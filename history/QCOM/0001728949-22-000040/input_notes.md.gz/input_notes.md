# QCOM notes — 0001728949-22-000040


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001728949-22-000040:notes:1]
Basis of Presentation and Significant Accounting Policies Update
Financial Statement Preparation. These condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with our Annual Report on Form 10-K for our fiscal year ended September 26, 2021. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. We operate and report using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three and nine months ended June 26, 2022 and June 27, 2021 included 13 weeks and 39 weeks, respectively.

[0001728949-22-000040:notes:2]
[same as prior period, unchanged from 0001728949-22-000026:notes:2]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001728949-22-000040:notes:3]
[same as prior period, unchanged from 0001728949-22-000026:notes:3]

[0001728949-22-000040:notes:4]
| Inventories (in millions) |  |  |  |
|  | June 26,2022 |  | September 26,2021 |
| Raw materials | $ | 267 |  |  | $ | 267 |  |
| Work-in-process | 2,778 |  |  | 1,475 |  |
| Finished goods | 2,373 |  |  | 1,486 |  |
|  | $ | 5,418 |  |  | $ | 3,228 |  |

[0001728949-22-000040:notes:5]
Revenues. We disaggregate our revenues by segment (Note 7), by products and services (as presented on our condensed consolidated statement of operations), and for our QCT (Qualcomm CDMA Technologies) segment, by revenue stream, which is based on the industry and application in which our products are sold (as presented below). In certain cases, the determination of QCT revenues by industry and application requires the use of certain assumptions. Substantially all of QCT’s revenues consist of equipment revenues that are recognized at a point in time, and substantially all of QTL’s (Qualcomm Technology Licensing) revenues represent licensing revenues that are recognized over time and are principally from royalties generated through our licensees’ sales of mobile handsets. QCT revenue streams were as follows (in millions):

[0001728949-22-000040:notes:6]
|  |  |  |  |  |  |  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  |  |  | June 26,2022 |  | June 27,2021 |  | June 26,2022 |  | June 27,2021 |
| Handsets (1) |  |  |  |  |  |  |  |  | $ | 6,149 |  |  | $ | 3,863 |  |  | $ | 18,457 |  |  | $ | 12,144 |  |
| RFFE (2) |  |  |  |  |  |  |  |  | 1,046 |  |  | 957 |  |  | 3,338 |  |  | 2,921 |  |
| Automotive (3) |  |  |  |  |  |  |  |  | 350 |  |  | 253 |  |  | 945 |  |  | 705 |  |
| IoT (internet of things) (4) |  |  |  |  |  |  |  |  | 1,833 |  |  | 1,399 |  |  | 5,033 |  |  | 3,517 |  |
| Total QCT revenues |  |  |  |  |  |  |  |  | $ | 9,378 |  |  | $ | 6,472 |  |  | $ | 27,773 |  |  | $ | 19,287 |  |

[0001728949-22-000040:notes:7]
[same as prior period, unchanged from 0001728949-22-000026:notes:9]

[0001728949-22-000040:notes:8]
[same as prior period, unchanged from 0001728949-22-000026:notes:10]

[0001728949-22-000040:notes:9]
[same as prior period, unchanged from 0001728949-22-000026:notes:11]

[0001728949-22-000040:notes:10]
[same as prior period, unchanged from 0001728949-22-000026:notes:12]

[0001728949-22-000040:notes:11]
[same as prior period, unchanged from 0001728949-22-000026:notes:13]

[0001728949-22-000040:notes:12]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2022 (1) |  | June 27,2021 (2) |  | June 26,2022 (1) |  | June 27,2021 (2) |
| Revenues recognized from previously satisfied performance obligations | $ | 260 |  |  | $ | 170 |  |  | $ | 578 |  |  | $ | 258 |  |

[0001728949-22-000040:notes:13]
(1) Primarily related to certain QCT sales-based royalty revenues related to system software, certain QCT customer incentives and QTL royalty revenues recognized related to devices sold in prior periods (including adjustments to prior period royalty estimates, which includes the impact of the reporting by our licensees of actual royalties due).

[0001728949-22-000040:notes:14]
(2) Primarily related to QCT customer incentives, the release of a variable constraint against revenues not previously allocated to our segment results and QTL royalty revenues recognized related to devices sold in prior periods (including adjustments to prior period royalty estimates, which includes the impact of the reporting by our licensees of actual royalties due).

[0001728949-22-000040:notes:15]
Unearned revenues (which are considered contract liabilities) consist primarily of license fees for intellectual property with continuing performance obligations. In the nine months ended June 26, 2022 and June 27, 2021, we recognized revenues of $482 million and $437 million, respectively, that were recorded as unearned revenues at September 26, 2021 and September 27, 2020, respectively.

[0001728949-22-000040:notes:16]
Remaining performance obligations, substantially all of which are included in unearned revenues, represent the aggregate amount of the transaction price of certain customer contracts yet to be recognized as revenues as of the end of the reporting period and exclude revenues related to (a) contracts that have an original expected duration of one year or less and (b) sales-based royalties (i.e., future royalty revenues) pursuant to our license agreements. Our remaining performance obligations are primarily comprised of certain customer contracts for which we received license fees upfront. At June 26, 2022, we had $849 million of remaining performance obligations, of which $210 million, $417 million, $157 million, $55 million and $6 million was expected to be recognized as revenues for the remainder of fiscal 2022 and each of the subsequent four years from fiscal 2023 through 2026, respectively, and $4 million thereafter.

[0001728949-22-000040:notes:17]
[same as prior period, unchanged from 0001728949-22-000026:notes:19]

[0001728949-22-000040:notes:18]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2022 |  | June 27,2021 |  | June 26,2022 |  | June 27,2021 |
| Customer/licensee (w) | 22 | % |  | 13 | % |  | 20 | % |  | 14 | % |
| Customer/licensee (x) | 17 |  |  | 16 |  |  | 20 |  |  | 22 |  |
| Customer/licensee (y) | * |  | 16 |  |  | * |  | 14 |  |
| Customer/licensee (z) | * |  | 10 |  |  | * |  | 10 |  |

[0001728949-22-000040:notes:19]
[same as prior period, unchanged from 0001728949-22-000026:notes:21]

[0001728949-22-000040:notes:20]
Other Income, Costs and Expenses. In the third quarter of fiscal 2022, the General Court of the European Union issued a ruling annulling a decision made by the European Commission (EC) in fiscal 2018 (Note 6). As a result of the court’s decision, we recorded a $1.1 billion benefit to other income in the three months ended June 26, 2022.

[0001728949-22-000040:notes:21]
| Investment and Other (Expense) Income, Net (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2022 |  | June 27,2021 |  | June 26,2022 |  | June 27,2021 |
| Interest and dividend income | $ | 22 |  |  | $ | 21 |  |  | $ | 59 |  |  | $ | 63 |  |
| Net (losses) gains on marketable securities | (104) |  |  | 53 |  |  | (327) |  |  | 86 |  |
| Net gains on other investments | 25 |  |  | 97 |  |  | 97 |  |  | 307 |  |
| Net (losses) gains on deferred compensation plan assets | (80) |  |  | 38 |  |  | (110) |  |  | 115 |  |
| Impairment losses on other investments | (20) |  |  | (7) |  |  | (41) |  |  | (24) |  |
| Net losses on derivative instruments | (7) |  |  | — |  |  | (25) |  |  | (7) |  |
| Equity in net (losses) earnings of investees | (12) |  |  | 1 |  |  | 5 |  |  | 12 |  |
| Net gains (losses) on foreign currency transactions | 13 |  |  | (3) |  |  | 21 |  |  | (29) |  |
|  | $ | (163) |  |  | $ | 200 |  |  | $ | (321) |  |  | $ | 523 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001728949-22-000040:notes:22]
Income Taxes
We estimate our annual effective income tax rate to be 13% for fiscal 2022, which is lower than the U.S. federal statutory rate primarily due to (i) a significant portion of our income qualifying for preferential treatment as foreign-derived intangible income (FDII) at a 13% effective tax rate, (ii) the reversal of the 2018 EC fine (Note 6), which is not taxable and is attributable to a foreign jurisdiction, (iii) excess tax benefits associated with share-based awards and (iv) benefits from our federal research and development tax credit. Our effective tax rate of 12% for the third quarter of fiscal 2022 was lower than our estimated annual effective tax rate of 13% primarily due to the benefit from the reversal of the EC fine in the third quarter, partially offset by $47 million of net discrete tax charges, which principally related to foreign currency losses on a noncurrent receivable related to our refund claim of Korean withholding tax, partially offset by excess tax benefits associated with share-based awards that vested in the third fiscal quarter. Our effective tax rate of 10% for the third quarter of fiscal 2021 included $64 million of discrete net tax benefits, which principally related to excess tax benefits associated with share-based awards that vested in the third fiscal quarter.

[0001728949-22-000040:notes:23]
Unrecognized tax benefits were $2.2 billion and $2.1 billion at June 26, 2022 and September 26, 2021, respectively, and primarily related to our refund claim of Korean withholding tax. If successful, the refund will result in a corresponding reduction in U.S. foreign tax credits. We expect that the total amount of unrecognized tax benefits at June 26, 2022 will increase in the next 12 months as licensees in Korea continue to withhold taxes on future payments due under their licensing agreements at a rate higher than we believe is owed; such increase is not expected to have a significant impact on our income tax provision.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001728949-22-000040:notes:24]
Capital Stock
Stock Repurchase Program. On October 12, 2021, we announced a $10.0 billion stock repurchase program. The stock repurchase program has no expiration date. At June 26, 2022, $8.6 billion remained authorized for repurchase under our stock repurchase program.

[0001728949-22-000040:notes:25]
Shares Outstanding. Shares of common stock outstanding at June 26, 2022 were as follows (in millions):

[0001728949-22-000040:notes:26]
| Balance at September 26, 2021 | 1,125 |  |
| Issued | 15 |  |
| Repurchased | (18) |  |
| Balance at June 26, 2022 | 1,122 |  |

[0001728949-22-000040:notes:27]
Dividends. On July 15, 2022, we announced a cash dividend of $0.75 per share on our common stock, payable on September 22, 2022 to stockholders of record as of the close of business on September 1, 2022.

[0001728949-22-000040:notes:28]
Earnings Per Common Share. Basic earnings per common share is computed by dividing net income by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per share is computed by dividing net income by the combination of the weighted-average number of dilutive common share equivalents, comprised of

[0001728949-22-000040:notes:29]
shares issuable under our share-based compensation plans and the weighted-average number of common shares outstanding during the reporting period. The following table provides information about the diluted earnings per share calculation (in millions):

[0001728949-22-000040:notes:30]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2022 |  | June 27,2021 |  | June 26,2022 |  | June 27,2021 |
| Dilutive common share equivalents included in diluted shares | 12 |  |  | 16 |  |  | 15 |  |  | 19 |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | 2 |  |  | — |  |  | 1 |  |  | — |  |


## us-gaap:DebtDisclosureTextBlock

[0001728949-22-000040:notes:31]
Debt
Long-term Debt. In May 2022, we issued unsecured fixed-rate notes, consisting of $500 million of fixed-rate 4.25% notes and $1.0 billion of fixed-rate 4.50% notes (May 2022 Notes) that mature on May 20, 2032 and May 20, 2052, respectively. The net proceeds from the May 2022 Notes, together with cash on hand, were used to repay $1.5 billion of fixed-rate notes that matured in May 2022.

[0001728949-22-000040:notes:32]
The following table provides a summary of our long-term debt:

[0001728949-22-000040:notes:33]
|  | June 26, 2022 |  | September 26, 2021 |
|  | Maturities |  | Amount(in millions) |  | Effective Rate |  | Maturities |  | Amount(in millions) |  | Effective Rate |
| May 2015 Notes | 2025 - 2045 |  | $ | 3,865 |  |  | 3.46% - 4.73% |  | 2022 - 2045 |  | $ | 5,405 |  |  | 2.63% - 4.73% |
| May 2017 Notes | 2023 - 2047 |  | 5,860 |  |  | 2.03% - 4.46% |  | 2023 - 2047 |  | 5,860 |  |  | 0.92% - 4.46% |
| May 2020 Notes | 2030 - 2050 |  | 2,000 |  |  | 2.73% - 3.30% |  | 2030 - 2050 |  | 2,000 |  |  | 2.31% - 3.30% |
| August 2020 Notes | 2028 - 2032 |  | 2,207 |  |  | 2.32% - 3.27% |  | 2028 - 2032 |  | 2,207 |  |  | 1.98% - 2.66% |
| May 2022 Notes | 2032 - 2052 |  | 1,500 |  |  | 3.14% - 4.26% |  |  |  | — |  |  |  |
| Total principal |  |  | 15,432 |  |  |  |  |  |  | 15,472 |  |  |  |
| Unamortized discount, including debt issuance costs |  | (249) |  |  |  |  |  |  | (234) |  |  |  |
| Hedge accounting fair value adjustments |  | (138) |  |  |  |  |  |  | 7 |  |  |  |
| Total long-term debt |  |  | $ | 15,045 |  |  |  |  |  |  | $ | 15,245 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt |  |  | $ | 1,445 |  |  |  |  |  |  | $ | 1,544 |  |  |  |
| Long-term debt |  |  | 13,600 |  |  |  |  |  |  | 13,701 |  |  |  |
| Total |  |  | $ | 15,045 |  |  |  |  |  |  | $ | 15,245 |  |  |  |

[0001728949-22-000040:notes:34]
At June 26, 2022, the aggregate fair value of our outstanding floating- and fixed-rate notes, based on Level 2 inputs, was approximately $14.6 billion.

[0001728949-22-000040:notes:35]
Interest Rate Swaps. At September 26, 2021, we had outstanding forward-starting interest rate swaps with an aggregate notional amount, denominated in U.S. dollars, of $2.6 billion. During the third quarter of fiscal 2022, we terminated $1.0 billion of these swaps associated with our May 2022 Notes, and the related gains of $123 million are being reclassified from accumulated comprehensive income as a reduction to interest expense over the terms of the related debt.

[0001728949-22-000040:notes:36]
Beginning in the second quarter of fiscal 2022, we entered into interest rate swaps that are designated as fair value hedges and allow us to effectively convert fixed-rate payments into floating-rate payments on a portion of our outstanding long-term debt. We entered into these agreements, in part, to manage interest rate risk associated with our cash equivalents and marketable securities, in addition to changes in the fair value of our outstanding debt. At June 26, 2022, the notional amount of these swaps, which are denominated in U.S. dollars and mature between 2027 and 2032, was $2.1 billion. The fair value of these swaps, which is included in other noncurrent liabilities, was $141 million at June 26, 2022. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate notes attributable to the hedged risks, are recognized in earnings as interest expense in the current period.
Commercial Paper Program. We have an unsecured commercial paper program, which provides for the issuance of up to $4.5 billion. At June 26, 2022 and September 26, 2021, we had $500 million of outstanding commercial paper recorded as short-term debt.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001728949-22-000040:notes:37]
Commitments and Contingencies
Legal and Regulatory Proceedings.

[0001728949-22-000040:notes:38]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of us in the United States District Court for the Southern District of California against us and certain of our then current and former officers and directors. The complaints alleged, among other things, that we violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that we are or were engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions. On July 3, 2017, the plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, we filed a motion to dismiss the consolidated amended complaint, and on March 18, 2019, the court denied our motion. On January 15, 2020, we filed a motion for judgment on the pleadings, which the court denied on February 3, 2022. On May 23, 2022, the plaintiffs filed a motion for class certification. The court has not yet ruled on the motion, and no trial date has been set. We believe the plaintiffs’ claims are without merit.

[0001728949-22-000040:notes:39]
Consumer Class Action Lawsuits: Beginning in January 2017, a number of consumer class action complaints were filed against us in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that we violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to our competitors, conditioning the supply of certain of our baseband chipsets on the purchaser first agreeing to license our entire patent portfolio, entering into exclusive deals with companies, including Apple Inc., and charging unreasonably high royalties that do not comply with our commitments to standard setting organizations. The complaint sought unspecified damages and disgorgement and/or restitution, as well as an order that we be enjoined from further unlawful conduct. On August 11, 2017, we filed a motion to dismiss the consolidated amended complaint. On November 10, 2017, the court denied our motion, except to the extent that certain claims seek damages under the Sherman Antitrust Act. On July 5, 2018, the plaintiffs filed a motion for class certification, and on September 27, 2018, the court granted that motion. We appealed the district court’s class certification order to the United States Court of Appeals for the Ninth Circuit (Ninth Circuit), and on September 29, 2021, the Ninth Circuit vacated the class certification order, ruling that the district court had failed to correctly assess the propriety of applying California law to a nationwide class. The Ninth Circuit remanded the case to the district court and instructed the court to consider the effect of United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated (which the Ninth Circuit decided in favor of Qualcomm in August 2020) on this case. On June 10, 2022, the plaintiffs filed an amended complaint, limiting the proposed class to California residents rather than a nationwide class. We believe the plaintiffs’ claims are without merit.

[0001728949-22-000040:notes:40]
Since November 2017, several other consumer class action complaints have been filed against us in Canada (in the Supreme Court of British Columbia and the Quebec Superior Court), Israel (in the Haifa District Court) and the United Kingdom (in the Competition Appeal Tribunal), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging violations of certain of those countries’ competition and consumer protection laws. The claims in these complaints are similar to those in the U.S. consumer class action complaints. The complaints seek damages. We believe the plaintiffs’ claims are without merit.

[0001728949-22-000040:notes:41]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against us in the United States District Court for the Middle District of Florida alleging that certain of our products infringed seven ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, alleging that we infringed 11 ParkerVision patents and sought damages and injunctive and other relief. ParkerVision subsequently reduced the number of patents asserted to three. The asserted patents are now expired, and injunctive relief is no longer available. ParkerVision continues to seek damages related to the sale of many of our radio frequency (RF) products sold between 2008 and 2018. On March 23, 2022, the court entered judgment in our favor on all claims and closed the case. On April 20, 2022, ParkerVision filed a

[0001728949-22-000040:notes:42]
notice of appeal to the United States Court of Appeals for the Federal Circuit. We believe that ParkerVision’s claims are without merit.

[0001728949-22-000040:notes:43]
Korea Fair Trade Commission (KFTC) Investigation (2015): On March 17, 2015, the KFTC notified us that it was conducting an investigation of us relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that we violated provisions of the MRFTA. On January 22, 2017, we received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with us; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders us to: (a) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (b) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chipsets; (c) not demand unjustifiable conditions in our license agreements with handset companies and, upon request, renegotiate existing patent license agreements; and (d) notify modem chipset companies and handset companies of the decision and order imposed on us and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between us and the following enterprises: (1) handset manufacturers headquartered in Korea and their affiliate companies; (2) enterprises that sell handsets in or to Korea and their affiliate companies; (3) enterprises that supply handsets to companies referred to in (2) above and the affiliate companies of such enterprises; (4) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (5) enterprises that supply modem chipsets to companies referred to in (1), (2) or (3) above and the affiliate companies of such enterprises. The KFTC’s decision also imposed a fine of 1.03 trillion Korean won (approximately $927 million), which we paid on March 30, 2017.

[0001728949-22-000040:notes:44]
On February 21, 2017, we filed an action in the Seoul High Court to cancel the KFTC’s decision. The Seoul High Court held hearings concluding on August 14, 2019, and on December 4, 2019, announced its judgment affirming certain portions of the KFTC’s decision and finding other portions of the KFTC’s decision unlawful. The Seoul High Court cancelled the KFTC’s remedial orders described in (c) above, and solely insofar as they correspond thereto, the Seoul High Court cancelled the KFTC’s remedial orders described in (d) above. The Seoul High Court dismissed the remainder of our action to cancel the KFTC’s decision. On December 19, 2019, we filed a notice of appeal to the Korea Supreme Court challenging those portions of the Seoul High Court decision that are not in our favor. The KFTC filed a notice of appeal to the Korea Supreme Court challenging the portions of the Seoul High Court decision that are not in its favor. Both we and the KFTC have filed briefs on the merits. The Korea Supreme Court has not yet ruled on our appeal or that of the KFTC. We believe that our business practices do not violate the MRFTA.

[0001728949-22-000040:notes:45]
Korea Fair Trade Commission (KFTC) Investigation (2020): On June 8, 2020, the KFTC informed us that it was conducting an investigation of us relating to the MRFTA. The KFTC has not provided a formal notice on the scope of its investigation, but we believe it concerns our business practices in connection with our sale of radio frequency front-end (RFFE) components. We continue to cooperate with the KFTC as it conducts its investigation. If a violation is found, a broad range of remedies is potentially available to the KFTC, including imposing a fine (of up to 3% of our sales in the relevant markets during the alleged period of violation) and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the KFTC. We believe that our business practices do not violate the MRFTA.

[0001728949-22-000040:notes:46]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided us with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that we were engaged in anticompetitive activity. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On July 18, 2019, the EC issued a decision finding that between 2009 and 2011, we engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost with the intention of hindering competition and imposed a fine of approximately 242 million euros. On October 1, 2019, we filed an appeal of the EC’s decision with the General Court of the European Union. The court has not yet ruled on our appeal. We believe that our business practices do not violate the European Union (EU) competition rules.

[0001728949-22-000040:notes:47]
In the third quarter of fiscal 2019, we recorded a charge of $275 million to other expenses related to this EC fine. We provided a financial guarantee in the first quarter of fiscal 2020 to satisfy the obligation in lieu of cash payment while we appeal the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum while it is outstanding. In the fourth

[0001728949-22-000040:notes:48]
quarter of fiscal 2019, we designated the liability as a hedge of our net investment in a certain foreign subsidiary, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. At June 26, 2022, the liability, including related foreign currency gains and accrued interest (which, to the extent they were not related to the net investment hedge, were recorded in investment and other (expense) income, net), was $266 million and included in other current liabilities.

[0001728949-22-000040:notes:49]
European Commission (EC) Investigation: On October 15, 2014, the EC notified us that it was conducting an investigation of us relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On January 24, 2018, the EC issued a decision finding that pursuant to an agreement with Apple Inc. we paid significant amounts to Apple on the condition that it exclusively use our baseband chipsets in its smartphones and tablets, reducing Apple’s incentives to source baseband chipsets from our competitors and harming competition and innovation for certain baseband chipsets, and imposed a fine of 997 million euros. On April 6, 2018, we filed an appeal of the EC’s decision with the General Court of the European Union. From May 4, 2021 to May 6, 2021, a hearing on our appeal was held before the court. On June 15, 2022, the court issued a ruling annulling the EC’s decision in its entirety. Any appeal of the General Court’s decision must be brought before the European Court of Justice by late August 2022.

[0001728949-22-000040:notes:50]
In the first quarter of fiscal 2018, we recorded a charge of $1.2 billion to other expenses related to this EC fine. We provided financial guarantees in the third quarter of fiscal 2018 to satisfy the obligation in lieu of cash payment while we appealed the EC’s decision. The fine accrued interest at a rate of 1.50% per annum while it was outstanding. In the first quarter of fiscal 2019, we designated the liability as a hedge of our net investment in certain foreign subsidiaries, with gains and losses recorded in accumulated other comprehensive income as a component of the foreign currency translation adjustment. As a result of the court’s ruling, in the third quarter of fiscal 2022, we recorded a $1.1 billion benefit in other income and a $62 million reduction in interest expense resulting from the reversal of the accrued fine and the associated interest previously recorded. We also discontinued the net investment hedge related to this fine. The associated foreign currency gains will remain in accumulated other comprehensive income until the foreign subsidiaries are sold or substantially liquidated, at which point it will be reclassified into earnings.

[0001728949-22-000040:notes:51]
Contingent Losses and Other Considerations: We will continue to vigorously defend ourselves in the foregoing matters. However, litigation and investigations are inherently uncertain, and we face difficulties in evaluating or estimating likely outcomes or ranges of possible loss, particularly in antitrust and trade regulation investigations. Other than with respect to the EC fine related to the Icera Complaint to the European Commission, we have not recorded any accrual at June 26, 2022 for contingent losses associated with these matters based on our belief that losses, while reasonably possible, are not probable. Further, any possible amount or range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition or cash flows. We are engaged in numerous other legal actions not described above arising in the ordinary course of our business (for example, proceedings relating to employment matters or the initiation or defense of proceedings relating to intellectual property rights) and, while there can be no assurance, we believe that the ultimate outcome of these other legal actions will not have a material adverse effect on our business, results of operations, financial condition or cash flows.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001728949-22-000040:notes:52]
Segment InformationWe are organized on the basis of products and services and have three reportable segments. Our operating segments reflect the way our businesses and management/reporting structure are organized internally and the way our Chief Operating Decision Maker (CODM), who is our CEO, reviews financial information, makes operating decisions and assesses business performance. We also consider, among other items, the way budgets and forecasts are prepared and reviewed and the basis on which executive compensation is determined, as well as the similarity of activities within our operating segments, such as the nature of products, the level of shared products, technology and other resources, production processes and customer base. We conduct business primarily through our QCT semiconductor business and our QTL licensing business. QCT develops and supplies integrated circuits and system software based on 3G/4G/5G and other technologies, including RFFE, for use in mobile devices, automotive systems for telematics, connectivity and digital cockpit and IoT including wireless networks, broadband gateway equipment, consumer electronic devices and industrial devices. QTL grants licenses or otherwise provides rights to use portions of our intellectual property portfolio, which includes certain patent rights essential to and/or useful in the manufacture and sale of certain wireless products. Our QSI (Qualcomm Strategic Initiatives) reportable segment makes strategic investments. We also have nonreportable segments, including QGOV (Qualcomm Government Technologies), our cloud AI inference processing initiative and other technology and service initiatives.
Our CODM allocates resources to and evaluates the performance of our segments based on revenues and earnings (loss) before income taxes (EBT). Segment EBT includes the allocation of certain corporate expenses to the segments, including depreciation and amortization expense related to unallocated corporate assets. Certain income and charges are not allocated to segments in our management reports because they are not considered in evaluating the segments’ operating performance. Unallocated income and charges include certain interest expense, certain net investment income, certain share-based compensation, gains and losses on our deferred compensation plan liabilities and related assets and certain research and development expenses, certain selling, general and administrative expenses and other expenses or income that were deemed to be not directly related to the businesses of the segments. Additionally, unallocated charges include recognition of the step-up of inventories and property, plant and equipment to fair value, amortization of certain intangible assets and certain other acquisition-related charges, third-party acquisition and integration services costs and certain other items, which may include major restructuring and restructuring-related costs, asset impairment charges and awards, settlements and/or damages arising from legal or regulatory matters. Our CODM does not evaluate our operating segments using discrete asset information.

[0001728949-22-000040:notes:53]
[same as prior period, unchanged from 0001728949-22-000026:notes:47]

[0001728949-22-000040:notes:54]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2022 |  | June 27,2021 |  | June 26,2022 |  | June 27,2021 |
| Revenues |  |  |  |  |  |  |  |
| QCT | $ | 9,378 |  |  | $ | 6,472 |  |  | $ | 27,773 |  |  | $ | 19,287 |  |
| QTL | 1,519 |  |  | 1,489 |  |  | 4,917 |  |  | 4,762 |  |
| QSI | 8 |  |  | 11 |  |  | 22 |  |  | 30 |  |
| Reconciling items | 31 |  |  | 88 |  |  | 93 |  |  | 151 |  |
| Total | $ | 10,936 |  |  | $ | 8,060 |  |  | $ | 32,805 |  |  | $ | 24,230 |  |
| EBT |  |  |  |  |  |  |  |
| QCT | $ | 2,996 |  |  | $ | 1,795 |  |  | $ | 9,450 |  |  | $ | 5,299 |  |
| QTL | 1,080 |  |  | 1,053 |  |  | 3,640 |  |  | 3,514 |  |
| QSI | (101) |  |  | 156 |  |  | (248) |  |  | 412 |  |
| Reconciling items | 264 |  |  | (747) |  |  | (1,314) |  |  | (2,236) |  |
| Total | $ | 4,239 |  |  | $ | 2,257 |  |  | $ | 11,528 |  |  | $ | 6,989 |  |

[0001728949-22-000040:notes:55]
[same as prior period, unchanged from 0001728949-22-000026:notes:49]

[0001728949-22-000040:notes:56]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2022 |  | June 27,2021 |  | June 26,2022 |  | June 27,2021 |
| Revenues |  |  |  |  |  |  |  |
| Nonreportable segments | $ | 31 |  |  | $ | 34 |  |  | $ | 93 |  |  | $ | 97 |  |
| Unallocated revenues (Note 2) | — |  |  | 54 |  |  | — |  |  | 54 |  |
|  | $ | 31 |  |  | $ | 88 |  |  | $ | 93 |  |  | $ | 151 |  |
| EBT |  |  |  |  |  |  |  |
| Unallocated revenues (Note 2) | $ | — |  |  | $ | 54 |  |  | $ | — |  |  | $ | 54 |  |
| Unallocated cost of revenues | (76) |  |  | (73) |  |  | (182) |  |  | (220) |  |
| Unallocated research and development expenses | (408) |  |  | (505) |  |  | (1,294) |  |  | (1,325) |  |
| Unallocated selling, general and administrative expenses | (171) |  |  | (125) |  |  | (462) |  |  | (418) |  |
| Unallocated other income (Note 2) | 1,059 |  |  | — |  |  | 1,059 |  |  | — |  |
| Unallocated interest expense (Note 6) | (69) |  |  | (138) |  |  | (345) |  |  | (420) |  |
| Unallocated investment and other (expense) income, net | (58) |  |  | 55 |  |  | (68) |  |  | 140 |  |
| Nonreportable segments | (13) |  |  | (15) |  |  | (22) |  |  | (47) |  |
|  | $ | 264 |  |  | $ | (747) |  |  | $ | (1,314) |  |  | $ | (2,236) |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001728949-22-000040:notes:57]
Acquisitions 
Nuvia. On March 16, 2021, we completed the acquisition of NuVia, Inc. (Nuvia) for $1.1 billion (net of $174 million cash acquired), substantially all of which was paid in cash. In connection with the acquisition, we assumed or replaced unvested Nuvia stock awards with Qualcomm stock awards with an estimated fair value of $258 million, which have post-acquisition requisite service periods of up to four years. Nuvia has certain in-process technologies and is comprised of a CPU (central processing unit) and technology design team with expertise in high performance processors, SoC (system-on-chip) and power management for compute-intensive devices and applications. Upon completion of development, Nuvia’s technologies are expected to be integrated into certain QCT products. We recorded $885 million of goodwill, which is not deductible for tax purposes and was allocated to our QCT segment for annual impairment testing purposes. Goodwill is primarily attributable to assembled workforce and certain revenue and cost synergies expected to arise after the acquisition. We also recorded a $247 million in-process research and development intangible asset related to a single project, which is expected to be completed in fiscal 2023 and, upon completion, will be amortized over its useful life, which is expected to be seven years. Our results of operations for fiscal 2021 included the operating results of Nuvia since the acquisition date, the amounts of which were not material.

[0001728949-22-000040:notes:58]
Veoneer. On October 4, 2021, we and SSW Partners, a New York-based investment partnership, entered into a definitive agreement to acquire Veoneer, Inc. (Veoneer). The transaction closed on April 1, 2022 (the Closing Date). Total cash consideration paid in the transaction was approximately $4.7 billion, consisting of (i) approximately $4.6 billion paid in respect of Veoneer’s outstanding capital stock and equity awards and amounts paid to settle Veoneer’s convertible senior notes (which were converted at the election of the note holders and settled in cash in the third quarter of fiscal 2022) and (ii) a $110 million termination fee paid to Magna International Inc. (Magna) in the first quarter of fiscal 2022. We funded substantially all of the cash consideration payable in the transaction in exchange for (i) the Arriver business (which SSW transferred to us shortly after the Closing Date) and (ii) the right to receive a majority of the proceeds upon the sale of the Non-Arriver businesses by SSW Partners. We intend to incorporate Arriver’s computer vision, drive policy and driver assistance technologies into our Snapdragon automotive platform to deliver an integrated software SoC ADAS (advanced driver assistance systems) platform for automakers and Tier-1 automotive suppliers. SSW Partners retained Veoneer’s Tier-1 automotive supplier businesses, primarily consisting of the Active Safety and Restraint Control Systems businesses (the Non-Arriver businesses), which it intends to sell in one or more transactions.

[0001728949-22-000040:notes:59]
We have agreed to provide certain funding of approximately $300 million to the Non-Arriver businesses while SSW Partners seeks a buyer(s), of which approximately $150 million of funding remained available to the Non-Arriver businesses at June 26, 2022. Such amounts, along with cash retained in the Non-Arriver business, are expected to be used to fund working and other near-term capital needs, as well as certain costs incurred in connection with the close of the acquisition.

[0001728949-22-000040:notes:60]
Although we do not own or operate the Non-Arriver businesses, we have determined that we are the primary beneficiary, within the meaning of the Financial Accounting Standards Board (FASB) accounting guidance related to consolidation (ASC 810), of these businesses under the variable interest model. Factors considered in reaching this conclusion included, among others: (i) our involvement in the design of and our funding of substantially all of the total cash consideration payable in the transaction and (ii) our obligations to absorb losses and rights to receive returns from the Non-Arriver businesses. We expect that SSW Partners will complete the sale of the Non-Arriver businesses within fiscal 2023, subject to any required regulatory approvals and other closing conditions being met. Accordingly, the assets and liabilities of the Non-Arriver businesses are consolidated and presented as held for sale (in other current and noncurrent assets and liabilities on our balance sheet), and the operating results will be presented as discontinued operations.

[0001728949-22-000040:notes:61]
Our accounting purchase price was approximately $4.3 billion, substantially all of which relates to our share of cash consideration at close for the outstanding common shares of Veoneer and the Magna termination fee and excludes Veoneer’s convertible senior notes that are reflected as an assumed liability.

[0001728949-22-000040:notes:62]
We have not finalized the purchase price allocation. Accordingly, the preliminary purchase price allocation shown below could change as the fair values of the tangible and intangible assets acquired and liabilities assumed, and the related income tax effects, are finalized during the remainder of the measurement period (which will not exceed 12 months from the Closing

[0001728949-22-000040:notes:63]
Date). The preliminary allocation of the purchase price to the assets acquired and liabilities assumed based on their fair values was as follows (in millions):

[0001728949-22-000040:notes:64]
| Cash | $ | 31 |  |
| Current held for sale assets, net of costs to sell (1) | 667 |
| Completed technology-based intangible assets | 349 |
| In-process research and development (IPR&D) | 298 |  |
| Goodwill | 3,016 |  |
| Noncurrent held for sale assets (1) | 916 |  |
| Other assets | 333 |  |
| Total assets | 5,610 |  |
| Current held for sale liabilities (1) | (677) |  |
| Convertible senior notes | (352) |  |
| Noncurrent held for sale liabilities (1) | (128) |  |
| Other liabilities | (202) |  |
| Total liabilities | (1,359) |  |
| Net assets acquired | $ | 4,251 |  |

[0001728949-22-000040:notes:65]
(1) Held for sale assets and liabilities relate to the Non-Arriver businesses and were measured at fair value less costs to sell (including SSW Partners’ estimated return with respect to the sale proceeds of the Non-Arriver businesses), which was estimated using a market approach based on significant inputs that were not observable. The Non-Arriver businesses’ assets are not available to be used to settle our obligations, and the Non-Arriver businesses’ creditors do not have recourse to us. SSW Partners owns and operates the Non-Arriver businesses, and its funding of the purchase price for Veoneer was recorded as a component of held for sale liabilities. The underlying classes of assets and liabilities held for sale have not been presented because such amounts are not material.

[0001728949-22-000040:notes:66]
Goodwill related to this transaction was allocated to our QCT segment, and $471 million of which is expected to be deductible for tax purposes. Goodwill is primarily attributable to assembled workforce and certain synergies expected to arise after the acquisition. Completed technology-based intangible assets will be amortized on a straight-line basis over the weighted-average useful life of nine years. IPR&D relates to a single project that is expected to be completed in fiscal 2025. Upon completion, we expect the IPR&D to be amortized over its useful life of seven years. We valued the completed technology and IPR&D using an income approach based on significant unobservable inputs.

[0001728949-22-000040:notes:67]
The operating results of the Arriver and Non-Arriver businesses are reported on a one quarter lag. Therefore, no such amounts were included in our results of operations for the three and nine months ended June 26, 2022. Pro forma results of operations have not been presented because the effects of this acquisition were not material to our consolidated results of operations.

[0001728949-22-000040:notes:68]
Other. During the first nine months of fiscal 2022, we acquired six other businesses for a total accounting purchase price of $660 million. We recognized $143 million of intangible assets (which primarily relate to completed technology) that will be amortized on a straight-line basis over a weighted-average useful life of six years. Substantially all of the goodwill recognized in these transactions of $527 million was allocated to our QCT segment.


## us-gaap:FairValueDisclosuresTextBlock

[0001728949-22-000040:notes:69]
Fair Value Measurements
The following table presents our fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at June 26, 2022 (in millions):

[0001728949-22-000040:notes:70]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 882 |  |  | $ | 222 |  |  | $ | — |  |  | $ | 1,104 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | — |  |  | 3,802 |  |  | — |  |  | 3,802 |  |
| Equity securities | 246 |  |  | — |  |  | — |  |  | 246 |  |
| Mortgage- and asset-backed securities | — |  |  | 108 |  |  | — |  |  | 108 |  |
| U.S. Treasury securities and government-related securities | — |  |  | 16 |  |  | — |  |  | 16 |  |
| Total marketable securities | 246 |  |  | 3,926 |  |  | — |  |  | 4,172 |  |
| Derivative instruments | — |  |  | 207 |  |  | — |  |  | 207 |  |
| Other investments | 642 |  |  | — |  |  | 16 |  |  | 658 |  |
| Total assets measured at fair value | $ | 1,770 |  |  | $ | 4,355 |  |  | $ | 16 |  |  | $ | 6,141 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 172 |  |  | $ | — |  |  | $ | 172 |  |
| Other liabilities | 642 |  |  | — |  |  | 1 |  |  | 643 |  |
| Total liabilities measured at fair value | $ | 642 |  |  | $ | 172 |  |  | $ | 1 |  |  | $ | 815 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001728949-22-000040:notes:71]
Marketable Securities
Our marketable securities were all classified as current and were comprised as follows (in millions):

[0001728949-22-000040:notes:72]
|  | June 26,2022 |  | September 26,2021 |  |  |  |  |
| Available-for-sale debt securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | $ | 3,802 |  |  | $ | 4,459 |  |  |  |  |  |
| Mortgage- and asset-backed securities | 108 |  |  | 147 |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | 16 |  |  | 10 |  |  |  |  |  |
| Total available-for-sale debt securities | 3,926 |  |  | 4,616 |  |  |  |  |  |
| Equity securities | 246 |  |  | 682 |  |  |  |  |  |
| Total marketable securities | $ | 4,172 |  |  | $ | 5,298 |  |  |  |  |  |

[0001728949-22-000040:notes:73]
The contractual maturities of available-for-sale debt securities were as follows (in millions):

[0001728949-22-000040:notes:74]
|  | June 26,2022 |
| Years to Maturity |  |
| Less than one year | $ | 959 |  |
| One to five years | 2,859 |  |
| No single maturity date | 108 |  |
| Total | $ | 3,926 |  |

[0001728949-22-000040:notes:75]
Debt securities with no single maturity date included mortgage- and asset-backed securities.
