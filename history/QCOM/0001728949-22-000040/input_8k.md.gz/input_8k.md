# QCOM 8-K — 0001728949-22-000039 filed 2022-07-27

## item codes, every 8-K on or before 2022-07-27

- 2022-07-27 0001728949-22-000039 — 2.02, 9.01
- 2022-05-09 0001104659-22-057562 — 1.01, 8.01, 9.01
- 2022-04-27 0001728949-22-000025 — 2.02, 9.01
- 2022-03-14 0001728949-22-000016 — 5.07
- 2022-02-02 0001728949-22-000011 — 2.02, 9.01
- 2021-11-03 0001728949-21-000075 — 2.02, 9.01
- 2021-10-04 0001104659-21-122578 — 1.01, 7.01, 9.01
- 2021-07-28 0001728949-21-000065 — 2.02, 9.01
- 2021-07-23 0001728949-21-000055 — 5.03, 9.01
- 2021-05-21 0001728949-21-000048 — 5.02
- 2021-04-28 0001728949-21-000042 — 2.02, 9.01
- 2021-03-15 0001628280-21-004741 — 5.07
- 2021-02-03 0001728949-21-000021 — 2.02, 9.01
- 2021-01-13 0001728949-21-000009 — 1.01, 9.01
- 2021-01-08 0001728949-21-000004 — 5.02
- 2020-12-10 0001104659-20-134200 — 1.01, 1.02, 2.03, 9.01
- 2020-11-19 0001728949-20-000070 — 5.02
- 2020-11-04 0001728949-20-000066 — 2.02, 9.01
- 2020-08-18 0001104659-20-096322 — 1.01, 8.01, 9.01
- 2020-08-05 0001104659-20-090597 — 8.01, 9.01
- 2020-07-29 0001728949-20-000056 — 2.02, 9.01
- 2020-07-24 0001728949-20-000047 — 5.02
- 2020-05-11 0001104659-20-058923 — 1.01, 8.01, 9.01
- 2020-05-04 0001728949-20-000037 — 5.02
- 2020-04-29 0001728949-20-000030 — 2.02, 9.01
- 2020-03-13 0001728949-20-000015 — 5.07
- 2020-02-05 0001728949-20-000010 — 2.02, 9.01
- 2019-11-06 0001728949-19-000074 — 5.02
- 2019-11-06 0001728949-19-000071 — 2.02, 9.01
- 2019-08-28 0001728949-19-000058 — 5.02
- 2019-07-31 0001728949-19-000053 — 2.02, 9.01
- 2019-05-10 0001728949-19-000044 — 5.02
- 2019-05-01 0001728949-19-000034 — 2.02, 9.01
- 2019-04-16 0001728949-19-000026 — 7.01, 9.01
- 2019-04-11 0001728949-19-000024 — 5.02 — amendment of 0001728949-19-000020
- 2019-04-05 0001728949-19-000020 — 5.02
- 2019-03-15 0001728949-19-000016 — 5.07
- 2019-01-30 0001728949-19-000011 — 2.02, 9.01
- 2018-12-06 0001728949-18-000100 — 5.02
- 2018-12-04 0001728949-18-000098 — 5.02
- 2018-11-07 0001728949-18-000093 — 2.02, 9.01
- 2018-10-09 0001728949-18-000085 — 5.02
- 2018-09-21 0001728949-18-000081 — 5.02, 9.01
- 2018-09-13 0001104659-18-056544 — 1.01, 9.01
- 2018-08-01 0001104659-18-048772 — 1.02, 2.04
- 2018-07-26 0001104659-18-047166 — 1.02, 7.01, 9.01
- 2018-07-25 0001728949-18-000074 — 2.02, 9.01
- 2018-07-17 0001728949-18-000063 — 5.03, 9.01
- 2018-06-28 0001728949-18-000060 — 5.02
- 2018-06-13 0000950157-18-000615 — 1.01, 2.03, 9.01
- 2018-06-05 0001193125-18-184011 — 1.01, 2.04, 8.01, 9.01
- 2018-05-29 0001193125-18-176081 — 8.01, 9.01
- 2018-05-25 0001728949-18-000049 — 5.02, 9.01
- 2018-05-21 0001193125-18-168810 — 8.01, 9.01
- 2018-05-21 0001193125-18-168730 — 8.01, 9.01
- 2018-04-25 0001728949-18-000038 — 2.02, 9.01
- 2018-04-24 0000950157-18-000470 — 1.01, 9.01
- 2018-04-20 0001728949-18-000029 — 5.03, 9.01
- 2018-04-19 0001104659-18-025001 — 1.01, 7.01, 9.01
- 2018-04-09 0001728949-18-000023 — 5.07 — amendment of 0001728949-18-000017
- 2018-03-29 0001728949-18-000017 — 5.07, 8.01
- 2018-03-19 0001104659-18-018402 — 9.01
- 2018-03-13 0001104659-18-016916 — 8.01, 9.01
- 2018-03-12 0001104659-18-016576 — 8.01, 9.01
- 2018-03-09 0001728949-18-000014 — 5.02
- 2018-03-09 0000950157-18-000274 — 1.01, 2.03, 9.01
- 2018-03-06 0001104659-18-015235 — 8.01
- 2018-03-06 0001104659-18-015036 — 8.01, 9.01
- 2018-03-05 0001104659-18-014823 — 8.01, 9.01
- 2018-03-02 0000950157-18-000257 — 1.01, 9.01
- 2018-02-20 0001104659-18-010546 — 1.01, 7.01, 9.01
- 2018-01-31 0001728949-18-000010 — 2.02, 9.01
- 2017-12-27 0001234452-17-000206 — 5.02
- 2017-12-22 0001104659-17-074753 — 1.01, 5.02, 9.01
- 2017-11-16 0001193125-17-345455 — 8.01
- 2017-11-13 0001193125-17-340001 — 8.01, 9.01
- 2017-11-01 0001234452-17-000189 — 2.02, 9.01
- 2017-08-24 0001234452-17-000163 — 5.02
- 2017-07-19 0001234452-17-000153 — 2.02, 9.01
- 2017-05-31 0001193125-17-189502 — 1.01, 9.01
- 2017-05-23 0001193125-17-178324 — 8.01, 9.01
- 2017-05-19 0001193125-17-175921 — 8.01, 9.01
- 2017-04-19 0001234452-17-000075 — 2.02, 9.01
- 2017-03-10 0001234452-17-000048 — 5.07
- 2017-02-15 0001234452-17-000036 — 5.02
- 2017-01-25 0001234452-17-000026 — 2.02, 9.01
- 2016-11-29 0000950157-16-002532 — 1.01, 2.03, 9.01
- 2016-11-09 0000950157-16-002442 — 1.01, 2.03, 9.01
- 2016-11-02 0001234452-16-000551 — 2.02, 9.01
- 2016-10-27 0001193125-16-749835 — 1.01, 7.01, 9.01
- 2016-10-11 0001234452-16-000527 — 5.02, 8.01, 9.01
- 2016-07-20 0001234452-16-000482 — 2.02, 9.01
- 2016-07-15 0001234452-16-000471 — 5.03, 9.01
- 2016-05-04 0001234452-16-000436 — 5.02
- 2016-04-20 0001234452-16-000427 — 2.02, 9.01
- 2016-03-11 0001234452-16-000392 — 5.07
- 2016-01-27 0001234452-16-000350 — 2.02, 9.01
- 2016-01-14 0001234452-16-000333 — 5.02
- 2016-01-13 0001193125-16-428370 — 1.01, 7.01, 9.01
- 2015-12-15 0001234452-15-000317 — 7.01, 9.01
- 2015-12-11 0001234452-15-000313 — 5.03, 9.01
- 2015-11-24 0001234452-15-000305 — 5.02
- 2015-11-04 0001234452-15-000269 — 2.02, 9.01
- 2015-09-30 0001234452-15-000251 — 5.03, 9.01
- 2015-09-30 0001234452-15-000249 — 5.02, 9.01
- 2015-07-22 0001234452-15-000210 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2015-07-22 0001234452-15-000206 — 2.02, 9.01
- 2015-05-21 0001193125-15-195953 — 1.01, 9.01
- 2015-05-21 0001193125-15-195451 — 1.01, 9.01
- 2015-05-15 0001193125-15-188588 — 8.01, 9.01
- 2015-04-22 0001234452-15-000132 — 2.02, 9.01
- 2015-03-13 0001234452-15-000088 — 5.07
- 2015-03-10 0001234452-15-000055 — 2.03
- 2015-02-18 0001234452-15-000040 — 1.01, 2.03, 9.01
- 2015-02-09 0001234452-15-000031 — 7.01, 9.01
- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2022-07-27

- none on or before 2022-07-27

## item 2.02 — earnings release, exhibit 99.1

[0001728949-22-000039:8k_2_02:1]
EX-99.1
2
qcom062622erex991.htm
EX-99.1

[0001728949-22-000039:8k_2_02:2]
Document

[0001728949-22-000039:8k_2_02:3]
Exhibit 99.1

[0001728949-22-000039:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001728949-22-000039:8k_2_02:5]
Qualcomm Contact:

[0001728949-22-000039:8k_2_02:6]
Mauricio Lopez-Hodoyan

[0001728949-22-000039:8k_2_02:7]
Vice President, Investor Relations

[0001728949-22-000039:8k_2_02:8]
Phone: 1-858-658-4813 | e-mail: ir@qualcomm.com

[0001728949-22-000039:8k_2_02:9]
Qualcomm Announces Third Quarter Fiscal 2022 Results

[0001728949-22-000039:8k_2_02:10]
Revenues: $10.9 billion

[0001728949-22-000039:8k_2_02:11]
GAAP EPS: $3.29, Non-GAAP EPS: $2.96

[0001728949-22-000039:8k_2_02:12]
—EPS Exceeded High End of Guidance Range, With Greater Than 50% Year-Over-Year Growth—

[0001728949-22-000039:8k_2_02:13]
—Executed Broad Strategic Agreements With Samsung, Including Licensing and Snapdragon Platforms—

[0001728949-22-000039:8k_2_02:14]
—QCT: Strong Quarterly Results Demonstrate the Success of Our Diversification Strategy—

[0001728949-22-000039:8k_2_02:15]
SAN DIEGO - July 27, 2022 - Qualcomm Incorporated (NASDAQ: QCOM) today announced results for its fiscal third quarter ended June 26, 2022.

[0001728949-22-000039:8k_2_02:16]
“We are pleased to report strong quarterly results, with record QCT Automotive and IoT revenues in a challenging macroeconomic environment,” said Cristiano Amon, President and CEO of Qualcomm Incorporated.  “We are also excited to announce the extension of our patent license agreement with Samsung and the expansion of our strategic partnership to deliver leading premium consumer experiences for Samsung Galaxy devices.  Qualcomm is well positioned to be the company bringing advanced connectivity, data processing and intelligence to the edge, enabling cloud-edge convergence.”

[0001728949-22-000039:8k_2_02:17]
Third Quarter Results1, 2

[0001728949-22-000039:8k_2_02:18]
|  | GAAP |  | Non-GAAP |  |
| (in millions, except per share data and percentages) | Q3 Fiscal 2022 |  | Q3 Fiscal 2021 |  | Change |  | Q3 Fiscal 2022 |  | Q3 Fiscal 2021 |  |  |  |  | Change |  |
| Revenues | $10,936 |  | $8,060 |  | +36% |  | $10,928 |  | $7,995 |  |  |  |  | +37% |  |
| Earnings before taxes (EBT) | $4,239 |  | $2,257 |  | +88% |  | $3,894 |  | $2,545 |  |  |  |  | +53% |  |
| Net income | $3,730 |  | $2,027 |  | +84% |  | $3,356 |  | $2,200 |  |  |  |  | +53% |  |
| Diluted earnings per share (EPS) | $3.29 |  | $1.77 |  | +86% |  | $2.96 |  | $1.92 |  |  |  |  | +54% |  |

[0001728949-22-000039:8k_2_02:19]
Segment Results

[0001728949-22-000039:8k_2_02:20]
|  | QCT |  | QTL |
| (in millions, except percentages) | Q3 Fiscal 2022 |  | Q3 Fiscal 2021 |  | Change |  | Q3 Fiscal 2022 |  | Q3 Fiscal 2021 |  | Change |  |  |  |
| Revenues | $9,378 |  | $6,472 |  | +45% |  | $1,519 |  | $1,489 |  | +2% |  |  |  |
| EBT | $2,996 |  | $1,795 |  | +67% |  | $1,080 |  | $1,053 |  | +3% |  |  |  |
| EBT as % of revenues | 32% |  | 28% |  | +4 points |  | 71% |  | 71% |  | — |  |  |  |

[0001728949-22-000039:8k_2_02:21]
(1)  Discussion regarding our use of Non-GAAP financial measures and reconciliations between GAAP and Non-GAAP results are included at the end of this news release in the sections labeled “Note Regarding Use of Non-GAAP Financial Measures” and “Reconciliations of GAAP Results to Non-GAAP Results.”

[0001728949-22-000039:8k_2_02:22]
(2)  Third quarter fiscal 2022 GAAP results included a $1.1 billion benefit, or $0.94 per share, resulting from the reversal of the accrued fine imposed by the European Commission (EC) in fiscal 2018 and the associated accrued interest.

[0001728949-22-000039:8k_2_02:23]
| Qualcomm Announces Third Quarter Fiscal 2022 Results | Page 2 of 9 |

[0001728949-22-000039:8k_2_02:24]
QCT Revenue Streams1

[0001728949-22-000039:8k_2_02:25]
| (in millions, except percentages) |  |  |  |  |  |  | Q3 Fiscal 2022 |  | Q3 Fiscal 2021 |  | Change |  |  |  |
| Handsets |  |  |  |  |  |  | $6,149 |  | $3,863 |  | +59% |  |  |  |
| RF front-end |  |  |  |  |  |  | 1,046 |  | 957 |  | +9% |  |  |  |
| Automotive |  |  |  |  |  |  | 350 |  | 253 |  | +38% |  |  |  |
| IoT |  |  |  |  |  |  | 1,833 |  | 1,399 |  | +31% |  |  |  |
| Total QCT revenues |  |  |  |  |  |  | $9,378 |  | $6,472 |  | +45% |  |  |  |

[0001728949-22-000039:8k_2_02:26]
(1)  We disaggregate QCT revenues based on the industries and applications in which our products are sold.

[0001728949-22-000039:8k_2_02:27]
Return of Capital to Stockholders

[0001728949-22-000039:8k_2_02:28]
During the third quarter of fiscal 2022, we returned $1.3 billion to stockholders, including $842 million, or $0.75 per share, of cash dividends paid and $500 million through repurchases of 4 million shares of common stock.

[0001728949-22-000039:8k_2_02:29]
| Qualcomm Announces Third Quarter Fiscal 2022 Results | Page 3 of 9 |

[0001728949-22-000039:8k_2_02:30]
Business Outlook

[0001728949-22-000039:8k_2_02:31]
The mid-point of our fourth quarter fiscal 2022 guidance includes an estimated impact of an approximate $0.20 reduction to EPS due to macroeconomic headwinds and a reduction in the global handset forecast.

[0001728949-22-000039:8k_2_02:32]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.

[0001728949-22-000039:8k_2_02:33]
|  |  |  | Current Guidance Q4 FY22 Estimates1, 2 |  |
|  | Revenues |  | $11.0B - $11.8B |  |
|  | Supplemental Revenue Information |  |  |  |
|  | QCT revenues |  | $9.5B - $10.1B |  |
|  | QTL revenues |  | $1.45B - $1.65B |  |
|  | GAAP diluted EPS |  | $2.53- $2.83 |  |
|  | Less diluted EPS attributable to QSI |  | $— |  |  |
|  | Less diluted EPS attributable to share-based compensation |  | ($0.39) |  |  |
|  | Less diluted EPS attributable to other items3 |  | ($0.08) |  |  |
|  | Non-GAAP diluted EPS |  | $3.00 - $3.30 |  |

[0001728949-22-000039:8k_2_02:34]
(1)  The Veoneer acquisition closed in the third quarter of fiscal 2022.  We initially used a one-quarter reporting lag to consolidate Arriver.  We currently expect to eliminate the one-quarter reporting lag in our fourth quarter, which will result in Arriver operating results for the third and fourth quarters being reflected in our fourth quarter fiscal 2022 results.  Although we do not own or operate Veoneer’s Tier-1 automotive supplier businesses that were retained by SSW Partners (Non-Arriver), we consolidate Non-Arriver, and its operating results are presented as discontinued operations in other items.  We will consolidate the Non-Arriver businesses one quarter in arrears until such businesses are sold by SSW Partners.

[0001728949-22-000039:8k_2_02:35]
(2)  Our outlook does not include provisions for proposed tax law changes, future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable.  Further, due to their nature, certain income and expense items, such as certain investments, derivative and foreign currency transaction gains or losses, cannot be accurately forecast.  Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain.  Our outlook includes the impact of any pending business combinations to the extent they are expected to close in the upcoming quarter.  Actual results may differ materially from the outlook.

[0001728949-22-000039:8k_2_02:36]
(3)  Our guidance for diluted EPS attributable to other items for the fourth quarter of fiscal 2022 is primarily related to acquisition-related items, including the operating results of the Non-Arriver businesses.

[0001728949-22-000039:8k_2_02:37]
| Qualcomm Announces Third Quarter Fiscal 2022 Results | Page 4 of 9 |

[0001728949-22-000039:8k_2_02:38]
Conference Call

[0001728949-22-000039:8k_2_02:39]
Qualcomm’s third quarter fiscal 2022 earnings conference call will be broadcast live on July 27, 2022, beginning at 1:45 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm.  This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G.  The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to our financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted at http://investor.qualcomm.com/ immediately prior to the commencement of the call.  An audio replay will be available at http://investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter.  To listen to the replay via telephone, U.S. callers may dial (877) 660-6853 and international callers may dial (201) 612-7415.  Callers should use reservation number 13731134.

[0001728949-22-000039:8k_2_02:40]
About Qualcomm

[0001728949-22-000039:8k_2_02:41]
Qualcomm is the world’s leading wireless technology innovator and the driving force behind the development, launch and expansion of 5G.  When we connected the phone to the internet, the mobile revolution was born.  Today, our foundational technologies enable the mobile ecosystem and are found in every 3G, 4G and 5G smartphone.  We bring the benefits of mobile to new industries, including automotive, the internet of things and computing, and are leading the way to a world where everything and everyone can communicate and interact seamlessly.

[0001728949-22-000039:8k_2_02:42]
Qualcomm Incorporated includes our licensing business, QTL, and the vast majority of our patent portfolio.  Qualcomm Technologies, Inc., a subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, substantially all of our engineering and research and development functions and substantially all of our products and services businesses, including our QCT semiconductor business.

[0001728949-22-000039:8k_2_02:43]
Note Regarding Forward-Looking Statements

[0001728949-22-000039:8k_2_02:44]
###

[0001728949-22-000039:8k_2_02:45]
Qualcomm is a trademark or registered trademark of Qualcomm Incorporated.  Other products and brand names may be trademarks or registered trademarks of their respective owners.

[0001728949-22-000039:8k_2_02:46]
| Qualcomm Announces Third Quarter Fiscal 2022 Results | Page 5 of 9 |

[0001728949-22-000039:8k_2_02:47]
QUALCOMM Incorporated

[0001728949-22-000039:8k_2_02:48]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001728949-22-000039:8k_2_02:49]
(In millions, except par value amounts)

[0001728949-22-000039:8k_2_02:50]
(Unaudited)

[0001728949-22-000039:8k_2_02:51]
|  | June 26,2022 |  | September 26,2021 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 2,676 |  |  | $ | 7,116 |  |
| Marketable securities | 4,172 |  |  | 5,298 |  |
| Accounts receivable, net | 3,804 |  |  | 3,579 |  |
| Inventories | 5,418 |  |  | 3,228 |  |
| Held for sale assets | 950 |  |  | — |  |
| Other current assets | 1,979 |  |  | 854 |  |
| Total current assets | 18,999 |  |  | 20,075 |  |
| Deferred tax assets | 1,778 |  |  | 1,591 |  |
| Property, plant and equipment, net | 5,038 |  |  | 4,559 |  |
| Goodwill | 10,719 |  |  | 7,246 |  |
| Other intangible assets, net | 1,954 |  |  | 1,458 |  |
| Held for sale assets | 916 |  |  | — |  |
| Other assets | 7,616 |  |  | 6,311 |  |
| Total assets | $ | 47,020 |  |  | $ | 41,240 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 3,752 |  |  | $ | 2,750 |  |
| Payroll and other benefits related liabilities | 1,578 |  |  | 1,531 |  |
| Unearned revenues | 463 |  |  | 612 |  |
| Short-term debt | 1,945 |  |  | 2,044 |  |
| Held for sale liabilities | 677 |  |  | — |  |
| Other current liabilities | 3,414 |  |  | 5,014 |  |
| Total current liabilities | 11,829 |  |  | 11,951 |  |
| Unearned revenues | 180 |  |  | 364 |  |
| Income taxes payable | 1,480 |  |  | 1,713 |  |
| Long-term debt | 13,600 |  |  | 13,701 |  |
| Held for sale liabilities | 128 |  |  | — |  |
| Other liabilities | 3,755 |  |  | 3,561 |  |
| Total liabilities | 30,972 |  |  | 31,290 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,122 and 1,125 shares issued and outstanding, respectively | — |  |  | — |  |
| Retained earnings | 15,830 |  |  | 9,822 |  |
| Accumulated other comprehensive income | 218 |  |  | 128 |  |
| Total stockholders’ equity | 16,048 |  |  | 9,950 |  |
| Total liabilities and stockholders’ equity | $ | 47,020 |  |  | $ | 41,240 |  |

[0001728949-22-000039:8k_2_02:52]
| Qualcomm Announces Third Quarter Fiscal 2022 Results | Page 6 of 9 |

[0001728949-22-000039:8k_2_02:53]
QUALCOMM Incorporated

[0001728949-22-000039:8k_2_02:54]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001728949-22-000039:8k_2_02:55]
(In millions, except per share data)

[0001728949-22-000039:8k_2_02:56]
(Unaudited)

[0001728949-22-000039:8k_2_02:57]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  |  |  |  | June 26,2022 |  | June 27,2021 |  | June 26,2022 |  | June 27,2021 |
| Revenues: |  |  |  |  |  |  |  |  |  |  |  |  |
| Equipment and services |  |  |  |  |  | $ | 9,266 |  |  | $ | 6,428 |  |  | $ | 27,365 |  |  | $ | 19,109 |  |
| Licensing |  |  |  |  |  | 1,670 |  |  | 1,632 |  |  | 5,440 |  |  | 5,121 |  |
| Total revenues |  |  |  |  |  | 10,936 |  |  | 8,060 |  |  | 32,805 |  |  | 24,230 |  |
| Costs and expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenues |  |  |  |  |  | 4,816 |  |  | 3,404 |  |  | 13,767 |  |  | 10,325 |  |
| Research and development |  |  |  |  |  | 2,052 |  |  | 1,864 |  |  | 6,016 |  |  | 5,297 |  |
| Selling, general and administrative |  |  |  |  |  | 655 |  |  | 597 |  |  | 1,887 |  |  | 1,721 |  |
| Other |  |  |  |  |  | (1,059) |  |  | — |  |  | (1,059) |  |  | — |  |
| Total costs and expenses |  |  |  |  |  | 6,464 |  |  | 5,865 |  |  | 20,611 |  |  | 17,343 |  |
| Operating income |  |  |  |  |  | 4,472 |  |  | 2,195 |  |  | 12,194 |  |  | 6,887 |  |
| Interest expense |  |  |  |  |  | (70) |  |  | (138) |  |  | (345) |  |  | (421) |  |
| Investment and other (expense) income, net |  |  |  |  |  | (163) |  |  | 200 |  |  | (321) |  |  | 523 |  |
| Income before income taxes |  |  |  |  |  | 4,239 |  |  | 2,257 |  |  | 11,528 |  |  | 6,989 |  |
| Income tax expense |  |  |  |  |  | (509) |  |  | (230) |  |  | (1,465) |  |  | (744) |  |
| Net income |  |  |  |  |  | $ | 3,730 |  |  | $ | 2,027 |  |  | $ | 10,063 |  |  | $ | 6,245 |  |
| Basic earnings per share |  |  |  |  |  | $ | 3.32 |  |  | $ | 1.80 |  |  | $ | 8.96 |  |  | $ | 5.52 |  |
| Diluted earnings per share |  |  |  |  |  | $ | 3.29 |  |  | $ | 1.77 |  |  | $ | 8.84 |  |  | $ | 5.43 |  |
| Shares used in per share calculations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  |  |  |  | 1,122 |  |  | 1,129 |  |  | 1,124 |  |  | 1,132 |  |
| Diluted |  |  |  |  |  | 1,134 |  |  | 1,145 |  |  | 1,139 |  |  | 1,151 |  |

[0001728949-22-000039:8k_2_02:58]
| Qualcomm Announces Third Quarter Fiscal 2022 Results | Page 7 of 9 |

[0001728949-22-000039:8k_2_02:59]
QUALCOMM Incorporated

[0001728949-22-000039:8k_2_02:60]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001728949-22-000039:8k_2_02:61]
(In millions)

[0001728949-22-000039:8k_2_02:62]
(Unaudited)

[0001728949-22-000039:8k_2_02:63]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 26,2022 |  | June 27,2021 |  | June 26,2022 |  | June 27,2021 |
| Operating Activities: |  |  |  |  |  |  |  |
| Net income | $ | 3,730 |  |  | $ | 2,027 |  |  | $ | 10,063 |  |  | $ | 6,245 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization expense | 438 |  |  | 406 |  |  | 1,272 |  |  | 1,157 |  |
| Income tax provision in excess of (less than) income tax payments | 169 |  |  | (123) |  |  | (234) |  |  | (358) |  |
| Share-based compensation expense | 516 |  |  | 425 |  |  | 1,510 |  |  | 1,238 |  |
| Net losses (gains) on marketable securities and other investments | 161 |  |  | (186) |  |  | 374 |  |  | (487) |  |
| Other items, net | 35 |  |  | (18) |  |  | — |  |  | (49) |  |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |
| Accounts receivable, net | 285 |  |  | 394 |  |  | (216) |  |  | 1,052 |  |
| Inventories | (864) |  |  | (449) |  |  | (2,201) |  |  | (509) |  |
| Other assets | (548) |  |  | 99 |  |  | (2,360) |  |  | 39 |  |
| Trade accounts payable | (31) |  |  | 158 |  |  | 948 |  |  | 449 |  |
| Payroll, benefits and other liabilities | (903) |  |  | 658 |  |  | (1,274) |  |  | 805 |  |
| Unearned revenues | (93) |  |  | (18) |  |  | (232) |  |  | (123) |  |
| Net cash provided by operating activities | 2,895 |  |  | 3,373 |  |  | 7,650 |  |  | 9,459 |  |
| Investing Activities: |  |  |  |  |  |  |  |
| Capital expenditures | (554) |  |  | (506) |  |  | (1,628) |  |  | (1,458) |  |
| Purchases of debt and equity marketable securities | (333) |  |  | (1,266) |  |  | (1,269) |  |  | (5,458) |  |
| Proceeds from sales and maturities of debt and equity marketable securities | 397 |  |  | 1,335 |  |  | 1,960 |  |  | 4,482 |  |
| Acquisitions and other investments, net of cash acquired | (4,455) |  |  | (48) |  |  | (4,743) |  |  | (1,284) |  |
| Proceeds from other investments | 28 |  |  | 67 |  |  | 125 |  |  | 234 |  |
| Other items, net | 41 |  |  | 46 |  |  | 41 |  |  | 78 |  |
| Net cash used by investing activities | (4,876) |  |  | (372) |  |  | (5,514) |  |  | (3,406) |  |
| Financing Activities: |  |  |  |  |  |  |  |
| Proceeds from short-term debt | 1,603 |  |  | 606 |  |  | 3,065 |  |  | 2,185 |  |
| Repayment of short-term debt | (1,604) |  |  | (606) |  |  | (3,066) |  |  | (2,185) |  |
| Repayment of debt of acquired company | (349) |  |  | — |  |  | (349) |  |  | — |  |
| Proceeds from long-term debt | 1,477 |  |  | — |  |  | 1,477 |  |  | — |  |
| Repayment of long-term debt | (1,540) |  |  | — |  |  | (1,540) |  |  | — |  |
| Proceeds from issuance of common stock | 1 |  |  | — |  |  | 188 |  |  | 174 |  |
| Repurchases and retirements of common stock | (500) |  |  | (630) |  |  | (2,629) |  |  | (2,595) |  |
| Dividends paid | (842) |  |  | (767) |  |  | (2,371) |  |  | (2,240) |  |
| Payments of tax withholdings related to vesting of share-based awards | (189) |  |  | (209) |  |  | (751) |  |  | (710) |  |
| Other items, net | (17) |  |  | (2) |  |  | (28) |  |  | (25) |  |
| Net cash used by financing activities | (1,960) |  |  | (1,608) |  |  | (6,004) |  |  | (5,396) |  |
| Effect of exchange rate changes on cash and cash equivalents | (34) |  |  | 6 |  |  | (50) |  |  | 35 |  |
| Net (decrease) increase in total cash and cash equivalents | (3,975) |  |  | 1,399 |  |  | (3,918) |  |  | 692 |  |
| Total cash and cash equivalents at beginning of period | 7,173 |  |  | 6,000 |  |  | 7,116 |  |  | 6,707 |  |
| Total cash and cash equivalents at end of period (including $522 million classified as held for sale) | $ | 3,198 |  |  | $ | 7,399 |  |  | $ | 3,198 |  |  | $ | 7,399 |  |

[0001728949-22-000039:8k_2_02:64]
| Qualcomm Announces Third Quarter Fiscal 2022 Results | Page 8 of 9 |

[0001728949-22-000039:8k_2_02:65]
Note Regarding Use of Non-GAAP Financial Measures

[0001728949-22-000039:8k_2_02:66]
The Non-GAAP financial measures presented herein should be considered in addition to, not as a substitute for or superior to, financial measures calculated in accordance with GAAP.  In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, our Non-GAAP financial measures might be different than similarly titled measures used by other companies.  Reconciliations between GAAP and Non-GAAP financial measures are presented herein.

[0001728949-22-000039:8k_2_02:67]
We use Non-GAAP financial information: (i) to evaluate, assess and benchmark our operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of our ongoing core operating businesses, including our QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against competitors.  Non-GAAP measurements used by us include revenues, cost of revenues, research and development (R&D) expenses, selling, general and administrative (SG&A) expenses, other income or expenses, operating income, interest expense, net investment and other income, income or earnings before income taxes, effective tax rate, net income and diluted earnings per share.  We are able to assess what we believe is a meaningful and comparable set of financial performance measures by using Non-GAAP information.  In addition, the HR and Compensation Committee of the Board of Directors uses certain Non-GAAP financial measures in establishing portions of the performance-based incentive compensation programs for our executive officers.  We present Non-GAAP financial information to provide greater transparency to investors with respect to our use of such information in financial and operational decision-making.  This Non-GAAP financial information is also used by institutional investors and analysts in evaluating our business and assessing trends and future expectations.

[0001728949-22-000039:8k_2_02:68]
Non-GAAP information presented herein excludes our QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.

[0001728949-22-000039:8k_2_02:69]
•QSI is excluded because we generally expect to exit our strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed as unrelated to our operational performance.

[0001728949-22-000039:8k_2_02:70]
•Share-based compensation expense primarily relates to restricted stock units.  We believe that excluding share-based compensation from the Non-GAAP financial information allows us and investors to make additional comparisons of the operating activities of our ongoing core businesses over time and with respect to other companies.

[0001728949-22-000039:8k_2_02:71]
•Certain other items are excluded because we view such items as unrelated to the operating activities of our ongoing core businesses, as follows:

[0001728949-22-000039:8k_2_02:72]
◦Acquisition-related items include amortization of acquisition-related intangible assets, substantially all of which relate to the amortization of technology-based intangible assets that is recorded in cost of revenues and will recur in future periods until the related intangible assets have been fully amortized.  We view acquisition-related intangible assets as items arising from pre-acquisition activities determined at the time of an acquisition.  Acquisition-related intangible assets contribute to revenue generation that has not been excluded from our Non-GAAP financial information.  Acquisition-related items also include recognition of the step-up of inventories and property, plant and equipment to fair value and the related tax effects of acquisition-related items, as well as any effects from restructuring the ownership of such acquired assets.  We also exclude the operating results of acquired and/or consolidated businesses that, as of close, are expected or required to be sold.  Additionally, we exclude certain other acquisition-related charges such as third-party acquisition and integration services costs and costs related to temporary debt facilities and letters of credit executed prior to the close of an acquisition.

[0001728949-22-000039:8k_2_02:73]
◦We exclude certain other items that we view as unrelated to our ongoing businesses, such as major restructuring and restructuring-related costs, asset impairments and awards, settlements and/or damages arising from legal or regulatory matters.  We exclude gains and losses driven by the revaluation of our deferred compensation plan liabilities recognized in operating expenses and the offsetting gains and losses on the related plan assets recognized in investment and other income.

[0001728949-22-000039:8k_2_02:74]
◦Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of our ongoing Non-GAAP tax rate and after-tax earnings.

[0001728949-22-000039:8k_2_02:75]
| Qualcomm Announces Third Quarter Fiscal 2022 Results | Page 9 of 9 |

[0001728949-22-000039:8k_2_02:76]
Reconciliations of GAAP Results to Non-GAAP Results

[0001728949-22-000039:8k_2_02:77]
| (in millions, except per share data and percentages) |  |  |  | GAAP to Non-GAAP Reconciliation | Non-GAAP Supplemental Information |
|  |  |  | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items1 | Non-GAAP Results | QCT | QTL | Non-GAAP Reconciling Items2 |
| Q3 Fiscal 2022 |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  |  |  | $10,936 |  | $8 |  | $— |  |  | $— |  |  | $10,928 |  | $9,378 |  | $1,519 |  | $31 |  |
| Operating income (loss) |  |  |  | 4,472 |  | 2 |  | (544) |  | 1,009 |  | 4,005 |  |  |  |  |  |  |  |
| EBT |  |  |  | 4,239 |  | (101) |  | (544) |  | 990 |  | 3,894 |  | 2,996 |  | 1,080 |  | (182) |  |
| EBT as % of revenues |  |  |  | 39 | % |  |  |  |  |  |  |  | 36 | % |  |  |  |  |  |  |  |
| Net income (loss) |  |  |  | 3,730 |  | (80) |  | (421) |  | 875 |  | 3,356 |  |  |  |  |  |  |  |
| Diluted EPS |  |  |  | $3.29 |  | ($0.07) |  | ($0.37) |  | $0.77 |  | $2.96 |  |  |  |  |  |  |  |
| Diluted shares |  |  |  | 1,134 |  | 1,134 |  | 1,134 |  | 1,134 |  | 1,134 |  |  |  |  |  |  |  |
| Q3 Fiscal 2021 |  |  |  |  |  |  |  |  |  |  |  |
| Revenues |  |  |  | $8,060 |  | $11 |  | $— |  |  | $54 |  |  | $7,995 |  | $6,472 |  | $1,489 |  | $34 |  |
| Operating income (loss) |  |  |  | 2,195 |  | 5 |  | (425) |  | (50) |  | 2,665 |  |  |  |  |  |  |  |
| EBT |  |  |  | 2,257 |  | 156 |  | (425) |  | (19) |  | 2,545 |  | 1,795 |  | 1,053 |  | (303) |  |
| EBT as % of revenues |  |  |  | 28 | % |  |  |  |  |  |  |  | 32 | % |  |  |  |  |  |  |  |
| Net income (loss) |  |  |  | 2,027 |  | 124 |  | (298) |  | 1 |  | 2,200 |  |  |  |  |  |  |  |
| Diluted EPS |  |  |  | $1.77 |  | $0.11 |  | ($0.26) |  | $— |  | $1.92 |  |  |  |  |  |  |  |
| Diluted shares |  |  |  | 1,145 |  | 1,145 |  | 1,145 |  | 1,145 |  | 1,145 |  |  |  |  |  |  |  |

[0001728949-22-000039:8k_2_02:78]
(1)  Further details of amounts included in the “Other Items” column for the current period are included in the “Supplemental Information and Reconciliations” table below.  Details of amounts included in the “Other Items” column for the prior periods are included in the news release for those periods.

[0001728949-22-000039:8k_2_02:79]
(2)    Non-GAAP reconciling items related to revenues consisted primarily of nonreportable segment revenues less intersegment eliminations.  Non-GAAP reconciling items related to EBT consisted primarily of certain R&D expenses, SG&A expenses, other expenses or income, interest expense and certain investment income that are not allocated to segments for management reporting purposes; nonreportable segment results; and the elimination of intersegment profit.

[0001728949-22-000039:8k_2_02:80]
Sums may not equal totals due to rounding.

[0001728949-22-000039:8k_2_02:81]
|  | Q3 Fiscal 2022 Supplemental Information and Reconciliations |  |
|  | ($ in millions) | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items1, 2 | Non-GAAP Results |
|  | Cost of revenues |  | $4,816 |  |  | $3 |  |  | $16 |  |  | $59 |  |  | $4,738 |  |
|  | Research and development expenses |  | 2,052 |  |  | — |  |  |  | 390 |  |  | (39) |  |  | 1,701 |  |
|  | Selling, general and administrative expenses |  | 655 |  |  | 3 |  |  | 138 |  |  | 30 |  |  | 484 |  |
|  | Other income |  | (1,059) |  |  |  | — |  |  |  | — |  |  |  | (1,059) |  |  |  | — |  |  |
|  | Interest expense |  | 70 |  |  | — |  |  |  | — |  |  |  | (61) |  |  | 131 |  |
|  | Investment and other (expense) income, net |  | (163) |  |  | (103) |  |  | — |  |  |  | (80) |  |  | 20 |  |
|  | Income tax expense (benefit) |  | 509 |  |  | (21) |  |  | (123) |  |  | 115 |  |  | 538 |  |

[0001728949-22-000039:8k_2_02:82]
(1)  Other items excluded from Non-GAAP results included a $1.1 billion benefit resulting from the reversal of the 2018 EC fine (including a $1.1 billion benefit in other income and a $62 million reduction in interest expense), partially offset by $103 million of acquisition-related charges, a $27 million loss attributable to restructuring-related activities and $1 million of interest expense related to the 2019 EC fine.  Other items excluded from Non-GAAP results also included $79 million of gains driven by the revaluation of our deferred compensation plan liabilities, which decreased operating expenses, offset by corresponding $79 million of losses driven by the revaluation of the associated plan assets, which were included within investment and other (expense) income, net.

[0001728949-22-000039:8k_2_02:83]
(2)   At fiscal year end, the quarterly tax provision for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP.  In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column.  Tax expense in the “Other Items” column included an $81 million foreign currency loss related to a noncurrent receivable resulting from our refund claim of Korean withholding taxes paid in prior periods, a $37 million charge to reconcile the tax provision of each column to the total GAAP tax provision for the quarter and an $8 million expense from the combined effect of other items in EBT, partially offset by an $11 million benefit for the tax effect of acquisition-related charges.
