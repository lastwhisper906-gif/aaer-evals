# QCOM MD&A — 0001728949-18-000075


## mdna

[0001728949-18-000075:mdna:1]
[same as prior period, unchanged from 0001728949-18-000039:mdna:1]

[0001728949-18-000075:mdna:2]
[same as prior period, unchanged from 0001728949-18-000039:mdna:2]

[0001728949-18-000075:mdna:3]
[same as prior period, unchanged from 0001728949-18-000039:mdna:3]

[0001728949-18-000075:mdna:4]
Third Quarter of Fiscal 2018 Overview

[0001728949-18-000075:mdna:5]
Revenues for the third quarter of fiscal 2018 were $5.6 billion, an increase of 4% compared to the year ago quarter, with net income attributable to Qualcomm of $1.2 billion, an increase of 41% compared to the year ago quarter. Highlights and other events from the third quarter of fiscal 2018 included:

[0001728949-18-000075:mdna:6]
| • | The transition of wireless networks and devices to 3G/4G (CDMA single-mode, OFDMA single-mode and CDMA/OFDMA multi-mode) continued around the world. 3G/4G connections grew sequentially by approximately 3% to approximately 5.1 billion, which was approximately 65% of total mobile connections at the end of the third quarter of fiscal 2018.(1) |

[0001728949-18-000075:mdna:7]
[same as prior period, unchanged from 0001728949-18-000039:mdna:7]

[0001728949-18-000075:mdna:8]
| • | QCT results in the third quarter of fiscal 2018 were positively impacted by higher demand from OEMs in China, partially offset by lower modem sales to Apple. |

[0001728949-18-000075:mdna:9]
| • | QTL results were negatively impacted by our continued dispute with Apple and its contract manufacturers (who are Qualcomm licensees), and we did not record any revenues in the third quarter of fiscal 2018 for royalties due on sales of Apple’s products. QTL revenues in the third quarter of fiscal 2018 included $500 million paid under an interim agreement with the other licensee in dispute (which dispute was previously disclosed). This represents a partial payment for royalties due after the second quarter of fiscal 2017 by that other licensee while negotiations continue. This payment does not reflect the full amount of royalties due under the underlying license agreement. |

[0001728949-18-000075:mdna:10]
| • | In the second quarter of fiscal 2018, we announced a Cost Plan designed to align our cost structure to our long-term margin targets, under which we continue to execute on a series of targeted actions across our businesses to reduce annual costs by $1 billion, excluding incremental costs resulting from any future acquisition of a business. We expect these cost reductions to be fully captured in fiscal 2019. We recorded restructuring and restructuring-related charges of $112 million in the third quarter of fiscal 2018 related to our Cost Plan. |

[0001728949-18-000075:mdna:11]
| (1) | According to GSMA Intelligence estimates as of July 23, 2018 (estimates excluded Wireless Local Loop). |

[0001728949-18-000075:mdna:12]
[same as prior period, unchanged from 0001728949-18-000039:mdna:30]

[0001728949-18-000075:mdna:13]
[same as prior period, unchanged from 0001728949-18-000039:mdna:15]

[0001728949-18-000075:mdna:14]
[same as prior period, unchanged from 0001728949-18-000039:mdna:16]

[0001728949-18-000075:mdna:15]
[same as prior period, unchanged from 0001728949-18-000039:mdna:17]

[0001728949-18-000075:mdna:16]
[same as prior period, unchanged from 0001728949-18-000039:mdna:18]

[0001728949-18-000075:mdna:17]
Seasonality. Many of our products and/or intellectual property are incorporated into consumer wireless devices, which are subject to seasonality and other fluctuations in demand. As a result, QCT has tended historically to have stronger sales toward the end of the calendar year as manufacturers prepare for major holiday selling seasons; and because QTL recognizes royalty revenues when royalties are reported by licensees, QTL has tended to record higher royalty revenues in the first calendar quarter when licensees report their sales made in the fourth calendar quarter. We have also experienced fluctuations in revenues due to the timing of conversions and expansions of 3G and 4G networks by wireless operators, the timing of launches of flagship wireless devices and consumer demand for wireless devices that incorporate our products and/or intellectual property. These trends may or may not continue in the future. The seasonal trends for QTL may be impacted by disputes and/or resolutions with licensees. Seasonal trends for QTL will be impacted by the adoption of the new guidance related to revenue recognition in the first quarter of fiscal 2019 pursuant to which we will be required to estimate and recognize sales-based royalties in the period in which the associated sales occur, resulting in an acceleration of revenue recognition compared to the current method.

[0001728949-18-000075:mdna:18]
[same as prior period, unchanged from 0001728949-18-000039:mdna:20]

[0001728949-18-000075:mdna:19]
| Revenues (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 24, 2018 |  | June 25, 2017 |  | Change |  | June 24, 2018 |  | June 25, 2017 |  | Change |
| Equipment and services | $ | 4,110 |  |  | $ | 4,121 |  |  | $ | (11 | ) |  | $ | 12,750 |  |  | $ | 11,949 |  |  | $ | 801 |  |
| Licensing | 1,489 |  |  | 1,250 |  |  | 239 |  |  | 4,178 |  |  | 4,438 |  |  | (260 | ) |
|  | $ | 5,599 |  |  | $ | 5,371 |  |  | $ | 228 |  |  | $ | 16,928 |  |  | $ | 16,387 |  |  | $ | 541 |  |

[0001728949-18-000075:mdna:20]
The decrease in equipment and services revenues in the third quarter of fiscal 2018 was primarily due to a decrease in QSI revenues, partially offset by an increase in QCT revenues. The increase in equipment and services revenues in the first nine months of fiscal 2018 was primarily due to an increase in QCT revenues. The increase in licensing revenues in the third quarter of fiscal 2018 was primarily due to an increase in QTL revenues. The decrease in licensing revenues in the first nine months of fiscal 2018 was primarily due to a decrease in QTL revenues, partially offset by the reduction to revenues of $962 million recorded in the first nine months of fiscal 2017 related to the BlackBerry arbitration decision.

[0001728949-18-000075:mdna:21]
| Costs and Expenses (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 24, 2018 |  | June 25, 2017 |  | Change |  | June 24, 2018 |  | June 25, 2017 |  | Change |
| Cost of revenues | $ | 2,491 |  |  | $ | 2,488 |  |  | $ | 3 |  |  | $ | 7,394 |  |  | $ | 7,140 |  |  | $ | 254 |  |
| Gross margin | 56 | % |  | 54 | % |  |  |  | 56 | % |  | 56 | % |  |  |

[0001728949-18-000075:mdna:22]
The increase in gross margin in the third quarter of fiscal 2018 was primarily due to an increase in higher margin QTL licensing revenues as a proportion of total revenues, partially offset by a $50 million reduction to licensing revenues related to a portion of a business arrangement that resolves a legal dispute. The margin percentage in the first nine months of fiscal 2018 remained flat primarily due to the effects of a decrease in higher margin QTL licensing revenues as a proportion of total revenues, offset by an increase in QCT margin and a reduction to licensing revenues of $962 million recorded in the first nine months of fiscal 2017 related to the BlackBerry arbitration decision. Our margin percentage may continue to fluctuate in future periods depending on the mix of segment results as well as products sold, competitive pricing, new product introduction costs and other factors, including disputes and/or resolutions with licensees. In addition, our margin percentage may be impacted by the adoption of the new revenue recognition guidance in the first quarter of fiscal 2019 pursuant to which we will be required to estimate and recognize sales-based royalty revenues in the period in which the associated sales occur. As a result, adjustments to revenues will be required in subsequent periods based on the actual amounts reported by our licensees.

[0001728949-18-000075:mdna:23]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 24, 2018 |  | June 25, 2017 |  | Change |  | June 24, 2018 |  | June 25, 2017 |  | Change |
| Research and development | $ | 1,416 |  |  | $ | 1,391 |  |  | $ | 25 |  |  | $ | 4,237 |  |  | $ | 4,087 |  |  | $ | 150 |  |
| % of revenues | 25 | % |  | 26 | % |  |  |  | 25 | % |  | 25 | % |  |  |
| Selling, general and administrative | $ | 655 |  |  | $ | 710 |  |  | $ | (55 | ) |  | $ | 2,297 |  |  | $ | 1,917 |  |  | $ | 380 |  |
| % of revenues | 12 | % |  | 13 | % |  |  |  | 14 | % |  | 12 | % |  |  |
| Other | $ | 112 |  |  | $ | 9 |  |  | $ | 103 |  |  | $ | 1,605 |  |  | $ | 962 |  |  | $ | 643 |  |

[0001728949-18-000075:mdna:24]
The dollar increases in research and development expenses in the third quarter and first nine months fiscal 2018 were primarily attributable to increases, which are net of cost decreases driven by actions taken under our Cost Plan, of $31 million and $192 million, respectively, in costs related to the development of integrated circuit technologies, including 5G technology and RFFE technologies from our RF360 Holdings joint venture, which was formed in the second quarter of fiscal 2017. The dollar increase in the first nine months of fiscal 2018 was partially offset by a $30 million impairment charge on certain intangible assets recorded in the first quarter of fiscal 2017.

[0001728949-18-000075:mdna:25]
Selling, general and administrative expenses included $162 million and $413 million in the third quarter and first nine months of fiscal 2018, respectively, related to litigation costs, an increase of $102 million and $275 million, respectively. Excluding the increase in litigation costs, selling, general and administrative expenses decreased by $157 million in the third quarter of fiscal 2018 primarily due to decreases of $60 million in other professional fees and costs related to other legal matters, principally related to third-party acquisition and integration services, $31 million in other expenses and $30 million in employee-related expenses driven by actions taken under our Cost Plan, $30 million in share-based compensation expense, primarily due to an increase in forfeitures, and $16 million in amortization of intangible assets. Excluding the increase in litigation costs, selling, general and administrative expenses increased by $105 million in the first nine months of fiscal 2018 primarily due to increases of $118 million in professional fees and costs related to other legal matters, which was primarily driven by Broadcom’s withdrawn takeover proposal and $45 million in bad debt expense, partially offset by decreases of $45 million in share-based compensation expense, primarily due to an increase in forfeitures and actions take under our Cost Plan, and $16 million in amortization of intangible assets.

[0001728949-18-000075:mdna:26]
Other expenses in the third quarter and first nine months of fiscal 2018 included $112 million and $422 million, respectively, in restructuring and restructuring-related charges related to our Cost Plan. Other expenses in the first nine months of fiscal 2018 also included a $1.2 billion charge related to the European Commission (EC) fine. Other expenses in the first nine months of fiscal 2017 consisted of a $927 million charge related to the Korea Fair Trade Commission (KFTC) fine, including related foreign currency losses, and $35 million in restructuring and restructuring-related charges related to our Strategic Realignment Plan.

[0001728949-18-000075:mdna:27]
34

[0001728949-18-000075:mdna:28]
| Interest Expense and Investment and Other Income, Net (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 24, 2018 |  | June 25, 2017 |  | Change |  | June 24, 2018 |  | June 25, 2017 |  | Change |
| Interest expense | $ | 212 |  |  | $ | 133 |  |  | $ | 79 |  |  | $ | 561 |  |  | $ | 330 |  |  | $ | 231 |  |
| Investment and other income, net |  |  |  |  |  |  |  |  |  |  |  |
| Interest and dividend income | $ | 182 |  |  | $ | 147 |  |  | $ | 35 |  |  | $ | 461 |  |  | $ | 466 |  |  | $ | (5 | ) |
| Net realized gains on marketable securities | 10 |  |  | 124 |  |  | (114 | ) |  | 24 |  |  | 330 |  |  | (306 | ) |
| Net realized gains on other investments | 16 |  |  | 15 |  |  | 1 |  |  | 77 |  |  | 45 |  |  | 32 |  |
| Impairment losses on marketable securities and other investments | (19 | ) |  | (15 | ) |  | (4 | ) |  | (40 | ) |  | (163 | ) |  | 123 |  |
| Equity in net losses of investees | (28 | ) |  | (31 | ) |  | 3 |  |  | (67 | ) |  | (42 | ) |  | (25 | ) |
| Net gains (losses) on foreign currency transactions | 112 |  |  | (26 | ) |  | 138 |  |  | 20 |  |  | (26 | ) |  | 46 |  |
| Net (losses) gains on derivative instruments | (30 | ) |  | 4 |  |  | (34 | ) |  | (21 | ) |  | 25 |  |  | (46 | ) |
|  | $ | 243 |  |  | $ | 218 |  |  | $ | 25 |  |  | $ | 454 |  |  | $ | 635 |  |  | $ | (181 | ) |

[0001728949-18-000075:mdna:29]
The increases in interest expense in the third quarter and first nine months of fiscal 2018 were primarily attributable to the issuance of an aggregate principal amount of $11.0 billion of unsecured floating- and fixed-rate notes in May 2017. In the first quarter of fiscal 2017, we began divesting a substantial portion of our marketable securities portfolio in order to finance, in part, the proposed acquisition of NXP. As a result, we recorded net realized gains and impairment losses on such marketable securities that we sold and expected to sell before their anticipated recovery, respectively, in fiscal 2017. The net gains on foreign currency transactions in the third quarter and first nine months of fiscal 2018 were primarily attributable to currency exchange rate movements on amounts accrued for the EC and Taiwan Fair Trade Commission (TFTC) fines, as well as the impact of currency exchange rate movements on certain monetary assets and liabilities of our RF360 Holdings joint venture.

[0001728949-18-000075:mdna:30]
| Income Tax (Benefit) Expense (in millions) |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 24, 2018 |  | June 25, 2017 |  | Change |  | June 24, 2018 |  | June 25, 2017 |  | Change |
| Income tax (benefit) expense | $ | (263 | ) |  | $ | (7 | ) |  | $ | (256 | ) |  | $ | 5,659 |  |  | $ | 290 |  |  | $ | 5,369 |  |
| Effective tax rate | (28 | %) |  | (1 | %) |  | (27 | %) |  | N/M |  |  | 11 | % |  | N/M |  |

[0001728949-18-000075:mdna:31]
[same as prior period, unchanged from 0001728949-18-000039:mdna:34]

[0001728949-18-000075:mdna:32]
The following table summarizes the primary factors that caused our effective tax rates for the third quarters of fiscal 2018 and 2017 to be less than the United States federal statutory rate:

[0001728949-18-000075:mdna:33]
|  | Three Months Ended |
|  | June 24, 2018 |  | June 25, 2017 |
| Expected income tax provision at federal statutory tax rate | 25 | % |  | 35 | % |
| Benefits from foreign income taxed at other than U.S. rates | (40 | %) |  | (41 | %) |
| Benefits related to the research and development tax credit | (4 | %) |  | (3 | %) |
| Toll Charge measurement period adjustments | 1 | % |  | — |  |
| Remeasurement of deferred taxes due to changes in statutory tax rate | (12 | %) |  | — |  |
| Nondeductible charges related to the KFTC and EC investigations | 1 | % |  | 5 | % |
| Other | 1 | % |  | 3 | % |
| Effective Tax Rate | (28 | %) |  | (1 | %) |

[0001728949-18-000075:mdna:34]
[same as prior period, unchanged from 0001728949-18-000039:mdna:37]

[0001728949-18-000075:mdna:35]
[same as prior period, unchanged from 0001728949-18-000039:mdna:55]

[0001728949-18-000075:mdna:36]
[same as prior period, unchanged from 0001728949-18-000039:mdna:38]

[0001728949-18-000075:mdna:37]
We have preliminarily accounted for the effects of the Tax Legislation, which resulted in a charge of $5.73 billion to income tax expense recorded discretely in the first nine months of fiscal 2018, comprised of $5.3 billion related to the estimated Toll Charge and $412 million resulting from the estimated impact of remeasurement of U.S. deferred tax assets and liabilities that existed at the end of fiscal 2017 at a lower enacted corporate income tax rate. These amounts included a $135 million tax benefit in the third quarter of fiscal 2018 related to the remeasurement of a U.S. deferred tax liability that was established as a result of a change in one of our positions due to Tax Legislation. In addition, we recorded $12 million net tax expense discretely in the third quarter of fiscal 2018 related to refining estimates associated with the estimated Toll Charge and the estimated impact of remeasurement of U.S. deferred tax assets and liabilities.

[0001728949-18-000075:mdna:38]
During the third quarter of fiscal 2018, we entered into a new tax incentive agreement in Singapore that results in a reduced tax rate from March 2017 through March 2022, provided that we meet specified employment and investment criteria in Singapore. Our Singapore tax rate will increase in March 2022 as a result of expiration of these incentives and again in March 2027 upon the expiration of tax incentives under a prior agreement. As a result of this new tax incentive, our estimated income tax expense for fiscal 2018 was reduced by approximately $126 million.

[0001728949-18-000075:mdna:39]
Our annual effective tax rate is estimated to be approximately 264% for fiscal 2018 as compared to the 18% effective income tax rate for fiscal 2017, primarily as a result of the estimated charge of $5.82 billion recorded to income tax expense in the first nine months of fiscal 2018 related to the combined effect of the Toll Charge, the remeasurement of deferred tax assets and liabilities and our decision to no longer indefinitely reinvest certain foreign earnings, all of which resulted from the Tax Legislation. Our estimated annual effective tax rate for fiscal 2018 was also impacted by the EC fine recorded in the first quarter of fiscal 2018, which is not deductible for tax purposes and is attributable to a foreign jurisdiction. Tax benefits from foreign income taxed at rates lower than rates in the U.S. are expected to be approximately 37% in fiscal 2018, compared to 32% in fiscal 2017, primarily due to lower estimated U.S. revenues principally related to decreased royalty revenues from Apple’s contract manufacturers, an increase in the allocation of expenses to our U.S. operations and the new tax incentive in Singapore, partially offset by the lower U.S. federal statutory income tax rate enacted by the Tax Legislation. The estimated annual effective tax rate for fiscal 2018 also reflects a blended U.S. federal statutory income tax rate of 25% as a result of the Tax Legislation. The annual effective tax rate of 18% for fiscal 2017 reflected the KFTC and TFTC fines, which were not deductible for tax purposes and were each attributable to both the U.S. and foreign jurisdictions.

[0001728949-18-000075:mdna:40]
The effective tax rate of 28% benefit for the third quarter of fiscal 2018 was lower than the estimated annual effective tax rate primarily due to the estimated charge of $5.95 billion recorded discretely to income tax expense in the first six months of fiscal 2018 related to the effects of certain components of the Tax Legislation and the EC fine recorded in the first quarter of fiscal 2018, as well as tax benefits recorded in the third quarter of fiscal 2018 resulting from an increase in the allocation of expenses to our U.S. operations and the new tax incentive in Singapore.

[0001728949-18-000075:mdna:41]
Unrecognized tax benefits were $356 million and $372 million at June 24, 2018 and September 24, 2017, respectively. We believe that it is reasonably possible that the total amounts of unrecognized tax benefits at June 24, 2018 may increase or decrease in the next 12 months.

[0001728949-18-000075:mdna:42]
We are subject to income taxes in the U.S. and numerous foreign jurisdictions, and we are currently under examination by various tax authorities worldwide, most notably in countries where we earn a routine return and tax authorities believe substantial value-add activities are performed. These examinations are at various stages with respect to assessments, claims, deficiencies and refunds, many of which are open for periods after fiscal 2000. We continually assess the likelihood and amount of potential adjustments and adjusts the income tax provision, income taxes payable and deferred taxes in the period in which the facts give rise to a revision become known. As of June 24, 2018, we believe that adequate amounts have been reserved for based on facts known. However, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our income tax provision and the related accruals.

[0001728949-18-000075:mdna:43]
[same as prior period, unchanged from 0001728949-18-000039:mdna:45]

[0001728949-18-000075:mdna:44]
The following should be read in conjunction with the financial results for the third quarter and first nine months of fiscal 2018 for each reportable segment included in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 7. Segment Information.”

[0001728949-18-000075:mdna:45]
|  | Three Months Ended |  | Nine Months Ended |
| (in millions) | June 24, 2018 |  | June 25, 2017 |  | Change |  | June 24, 2018 |  | June 25, 2017 |  | Change |
| Revenues |  |  |  |  |  |  |  |  |  |  |  |
| QCT | $ | 4,087 |  |  | $ | 4,052 |  |  | $ | 35 |  |  | $ | 12,635 |  |  | $ | 11,829 |  |  | $ | 806 |  |
| QTL | 1,465 |  |  | 1,172 |  |  | 293 |  |  | 4,025 |  |  | 5,232 |  |  | (1,207 | ) |
| QSI | 20 |  |  | 56 |  |  | (36 | ) |  | 80 |  |  | 70 |  |  | 10 |  |
| EBT (1) |  |  |  |  |  |  |  |  |  |  |  |
| QCT | $ | 607 |  |  | $ | 575 |  |  | $ | 32 |  |  | $ | 2,170 |  |  | $ | 1,774 |  |  | $ | 396 |  |
| QTL | 1,049 |  |  | 854 |  |  | 195 |  |  | 2,786 |  |  | 4,346 |  |  | (1,560 | ) |
| QSI | (7 | ) |  | 55 |  |  | (62 | ) |  | 44 |  |  | 38 |  |  | 6 |  |
| EBT as a % of revenues |  |  |  |  |  |  |  |  |  |  |  |
| QCT | 15 | % |  | 14 | % |  | 1 | % |  | 17 | % |  | 15 | % |  | 2 | % |
| QTL | 72 | % |  | 73 | % |  | (1 | %) |  | 69 | % |  | 83 | % |  | (14 | %) |

[0001728949-18-000075:mdna:46]
[same as prior period, unchanged from 0001728949-18-000039:mdna:48]

[0001728949-18-000075:mdna:47]
QCT Segment. The increases in QCT revenues in the third quarter and first nine months of fiscal 2018 were primarily due to increases in equipment and services revenues. Equipment and services revenues, mostly related to sales of Mobile Station Modem (MSM) and accompanying Radio Frequency, Power Management and wireless connectivity integrated circuits, were $4.04 billion and $4.01 billion in the third quarter of fiscal 2018 and 2017, respectively, and $12.49 billion and $11.71 billion in the first nine months of fiscal 2018 and 2017, respectively. Approximately 199 million and 187 million MSM integrated circuits were sold in the third quarter of fiscal 2018 and 2017, respectively, and approximately 623 million and 584 million MSM integrated circuits were sold in the first nine months of fiscal 2018 and 2017, respectively.

[0001728949-18-000075:mdna:48]
The increases in QCT equipment and services revenues in the third quarter and first nine months of fiscal 2018 were primarily due to increases in RFFE product revenues of $75 million and $823 million, respectively, primarily driven by revenues from our RF360 Holdings joint venture, which was formed in the second quarter of fiscal 2017, and reflected the impact of eliminating a one-month reporting lag in the third quarter of fiscal 2018, and increases of $166 million and $559 million, respectively, primarily related to higher MSM and accompanying unit shipments driven primarily by higher demand from OEMs in China, partially offset by a decline in share at Apple. The increase in QCT revenues in the third quarter of fiscal 2018 was partially offset by decreases of $178 million resulting from lower average selling prices and unfavorable product mix and $31 million in connectivity product revenues. The increase in QCT revenues in the first nine months of fiscal 2018 was partially offset by decreases of $422 million resulting from the net impact of lower average selling prices and favorable product mix and $131 million in connectivity product revenues.

[0001728949-18-000075:mdna:49]
QCT EBT as a percentage of revenues in the third quarter of fiscal 2018 increased primarily due to net gains on foreign currency transactions related to our RF360 Holdings joint venture, partially offset by a decrease in gross margin percentage. The decrease in gross margin percentage was primarily due to unfavorable product mix and lower average selling prices, partially offset by lower average unit costs. QCT EBT as a percentage of revenues in first nine months of fiscal 2018 increased primarily due to an increase in gross margin percentage and the favorable impact of higher revenues relative to operating expenses. The increase in gross margin percentage was primarily due to lower average unit costs, partially offset by lower average selling prices.

[0001728949-18-000075:mdna:50]
QCT accounts receivable decreased by 29% in the first nine months of fiscal 2018 from $1.81 billion to $1.30 billion, primarily due to a decline in revenues in the third quarter of fiscal 2018 compared to the fourth quarter of fiscal 2017 and the timing of integrated circuit shipments. QCT inventories decreased by 12% in the first nine months of fiscal 2018 from $2.02 billion to $1.77 billion primarily due to a decrease in the overall quantity of units on hand.

[0001728949-18-000075:mdna:51]
QTL Segment. QTL results in the third quarter and first nine months of fiscal 2018 were negatively impacted by our continued dispute with Apple and its contract manufacturers (who are Qualcomm licensees). We did not record any revenues in the first nine months of fiscal 2018 for royalties due on sales of Apple’s products. QTL revenues in the third quarter of fiscal 2018 included $500 million paid under an interim agreement with the other licensee in dispute. This represents a partial payment for royalties due after the second quarter of fiscal 2017 by that other licensee while negotiations continue, and it does not reflect the full amount of royalties due under the underlying license agreement. We did not record any revenues in the third quarter of fiscal 2017 for royalties due on the sales of Apple’s and the other licensee’s products. Royalty revenues related to the products of Apple’s contract manufacturers and the other licensee in dispute were approximately $1.7 billion in

[0001728949-18-000075:mdna:52]
[same as prior period, unchanged from 0001728949-18-000039:mdna:73]

[0001728949-18-000075:mdna:53]
the first nine months of fiscal 2017. Additionally, QTL revenues in the third quarter and first nine months of fiscal 2018 were negatively impacted by lower royalty revenues recognized related to devices sold in prior periods from certain other licensees. Excluding the impact of these items, QTL revenues in the third quarter of fiscal 2018 decreased primarily due to a decrease in reported sales of CDMA-based products (including multi-mode products that also implement OFDMA) and revenues per reported unit, while QTL revenues in the first nine months of fiscal 2018 increased primarily due to increases in reported sales of CDMA-based products (including multi-mode products that also implement OFDMA) and revenues per reported unit.

[0001728949-18-000075:mdna:54]
QTL EBT as a percentage of revenues in the third quarter and first nine months of fiscal 2018 decreased primarily due to increases in selling, general and administrative expenses resulting from higher litigation costs. The decrease in QTL EBT as a percentage of revenues was partially offset in the third quarter of fiscal 2018 by higher QTL revenues. The decrease in QTL EBT as a percentage of revenues in the first nine months of fiscal 2018 was also attributable to lower QTL revenues. QTL revenues and EBT also continued to be impacted negatively by units that we believe are not being reported by certain other licensees and sales of certain unlicensed products. While we have reached agreements with many licensees, negotiations with certain other licensees and unlicensed companies are ongoing, particularly in emerging regions, including China, and additional litigation may become necessary if negotiations fail to resolve the relevant issues.

[0001728949-18-000075:mdna:55]
QSI Segment. The decrease in QSI EBT in the third quarter of fiscal 2018 was primarily due to the impact of $36 million resulting from lower revenues from certain development contracts with one of our equity method investees and a decrease of $32 million in net realized gains on investments. The increase in QSI EBT in the first nine months of fiscal 2018 was primarily due to higher net realized gains on investments.

[0001728949-18-000075:mdna:56]
[same as prior period, unchanged from 0001728949-18-000039:mdna:58]

[0001728949-18-000075:mdna:57]
In the coming years, we expect continued growth in consumer demand for 3G/4G multi-mode and 4G products and services and new consumer demand for 5G products and services, around the world, driven primarily by smartphones. We also expect growth in new device categories and industries, driven by the expanding adoption of certain technologies that are already commonly used in smartphones by industry segments outside traditional cellular industries, such as automotive, IoT and networking.

[0001728949-18-000075:mdna:58]
[same as prior period, unchanged from 0001728949-18-000039:mdna:60]

[0001728949-18-000075:mdna:59]
| • | On October 27, 2016, we announced a definitive agreement (as amended on February 20, 2018 and April 19, 2018, the Purchase Agreement) under which Qualcomm River Holdings, B.V. (Qualcomm River Holdings), an indirect, wholly owned subsidiary of QUALCOMM Incorporated, proposed to acquire NXP Semiconductors N.V. (NXP). The transaction remains subject to receipt of regulatory clearance by the State Administration for Market Regulation in China (SAMR), which we believe is being impacted by the current state of U.S./China trade relations. In the absence of such approval or other material developments, we expect to terminate the transaction after 11:59 p.m. New York time on July 25, 2018, which is the “End Date” for the transaction under the Purchase Agreement. In accordance with the terms of the Purchase Agreement, in the absence of approval from SAMR prior to the End Date, NXP will be entitled to receive a termination fee of $2.0 billion from Qualcomm River Holdings, which will be paid using existing cash and cash equivalents. If events occur that cause us to not terminate the transaction, we will continue to pursue the acquisition of all of the issued and outstanding common shares of NXP for $127.50 per share in cash, representing estimated total cash consideration to be paid to NXP’s shareholders of $44 billion, in accordance with the Purchase Agreement. |

[0001728949-18-000075:mdna:60]
| • | In the second quarter of fiscal 2018, we announced a cost plan designed to align our cost structure to our long-term margin targets. As part of this plan, we continue to execute on a series of targeted actions across our businesses to reduce annual costs by $1 billion, excluding incremental costs resulting from any future acquisition of a business. We expect these cost reductions to be fully captured in fiscal 2019. In connection with this plan, we expect to incur an additional $50 million to $150 million in restructuring and restructuring-related charges, and we have incurred $112 million and $422 million in restructuring and restructuring-related charges in the third quarter and first nine months of fiscal 2018, respectively. |

[0001728949-18-000075:mdna:61]
| • | Regulatory authorities in certain jurisdictions continue to investigate our business practices, and other regulatory authorities may do so in the future. Unfavorable resolutions of one or more of these matters have had and could in the future have a material adverse effect on our business with remedies that include, among others, injunctions, monetary damages or fines or other orders to pay money, and the issuance of orders to cease certain conduct and/or modify our business practices. Additionally, certain of our direct and indirect customers and licensees, including Apple, have pursued, and others may in the future pursue, litigation or arbitration against us related to our business. |

[0001728949-18-000075:mdna:62]
38

[0001728949-18-000075:mdna:63]
Unfavorable resolutions of one or more of these matters have in the past had a material adverse effect on our business, and could in the future have a material adverse effect on our business including, among others, monetary damages, the loss of our ability to enforce one or more of our patents, and/or portions of our license agreements could be determined to be invalid or unenforceable. These activities have required, and we expect that they will continue to require, the investment of significant management time and attention and have resulted, and we expect that they will continue to result, in increased legal costs until the respective matters are resolved. See “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies” and “Risk Factors” included in this Quarterly Report.

[0001728949-18-000075:mdna:64]
| • | We are currently in dispute with Apple surrounding what we believe is an attempt by Apple to reduce the amount of royalties that its contract manufacturers (who are Qualcomm licensees) are required to pay to us for use of our intellectual property. In the first nine months of fiscal 2018, such contract manufacturers did not fully report, and did not pay, royalties due on sales of Apple products. We have taken action against Apple’s contract manufacturers to compel them to pay the required royalties, and against Apple, as described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” We did not record any revenues in the first nine months of fiscal 2018 for royalties due on sales of Apple’s products, and as a result, QTL revenues and EBT were negatively impacted by these continued disputes. We expect these companies will continue to take such actions in the future, resulting in increased legal costs and negatively impacting our future revenues, as well as our financial condition, results of operations and cash flows until the respective disputes are resolved. In the third quarter of fiscal 2018, we entered into an interim agreement with the other licensee in dispute in which that licensee agreed to pay $700 million as partial payment for royalties due after the second quarter of fiscal 2017. That licensee paid $500 million in the third quarter of fiscal 2018 as a partial payment while negotiations continue. This payment does not reflect the full amount of royalties due under the underlying license agreement. If we do not reach a final agreement with that other licensee, it may not make any other payments or may not make full payments under the underlying license agreement, which may result in increased legal costs and will negatively impact our future revenues, as well as our financial condition, results of operations and cash flows until the dispute is resolved. |

[0001728949-18-000075:mdna:65]
| • | We continue to believe that certain licensees, particularly those domiciled in China, are not fully complying with their contractual obligations to report their sales of licensed products to us, and certain companies, including unlicensed companies, particularly in emerging regions, including China, are delaying execution of new license agreements. We have made substantial progress in reaching agreements with many companies, primarily in China. However, negotiations with certain licensees and unlicensed companies are ongoing. We believe that the conclusion of new agreements with these companies will result in improved reporting. Litigation and/or other actions, such as those taken against Apple and its contract manufacturers, may be necessary to compel licensees to report and pay the required royalties for sales they have not previously reported and/or to compel unlicensed companies to execute licenses. Such litigation or other actions would result in increased legal costs. |

[0001728949-18-000075:mdna:66]
| • | To position QTL for stability on a long-term basis, we have announced that our standard essential patent only licensing terms through 5G, Release 15 will remain at the same rate, consistent with our licensing program established in China for 3G and 4G devices. A small number of our licensees have entered into standard essential patent only agreements on a worldwide basis, and we expect more of our licensees may enter into such standard essential patent only agreements basis as existing agreements come up for renewal and/ or renegotiation. In addition, we have reduced the per unit royalty cap on smartphones, which is the base on which our royalties are calculated. While we expect these developments to enhance stability for the long term, they will impact QTL royalty revenues in the shorter term. |

[0001728949-18-000075:mdna:67]
[same as prior period, unchanged from 0001728949-18-000039:mdna:68]

[0001728949-18-000075:mdna:68]
[same as prior period, unchanged from 0001728949-18-000039:mdna:69]

[0001728949-18-000075:mdna:69]
[same as prior period, unchanged from 0001728949-18-000039:mdna:70]

[0001728949-18-000075:mdna:70]
| • | Decisions by certain companies to utilize our competitors’ integrated circuit products in all or a portion of their devices. For example, we have not been the sole supplier of modems for iPhone products beginning with products that launched in September 2016, as Apple utilizes modems from one of our competitors in a portion of such devices. We expect that Apple will solely use one or more of our competitor’s modems, rather than our modems, in its next iPhone release and may take similar actions in the future. Accordingly, |

[0001728949-18-000075:mdna:71]
39

[0001728949-18-000075:mdna:72]
QCT revenues from modem sales for iPhones are expected to decline in fiscal 2018 and may continue to decline in the future, in part depending on the extent of Apple’s utilization of competitors’ modems and the mix of the various versions of its products that are sold. Overall QCT revenues, as well as profitability, may similarly decline unless offset by sales of integrated circuit products to other customers, including those outside of traditional cellular industries, such as the Internet of Things (IoT), automotive and networking. Apple’s sourcing of integrated circuit products does not impact our licensing revenues since our licensing revenues from Apple products are not dependent upon whether such products include our chipsets;

[0001728949-18-000075:mdna:73]
[same as prior period, unchanged from 0001728949-18-000039:mdna:72]

[0001728949-18-000075:mdna:74]
[same as prior period, unchanged from 0001728949-18-000039:mdna:74]

[0001728949-18-000075:mdna:75]
[same as prior period, unchanged from 0001728949-18-000039:mdna:75]

[0001728949-18-000075:mdna:76]
[same as prior period, unchanged from 0001728949-18-000039:mdna:76]

[0001728949-18-000075:mdna:77]
[same as prior period, unchanged from 0001728949-18-000039:mdna:77]

[0001728949-18-000075:mdna:78]
[same as prior period, unchanged from 0001728949-18-000039:mdna:78]

[0001728949-18-000075:mdna:79]
| • | We continue to invest significant resources to develop our wireless baseband chips and our converged computing/communications (Snapdragon) chipsets, which incorporate technologies in the following areas, among others: advancements in 4G and 5G, OFDM-based WLAN, RFFE, connectivity, power management, graphics, audio and video codecs, multimedia, artificial intelligence and virtual/augmented reality, and all of which contribute to the expansion of our intellectual property portfolio. We are also investing in targeted opportunities that leverage our existing technical and business expertise to deploy new business models and enter and/or expand into new industry segments, such as products for automotive, IoT (including the connected home, smart cities, wearables, voice and music and robotics), networking, computing and machine learning, among others. |

[0001728949-18-000075:mdna:80]
[same as prior period, unchanged from 0001728949-18-000039:mdna:80]

[0001728949-18-000075:mdna:81]
[same as prior period, unchanged from 0001728949-18-000039:mdna:81]

[0001728949-18-000075:mdna:82]
[same as prior period, unchanged from 0001728949-18-000039:mdna:82]

[0001728949-18-000075:mdna:83]
On October 27, 2016, we announced a Purchase Agreement under which Qualcomm River Holdings proposed to acquire NXP. The transaction remains subject to receipt of regulatory approval from SAMR and other closing conditions. In the absence of such approval or other material developments, we expect to terminate the transaction after 11:59 p.m. New York time on July 25, 2018, which is the “End Date” for the transaction under the Purchase Agreement. In accordance with the terms of the Purchase Agreement, in the absence of approval from SAMR prior to the End Date, NXP will be entitled to receive a termination fee of $2.0 billion from Qualcomm River Holdings, which will be paid using existing cash and cash equivalents.

[0001728949-18-000075:mdna:84]
If events occur that cause us to not terminate the transaction, we will continue to pursue the acquisition of all of the issued and outstanding common shares of NXP for $127.50 per share in cash, representing estimated total cash consideration to be paid to NXP’s shareholders of $44 billion, in accordance with the Purchase Agreement. In such case, we could be required to pay NXP a termination fee of $2.0 billion if the transaction is subsequently terminated in certain circumstances, as set forth in the Purchase Agreement.

[0001728949-18-000075:mdna:85]
Qualcomm River Holdings entered into four letters of credit for an aggregate amount of $2.0 billion pursuant to which NXP will have the right to draw amounts to fund the potential termination fee payable to NXP. Upon our payment of the termination fee, NXP will no longer have the right to validly draw on the letters of credit. Each letter of credit is required to

[0001728949-18-000075:mdna:86]
be fully cash collateralized in an amount equal to 100% of its face value through deposits with the issuers of the letters of credit. We are restricted from using the funds deposited as collateral while the letters of credit are outstanding. At June 24, 2018, the letters of credit were fully collateralized through bank time and demand deposits.

[0001728949-18-000075:mdna:87]
Our principal sources of liquidity are our existing cash, cash equivalents and marketable securities, cash generated from operations, cash provided by our debt programs and proceeds from the issuance of common stock under our stock option and employee stock purchase plans. The following table presents selected financial information related to our liquidity as of June 24, 2018 and September 24, 2017 and for the first nine months of fiscal 2018 and 2017 (in millions):

[0001728949-18-000075:mdna:88]
|  | June 24, 2018 |  | September 24, 2017 |  | $ Change |  | % Change |
| Cash, cash equivalents and marketable securities | $ | 35,945 |  |  | $ | 38,578 |  |  | $ | (2,633 | ) |  | (7 | %) |
| Accounts receivable, net | 3,163 |  |  | 3,632 |  |  | (469 | ) |  | (13 | %) |
| Inventories | 1,785 |  |  | 2,035 |  |  | (250 | ) |  | (12 | %) |
| Short-term debt | 7,103 |  |  | 2,495 |  |  | 4,608 |  |  | 185 | % |
| Long-term debt | 15,378 |  |  | 19,398 |  |  | (4,020 | ) |  | (21 | %) |
| Noncurrent income taxes payable | 2,659 |  |  | — |  |  | 2,659 |  |  | N/M |  |

[0001728949-18-000075:mdna:89]
[same as prior period, unchanged from 0001728949-18-000039:mdna:88]

[0001728949-18-000075:mdna:90]
|  | Nine Months Ended |
|  | June 24, 2018 |  | June 25, 2017 |  | $ Change |  | % Change |
| Net cash provided by operating activities | $ | 4,331 |  |  | $ | 2,577 |  |  | $ | 1,754 |  |  | 68 | % |
| Net cash provided (used) by investing activities | 2,615 |  |  | (342 | ) |  | 2,957 |  |  | N/M |  |
| Net cash (used) provided by financing activities | (6,337 | ) |  | 6,700 |  |  | (13,037 | ) |  | N/M |  |

[0001728949-18-000075:mdna:91]
The net decrease in cash, cash equivalents and marketable securities was primarily due to $2.8 billion in cash deposited to redeem long-term debt in July 2018, $2.6 billion in cash dividends paid, $1.6 billion in repayment of long-term debt, $1.4 billion in payments to repurchase shares of our common stock and $625 million in capital expenditures, partially offset by net cash provided by operating activities and $2.2 billion of net issuances of our outstanding commercial paper debt. Total cash provided by operating activities increased primarily due to the effect of the $940 million payment in connection with the BlackBerry arbitration and the $927 million payment of the fine related to the KFTC investigation in the first nine months of fiscal 2017. Total cash provided by operating activities was also impacted by continued actions taken by Apple and its contract manufacturers who did not report or pay royalties due in the first nine months of fiscal 2018.

[0001728949-18-000075:mdna:92]
Our days sales outstanding, on a consolidated basis, decreased to 51 days at June 24, 2018, as compared to 56 days at September 24, 2017. The decrease in accounts receivable and the related days sales outstanding were primarily due to the timing of integrated circuit shipments and the collection of receivables related to integrated circuits. The decrease in days sales outstanding was also attributable to $500 million recognized as revenues and paid under an interim agreement with the other licensee in dispute. The decrease in inventories was primarily due to a decrease in the overall quantity of units on hand.

[0001728949-18-000075:mdna:93]
Debt. Our 2016 Amended and Restated Revolving Credit Facility provides for unsecured revolving facility loans, swing line loans and letters of credit in the aggregate amount of $5.0 billion, of which $530 million and $4.47 billion will expire in February 2020 and November 2021, respectively. At June 24, 2018, no amounts were outstanding under the revolving credit facility.

[0001728949-18-000075:mdna:94]
We have an unsecured commercial paper program, which provides for the issuance of up to $5.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. At June 24, 2018, we had $3.2 billion of commercial paper outstanding with weighted-average net interest rates of 2.34% and weighted-average remaining days to maturity of 46 days.

[0001728949-18-000075:mdna:95]
Our 2018 Revolving Credit Facility, 2016 Term Loan Facility and our 2018 Term Loan Facility were established primarily to fund the proposed acquisition of NXP. In the event the NXP purchase agreement is terminated, these commitments will expire unused in accordance with their terms. Our 2018 Revolving Credit Facility provides for unsecured delayed-draw revolving facility loans in an aggregate amount of $3.0 billion. Our 2016 Term Loan Facility provides for senior unsecured delayed-draw term facility loans in an aggregate amount of $4.0 billion, and our 2018 Term Loan Facility provides for senior unsecured delayed-draw term facility loans in an aggregate amount of $7.0 billion. At June 24, 2018, no amounts were outstanding under the credit or term loan facilities.

[0001728949-18-000075:mdna:96]
In May 2017, we issued an aggregate principal amount of $11.0 billion in nine tranches of unsecured floating- and fixed-rate notes, with maturity dates starting in 2019 through 2047. Effective interest rates were between 2.70% and 4.74% at June 24, 2018. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes.

[0001728949-18-000075:mdna:97]
In May 2018, we initiated offers to exchange and repurchase certain of our notes issued in May 2017 that were subject to special mandatory redemption provisions. We exchanged $122 million of notes and repurchased $71 million of notes in the aggregate. On May 31, 2018, we called for full redemption of our then-outstanding fixed-rate notes subject to special mandatory redemption provisions and irrevocably deposited cash of $2.8 billion with the trustee of the notes, of which $2.6 billion was paid to the holders of the fixed-rate notes on July 2, 2018, with the excess amount refunded to us. On June 8, 2018, we called for full redemption of our then-outstanding floating-rate notes of $1.2 billion subject to special mandatory redemption provisions, which was subsequently paid to the holders of the floating-rate notes on July 6, 2018. Our floating-rate notes due 2019, floating-rate notes due 2020 and 1.85% fixed-rate notes due 2019 issued in May 2018 as part of the exchange offers for an aggregate principal amount of $122 million are subject to a special mandatory redemption at a price equal to 101% of the aggregate principal amount, plus accrued and unpaid interest to, but excluding, the date of such mandatory redemption (the May 2018 Notes). The redemption is required on the first to occur of (i) the termination of the NXP purchase agreement or (ii) November 1, 2018, if the NXP transaction has not closed as of such date. In the event the NXP purchase agreement is terminated, the May 2018 Notes will be redeemed in accordance with their terms. We may redeem the fixed-rate notes issued in May 2018 at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note.

[0001728949-18-000075:mdna:98]
In May 2015, we issued an aggregate principal amount of $10.0 billion in eight tranches of unsecured floating- and fixed-rate notes, of which $8.5 billion remains outstanding with maturity dates in 2020 through 2045. Effective interest rates were between 2.94% and 4.74% at June 24, 2018. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes.

[0001728949-18-000075:mdna:99]
[same as prior period, unchanged from 0001728949-18-000039:mdna:97]

[0001728949-18-000075:mdna:100]
Additional information regarding our outstanding debt at June 24, 2018 is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 5. Debt.”

[0001728949-18-000075:mdna:101]
Income Taxes. The Tax Legislation, which was signed into law during the first quarter of fiscal 2018, resulted in an estimated $5.3 billion charge related to the Toll Charge. We currently estimate that we will pay $2.7 billion for the Toll Charge, after application of certain tax credits (including those that are expected to be generated in fiscal 2018), which is payable in installments over eight years (8% in each of the first five years, 15% in year six, 20% in year seven and 25% in year eight) beginning on January 15, 2019.

[0001728949-18-000075:mdna:102]
Our cash, cash equivalents and marketable securities at June 24, 2018 consisted of $5.7 billion held by our United States-based entities and $30.2 billion held by our foreign entities. The Tax Legislation eliminated certain material tax effects on the repatriation of cash to the United States. As of December 24, 2017, we no longer consider available cash balances that existed at the end of fiscal 2017 related to undistributed pre-fiscal 2018 earnings and profits of certain U.S.-owned foreign subsidiaries to be indefinitely reinvested. We otherwise continue to consider other undistributed earnings of certain U.S.-owned foreign subsidiaries to be indefinitely reinvested based on our current plans for use and/or investment outside of the U.S., and therefore, no liability has been recorded for such taxes. However, as a result of the Tax Legislation, we are reassessing our intentions related to our indefinite reinvestment assertion. Should we decide to no longer indefinitely reinvest such earnings outside the U.S., we would have to adjust the income tax provision in the period such determination is made.

[0001728949-18-000075:mdna:103]
[same as prior period, unchanged from 0001728949-18-000039:mdna:101]

[0001728949-18-000075:mdna:104]
Capital Return Program. In the first nine months of fiscal 2018, we repurchased and retired 24.2 million shares of our common stock for $1.4 billion, before commissions. On May 9, 2018, we announced that we had been authorized to repurchase up to $10 billion of our common stock. The $10 billion stock repurchase program replaced a $15 billion stock repurchase program announced on March 9, 2015, of which $1.2 billion remained authorized for repurchase under the prior program. At June 24, 2018, $9.0 billion remained authorized for repurchase under the stock repurchase program announced in May 2018.

[0001728949-18-000075:mdna:105]
In the event the agreement to acquire NXP is terminated, we intend to implement a stock repurchase program to repurchase up to $30 billion of our outstanding common stock. This stock repurchase program will significantly reduce the amount of cash that we have available to fund our operations (including research and development), working capital, capital

[0001728949-18-000075:mdna:106]
expenditures, acquisitions, investments, dividends and other corporate purposes; and limit our flexibility in planning for or reacting to, and increase our vulnerability to, adverse economic, market, industry and competitive conditions and developments, and other changes in our business and our industry. This new stock repurchase program, if implemented, will have no expiration date and will replace the May 2018 stock repurchase program.

[0001728949-18-000075:mdna:107]
However, we periodically evaluate repurchases as a means of returning capital to stockholders to determine when and if repurchases are in the best interests of our stockholders and may accelerate, suspend, delay or discontinue repurchases at any time.

[0001728949-18-000075:mdna:108]
In the first nine months of fiscal 2018, we paid cash dividends totaling $2.6 billion, or $1.76 per share. On July 12, 2018, we announced a cash dividend of $0.62 per share on our common stock, payable on September 26, 2018 to stockholders of record as of the close of business on September 5, 2018. We intend to continue to use cash dividends as a means of returning capital to stockholders, subject to capital availability and our view that cash dividends are in the best interests of our stockholders.

[0001728949-18-000075:mdna:109]
Additional Capital Requirements. We believe our cash, cash equivalents and marketable securities, our expected cash flow generated from operations and our expected financing activities will satisfy our working and other capital requirements for at least the next 12 months based on our current business plans. Recent and expected working and other capital requirements, in addition to the above matters, also include the items described below.

[0001728949-18-000075:mdna:110]
| • | We expect the majority of the charges incurred in connection with our Cost Plan will result in cash payments. Our restructuring accrual was $252 million at June 24, 2018, and we expect to incur additional restructuring and restructuring-related charges of approximately $50 million to $150 million. |

[0001728949-18-000075:mdna:111]
| • | Our purchase obligations at June 24, 2018, some of which relate to research and development activities and capital expenditures, totaled $2.8 billion and $1.7 billion for fiscal 2018 and 2019, respectively, and $663 million thereafter. |

[0001728949-18-000075:mdna:112]
| • | Our research and development expenditures were $4.2 billion in the first nine months of fiscal 2018 and $5.5 billion in fiscal 2017, and we expect to continue to invest heavily in research and development for new technologies, applications and services for voice and data communications. |

[0001728949-18-000075:mdna:113]
| • | Cash outflows for capital expenditures were $625 million in the first nine months of fiscal 2018 and $690 million in fiscal 2017. We expect to continue to incur capital expenditures in the future to support our business, including research and development activities. Future capital expenditures may be impacted by transactions that are currently not forecasted. |

[0001728949-18-000075:mdna:114]
| • | The TFTC imposed a fine on us, of which $708 million remained outstanding at June 24, 2018 (based on the exchange rate at June 24, 2018 and including related foreign currency gains), which will be paid in monthly installments through December 2022. |

[0001728949-18-000075:mdna:115]
| • | The EC imposed a fine on us, of which $1.2 billion was accrued at June 24, 2018 (based on the exchange rate at June 24, 2018, including related foreign currency gains and accrued interest). In the third quarter of 2018, we provided financial guarantees in lieu of cash payment to satisfy the obligation. The fine is accruing interest at a rate of 1.50% per annum until it is paid or annulled. |

[0001728949-18-000075:mdna:116]
[same as prior period, unchanged from 0001728949-18-000039:mdna:112]

[0001728949-18-000075:mdna:117]
[same as prior period, unchanged from 0001728949-18-000039:mdna:113]

[0001728949-18-000075:mdna:118]
[same as prior period, unchanged from 0001728949-18-000039:mdna:114]

[0001728949-18-000075:mdna:119]
Additional information regarding our financial commitments at June 24, 2018 is provided in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 3. Income Taxes,” “Note 5. Debt,” “Note 6. Commitments and Contingencies” and “Note 8. Acquisitions.”

[0001728949-18-000075:mdna:120]
[same as prior period, unchanged from 0001728949-18-000039:mdna:116]

[0001728949-18-000075:mdna:121]
[same as prior period, unchanged from 0001728949-18-000039:mdna:117]

[0001728949-18-000075:mdna:122]
[same as prior period, unchanged from 0001728949-18-000039:mdna:118]

[0001728949-18-000075:mdna:123]
[same as prior period, unchanged from 0001728949-18-000039:mdna:119]

[0001728949-18-000075:mdna:124]
[same as prior period, unchanged from 0001728949-18-000039:mdna:120]

[0001728949-18-000075:mdna:125]
Our proposed acquisition of NXP Semiconductors N.V. (NXP), and our intended termination of that acquisition, entails a number of risks that may adversely affect our business and results of operations.

[0001728949-18-000075:mdna:126]
Our proposed acquisition of NXP has not been approved by the State Administration for Market Regulation in China (SAMR). In the absence of such approval or other material developments, we expect to terminate the transaction after 11:59 p.m. New York time on July 25, 2018, which is the “End Date” for the transaction under the Purchase Agreement. As a result, we would not realize the benefits that we anticipated from the acquisition, including, but not limited to, increased revenues; accelerated revenue diversification; significantly expanded addressable markets and opportunities; accelerated entry into new industry segments and expansion in existing industry segments; new and expanded product offerings and technologies; accelerated expansion of sales and distribution channels; cost and other synergies; and earnings accretion from the acquisition. In addition, future acquisitions may be more difficult, complex or expensive to the extent that our reputation for our ability to consummate acquisitions is harmed. Further, if U.S./China trade relations remain strained, our ability to consummate any transaction that would require SAMR approval may be severely impacted.

[0001728949-18-000075:mdna:127]
If the proposed transaction is terminated, our stock price could fall and we may suffer other consequences that could adversely affect our business, results of operations and stock price, including, among others:

[0001728949-18-000075:mdna:128]
| • | we would be required to pay a termination fee to NXP of $2.0 billion; |

[0001728949-18-000075:mdna:129]
| • | we will have incurred and may continue to incur costs relating to the transaction, many of which are payable by us even if the transaction is not completed; |

[0001728949-18-000075:mdna:130]
| • | matters relating to the transaction (including integration planning) required substantial commitments of time and resources by our management team and numerous others throughout our organization, which could otherwise have been devoted to other opportunities; |

[0001728949-18-000075:mdna:131]
| • | we may be subject to legal proceedings related to the failure to complete the transaction; |

[0001728949-18-000075:mdna:132]
| • | the failure to consummate the transaction may result in negative publicity and a negative perception of us in the investment community; and |

[0001728949-18-000075:mdna:133]
| • | any disruptions to our business resulting from the announcement and pendency of the transaction, including any adverse changes in our relationships with our customers, suppliers, partners or employees, may continue or intensify if the transaction is not consummated. |

[0001728949-18-000075:mdna:134]
Even if we receive approval of the NXP transaction from SAMR, or there are other material developments that cause us to not terminate the NXP acquisition, the proposed transaction involves a number of risks, including, among others, the risk that we fail to complete the acquisition, regulatory risks, risks associated with our use of a significant portion of our cash and our taking on significant indebtedness, other financial risks, integration risks, and risk associated with the reactions of customers, suppliers and employees.

[0001728949-18-000075:mdna:135]
Our and NXP’s obligations to consummate the proposed transaction are subject to the satisfaction or waiver of certain conditions, including, among others: (i) the tender of a minimum number of NXP’s outstanding common shares in the tender offer commenced by a subsidiary of QUALCOMM Incorporated; (ii) the receipt of regulatory clearance from SAMR; (iii) the absence of any law or order prohibiting the proposed transaction; (iv) there being no event that would have a material adverse effect on NXP; (v) the accuracy of the representations and warranties of NXP, subject to certain exceptions, and NXP’s material compliance with its covenants, in the Purchase Agreement; and (vi) the completion of certain internal reorganization steps with respect to NXP and the disposition of certain non-core assets of NXP. We cannot provide assurance that the conditions to the completion of the proposed transaction will be satisfied.

[0001728949-18-000075:mdna:136]
44

[0001728949-18-000075:mdna:137]
The final regulatory approval required in connection with the proposed transaction may not ultimately be obtained or may contain materially burdensome conditions. If any conditions or changes to the structure of the proposed transaction are required to obtain this regulatory approval, they may have the effect of jeopardizing or delaying completion of the proposed transaction or reducing our anticipated benefits. If we agree to any material conditions in order to obtain this approval, our business and results of operations may be adversely affected.

[0001728949-18-000075:mdna:138]
In addition, the use of a significant portion of our cash and the incurrence of substantial indebtedness in connection with the financing of the proposed transaction will reduce our liquidity, and may limit our flexibility in responding to other business opportunities and increase our vulnerability to adverse economic and industry conditions. See the Risk Factor entitled “There are risks associated with our indebtedness and our significant proposed stock repurchase program.”

[0001728949-18-000075:mdna:139]
The proposed transaction will be our largest acquisition to date, by a significant margin. The benefits we expect to realize from the proposed transaction will depend, in part, on our ability to integrate the businesses successfully and efficiently. See the Risk Factor entitled “We may engage in strategic acquisitions, transactions or make investments, or be unable to consummate planned strategic acquisitions, which could adversely affect our results of operations or fail to enhance stockholder value.”

[0001728949-18-000075:mdna:140]
[same as prior period, unchanged from 0001728949-18-000039:mdna:134]

[0001728949-18-000075:mdna:141]
The proposed transaction may also result in significant charges or other liabilities that could adversely affect our results of operations, such as cash expenses and non-cash accounting charges incurred in connection with our acquisition and/or integration of the business and operations of NXP. Further, our failure to identify or accurately assess the magnitude of certain liabilities we are assuming in the proposed transaction could result in unexpected litigation or regulatory exposure, unfavorable accounting charges, unexpected increases in taxes due, a loss of anticipated tax benefits or other adverse effects on our business, results of operations, financial condition or cash flows.

[0001728949-18-000075:mdna:142]
[same as prior period, unchanged from 0001728949-18-000039:mdna:136]

[0001728949-18-000075:mdna:143]
We develop, patent and commercialize technology and products based on CDMA, OFDMA and other communications technologies, which are primarily wireless. We depend on operators of wireless networks and our customers and licensees to adopt and/or implement the latest generation of these technologies for use in their networks, devices and services. We also depend on our customers and licensees to develop devices and services based on these technologies with value-added features to drive consumer demand for new 3G, 3G/4G multi-mode and 4G devices, and in the future 5G devices, as well as establishing the selling prices for such devices. Further, we depend on the timing of our customers’ and licensees’ deployments of new devices and services based on these technologies. Increasingly, we also depend on operators of wireless networks, our customers and licensees and other third parties to incorporate these technologies into new device types and into industries beyond traditional cellular communications, such as automotive, the internet of things (IoT) (including the connected home, smart cities, wearables, voice and music and robotics), networking, computing and machine learning, among others. We are also impacted by consumers’ rates of replacement of smartphones and other computing devices.

[0001728949-18-000075:mdna:144]
[same as prior period, unchanged from 0001728949-18-000039:mdna:138]

[0001728949-18-000075:mdna:145]
[same as prior period, unchanged from 0001728949-18-000039:mdna:139]

[0001728949-18-000075:mdna:146]
[same as prior period, unchanged from 0001728949-18-000039:mdna:140]

[0001728949-18-000075:mdna:147]
[same as prior period, unchanged from 0001728949-18-000039:mdna:141]

[0001728949-18-000075:mdna:148]
| • | government regulators delay making sufficient spectrum available for 3G, 4G and new spectrum sharing technologies that we are developing in conjunction with 3G and 4G, as well as for 5G, thereby restricting the ability of wireless operators to deploy or expand the use of these technologies; |

[0001728949-18-000075:mdna:149]
45

[0001728949-18-000075:mdna:150]
[same as prior period, unchanged from 0001728949-18-000039:mdna:143]

[0001728949-18-000075:mdna:151]
[same as prior period, unchanged from 0001728949-18-000039:mdna:144]

[0001728949-18-000075:mdna:152]
[same as prior period, unchanged from 0001728949-18-000039:mdna:145]

[0001728949-18-000075:mdna:153]
[same as prior period, unchanged from 0001728949-18-000039:mdna:146]

[0001728949-18-000075:mdna:154]
[same as prior period, unchanged from 0001728949-18-000039:mdna:147]

[0001728949-18-000075:mdna:155]
[same as prior period, unchanged from 0001728949-18-000039:mdna:148]

[0001728949-18-000075:mdna:156]
Our products, services and technologies face significant competition. We expect competition to increase as our current competitors expand their product offerings or reduce the prices of their products as part of a strategy to attract new business and/or customers, as new opportunities develop and as new competitors enter the industry. Competition in wireless communications is affected by various factors that include, among others: device manufacturer concentrations and vertical integration; growth in demand, consumption and competition in certain geographic regions; government intervention and/or support of national industries and/or competitors; evolving industry standards and business models; evolving methods of transmission of voice and data communications; increasing data traffic and densification of wireless networks; convergence and aggregation of connectivity technologies (including Wi-Fi and LTE) in both devices and access points; consolidation of wireless technologies and infrastructure at the network edge; networking and connectivity trends (including cloud services); use of both licensed and unlicensed spectrum; the evolving nature of computing (including demand for always on, always connected capabilities); the speed of technological change (including the transition to smaller geometry process technologies); value-added features that drive selling prices as well as consumer demand for new 3G, 3G/4G multi-mode and 4G devices; turnkey, integrated products that incorporate hardware, software, user interface, applications and reference designs; scalability; and the ability of the system technology to meet customers’ immediate and future network requirements. We anticipate that additional competitors will introduce products as a result of growth opportunities in wireless communications, the trend toward global expansion by foreign and domestic competitors, technological and public policy changes and relatively low barriers to entry in certain segments of the industry. Additionally, the semiconductor industry has experienced and may continue to experience consolidation, which could result in significant changes to the competitive landscape.

[0001728949-18-000075:mdna:157]
[same as prior period, unchanged from 0001728949-18-000039:mdna:152]

[0001728949-18-000075:mdna:158]
[same as prior period, unchanged from 0001728949-18-000039:mdna:153]

[0001728949-18-000075:mdna:159]
[same as prior period, unchanged from 0001728949-18-000039:mdna:154]

[0001728949-18-000075:mdna:160]
| • | continue to drive the adoption of our integrated circuit products into the most popular device models and across a broad spectrum of devices, such as smartphones, tablets, laptops and other computing devices, automobiles, wearables and voice and music and other connected devices and infrastructure products; |

[0001728949-18-000075:mdna:161]
[same as prior period, unchanged from 0001728949-18-000039:mdna:156]

[0001728949-18-000075:mdna:162]
[same as prior period, unchanged from 0001728949-18-000039:mdna:157]

[0001728949-18-000075:mdna:163]
[same as prior period, unchanged from 0001728949-18-000039:mdna:158]

[0001728949-18-000075:mdna:164]
[same as prior period, unchanged from 0001728949-18-000039:mdna:183]

[0001728949-18-000075:mdna:165]
[same as prior period, unchanged from 0001728949-18-000039:mdna:159]

[0001728949-18-000075:mdna:166]
[same as prior period, unchanged from 0001728949-18-000039:mdna:160]

[0001728949-18-000075:mdna:167]
[same as prior period, unchanged from 0001728949-18-000039:mdna:161]

[0001728949-18-000075:mdna:168]
| • | create standalone value and/or contribute to the success of our existing businesses through acquisitions, joint ventures and other transactions (and/or by developing customer, licensee and/or vendor relationships) in new industry segments and/or disruptive technologies, products and/or services (such as products for automotive, IoT (including the connected home, smart cities, wearables, voice and music and robotics), networking, computing and machine learning, among others); |

[0001728949-18-000075:mdna:169]
[same as prior period, unchanged from 0001728949-18-000039:mdna:163]

[0001728949-18-000075:mdna:170]
[same as prior period, unchanged from 0001728949-18-000039:mdna:164]

[0001728949-18-000075:mdna:171]
[same as prior period, unchanged from 0001728949-18-000039:mdna:165]

[0001728949-18-000075:mdna:172]
Competition in any or all product tiers may result in the loss of certain business or customers, which would negatively impact our revenues, results of operations and cash flows. Such competition may also reduce average selling prices for our chipset products and/or the products of our customers and licensees. Certain of these dynamics are particularly pronounced in emerging regions where competitors may have lower cost structures and/or may have a willingness and ability to accept lower prices and/or lower or negative margins on their products (particularly in China). Reductions in the average selling prices of our chipset products, without a corresponding increase in volumes, would negatively impact our revenues, and without corresponding decreases in average unit costs, would negatively impact our margins. In addition, reductions in the average selling prices of our licensees’ products, unless offset by an increase in volumes, would generally decrease total royalties payable to us, negatively impacting our licensing revenues.

[0001728949-18-000075:mdna:173]
We compete with many different semiconductor companies, ranging from multinational companies with integrated research and development, manufacturing, sales and marketing organizations across a broad spectrum of product lines, to companies that are focused on a single application market segment or standard product, including those that produce products for automotive, IoT and networking applications. Most of these competitors compete with us with respect to some, but not all, of our businesses. Companies that promote standards that are neither CDMA- nor OFDMA-based (e.g., GSM) as well as companies that design integrated circuits based on CDMA, OFDMA, Wi-Fi or their derivatives are generally competitors or potential competitors. Examples (some of which are strategic partners of ours in other areas) include Advanced Micro Devices, Inc., Broadcom Limited, Cirrus Logic, Cypress Semiconductor Corporation, HiSilicon Technologies, Intel, Marvell Technology, Maxim Integrated Products, MediaTek, Microchip Technology Inc., Murata Manufacturing Co., Ltd., Nordic Semiconductor, Nvidia, Qorvo Inc., Realtek Semiconductor, Renesas Electronics Corporation, Samsung Electronics, Sequans Communications S.A., Skyworks Solutions Inc., Sony Corporation and Spreadtrum Communications (which is controlled by Tsinghua Unigroup). Some of these current and potential competitors may have advantages over us that include, among others: motivation by our customers in certain circumstances to utilize their own internally-developed integrated circuit products, to use our competitors’ integrated circuit products and/or sell such products to others, including by bundling with other products, or to choose alternative technologies; lower cost structures and/or a willingness and ability to accept lower prices and lower or negative margins for their products, particularly in China; foreign government support of other technologies or competitors; better known brand names; ownership and control of manufacturing facilities and greater expertise in manufacturing processes; more extensive relationships with local distribution companies and original equipment manufacturers in certain geographic regions (such as China) and/or experience in adjacent industry segments outside traditional cellular industries (such as automotive and IoT); and/or a more established presence in certain regions.

[0001728949-18-000075:mdna:174]
[same as prior period, unchanged from 0001728949-18-000039:mdna:192]

[0001728949-18-000075:mdna:175]
[same as prior period, unchanged from 0001728949-18-000039:mdna:169]

[0001728949-18-000075:mdna:176]
Our QCT segment derives a significant portion of its revenues from a small number of customers, and we expect this trend to continue in the foreseeable future. Our industry is experiencing and may continue to experience concentration of device share among a few companies, particularly at the premium tier, contributing to this trend. In addition, certain of our largest integrated circuit customers develop their own integrated circuit products, which they have in the past chosen to utilize in certain of their devices rather than our products, and may in the future choose to utilize in certain (or all) of their devices rather than our products (and/or sell their integrated circuit products to third parties in competition with us). Also, one of our integrated circuit customers, which has historically been one of our largest customers, now utilizes products of one of our competitors in many of their devices rather than our products. We expect this customer will solely utilize one or more or our competitor’s products in its next smartphone launch and may take similar actions in the future.

[0001728949-18-000075:mdna:177]
[same as prior period, unchanged from 0001728949-18-000039:mdna:171]

[0001728949-18-000075:mdna:178]
One of our integrated circuit customers, which has historically been one of our largest customers, purchases our Mobile Data Modem (MDM) products, which do not include our integrated application processor technology and which have lower revenue and margin contributions than our combined modem and application processor products. To the extent such customer takes device share from our other customers who purchase our integrated modem and application processor products, our revenues and margins may be negatively impacted.

[0001728949-18-000075:mdna:179]
Further, companies that develop HLOS for devices, including leading technology companies, now sell their own devices. If we fail to effectively partner or continue partnering with these companies, or with their partners or customers, they may decide not to purchase (either directly or through their contract manufacturers), or to reduce or discontinue their purchases of, our integrated circuit products.

[0001728949-18-000075:mdna:180]
In addition, there has been and continues to be litigation among certain of our customers and other industry participants, and the potential outcomes of such litigation, including but not limited to injunctions against devices that incorporate our products and/or intellectual property, or rulings on certain patent law or patent licensing issues that create new legal precedent, could impact our business, particularly if such action impacts one of our larger customers.

[0001728949-18-000075:mdna:181]
Although we have more than 300 licensees, our QTL segment derives a significant portion of its licensing revenues from a limited number of licensees. In the event that one or more of our significant licensees fail to meet their reporting and/or payment obligations, or we are unable to renew or modify one or more of such license agreements under similar terms, our revenues, results of operations and cash flows would be adversely impacted. Moreover, the future growth and success of our core licensing business will depend in part on the ability of our licensees to develop, introduce and deliver high-volume products that achieve and sustain customer acceptance. We have no control over the product development, sales efforts or pricing of products by our licensees, and our licensees might not be successful. Reductions in the average selling prices of wireless devices sold by our licensees, without a sufficient increase in the volumes of such devices sold, would generally have an adverse effect on our licensing revenues. Such adverse impact may be muted by the per unit running royalty caps that apply to certain categories of complete wireless devices, namely smartphones, tablets and laptops.

[0001728949-18-000075:mdna:182]
[same as prior period, unchanged from 0001728949-18-000039:mdna:177]

[0001728949-18-000075:mdna:183]
We derive a significant portion of our revenues from the premium-tier device segment, and we expect this trend to continue in the foreseeable future. We have experienced, and expect to continue to experience, slowing growth in the

[0001728949-18-000075:mdna:184]
premium-tier device segment due to, among other factors, lengthening replacement cycles in developed regions, where premium-tier smartphones are common; increasing consumer demand in emerging regions, particularly China and India, where premium-tier smartphones are less common and replacement cycles are on average longer than in developed regions; lengthening replacement cycles in emerging regions; and/or a maturing premium-tier smartphone industry in which demand is increasingly driven by new product launches and/or innovation cycles.

[0001728949-18-000075:mdna:185]
[same as prior period, unchanged from 0001728949-18-000039:mdna:179]

[0001728949-18-000075:mdna:186]
[same as prior period, unchanged from 0001728949-18-000039:mdna:180]

[0001728949-18-000075:mdna:187]
[same as prior period, unchanged from 0001728949-18-000039:mdna:181]

[0001728949-18-000075:mdna:188]
From time to time, companies initiate various strategies to attempt to renegotiate, mitigate and/or eliminate their need to pay royalties to us for the use of our intellectual property. These strategies have included: (i) litigation, often alleging infringement of patents held by such companies, patent misuse, patent exhaustion, patent invalidity and/or unenforceability of our patents and/or licenses, that we do not license our patents on fair, reasonable and nondiscriminatory (FRAND) terms, or some form of unfair competition or competition law violation; (ii) taking positions contrary to our understanding of their contracts with us; (iii) appeals to governmental authorities; (iv) collective action, including working with wireless operators, standards bodies, other like-minded companies and other organizations, on both formal and informal bases, to adopt intellectual property policies and practices that could have the effect of limiting returns on intellectual property innovations; (v) lobbying governmental regulators and elected officials for the purpose of seeking the reduction of royalty rates or the base on which royalties are calculated, of seeking to impose some form of compulsory licensing and/or of weakening a patent holder’s ability to enforce its rights or obtain a fair return for such rights; and (vi) licensees using various strategies to attempt to shift their royalty obligation to their suppliers that results in lowering the wholesale (i.e., licensee’s) selling price on which the royalty is calculated. In addition, certain licensees have disputed, underreported, underpaid, not reported and/or not paid royalties owed to us under their license agreements or reported to us in a manner that is not in compliance with their contractual obligations, and certain companies have yet to enter into or delayed entering into or renewing license agreements with us for their use of our intellectual property, and licensees and/or companies may continue to do so in the future. The fact that one or more licensees dispute, underreport, underpay, do not report and/or do not pay royalties owed to us may encourage other licensees to take similar actions and may encourage other licensees or unlicensed companies to delay entering into, or not enter into, new license agreements. Further, to the extent such licensees and/or companies increase their device share, the negative impact of their underreporting, underpayment, non-payment and/or non-reporting on our business, revenues, results of operations, financial condition and/or cash flows will be exacerbated.

[0001728949-18-000075:mdna:189]
We are currently subject to various litigation and governmental investigations and/or proceedings, some of which have arisen and may continue to arise out of the strategies described above. Certain legal matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, revenues, results of operations, financial condition and/or cash flows. Depending on the type of matter, various remedies that could result from an unfavorable resolution include, among others, injunctions, monetary damages or fines or other orders to pay money and/or the issuance of orders to cease certain conduct and/or modify our business practices. In addition, decisions or orders arising out of governmental investigations or proceedings could require us to renegotiate, or could encourage or embolden our licensees to demand to renegotiate, their license agreements with us (which could be on terms that are less favorable to us than existing terms), and such licensees may underreport, underpay, not report or not pay royalties owed to us pending the conclusion of such negotiations. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. See also the Risk Factor entitled “Changes in our patent licensing practices, whether due to governmental investigations, private legal proceedings challenging those practices or otherwise, could adversely impact our business and results of operations.”

[0001728949-18-000075:mdna:190]
[same as prior period, unchanged from 0001728949-18-000039:mdna:205]

[0001728949-18-000075:mdna:191]
[same as prior period, unchanged from 0001728949-18-000039:mdna:186]

[0001728949-18-000075:mdna:192]
[same as prior period, unchanged from 0001728949-18-000039:mdna:187]

[0001728949-18-000075:mdna:193]
Some SDOs, courts and governmental agencies have adopted and may in the future adopt some or all of these interpretations or proposals in a manner adverse to our interests, including in litigation to which we may not be a party.

[0001728949-18-000075:mdna:194]
[same as prior period, unchanged from 0001728949-18-000039:mdna:189]

[0001728949-18-000075:mdna:195]
[same as prior period, unchanged from 0001728949-18-000039:mdna:190]

[0001728949-18-000075:mdna:196]
We are currently subject to various governmental investigations and/or proceedings, particularly with respect to our licensing business, and certain such matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” Key allegations in those matters include, among others, that we do not license our cellular standard-essential patents separately from our other patents, that we violate FRAND licensing commitments by refusing to grant licenses to chipset makers, that our royalty rates are too high and/or that the base on which our royalties are calculated should be something less than the wholesale (i.e., licensee’s) selling price of the applicable device (minus certain permitted deductions). The unfavorable resolution of one or more of these matters could have a material adverse effect on our business, results of operations, financial condition and/or cash flows. Depending on the type of matter, various remedies that could result from an unfavorable resolution include, among others, injunctions, monetary damages or fines or other orders to pay money, and/or the issuance of orders to cease certain conduct and/or modify our business practices. In addition, decisions or orders arising out of such governmental investigations or proceedings could require us to renegotiate, or could encourage or embolden our licensees to demand to renegotiate, their license agreements with us (which could be on terms that are less favorable to us than existing terms), and such licensees may underreport, underpay, not report or not pay royalties owed to us pending the conclusion of such negotiations. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. See also the Risk Factor entitled “Changes in our patent licensing practices, whether due to governmental investigations, private legal proceedings challenging those practices or otherwise, could adversely impact our business and results of operations.”

[0001728949-18-000075:mdna:197]
Changes in our patent licensing practices, whether due to governmental investigations, private legal proceedings challenging those practices or otherwise, could adversely impact our business and results of operations.

[0001728949-18-000075:mdna:198]
We are currently subject to various governmental investigations and private legal proceedings challenging our patent licensing practices as described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” Key allegations in those matters include, among others, that we do

[0001728949-18-000075:mdna:199]
not license our cellular standard-essential patents separately from our other patents, that we violate FRAND licensing commitments by refusing to grant licenses to chipset makers, that our royalty rates are too high and/or that the base on which our royalties are calculated should be something less than the wholesale (i.e., licensee’s) selling price of the applicable device (minus certain permitted deductions). We believe that the ultimate intent of these investigations and legal proceedings is to reduce the amount of royalties that licensees are required to pay to us for their use of our intellectual property.

[0001728949-18-000075:mdna:200]
We have historically licensed our cellular standard-essential patents together with our other patents that may be useful to licensed products because licensees typically have desired to obtain the commercial benefits of receiving such broad patent rights from us. However, we also have licensed only our cellular standard-essential patents to certain licensees who have requested such licenses. In addition, in connection with our resolution with the China National Development and Reform Commission (NDRC), our standard practice in China since 2015 is to offer licenses to our 3G and 4G standard-essential Chinese patents for devices sold for use in China separately from our other patents. We offer licenses to only our cellular standard-essential patents (including 3G, 4G and 5G) for both single mode and multi-mode devices. A small number of our licensees have entered into standard-essential patent only agreements on a worldwide basis, and we expect more of our licensees may do so in the future. Our royalty rates for licenses to only our cellular standard-essential patents are lower than our royalty rates for licenses to substantially all of our patent portfolio. If more licensees choose a license to only our cellular standard-essential patents instead of a portfolio license than has historically been the case, our licensing revenues and earnings would be negatively impacted unless we were able to license our other patents at rates that offset all or a portion of any difference between the royalties previously received for licenses of substantially all of our patent portfolio as compared to licenses of only our cellular standard-essential patents and/or there was a sufficient increase in the overall volume of sales of devices upon which royalties are paid.

[0001728949-18-000075:mdna:201]
If we were required to grant patent licenses to chipset manufacturers (i.e., to implement a more complex, tiered licensing structure in which we license certain portions of our patent portfolio to chipset manufacturers and other portions to device manufacturers), we would incur additional transaction costs, which may be significant, and we could incur delays in recognizing revenues until license negotiations were completed. In addition, our licensing revenues and earnings would be negatively impacted if we were not able to obtain, in the aggregate, equivalent revenues under such a multi-level licensing structure.

[0001728949-18-000075:mdna:202]
If we were required to reduce the royalty rates we charge under our patent license agreements, our revenues, earnings and/or cash flows would be negatively impacted absent a sufficient increase in the volume of sales of devices upon which royalties are paid. Similarly, if we were required to reduce the base on which our royalties are calculated, our revenues, results of operations and/or cash flows would be negatively impacted unless there was a sufficient increase in the volume of sales of devices upon which royalties are paid and/or we were able to increase our royalty rates to offset the decrease in revenues resulting from such lower royalty base (assuming the absolute royalty dollars were below any relevant royalty caps).

[0001728949-18-000075:mdna:203]
To the extent that we were required to implement any of these new licensing practices by modifying or renegotiating our existing license agreements, we would incur additional transaction costs, which may be significant, and we could incur delays in recognizing revenues until license negotiations were completed. The impact of any such changes to our licensing practices could vary widely and by jurisdiction, depending on the specific outcomes and the geographic scope of such outcomes. In addition, if we were required to make modifications to our licensing practices in one jurisdiction, licensees and/or governmental agencies in other jurisdictions may attempt to obtain similar outcomes for themselves and/or for such other jurisdictions, as applicable.

[0001728949-18-000075:mdna:204]
[same as prior period, unchanged from 0001728949-18-000039:mdna:201]

[0001728949-18-000075:mdna:205]
We rely primarily on patent, copyright, trademark and trade secret laws, as well as nondisclosure and confidentiality agreements, international treaties and other methods, to protect our proprietary information, technologies and processes, including our patent portfolio. Policing unauthorized use of our products, technologies and proprietary information is difficult and time consuming. The steps we have taken have not always prevented, and we cannot be certain the steps we will take in the future will prevent, the misappropriation or unauthorized use of our proprietary information and technologies, particularly in foreign countries where the laws may not protect our proprietary intellectual property rights as fully or as readily as United States laws or where the enforcement of such laws may be lacking or ineffective. Some industry participants who have a vested interest in devaluing patents in general, or standard-essential patents in particular, have mounted attacks on certain patent systems, increasing the likelihood of changes to established patent laws. In the United States, there is continued

[0001728949-18-000075:mdna:206]
discussion regarding potential patent law changes and current and potential future litigation regarding patents, the outcomes of which could be detrimental to our licensing business. The laws in certain foreign countries in which our products are or may be manufactured or sold, including certain countries in Asia, may not protect our intellectual property rights to the same extent as the laws in the United States. We expect that the European Union will adopt a unitary patent system in the next few years that may broadly impact that region’s patent regime. We cannot predict with certainty the long-term effects of any potential changes. In addition, we cannot be certain that the laws and policies of any country or the practices of any standards bodies, foreign or domestic, with respect to intellectual property enforcement or licensing or the adoption of standards, will not be changed in the future in a way detrimental to our licensing program or to the sale or use of our products or technologies.

[0001728949-18-000075:mdna:207]
[same as prior period, unchanged from 0001728949-18-000039:mdna:203]

[0001728949-18-000075:mdna:208]
We have entered into litigation and/or arbitration in the past and may need to further litigate and/or arbitrate in the future to enforce our contract and/or intellectual property rights, protect our trade secrets or determine the validity and scope of proprietary rights of others. We are currently engaged in litigation matters related to protecting or enforcing our contract and/or intellectual property rights, and certain such matters are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.” As a result of any such litigation and/or arbitration, we could lose our ability to enforce one or more patents, portions of our license agreements could be determined to be invalid or unenforceable (which may in turn result in other licensees either not complying with their existing license agreements and/or initiating litigation) and/or we could incur substantial costs. Any action we take to enforce our contract or intellectual property rights could be costly and could absorb significant management time and attention, which, in turn, could negatively impact our results of operations and/or cash flows. Further, even a positive resolution to our enforcement efforts may take time to conclude, which may reduce our revenues and cash resources available for other purposes, such as research and development, in the periods prior to conclusion. See also the Risk Factor entitled “Changes in our patent licensing practices, whether due to governmental investigations, private legal proceedings challenging those practices or otherwise, could adversely impact our business and results of operations.”

[0001728949-18-000075:mdna:209]
[same as prior period, unchanged from 0001728949-18-000039:mdna:207]

[0001728949-18-000075:mdna:210]
Our industry is subject to rapid technological change, evolving industry standards and frequent new product introductions, and we must make substantial research, development and other investments, such as acquisitions, in new products, services and technologies to compete successfully. Technological innovations generally require significant research and development efforts before they are commercially viable. While we continue to invest significant resources toward

[0001728949-18-000075:mdna:211]
[same as prior period, unchanged from 0001728949-18-000039:mdna:237]

[0001728949-18-000075:mdna:212]
advancements primarily in support of 4G- and 5G-based technologies, we also innovate across a broad spectrum of opportunities to deploy new and expanded products and enter into adjacent industry segments by leveraging our existing technical and business expertise and/or through acquisitions.

[0001728949-18-000075:mdna:213]
In particular, our future growth significantly depends on new and expanded product areas, such as RFFE, and adjacent industry segments, such as automotive, IoT (including the connected home, smart cities, wearables, voice and music and robotics), networking, computing and machine learning, among others; our ability to develop leading and cost-effective technologies, products and services for new and expanded product areas and adjacent industry segments; and third parties incorporating our technology, products and services into devices used in these product areas and industry segments. Accordingly, we intend to continue to make substantial investments in these new and expanded product areas and adjacent industry segments, and in developing new products, services and technologies for these product areas and industry segments.

[0001728949-18-000075:mdna:214]
[same as prior period, unchanged from 0001728949-18-000039:mdna:210]

[0001728949-18-000075:mdna:215]
[same as prior period, unchanged from 0001728949-18-000039:mdna:211]

[0001728949-18-000075:mdna:216]
[same as prior period, unchanged from 0001728949-18-000039:mdna:212]

[0001728949-18-000075:mdna:217]
[same as prior period, unchanged from 0001728949-18-000039:mdna:213]

[0001728949-18-000075:mdna:218]
We are subject to many environmental, health and safety laws and regulations in each jurisdiction in which we operate our manufacturing facilities, which govern, among other things, emissions of pollutants into the air, wastewater discharges, the use and handling of hazardous substances, waste disposal, the investigation and remediation of soil and ground water contamination and the health and safety of our employees. We are also required to obtain and maintain environmental permits from governmental authorities for certain of our operations. We cannot make assurances that we will be at all times in compliance with such laws, regulations and permits. Certain environmental laws impose strict, and in certain circumstances, joint and several, liability on current or previous owners or operators of real property for the cost of investigation, removal or remediation of hazardous substances. Certain of these laws also assess liability on persons who arrange for hazardous substances to be sent to disposal or treatment facilities when such facilities are found to be contaminated. In addition, we could also be held liable for consequences arising out of human exposure to hazardous substances or other environmental damage.

[0001728949-18-000075:mdna:219]
[same as prior period, unchanged from 0001728949-18-000039:mdna:217]

[0001728949-18-000075:mdna:220]
Our manufacturing operations depend on securing raw materials and other supplies in adequate quality and quantity in a timely manner from multiple suppliers, and in some cases, we rely on a limited number of suppliers, particularly in Asia. Accordingly, there may be cases where supplies of raw materials and other products are interrupted by disaster, accident or some other event at a supplier, supply is suspended due to quality or other issues, or there is a shortage of supply due to a

[0001728949-18-000075:mdna:221]
rapid increase in demand, which could impact production and prevent us from supplying products to our customers. If the supply-demand balance is disrupted, it may considerably increase costs of manufacturing due to increased prices we pay for raw materials or fuel. From time to time, suppliers may extend lead times, limit the amounts supplied to us or increase prices due to capacity constraints or other factors. Further, it may be difficult or impossible to substitute one piece of equipment for another or replace one type of material with another. A failure by our suppliers to deliver our requirements could result in disruptions to our manufacturing operations.

[0001728949-18-000075:mdna:222]
[same as prior period, unchanged from 0001728949-18-000039:mdna:219]

[0001728949-18-000075:mdna:223]
[same as prior period, unchanged from 0001728949-18-000039:mdna:220]

[0001728949-18-000075:mdna:224]
[same as prior period, unchanged from 0001728949-18-000039:mdna:221]

[0001728949-18-000075:mdna:225]
In addition, new connectivity and other services are emerging that rely on devices that may or may not be used on traditional cellular networks, such as devices used in the IoT and automotive industry segments. We also seek to diversify and broaden our technology licensing programs to new industry segments in which we can utilize our technology leadership. Standards, even de facto standards, that develop as these technologies mature, in particular those that do not include a base level of interoperability, may impact our ability to obtain royalties at all or that are equivalent to those that we receive for products used in cellular communications. Although we believe that our patented technologies are essential and useful to the commercialization of such services, any royalties we receive may be lower than those we receive from our current licensing program.

[0001728949-18-000075:mdna:226]
Further, the licenses granted to and from us under a number of our license agreements include only patents that are either filed or issued prior to a certain date. As a result, there are agreements with some licensees where later patents are not licensed by or to us. Additionally, many of our license agreements (including essentially all of our recent agreements in China) are effective for a specified term. In order to license or to obtain a license to such later patents after the expiration of a specified term, or to receive royalties after the specified time period, we will need to extend or modify such license agreements or enter into new license agreements with such licensees. Accordingly, to the extent not renewed on their terms or by election for an additional (generally multi-year) period, if applicable, we will need to extend or modify such license agreements or enter into new license agreements with such licensees more frequently than we have done historically. We might not be able to renew those license agreements, or enter into new license agreements, in the future without affecting the material terms and conditions of our license agreements with such licensees, and such modifications or new agreements may negatively impact our revenues. If there is a delay in renewing a license agreement prior to its expiration, there would be a delay in our ability to recognize revenues related to that licensee’s product sales. Further, if we are unable to reach agreement on such modifications or new agreements, it could result in patent infringement litigation with such companies.

[0001728949-18-000075:mdna:227]
[same as prior period, unchanged from 0001728949-18-000039:mdna:226]

[0001728949-18-000075:mdna:228]
Our QCT segment primarily utilizes a fabless production model, which means that we do not own or operate foundries for the production of silicon wafers from which our integrated circuits are made. Other than the manufacturing facilities we now operate through our RF360 Holdings joint venture, we rely on independent third-party suppliers to perform the manufacturing and assembly, and most of the testing, of our integrated circuits. Our suppliers are also responsible for the procurement of most of the raw materials used in the production of our integrated circuits. We employ both turnkey and two-stage manufacturing models to purchase our integrated circuits. Under the turnkey model, our foundry suppliers are responsible for delivering fully assembled and tested integrated circuits. Under the two-stage manufacturing model, we purchase die in singular or wafer form from semiconductor manufacturing foundries and contract with separate third-party suppliers for manufacturing services such as wafer bump, probe, assembly and the majority of our final test requirements.

[0001728949-18-000075:mdna:229]
54

[0001728949-18-000075:mdna:230]
The semiconductor manufacturing foundries that supply products to our QCT segment are primarily located in Asia, as are our primary warehouses where we store finished goods for fulfillment of customer orders. The following could have an adverse effect on our ability to meet customer demands and/or negatively impact our revenues, business operations, profitability and/or cash flows:

[0001728949-18-000075:mdna:231]
[same as prior period, unchanged from 0001728949-18-000039:mdna:228]

[0001728949-18-000075:mdna:232]
[same as prior period, unchanged from 0001728949-18-000039:mdna:229]

[0001728949-18-000075:mdna:233]
[same as prior period, unchanged from 0001728949-18-000039:mdna:230]

[0001728949-18-000075:mdna:234]
[same as prior period, unchanged from 0001728949-18-000039:mdna:231]

[0001728949-18-000075:mdna:235]
[same as prior period, unchanged from 0001728949-18-000039:mdna:232]

[0001728949-18-000075:mdna:236]
[same as prior period, unchanged from 0001728949-18-000039:mdna:233]

[0001728949-18-000075:mdna:237]
[same as prior period, unchanged from 0001728949-18-000039:mdna:234]

[0001728949-18-000075:mdna:238]
[same as prior period, unchanged from 0001728949-18-000039:mdna:235]

[0001728949-18-000075:mdna:239]
Although we have long-term contracts with our suppliers, many of these contracts do not provide for long-term capacity commitments. To the extent we do not have firm commitments from our suppliers over a specific time period or for any specific quantity, our suppliers may allocate, and in the past, have allocated, capacity to the production and testing of products for their other customers while reducing or limiting capacity to manufacture or test our products. Accordingly, capacity for our products may not be available when we need it or at reasonable prices. To the extent we do obtain long-term capacity commitments, we may incur additional costs related to those commitments and/or make non-refundable payments for capacity commitments that are not used.

[0001728949-18-000075:mdna:240]
[same as prior period, unchanged from 0001728949-18-000039:mdna:239]

[0001728949-18-000075:mdna:241]
[same as prior period, unchanged from 0001728949-18-000039:mdna:240]

[0001728949-18-000075:mdna:242]
55

[0001728949-18-000075:mdna:243]
[same as prior period, unchanged from 0001728949-18-000039:mdna:241]

[0001728949-18-000075:mdna:244]
From time to time, companies have asserted, and may again assert, patent, copyright and other intellectual property rights against our products or products using our technologies or other technologies used in our industry. These claims have resulted and may again result in our involvement in litigation. We may not prevail in such litigation given, among other factors, the complex technical issues and inherent uncertainties in intellectual property litigation. If any of our products or services were found to infringe another company’s intellectual property rights, we could be subject to an injunction or be required to redesign our products or services, which could be costly, or to license such rights and/or pay damages or other compensation to such other company. If we are unable to redesign our products or services, license such intellectual property rights used in our products or services or otherwise distribute our products (e.g., through a licensed supplier), we could be prohibited from making and selling such products or providing such services. In any potential dispute involving other companies’ patents or other intellectual property, our chipset foundries, semiconductor assembly and test providers and customers could also become the targets of litigation. We are contingently liable under certain product sales, services, license and other agreements to indemnify certain customers, chipset foundries and semiconductor assembly and test service providers against certain types of liability and/or damages arising from qualifying claims of patent infringement by products or services sold or provided by us, or by intellectual property provided by us to our chipset foundries and semiconductor assembly and test service providers. Reimbursements under indemnification arrangements could have an adverse effect on our results of operations and/or cash flows. Furthermore, any such litigation could severely disrupt the supply of our products and the businesses of our chipset customers and their customers, which in turn could hurt our relationships with them and could result in a decline in our chipset sales and/or reductions in our licensees’ sales, causing a corresponding decline in our chipset and/or licensing revenues. Any claims, regardless of their merit, could be time consuming to address, result in costly litigation, divert the efforts of our technical and management personnel or cause product release or shipment delays, any of which could have an adverse effect on our results of operations and cash flows.

[0001728949-18-000075:mdna:245]
We expect that we may continue to be involved in litigation and may have to appear in front of administrative bodies (such as the United States International Trade Commission) to defend against patent assertions against our products by companies, some of whom are attempting to gain competitive advantage or leverage in licensing negotiations. We may not be successful in such proceedings, and if we are not, the range of possible outcomes is very broad and may include, for example, monetary damages or fines or other orders to pay money, royalty payments, injunctions on the sale of certain of our integrated circuit products (and/or on the sale of our customers’ devices using such products) and/or the issuance of orders to cease certain conduct and/or modify our business practices. Further, a governmental body in a particular country or region may assert, and may be successful in imposing, remedies with effects that extend beyond the borders of that country or region. In addition, a negative outcome in any such proceeding could severely disrupt the business of our chipset customers and their wireless operator customers, which in turn could harm our relationships with them and could result in a decline in our worldwide chipset sales and/or a reduction in our licensees’ sales to wireless operators, causing corresponding declines in our chipset and/or licensing revenues.

[0001728949-18-000075:mdna:246]
Certain legal matters, including certain claims by other companies that we infringe their intellectual property, are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.”

[0001728949-18-000075:mdna:247]
We may engage in strategic acquisitions, transactions or make investments, or be unable to consummate planned strategic acquisitions, which could adversely affect our results of operations or fail to enhance stockholder value.

[0001728949-18-000075:mdna:248]
We engage in strategic acquisitions and other transactions, including joint ventures, and make investments, which we believe are important to the future of our business, with the goal of maximizing stockholder value. We acquire businesses and other assets, including patents, technology, wireless spectrum and other intangible assets, enter into joint ventures or other strategic transactions and purchase minority equity interests in or make loans to companies that may be private and early-stage. Our strategic activities are generally focused on opening or expanding opportunities for our technologies and supporting the design and introduction of new products and services (or enhancing existing products or services) for voice and data communications and new industry segments. Recent material transactions include our RF360 Holdings joint venture with TDK Corporation and our acquisition of CSR plc. Many of our strategic activities entail a high degree of risk and require the use of domestic and/or foreign capital, and investments may not become liquid for several years after the date of the investment, if at all. Our strategic activities may not generate financial returns or result in increased adoption or continued use of our technologies, products or services. We may underestimate the costs and/or overestimate the benefits, including product, revenue, cost and other synergies and growth opportunities that we expect to realize, and we may not achieve those benefits. In some cases, we may be required to consolidate or record our share of the earnings or losses of companies in which we have acquired ownership interests. In addition, we may record impairment charges related to our strategic activities. Any losses or impairment charges that we incur related to strategic activities will have a negative impact on our

[0001728949-18-000075:mdna:249]
[same as prior period, unchanged from 0001728949-18-000039:mdna:273]

[0001728949-18-000075:mdna:250]
financial condition and results of operations, and we may continue to incur new or additional losses related to strategic assets or investments that we have not fully impaired or exited.

[0001728949-18-000075:mdna:251]
Achieving the anticipated benefits of business acquisitions, including joint ventures and other strategic investments in which we have management and operational control, depends in part upon our ability to integrate the businesses in an efficient and effective manner and achieve anticipated synergies, and we may not be successful in these efforts. Such integration is complex and time consuming and involves significant challenges, including, among others: retaining key employees; successfully integrating new employees, technology, products, processes, operations (including manufacturing operations), sales and distribution channels, business models and business systems; retaining customers and suppliers of the businesses; consolidating research and development and/or supply operations; minimizing the diversion of management’s attention from ongoing business matters; consolidating corporate and administrative infrastructures; and managing the increased scale, complexity and globalization of our business, operations and employee base. We may not derive any commercial value from associated technologies or products or from future technologies or products based on these technologies, and we may be subject to liabilities that are not covered by indemnification protection that we may obtain, and we may become subject to litigation. Additionally, we may not be successful in entering or expanding into new sales or distribution channels, business or operational models (including manufacturing), geographic regions, industry segments and/or categories of products served by or adjacent to the associated businesses or in addressing potential new opportunities that may arise out of the combination.

[0001728949-18-000075:mdna:252]
[same as prior period, unchanged from 0001728949-18-000039:mdna:248]

[0001728949-18-000075:mdna:253]
In the absence of approval from SAMR or other material developments, we expect to terminate our proposed acquisition of NXP after the End Date. In such an event, we would not realize the benefits that we anticipated from the acquisition, including, but not limited to, increased revenues; accelerated revenue diversification; significantly expanded addressable markets and opportunities; accelerated entry into new industry segments and expansion in existing industry segments; new and expanded product offerings and technologies; accelerated expansion of sales and distribution channels; cost and other synergies; and earnings accretion from the acquisition. In addition, future acquisitions may now be more difficult, complex or expensive to the extent that our reputation for our ability to consummate acquisitions has been harmed. Further, if U.S./China trade relations remain strained, our ability to consummate any transaction that would require approval from SAMR may be severely impacted.

[0001728949-18-000075:mdna:254]
[same as prior period, unchanged from 0001728949-18-000039:mdna:249]

[0001728949-18-000075:mdna:255]
In the second quarter of fiscal 2018, we announced a cost plan designed to align our cost structure to our long-term margin targets. As part of this plan, we are implementing a series of targeted reductions across our businesses to reduce annual costs by $1 billion, excluding incremental costs resulting from any future acquisition of a business. We expect these cost reductions to be fully captured in fiscal 2019.

[0001728949-18-000075:mdna:256]
[same as prior period, unchanged from 0001728949-18-000039:mdna:251]

[0001728949-18-000075:mdna:257]
[same as prior period, unchanged from 0001728949-18-000039:mdna:252]

[0001728949-18-000075:mdna:258]
Our business, products and services, and those of our customers and licensees, are subject to various laws and regulations globally, as well as government policies and the specifications of international, national and regional communications standards bodies. Compliance with existing laws, regulations, policies and standards, the adoption of new laws, regulations, policies or standards, changes in the interpretation of existing laws, regulations, policies or standards, changes in the regulation of our activities by a government or standards body and/or rulings in court, regulatory, administrative or other proceedings relating to such laws, regulations, policies or standards, including, among others, those

[0001728949-18-000075:mdna:259]
affecting licensing practices, competitive business practices, the use of our technology or products, protection of intellectual property, trade and trade protection including tariffs, foreign currency, investments or loans, spectrum availability and license issuance, adoption of standards, the provision of device subsidies by wireless operators to their customers, taxation, export control, privacy and data protection, environmental protection, health and safety, labor and employment, human rights, corporate governance, public disclosure or business conduct could have an adverse effect on our business and results of operations.

[0001728949-18-000075:mdna:260]
[same as prior period, unchanged from 0001728949-18-000039:mdna:254]

[0001728949-18-000075:mdna:261]
[same as prior period, unchanged from 0001728949-18-000039:mdna:255]

[0001728949-18-000075:mdna:262]
[same as prior period, unchanged from 0001728949-18-000039:mdna:256]

[0001728949-18-000075:mdna:263]
Regulations in the United States require that we determine whether certain materials used in our products, referred to as conflict minerals, originated in the Democratic Republic of the Congo or an adjoining country (collectively, the Covered Countries), or were from recycled or scrap sources. Other countries and/or regions are expected to impose similar requirements in the future. The verification and reporting requirements, in addition to customer demands for conflict free sourcing, impose additional costs on us and on our suppliers and may limit the sources or increase the prices of materials used in our products. Further, if we are unable to determine that the conflict minerals used in our products do not directly or indirectly finance or benefit armed groups in the Covered Countries, we may face challenges with our customers that place us at a competitive disadvantage, and our reputation may be harmed. Similarly, other laws and regulations have been adopted or proposed that require additional transparency regarding the employment practices of our suppliers, and any failure to maintain responsible sourcing practices could also adversely affect our relationships with customers and our reputation.

[0001728949-18-000075:mdna:264]
[same as prior period, unchanged from 0001728949-18-000039:mdna:258]

[0001728949-18-000075:mdna:265]
[same as prior period, unchanged from 0001728949-18-000039:mdna:259]

[0001728949-18-000075:mdna:266]
Certain of our software and our suppliers’ software may contain or may be derived from “open source” software, and we have seen, and believe we will continue to see, an increase in customers requesting that we develop products, including software associated with our integrated circuit products, that incorporate open source software elements and operate in an open source environment, which, under certain open source licenses, may offer accessibility to a portion of a product’s source code and may expose related intellectual property to adverse licensing conditions. Licensing of such software may impose certain obligations on us if we were to distribute derivative works of the open source software. For example, these obligations may require us to make source code for the derivative works available to our customers in a manner that allows them to make such source code available to their customers or license such derivative works under a particular type of license that is different than what we customarily use to license our software. Developing open source products, while adequately protecting the intellectual property rights upon which our licensing business depends, may prove burdensome and time-consuming under certain circumstances, thereby placing us at a competitive disadvantage, and we may not adequately protect our intellectual property rights. Also, our use and our customers’ use of open source software may subject our products and our customers’ products to governmental scrutiny and delays in product certification, which could cause customers to view our products as less desirable than our competitors’ products. While we believe we have taken appropriate steps and employ

[0001728949-18-000075:mdna:267]
adequate controls to protect our intellectual property rights, our use of open source software presents risks that could have an adverse effect on these rights and on our business.

[0001728949-18-000075:mdna:268]
[same as prior period, unchanged from 0001728949-18-000039:mdna:262]

[0001728949-18-000075:mdna:269]
[same as prior period, unchanged from 0001728949-18-000039:mdna:263]

[0001728949-18-000075:mdna:270]
In the past, securities class action litigation has been brought against a company following periods of volatility in the market price of its securities. Due to changes in our stock price, we are and may in the future be the target of securities litigation. Securities litigation could result in substantial uninsured costs and divert management’s attention and our resources. Certain legal matters, including certain securities litigation brought against us, are described more fully in this Quarterly Report in “Notes to Condensed Consolidated Financial Statements, Note 6. Commitments and Contingencies.”

[0001728949-18-000075:mdna:271]
[same as prior period, unchanged from 0001728949-18-000039:mdna:265]

[0001728949-18-000075:mdna:272]
There are risks associated with our indebtedness and our significant proposed stock repurchase program.

[0001728949-18-000075:mdna:273]
Our outstanding indebtedness and any additional indebtedness we incur may have negative consequences on our business, including, among others:

[0001728949-18-000075:mdna:274]
[same as prior period, unchanged from 0001728949-18-000039:mdna:268]

[0001728949-18-000075:mdna:275]
[same as prior period, unchanged from 0001728949-18-000039:mdna:269]

[0001728949-18-000075:mdna:276]
[same as prior period, unchanged from 0001728949-18-000039:mdna:270]

[0001728949-18-000075:mdna:277]
[same as prior period, unchanged from 0001728949-18-000039:mdna:271]

[0001728949-18-000075:mdna:278]
Our ability to make payments of principal and interest on our indebtedness depends upon our future performance, which is subject to general economic conditions, industry cycles and financial, business and other factors, including factors which negatively impact our cash flows, such as licensees withholding some or all of the royalty payments they owe to us or paying fines in connection with regulatory investigations, many of which are beyond our control. If we are unable to generate sufficient cash flow from operations in the future to service our debt, we may be required to, among other things: refinance or restructure all or a portion of our indebtedness; reduce or delay planned capital or operating expenditures; or sell selected assets. Such measures might not be sufficient to enable us to service our debt. In addition, any such refinancing, restructuring or sale of assets might not be available on economically favorable terms or at all, and if prevailing interest rates at the time of any such refinancing and/or restructuring are higher than our current rates, interest expense related to such refinancing and/or restructuring would increase. If there are adverse changes in the ratings assigned to our debt securities by credit rating agencies, our borrowing costs, our ability to access debt in the future and/or the terms of such debt could be adversely affected.

[0001728949-18-000075:mdna:279]
In the event of the termination of our proposed acquisition of NXP, we intend to implement a stock repurchase program to repurchase up to $30 billion of our outstanding common stock. This stock repurchase program will significantly reduce the amount of cash that we have available to fund our operations (including research and development), working capital, capital expenditures, acquisitions, investments, dividends and other corporate purposes; and limit our flexibility in planning for or

[0001728949-18-000075:mdna:280]
reacting to, and increase our vulnerability to, adverse economic, market, industry and competitive conditions and developments, and other changes in our business and our industry. In addition, this significant decrease in our cash reserves will exacerbate the risks described above associated with our indebtedness.

[0001728949-18-000075:mdna:281]
Our business and operations could suffer in the event of security breaches of our information technology systems, or other misappropriation of our intellectual property or proprietary or confidential information.

[0001728949-18-000075:mdna:282]
Third parties regularly attempt to gain unauthorized access to our information technology systems, and most of such attempts are increasingly more sophisticated. These attempts, which might be related to industrial or other espionage, criminal hackers or state-sponsored intrusions, include trying to covertly introduce malware to our computers and networks, including those in our manufacturing operations, and impersonating authorized users, among others. Such attempts could result in the misappropriation, theft, misuse, disclosure or loss or destruction of the intellectual property, or the proprietary, confidential or personal information, of us or our employees, customers, licensees, suppliers or other third parties, as well as damage to or disruptions in our information technology systems. These threats are constantly evolving, thereby increasing the difficulty of successfully defending against them or implementing adequate preventative measures.

[0001728949-18-000075:mdna:283]
We seek to detect and investigate all security incidents and to prevent their recurrence, but attempts to gain unauthorized access to our information technology systems may be successful, and in some cases, we might be unaware of an incident or its magnitude and effects. The misappropriation, theft, misuse, disclosure or loss or destruction of the intellectual property, or the proprietary, confidential or personal information, of us or our employees, customers, licensees, suppliers or other third parties could harm our competitive position, reduce the value of our investment in research and development and other strategic initiatives, cause us to lose business, damage our reputation, subject us to legal or regulatory proceedings, cause us to incur other loss or liability and/or otherwise adversely affect our business. We expect to continue to devote significant resources to the security of our information technology systems.

[0001728949-18-000075:mdna:284]
In addition, employees and former employees, in particular former employees who become employees of our competitors, customers or licensees, may misappropriate, use, publish or provide to our competitors, customers or licensees our intellectual property and/or proprietary or confidential business information. Similarly, we provide access to certain of our intellectual property and/or proprietary and/or confidential business information to our direct and indirect customers and licensees, who may wrongfully use such intellectual property and/or information and/or wrongfully disclose such intellectual property and/or information to third parties, including our competitors.

[0001728949-18-000075:mdna:285]
[same as prior period, unchanged from 0001728949-18-000039:mdna:277]

[0001728949-18-000075:mdna:286]
We are subject to income taxes in the United States and numerous foreign jurisdictions, including Singapore where our QCT segment’s non-United States headquarters is located. Significant judgment is required in determining our provision for income taxes. We regularly are subject to examination of our tax returns and reports by taxing authorities in the United States federal jurisdiction and various state and foreign jurisdictions, most notably in countries where we earn a routine return and the tax authorities believe substantial value-add activities are performed. Our current examinations are at various stages with respect to assessments, claims, deficiencies and refunds. We continually assess the likelihood and amount of potential adjustments and adjust the income tax provision, income taxes payable and deferred taxes in the period in which the facts give rise to a revision become known. Although we believe that our tax estimates are reasonable at June 24, 2018, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in our historical income tax provisions and accruals. In such case, our income tax provision, results of operations and/or cash flows in the period or periods in which that determination is made could be negatively affected.

[0001728949-18-000075:mdna:287]
On December 22, 2017, tax reform legislation known as the Tax Cuts and Jobs Act (the Tax Legislation) was enacted in the United States. Given the amount and complexity of the changes in tax law resulting from the Tax Legislation, we have not finalized the accounting for the income tax effects of the Tax Legislation. This includes the provisional amounts recorded in the nine months ended June 24, 2018 related to the repatriation tax on deemed repatriated earnings and profits of U.S.-owned foreign subsidiaries (Toll Charge) and the remeasurement of deferred taxes. Further, we are in the process of analyzing the effects of new taxes due on certain foreign income, such as GILTI (global intangible low-taxed income), BEAT (base-erosion anti-abuse tax), FDII (foreign-derived intangible income) and limitations on interest expense deductions (if certain conditions apply) that are effective starting in fiscal 2019, and other provisions of the Tax Legislation. The impact of the Tax Legislation may differ from this estimate, possibly materially, during the one-year measurement period due to, among other things, further refinement of our calculations, changes in interpretations and assumptions we have made, guidance that may be issued and actions we may take as a result of the Tax Legislation.

[0001728949-18-000075:mdna:288]
We have tax incentives in Singapore provided that we meet specified employment and other criteria, and as a result of the expiration of these incentives, our Singapore tax rate is expected to increase in fiscal 2022 and again in fiscal 2027. If we

[0001728949-18-000075:mdna:289]
do not meet the criteria required to retain such incentives, our Singapore tax rate could increase prior to fiscal 2027, and our results of operations and cash flows could be adversely affected.

[0001728949-18-000075:mdna:290]
Tax rules may change in a manner that adversely affects our future reported results of operations or the way we conduct our business. Further changes in the tax laws of foreign jurisdictions could arise as a result of the base erosion and profit shifting (BEPS) project that was undertaken by the Organization for Economic Co-operation and Development (OECD). The OECD, which represents a coalition of member countries, recommended changes to numerous long-standing tax principles related to transfer pricing. These changes, if adopted by countries, could increase tax uncertainty and may adversely affect our provision for income taxes, results of operations and/or cash flow. We have not yet determined what changes, if any, may be needed to our operations or structure to address BEPS. If our effective tax rates were to increase, particularly in the United States or Singapore, our results of operations, cash flows and/or financial condition could be adversely affected.

[0001728949-18-000075:mdna:291]
[same as prior period, unchanged from 0001728949-18-000039:mdna:284]

[0001728949-18-000075:mdna:292]
[same as prior period, unchanged from 0001728949-18-000039:mdna:285]

[0001728949-18-000075:mdna:293]
[same as prior period, unchanged from 0001728949-18-000039:mdna:286]

[0001728949-18-000075:mdna:294]
[same as prior period, unchanged from 0001728949-18-000039:mdna:287]

[0001728949-18-000075:mdna:295]
[same as prior period, unchanged from 0001728949-18-000039:mdna:288]

[0001728949-18-000075:mdna:296]
[same as prior period, unchanged from 0001728949-18-000039:mdna:289]

[0001728949-18-000075:mdna:297]
[same as prior period, unchanged from 0001728949-18-000039:mdna:290]

[0001728949-18-000075:mdna:298]
| • | Certain of our revenues that are derived from products that are sold in foreign currencies could decrease, resulting in lower revenue, cash flows and margins; |

[0001728949-18-000075:mdna:299]
| • | Certain of our revenues, such as royalties, that are derived from licensee or customer sales denominated in foreign currencies could decrease, resulting in lower revenues and cash flows; |

[0001728949-18-000075:mdna:300]
[same as prior period, unchanged from 0001728949-18-000039:mdna:292]

[0001728949-18-000075:mdna:301]
| • | Certain of our costs that are denominated in foreign currencies could increase, resulting in higher than expected costs and cash outflows; and/or |

[0001728949-18-000075:mdna:302]
| • | Foreign exchange hedging transactions that we engage in to reduce the impact of currency fluctuations may require the payment of structuring fees, limit the U.S. dollar value of royalties from licensees’ sales that are denominated in |

[0001728949-18-000075:mdna:303]
foreign currencies, cause earnings volatility if the hedges do not qualify for hedge accounting and expose us to counterparty risk if the counterparty fails to perform.

[0001728949-18-000075:mdna:304]
[same as prior period, unchanged from 0001728949-18-000039:mdna:295]

[0001728949-18-000075:mdna:305]
The use of devices containing our products to interact with untrusted systems or otherwise access untrusted content creates a risk of exposing the system hardware and software in those devices to malicious attacks. While we continue to focus on this issue and are taking measures to safeguard our products from cybersecurity threats, device capabilities continue to evolve, enabling more elaborate functionality and use cases, and increasing the risk of security failures. Further, our products are inherently complex and may contain defects or errors that are detected only when the products are in use. Because our products and services are responsible for critical functions in our customers’ products and/or networks, security failures, defects or errors in our products or services could have an adverse impact on us, on our customers and/or on the end users of our customers’ products. Such adverse impact could include shipment delays; product liability claims or recalls; write-offs of our inventories, property, plant and equipment and/or intangible assets; unfavorable purchase commitments; a shift of business to our competitors; a decrease in demand for connected devices and wireless services; damage to our reputation and our customer relationships; regulatory actions; and other financial liability or harm to our business. Further, security failures, defects or errors in the products of our customers or licensees could have an adverse impact on our results of operations and/or cash flows due to a delay or decrease in demand for our products or services generally, and our premium-tier products in particular, among other factors. Development of products and features in new domains of technology and the migration to integrated circuit technologies with smaller geometric feature sizes are complex and add risk to manufacturing yields and reliability. Further, manufacturing, testing, marketing and use of our products and those of our customers and licensees entail the risk of product liability.
