# QCOM 8-K — 0001728949-18-000074 filed 2018-07-25

## item codes, every 8-K on or before 2018-07-25

- 2018-07-25 0001728949-18-000074 — 2.02, 9.01
- 2018-07-17 0001728949-18-000063 — 5.03, 9.01
- 2018-06-28 0001728949-18-000060 — 5.02
- 2018-06-13 0000950157-18-000615 — 1.01, 2.03, 9.01
- 2018-06-05 0001193125-18-184011 — 1.01, 2.04, 8.01, 9.01
- 2018-05-29 0001193125-18-176081 — 8.01, 9.01
- 2018-05-25 0001728949-18-000049 — 5.02, 9.01
- 2018-05-21 0001193125-18-168810 — 8.01, 9.01
- 2018-05-21 0001193125-18-168730 — 8.01, 9.01
- 2018-04-25 0001728949-18-000038 — 2.02, 9.01
- 2018-04-24 0000950157-18-000470 — 1.01, 9.01
- 2018-04-20 0001728949-18-000029 — 5.03, 9.01
- 2018-04-19 0001104659-18-025001 — 1.01, 7.01, 9.01
- 2018-04-09 0001728949-18-000023 — 5.07 — amendment of 0001728949-18-000017
- 2018-03-29 0001728949-18-000017 — 5.07, 8.01
- 2018-03-19 0001104659-18-018402 — 9.01
- 2018-03-13 0001104659-18-016916 — 8.01, 9.01
- 2018-03-12 0001104659-18-016576 — 8.01, 9.01
- 2018-03-09 0001728949-18-000014 — 5.02
- 2018-03-09 0000950157-18-000274 — 1.01, 2.03, 9.01
- 2018-03-06 0001104659-18-015235 — 8.01
- 2018-03-06 0001104659-18-015036 — 8.01, 9.01
- 2018-03-05 0001104659-18-014823 — 8.01, 9.01
- 2018-03-02 0000950157-18-000257 — 1.01, 9.01
- 2018-02-20 0001104659-18-010546 — 1.01, 7.01, 9.01
- 2018-01-31 0001728949-18-000010 — 2.02, 9.01
- 2017-12-27 0001234452-17-000206 — 5.02
- 2017-12-22 0001104659-17-074753 — 1.01, 5.02, 9.01
- 2017-11-16 0001193125-17-345455 — 8.01
- 2017-11-13 0001193125-17-340001 — 8.01, 9.01
- 2017-11-01 0001234452-17-000189 — 2.02, 9.01
- 2017-08-24 0001234452-17-000163 — 5.02
- 2017-07-19 0001234452-17-000153 — 2.02, 9.01
- 2017-05-31 0001193125-17-189502 — 1.01, 9.01
- 2017-05-23 0001193125-17-178324 — 8.01, 9.01
- 2017-05-19 0001193125-17-175921 — 8.01, 9.01
- 2017-04-19 0001234452-17-000075 — 2.02, 9.01
- 2017-03-10 0001234452-17-000048 — 5.07
- 2017-02-15 0001234452-17-000036 — 5.02
- 2017-01-25 0001234452-17-000026 — 2.02, 9.01
- 2016-11-29 0000950157-16-002532 — 1.01, 2.03, 9.01
- 2016-11-09 0000950157-16-002442 — 1.01, 2.03, 9.01
- 2016-11-02 0001234452-16-000551 — 2.02, 9.01
- 2016-10-27 0001193125-16-749835 — 1.01, 7.01, 9.01
- 2016-10-11 0001234452-16-000527 — 5.02, 8.01, 9.01
- 2016-07-20 0001234452-16-000482 — 2.02, 9.01
- 2016-07-15 0001234452-16-000471 — 5.03, 9.01
- 2016-05-04 0001234452-16-000436 — 5.02
- 2016-04-20 0001234452-16-000427 — 2.02, 9.01
- 2016-03-11 0001234452-16-000392 — 5.07
- 2016-01-27 0001234452-16-000350 — 2.02, 9.01
- 2016-01-14 0001234452-16-000333 — 5.02
- 2016-01-13 0001193125-16-428370 — 1.01, 7.01, 9.01
- 2015-12-15 0001234452-15-000317 — 7.01, 9.01
- 2015-12-11 0001234452-15-000313 — 5.03, 9.01
- 2015-11-24 0001234452-15-000305 — 5.02
- 2015-11-04 0001234452-15-000269 — 2.02, 9.01
- 2015-09-30 0001234452-15-000251 — 5.03, 9.01
- 2015-09-30 0001234452-15-000249 — 5.02, 9.01
- 2015-07-22 0001234452-15-000210 — 1.01, 5.02, 7.01, 8.01, 9.01
- 2015-07-22 0001234452-15-000206 — 2.02, 9.01
- 2015-05-21 0001193125-15-195953 — 1.01, 9.01
- 2015-05-21 0001193125-15-195451 — 1.01, 9.01
- 2015-05-15 0001193125-15-188588 — 8.01, 9.01
- 2015-04-22 0001234452-15-000132 — 2.02, 9.01
- 2015-03-13 0001234452-15-000088 — 5.07
- 2015-03-10 0001234452-15-000055 — 2.03
- 2015-02-18 0001234452-15-000040 — 1.01, 2.03, 9.01
- 2015-02-09 0001234452-15-000031 — 7.01, 9.01
- 2015-01-28 0001234452-15-000022 — 2.02, 9.01
- 2014-12-15 0001234452-14-000387 — 5.02
- 2014-11-05 0001234452-14-000318 — 2.02, 9.01
- 2014-10-15 0001234452-14-000304 — 1.01, 7.01, 9.01
- 2014-08-28 0001234452-14-000263 — 5.02
- 2014-07-23 0001234452-14-000236 — 2.02, 9.01
- 2014-05-08 0001234452-14-000177 — 5.07 — amendment of 0001234452-14-000104
- 2014-05-08 0001234452-14-000175 — 5.02
- 2014-05-08 0001234452-14-000173 — 5.02
- 2014-04-23 0001234452-14-000152 — 2.02, 9.01
- 2014-03-10 0001234452-14-000104 — 5.02, 5.07
- 2014-01-29 0001234452-14-000047 — 2.02, 9.01
- 2013-12-18 0001234452-13-000640 — 5.02
- 2013-11-06 0001234452-13-000482 — 2.02, 9.01
- 2013-10-08 0001234452-13-000450 — 5.02
- 2013-07-25 0001234452-13-000297 — 2.02, 9.01 — amendment of 0001234452-13-000291
- 2013-07-24 0001234452-13-000291 — 2.02, 9.01
- 2013-05-07 0001234452-13-000197 — 5.02
- 2013-04-24 0001193125-13-170370 — 2.02, 9.01
- 2013-03-08 0001234452-13-000122 — 5.07
- 2013-01-31 0001234452-13-000043 — 5.02
- 2013-01-30 0001193125-13-029954 — 2.02, 9.01
- 2012-11-07 0001193125-12-457398 — 2.02, 9.01
- 2012-10-03 0001234452-12-000344 — 5.02
- 2012-07-18 0001193125-12-306120 — 2.02, 9.01
- 2012-07-11 0001193125-12-299885 — 5.02, 5.03, 9.01
- 2012-04-18 0001193125-12-168316 — 2.02, 9.01
- 2012-03-09 0001193125-12-105945 — 5.03, 5.07, 9.01
- 2012-02-01 0001193125-12-034313 — 2.02, 9.01
- 2011-11-02 0001193125-11-292735 — 2.02, 9.01
- 2011-10-06 0001193125-11-265621 — 5.02
- 2011-07-20 0001193125-11-192491 — 2.02, 9.01
- 2011-07-05 0000950123-11-063897 — 5.07, 8.01 — amendment of 0000950123-11-025180
- 2011-05-24 0000950123-11-053544 — 2.01, 8.01, 9.01
- 2011-04-20 0000950123-11-037275 — 2.02, 9.01
- 2011-03-14 0000950123-11-025180 — 5.07
- 2011-01-26 0000950123-11-005563 — 2.02, 9.01
- 2011-01-06 0000950123-11-000975 — 1.01, 9.01
- 2011-01-05 0000950123-11-000786 — 8.01, 9.01
- 2010-12-08 0000950123-10-111996 — 5.02
- 2010-11-03 0000950123-10-100102 — 2.02, 9.01
- 2010-09-16 0000950123-10-086630 — 5.02, 9.01
- 2010-07-21 0000950123-10-066825 — 2.02, 9.01
- 2010-04-21 0000950123-10-036686 — 2.02, 9.01
- 2010-03-08 0000950123-10-022056 — 5.07
- 2010-01-27 0000950123-10-005681 — 2.02, 9.01
- 2009-12-24 0000950123-09-073396 — 5.02
- 2009-11-04 0000950123-09-057673 — 2.02, 9.01
- 2009-09-25 0000950123-09-046072 — 5.03, 9.01
- 2009-07-22 0000950123-09-024347 — 2.02, 9.01
- 2009-04-27 0000950134-09-008414 — 2.02, 9.01
- 2009-04-23 0000936392-09-000201 — 2.02, 9.01
- 2009-01-28 0000936392-09-000031 — 2.02, 9.01
- 2008-12-12 0000950134-08-022080 — 5.02, 5.03, 9.01
- 2008-11-06 0000936392-08-000705 — 2.02, 9.01
- 2008-08-07 0000936392-08-000509 — 5.02
- 2008-08-07 0000936392-08-000508 — 5.02
- 2008-07-24 0000936392-08-000470 — 2.02, 9.01
- 2008-04-23 0000936392-08-000287 — 2.02, 9.01
- 2008-01-23 0000936392-08-000070 — 2.02, 9.01
- 2007-11-08 0000936392-07-000837 — 2.02, 9.01
- 2007-07-25 0000936392-07-000601 — 2.02, 9.01
- 2007-04-25 0000936392-07-000326 — 2.02, 9.01
- 2007-01-24 0000936392-07-000045 — 2.02, 9.01
- 2006-12-15 0000936392-06-001120 — 5.02
- 2006-12-12 0000936392-06-001106 — 1.01, 3.03, 9.01
- 2006-12-01 0000936392-06-001087 — 5.02
- 2006-11-13 0000936392-06-001048 — 1.01
- 2006-11-02 0000936392-06-000995 — 2.02, 9.01
- 2006-09-22 0000936392-06-000901 — 5.03, 9.01
- 2006-09-20 0000936392-06-000898 — 1.01, 5.02
- 2006-08-02 0000936392-06-000750 — 1.01, 5.02
- 2006-07-19 0000936392-06-000708 — 2.02, 9.01
- 2006-06-23 0000936392-06-000651 — 8.01, 9.01
- 2006-04-19 0000936392-06-000383 — 2.02, 9.01
- 2006-03-13 0000936392-06-000201 — 1.01, 5.03, 9.01
- 2006-01-25 0000936392-06-000038 — 2.02, 9.01
- 2006-01-23 0000950137-06-000745 — 8.01, 9.01
- 2005-11-08 0000950137-05-013474 — 1.01
- 2005-11-02 0000936392-05-000361 — 2.02, 9.01
- 2005-10-26 0000950137-05-012901 — 1.01, 9.01
- 2005-09-30 0000950137-05-011911 — 1.01, 3.03, 5.03, 9.01
- 2005-08-19 0000936392-05-000257 — 8.01, 9.01
- 2005-08-11 0000936392-05-000234 — 8.01, 9.01
- 2005-07-20 0000950137-05-008877 — 2.02, 9.01
- 2005-07-08 0000950137-05-008520 — 1.01
- 2005-06-08 0000950137-05-007163 — 1.01, 5.02, 9.01
- 2005-05-06 0000950137-05-005520 — 1.01, 9.01 — amendment of 0000936392-05-000056
- 2005-04-20 0000936392-05-000098 — 2.02, 9.01
- 2005-03-11 0000936392-05-000056 — 1.01, 5.02, 5.03, 9.01
- 2005-02-25 0000950137-05-002269 — 1.01, 9.01
- 2005-01-19 0000950137-05-000528 — 2.02, 9.01
- 2005-01-19 0000950137-05-000520 — 1.01, 9.01
- 2004-12-13 0000950134-04-019171 — 1.01, 9.01
- 2004-11-03 0000936392-04-000856 — 2.02, 9.01
- 2004-07-21 0000936392-04-000767 — 12, 7
- 2004-04-21 0000936392-04-000405 — 12, 7
- 2004-01-21 0000936392-04-000040 — 12, 7
- 2003-12-17 0000936392-03-001679 — 2, 7
- 2003-11-05 0000936392-03-001499 — 12, 7
- 2003-07-23 0000936392-03-000967 — 7, 9
- 2003-04-23 0000936392-03-000530 — 7, 9
- 2002-08-02 0000936392-02-000918 — 7, 9
- 2002-02-15 0000936392-02-000149 — 7 — amendment of 0000936392-01-500325
- 2002-01-28 0000936392-02-000060 — 7 — amendment of 0000936392-01-500325
- 2001-11-28 0000936392-01-500325 — 2, 7
- 2000-07-25 0000912057-00-032988 — 5, 7
- 2000-04-11 0000936392-00-000202 — 2, 7 — amendment of 0001095811-00-000552
- 2000-03-15 0001095811-00-000552 — 2, 7
- 2000-03-07 0001095811-00-000468 — 2, 7
- 1999-12-23 0000936392-99-001459 — 5, 7
- 1999-07-19 0000936392-99-000845 — 5, 7
- 1999-06-08 0000936392-99-000683 — 2, 7
- 1998-10-08 0000936392-98-001339 — 2, 7
- 1997-03-07 0000936392-97-000299 — 5, 7
- 1997-02-25 0000936392-97-000275 — 5, 7, 9

## late-filing notifications on or before 2018-07-25

- none on or before 2018-07-25

## item 2.02 — earnings release, exhibit 99.1

[0001728949-18-000074:8k_2_02:1]
EX-99.1
2
qcom062418erex991.htm
EXHIBIT 99.1

[0001728949-18-000074:8k_2_02:2]
Exhibit

[0001728949-18-000074:8k_2_02:3]
Exhibit 99.1

[0001728949-18-000074:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001728949-18-000074:8k_2_02:5]
Qualcomm Contact:

[0001728949-18-000074:8k_2_02:6]
John Sinnott

[0001728949-18-000074:8k_2_02:7]
Vice President, Investor Relations

[0001728949-18-000074:8k_2_02:8]
Phone: 1-858-658-4813

[0001728949-18-000074:8k_2_02:9]
e-mail: ir@qualcomm.com

[0001728949-18-000074:8k_2_02:10]
Qualcomm Announces Third Quarter Fiscal 2018 Results

[0001728949-18-000074:8k_2_02:11]
GAAP Revenues $5.6 billion

[0001728949-18-000074:8k_2_02:12]
GAAP EPS $0.82, Non-GAAP EPS $1.01

[0001728949-18-000074:8k_2_02:13]
-EPS Exceeds High End of Prior Guidance Range-

[0001728949-18-000074:8k_2_02:14]
SAN DIEGO - July 25, 2018 - Qualcomm Incorporated (NASDAQ: QCOM) today announced results for its fiscal third quarter ended June 24, 2018.

[0001728949-18-000074:8k_2_02:15]
“We reported results significantly above our prior expectations for our fiscal third quarter, driven by solid execution across the company, including very strong results in our licensing business,” said Steve Mollenkopf, CEO of Qualcomm Incorporated.  “We intend to terminate our purchase agreement to acquire NXP when the agreement expires at the end of the day today, pending any new material developments.  In addition, as previously indicated, upon termination of the agreement, we intend to pursue a stock repurchase program of up to $30 billion to deliver significant value to our stockholders.”

[0001728949-18-000074:8k_2_02:16]
Third Quarter Results (GAAP)*

[0001728949-18-000074:8k_2_02:17]
|  | Q3 Fiscal 2018 |  | Q3 Fiscal 2017 |  | Year-Over-Year Change |  | Q2 Fiscal 2018 |  | Sequential Change |
| Revenues | $5.6B |  | $5.4B |  | +4% |  | $5.3B |  | +6% |
| Operating income | $0.9B |  | $0.8B |  | +20% |  | $0.4B |  | +110% |
| Net income 1 | $1.2B |  | $0.9B |  | +41% |  | $0.4B |  | N/M |
| Diluted earnings per share 1 | $0.82 |  | $0.58 |  | +41% |  | $0.24 |  | N/M |
| Operating cash flow 2 | $2.1B |  | $0.2B |  | N/M |  | $0.5B |  | N/M |

[0001728949-18-000074:8k_2_02:18]
1 Throughout this news release, net income and diluted earnings per share are attributable to Qualcomm (i.e., after adjustments for noncontrolling interests), unless otherwise stated, and percentage changes are calculated based on the dollar amounts as disclosed in millions.

[0001728949-18-000074:8k_2_02:19]
2 In the first quarter of fiscal 2018, we adopted new accounting guidance that changed the presentation of certain cash flows related to share-based awards in the statements of cash flows.  As a result, prior period cash flow amounts presented in this news release have been adjusted to conform to the current year presentation as follows: net cash provided by operating activities for the three months and nine months ended June 25, 2017 increased by $89 million and $301 million, respectively, with corresponding offsets to net cash (used) provided by financing activities.

[0001728949-18-000074:8k_2_02:20]
N/M - Not Meaningful

[0001728949-18-000074:8k_2_02:21]
| Qualcomm Announces Third Quarter Fiscal 2018 Results | Page 2 of 15 |

[0001728949-18-000074:8k_2_02:22]
Third Quarter Results (Non-GAAP)*

[0001728949-18-000074:8k_2_02:23]
Non-GAAP results exclude the QSI (Qualcomm Strategic Initiatives) segment and certain share-based compensation, acquisition-related items, tax items and other items.  Further discussion regarding the Company’s use of Non-GAAP financial measures and detailed reconciliations between GAAP and Non-GAAP results are included within this news release.

[0001728949-18-000074:8k_2_02:24]
|  | Q3 Fiscal 2018 |  | Q3 Fiscal 2017 |  | Year-Over-Year Change |  | Q2 Fiscal 2018 |  | Sequential Change |
| Revenues | $5.6B |  | $5.3B |  | +6% |  | $5.2B |  | +8% |
| Operating income | $1.4B |  | $1.2B |  | +16% |  | $1.3B |  | +11% |
| Net income | $1.5B |  | $1.2B |  | +22% |  | $1.2B |  | +27% |
| Diluted earnings per share | $1.01 |  | $0.83 |  | +22% |  | $0.80 |  | +26% |

[0001728949-18-000074:8k_2_02:25]
* Beginning in the third quarter of fiscal 2017, GAAP and Non-GAAP results have been negatively impacted by our dispute with Apple and its contract manufacturers (who are Qualcomm licensees).  We did not record any QTL revenues in the first nine months of fiscal 2018 or the third or fourth quarter of fiscal 2017 for royalties due on sales of Apple’s products.  We expect the actions taken by these companies will continue until these disputes are resolved.  QTL revenues in the third quarter of fiscal 2018 included $500 million paid under an interim agreement with the other licensee in dispute (which dispute was previously disclosed).  This represents a partial payment for royalties due after the second quarter of fiscal 2017 by that other licensee while negotiations continue.  This payment does not reflect the full amount of royalties due under the underlying license agreement.  We did not record any revenues from the third quarter of fiscal 2017 through the second quarter of fiscal 2018 for royalties due on the sales of the other licensee’s products.  If we do not reach a final agreement with the other licensee, it may not make any other payments or may not make full payments under the underlying license agreement, which may result in increased legal costs and will negatively impact our GAAP and Non-GAAP results.

[0001728949-18-000074:8k_2_02:26]
The following also should be considered in regard to the year-over-year and sequential comparisons:

[0001728949-18-000074:8k_2_02:27]
| • | The third quarter of fiscal 2018 GAAP results included: |

[0001728949-18-000074:8k_2_02:28]
| ◦ | $112 million of restructuring and restructuring-related charges, or ($0.06) per share, related to our Cost Plan that was announced in the second quarter of fiscal 2018. |

[0001728949-18-000074:8k_2_02:29]
| • | The third quarter of fiscal 2018 GAAP and Non-GAAP results included: |

[0001728949-18-000074:8k_2_02:30]
| ◦ | $500 million of revenues, or $0.30 per share for GAAP and $0.26 per share for Non-GAAP, resulting from an interim agreement with the other licensee in dispute for royalties due after the second quarter of fiscal 2017, while negotiations continue. |

[0001728949-18-000074:8k_2_02:31]
| • | The third quarter of fiscal 2017 GAAP results included: |

[0001728949-18-000074:8k_2_02:32]
| Qualcomm Announces Third Quarter Fiscal 2018 Results | Page 3 of 15 |

[0001728949-18-000074:8k_2_02:33]
| ◦ | A reduction in operating cash flow due to a $940 million payment to BlackBerry and a $927 million payment related to the Korea Fair Trade Commission (KFTC) fine. |

[0001728949-18-000074:8k_2_02:34]
| • | The second quarter of fiscal 2018 GAAP results included: |

[0001728949-18-000074:8k_2_02:35]
| ◦ | $310 million of restructuring and restructuring-related charges, or ($0.18) per share, related to our Cost Plan. |

[0001728949-18-000074:8k_2_02:36]
Segment Results

[0001728949-18-000074:8k_2_02:37]
Third Quarter Fiscal 2018

[0001728949-18-000074:8k_2_02:38]
| (in millions, except percentages) | Q3 Fiscal 2018 |  | Q3 Fiscal 2017 |  | Year-Over-Year Change |  | Q2 Fiscal 2018 |  | Sequential Change |
| QCT |  |  |  |  |  |  |  |  |  |
| Revenues | $4,087 |  | $4,052 |  | +1% |  | $3,897 |  | +5% |
| EBT 1 | $607 |  | $575 |  | +6% |  | $608 |  | —% |
| EBT as % of revenues | 15% |  | 14% |  | +1% |  | 16% |  | (1%) |
| MSMTM chip shipments | 199 |  | 187 |  | +6% |  | 187 |  | +6% |
| QTL |  |  |  |  |  |  |  |  |  |
| Revenues | $1,465 |  | $1,172 |  | +25% |  | $1,260 |  | +16% |
| EBT | $1,049 |  | $854 |  | +23% |  | $850 |  | +23% |
| EBT as % of revenues | 72% |  | 73% |  | (1%) |  | 67% |  | +5% |

[0001728949-18-000074:8k_2_02:39]
1 Earnings (loss) before taxes

[0001728949-18-000074:8k_2_02:40]
Cash and Marketable Securities

[0001728949-18-000074:8k_2_02:41]
Our cash, cash equivalents and marketable securities totaled $35.9 billion at the end of the third quarter of fiscal 2018, compared to $37.8 billion a year ago and $39.6 billion at the end of the second quarter of fiscal 2018.  In addition, funds of $2.0 billion were held to collateralize the letters of credit related to our proposed acquisition of NXP, which have been included in other noncurrent assets since the end of the first quarter of fiscal 2017, and funds of $2.8 billion were restricted for redemption of long-term debt, which were included in other current assets at the end of the third quarter of fiscal 2018.

[0001728949-18-000074:8k_2_02:42]
| Qualcomm Announces Third Quarter Fiscal 2018 Results | Page 4 of 15 |

[0001728949-18-000074:8k_2_02:43]
Agreement to Acquire NXP

[0001728949-18-000074:8k_2_02:44]
We have entered into a definitive agreement, as amended, to acquire NXP Semiconductors N.V. (NXP) for estimated total cash consideration to be paid to NXP’s shareholders of $44 billion.  The transaction remains subject to receipt of regulatory clearance from the State Administration for Market Regulation in China (SAMR) and other closing conditions, including the tender of at least 70% of the issued and outstanding common shares of NXP in the offer.  In the absence of approval from SAMR or other material developments, we expect to terminate the transaction after 11:59 p.m. New York time on July 25, 2018, which is the “End Date” for the transaction under the definitive agreement.  If SAMR has not approved by the End Date, NXP will be entitled to receive a termination fee of $2.0 billion, which will be paid using existing cash and cash equivalents.  If events occur that cause us to not terminate the transaction, we will continue to pursue the acquisition of all of the issued and outstanding shares of NXP.

[0001728949-18-000074:8k_2_02:45]
Return of Capital to Stockholders

[0001728949-18-000074:8k_2_02:46]
During the third quarter of fiscal 2018, we returned $1.9 billion to stockholders, including $911 million, or $0.62 per share, of cash dividends paid and $1.0 billion through repurchases of 17.4 million shares of common stock.  On July 12, 2018, we announced a cash dividend of $0.62 per share payable on September 26, 2018 to stockholders of record as of the close of business on September 5, 2018.

[0001728949-18-000074:8k_2_02:47]
In the event of the termination of our proposed acquisition of NXP, we intend to implement a stock repurchase program to repurchase up to $30 billion of our outstanding common stock.

[0001728949-18-000074:8k_2_02:48]
Effective Income Tax Rates

[0001728949-18-000074:8k_2_02:49]
Our fiscal 2018 annual effective income tax rates are estimated to be 264% provision for GAAP and 2% provision for Non-GAAP.  The estimated fiscal 2018 GAAP effective tax rate includes the impact of the Tax Legislation and the European Commission fine, which is not deductible for tax purposes and is attributable to a foreign jurisdiction.  The effective income tax rates for the third quarter of fiscal 2018 were 28% benefit for GAAP and 6% benefit for Non-GAAP.  Our effective tax rates for third quarter of fiscal 2018 GAAP and Non-GAAP were lower than our prior guidance estimate effective rates for the third quarter of fiscal 2018 of 38% to 47% benefit for GAAP and 20% to 25% benefit for Non-GAAP primarily as a result of a change in the estimates of our U.S. earnings, principally due to the execution of the interim agreement with the other licensee in dispute, which was not included in our prior guidance estimate for the third quarter of fiscal 2018.  The third quarter of fiscal 2018 GAAP effective income tax rate also included a $135 million tax benefit related to the remeasurement of a U.S. deferred tax liability

[0001728949-18-000074:8k_2_02:50]
| Qualcomm Announces Third Quarter Fiscal 2018 Results | Page 5 of 15 |

[0001728949-18-000074:8k_2_02:51]
that was established as a result of a change in one of our tax positions due to U.S. tax reform legislation known as the Tax Cuts and Jobs Act (the Tax Legislation), which was not included in our guidance estimate for the third quarter of fiscal 2018.

[0001728949-18-000074:8k_2_02:52]
Business Outlook

[0001728949-18-000074:8k_2_02:53]
Our outlook does not include provisions for future asset impairments or for pending legal matters, other than future legal amounts that are probable and estimable.  Further, due to their nature, certain income and expense items, such as realized investment, certain derivative and foreign currency transaction gains or losses, cannot be accurately forecast.  Accordingly, we only include such items in our financial outlook to the extent they are reasonably certain; however, actual results may differ materially from the outlook.

[0001728949-18-000074:8k_2_02:54]
Our outlook for the fourth quarter of fiscal 2018 does not include estimates related to the operating results of our proposed acquisition of NXP or the payment of the $2.0 billion termination fee that is due if we have not received approval from SAMR by the End Date.  It also does not include the impact of the significant stock repurchase program that we intend to implement if the agreement is terminated.

[0001728949-18-000074:8k_2_02:55]
Our financial guidance for the fourth quarter of fiscal 2018 excludes QTL revenues for royalties due on sales of Apple products by Apple’s contract manufacturers, as we expect the actions taken by these companies will continue until the respective disputes are resolved.  Our financial guidance for the fourth quarter of fiscal 2018 includes $100 million of QTL revenues from the other licensee expected to be collected under the interim agreement.  This represents a partial payment for royalties while negotiations continue, and this payment does not reflect the full amount of royalties due under the underlying license agreement.

[0001728949-18-000074:8k_2_02:56]
| Qualcomm Announces Third Quarter Fiscal 2018 Results | Page 6 of 15 |

[0001728949-18-000074:8k_2_02:57]
The following table summarizes GAAP and Non-GAAP guidance based on the current outlook.  The Non-GAAP outlook presented below is consistent with the presentation of Non-GAAP results included elsewhere herein.

[0001728949-18-000074:8k_2_02:58]
Qualcomm’s Business Outlook Summary and Reconciliation

[0001728949-18-000074:8k_2_02:59]
|  |  | Q4 FY17Results (1) | Current Guidance Q4 FY18 Estimates (2)(3) |  |
|  | Revenues | $5.9B | $5.1B - $5.9B |  |  |
|  | Year-over-year change |  | decrease 14% - flat |  |  |
|  | GAAP diluted earnings per share (EPS) | $0.11 | $0.58 - $0.68 |  |  |
|  | Year-over-year change |  | N/M |  |  |
|  | Less diluted EPS attributable to QSI | $0.02 |  | $0.03 |  |  |
|  | Less diluted EPS attributable to share-based compensation | ($0.10) |  | ($0.12 | ) |  |
|  | Less diluted EPS attributable to other items | ($0.73) |  | ($0.08 | ) |  |
|  | Non-GAAP diluted EPS | $0.92 | $0.75 - $0.85 |  |  |
|  | Year-over-year change |  | decrease 8% - 18% |  |  |
|  | Other Information |  |  |  |
|  | MSM chip shipments | 220 | M | 205M - 225M |  |  |
|  | Year-over-year change |  | decrease 7% - increase 2% |  |  |
|  | QTL revenues | $1.2B | $1.0B - $1.2B |  |  |
|  | Year-over-year change |  | decrease 1% - 18% |  |  |

[0001728949-18-000074:8k_2_02:60]
| (1) | The fourth quarter of fiscal 2017 results excluded QTL revenues for royalties due on sales of Apple’s products by Apple’s contract manufacturers, as well as sales of products by the other licensee in dispute. Diluted EPS attributable to other items for the fourth quarter of fiscal 2017 was primarily attributable to the $778 million charge related to the fine imposed by the Taiwan Fair Trade Commission. |

[0001728949-18-000074:8k_2_02:61]
| (2) | Our financial guidance for the fourth quarter of fiscal 2018 excludes QTL revenues for royalties due on sales of Apple’s products by Apple’s contract manufacturers as we expect the actions taken by these companies will continue until the respective disputes are resolved. Our financial guidance for the fourth quarter of fiscal 2018 includes $100 million of QTL revenues from the other licensee under the interim agreement while negotiations continue. Further, our guidance for the fourth quarter of fiscal 2018 does not include estimates related to the operating results of our proposed acquisition of NXP or the payment of the $2.0 billion termination fee that is due if we have not received approval from SAMR by the End Date, which is estimated to be ($1.35) per share and will be excluded from our Non-GAAP results. It also does not include the impact of the significant stock repurchase program that we intend to implement if the agreement is terminated. |

[0001728949-18-000074:8k_2_02:62]
| (3) | Our guidance for diluted EPS attributable to other items for the fourth quarter of fiscal 2018 is primarily attributable to acquisition-related items and restructuring and restructuring-related items. Our guidance for Non-GAAP diluted EPS excludes a reduction to revenues related to a portion of a business arrangement that resolves a legal dispute. |

[0001728949-18-000074:8k_2_02:63]
N/M - Not Meaningful

[0001728949-18-000074:8k_2_02:64]
Sums may not equal total due to rounding.

[0001728949-18-000074:8k_2_02:65]
| Qualcomm Announces Third Quarter Fiscal 2018 Results | Page 7 of 15 |

[0001728949-18-000074:8k_2_02:66]
Reconciliations of GAAP Results to Non-GAAP Results

[0001728949-18-000074:8k_2_02:67]
The following tables reconcile our GAAP results to our Non-GAAP results ($ and shares in millions, except per share data):

[0001728949-18-000074:8k_2_02:68]
|  | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (a) (b) | Non-GAAP Results |
| Q3 FISCAL 2018 |  |  |  |  |  |  |  |
| Revenues | $5,599 |  | $20 |  |  | $— |  |  | ($50) | (c) | $5,629 |  |
| Operating income (loss) | 925 |  | 2 |  | (189) |  | (312) |  | 1,424 |  |
| EBT | 956 |  | (7) |  | (189) |  | (264) |  | 1,416 |  |
| EBT as % of revenues | 17 | % |  |  |  |  |  |  |  | 25 | % |  |
| Net income (loss) | 1,219 |  | (5) |  | (155) |  | (129) |  | 1,508 |  |
| Diluted EPS | $0.82 |  | $0.00 |  | ($0.10) |  | ($0.09) |  | $1.01 |  |
| Diluted shares | 1,487 |  | 1,487 |  | 1,487 |  | 1,487 |  | 1,487 |  |
| Q2 FISCAL 2018 |  |  |  |  |  |  |  |
| Revenues | $5,261 |  | $30 |  |  | $— |  |  |  | $— |  |  | $5,231 |  |
| Operating income (loss) | 441 |  | 10 |  | (222) |  | (628) |  | 1,281 |  |
| EBT | 358 |  | 40 |  | (222) |  | (696) |  | 1,236 |  |
| EBT as % of revenues | 7 | % |  |  |  |  |  |  |  | 24 | % |  |
| Net income (loss) | 363 |  | 30 |  | (193) |  | (661) |  | 1,187 |  |
| Diluted EPS | $0.24 |  | $0.02 |  | ($0.13) |  | ($0.44) |  | $0.80 |  |
| Diluted shares | 1,494 |  | 1,494 |  | 1,494 |  | 1,494 |  | 1,494 |  |
| Q3 FISCAL 2017 |  |  |  |  |  |  |  |
| Revenues | $5,371 |  | $56 |  |  | $— |  |  | $12 |  | $5,303 |  |
| Operating income (loss) | 773 |  | 34 |  | (227) |  | (259) |  | 1,225 |  |
| EBT | 858 |  | 55 |  | (227) |  | (271) |  | 1,301 |  |
| EBT as % of revenues | 16 | % |  |  |  |  |  |  |  | 25 | % |  |
| Net income (loss) | 866 |  | 32 |  | (199) |  | (204) |  | 1,237 |  |
| Diluted EPS | $0.58 |  | $0.02 |  | ($0.13) |  | ($0.14) |  | $0.83 |  |
| Diluted shares | 1,491 |  | 1,491 |  | 1,491 |  | 1,491 |  | 1,491 |  |

[0001728949-18-000074:8k_2_02:69]
| (a) | At fiscal year end, the quarterly tax provision (benefit) for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column. See the “Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates” herein for further details. |

[0001728949-18-000074:8k_2_02:70]
| (b) | Further details of amounts included in the “Other Items” column for the current period are included in the “Supplemental Information and Reconciliations” and the “Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates.” Details of amounts included in the “Other Items” column for prior periods are included in the news releases for those periods. |

[0001728949-18-000074:8k_2_02:71]
| (c) | Other items excluded from Non-GAAP revenues consisted of a reduction to licensing revenues related to a portion of a business arrangement that resolves a legal dispute. |

[0001728949-18-000074:8k_2_02:72]
Sums may not equal totals due to rounding.

[0001728949-18-000074:8k_2_02:73]
| Qualcomm Announces Third Quarter Fiscal 2018 Results | Page 8 of 15 |

[0001728949-18-000074:8k_2_02:74]
Supplemental Information and Reconciliations

[0001728949-18-000074:8k_2_02:75]
(Unaudited)

[0001728949-18-000074:8k_2_02:76]
|  | Q3 FISCAL 2018 |  |
|  | ($ in millions, except per share data) | GAAP Results | Less QSI | Less Share-Based Compensation | Less Other Items (a) | Non-GAAP Results |
|  | Cost of revenues |  | $2,491 |  |  | $15 |  |  | $9 |  |  | $127 |  |  | $2,340 |  |
|  | Research and development (R&D) expenses |  | 1,416 |  |  | — |  |  |  | 140 |  |  | 2 |  |  | 1,274 |  |
|  | Selling, general and administrative (SG&A) expenses |  | 655 |  |  | 3 |  |  | 40 |  |  | 21 |  |  | 591 |  |
|  | Other expenses |  | 112 |  |  | — |  |  |  | — |  |  |  | 112 |  |  | — |  |  |
|  | Interest expense |  | 212 |  |  | — |  |  |  | — |  |  |  | 22 |  |  | 190 |  |
|  | Investment and other income (loss), net |  | 243 |  |  | (9) |  |  | — |  |  |  | 70 |  |  | 182 | (b) |
|  | Diluted EPS impact of the interim agreement with the other licensee in dispute while negotiations continue |  | $0.30 |  |  | $0.00 |  |  | $0.00 |  |  | $0.04 | (c) |  | $0.26 |  |

[0001728949-18-000074:8k_2_02:77]
| (a) | Other items excluded from Non-GAAP results included $167 million of acquisition-related charges, $112 million of restructuring and restructuring-related charges related to our Cost Plan, $5 million of interest expense related to the European Commission fine and $70 million of foreign currency transaction gains related to the European Commission and Taiwan Fair Trade Commission fines, net of associated losses on derivative instruments. |

[0001728949-18-000074:8k_2_02:78]
| (b) | Included $175 million in interest and dividend income, $17 million in net foreign currency gains and $10 million in net realized gains on investments, partially offset by $17 million in equity in net losses of investees and $3 million of net losses on derivative instruments. |

[0001728949-18-000074:8k_2_02:79]
| (c) | At fiscal year end, the quarterly tax provision (benefit) for each column equals the annual tax provision (benefit) for each column computed in accordance with GAAP. In interim quarters, the sum of these provisions (benefits) may not equal the total GAAP tax provision, and this difference is included in the tax provision (benefit) in the “Other Items” column. |

[0001728949-18-000074:8k_2_02:80]
Reconciliations of GAAP Tax Rates to Non-GAAP Tax Rates

[0001728949-18-000074:8k_2_02:81]
(Unaudited)

[0001728949-18-000074:8k_2_02:82]
| ($ in millions) |  | GAAP Results |  |  | Less QSI | Less Share-Based Compensation | Less Other Items (c) (d) |  | Non-GAAP Results |  |
| Q3 FISCAL 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) before income taxes |  | $ | 956 |  |  |  | $ | (7 | ) |  |  | $ | (189 | ) |  |  | $ | (264 | ) |  |  | $ | 1,416 |  |  |
| Income tax benefit |  | 263 |  |  |  | 2 |  |  |  | 34 |  |  |  | 135 |  |  |  | 92 |  |  |
| Net income (loss) (a) |  | $ | 1,219 |  |  |  | $ | (5 | ) |  |  | $ | (155 | ) |  |  | $ | (129 | ) |  |  | $ | 1,508 |  |  |
| Tax rate |  | (28 | %) |  |  | 0 | % | (b) |  |  |  | (6 | %) | (b) |  |  | (16 | %) | (b) |  |  | (6 | %) |  |
| FISCAL 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Estimated annual tax rate |  | 264 | % |  |  | 1 | % | (b) |  |  |  | (4 | %) | (b) |  |  | 265 | % | (b) |  |  | 2 | % |  |

[0001728949-18-000074:8k_2_02:83]
| (a) | Before adjustments for noncontrolling interests. |

[0001728949-18-000074:8k_2_02:84]
| (b) | The incremental effect of our adjustments to the Non-GAAP tax rate is calculated by allocating the difference between (i) the tax expense (benefit) calculated based on the GAAP tax rate and (ii) the actual or estimated tax expense (benefit) for each column. |

[0001728949-18-000074:8k_2_02:85]
| (c) | In the third quarter of fiscal 2018, the tax benefit in the “Other Items” column included a $123 million net benefit related to the refinement of estimates related to the combined effect of the Toll Charge and the remeasurement of deferred tax assets and liabilities, all of which relate to the Tax Legislation, a $27 million tax benefit for the tax effect of acquisition-related items in EBT and a $17 million tax benefit related to the fiscal 2017 tax benefits from a new tax incentive agreement in Singapore, partially offset by tax expenses of $20 million to reconcile the tax provision for each column to the total GAAP tax provision for the quarter, $11 million due to an increase in unrecognized tax benefits and $1 million for the combined effect of other items in EBT. |

[0001728949-18-000074:8k_2_02:86]
| (d) | In fiscal 2018, the estimated annual effective tax rate for the “Other Items” column included a $5.8 billion charge related to the combined effect of the Toll Charge, the remeasurement of deferred tax assets and liabilities and our decision to no longer indefinitely reinvest certain foreign earnings, all of which relate to the Tax Legislation, and an $11 million increase in unrecognized tax benefits, partially offset by tax benefits of $134 million for the tax effect of acquisition-related items in EBT, $88 million for the combined effect of other items in EBT and $17 million related to the fiscal 2017 tax benefits from a new tax incentive agreement in Singapore. |

[0001728949-18-000074:8k_2_02:87]
| Qualcomm Announces Third Quarter Fiscal 2018 Results | Page 9 of 15 |

[0001728949-18-000074:8k_2_02:88]
Conference Call

[0001728949-18-000074:8k_2_02:89]
Qualcomm’s fiscal third quarter 2018 earnings conference call will be broadcast live on July 25, 2018, beginning at 1:45 p.m. Pacific Time (PT) at http://investor.qualcomm.com/events.cfm.  This conference call will include a discussion of “Non-GAAP financial measures” as defined in Regulation G.  The most directly comparable GAAP financial measures and information reconciling these Non-GAAP financial measures to the Company’s financial results prepared in accordance with GAAP, as well as other financial and statistical information to be discussed on the conference call, will be posted at www.qualcomm.com/investor immediately prior to the commencement of the call.  An audio replay will be available at http://investor.qualcomm.com/events.cfm and via telephone following the live call for 30 days thereafter.  To listen to the replay via telephone, U.S. callers may dial (855) 859-2056 and international callers may dial (404) 537-3406.  Callers should use reservation number 39466129.

[0001728949-18-000074:8k_2_02:90]
Note Regarding Use of Non-GAAP Financial Measures

[0001728949-18-000074:8k_2_02:91]
The Non-GAAP financial information presented herein should be considered in addition to, not as a substitute for or superior to, financial measures calculated in accordance with GAAP.  In addition, “Non-GAAP” is not a term defined by GAAP, and as a result, the Company’s measure of Non-GAAP results might be different than similarly titled measures used by other companies.  Reconciliations between GAAP and Non-GAAP results used herein are presented herein.

[0001728949-18-000074:8k_2_02:92]
The Company uses Non-GAAP financial information: (i) to evaluate, assess and benchmark the Company’s operating results on a consistent and comparable basis; (ii) to measure the performance and efficiency of the Company’s ongoing core operating businesses, including the QCT (Qualcomm CDMA Technologies) and QTL (Qualcomm Technology Licensing) segments; and (iii) to compare the performance and efficiency of these segments against competitors.  Non-GAAP measurements used by the Company include revenues, cost of revenues, R&D expenses, SG&A expenses, other income or expenses, operating income, interest expense, net investment and other income, income or earnings before income taxes, effective tax rate, net income (loss) and diluted earnings (loss) per share.  The Company is able to assess what it believes is a more meaningful and comparable set of financial performance measures for the Company and its business segments by using Non-GAAP information.  In addition, the Compensation Committee of the Board of Directors uses certain Non-GAAP financial measures in establishing portions of the performance-based incentive compensation programs for our executive officers.  The Company presents Non-GAAP financial information to provide greater transparency to investors with respect to its use of such information in financial and operational decision-making.  This Non-GAAP financial

[0001728949-18-000074:8k_2_02:93]
| Qualcomm Announces Third Quarter Fiscal 2018 Results | Page 10 of 15 |

[0001728949-18-000074:8k_2_02:94]
information is also used by institutional investors and analysts in evaluating the Company’s business and assessing trends and future expectations.

[0001728949-18-000074:8k_2_02:95]
Non-GAAP information used by management excludes its QSI segment and certain share-based compensation, acquisition-related items, tax items and other items.

[0001728949-18-000074:8k_2_02:96]
| • | QSI is excluded because the Company expects to exit its strategic investments in the foreseeable future, and the effects of fluctuations in the value of such investments and realized gains or losses are viewed by management as unrelated to the Company’s operational performance. |

[0001728949-18-000074:8k_2_02:97]
| • | Share-based compensation expense primarily relates to restricted stock units. Management believes that excluding non-cash share-based compensation from the Non-GAAP financial information allows management and investors to make additional comparisons of the operating activities of the Company’s ongoing core businesses over time and with respect to other companies. |

[0001728949-18-000074:8k_2_02:98]
| • | Certain other items are excluded because management views such items as unrelated to the operating activities of the Company’s ongoing core businesses, as follows: |

[0001728949-18-000074:8k_2_02:99]
| • | Acquisition-related items include amortization of certain intangible assets, recognition of the step-up of inventories to fair value and the related tax effects of these items, as well as any effects from restructuring the ownership of such acquired assets. Additionally, the Company excludes expenses related to the termination of contracts that limit the use of the acquired intellectual property, third-party acquisition and integration services costs and costs related to temporary debt facilities and letters of credit executed prior to the close of an acquisition. Starting with acquisitions in the second quarter of fiscal 2017, the Company excludes recognition of the step-up of property, plant and equipment from the net book value based on the original cost basis to fair value. Such charges related to acquisitions that were completed prior to the second quarter of fiscal 2017 continue to be allocated to the segments, and such amounts are not material. |

[0001728949-18-000074:8k_2_02:100]
| • | The Company excludes certain other items that management views as unrelated to the Company’s ongoing business, such as major restructuring and restructuring-related costs, goodwill and indefinite- and long-lived asset impairments and awards, settlements and/or damages arising from legal or regulatory matters. |

[0001728949-18-000074:8k_2_02:101]
| • | Certain tax items that are unrelated to the fiscal year in which they are recorded are excluded in order to provide a clearer understanding of the Company’s ongoing Non-GAAP tax rate and after tax earnings. In the first nine months of fiscal 2018, the Company excluded the full |

[0001728949-18-000074:8k_2_02:102]
| Qualcomm Announces Third Quarter Fiscal 2018 Results | Page 11 of 15 |

[0001728949-18-000074:8k_2_02:103]
impact of the Toll Charge, including the portion that relates to earnings and profits of U.S.-owned foreign subsidiaries generated in the first quarter of fiscal 2018.

[0001728949-18-000074:8k_2_02:104]
About Qualcomm

[0001728949-18-000074:8k_2_02:105]
Qualcomm invents breakthrough technologies that transform how the world connects and communicates.  When we connected the phone to the Internet, the mobile revolution was born.  Today, our inventions are the foundation for life-changing products, experiences, and industries.  As we lead the world to 5G, we envision this next big change in cellular technology spurring a new era of intelligent, connected devices and enabling new opportunities in connected cars, remote delivery of health care services, and the IoT - including smart cities, smart homes, and wearables.  Qualcomm Incorporated includes our licensing business, QTL, and the vast majority of our patent portfolio.  Qualcomm Technologies, Inc., a subsidiary of Qualcomm Incorporated, operates, along with its subsidiaries, all of our engineering, research and development functions, and all of our products and services businesses, including, our QCT semiconductor business.  For more information, visit www.qualcomm.com.

[0001728949-18-000074:8k_2_02:106]
Note Regarding Forward-Looking Statements

[0001728949-18-000074:8k_2_02:107]
| Qualcomm Announces Third Quarter Fiscal 2018 Results | Page 12 of 15 |

[0001728949-18-000074:8k_2_02:108]
###

[0001728949-18-000074:8k_2_02:109]
Qualcomm and MSM are trademarks of Qualcomm Incorporated, registered in the United States and other countries. Other products and brand names may be trademarks or registered trademarks of their respective owners.

[0001728949-18-000074:8k_2_02:110]
MSM is a product of Qualcomm Technologies, Inc.

[0001728949-18-000074:8k_2_02:111]
| Qualcomm Announces Third Quarter Fiscal 2018 Results | Page 13 of 15 |

[0001728949-18-000074:8k_2_02:112]
Qualcomm Incorporated

[0001728949-18-000074:8k_2_02:113]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001728949-18-000074:8k_2_02:114]
(In millions, except per share data)

[0001728949-18-000074:8k_2_02:115]
(Unaudited)

[0001728949-18-000074:8k_2_02:116]
|  | June 24, 2018 |  | September 24, 2017 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 35,619 |  |  | $ | 35,029 |  |
| Marketable securities | 291 |  |  | 2,279 |  |
| Accounts receivable, net | 3,163 |  |  | 3,632 |  |
| Inventories | 1,785 |  |  | 2,035 |  |
| Other current assets | 3,460 |  |  | 618 |  |
| Total current assets | 44,318 |  |  | 43,593 |  |
| Marketable securities | 35 |  |  | 1,270 |  |
| Deferred tax assets | 844 |  |  | 2,900 |  |
| Property, plant and equipment, net | 3,073 |  |  | 3,216 |  |
| Goodwill | 6,630 |  |  | 6,623 |  |
| Other intangible assets, net | 3,174 |  |  | 3,737 |  |
| Other assets | 4,016 |  |  | 4,147 |  |
| Total assets | $ | 62,090 |  |  | $ | 65,486 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Trade accounts payable | $ | 1,644 |  |  | $ | 1,971 |  |
| Payroll and other benefits related liabilities | 1,379 |  |  | 1,183 |  |
| Unearned revenues | 507 |  |  | 502 |  |
| Short-term debt | 7,103 |  |  | 2,495 |  |
| Other current liabilities | 5,579 |  |  | 4,756 |  |
| Total current liabilities | 16,212 |  |  | 10,907 |  |
| Unearned revenues | 1,708 |  |  | 2,003 |  |
| Income taxes payable | 2,659 |  |  | — |  |
| Long-term debt | 15,378 |  |  | 19,398 |  |
| Other liabilities | 3,065 |  |  | 2,432 |  |
| Total liabilities | 39,022 |  |  | 34,740 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.0001 par value; 8 shares authorized; none outstanding | — |  |  | — |  |
| Common stock and paid-in capital, $0.0001 par value; 6,000 shares authorized; 1,469 and 1,474 shares issued and outstanding, respectively | — |  |  | 274 |  |
| Retained earnings | 22,745 |  |  | 30,088 |  |
| Accumulated other comprehensive income | 323 |  |  | 384 |  |
| Total stockholders’ equity | 23,068 |  |  | 30,746 |  |
| Total liabilities and stockholders’ equity | $ | 62,090 |  |  | $ | 65,486 |  |

[0001728949-18-000074:8k_2_02:117]
| Qualcomm Announces Third Quarter Fiscal 2018 Results | Page 14 of 15 |

[0001728949-18-000074:8k_2_02:118]
Qualcomm Incorporated

[0001728949-18-000074:8k_2_02:119]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001728949-18-000074:8k_2_02:120]
(In millions, except per share data)

[0001728949-18-000074:8k_2_02:121]
(Unaudited)

[0001728949-18-000074:8k_2_02:122]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 24, 2018 |  | June 25, 2017 |  | June 24, 2018 |  | June 25, 2017 |
| Revenues: |  |  |  |  |  |  |  |
| Equipment and services | $ | 4,110 |  |  | $ | 4,121 |  |  | $ | 12,750 |  |  | $ | 11,949 |  |
| Licensing | 1,489 |  |  | 1,250 |  |  | 4,178 |  |  | 4,438 |  |
| Total revenues | 5,599 |  |  | 5,371 |  |  | 16,928 |  |  | 16,387 |  |
| Costs and expenses: |  |  |  |  |  |  |  |
| Cost of revenues | 2,491 |  |  | 2,488 |  |  | 7,394 |  |  | 7,140 |  |
| Research and development | 1,416 |  |  | 1,391 |  |  | 4,237 |  |  | 4,087 |  |
| Selling, general and administrative | 655 |  |  | 710 |  |  | 2,297 |  |  | 1,917 |  |
| Other | 112 |  |  | 9 |  |  | 1,605 |  |  | 962 |  |
| Total costs and expenses | 4,674 |  |  | 4,598 |  |  | 15,533 |  |  | 14,106 |  |
| Operating income | 925 |  |  | 773 |  |  | 1,395 |  |  | 2,281 |  |
| Interest expense | (212 | ) |  | (133 | ) |  | (561 | ) |  | (330 | ) |
| Investment and other income, net | 243 |  |  | 218 |  |  | 454 |  |  | 635 |  |
| Income before income taxes | 956 |  |  | 858 |  |  | 1,288 |  |  | 2,586 |  |
| Income tax benefit (expense) | 263 |  |  | 7 |  |  | (5,659 | ) |  | (290 | ) |
| Net income (loss) | 1,219 |  |  | 865 |  |  | (4,371 | ) |  | 2,296 |  |
| Net loss attributable to noncontrolling interests | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Net income (loss) attributable to Qualcomm | $ | 1,219 |  |  | $ | 866 |  |  | $ | (4,371 | ) |  | $ | 2,297 |  |
| Basic earnings (loss) per share attributable to Qualcomm | $ | 0.82 |  |  | $ | 0.59 |  |  | $ | (2.96 | ) |  | $ | 1.55 |  |
| Diluted earnings (loss) per share attributable to Qualcomm | $ | 0.82 |  |  | $ | 0.58 |  |  | $ | (2.96 | ) |  | $ | 1.54 |  |
| Shares used in per share calculations: |  |  |  |  |  |  |  |
| Basic | 1,478 |  |  | 1,478 |  |  | 1,479 |  |  | 1,478 |  |
| Diluted | 1,487 |  |  | 1,491 |  |  | 1,479 |  |  | 1,491 |  |
| Dividends per share announced | $ | 0.62 |  |  | $ | 0.57 |  |  | $ | 1.76 |  |  | $ | 1.63 |  |

[0001728949-18-000074:8k_2_02:123]
| Qualcomm Announces Third Quarter Fiscal 2018 Results | Page 15 of 15 |

[0001728949-18-000074:8k_2_02:124]
Qualcomm Incorporated

[0001728949-18-000074:8k_2_02:125]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001728949-18-000074:8k_2_02:126]
(In millions)

[0001728949-18-000074:8k_2_02:127]
(Unaudited)

[0001728949-18-000074:8k_2_02:128]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 24, 2018 |  | June 25, 2017 |  | June 24, 2018 |  | June 25, 2017 |
| Operating Activities: |  |  |  |  |  |  |  |
| Net income (loss) | $ | 1,219 |  |  | $ | 865 |  |  | $ | (4,371 | ) |  | $ | 2,296 |  |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization expense | 414 |  |  | 393 |  |  | 1,165 |  |  | 1,064 |  |
| Income tax provision (less than) in excess of income tax payments | (504 | ) |  | (237 | ) |  | 4,973 |  |  | (467 | ) |
| Non-cash portion of share-based compensation expense | 189 |  |  | 227 |  |  | 659 |  |  | 712 |  |
| Net realized gains on marketable securities and other investments | (26 | ) |  | (139 | ) |  | (101 | ) |  | (375 | ) |
| Indefinite and long-lived asset impairment charges | 63 |  |  | 42 |  |  | 96 |  |  | 76 |  |
| Impairment losses on marketable securities and other investments | 19 |  |  | 15 |  |  | 40 |  |  | 163 |  |
| Other items, net | (229 | ) |  | (83 | ) |  | 25 |  |  | 14 |  |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |
| Accounts receivable, net | 376 |  |  | 670 |  |  | 470 |  |  | (1,021 | ) |
| Inventories | 2 |  |  | 63 |  |  | 245 |  |  | (182 | ) |
| Other assets | 20 |  |  | 4 |  |  | 90 |  |  | 111 |  |
| Trade accounts payable | 215 |  |  | 134 |  |  | (296 | ) |  | (543 | ) |
| Payroll, benefits and other liabilities | 348 |  |  | (1,714 | ) |  | 1,514 |  |  | 878 |  |
| Unearned revenues | (53 | ) |  | (69 | ) |  | (178 | ) |  | (149 | ) |
| Net cash provided by operating activities | 2,053 |  |  | 171 |  |  | 4,331 |  |  | 2,577 |  |
| Investing Activities: |  |  |  |  |  |  |  |
| Capital expenditures | (214 | ) |  | (177 | ) |  | (625 | ) |  | (428 | ) |
| Purchases of available-for-sale marketable securities | (77 | ) |  | (6,707 | ) |  | (5,835 | ) |  | (15,509 | ) |
| Proceeds from sales and maturities of available-for-sale securities | 1,446 |  |  | 6,497 |  |  | 9,105 |  |  | 19,643 |  |
| Purchases of other marketable securities | (46 | ) |  | (705 | ) |  | (49 | ) |  | (705 | ) |
| Deposits of investments designated as collateral | — |  |  | — |  |  | — |  |  | (2,000 | ) |
| Acquisitions and other investments, net of cash acquired | (22 | ) |  | (19 | ) |  | (192 | ) |  | (1,401 | ) |
| Proceeds from other investments | 48 |  |  | 10 |  |  | 207 |  |  | 18 |  |
| Other items, net | (1 | ) |  | (1 | ) |  | 4 |  |  | 40 |  |
| Net cash provided (used) by investing activities | 1,134 |  |  | (1,102 | ) |  | 2,615 |  |  | (342 | ) |
| Financing Activities: |  |  |  |  |  |  |  |
| Proceeds from short-term debt | 3,822 |  |  | 1,735 |  |  | 9,385 |  |  | 6,848 |  |
| Repayment of short-term debt | (2,868 | ) |  | (2,734 | ) |  | (7,198 | ) |  | (7,598 | ) |
| Proceeds from long-term debt | — |  |  | 10,953 |  |  | — |  |  | 10,953 |  |
| Repayment of long-term debt | (1,571 | ) |  | — |  |  | (1,571 | ) |  | — |  |
| Deposit to redeem long-term debt | (2,831 | ) |  | — |  |  | (2,831 | ) |  | — |  |
| Proceeds from issuance of common stock | 52 |  |  | 41 |  |  | 387 |  |  | 331 |  |
| Repurchases and retirements of common stock | (1,000 | ) |  | (300 | ) |  | (1,425 | ) |  | (1,027 | ) |
| Dividends paid | (911 | ) |  | (844 | ) |  | (2,600 | ) |  | (2,411 | ) |
| Payments of tax withholdings related to vesting of share-based awards | (77 | ) |  | (88 | ) |  | (273 | ) |  | (263 | ) |
| Payment of purchase consideration related to RF360 joint venture | (42 | ) |  | — |  |  | (157 | ) |  | — |  |
| Other items, net | (37 | ) |  | (81 | ) |  | (54 | ) |  | (133 | ) |
| Net cash (used) provided by financing activities | (5,463 | ) |  | 8,682 |  |  | (6,337 | ) |  | 6,700 |  |
| Effect of exchange rate changes on cash and cash equivalents | (51 | ) |  | 34 |  |  | (19 | ) |  | 28 |  |
| Net (decrease) increase in cash and cash equivalents | (2,327 | ) |  | 7,785 |  |  | 590 |  |  | 8,963 |  |
| Cash and cash equivalents at beginning of period | 37,946 |  |  | 7,124 |  |  | 35,029 |  |  | 5,946 |  |
| Cash and cash equivalents at end of period | $ | 35,619 |  |  | $ | 14,909 |  |  | $ | 35,619 |  |  | $ | 14,909 |  |
