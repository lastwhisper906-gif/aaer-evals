# QCOM notes — 0001728949-18-000075


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001728949-18-000075:notes:1]
[same as prior period, unchanged from 0001728949-18-000039:notes:1]

[0001728949-18-000075:notes:2]
| Inventories (in millions) |  |  |  |
|  | June 24, 2018 |  | September 24, 2017 |
| Raw materials | $ | 82 |  |  | $ | 103 |  |
| Work-in-process | 666 |  |  | 799 |  |
| Finished goods | 1,037 |  |  | 1,133 |  |
|  | $ | 1,785 |  |  | $ | 2,035 |  |

[0001728949-18-000075:notes:3]
| Other Current Assets (in millions) |  |  |  |
|  | June 24, 2018 |  | September 24, 2017 |
| Deposit to redeem long-term debt (Note 5) | $ | 2,836 |  |  | $ | — |  |
| Other | 624 |  |  | 618 |  |
|  | $ | 3,460 |  |  | $ | 618 |  |

[0001728949-18-000075:notes:4]
| Other Current Liabilities (in millions) |  |  |  |
|  | June 24, 2018 |  | September 24, 2017 |
| Customer incentives and other customer-related liabilities | $ | 3,112 |  |  | $ | 2,804 |  |
| Accrual for EC fine (Note 6) | 1,166 |  |  | — |  |
| Income taxes payable | 448 |  |  | 312 |  |
| Accrual for TFTC fine (Note 6) | 154 |  |  | 778 |  |
| Other | 699 |  |  | 862 |  |
|  | $ | 5,579 |  |  | $ | 4,756 |  |

[0001728949-18-000075:notes:5]
Other Income, Costs and Expenses. Other expenses in the three and nine months ended June 24, 2018 included $112 million and $422 million, respectively, in restructuring and restructuring-related charges related to the Company’s Cost Plan (Note 9). Other expenses in the nine months ended June 24, 2018 also included a $1.2 billion charge related to the European Commission (EC) fine (Note 6).

[0001728949-18-000075:notes:6]
Other expenses in the nine months ended June 25, 2017 consisted of a $927 million charge related to the KFTC fine, including related foreign currency losses, and $35 million in restructuring and restructuring-related charges related to the Company’s Strategic Realignment Plan.

[0001728949-18-000075:notes:7]
| Investment and Other Income, Net (in millions) |  |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | June 24, 2018 |  | June 25, 2017 |  | June 24, 2018 |  | June 25, 2017 |
| Interest and dividend income | $ | 182 |  |  | $ | 147 |  |  | $ | 461 |  |  | $ | 466 |  |
| Net realized gains on marketable securities | 10 |  |  | 124 |  |  | 24 |  |  | 330 |  |
| Net realized gains on other investments | 16 |  |  | 15 |  |  | 77 |  |  | 45 |  |
| Impairment losses on marketable securities | — |  |  | (2 | ) |  | (1 | ) |  | (127 | ) |
| Impairment losses on other investments | (19 | ) |  | (13 | ) |  | (39 | ) |  | (36 | ) |
| Net (losses) gains on derivative investments | (30 | ) |  | 4 |  |  | (21 | ) |  | 25 |  |
| Equity in net losses of investees | (28 | ) |  | (31 | ) |  | (67 | ) |  | (42 | ) |
| Net gains (losses) on foreign currency transactions | 112 |  |  | (26 | ) |  | 20 |  |  | (26 | ) |
|  | $ | 243 |  |  | $ | 218 |  |  | $ | 454 |  |  | $ | 635 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001728949-18-000075:notes:8]
[same as prior period, unchanged from 0001728949-18-000039:notes:7]

[0001728949-18-000075:notes:9]
On October 27, 2016, the Company announced a definitive agreement (as amended on February 20, 2018 and April 19, 2018, the Purchase Agreement) under which Qualcomm River Holdings, B.V. (Qualcomm River Holdings), an indirect, wholly owned subsidiary of QUALCOMM Incorporated, proposed to acquire NXP Semiconductors N.V. (NXP). Pursuant to the Purchase Agreement, Qualcomm River Holdings is conducting a tender offer to acquire all of the issued and outstanding common shares of NXP, which will expire at 5:00 p.m. New York time on July 25, 2018, unless extended or earlier terminated, in either case pursuant to the terms of the Purchase Agreement.

[0001728949-18-000075:notes:10]
The transaction remains subject to receipt of regulatory clearance from SAMR and other closing conditions, including the tender of at least 70% of the issued and outstanding common shares of NXP in the tender offer. In the absence of such approval or other material developments, the Company expects to terminate the transaction after 11:59 p.m. New York time on July 25, 2018, which is the “End Date” for the transaction under the Purchase Agreement. In accordance with the terms of the Purchase Agreement, in the absence of approval from SAMR prior to the End Date, NXP will be entitled to receive a termination fee of $2.0 billion from Qualcomm River Holdings, which will be paid using existing cash and cash equivalents.

[0001728949-18-000075:notes:11]
If events occur that cause the Company to not terminate the transaction, the Company will continue to pursue the acquisition of all of the issued and outstanding common shares of NXP for $127.50 per share in cash, representing estimated total cash consideration to be paid to NXP’s shareholders of $44 billion, in accordance with the Purchase Agreement. In such case, the Company could be required to pay NXP a termination fee of $2.0 billion if the transaction is subsequently terminated in certain circumstances, as set forth in the Purchase Agreement.

[0001728949-18-000075:notes:12]
Qualcomm River Holdings entered into four letters of credit for an aggregate amount of $2.0 billion related to the potential termination fee payable to NXP. Pursuant to the terms of each letter of credit, NXP will have the right to draw amounts to fund certain termination compensation owed by Qualcomm River Holdings to NXP if the Purchase Agreement is terminated under certain circumstances, as described above. The letters of credit expire on December 31, 2018 or if drawn on or surrendered by NXP or surrendered by Qualcomm River Holdings. Upon the Company’s payment of the termination fee, NXP will no longer have the right to validly draw on the letters of credit. Each letter of credit is required to be fully cash collateralized in an amount equal to 100% of its face value through deposits with the issuers of the letters of credit. Qualcomm River Holdings is restricted from using the funds deposited as collateral while the letters of credit are outstanding. At June 24, 2018, the letters of credit were fully collateralized through bank time and demand deposits, which were included in other noncurrent assets.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001728949-18-000075:notes:13]
Commitments and Contingencies

[0001728949-18-000075:notes:14]
Legal and Regulatory Proceedings.

[0001728949-18-000075:notes:15]
ParkerVision, Inc. v. QUALCOMM Incorporated: On May 1, 2014, ParkerVision filed a complaint against the Company in the United States District Court for the Middle District of Florida alleging that certain of the Company’s products infringe certain ParkerVision patents. On August 21, 2014, ParkerVision amended the complaint, captioned ParkerVision, Inc. v. QUALCOMM Incorporated, Qualcomm Atheros, Inc., HTC Corporation, HTC America, Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc. and Samsung Telecommunications America, LLC, broadening the allegations. ParkerVision alleged that the Company infringes 11 ParkerVision patents and seeks damages and injunctive and other relief. On December 3, 2015, ParkerVision dismissed six patents from the lawsuit and granted the Company and all other defendants a covenant not to assert those patents against any existing products. On February 2, 2016, after agreement among the parties, the District Court stayed the remainder of the case pending the resolution of the complaint filed by ParkerVision against the Company and other parties with the United States International Trade Commission (ITC) described below. Subsequently, ParkerVision announced that it had reached a settlement with Samsung which dismissed the Samsung entities from the District Court case. The Company had previously filed Inter-Partes Review petitions with the United States Patent and Trademark Office (USPTO) to invalidate all asserted claims of several of the remaining patents. On March 7, 2017, the USPTO decided in the Company’s favor with respect to all asserted claims of one such patent. After the ITC action described below was closed, and upon agreement among the parties, on May 24, 2017, the District Court further stayed the District Court case pending ParkerVision’s appeal of the USPTO’s invalidation decisions. A hearing on ParkerVision’s appeal before the United States Court of Appeals for the Federal Circuit is scheduled for August 7, 2018.

[0001728949-18-000075:notes:16]
On December 14, 2015, ParkerVision filed another complaint against the Company in the United States District Court for the Middle District of Florida alleging patent infringement. Apple Inc., Samsung Electronics Co., LTD., Samsung Electronics America, Inc., Samsung Telecommunications America, LLC, Samsung Semiconductor, Inc., LG Electronics, Inc., LG Electronics U.S.A., Inc. and LG Electronics MobileComm U.S.A., Inc. were also named defendants. The complaint asserts that certain of the Company’s products infringe four additional ParkerVision patents and seeks damages and other relief. On December 15, 2015, ParkerVision filed a complaint with the ITC pursuant to Section 337 of the Tariff Act of 1930 against the same parties asserting the same four patents. The complaint seeks an exclusion order barring the importation of products that use either of two Company transceivers or one Samsung transceiver and a cease and desist order preventing the Company and the other defendants from carrying out commercial activities within the United States related to such products. On January 13, 2016, the Company served its answer to the District Court complaint. On January 15, 2016, the ITC instituted an investigation. On February 12, 2016, the District Court case was stayed pending completion of the ITC investigation. Subsequently, ParkerVision announced that it had reached a settlement with Samsung which dismissed the Samsung entities from the ITC investigation and related District Court case. On February 2, 2017, the ITC granted ParkerVision’s motion to drop all but one patent and one accused product from the ITC investigation. On March 12, 2017, one day before the ITC hearing was scheduled to begin, ParkerVision moved to withdraw its ITC complaint in its entirety. The Company and the other defendants did not oppose the withdrawal of the complaint. On April 28, 2017, the ITC formally closed the investigation. On May 4, 2017, ParkerVision filed a motion to reopen the related District Court Case, and on May 26, 2017, the District Court granted the motion. On March 16, 2018, the parties agreed to dismiss three of ParkerVision’s patents from the case without prejudice, leaving only one patent at issue. A claim construction hearing is scheduled for August 31, 2018. No trial date has been set.

[0001728949-18-000075:notes:17]
Apple Inc. (Apple) v. QUALCOMM Incorporated: On January 20, 2017, Apple filed a complaint against the Company in the United States District Court for the Southern District of California seeking declarations with respect to several of the Company’s patents and alleging that the Company breached certain agreements and violated federal antitrust and California state unfair competition laws. In its initial complaint, Apple sought declaratory judgments of non-infringement by Apple of nine of the Company’s patents, or in the alternative, a declaration of royalties Apple must pay for the patents. Apple further sought a declaration that the Company’s sale of baseband chipsets exhausts the Company’s patent rights for patents embodied in those chipsets. Separately, Apple sought to enjoin the Company from seeking excessive royalties from Apple and to disgorge royalties paid by Apple’s contract manufacturers that the court finds were not fair, reasonable and non-discriminatory (FRAND). Apple also claimed that the Company’s refusal to make certain payments to Apple under a Business Cooperation and Patent Agreement (Cooperation Agreement) constitutes a breach of contract in violation of California law and sought damages in the amount of the unpaid payments, alleged to be approximately $1 billion. In addition, Apple claimed that the Company has refused to deal with competitors in contravention of the Company’s agreements with applicable standard setting organizations, has used its market position to impose contractual obligations on Apple that prevented Apple from challenging the Company’s licensing practices, has tied the purchase of the Company’s CDMA-enabled and “premium” LTE-enabled chipsets to licensing certain of the Company’s patents and has required Apple to purchase baseband chipsets exclusively from the Company as a condition of the Company’s payment to Apple of certain rebates, in violation of Section 2 of the Sherman Act and the California Unfair Competition Law. Apple sought injunctive relief with respect to these claims and a judgment awarding its expenses, costs and attorneys’ fees.

[0001728949-18-000075:notes:18]
On April 10, 2017, the Company filed its Answer and Counterclaims (amended on May 24, 2017) in response to Apple’s complaint denying Apple’s claims and asserting claims against Apple. The counterclaims against Apple include tortious interference with the Company’s long-standing Subscriber Unit License Agreements (SULAs) with third-party contract manufacturers of Apple devices, causing those contract manufacturers to withhold certain royalty payments owed to the Company and violate their audit obligations; breach of contract and the implied covenant of good faith and fair dealing relating to the parties’ Cooperation Agreement; unjust enrichment and declaratory relief relating to the Cooperation Agreement; breach of contract based on Apple’s failure to pay amounts owed to the Company under a Statement of Work relating to a high-speed feature of the Company’s chipsets; breach of the parties’ software agreement; and violation of California Unfair Competition Law based on Apple’s threatening the Company to prevent it from promoting the superior performance of the Company’s own chipsets. The Company also seeks declaratory judgments that the Company has satisfied its FRAND commitments with respect to Apple, and that the Company’s SULAs with the contract manufacturers do not violate either competition law or the Company’s FRAND commitments. On June 19, 2017, Apple filed a Partial Motion to Dismiss the Company’s counterclaim for violation of the California Unfair Competition Law. The court granted that motion on November 8, 2017. On June 20, 2017, Apple filed an Answer and Affirmative Defenses to the rest of the Company’s counterclaims, and also filed an Amended Complaint reiterating all of the original claims and adding claims for declaratory judgments of invalidity of the nine patents that are subject to declaratory judgment claims in the original complaint, adding new declaratory judgment claims for non-infringement, invalidity and a declaration of royalties for nine more patents. Apple also added claims for declaratory judgments that certain of the Company’s agreements are unenforceable. On July 21, 2017, the Company filed an Answer to Apple’s Amended Complaint as well as a motion to dismiss the new declaratory judgment claims for non-infringement, invalidity and a declaration of royalties for the nine additional patents. The court granted the Company’s motion on November 8, 2017.

[0001728949-18-000075:notes:19]
On May 17, 2017, the Company filed a complaint (captioned QUALCOMM Incorporated v. Compal Electronics, Inc. et al.) in the United States District Court for the Southern District of California against Compal Electronics, Inc. (Compal), FIH Mobile, Ltd., Hon Hai Precision Industry Co., Ltd. (together with FIH Mobile, Ltd., Foxconn), Pegatron Corporation (Pegatron) and Wistron Corporation (Wistron) asserting claims for injunctive relief, specific performance, declaratory relief and damages stemming from the defendants’ breach of contracts by ceasing the payment of royalties for iPhones and other devices which they manufacture for Apple. On July 17, 2017, Compal, Foxconn, Pegatron and Wistron each filed third-party complaints for contractual indemnity against Apple seeking to join Apple as a party to the action. On July 18, 2017, Apple filed an answer to these third-party complaints acknowledging its indemnity agreements and consenting to be joined. On July 18, 2017, the defendants filed an Answer and Counterclaims to the complaint, asserting defenses and counterclaims similar to allegations previously made by Apple in the Apple Inc. v. QUALCOMM Incorporated case discussed above. In addition, the defendants asserted certain new claims, including claims under Section 1 of the Sherman Act and California’s Cartwright Act. The defendants seek damages, declaratory relief, injunctive relief, restitution of certain royalties and other relief. On July 18, 2017, Apple filed a motion to consolidate this action with the Apple Inc. v. QUALCOMM Incorporated case. On September 13, 2017, the court granted Apple’s consolidation motion.

[0001728949-18-000075:notes:20]
Fact discovery is substantially closed in these cases. A final pretrial conference is scheduled for November 30, 2018. The trials have not been scheduled.

[0001728949-18-000075:notes:21]
On January 23, 2017, an Apple subsidiary in China filed two complaints against the Company in the Beijing Intellectual Property Court. On March 31, 2017, the court granted an application by Apple Inc. to join the actions as a plaintiff, and Apple amended the complaints. One of the complaints alleges a violation of China’s Anti-Monopoly Law (AML complaint); the other complaint requests a determination of the terms of a patent license between the Company and Apple (FRAND complaint). The AML complaint alleges that (i) the Company has abused its dominant position in communication standard-essential patents licensing markets and certain global baseband chipset markets by charging and offering royalty terms that were excessively high; (ii) the Company refused to license certain implementers of standardized technologies, including Apple and baseband chipset manufacturers; (iii) the Company forced Apple to use only the Company’s products and services; and (iv) the Company bundled licenses to standard-essential patents with licenses to non-standard-essential patents and imposed other unreasonable or discriminatory trading terms on Apple in violation of the AML. The AML complaint seeks a decree that the Company cease the alleged abuse of dominance, as well as damages in the amount of 1 billion Chinese Renminbi (approximately $154 million based on the exchange rate on June 24, 2018). The FRAND complaint makes allegations similar to the AML complaint and further alleges that the Company refused to offer licensing terms for the Company’s cellular standard-essential patents consistent with the Company’s FRAND licensing commitments and failed to provide to Apple certain information about the Company’s patents. The FRAND complaint seeks (i) a declaration that the license terms offered to Apple by the Company for its mobile communication standard essential patents are not compliant with FRAND; (ii) an order that the Company cease its actions that allegedly violate the Company’s FRAND obligations, including pricing on unfair, unreasonable and excessive terms, refusing to deal, imposing unreasonable trade conditions and failing to provide information on the Company’s patents; and (iii) a determination of FRAND-compliant license terms for the Company’s Chinese standard-essential patents. Apple also seeks its expenses in each of the cases. On August 3, 2017, the Company received three additional complaints filed by an Apple subsidiary and Apple Inc. against the Company in the Beijing Intellectual Property Court. The complaints seek declaratory judgments of non-infringement of three Qualcomm patents. The Company filed jurisdictional and other objections to the complaints, which the court denied on May 31, 2018. On July 5, 2018, the Company appealed the denial of its objections to the Beijing High People’s Court.

[0001728949-18-000075:notes:22]
On February 16, 2017, Apple and one of its Japanese subsidiaries filed four complaints against the Company in the Tokyo District Court. In three of the complaints, Apple seeks declaratory judgment of non-infringement by Apple of three of the Company’s patents. Apple further seeks a declaration that the Company’s patent rights with respect to those three patents are exhausted by the Company’s SULAs with the contract manufacturers of Apple’s devices as well as the Company’s sale of baseband chipsets. Apple also seeks an award of fees. On January 30, 2018, April 27, 2018 and July 13, 2018, the court dismissed each of the three declaratory judgment complaints, finding that Apple lacked standing based on the facts it alleged in those complaints. The court has yet to rule on whether Apple has standing in the remaining complaint. On May 15, 2017, the Company learned of the fourth complaint. In that complaint, Apple and one of its Japanese subsidiaries seek damages of 100 million Japanese Yen (approximately $1 million based on the exchange rate on June 24, 2018) from the Company, based on allegations that the Company violated the Japanese Antimonopoly Act and the Japanese Civil Code. In particular, the fourth complaint alleges that (i) the Company holds a monopoly position in the market for baseband processor chipsets that implement certain cellular standards; (ii) the Company collects double royalties through its license agreements and the sale of chipsets; (iii) the Company refused to grant Apple a license on FRAND terms and forced Apple to execute a rebate agreement under unreasonable conditions; (iv) the Company refused to grant Apple a direct license; and (v) the Company demanded a license fee based on the market value of the total device. The Company has filed jurisdictional and other objections to this complaint.

[0001728949-18-000075:notes:23]
On March 2, 2017, the Company learned that Apple and certain of its European subsidiaries issued a Claim Form against the Company in the UK High Court of Justice, Chancery Division, Patents Court on January 23, 2017. Apple subsequently filed an Amended Claim Form and Particulars of Claim. Both the Amended Claim Form and the Particulars of Claim allege several European competition law claims, including refusal to license competing chipmakers, failure to offer Apple a direct license to the Company’s standard-essential patents on FRAND terms, demanding excessive royalties for the Company’s standard-essential patents, and demanding excessive license fees for the use of the Company’s standard-essential patents in connection with chipsets purchased from the Company. Apple also seeks declarations that the Company is obliged to offer a direct patent license to Apple in respect of standard-essential patents actually practiced on fair, reasonable and non-discriminatory terms and that using the Company’s chipsets does not infringe any of the Company’s patents because the Company exhausted its patent rights. Finally, Apple seeks declarations that five of the Company’s European (UK) patents are invalid and not essential, and an order that each of those patents be revoked.

[0001728949-18-000075:notes:24]
On April 18, 2017, Apple and one of its Taiwanese subsidiaries filed a complaint against the Company in the Taiwan Intellectual Property Court alleging that the Company has abused a dominant market position in licensing wireless standard-essential patents and selling baseband chipsets, including improper pricing, refusal to deal, exclusive dealing, tying, imposing unreasonable trade terms and discriminatory treatment. The complaint seeks rulings that the Company not use the sales price of the terminal device as the royalty base for standard-essential patents; not leverage its cellular standard-essential patents to obtain licenses of its non-standard-essential patents or demand cross-licenses without proper compensation; not refuse, reduce, delay or take any other action to limit the supply of its baseband chipsets to non-licensees; that the Company must license its standard-essential patents on FRAND terms; and that the Company shall not, based on standard-essential patents, seek injunctions. The complaint also seeks damages of 10 million Taiwan Dollars (less than $1 million based on the exchange rate on June 24, 2018), among other relief.

[0001728949-18-000075:notes:25]
On November 30, 2017, Apple and certain of its Chinese subsidiaries filed three patent infringement complaints against the Company in the Beijing Intellectual Property Court. Apple seeks damages and costs. The Company has filed jurisdictional objections to the complaints.

[0001728949-18-000075:notes:26]
The Company believes Apple’s (as well as Compal’s, Foxconn’s, Pegatron’s and Wistron’s) claims in the above matters are without merit.

[0001728949-18-000075:notes:27]
QUALCOMM Incorporated v. Apple Inc.: On July 6, 2017, the Company filed a complaint against Apple in the United States District Court for the Southern District of California asserting claims for damages and injunctive relief for infringement of six of the Company’s patents directed to a variety of features found in iPhone models. On July 7, 2017, the Company filed a complaint against Apple in the United States International Trade Commission (ITC) requesting that the ITC institute an investigation pursuant to Section 337 of the Tariff Act of 1930 based on Apple’s infringement of the same six patents. The Company is seeking a limited exclusion order and cease and desist order against importation of iPhone models that do not contain a Qualcomm brand baseband processor. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. Apple filed an Answer and Counterclaims in the District Court case on September 26, 2017. On November 29, 2017, Apple filed a First Amended Answer and Counterclaims asserting that the Company’s Snapdragon processors infringe eight Apple patents. On August 8, 2017, the ITC issued a notice of institution of an investigation. On August 25, 2017, the Company withdrew allegations as to one patent in both the ITC investigation and the District Court case. On April 25, 2018, the Company withdrew allegations as to two additional patents in the ITC investigation, but not the district court case, in order to satisfy certain briefing limitations and to narrow the issues for hearing. The ITC investigation evidentiary hearing by the Administrative Law Judge (ALJ) was held June 18-26, 2018. The ALJ’s Initial Determination on the merits is due on September 14, 2018, and the target date for final determination by the ITC is set for January 14, 2019. A case management conference in the district court case was held on January 26, 2018. On March 2, 2018, the court granted the Company’s motion to sever, for separate trial, Apple’s counterclaims for patent infringement against the Company. With respect to the Company’s patent claims against Apple, fact discovery closed on June 11, 2018, and a claim construction hearing is set for July 31, 2018. Trial is scheduled to begin on March 4, 2019. With respect to Apple’s patent claims against the Company, fact discovery is scheduled to close on December 3, 2018. A claim construction hearing is scheduled for September 5, 2018, and trial is scheduled to begin on July 15, 2019. On June 28, 2018, Intel filed petitions with the USPTO Patent Trial and Appeal Board (PTAB) challenging the validity of one of the patents asserted in the July 7, 2017 ITC investigation and corresponding District Court case. On June 29, 2018 and July 6, 2018, Intel filed petitions with the USPTO PTAB challenging the validity of another patent asserted in the July 7, 2017 ITC investigation and corresponding District Court case. On July 3, 2018, Intel filed petitions with the USPTO PTAB challenging the validity of two additional patents asserted in the July 7, 2017 ITC investigation and corresponding District Court case.

[0001728949-18-000075:notes:28]
On November 1, 2017, the Company filed a complaint against Apple in San Diego Superior Court for breach of the Master Software Agreement between the companies. The complaint recounts instances when Apple failed to protect the Company’s software as required by the agreement and failed to provide sufficient information to which the Company is entitled under the agreement in order to understand whether other breaches have occurred. The complaint seeks specific performance of Apple’s obligations to cooperate with an audit of its handling of the Company’s software, damages and injunctive relief. Apple filed its Answer to the Complaint on December 29, 2017. Trial is scheduled to begin on April 26, 2019.

[0001728949-18-000075:notes:29]
On November 29, 2017, the Company filed three additional complaints against Apple in the United States District Court for the Southern District of California alleging infringement of a total of 16 of the Company’s patents. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. The complaints seek damages and injunctive relief. On January 22, 2018, Apple filed Answers and Counterclaims in each of these cases seeking declaratory judgments that the asserted patents are invalid and/or not infringed. Case management conferences were held on February 7, 2018 and March 1, 2018. Tutorials and presentation of claim construction arguments for two of the cases are scheduled for September 12-13, 2018 and October 10 - 11, 2018, respectively. For the case relating to the November 30, 2017 ITC investigation described below, a mandatory settlement conference is scheduled for October 19, 2018, fact discovery is scheduled to close on March 13, 2019, and trial is scheduled to begin on October 21, 2019. On June 18, 2018, Apple filed a petition with the USPTO PTAB challenging the validity of one patent asserted in the November 30, 2017 ITC investigation and the corresponding District Court case. On June 29, 2018, Apple filed petitions with the USPTO PTAB challenging the validity of another patent asserted in the November 30, 2017 ITC investigation and the corresponding District Court case. No trial date has been set for the other two cases.

[0001728949-18-000075:notes:30]
On November 30, 2017, the Company filed a complaint in the ITC accusing certain Apple products of infringing five of the Company’s patents. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. The Company seeks a limited exclusion order and cease and desist order against importation of iPhone models that do not contain a Qualcomm brand baseband processor. On January 2, 2018, the ITC instituted an investigation. The ITC investigation is scheduled for evidentiary hearing by the Administrative Law Judge (ALJ) from September 17-24, 2018. The ALJ’s Initial Determination on the merits is due on January 22, 2019, and the target date for final determination by the ITC is set for May 22, 2019.

[0001728949-18-000075:notes:31]
On July 17, 2017, the Company filed complaints against Apple and certain of its subsidiaries in the Federal Republic of Germany, asserting infringement of one of the Company’s patents in the Mannheim District Court and infringement of another patent in the Munich District Court. On October 2, 2017, the Company filed claim extensions in these actions against Apple and certain of its subsidiaries, asserting infringement of two additional patents in the Mannheim District Court and infringement of five additional patents in the Munich District Court. On May 28, 2018, the Company filed additional claim extensions in these actions against Apple and certain of its subsidiaries, asserting infringement of three additional patents in the Mannheim District Court and infringement of one additional patent in the Munich District Court. The complaints seek remedies including, among other relief, declaratory relief confirming liability on the merits for damages and injunctive relief. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. Hearings are scheduled for various dates through March 2019.

[0001728949-18-000075:notes:32]
On September 29, 2017, the Company filed three complaints against Apple and certain of its subsidiaries in the Beijing (China) Intellectual Property Court, asserting infringement of three of the Company’s patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On May 10, 2018 and June 21, 2018, Apple filed invalidation requests with the PRB for the three asserted patents. The PRB has not set hearing dates for these proceedings.

[0001728949-18-000075:notes:33]
On November 13, 2017, the Company filed three complaints against certain of Apple’s subsidiaries in the Beijing (China) High People’s Court, asserting infringement of three of the Company’s patents. The complaints seek remedies including injunctive relief, damages and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On December 19, 2017, Apple’s subsidiaries filed invalidation requests with the Chinese Patent Review Board (PRB) for each of the three asserted patents. PRB hearings regarding the validity of the patents were held in April and May 2018. On May 22, 2018, Apple’s subsidiaries filed a second invalidation request with the PRB for one of the three asserted patents. The PRB has not ruled on the invalidation requests.

[0001728949-18-000075:notes:34]
On November 15, 2017, the Company filed three complaints against certain of Apple’s subsidiaries in the Fuzhou (China) Intermediate People’s Court, asserting infringement of three of the Company’s patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. Apple’s subsidiaries filed invalidation requests with the PRB on December 8, 2017 for one of the patents and December 11, 2017 for the other two patents. PRB hearings regarding the validity of the patents were held in April and May 2018. On July 13, 2018, the PRB issued an order upholding the validity of one of the patents subject to Apple’s invalidity challenges. The PRB has not ruled on the invalidation requests with respect to the other two patents.

[0001728949-18-000075:notes:35]
On January 12, 2018, the Company filed three additional complaints against Apple and certain of its subsidiaries in the Fuzhou (China) Intermediate People’s Court, asserting infringement of three additional Company patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms.

[0001728949-18-000075:notes:36]
Also on January 12, 2018, the Company filed three complaints against certain of Apple’s subsidiaries in the Jiangsu (China) High People’s Court, asserting infringement of three of the Company’s patents. The complaints seek remedies including injunctive relief, damages and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On February 5, 2018, Apple’s subsidiaries filed invalidation requests with the PRB. PRB hearings regarding the validity of the patents were held in June 2018. The PRB has not ruled on the invalidation requests.

[0001728949-18-000075:notes:37]
On February 2, 2018, the Company filed three complaints against certain of Apple’s subsidiaries in the Qingdao (China) Intermediate People’s Court, asserting infringement of three of the Company’s patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On February 26, 2018, Apple’s subsidiaries filed invalidation requests with the PRB. PRB hearings regarding the validity of the patents were held in June 2018. The PRB has not ruled on the invalidation requests.

[0001728949-18-000075:notes:38]
Also on February 2, 2018, the Company filed three complaints against certain of Apple’s subsidiaries in the Guangzhou (China) Intermediate People’s Court, asserting infringement of three of the Company’s patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms. On March 14, 2018, Apple’s subsidiaries filed invalidation requests with the PRB. PRB hearings regarding the validity of the patents began in July 2018. The PRB has not ruled on the invalidation requests.

[0001728949-18-000075:notes:39]
On June 14, 2018, the Company filed three complaints against certain of Apple’s subsidiaries in the Guangdong (China) High People’s Court, asserting infringement of three of the Company’s patents. The complaints seek remedies including injunctive relief and costs. The patents have not been declared as essential to any standards organization and are not subject to commitments to license on FRAND terms.

[0001728949-18-000075:notes:40]
The Company believes Apple’s counterclaims and invalidation requests in the above matters are without merit.

[0001728949-18-000075:notes:41]
3226701 Canada, Inc. v. QUALCOMM Incorporated et al: On November 30, 2015, plaintiffs filed a securities class action complaint against the Company and certain of its current and former officers in the United States District Court for the Southern District of California. On April 29, 2016, plaintiffs filed an amended complaint. On January 27, 2017, the court dismissed the amended complaint in its entirety, granting leave to amend. On March 17, 2017, plaintiffs filed a second amended complaint, alleging that the Company and certain of its current and former officers violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, as amended, by making false and misleading statements regarding the Company’s business outlook and product development between November 19, 2014 and July 22, 2015. The second amended complaint sought unspecified damages, interest, attorneys’ fees and other costs. On May 8, 2017, the Company filed a motion to dismiss the second amended complaint. On October 20, 2017, the court entered an order granting in part the Company’s motion to dismiss, and on November 29, 2017, the court entered an order granting the remaining portions of the Company’s motion to dismiss. On December 28, 2017, the plaintiffs filed an appeal to the United States Court of Appeals for the Ninth Circuit. No hearing date has been set. The Company believes the plaintiffs’ claims are without merit.

[0001728949-18-000075:notes:42]
Consolidated Securities Class Action Lawsuit: On January 23, 2017 and January 26, 2017, securities class action complaints were filed by purported stockholders of the Company in the United States District Court for the Southern District of California against the Company and certain of its current and former officers and directors. The complaints alleged, among other things, that the defendants violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 thereunder, by making false and misleading statements and omissions of material fact in connection with certain allegations that the Company is or was engaged in anticompetitive conduct. The complaints sought unspecified damages, interest, fees and costs. On May 4, 2017, the court consolidated the two actions and appointed lead plaintiffs. On July 3, 2017, the lead plaintiffs filed a consolidated amended complaint asserting the same basic theories of liability and requesting the same basic relief. On September 1, 2017, the defendants filed a motion to dismiss the consolidated amended complaint. The court has not yet ruled on the motion. The Company believes the plaintiffs’ claims are without merit.

[0001728949-18-000075:notes:43]
Camp v. Qualcomm Incorporated et al: On June 8, 2018 and June 26, 2018, securities class action complaints were filed by purported stockholders of the Company in the United States District Court for the Southern District of California against the Company and two of its current officers. The two complaints allege, among other things, that the defendants violated Sections 10(b) and 20(a) of the Securities Exchange Act of 1934, and Rule 10b-5 thereunder, by failing to disclose that the Company had made a filing with the Committee on Foreign Investment in the United States (CFIUS) in January 2018. The complaints seek unspecified damages, interest, fees and costs. Upon the appointment of lead plaintiff in the action and the filing of a First Amended Complaint, the Company anticipates filing a motion to dismiss the complaint, as it believes the plaintiffs’ claims are without merit.

[0001728949-18-000075:notes:44]
Consumer Class Action Lawsuit: Since January 18, 2017, a number of consumer class action complaints have been filed against the Company in the United States District Courts for the Southern and Northern Districts of California, each on behalf of a putative class of purchasers of cellular phones and other cellular devices. Twenty-two such cases remain outstanding. In April 2017, the Judicial Panel on Multidistrict Litigation transferred the cases that had been filed in the Southern District of California to the Northern District of California. On May 15, 2017, the court entered an order appointing the plaintiffs’ co-lead counsel. On July 11, 2017, the plaintiffs filed a consolidated amended complaint alleging that the Company violated California and federal antitrust and unfair competition laws by, among other things, refusing to license standard-essential patents to its competitors, conditioning the supply of certain of its baseband chipsets on the purchaser first agreeing to license the Company’s entire patent portfolio, entering into exclusive deals with companies including Apple Inc., and charging unreasonably high royalties that do not comply with the Company’s commitments to standard setting organizations. The complaint seeks unspecified damages and disgorgement and/or restitution, as well as an order that the Company be enjoined from further unlawful conduct. On August 11, 2017, the Company filed a motion to dismiss the consolidated amended complaint. On November 10, 2017, the court denied the Company’s motion to dismiss the consolidated amended complaint, except to the extent that certain claims seek damages under the Sherman Antitrust Act. On July 5, 2018, the plaintiffs filed a motion for class certification, and a hearing on that motion is scheduled for September 27, 2018. The case is currently in the discovery stage, with discovery scheduled to close on December 28, 2018. Trial is scheduled to begin on January 19, 2019. The Company believes the plaintiffs’ claims are without merit.

[0001728949-18-000075:notes:45]
Canadian Consumer Class Action Lawsuits: Since November 9, 2017, six consumer class action complaints have been filed against the Company in Canada (in the Ontario Superior Court of Justice, the Supreme Court of British Columbia, and the Quebec Superior Court), each on behalf of a putative class of purchasers of cellular phones and other cellular devices, alleging various violations of Canadian competition and consumer protection laws. The claims are similar to those in the FTC and U.S. consumer class action complaints. The complaints seek unspecified damages. The Company has not yet answered the complaints.

[0001728949-18-000075:notes:46]
Japan Fair Trade Commission (JFTC) Complaint: The JFTC received unspecified complaints alleging that the Company’s business practices are, in some way, a violation of Japanese law. On September 29, 2009, the JFTC issued a cease and desist order concluding that the Company’s Japanese licensees were forced to cross-license patents to the Company on a royalty-free basis and were forced to accept a provision under which they agreed not to assert their essential patents against the Company’s other licensees who made a similar commitment in their license agreements with the Company. The cease and desist order seeks to require the Company to modify its existing license agreements with Japanese companies to eliminate these provisions while preserving the license of the Company’s patents to those companies. The Company disagrees with the conclusions that it forced its Japanese licensees to agree to any provision in the parties’ agreements and that those provisions violate the Japanese Antimonopoly Act. The Company has invoked its right under Japanese law to an administrative hearing before the JFTC. In February 2010, the Tokyo High Court granted the Company’s motion and issued a stay of the cease and desist order pending the administrative hearing before the JFTC. The JFTC has held hearings on 37 different dates. No further hearings are currently scheduled. Fines or other monetary remedies are not available in this matter.

[0001728949-18-000075:notes:47]
Korea Fair Trade Commission (KFTC) Complaint: On January 4, 2010, the KFTC issued a written decision finding that the Company had violated Korean law by offering certain discounts and rebates for purchases of its CDMA chipsets and for including in certain agreements language requiring the continued payment of royalties after all licensed patents have expired. The KFTC levied a fine, which the Company paid and recorded as an expense in fiscal 2010. The Company appealed to the Seoul High Court, and on June 19, 2013, the Seoul High Court affirmed the KFTC’s decision. On July 4, 2013, the Company filed an appeal with the Korea Supreme Court. There have been no material developments since then with respect to this matter.

[0001728949-18-000075:notes:48]
Korea Fair Trade Commission (KFTC) Investigation: On March 17, 2015, the KFTC notified the Company that it was conducting an investigation of the Company relating to the Korean Monopoly Regulation and Fair Trade Act (MRFTA). On December 27, 2016, the KFTC announced that it had reached a decision in the investigation, finding that the Company violated provisions of the MRFTA. On January 22, 2017, the Company received the KFTC’s formal written decision, which found that the following conducts violate the MRFTA: (i) refusing to license, or imposing restrictions on licenses for, cellular communications standard-essential patents with competing modem chipset makers; (ii) conditioning the supply of modem chipsets to handset suppliers on their execution and performance of license agreements with the Company; and (iii) coercing agreement terms including portfolio license terms, royalty terms and free cross-grant terms in executing patent license agreements with handset makers. The KFTC’s decision orders the Company to: (i) upon request by modem chipset companies, engage in good-faith negotiations for patent license agreements, without offering unjustifiable conditions, and if necessary submit to a determination of terms by an independent third party; (ii) not demand that handset companies execute and perform under patent license agreements as a precondition for purchasing modem chips; (iii) not demand unjustifiable conditions in the Company’s license agreements with handset companies, and upon request renegotiate existing patent license agreements; and (iv) notify modem chipset companies and handset companies of the decision and order imposed on the Company and report to the KFTC new or amended agreements. According to the KFTC’s decision, the foregoing will apply to transactions between the Company and the following enterprises: (i) handset manufacturers headquartered in Korea and their affiliate companies; (ii) enterprises that sell handsets in or to Korea and their affiliate companies; (iii) enterprises that supply handsets to companies referred to in (ii) above and the affiliate companies of such enterprises; (iv) modem chipset manufacturers headquartered in Korea and their affiliate companies; and (v) enterprises that supply modem chipsets to companies referred to in (i), (ii) or (iii) above and the affiliate companies of such enterprises. The KFTC’s decision also imposed a fine of approximately 1.03 trillion Korean Won (approximately $927 million), which was paid on March 30, 2017. The Company believes that its business practices do not violate the MRFTA, and on February 21, 2017 filed an action in the Seoul High Court to cancel the KFTC’s decision. On the same day, the Company filed an application with the Seoul High Court to stay the decision’s remedial order pending the Seoul High Court’s final judgment on the Company’s action to cancel the KFTC’s decision. On September 4, 2017, the Seoul High Court denied the Company’s application to stay the remedial order, and on November 27, 2017, the Korea Supreme Court dismissed the Company’s appeal of the Seoul High Court’s decision on the application to stay. The Seoul High Court has not ruled on the Company’s action to cancel the KFTC’s decision.

[0001728949-18-000075:notes:49]
Icera Complaint to the European Commission (EC): On June 7, 2010, the EC notified and provided the Company with a redacted copy of a complaint filed with the EC by Icera, Inc. (subsequently acquired by Nvidia Corporation) alleging that the Company has engaged in anticompetitive activity. The Company was asked by the EC to submit a preliminary response to the portions of the complaint disclosed to it, and the Company submitted its response in July 2010. Subsequently, the Company provided additional documents and information as requested by the EC. On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On December 8, 2015, the EC announced that it had issued a Statement of Objections expressing its preliminary view that between 2009 and 2011, the Company engaged in predatory pricing by selling certain baseband chipsets to two customers at prices below cost, with the intention of hindering competition. A Statement of Objections informs the subject of the investigation of the allegations against it and provides an opportunity to respond to such allegations. It is not a determination of the final outcome of the investigation. On August 15, 2016, the Company submitted its response to the Statement of Objections. On July 19, 2018, the EC announced that it had issued a Supplementary Statement of Objections which focuses on certain elements of the "price-cost" test applied by the EC to assess the extent to which the Company sold certain baseband chipsets allegedly below cost. If a violation is found, a broad range of remedies is potentially available to the EC, including imposing a fine (of up to 10% of the Company’s revenues) and/or injunctive relief prohibiting or restricting certain business practices. It is difficult to predict the outcome of this matter or what remedies, if any, may be imposed by the EC. The Company believes that its business practices do not violate the European Union (EU) competition rules.

[0001728949-18-000075:notes:50]
European Commission (EC) Investigation: On October 15, 2014, the EC notified the Company that it was conducting an investigation of the Company relating to Articles 101 and/or 102 of the Treaty on the Functioning of the European Union (TFEU). On July 16, 2015, the EC announced that it had initiated formal proceedings in this matter. On December 8, 2015, the EC announced that it had issued a Statement of Objections expressing its preliminary view that, pursuant to an agreement with a customer, since 2011 the Company paid significant amounts to that customer on condition that it exclusively use the Company’s baseband chipsets in its smartphones and tablets. This conduct allegedly reduced the customer’s incentives to source chipsets from the Company’s competitors and harmed competition and innovation for certain baseband chipsets. On January 24, 2018, the EC issued a decision finding that certain terms of that agreement violate EU competition law and imposed a fine of approximately 997 million Euros. On April 6, 2018, the Company filed an appeal of the EC’s decision with the General Court of the European Union. The court has not ruled on the Company’s appeal. The Company believes that its business practices do not violate the EU competition rules.

[0001728949-18-000075:notes:51]
The Company recorded a charge of $1.18 billion to other expenses related to the EC fine in the first quarter of fiscal 2018. The Company provided financial guarantees in the third quarter of fiscal 2018 to satisfy the obligation in lieu of cash payment while the Company appeals the EC’s decision. The fine is accruing interest at a rate of 1.50% per annum until it is paid or annulled. At June 24, 2018, the liability, including related foreign currency gains and accrued interest (which were recorded in investment and other income, net), was $1.17 billion and included in other current liabilities.

[0001728949-18-000075:notes:52]
United States Federal Trade Commission (FTC) v. QUALCOMM Incorporated: On September 17, 2014, the FTC notified the Company that it is conducting an investigation of the Company relating to Section 5 of the Federal Trade Commission Act (FTCA). On January 17, 2017, the FTC filed a complaint against the Company in the United States District Court for the Northern District of California alleging that the Company engaged in anticompetitive conduct and unfair methods of competition in violation of Section 5 of the FTCA by conditioning the supply of baseband processors on the purchaser first agreeing to a license to the Company’s standard-essential patents, paying incentives to purchasers of baseband processors to induce them to accept certain license terms, refusing to license its standard-essential patents to the Company’s competitors and entering into alleged exclusive dealing arrangements with Apple Inc. The complaint seeks a permanent injunction against the Company’s alleged violations of the FTCA and other unspecified ancillary equitable relief. A fine is not an available remedy in this matter, and the Company does not believe that other monetary remedies are likely. On April 19, 2017, the court set a trial date for January 4, 2019. The Company believes the FTC’s claims are without merit.

[0001728949-18-000075:notes:53]
Taiwan Fair Trade Commission (TFTC) Investigation: On December 4, 2015, the TFTC notified the Company that it was conducting an investigation into whether the Company’s patent licensing practices violate the Taiwan Fair Trade Act (TFTA). On October 11, 2017, the TFTC announced that it had reached a decision in the investigation, finding that the Company violated the TFTA. On October 23, 2017, the Company received TFTC’s formal written decision, which found that the following conducts violate the TFTA: (i) refusing to license and demanding restrictive covenants from chip competitors; (ii) refusing to supply baseband processors to companies that do not have an executed license; and (iii) providing a royalty discount to Apple in exchange for its exclusive use of the Company’s chipsets. The TFTC’s decision was based on a four-three vote, and included three written dissents. The TFTC’s decision orders the Company to: (1) cease the following conduct within 60 days of the day after receipt of the decision: (a) applying the clauses in an agreement entered into with a competing chip supplier requesting it to provide sensitive sales information such as chip prices, customers, sales volumes, product types and serial numbers; (b) applying clauses in component supply agreements entered into with handset manufacturers relating to the refusal to sell chips to unlicensed manufacturers; and (c) applying discount clauses in the exclusive agreement entered into with a relevant enterprise; (2) notify competing chip companies and handset manufacturers in writing within 30 days after receipt of the decision that those companies may request to amend or enter into patent license agreements and other relevant agreements within 60 days of the day following the day such notices are received, and upon receipt of such requests, the Company shall commence negotiation in good faith; (3) submit status reports to the TFTC on any such negotiations every six months beginning from the day after receipt of the decision, as well as to submit a report to the TFTC within 30 days after amendments to any license agreements or newly signed license agreements are executed. The TFTC’s decision also imposed a fine of 23.4 billion Taiwan Dollars. The Company believes that its business practices do not violate the TFTA, and on November 10, 2017, the Company filed an Application for Stay of Enforcement (Stay Application) of the TFTC’s decision in the Taiwan Intellectual Property Court (IPC). On December 22, 2017, the Company filed an Administrative Litigation Complaint in the IPC to revoke the TFTC’s decision. On May 24, 2018, the Company withdrew its Stay Application. The IPC has not yet ruled on the Company’s Administrative Litigation Complaint to revoke the TFTC’s decision.

[0001728949-18-000075:notes:54]
The Company recorded a charge of $778 million to other expenses related to the TFTC fine in the fourth quarter of fiscal 2017. The fine will be paid in monthly installments through December 2022. At June 24, 2018, the remaining liability, including related foreign currency gains (which were recorded in investment and other income, net), was approximately $708 million, of which $554 million was included in other noncurrent liabilities.

[0001728949-18-000075:notes:55]
Contingent losses: The Company will continue to vigorously defend itself in the foregoing matters. However, litigation and investigations are inherently uncertain, and the Company faces difficulties in evaluating or estimating likely outcomes or ranges of possible loss in antitrust and trade regulation investigations in particular. Investigations by antitrust and trade regulation agencies are not conducted in a consistent manner across jurisdictions. Further, each country and agency has different sets of laws, rules and regulations, both substantive and procedural, as well as different legal principles, theories and potential remedies, and some agencies may seek to use the investigation to advance domestic policy goals. Depending on the jurisdiction, these investigations can involve non-transparent procedures under which the Company may not receive access to evidence relied upon by the enforcement agency or that may be exculpatory, and may not be informed of the specific legal theories or evidence considered or relied upon by the agency. Unlike in civil litigation in the United States, in foreign proceedings, the Company may not be entitled to discovery or depositions, allowed to cross-examine witnesses or confront its accusers. As a result, the Company may not be aware of, and may not be entitled to know, all allegations against it, or the information or documents provided to, or discovered or prepared by, the agency. Accordingly, the Company may have little or no idea what an agency’s intent is with respect to liability, penalties or the timing of a decision. In many cases the agencies are given significant discretion, and any available precedent may have limited, if any, predictive value in their jurisdictions, much less in other jurisdictions. Accordingly, the Company cannot predict the outcome of these matters.

[0001728949-18-000075:notes:56]
Other than with respect to the TFTC and EC fines, the Company has not recorded any accrual at June 24, 2018 for contingent losses associated with these matters based on its belief that losses, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time. The unfavorable resolution of one or more of these matters could have a material adverse effect on the Company’s business, results of operations, financial condition or cash flows. The Company is engaged in numerous other legal actions not described above arising in the ordinary course of its business and, while there can be no assurance, believes that the ultimate outcome of these other legal actions will not have a material adverse effect on its business, results of operations, financial condition or cash flows.

[0001728949-18-000075:notes:57]
Indemnifications. The Company generally does not indemnify its customers and licensees for losses sustained from infringement of third-party intellectual property rights. However, the Company is contingently liable under certain product sales, services, license and other agreements to indemnify certain customers, chipset foundries and semiconductor assembly and test service providers against certain types of liability and/or damages arising from qualifying claims of patent, copyright, trademark or trade secret infringement by products or services sold or provided by the Company, or by intellectual property provided by the Company to chipset foundries and semiconductor assembly and test service providers. The Company’s obligations under these agreements may be limited in terms of time and/or amount, and in some instances, the Company may have recourse against third parties for certain payments made by the Company.

[0001728949-18-000075:notes:58]
Through June 24, 2018, the Company has received a number of claims from its direct and indirect customers and other third parties for indemnification under such agreements with respect to alleged infringement of third-party intellectual property rights by its products. Reimbursements under indemnification arrangements have not been material to the Company’s consolidated financial statements. The Company has not recorded any accrual for contingent liabilities at June 24, 2018 associated with these indemnification arrangements based on the Company’s belief that additional liabilities, while possible, are not probable. Further, any possible range of loss cannot be reasonably estimated at this time.

[0001728949-18-000075:notes:59]
Purchase Obligations and Operating Leases. The Company has agreements with suppliers and other parties to purchase inventory, other goods and services and long-lived assets. Integrated circuit product inventory obligations represent purchase commitments for raw materials, semiconductor die, finished goods and manufacturing services, such as wafer bump, probe, assembly and final test. Under the Company’s manufacturing relationships with its foundry suppliers and assembly and test service providers, cancelation of outstanding purchase commitments is generally allowed but requires payment of costs incurred through the date of cancelation, and in some cases, incremental fees related to capacity underutilization.

[0001728949-18-000075:notes:60]
The Company leases certain of its land, facilities and equipment under noncancelable operating leases, with terms ranging from less than one year to 21 years and with provisions in certain leases for cost-of-living increases.

[0001728949-18-000075:notes:61]
Obligations under these purchase agreements and future minimum lease payments under these operating leases at June 24, 2018 were as follows (in millions):

[0001728949-18-000075:notes:62]
|  | Integrated Circuit Purchase Obligations |  | Other Purchase Obligations |  | Operating Leases |
| Remainder of fiscal 2018 | $ | 2,153 |  |  | $ | 665 |  |  | $ | 30 |  |
| 2019 | 1,357 |  |  | 391 |  |  | 114 |  |
| 2020 | 316 |  |  | 179 |  |  | 84 |  |
| 2021 | 60 |  |  | 67 |  |  | 63 |  |
| 2022 | 23 |  |  | 13 |  |  | 42 |  |
| Thereafter | — |  |  | 5 |  |  | 53 |  |
| Total | $ | 3,909 |  |  | $ | 1,320 |  |  | $ | 386 |  |

[0001728949-18-000075:notes:63]
Other Commitments. At June 24, 2018, the Company was committed to fund certain strategic investments up to $544 million, of which $218 million, $37 million and $74 million was expected to be funded in the remainder of fiscal 2018, fiscal 2019 and fiscal 2021, respectively. The remaining commitments do not have fixed funding dates and are subject to certain conditions. Commitments represent the maximum amounts to be funded under these arrangements; actual funding may be in lesser amounts or not at all.

[0001728949-18-000075:notes:64]
In March 2018, the Company’s RF360 Holdings joint venture entered into an agreement for a build-to-suit construction project with a third-party lessor for the development of a manufacturing facility located in Singapore. The agreement includes a long-term lease commitment with a noncancelable 10-year term commencing upon completion of the construction project. At June 24, 2018, the minimum lease commitment under the agreement based on the noncancelable term was approximately $87 million.


## us-gaap:ConsolidationPolicyTextBlock

[0001728949-18-000075:notes:65]
During the third quarter of fiscal 2018, the Company eliminated the one-month reporting lag previously used to consolidate its RF360 Holdings joint venture to provide contemporaneous reporting within its consolidated financial statements. The effect of this change is not material to the consolidated financial statements, and therefore, the impact of eliminating the one-month reporting lag has been included in the Company’s results of operations for the three months and nine months ended June 24, 2018.


## us-gaap:DebtDisclosureTextBlock

[0001728949-18-000075:notes:66]
Debt

[0001728949-18-000075:notes:67]
Revolving Credit Facility. The Company has an Amended and Restated Revolving Credit Facility (2016 Amended and Restated Revolving Credit Facility) that provides for unsecured revolving facility loans, swing line loans and letters of credit in an aggregate amount of up to $5.0 billion, of which $530 million and $4.47 billion will expire in February 2020 and November 2021, respectively. Proceeds from the 2016 Amended and Restated Revolving Credit Facility, if drawn, are expected to be used for general corporate purposes. At June 24, 2018 and September 24, 2017, the Company had not borrowed any funds under the 2016 Amended and Restated Revolving Credit Facility.

[0001728949-18-000075:notes:68]
Commercial Paper Program. The Company has an unsecured commercial paper program, which provides for the issuance of up to $5.0 billion of commercial paper. Net proceeds from this program are used for general corporate purposes. Maturities of commercial paper can range from 1 day to up to 397 days. At June 24, 2018 and September 24, 2017, the Company had $3.2 billion and $999 million, respectively, of outstanding commercial paper included in short-term debt with a weighted-average interest rate of 2.34% and 1.19%, respectively, which included fees paid to the commercial paper dealers, and weighted-average remaining days to maturity of 46 days and 45 days, respectively. The carrying value of the outstanding commercial paper approximated its estimated fair value at June 24, 2018 and September 24, 2017.

[0001728949-18-000075:notes:69]
NXP-Related Credit and Term Loan Facilities. If the Company has not received regulatory approval from SAMR or other material developments have not occurred, the Company expects to terminate the NXP Acquisition after July 25, 2018 at 11:59 p.m. New York time (Note 8). As a result, the following credit agreements are expected to remain undrawn and terminate in accordance with their terms.

[0001728949-18-000075:notes:70]
The Company is party to a credit agreement, as amended, that provides for senior unsecured delayed-draw revolving facility loans in an aggregate amount of $3.0 billion (as amended, the 2018 Revolving Credit Facility). Proceeds from the 2018 Revolving Credit Facility, if drawn, will be used in part to finance the NXP Acquisition and for general corporate purposes. Commitments under the 2018 Revolving Credit Facility expire on the first to occur of (i) the termination of Qualcomm River Holdings’s obligation to consummate the proposed acquisition of NXP, (ii) if the closing date under the 2018 Revolving Credit Facility has not occurred, the date that is five business days following July 25, 2018 and (iii) the termination of the commitments in accordance with the provisions of the 2018 Revolving Credit Facility providing for voluntary and mandatory commitment reductions. In the event the NXP Acquisition is terminated, these commitments will expire. Loans under the 2018 Revolving Credit Facility, if drawn, will mature on December 31, 2018 and will bear interest, at the option of the Company, at either the reserve-adjusted Eurocurrency Rate (determined in accordance with the 2018 Revolving Credit Facility) or the Base Rate (determined in accordance with the 2018 Revolving Credit Facility), in each case plus an applicable margin based on the Company’s long-term unsecured senior, non-credit enhanced debt ratings. The initial margins over the reserve-adjusted Eurocurrency Rate and the Base Rate based on Qualcomm’s debt ratings as of June 24, 2018 will be 0.75% and 0.00% per annum, respectively. The 2018 Revolving Credit Facility has a ticking fee, which is based on Qualcomm’s debt ratings and initially accrues at a rate of 0.05% per annum commencing on March 6, 2018. At June 24, 2018, the Company had not borrowed any funds under the 2018 Revolving Credit Facility.

[0001728949-18-000075:notes:71]
The Company is party to a credit agreement, as amended, that provides for senior unsecured delayed-draw term facility loans in an aggregate amount of $4.0 billion (as amended, the 2016 Term Loan Facility). Proceeds from the 2016 Term Loan Facility, if drawn, will be used to finance the NXP Acquisition. Commitments under the 2016 Term Loan Facility expire on the first to occur of (i) the consummation of the proposed acquisition of NXP without using loans under the 2016 Term Loan Facility, (ii) the termination of Qualcomm River Holdings’s obligation to consummate the proposed acquisition of NXP and (iii) the date that is five business days following July 25, 2018. In the event the NXP Acquisition is terminated, these commitments will expire. At June 24, 2018 and September 24, 2017, the Company had not borrowed any funds under the 2016 Term Loan Facility.

[0001728949-18-000075:notes:72]
The Company is party to a credit agreement, as amended, that provides for senior unsecured delayed-draw term facility loans in an aggregate amount of $7.0 billion (as amended, the 2018 Term Loan Facility). Proceeds from the 2018 Term Loan Facility, if drawn, will be used in part to finance the NXP Acquisition and for general corporate purposes. Commitments under the 2018 Term Loan Facility expire on the first to occur of (i) the consummation of the proposed acquisition of NXP without using loans under the 2018 Term Loan Facility, (ii) the termination of Qualcomm River Holdings’s obligation to consummate the proposed acquisition of NXP, (iii) the date that is five business days following July 25, 2018 and (iv) the termination of the commitments in accordance with the provisions of the 2018 Term Loan Facility providing for voluntary and mandatory commitment reductions. In the event the NXP Acquisition is terminated, these commitments will expire. Loans under the 2018 Term Loan Facility, if drawn, will mature on December 31, 2018 and will bear interest, at the option of the Company, at either the reserve-adjusted Eurocurrency Rate (determined in accordance with the 2018 Term Loan Facility) or the Base Rate (determined in accordance with the 2018 Term Loan Facility), in each case plus an applicable margin based on the Company’s long-term unsecured senior, non-credit enhanced debt ratings. The initial margins over the reserve-adjusted Eurocurrency Rate and the Base Rate based on Qualcomm’s debt ratings as of June 24, 2018 will be 0.875% and 0.00% per annum, respectively. The 2018 Term Loan Facility has a ticking fee, which is based on Qualcomm’s debt ratings and initially accrues at a rate of 0.05% per annum commencing on March 6, 2018. At June 24, 2018, the Company had not borrowed any funds under the 2018 Term Loan Facility.

[0001728949-18-000075:notes:73]
Long-term Debt. In May 2018, the Company initiated private offerings to exchange the Company’s floating-rate notes due 2019, floating-rate notes due 2020, fixed-rate 1.85% notes due 2019 and fixed-rate 2.10% notes due 2020 (collectively, the Old Notes) issued in May 2017 that were subject to special mandatory redemption provisions. The Company offered certain eligible holders of the Old Notes the option to exchange Old Notes for (i) new notes that have the same principal amount and terms of the Old Notes, except for a new special mandatory redemption date of November 1, 2018 and maturity dates that are one day after the applicable maturity dates for the applicable series of Old Notes and (ii) a cash fee of 0.25% of the principal amount of the Old Notes. For holders not eligible to participate in the exchanges, the Company offered to repurchase the Old Notes pursuant to cash tender offers for 100.25% of the principal amount of the Old Notes. The offers to exchange and offers to repurchase the Company’s 2.10% fixed-rate notes due 2020 were not accepted because the amount of such notes validly tendered and not withdrawn in the applicable exchange offer was not sufficient to meet the minimum tender condition. On May 31, 2018, the Company exchanged $122 million of Old Notes for new notes and repurchased $71 million of Old Notes in the aggregate pursuant to the offers to exchange and the offers to repurchase. Also on May 31, 2018, the Company called for full redemption of all of its then-outstanding 1.85% fixed-rate notes due 2019 and 2.10% fixed-rate notes due 2020 pursuant to the optional redemption provision in the fixed-rate notes, and irrevocably deposited cash of $2.8 billion with the trustee of the notes, which represented an amount sufficient to satisfy and discharge such fixed-rate notes in full. On June 8, 2018, the Company called for full redemption all of its then-outstanding floating-rate notes due 2019 and floating-rate notes due 2020 pursuant to the special mandatory redemption provisions in the floating-rate notes. On July 2, 2018, $2.6 billion was paid to the holders of the fixed-rate notes in full redemption of such notes out of the $2.8 billion in cash previously deposited with the trustee, with the excess amount then refunded to the Company. On July 6, 2018, $1.2 billion was paid to the holders of the floating-rate notes in full redemption of such notes. At June 24, 2018, the $2.8 billion of irrevocably deposited cash was included in other current assets and the Old Notes redeemed in July 2018 were included in short-term debt.

[0001728949-18-000075:notes:74]
The following table provides a summary of the Company’s long-term debt (in millions, except percentages):

[0001728949-18-000075:notes:75]
|  |  | June 24, 2018 |  | September 24, 2017 |
|  |  | Amount |  | EffectiveRate |  | Amount |  | EffectiveRate |
| May 2015 Notes |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.27% notes due May 18, 2018 | $ | — |  |  |  |  | $ | 250 |  |  | 1.65% |
|  | Floating-rate three-month LIBOR plus 0.55% notes due May 20, 2020 | 250 |  |  | 2.94% |  | 250 |  |  | 1.92% |
|  | Fixed-rate 1.40% notes due May 18, 2018 | — |  |  |  |  | 1,250 |  |  | 1.93% |
|  | Fixed-rate 2.25% notes due May 20, 2020 | 1,750 |  |  | 3.08% |  | 1,750 |  |  | 2.20% |
|  | Fixed-rate 3.00% notes due May 20, 2022 | 2,000 |  |  | 3.66% |  | 2,000 |  |  | 2.65% |
|  | Fixed-rate 3.45% notes due May 20, 2025 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
|  | Fixed-rate 4.65% notes due May 20, 2035 | 1,000 |  |  | 4.74% |  | 1,000 |  |  | 4.74% |
|  | Fixed-rate 4.80% notes due May 20, 2045 | 1,500 |  |  | 4.71% |  | 1,500 |  |  | 4.71% |
| May 2017 Notes |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.36% notes due May 20, 2019 | 695 |  |  | 3.88% |  | 750 |  |  | 1.80% |
|  | Floating-rate three-month LIBOR plus 0.45% notes due May 20, 2020 | 485 |  |  | 4.54% |  | 500 |  |  | 1.86% |
|  | Floating-rate three-month LIBOR plus 0.73% notes due January 30, 2023 | 500 |  |  | 3.16% |  | 500 |  |  | 2.11% |
|  | Fixed-rate 1.85% notes due May 20, 2019 | 1,127 |  |  | 3.55% |  | 1,250 |  |  | 2.00% |
|  | Fixed-rate 2.10% notes due May 20, 2020 | 1,500 |  |  | 4.09% |  | 1,500 |  |  | 2.19% |
|  | Fixed-rate 2.60% notes due January 30, 2023 | 1,500 |  |  | 2.70% |  | 1,500 |  |  | 2.70% |
|  | Fixed-rate 2.90% notes due May 20, 2024 | 1,500 |  |  | 3.01% |  | 1,500 |  |  | 3.01% |
|  | Fixed-rate 3.25% notes due May 20, 2027 | 2,000 |  |  | 3.46% |  | 2,000 |  |  | 3.46% |
|  | Fixed-rate 4.30% notes due May 20, 2047 | 1,500 |  |  | 4.74% |  | 1,500 |  |  | 4.47% |
| May 2018 Notes |  |  |  |  |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.36% notes due May 21, 2019 | 52 |  |  | 3.08% |  | — |  |  |  |
|  | Floating-rate three-month LIBOR plus 0.45% notes due May 21, 2020 | 14 |  |  | 3.00% |  | — |  |  |  |
|  | Fixed-rate 1.85% notes due May 21, 2019 | 56 |  |  | 2.28% |  | — |  |  |  |
| Total principal | 19,429 |  |  |  |  | 21,000 |  |  |  |
|  | Unamortized discount, including debt issuance costs | (90 | ) |  |  |  | (106 | ) |  |  |
|  | Hedge accounting fair value adjustments | (48 | ) |  |  |  | — |  |  |  |
|  | Total | $ | 19,291 |  |  |  |  | $ | 20,894 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |
|  | Short-term debt | $ | 3,913 |  |  |  |  | $ | 1,496 |  |  |  |
|  | Long-term debt | 15,378 |  |  |  |  | 19,398 |  |  |  |
|  | Total | $ | 19,291 |  |  |  |  | $ | 20,894 |  |  |  |

[0001728949-18-000075:notes:76]
At June 24, 2018 and September 24, 2017, the aggregate fair value of the notes, based on Level 2 inputs, was approximately $18.9 billion and $21.5 billion, respectively.

[0001728949-18-000075:notes:77]
The Company’s floating-rate notes due 2019, floating-rate notes due 2020 and 1.85% fixed-rate notes due 2019 issued in May 2018 for an aggregate principal amount of $122 million are subject to a special mandatory redemption at a price equal to 101% of the aggregate principal amount, plus accrued and unpaid interest to, but excluding, the date of such mandatory redemption (the May 2018 Notes). The redemption is required on the first to occur of (i) the termination of the NXP purchase agreement or (ii) November 1, 2018, if the NXP transaction has not closed as of such date. In the event the NXP Acquisition is terminated, the May 2018 Notes will be redeemed in accordance with their terms. The Company may redeem the fixed-rate notes at any time in whole, or from time to time in part, at specified make-whole premiums as defined in the applicable form of note. The Company may not redeem the other floating-rate notes prior to maturity. The obligations under the notes rank equally in right of payment with all of the Company’s other senior unsecured indebtedness and will effectively rank junior to all liabilities of the Company’s subsidiaries.

[0001728949-18-000075:notes:78]
At June 24, 2018, the Company had outstanding interest rate swaps with an aggregate notional amount of $1.8 billion related to the May 2015 Notes, which effectively converted approximately 43% and 50% of the fixed-rate notes due in 2020 and 2022, respectively, into floating-rate notes. The net gains and losses on the interest rate swaps, as well as the offsetting gains or losses on the related fixed-rate notes attributable to the hedged risks, are recorded in earnings in interest expense in the current period. The Company did not enter into similar interest rate swaps in connection with issuance of the May 2017 Notes or May 2018 Notes.

[0001728949-18-000075:notes:79]
The effective interest rates for the notes include the interest on the notes, amortization of the discount, which includes debt issuance costs, and if applicable, adjustments related to hedging. Interest is payable in arrears quarterly for the floating-rate notes and semi-annually for the fixed-rate notes. Cash interest paid related to the Company’s commercial paper program and long-term debt, net of cash received from the related interest rate swaps, was $594 million and $289 million in the nine months ended June 24, 2018 and June 25, 2017, respectively.

[0001728949-18-000075:notes:80]
Debt Covenants. The 2016 Amended and Restated Revolving Credit Facility, the 2016 Term Loan Facility, the 2018 Revolving Credit Facility and the 2018 Term Loan Facility require that the Company comply with certain covenants, including one financial covenant to maintain a ratio of consolidated earnings before interest, taxes, depreciation and amortization to consolidated interest expense, as defined in each of the respective agreements, of not less than three to one at the end of each fiscal quarter. The Company is not subject to any financial covenants under the notes nor any covenants that would prohibit the Company from incurring additional indebtedness ranking equal to the notes, paying dividends, issuing securities or repurchasing securities issued by it or its subsidiaries. At June 24, 2018 and September 24, 2017, the Company was in compliance with the applicable covenants under each facility outstanding at such time.


## us-gaap:DividendsDeclaredTableTextBlock

[0001728949-18-000075:notes:81]
In the nine months ended June 24, 2018 and June 25, 2017, dividends charged to retained earnings were as follows (in millions, except per share data):

[0001728949-18-000075:notes:82]
|  | 2018 |  | 2017 |
|  | Per Share |  | Total |  | Per Share |  | Total |
| First quarter | $ | 0.57 |  |  | $ | 862 |  |  | $ | 0.53 |  |  | $ | 801 |  |
| Second quarter | 0.57 |  |  | 857 |  |  | 0.53 |  |  | 798 |  |
| Third quarter | 0.62 |  |  | 921 |  |  | 0.57 |  |  | 858 |  |
|  | $ | 1.76 |  |  | $ | 2,640 |  |  | $ | 1.63 |  |  | $ | 2,457 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0001728949-18-000075:notes:83]
Earnings (Loss) Per Common Share. Basic earnings (loss) per common share is computed by dividing net income (loss) attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per share is computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans, if any, and the weighted-average number of common shares outstanding during the reporting period. Due to the net loss for the nine months ended June 24, 2018, all of the common share equivalents issuable under share-based compensation plans had an anti-dilutive effect and were therefore excluded from the computation of diluted loss per share.


## us-gaap:FairValueDisclosuresTextBlock

[0001728949-18-000075:notes:84]
[same as prior period, unchanged from 0001728949-18-000039:notes:78]

[0001728949-18-000075:notes:85]
The following table presents the Company’s fair value hierarchy for assets and liabilities measured at fair value on a recurring basis at June 24, 2018 (in millions):

[0001728949-18-000075:notes:86]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | 23,855 |  |  | $ | 10,602 |  |  | $ | — |  |  | $ | 34,457 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| Corporate bonds and notes | — |  |  | 213 |  |  | — |  |  | 213 |  |
| Mortgage- and asset-backed and auction rate securities | — |  |  | — |  |  | 35 |  |  | 35 |  |
| Equity and preferred securities and equity funds | 34 |  |  | — |  |  | — |  |  | 34 |  |
| Total marketable securities | 34 |  |  | 213 |  |  | 35 |  |  | 282 |  |
| Derivative instruments | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Other investments | 393 |  |  | — |  |  | 20 |  |  | 413 |  |
| Total assets measured at fair value | $ | 24,282 |  |  | $ | 10,817 |  |  | $ | 55 |  |  | $ | 35,154 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 80 |  |  | $ | — |  |  | $ | 80 |  |
| Other liabilities | 393 |  |  | — |  |  | 129 |  |  | 522 |  |
| Total liabilities measured at fair value | $ | 393 |  |  | $ | 80 |  |  | $ | 129 |  |  | $ | 602 |  |

[0001728949-18-000075:notes:87]
Activity between Levels of the Fair Value Hierarchy. There were no transfers between Level 1 and Level 2 in the nine months ended June 24, 2018 and June 25, 2017. There were no transfers of marketable securities into or out of Level 3 during the nine months ended June 24, 2018 and June 25, 2017. Other investments and other liabilities included in Level 3 at June 24, 2018 were comprised of convertible debt instruments issued by private companies and contingent consideration related to business combinations, respectively. There were no transfers of convertible debt instruments or contingent consideration amounts into or out of Level 3 during the nine months ended June 24, 2018 and June 25, 2017.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001728949-18-000075:notes:88]
[same as prior period, unchanged from 0001728949-18-000039:notes:82]

[0001728949-18-000075:notes:89]
[same as prior period, unchanged from 0001728949-18-000039:notes:83]

[0001728949-18-000075:notes:90]
Pursuant to the Securities and Exchange Commission Staff Accounting Bulletin No. 118, Income Tax Accounting Implications of the Tax Cuts and Jobs Act, given the amount and complexity of the changes in tax law resulting from the Tax Legislation, the Company has not finalized the accounting for the income tax effects of the Tax Legislation. This includes the provisional amounts recorded related to the Toll Charge, the remeasurement of deferred taxes and the change in the Company’s indefinite reinvestment assertion. Further, the Company is in the process of analyzing the effects of new taxes due on certain foreign income, such as GILTI (global intangible low-taxed income), BEAT (base-erosion anti-abuse tax) and FDII (foreign-derived intangible income), and limitations on interest expense deductions (if certain conditions apply), all of which are effective starting in fiscal 2019, as well as other provisions of the Tax Legislation. The Company has elected to account for GILTI as period costs if and when incurred. As a result of recognizing the impact of the Tax Legislation in income tax expense (benefit), certain tax effects, which were nominal, were stranded in accumulated other comprehensive income, and the Company will not reclassify such amounts to retained earnings. The impact of the Tax Legislation may differ from this estimate, possibly materially, during the remainder of the one-year measurement period due to, among other things, further refinement of the Company’s calculations, changes in interpretations and assumptions the Company has made, guidance that may be issued and actions the Company may take as a result of the Tax Legislation.

[0001728949-18-000075:notes:91]
The Company has preliminarily accounted for the effects of the Tax Legislation, which resulted in a charge of $5.73 billion to income tax expense recorded discretely in the first nine months of fiscal 2018, comprised of $5.3 billion related to the estimated Toll Charge and $412 million resulting from the estimated impact of remeasurement of U.S. deferred tax assets and liabilities that existed at the end of fiscal 2017 at a lower enacted corporate income tax rate. These amounts included a $135 million tax benefit recorded in the third quarter of fiscal 2018 related to the remeasurement of a U.S. deferred tax liability that was established as a result of a change in one of the Company’s tax positions due to Tax Legislation. In addition, the Company recorded $12 million net tax expense discretely in the third quarter of fiscal 2018 related to refining estimates associated with the Toll Charge and impact of remeasurement of U.S. deferred tax assets and liabilities.

[0001728949-18-000075:notes:92]
The Toll Charge is based on the Company’s post-1986 earnings and profits of U.S.-owned foreign subsidiaries through December 31, 2017 for which the Company had previously deferred U.S. income taxes. The Company has not yet finalized its calculation of the total post-1986 foreign earnings and profits for the respective foreign subsidiaries. Further, the Toll Charge is based in part on the amount of those earnings held in cash and other specific assets. The Company remeasured its deferred tax assets and liabilities that existed at the end of fiscal 2017 based on the income tax rate at which they are expected to reverse, which primarily assumes the reduced income tax rate of 21% applicable in fiscal 2019, resulting in a reduction to noncurrent net deferred tax assets of $412 million in the first nine months of fiscal 2018.

[0001728949-18-000075:notes:93]
As of December 24, 2017, the Company no longer considers available cash balances that existed at the end of fiscal 2017 related to undistributed pre-fiscal 2018 earnings and profits of certain U.S.-owned foreign subsidiaries to be indefinitely reinvested and recorded a tax expense of $92 million related to foreign withholding taxes during the first nine months of fiscal 2018. The Company otherwise continues to consider other undistributed earnings of certain U.S.-owned foreign subsidiaries to be indefinitely reinvested based on its current plans for use and/or investment outside of the U.S., and therefore, no liability has been recorded for such taxes. However, as a result of the Tax Legislation, the Company is reassessing its intentions related to its indefinite reinvestment assertion. Should the Company decide to no longer indefinitely reinvest such earnings outside the U.S., the Company would have to adjust the income tax provision in the period such determination is made.

[0001728949-18-000075:notes:94]
As a result of the Toll Charge imposed by the Tax Legislation, the Company expects to fully utilize all of its unused federal tax credits that existed at the end of fiscal 2017 of $1.4 billion, which resulted in a reduction to noncurrent deferred tax assets in the first quarter of fiscal 2018, and the federal tax credits that are expected to be generated in fiscal 2018. The Company will elect to pay the Toll Charge, interest free, over a period of eight years, with payments beginning on January 15, 2019. The Company did not discount the amount of the Toll Charge. The cash amount the Company currently estimates will be paid for the Toll Charge, net of tax credit carryforwards and expected tax credits estimated to be generated in fiscal 2018, is $2.7 billion. The estimated first installment of $215 million is due on January 15, 2019 and was included in other current liabilities. The remaining liability was included in noncurrent income taxes payable.

[0001728949-18-000075:notes:95]
During the third quarter of fiscal 2018, the Company entered into a new tax incentive agreement in Singapore that results in a reduced tax rate from March 2017 through March 2022, provided that the Company meets specified employment and investment criteria in Singapore. The Company’s Singapore tax rate will increase in fiscal 2022 as a result of expiration of these incentives and again in March 2027 upon the expiration of tax incentives under a prior agreement. As a result of this new tax incentive, the Company’s estimated income tax expense for fiscal 2018 was reduced by approximately $126 million.

[0001728949-18-000075:notes:96]
The Company estimates its annual effective income tax rate to be approximately 264% for fiscal 2018, as compared to the 18% effective income tax rate for fiscal 2017, primarily as a result of the estimated charge of $5.82 billion recorded to income tax expense in the first nine months of fiscal 2018 related to the combined effect of the Toll Charge, the remeasurement of deferred tax assets and liabilities and the Company’s decision to no longer indefinitely reinvest certain foreign earnings, all of which resulted from the Tax Legislation. The estimated annual effective tax rate for fiscal 2018 was also impacted by the EC fine (Note 6) recorded in the first quarter of fiscal 2018, which is not deductible for tax purposes and is attributable to a foreign jurisdiction. Tax benefits from foreign income taxed at rates lower than rates in the U.S. are expected to be approximately 37% in fiscal 2018, compared to 32% in fiscal 2017, primarily due to lower estimated U.S. revenues principally related to decreased royalty revenues from Apple’s contract manufacturers, an increase in the allocation of expenses to the Company’s U.S. operations and the new tax incentive in Singapore, partially offset by the lower U.S. federal statutory income tax rate enacted by the Tax Legislation. The estimated annual effective tax rate for fiscal 2018 also reflects a blended U.S. federal statutory income tax rate of 25% as a result of the Tax Legislation. The annual effective tax rate of 18% for fiscal 2017 reflected the KFTC and TFTC fines (Note 6), which were not deductible for tax purposes and were each attributable to the U.S. and foreign jurisdictions.

[0001728949-18-000075:notes:97]
The effective tax rate of 28% benefit for the third quarter of fiscal 2018 was lower than the estimated annual effective tax rate primarily due to the estimated charge of $5.95 billion recorded discretely to income tax expense in the first six months of fiscal 2018 related to the effects of certain components of the Tax Legislation and the EC fine recorded in the first quarter of fiscal 2018, as well as tax benefits recorded in the third quarter of fiscal 2018 resulting from an increase in the allocation of expenses to the Company’s U.S. operations and the new tax incentive in Singapore.

[0001728949-18-000075:notes:98]
Unrecognized tax benefits were $356 million and $372 million at June 24, 2018 and September 24, 2017, respectively. The Company believes that it is reasonably possible that the total amounts of unrecognized tax benefits at June 24, 2018 may increase or decrease in the next 12 months.

[0001728949-18-000075:notes:99]
The Company is subject to income taxes in the U.S. and numerous foreign jurisdictions, and is currently under examination by various tax authorities worldwide, most notably in countries where the Company earns a routine return and tax authorities believe substantial value-add activities are performed. These examinations are at various stages with respect to assessments, claims, deficiencies and refunds, many of which are open for periods after fiscal 2000. The Company continually assesses the likelihood and amount of potential adjustments and adjusts the income tax provision, income taxes payable and deferred taxes in the period in which the facts give rise to a revision become known. As of June 24, 2018, the Company believes that adequate amounts have been reserved for based on facts known. However, the final determination of tax audits and any related legal proceedings could materially differ from amounts reflected in the Company’s income tax provision and the related accruals.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001728949-18-000075:notes:100]
[same as prior period, unchanged from 0001728949-18-000039:notes:93]

[0001728949-18-000075:notes:101]
|  | June 24, 2018 |
| Years to Maturity |  |
| Less than one year | $ | 194 |  |
| One to five years | 19 |  |
| Five to ten years | — |  |
| Greater than ten years | — |  |
| No single maturity date | 35 |  |
| Total | $ | 248 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001728949-18-000075:notes:102]
Marketable Securities

[0001728949-18-000075:notes:103]
Marketable securities were comprised as follows (in millions):

[0001728949-18-000075:notes:104]
|  | Current |  | Noncurrent |
|  | June 24, 2018 |  | September 24, 2017 |  | June 24, 2018 |  | September 24, 2017 |
| Available-for-sale: |  |  |  |  |  |  |  |
| U.S. Treasury securities and government-related securities | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | 959 |  |
| Corporate bonds and notes | 213 |  |  | 2,014 |  |  | — |  |  | 271 |  |
| Mortgage- and asset-backed and auction rate securities | — |  |  | 93 |  |  | 35 |  |  | 40 |  |
| Equity and preferred securities and equity funds | 34 |  |  | 36 |  |  | — |  |  | — |  |
| Debt funds | — |  |  | 109 |  |  | — |  |  | — |  |
| Total available-for-sale | 247 |  |  | 2,275 |  |  | 35 |  |  | 1,270 |  |
| Time deposits | 44 |  |  | 4 |  |  | — |  |  | — |  |
| Total marketable securities | $ | 291 |  |  | $ | 2,279 |  |  | $ | 35 |  |  | $ | 1,270 |  |

[0001728949-18-000075:notes:105]
Debt securities with no single maturity date included mortgage- and asset-backed securities and auction rate securities.

[0001728949-18-000075:notes:106]
The Company recorded realized gains and losses on sales of available-for-sale securities as follows (in millions):

[0001728949-18-000075:notes:107]
|  | For the three months ended |  | For the nine months ended |
|  | June 24, 2018 |  | June 25, 2017 |  | June 24, 2018 |  | June 25, 2017 |
| Gross realized gains | $ | 3 |  |  | $ | 119 |  |  | $ | 16 |  |  | $ | 422 |  |
| Gross realized losses | (6 | ) |  | (8 | ) |  | (6 | ) |  | (116 | ) |
| Net realized gains | $ | (3 | ) |  | $ | 111 |  |  | $ | 10 |  |  | $ | 306 |  |

[0001728949-18-000075:notes:108]
Available-for-sale securities were comprised as follows (in millions):

[0001728949-18-000075:notes:109]
|  | June 24, 2018 |  | September 24, 2017 |
| Equity securities |  |  |  |
| Cost | $ | 8 |  |  | $ | 8 |  |
| Unrealized gains | 26 |  |  | 28 |  |
| Fair value | 34 |  |  | 36 |  |
| Debt securities (including debt funds) |  |  |  |
| Cost | 247 |  |  | 3,497 |  |
| Unrealized gains | 1 |  |  | 13 |  |
| Unrealized losses | — |  |  | (1 | ) |
| Fair value | 248 |  |  | 3,509 |  |
|  | $ | 282 |  |  | $ | 3,545 |  |

[0001728949-18-000075:notes:110]
In connection with the proposed NXP transaction (Note 8), the Company divested a substantial portion of its marketable securities portfolio in order to finance, in part, that transaction. Marketable securities that were expected to be used to finance the NXP transaction were fully liquidated and classified as cash and cash equivalents at June 24, 2018. Given the Company’s intention to sell certain marketable securities, the Company recorded other-than-temporary impairment losses in fiscal 2017 for certain marketable securities, and no additional losses were recorded in the nine months ended June 24, 2018.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001728949-18-000075:notes:111]
Recent Accounting Pronouncements.

[0001728949-18-000075:notes:112]
Share-based Awards: In March 2016, the Financial Accounting Standards Board (FASB) issued new guidance that changed the accounting for share-based awards, including income taxes, classification of awards and classification in the statement of cash flows. The Company adopted the new guidance in the first quarter of fiscal 2018. In accordance with the new guidance, excess tax benefits or deficiencies associated with share-based awards are recognized through earnings when the awards vest or settle, rather than in stockholders’ equity. In the nine months ended June 24, 2018, net excess tax benefits associated with share-based awards of $15 million were recognized in the Company’s income tax provision. In addition, cash flows related to excess tax benefits are presented as an operating activity and cash payments made on an employee’s behalf for withheld shares are presented as financing activities, with the prior periods adjusted accordingly. As a result of these changes, amounts for the nine months ended June 25, 2017 have been adjusted as follows: net cash provided by operating activities increased by $301 million with a corresponding offset to net cash used in financing activities. The new guidance also impacts the Company’s earnings per share calculation as the estimate of dilutive common share equivalents under the treasury stock method no longer assumes that the estimated tax benefits realized when an award is settled are used to repurchase shares. There was no impact of this change on the Company’s calculation of earnings per share as a result of the net loss for the nine months ended June 24, 2018. The Company elected to continue its practice of estimating forfeitures expected to occur in determining the amount of compensation cost to be recognized each period.

[0001728949-18-000075:notes:113]
Revenue Recognition: In May 2014, the FASB issued new guidance related to revenue recognition, which outlines a comprehensive revenue recognition model and supersedes most current revenue recognition guidance. The new guidance requires a company to recognize revenue as control of goods or services transfers to a customer at an amount that reflects the expected consideration to be received in exchange for those goods or services. It defines a five-step approach for recognizing revenue, which may require a company to use more judgment and make more estimates than under the current guidance. The Company will adopt the new guidance in the first quarter of fiscal 2019 using the modified retrospective approach, with the cumulative effect of applying the new guidance recognized as an adjustment to the opening retained earnings balance. The Company is finalizing its identification of changes to policy, processes, systems and controls, as well as its assessment of data availability and presentation necessary to meet the additional disclosure requirements of the guidance in the notes to the consolidated financial statements.

[0001728949-18-000075:notes:114]
The Company currently expects the adoption of this new guidance to most significantly impact its licensing business (Qualcomm Technology Licensing, or QTL). Specifically, the Company expects a change in the timing of revenues recognized from sales-based royalties, which are the vast majority of QTL’s revenues. The Company currently recognizes sales-based royalties as revenues in the period in which such royalties are reported by licensees, which is after the conclusion of the quarter in which the licensees’ sales occur and when all other revenue recognition criteria are met. Under the new guidance, the Company will be required to estimate and recognize sales-based royalties in the period in which the associated sales occur, resulting in an acceleration of revenue recognition compared to the current method. As a result of recognizing royalty revenues based on estimates, adjustments to revenues will be required in subsequent periods based on the actual amounts reported by licensees. Upon adoption of the new guidance, licenses to use portions of the Company’s intellectual property portfolio will be considered one performance obligation, and license fees will be recognized as revenues on a straight-line basis over the estimated period of benefit of the license to the licensee, which is similar to the recognition of license revenues under the current guidance. The Company currently accounts for customer incentive arrangements in its licensing and semiconductor businesses, including volume-related and other pricing rebates or cost reimbursements for marketing and other activities involving certain of the Company’s products and technologies, in part based on the maximum potential liability. Under the new guidance, the Company will estimate the amount of all customer incentives. The Company does not otherwise expect the adoption of the new guidance to have a material impact on its businesses.

[0001728949-18-000075:notes:115]
Financial Assets: In January 2016, the FASB issued new guidance on classifying and measuring financial instruments, which requires that (i) all equity investments, other than equity-method investments, in unconsolidated entities generally be measured at fair value through earnings and (ii) when the fair value option has been elected for financial liabilities, changes in fair value due to instrument-specific credit risk be recognized separately in other comprehensive income. Additionally, it changes the disclosure requirements for financial instruments. For equity investments that do not have readily determinable fair values, the Company expects to use the measurement alternative, which is defined as cost, less impairments, adjusted by observable price changes in orderly transactions for identical or similar investments. The Company anticipates the adoption of the new guidance will increase the volatility of the Company’s investment and other income, net due to recording the changes in fair value of equity investments through earnings. The Company will adopt the new guidance in the first quarter of fiscal 2019 using the modified retrospective transition method for equity investments that have readily determinable fair values, with the cumulative effect of applying the new guidance recognized as an adjustment to opening retained earnings in the year of adoption, and the prospective transition method for equity investments that do not have readily determinable fair values. The Company is in the process of determining the effects the adoption will have on its consolidated financial statements.

[0001728949-18-000075:notes:116]
In June 2016, the FASB issued new guidance that changes the accounting for recognizing impairments of financial assets. Under the new guidance, credit losses for certain types of financial instruments will be estimated based on expected losses. The new guidance also modifies the impairment models for available-for-sale debt securities and for purchased financial assets with credit deterioration since their origination. The new guidance will be effective for the Company starting in the first quarter of fiscal 2021 and generally requires the modified retrospective transition method, with the cumulative effect of applying the new guidance recognized as an adjustment to opening retained earnings in the year of adoption, except for certain financial assets where the prospective transition method is required, such as available-for-sale debt securities for which an other-than-temporary impairment has been recorded. Early adoption is permitted starting in the first quarter of fiscal 2020. The Company is in the process of determining the effects the adoption will have on its consolidated financial statements and whether to adopt the new guidance early.

[0001728949-18-000075:notes:117]
Leases: In February 2016, the FASB issued new guidance related to leases that outlines a comprehensive lease accounting model and supersedes the current lease guidance. The new guidance requires lessees to recognize lease liabilities and corresponding right-of-use assets for all leases with lease terms of greater than 12 months. It also changes the definition of a lease and expands the disclosure requirements of lease arrangements. The Company will adopt the new guidance in the first quarter of fiscal 2020 and expects to use the modified retrospective approach, with the cumulative effect of applying the new guidance recognized as an adjustment to opening retained earnings in the year of adoption. The Company is in the process of determining the effects the adoption will have on its consolidated financial statements and whether to apply any of the optional practical expedients.

[0001728949-18-000075:notes:118]
Hedge Instruments: In August 2017, the FASB issued new guidance that expands and refines hedge accounting for both financial and non-financial risks, aligns the recognition and presentation of the effects of hedging instruments and hedged items in the financial statements, and includes targeted improvements related to the assessment of hedge effectiveness. The new guidance also modifies disclosure requirements for hedging activities. The Company plans to adopt the new guidance in the first quarter of fiscal 2019 using the modified retrospective transition method, with the cumulative effect of applying the new guidance recognized as an adjustment to opening retained earnings in the year of adoption, and does not expect the effects of the adoption to have a material impact on its consolidated financial statements.

[0001728949-18-000075:notes:119]
Other: In August 2016, the FASB issued new guidance related to the classification of certain cash receipts and cash payments on the statement of cash flows. The Company will adopt the new guidance in the first quarter of fiscal 2019 using the retrospective transition method for each period presented, and does not expect the effects of the adoption to have a material impact on its consolidated statements of cash flows.

[0001728949-18-000075:notes:120]
In October 2016, the FASB issued new guidance that changes the accounting for income tax effects of intra-entity transfers of assets other than inventory. Under the new guidance, the selling (transferring) entity is required to recognize a current tax expense or benefit upon transfer of the asset. Similarly, the purchasing (receiving) entity is required to recognize a deferred tax asset or deferred tax liability, as well as the related deferred tax benefit or expense, upon receipt of the asset. The Company will adopt the new guidance in the first quarter of fiscal 2019 using the modified retrospective transition method, with the cumulative effect of applying the new guidance recognized as an adjustment to opening retained earnings in the year of adoption, and is in the process of determining the effects the adoption will have on its consolidated financial statements.

[0001728949-18-000075:notes:121]
In November 2016, the FASB issued new guidance related to the classification and presentation of changes in restricted cash and cash equivalents in the statement of cash flows. The Company will adopt the new guidance in the first quarter of fiscal 2019 using the retrospective transition method for each period presented. At June 24, 2018, the Company had restricted cash and cash equivalents of $2.0 billion related to funds deposited as collateral for outstanding letters of credit in connection with the NXP Purchase Agreement (Note 8), and $2.8 billion related to irrevocably deposited cash to redeem notes in July 2018 (Note 5). Otherwise, the Company does not expect the effects of the retrospective adoption to have a material impact on its consolidated statements of cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001728949-18-000075:notes:122]
[same as prior period, unchanged from 0001728949-18-000039:notes:114]

[0001728949-18-000075:notes:123]
Financial Statement Preparation. These condensed consolidated financial statements have been prepared by QUALCOMM Incorporated (collectively with its subsidiaries, the Company or Qualcomm) in accordance with accounting principles generally accepted in the United States of America (GAAP) for interim financial information and the instructions to Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements. In the opinion of management, the interim financial information includes all normal recurring adjustments necessary for a fair statement of the results for the interim periods. These condensed consolidated financial statements are unaudited and should be read in conjunction with the Company’s Annual Report on Form 10-K for the fiscal year ended September 24, 2017. Operating results for interim periods are not necessarily indicative of operating results for an entire fiscal year. The Company operates and reports using a 52-53 week fiscal year ending on the last Sunday in September. Each of the three-month and nine-month periods ended June 24, 2018 and June 25, 2017 included 13 weeks and 39 weeks, respectively.

[0001728949-18-000075:notes:124]
[same as prior period, unchanged from 0001728949-18-000039:notes:116]

[0001728949-18-000075:notes:125]
Earnings (Loss) Per Common Share. Basic earnings (loss) per common share is computed by dividing net income (loss) attributable to Qualcomm by the weighted-average number of common shares outstanding during the reporting period. Diluted earnings per share is computed by dividing net income attributable to Qualcomm by the combination of dilutive common share equivalents, comprised of shares issuable under the Company’s share-based compensation plans, if any, and the weighted-average number of common shares outstanding during the reporting period. Due to the net loss for the nine months ended June 24, 2018, all of the common share equivalents issuable under share-based compensation plans had an anti-dilutive effect and were therefore excluded from the computation of diluted loss per share. The following table provides information about the diluted earnings per share calculation (in millions):

[0001728949-18-000075:notes:126]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 24, 2018 |  | June 25, 2017 |  | June 24, 2018 |  | June 25, 2017 |
| Dilutive common share equivalents included in diluted shares | 9.0 |  |  | 12.2 |  |  | — |  |  | 13.5 |  |
| Shares of common stock equivalents not included because the effect would be anti-dilutive or certain performance conditions were not satisfied at the end of the period | 0.6 |  |  | 0.6 |  |  | 43.2 |  |  | 3.8 |  |

[0001728949-18-000075:notes:127]
[same as prior period, unchanged from 0001728949-18-000039:notes:119]

[0001728949-18-000075:notes:128]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 24, 2018 |  | June 25, 2017 |  | June 24, 2018 |  | June 25, 2017 |
| Cost of revenues | $ | 9 |  |  | $ | 10 |  |  | $ | 30 |  |  | $ | 30 |  |
| Research and development | 140 |  |  | 147 |  |  | 447 |  |  | 455 |  |
| Selling, general and administrative | 40 |  |  | 70 |  |  | 182 |  |  | 227 |  |
| Share-based compensation expense before income taxes | 189 |  |  | 227 |  |  | 659 |  |  | 712 |  |
| Related income tax benefit | (34 | ) |  | (28 | ) |  | (111 | ) |  | (113 | ) |
|  | $ | 155 |  |  | $ | 199 |  |  | $ | 548 |  |  | $ | 599 |  |

[0001728949-18-000075:notes:129]
At June 24, 2018, total unrecognized compensation expense related to nonvested restricted stock units granted prior to that date was $1.1 billion, which is expected to be recognized over a weighted-average period of 1.9 years. At June 24, 2018, the Company had 23.8 million restricted stock units outstanding and 6.5 million stock options outstanding.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0001728949-18-000075:notes:130]
[same as prior period, unchanged from 0001728949-18-000039:notes:124]

[0001728949-18-000075:notes:131]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 24, 2018 |  | June 25, 2017 |  | June 24, 2018 |  | June 25, 2017 |
| Cost of revenues | $ | 127 |  |  | $ | 139 |  |  | $ | 335 |  |  | $ | 330 |  |
| Research and development expenses | 2 |  |  | 3 |  |  | 5 |  |  | 18 |  |
| Selling, general and administrative expenses | 20 |  |  | 77 |  |  | 310 |  |  | 195 |  |

[0001728949-18-000075:notes:132]
[same as prior period, unchanged from 0001728949-18-000039:notes:122]

[0001728949-18-000075:notes:133]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 24, 2018 |  | June 25, 2017 |  | June 24, 2018 |  | June 25, 2017 |
| Revenues |  |  |  |  |  |  |  |
| Nonreportable segments | $ | 77 |  |  | $ | 79 |  |  | $ | 238 |  |  | $ | 218 |  |
| Reduction to revenues related to BlackBerry arbitration decision | — |  |  | 12 |  |  | — |  |  | (962 | ) |
| Other unallocated revenues | (50 | ) |  | — |  |  | (50 | ) |  | — |  |
|  | $ | 27 |  |  | $ | 91 |  |  | $ | 188 |  |  | $ | (744 | ) |
| EBT |  |  |  |  |  |  |  |
| Reduction to revenues related to BlackBerry arbitration decision | $ | — |  |  | $ | 12 |  |  | $ | — |  |  | $ | (962 | ) |
| Other unallocated revenues | (50 | ) |  | — |  |  | (50 | ) |  | — |  |
| Unallocated cost of revenues | (135 | ) |  | (188 | ) |  | (362 | ) |  | (402 | ) |
| Unallocated research and development expenses | (293 | ) |  | (257 | ) |  | (844 | ) |  | (803 | ) |
| Unallocated selling, general and administrative expenses | (60 | ) |  | (197 | ) |  | (480 | ) |  | (481 | ) |
| Unallocated other expenses (Note 2) | (112 | ) |  | (9 | ) |  | (1,605 | ) |  | (962 | ) |
| Unallocated interest expense | (208 | ) |  | (130 | ) |  | (556 | ) |  | (325 | ) |
| Unallocated investment and other income, net | 255 |  |  | 239 |  |  | 461 |  |  | 646 |  |
| Nonreportable segments | (90 | ) |  | (96 | ) |  | (276 | ) |  | (283 | ) |
|  | $ | (693 | ) |  | $ | (626 | ) |  | $ | (3,712 | ) |  | $ | (3,572 | ) |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001728949-18-000075:notes:134]
[same as prior period, unchanged from 0001728949-18-000039:notes:126]

[0001728949-18-000075:notes:135]
In the second quarter of fiscal 2018, the Company announced a Cost Plan designed to align the Company’s cost structure to its long-term margin targets. As part of this plan, the Company has initiated a series of targeted actions across the Company’s businesses to reduce annual costs by $1 billion, excluding incremental costs resulting from any future acquisition of a business. The Company expects these cost reductions to be fully captured in fiscal 2019.

[0001728949-18-000075:notes:136]
During the nine months ended June 24, 2018, the Company recorded restructuring and restructuring-related charges of $422 million in other expenses (Note 2), which consisted of restructuring charges of $302 million, primarily related to severance costs, and restructuring-related charges of $120 million, primarily related to certain asset impairments. In connection with this plan, the Company expects to incur additional restructuring and restructuring-related charges of approximately $50 million to $150 million, which primarily consist of severance and consulting costs, and the vast majority of which are expected to be settled in cash.

[0001728949-18-000075:notes:137]
The restructuring accrual, a portion of which was included in payroll and other benefits related liabilities with the remainder included in other current liabilities, is expected to be substantially paid within the next 12 months. Changes in the restructuring accrual for fiscal 2018 were as follows (in millions):

[0001728949-18-000075:notes:138]
|  | Severance Costs |  | OtherCosts |  | Total |
| Beginning balance of restructuring accrual | $ | — |  |  | $ | — |  |  | $ | — |  |
| Costs | 283 |  |  | 17 |  |  | 300 |  |
| Cash payments | (48 | ) |  | (2 | ) |  | (50 | ) |
| Adjustments | 3 |  |  | (1 | ) |  | 2 |  |
| Ending balance of restructuring accrual | $ | 238 |  |  | $ | 14 |  |  | $ | 252 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001728949-18-000075:notes:139]
Changes in the components of accumulated other comprehensive income, net of income taxes, in stockholders’ equity in the nine months ended June 24, 2018 were as follows (in millions):

[0001728949-18-000075:notes:140]
|  | Foreign Currency Translation Adjustment |  | Noncredit Other-than-Temporary Impairment Losses and Subsequent Changes in Fair Value for Certain Available-for-Sale Debt Securities |  | Net Unrealized Gain (Loss) on Other Available-for-Sale Securities |  | Net Unrealized (Loss) Gain on Derivative Instruments |  | Other Gains |  | Total Accumulated Other Comprehensive Income |
| Balance at September 24, 2017 | $ | 147 |  |  | $ | 23 |  |  | $ | 218 |  |  | $ | (8 | ) |  | $ | 4 |  |  | $ | 384 |  |
| Other comprehensive (loss) income before reclassifications | (64 | ) |  | — |  |  | 2 |  |  | (3 | ) |  | — |  |  | (65 | ) |
| Reclassifications from accumulated other comprehensive income | — |  |  | 1 |  |  | (7 | ) |  | 10 |  |  | — |  |  | 4 |  |
| Other comprehensive (loss) income | (64 | ) |  | 1 |  |  | (5 | ) |  | 7 |  |  | — |  |  | (61 | ) |
| Balance at June 24, 2018 | $ | 83 |  |  | $ | 24 |  |  | $ | 213 |  |  | $ | (1 | ) |  | $ | 4 |  |  | $ | 323 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001728949-18-000075:notes:141]
[same as prior period, unchanged from 0001728949-18-000039:notes:131]

[0001728949-18-000075:notes:142]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 24, 2018 |  | June 25, 2017 |  | June 24, 2018 |  | June 25, 2017 |
| Revenues |  |  |  |  |  |  |  |
| QCT | $ | 4,087 |  |  | $ | 4,052 |  |  | $ | 12,635 |  |  | $ | 11,829 |  |
| QTL | 1,465 |  |  | 1,172 |  |  | 4,025 |  |  | 5,232 |  |
| QSI | 20 |  |  | 56 |  |  | 80 |  |  | 70 |  |
| Reconciling items | 27 |  |  | 91 |  |  | 188 |  |  | (744 | ) |
| Total | $ | 5,599 |  |  | $ | 5,371 |  |  | $ | 16,928 |  |  | $ | 16,387 |  |
| EBT |  |  |  |  |  |  |  |
| QCT | $ | 607 |  |  | $ | 575 |  |  | $ | 2,170 |  |  | $ | 1,774 |  |
| QTL | 1,049 |  |  | 854 |  |  | 2,786 |  |  | 4,346 |  |
| QSI | (7 | ) |  | 55 |  |  | 44 |  |  | 38 |  |
| Reconciling items | (693 | ) |  | (626 | ) |  | (3,712 | ) |  | (3,572 | ) |
| Total | $ | 956 |  |  | $ | 858 |  |  | $ | 1,288 |  |  | $ | 2,586 |  |

[0001728949-18-000075:notes:143]
|  | June 24, 2018 |  | September 24, 2017 |
| Assets |  |  |  |
| QCT | $ | 3,063 |  |  | $ | 3,830 |  |
| QTL | 1,801 |  |  | 1,735 |  |
| QSI | 1,153 |  |  | 1,037 |  |
| Reconciling items | 56,073 |  |  | 58,884 |  |
| Total | $ | 62,090 |  |  | $ | 65,486 |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0001728949-18-000075:notes:144]
Changes in stockholders’ equity in the nine months ended June 24, 2018 were as follows (in millions):

[0001728949-18-000075:notes:145]
|  | Total Stockholders’ Equity |
| Balance at September 24, 2017 | $ | 30,746 |  |
| Net loss | (4,371 | ) |
| Other comprehensive loss | (61 | ) |
| Common stock issued under employee benefit plans and related tax benefits | 393 |  |
| Share-based compensation | 699 |  |
| Tax withholdings related to vesting of share-based payments | (273 | ) |
| Dividends | (2,640 | ) |
| Stock repurchases | (1,425 | ) |
| Balance at June 24, 2018 | $ | 23,068 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001728949-18-000075:notes:146]
[same as prior period, unchanged from 0001728949-18-000039:notes:136]

[0001728949-18-000075:notes:147]
[same as prior period, unchanged from 0001728949-18-000039:notes:137]

[0001728949-18-000075:notes:148]
The Company evaluates the performance of its segments based on earnings (loss) before income taxes (EBT). In fiscal 2018, all of the costs related to pre-commercial research and development of 5G (fifth generation) technology, of which $124 million and $340 million was recorded in the three and nine months ended June 24, 2018, respectively, were included in unallocated corporate research and development expenses, whereas similar costs related to the research and development of other technology, including 3G (third generation) and 4G (fourth generation) technology, were recorded in the QCT and QTL segments.

[0001728949-18-000075:notes:149]
Other unallocated revenues in the three and nine months ended June 24, 2018 were comprised of a reduction to licensing revenues related to a portion of a business arrangement that resolved a legal dispute and were not allocated to a reportable segment in the Company’s management reports because it will not be considered in evaluating segment results.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001728949-18-000075:notes:150]
[same as prior period, unchanged from 0001728949-18-000039:notes:139]

[0001728949-18-000075:notes:151]
Accumulated Other Comprehensive Income. Changes in the components of accumulated other comprehensive income, net of income taxes, in stockholders’ equity in the nine months ended June 24, 2018 were as follows (in millions):

[0001728949-18-000075:notes:152]
Reclassifications from accumulated other comprehensive income related to available-for-sale securities were negligible in each the three and nine months ended June 24, 2018 and $71 million and $118 million in the three and nine months ended June 25, 2017, respectively, and were recorded in investment and other income, net (Note 2).

[0001728949-18-000075:notes:153]
Stock Repurchase Program. On May 9, 2018, the Company announced a stock repurchase program authorizing it to repurchase up to $10 billion of the Company’s common stock. The stock repurchase program has no expiration date. The $10 billion stock repurchase program replaced a $15 billion stock repurchase program announced on March 9, 2015, of which $1.2 billion remained authorized for repurchase under the prior program. In the nine months ended June 24, 2018 and June 25, 2017, the Company repurchased and retired 24.2 million and 16.7 million shares for $1.4 billion and $1.0 billion, respectively, before commissions. At June 24, 2018, $9.0 billion remained authorized for repurchase under the May 2018 stock repurchase program.

[0001728949-18-000075:notes:154]
If the Company has not received regulatory approval by the State Administration for Market Regulation in China (SAMR) or other material developments have not occurred, the Company expects to terminate the proposed acquisition of NXP Semiconductors N.V. (NXP) by Qualcomm River Holdings B.V. (Qualcomm River Holdings), an indirect, wholly owned subsidiary of QUALCOMM Incorporated (the NXP Acquisition) after July 25, 2018 at 11:59 p.m. New York time (Note 8). In the event the NXP Acquisition is terminated, the Company intends to implement a stock repurchase program to repurchase up to $30 billion of the Company’s outstanding common stock. This new stock repurchase program, if implemented, will have no expiration date and will replace the May 2018 stock repurchase program.

[0001728949-18-000075:notes:155]
Dividends. On July 12, 2018, the Company announced a cash dividend of $0.62 per share on the Company’s common stock, payable on September 26, 2018 to stockholders of record as of the close of business on September 5, 2018. In the nine months ended June 24, 2018 and June 25, 2017, dividends charged to retained earnings were as follows (in millions, except per share data):

[0001728949-18-000075:notes:156]
[same as prior period, unchanged from 0001728949-18-000039:notes:144]
