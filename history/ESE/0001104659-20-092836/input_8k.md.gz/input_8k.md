# ESE 8-K — 0001104659-20-092734 filed 2020-08-10

## item codes, every 8-K on or before 2020-08-10

- 2020-08-10 0001104659-20-092734 — 2.02, 7.01, 9.01
- 2020-05-06 0001104659-20-057442 — 2.02, 7.01, 8.01, 9.01
- 2020-02-04 0001104659-20-010640 — 2.02, 5.07, 7.01, 9.01
- 2020-01-07 0001104659-20-001789 — 2.01, 9.01
- 2019-11-19 0001104659-19-065437 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2019-11-18 0001104659-19-065096 — 1.01, 2.02, 7.01, 9.01
- 2019-09-30 0001144204-19-046523 — 1.01, 1.02, 2.03, 9.01
- 2019-08-08 0001144204-19-038567 — 2.02, 7.01, 9.01
- 2019-05-07 0001144204-19-024241 — 2.02, 5.02, 7.01, 9.01
- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2020-08-10

- none on or before 2020-08-10

## item 2.02 — earnings release, exhibit 99.1

[0001104659-20-092734:8k_2_02:1]
EX-99.1
2
tm2027029d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-20-092734:8k_2_02:2]
Exhibit 99.1

[0001104659-20-092734:8k_2_02:3]
| NEWS FROM |  |

[0001104659-20-092734:8k_2_02:4]
For more information contact:

[0001104659-20-092734:8k_2_02:5]
Kate Lowrey

[0001104659-20-092734:8k_2_02:6]
Director, Investor Relations

[0001104659-20-092734:8k_2_02:7]
ESCO Technologies Inc.

[0001104659-20-092734:8k_2_02:8]
(314)
213-7277

[0001104659-20-092734:8k_2_02:9]
ESCO ANNOUNCES THIRD QUARTER FISCAL
2020 RESULTS

[0001104659-20-092734:8k_2_02:10]
– Q3 2020 GAAP EPS $0.72 and
Adjusted EPS $0.76 –

[0001104659-20-092734:8k_2_02:11]
– Net Debt of $47 Million, Leverage
Ratio 0.95x, Liquidity of $700 Million –

[0001104659-20-092734:8k_2_02:12]
ST. LOUIS, August 10, 2020 – ESCO
Technologies Inc. (NYSE: ESE) (ESCO, or the Company) today reported its operating results for the third quarter ended June 30,
2020 (Q3 2020) compared to the third quarter ended June 30, 2019 (Q3 2019).

[0001104659-20-092734:8k_2_02:13]
COVID-19 Update

[0001104659-20-092734:8k_2_02:14]
Vic Richey, Chairman and Chief Executive
Officer, commented, “As we manage through the COVID-19 global pandemic, we continue to focus on the health and safety of
our employees, customers and suppliers, thereby securing the financial well-being of the Company and supporting business continuity.

[0001104659-20-092734:8k_2_02:15]
“While our businesses have obviously
been impacted by the pandemic, I’m proud of our employees’ commitment to supporting our customers’ essential
industries. Our entire organization has stepped up to the challenge and drove our strong operating performance which exceeded expectations.

[0001104659-20-092734:8k_2_02:16]
“Our solid results reflect the importance
of maintaining diversity across our end-markets, as this diversity, coupled with our strong balance sheet and substantial liquidity
are critical to managing today’s challenges. We were able to mitigate the earnings impact of Q3 2020’s sales decrease
because of our diversified, multi-segment approach. Coupled with effective cost management and solid operating execution, we reported
Q3 2020 Adjusted EBITDA of $35 million, consistent with Q3 2019’s Adjusted EBITDA.

[0001104659-20-092734:8k_2_02:17]
“We successfully worked our way through
a challenging quarter, and I’m confident that our well-tested operating model and our track record of taking effective cost
management actions to reduce spending and resize the business will position us for robust growth coming out of this downturn.

[0001104659-20-092734:8k_2_02:18]
“Our
deep and experienced leadership team has us well-positioned for the future as we continue to invest in our growth initiatives
both organically and through the deployment of capital on acquisitions. The long-term fundamentals of our portfolio remain strong
and our goal is to emerge from this current challenge as an even stronger company.”

[0001104659-20-092734:8k_2_02:19]
Q3 2020 Earnings Report

[0001104659-20-092734:8k_2_02:20]
On January 2, 2020, the Company announced
that it had completed the sale of its Technical Packaging segment effective December 31, 2019 which resulted in gross cash proceeds
of $191 million ($187 million purchase price plus working capital surplus) and a $77 million, or $2.93 per share net gain on the
sale in Q1 2020.

[0001104659-20-092734:8k_2_02:21]
The financial results presented include
certain non-GAAP financial measures such as EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS, as defined within the “Non-GAAP
Financial Measures” described below. Any non-GAAP financial measures presented are reconciled to their respective GAAP equivalents.

[0001104659-20-092734:8k_2_02:22]
Management believes these non-GAAP financial
measures are useful in assessing the ongoing operational profitability of the Company’s business segments, and therefore,
allow shareholders better visibility into the Company’s underlying operations. See “Non-GAAP Financial Measures”
described below.

[0001104659-20-092734:8k_2_02:23]
Q3 2020 GAAP EPS of $0.72 per share included
$1.2 million, or $0.04 per share of incremental costs related to COVID-19 spending. Excluding the $0.04 per share impact of these
discrete items resulted in Q3 2020 Adjusted EPS of $0.76 per share. Q3 2020 GAAP net earnings were $19 million.

[0001104659-20-092734:8k_2_02:24]
Q3 2019 GAAP EPS from continuing operations
of $0.73 per share included $0.02 per share of cost reduction charges described in prior releases. The net effect of excluding
the $0.02 per share of discrete items resulted in Q3 2019 Adjusted EPS of $0.75 per share, with GAAP net earnings from continuing
operations of $19 million.

[0001104659-20-092734:8k_2_02:25]
Q3 2020 Adjusted EBITDA was $35 million,
consistent with Q3 2019 Adjusted EBITDA of $35 million.

[0001104659-20-092734:8k_2_02:26]
Operating Highlights

[0001104659-20-092734:8k_2_02:27]
|  | · | Net sales decreased 3 percent to $173 million in Q3 2020 compared to $178 million in Q3 2019. |

[0001104659-20-092734:8k_2_02:28]
|  | · | Aerospace & Defense (A&D) segment sales increased $1 million from Q3 2019, including $8 million in sales from Globe, coupled with $2 million increased navy and space sales at Vacco, offset by lower commercial aerospace sales due to COVID-19. |

[0001104659-20-092734:8k_2_02:29]
|  | · | Test sales increased $4 million (9 percent) in Q3 2020 as a result of strong foreign chamber project sales. Sales increased to $46 million despite continuing timing delays on certain installation projects due to COVID-19 related customer closure mandates and on-site personnel restrictions at customer locations. |

[0001104659-20-092734:8k_2_02:30]
|  | · | USG sales decreased $10 million in Q3 2020 due to the timing / deferrals of various project deliverables as utility customers have re-aligned their short-term maintenance and spending protocols to focus on uninterrupted power delivery due to short-term electricity demand / mix changes between industrial, commercial and residential customers due to COVID-19. Maintenance deferrals also reflect various mandates restricting on-site personnel at substations, large transformers and other customer locations. |

[0001104659-20-092734:8k_2_02:31]
|  | · | SG&A expenses decreased $4 million (10 percent) in Q3 2020 driven by significant cost mitigation programs implemented to help offset the negative sales impact from COVID-19. SG&A as a percent of sales decreased to 21 percent in Q3 2020, from 23 percent in Q3 2019, despite the inclusion of Globe in the current period, and continued spending on R&D and new product development to enhance future growth. |

[0001104659-20-092734:8k_2_02:32]
|  | · | Q3 2020 non-cash amortization of intangible assets increased $1 million, or 25 percent compared to Q3 2019 as a result of the Globe acquisition being included in the Q3 2020 results. |

[0001104659-20-092734:8k_2_02:33]
|  | · | Interest expense decreased in Q3 2020 due to the lower net debt outstanding and favorable interest rates. |

[0001104659-20-092734:8k_2_02:34]
|  | · | The effective income tax rate was approximately 15 percent in Q3 2020 and 19 percent in Q3 2019 as both periods were favorably impacted by ongoing tax reduction initiatives. The Q3 2020 quarterly rate was lower than expected due to favorable one-time tax strategies implemented, primarily related to foreign sourced income. |

[0001104659-20-092734:8k_2_02:35]
|  | · | Entered orders were $158 million in Q3 2020 (book-to-bill of 0.91x), and were $624 million YTD 2020 (book-to-bill of 1.19x), resulting in an ending backlog of $551 million at June 30, 2020, an increase of $99 million, or 22 percent, from September 30, 2019. |

[0001104659-20-092734:8k_2_02:36]
|  | · | Q3 2020 net cash provided by operating activities from continuing operations was $54 million, and included a $10 million cash payment to partially fund the previously announced pension plan termination expected to be completed in Q4 2020. Net debt (total borrowings, less cash on hand) was $47 million at June 30, 2020 reflecting a 0.95x leverage ratio. |

[0001104659-20-092734:8k_2_02:37]
Chairman’s Commentary

[0001104659-20-092734:8k_2_02:38]
Vic Richey, Chairman and Chief Executive
Officer, commented, “The clear highlight of Q3 2020 was the strength of our Test segment with a sales increase of 9 percent
and an EBIT margin of nearly 16 percent. Our A&D segment demonstrated its resilience driven by its program, product and end-market
diversity, as the navy and defense markets remained strong which offset the decline in commercial aerospace. PTI, Crissair and
Mayday’s sales decline reflected the reduction in both OEM build rates and air traffic, while Globe, Vacco and Westland outperformed
on their navy / submarine platforms.

[0001104659-20-092734:8k_2_02:39]
“We expect the softness in commercial
aerospace deliveries to continue for the balance of the year, but the outlook is too uncertain to determine the sales and EBIT
impact from the current industry downturn. Recently, the commercial aerospace industry began seeing some initial signs of a recovery
emerging as several airlines are bringing more of their idled fleet back into service and daily passenger boardings have been increasing
over the past few months.

[0001104659-20-092734:8k_2_02:40]
“The defense portion of A&D, both
military aerospace and navy products, is expected to remain strong for the foreseeable future given its sizeable backlog coupled
with the timing of expected platform deliveries.

[0001104659-20-092734:8k_2_02:41]
“As noted above, Test reported another
solid quarter delivering a better than expected EBIT margin of nearly 16 percent, despite some delayed installation projects caused
by access limitations to customer sites.

[0001104659-20-092734:8k_2_02:42]
“We expect Test to remain relatively
solid over the remainder of the year given the strength of its backlog and its served markets, primarily related to new communications
technologies such as 5G and our growing shielding business. Our view of 5G’s future contributions to the Test business is
favorable given the size of the investments being made by numerous large, global companies leading the development of this robust
technology.

[0001104659-20-092734:8k_2_02:43]
“As expected, USG sales remained
soft in Q3 2020 as utility customers continued deferring purchase orders and maintenance-related projects so they can focus their
resources on issues such as critical power delivery. Given their mandate around COVID-19 travel and site access restrictions,
Doble’s service business is largely on hold until these personal safety risks can be reduced.

[0001104659-20-092734:8k_2_02:44]
“On the positive side,
Doble’s order pipeline of new business remains robust, especially as it relates to cyber security solutions such as the
DUCe, and I’m pleased to see the enthusiasm being generated in the market surrounding several new products and solutions
recently introduced. We are also seeing NRG’s end markets recovering as investments in renewable energy have been increasing
in both wind and solar. Our new products supporting solar have been growing far better than anticipated and we expect that growth
to continue.

[0001104659-20-092734:8k_2_02:45]
“We expect Doble’s customer
spending softness to continue for the next few quarters before returning to normal levels. We take comfort knowing that COVID-19
does not change the fundamentals of the global utility market as society needs reliable, safe and secure electricity. While customers
can defer testing and maintenance for a period of time, they cannot do it indefinitely without significantly increasing the risk
of catastrophic failure.

[0001104659-20-092734:8k_2_02:46]
“Looking forward, Doble is using this
temporary pause in the market to accelerate development of several new products and software solutions that we expect to introduce
over the next several quarters.

[0001104659-20-092734:8k_2_02:47]
“Commenting on the results, we were
able to maintain our consolidated Q3 2020 Adjusted EBITDA and increased our EBITDA margin to over 20 percent, despite the lower
contribution from our highest margin segment. Our Q3 2020 ending backlog remains strong at $551 million and increased from the
start of the year by nearly $100 million, or 22 percent, which helps protect against downside risks over the remainder of the year.

[0001104659-20-092734:8k_2_02:48]
“From a liquidity perspective, we
are in a really solid position given our significant cash balance, our low debt level and our conservative leverage ratio.

[0001104659-20-092734:8k_2_02:49]
“Given our solid financial condition
and our near-term cash generation outlook, we plan to use a portion of our liquidity and substantial debt capacity to fund future
acquisitions and grow our business. We continue to evaluate a robust pipeline of M&A opportunities, but given the current environment,
we are taking a particularly prudent and deliberate approach evaluating our near-term targets. As markets continue to settle down
and more clarity appears in our targeted end-markets, we are comfortable adding to our current portfolio and capitalizing on today’s
slightly lower valuations.

[0001104659-20-092734:8k_2_02:50]
“Despite the significant economic
challenges we, and everyone else, are facing today, we plan to capitalize on our history of proven cost management and believe
that we will benefit from our disciplined operating culture to minimize our risks throughout the remainder of the year. We will
continue to position ourselves favorably from a cost structure standpoint as we look toward 2021 as a return to a more normal operating
environment. I continue to have a favorable view of our future with our goal remaining unchanged – to increase long-term
shareholder value.”

[0001104659-20-092734:8k_2_02:51]
Dividend Payment

[0001104659-20-092734:8k_2_02:52]
The next
quarterly cash dividend of $0.08 per share will be paid on October 15, 2020 to stockholders of record on October 1, 2020.

[0001104659-20-092734:8k_2_02:53]
Business Outlook – Including COVID-19
Impact

[0001104659-20-092734:8k_2_02:54]
During Q2 2020, business disruptions related
to the pandemic started to affect the Company’s operations, and the disruptions continued throughout Q3 2020 as reflected
above. Given the continued uncertainty regarding the extent and duration of these economic circumstances, it is difficult to predict
how our future operations will be affected using our normal forecasting methodologies, therefore, the Company will continue the
suspension of fiscal year 2020 guidance.

[0001104659-20-092734:8k_2_02:55]
For 2020 financial reporting, the former
Technical Packaging business segment’s results of operations, gain on sale, balance sheet and cash flows are reported as
Discontinued Operations.

[0001104659-20-092734:8k_2_02:56]
Pension Plan Termination Update

[0001104659-20-092734:8k_2_02:57]
As previously announced, Management is using
a portion of the Technical Packaging divestiture proceeds to fully fund, terminate, and annuitize the defined benefit pension plan
(the Plan) currently maintained by the Company. Approximately $10 million was contributed in Q3 2020 toward the termination liability,
and the remaining cash balance is expected to be funded in Q4 2020.

[0001104659-20-092734:8k_2_02:58]
By initiating this process in November 2019,
the Company was able to convert the majority of the Plan assets (equities and bonds) to Cash in January and February thereby limiting
the impact of market volatility.

[0001104659-20-092734:8k_2_02:59]
As noted in previous releases, annuitizing
this non-strategic liability through an insurance company will eliminate both equity market risk and interest rate volatility,
thereby reducing ongoing costs and eliminating future cash payments.

[0001104659-20-092734:8k_2_02:60]
The Plan was frozen in 2003 and no additional
benefits have been accrued since that date.

[0001104659-20-092734:8k_2_02:61]
The Q4 2020 accounting impact of terminating
and annuitizing the pension will be excluded from the calculation of Adjusted EBITDA and Adjusted EPS.

[0001104659-20-092734:8k_2_02:62]
Conference Call

[0001104659-20-092734:8k_2_02:63]
The Company will host a conference call
today, August 10, at 4:00 p.m. Central Time, to discuss the Company’s Q3 2020 results. A live audio webcast will be available
on the Company’s website at www.escotechnologies.com. Please access the website at least 15 minutes prior to the call to
register, download and install any necessary audio software. A replay of the conference call will be available on the Company’s
website noted above or by phone (dial 1-855-859-2056 and enter the pass code 6423509).

[0001104659-20-092734:8k_2_02:64]
Forward-Looking Statements

[0001104659-20-092734:8k_2_02:65]
Statements in this press release regarding
the future impacts of COVID-19 on the Company’s results, the financial success of the Company, the strength of its end markets,
including without limitation the anticipated slowdown in commercial aerospace, actions in regard to the Company’s frozen
defined benefit pension plan, the ability to increase shareholder value, the success of acquisition efforts, the long-term success
of the Company, and any other statements which are not strictly historical are “forward-looking” statements within
the meaning of the safe harbor provisions of the federal securities laws.

[0001104659-20-092734:8k_2_02:66]
Investors are cautioned that such statements
are only predictions and speak only as of the date of this release, and the Company undertakes no duty to update them except as
may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from
those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and
business environment including but not limited to those described in Item 1A, “Risk Factors”, of the Company’s
Annual Report on Form 10-K for the fiscal year ended September 30, 2019, in Item 8.01 of the Company’s Form 8-K filed May
6, 2020, and the following: impacts arising from COVID-19 including without limitation labor shortages due to illness, shelter
in place policies or quarantines, material shortages, transportation delays, delays or termination of Company contracts, the inability
of our suppliers to perform, weakening of economic conditions in served markets; changes in customer demands or customer insolvencies;
competition; intellectual property rights; technical difficulties; delivery delays or defaults by customers; material changes in
the costs and availability of certain raw materials; the appropriation, allocation and availability of Government funds; the termination
for convenience of Government and other customer contracts; the timing and content of future contract awards or customer orders;
performance issues with key customers, suppliers and subcontractors; labor disputes; the impacts of natural disasters on the Company’s
operations and those of the Company’s customers and suppliers; changes in laws and regulations, including but not limited
to changes in accounting standards, taxation requirements, and new or modified tariffs; changes in interest rates; costs relating
to environmental matters arising from current or former facilities; the availability of select acquisitions; and the uncertainty
regarding the ultimate resolution of current disputes, claims, litigation or arbitration.

[0001104659-20-092734:8k_2_02:67]
Non-GAAP Financial Measures

[0001104659-20-092734:8k_2_02:68]
The financial measures EBIT, EBITDA, Adjusted
EBITDA and Adjusted EPS are presented in this press release. The Company defines “EBIT” as earnings before interest
and taxes, “EBITDA” as earnings before interest, taxes, depreciation and amortization, “Adjusted EBITDA”
as EBITDA excluding certain defined charges, and “Adjusted EPS” as GAAP earnings per share (EPS) excluding the net
impact of the items described above which were $0.06 per share in YTD 2020.

[0001104659-20-092734:8k_2_02:69]
EBIT, EBITDA, Adjusted EBITDA and Adjusted
EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management believes that
EBIT, EBITDA and Adjusted EBITDA are useful in assessing the operational profitability of the Company’s business segments
because they exclude interest, taxes, depreciation and amortization, which are generally accounted for across the entire Company
on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company
as well as incentive compensation. The presentation of EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS provides important supplemental
information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures
to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance
determined in accordance with GAAP.

[0001104659-20-092734:8k_2_02:70]
ESCO,
headquartered in St. Louis, Missouri: Manufactures highly-engineered filtration and fluid control products for the aviation, navy,
space and process markets worldwide, as well as composite-based products and solutions for navy, defense and industrial customers;
is the industry leader in RF shielding and EMC test products; and provides diagnostic instruments, software and services for the
benefit of industrial power users and the electric utility and renewable energy industries. Further information regarding ESCO
and its subsidiaries is available on the Company’s website at www.escotechnologies.com.

[0001104659-20-092734:8k_2_02:71]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-20-092734:8k_2_02:72]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-20-092734:8k_2_02:73]
(Dollars in
thousands, except per share amounts)

[0001104659-20-092734:8k_2_02:74]
|  |  | Three Months Ended June 30, 2020 |  |  | Three Months Ended June 30, 2019 |  |
| Net Sales |  | $ | 172,665 |  |  |  | 178,259 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 107,686 |  |  |  | 105,036 |  |
| Selling, general and administrative expenses |  |  | 36,936 |  |  |  | 41,226 |  |
| Amortization of intangible assets |  |  | 5,535 |  |  |  | 4,445 |  |
| Interest expense |  |  | 1,523 |  |  |  | 1,878 |  |
| Other expenses (income), net |  |  | (824 | ) |  |  | 2,007 |  |
| Total costs and expenses |  |  | 150,856 |  |  |  | 154,592 |  |
| Earnings before income taxes |  |  | 21,809 |  |  |  | 23,667 |  |
| Income tax expense |  |  | 3,122 |  |  |  | 4,622 |  |
| Earnings from continuing operations |  |  | 18,687 |  |  |  | 19,045 |  |
| Earnings from discontinued operations, net of tax expense of $203 |  |  | - |  |  |  | 1,022 |  |
| Net earnings |  | $ | 18,687 |  |  |  | 20,067 |  |
| Diluted EPS: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.72 |  |  |  | 0.73 |  |
| Discontinued operations |  |  | 0.00 |  |  |  | 0.04 |  |
| Net earnings |  | $ | 0.72 |  |  |  | 0.77 |  |
| Diluted - As Adjusted Basis |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.76 | (1) |  |  | 0.75 | (2) |
| Diluted average common shares O/S: |  |  | 26,134 |  |  |  | 26,109 |  |

[0001104659-20-092734:8k_2_02:75]
|  | (1) | Q3 FY 20 Adjusted EPS excludes $0.04 per share of after-tax charges incurred primarily within the A&D segment, USG segment and Corporate due to incremental costs associated with COVID-19 in the third quarter of fiscal 2020. |

[0001104659-20-092734:8k_2_02:76]
|  | (2) | Q3 FY 19 Adjusted EPS excludes $0.02 per share of after-tax restructuring charges incurred primarily at Doble, PTI and VACCO during the third quarter of fiscal 2019. |

[0001104659-20-092734:8k_2_02:77]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-20-092734:8k_2_02:78]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-20-092734:8k_2_02:79]
(Dollars in thousands, except per share amounts)

[0001104659-20-092734:8k_2_02:80]
|  |  | Nine Months Ended June 30, 2020 |  |  | Nine Months Ended June 30, 2019 |  |
| Net Sales |  | $ | 524,885 |  |  |  | 512,867 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 327,655 |  |  |  | 311,037 |  |
| Selling, general and administrative expenses |  |  | 119,023 |  |  |  | 119,093 |  |
| Amortization of intangible assets |  |  | 16,565 |  |  |  | 13,216 |  |
| Interest expense |  |  | 5,264 |  |  |  | 5,586 |  |
| Other expenses (income), net |  |  | 174 |  |  |  | (3,350 | ) |
| Total costs and expenses |  |  | 468,681 |  |  |  | 445,582 |  |
| Earnings before income taxes |  |  | 56,204 |  |  |  | 67,285 |  |
| Income tax expense |  |  | 8,931 |  |  |  | 13,068 |  |
| Earnings from continuing operations |  |  | 47,273 |  |  |  | 54,217 |  |
| (Loss) earnings from discontinued operations, net of tax expense of $269 and $255 |  |  | (601 | ) |  |  | 1,964 |  |
| Gain on sale of discontinued operations, net of tax expense of $23,734 |  |  | 76,614 |  |  |  | - |  |
| Earnings from discontinued operations |  |  | 76,013 |  |  |  | 1,964 |  |
| Net earnings |  | $ | 123,286 |  |  |  | 56,181 |  |
| Diluted EPS: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 1.81 |  |  |  | 2.07 |  |
| Discontinued operations |  |  | 2.91 |  |  |  | 0.08 |  |
| Net earnings |  | $ | 4.72 |  |  |  | 2.15 |  |
| Diluted - As Adjusted Basis Continuing operations |  | $ | 1.87 | (1) |  |  | 1.92 | (2) |
| Diluted average common shares O/S: |  |  | 26,130 |  |  |  | 26,090 |  |

[0001104659-20-092734:8k_2_02:81]
|  | (1) | YTD Q3 FY 20 Adjusted EPS excludes $0.06 per share of after-tax charges primarily related to the incremental costs associated with COVID-19 and charges related to the move of the Doble headquarters facility. |

[0001104659-20-092734:8k_2_02:82]
|  | (2) | YTD Q3 FY 19 Adjusted EPS excludes $0.15 per share of after-tax income mainly resulting from the gain on the sale of the Doble Watertown property partially offset by certain restructuring charges primarily at Doble, PTI and VACCO. |

[0001104659-20-092734:8k_2_02:83]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-20-092734:8k_2_02:84]
Condensed Business Segment Information (Unaudited)

[0001104659-20-092734:8k_2_02:85]
(Dollars in thousands)

[0001104659-20-092734:8k_2_02:86]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | Q3 2020 |  |  | Q3 2019 |  |  | Q3 2020 |  |  | Q3 2019 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 84,072 |  |  |  | 83,067 |  |  |  | 84,072 |  |  |  | 83,067 |  |
| Test |  |  | 46,016 |  |  |  | 42,298 |  |  |  | 46,016 |  |  |  | 42,298 |  |
| USG |  |  | 42,577 |  |  |  | 52,894 |  |  |  | 42,577 |  |  |  | 52,894 |  |
| Totals |  | $ | 172,665 |  |  |  | 178,259 |  |  |  | 172,665 |  |  |  | 178,259 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 17,409 |  |  |  | 19,039 |  |  |  | 18,224 |  |  |  | 19,344 |  |
| Test |  |  | 7,177 |  |  |  | 5,927 |  |  |  | 7,246 |  |  |  | 5,927 |  |
| USG |  |  | 6,156 |  |  |  | 10,148 |  |  |  | 6,316 |  |  |  | 10,467 |  |
| Corporate |  |  | (7,410 | ) |  |  | (9,569 | ) |  |  | (7,219 | ) |  |  | (9,374 | ) |
| Consolidated EBIT |  |  | 23,332 |  |  |  | 25,545 |  |  |  | 24,567 |  |  |  | 26,364 |  |
| Less: Interest expense |  |  | (1,523 | ) |  |  | (1,878 | ) |  |  | (1,523 | ) |  |  | (1,878 | ) |
| Less: Income tax expense |  |  | (3,122 | ) |  |  | (4,622 | ) |  |  | (3,418 | ) |  |  | (4,801 | ) |
| Net earnings from cont ops |  | $ | 18,687 |  |  |  | 19,045 |  |  |  | 19,626 |  |  |  | 19,685 |  |

[0001104659-20-092734:8k_2_02:87]
Note 1: Adjusted
net earnings were $19.6 million in Q3 FY 20 which excludes $0.9 million (or $0.04 per share) net impact of the incremental costs
associated with COVID-19 during the third quarter of 2020.

[0001104659-20-092734:8k_2_02:88]
Note 2: Adjusted
net earnings were $19.7 million in Q3 FY 19 which excludes $0.6 million (or $0.02 per share) net impact of the restructuring charges
incurred at Doble, PTI and VACCO during the third quarter of 2019.

[0001104659-20-092734:8k_2_02:89]
EBITDA Reconciliation to Net earnings:

[0001104659-20-092734:8k_2_02:90]
|  |  |  |  |  |  |  |  | Adjusted |  |  | Adjusted |  |
|  |  | Q3 2020 |  |  | Q3 2019 |  |  | Q3 2020 |  |  | Q3 2019 |  |
| Consolidated EBITDA |  | $ | 33,815 |  |  |  | 34,510 |  |  |  | 35,050 |  |  |  | 35,329 |  |
| Less: Depr & Amort |  |  | (10,483 | ) |  |  | (8,965 | ) |  |  | (10,483 | ) |  |  | (8,965 | ) |
| Consolidated EBIT |  |  | 23,332 |  |  |  | 25,545 |  |  |  | 24,567 |  |  |  | 26,364 |  |
| Less: Interest expense |  |  | (1,523 | ) |  |  | (1,878 | ) |  |  | (1,523 | ) |  |  | (1,878 | ) |
| Less: Income tax expense |  |  | (3,122 | ) |  |  | (4,622 | ) |  |  | (3,418 | ) |  |  | (4,801 | ) |
| Net earnings |  | $ | 18,687 |  |  |  | 19,045 |  |  |  | 19,626 |  |  |  | 19,685 |  |

[0001104659-20-092734:8k_2_02:91]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-20-092734:8k_2_02:92]
Condensed Business Segment Information (Unaudited)

[0001104659-20-092734:8k_2_02:93]
(Dollars in thousands)

[0001104659-20-092734:8k_2_02:94]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | YTD Q3 |  |  | YTD Q3 |  |  | YTD Q3 |  |  | YTD Q3 |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 256,707 |  |  |  | 228,769 |  |  |  | 256,707 |  |  |  | 228,769 |  |
| Test |  |  | 128,999 |  |  |  | 126,459 |  |  |  | 128,999 |  |  |  | 126,459 |  |
| USG |  |  | 139,179 |  |  |  | 157,639 |  |  |  | 139,179 |  |  |  | 157,639 |  |
| Totals |  | $ | 524,885 |  |  |  | 512,867 |  |  |  | 524,885 |  |  |  | 512,867 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 51,658 |  |  |  | 47,092 |  |  |  | 52,543 |  |  |  | 47,857 |  |
| Test |  |  | 17,483 |  |  |  | 14,791 |  |  |  | 17,552 |  |  |  | 14,791 |  |
| USG |  |  | 20,310 |  |  |  | 40,461 |  |  |  | 21,090 |  |  |  | 33,567 |  |
| Corporate |  |  | (27,983 | ) |  |  | (29,473 | ) |  |  | (27,792 | ) |  |  | (28,804 | ) |
| Consolidated EBIT |  |  | 61,468 |  |  |  | 72,871 |  |  |  | 63,393 |  |  |  | 67,411 |  |
| Less: Interest expense |  |  | (5,264 | ) |  |  | (5,586 | ) |  |  | (5,264 | ) |  |  | (5,586 | ) |
| Less: Income tax expense |  |  | (8,931 | ) |  |  | (13,068 | ) |  |  | (9,393 | ) |  |  | (11,517 | ) |
| Net earnings from cont ops |  | $ | 47,273 |  |  |  | 54,217 |  |  |  | 48,736 |  |  |  | 50,308 |  |

[0001104659-20-092734:8k_2_02:95]
Note 1: Adjusted
net earnings were $48.7 million in YTD Q3 FY 20 which excludes $1.5 million (or $0.06 per share) net impact of the incremental
costs associated with COVID-19 and charges related to the move of the Doble headquarters facility.

[0001104659-20-092734:8k_2_02:96]
Note 2: Adjusted net earnings
were $50.3 million in YTD Q3 FY 19 which excludes $3.9 million (or $0.15 per share) net impact of the gain on the sale of the
Doble Watertown property partially offset by charges related to restructuring actions at Doble, PTI & VACCO.

[0001104659-20-092734:8k_2_02:97]
EBITDA Reconciliation to Net earnings:

[0001104659-20-092734:8k_2_02:98]
|  |  |  |  |  |  |  |  | Adjusted |  |  | Adjusted |  |
|  |  | YTD Q3 |  |  | YTD Q3 |  |  | YTD Q3 |  |  | YTD Q3 |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Consolidated EBITDA |  | $ | 92,534 |  |  |  | 98,673 |  |  |  | 94,459 |  |  |  | 93,213 |  |
| Less: Depr & Amort |  |  | (31,066 | ) |  |  | (25,802 | ) |  |  | (31,066 | ) |  |  | (25,802 | ) |
| Consolidated EBIT |  |  | 61,468 |  |  |  | 72,871 |  |  |  | 63,393 |  |  |  | 67,411 |  |
| Less: Interest expense |  |  | (5,264 | ) |  |  | (5,586 | ) |  |  | (5,264 | ) |  |  | (5,586 | ) |
| Less: Income tax expense |  |  | (8,931 | ) |  |  | (13,068 | ) |  |  | (9,393 | ) |  |  | (11,517 | ) |
| Net earnings |  | $ | 47,273 |  |  |  | 54,217 |  |  |  | 48,736 |  |  |  | 50,308 |  |

[0001104659-20-092734:8k_2_02:99]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-20-092734:8k_2_02:100]
Condensed Consolidated Balance Sheets (Unaudited)

[0001104659-20-092734:8k_2_02:101]
(Dollars in thousands)

[0001104659-20-092734:8k_2_02:102]
|  |  | June 30, 2020 |  |  | September 30, 2019 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 104,739 |  |  |  | 61,808 |  |
| Accounts receivable, net |  |  | 138,080 |  |  |  | 158,715 |  |
| Contract assets |  |  | 101,533 |  |  |  | 110,211 |  |
| Inventories |  |  | 152,264 |  |  |  | 124,956 |  |
| Other current assets |  |  | 16,868 |  |  |  | 14,190 |  |
| Assets of discontinued operations-current |  |  | - |  |  |  | 25,314 |  |
| Total current assets |  |  | 513,484 |  |  |  | 495,194 |  |
| Property, plant and equipment, net |  |  | 141,461 |  |  |  | 127,843 |  |
| Intangible assets, net |  |  | 370,100 |  |  |  | 381,605 |  |
| Goodwill |  |  | 389,942 |  |  |  | 390,256 |  |
| Operating lease assets |  |  | 18,351 |  |  |  | - |  |
| Other assets |  |  | 11,247 |  |  |  | 4,445 |  |
| Assets of discontinued operations-other |  |  | - |  |  |  | 67,377 |  |
|  |  | $ | 1,444,585 |  |  |  | 1,466,720 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt |  | $ | 21,577 |  |  |  | 20,000 |  |
| Accounts payable |  |  | 54,305 |  |  |  | 63,800 |  |
| Contract liabilities |  |  | 87,421 |  |  |  | 81,177 |  |
| Other current liabilities |  |  | 79,112 |  |  |  | 75,141 |  |
| Liabilities of discontinued operations-current |  |  | - |  |  |  | 11,517 |  |
| Total current liabilities |  |  | 242,415 |  |  |  | 251,635 |  |
| Deferred tax liabilities |  |  | 65,954 |  |  |  | 60,856 |  |
| Non-current operating lease liabilities |  |  | 14,357 |  |  |  | - |  |
| Other liabilities |  |  | 48,402 |  |  |  | 59,008 |  |
| Long-term debt |  |  | 130,000 |  |  |  | 265,000 |  |
| Liabilities of discontinued operations-other |  |  | - |  |  |  | 3,999 |  |
| Shareholders' equity |  |  | 943,457 |  |  |  | 826,222 |  |
|  |  | $ | 1,444,585 |  |  |  | 1,466,720 |  |

[0001104659-20-092734:8k_2_02:103]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-20-092734:8k_2_02:104]
Consolidated Statements of Cash Flows (Unaudited)

[0001104659-20-092734:8k_2_02:105]
(Dollars in thousands)

[0001104659-20-092734:8k_2_02:106]
|  |  | Nine Months Ended June 30, 2020 |  |
| Cash flows from operating activities: |  |  |  |  |
| Net earnings |  | $ | 123,286 |  |
| Earnings from discontinued operations |  |  | (76,013 | ) |
| Adjustments to reconcile net earnings to net cash provided by operating activities: |  |  |  |  |
| Depreciation and amortization |  |  | 31,066 |  |
| Stock compensation expense |  |  | 4,184 |  |
| Changes in assets and liabilities |  |  | (20,926 | ) |
| Effect of deferred taxes |  |  | 2,155 |  |
| Pension contributions related to terminated pension plan |  |  | (10,000 | ) |
| Net cash provided by operating activities - continuing operations |  |  | 53,752 |  |
| Net cash used by operating activities - discontinued operations |  |  | (14,737 | ) |
| Cash flows from investing activities: |  |  |  |  |
| Capital expenditures |  |  | (28,291 | ) |
| Additions to capitalized software |  |  | (6,564 | ) |
| Net cash used by investing activities - continuing operations |  |  | (34,855 | ) |
| Proceeds from sale of discontinued operations |  |  | 183,812 |  |
| Capital expenditures - discontinued operations |  |  | (1,728 | ) |
| Net cash provided by investing activities - discontinued operations |  |  | 182,084 |  |
| Net cash provided by investing activities |  |  | 147,229 |  |
| Cash flows from financing activities: |  |  |  |  |
| Proceeds from long-term debt and short-term borrowings |  |  | 11,577 |  |
| Principal payments on long-term debt |  |  | (145,000 | ) |
| Dividends paid |  |  | (6,240 | ) |
| Other |  |  | (3,127 | ) |
| Net cash used by financing activities - continuing operations |  |  | (142,790 | ) |
| Net cash used by financing activities - discontinued operations |  |  | (2,140 | ) |
| Net cash used by financing activities |  |  | (144,930 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 1,617 |  |
| Net increase in cash and cash equivalents |  |  | 42,931 |  |
| Cash and cash equivalents, beginning of period |  |  | 61,808 |  |
| Cash and cash equivalents, end of period |  | $ | 104,739 |  |

[0001104659-20-092734:8k_2_02:107]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-20-092734:8k_2_02:108]
Other Selected Financial Data (Unaudited)  -- Continuing Operations Basis

[0001104659-20-092734:8k_2_02:109]
(Dollars in thousands)

[0001104659-20-092734:8k_2_02:110]
| Backlog And Entered Orders - Q3 FY 2020 |  | Aerospace & Defense |  |  | Test |  |  | USG |  |  | Total |  |
| Beginning Backlog - 4/1/20 |  | $ | 388,644 |  |  |  | 130,888 |  |  |  | 45,862 |  |  |  | 565,394 |  |
| Entered Orders |  |  | 65,857 |  |  |  | 41,538 |  |  |  | 50,424 |  |  |  | 157,819 |  |
| Sales |  |  | (84,072 | ) |  |  | (46,016 | ) |  |  | (42,577 | ) |  |  | (172,665 | ) |
| Ending Backlog - 6/30/20 |  | $ | 370,429 |  |  |  | 126,410 |  |  |  | 53,709 |  |  |  | 550,548 |  |
| Backlog And Entered Orders - YTD Q3 FY 2020 |  | Aerospace & Defense |  |  | Test |  |  | USG |  |  | Total |  |
| Beginning Backlog - 10/1/19 |  | $ | 276,273 |  |  |  | 133,571 |  |  |  | 41,715 |  |  |  | 451,559 |  |
| Entered Orders |  |  | 350,863 |  |  |  | 121,838 |  |  |  | 151,173 |  |  |  | 623,874 |  |
| Sales |  |  | (256,707 | ) |  |  | (128,999 | ) |  |  | (139,179 | ) |  |  | (524,885 | ) |
| Ending Backlog - 6/30/20 |  | $ | 370,429 |  |  |  | 126,410 |  |  |  | 53,709 |  |  |  | 550,548 |  |

[0001104659-20-092734:8k_2_02:111]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-20-092734:8k_2_02:112]
Reconciliation of
Non-GAAP Financial Measures (Unaudited)

[0001104659-20-092734:8k_2_02:113]
| EPS – Adjusted Basis Reconciliation – Q3 FY 20 |  |  |  |  |
| EPS from Continuing Ops – GAAP Basis – Q3 FY 20 |  | $ | 0.72 |  |
| Adjustments (defined below) |  |  | 0.04 |  |
| EPS from Continuing Ops – As Adjusted Basis – Q3 FY 20 |  | $ | 0.76 |  |

[0001104659-20-092734:8k_2_02:114]
Adjustments
exclude $0.04 per share consisting primarily of incremental costs associated with COVID-19 in the third quarter of 2020. (The
$0.04 of EPS adjustments per share consists of $1,235K of pre-tax charges offset by $296K of tax benefit for net impact of
$939K.)

[0001104659-20-092734:8k_2_02:115]
| EPS – Adjusted Basis Reconciliation – YTD Q3 FY 20 |  |  |  |  |
| EPS from Continuing Ops – GAAP Basis – YTD Q3 20 |  | $ | 1.81 |  |
| Adjustments (defined below) |  |  | 0.06 |  |
| EPS from Continuing Ops – As Adjusted Basis – YTD Q3 20 |  | $ | 1.87 |  |

[0001104659-20-092734:8k_2_02:116]
Adjustments
exclude $0.06 per share consisting of incremental costs associated with COVID-19 and move costs associated with the Doble
facility consolidation in the first nine months of 2020. (The $0.06 of EPS adjustments per share consists of $1,925K of
pre-tax charges offset by $462K of tax benefit for net impact of $1,463K.)

[0001104659-20-092734:8k_2_02:117]
| EPS – Adjusted Basis Reconciliation – Q3 FY 19 |  |  |  |  |
| EPS from Continuing Ops – GAAP Basis – Q3 FY 19 |  | $ | 0.73 |  |
| Adjustments (defined below) |  |  | 0.02 |  |
| EPS from Continuing Ops – As Adjusted Basis – Q3 FY 19 |  | $ | 0.75 |  |

[0001104659-20-092734:8k_2_02:118]
Adjustments
exclude $0.02 per share consisting of restructuring charges related to Doble, PTI & VACCO during the third quarter of
2019. (The $0.02 of EPS adjustments per share consists of $819K of pre-tax charges offset by $179K of tax benefit for net
impact of $640K.)

[0001104659-20-092734:8k_2_02:119]
| EPS – Adjusted Basis Reconciliation – YTD Q3 FY 19 |  |  |  |  |
| EPS from Continuing Ops – GAAP Basis – YTD Q3 FY 19 |  | $ | 2.07 |  |
| Adjustments (defined below) |  |  | (0.15 | ) |
| EPS from Continuing Ops – As Adjusted Basis – YTD Q3 FY 19 |  | $ | 1.92 |  |

[0001104659-20-092734:8k_2_02:120]
Adjustments exclude $0.15 per share consisting of income related
to the gain on sale of the Doble Watertown property partially offset by certain restructuring charges at Doble, PTI & VACCO
in the first nine months of 2019. (The $0.15 of EPS adjustments per share consists of $5.5 million of pre-tax income and $1.6
million of tax expense for net impact of $3.9 million.)
