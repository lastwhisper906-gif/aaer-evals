# ESE note change history — 0001104659-20-058660 → 0001104659-20-092836


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-08-10):
[0001104659-20-092836:note_history:1]
The Company’s results for the three-month period ended June 30, 2020 are not necessarily indicative of the results for the entire 2020 fiscal year. References to the third quarters of 2020 and 2019 represent the fiscal quarters ended June 30, 2020 and 2019, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.
  (was, 2020-05-08, similarity 0.9717):
[0001104659-20-058660:note_history:1]
The Company’s results for the three-month period ended March 31, 2020 are not necessarily indicative of the results for the entire 2020 fiscal year. References to the second quarters of 2020 and 2019 represent the fiscal quarters ended March 31, 2020 and 2019, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.

- changed (2020-08-10):
[0001104659-20-092836:note_history:2]
Beginning in the first quarter of 2020, Management has renamed the Filtration / Fluid Flow (Filtration) segment as Aerospace & Defense (A&D) to better reflect the composition of the segment’s products, end markets and customer characteristics. The A&D segment’s individual legal and operating entities, historical financial results, and management structure are unchanged from what was formerly presented as Filtration.
  (was, 2020-05-08, similarity 0.9784):
[0001104659-20-058660:note_history:2]
Beginning in the first quarter of 2020, Management has renamed the Filtration / Fluid Flow (Filtration) segment as Aerospace & Defense (A&D) to better reflect the composition of the segment’s products, end markets and customer characteristics. The A&D’s segment’s individual legal and operating entities, historical financial results, and management structure are unchanged from what was formerly presented as Filtration.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-08-10):
[0001104659-20-092836:note_history:3]
| ​ |  | June 30, | ​ | September 30, |
| (In thousands) | ​ | 2020 |  | 2019 |
| Total borrowings | ​ | $ | 151,577 |  | 285,000 |
| Current portion of long-term debt and short-term borrowings | ​ |  | (21,577) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 130,000 |  | 265,000 |
  (was, 2020-05-08, similarity 0.7515):
[0001104659-20-058660:note_history:3]
| ​ | ​ | March 31, | ​ | September 30, |
| (In thousands) |  | 2020 |  | 2019 |
| Total borrowings | ​ | $ | 150,000 |  | ​ | 285,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 130,000 |  | ​ | 265,000 |

- changed (2020-08-10):
[0001104659-20-092836:note_history:4]
On September 27, 2019, the Company entered into a new five-year credit facility (“the Credit Facility”), modifying its previous credit facility which would have matured December 21, 2020. The Credit Facility includes a $500 million revolving line of credit, as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024.
  (was, 2020-05-08, similarity 0.9992):
[0001104659-20-058660:note_history:4]
On September 27, 2019, the Company entered into a new five-year credit facility (“the Credit Facility”), modifying its previous credit facility which would have matured December 21, 2020. The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024.

- changed (2020-08-10):
[0001104659-20-092836:note_history:5]
At June 30, 2020, the Company had approximately $340 million available to borrow under the Credit Facility, plus the $250 million increase option, subject to lender approval, in addition to $104.7 million cash on hand. The Company classified $20.0 million as the current portion of long-term debt as of June 30, 2020, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $9.9 million at June 30, 2020.
  (was, 2020-05-08, similarity 0.9696):
[0001104659-20-058660:note_history:5]
At March 31, 2020, the Company had approximately $341 million available to borrow under the Credit Facility, plus the $250 million increase option, subject to lender approval, in addition to $100.2 million cash on hand. The Company classified $20.0 million as the current portion of long-term debt as of March 31, 2020, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $9.8 million at March 31, 2020.

- changed (2020-08-10):
[0001104659-20-092836:note_history:6]
Interest on borrowings under the Credit Facility is calculated at a spread over either the London Interbank Offered Rate (LIBOR ), the New York Federal Reserve Bank Rate or the prime rate, depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The Credit Facility is secured by the unlimited guaranty of the Company’s direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of its direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 3.24% and 3.22% for the three and  nine-month periods ending June 30, 2020, respectively , and 3.21% and 3.22% for the three and nine-month periods ending June 30, 2019. As of June 30, 2020, the Company was in compliance with all covenants.
  (was, 2020-05-08, similarity 0.9655):
[0001104659-20-058660:note_history:6]
Interest on borrowings under the Credit Facility is calculated at a spread over either the London Interbank Offered Rate (LIBOR ), the New York Federal Reserve Bank Rate or the prime rate, depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The Credit Facility is secured by the unlimited guaranty of the Company’s direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of its direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 3.24% and 3.21% for the three and  six-month periods ending March 31, 2020, respectively , and 3.20% and 3.23% for the three and six-month periods ending March 31, 2019. As of March 31, 2020, the Company was in compliance with all covenants.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-08-10):
[0001104659-20-092836:note_history:7]
| ​ |  | June 30, | ​ | September 30, |
| (In thousands) | ​ | 2020 |  | 2019 |
| Total borrowings | ​ | $ | 151,577 |  | 285,000 |
| Current portion of long-term debt and short-term borrowings | ​ |  | (21,577) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 130,000 |  | 265,000 |
  (was, 2020-05-08, similarity 0.7515):
[0001104659-20-058660:note_history:7]
| ​ | ​ | March 31, | ​ | September 30, |
| (In thousands) |  | 2020 |  | 2019 |
| Total borrowings | ​ | $ | 150,000 |  | ​ | 285,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 130,000 |  | ​ | 265,000 |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-08-10):
[0001104659-20-092836:note_history:8]
| Three Months Ended June 30, 2020 |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | Test | ​ | USG | ​ | Total | ​ |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 37,485 | ​ | $ | 38,737 | ​ | $ | 39,740 | ​ | $ | 115,962 | ​ |
| U.S. Government | ​ |  | 46,587 | ​ | ​ | 7,279 | ​ | ​ | 2,837 | ​ |  | 56,703 | ​ |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 46,016 | ​ | $ | 42,577 | ​ | $ | 172,665 | ​ |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| United States | ​ | $ | 73,476 | ​ | $ | 19,441 | ​ | $ | 26,499 | ​ | $ | 119,416 | ​ |
| International | ​ |  | 10,596 | ​ | ​ | 26,575 | ​ | ​ | 16,078 | ​ |  | 53,249 | ​ |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 46,016 | ​ | $ | 42,577 | ​ | $ | 172,665 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 36,461 | ​ | $ | 9,138 | ​ | $ | 27,765 | ​ | $ | 73,364 | ​ |
| Over time | ​ |  | 47,611 | ​ | ​ | 36,878 | ​ | ​ | 14,812 | ​ |  | 99,301 | ​ |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 46,016 | ​ | $ | 42,577 | ​ | $ | 172,665 | ​ |
  (was, 2020-05-08, similarity 0.8611):
[0001104659-20-058660:note_history:8]
| Three months ended March 31, 2020 |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | Test | ​ | USG | ​ | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 51,550 | ​ | $ | 33,952 | ​ | $ | 43,736 | ​ | $ | 129,238 |
| U.S. Government | ​ |  | 43,574 | ​ | ​ | 7,648 | ​ | ​ | 32 | ​ |  | 51,254 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 41,600 | ​ | $ | 43,768 | ​ | $ | 180,492 |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |
| United States | ​ | $ | 81,458 | ​ | $ | 25,121 | ​ | $ | 28,706 | ​ | $ | 135,285 |
| International | ​ |  | 13,666 | ​ | ​ | 16,479 | ​ | ​ | 15,062 | ​ |  | 45,207 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 41,600 | ​ | $ | 43,768 | ​ | $ | 180,492 |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 46,610 | ​ | $ | 8,009 | ​ | $ | 32,209 | ​ | $ | 86,828 |
| Over time | ​ |  | 48,514 | ​ | ​ | 33,591 | ​ | ​ | 11,559 | ​ |  | 93,664 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 41,600 | ​ | $ | 43,768 | ​ | $ | 180,492 |

- changed (2020-08-10):
[0001104659-20-092836:note_history:9]
| Nine Months Ended June 30, 2020 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | Test |  | USG |  | Total | ​ |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 130,817 | ​ | $ | 107,931 | ​ | $ | 135,711 | ​ | $ | 374,459 | ​ |
| U.S. Government | ​ |  | 125,890 | ​ |  | 21,068 | ​ |  | 3,468 | ​ |  | 150,426 | ​ |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 128,999 | ​ | $ | 139,179 | ​ | $ | 524,885 | ​ |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |
| United States | ​ | $ | 219,640 | ​ | $ | 69,399 | ​ | $ | 90,155 | ​ | $ | 379,194 | ​ |
| International | ​ |  | 37,067 | ​ |  | 59,600 | ​ |  | 49,024 | ​ |  | 145,691 | ​ |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 128,999 | ​ | $ | 139,179 | ​ | $ | 524,885 | ​ |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |
| Point in time | ​ | $ | 118,660 | ​ | $ | 26,157 | ​ | $ | 100,289 | ​ | $ | 245,106 | ​ |
| Over time | ​ |  | 138,047 | ​ |  | 102,842 | ​ |  | 38,890 | ​ |  | 279,779 | ​ |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 128,999 | ​ | $ | 139,179 | ​ | $ | 524,885 | ​ |
  (was, 2020-05-08, similarity 0.7012):
[0001104659-20-058660:note_history:9]
| Six months ended March 31, 2020 |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | Test | ​ | USG | ​ | Total |
| Customer type: |  | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| Commercial | ​ | $ | 93,417 | ​ | $ | 69,194 | ​ | $ | 95,971 | ​ | $ | 258,582 |
| U.S. Government | ​ |  | 79,218 | ​ | ​ | 13,789 | ​ | ​ | 631 | ​ |  | 93,638 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 82,983 | ​ | $ | 96,602 | ​ | $ | 352,220 |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |
| United States | ​ | $ | 146,164 | ​ | $ | 49,959 | ​ | $ | 63,665 | ​ | $ | 259,788 |
| International | ​ |  | 26,471 | ​ | ​ | 33,024 | ​ | ​ | 32,937 | ​ |  | 92,432 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 82,983 | ​ | $ | 96,602 | ​ | $ | 352,220 |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 82,897 | ​ | $ | 17,019 | ​ | $ | 72,524 | ​ | $ | 172,440 |
| Over time | ​ |  | 89,738 | ​ | ​ | 65,964 | ​ | ​ | 24,078 | ​ |  | 179,780 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 82,983 | ​ | $ | 96,602 | ​ | $ | 352,220 |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-08-10):
[0001104659-20-092836:note_history:10]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2020 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also include a reconciliation of the disaggregated revenue within each reportable segment on a continuing operations basis.
  (was, 2020-05-08, similarity 0.9822):
[0001104659-20-058660:note_history:10]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2020 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also include a reconciliation of the disaggregated revenue within each reportable segment on a continuing operations basis.

- changed (2020-08-10):
[0001104659-20-092836:note_history:11]
| Three Months Ended June 30, 2020 |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | Test | ​ | USG | ​ | Total | ​ |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 37,485 | ​ | $ | 38,737 | ​ | $ | 39,740 | ​ | $ | 115,962 | ​ |
| U.S. Government | ​ |  | 46,587 | ​ | ​ | 7,279 | ​ | ​ | 2,837 | ​ |  | 56,703 | ​ |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 46,016 | ​ | $ | 42,577 | ​ | $ | 172,665 | ​ |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| United States | ​ | $ | 73,476 | ​ | $ | 19,441 | ​ | $ | 26,499 | ​ | $ | 119,416 | ​ |
| International | ​ |  | 10,596 | ​ | ​ | 26,575 | ​ | ​ | 16,078 | ​ |  | 53,249 | ​ |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 46,016 | ​ | $ | 42,577 | ​ | $ | 172,665 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 36,461 | ​ | $ | 9,138 | ​ | $ | 27,765 | ​ | $ | 73,364 | ​ |
| Over time | ​ |  | 47,611 | ​ | ​ | 36,878 | ​ | ​ | 14,812 | ​ |  | 99,301 | ​ |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 46,016 | ​ | $ | 42,577 | ​ | $ | 172,665 | ​ |
  (was, 2020-05-08, similarity 0.8611):
[0001104659-20-058660:note_history:11]
| Three months ended March 31, 2020 |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | Test | ​ | USG | ​ | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 51,550 | ​ | $ | 33,952 | ​ | $ | 43,736 | ​ | $ | 129,238 |
| U.S. Government | ​ |  | 43,574 | ​ | ​ | 7,648 | ​ | ​ | 32 | ​ |  | 51,254 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 41,600 | ​ | $ | 43,768 | ​ | $ | 180,492 |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |
| United States | ​ | $ | 81,458 | ​ | $ | 25,121 | ​ | $ | 28,706 | ​ | $ | 135,285 |
| International | ​ |  | 13,666 | ​ | ​ | 16,479 | ​ | ​ | 15,062 | ​ |  | 45,207 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 41,600 | ​ | $ | 43,768 | ​ | $ | 180,492 |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 46,610 | ​ | $ | 8,009 | ​ | $ | 32,209 | ​ | $ | 86,828 |
| Over time | ​ |  | 48,514 | ​ | ​ | 33,591 | ​ | ​ | 11,559 | ​ |  | 93,664 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 41,600 | ​ | $ | 43,768 | ​ | $ | 180,492 |

- changed (2020-08-10):
[0001104659-20-092836:note_history:12]
| Nine Months Ended June 30, 2020 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | Test |  | USG |  | Total | ​ |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 130,817 | ​ | $ | 107,931 | ​ | $ | 135,711 | ​ | $ | 374,459 | ​ |
| U.S. Government | ​ |  | 125,890 | ​ |  | 21,068 | ​ |  | 3,468 | ​ |  | 150,426 | ​ |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 128,999 | ​ | $ | 139,179 | ​ | $ | 524,885 | ​ |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |
| United States | ​ | $ | 219,640 | ​ | $ | 69,399 | ​ | $ | 90,155 | ​ | $ | 379,194 | ​ |
| International | ​ |  | 37,067 | ​ |  | 59,600 | ​ |  | 49,024 | ​ |  | 145,691 | ​ |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 128,999 | ​ | $ | 139,179 | ​ | $ | 524,885 | ​ |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |
| Point in time | ​ | $ | 118,660 | ​ | $ | 26,157 | ​ | $ | 100,289 | ​ | $ | 245,106 | ​ |
| Over time | ​ |  | 138,047 | ​ |  | 102,842 | ​ |  | 38,890 | ​ |  | 279,779 | ​ |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 128,999 | ​ | $ | 139,179 | ​ | $ | 524,885 | ​ |
  (was, 2020-05-08, similarity 0.7012):
[0001104659-20-058660:note_history:12]
| Six months ended March 31, 2020 |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | Test | ​ | USG | ​ | Total |
| Customer type: |  | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| Commercial | ​ | $ | 93,417 | ​ | $ | 69,194 | ​ | $ | 95,971 | ​ | $ | 258,582 |
| U.S. Government | ​ |  | 79,218 | ​ | ​ | 13,789 | ​ | ​ | 631 | ​ |  | 93,638 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 82,983 | ​ | $ | 96,602 | ​ | $ | 352,220 |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |
| United States | ​ | $ | 146,164 | ​ | $ | 49,959 | ​ | $ | 63,665 | ​ | $ | 259,788 |
| International | ​ |  | 26,471 | ​ | ​ | 33,024 | ​ | ​ | 32,937 | ​ |  | 92,432 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 82,983 | ​ | $ | 96,602 | ​ | $ | 352,220 |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 82,897 | ​ | $ | 17,019 | ​ | $ | 72,524 | ​ | $ | 172,440 |
| Over time | ​ |  | 89,738 | ​ | ​ | 65,964 | ​ | ​ | 24,078 | ​ |  | 179,780 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 82,983 | ​ | $ | 96,602 | ​ | $ | 352,220 |

- changed (2020-08-10):
[0001104659-20-092836:note_history:13]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At June 30, 2020, the Company had $550.5 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 72% in the next twelve months.
  (was, 2020-05-08, similarity 0.9935):
[0001104659-20-058660:note_history:13]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At March 31, 2020, the Company had $565 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 68% in the next twelve months.

- changed (2020-08-10):
[0001104659-20-092836:note_history:14]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At June 30, 2020, contract assets and liabilities totaled $101.5 million and $87.4 million, respectively.  During the first nine months of 2020, the Company recognized approximately $47.1 million in revenues that were included in the contract liabilities balance at the adoption date.
  (was, 2020-05-08, similarity 0.9802):
[0001104659-20-058660:note_history:14]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At March 31, 2020, contract assets and liabilities totaled $96.1 million and $95.4 million, respectively.  During the first six months of 2020, the Company recognized approximately $36.4 million in revenues that were included in the contract liabilities balance at the adoption date.
