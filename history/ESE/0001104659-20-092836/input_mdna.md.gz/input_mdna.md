# ESE MD&A — 0001104659-20-092836


## mdna

[0001104659-20-092836:mdna:1]
[same as prior period, unchanged from 0001104659-20-058660:mdna:1]

[0001104659-20-092836:mdna:2]
[same as prior period, unchanged from 0001104659-20-058660:mdna:2]

[0001104659-20-092836:mdna:3]
The COVID-19 global pandemic has created significant and unprecedented challenges, and during these highly uncertain times, our top priority remains the health and safety of our employees, customers and suppliers, thereby securing the financial well-being of the Company and supporting business continuity. Our businesses have been deemed essential and are currently operational, supplying our customers with vital and necessary products. To date, our global supply chains have not been materially affected by the global pandemic. Given our diverse portfolio of strong, durable businesses serving non-discretionary end-markets, the strength and resilience of our business model positions us to continue to support our long-term outlook.

[0001104659-20-092836:mdna:4]
Recognizing the uncertainty presented by this global pandemic, we are suspending our full-year 2020 financial guidance. Our businesses are facing varying levels of pressure depending on the markets they serve as outlined below and the impact on our business cannot be reasonably estimated at this time. In response to COVID-19, we have taken decisive actions to enhance our financial condition, while continuing to execute our long-term strategy for profitable growth. Some of the actions we have taken include: deferring a portion of executive compensation, reducing discretionary spending, minimizing capital spending, implementing hiring and salary freezes, and increasing our focus on optimizing free cash flow. These operational measures are prudent steps to maintain our liquidity and will help manage our financial flexibility as we work through near-term volatility. As of June 30, 2020, we had nearly $700 million of liquidity, with $105 million in cash, net debt of approximately $47 million. Additionally, we have no debt maturities nor repayment obligations coming due and payable until September 2024. The Company has made no changes to its dividend plan. We are also monitoring the impacts of COVID-19 on the fair value of assets. We do not currently anticipate any material impairments on assets as a result of COVID-19. A portion of our workforce has worked from home at times due to COVID-19, however we have not had to redesign or design new internal controls over financial reporting at this time. Depending on the duration of COVID-19, it may become necessary for us to redesign or design new internal controls over financial reporting in a future period. We do not believe such an event will have a material impact on our business. Further details by operating segment are outlined below.

[0001104659-20-092836:mdna:5]
In our A&D segment, our third quarter revenues were negatively impacted by a decrease of approximately $4 million as compared to our expectations in April 2020 and we continue to see a slowdown in commercial aerospace deliveries and revenues over the remainder of the year. For the quarter ended June 30, 2020, the economic uncertainty, changes in the propensity for the general public to travel by air, and reductions in demand for commercial aircraft as a result of the COVID-19 pandemic have adversely impacted net sales and operating results in certain of our Aerospace and Defense reporting units and was determined to be an event and change in circumstances that required a quantitative review of goodwill and other intangible assets for impairment. We determined that there was no impairment during the three and nine months ended June 30, 2020 and the fair value of each reporting unit reviewed substantially exceeded carrying value, with the exception of Mayday where fair value exceeded carrying value by 8%. At June 30, 2020, we had $30 million of goodwill recorded for Mayday. The valuation methodology we use involves estimates of discounted cash flows, which are subject to change, and if they change negatively it could result in the need to write down those assets to fair value. We will continue to monitor the impacts of COVID-19 on the fair value of assets. The defense portion of A&D, both military aerospace and navy products is expected to remain at approximately historical business levels given its backlog coupled with the timing of expected platform deliveries.

[0001104659-20-092836:mdna:6]
In our Test segment, our third quarter revenues were negatively impacted by a decrease of approximately $6 million as compared to our expectations in April 2020 due to the China facility’s temporary three-week shutdown in February, and delayed timing of installation projects caused by access limitations to customer sites due to COVID-19. We expect the Test segment to remain at relatively normal business levels over the remainder of the year given the strength of its backlog and its served markets, primarily related to new communications technologies such as 5G.

[0001104659-20-092836:mdna:7]
In our USG segment, our third quarter revenues were negatively impacted by approximately $7 million as compared to our expectations in April 2020 as several utility customers continued to defer purchase orders and maintenance-related project deliveries so they could divert resources to other issues such as critical power delivery given their concerns around COVID-19. Additionally, Doble’s service business continued to largely be on hold during the pandemic. We expect USG’s customer spending softness to continue for the next few quarters before returning to normal levels. We reviewed the long-lived assets, including goodwill, of our NRG business for impairment that had $8 million of goodwill as of June 30, 2020. While the quantitative review determined that there was no impairment, the fair value of that reporting unit exceeded carrying value by 10%. The valuation methodology we use involves estimates of discounted cash flows, which are subject to change, and if they change negatively it could result in the need to write down those assets to fair value. We will continue to monitor the impacts of COVID-19 on the fair value of assets.

[0001104659-20-092836:mdna:8]
[same as prior period, unchanged from 0001104659-20-058660:mdna:8]

[0001104659-20-092836:mdna:9]
[same as prior period, unchanged from 0001104659-20-058660:mdna:9]

[0001104659-20-092836:mdna:10]
References to the third quarters of 2020 and 2019 represent the three-month periods ended June 30, 2020 and 2019, respectively.

[0001104659-20-092836:mdna:11]
[same as prior period, unchanged from 0001104659-20-058660:mdna:11]

[0001104659-20-092836:mdna:12]
In the third quarter of 2020, sales, net earnings and diluted earnings per share from continuing operations were $172.7 million, $18.7 million and $0.72 per share, respectively, compared to $178.3 million, $19.0 million and $0.73 per share, respectively, in the third quarter of 2019. In the first nine months of 2020, sales, net earnings and diluted earnings per share from continuing operations were $524.9 million, $47.3 million and $1.81, respectively, compared to $512.9 million, $54.2 million and $2.07 per share, respectively, in the first nine months of 2019. The decrease in net earnings and diluted earnings per share in the first nine months of 2020 as compared to the first nine months of 2019 was mainly due to the gain of approximately $8 million on the sale of the Doble Watertown property in the first quarter of 2019.

[0001104659-20-092836:mdna:13]
[same as prior period, unchanged from 0001104659-20-058660:mdna:13]

[0001104659-20-092836:mdna:14]
In the third quarter of 2020, net sales of $172.7 million were $5.6 million, or 3.1%, lower than the $178.3 million in the third quarter of 2019. In the first nine months of 2020, net sales of $524.9 million were $12.0 million, or 2.3%, higher than the $512.9 million in the first nine months of 2019. The decrease in net sales in the third quarter of 2020 as compared to the third quarter of 2019 was due to a $10.3 million decrease in the USG segment, partially offset by a $3.7 million increase in the Test segment and a $1.0 million increase in the Aerospace & Defense segment. The increase in net sales in the first nine months of 2020 as compared to the first nine months of 2019 was due to a $27.8 million increase in the Aerospace & Defense segment and a $2.7 million increase in the Test segment, partially offset by an $18.5 million decrease in the USG segment.

[0001104659-20-092836:mdna:15]
[same as prior period, unchanged from 0001104659-20-058660:mdna:15]

[0001104659-20-092836:mdna:16]
In the third quarter of 2020, net sales of $84.1 million were $1.0 million, or 1.2%, higher than the $83.1 million in the third quarter of 2019. In the first nine months of 2020, net sales of $256.7 million were $27.9 million, or 12.2%, higher than the $228.8 million in the first nine months of 2019. The sales increase in the third quarter of 2020 compared to the third quarter of 2019 was mainly due to the addition of $7.9 million in net sales from Globe, a $2.4 million increase in net sales at VACCO due to increased revenue from space products and a $0.5 million increase in net sales at Westland, partially offset by a $4.2 million decrease in net sales at PTI due to lower aerospace assembly shipments, a $3.5 million decrease in net sales at Crissair, and a $2.1 million decrease in net sales at Mayday all due to the impacts of COVID-19. The sales increase in the first nine months of 2020 compared to the first nine months of 2019 was due to the addition of $25.7 million in net sales from Globe, a $7.8 million increase in net sales at VACCO due to increased revenue from space products, partially offset by $2.2 million decrease in net sales at Crissair, a $1.6 million decrease in net sales at Westland due to timing of revenue on government programs, a $1.6 million decrease in net sales at Mayday, and a $0.2 million decrease in net sales at PTI.

[0001104659-20-092836:mdna:17]
[same as prior period, unchanged from 0001104659-20-058660:mdna:17]

[0001104659-20-092836:mdna:18]
In the third quarter of 2020, net sales of $46.0 million were $3.7 million, or 8.7%, higher than the $42.3 million in the third quarter of 2019. In the first nine months of 2020, net sales of $129.0 million were $2.5 million, or 2.0%, higher than the $126.5 million in the first nine months of 2019. The increase in the third quarter and first nine months of 2020 compared to the corresponding periods of 2019 was primarily due to higher sales from the segment’s Asian operations due to the catch up in shipments as the China facility had a temporary three-week shutdown during the second quarter due to COVID-19 and higher sales from the segment’s European operations due to the timing of test and measurement chamber projects.

[0001104659-20-092836:mdna:19]
[same as prior period, unchanged from 0001104659-20-058660:mdna:19]

[0001104659-20-092836:mdna:20]
In the third quarter of 2020, net sales of $42.6 million were $10.3 million, or 19.5% lower than the $52.9 million in the third quarter of 2019. In the first nine months of 2020, net sales of $139.2 million were $18.4 million, or 11.7%, lower than the $157.6 million in the first nine months of 2019. The decrease in the third quarter and first nine months of 2020 compared to the corresponding periods of 2019 was mainly due to lower product and software sales at Doble primarily driven by the impact of COVID-19 as customers delayed orders and on-site testing.

[0001104659-20-092836:mdna:21]
[same as prior period, unchanged from 0001104659-20-058660:mdna:21]

[0001104659-20-092836:mdna:22]
Backlog from continuing operations was $550.5 million at June 30, 2020 compared with $451.6 million at September 30, 2019. The Company received new orders totaling $157.8 million in the third quarter of 2020 compared to $170.7 million in the third quarter of 2019. Of the new orders received in the third quarter of 2020, $65.9 million related to Aerospace & Defense products, $41.5 million related to Test products, and $50.4 million related to USG products. Of the new orders received in the third quarter of 2019, $71.2 million related to Aerospace & Defense products, $44.1 million related to Test products, and $55.4 million related to USG products.

[0001104659-20-092836:mdna:23]
The Company received new orders totaling $623.9 million in the first nine months of 2020 compared to $561.3 million in the first nine months of 2019. Of the new orders received in the first nine months of 2020, $350.9 million related to Aerospace & Defense products, $121.8 million related to Test products, and $151.2 million related to USG products. Of the new orders received in the first nine months of 2019, $255.7 million related to Aerospace & Defense products, $147.1 million related to Test products, and $158.5 million related to USG products.

[0001104659-20-092836:mdna:24]
[same as prior period, unchanged from 0001104659-20-058660:mdna:24]

[0001104659-20-092836:mdna:25]
Selling, general and administrative (SG&A) expenses from continuing operations for the third quarter of 2020 were $36.9 million (21.4% of net sales), compared with $41.2 million (23.1% of net sales) for the third quarter of 2019. For the first nine months of 2020, SG&A expenses were $119.0 million (22.7% of net sales) compared to $119.1 million (23.2% of net sales) for the first nine months of 2019. The decrease in SG&A in the third quarter and first nine months of 2020 compared to the corresponding periods of 2019 was mainly due to lower discretionary spending related to travel and other discretionary expenses due to the COVID-19 pandemic; partially offset by the addition of Globe.

[0001104659-20-092836:mdna:26]
[same as prior period, unchanged from 0001104659-20-058660:mdna:26]

[0001104659-20-092836:mdna:27]
Amortization of intangible assets from continuing operations was $5.5 million and $16.6 million for the third quarter and first nine months of 2020, respectively, compared to $4.4 million and $13.2 million for the corresponding periods of 2019. Amortization expenses consist of amortization of acquired intangible assets from acquisitions and other identifiable intangible assets (primarily software). The increase in amortization expense in the third quarter and first nine months of 2020 compared to the corresponding periods of 2019 was mainly due to an increase in amortization of intangible assets related to the Globe acquisition and an increase in amortization of capitalized software at Doble.

[0001104659-20-092836:mdna:28]
OTHER (INCOME) EXPENSES, NET

[0001104659-20-092836:mdna:29]
Other income, net, was ($0.8) million in the third quarter of 2020 compared to other expenses, net, of $2.0 million in the third quarter of 2019. The principal component of other income, net, in the third quarter of 2020 was a gain on derivative instruments of $0.5 million. The principal component of other expenses, net, in the third quarter of 2019 was $0.8 million of restructuring charges related to the consolidation of VACCO’s aircraft/aerospace business into PTI’s aerospace facility in Oxnard, California and the completion of other restructuring activities begun in 2018; and losses on derivative instruments.

[0001104659-20-092836:mdna:30]
Other expenses, net, was $0.2 million in the first nine months of 2020 compared to other income, net, of ($3.4) million in the first nine months of 2019. There were no individually significant items in other expenses (income), net, in the first nine months of 2020. The principal component of other income, net, in the first nine months of 2019 was a gain of approximately $8 million on the sale of the Doble Watertown, MA building and land, partially offset by certain restructuring activities at Doble, PTI and VACCO and losses on derivative instruments.

[0001104659-20-092836:mdna:31]
[same as prior period, unchanged from 0001104659-20-058660:mdna:31]

[0001104659-20-092836:mdna:32]
The Company evaluates the performance of its operating segments based on EBIT, and provides EBIT on a consolidated basis, which is a non-GAAP financial measure. Please refer to the discussion of non-GAAP financial measures in Note 8 to the Consolidated Financial Statements, above. EBIT was $23.3 million (13.5% of net sales) for the third quarter of 2020 compared to $25.5 million (14.3% of net sales) for the third quarter of 2019. For the first nine months of 2020, EBIT was $61.5 million (11.7% of net sales) compared to $72.9 million (14.2% of net sales) for the first nine months of 2019.

[0001104659-20-092836:mdna:33]
[same as prior period, unchanged from 0001104659-20-058660:mdna:33]

[0001104659-20-092836:mdna:34]
| ​ | ​ | Three Months Ended | ​ | Nine Months Ended |
| ​ | ​ | June 30, | ​ | June 30, |
| (In thousands) |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Consolidated EBIT | ​ | $ | 23,332 | ​ | ​ | 25,545 | ​ | 61,468 | ​ | 72,871 |
| Less: Interest expense, net | ​ |  | (1,523) |  | ​ | (1,878) |  | (5,264) |  | (5,586) |
| Less: Income tax | ​ |  | (3,122) |  |  | (4,622) |  | (8,931) |  | (13,068) |
| Net earnings from continuing operations | ​ | $ | 18,687 |  | ​ | 19,045 |  | 47,273 |  | 54,217 |

[0001104659-20-092836:mdna:35]
[same as prior period, unchanged from 0001104659-20-058660:mdna:35]

[0001104659-20-092836:mdna:36]
EBIT in the third quarter of 2020 was $17.4 million (20.7% of net sales) compared to $19.0 million (22.9% of net sales) in the third quarter of 2019. EBIT in the first nine months of 2020 was $51.7 million (20.1% of net sales) compared to $47.1 million (20.6% of net sales) in the first nine months of 2019.  The decrease in EBIT in the third quarter of 2020 compared to the third quarter of 2019 was mainly due to a $1.8 million decrease at Crissair due to lower sales volumes, a $1.0 million decrease at VACCO due to product mix, an $0.8 million decrease at PTI due to lower sales volumes; partially offset by the $1.8 million contribution from Globe. The increase in EBIT in the first nine months of 2020 compared to the first nine months of 2019 was mainly due to the $6.4 million contribution from Globe; partially offset by a $1.5 million decrease at Crissair due to lower sales volumes. In addition, EBIT in the third quarter of 2020 was negatively impacted by $0.8 million of incremental costs associated with the COVID-19 pandemic.

[0001104659-20-092836:mdna:37]
[same as prior period, unchanged from 0001104659-20-058660:mdna:37]

[0001104659-20-092836:mdna:38]
EBIT in the third quarter of 2020 was $7.2 million (15.6% of net sales) compared to $5.9 million (14.0% of net sales) in the third quarter of 2019. EBIT in the first nine months of 2020 was $17.5 million (13.6% of net sales) compared to $14.8 million (11.7% of net sales) in the first nine months of 2019. The increase in EBIT in the third quarter and first nine months of 2020 compared to the corresponding periods of 2019 was primarily due to higher sales volumes from the segment’s Asian and European operations as mentioned above.

[0001104659-20-092836:mdna:39]
[same as prior period, unchanged from 0001104659-20-058660:mdna:39]

[0001104659-20-092836:mdna:40]
EBIT in the third quarter of 2020 was $6.2 million (14.5% of net sales) compared to $10.1 million (19.2% of net sales) in the third quarter of 2019. EBIT in the first nine months of 2020 was $20.3 million (14.6% of net sales) compared to $40.5 million (25.7% of net sales) in the first nine months of 2019. The decrease in EBIT in the third quarter of 2020 compared to the third quarter of 2019 was mainly due to a decrease in EBIT from Doble due to lower sales volumes of higher margin products and software mentioned above.   The decrease in EBIT in the first nine months of 2020 as compared to the first nine months of 2019 was mainly due to the gain on sale of the Doble Watertown facility of approximately $8 million in the first quarter of 2019 as well as a decrease in EBIT from Doble due to lower sales volumes in the first nine months of 2020. In addition, EBIT in the third quarter of 2020 was negatively impacted by approximately $0.2 million of incremental costs associated with the COVID-19 pandemic and EBIT in the first quarter of 2020 was negatively impacted by approximately $0.6 million of facility move costs at Doble.

[0001104659-20-092836:mdna:41]
[same as prior period, unchanged from 0001104659-20-058660:mdna:41]

[0001104659-20-092836:mdna:42]
Corporate costs included in EBIT were $7.4 million and $28.0 million in the third quarter and first nine months of 2020, respectively, compared to $9.6 million and $29.5 million in the corresponding periods of 2019. The decrease in Corporate costs in the third quarter of 2020 and first nine months of 2020 compared to the corresponding periods of 2019 was mainly due to lower professional services and lower compensation expense.

[0001104659-20-092836:mdna:43]
[same as prior period, unchanged from 0001104659-20-058660:mdna:43]

[0001104659-20-092836:mdna:44]
Interest expense was $1.5 million and $5.3 million in the third quarter and first nine months of 2020, respectively, and $1.9 million and $5.6 million in the corresponding periods of 2019. The decrease in interest expense in the third quarter of 2020 as compared to the third quarter of 2019 was mainly due to lower average outstanding borrowings ($151 million compared to $218 million) at relatively consistent average interest rates of 3.2%.

[0001104659-20-092836:mdna:45]
[same as prior period, unchanged from 0001104659-20-058660:mdna:45]

[0001104659-20-092836:mdna:46]
The third quarter 2020 effective income tax rate from continuing operations was 14.3% compared to 19.5% in the third quarter of 2019. The effective income tax rate in the first nine months of 2020 was 15.9% compared to 19.4% for the first nine months of 2019. The income tax expense in the third quarter and first nine months of 2020 was favorably impacted by the following items: 1) additional tax benefits on share-based compensation that vested during the third quarter and year-to-date quarter decreasing the effective tax rate by 1.4% and 0.6%, respectively; 2) research credits and other 2019 tax return to provision true-ups decreasing the third quarter and year-to-date effective tax rate by 1.6% and 0.6%, respectively; and 3) an increase in the available 2019 and 2020 foreign tax credit which was attributable to new information and tax planning strategies; for which the combined effect was a 6.3% reduction in the third quarter effective tax rate and a 2.4% reduction in the year-to-date effective tax rate. The income tax expense was favorably impacted in the second quarter of 2020 by the release of a valuation allowance of $2.8 million for foreign net operating losses decreasing the year-to-date effective tax rate by 5.1%.

[0001104659-20-092836:mdna:47]
The income tax expense in the third quarter and first nine months of 2019 was favorably impacted by tax planning strategies to increase the foreign tax credits claimed retrospectively. The Company reduced the valuation allowance for excess foreign tax credits by $2.4 million ($2.3 million in the second quarter of 2019 and $0.1 million in the third quarter of 2019) and recorded an amended return receivable of $0.3 million ($0.2 million in the second quarter of 2019 and $0.1 million in the third quarter of 2019) which favorably impacted the third quarter and year-to-date effective tax rate of 2019 by 1.4% and 4.3%, respectively. Income tax expense in the third quarter and first nine months of 2019 was also favorably impacted by additional tax benefits on share-based compensation that vested during the quarter decreasing the effective tax rate by 1.8% and 0.6%, respectively. A non-automatic accounting method change filed with the 2018 tax return was approved by the Internal Revenue Service during the third quarter of 2019 and favorably impacted the third quarter and year-to-date effective tax rate by 1.1% and 0.4%, respectively.

[0001104659-20-092836:mdna:48]
[same as prior period, unchanged from 0001104659-20-058660:mdna:47]

[0001104659-20-092836:mdna:49]
The Company’s overall financial position and liquidity remains strong. The effects of COVID-19 have not materially affected liquidity. Working capital from continuing operations (current assets less current liabilities) increased to $271.1 million at June 30, 2020 from $229.8 million at September 30, 2019. Inventories increased by $27.3 million during this period due to a $12.3 million increase within the Aerospace & Defense segment, a $7.2 million increase within the Test segment and a $7.8 million increase within the USG segment, resulting primarily from the timing of receipt of raw materials and work-in-process due to timing of projects.

[0001104659-20-092836:mdna:50]
Net cash provided by operating activities from continuing operations was $53.8 million and $30.8 million in the first nine months of 2020 and 2019, respectively. The increase in net cash provided by operating activities from continuing operations in the first nine months of 2020 as compared to the first nine months of 2019 was driven by lower working capital requirements.

[0001104659-20-092836:mdna:51]
Capital expenditures from continuing operations were $28.3 million and $15.3 million in the first nine months of 2020 and 2019, respectively. The increase in the first nine months of 2020 was mainly due to the building improvement additions at the new Doble headquarters facility of approximately $7 million and a $2.7 million increase in capital expenditures at VACCO primarily for construction of a new parking lot and certain machinery and equipment. In addition, the Company incurred expenditures for capitalized software of $6.6 million and $6.2 million in the first nine months of 2020 and 2019, respectively.

[0001104659-20-092836:mdna:52]
Credit Facility

[0001104659-20-092836:mdna:53]
At June 30, 2020, the Company had approximately $340 million available to borrow under its bank credit facility, a $250 million increase option subject to lender approval, and $104.7 million cash on hand. At June 30, 2020, the Company had $150 million of outstanding borrowings under the credit facility, and $1.6 million of short-term borrowings in addition to outstanding letters of credit of $9.9 million. Cash flow from operations and borrowings under the Company’s credit facility are expected to meet the Company’s capital requirements and operational needs for the foreseeable future. The Company’s ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.

[0001104659-20-092836:mdna:54]
Pension contributions

[0001104659-20-092836:mdna:55]
The Company paid $10 million of pension contributions during the third quarter of 2020. During the first quarter of 2020, the Company announced that it plans to terminate and annuitize the defined benefit pension plan during the fourth quarter of 2020.

[0001104659-20-092836:mdna:56]
[same as prior period, unchanged from 0001104659-20-058660:mdna:53]

[0001104659-20-092836:mdna:57]
A dividend of $0.08 per share, totaling $2.1 million, was paid on April 17, 2020 to stockholders of record as of April 2, 2020. Subsequent to June 30, 2020, a quarterly dividend of $0.08 per share, totaling $2.1 million, was paid on July 16, 2020 to stockholders of record as of July 2, 2020.

[0001104659-20-092836:mdna:58]
[same as prior period, unchanged from 0001104659-20-058660:mdna:55]

[0001104659-20-092836:mdna:59]
During the second and third quarters of 2020, business disruptions related to the COVID-19 pandemic affected the Company’s operations. Given the considerable uncertainty regarding the extent and duration of these economic circumstances, it is difficult to predict how our future operations will be affected using our normal forecasting methodologies, therefore, the Company is suspending its previously issued fiscal year 2020 guidance.

[0001104659-20-092836:mdna:60]
[same as prior period, unchanged from 0001104659-20-058660:mdna:57]

[0001104659-20-092836:mdna:61]
[same as prior period, unchanged from 0001104659-20-058660:mdna:58]

[0001104659-20-092836:mdna:62]
[same as prior period, unchanged from 0001104659-20-058660:mdna:59]

[0001104659-20-092836:mdna:63]
Contingencies

[0001104659-20-092836:mdna:64]
As a normal incident of the business in which the Company is engaged, various claims, charges and litigation are asserted or commenced against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. In the opinion of Management, the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company, are adequately reserved, are covered by insurance, or would not have a material adverse effect on the Company’s results from operations, capital expenditures, or competitive position.

[0001104659-20-092836:mdna:65]
[same as prior period, unchanged from 0001104659-20-058660:mdna:62]

[0001104659-20-092836:mdna:66]
Investors are cautioned that such statements are only predictions and speak only as of the date of this Form 10-Q, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment, including but not limited to those described in Item 1A, “Risk Factors,” of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2019 and this Quarterly Report on Form 10-Q, and the following: the impact of the COVID-19 pandemic including labor shortages, facility closures, material shortages, transportation delays, termination or delays of Company contracts, the inability of our suppliers or customers to perform, and weakening of economic conditions in served markets; the impacts of natural disasters on the Company’s operations and those of the Company’s customers and suppliers; the timing and content of future contract awards or customer orders; the appropriation, allocation and availability of Government funds; the termination of Government and other customer contracts or orders; weakening of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties; the availability of selected acquisitions; delivery delays or defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability of certain raw materials; labor disputes; changes in U.S. tax laws and regulations; other changes in laws and regulations including but not limited to changes in accounting standards and foreign taxation; changes in interest rates; costs relating to environmental matters arising from current or former facilities; and uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration.
