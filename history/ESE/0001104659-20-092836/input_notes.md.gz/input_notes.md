# ESE notes — 0001104659-20-092836


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001104659-20-092836:notes:1]
[same as prior period, unchanged from 0001104659-20-058660:notes:1]

[0001104659-20-092836:notes:2]
[same as prior period, unchanged from 0001104659-20-058660:notes:2]

[0001104659-20-092836:notes:3]
The Company’s results for the three-month period ended June 30, 2020 are not necessarily indicative of the results for the entire 2020 fiscal year. References to the third quarters of 2020 and 2019 represent the fiscal quarters ended June 30, 2020 and 2019, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.

[0001104659-20-092836:notes:4]
Beginning in the first quarter of 2020, Management has renamed the Filtration / Fluid Flow (Filtration) segment as Aerospace & Defense (A&D) to better reflect the composition of the segment’s products, end markets and customer characteristics. The A&D segment’s individual legal and operating entities, historical financial results, and management structure are unchanged from what was formerly presented as Filtration.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001104659-20-092836:notes:5]
[same as prior period, unchanged from 0001104659-20-058660:notes:5]

[0001104659-20-092836:notes:6]
[same as prior period, unchanged from 0001104659-20-058660:notes:6]

[0001104659-20-092836:notes:7]
Net sales from the Technical Packaging business were zero and $16.5 million in the third quarter and first nine months of 2020, respectively, compared to $21.5 million and $63.4 million in the corresponding periods of 2019. The Company received net proceeds from the sale of approximately $184 million and recorded a $76.6 million after-tax gain on the sale in the first quarter of 2020. The Company finalized the working capital adjustment and paid $0.2 million to the buyer during the third quarter of 2020.

[0001104659-20-092836:notes:8]
[same as prior period, unchanged from 0001104659-20-058660:notes:8]

[0001104659-20-092836:notes:9]
[same as prior period, unchanged from 0001104659-20-058660:notes:9]


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001104659-20-092836:notes:10]
3.    ACCOUNTING STANDARDS UPDATE

[0001104659-20-092836:notes:11]
In February 2016, the FASB issued ASU No. 2016-062, "Leases" (ASU 2016-062) which supersedes ASC 840, "Leases" and creates a new topic, ASC 842, "Leases." Subsequent to the issuance of ASU 2016-062, ASC 842 was amended by various updates that amend and clarify the impact and implementation of the aforementioned update. Effective October 1, 2019, the Company adopted these updates using the optional transition method. These updates require lessees to recognize a lease liability and a lease asset for all leases, including operating leases, with a term greater than 12 months on its balance sheet. Upon initial application, the provisions of these updates are required to be applied using the modified retrospective method, which requires retrospective adoption to each prior reporting period presented with the cumulative effect of adoption recorded to the earliest reporting period presented. An optional transition method can be utilized which requires retrospective adoption beginning on the date of adoption with the cumulative effect of initially applying these updates recognized at the date of initial adoption. The standard also provided several optional practical expedients for use in transition. The Company elected to use what the FASB has deemed the “package of practical expedients,” which allowed the Company not to reassess previous conclusions regarding lease identification, lease classification and the accounting treatment for initial direct costs. These updates also expand the required quantitative and qualitative disclosures surrounding leases. The adoption resulted in the addition of "right of use" assets and lease liabilities of approximately $20 million in the consolidated balance sheet, with no significant change to the Company’s consolidated statements of operations or cash flows. Refer to Note 16 for further discussion.


## us-gaap:EarningsPerShareTextBlock

[0001104659-20-092836:notes:12]
[same as prior period, unchanged from 0001104659-20-058660:notes:12]

[0001104659-20-092836:notes:13]
[same as prior period, unchanged from 0001104659-20-058660:notes:13]

[0001104659-20-092836:notes:14]
| ​ |  | Three Months Ended | ​ | Nine Months Ended |  |
| ​ | ​ | June 30, | ​ | June 30, | ​ |
| ​ | ​ | 2020 |  | 2019 |  | 2020 |  | 2019 | ​ |
| Weighted Average Shares Outstanding - Basic |  | 26,031 |  | 25,971 |  | 26,002 |  | 25,935 |  |
| Dilutive Options and Restricted Shares | ​ | 103 | ​ | 138 | ​ | 128 | ​ | 155 | ​ |
| Adjusted Shares - Diluted |  | 26,134 |  | 26,109 |  | 26,130 |  | 26,090 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001104659-20-092836:notes:15]
[same as prior period, unchanged from 0001104659-20-058660:notes:15]

[0001104659-20-092836:notes:16]
[same as prior period, unchanged from 0001104659-20-058660:notes:16]

[0001104659-20-092836:notes:17]
[same as prior period, unchanged from 0001104659-20-058660:notes:17]

[0001104659-20-092836:notes:18]
Compensation expense related to the restricted share awards was $1.0 million and $3.2 million for the three and nine-month periods ended June 30, 2020, respectively, and $1.1 million and $3.1 million for the corresponding periods in 2019. There were 221,024 non-vested shares outstanding as of June 30, 2020.

[0001104659-20-092836:notes:19]
[same as prior period, unchanged from 0001104659-20-058660:notes:19]

[0001104659-20-092836:notes:20]
Compensation expense related to the non-employee director grants was $0.3 million and $1.0 million for the three and nine-month periods ended June 30, 2020, respectively, and $0.3 million and $0.8 million for the corresponding periods in 2019.

[0001104659-20-092836:notes:21]
The total share-based compensation cost that has been recognized in the results of operations and included within selling, general and administrative expenses (SG&A) was $1.3 million and $4.2 million for the three and nine-month periods ended June 30, 2020, respectively, and $1.3 million and $3.9 million for the corresponding periods in 2019. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $0.2 million and $0.9 million for the three and nine-month periods ended June 30, 2020, respectively, and $0.2 million and $0.8 million for the corresponding periods in 2019. As of June 30, 2020, there was $9.2 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a remaining weighted-average period of 2.2 years.


## us-gaap:InventoryDisclosureTextBlock

[0001104659-20-092836:notes:22]
[same as prior period, unchanged from 0001104659-20-058660:notes:22]

[0001104659-20-092836:notes:23]
[same as prior period, unchanged from 0001104659-20-058660:notes:23]

[0001104659-20-092836:notes:24]
| ​ |  | June 30, |  | September 30, |
| (In thousands) | ​ | 2020 | ​ | 2019 |
| Finished goods | ​ | $ | 26,706 |  | 23,550 |
| Work in process | ​ |  | 43,569 |  | 26,407 |
| Raw materials | ​ |  | 81,989 |  | 74,999 |
| Total inventories | ​ | $ | 152,264 |  | 124,956 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001104659-20-092836:notes:25]
[same as prior period, unchanged from 0001104659-20-058660:notes:25]

[0001104659-20-092836:notes:26]
Included on the Company’s Consolidated Balance Sheets at June 30, 2020 and September 30, 2019 are the following intangible assets gross carrying amounts and accumulated amortization from continuing operations:

[0001104659-20-092836:notes:27]
| ​ |  | June 30, |  | September 30, |
| (Dollars in thousands) |  | 2020 |  | 2019 |
| Goodwill | ​ | $ | 389,942 |  | 390,256 |
| Intangible assets with determinable lives: | ​ |  | ​ | ​ |  |
| Patents | ​ |  | ​ | ​ |  |
| Gross carrying amount | ​ | $ | 2,079 | ​ | 1,945 |
| Less: accumulated amortization | ​ |  | 832 | ​ | 748 |
| Net | ​ | $ | 1,247 | ​ | 1,197 |
| Capitalized software | ​ |  | ​ | ​ |  |
| Gross carrying amount | ​ | $ | 85,528 | ​ | 78,962 |
| Less: accumulated amortization | ​ |  | 55,315 | ​ | 48,530 |
| Net | ​ | $ | 30,213 | ​ | 30,432 |
| Customer relationships | ​ |  | ​ | ​ |  |
| Gross carrying amount | ​ | $ | 227,095 | ​ | 227,225 |
| Less: accumulated amortization | ​ |  | 64,562 | ​ | 55,326 |
| Net | ​ | $ | 162,533 | ​ | 171,899 |
| Other | ​ |  | ​ | ​ |  |
| Gross carrying amount | ​ | $ | 5,129 | ​ | 5,441 |
| Less: accumulated amortization | ​ |  | 3,105 | ​ | 2,645 |
| Net | ​ | $ | 2,024 | ​ | 2,796 |
| Intangible assets with indefinite lives: | ​ |  | ​ | ​ |  |
| Trade names | ​ | $ | 174,083 | ​ | 175,281 |

[0001104659-20-092836:notes:28]
The changes in the carrying amount of goodwill attributable to each business segment for the nine months ended June 30, 2020 is as follows on a continuing operations basis:

[0001104659-20-092836:notes:29]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | Aerospace | ​ | ​ |
| (Dollars in millions) |  | USG |  | Test |  | & Defense |  | Total |
| Balance as of September 30, 2019 | ​ | $ | 254.0 |  | 34.1 |  | 102.2 |  | 390.3 |
| Foreign currency translation | ​ | ​ | (0.3) | ​ | (0.1) | ​ | — | ​ | (0.4) |
| Balance as of June 30, 2020 | ​ | $ | 253.7 | ​ | 34.0 | ​ | 102.2 | ​ | 389.9 |

[0001104659-20-092836:notes:30]
The economic uncertainty, changes in the propensity for the general public to travel by air, and reductions in demand for commercial aircraft as a result of the COVID-19 pandemic have adversely impacted net sales and operating results in certain of our Aerospace and Defense reporting units and was determined to be an event and change in circumstances that required a quantitative review of goodwill and other intangible assets for impairment. The determination of the fair value of reporting units is based, among other things, on estimates of future operating performance of the reporting unit being valued. The Company's methodology includes the use of an income approach that discounts future net cash flows to their present value at a rate that reflects the Company's cost of capital. These estimated fair values are based on estimates of future cash flows of the businesses. Factors affecting these future cash flows include the continued market demand for, and acceptance of, the products and services offered by the businesses, the development of new products and services by the businesses and the underlying cost of development, the future cost structure of the businesses and future technological changes. The Company also incorporates market multiples for comparable companies in determining the fair value of its reporting units where applicable. The quantitative review determined that there was no impairment during the three and nine months ended June 30, 2020. Due to similar and other challenges in our NRG reporting unit, a quantitative review of goodwill and other intangible assets for impairment was performed. The Company determined that there was no impairment during the three and nine months ended June 30, 2020.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001104659-20-092836:notes:31]
[same as prior period, unchanged from 0001104659-20-058660:notes:30]

[0001104659-20-092836:notes:32]
The Company is organized based on the products and services that it offers, and classifies its continuing business operations in three reportable segments for financial reporting purposes: Aerospace & Defense (formerly called Filtration/Fluid Flow), RF Shielding and Test (Test), and Utility Solutions Group (USG). The Aerospace & Defense segment’s operations consist of PTI Technologies Inc. (PTI), VACCO Industries (VACCO), Crissair, Inc. (Crissair), Westland Technologies Inc. (Westland), Mayday Manufacturing Co. and its affiliate Hi-Tech Metals, Inc. (collectively referred to as Mayday) and Globe Composite Solutions, LLC (Globe). The companies within this segment primarily design and manufacture specialty filtration and naval products, including hydraulic filter elements and fluid control devices used in commercial aerospace applications; unique filter mechanisms used in micro-propulsion devices for satellites and custom designed filters for manned aircraft and submarines; products and systems to reduce vibration and/or acoustic signatures and otherwise reduce or obscure a vessel’s signature, and other communications, sealing, surface control and hydrodynamic related applications to enhance U.S. Navy maritime survivability; precision-tolerance machined components for the aerospace and defense industry; and metal processing services.

[0001104659-20-092836:notes:33]
The Test segment’s operations consist primarily of ETS-Lindgren Inc. (ETS-Lindgren). ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy. ETS-Lindgren also manufactures radio frequency shielding products and components used by manufacturers of medical equipment, communications systems, electronic products, and shielded rooms for high-security data processing and secure communication.

[0001104659-20-092836:notes:34]
The USG segment’s operations consist primarily of Doble Engineering Company (Doble), Morgan Schaffer Inc. (Morgan Schaffer), and NRG Systems, Inc. (NRG). Doble provides high-end, intelligent, diagnostic test and data management solutions for the electric power delivery industry and is a leading supplier of partial discharge testing instruments used to assess the integrity of high voltage power delivery equipment. Morgan Schaffer provides an integrated offering of dissolved gas analysis, oil testing, and data management solutions for the electric power industry. NRG designs and manufactures decision support tools for the renewable energy industry, primarily wind.

[0001104659-20-092836:notes:35]
[same as prior period, unchanged from 0001104659-20-058660:notes:32]

[0001104659-20-092836:notes:36]
| ​ | ​ | Three Months Ended | ​ | Nine Months Ended |
| ​ | ​ | June 30, | ​ | June 30, |
| (In thousands) |  | 2020 |  | 2019 |  | 2020 | ​ | 2019 |
| NET SALES | ​ | ​ |  | ​ |  | ​ |  | ​ |  |
| Aerospace & Defense | ​ | $ | 84,072 | ​ | 83,067 | ​ | 256,707 | ​ | 228,769 |
| Test | ​ | ​ | 46,016 | ​ | 42,298 | ​ | 128,999 | ​ | 126,459 |
| USG | ​ | ​ | 42,577 | ​ | 52,894 | ​ | 139,179 | ​ | 157,639 |
| Consolidated totals | ​ | $ | 172,665 | ​ | 178,259 | ​ | 524,885 | ​ | 512,867 |
| EBIT | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Aerospace & Defense | ​ | $ | 17,409 | ​ | 19,039 | ​ | 51,658 | ​ | 47,092 |
| Test | ​ | ​ | 7,177 | ​ | 5,927 | ​ | 17,483 | ​ | 14,791 |
| USG | ​ | ​ | 6,156 | ​ | 10,148 | ​ | 20,310 | ​ | 40,461 |
| Corporate (loss) | ​ | ​ | (7,410) | ​ | (9,569) | ​ | (27,983) | ​ | (29,473) |
| Consolidated EBIT | ​ | ​ | 23,332 | ​ | 25,545 | ​ | 61,468 | ​ | 72,871 |
| Less: Interest expense | ​ | ​ | (1,523) | ​ | (1,878) | ​ | (5,264) | ​ | (5,586) |
| Earnings before income taxes | ​ | $ | 21,809 | ​ | 23,667 | ​ | 56,204 | ​ | 67,285 |

[0001104659-20-092836:notes:37]
[same as prior period, unchanged from 0001104659-20-058660:notes:34]

[0001104659-20-092836:notes:38]
[same as prior period, unchanged from 0001104659-20-058660:notes:35]

[0001104659-20-092836:notes:39]
[same as prior period, unchanged from 0001104659-20-058660:notes:36]


## us-gaap:DebtDisclosureTextBlock

[0001104659-20-092836:notes:40]
9.    DEBT

[0001104659-20-092836:notes:41]
The Company’s debt is summarized as follows:

[0001104659-20-092836:notes:42]
| ​ |  | June 30, | ​ | September 30, |
| (In thousands) | ​ | 2020 |  | 2019 |
| Total borrowings | ​ | $ | 151,577 |  | 285,000 |
| Current portion of long-term debt and short-term borrowings | ​ |  | (21,577) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 130,000 |  | 265,000 |

[0001104659-20-092836:notes:43]
On September 27, 2019, the Company entered into a new five-year credit facility (“the Credit Facility”), modifying its previous credit facility which would have matured December 21, 2020. The Credit Facility includes a $500 million revolving line of credit, as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024.

[0001104659-20-092836:notes:44]
At June 30, 2020, the Company had approximately $340 million available to borrow under the Credit Facility, plus the $250 million increase option, subject to lender approval, in addition to $104.7 million cash on hand. The Company classified $20.0 million as the current portion of long-term debt as of June 30, 2020, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $9.9 million at June 30, 2020.

[0001104659-20-092836:notes:45]
Interest on borrowings under the Credit Facility is calculated at a spread over either the London Interbank Offered Rate (LIBOR ), the New York Federal Reserve Bank Rate or the prime rate, depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The Credit Facility is secured by the unlimited guaranty of the Company’s direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of its direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 3.24% and 3.22% for the three and  nine-month periods ending June 30, 2020, respectively , and 3.21% and 3.22% for the three and nine-month periods ending June 30, 2019. As of June 30, 2020, the Company was in compliance with all covenants.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001104659-20-092836:notes:46]
[same as prior period, unchanged from 0001104659-20-058660:notes:43]

[0001104659-20-092836:notes:47]
The third quarter 2020 effective income tax rate from continuing operations was 14.3% compared to 19.5% in the third quarter of 2019. The effective income tax rate in the first nine months of 2020 was 15.9% compared to 19.4% for the first nine months of 2019. The income tax expense in the third quarter and first nine months of 2020 was favorably impacted by the following items: 1) additional tax benefits on share-based compensation that vested during the quarter decreasing the third quarter and year-to-date effective tax rate by 1.4% and 0.6%, respectively; 2) research credits and other 2019 tax return to provision true-ups decreasing the third quarter and year-to-date effective tax rate by 1.6% and 0.6%, respectively; and 3) an increase in the available 2019 and 2020 foreign tax credit which was attributable to new information and tax planning strategies, for which the combined effect was a 6.3% reduction in the third quarter effective tax rate and a 2.4% reduction in the year-to-date effective tax rate. The income tax expense was favorably impacted in the second quarter of 2020 by the release of a valuation allowance of $2.8 million for foreign net operating losses decreasing the year-to-date effective tax rate by 5.1%.

[0001104659-20-092836:notes:48]
The income tax expense in the third quarter and first nine months of 2019 was favorably impacted by tax planning strategies to increase the foreign tax credits claimed retrospectively. The Company reduced the valuation allowance for excess foreign tax credits by $2.4 million ($2.3 million in the second quarter of 2019 and $0.1 million in the third quarter of 2019) and recorded an amended return receivable of $0.3 million ($0.2 million in the second quarter of 2019 and $0.1 million in the third quarter of 2019) which favorably impacted the third quarter and year-to-date effective tax rate of 2019 by 1.4% and 4.3%, respectively. Income tax expense in the third quarter and first nine months of 2019 was also favorably impacted by additional tax benefits on share-based compensation that vested during the quarter decreasing the effective tax rate by 1.8% and 0.6%, respectively. A non-automatic accounting method change filed with the 2018 tax return was approved by the Internal Revenue Service during the third quarter of 2019 and favorably impacted the third quarter and year-to-date effective tax rate by 1.1% and 0.4%, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001104659-20-092836:notes:49]
[same as prior period, unchanged from 0001104659-20-058660:notes:45]

[0001104659-20-092836:notes:50]
The change in shareholders’ equity for the first three and nine months of 2020 and 2019 is shown below (in thousands):

[0001104659-20-092836:notes:51]
| ​ | ​ | Three Months Ended June 30, | ​ | Nine Months Ended June 30, |
| ​ |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Common stock | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 306 | ​ | 305 | ​ | 306 | ​ | 305 |
| Stock plans | ​ | 1 | ​ | 1 | ​ | 1 | ​ | 1 |
| Ending balance | ​ | 307 | ​ | 306 | ​ | 307 | ​ | 306 |
| Additional paid-in-capital | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 294,787 | ​ | 293,612 | ​ | 292,408 | ​ | 291,190 |
| Stock plans | ​ | (2,156) | ​ | (2,408) | ​ | 223 | ​ | 14 |
| Ending balance | ​ | 292,631 | ​ | 291,204 | ​ | 292,631 | ​ | 291,204 |
| Retained earnings | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 785,184 | ​ | 643,018 | ​ | 684,741 | ​ | 606,836 |
| Net earnings common stockholders | ​ | 18,687 | ​ | 20,067 | ​ | 123,286 | ​ | 56,181 |
| Dividends paid | ​ | (2,084) | ​ | (2,082) | ​ | (6,240) | ​ | (6,227) |
| Adoption of accounting standards updates | ​ | — | ​ | — | ​ | — | ​ | 4,213 |
| Ending balance | ​ | 801,787 | ​ | 661,003 | ​ | 801,787 | ​ | 661,003 |
| Accumulated other comprehensive income (loss) | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | (46,936) | ​ | (35,280) | ​ | (43,974) | ​ | (31,528) |
| Foreign currency translation | ​ | 2,802 | ​ | 1,840 | ​ | (160) | ​ | (2,013) |
| Pension | ​ | — | ​ | — | ​ | — | ​ | — |
| Forward exchange contracts | ​ | — | ​ | (7) | ​ | — | ​ | 94 |
| Ending balance | ​ | (44,134) | ​ | (33,447) | ​ | (44,134) | ​ | (33,447) |
| Treasury stock | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | (107,134) | ​ | (107,259) | ​ | (107,259) | ​ | (107,394) |
| Issued under stock plans | ​ | — | ​ | — | ​ | 125 | ​ | 135 |
| Ending balance | ​ | (107,134) | ​ | (107,259) | ​ | (107,134) | ​ | (107,259) |
| Total equity | ​ | 943,457 | ​ | 811,807 | ​ | 943,457 | ​ | 811,807 |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001104659-20-092836:notes:52]
[same as prior period, unchanged from 0001104659-20-058660:notes:48]

[0001104659-20-092836:notes:53]
A summary of net periodic benefit expense for the Company’s defined benefit plans for the three and nine-month periods ended June 30, 2020 and 2019 is shown in the following table. Net periodic benefit cost for each period presented is comprised of the following:

[0001104659-20-092836:notes:54]
| ​ |  | Three Months Ended | ​ | Nine Months Ended |  |
| ​ | ​ | June 30, | ​ | June 30, | ​ |
| (In thousands) | ​ | 2020 |  | 2019 |  | 2020 |  | 2019 | ​ |
| Defined benefit plans | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Interest cost | ​ | $ | 616 |  | 875 | ​ |  | 2,264 |  | 2,626 | ​ |
| Expected return on assets | ​ |  | (1,067) |  | (1,086) | ​ |  | (3,149) |  | (3,259) | ​ |
| Amortization of: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Prior service cost | ​ | ​ | — | ​ | — | ​ | ​ | — | ​ | — | ​ |
| Actuarial loss | ​ |  | 715 |  | 487 | ​ |  | 1,801 |  | 1,461 | ​ |
| Net periodic benefit cost | ​ | $ | 264 |  | 276 | ​ |  | 916 |  | 828 | ​ |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001104659-20-092836:notes:55]
[same as prior period, unchanged from 0001104659-20-058660:notes:51]

[0001104659-20-092836:notes:56]
Market risks relating to the Company’s operations result primarily from changes in interest rates and changes in foreign currency exchange rates. The Company is exposed to market risk related to changes in interest rates and selectively uses derivative financial instruments, including forward contracts and swaps, to manage these risks. In 2018, the Company entered into three interest rate swaps with a notional amount of $150 million to hedge some of its exposure to variability in future LIBOR-based interest payments on variable rate debt, of which one swap is outstanding as of June 30, 2020. In addition, the Company’s Canadian subsidiary Morgan Schaffer enters into foreign exchange contracts to manage foreign currency risk as a portion of their revenue is denominated in U.S. dollars. The Company expects hedging gains or losses to be essentially offset by losses or gains on the related underlying exposures. The amounts ultimately recognized may differ for open positions, which remain subject to ongoing market price fluctuations until settlement. All derivative instruments are reported in either accrued expenses or other assets on the balance sheet at fair value. For derivative instruments designated as cash flow hedges, the gain or loss on the derivative is deferred in accumulated other comprehensive income until recognized in earnings with the underlying hedged item. The interest rate swaps entered into during 2018 were not designated as cash flow hedges and, therefore, the gain or loss on the derivative is reflected in earnings each period.

[0001104659-20-092836:notes:57]
The following is a summary of the notional transaction amounts and fair values for the Company’s outstanding derivative financial instruments by risk category and instrument type as of June 30, 2020:

[0001104659-20-092836:notes:58]
| ​ | ​ | Notional | ​ | Fair Value | ​ | ​ | ​ |
| (In thousands) |  | amount |  | (US$) |  | Fix Rate |  |
| Forward contracts |  | 5,000 | USD | (106) |  |  | ​ |
| Interest rate swap |  | 150,000 | USD | (1,485) |  | 2.24 | % |


## us-gaap:FairValueDisclosuresTextBlock

[0001104659-20-092836:notes:59]
[same as prior period, unchanged from 0001104659-20-058660:notes:55]

[0001104659-20-092836:notes:60]
[same as prior period, unchanged from 0001104659-20-058660:notes:56]

[0001104659-20-092836:notes:61]
[same as prior period, unchanged from 0001104659-20-058660:notes:57]

[0001104659-20-092836:notes:62]
[same as prior period, unchanged from 0001104659-20-058660:notes:58]

[0001104659-20-092836:notes:63]
[same as prior period, unchanged from 0001104659-20-058660:notes:59]

[0001104659-20-092836:notes:64]
[same as prior period, unchanged from 0001104659-20-058660:notes:60]

[0001104659-20-092836:notes:65]
The Company has estimated the fair value of its financial instruments as of June 30, 2020 and September 30, 2019 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, debt and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001104659-20-092836:notes:66]
[same as prior period, unchanged from 0001104659-20-058660:notes:62]

[0001104659-20-092836:notes:67]
The Company’s forward contracts and interest rate swaps are classified within Level 2 of the valuation hierarchy in accordance with FASB Accounting Standards Codification (ASC) 825, as presented below as of June 30, 2020:

[0001104659-20-092836:notes:68]
| (In thousands) |  | Level 1 |  | Level 2 |  | ​ | Level 3 |  | Total |
| Assets (Liabilities): | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Forward contracts and interest rate swaps | ​ | $ | — |  | (1,591) |  | $ | — |  | (1,591) |

[0001104659-20-092836:notes:69]
[same as prior period, unchanged from 0001104659-20-058660:notes:65]

[0001104659-20-092836:notes:70]
[same as prior period, unchanged from 0001104659-20-058660:notes:66]

[0001104659-20-092836:notes:71]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. As more fully described in note 7, events and changes in circumstances for the NRG reporting unit and certain reporting units in our Aerospace & Defense segment resulting from the COVID-19 pandemic required that the property, plant and equipment, and other intangible assets of those businesses be reviewed for impairment. No impairments were recorded during the three and nine-month periods ended June 30, 2020.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001104659-20-092836:notes:72]
[same as prior period, unchanged from 0001104659-20-058660:notes:68]

[0001104659-20-092836:notes:73]
[same as prior period, unchanged from 0001104659-20-058660:notes:69]

[0001104659-20-092836:notes:74]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2020 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also include a reconciliation of the disaggregated revenue within each reportable segment on a continuing operations basis.

[0001104659-20-092836:notes:75]
| Three Months Ended June 30, 2020 |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | Test | ​ | USG | ​ | Total | ​ |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 37,485 | ​ | $ | 38,737 | ​ | $ | 39,740 | ​ | $ | 115,962 | ​ |
| U.S. Government | ​ |  | 46,587 | ​ | ​ | 7,279 | ​ | ​ | 2,837 | ​ |  | 56,703 | ​ |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 46,016 | ​ | $ | 42,577 | ​ | $ | 172,665 | ​ |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| United States | ​ | $ | 73,476 | ​ | $ | 19,441 | ​ | $ | 26,499 | ​ | $ | 119,416 | ​ |
| International | ​ |  | 10,596 | ​ | ​ | 26,575 | ​ | ​ | 16,078 | ​ |  | 53,249 | ​ |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 46,016 | ​ | $ | 42,577 | ​ | $ | 172,665 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 36,461 | ​ | $ | 9,138 | ​ | $ | 27,765 | ​ | $ | 73,364 | ​ |
| Over time | ​ |  | 47,611 | ​ | ​ | 36,878 | ​ | ​ | 14,812 | ​ |  | 99,301 | ​ |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 46,016 | ​ | $ | 42,577 | ​ | $ | 172,665 | ​ |

[0001104659-20-092836:notes:76]
| Nine Months Ended June 30, 2020 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | Test |  | USG |  | Total | ​ |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 130,817 | ​ | $ | 107,931 | ​ | $ | 135,711 | ​ | $ | 374,459 | ​ |
| U.S. Government | ​ |  | 125,890 | ​ |  | 21,068 | ​ |  | 3,468 | ​ |  | 150,426 | ​ |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 128,999 | ​ | $ | 139,179 | ​ | $ | 524,885 | ​ |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |
| United States | ​ | $ | 219,640 | ​ | $ | 69,399 | ​ | $ | 90,155 | ​ | $ | 379,194 | ​ |
| International | ​ |  | 37,067 | ​ |  | 59,600 | ​ |  | 49,024 | ​ |  | 145,691 | ​ |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 128,999 | ​ | $ | 139,179 | ​ | $ | 524,885 | ​ |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |
| Point in time | ​ | $ | 118,660 | ​ | $ | 26,157 | ​ | $ | 100,289 | ​ | $ | 245,106 | ​ |
| Over time | ​ |  | 138,047 | ​ |  | 102,842 | ​ |  | 38,890 | ​ |  | 279,779 | ​ |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 128,999 | ​ | $ | 139,179 | ​ | $ | 524,885 | ​ |

[0001104659-20-092836:notes:77]
[same as prior period, unchanged from 0001104659-20-058660:notes:73]

[0001104659-20-092836:notes:78]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At June 30, 2020, the Company had $550.5 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 72% in the next twelve months.

[0001104659-20-092836:notes:79]
[same as prior period, unchanged from 0001104659-20-058660:notes:75]

[0001104659-20-092836:notes:80]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At June 30, 2020, contract assets and liabilities totaled $101.5 million and $87.4 million, respectively.  During the first nine months of 2020, the Company recognized approximately $47.1 million in revenues that were included in the contract liabilities balance at the adoption date.


## us-gaap:LeasesOfLesseeDisclosureTextBlock

[0001104659-20-092836:notes:81]
[same as prior period, unchanged from 0001104659-20-058660:notes:77]

[0001104659-20-092836:notes:82]
[same as prior period, unchanged from 0001104659-20-058660:notes:78]

[0001104659-20-092836:notes:83]
[same as prior period, unchanged from 0001104659-20-058660:notes:79]

[0001104659-20-092836:notes:84]
[same as prior period, unchanged from 0001104659-20-058660:notes:80]

[0001104659-20-092836:notes:85]
[same as prior period, unchanged from 0001104659-20-058660:notes:81]

[0001104659-20-092836:notes:86]
[same as prior period, unchanged from 0001104659-20-058660:notes:82]

[0001104659-20-092836:notes:87]
| ​ | ​ | Three Months Ended | ​ | Nine Months Ended |
| ​ | ​ | June 30, | ​ | June 30, |
| (Dollars in thousands) |  | 2020 |  | 2020 |
| Finance lease cost |  | ​ | ​ | ​ | ​ |  |
| Amortization of right-of-use assets | ​ | $ | 540 | ​ | $ | 1,622 |
| Interest on lease liabilities | ​ |  | 319 | ​ |  | 970 |
| Operating lease cost | ​ |  | 1,474 | ​ |  | 4,399 |
| Total lease costs | ​ | $ | 2,333 | ​ | $ | 6,991 |

[0001104659-20-092836:notes:88]
[same as prior period, unchanged from 0001104659-20-058660:notes:84]

[0001104659-20-092836:notes:89]
| ​ | ​ | Three Months Ended | ​ | Nine Months Ended | ​ |
| ​ | ​ | June 30, | ​ | June 30, | ​ |
| (Dollars in thousands) |  | 2020 |  | 2020 | ​ |
| Cash paid for amounts included in the measurement of lease liabilities |  | ​ | ​ | ​ | ​ |  | ​ |
| Operating cash flows from operating leases | ​ | $ | 1,452 | ​ | $ | 4,334 | ​ |
| Operating cash flows from finance leases | ​ |  | 319 | ​ |  | 655 | ​ |
| Financing cash flows from finance leases | ​ |  | 418 | ​ |  | 1,145 | ​ |
| Right-of-use assets obtained in exchange for lease liabilities | ​ |  | ​ | ​ |  | ​ | ​ |
| Operating leases | ​ | $ | 53 | ​ | $ | 22,072 | ​ |
| Weighted-average remaining lease term | ​ | ​ | ​ | ​ |  | ​ | ​ |
| Operating leases | ​ | ​ | ​ | ​ |  | 6.64 | years |
| Finance leases | ​ | ​ | ​ | ​ |  | 12.76 | years |
| Weighted-average discount rate | ​ | ​ | ​ | ​ |  | ​ | ​ |
| Operating leases | ​ | ​ | ​ | ​ |  | 3.14 | % |
| Finance leases | ​ | ​ | ​ | ​ |  | 4.29 | % |

[0001104659-20-092836:notes:90]
The following is a reconciliation of future undiscounted cash flows to the operating and finance lease liabilities, and the related ROU assets, presented on our Consolidated Balance Sheet on June 30, 2020:

[0001104659-20-092836:notes:91]
| (Dollars in thousands) | ​ |  | Operating |  | Finance |
| Years Ending September 30: |  | Leases |  | Leases |
| 2020 (excluding the nine months ended June 30, 2020) | ​ | $ | 1,294 |  | ​ | 718 |
| 2021 | ​ |  | 4,664 |  | ​ | 2,930 |
| 2022 | ​ |  | 4,005 |  | ​ | 3,011 |
| 2023 | ​ |  | 3,057 |  | ​ | 3,094 |
| 2024 and thereafter | ​ |  | 7,633 |  | ​ | 31,416 |
| Total minimum lease payments | ​ |  | 20,653 |  | ​ | 41,169 |
| Less: amounts representing interest | ​ |  | 2,021 |  |  | 10,502 |
| Present value of net minimum lease payments | ​ | $ | 18,632 |  | ​ | 30,667 |
| Less: current portion of lease obligations | ​ |  | 4,275 |  | ​ | 1,908 |
| Non-current portion of lease obligations | ​ |  | 14,357 |  | ​ | 28,759 |
| ROU assets | ​ | $ | 18,351 |  | ​ | 27,535 |

[0001104659-20-092836:notes:92]
[same as prior period, unchanged from 0001104659-20-058660:notes:88]

[0001104659-20-092836:notes:93]
[same as prior period, unchanged from 0001104659-20-058660:notes:89]

[0001104659-20-092836:notes:94]
| (Dollars in thousands) | ​ | Operating | ​ | Finance | ​ |
| Years Ending September 30: |  | Leases |  | Leases |  |
| 2020 | ​ | $ | 5,574 | ​ | ​ | 2,518 | ​ |
| 2021 | ​ |  | 4,558 | ​ | ​ | 2,930 | ​ |
| 2022 | ​ |  | 3,950 | ​ | ​ | 3,012 | ​ |
| 2023 | ​ |  | 3,270 | ​ | ​ | 3,094 | ​ |
| 2024 and thereafter | ​ |  | 8,443 | ​ | ​ | 31,499 | ​ |
| Total minimum lease payments | ​ | $ | 25,795 | ​ | ​ | 43,053 | ​ |
| Less: amounts representing interest | ​ |  | * | ​ | ​ | 11,241 | ​ |
| Present value of net minimum lease payments | ​ |  | * | ​ | ​ | 31,812 | ​ |
| Less: Current portion of lease obligations | ​ |  | * | ​ | ​ | 1,832 | ​ |
| Non-current portion of lease obligations | ​ | ​ | * | ​ | ​ | 29,980 | ​ |

[0001104659-20-092836:notes:95]
[same as prior period, unchanged from 0001104659-20-058660:notes:91]
