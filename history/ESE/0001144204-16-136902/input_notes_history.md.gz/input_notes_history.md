# ESE note change history — 0001144204-16-099477 → 0001144204-16-117178


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-08-08):
[0001144204-16-117178:note_history:1]
The Company’s business is typically not impacted by seasonality; however, the results for the three and nine-month periods ended June 30, 2016 are not necessarily indicative of the results for the entire 2016 fiscal year. References to the third quarters of 2016 and 2015 represent the fiscal quarters ended June 30, 2016 and 2015, respectively.
  (was, 2016-05-06, similarity 0.9474):
[0001144204-16-099477:note_history:1]
The Company’s business is typically not impacted by seasonality; however, the results for the three and six-month periods ended March 31, 2016 are not necessarily indicative of the results for the entire 2016 fiscal year. References to the second quarters of 2016 and 2015 represent the fiscal quarters ended March 31, 2016 and 2015, respectively.

- changed (2016-08-08):
[0001144204-16-117178:note_history:2]
The Company is organized based on the products and services that it offers. To enhance shareholders’ understanding of the Company’s underlying operations, beginning in the second quarter of 2016, Management expanded the presentation of its reporting segments to include “Technical Packaging”. The new Technical Packaging reporting segment was created to separately disclose Thermoform Engineered Quality LLC (TEQ) along with the recent acquisitions of Plastique Group Limited and Fremont Plastics, Inc., as it no longer met the criteria for aggregation with our Filtration/Fluid Flow (Filtration) reporting segment.
  (was, 2016-05-06, similarity 0.9967):
[0001144204-16-099477:note_history:2]
The Company is organized based on the products and services that it offers. To enhance shareholders’ understanding of the Company’s underlying operations, beginning in the second quarter of 2016, Management has expanded the presentation of its reporting segments to include “Technical Packaging”. The new Technical Packaging reporting segment was created to separately disclose Thermoform Engineered Quality LLC (TEQ) along with the recent acquisitions of Plastique Group Limited and Fremont Plastics, Inc., as it no longer met the criteria for aggregation with our Filtration/Fluid Flow (Filtration) reporting segment.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-08-08):
[0001144204-16-117178:note_history:3]
|  | 8. | DEBT |
  (was, 2016-05-06, similarity 0.9231):
[0001144204-16-099477:note_history:3]
| 8. | DEBT |

- changed (2016-08-08):
[0001144204-16-117178:note_history:4]
| (In thousands) |  | June 30, 2016 |  | September 30, 2015 |  |
| Total borrowings |  | $ | 86,458 |  |  | 50,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (21,458) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 65,000 |  |  | 30,000 |  |
  (was, 2016-05-06, similarity 0.8752):
[0001144204-16-099477:note_history:4]
|  |  | March 31, |  | September 30, |  |
| (In thousands) |  | 2016 |  | 2015 |  |
| Total borrowings |  | $ | 98,890 |  |  | 50,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,890) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 78,000 |  |  | 30,000 |  |

- added (2016-08-08):
[0001144204-16-117178:note_history:5]
At June 30, 2016, the Company had approximately $361 million available to borrow under the credit facility, and a $250 million increase option, in addition to $40.5 million of cash on hand. At June 30, 2016, the Company had $85.0 million of outstanding borrowings under the credit facility and $1.5 million of other short-term borrowings in addition to outstanding letters of credit of $4.4 million. The Company’s ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.

- changed (2016-08-08):
[0001144204-16-117178:note_history:6]
The credit facility requires, as determined by certain financial ratios, a facility fee ranging from  12.5 to  27.5 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a  65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the credit facility also include a leverage ratio and an interest coverage ratio. The weighted average interest rates were  1.50% and  1.58% for the three and nine-month periods ending June 30, 2016, respectively, and  1.14% and  1.28% for the corresponding periods of 2015. At June 30, 2016, the Company was in compliance with all debt covenants.
  (was, 2016-05-06, similarity 0.9854):
[0001144204-16-099477:note_history:6]
The credit facility requires, as determined by certain financial ratios, a facility fee ranging from  12.5 to  27.5 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a  65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the credit facility also include a leverage ratio and an interest coverage ratio. The weighted average interest rates were  1.76% and  1.61% for the three and six-month periods ending March 31, 2016, respectively, and  1.27% and  1.35% for the corresponding periods of 2015. At March 31, 2016, the Company was in compliance with all debt covenants.

- removed (2016-08-08):
[0001144204-16-099477:note_history:7]
At March 31, 2016, the Company had approximately $345 million available to borrow under the credit facility, and a $250 million increase option, in addition to $38.8 million cash on hand. At March 31, 2016, the Company had $98.0 million of outstanding borrowings under the credit facility and $0.9 million of other short-term borrowings in addition to outstanding letters of credit of $6.8 million. The Company’s ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-08-08):
[0001144204-16-117178:note_history:8]
| (In thousands) |  | June 30, 2016 |  | September 30, 2015 |  |
| Total borrowings |  | $ | 86,458 |  |  | 50,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (21,458) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 65,000 |  |  | 30,000 |  |
  (was, 2016-05-06, similarity 0.8752):
[0001144204-16-099477:note_history:8]
|  |  | March 31, |  | September 30, |  |
| (In thousands) |  | 2016 |  | 2015 |  |
| Total borrowings |  | $ | 98,890 |  |  | 50,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,890) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 78,000 |  |  | 30,000 |  |
