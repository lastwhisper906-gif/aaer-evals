# ESE 8-K — 0000866706-16-000026 filed 2016-11-14

## item codes, every 8-K on or before 2016-11-29

- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2016-11-29

- none on or before 2016-11-29

## item 2.02 — earnings release, exhibit 99.1

[0000866706-16-000026:8k_2_02:1]
EX-99.1
2
escopressrelease14nov2016.htm
ESCO PRESS RELEASE

[0000866706-16-000026:8k_2_02:2]
Unassociated Document

[0000866706-16-000026:8k_2_02:3]
Exhibit 99.1

[0000866706-16-000026:8k_2_02:4]
NEWS FROM

[0000866706-16-000026:8k_2_02:5]
For more information contact:

[0000866706-16-000026:8k_2_02:6]
Kate Lowrey

[0000866706-16-000026:8k_2_02:7]
Director, Investor Relations

[0000866706-16-000026:8k_2_02:8]
ESCO Technologies Inc.

[0000866706-16-000026:8k_2_02:9]
(314) 213-7277

[0000866706-16-000026:8k_2_02:10]
ESCO ANNOUNCES FISCAL 2016 RESULTS

[0000866706-16-000026:8k_2_02:11]
GAAP EPS – From Continuing Operations $1.77; EPS – As Adjusted $2.03

[0000866706-16-000026:8k_2_02:12]
ST. LOUIS, November 14, 2016 – ESCO Technologies Inc. (NYSE: ESE) (ESCO or the Company) today reported its operating results for the fourth quarter (Q4 2016) and fiscal year ended September 30, 2016 (2016), compared to the fourth quarter (Q4 2015) and fiscal year ended September 30, 2015 (2015).

[0000866706-16-000026:8k_2_02:13]
Management previously announced certain 2016 restructuring actions which were described and quantified in the Company’s October 8, 2015 and November 12, 2015 releases. The costs associated with these restructuring actions were excluded from Management’s 2016 quarterly and full year earnings guidance communicated at the start of the year. Throughout 2016, Management quantified these costs in its quarterly earnings reports when presenting its operating results on an EPS – As Adjusted basis, and reconciled these amounts to their respective EPS – GAAP equivalents.

[0000866706-16-000026:8k_2_02:14]
By excluding the restructuring charges when discussing the 2016 non-GAAP financial measures, Management believes EPS – As Adjusted is more representative of the Company’s ongoing performance and allows shareholders better visibility into the Company’s underlying operations.

[0000866706-16-000026:8k_2_02:15]
EPS Summary

[0000866706-16-000026:8k_2_02:16]
| · | 2016 EPS – As Adjusted was $2.03 per share, compared to $1.59 per share in 2015; |

[0000866706-16-000026:8k_2_02:17]
| · | 2016 GAAP EPS from continuing operations was $1.77 per share and $1.59 per share in 2015; |

[0000866706-16-000026:8k_2_02:18]
| · | Q4 2016 EPS – As Adjusted was $0.67 per share, compared to $0.50 per share in Q4 2015; and, |

[0000866706-16-000026:8k_2_02:19]
| · | Q4 2016 GAAP EPS from continuing operations was $0.65 per share and $0.50 per share in Q4 2015. |

[0000866706-16-000026:8k_2_02:20]
Previous Management guidance for 2016 EPS – As Adjusted was $1.95 to $2.02 per share, with Q4 2016 EPS – As Adjusted in the range of $0.59 to $0.66 per share. 2016 actual results came in higher than previous guidance as Filtration, led by higher commercial aerospace earnings, and Doble both exceeded previous earnings expectations.

[0000866706-16-000026:8k_2_02:21]
EPS – As Adjusted excludes after-tax charges of $0.6 million, or $0.02 per share in Q4 2016, and $7.0 million, or $0.26 per share in 2016 related to the previously described restructuring actions, which were completed as of September 30, 2016.

[0000866706-16-000026:8k_2_02:22]
Operating Highlights - 2016

[0000866706-16-000026:8k_2_02:23]
| · | 2016 sales increased $34 million (6 percent) to $571 million compared to $537 million in 2015; |

[0000866706-16-000026:8k_2_02:24]
| · | 2016 Filtration sales increased $11 million (aerospace sales increased $10 million, or 9 percent, and VACCO sales increased $1 million, or 2 percent), Technical Packaging sales increased $35 million (Plastique added $22 million in sales and TEQ sales increased $13 million), Test sales decreased $16 million (due to the timing of large chamber projects in the respective periods), and USG sales increased $4 million (higher sales of software, services, and new products, partially offset by lower legacy hardware); |

[0000866706-16-000026:8k_2_02:25]
| · | Consolidated gross margins were 39 and 38 percent in 2016 and 2015, respectively; |

[0000866706-16-000026:8k_2_02:26]
| · | Despite the addition of the Fremont, Plastique, and Westland acquisitions, 2016 SG&A increased by only $1 million compared to 2015. The additional SG&A costs related to these acquisitions were mitigated by a lower cost structure at Test and Doble, lower operating costs in Filtration, partially offset by higher Corporate spending on professional fees; |

[0000866706-16-000026:8k_2_02:27]
| · | Other (income) expenses, net, increased in 2016 due to the restructuring costs at Test and Doble; |

[0000866706-16-000026:8k_2_02:28]
| · | The effective tax rate was 32.9 percent in 2016 compared to 32.2 percent in 2015; |

[0000866706-16-000026:8k_2_02:29]
| · | 2016 EBITDA (earnings before interest, taxes, depreciation and amortization) increased to $93 million as reported, and $101 million As – Adjusted, compared to $81 million as reported in 2015; |

[0000866706-16-000026:8k_2_02:30]
| · | 2016 orders were $576 million compared to $562 million in 2015, which resulted in an ending backlog of $332 million at September 30, 2016; and, |

[0000866706-16-000026:8k_2_02:31]
| · | Net debt (outstanding borrowings less cash on hand) at September 30, 2016 was $56 million, reflecting additional borrowings for the 2016 acquisitions and spending on share repurchases. |

[0000866706-16-000026:8k_2_02:32]
Share Repurchases

[0000866706-16-000026:8k_2_02:33]
During 2016, the Company spent $4.3 million to repurchase approximately 120,000 of its outstanding shares in the open market.

[0000866706-16-000026:8k_2_02:34]
In support of Management’s formal capital allocation policy, over the past three years (2014 through 2016), the Company returned approximately $60 million to shareholders by distributing $25 million in cash dividends and spending $35 million to repurchase approximately one million of its outstanding shares in the open market.

[0000866706-16-000026:8k_2_02:35]
The Company’s share repurchase authorization extends through September 30, 2017, and Management expects to continue to opportunistically repurchase its shares under this authorization.

[0000866706-16-000026:8k_2_02:36]
2016 Restructuring Actions

[0000866706-16-000026:8k_2_02:37]
The 2016 restructuring actions were completed as of September 30, 2016, with cumulative costs incurred of $7.8 million pretax, $7.0 million after tax, and $0.26 per share.

[0000866706-16-000026:8k_2_02:38]
Chairman’s Commentary – 2016

[0000866706-16-000026:8k_2_02:39]
Vic Richey, Chairman and Chief Executive Officer, commented, “I’m pleased with the way we ended 2016 by delivering operating results above our initial expectations, and by successfully executing several key strategic initiatives we established at the beginning of the year.

[0000866706-16-000026:8k_2_02:40]
“Throughout 2016, we were driven by four significant goals:

[0000866706-16-000026:8k_2_02:41]
| · | We set our original EPS – As Adjusted targets at $1.90 to $2.00 per share, and subsequently increased those targets to $1.95 to $2.02 per share with the acquisition of Plastique. It was our goal to deliver, or exceed, these expectations; |

[0000866706-16-000026:8k_2_02:42]
| · | During each quarterly earnings call, we defined our expectations with the goal of demonstrating consistency and predictability within our diversified, multi-segment operating structure, which reduces volatility and provides stable earnings; |

[0000866706-16-000026:8k_2_02:43]
| · | Given our 2016 cost reduction / restructuring initiatives impacting Test and Doble, our goal set at the beginning of the year was that when completed, these efforts would benefit future EBIT margins by a meaningful amount; and, |

[0000866706-16-000026:8k_2_02:44]
| · | We implemented an aggressive, yet disciplined, acquisition strategy to supplement our organic growth and provide profit protection to mitigate economic softness across the global industrial landscape. |

[0000866706-16-000026:8k_2_02:45]
“I’m thrilled with the way our entire Company came together collectively to deliver what is arguably the best year in ESCO’s history. Our EPS – As Adjusted was $2.03 per share in 2016, which despite numerous industrial market challenges, exceeded expectations for the year, and for every fiscal quarter during the year.

[0000866706-16-000026:8k_2_02:46]
“We completed our challenging restructuring actions well under budget and on time, and I’m very proud of our staff for the way they respectfully and professionally accomplished this very difficult task.

[0000866706-16-000026:8k_2_02:47]
“On the acquisition front, I’m extremely pleased with the way our M&A strategy played out this year. Beginning with Fremont, followed by Plastique in mid-year, and wrapping up the year with Westland, I’m ecstatic with the addition of each of these teams. These deals were done with a structured and disciplined approach with a continued focus on our ROIC goals. The Management teams we’ve added are a strong complement to the teams we have throughout the company. As we head into 2017, the November addition of Mayday and Hi-Tech furthers our aerospace growth objectives.

[0000866706-16-000026:8k_2_02:48]
“We plan to build on the success we achieved in 2016 and continue to have a favorable view of our future with our goal remaining the same – to increase long-term shareholder value.”

[0000866706-16-000026:8k_2_02:49]
Dividend Payment

[0000866706-16-000026:8k_2_02:50]
The next quarterly cash dividend of $0.08 per share will be paid on January 19, 2017 to stockholders of record on January 4, 2017.

[0000866706-16-000026:8k_2_02:51]
Acquisition Update – 2017

[0000866706-16-000026:8k_2_02:52]
On November 7, 2016, the Company acquired industry leading aerospace suppliers, Mayday Manufacturing Co. (Mayday) and its affiliate, Hi-Tech Metals, Inc. (Hi-Tech) which operate together in a state-of-the-art, expandable 130,000 square foot facility in Denton, Texas. Mayday and Hi-Tech will be included in the Company’s Filtration operating segment beginning in 2017.

[0000866706-16-000026:8k_2_02:53]
Mayday is a market leading manufacturer of mission-critical bushings, pins, sleeves and precise-tolerance machined components for landing gear, rotor heads, engine mounts, flight controls, and actuation systems for the aerospace and defense industry.

[0000866706-16-000026:8k_2_02:54]
Hi-Tech is a full-service metal processor offering a vast portfolio of unique and challenging processing services to aerospace OEM’s and Tier 1 suppliers. Hi-Tech’s capabilities include anodizing, cadmium and zinc-nickel plating, organic coatings, non-destructive testing, and heat treatment.

[0000866706-16-000026:8k_2_02:55]
The Company is continuing to evaluate additional opportunities and Management remains confident that it will be successful in closing additional acquisitions to support future growth.

[0000866706-16-000026:8k_2_02:56]
Business Outlook – 2017

[0000866706-16-000026:8k_2_02:57]
Management continues to see meaningful sales, EBIT, EBITDA, and EPS growth across each of the Company’s business segments and anticipates growth rates in 2017 and beyond that exceed the Company’s defined peer group and the broader industrial market.

[0000866706-16-000026:8k_2_02:58]
The details of Management’s growth expectations for 2017 (compared to 2016 As – Adjusted) are as follows:

[0000866706-16-000026:8k_2_02:59]
| · | Sales are expected to increase between 18 percent and 20 percent, resulting in projected sales in the range of $675 million to $685 million, with all operating segments reflecting meaningful increases; |

[0000866706-16-000026:8k_2_02:60]
| · | Gross profit dollars are expected to be negatively impacted by a one-time non-cash pretax charge of $3 million or $0.08 per share after-tax, related to Mayday’s inventory “step up”; |

[0000866706-16-000026:8k_2_02:61]
| · | EBIT dollars are expected to increase greater than 18 percent due to the sales increase, despite the purchase accounting charge; |

[0000866706-16-000026:8k_2_02:62]
| · | EBITDA is expected to increase between 21 percent and 23 percent, resulting in EBITDA in the range of $122 million and $124 million, compared to 2016 EBITDA As – Adjusted of $101 million; |

[0000866706-16-000026:8k_2_02:63]
| · | Interest expense on higher net debt resulting from recent acquisitions and share repurchases is expected to increase to $3.6 million, up from the $1.3 million expense reported in 2016; |

[0000866706-16-000026:8k_2_02:64]
| · | Non-cash depreciation and amortization of intangibles is expected to increase approximately $9 million, pretax, or ($0.22 per share after-tax) as a result of the recent acquisitions; |

[0000866706-16-000026:8k_2_02:65]
| · | 2017 income tax expense is expected to increase as Management is projecting a 35 percent effective tax rate calculated on higher pretax earnings, as compared to the 32.9 percent tax rate in 2016; and, |

[0000866706-16-000026:8k_2_02:66]
| · | In summary, Management projects 2017 EPS to be in the range of $2.16 to $2.26 per share, including the impact of the inventory “step up” charge of $0.08 per share expected to be incurred in the first half of 2017, and the $0.22 per share impact of additional depreciation and amortization. |

[0000866706-16-000026:8k_2_02:67]
Management’s 2017 operating segment expectations are presented in summary fashion:

[0000866706-16-000026:8k_2_02:68]
| · | Filtration sales are expected to increase over 35 percent with EBIT margins (excluding inventory “step up” charges at Mayday) similar to 2016. The significant increase in sales and EBIT is driven by the additions of Westland and Mayday, the continued strength of the commercial aerospace market, and significantly higher space (SLS) sales at VACCO; |

[0000866706-16-000026:8k_2_02:69]
| · | Technical Packaging sales are expected to increase over 17 percent with EBIT margins in the low-to-mid teens. The sales increase is driven by Plastique being included for the full year, partially offset by a temporary (3 month) slowdown of KAZ deliveries at TEQ as the customer rationalizes its current inventory in Q1 2017; |

[0000866706-16-000026:8k_2_02:70]
| · | Test sales are expected to increase in the high single digits with EBIT margins near 13 percent. The sales increase is driven by the catch up from 2016 delayed orders being received and with projects ultimately being delivered in 2017. The EBIT margin increase reflects the lower cost structure resulting from the 2016 restructuring and other operating improvements implemented; |

[0000866706-16-000026:8k_2_02:71]
| · | Doble sales are expected to increase in the mid-to-high single digits with EBIT margins consistent with 2016’s As - Adjusted EBIT margin of 26 percent. The sales increase reflects higher software and service revenues, and flat to slightly higher hardware revenues driven by an expectation of a modest recovery in utility customer capital spending; and, |

[0000866706-16-000026:8k_2_02:72]
| · | Corporate costs are expected to be higher due to additional non-cash amortization of purchase accounting intangible assets resulting from the recent acquisitions. |

[0000866706-16-000026:8k_2_02:73]
On a quarterly basis, Management expects 2017 operating results to reflect a profile similar to 2016 and previous years, with revenues and EPS being more second-half weighted. As with past years, projected Q4 2017 sales and EPS are expected to be the strongest/highest of the fiscal year.

[0000866706-16-000026:8k_2_02:74]
Management expects Q1 2017 EPS to be in the range of $0.35 to $0.40 per share, which reflects one half of the impact of the $3 million, or $0.08 per share, of pretax purchase accounting charges noted above. Additionally, the timing of sales and related earnings within the respective quarters also impacts Q1 comparative EPS.

[0000866706-16-000026:8k_2_02:75]
Chairman’s Commentary – 2017

[0000866706-16-000026:8k_2_02:76]
Mr. Richey continued, “The sales, EBIT, EBITDA and EPS growth we are expecting in 2017 puts us in a solid position to meet our shareholder value-creation goals, and to date, our share price appreciation has validated our strategy.

[0000866706-16-000026:8k_2_02:77]
The sales, EBITDA, and EPS growth we are projecting in 2017 is expected to outperform the majority of our industrial peers and the overall industrial market.

[0000866706-16-000026:8k_2_02:78]
“In 2016, we established a solid foundation with our operating results and, coupled with our recent acquisitions, I remain confident in our ability to meet our longer-term financial goals. We are well-positioned for continued growth, and with us now realizing the benefits of our lower operating cost structure, I’m confident that this will provide us an opportunity to further increase our operating margins and improve our competitive position across our various end-markets.

[0000866706-16-000026:8k_2_02:79]
“I firmly believe our market leadership positions and the breadth and diversity of our new product offerings will allow us to continue to grow at levels above our peer and industry averages.

[0000866706-16-000026:8k_2_02:80]
“We continue to see opportunities to supplement this organic growth through accretive acquisitions, and we remain committed to our longer-term growth targets and EPS goals.”

[0000866706-16-000026:8k_2_02:81]
Conference Call

[0000866706-16-000026:8k_2_02:82]
The Company will host a conference call today, November 14, at 4:00 p.m. Central Time, to discuss the Company’s 2016 results and 2017 outlook. A live audio webcast will be available on the Company’s website at www.escotechnologies.com. Please access the website at least 15 minutes prior to the call to register, download and install any necessary audio software. A replay of the conference call will be available for seven days on the Company’s website noted above or by phone (dial 1-855-859-2056 and enter the pass code 91075521).

[0000866706-16-000026:8k_2_02:83]
Forward-Looking Statements

[0000866706-16-000026:8k_2_02:84]
Statements in this press release regarding the Company’s expected quarterly and 2017 full year operating results, revenue and sales growth, EPS, EPS growth, EBIT, EBIT margins, EBITDA, gross profit, interest expense, non-cash depreciation and amortization of intangibles, corporate costs, effective tax rates, the Company’s ability to increase operating margins, realize financial goals and increase shareholder value, the success of acquisition efforts, the size, number and timing of future sales and growth opportunities, share repurchases, the long-term success of the Company, and any other statements which are not strictly historical are “forward-looking” statements within the meaning of the safe harbor provisions of the federal securities laws.

[0000866706-16-000026:8k_2_02:85]
Investors are cautioned that such statements are only predictions and speak only as of the date of this release, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment including, but not limited to those described in Item 1A, “Risk Factors”, of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2015, and the following: the success of the Company’s competitors; site readiness issues with Test segment customers; weakening of economic conditions in served markets; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties; unforeseen charges impacting corporate operating expenses; delivery delays or defaults by customers; the performance of the Company’s international operations; material changes in the costs and availability of certain raw materials; the appropriation and allocation of Government funds; the termination for convenience of Government and other customer contracts; the timing and content of future contract awards or customer orders; containment of engineering and development costs; performance issues with key customers, suppliers and subcontractors; labor disputes; the impacts of natural disasters on the Company’s operations and those of the Company’s customers and suppliers; changes in laws and regulations, including but not limited to changes in accounting standards and taxation requirements; costs relating to environmental matters arising from current or former facilities; financial exposure in connection with Company guarantees of certain Aclara contracts; the availability of select acquisitions; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the Company’s successful execution of cost reduction and profit improvement initiatives.

[0000866706-16-000026:8k_2_02:86]
Non-GAAP Financial Measures

[0000866706-16-000026:8k_2_02:87]
The financial measures EBIT, EBIT margin, Adjusted EBIT margin, EBITDA, and EPS – As Adjusted are presented in this press release. The Company defines “EBIT” as earnings before interest and taxes from continuing operations, “EBIT margin” as EBIT expressed as a percent of net sales, “Adjusted EBIT margin” as EBIT excluding the 2016 restructuring charges expressed as a percent of net sales, “EBITDA” as earnings before interest, taxes, depreciation and amortization, and “EPS – As Adjusted” as GAAP earnings per share (EPS) excluding the restructuring charges described above which were $0.02 per share for Q4 2016 and $0.26 per share for 2016.

[0000866706-16-000026:8k_2_02:88]
EBIT, EBIT margin, Adjusted EBIT margin, EBITDA and EPS – As Adjusted are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management believes that EBIT, EBIT margin, and EBITDA are useful in assessing the operational profitability of the Company’s business segments because they exclude interest, taxes, depreciation and amortization, which are generally accounted for across the entire Company on a consolidated basis. Adjusted EBIT margin excludes the 2016 impact of the ETS and Doble restructuring charges. EBIT is also one of the measures used by Management in determining resource allocations within the Company as well as incentive compensation. The Company believes that the presentation of EBIT, EBIT margin, Adjusted EBIT margin, EBITDA, and EPS – As Adjusted provides important supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance determined in accordance with GAAP. A reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is included in the attached tables.

[0000866706-16-000026:8k_2_02:89]
ESCO, headquartered in St. Louis: Manufactures highly-engineered filtration and fluid control products for the aviation, space and process markets worldwide; is the industry leader in RF shielding and EMC test products; provides diagnostic instruments, software and services for the benefit of the electric utility industry and industrial power users; and, produces custom thermoformed packaging, pulp based packaging, and specialty products for medical and commercial markets. Further information regarding ESCO and its subsidiaries is available on the Company’s website at www.escotechnologies.com.

[0000866706-16-000026:8k_2_02:90]
-  tables attached -

[0000866706-16-000026:8k_2_02:91]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Condensed Consolidated Statements of Operations (Unaudited) |  |
| (Dollars in thousands, except per share amounts) |  |
|  | Three Months Ended September 30, 2016 |  |  | Three Months Ended September 30, 2015 |  |
| Net Sales | $ | 159,505 |  |  |  | 153,612 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |
| Cost of sales |  | 96,038 |  |  |  | 99,131 |  |
| Selling, general and administrative expenses |  | 34,304 |  |  |  | 30,945 |  |
| Amortization of intangible assets |  | 3,090 |  |  |  | 2,472 |  |
| Interest expense |  | 391 |  |  |  | 130 |  |
| Other expenses (income), net |  | 1,365 |  |  |  | 1,357 |  |
| Total costs and expenses |  | 135,188 |  |  |  | 134,035 |  |
| Earnings before income taxes |  | 24,317 |  |  |  | 19,577 |  |
| Income taxes |  | 7,402 |  |  |  | 6,594 |  |
| Net earnings | $ | 16,915 |  |  |  | 12,983 |  |
| Diluted EPS - GAAP | $ | 0.65 |  |  |  | 0.50 |  |
| Diluted EPS - As Adjusted | $ | 0.67 | (1) |  |  | 0.50 |  |
| Diluted average common shares O/S: |  | 25,935 |  |  |  | 26,191 |  |

[0000866706-16-000026:8k_2_02:92]
| (1) | As Adjusted excludes $0.6 million (or $0.02 per share) of previously announced adjustments for restructuring charges incurred at ETS & Doble during the fourth quarter of fiscal 2016. |

[0000866706-16-000026:8k_2_02:93]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Condensed Consolidated Statements of Operations (Unaudited) |  |
| (Dollars in thousands, except per share amounts) |  |
|  |  | Year Ended September 30, 2016 |  |  |  | Year Ended September 30, 2015 |  |
| Net Sales |  | $ | 571,459 |  |  |  |  | 537,291 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 350,807 |  |  |  |  | 334,850 |  |
| Selling, general and administrative expenses |  |  | 131,493 |  |  |  |  | 130,166 |  |
| Amortization of intangible assets |  |  | 11,630 |  |  |  |  | 8,850 |  |
| Interest expense |  |  | 1,308 |  |  |  |  | 785 |  |
| Other expenses (income), net |  |  | 7,801 |  |  |  |  | 1,119 |  |
| Total costs and expenses |  |  | 503,039 |  |  |  |  | 475,770 |  |
| Earnings before income taxes |  |  | 68,420 |  |  |  |  | 61,521 |  |
| Income taxes |  |  | 22,538 |  |  |  |  | 19,785 |  |
| Net earnings from continuing operations |  |  | 45,882 |  |  |  |  | 41,736 |  |
| Earnings from discontinued operations, net of tax |  |  |  |  |  |  |  |  |  |
| expense of $390 |  |  | - |  |  |  |  | 776 |  |
| Net earnings |  | $ | 45,882 |  |  |  |  | 42,512 |  |
| Diluted EPS - GAAP |  |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 1.77 |  |  |  |  | 1.59 |  |
| Discontinued operations |  |  | 0.00 |  |  |  |  | 0.03 |  |
| Net earnings |  |  | 1.77 |  |  |  |  | 1.62 |  |
| Diluted EPS - As Adjusted |  | $ | 2.03 | (1) |  |  |  | 1.59 |  |
| Diluted average common shares O/S: |  |  | 25,968 |  |  |  |  | 26,265 |  |

[0000866706-16-000026:8k_2_02:94]
| (1) | As Adjusted excludes $6.9 million (or $0.26 per share) of previously announced adjustments for restructuring charges incurred at ETS & Doble during fiscal 2016. |

[0000866706-16-000026:8k_2_02:95]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Condensed Business Segment Information (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  |  | GAAP |  |  | Q4 2016 Adjustments (1) |  |  | As Adjusted |  |
|  |  |  |  | Q4 2016 |  |  |  | Q4 2015 |  |  |  |  |  |  | Q4 2016 |  |  |  | Q4 2015 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Filtration |  | $ | 61,994 |  |  |  | 57,399 |  |  |  |  |  |  | 61,994 |  |  |  | 57,399 |  |
|  | Test |  |  | 41,903 |  |  |  | 53,161 |  |  |  |  |  |  | 41,903 |  |  |  | 53,161 |  |
|  | USG |  |  | 34,129 |  |  |  | 30,667 |  |  |  |  |  |  | 34,129 |  |  |  | 30,667 |  |
|  | Technical Packaging |  |  | 21,479 |  |  |  | 12,385 |  |  |  |  |  |  | 21,479 |  |  |  | 12,385 |  |
|  | Totals |  | $ | 159,505 |  |  |  | 153,612 |  |  |  |  |  |  | 159,505 |  |  |  | 153,612 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Filtration |  | $ | 15,716 |  |  |  | 12,978 |  |  |  |  |  |  | 15,716 |  |  |  | 12,978 |  |
|  | Test |  |  | 5,276 |  |  |  | 2,467 |  |  |  | 424 |  |  |  | 5,700 |  |  |  | 2,467 |  |
|  | USG |  |  | 9,502 |  |  |  | 7,448 |  |  |  | 308 |  |  |  | 9,810 |  |  |  | 7,448 |  |
|  | Technical Packaging |  |  | 2,590 |  |  |  | 2,172 |  |  |  |  |  |  |  | 2,590 |  |  |  | 2,172 |  |
|  | Corporate |  |  | (8,376 | ) |  |  | (5,358 | ) |  |  | 106 |  |  |  | (8,270 | ) |  |  | (5,358 | ) |
|  | Consolidated EBIT |  |  | 24,708 |  |  |  | 19,707 |  |  |  | 838 |  |  |  | 25,546 |  |  |  | 19,707 |  |
|  | Less: Interest expense |  |  | (391 | ) |  |  | (130 | ) |  |  |  |  |  |  | (391 | ) |  |  | (130 | ) |
|  | Less: Income tax expense |  |  | (7,402 | ) |  |  | (6,594 | ) |  |  | (215 | ) |  |  | (7,617 | ) |  |  | (6,594 | ) |
|  | Net earnings from cont ops |  | $ | 16,915 |  |  |  | 12,983 |  |  |  | 623 |  |  |  | 17,538 |  |  |  | 12,983 |  |

[0000866706-16-000026:8k_2_02:96]
| Note: | Depreciation and amortization expense was $6.4 million and $5.0 million for the quarters ended September 30, 2016 and 2015, respectively. |
| (1) | Adjustments consist of $0.6 million (or $0.02 per share) of restructuring charges at ETS & Doble during the fourth quarter of 2016. |

[0000866706-16-000026:8k_2_02:97]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Condensed Business Segment Information (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  |  | GAAP |  |  | FY 2016 Adjustments (1) |  |  | As Adjusted |  |
|  |  |  | FY 2016 |  |  | FY 2015 |  |  |  |  |  | FY 2016 |  |  | FY 2015 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Filtration |  | $ | 207,752 |  |  |  | 196,671 |  |  |  |  |  |  | 207,752 |  |  |  | 196,671 |  |
|  | Test |  |  | 161,512 |  |  |  | 177,611 |  |  |  |  |  |  | 161,512 |  |  |  | 177,611 |  |
|  | USG |  |  | 127,785 |  |  |  | 123,556 |  |  |  |  |  |  | 127,785 |  |  |  | 123,556 |  |
|  | Technical Packaging |  |  | 74,410 |  |  |  | 39,453 |  |  |  |  |  |  | 74,410 |  |  |  | 39,453 |  |
|  | Totals |  | $ | 571,459 |  |  |  | 537,291 |  |  |  |  |  |  | 571,459 |  |  |  | 537,291 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Filtration |  | $ | 45,227 |  |  |  | 41,686 |  |  |  |  |  |  | 45,227 |  |  |  | 41,686 |  |
|  | Test |  |  | 13,863 |  |  |  | 9,540 |  |  |  | 5,139 |  |  |  | 19,002 |  |  |  | 9,540 |  |
|  | USG |  |  | 31,083 |  |  |  | 29,637 |  |  |  | 2,228 |  |  |  | 33,311 |  |  |  | 29,637 |  |
|  | Technical Packaging |  |  | 9,625 |  |  |  | 4,875 |  |  |  |  |  |  |  | 9,625 |  |  |  | 4,875 |  |
|  | Corporate |  |  | (30,070 | ) |  |  | (23,432 | ) |  |  | 434 |  |  |  | (29,636 | ) |  |  | (23,432 | ) |
|  | Consolidated EBIT |  |  | 69,728 |  |  |  | 62,306 |  |  |  | 7,801 |  |  |  | 77,529 |  |  |  | 62,306 |  |
|  | Less: Interest expense |  |  | (1,308 | ) |  |  | (785 | ) |  |  |  |  |  |  | (1,308 | ) |  |  | (785 | ) |
|  | Less: Income tax expense |  |  | (22,538 | ) |  |  | (19,785 | ) |  |  | (849 | ) |  |  | (23,387 | ) |  |  | (19,785 | ) |
|  | Net earnings from cont ops |  | $ | 45,882 |  |  |  | 41,736 |  |  |  | 6,952 |  |  |  | 52,834 |  |  |  | 41,736 |  |

[0000866706-16-000026:8k_2_02:98]
| Note: | Depreciation and amortization expense was $23.6 million and $18.6 million for the years ended September 30, 2016 and 2015, respectively. |
| (1) | Adjustments consist of $6.9 million (or $0.26 per share) of restructuring charges at ETS & Doble during fiscal year 2016. |

[0000866706-16-000026:8k_2_02:99]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Condensed Consolidated Balance Sheets (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  | September 30, 2016 |  |  | September 30, 2015 |  |
| Assets |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 53,825 |  |  |  | 39,411 |  |
| Accounts receivable, net |  |  | 121,486 |  |  |  | 102,607 |  |
| Costs and estimated earnings on |  |  |  |  |  |  |  |  |
| long-term contracts |  |  | 28,746 |  |  |  | 28,387 |  |
| Inventories |  |  | 105,542 |  |  |  | 99,786 |  |
| Current portion of deferred tax assets |  |  | - |  |  |  | 15,558 |  |
| Other current assets |  |  | 13,884 |  |  |  | 12,502 |  |
| Total current assets |  |  | 323,483 |  |  |  | 298,251 |  |
| Property, plant and equipment, net |  |  | 92,405 |  |  |  | 77,358 |  |
| Intangible assets, net |  |  | 231,759 |  |  |  | 190,748 |  |
| Goodwill |  |  | 323,616 |  |  |  | 291,157 |  |
| Other assets |  |  | 7,108 |  |  |  | 6,694 |  |
|  |  | $ | 978,371 |  |  |  | 864,208 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Short-term borrowings and current |  | $ | 20,000 |  |  |  | 20,000 |  |
| maturities of long-term debt |  |  |  |  |  |  |  |  |
| Accounts payable |  |  | 42,074 |  |  |  | 37,863 |  |
| Current portion of deferred revenue |  |  | 27,212 |  |  |  | 21,498 |  |
| Other current liabilities |  |  | 68,790 |  |  |  | 63,850 |  |
| Total current liabilities |  |  | 158,076 |  |  |  | 143,211 |  |
| Deferred tax liabilities |  |  | 69,562 |  |  |  | 74,469 |  |
| Other liabilities |  |  | 45,624 |  |  |  | 32,346 |  |
| Long-term debt |  |  | 90,000 |  |  |  | 30,000 |  |
| Shareholders' equity |  |  | 615,109 |  |  |  | 584,182 |  |
|  |  | $ | 978,371 |  |  |  | 864,208 |  |

[0000866706-16-000026:8k_2_02:100]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Consolidated Statements of Cash Flows (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  | Year Ended September 30, 2016 |  |
| Cash flows from operating activities: |  |  |  |
| Net earnings |  | $ | 45,882 |  |
| Adjustments to reconcile net earnings |  |  |  |  |
| to net cash provided by operating activities: |  |  |  |  |
| Depreciation and amortization |  |  | 23,568 |  |
| Stock compensation expense |  |  | 4,704 |  |
| Changes in assets and liabilities |  |  | 1,746 |  |
| Effect of deferred taxes |  |  | (2,993 | ) |
| Other |  |  | 952 |  |
| Net cash provided by operating activities |  |  | 73,859 |  |
| Cash flows from investing activities: |  |  |  |  |
| Acquisition of businesses, net of cash acquired |  |  | (82,062 | ) |
| Capital expenditures |  |  | (13,843 | ) |
| Additions to capitalized software |  |  | (8,665 | ) |
| Net cash used by investing activities |  |  | (104,570 | ) |
| Cash flows from financing activities: |  |  |  |  |
| Proceeds from long-term debt |  |  | 140,000 |  |
| Principal payments on long-term debt |  |  | (80,000 | ) |
| Dividends paid |  |  | (8,248 | ) |
| Purchases of common stock into treasury |  |  | (4,303 | ) |
| Debt issuance costs |  |  | (1,097 | ) |
| Other |  |  | (128 | ) |
| Net cash provided by financing activities |  |  | 46,224 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (1,099 | ) |
| Net increase in cash and cash equivalents |  |  | 14,414 |  |
| Cash and cash equivalents, beginning of period |  |  | 39,411 |  |
| Cash and cash equivalents, end of period |  | $ | 53,825 |  |

[0000866706-16-000026:8k_2_02:101]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Other Selected Financial Data (Unaudited) |  |
| (Dollars in thousands) |  |
| Backlog And Entered Orders - Q4 FY 2016 |  | USG |  |  | Test |  |  | Filtration |  |  | Technical Packaging |  |  | Total |  |
| Beginning Backlog - 7/1/16 |  | $ | 30,589 |  |  |  | 83,913 |  |  |  | 177,016 |  |  |  | 21,712 |  |  |  | 313,230 |  |
| Entered Orders |  |  | 37,383 |  |  |  | 41,061 |  |  |  | 80,779 |  |  |  | 19,421 |  |  |  | 178,644 |  |
| Sales |  |  | (34,129 | ) |  |  | (41,903 | ) |  |  | (61,994 | ) |  |  | (21,479 | ) |  |  | (159,505 | ) |
| Ending Backlog - 9/30/16 |  | $ | 33,843 |  |  |  | 83,071 |  |  |  | 195,801 |  |  |  | 19,654 |  |  |  | 332,369 |  |
| Backlog And Entered Orders - FY 2016 |  | USG |  |  | Test |  |  | Filtration |  |  | Technical Packaging |  |  | Total |  |
| Beginning Backlog - 10/1/15 |  | $ | 36,272 |  |  |  | 95,129 |  |  |  | 178,844 |  |  |  | 17,264 |  |  |  | 327,509 |  |
| Entered Orders |  |  | 125,356 |  |  |  | 149,454 |  |  |  | 224,709 |  |  |  | 76,800 |  |  |  | 576,319 |  |
| Sales |  |  | (127,785 | ) |  |  | (161,512 | ) |  |  | (207,752 | ) |  |  | (74,410 | ) |  |  | (571,459 | ) |
| Ending Backlog - 9/30/16 |  | $ | 33,843 |  |  |  | 83,071 |  |  |  | 195,801 |  |  |  | 19,654 |  |  |  | 332,369 |  |

[0000866706-16-000026:8k_2_02:102]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Reconciliation of Non-GAAP Financial Measures (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  |  |  |  | As Adjusted |  |  |  |  |
|  |  | FY 2016 |  |  | FY 2016 |  |  | FY 2015 |  |
| EBITDA |  | $ | 93,296 |  |  | $ | 101,097 |  |  | $ | 80,890 |  |
| Less: Depreciation & Amortization expense |  |  | (23,568 | ) |  |  | (23,568 | ) |  |  | (18,584 | ) |
| Less: FY 16 Test & Doble restructuring charges |  |  | - |  |  |  | (7,801 | ) |  |  | - |  |
| Consolidated EBIT |  | $ | 69,728 |  |  | $ | 69,728 |  |  | $ | 62,306 |  |
| Less: Interest expense |  |  | (1,308 | ) |  |  | (1,308 | ) |  |  | (785 | ) |
| Less: Income tax expense |  |  | (22,538 | ) |  |  | (22,538 | ) |  |  | (19,785 | ) |
| Net earnings from cont ops |  | $ | 45,882 |  |  | $ | 45,882 |  |  | $ | 41,736 |  |

## item 5.02 — body, verbatim

[0000866706-16-000026:8k_body:1]
Item 5.02                      Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers

[0000866706-16-000026:8k_body:2]
Fiscal 2017 Executive Officer Base Salaries and Cash Incentive Compensation

[0000866706-16-000026:8k_body:3]
On November 11, 2016, the Human Resources and Compensation Committee (the “Committee”) of the Company’s Board of Directors approved the fiscal 2017 base salaries and target cash incentive compensation opportunities for its executive officers; there was no increase in base salaries from fiscal 2016:

[0000866706-16-000026:8k_body:4]
Officer

[0000866706-16-000026:8k_body:5]
Fiscal 2017

[0000866706-16-000026:8k_body:6]
Base Salary

[0000866706-16-000026:8k_body:7]
Fiscal 2017 Target Cash Incentive Compensation

[0000866706-16-000026:8k_body:8]
Victor L. Richey

[0000866706-16-000026:8k_body:9]
$824,500

[0000866706-16-000026:8k_body:10]
$733,500

[0000866706-16-000026:8k_body:11]
Gary E. Muenster

[0000866706-16-000026:8k_body:12]
$550,000

[0000866706-16-000026:8k_body:13]
$413,000

[0000866706-16-000026:8k_body:14]
Alyson S. Barclay

[0000866706-16-000026:8k_body:15]
$326,000

[0000866706-16-000026:8k_body:16]
$202,000

[0000866706-16-000026:8k_body:17]
The Company has two cash incentive compensation plans: (i) the Incentive Compensation Plan (the “ICP”) and (ii) the Performance Compensation Plan for Executive Officers (the “PCP”). For fiscal 2017 the Committee determined to allocate 50% of the executive officers’ cash incentive compensation opportunity to the ICP, and 50% to the PCP.  The Committee also approved the fiscal 2017 performance criteria for determining the percentage of such target incentive compensation opportunity that will be actually earned by the executive officers, depending on actual fiscal 2017 results compared to the criteria.

[0000866706-16-000026:8k_body:18]
Under the ICP, the Committee established Company earnings per share (“EPS”) as the single criterion for measuring performance, the same as for fiscal 2016.  The actual cash incentive compensation payable under the ICP for fiscal 2017 will range from 0.0 to 2.0 times the ICP share of the target opportunity depending on actual 2017 EPS, based on a matrix specifying particular EPS thresholds.

[0000866706-16-000026:8k_body:19]
Under the PCP, the Committee established two performance measures:  Cash Flow, weighted at 50% of the total target opportunity; and Working Capital, weighted at 50% of the total target opportunity. The actual cash incentive compensation payable under the PCP for fiscal 2017 will range from 0.2 to 2.0 times the PCP share of the target opportunity depending on actual 2017 performance, based on a separate matrix for each of the two measures.
