# ESE notes — 0001144204-16-136902


## us-gaap:ConsolidationPolicyTextBlock

[0001144204-16-136902:notes:1]
| A. | Principles of Consolidation |

[0001144204-16-136902:notes:2]
The Consolidated Financial Statements include the accounts of ESCO Technologies Inc. (ESCO) and its wholly owned subsidiaries (the Company). All significant intercompany transactions and accounts have been eliminated in consolidation.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001144204-16-136902:notes:3]
| E. | Revenue Recognition |

[0001144204-16-136902:notes:4]
Filtration: Within the Filtration segment, approximately  83% of revenues (approximately  30% of consolidated revenues) are recognized when products are delivered (when title and risk of ownership transfers) or when services are performed for unaffiliated customers.

[0001144204-16-136902:notes:5]
Approximately  17% of segment revenues (approximately 6% of consolidated revenues) are recorded under the percentage-of-completion method. The majority of these contracts are cost-reimbursable contracts which provide for the payment of allowable costs incurred during the performance of the contract plus an incentive fee. The remainder of the contracts are fixed-price contracts. Products accounted for under this guidance include the design, development and manufacture of complex fluid control products, quiet valves, manifolds and systems primarily for the aerospace and military markets. For fixed-price contracts that are accounted for under this guidance, the Company estimates profit as the difference between total estimated revenue and total estimated cost of a contract and recognizes these revenues and costs based on units delivered. The percentage-of-completion method of accounting involves the use of various techniques to estimate expected costs at completion.

[0001144204-16-136902:notes:6]
Test: Within the Test segment, approximately  31% of revenues (approximately 9% of consolidated revenues) are recognized when products are delivered (when title and risk of ownership transfers) or when services are performed for unaffiliated customers.

[0001144204-16-136902:notes:7]
Approximately  69% of the segment’s revenues (approximately  20% of consolidated revenues) are recorded under the percentage-of-completion method due to the complex nature of the enclosures that are designed and produced under these contracts. Products accounted for under this guidance include the construction and installation of complex test chambers to a buyer’s specifications that provide its customers with the ability to measure and contain magnetic, electromagnetic and acoustic energy. As discussed above, for arrangements that are accounted for under this guidance, the Company estimates profit as the difference between total estimated revenue and total estimated cost of a contract and recognizes these revenues and costs based primarily on contract milestones.

[0001144204-16-136902:notes:8]
The percentage-of-completion method of accounting involves the use of various techniques to estimate expected costs at completion. These estimates are based on Management’s judgment and the Company’s substantial experience in developing these types of estimates.

[0001144204-16-136902:notes:9]
USG:  Within the USG segment,  100% of segment revenues (approximately  22% of consolidated revenues) are recognized when products are delivered (when title and risk of ownership transfers), when services are performed for unaffiliated customers or on a straight-line basis over the lease term.

[0001144204-16-136902:notes:10]
Technical Packaging: Within the Technical Packaging segment,  100% of revenues (13% of consolidated revenues) are recognized when products are delivered (when title and risk of ownership transfers) or when services are performed for unaffiliated customers.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001144204-16-136902:notes:11]
| F. | Cash and Cash Equivalents |

[0001144204-16-136902:notes:12]
Cash equivalents include temporary investments that are readily convertible into cash, such as money market funds, with original maturities of three months or less.


## us-gaap:InventoryPolicyTextBlock

[0001144204-16-136902:notes:13]
| I. | Inventories |

[0001144204-16-136902:notes:14]
Inventories are valued at the lower of cost (first-in, first-out) or market value. Inventories are regularly reviewed for excess quantities and obsolescence based upon historical experience, specific identification of discontinued items, future demand, and market conditions. Inventories under long-term contracts reflect accumulated production costs, factory overhead, initial tooling and other related costs less the portion of such costs charged to cost of sales and any unliquidated progress payments.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001144204-16-136902:notes:15]
| J. | Property, Plant and Equipment |

[0001144204-16-136902:notes:16]
Property, plant and equipment are recorded at cost. Depreciation and amortization are computed primarily on a straight-line basis over the estimated useful lives of the assets: buildings,  10-40 years; machinery and equipment,  3-10 years; and office furniture and equipment,  3-10 years. Leasehold improvements are amortized over the remaining term of the applicable lease or their estimated useful lives, whichever is shorter. Long-lived tangible assets are reviewed for impairment whenever events or changes in business circumstances indicate the carrying value of the assets may not be recoverable. Impairment losses are recognized based on fair value.


## us-gaap:IncomeTaxPolicyTextBlock

[0001144204-16-136902:notes:17]
| M. | Income Taxes |

[0001144204-16-136902:notes:18]
Income taxes are accounted for under the asset and liability method. Deferred tax assets and liabilities are recognized for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. Deferred tax assets may be reduced by a valuation allowance if it is more likely than not that some portion or all of the deferred tax assets will not be realized. The effect on deferred tax assets and liabilities of a change in tax rates is recognized in income in the period that includes the enactment date. The Company regularly reviews its deferred tax assets for recoverability and establishes a valuation allowance when Management believes it is more likely than not such assets will not be recovered, taking into consideration historical operating results, expectations of future earnings, tax planning strategies, and the expected timing of the reversals of existing temporary differences.


## ese:AccumulatedOtherComprehensiveIncomeLossPolicyPolicyTextBlock

[0001144204-16-136902:notes:19]
| R. | Accumulated Other Comprehensive Loss |

[0001144204-16-136902:notes:20]
Accumulated other comprehensive loss of $(39.3) million at September 30, 2016 consisted of $(34.5) million related to the pension net actuarial loss; $(4.7) million related to currency translation adjustments; and $(0.1) million related to forward exchange contracts. Accumulated other comprehensive loss of $(32.5) million at September 30, 2015 consisted of $(29.2) million related to the pension net actuarial loss; $(3.2) million related to currency translation adjustments; and $(0.1) million related to forward exchange contracts.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001144204-16-136902:notes:21]
| V. | New Accounting Standards |

[0001144204-16-136902:notes:22]
In February 2016, the FASB issued ASU No. 2016-062, Leases (Topic 842), which, among other things, requires an entity to recognize lease assets and lease liabilities on the balance sheet and disclose key information about leasing arrangements. This new standard will increase an entities’ reported assets and liabilities. The new standard is effective for fiscal years beginning after December 15, 2018 and mandates a modified retrospective transition period for all entities. The Company is currently assessing the impact of this new standard on its consolidated financial statements and related disclosures.

[0001144204-16-136902:notes:23]
In November 2015, the FASB issued ASU No. 2015-17, Balance Sheet Classification of Deferred Taxes, which requires entities to present deferred tax assets and deferred tax liabilities as noncurrent in a classified balance sheet. This new standard is effective for annual periods beginning after December 15, 2016. The Company adopted this new standard during the fourth quarter of 2016 and has applied it on a prospective basis. Therefore, the prior year balance sheet was not retrospectively adjusted.

[0001144204-16-136902:notes:24]
In July 2015, the FASB affirmed its proposed one-year deferral of ASU No. 2014-09, Revenue from Contracts with Customers, which requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The new standard will be effective for annual reporting periods beginning after December 15, 2017, and interim periods within those annual periods. Early application is not permitted. The standard permits the use of either the retrospective or cumulative effect transition method. The Company is currently in the process of evaluating the effect that ASU 2014-09 will have on its consolidated financial statements and related disclosures and selecting the method of transition to the new standard.


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001144204-16-136902:notes:25]
The number of shares used in the calculation of earnings per share for each year presented is as follows:

[0001144204-16-136902:notes:26]
| (in thousands) |  | 2016 |  | 2015 |  | 2014 |  |
| Weighted Average Shares Outstanding — Basic |  |  | 25,762 |  |  | 26,077 |  |  | 26,447 |  |
| Performance- Accelerated Restricted Stock |  |  | 206 |  |  | 188 |  |  | 197 |  |
| Shares — Diluted |  |  | 25,968 |  |  | 26,265 |  |  | 26,644 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001144204-16-136902:notes:27]
| 2. | Acquisitions |

[0001144204-16-136902:notes:28]
2016

[0001144204-16-136902:notes:29]
On September 2, 2016, the Company acquired the stock of Westland Technologies, Inc. (Westland), located in Modesto, California, for a purchase price of approximately $41 million in cash. Westland is a market leader in the design, development and manufacture of elastomeric-based signature reduction solutions which enhance U.S. Naval maritime platform survivability. Westland has annual sales of approximately $25 million. Since the date of acquisition, the operating results for Westland have been included within the Company’s Filtration segment. Based on the preliminary purchase price allocation, the Company recorded tangible assets, net, of $5.5 million, deferred tax liabilities of $10.4 million, goodwill of $17.9 million, and $28.3 million of identifiable intangible assets primarily consisting of customer relationships.

[0001144204-16-136902:notes:30]
On January 29, 2016, the Company acquired Plastique Limited and Plastique Sp. z o.o. (together, Plastique), headquartered in Tunbridge Wells, England with manufacturing locations in Nottingham, England and Poznan, Poland, for a purchase price of approximately $31.6 million (of which $2.7 million is due over the next three years). Plastique is a market leader in the development and manufacture of highly-technical thermoformed plastic and precision molded pulp fiber packaging primarily serving pharmaceutical, personal care, and various specialty end markets. Since the date of acquisition, the operating results for Plastique have been included within the Company’s Technical Packaging segment. Plastique has annual sales of approximately $35 million. Based on the purchase price allocation, the Company recorded tangible assets, net, of $9.6 million, goodwill of $10.2 million, and $11.9 million of identifiable intangible assets primarily consisting of customer relationships.

[0001144204-16-136902:notes:31]
On October 16, 2015, the Company acquired the stock of Fremont Plastics, Inc. (Fremont) for a purchase price of $10.5 million in cash. The Company also purchased for $2 million Fremont’s real property located in Fremont, Indiana. Fremont was a developer, manufacturer, promoter and seller of high quality sterile-ready and non-sterile thin gauge thermoformed medical plastic packaging products. Immediately following the closing of the transaction, Fremont was merged into TEQ, and therefore since the date of acquisition the operating results for Fremont have been included as part of TEQ.

[0001144204-16-136902:notes:32]
2015

[0001144204-16-136902:notes:33]
On January 28, 2015, the Company acquired the assets of Enoserv LLC (Enoserv), headquartered in Tulsa, Oklahoma, for $20.5 million in cash. Enoserv provides utility customers with high quality, user-friendly multi-platform software and has annual revenues of approximately $8 million. Since the date of acquisition the operating results for Enoserv have been included as part of Doble within the Company’s USG segment. Based on the purchase price allocation, the Company recorded approximately $10.0 million of goodwill and $9.0 million of amortizable identifiable intangible assets consisting primarily of customer relationships and developed technology.

[0001144204-16-136902:notes:34]
All of the Company’s acquisitions have been accounted for using the purchase method of accounting and accordingly, the respective purchase prices were allocated to the assets (including intangible assets) acquired and liabilities assumed based on estimated fair values at the date of acquisition. The financial results from these acquisitions have been included in the Company’s financial statements from the date of acquisition. Pro forma financial information related to the Company’s acquisitions was not presented as it was not significant to the Company’s results of operations. None of the goodwill recorded as part of the acquisitions mentioned above is expected to be deductible for U.S. Federal or state income tax purposes.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001144204-16-136902:notes:35]
| 3. | Aclara Divestiture |

[0001144204-16-136902:notes:36]
On March 28, 2014, the Company completed the sale of Aclara to an affiliate of Sun Capital Partners, Inc. The divestiture generated approximately $135 million of gross cash proceeds. A disagreement between the parties over the calculation of the final working capital adjustment was resolved by arbitration on June 15, 2015, resulting in a cash payment to the Company of $2.3 million. Aclara is reflected as discontinued operations in the consolidated financial statements and related notes for all periods presented.

[0001144204-16-136902:notes:37]
Aclara’s pretax earnings (loss) recorded in discontinued operations was $1.2 million and $(48.2) million for the years ended September 30, 2015 and 2014, respectively. The 2014 pretax loss consisted of Aclara’s pretax earnings from its results of operations of $15.6 million and a pretax loss of $63.8 million on the sale of Aclara. Aclara’s net sales were $129.6 million for the year ended September 30, 2014. Aclara’s operations were included within the Company’s USG segment prior to the classification as discontinued operations.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001144204-16-136902:notes:38]
| 18. | Quarterly Financial Information (Unaudited) |

[0001144204-16-136902:notes:39]
|  |  | First |  | Second |  | Third |  | Fourth |  | Fiscal |  |
| (Dollars in thousands, except per share amounts) |  | Quarter |  | Quarter |  | Quarter |  | Quarter |  | Year |  |
| 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 132,833 |  |  | 138,930 |  |  | 140,191 |  |  | 159,505 |  |  | 571,459 |  |
| Net earnings from continuing operations |  |  | 8,829 |  |  | 8,610 |  |  | 11,528 |  |  | 16,915 |  |  | 45,882 |  |
| Net earnings (loss) from discontinued operations |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net earnings |  |  | 8,829 |  |  | 8,610 |  |  | 11,528 |  |  | 16,915 |  |  | 45,882 |  |
| Basic earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings from continuing operations |  |  | 0.34 |  |  | 0.33 |  |  | 0.45 |  |  | 0.66 |  |  | 1.78 |  |
| Net earnings (loss) from discontinued operations |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net earnings |  |  | 0.34 |  |  | 0.33 |  |  | 0.45 |  |  | 0.66 |  |  | 1.78 |  |
| Diluted earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings from continuing operations |  |  | 0.34 |  |  | 0.33 |  |  | 0.44 |  |  | 0.65 |  |  | 1.77 |  |
| Net earnings (loss) from discontinued operations |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net earnings |  |  | 0.34 |  |  | 0.33 |  |  | 0.44 |  |  | 0.65 |  |  | 1.77 |  |
| Dividends declared per common share |  | $ | 0.08 |  |  | 0.08 |  |  | 0.08 |  |  | 0.08 |  |  | 0.32 |  |
| 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 120,547 |  |  | 128,941 |  |  | 134,191 |  |  | 153,612 |  |  | 537,291 |  |
| Net earnings from continuing operations |  |  | 10,023 |  |  | 7,982 |  |  | 10,748 |  |  | 12,983 |  |  | 41,736 |  |
| Net (loss) earnings from discontinued operations |  |  | — |  |  | (372) |  |  | 1,148 |  |  | — |  |  | 776 |  |
| Net earnings |  |  | 10,023 |  |  | 7,610 |  |  | 11,896 |  |  | 12,983 |  |  | 42,512 |  |
| Basic earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings from continuing operations |  |  | 0.38 |  |  | 0.31 |  |  | 0.41 |  |  | 0.50 |  |  | 1.60 |  |
| Net (loss) earnings from discontinued operations |  |  | — |  |  | (0.01) |  |  | 0.04 |  |  | — |  |  | 0.03 |  |
| Net (loss) earnings |  |  | 0.38 |  |  | 0.30 |  |  | 0.45 |  |  | 0.50 |  |  | 1.63 |  |
| Diluted earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings from continuing operations |  |  | 0.38 |  |  | 0.30 |  |  | 0.41 |  |  | 0.50 |  |  | 1.59 |  |
| Net (loss) earnings from discontinued operations |  |  | — |  |  | (0.01) |  |  | 0.04 |  |  | — |  |  | 0.03 |  |
| Net earnings |  |  | 0.38 |  |  | 0.29 |  |  | 0.45 |  |  | 0.50 |  |  | 1.62 |  |
| Dividends declared per common share |  | $ | 0.08 |  |  | 0.08 |  |  | 0.08 |  |  | 0.08 |  |  | 0.32 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001144204-16-136902:notes:40]
| 4. | Goodwill and Other Intangible Assets |

[0001144204-16-136902:notes:41]
Included on the Company’s Consolidated Balance Sheets at September 30, 2016 and 2015 are the following intangible assets gross carrying amounts and accumulated amortization:

[0001144204-16-136902:notes:42]
| (Dollars in millions) |  | 2016 |  | 2015 |  |
| Goodwill |  | $ | 323.6 |  |  | 291.2 |  |
| Intangible assets with determinable lives: |  |  |  |  |  |  |  |
| Patents |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 1.0 |  |  | 1.0 |  |
| Less: accumulated amortization |  |  | 0.8 |  |  | 0.8 |  |
| Net |  | $ | 0.2 |  |  | 0.2 |  |
| Capitalized software |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 54.0 |  |  | 45.5 |  |
| Less: accumulated amortization |  |  | 26.7 |  |  | 20.1 |  |
| Net |  | $ | 27.3 |  |  | 25.4 |  |
| Customer Relationships |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 111.9 |  |  | 70.5 |  |
| Less: accumulated amortization |  |  | 28.6 |  |  | 24.7 |  |
| Net |  | $ | 83.3 |  |  | 45.8 |  |
| Other |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 2.8 |  |  | 2.6 |  |
| Less: accumulated amortization |  |  | 0.9 |  |  | 0.4 |  |
| Net |  | $ | 1.9 |  |  | 2.2 |  |
| Intangible assets with indefinite lives: |  |  |  |  |  |  |  |
| Trade names |  | $ | 119.1 |  |  | 117.1 |  |

[0001144204-16-136902:notes:43]
The Company performed its annual evaluation of goodwill and intangible assets for impairment during the fourth quarter of 2016 and concluded no impairment existed at September 30, 2016.

[0001144204-16-136902:notes:44]
The changes in the carrying amount of goodwill attributable to each business segment for 2016 and 2015 are as follows:

[0001144204-16-136902:notes:45]
|  |  |  |  |  |  |  |  | Technical |  |  |  |
| (Dollars in millions) |  | Filtration |  | Test |  | USG |  | Packaging |  | Total |  |
| Balance as of September 30, 2014 |  | $ | 26.0 |  |  | 34.7 |  |  | 216.8 |  |  | 4.8 |  |  | 282.3 |  |
| Adjustments |  |  | – |  |  | (0.5) |  |  | 9.4 |  |  | – |  |  | 8.9 |  |
| Balance as of September 30, 2015 |  |  | 26.0 |  |  | 34.2 |  |  | 226.2 |  |  | 4.8 |  |  | 291.2 |  |
| Adjustments |  |  | 17.9 |  |  | (0.1) |  |  | – |  |  | 14.6 |  |  | 32.4 |  |
| Balance as of September 30, 2016 |  | $ | 43.9 |  |  | 34.1 |  |  | 226.2 |  |  | 19.4 |  |  | 323.6 |  |

[0001144204-16-136902:notes:46]
Amortization expense related to intangible assets with determinable lives was $11.6 million, $8.9 million and $6.7 million in 2016, 2015 and 2014, respectively. Patents are amortized over the life of the patents, generally 17 years. Capitalized software is amortized over the estimated useful life of the software, generally three to seven years. Customer relationships are generally amortized over twenty years. Intangible asset amortization for fiscal years 2017 through 2021 is estimated at approximately $15 million per year.


## us-gaap:SubsequentEventsTextBlock

[0001144204-16-136902:notes:47]
| 17. | Subsequent Event |

[0001144204-16-136902:notes:48]
On November 7, 2016, the Company acquired aerospace suppliers Mayday Manufacturing Co. (Mayday) and its affiliate, Hi-Tech Metals, Inc. (Hi-Tech), which share a state-of-the-art, expandable  130,000 square foot facility in Denton, Texas, for a purchase price of approximately $75 million in cash. Mayday is a leading manufacturer of mission-critical bushings, pins, sleeves and precision-tolerance machined components for landing gear, rotor heads, engine mounts, flight controls, and actuation systems for the aerospace and defense industry. Hi-Tech is a full-service metal processor offering aerospace OEM’s and Tier 1 suppliers a large portfolio of processing services including anodizing, cadmium and zinc-nickel plating, organic coatings, non-destructive testing, and heat treatment. Mayday and Hi-Tech will be included in the Company’s Filtration segment beginning in 2017.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001144204-16-136902:notes:49]
| 16. | Commitments and Contingencies |

[0001144204-16-136902:notes:50]
The Company leases certain real property, equipment and machinery under non-cancelable operating leases. Rental expense under these operating leases was $6.0 million, $5.2 million and $5.3 million for 2016, 2015 and 2014, respectively.  Future aggregate minimum lease payments under operating leases that have initial or remaining non-cancelable lease terms in excess of one year as of September 30, 2016, are:

[0001144204-16-136902:notes:51]
| (Dollars in thousands) |  |  |  |
| Years ending September 30: |  |  |  |
| 2017 |  |  | 6,351 |  |
| 2018 |  |  | 4,879 |  |
| 2019 |  |  | 3,880 |  |
| 2020 |  |  | 2,493 |  |
| 2021 and thereafter |  |  | 2,988 |  |
| Total |  | $ | 20,591 |  |

[0001144204-16-136902:notes:52]
At September 30, 2016, the Company had $4.9 million in letters of credit outstanding as guarantees of contract performance. As a normal incident of the businesses in which the Company is engaged, various claims, charges and litigation are asserted or commenced from time to time against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. It is the opinion of Management that the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company are adequately reserved for, are covered by insurance, or are not likely to have a material adverse effect on the Company’s results from continuing operations, capital expenditures, or competitive position.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001144204-16-136902:notes:53]
| 15. | Business Segment Information |

[0001144204-16-136902:notes:54]
The Company is organized based on the products and services it offers, and classifies its business operations in segments for financial reporting purposes. Currently, the Company has four reporting segments: Filtration/Fluid Flow (Filtration), RF Shielding and Test (Test), Utility Solutions Group (USG) and Technical Packaging.

[0001144204-16-136902:notes:55]
The Filtration segment’s operations consist of: PTI Technologies Inc., VACCO Industries (VACCO), Crissair, Inc. (Crissair) and Westland Technologies Inc. (Westland). The companies in this segment primarily design and manufacture specialty filtration products including hydraulic filter elements and fluid control devices used in commercial aerospace applications, unique filter mechanisms used in micro-propulsion devices for satellites and custom designed filters for manned aircraft and submarines.

[0001144204-16-136902:notes:56]
Test segment operations consist of ETS-Lindgren Inc. and related subsidiaries (ETS-Lindgren). ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy. ETS-Lindgren also manufactures radio frequency shielding products and components used by manufacturers of medical equipment, communications systems, electronic products, and shielded rooms for high-security data processing and secure communication.

[0001144204-16-136902:notes:57]
The USG segment’s operations consist of Doble Engineering Company and related subsidiaries (Doble). Doble provides high-end, intelligent diagnostic test solutions for the electric power delivery industry and is a leading supplier of power factor and partial discharge testing instruments used to assess the integrity of high-voltage power delivery equipment. Previously, USG also included Aclara Technologies LLC. See Note 3.

[0001144204-16-136902:notes:58]
The Technical Packaging segment’s operations consist of Thermoform Engineered Quality LLC (TEQ) and Plastique. The companies within this segment provide innovative solutions to the medical and commercial markets for thermoformed and precision molded pulp fiber packages and specialty products using a wide variety of thin gauge plastics and pulp.

[0001144204-16-136902:notes:59]
Accounting policies of the segments are the same as those described in the summary of significant accounting policies in Note 1 to the Consolidated Financial Statements. The operating units within each reporting segment have been aggregated because of similar economic characteristics and meet the other aggregation criteria of FASB ASC 280.

[0001144204-16-136902:notes:60]
The Company evaluates the performance of its operating units based on EBIT, which is defined as earnings before interest and taxes. EBIT on a consolidated basis is a non-GAAP financial measure; see “Non-GAAP Financial Measures” in Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations.” Intersegment sales and transfers are not significant. Segment assets consist primarily of customer receivables, inventories, capitalized software and fixed assets directly associated with the production processes of the segment. Segment depreciation and amortization is based upon the direct assets listed above.

[0001144204-16-136902:notes:61]
Net Sales

[0001144204-16-136902:notes:62]
| (Dollars in millions) |  |  |  |  |  |  |  |
| Year ended September 30, |  | 2016 |  | 2015 |  | 2014 |  |
| Filtration |  | $ | 207.8 |  |  | 196.7 |  |  | 196.5 |  |
| Test |  |  | 161.5 |  |  | 177.6 |  |  | 181.8 |  |
| USG |  |  | 127.8 |  |  | 123.6 |  |  | 115.6 |  |
| Technical Packaging |  |  | 74.4 |  |  | 39.4 |  |  | 37.2 |  |
| Consolidated totals |  | $ | 571.5 |  |  | 537.3 |  |  | 531.1 |  |

[0001144204-16-136902:notes:63]
No customer exceeded  10% of sales in 2016 or 2015; one customer exceeded  10% of sales in 2014.

[0001144204-16-136902:notes:64]
EBIT

[0001144204-16-136902:notes:65]
| (Dollars in millions) |  |  |  |  |  |  |  |
| Year ended September 30, |  | 2016 |  | 2015 |  | 2014 |  |
| Filtration |  | $ | 45.2 |  |  | 41.7 |  |  | 36.4 |  |
| Test |  |  | 13.9 |  |  | 9.5 |  |  | 21.1 |  |
| USG |  |  | 31.1 |  |  | 29.6 |  |  | 26.6 |  |
| Technical Packaging |  |  | 9.6 |  |  | 4.9 |  |  | 5.0 |  |
| Reconciliation to consolidated totals (Corporate) |  |  | (30.1) |  |  | (23.4) |  |  | (25.3) |  |
| Consolidated EBIT |  |  | 69.7 |  |  | 62.3 |  |  | 63.8 |  |
| Less: interest expense |  |  | (1.3) |  |  | (0.8) |  |  | (1.6) |  |
| Earnings before income tax |  | $ | 68.4 |  |  | 61.5 |  |  | 62.2 |  |

[0001144204-16-136902:notes:66]
Identifiable Assets

[0001144204-16-136902:notes:67]
| (Dollars in millions) |  |  |  |  |  |
| Year ended September 30, |  | 2016 |  | 2015 |  |
| Filtration |  | $ | 143.5 |  |  | 127.0 |  |
| Test |  |  | 110.9 |  |  | 117.8 |  |
| USG |  |  | 85.4 |  |  | 80.6 |  |
| Technical Packaging |  |  | 40.9 |  |  | 14.8 |  |
| Corporate |  |  | 597.7 |  |  | 524.0 |  |
| Consolidated totals |  | $ | 978.4 |  |  | 864.2 |  |

[0001144204-16-136902:notes:68]
Corporate assets consist primarily of goodwill, deferred taxes, acquired intangible assets, cash balances and assets held for sale.

[0001144204-16-136902:notes:69]
Capital Expenditures

[0001144204-16-136902:notes:70]
| (Dollars in millions) |  |  |  |  |  |  |  |
| Year ended September 30, |  | 2016 |  | 2015 |  | 2014 |  |
| Filtration |  | $ | 3.3 |  |  | 5.0 |  |  | 5.8 |  |
| Test |  |  | 3.3 |  |  | 3.1 |  |  | 1.4 |  |
| USG |  |  | 3.3 |  |  | 3.3 |  |  | 4.1 |  |
| Technical Packaging |  |  | 3.9 |  |  | 1.0 |  |  | 1.2 |  |
| Corporate |  |  | – |  |  | – |  |  | 0.2 |  |
| Consolidated totals |  | $ | 13.8 |  |  | 12.4 |  |  | 12.7 |  |

[0001144204-16-136902:notes:71]
In addition to the above amounts, the Company incurred expenditures for capitalized software of $8.7 million, $6.9 million and $8.6 million in 2016, 2015 and 2014, respectively.

[0001144204-16-136902:notes:72]
Depreciation and Amortization

[0001144204-16-136902:notes:73]
| (Dollars in millions) |  |  |  |  |  |  |  |
| Year ended September 30, |  | 2016 |  | 2015 |  | 2014 |  |
| Filtration |  | $ | 4.0 |  |  | 3.8 |  |  | 4.0 |  |
| Test |  |  | 3.6 |  |  | 3.1 |  |  | 2.7 |  |
| USG |  |  | 8.1 |  |  | 6.2 |  |  | 4.8 |  |
| Technical Packaging |  |  | 2.9 |  |  | 1.4 |  |  | 1.2 |  |
| Corporate |  |  | 5.0 |  |  | 4.1 |  |  | 3.7 |  |
| Consolidated totals |  | $ | 23.6 |  |  | 18.6 |  |  | 16.4 |  |

[0001144204-16-136902:notes:74]
Depreciation expense of property, plant and equipment was $11.9 million, $9.7 million and $9.6 million for 2016, 2015 and 2014, respectively.

[0001144204-16-136902:notes:75]
Geographic Information

[0001144204-16-136902:notes:76]
| (Dollars in millions) |  |  |  |  |  |  |  |
| Year ended September 30, |  | 2016 |  | 2015 |  | 2014 |  |
| United States |  | $ | 403.6 |  |  | 385.5 |  |  | 374.0 |  |
| Asia |  |  | 68.1 |  |  | 70.4 |  |  | 59.9 |  |
| Europe |  |  | 71.6 |  |  | 46.6 |  |  | 62.0 |  |
| Canada |  |  | 12.9 |  |  | 11.6 |  |  | 10.4 |  |
| India |  |  | 2.9 |  |  | 4.3 |  |  | 3.3 |  |
| Other |  |  | 12.4 |  |  | 18.9 |  |  | 21.5 |  |
| Consolidated totals |  | $ | 571.5 |  |  | 537.3 |  |  | 531.1 |  |

[0001144204-16-136902:notes:77]
Long-Lived Assets

[0001144204-16-136902:notes:78]
| (Dollars in millions) |  |  |  |  |  |
| Year ended September 30, |  | 2016 |  | 2015 |  |
| United States |  | $ | 79.9 |  |  | 74.5 |  |
| Europe |  |  | 11.7 |  |  | 2.1 |  |
| Other |  |  | 0.8 |  |  | 0.8 |  |
| Consolidated totals |  | $ | 92.4 |  |  | 77.4 |  |

[0001144204-16-136902:notes:79]
Net sales are attributed to countries based on location of customer. Long-lived assets are attributed to countries based on location of the asset.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001144204-16-136902:notes:80]
| 5. | Accounts Receivable |

[0001144204-16-136902:notes:81]
Accounts receivable, net of the allowance for doubtful accounts, consist of the following at September 30, 2016 and 2015:

[0001144204-16-136902:notes:82]
| (Dollars in thousands) |  | 2016 |  | 2015 |  |
| Commercial |  | $ | 112,280 |  |  | 99,083 |  |
| U.S. Government and prime contractors |  |  | 9,206 |  |  | 3,524 |  |
| Total |  | $ | 121,486 |  |  | 102,607 |  |


## us-gaap:ScheduleOfOtherOperatingCostAndExpenseByComponentTextBlock

[0001144204-16-136902:notes:83]
Items charged to continuing operations during 2016, 2015 and 2014 included the following:

[0001144204-16-136902:notes:84]
| (Dollars in thousands) |  | 2016 |  | 2015 |  | 2014 |  |
| Research and development (R&D) costs: |  |  |  |  |  |  |  |  |  |  |
| Company-sponsored |  |  | 12,863 |  |  | 16,728 |  |  | 16,880 |  |
| Customer-sponsored |  |  | 6,972 |  |  | 6,776 |  |  | 11,586 |  |
| Total R&D |  |  | 19,835 |  |  | 23,504 |  |  | 28,466 |  |
| Other engineering costs |  |  | 12,233 |  |  | 13,899 |  |  | 12,484 |  |
| Total R&D and other engineering costs |  |  | 32,068 |  |  | 37,403 |  |  | 40,950 |  |
| As a % of net sales |  |  | 5.6 | % |  | 7.0 | % |  | 7.7 | % |


## us-gaap:InventoryDisclosureTextBlock

[0001144204-16-136902:notes:85]
| 6. | Inventories |

[0001144204-16-136902:notes:86]
Inventories consist of the following at September 30, 2016 and 2015:

[0001144204-16-136902:notes:87]
| (Dollars in thousands) |  | 2016 |  | 2015 |  |
| Finished goods |  | $ | 19,451 |  |  | 19,120 |  |
| Work in process |  |  | 37,922 |  |  | 33,176 |  |
| Raw materials |  |  | 48,169 |  |  | 47,490 |  |
| Total |  | $ | 105,542 |  |  | 99,786 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001144204-16-136902:notes:88]
| 7. | Related Parties |

[0001144204-16-136902:notes:89]
One of the Company’s directors is an officer at a customer of the Company’s subsidiary Doble. Doble sells products, leases equipment and provides testing services to the customer in the ordinary course of Doble’s business. The total amount of these sales were approximately $1.4 million, $0.8 million and $0.8 million during fiscal 2016, 2015 and 2014, respectively. All transactions between Doble and the customer are intended to be and have been consistent with Doble’s normal commercial terms offered to its customers, and the Company’s Board of Directors has determined that the relationship between the Company and the customer is not material and did not impair either the Company’s or the director’s independence.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001144204-16-136902:notes:90]
| 8. | Income Tax Expense |

[0001144204-16-136902:notes:91]
Total income tax expense (benefit) for 2016, 2015 and 2014 was allocated to income tax expense as follows:

[0001144204-16-136902:notes:92]
| (Dollars in thousands) |  | 2016 |  | 2015 |  | 2014 |  |
| Income tax expense from Continuing Operations |  | $ | 22,538 |  |  | 19,785 |  |  | 19,594 |  |
| Income tax expense (benefit) from Discontinued Operations |  |  | – |  |  | 390 |  |  | (6,034) |  |
| Total income tax expense |  | $ | 22,538 |  |  | 20,175 |  |  | 13,560 |  |

[0001144204-16-136902:notes:93]
The components of income from continuing operations before income taxes for 2016, 2015 and 2014 consisted of the following:

[0001144204-16-136902:notes:94]
| (Dollars in thousands) |  | 2016 |  | 2015 |  | 2014 |  |
| United States |  | $ | 62,353 |  |  | 56,661 |  |  | 56,196 |  |
| Foreign |  |  | 6,067 |  |  | 4,860 |  |  | 6,011 |  |
| Total income before income taxes |  | $ | 68,420 |  |  | 61,521 |  |  | 62,207 |  |

[0001144204-16-136902:notes:95]
The principal components of income tax expense (benefit) from continuing operations for 2016, 2015 and 2014 consist of:

[0001144204-16-136902:notes:96]
| (Dollars in thousands) |  | 2016 |  | 2015 |  | 2014 |  |
| Federal: |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 19,236 |  |  | 11,906 |  |  | 18,756 |  |
| Deferred |  |  | (909) |  |  | 5,406 |  |  | (2,442) |  |
| State and local: |  |  |  |  |  |  |  |  |  |  |
| Current |  |  | 1,674 |  |  | 867 |  |  | 1,397 |  |
| Deferred |  |  | (222) |  |  | 16 |  |  | (245) |  |
| Foreign: |  |  |  |  |  |  |  |  |  |  |
| Current |  |  | 1,899 |  |  | 1,525 |  |  | 2,044 |  |
| Deferred |  |  | 860 |  |  | 65 |  |  | 84 |  |
| Total |  | $ | 22,538 |  |  | 19,785 |  |  | 19,594 |  |

[0001144204-16-136902:notes:97]
The actual income tax expense (benefit) from continuing operations for 2016, 2015 and 2014 differs from the expected tax expense for those years (computed by applying the U.S. Federal corporate statutory rate) as follows:

[0001144204-16-136902:notes:98]
|  |  | 2016 |  | 2015 |  | 2014 |  |
| Federal corporate statutory rate |  |  | 35.0 | % |  | 35.0 | % |  | 35.0 | % |
| State and local, net of Federal benefits |  |  | 2.0 |  |  | 1.2 |  |  | 2.0 |  |
| Foreign |  |  | (1.0) |  |  | (1.5) |  |  | (1.7) |  |
| Research credit |  |  | (2.5) |  |  | (1.8) |  |  | (1.0) |  |
| Domestic production deduction |  |  | (2.8) |  |  | (2.6) |  |  | (2.9) |  |
| Change in uncertain tax positions |  |  | – |  |  | (0.2) |  |  | (2.9) |  |
| Executive compensation |  |  | 0.9 |  |  | 0.9 |  |  | 1.3 |  |
| Valuation allowance |  |  | 1.8 |  |  | 1.0 |  |  | 1.3 |  |
| Other, net |  |  | (0.5) |  |  | 0.2 |  |  | 0.4 |  |
| Effective income tax rate |  |  | 32.9 | % |  | 32.2 | % |  | 31.5 | % |

[0001144204-16-136902:notes:99]
The tax effects of temporary differences that give rise to significant portions of the deferred tax assets and liabilities at September 30, 2016 and 2015 are presented below:

[0001144204-16-136902:notes:100]
| (Dollars in thousands) |  | 2016 |  | 2015 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |
| Inventories |  | $ | 7,553 |  |  | 6,336 |  |
| Pension and other postretirement benefits |  |  | 13,978 |  |  | 11,663 |  |
| Net operating loss carryforward — domestic |  |  | 372 |  |  | 520 |  |
| Net operating loss carryforward — foreign |  |  | 4,991 |  |  | 4,135 |  |
| Other compensation-related costs and other cost accruals |  |  | 13,678 |  |  | 11,785 |  |
| State credit carryforward |  |  | 1,944 |  |  | 1,704 |  |
| Total deferred tax assets |  |  | 42,516 |  |  | 36,143 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |
| Goodwill |  |  | (15,528) |  |  | (14,829) |  |
| Acquisition assets |  |  | (69,934) |  |  | (57,415) |  |
| Depreciation, software amortization |  |  | (20,285) |  |  | (18,681) |  |
| Net deferred tax liabilities before valuation allowance |  |  | (63,231) |  |  | (54,782) |  |
| Less valuation allowance |  |  | (5,711) |  |  | (4,129) |  |
| Net deferred tax liabilities |  | $ | (68,942) |  |  | (58,911) |  |

[0001144204-16-136902:notes:101]
The Company has a foreign net operating loss (NOL) carryforward of $18.7 million at September 30, 2016, which reflects tax loss carryforwards in Brazil, Germany, India, Finland, China, South Africa and the United Kingdom. $17.7 million of the tax loss carryforwards have no expiration date while the remaining $1.0 million will expire between 2019 and 2025. The Company has state NOL carryforwards of $0.3 million at September 30, 2016 which expire between 2025 and 2036. The Company also has net state research and other credit carryforwards of $1.9 million of which $1.5 million expires between 2025 and 2036. The remaining $0.4 million does not have an expiration date.

[0001144204-16-136902:notes:102]
The valuation allowance for deferred tax assets as of September 30, 2016 and 2015 was $5.7 million and $4.1 million, respectively. The net change in the total valuation allowance for each of the years ended September 30, 2016 and 2015 was an increase of $1.6 million and a decrease of $0.2 million, respectively. The Company has established a valuation allowance against state credit carryforwards of $0.6 million and $0.5 million at September 30, 2016 and 2015. In addition, the Company has established a valuation allowance against state NOL carryforwards that are not expected to be realized in future periods of $0.3 million at both September 30, 2016 and 2015. Lastly, the Company has established a valuation allowance against certain NOL carryforwards in foreign jurisdictions which may not be realized in future periods. The valuation allowance established against the foreign NOL carryforwards was $4.8 million and $3.3 million at September 30, 2016 and 2015, respectively.

[0001144204-16-136902:notes:103]
The Company’s foreign subsidiaries have accumulated unremitted earnings of $46.3 million and cash of $45.2 million at September 30, 2016. No deferred taxes have been provided on these accumulated unremitted earnings because these funds are not needed to meet the liquidity requirements of the Company’s U.S. operations and it is the Company’s intention to indefinitely reinvest these earnings in continuing international operations. In the event these foreign entities’ earnings were distributed, it is estimated that U.S. taxes, net of available foreign tax credits, of approximately $7.4 million would be due, which would correspondingly reduce the Company’s net earnings. No significant portion of the Company’s foreign subsidiaries’ earnings was taxed at a very low tax rate.

[0001144204-16-136902:notes:104]
The Company had $0.1 million of unrecognized benefits as of both September 30, 2016 and 2015, which, net of Federal benefit, if recognized, would affect the Company’s effective tax rate.

[0001144204-16-136902:notes:105]
The Company does not anticipate a material change in the amount of unrecognized tax benefits in the next 12 months. The Company’s policy is to include interest related to unrecognized tax benefits in income tax expense and penalties in operating expense. As of September 30, 2016, 2015 and 2014, the Company had zero accrued interest related to uncertain tax positions, net of Federal income tax benefit, on its Consolidated Balance Sheets. No significant penalties have been accrued.

[0001144204-16-136902:notes:106]
The principal jurisdictions for which the Company files income tax returns are U.S. Federal and the various city, state, and international locations where the Company has operations. The U.S. Federal tax years for the periods ended September 30, 2012 and forward remain subject to income tax examination. Various state tax years for the periods ended September 30, 2012 and forward remain subject to income tax examinations. The Company is subject to income tax in many jurisdictions outside the United States, none of which is individually significant.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001144204-16-136902:notes:107]
| 13. | Derivative Financial Instruments |

[0001144204-16-136902:notes:108]
Market risks relating to the Company’s operations result primarily from changes in interest rates and changes in foreign currency exchange rates. The Company is exposed to market risk related to changes in interest rates and selectively uses derivative financial instruments, including forward contracts and swaps, to manage these risks. During the second quarter of 2016, the Company entered into several forward contracts to purchase pounds sterling (GBP) to hedge two deferred payments due in connection with the acquisition of Plastique. During 2015, the Company entered into a forward contract to purchase Euros to hedge the foreign currency risk related to Euro-denominated inventory payments. The Company expects hedging gains or losses to be essentially offset by losses or gains on the related underlying exposures. The amounts ultimately recognized may differ for open positions, which remain subject to ongoing market price fluctuations until settlement. The derivative instruments are designated as cash flow hedges and the gain or loss on the derivative is deferred in accumulated other comprehensive income until recognized in earnings with the underlying hedged item. The fair value of the foreign currency derivative is classified in accrued expenses on the Company’s Consolidated Balance Sheets. The following is a summary of the notional transaction amounts and fair values for the Company’s outstanding derivative financial instruments as of September 30, 2016.

[0001144204-16-136902:notes:109]
|  |  | Notional Amount |  | Fair Value |  |
| (In thousands) |  | (Currency) |  | (US$) |  |
| Forward contract |  |  | 309 (Euro) |  |  | (25) |  |
| Forward contracts |  |  | 1,859 (GBP) |  |  | (233) |  |

[0001144204-16-136902:notes:110]
Fair value of financial instruments

[0001144204-16-136902:notes:111]
The Company’s forward contracts are classified within Level 2 of the valuation hierarchy in accordance with FASB Accounting Standards Codification (ASC) 825, as presented below as of September 30, 2016:

[0001144204-16-136902:notes:112]
| (In thousands) |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Forward contracts |  | $ | – |  |  | (258) |  |  | – |  |  | (258) |  |

[0001144204-16-136902:notes:113]
Valuation was based on third party evidence of similarly priced derivative instruments.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001144204-16-136902:notes:114]
| 12. | Retirement and Other Benefit Plans |

[0001144204-16-136902:notes:115]
Substantially all domestic employees were covered by a defined contribution pension plan maintained by the Company. Effective December 31, 2003, the Company’s defined benefit plan was frozen and no additional benefits have been accrued after that date. As a result, the accumulated benefit obligation and projected benefit obligation are equal. These frozen retirement income benefits are provided to employees under defined benefit pay-related and flat-dollar plans, which are noncontributory. The annual contributions to the defined benefit retirement plan equal or exceed the minimum funding requirements of the Employee Retirement Income Security Act. In addition to providing retirement income benefits, the Company provides unfunded postretirement health and life insurance benefits to certain retirees. To qualify, an employee must retire at age 55 or later and the employee’s age plus service must equal or exceed 75. Retiree contributions are defined as a percentage of medical premiums. Consequently, retiree contributions increase with increases in the medical premiums. The life insurance plans are noncontributory and provide coverage of a flat dollar amount for qualifying retired employees. Effective December 31, 2004, no new retirees were eligible for life insurance benefits.

[0001144204-16-136902:notes:116]
The Company uses a measurement date of September 30 for its pension and other postretirement benefit plans. The Company has an accrued benefit liability of $0.7 million and $0.9 million at September 30, 2016 and 2015, respectively, related to its other postretirement benefit obligations. All other information related to its postretirement benefit plans is not considered material to the Company’s results of operations or financial condition.

[0001144204-16-136902:notes:117]
The following tables provide a reconciliation of the changes in the pension plans and fair value of assets over the two-year period ended September 30, 2016, and a statement of the funded status as of September 30, 2016 and 2015:

[0001144204-16-136902:notes:118]
| (Dollars in millions) |  |  |  |  |  |
| Reconciliation of benefit obligation |  | 2016 |  | 2015 |  |
| Net benefit obligation at beginning of year |  | $ | 93.6 |  |  | 92.5 |  |
| Interest cost |  |  | 3.9 |  |  | 3.8 |  |
| Actuarial loss |  |  | 11.1 |  |  | 4.5 |  |
| Gross benefits paid |  |  | (7.8) |  |  | (7.2) |  |
| Settlements |  |  | (0.2) |  |  | – |  |
| Net benefit obligation at end of year |  | $ | 100.6 |  |  | 93.6 |  |

[0001144204-16-136902:notes:119]
| (Dollars in millions) |  |  |  |  |  |
| Reconciliation of fair value of plan assets |  | 2016 |  | 2015 |  |
| Fair value of plan assets at beginning of year |  | $ | 63.0 |  |  | 73.0 |  |
| Actual return on plan assets |  |  | 5.1 |  |  | (3.7) |  |
| Employer contributions |  |  | 0.5 |  |  | 0.9 |  |
| Gross benefits paid |  |  | (7.8) |  |  | (7.2) |  |
| Settlements |  |  | (0.2) |  |  | – |  |
| Fair value of plan assets at end of year |  | $ | 60.6 |  |  | 63.0 |  |

[0001144204-16-136902:notes:120]
| (Dollars in millions) |  |  |  |  |  |
| Funded Status |  | 2016 |  | 2015 |  |
| Funded status at end of year |  | $ | (40.0) |  |  | (30.6) |  |
| Accrued benefit cost |  |  | (40.0) |  |  | (30.6) |  |
| Amounts recognized in the Balance Sheet consist of: |  |  |  |  |  |  |  |
| Current liability |  |  | (0.2) |  |  | (0.2) |  |
| Noncurrent liability |  |  | (39.8) |  |  | (30.4) |  |
| Accumulated other comprehensive (income)/loss (before tax effect) |  |  | 56.0 |  |  | 47.6 |  |
| Amounts recognized in accumulated other comprehensive (income)/loss consist of: |  |  |  |  |  |  |  |
| Net actuarial loss |  |  | 56.0 |  |  | 47.6 |  |
| Accumulated other comprehensive (income)/loss (before tax effect) |  | $ | 56.0 |  |  | 47.6 |  |

[0001144204-16-136902:notes:121]
The estimated amount that will be amortized from accumulated other comprehensive (income) loss into net periodic benefit cost (income) in 2017 is $2.5 million.

[0001144204-16-136902:notes:122]
The following table provides the components of net periodic benefit cost for the plans for 2016, 2015 and 2014:

[0001144204-16-136902:notes:123]
| (Dollars in millions) |  | 2016 |  | 2015 |  | 2014 |  |
| Service cost |  | $ | – |  |  | – |  |  | – |  |
| Interest cost |  |  | 3.9 |  |  | 3.8 |  |  | 4.0 |  |
| Expected return on plan assets |  |  | (4.4) |  |  | (4.5) |  |  | (4.4) |  |
| Net actuarial loss |  |  | 2.0 |  |  | 1.8 |  |  | 1.6 |  |
| Settlement gain |  |  | – |  |  | – |  |  | – |  |
| Net periodic benefit cost |  |  | 1.5 |  |  | 1.1 |  |  | 1.2 |  |
| Defined contribution plans |  |  | 3.5 |  |  | 3.4 |  |  | 3.3 |  |
| Total |  | $ | 5.0 |  |  | 4.5 |  |  | 4.5 |  |

[0001144204-16-136902:notes:124]
The discount rate used in measuring the Company’s pension obligations was developed by matching yields of actual high-quality corporate bonds to expected future pension plan cash flows (benefit payments). Over 400 Aa-rated, non-callable bonds with a wide range of maturities were used in the analysis. After using the bond yields to determine the present value of the plan cash flows, a single representative rate that resulted in the same present value was developed. The expected long-term rate of return on plan assets assumption was determined by reviewing the actual investment return of the plans since inception and evaluating those returns in relation to expectations of various investment organizations to determine whether long-term future returns are expected to differ significantly from the past.

[0001144204-16-136902:notes:125]
The following weighted-average assumptions were used to determine the net periodic benefit cost for the pension plans:

[0001144204-16-136902:notes:126]
|  |  | 2016 |  | 2015 |  | 2014 |  |
| Discount rate |  |  | 4.25 | % |  | 4.25 | % |  | 4.75 | % |
| Rate of increase in compensation levels |  |  | N/A |  |  | N/A |  |  | N/A |  |
| Expected long-term rate of return on assets |  |  | 6.75 | % |  | 6.75 | % |  | 7.00 | % |

[0001144204-16-136902:notes:127]
The following weighted-average assumptions were used to determine the net periodic benefit obligations for the pension plans:

[0001144204-16-136902:notes:128]
|  |  | 2016 |  | 2015 |  |
| Discount rate |  |  | 3.25 | % |  | 4.25 | % |
| Rate of increase in compensation levels |  |  | N/A |  |  | N/A |  |

[0001144204-16-136902:notes:129]
The assumed rate of increase in compensation levels is not applicable in 2016, 2015 and 2014 as the plan was frozen in earlier years.

[0001144204-16-136902:notes:130]
The asset allocation for the Company’s pension plans at the end of 2016 and 2015, the Company’s acceptable range and the target allocation for 2017, by asset category, are as follows:

[0001144204-16-136902:notes:131]
|  |  | Target |  |  |  |  | Percentage of Plan Assets |  |
|  |  | Allocation |  | Acceptable |  | at Year-end |  |
| Asset Category |  | 2017 |  | Range |  | 2016 |  | 2015 |  |
| Return seeking |  |  | 60 | % |  | 55-65 | % |  | 59 | % |  | 62 | % |
| Liability hedging |  |  | 40 | % |  | 35-45 | % |  | 38 | % |  | 37 | % |
| Cash/cash equivalents |  |  | – |  |  | 0-5 | % |  | 3 | % |  | 1 | % |

[0001144204-16-136902:notes:132]
The Company’s pension plan assets are managed by outside investment managers and assets are rebalanced when the target ranges are exceeded. Pension plan assets consist principally of funds which invest in marketable securities including common stocks, bonds, and interest-bearing deposits. The Company’s investment strategy with respect to pension assets is to achieve a total rate of return (income and capital appreciation) that is sufficient to accomplish the purpose of providing retirement benefits to all eligible and future retirees of the pension plan. The Company regularly monitors performance and compliance with investment guidelines.

[0001144204-16-136902:notes:133]
Fair Value of Financial Measurements

[0001144204-16-136902:notes:134]
The fair values of the Company’s defined benefit plan investments as of September 30, 2016 and 2015, by asset category, were as follows:

[0001144204-16-136902:notes:135]
| (Dollars in millions) |  | 2016 |  | 2015 |  |
| Investments at fair value: |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1.6 |  |  | 0.8 |  |
| Common and preferred stock funds: |  |  |  |  |  |  |  |
| Domestic large capitalization |  |  | 8.9 |  |  | 9.9 |  |
| Domestic small/mid capitalization |  |  | 2.7 |  |  | 3.3 |  |
| International funds |  |  | 12.3 |  |  | 13.5 |  |
| Fixed income funds |  |  | 30.6 |  |  | 31.1 |  |
| Real estate investment funds |  |  | 4.5 |  |  | 4.4 |  |
| Total investments at fair value |  | $ | 60.6 |  |  | 63.0 |  |

[0001144204-16-136902:notes:136]
The following methods were used to estimate the fair value of each class of financial instrument:

[0001144204-16-136902:notes:137]
Cash and cash equivalents: The carrying value of cash represents fair value as it consists of actual currency.

[0001144204-16-136902:notes:138]
Investment Funds: The fair value of the investment funds, which offer daily redemptions, is determined based on the published net asset value of the funds as a practical expedient for fair value.

[0001144204-16-136902:notes:139]
Expected Cash Flows

[0001144204-16-136902:notes:140]
Information about the expected cash flows for the pension and other postretirement benefit plans follows:

[0001144204-16-136902:notes:141]
|  |  | Pension |  | Other |  |
| (Dollars in millions) |  | Benefits |  | Benefits |  |
| Expected Employer Contributions — 2017 |  | $ | 2.9 |  |  | 0.1 |  |
| Expected Benefit Payments: |  |  |  |  |  |  |  |
| 2017 |  |  | 4.8 |  |  | 0.1 |  |
| 2018 |  |  | 4.9 |  |  | 0.1 |  |
| 2019 |  |  | 5.1 |  |  | 0.1 |  |
| 2020 |  |  | 5.7 |  |  | 0.1 |  |
| 2021 |  |  | 5.4 |  |  | 0.1 |  |
| 2022-2026 |  | $ | 28.9 |  |  | 0.4 |  |


## us-gaap:DebtDisclosureTextBlock

[0001144204-16-136902:notes:142]
| 9. | Debt |

[0001144204-16-136902:notes:143]
Debt consists of the following at September 30, 2016 and 2015:

[0001144204-16-136902:notes:144]
| (Dollars in thousands) |  | 2016 |  | 2015 |  |
| Revolving credit facility, including current portion |  | $ | 110,000 |  |  | 50,000 |  |
| Current portion of long-term debt |  |  | (20,000) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 90,000 |  |  | 30,000 |  |

[0001144204-16-136902:notes:145]
On December 21, 2015, the Company amended its existing credit facility to extend the maturity date from May 13, 2017 through December 21, 2020, and to reduce the outstanding borrowing rates and commitment fees. Consistent with the prior credit facility, the amended facility includes a $450 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the new facility is comprised of a diverse group of nine banks led by JP Morgan Chase Bank, N.A., as Administrative Agent.

[0001144204-16-136902:notes:146]
At September 30, 2016, the Company had approximately $335 million available to borrow under the Credit Facility, plus a $250 million increase option, in addition to $53.8 million cash on hand. The Company classified $20.0 million as the current portion of long-term debt as of September 30, 2016, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months.

[0001144204-16-136902:notes:147]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from  12.5 to  27.5 basis points per annum on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a  65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. During 2016 and 2015, the maximum aggregate short-term borrowings at any month-end were $110 million and $83 million, respectively; the average aggregate short-term borrowings outstanding based on month-end balances were $89.2 million and $68.5 million, respectively; and the weighted average interest rates were  1.58%,  1.27% and  1.48% for 2016, 2015 and 2014, respectively. The letters of credit issued and outstanding under the Credit Facility totaled $4.9 million and $8.0 million at September 30, 2016 and 2015, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001144204-16-136902:notes:148]
| 10. | Capital Stock |

[0001144204-16-136902:notes:149]
The  30,364,183 and  30,358,864 common shares as presented in the accompanying Consolidated Balance Sheets at September 30, 2016 and 2015 represent the actual number of shares issued at the respective dates. The Company held  4,647,322 and  4,542,214 common shares in treasury at September 30, 2016 and 2015, respectively.

[0001144204-16-136902:notes:150]
In August 2012, the Company’s Board of Directors authorized a common stock repurchase program under which the Company may repurchase shares of its stock from time to time in its discretion, in the open market or otherwise, up to a maximum total repurchase amount of $100 million (or such lesser amount as may be permitted under the Company’s bank credit agreements). This program has been repeatedly extended by the Company’s Board of Directors and is currently scheduled to expire September 30, 2017. The Company repurchased approximately  120,000 shares for $4.3 million in 2016,  517,000 shares for $18.2 million in 2015, and  350,000 shares for $12.0 million in 2014.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001144204-16-136902:notes:151]
| O. | Foreign Currency Translation |

[0001144204-16-136902:notes:152]
The financial statements of the Company’s foreign operations are translated into U.S. dollars in accordance with FASB ASC Topic 830, Foreign Currency Matters. The resulting translation adjustments are recorded as a separate component of accumulated other comprehensive income.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001144204-16-136902:notes:153]
| P. | Earnings Per Share |

[0001144204-16-136902:notes:154]
Basic earnings per share is calculated using the weighted average number of common shares outstanding during the period. Diluted earnings per share is calculated using the weighted average number of common shares outstanding during the period plus shares issuable upon the assumed exercise of dilutive common share options and vesting of performance-accelerated restricted shares using the treasury stock method.


## us-gaap:DerivativesPolicyTextBlock

[0001144204-16-136902:notes:155]
| T. | Derivative Financial Instruments |

[0001144204-16-136902:notes:156]
All derivative financial instruments are reported on the balance sheet at fair value. The accounting for changes in fair value of a derivative instrument depends on whether it has been designated and qualifies as a hedge and on the type of hedge. For each derivative instrument designated as a cash flow hedge, the effective portion of the gain or loss on the derivative is deferred in accumulated other comprehensive income until recognized in earnings with the underlying hedged item. For each derivative instrument designated as a fair value hedge, the gain or loss on the derivative and the offsetting gain or loss on the hedged item are recognized immediately in earnings. Regardless of type, a fully effective hedge will result in no net earnings impact while the derivative is outstanding. To the extent that any hedge is ineffective at offsetting cash flow or fair value changes in the underlying hedged item, there could be a net earnings impact.


## us-gaap:ScheduleOfNonvestedShareActivityTableTextBlock

[0001144204-16-136902:notes:157]
The following summary presents information regarding outstanding PARS awards as of the specified dates, and changes during the specified periods:

[0001144204-16-136902:notes:158]
|  |  | FY 2016 |  | FY 2015 |  | FY 2014 |  |
|  |  |  |  | Estimated |  |  |  | Estimated |  |  |  | Estimated |  |
|  |  |  |  | Weighted |  |  |  | Weighted |  |  |  | Weighted |  |
|  |  | Shares |  | Avg. Price |  | Shares |  | Avg. Price |  | Shares |  | Avg. Price |  |
| Nonvested at October 1, |  |  | 326,536 |  | $ | 35.29 |  |  | 332,340 |  | $ | 32.23 |  |  | 425,245 |  | $ | 33.29 |  |
| Granted |  |  | 120,902 |  | $ | 35.75 |  |  | 123,501 |  | $ | 34.33 |  |  | 109,404 |  | $ | 33.12 |  |
| Vested |  |  | (8,000) |  | $ | 36.06 |  |  | (129,305) |  | $ | 26.66 |  |  | (168,809) |  | $ | 35.13 |  |
| Cancelled |  |  | (12,000) |  | $ | 35.47 |  |  | – |  |  | – |  |  | (33,500) |  | $ | 34.08 |  |
| Nonvested at September 30, |  |  | 427,438 |  | $ | 35.40 |  |  | 326,536 |  | $ | 35.29 |  |  | 332,340 |  | $ | 32.23 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001144204-16-136902:notes:159]
| 1. | Summary of Significant Accounting Policies |

[0001144204-16-136902:notes:160]
| B. | Basis of Presentation |

[0001144204-16-136902:notes:161]
The Company’s fiscal year ends September 30. Throughout these Consolidated Financial Statements, unless the context indicates otherwise, references to a year (for example 2016) refer to the Company’s fiscal year ending on September 30 of that year. Certain prior period amounts have been reclassified to conform to the current period presentation.

[0001144204-16-136902:notes:162]
Aclara is reflected as discontinued operations in the consolidated financial statements and related notes for all periods presented, in accordance with accounting principles generally accepted in the United States of America (GAAP). See Note 3.

[0001144204-16-136902:notes:163]
| C. | Nature of Operations |

[0001144204-16-136902:notes:164]
The Company is organized based on the products and services it offers, and classifies its business operations in segments for financial reporting purposes. Beginning in the second quarter of 2016 Management expanded the presentation of its reporting segments to include a fourth segment, Technical Packaging. This segment was created to separately disclose TEQ along with the recently acquired Plastique and Fremont businesses, as they no longer met the criteria for aggregation with the Filtration segment. Prior period segment amounts have been reclassified to conform to the current period presentation.

[0001144204-16-136902:notes:165]
Under the current organizational structure, the Company has four segments for financial reporting purposes: Filtration, RF Shielding and Test (Test), Utility Solutions Group (USG) and Technical Packaging.

[0001144204-16-136902:notes:166]
Filtration: The companies within this segment primarily design and manufacture specialty filtration products including hydraulic filter elements and fluid control devices used in commercial aerospace applications, unique filter mechanisms used in micro-propulsion devices for satellites and custom designed filters for manned aircraft and submarines.

[0001144204-16-136902:notes:167]
Test: ETS-Lindgren Inc. provides its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy.

[0001144204-16-136902:notes:168]
USG: Doble provides high-end, intelligent, diagnostic test solutions for the electric power delivery industry.

[0001144204-16-136902:notes:169]
Technical Packaging: The companies within this segment provide innovative solutions to the medical and commercial markets for thermoformed and precision molded pulp fiber packages and specialty products using a wide variety of thin gauge plastics and pulp.

[0001144204-16-136902:notes:170]
| D. | Use of Estimates |

[0001144204-16-136902:notes:171]
The preparation of financial statements in conformity with GAAP requires Management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.

[0001144204-16-136902:notes:172]
| G. | Accounts Receivable |

[0001144204-16-136902:notes:173]
Accounts receivable have been reduced by an allowance for amounts that the Company estimates are uncollectible in the future. This estimated allowance is based on Management’s evaluation of the financial condition of the customer and historical write-off experience.

[0001144204-16-136902:notes:174]
| H. | Costs and Estimated Earnings on Long-Term Contracts |

[0001144204-16-136902:notes:175]
Costs and estimated earnings on long-term contracts represent unbilled revenues, including accrued profits, accounted for under the percentage-of-completion method, net of progress billings.

[0001144204-16-136902:notes:176]
| K. | Goodwill and Other Long-Lived Assets |

[0001144204-16-136902:notes:177]
Goodwill represents the excess of purchase costs over the fair value of net identifiable assets acquired in business acquisitions. Management annually reviews goodwill and other long-lived assets with indefinite useful lives for impairment or whenever events or changes in circumstances indicate the carrying amount may not be recoverable. If the Company determines that the carrying value of the long-lived asset may not be recoverable, a permanent impairment charge is recorded for the amount by which the carrying value of the long-lived asset exceeds its fair value. Fair value is measured based on a discounted cash flow method using a discount rate determined by Management to be commensurate with the risk inherent in the Company’s current business model.

[0001144204-16-136902:notes:178]
Other intangible assets represent costs allocated to identifiable intangible assets, principally customer relationships, capitalized software, patents, trademarks, and technology rights. Intangible assets with estimable useful lives are amortized over their respective estimated useful lives to their estimated residual values, and are reviewed for impairment whenever events or changes in business circumstances indicate the carrying value of the assets may not be recoverable. See Note 4 regarding goodwill and other intangible assets activity.

[0001144204-16-136902:notes:179]
| L. | Capitalized Software |

[0001144204-16-136902:notes:180]
The costs incurred for the development of computer software that will be sold, leased, or otherwise marketed are charged to expense when incurred as research and development until technological feasibility has been established for the product. Technological feasibility is typically established upon completion of a detailed program design. Costs incurred after this point are capitalized on a project-by-project basis. Capitalized costs consist of internal and external development costs. Upon general release of the product to customers, the Company ceases capitalization and begins amortization, which is calculated on a project-by-project basis as the greater of (1) the ratio of current gross revenues for a product to the total of current and anticipated future gross revenues for the product or (2) the straight-line method over the estimated economic life of the product. The Company generally amortizes the software development costs over a three-to-seven year period based upon the estimated future economic life of the product. Factors considered in determining the estimated future economic life of the product include anticipated future revenues, and changes in software and hardware technologies. Management annually reviews the carrying values of capitalized costs for impairment or whenever events or changes in circumstances indicate the carrying amount may not be recoverable. If expected cash flows are insufficient to recover the carrying amount of the asset, then an impairment loss is recognized to state the asset at its net realizable value.

[0001144204-16-136902:notes:181]
| N. | Research and Development Costs |

[0001144204-16-136902:notes:182]
Company-sponsored research and development costs include research and development and bid and proposal efforts related to the Company’s products and services. Company-sponsored product development costs are charged to expense when incurred. Customer-sponsored research and development costs incurred pursuant to contracts are accounted for similarly to other program costs. Customer-sponsored research and development costs refer to certain situations whereby customers provide funding to support specific contractually defined research and development costs.

[0001144204-16-136902:notes:183]
| Q. | Share-Based Compensation |

[0001144204-16-136902:notes:184]
The Company provides compensation benefits to certain key employees under several share-based plans providing for employee stock options and/or performance-accelerated restricted shares (restricted shares), and to non-employee directors under a non-employee directors compensation plan. Share-based payment expense is measured at the grant date based on the fair value of the award and is recognized on a straight-line basis over the requisite service period (generally the vesting period of the award).

[0001144204-16-136902:notes:185]
| S. | Deferred Revenue And Costs |

[0001144204-16-136902:notes:186]
Deferred revenue and costs are recorded when products or services have been provided but the criteria for revenue recognition have not been met. If there is a customer acceptance provision or there is uncertainty about customer acceptance, revenue and costs are deferred until the customer has accepted the product or service.

[0001144204-16-136902:notes:187]
| U. | Fair Value Measurements |

[0001144204-16-136902:notes:188]
Fair value is defined as the price at which an asset could be exchanged in a current transaction between knowledgeable, willing parties or the amount that would be paid to transfer a liability to a new obligor, not the amount that would be paid to settle the liability with the creditor. Where available, fair value is based on observable market prices or parameters or derived from such prices or parameters. Where observable prices or inputs are not available, valuation models are applied. These valuation techniques involve some level of Management estimation and judgment, the degree of which is dependent on the price transparency for the instruments or market and the instruments’ complexity.

[0001144204-16-136902:notes:189]
The accounting guidance establishes a three-level hierarchy for disclosure of fair value measurements, based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date, as follows:

[0001144204-16-136902:notes:190]
Level 1 – Inputs to the valuation methodology are quoted prices (unadjusted) for identical assets or liabilities in active markets.

[0001144204-16-136902:notes:191]
Level 2 –Inputs to the valuation methodology include quoted prices for similar assets and liabilities in active markets, and inputs that are observable for the asset or liability, either directly or indirectly, for substantially the full term of the financial instrument.

[0001144204-16-136902:notes:192]
Level 3 – Inputs to the valuation methodology are unobservable and significant to the fair value measurement.

[0001144204-16-136902:notes:193]
Financial Assets and Liabilities

[0001144204-16-136902:notes:194]
The Company has estimated the fair value of its financial instruments as of September 30, 2016 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001144204-16-136902:notes:195]
Nonfinancial Assets and Liabilities

[0001144204-16-136902:notes:196]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during 2016.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001144204-16-136902:notes:197]
| 11. | Share-Based Compensation |

[0001144204-16-136902:notes:198]
The Company provides compensation benefits to certain key employees under several share-based plans providing for performance-accelerated restricted share unit (PARS) awards, and to non-employee directors under a non-employee directors compensation plan. The Company has no stock options currently outstanding.

[0001144204-16-136902:notes:199]
Performance-Accelerated Restricted Share Unit Awards

[0001144204-16-136902:notes:200]
A PARS award represents the right to receive a specified number of shares of Company common stock if and when the award vests. A PARS award is not stock and does not give the recipient any rights as a shareholder until it vests and is paid out in shares of stock. PARS awards currently outstanding have a  five-year vesting period, with accelerated vesting if certain targets based on market conditions are achieved. In these cases, if it is probable that the performance condition will be met, the Company recognizes compensation cost on a straight-line basis over the shorter performance period; otherwise, it will recognize compensation cost over the longer service period. Compensation cost for the majority of the outstanding PARS awards is being recognized over the shorter performance period as it is probable the performance condition will be met. The PARS award grants were valued at the stock price on the date of grant. Pretax compensation expense related to the PARS awards for continuing operations was $3.9 million, $4.0 million and $4.1 million for 2016, 2015 and 2014, respectively.

[0001144204-16-136902:notes:201]
Non-Employee Directors Plan

[0001144204-16-136902:notes:202]
The non-employee directors compensation plan provides to each non-employee director a retainer of  900 common shares per quarter. Compensation expense related to the non-employee director grants was $0.8 million, $0.8 million and $0.7 million for 2016, 2015 and 2014, respectively.

[0001144204-16-136902:notes:203]
Total Share-Based Compensation

[0001144204-16-136902:notes:204]
The total share-based compensation cost that has been recognized in results of operations and included within SG&A from continuing operations was $4.7 million, $4.8 million and $4.8 million for 2016, 2015 and 2014, respectively. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $1.3 million, $1.6 million and $1.3 million for 2016, 2015 and 2014, respectively. The Company has elected to use tax law ordering rules when calculating the income tax benefit associated with its share-based payment arrangements. In addition, the Company elected to use the simplified method of calculating the pool of excess tax benefits available to absorb tax deficiencies recognized. As of September 30, 2016, there was $5.1 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a weighted-average period of  1.2 years.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001144204-16-136902:notes:205]
14.       Other Financial Data
