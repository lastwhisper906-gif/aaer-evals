# ESE MD&A — 0001410578-24-000030


## mdna

[0001410578-24-000030:mdna:1]
[same as prior period, unchanged from 0001410578-23-001616:mdna:1]

[0001410578-24-000030:mdna:2]
[same as prior period, unchanged from 0001410578-23-001616:mdna:2]

[0001410578-24-000030:mdna:3]
References to the first quarters of 2024 and 2023 represent the three-month periods ended December 31, 2023 and 2022, respectively.

[0001410578-24-000030:mdna:4]
[same as prior period, unchanged from 0001410578-23-001616:mdna:4]

[0001410578-24-000030:mdna:5]
Sales, net earnings and diluted earnings per share were $218.3 million, $15.2 million and $0.59 per share, respectively, in the first quarter of 2024 compared to $205.5 million, $14.7 million and $0.57 per share, respectively, in the first quarter of 2023.

[0001410578-24-000030:mdna:6]
[same as prior period, unchanged from 0001410578-23-001616:mdna:6]

[0001410578-24-000030:mdna:7]
Net sales increased $12.8 million, or 6.2%, to $218.3 million in the first quarter of 2024 from $205.5 million in the first quarter of 2023. The increase in net sales in the first quarter of 2024 as compared to the first quarter of 2023 was due to a $12.0 million increase in the USG segment, and an $11.7 million increase in the Aerospace & Defense segment, partially offset by a $10.9 million decrease in the Test segment.

[0001410578-24-000030:mdna:8]
[same as prior period, unchanged from 0001410578-23-001616:mdna:8]

[0001410578-24-000030:mdna:9]
Net sales of $94.7 million in the first quarter of 2024 were $11.7 million, or 14.1%, higher than the $83.0 million in the first quarter of 2023. The sales increase in the first quarter of 2024 compared to the first quarter of 2023 was primarily due to an approximately $7.0 million increase in aerospace shipments at Mayday, Crissair and PTI, and a $4.7 million increase in net sales at Globe driven mainly by the CMT acquisition.

[0001410578-24-000030:mdna:10]
[same as prior period, unchanged from 0001410578-23-001616:mdna:10]

[0001410578-24-000030:mdna:11]
Net sales of $83.0 million in the first quarter of 2024 were $12.0 million, or 16.9% higher than the $71.0 million in the first quarter of 2023. The increase in the first quarter of 2024 compared to the first quarter of 2023 was mainly due to a $7.6 million increase in net sales at Doble driven by higher sales of offline testing products and services and a $4.4 million increase in net sales at NRG driven by continued strength in the renewables end-market.

[0001410578-24-000030:mdna:12]
[same as prior period, unchanged from 0001410578-23-001616:mdna:12]

[0001410578-24-000030:mdna:13]
Net sales of $40.6 million in the first quarter of 2024 were $10.9 million, or 21.2%, lower than the $51.5 million in the first quarter of 2023. The decrease in the first quarter of 2024 compared to the first quarter of 2023 was primarily due to $7.5 million of lower sales from the segment’s U.S operations and $3.4 million of lower sales from the segment’s Asian and European operations, all due to the timing of test and measurement chamber projects.

[0001410578-24-000030:mdna:14]
[same as prior period, unchanged from 0001410578-23-001616:mdna:14]

[0001410578-24-000030:mdna:15]
Backlog was $847.8 million at December 31, 2023 compared with $772.4 million at September 30, 2023. The Company received new orders totaling $293.7 million in the first quarter of 2024 compared to $228.9 million in the first quarter of 2023. Of the new orders received in the first quarter of 2024, $171.5 million related to Aerospace & Defense products, $77.0 million related to USG products, and $45.2 million related to Test products. Of the new orders received in the first quarter of 2023, $97.3 million related to Aerospace & Defense products, $80.2 million related to USG products, and $51.4 million related to Test products.

[0001410578-24-000030:mdna:16]
[same as prior period, unchanged from 0001410578-23-001616:mdna:17]

[0001410578-24-000030:mdna:17]
Selling, general and administrative (SG&A) expenses were $54.0 million (24.7% of net sales) for the first quarter of 2024, compared with $51.3 million (25.0% of net sales) for the first quarter of 2023. The increase in SG&A in the first quarter of 2024 compared to the first quarter of 2023 was mainly due to an increase within the USG and A&D segments due to higher sales, inflationary impacts and acquisition impacts.

[0001410578-24-000030:mdna:18]
[same as prior period, unchanged from 0001410578-23-001616:mdna:19]

[0001410578-24-000030:mdna:19]
Amortization of intangible assets was $7.9 million and $6.9 million for the first quarter of 2024 and 2023, respectively. Amortization expenses consist of amortization of acquired intangible assets from acquisitions and other identifiable intangible assets (primarily

[0001410578-24-000030:mdna:20]
software). The increase in amortization expense in the first quarter of 2024 compared to the first quarter of 2023 was mainly due to an increase in amortization of capitalized software and amortization of intangible assets related to the MPE and CMT acquisitions.

[0001410578-24-000030:mdna:21]
OTHER EXPENSES, NET

[0001410578-24-000030:mdna:22]
Other expenses, net, were $0.2 million in the first quarter of 2024 compared to $0.4 million in the first quarter of 2023. There were no individually significant items in other expenses, net, in the first quarter of 2024. The principal component of other expenses, net, in the first quarter of 2023 included approximately $0.2 million of restructuring charges within the A&D segment.

[0001410578-24-000030:mdna:23]
[same as prior period, unchanged from 0001410578-23-001616:mdna:23]

[0001410578-24-000030:mdna:24]
The Company evaluates the performance of its operating segments based on EBIT, and provides EBIT on a consolidated basis, which is a non-GAAP financial measure. Please refer to the discussion of non-GAAP financial measures in Note 7 to the Consolidated Financial Statements, above. EBIT was $22.1 million (10.1% of net sales) for the first quarter of 2024 compared to $20.6 million (10.0% of net sales) for the first quarter of 2023.

[0001410578-24-000030:mdna:25]
The following table presents a reconciliation of EBIT to a GAAP financial measure:

[0001410578-24-000030:mdna:26]
| ​ | ​ | Three Months Ended |
| ​ | ​ | December 31, |
| (In thousands) |  | 2023 |  | 2022 |
| Net earnings | ​ | $ | 15,169 | ​ | ​ | 14,727 |
| Plus: Interest expense, net | ​ |  | 2,667 | ​ | ​ | 1,658 |
| Plus: Income tax expense | ​ |  | 4,285 | ​ | ​ | 4,172 |
| Consolidated EBIT | ​ | $ | 22,121 | ​ | ​ | 20,557 |

[0001410578-24-000030:mdna:27]
–Aerospace & Defense

[0001410578-24-000030:mdna:28]
EBIT was $16.7 million (17.6% of net sales) in the first quarter of 2024 compared to $12.5 million (15.1% of net sales) in the first quarter of 2023. The increase in EBIT in the first quarter of 2024 compared to the first quarter of 2023 was mainly due to higher sales volumes at Mayday, Crissair & Globe mentioned above.

[0001410578-24-000030:mdna:29]
[same as prior period, unchanged from 0001410578-23-001616:mdna:29]

[0001410578-24-000030:mdna:30]
EBIT was $17.6 million (21.2% of net sales) in the first quarter of 2024 compared to $16.1 million (22.7% of net sales) in the first quarter of 2023. The increase in EBIT in the first quarter of 2024 compared to the first quarter of 2023 was mainly due to the higher sales volumes at both Doble and NRG in the first quarter of 2024.

[0001410578-24-000030:mdna:31]
[same as prior period, unchanged from 0001410578-23-001616:mdna:31]

[0001410578-24-000030:mdna:32]
EBIT was $1.8 million (4.4% of net sales) in the first quarter of 2024 compared to $5.4 million (10.5% of net sales) in the first quarter of 2023. The decrease in EBIT in the first quarter of 2024 compared to the first quarter of 2023 was primarily driven by the lower sales volumes from the segment’s U.S. and Asian operations. In addition, EBIT in the first quarter of 2024 was negatively impacted by $0.3 million of inventory step-up charges related to the MPE acquisition.

[0001410578-24-000030:mdna:33]
–Corporate

[0001410578-24-000030:mdna:34]
Corporate costs included in EBIT were $13.9 million and $13.5 million in the first quarter of 2024 and 2023, respectively. The increase in Corporate costs in the first quarter of 2024 compared to the first quarter of 2023 was mainly due to an increase in share based compensation costs and costs related to the MPE acquisition.

[0001410578-24-000030:mdna:35]
[same as prior period, unchanged from 0001410578-23-001616:mdna:35]

[0001410578-24-000030:mdna:36]
Interest expense was $2.7 million and $1.7 million in the first quarter of 2024 and 2023, respectively. The increase in interest expense in the first quarter of 2024 as compared to the first quarter of 2023 was mainly due to higher average interest rates (6.8% in the first quarter of 2024 compared to 4.6% in the first quarter of 2023) and higher average outstanding borrowings.

[0001410578-24-000030:mdna:37]
[same as prior period, unchanged from 0001410578-23-001616:mdna:37]

[0001410578-24-000030:mdna:38]
The effective income tax rate was 22.0% in the first quarter of 2024 compared to 22.1% in the first quarter of 2023. There were no significant changes in the effective income tax rate between the periods.

[0001410578-24-000030:mdna:39]
[same as prior period, unchanged from 0001410578-23-001616:mdna:40]

[0001410578-24-000030:mdna:40]
The Company’s overall financial position and liquidity remain strong. Working capital (current assets less current liabilities) increased to $298.5 million at December 31, 2023 from $266.4 million at September 30, 2023. Inventories increased $18.5 million during this period mainly due to a $9.1 million increase within the Aerospace & Defense segment, a $7.5 million increase within the USG segment and a $1.9 million increase within the Test segment primarily from an increase in work in process inventories due to timing of manufacturing existing orders. Accrued salaries decreased by $9.9 million during this period due to timing of salaries and bonus payments.

[0001410578-24-000030:mdna:41]
Net cash provided by operating activities was $8.7 million and net cash used by operating activities was $(9.0) million in the first quarters of 2024 and 2023, respectively. The increase in net cash provided by operating activities in the first quarter of 2024 as compared to the first quarter of 2023 was mainly driven by an increase in contract liabilities and lower accounts receivable balances due to timing of collections.

[0001410578-24-000030:mdna:42]
Capital expenditures were $7.8 million and $4.8 million in the first quarters of 2024 and 2023, respectively. The increase in the first quarter of 2024 was mainly due to an increase in building improvements and machinery & equipment within the A&D segment. In addition, the Company incurred expenditures for capitalized software of approximately $2.9 million and $2.8 million in the first quarters of 2024 and 2023, respectively.

[0001410578-24-000030:mdna:43]
[same as prior period, unchanged from 0001410578-23-001616:mdna:44]

[0001410578-24-000030:mdna:44]
On November 9, 2023, the Company acquired MPE Limited (MPE), based in the United Kingdom, for a purchase price of approximately $56.2 million, net of cash acquired. MPE is a leading global manufacturer of high-performance EMC/EMP filters and capacitor products for military, utility, telecommunication, and other critical infrastructure applications. Since the date of acquisition, the operating results for the MPE business have been included as part of ETS-Lindgren in the Test segment.

[0001410578-24-000030:mdna:45]
Credit Facility

[0001410578-24-000030:mdna:46]
At December 31, 2023, the Company had approximately $322 million available to borrow under its bank credit facility, a $250 million increase option, and $51.4 million cash on hand. At December 31, 2023, the Company had $172 million of outstanding borrowings under the credit facility in addition to outstanding letters of credit of $5.8 million. Cash flow from operations and borrowings under the Company’s credit facility are expected to meet the Company’s capital requirements and operational needs for the foreseeable future. The Company’s ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.

[0001410578-24-000030:mdna:47]
[same as prior period, unchanged from 0001410578-23-001616:mdna:50]

[0001410578-24-000030:mdna:48]
A dividend of $0.08 per share, totaling $2.1 million, was paid on October 17, 2023 to stockholders of record as of October 3, 2023. Subsequent to December 31, 2023, a quarterly dividend of $0.08 per share, totaling $2.1 million, was paid on January 19, 2024 to stockholders of record as of January 4, 2024.

[0001410578-24-000030:mdna:49]
CRITICAL ACCOUNTING POLICIES

[0001410578-24-000030:mdna:50]
Management has evaluated the accounting policies used in the preparation of the Company’s financial statements and related notes and believes those policies to be reasonable and appropriate. Certain of these accounting policies require the application of significant judgment by Management in selecting appropriate assumptions for calculating financial estimates. By their nature, these judgments are subject to an inherent degree of uncertainty. These judgments are based on historical experience, trends in the industry, information provided by customers and information available from other outside sources, as appropriate. The most significant areas involving Management judgments and estimates may be found in the Critical Accounting Policies section of Management’s Discussion and Analysis and in Note 1 to the Consolidated Financial Statements contained in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2023.

[0001410578-24-000030:mdna:51]
[same as prior period, unchanged from 0001410578-23-001616:mdna:54]

[0001410578-24-000030:mdna:52]
Contingencies

[0001410578-24-000030:mdna:53]
As a normal incident of the business in which the Company is engaged, various claims, charges and litigation are asserted or commenced against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. In the opinion of Management, the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company, are adequately reserved, are covered by insurance, or would not have a material adverse effect on the Company’s results from operations, capital expenditures, or competitive position.

[0001410578-24-000030:mdna:54]
[same as prior period, unchanged from 0001410578-23-001616:mdna:57]

[0001410578-24-000030:mdna:55]
Investors are cautioned that such statements are only predictions and speak only as of the date of this Form 10-Q, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment, including but not limited to those described in Item 1A, “Risk Factors,” of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2023, and the following: the impacts of climate change and related regulation of greenhouse gases; the impacts of labor disputes, civil disorder, wars, elections, political changes, tariffs and trade disputes, terrorist activities, cyberattacks or natural disasters on the Company’s operations and those of the Company’s customers and suppliers; disruptions in manufacturing or delivery arrangements due to shortages or unavailability of materials or components; or supply chain disruptions; inability to access work sites; the timing and content of future contract awards or customer orders; the timely appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer contracts or orders; weakening of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties or data breaches; the availability of selected acquisitions; delivery delays or defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability of certain raw materials; material changes in the cost of credit; changes in laws and regulations including but not limited to changes in accounting standards and taxation; changes in interest rates; costs relating to environmental matters arising from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the integration and performance of recently acquired businesses.

[0001410578-24-000030:mdna:56]
18
