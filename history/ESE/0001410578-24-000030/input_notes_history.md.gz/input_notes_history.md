# ESE note change history — 0001410578-23-001616 → 0001410578-24-000030


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-02-09):
[0001410578-24-000030:note_history:1]
The Company’s results for the three-month period ended December 31, 2023 are not necessarily indicative of the results for the entire 2024 fiscal year. References to the first quarters of 2024 and 2023 represent the fiscal quarters ended December 31, 2023 and 2022, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.
  (was, 2023-08-09, similarity 0.9646):
[0001410578-23-001616:note_history:1]
The Company’s results for the three-month period ended June 30, 2023 are not necessarily indicative of the results for the entire 2023 fiscal year. References to the third quarters of 2023 and 2022 represent the fiscal quarters ended June 30, 2023 and 2022, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-02-09):
[0001410578-24-000030:note_history:2]
| ​ |  | December 31, | ​ | September 30, |
| (In thousands) |  | 2023 |  | 2023 |
| Total borrowings | ​ | $ | 172,000 | ​ | 102,000 |
| Current portion of long-term debt | ​ | ​ | (20,000) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 152,000 | ​ | 82,000 |
  (was, 2023-08-09, similarity 0.6867):
[0001410578-23-001616:note_history:2]
| ​ |  | June 30, | ​ | September 30, |
| (In thousands) |  | 2023 |  | 2022 |
| Total borrowings | ​ | $ | 148,000 |  | 153,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 128,000 |  | 133,000 |

- changed (2024-02-09):
[0001410578-24-000030:note_history:3]
The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of seven banks led by JP Morgan Chase Bank, N.A., as administrative agent, Bank of America, N.A., as syndication agent, and Commerce Bank and TD Bank, N.A. as co-documentation agents. The Credit Facility matures August 30, 2028, with balance due by this date.
  (was, 2023-08-09, similarity 0.7446):
[0001410578-23-001616:note_history:3]
The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024, with balance due by this date.

- added (2024-02-09):
[0001410578-24-000030:note_history:4]
At December 31, 2023, the Company had approximately $322 million available to borrow under the Credit Facility, plus the $250 million increase option subject to the lenders’ consent, in addition to $51.4 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of December 31, 2023, as the Company intends to repay this amount within the next twelve months; however, the Company no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $5.8 million at December 31, 2023.

- added (2024-02-09):
[0001410578-24-000030:note_history:5]
Interest on borrowings under the Credit Facility is calculated at a spread over either an Adjusted Term SOFR Rate, Adjusted EURIBOR Rate, Adjusted CDOR Rate, Alternate Base Rate or Daily Simple RFR, at the Company’s election. The Credit Facility also requires a facility fee ranging from 12.5 to 25 basis points per annum on the unused portion. The interest rate spreads and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio. The weighted average interest rates were 6.8% and 4.6% for the three-month periods ending December 31, 2023 and 2022, respectively. As of December 31, 2023, the Company was in compliance with all covenants.

- removed (2024-02-09):
[0001410578-23-001616:note_history:6]
At June 30, 2023, the Company had approximately $345 million available to borrow under the Credit Facility, plus the $250 million increase option, subject to lenders’ consent, in addition to $56.1 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of June 30, 2023, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $7.4 million at June 30, 2023.

- removed (2024-02-09):
[0001410578-23-001616:note_history:7]
Interest on borrowings under the Credit Facility is calculated at a spread over either the Standard Overnight Financing Rate (SOFR) or the prime rate depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The interest rate spreads on the facility and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio.  The weighted average interest rates were 6.05% and 5.57% for the three and nine-month periods ending June 30, 2023, respectively, and 2.20% and 1.57% for the three and nine-month periods ending June 30, 2022. As of June 30, 2023, the Company was in compliance with all covenants.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-02-09):
[0001410578-24-000030:note_history:8]
| ​ |  | December 31, | ​ | September 30, |
| (In thousands) |  | 2023 |  | 2023 |
| Total borrowings | ​ | $ | 172,000 | ​ | 102,000 |
| Current portion of long-term debt | ​ | ​ | (20,000) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 152,000 | ​ | 82,000 |
  (was, 2023-08-09, similarity 0.6867):
[0001410578-23-001616:note_history:8]
| ​ |  | June 30, | ​ | September 30, |
| (In thousands) |  | 2023 |  | 2022 |
| Total borrowings | ​ | $ | 148,000 |  | 153,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 128,000 |  | 133,000 |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-02-09):
[0001410578-24-000030:note_history:9]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2023 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within each reportable segment.
  (was, 2023-08-09, similarity 0.953):
[0001410578-23-001616:note_history:9]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2023 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue within each reportable segment.

- changed (2024-02-09):
[0001410578-24-000030:note_history:10]
| ​ | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 37,209 | ​ | $ | 81,469 | ​ | $ | 35,087 | ​ | $ | 153,765 |
| Government | ​ | ​ | 57,524 | ​ | ​ | 1,515 | ​ | ​ | 5,510 | ​ | ​ | 64,549 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 79,901 | ​ | $ | 55,961 | ​ | $ | 22,252 | ​ | $ | 158,114 |
| International | ​ | ​ | 14,832 | ​ | ​ | 27,023 | ​ | ​ | 18,345 | ​ | ​ | 60,200 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 39,465 | ​ | $ | 66,703 | ​ | $ | 7,980 | ​ | $ | 114,148 |
| Over time | ​ | ​ | 55,268 | ​ | ​ | 16,281 | ​ | ​ | 32,617 | ​ | ​ | 104,166 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |
  (was, 2023-08-09, similarity 0.8013):
[0001410578-23-001616:note_history:10]
| Three months ended June 30, 2023 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 51,303 | ​ | $ | 88,442 | ​ | $ | 48,407 | ​ | $ | 188,152 |
| Government | ​ |  | 52,166 | ​ |  | 1,524 | ​ |  | 6,907 | ​ |  | 60,597 |
| Total revenues | ​ | $ | 103,469 | ​ | $ | 89,966 | ​ | $ | 55,314 | ​ | $ | 248,749 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 86,031 | ​ | $ | 55,011 | ​ | $ | 32,246 | ​ | $ | 173,288 |
| International | ​ |  | 17,438 | ​ |  | 34,955 | ​ |  | 23,068 | ​ |  | 75,461 |
| Total revenues | ​ | $ | 103,469 | ​ | $ | 89,966 | ​ | $ | 55,314 | ​ | $ | 248,749 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 48,496 | ​ | $ | 74,128 | ​ | $ | 11,496 | ​ | $ | 134,120 |
| Over time | ​ |  | 54,973 | ​ |  | 15,838 | ​ |  | 43,818 | ​ |  | 114,629 |
| Total revenues | ​ | $ | 103,469 | ​ | $ | 89,966 | ​ | $ | 55,314 | ​ | $ | 248,749 |

- changed (2024-02-09):
[0001410578-24-000030:note_history:11]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2022 are presented in the table below:
  (was, 2023-08-09, similarity 0.9288):
[0001410578-23-001616:note_history:11]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2022 are presented in the tables below.

- changed (2024-02-09):
[0001410578-24-000030:note_history:12]
| ​ | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 36,740 | ​ | $ | 70,162 | ​ | $ | 45,992 | ​ | $ | 152,894 |
| Government | ​ | ​ | 46,243 | ​ | ​ | 883 | ​ | ​ | 5,481 | ​ | ​ | 52,607 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 68,934 | ​ | $ | 46,379 | ​ | $ | 27,503 | ​ | $ | 142,816 |
| International | ​ | ​ | 14,049 | ​ | ​ | 24,666 | ​ | ​ | 23,970 | ​ | ​ | 62,685 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 33,604 | ​ | $ | 56,031 | ​ | $ | 9,101 | ​ | $ | 98,736 |
| Over time | ​ | ​ | 49,379 | ​ | ​ | 15,014 | ​ | ​ | 42,372 | ​ | ​ | 106,765 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |
  (was, 2023-08-09, similarity 0.8409):
[0001410578-23-001616:note_history:12]
| Nine months ended June 30, 2022 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 100,407 | ​ | $ | 191,832 | ​ | $ | 147,390 | ​ | $ | 439,629 |
| Government | ​ |  | 147,264 | ​ |  | 3,045 | ​ |  | 11,066 | ​ |  | 161,375 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 212,849 | ​ | $ | 122,021 | ​ | $ | 88,708 | ​ | $ | 423,578 |
| International | ​ |  | 34,822 | ​ |  | 72,856 | ​ |  | 69,748 | ​ |  | 177,426 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 99,464 | ​ | $ | 155,693 | ​ | $ | 43,488 | ​ | $ | 298,645 |
| Over time | ​ |  | 148,207 | ​ |  | 39,184 | ​ |  | 114,968 | ​ |  | 302,359 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |

- removed (2024-02-09):
[0001410578-23-001616:note_history:13]
| Nine months ended June 30, 2023 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial |  | $ | 136,271 | ​ | $ | 236,715 | ​ | $ | 137,587 | ​ | $ | 510,573 |
| Government | ​ | ​ | 149,163 | ​ |  | 3,457 | ​ |  | 20,193 | ​ |  | 172,813 |
| Total revenues |  | $ | 285,434 | ​ | $ | 240,172 | ​ | $ | 157,780 | ​ | $ | 683,386 |
| Geographic location: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States |  | $ | 237,481 | ​ | $ | 154,410 | ​ | $ | 87,253 | ​ | $ | 479,144 |
| International | ​ | ​ | 47,953 | ​ |  | 85,762 | ​ |  | 70,527 | ​ |  | 204,242 |
| Total revenues |  | $ | 285,434 | ​ | $ | 240,172 | ​ | $ | 157,780 | ​ | $ | 683,386 |
| Revenue recognition method: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time |  | $ | 129,355 | ​ | $ | 194,240 | ​ | $ | 32,565 | ​ | $ | 356,160 |
| Over time | ​ | ​ | 156,079 | ​ |  | 45,932 | ​ |  | 125,215 | ​ |  | 327,226 |
| Total revenues |  | $ | 285,434 | ​ | $ | 240,172 | ​ | $ | 157,780 | ​ | $ | 683,386 |

- removed (2024-02-09):
[0001410578-23-001616:note_history:14]
| Three months ended June 30, 2022 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 38,918 | ​ | $ | 65,610 | ​ | $ | 54,449 | ​ | $ | 158,977 |
| Government | ​ |  | 53,688 | ​ |  | 1,591 | ​ |  | 4,810 | ​ |  | 60,089 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 79,536 | ​ | $ | 41,822 | ​ | $ | 34,662 | ​ | $ | 156,020 |
| International | ​ |  | 13,070 | ​ |  | 25,379 | ​ |  | 24,597 | ​ |  | 63,046 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 35,238 | ​ | $ | 53,656 | ​ | $ | 15,827 | ​ | $ | 104,721 |
| Over time | ​ |  | 57,368 | ​ |  | 13,545 | ​ |  | 43,432 | ​ |  | 114,345 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-02-09):
[0001410578-24-000030:note_history:15]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2023 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within each reportable segment.
  (was, 2023-08-09, similarity 0.953):
[0001410578-23-001616:note_history:15]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2023 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue within each reportable segment.

- changed (2024-02-09):
[0001410578-24-000030:note_history:16]
| ​ | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 37,209 | ​ | $ | 81,469 | ​ | $ | 35,087 | ​ | $ | 153,765 |
| Government | ​ | ​ | 57,524 | ​ | ​ | 1,515 | ​ | ​ | 5,510 | ​ | ​ | 64,549 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 79,901 | ​ | $ | 55,961 | ​ | $ | 22,252 | ​ | $ | 158,114 |
| International | ​ | ​ | 14,832 | ​ | ​ | 27,023 | ​ | ​ | 18,345 | ​ | ​ | 60,200 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 39,465 | ​ | $ | 66,703 | ​ | $ | 7,980 | ​ | $ | 114,148 |
| Over time | ​ | ​ | 55,268 | ​ | ​ | 16,281 | ​ | ​ | 32,617 | ​ | ​ | 104,166 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |
  (was, 2023-08-09, similarity 0.8013):
[0001410578-23-001616:note_history:16]
| Three months ended June 30, 2023 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 51,303 | ​ | $ | 88,442 | ​ | $ | 48,407 | ​ | $ | 188,152 |
| Government | ​ |  | 52,166 | ​ |  | 1,524 | ​ |  | 6,907 | ​ |  | 60,597 |
| Total revenues | ​ | $ | 103,469 | ​ | $ | 89,966 | ​ | $ | 55,314 | ​ | $ | 248,749 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 86,031 | ​ | $ | 55,011 | ​ | $ | 32,246 | ​ | $ | 173,288 |
| International | ​ |  | 17,438 | ​ |  | 34,955 | ​ |  | 23,068 | ​ |  | 75,461 |
| Total revenues | ​ | $ | 103,469 | ​ | $ | 89,966 | ​ | $ | 55,314 | ​ | $ | 248,749 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 48,496 | ​ | $ | 74,128 | ​ | $ | 11,496 | ​ | $ | 134,120 |
| Over time | ​ |  | 54,973 | ​ |  | 15,838 | ​ |  | 43,818 | ​ |  | 114,629 |
| Total revenues | ​ | $ | 103,469 | ​ | $ | 89,966 | ​ | $ | 55,314 | ​ | $ | 248,749 |

- changed (2024-02-09):
[0001410578-24-000030:note_history:17]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2022 are presented in the table below:
  (was, 2023-08-09, similarity 0.9288):
[0001410578-23-001616:note_history:17]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2022 are presented in the tables below.

- changed (2024-02-09):
[0001410578-24-000030:note_history:18]
| ​ | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 36,740 | ​ | $ | 70,162 | ​ | $ | 45,992 | ​ | $ | 152,894 |
| Government | ​ | ​ | 46,243 | ​ | ​ | 883 | ​ | ​ | 5,481 | ​ | ​ | 52,607 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 68,934 | ​ | $ | 46,379 | ​ | $ | 27,503 | ​ | $ | 142,816 |
| International | ​ | ​ | 14,049 | ​ | ​ | 24,666 | ​ | ​ | 23,970 | ​ | ​ | 62,685 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 33,604 | ​ | $ | 56,031 | ​ | $ | 9,101 | ​ | $ | 98,736 |
| Over time | ​ | ​ | 49,379 | ​ | ​ | 15,014 | ​ | ​ | 42,372 | ​ | ​ | 106,765 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |
  (was, 2023-08-09, similarity 0.8409):
[0001410578-23-001616:note_history:18]
| Nine months ended June 30, 2022 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 100,407 | ​ | $ | 191,832 | ​ | $ | 147,390 | ​ | $ | 439,629 |
| Government | ​ |  | 147,264 | ​ |  | 3,045 | ​ |  | 11,066 | ​ |  | 161,375 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 212,849 | ​ | $ | 122,021 | ​ | $ | 88,708 | ​ | $ | 423,578 |
| International | ​ |  | 34,822 | ​ |  | 72,856 | ​ |  | 69,748 | ​ |  | 177,426 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 99,464 | ​ | $ | 155,693 | ​ | $ | 43,488 | ​ | $ | 298,645 |
| Over time | ​ |  | 148,207 | ​ |  | 39,184 | ​ |  | 114,968 | ​ |  | 302,359 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |

- changed (2024-02-09):
[0001410578-24-000030:note_history:19]
For our overtime revenue recognized using the output method of costs incurred, contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to one or more years, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change. In addition, in the USG segment, we recognize revenue as a series of distinct services based on each day of providing services (straight-line over the contract term) for certain of our USG segment contracts. Under the typical payment terms of our service contracts, the customer pays us in advance of when services are performed. In addition, in the Test segment, we use milestones to measure progress for our Test segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts.
  (was, 2023-08-09, similarity 0.7045):
[0001410578-23-001616:note_history:19]
For our overtime revenue recognized using the output method of costs incurred, contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to one or more years, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change. In addition, in the USG

- changed (2024-02-09):
[0001410578-24-000030:note_history:20]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At December 31, 2023, the Company had $847.8 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 66% in the next twelve months.
  (was, 2023-08-09, similarity 0.9914):
[0001410578-23-001616:note_history:20]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At June 30, 2023, the Company had $705.4 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 79% in the next twelve months.

- changed (2024-02-09):
[0001410578-24-000030:note_history:21]
Contract assets, contract liabilities and accounts receivable
  (was, 2023-08-09, similarity 0.6304):
[0001410578-23-001616:note_history:21]
Contract assets and liabilities

- changed (2024-02-09):
[0001410578-24-000030:note_history:22]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At December 31, 2023, contract assets, contract liabilities and accounts receivable totaled $138.4 million, $131.9 million and $194.4 million, respectively. During the first quarter of 2024, the Company recognized approximately $24.4 million in revenues that were included in the contract liabilities balance at September 30, 2023. At September 30, 2023, contract assets, contract liabilities and accounts receivable totaled $138.6 million, $123.1 million and $198.6 million, respectively.
  (was, 2023-08-09, similarity 0.6489):
[0001410578-23-001616:note_history:22]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred. At June 30, 2023, contract assets and liabilities totaled $128.3 million and $133.6 million, respectively. During the first nine months of 2023, the Company recognized approximately $81 million in revenues that were included in the contract liabilities balance at September 30, 2022. At September 30, 2022, contract assets and liabilities totaled $125.2 million and $137.6 million, respectively.

- removed (2024-02-09):
[0001410578-23-001616:note_history:23]
| Nine months ended June 30, 2023 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial |  | $ | 136,271 | ​ | $ | 236,715 | ​ | $ | 137,587 | ​ | $ | 510,573 |
| Government | ​ | ​ | 149,163 | ​ |  | 3,457 | ​ |  | 20,193 | ​ |  | 172,813 |
| Total revenues |  | $ | 285,434 | ​ | $ | 240,172 | ​ | $ | 157,780 | ​ | $ | 683,386 |
| Geographic location: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States |  | $ | 237,481 | ​ | $ | 154,410 | ​ | $ | 87,253 | ​ | $ | 479,144 |
| International | ​ | ​ | 47,953 | ​ |  | 85,762 | ​ |  | 70,527 | ​ |  | 204,242 |
| Total revenues |  | $ | 285,434 | ​ | $ | 240,172 | ​ | $ | 157,780 | ​ | $ | 683,386 |
| Revenue recognition method: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time |  | $ | 129,355 | ​ | $ | 194,240 | ​ | $ | 32,565 | ​ | $ | 356,160 |
| Over time | ​ | ​ | 156,079 | ​ |  | 45,932 | ​ |  | 125,215 | ​ |  | 327,226 |
| Total revenues |  | $ | 285,434 | ​ | $ | 240,172 | ​ | $ | 157,780 | ​ | $ | 683,386 |

- removed (2024-02-09):
[0001410578-23-001616:note_history:24]
| Three months ended June 30, 2022 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 38,918 | ​ | $ | 65,610 | ​ | $ | 54,449 | ​ | $ | 158,977 |
| Government | ​ |  | 53,688 | ​ |  | 1,591 | ​ |  | 4,810 | ​ |  | 60,089 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 79,536 | ​ | $ | 41,822 | ​ | $ | 34,662 | ​ | $ | 156,020 |
| International | ​ |  | 13,070 | ​ |  | 25,379 | ​ |  | 24,597 | ​ |  | 63,046 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 35,238 | ​ | $ | 53,656 | ​ | $ | 15,827 | ​ | $ | 104,721 |
| Over time | ​ |  | 57,368 | ​ |  | 13,545 | ​ |  | 43,432 | ​ |  | 114,345 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |

- removed (2024-02-09):
[0001410578-23-001616:note_history:25]
segment, we recognize revenue as a series of distinct services based on each day of providing services (straight-line over the contract term) for certain of our USG segment contracts. Under the typical payment terms of our service contracts, the customer pays us in advance of when services are performed. In addition, in the Test segment, we use milestones to measure progress for our Test segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts.
