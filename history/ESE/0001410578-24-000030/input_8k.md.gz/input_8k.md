# ESE 8-K — 0001104659-24-012294 filed 2024-02-08

## item codes, every 8-K on or before 2024-02-09

- 2024-02-08 0001104659-24-012294 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2023-11-20 0001104659-23-119761 — 5.02, 9.01
- 2023-11-16 0001104659-23-119126 — 2.02, 7.01, 9.01
- 2023-10-03 0001104659-23-106090 — 5.02, 9.01
- 2023-09-06 0001104659-23-098463 — 1.01, 2.03, 9.01
- 2023-08-08 0001104659-23-088847 — 2.02, 7.01, 9.01
- 2023-07-06 0001104659-23-078571 — 5.02, 8.01, 9.01
- 2023-05-09 0001104659-23-057736 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2023-05-05 0001104659-23-056387 — 5.02, 9.01
- 2023-02-08 0001104659-23-014539 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2023-01-06 0001104659-23-001859 — 5.02, 9.01
- 2022-11-22 0001104659-22-121229 — 5.02, 5.03, 8.01, 9.01
- 2022-11-17 0001104659-22-119898 — 2.02, 7.01, 9.01
- 2022-09-12 0001104659-22-099248 — 5.02, 7.01, 9.01
- 2022-08-08 0001104659-22-087247 — 2.02, 5.02, 7.01, 9.01
- 2022-05-09 0001104659-22-057524 — 2.02, 5.02, 7.01, 9.01
- 2022-02-08 0001104659-22-013878 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2021-12-03 0001104659-21-146361 — 4.01, 9.01 — amendment, the index does not say of what
- 2021-11-24 0001104659-21-143568 — 4.01, 9.01
- 2021-11-23 0001104659-21-142871 — 5.02, 8.01
- 2021-11-18 0001104659-21-141206 — 2.02, 7.01, 9.01
- 2021-08-09 0001104659-21-102150 — 2.02, 7.01, 9.01
- 2021-05-04 0001104659-21-060985 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2021-04-05 0001104659-21-046581 — 5.02, 9.01
- 2021-02-08 0001104659-21-013712 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2020-12-09 0001104659-20-133674 — 5.02, 9.01
- 2020-12-07 0001104659-20-132861 — 5.02, 7.01, 9.01
- 2020-11-19 0001104659-20-127352 — 2.02, 5.02, 7.01, 9.01
- 2020-08-10 0001104659-20-092734 — 2.02, 7.01, 9.01
- 2020-05-06 0001104659-20-057442 — 2.02, 7.01, 8.01, 9.01
- 2020-02-04 0001104659-20-010640 — 2.02, 5.07, 7.01, 9.01
- 2020-01-07 0001104659-20-001789 — 2.01, 9.01
- 2019-11-19 0001104659-19-065437 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2019-11-18 0001104659-19-065096 — 1.01, 2.02, 7.01, 9.01
- 2019-09-30 0001144204-19-046523 — 1.01, 1.02, 2.03, 9.01
- 2019-08-08 0001144204-19-038567 — 2.02, 7.01, 9.01
- 2019-05-07 0001144204-19-024241 — 2.02, 5.02, 7.01, 9.01
- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2024-02-09

- none on or before 2024-02-09

## item 2.02 — earnings release, exhibit 99.1

[0001104659-24-012294:8k_2_02:1]
EX-99.1
2
tm245480d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-24-012294:8k_2_02:2]
Exhibit 99.1

[0001104659-24-012294:8k_2_02:3]
| NEWS FROM |  |

[0001104659-24-012294:8k_2_02:4]
For more information contact:

[0001104659-24-012294:8k_2_02:5]
Kate Lowrey - VP of Investor Relations

[0001104659-24-012294:8k_2_02:6]
(314) 213-7277
/ klowrey@escotechnologies.com

[0001104659-24-012294:8k_2_02:7]
ESCO REPORTS FIRST QUARTER FISCAL 2024 RESULTS

[0001104659-24-012294:8k_2_02:8]
- Q1 Sales increase 6% to $218 Million -

[0001104659-24-012294:8k_2_02:9]
- $294 Million in Q1 Orders / Book-to-bill
of 1.35x -

[0001104659-24-012294:8k_2_02:10]
- Q1 GAAP EPS $0.59 / Adjusted EPS $0.62
-

[0001104659-24-012294:8k_2_02:11]
ST. LOUIS, February 8, 2024 – ESCO Technologies
Inc. (NYSE: ESE) (ESCO, or the Company) today reported its operating results for the first quarter ended December 31, 2023 (Q1 2024).

[0001104659-24-012294:8k_2_02:12]
Operating Highlights

[0001104659-24-012294:8k_2_02:13]
|  | · | Q1 2024 Sales increased $12.8 million (6.2 percent) to $218.3 million compared to $205.5 million in Q1 2023. |

[0001104659-24-012294:8k_2_02:14]
|  | · | Q1 2024 Entered Orders increased $64.8 million (28 percent) over the prior year period to $293.7 million (book-to-bill of 1.35x), resulting in record backlog of $848 million. |

[0001104659-24-012294:8k_2_02:15]
|  | · | Q1 2024 GAAP EPS increased 4 percent to $0.59 per share compared to $0.57 per share in Q1 2023. Q1 2024 Adjusted EPS increased 3 percent to $0.62 per share compared to $0.60 per share in Q1 2023. |

[0001104659-24-012294:8k_2_02:16]
|  | · | Net cash provided by operating activities was $9 million in Q1 2024, an increase of $18 million compared to the prior year period, as cash flow was positively impacted by lower working capital requirements. |

[0001104659-24-012294:8k_2_02:17]
|  | · | Net debt (total borrowings less cash on hand) was $121 million, resulting in a 0.82x leverage ratio and $572 million in liquidity at December 31, 2023. |

[0001104659-24-012294:8k_2_02:18]
Bryan Sayler, Chief Executive Officer and President,
commented, “Our fiscal year got off to a great start in many ways, with orders being particularly strong. This was evidenced by
a $65 million order for surface hull tiles for the Virginia Class Submarine program. In addition, it was another solid quarter in aerospace
with strength in both commercial and defense OEM and aftermarket orders. The book-to-bill for the quarter was 1.35x and resulted in record
backlog of almost $850 million.

[0001104659-24-012294:8k_2_02:19]
“Revenue was up 6 percent over the prior year
with double digit growth in A&D and USG, driven by continuing strength across our aerospace, Navy, utility, and renewables end-markets.
Our teams continue working hard to drive growth and deliver solid operating results and their efforts enabled us to deliver solid Q1 EPS
results. Overall, it was good start to the year, giving us added confidence in our ability to deliver our full year revenue and earnings
guidance.”

[0001104659-24-012294:8k_2_02:20]
Segment Performance

[0001104659-24-012294:8k_2_02:21]
Aerospace & Defense (A&D)

[0001104659-24-012294:8k_2_02:22]
|  | · | Sales increased $11.7 million (14 percent) to $94.7 million in Q1 2024 from $83.0 million in Q1 2023. Q1 organic sales increased $8.5 million (10 percent) in the quarter driven by strength across commercial aerospace, defense aerospace, and Navy. In addition, the CMT acquisition contributed $3.2 million (4 percent) of revenue growth in the quarter. |

[0001104659-24-012294:8k_2_02:23]
|  | · | Q1 2024 EBIT increased $4.2 million to $16.7 million from $12.5 million in Q1 2023. Adjusted EBIT increased $4.0 million in Q1 2024 to $16.7 million (17.6 percent margin) from $12.7 million (15.3 percent margin) in Q1 2023. Margin improvement was driven by leverage on revenue growth and price increases, partially offset by inflationary pressures and mix. |

[0001104659-24-012294:8k_2_02:24]
|  | · | Entered Orders increased $74 million (76 percent) to $172 million in Q1 2024 compared to $97 million in Q1 2023. The increase in orders was primarily driven by large Navy orders for Virginia Class Block V surface hull tiles and Block VI long lead material procurement for the Light Weight Wide Aperture Array (LWWAA), along with a strong quarter for commercial and defense aerospace. The orders strength in the quarter resulted in a segment book-to-bill of 1.81x and record ending backlog of $561 million. |

[0001104659-24-012294:8k_2_02:25]
Utility Solutions Group (USG)

[0001104659-24-012294:8k_2_02:26]
|  | · | Sales increased $12.0 million (17 percent) to $83.0 million in Q1 2024 from $71.0 million in Q1 2023. Doble’s sales increased by $7.6 million (13 percent) driven by a strong quarter for offline products and services. NRG sales increased $4.4 million (30 percent) as they reduced backlog related to longer-term orders placed during FY 2023. |

[0001104659-24-012294:8k_2_02:27]
|  | · | EBIT increased $1.5 million in Q1 2024 to $17.6 million from $16.1 million in Q1 2023. Adjusted EBIT increased $1.6 million to $17.7 million (21.4 percent margin) from $16.1 million (22.7 percent margin) in Q1 2023. In the quarter, margin was impacted unfavorably by mix and inflationary pressures, which more than offset leverage on higher revenue and price increases. |

[0001104659-24-012294:8k_2_02:28]
|  | · | Entered Orders decreased $3 million (4 percent) to $77 million in Q1 2024. Orders moderated in the quarter for Doble and NRG after a record year in 2023. The segment book-to-bill was 0.93x in the quarter and resulted in an ending backlog of $127 million. |

[0001104659-24-012294:8k_2_02:29]
RF Test & Measurement (Test)

[0001104659-24-012294:8k_2_02:30]
|  | · | Sales decreased $10.9 million (21 percent) to $40.6 million in Q1 2024 from $51.5 million in Q1 2023. Organic sales decreased $12.0 million primarily related to lower T&M volume in the U.S., Europe and China and lower OTC filter sales in the U.S., partially offset by $1.1 million of revenue growth related to the MPE acquisition completed during the quarter. |

[0001104659-24-012294:8k_2_02:31]
|  | · | EBIT decreased $3.6 million in Q1 2024 to $1.8 million from $5.4 million in Q1 2023. Adjusted EBIT decreased $3.3 million in Q1 2024 to $2.1 million (5.1 percent margin) from $5.4 million (10.5 percent margin) in Q1 2023. In the quarter, margin was impacted by lower volume, partially offset by price increases and cost reduction actions. |

[0001104659-24-012294:8k_2_02:32]
|  | · | Entered Orders decreased $6 million (12 percent) to $45 million in Q1 2024. The decrease was primarily related to delays on a few large projects in EMEA and China and was partially offset by the $5 million impact of MPE orders and backlog. Book-to-bill was 1.11x in the quarter and resulted in ending backlog of $159 million. |

[0001104659-24-012294:8k_2_02:33]
Dividend Payment

[0001104659-24-012294:8k_2_02:34]
The next quarterly cash dividend
of $0.08 per share will be paid on April 16, 2024 to stockholders of record on April 1, 2024.

[0001104659-24-012294:8k_2_02:35]
Business Outlook – 2024

[0001104659-24-012294:8k_2_02:36]
Management’s expectation is for Q2 Adjusted
EPS in the range of $0.85 to $0.90. We are raising the lower end of our full year guidance which we now expect to be in the range of $4.15
to $4.30 (12 to 16 percent growth). This is based on sales in line with our initial guidance range of $1.02 to $1.04 billion (7 to 9 percent
annual growth). Within our revenue guidance we are raising our expected A&D growth to 11 to 13 percent (from 8 to 10 percent) and
lowering our expected Test growth to 1 to 3 percent (from 8 to 10 percent). We do expect the Test business to improve sales and EBIT in
the second half of the year and we are currently implementing a plan to streamline the cost structure of the business, which will further
enhance its margin profile going forward.

[0001104659-24-012294:8k_2_02:37]
Conference Call

[0001104659-24-012294:8k_2_02:38]
The Company will host a conference call today, February 8, at 4:00
p.m. Central Time, to discuss the Company’s Q1 2024 results. A live audio webcast and an accompanying slide presentation will be
available on ESCO’s investor website. For those unable to participate, a webcast replay will be available after the call on ESCO’s
investor website.

[0001104659-24-012294:8k_2_02:39]
Forward-Looking Statements

[0001104659-24-012294:8k_2_02:40]
Investors are cautioned that such statements are
only predictions and speak only as of the date of this release, and the Company undertakes no duty to update them except as may be required
by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the
forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment including
but not limited to those described in Item 1A, “Risk Factors”, of the Company’s Annual Report on Form 10-K for the fiscal
year ended September 30, 2023 and the following: the impacts of climate change and related regulation of greenhouse gases; the impacts
of labor disputes, civil disorder, wars, elections, political changes, tariffs and trade disputes, terrorist activities, cyberattacks
or natural disasters on the Company’s operations and those of the Company’s customers and suppliers; disruptions in manufacturing
or delivery arrangements due to shortages or unavailability of materials or components, or supply chain disruptions; inability to access
work sites; the timing and content of future contract awards or customer orders; the timely appropriation, allocation and availability
of Government funds; the termination for convenience of Government and other customer contracts or orders; weakening of economic conditions
in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies; competition;
intellectual property rights; technical difficulties or data breaches; the availability of selected acquisitions; delivery delays or defaults
by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability of certain
raw materials; material changes in the cost of credit; changes in laws and regulations including but not limited to changes in accounting
standards and taxation; changes in interest rates; costs relating to environmental matters arising from current or former facilities;
uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the integration and performance
of recently acquired businesses.

[0001104659-24-012294:8k_2_02:41]
Non-GAAP Financial Measures

[0001104659-24-012294:8k_2_02:42]
The financial measures EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA,
and Adjusted EPS are presented in this press release. The Company defines “EBIT” as earnings before interest and taxes, “EBITDA”
as earnings before interest, taxes, depreciation and amortization, “Adjusted EBIT” and “Adjusted EBITDA” as excluding
the net impact of the items described in the attached Reconciliation of Non-GAAP Financial Measures, and “Adjusted EPS” as
GAAP earnings per share excluding the net impact of the items described and reconciled in the attached Reconciliation of Non-GAAP Financial
Measures.

[0001104659-24-012294:8k_2_02:43]
EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA, and
Adjusted EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management believes
EBIT, Adjusted EBIT, EBITDA, and Adjusted EBITDA are useful in assessing the operational profitability of the Company’s business
segments because they exclude interest, taxes, depreciation, and amortization, which are generally accounted for across the entire Company
on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company as
well as incentive compensation. The presentation of EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA, and Adjusted EPS provides important
supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures
to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance determined
in accordance with GAAP.

[0001104659-24-012294:8k_2_02:44]
ESCO is a global provider of highly engineered products and solutions
serving diverse end-markets. It manufactures filtration and fluid control products for the aviation, Navy, space, and process markets
worldwide and composite-based products and solutions for Navy, defense, and industrial customers. ESCO is an industry leader in designing
and manufacturing RF test and measurement products and systems; and provides diagnostic instruments, software and services to industrial
power users and the electric utility and renewable energy industries. Headquartered in St. Louis, Missouri, ESCO and its subsidiaries
have offices and manufacturing facilities worldwide. For more information on ESCO and its subsidiaries, visit the Company’s website
at www.escotechnologies.com.

[0001104659-24-012294:8k_2_02:45]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-012294:8k_2_02:46]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-24-012294:8k_2_02:47]
(Dollars in thousands, except per share amounts)

[0001104659-24-012294:8k_2_02:48]
|  |  | Three Months Ended December 31, 2023 |  |  | Three Months Ended December 31, 2022 |  |
| Net Sales |  | $ | 218,314 |  |  |  | 205,501 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 134,151 |  |  |  | 126,383 |  |
| Selling, general and administrative expenses |  |  | 53,968 |  |  |  | 51,302 |  |
| Amortization of intangible assets |  |  | 7,868 |  |  |  | 6,861 |  |
| Interest expense |  |  | 2,667 |  |  |  | 1,658 |  |
| Other expenses (income), net |  |  | 206 |  |  |  | 398 |  |
| Total costs and expenses |  |  | 198,860 |  |  |  | 186,602 |  |
| Earnings before income taxes |  |  | 19,454 |  |  |  | 18,899 |  |
| Income tax expense |  |  | 4,285 |  |  |  | 4,172 |  |
| Net earnings |  | $ | 15,169 |  |  |  | 14,727 |  |
| Earnings Per Share (EPS) |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.59 |  |  |  | 0.57 |  |
| Diluted - As Adjusted Basis |  | $ | 0.62 | (1) |  |  | 0.60 | (2) |
| Diluted average common shares O/S: |  |  | 25,846 |  |  |  | 25,943 |  |

[0001104659-24-012294:8k_2_02:49]
|  | (1) | Q1 2024 Adjusted EPS excludes $0.03 per share of after-tax charges consisting primarily of MPE acquisition inventory step-up and backlog charges and acquisition related costs. |

[0001104659-24-012294:8k_2_02:50]
|  | (2) | Q1 2023 Adjusted EPS excludes $0.03 per share of after-tax charges associated with executive management transition costs at Corporate and restructuring charges within the A&D segment. |

[0001104659-24-012294:8k_2_02:51]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-012294:8k_2_02:52]
Condensed Business Segment Information (Unaudited)

[0001104659-24-012294:8k_2_02:53]
(Dollars in thousands)

[0001104659-24-012294:8k_2_02:54]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | Q1 2024 |  |  | Q1 2023 |  |  | Q1 2024 |  |  | Q1 2023 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 94,733 |  |  |  | 82,983 |  |  |  | 94,733 |  |  |  | 82,983 |  |
| USG |  |  | 82,984 |  |  |  | 71,045 |  |  |  | 82,984 |  |  |  | 71,045 |  |
| Test |  |  | 40,597 |  |  |  | 51,473 |  |  |  | 40,597 |  |  |  | 51,473 |  |
| Totals |  | $ | 218,314 |  |  |  | 205,501 |  |  |  | 218,314 |  |  |  | 205,501 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 16,663 |  |  |  | 12,536 |  |  |  | 16,663 |  |  |  | 12,735 |  |
| USG |  |  | 17,625 |  |  |  | 16,131 |  |  |  | 17,745 |  |  |  | 16,131 |  |
| Test |  |  | 1,779 |  |  |  | 5,411 |  |  |  | 2,052 |  |  |  | 5,411 |  |
| Corporate |  |  | (13,946 | ) |  |  | (13,521 | ) |  |  | (13,295 | ) |  |  | (12,728 | ) |
| Consolidated EBIT |  |  | 22,121 |  |  |  | 20,557 |  |  |  | 23,165 |  |  |  | 21,549 |  |
| Less: Interest expense |  |  | (2,667 | ) |  |  | (1,658 | ) |  |  | (2,667 | ) |  |  | (1,658 | ) |
| Less: Income tax expense |  |  | (4,285 | ) |  |  | (4,172 | ) |  |  | (4,525 | ) |  |  | (4,400 | ) |
| Net earnings |  | $ | 15,169 |  |  |  | 14,727 |  |  |  | 15,973 |  |  |  | 15,491 |  |

[0001104659-24-012294:8k_2_02:55]
Note 1: Adjusted net earnings of $16.0 million in Q1 2024 exclude $0.8
million (or $0.03 per share) of after-tax charges consisting primarily of MPE acquisition inventory step-up and backlog charges and acquisition
related costs.

[0001104659-24-012294:8k_2_02:56]
Note 2: Adjusted net earnings of $15.5 million in Q1 2023 exclude $0.8
million (or $0.03 per share) of after-tax charges associated with executive management transition costs at Corporate and restructuring
charges within the A&D segment.

[0001104659-24-012294:8k_2_02:57]
| EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |  | Q1 2024 |  |  | Q1 2023 |  |
|  |  | Q1 2024 |  |  | Q1 2023 |  |  | As Adjusted |  |  | As Adjusted |  |
| Consolidated EBITDA |  | $ | 35,573 |  |  |  | 32,924 |  |  |  | 36,408 |  |  |  | 33,916 |  |
| Less: Depr & Amort |  |  | (13,452 | ) |  |  | (12,367 | ) |  |  | (13,243 | ) |  |  | (12,367 | ) |
| Consolidated EBIT |  |  | 22,121 |  |  |  | 20,557 |  |  |  | 23,165 |  |  |  | 21,549 |  |
| Less: Interest expense |  |  | (2,667 | ) |  |  | (1,658 | ) |  |  | (2,667 | ) |  |  | (1,658 | ) |
| Less: Income tax expense |  |  | (4,285 | ) |  |  | (4,172 | ) |  |  | (4,525 | ) |  |  | (4,400 | ) |
| Net earnings |  | $ | 15,169 |  |  |  | 14,727 |  |  |  | 15,973 |  |  |  | 15,491 |  |

[0001104659-24-012294:8k_2_02:58]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-012294:8k_2_02:59]
Condensed Consolidated Balance Sheets (Unaudited)

[0001104659-24-012294:8k_2_02:60]
(Dollars in thousands)

[0001104659-24-012294:8k_2_02:61]
|  |  | December 31, 2023 |  |  | September 30, 2023 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 51,396 |  |  |  | 41,866 |  |
| Accounts receivable, net |  |  | 194,395 |  |  |  | 198,557 |  |
| Contract assets |  |  | 138,393 |  |  |  | 138,633 |  |
| Inventories |  |  | 202,577 |  |  |  | 184,067 |  |
| Other current assets |  |  | 16,441 |  |  |  | 17,972 |  |
| Total current assets |  |  | 603,202 |  |  |  | 581,095 |  |
| Property, plant and equipment, net |  |  | 159,262 |  |  |  | 155,484 |  |
| Intangible assets, net |  |  | 422,053 |  |  |  | 392,124 |  |
| Goodwill |  |  | 537,601 |  |  |  | 503,177 |  |
| Operating lease assets |  |  | 38,685 |  |  |  | 39,839 |  |
| Other assets |  |  | 11,723 |  |  |  | 11,495 |  |
|  |  | $ | 1,772,526 |  |  |  | 1,683,214 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt |  | $ | 20,000 |  |  |  | 20,000 |  |
| Accounts payable |  |  | 77,960 |  |  |  | 86,973 |  |
| Contract liabilities |  |  | 121,149 |  |  |  | 112,277 |  |
| Other current liabilities |  |  | 85,584 |  |  |  | 95,401 |  |
| Total current liabilities |  |  | 304,693 |  |  |  | 314,651 |  |
| Deferred tax liabilities |  |  | 83,802 |  |  |  | 75,531 |  |
| Non-current operating lease liabilities |  |  | 35,709 |  |  |  | 36,554 |  |
| Other liabilities |  |  | 42,228 |  |  |  | 43,336 |  |
| Long-term debt |  |  | 152,000 |  |  |  | 82,000 |  |
| Shareholders' equity |  |  | 1,154,094 |  |  |  | 1,131,142 |  |
|  |  | $ | 1,772,526 |  |  |  | 1,683,214 |  |

[0001104659-24-012294:8k_2_02:62]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-012294:8k_2_02:63]
Consolidated Statements of Cash Flows

[0001104659-24-012294:8k_2_02:64]
(Dollars in thousands)

[0001104659-24-012294:8k_2_02:65]
|  |  | Three Months Ended December 31, 2023 |  |  | Three Months Ended December 31, 2022 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 15,169 |  |  |  | 14,727 |  |
| Adjustments to reconcile net earnings to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 13,452 |  |  |  | 12,367 |  |
| Stock compensation expense |  |  | 2,180 |  |  |  | 1,860 |  |
| Changes in assets and liabilities |  |  | (22,539 | ) |  |  | (36,920 | ) |
| Effect of deferred taxes |  |  | 484 |  |  |  | (1,042 | ) |
| Net cash provided (used) by operating activities |  |  | 8,746 |  |  |  | (9,008 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Acquisition of business, net of cash acquired |  |  | (56,179 | ) |  |  | - |  |
| Capital expenditures |  |  | (7,848 | ) |  |  | (4,791 | ) |
| Additions to capitalized software |  |  | (2,942 | ) |  |  | (2,795 | ) |
| Net cash used by investing activities |  |  | (66,969 | ) |  |  | (7,586 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from long-term debt |  |  | 99,000 |  |  |  | 17,000 |  |
| Principal payments on long-term debt and short-term borrowings |  |  | (29,000 | ) |  |  | (38,000 | ) |
| Dividends paid |  |  | (2,064 | ) |  |  | (2,067 | ) |
| Purchases of common stock into treasury |  |  | - |  |  |  | (4,147 | ) |
| Other |  |  | (1,432 | ) |  |  | (2,412 | ) |
| Net cash provided (used) by financing activities |  |  | 66,504 |  |  |  | (29,626 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 1,249 |  |  |  | 418 |  |
| Net increase (decrease) in cash and cash equivalents |  |  | 9,530 |  |  |  | (45,802 | ) |
| Cash and cash equivalents, beginning of period |  |  | 41,866 |  |  |  | 97,724 |  |
| Cash and cash equivalents, end of period |  | $ | 51,396 |  |  |  | 51,922 |  |

[0001104659-24-012294:8k_2_02:66]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-012294:8k_2_02:67]
Other Selected Financial Data (Unaudited)

[0001104659-24-012294:8k_2_02:68]
(Dollars in thousands)

[0001104659-24-012294:8k_2_02:69]
| Backlog And Entered Orders - Q1 2024 |  | Aerospace & Defense |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 10/1/23 |  | $ | 484,069 |  |  |  | 133,459 |  |  |  | 154,834 |  |  |  | 772,362 |  |
| Entered Orders |  |  | 171,557 |  |  |  | 76,964 |  |  |  | 45,199 |  |  |  | 293,720 |  |
| Sales |  |  | (94,733 | ) |  |  | (82,984 | ) |  |  | (40,597 | ) |  |  | (218,314 | ) |
| Ending Backlog - 12/31/23 |  | $ | 560,893 |  |  |  | 127,439 |  |  |  | 159,436 |  |  |  | 847,768 |  |

[0001104659-24-012294:8k_2_02:70]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-012294:8k_2_02:71]
Reconciliation of Non-GAAP Financial Measures (Unaudited)

[0001104659-24-012294:8k_2_02:72]
| EPS – Adjusted Basis Reconciliation – Q1 2024 |  |  |  |  |
| EPS – GAAP Basis – Q1 2024 |  | $ | 0.59 |  |
| Adjustments (defined below) |  |  | 0.03 |  |
| EPS – As Adjusted Basis – Q1 2024 |  | $ | 0.62 |  |

[0001104659-24-012294:8k_2_02:73]
Adjustments exclude $0.03
per share consisting primarily of MPE acquisition inventory step-up and backlog charges and acquisition related costs.

[0001104659-24-012294:8k_2_02:74]
The $0.03 of EPS adjustments per share consists
of $1,044K of pre-tax charges offset by $240K of tax benefit for net impact of $804K.

[0001104659-24-012294:8k_2_02:75]
| EPS – Adjusted Basis Reconciliation – Q1 2023 |  |  |  |  |
| EPS – GAAP Basis – Q1 2023 |  | $ | 0.57 |  |
| Adjustments (defined below) |  |  | 0.03 |  |
| EPS – As Adjusted Basis – Q1 2023 |  | $ | 0.60 |  |

[0001104659-24-012294:8k_2_02:76]
Adjustments exclude $0.03
per share consisting of executive management transition costs at Corporate and restructuring charges within the A&D segment.

[0001104659-24-012294:8k_2_02:77]
The $0.03 of EPS adjustments per share consists
of $992K of pre-tax charges offset by $228K of tax benefit for net impact of $764K.
