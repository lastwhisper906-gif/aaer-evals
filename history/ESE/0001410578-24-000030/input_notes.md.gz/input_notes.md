# ESE notes — 0001410578-24-000030


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001410578-24-000030:notes:1]
[same as prior period, unchanged from 0001410578-23-001616:notes:1]

[0001410578-24-000030:notes:2]
[same as prior period, unchanged from 0001410578-23-001616:notes:2]

[0001410578-24-000030:notes:3]
The Company’s results for the three-month period ended December 31, 2023 are not necessarily indicative of the results for the entire 2024 fiscal year. References to the first quarters of 2024 and 2023 represent the fiscal quarters ended December 31, 2023 and 2022, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:EarningsPerShareTextBlock

[0001410578-24-000030:notes:4]
[same as prior period, unchanged from 0001410578-23-001616:notes:4]

[0001410578-24-000030:notes:5]
Basic EPS is calculated using the weighted average number of common shares outstanding during the period. Diluted EPS is calculated using the weighted average number of common shares outstanding during the period plus shares issuable upon the assumed exercise of dilutive common share options and vesting of performance-accelerated restricted stock unit awards and time - vested restricted stock unit awards by using the treasury stock method. The number of shares used in the calculation of earnings per share for each period presented is as follows (in thousands):

[0001410578-24-000030:notes:6]
| ​ |  | Three Months |
| ​ | ​ | Ended December 31, |
| ​ |  | 2023 |  | 2022 |
| Weighted Average Shares Outstanding — Basic |  | 25,797 |  | 25,863 |
| Dilutive Restricted Shares | ​ | 49 | ​ | 80 |
| Adjusted Shares — Diluted |  | 25,846 |  | 25,943 |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001410578-24-000030:notes:7]
[same as prior period, unchanged from 0001410578-23-001616:notes:7]

[0001410578-24-000030:notes:8]
On November 9, 2023, the Company acquired MPE Limited (MPE), based in the United Kingdom, for a purchase price of approximately $56.2 million, net of cash acquired. MPE is a leading global manufacturer of high-performance EMC/EMP filters and capacitor products for military, utility, telecommunication, and other critical infrastructure applications. Since the date of acquisition, the operating results for the MPE business have been included as part of ETS-Lindgren in the Test segment. The acquisition date fair value of the assets acquired and liabilities assumed primarily were as follows: approximately $0.4 million of accounts receivable, $1.1 million of inventory, $1.7 million of property, plant and equipment, $0.7 million of accounts payable and accrued expenses, $7.8 million of deferred tax liabilities, and $31.1 million of identifiable intangible assets, mainly consisting of customer relationships totaling $29.1 million. The acquired goodwill of $30.3 million related to excess value associated with opportunities to expand the services and products that the Company can offer to its customers. The Company does not anticipate that the goodwill will be deductible for tax purposes.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001410578-24-000030:notes:9]
[same as prior period, unchanged from 0001410578-23-001616:notes:9]

[0001410578-24-000030:notes:10]
The Company provides compensation benefits to certain key employees under several share-based plans providing for performance-accelerated and/or time-vested restricted stock unit awards, and to non-employee directors under a separate compensation plan.

[0001410578-24-000030:notes:11]
Performance-Accelerated Restricted Stock Unit (PARS) Awards, Time-Vested Restricted Stock Unit (RSU) Awards, and Performance Share Unit (PSU) Awards

[0001410578-24-000030:notes:12]
Compensation expense related to these awards was $1.9 million and $1.6 million for the three-month periods ended December 31, 2023 and 2022, respectively. There were 234,036 non-vested shares outstanding as of December 31, 2023.

[0001410578-24-000030:notes:13]
[same as prior period, unchanged from 0001410578-23-001616:notes:13]

[0001410578-24-000030:notes:14]
Compensation expense related to the non-employee director grants was $0.3 million and $0.3 million for the three-month periods ended December 31, 2023 and 2022, respectively.

[0001410578-24-000030:notes:15]
The total share-based compensation cost that has been recognized in the results of operations and included within selling, general and administrative expenses (SG&A) was $2.2 million and $1.9 million for the three-month periods ended December 31, 2023 and 2022, respectively. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $0.2 million and $0.1 million for the three-month periods ended December 31, 2023 and 2022, respectively. As of December 31, 2023 there was $15.5 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a remaining weighted-average period of 2.0 years.


## us-gaap:InventoryDisclosureTextBlock

[0001410578-24-000030:notes:16]
[same as prior period, unchanged from 0001410578-23-001616:notes:16]

[0001410578-24-000030:notes:17]
[same as prior period, unchanged from 0001410578-23-001616:notes:17]

[0001410578-24-000030:notes:18]
| ​ | ​ | December 31, | ​ | September 30, |
| (In thousands) |  | 2023 |  | 2023 |
| Finished goods | ​ | $ | 37,996 |  | 34,577 |
| Work in process | ​ |  | 54,656 |  | 42,178 |
| Raw materials | ​ |  | 109,925 |  | 107,312 |
| Total inventories | ​ | $ | 202,577 |  | 184,067 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001410578-24-000030:notes:19]
[same as prior period, unchanged from 0001410578-23-001616:notes:19]

[0001410578-24-000030:notes:20]
Included on the Company’s Consolidated Balance Sheets at December 31, 2023 and September 30, 2023 are the following intangible assets gross carrying amounts and accumulated amortization from continuing operations:

[0001410578-24-000030:notes:21]
| ​ |  | December 31, |  | September 30, |
| (Dollars in thousands) |  | 2023 |  | 2023 |
| Goodwill | ​ | $ | 537,601 |  | 503,177 |
| Intangible assets with determinable lives: | ​ |  | ​ | ​ | ​ |
| Patents | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 2,517 | ​ | 2,516 |
| Less: accumulated amortization | ​ |  | 1,253 | ​ | 1,218 |
| Net | ​ | $ | 1,264 | ​ | 1,298 |
| Capitalized software | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 125,237 | ​ | 121,883 |
| Less: accumulated amortization | ​ |  | 83,709 | ​ | 80,774 |
| Net | ​ | $ | 41,528 | ​ | 41,109 |
| Customer relationships | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 328,624 | ​ | 296,927 |
| Less: accumulated amortization | ​ |  | 117,755 | ​ | 113,311 |
| Net | ​ | $ | 210,869 | ​ | 183,616 |
| Other | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 15,216 | ​ | 14,232 |
| Less: accumulated amortization | ​ |  | 10,033 | ​ | 9,578 |
| Net | ​ | $ | 5,183 | ​ | 4,654 |
| Intangible assets with indefinite lives: | ​ |  | ​ | ​ | ​ |
| Trade names | ​ | $ | 163,209 | ​ | 161,447 |

[0001410578-24-000030:notes:22]
The changes in the carrying amount of goodwill attributable to each business segment for the three months ended December 31, 2023 are as follows:

[0001410578-24-000030:notes:23]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | Aerospace | ​ | ​ |
| (Dollars in millions) |  | USG |  | Test |  | & Defense |  | Total |
| Balance as of September 30, 2023 | ​ | $ | 353.6 |  | ​ | 34.0 |  | 115.6 |  | 503.2 |
| Acquisition activity | ​ | ​ | — | ​ | ​ | 30.3 | ​ | — | ​ | 30.3 |
| Foreign currency translation | ​ | ​ | 3.3 | ​ | ​ | 0.8 | ​ | — | ​ | 4.1 |
| Balance as of December 31, 2023 | ​ | $ | 356.9 | ​ | ​ | 65.1 | ​ | 115.6 | ​ | 537.6 |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001410578-24-000030:notes:24]
[same as prior period, unchanged from 0001410578-23-001616:notes:24]

[0001410578-24-000030:notes:25]
The Company is organized based on the products and services that it offers and classifies its business operations in three reportable segments for financial reporting purposes: Aerospace & Defense (A&D), Utility Solutions Group (USG) and RF Test & Measurement (Test). The A&D segment’s operations consist of PTI Technologies Inc. (PTI), VACCO Industries (VACCO), Crissair, Inc. (Crissair), Globe Composite Solutions, LLC (Globe) and Mayday Manufacturing Co. (Mayday). The companies within this segment primarily design and manufacture specialty filtration, fluid control and naval products, including hydraulic filter elements and fluid control devices used in aerospace and defense applications; unique filter mechanisms used in micro-propulsion devices for satellites, custom designed filters for manned aircraft and submarines, products and systems to reduce vibration and/or acoustic signatures and otherwise reduce or obscure a vessel’s signature, and other communications, sealing, surface control and hydrodynamic related applications to enhance U.S. Navy maritime survivability; precision-tolerance machined components for the aerospace and defense industry; metal processing services; and miniature electro-explosive devices utilized in mission-critical defense and aerospace applications.

[0001410578-24-000030:notes:26]
The USG segment’s operations consist primarily of Doble Engineering Company and related subsidiaries including Morgan Schaffer and Altanova (collectively, Doble), and NRG Systems, Inc. (NRG). Doble is an industry leader in the development, manufacture and delivery of diagnostic testing and data management solutions that enable electric power grid operators to assess the integrity of high voltage power delivery equipment. It combines three core elements for customers – diagnostic test and condition monitoring instruments, expert consulting, and testing services – and provides access to its large reserve of related empirical knowledge. NRG is a global market leader in the design and manufacture of decision support tools for the renewable energy industry, primarily wind and solar.

[0001410578-24-000030:notes:27]
The Test segment’s operations consist primarily of ETS-Lindgren Inc. and related subsidiaries (ETS-Lindgren). ETS-Lindgren is an industry leader in designing and manufacturing products and systems to measure and control RF and acoustic energy. It serves the acoustics, medical, health and safety, electronics, wireless communications, automotive and defense markets, supplying a broad range of turnkey systems, including RF test facilities and measurement systems, acoustic test enclosures, RF and magnetically shielded rooms and secure communication facilities, and providing the design, program management, installation and integration services required to successfully complete these types of facilities. It also provides a broad range of components including RF absorptive materials, filters, antennas, field probes, test cells, proprietary measurement software and other test accessories required to perform a variety of tests and measurements, and offers a variety of services including calibration and product tests.

[0001410578-24-000030:notes:28]
[same as prior period, unchanged from 0001410578-23-001616:notes:29]

[0001410578-24-000030:notes:29]
| ​ | ​ | Three Months |
| ​ | ​ | Ended December 31, |
| (In thousands) |  | 2023 |  | 2022 |
| NET SALES | ​ | ​ | ​ | ​ | ​ |
| Aerospace & Defense | ​ | $ | 94,733 | ​ | 82,983 |
| USG | ​ | ​ | 82,984 | ​ | 71,045 |
| Test | ​ | ​ | 40,597 | ​ | 51,473 |
| Consolidated totals | ​ | $ | 218,314 | ​ | 205,501 |
| EBIT | ​ | ​ | ​ | ​ | ​ |
| Aerospace & Defense | ​ | $ | 16,663 | ​ | 12,536 |
| USG | ​ | ​ | 17,625 | ​ | 16,131 |
| Test | ​ | ​ | 1,779 | ​ | 5,411 |
| Corporate (loss) | ​ | ​ | (13,946) | ​ | (13,521) |
| Consolidated EBIT | ​ | ​ | 22,121 | ​ | 20,557 |
| Less: Interest expense | ​ | ​ | (2,667) | ​ | (1,658) |
| Earnings before income taxes | ​ | $ | 19,454 | ​ | 18,899 |

[0001410578-24-000030:notes:30]
[same as prior period, unchanged from 0001410578-23-001616:notes:31]

[0001410578-24-000030:notes:31]
[same as prior period, unchanged from 0001410578-23-001616:notes:32]

[0001410578-24-000030:notes:32]
[same as prior period, unchanged from 0001410578-23-001616:notes:33]


## us-gaap:DebtDisclosureTextBlock

[0001410578-24-000030:notes:33]
8.    DEBT

[0001410578-24-000030:notes:34]
The Company’s debt is summarized as follows:

[0001410578-24-000030:notes:35]
| ​ |  | December 31, | ​ | September 30, |
| (In thousands) |  | 2023 |  | 2023 |
| Total borrowings | ​ | $ | 172,000 | ​ | 102,000 |
| Current portion of long-term debt | ​ | ​ | (20,000) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 152,000 | ​ | 82,000 |

[0001410578-24-000030:notes:36]
The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of seven banks led by JP Morgan Chase Bank, N.A., as administrative agent, Bank of America, N.A., as syndication agent, and Commerce Bank and TD Bank, N.A. as co-documentation agents. The Credit Facility matures August 30, 2028, with balance due by this date.

[0001410578-24-000030:notes:37]
At December 31, 2023, the Company had approximately $322 million available to borrow under the Credit Facility, plus the $250 million increase option subject to the lenders’ consent, in addition to $51.4 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of December 31, 2023, as the Company intends to repay this amount within the next twelve months; however, the Company no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $5.8 million at December 31, 2023.

[0001410578-24-000030:notes:38]
Interest on borrowings under the Credit Facility is calculated at a spread over either an Adjusted Term SOFR Rate, Adjusted EURIBOR Rate, Adjusted CDOR Rate, Alternate Base Rate or Daily Simple RFR, at the Company’s election. The Credit Facility also requires a facility fee ranging from 12.5 to 25 basis points per annum on the unused portion. The interest rate spreads and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio. The weighted average interest rates were 6.8% and 4.6% for the three-month periods ending December 31, 2023 and 2022, respectively. As of December 31, 2023, the Company was in compliance with all covenants.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001410578-24-000030:notes:39]
[same as prior period, unchanged from 0001410578-23-001616:notes:40]

[0001410578-24-000030:notes:40]
The first quarter 2024 effective income tax rate was 22.0% compared to 22.1% in the first quarter of 2023. There were no significant changes in the effective income tax rate between the periods.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001410578-24-000030:notes:41]
[same as prior period, unchanged from 0001410578-23-001616:notes:43]

[0001410578-24-000030:notes:42]
The change in shareholders’ equity for the first three months ended December 31, 2023 and 2022 is shown below (in thousands):

[0001410578-24-000030:notes:43]
| ​ | ​ | Three Months Ended December 31, |
| ​ |  | 2023 |  | 2022 |
| Common stock | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | $ | 308 | ​ | 307 |
| Stock plans | ​ | ​ | — | ​ | — |
| Ending balance | ​ | ​ | 308 | ​ | 307 |
| Additional paid-in-capital | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | 304,850 | ​ | 301,553 |
| Stock plans | ​ | ​ | 433 | ​ | (856) |
| Ending balance | ​ | ​ | 305,283 | ​ | 300,697 |
| Retained earnings | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | 989,315 | ​ | 905,022 |
| Net earnings common stockholders | ​ | ​ | 15,169 | ​ | 14,727 |
| Dividends paid | ​ | ​ | (2,064) | ​ | (2,067) |
| Ending balance | ​ | ​ | 1,002,420 | ​ | 917,682 |
| Accumulated other comprehensive income (loss) | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | (23,969) | ​ | (31,764) |
| Foreign currency translation | ​ | ​ | 9,414 | ​ | 11,513 |
| Ending balance | ​ | ​ | (14,555) | ​ | (20,251) |
| Treasury stock | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | (139,362) | ​ | (126,961) |
| Share repurchases | ​ | ​ | — | ​ | (5,076) |
| Ending balance | ​ | ​ | (139,362) | ​ | (132,037) |
| Total equity | ​ | $ | 1,154,094 | ​ | 1,066,398 |


## us-gaap:FairValueDisclosuresTextBlock

[0001410578-24-000030:notes:44]
[same as prior period, unchanged from 0001410578-23-001616:notes:46]

[0001410578-24-000030:notes:45]
[same as prior period, unchanged from 0001410578-23-001616:notes:47]

[0001410578-24-000030:notes:46]
[same as prior period, unchanged from 0001410578-23-001616:notes:48]

[0001410578-24-000030:notes:47]
[same as prior period, unchanged from 0001410578-23-001616:notes:49]

[0001410578-24-000030:notes:48]
[same as prior period, unchanged from 0001410578-23-001616:notes:50]

[0001410578-24-000030:notes:49]
[same as prior period, unchanged from 0001410578-23-001616:notes:51]

[0001410578-24-000030:notes:50]
The Company has estimated the fair value of its financial instruments as of December 31, 2023 and September 30, 2023 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001410578-24-000030:notes:51]
[same as prior period, unchanged from 0001410578-23-001616:notes:53]

[0001410578-24-000030:notes:52]
[same as prior period, unchanged from 0001410578-23-001616:notes:54]

[0001410578-24-000030:notes:53]
[same as prior period, unchanged from 0001410578-23-001616:notes:55]

[0001410578-24-000030:notes:54]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however, they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during the three-month period ended December 31, 2023.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001410578-24-000030:notes:55]
[same as prior period, unchanged from 0001410578-23-001616:notes:57]

[0001410578-24-000030:notes:56]
[same as prior period, unchanged from 0001410578-23-001616:notes:58]

[0001410578-24-000030:notes:57]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2023 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within each reportable segment.

[0001410578-24-000030:notes:58]
| ​ | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 37,209 | ​ | $ | 81,469 | ​ | $ | 35,087 | ​ | $ | 153,765 |
| Government | ​ | ​ | 57,524 | ​ | ​ | 1,515 | ​ | ​ | 5,510 | ​ | ​ | 64,549 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 79,901 | ​ | $ | 55,961 | ​ | $ | 22,252 | ​ | $ | 158,114 |
| International | ​ | ​ | 14,832 | ​ | ​ | 27,023 | ​ | ​ | 18,345 | ​ | ​ | 60,200 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 39,465 | ​ | $ | 66,703 | ​ | $ | 7,980 | ​ | $ | 114,148 |
| Over time | ​ | ​ | 55,268 | ​ | ​ | 16,281 | ​ | ​ | 32,617 | ​ | ​ | 104,166 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |

[0001410578-24-000030:notes:59]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2022 are presented in the table below:

[0001410578-24-000030:notes:60]
| ​ | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 36,740 | ​ | $ | 70,162 | ​ | $ | 45,992 | ​ | $ | 152,894 |
| Government | ​ | ​ | 46,243 | ​ | ​ | 883 | ​ | ​ | 5,481 | ​ | ​ | 52,607 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 68,934 | ​ | $ | 46,379 | ​ | $ | 27,503 | ​ | $ | 142,816 |
| International | ​ | ​ | 14,049 | ​ | ​ | 24,666 | ​ | ​ | 23,970 | ​ | ​ | 62,685 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 33,604 | ​ | $ | 56,031 | ​ | $ | 9,101 | ​ | $ | 98,736 |
| Over time | ​ | ​ | 49,379 | ​ | ​ | 15,014 | ​ | ​ | 42,372 | ​ | ​ | 106,765 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |

[0001410578-24-000030:notes:61]
[same as prior period, unchanged from 0001410578-23-001616:notes:65]

[0001410578-24-000030:notes:62]
[same as prior period, unchanged from 0001410578-23-001616:notes:66]

[0001410578-24-000030:notes:63]
For our overtime revenue recognized using the output method of costs incurred, contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to one or more years, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change. In addition, in the USG segment, we recognize revenue as a series of distinct services based on each day of providing services (straight-line over the contract term) for certain of our USG segment contracts. Under the typical payment terms of our service contracts, the customer pays us in advance of when services are performed. In addition, in the Test segment, we use milestones to measure progress for our Test segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts.

[0001410578-24-000030:notes:64]
[same as prior period, unchanged from 0001410578-23-001616:notes:69]

[0001410578-24-000030:notes:65]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At December 31, 2023, the Company had $847.8 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 66% in the next twelve months.

[0001410578-24-000030:notes:66]
Contract assets, contract liabilities and accounts receivable

[0001410578-24-000030:notes:67]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At December 31, 2023, contract assets, contract liabilities and accounts receivable totaled $138.4 million, $131.9 million and $194.4 million, respectively. During the first quarter of 2024, the Company recognized approximately $24.4 million in revenues that were included in the contract liabilities balance at September 30, 2023. At September 30, 2023, contract assets, contract liabilities and accounts receivable totaled $138.6 million, $123.1 million and $198.6 million, respectively.


## ese:OperatingAndFinancingLeasesOfLesseeDisclosureTextBlock

[0001410578-24-000030:notes:68]
[same as prior period, unchanged from 0001410578-23-001616:notes:73]

[0001410578-24-000030:notes:69]
[same as prior period, unchanged from 0001410578-23-001616:notes:74]

[0001410578-24-000030:notes:70]
The Company’s leases for real estate commonly include escalating payments. These variable lease payments are included in the calculation of the ROU asset and lease liability. In addition to the present value of the future lease payments, the calculation of the ROU asset also includes any deferred rent, lease pre-payments and initial direct costs of obtaining the lease.

[0001410578-24-000030:notes:71]
In addition to the base rent, real estate leases typically contain provisions for common-area maintenance and other similar services, which are considered non-lease components for accounting purposes. Non-lease components are excluded from ROU assets and lease liabilities and expensed as incurred.

[0001410578-24-000030:notes:72]
[same as prior period, unchanged from 0001410578-23-001616:notes:77]

[0001410578-24-000030:notes:73]
[same as prior period, unchanged from 0001410578-23-001616:notes:78]

[0001410578-24-000030:notes:74]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended |
| ​ | ​ | December 31, | ​ | December 31, |
| (Dollars in thousands) |  | 2023 |  | 2022 |
| Finance lease cost | ​ | ​ | ​ | ​ | ​ | ​ |
| Amortization of right-of-use assets | ​ | $ | 393 | ​ | ​ | 393 |
| Interest on lease liabilities | ​ | ​ | 223 | ​ | ​ | 236 |
| Operating lease cost | ​ | ​ | 1,864 | ​ | ​ | 1,645 |
| Total lease costs | ​ | $ | 2,480 | ​ | ​ | 2,274 |

[0001410578-24-000030:notes:75]
[same as prior period, unchanged from 0001410578-23-001616:notes:81]

[0001410578-24-000030:notes:76]
| ​ |  | Three Months Ended |  | Three Months Ended |  |
| ​ | ​ | December 31, | ​ | December 31, |  |
| (Dollars in thousands) | ​ | 2023 | ​ | 2022 |  |
| Cash paid for amounts included in the measurement of lease liabilities | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Operating cash flows from operating leases | ​ | $ | 1,819 | ​ | ​ | 1,601 | ​ |
| Operating cash flows from finance leases | ​ | ​ | 223 | ​ | ​ | 236 | ​ |
| Financing cash flows from finance leases | ​ | ​ | 355 | ​ | ​ | 327 | ​ |
| Right-of-use assets obtained in exchange for lease liabilities | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Operating leases | ​ | $ | — | ​ | ​ | 13,964 | ​ |
| Weighted-average remaining lease term | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Operating leases | ​ | ​ | 11.1 | years | ​ | 11.6 | years |
| Finance leases | ​ | ​ | 11.1 | years | ​ | 11.7 | years |
| Weighted-average discount rate | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Operating leases | ​ | ​ | 4.5 | % | ​ | 4.4 | % |
| Finance leases | ​ | ​ | 4.7 | % | ​ | 4.6 | % |

[0001410578-24-000030:notes:77]
The following is a reconciliation of future undiscounted cash flows to the operating and finance lease liabilities, and the related ROU assets, presented on the Consolidated Balance Sheet on December 31, 2023:

[0001410578-24-000030:notes:78]
| (Dollars in thousands) | ​ | Operating |  | Finance |
| Years Ending September 30: |  | Leases |  | Leases |
| 2024 (excluding the three months ended December 31, 2023) | ​ | $ | 5,044 | ​ | 1,634 |
| 2025 | ​ | ​ | 5,684 | ​ | 2,233 |
| 2026 | ​ | ​ | 4,472 | ​ | 2,297 |
| 2027 | ​ | ​ | 4,265 | ​ | 2,356 |
| 2028 and thereafter | ​ | ​ | 32,991 | ​ | 16,470 |
| Total minimum lease payments | ​ | ​ | 52,456 | ​ | 24,990 |
| Less: amounts representing interest | ​ | ​ | 11,869 | ​ | 6,010 |
| Present value of net minimum lease payments | ​ | $ | 40,587 | ​ | 18,980 |
| Less: current portion of lease obligations | ​ | ​ | 4,878 | ​ | 1,348 |
| Non-current portion of lease obligations | ​ | $ | 35,709 | ​ | 17,632 |
| ROU assets | ​ | $ | 38,685 | ​ | 14,799 |

[0001410578-24-000030:notes:79]
Operating lease liabilities are included on the Consolidated Balance Sheet in accrued other expenses (current portion) and as a caption on the Consolidated Balance Sheet (long-term portion). Finance lease liabilities are included on the Consolidated Balance Sheet in accrued other expenses (current portion) and other liabilities (long-term portion). Operating lease ROU assets are included as a caption on the Consolidated Balance Sheet and finance lease ROU assets are included in Property, plant and equipment on the Consolidated Balance sheet.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001410578-24-000030:notes:80]
14.  RECENT ACCOUNTING PRONOUNCEMENTS

[0001410578-24-000030:notes:81]
In November 2023, the FASB issued ASU 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures,” which expands annual and interim disclosure requirements for reportable segments, primarily through enhanced disclosures about significant expenses. The new segment disclosures are effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024. Management will review the extent of new disclosures necessary in the coming quarters, prior to implementation in our fiscal year 2025. Other than additional disclosure, we do not expect a change to our consolidated statements of operations, financial position, or cash flows.

[0001410578-24-000030:notes:82]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures,” which provides qualitative and quantitative updates to the rate reconciliation and income taxes paid disclosures. This ASU will be effective for fiscal years beginning after December 15, 2024. Management will review the extent of new disclosures necessary in the coming quarters, prior to implementation in our fiscal year 2026. Other than additional disclosure, we do not expect a change to our consolidated statements of operations, financial position, or cash flows.
