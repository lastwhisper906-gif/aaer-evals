# ESE 10-K controls and the auditor's report


## auditors_report

[0001410578-21-000447:auditors_report:1]
F-1

[0001410578-21-000447:auditors_report:2]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001410578-21-000447:auditors_report:3]
To the Shareholders and Board of Directors

[0001410578-21-000447:auditors_report:4]
ESCO Technologies Inc.:

[0001410578-21-000447:auditors_report:5]
Opinion on the Consolidated Financial Statements

[0001410578-21-000447:auditors_report:6]
We have audited the accompanying consolidated balance sheets of ESCO Technologies Inc. and subsidiaries (the Company) as of September 30, 2021 and 2020, the related consolidated statements of operations, comprehensive income, shareholders’ equity, and cash flows for each of the years in the three-year period ended September 30, 2021 and the related notes (collectively, the consolidated financial statements). In our opinion, the consolidated financial statements present fairly, in all material respects, the financial position of the Company as of September 30, 2021 and 2020, and the results of its operations and its cash flows for each of the years in the three-year period ended September 30, 2021, in conformity with U.S. generally accepted accounting principles.

[0001410578-21-000447:auditors_report:7]
We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the Company’s internal control over financial reporting as of September 30, 2021, based on criteria established in Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission, and our report dated November 29, 2021 expressed an adverse opinion on the effectiveness of the Company’s internal control over financial reporting.

[0001410578-21-000447:auditors_report:8]
Basis for Opinion

[0001410578-21-000447:auditors_report:9]
These consolidated financial statements are the responsibility of the Company’s management. Our responsibility is to express an opinion on these consolidated financial statements based on our audits. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001410578-21-000447:auditors_report:10]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0001410578-21-000447:auditors_report:11]
Critical Audit Matters

[0001410578-21-000447:auditors_report:12]
The critical audit matters communicated below are matters arising from the current period audit of the consolidated financial statements that were communicated or required to be communicated to the audit committee and that: (1) relate to accounts or disclosures that are material to the consolidated financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0001410578-21-000447:auditors_report:13]
Revenue Recognition — Estimate of contract costs at completion

[0001410578-21-000447:auditors_report:14]
As discussed in Notes 1 and 15 to the consolidated financial statements, the Company’s Aerospace & Defense segment enters into certain long-term fixed price contracts with aerospace and defense customers to produce various products. These products do not have an alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin. Revenue for these contracts is recognized over time generally using a cost-to-cost model. Under such model, the Company measures the extent of progress towards completion of these contracts based on the ratio of contract costs incurred to date to the estimate of total contract costs at completion. The estimation of these costs requires judgment by the Company given the unique product specifications and requirements for contracts related to the design, development, and manufacture of complex products.

[0001410578-21-000447:auditors_report:15]
We identified the assessment of the estimate of total contract costs at completion for certain contracts in the Aerospace & Defense segment for which revenue is recognized over time using a cost-to-cost model as a critical audit matter. Complex auditor

[0001410578-21-000447:auditors_report:16]
F-2

[0001410578-21-000447:auditors_report:17]
judgment was required in evaluating expected engineering and production requirements of the contracts and the associated cost estimates for labor hours and materials, which represent assumptions with a high level of estimation uncertainty and that are also susceptible to potential management bias. Changes to these estimates may have a significant impact on the net sales and earnings recorded during the fiscal year.

[0001410578-21-000447:auditors_report:18]
The following are the primary procedures we performed to address this critical audit matter. We evaluated the design and tested the operating effectiveness of certain internal controls related to the Company’s revenue recognition process. This included controls over the accumulation and estimation of costs to complete for labor hours and materials for the contracts described above. For a selection of contracts, we compared the Company’s historical estimated costs and profit margin to the actual costs and profit margin for completed contracts to assess the Company’s ability to accurately estimate costs. We challenged the Company’s assumptions for labor hours and materials to be incurred for a selection of contracts by:

[0001410578-21-000447:auditors_report:19]
|  | ● | reading the underlying contract documents, including applicable amendments, to obtain an understanding of the contractual requirements and deliverables |

[0001410578-21-000447:auditors_report:20]
|  | ● | inquiring of financial and operational personnel of the Company to identify factors that should be considered within the cost to complete estimates |

[0001410578-21-000447:auditors_report:21]
|  | ● | comparing the costs incurred to date, as a percentage of the estimated costs at completion, to the Company’s production to date under the contract, including consideration of remaining contract performance risks |

[0001410578-21-000447:auditors_report:22]
|  | ● | comparing actual incurred and remaining estimated material costs to the original estimated amount of material costs at the beginning of the project plus incremental material costs due to contract modification |

[0001410578-21-000447:auditors_report:23]
|  | ● | comparing actual incurred and remaining estimated labor hours to the original estimate of labor hours at the beginning of the project plus incremental labor hours due to contract modification |

[0001410578-21-000447:auditors_report:24]
|  | ● | comparing the estimated costs at completion, which includes costs incurred to date plus estimated costs to complete, to actual costs incurred for similar products previously developed and produced, if applicable |

[0001410578-21-000447:auditors_report:25]
|  | ● | inspecting correspondence, if applicable, between the Company and the customer regarding actual and expected contract performance to date and comparing to the estimate to complete |

[0001410578-21-000447:auditors_report:26]
|  | ● | assessing the estimates for indicators of management bias by evaluating the audit evidence obtained through the procedures described above. |

[0001410578-21-000447:auditors_report:27]
Sufficiency of audit evidence obtained over net sales

[0001410578-21-000447:auditors_report:28]
As discussed in Notes 1 and 15 to the consolidated financial statements, sales are recognized primarily from the sale of products across various industries and through multiple Company subsidiaries and locations around the world. The Company recorded $715.4 million of net sales for the year ended September 30, 2021.

[0001410578-21-000447:auditors_report:29]
We identified the evaluation of the sufficiency of audit evidence obtained over net sales as a critical audit matter. Evaluating the sufficiency of audit evidence obtained over net sales required especially subjective auditor judgment because of the disaggregated nature of the Company’s operations, including revenue recognition accounting policies and procedures that differ among the various subsidiaries and locations. This included determining the Company subsidiaries and locations at which procedures were performed.

[0001410578-21-000447:auditors_report:30]
The following are the primary procedures we performed to address this critical audit matter. We applied auditor judgment to determine the nature and extent of procedures to be performed over net sales, including the determination of the Company subsidiaries and locations at which those procedures were to be performed. At each Company subsidiary and location where procedures were performed, we:

[0001410578-21-000447:auditors_report:31]
|  | ● | evaluated the design and tested the operating effectiveness of certain internal controls related to the Company’s revenue recognition process at the applicable subsidiaries and locations; and |

[0001410578-21-000447:auditors_report:32]
|  | ● | assessed the recorded net sales for a selection of transactions by comparing the amount recognized for consistency with underlying documentation, including contracts with customers and shipping documentation, if applicable, and the Company’s revenue recognition policies. |

[0001410578-21-000447:auditors_report:33]
We evaluated the sufficiency of audit evidence obtained by assessing the results of procedures performed.

[0001410578-21-000447:auditors_report:34]
F-3

[0001410578-21-000447:auditors_report:35]
Assessing the carrying value of goodwill of certain reporting units in the Aerospace & Defense segment

[0001410578-21-000447:auditors_report:36]
As discussed in Notes 1 and 4 to the consolidated financial statements, the Company reviews goodwill for impairment annually and whenever events or changes in circumstances indicate it is more likely than not that the fair value of a reporting unit is less than its carrying value. The Company uses a discounted cash flow method, using a discount rate determined to be commensurate with the risk inherent in each reporting unit’s business model when estimating fair value.

[0001410578-21-000447:auditors_report:37]
We identified the assessment of the carrying value of goodwill of certain reporting units in the Aerospace & Defense segment as a critical audit matter. The valuation of each reporting unit involved estimation uncertainty in the projection of future cash flows, resulting in an increased level of subjective auditor judgment. Specifically, subjective and challenging auditor judgment was required to evaluate the forecasted revenue growth rates, gross margins, and discount rates used in the discounted cash flows to derive the fair value of the reporting unit. Evaluation of the forecasted revenue growth rates and gross margins was challenging as they represented subjective determinations of future market and economic conditions that were sensitive to variation. Specialized skills and knowledge were required to evaluate the Company’s discount rate assumptions.

[0001410578-21-000447:auditors_report:38]
The following were the primary procedures we performed to address this critical audit matter. We evaluated the design and tested the operating effectiveness of certain internal controls over the Company’s goodwill impairment assessment process. This included controls related to the determination of the fair value of the reporting units and the development of forecasted revenue growth rates, gross margins, and discount rates. We evaluated the Company’s forecasted revenue growth rates by comparing to industry and peer company forecasted revenue growth rates. We also assessed the Company’s forecasted revenue growth rates and gross margins by comparing them to historical experience and to underlying business strategies and growth plans available for market participants for each reporting unit. We compared historical forecasted revenue growth rates and gross margins to actual results in order to assess the Company’s ability to forecast. We involved valuation professionals with specialized skills and knowledge, who assisted in evaluating the discount rates by comparing them to discount rate ranges that were independently developed using publicly available market data for comparable entities.

[0001410578-21-000447:auditors_report:39]
Evaluation of the fair value of acquired intangible assets

[0001410578-21-000447:auditors_report:40]
As discussed in Note 2 to the consolidated financial statements, the Company acquired I.S.A. – Altanova Group S.r.l., (Altanova) on July 29, 2021 and the assets of Phenix Technologies, Inc. (Phenix) on August 9, 2021. As a result of these transactions, the Company acquired customer relationship intangible assets with a preliminary valuation of $4.3 million and $3.7 million, respectively, and trade name intangible assets with a preliminary valuation of $50.5 million and $9.6 million, respectively (collectively, the intangible assets).

[0001410578-21-000447:auditors_report:41]
We identified the evaluation of the fair value of these intangible assets acquired in the Altanova and Phenix business combinations as a critical audit matter. A higher degree of subjective auditor judgment was required to evaluate forecasted revenue from existing customers, inclusive of attrition, and the related forecasted cost of sales and operating expenses, discount rate, and the selection of guideline public companies (GPC) assumptions used by the Company to value the customer relationship intangible assets. A higher degree of subjective auditor judgment was also required to evaluate forecasted revenue, royalty rate, and discount rate assumptions used by the Company to value the trade name intangible assets.

[0001410578-21-000447:auditors_report:42]
The following are the primary procedures we performed to address this critical audit matter. We evaluated the design and tested the operating effectiveness of certain internal controls over the Company’s acquisition-date valuation process, including controls related to the development of the relevant assumptions listed above. We compared the Company’s estimates of forecasted revenues from existing customers, total forecasted revenues and the related forecasted cost of sales and operating expenses to the acquiree’s historical results. We evaluated the Company’s forecasted revenues from existing customers, total forecasted revenues, and forecasted cost of sales and operating expenses by comparing them to those of the Company’s peers and trends in the industry. In addition, we involved valuation professionals with specialized skills and knowledge, who assisted in:

[0001410578-21-000447:auditors_report:43]
|  | ● | evaluating the Company’s determination of the weighted average cost of capital (WACC) by comparing it to the WACCs of comparable peer companies and evaluating the selection of the discount rate by reconciling the weighted average return on assets to the WACC and internal rate of return |

[0001410578-21-000447:auditors_report:44]
|  | ● | comparing the selection of GPCs made by the Company to an independent search of GPCs and evaluating the reasonableness of each GPC selected by reviewing the business descriptions, industries, and markets served |

[0001410578-21-000447:auditors_report:45]
|  | ● | comparing the selected revenue long-term growth rate to publicly available market forecasts of gross domestic product and relevant economic data in the relevant markets and industries |

[0001410578-21-000447:auditors_report:46]
|  | ● | comparing customer attrition to an independent estimate developed based on historical attrition rates for Altanova and Phenix and certain qualitative market factors |

[0001410578-21-000447:auditors_report:47]
F-4

[0001410578-21-000447:auditors_report:48]
|  | ● | evaluating the Company’s royalty rates, by comparing them to royalty rates used for similar assets in the same industry |

[0001410578-21-000447:auditors_report:49]
|  | ● | evaluating the Company’s discount rates, by comparing them against a discount rate range that was independently developed using publicly available market data for comparable peers. |

[0001410578-21-000447:auditors_report:50]
| /s/ KPMG LLP | ​ |

[0001410578-21-000447:auditors_report:51]
We have served as the Company’s auditor since 1990.

[0001410578-21-000447:auditors_report:52]
St. Louis, Missouri

[0001410578-21-000447:auditors_report:53]
November 29, 2021

[0001410578-21-000447:auditors_report:54]
F-5


## item_9a

[0001410578-21-000447:item_9a:1]
Item 9A. Controls and Procedures

[0001410578-21-000447:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001410578-21-000447:item_9a:3]
Our Chief Executive Officer and Chief Financial Officer (“Certifying Officers”) carried out an evaluation of the effectiveness of the design and operation of the Company’s disclosure controls and procedures, as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the Exchange Act) as of September 30, 2021. Our Certifying Officers concluded that, as a result of the material weaknesses in internal control over financial reporting as described below, our disclosure controls and procedures were not effective as of September 30, 2021. Disclosure controls and procedures are designed to ensure that information required to be disclosed by the Company in reports filed or submitted under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the Securities and Exchange Commission’s rules and forms.

[0001410578-21-000447:item_9a:4]
In light of the material weaknesses at a reporting unit within the Company’s Aerospace & Defense (A&D) segment, described below, management performed additional analyses and other procedures to ensure that our Consolidated Financial Statements were prepared in accordance with U.S. generally accepted accounting principles (GAAP). Accordingly, management believes that the Consolidated Financial Statements included in this Annual Report on Form 10-K fairly present, in all material respects, our financial position, results of operations, and cash flows as of and for the periods presented in accordance with GAAP.

[0001410578-21-000447:item_9a:5]
Management’s Report on Internal Control Over Financial Reporting

[0001410578-21-000447:item_9a:6]
Management is responsible for establishing and maintaining adequate internal control over financial reporting, as defined in Rules 13a-15(f) and 15d-15(f) of the Exchange Act. The Company’s management, with participation of the Certifying Officers, under the oversight of our Board of Directors, evaluated the effectiveness of the Company’s internal control over financial reporting as of September 30, 2021 using the framework in Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). Based upon that evaluation, management concluded that the Company’s internal control over financial reporting was not effective as of September 30, 2021, due to the material weaknesses in internal control over financial reporting, described below.

[0001410578-21-000447:item_9a:7]
Based on this assessment, the Company’s management concluded that an effective risk assessment process responsive to changes in the operating environment and business at a reporting unit in the Company’s Aerospace & Defense (A&D) segment did not occur, resulting in the ineffective design and implementation of certain controls to reduce the risks of material misstatements at that reporting unit.  Specifically, the design of certain controls over revenue recognition, and the accumulation of inventory costs and the determination of inventory carrying values were ineffective. The control deficiencies resulted in immaterial misstatements of net sales and cost of sales. The control deficiencies described above created a reasonable possibility that a material misstatement to the consolidated financial statements would not be prevented or detected on a timely basis. Therefore, we concluded that the deficiencies represent material weaknesses in the Company’s internal control over financial reporting and that our internal control over financial reporting was not effective as of September 30, 2021.

[0001410578-21-000447:item_9a:8]
The Company acquired Altanova and the assets of Phenix (together, the “Acquired Businesses”) during the year ended September 30, 2021, and management excluded from its assessment of the effectiveness of the Company’s internal control over financial reporting as of September 30, 2021, the Acquired Businesses’ internal control over financial reporting associated with total assets representing 12.2 percent of consolidated assets, and total sales representing 0.6 percent of consolidated net sales, included in the consolidated financial statements of the Company as of and for the year ended September 30, 2021.

[0001410578-21-000447:item_9a:9]
The Company’s independent registered public accounting firm, KPMG LLP, who audited the consolidated financial statements included in this Annual Report on Form 10-K issued an adverse opinion on the effectiveness of the Company’s internal control over financial reporting. KPMG LLP’s report appears on page F-33 of this Annual Report on Form 10-K.

[0001410578-21-000447:item_9a:10]
Remediation

[0001410578-21-000447:item_9a:11]
The Company is in the process of remediating the material weaknesses and is taking the following actions:

[0001410578-21-000447:item_9a:12]
27

[0001410578-21-000447:item_9a:13]
|  | a) | Dedicating additional resources to improve the Company’s risk assessment process to ensure that it is comprehensive, continuous, and designed to identify and assess changes that could significantly impact internal control over financial reporting. |

[0001410578-21-000447:item_9a:14]
|  | b) | Improving Company policies, procedures and system and process controls related to inventory costing and revenue recognition. |

[0001410578-21-000447:item_9a:15]
|  | c) | Providing additional risk assessment training to the A&D segment finance department on the applicable financial reporting requirements and related accounting policies. |

[0001410578-21-000447:item_9a:16]
We believe these measures will remediate the control deficiencies and strengthen internal control over financial reporting. The operating effectiveness of the revised and new controls are currently being assessed and the material weaknesses will be considered remediated only after the applicable controls have operated effectively for a sufficient period of time.

[0001410578-21-000447:item_9a:17]
Changes in Internal Control Over Financial Reporting

[0001410578-21-000447:item_9a:18]
No changes in the Company’s internal control over financial reporting (as defined in Rule 13a-15(f) under the Exchange Act) occurred during the fiscal quarter ended September 30, 2021, that have materially affected, or are reasonably likely to materially affect, the Company’s internal control over financial reporting.
