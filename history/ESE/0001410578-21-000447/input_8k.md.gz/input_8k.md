# ESE 8-K — 0001104659-21-141206 filed 2021-11-18

## item codes, every 8-K on or before 2021-11-29

- 2021-11-24 0001104659-21-143568 — 4.01, 9.01
- 2021-11-23 0001104659-21-142871 — 5.02, 8.01
- 2021-11-18 0001104659-21-141206 — 2.02, 7.01, 9.01
- 2021-08-09 0001104659-21-102150 — 2.02, 7.01, 9.01
- 2021-05-04 0001104659-21-060985 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2021-04-05 0001104659-21-046581 — 5.02, 9.01
- 2021-02-08 0001104659-21-013712 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2020-12-09 0001104659-20-133674 — 5.02, 9.01
- 2020-12-07 0001104659-20-132861 — 5.02, 7.01, 9.01
- 2020-11-19 0001104659-20-127352 — 2.02, 5.02, 7.01, 9.01
- 2020-08-10 0001104659-20-092734 — 2.02, 7.01, 9.01
- 2020-05-06 0001104659-20-057442 — 2.02, 7.01, 8.01, 9.01
- 2020-02-04 0001104659-20-010640 — 2.02, 5.07, 7.01, 9.01
- 2020-01-07 0001104659-20-001789 — 2.01, 9.01
- 2019-11-19 0001104659-19-065437 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2019-11-18 0001104659-19-065096 — 1.01, 2.02, 7.01, 9.01
- 2019-09-30 0001144204-19-046523 — 1.01, 1.02, 2.03, 9.01
- 2019-08-08 0001144204-19-038567 — 2.02, 7.01, 9.01
- 2019-05-07 0001144204-19-024241 — 2.02, 5.02, 7.01, 9.01
- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2021-11-29

- none on or before 2021-11-29

## item 2.02 — earnings release, exhibit 99.1

[0001104659-21-141206:8k_2_02:1]
EX-99.1
2
tm2133267d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-21-141206:8k_2_02:2]
Exhibit 99.1

[0001104659-21-141206:8k_2_02:3]
| NEWS FROM |  |

[0001104659-21-141206:8k_2_02:4]
For more information contact:

[0001104659-21-141206:8k_2_02:5]
Kate Lowrey

[0001104659-21-141206:8k_2_02:6]
Director, Investor Relations

[0001104659-21-141206:8k_2_02:7]
ESCO Technologies Inc.

[0001104659-21-141206:8k_2_02:8]
(314) 213-7277

[0001104659-21-141206:8k_2_02:9]
ESCO ANNOUNCES FOURTH QUARTER AND FISCAL
2021 RESULTS

[0001104659-21-141206:8k_2_02:10]
- Q4 GAAP EPS $0.78 and Adjusted EPS $0.85
-

[0001104659-21-141206:8k_2_02:11]
- $259 Million in Q4 Orders - Book-to-bill
of 1.26x -

[0001104659-21-141206:8k_2_02:12]
-Record Cash Flow from Operations of $123
million in FY 2021 –

[0001104659-21-141206:8k_2_02:13]
ST. LOUIS, November 18, 2021 – ESCO Technologies
Inc. (NYSE: ESE) (ESCO, or the Company) today reported its operating results for the fourth quarter (Q4 2021) and fiscal year (2021) ended
September 30, 2021.

[0001104659-21-141206:8k_2_02:14]
Vic Richey, Chairman and Chief Executive Officer, commented, “Our
committed team worked diligently throughout 2021 to manage through the continuing economic impacts associated with COVID-19. 2021 presented
challenges related to global supply chain management, labor shortages, and a delayed return to normal travel patterns. Despite these challenges,
our focus on cost structure optimization, cash flow management, and program execution enabled us to deliver solid results across each
of our three business segments. The quarter was highlighted by revenue growth in USG and Test, strong cash flow generation, a double-digit
increase in entered orders, and record ending backlog.

[0001104659-21-141206:8k_2_02:15]
“Our strong balance sheet and substantial liquidity enabled us
to fund capital investments, new product development, and acquisitions during 2021. We continued to expand our product portfolio through
the launch of a number of new products and two new acquisitions, the Altanova Group (Altanova) and the assets of Phenix Technologies (Phenix),
which broaden our product offerings and geographic footprint.”

[0001104659-21-141206:8k_2_02:16]
Earnings Summary

[0001104659-21-141206:8k_2_02:17]
Q4 2021 GAAP EPS was $0.78 per share (GAAP net earnings of $20.4 million)
and included the net earnings impact of the Q4 2021 Discrete Items described below. Excluding the net earnings impact of the Discrete
Items, Q4 2021 Adjusted EPS was $0.85 per share.

[0001104659-21-141206:8k_2_02:18]
2021 GAAP EPS was $2.42 per share (GAAP net earnings
of $63.5 million) and included the net earnings impact of the 2021 Discrete Items described below. Excluding the net earnings impact of
the Discrete Items, 2021 Adjusted EPS was $2.59 per share.

[0001104659-21-141206:8k_2_02:19]
Q4 2020 GAAP EPS from Continuing Operations was ($0.93)
per share with a GAAP net loss from Continuing Operations of ($24.4) million, and included the net earnings impact of the Q4 2020 Discrete
Items described below. Excluding the net earnings impact of the Discrete Items, Q4 2020 Adjusted EPS from Continuing Operations was $0.80
per share.

[0001104659-21-141206:8k_2_02:20]
2020 GAAP EPS from Continuing Operations was $0.88
per share with GAAP net earnings from Continuing Operations of $22.9 million, and included the net earnings impact of the 2020 Discrete
Items described below. Excluding the net earnings impact of the Discrete Items, 2020 Adjusted EPS from Continuing Operations was $2.67
per share.

[0001104659-21-141206:8k_2_02:21]
Discrete Items

[0001104659-21-141206:8k_2_02:22]
The financial results presented include certain non-GAAP
financial measures such as Adjusted SG&A, EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS, as defined within the “Non-GAAP
Financial Measures” described below. Any non-GAAP financial measures presented are reconciled to their respective GAAP equivalents.
Management believes these non-GAAP financial measures are useful in assessing the ongoing operational profitability of the Company’s
business segments, and therefore, allow shareholders better visibility into the Company’s underlying operations. See “Non-GAAP
Financial Measures” described below.

[0001104659-21-141206:8k_2_02:23]
During Q4 2021, the Company incurred $1.8 million
($0.07 per share) of after-tax charges mainly consisting of purchase accounting adjustments related to the Phenix and Altanova acquisitions
($0.03 per share), acquisition costs at Corporate ($0.02 per share), and restructuring costs primarily within the USG segment ($0.02 per
share). These costs are excluded from the calculation of Q4 2021 Adjusted EBITDA and Adjusted EPS.

[0001104659-21-141206:8k_2_02:24]
In 2021, the Company incurred $4.6 million ($0.17
per share) of after-tax charges mainly consisting of one-time compensation and acquisition costs at Corporate ($0.12 per share), restructuring
costs primarily within the USG segment ($0.08 per share), and purchase accounting adjustments related to the Phenix and Altanova acquisitions
($0.03 per share), partially offset by the final settlement from the sale of the Doble Watertown facility ($0.06 gain per share). These
costs are excluded from the calculation of 2021 Adjusted EBITDA and Adjusted EPS.

[0001104659-21-141206:8k_2_02:25]
During Q4 2020, the Company incurred $40.6 million
($1.55 per share) of after-tax charges related to the pension plan termination and $4.8 million ($0.18 per share) of after-tax charges
primarily within the USG segment due to facility consolidation, asset impairment, and severance. These costs are excluded from the calculation
of Q4 2020 Adjusted EBITDA and Adjusted EPS.

[0001104659-21-141206:8k_2_02:26]
In 2020, the Company incurred $40.6 million ($1.55
per share) of after-tax charges related to the pension plan termination and $6.3 million ($0.24 per share) of after-tax charges primarily
within the USG segment related to facility consolidation, asset impairment, severance, and incremental costs associated with COVID-19.
These costs are excluded from the calculation of 2020 Adjusted EBITDA and Adjusted EPS.

[0001104659-21-141206:8k_2_02:27]
Operating Highlights – Q4 & 2021

[0001104659-21-141206:8k_2_02:28]
|  | · | Q4 sales of $205 million were in line with Q4 2020. Excluding the impact of Altanova and Phenix, sales declined $5 million (2 percent) in the quarter. Full year 2021 sales decreased $15 million (2 percent) to $715 million, compared to $730 million in 2020, primarily related to softness in the commercial aerospace market. |

[0001104659-21-141206:8k_2_02:29]
|  | · | Gross margin increased to 37.6 percent in Q4 2021 from 36.4 percent in Q4 2020, driven by higher sales volume in USG and the implementation of cost reduction actions across the company. Full year 2021 gross margin increased to 37.8 percent from 37.3 percent in 2020. |

[0001104659-21-141206:8k_2_02:30]
|  | · | G&A expenses increased $4.4 million in Q4 2021 compared to Q4 2020. This was primarily due to the acquisition of two new companies during the quarter, the moderate return of travel and other expenses, and the Q4 Discrete Items previously described. Full year SG&A expenses increased by $8.0 million compared to 2020 due to the above and the full year Discrete Items previously described, partially offset by lower spending (headcount, travel and pension) in the first half of the year. |

[0001104659-21-141206:8k_2_02:31]
|  | · | Interest expense decreased $0.7 million in Q4 2021 and $4.5 million in 2021 compared to the prior year periods due to lower debt outstanding and lower average interest rates. |

[0001104659-21-141206:8k_2_02:32]
|  | · | The Q4 2021 effective income tax rate of 18.7 percent was favorably impacted by state tax provision adjustments. |

[0001104659-21-141206:8k_2_02:33]
|  | · | Q4 2021 Entered orders were $259 million (book-to-bill of 1.26x). Full year 2021 entered orders were $796 million (book-to-bill of 1.11x). Ending backlog increased $81 million (16 percent) in 2021 to $592 million, with ending backlog increasing for the quarter and year in all three business segments. |

[0001104659-21-141206:8k_2_02:34]
|  | · | Net cash provided by operating activities was $48 million in Q4 and a record $123 million for the full year, resulting from solid earnings and favorable working capital management. Net debt (total borrowings less cash on hand) was $98 million with a 1.03x leverage ratio at September 30, 2021. |

[0001104659-21-141206:8k_2_02:35]
Segment Performance

[0001104659-21-141206:8k_2_02:36]
A&D

[0001104659-21-141206:8k_2_02:37]
|  | · | Sales decreased $15 million (16 percent) to $80 million in Q4 2021 from $95 million in Q4 2020, due to lower commercial aerospace and Navy sales. The impact of COVID-19 on sales demand in commercial aerospace continued throughout the year, but strong Q4 orders and ending backlog are encouraging signs for 2022. Q4 2020 was an exceptionally strong quarter for Navy sales ($27 million or 34 percent of Navy revenue in 2020). Full year 2021 Navy sales grew by 4 percent to $84 million and were spread more evenly over the course of the year. |

[0001104659-21-141206:8k_2_02:38]
|  | · | Adjusted EBIT decreased $4.0 million in Q4 2021 to $14.7 million from $18.7 million in Q4 2020, with an 18 percent Adjusted EBIT margin, due to the continued softness in the commercial aerospace market and the lower Navy sales in the quarter. |

[0001104659-21-141206:8k_2_02:39]
|  | · | Entered Orders were $89 million in Q4 2021 (book-to-bill of 1.11x) compared to $69 million in Q4 2020. It was the second consecutive quarter of solid order growth in aerospace, and overall A&D orders increased 28 percent in the quarter compared to the prior year and resulted in ending backlog of $367 million. |

[0001104659-21-141206:8k_2_02:40]
USG

[0001104659-21-141206:8k_2_02:41]
|  | · | Sales increased $8 million (16 percent) to $61 million in Q4 2021 from $53 million in Q4 2020. Doble’s sales increased $6 million (14 percent), driven by growth from utility customers ($2 million) and the initial impact of acquisitions made during the quarter ($4 million). NRG sales increased $2 million (29 percent) in the quarter and $8 million (29 percent) for the full year due to new product introductions and renewed strength in the wind and solar markets. |

[0001104659-21-141206:8k_2_02:42]
|  | · | Adjusted EBIT increased $5.0 million in Q4 2021 to $14.9 million from $9.9 million in Q4 2020, with a 24 percent EBIT margin versus 19 percent in the prior year. The increase in profitability was driven by leverage on higher revenue, favorable mix on instrument sales and contract renewals, as well as continued cost containment. |

[0001104659-21-141206:8k_2_02:43]
|  | · | Q4 Entered Orders were $67 million (excluding $29 million of acquired backlog in the quarter) compared to $50 million in Q4 2020. The $17 million (34 percent) increase in Q4 orders combined with the acquired backlog resulted in record ending backlog of $92 million. |

[0001104659-21-141206:8k_2_02:44]
Test

[0001104659-21-141206:8k_2_02:45]
|  | · | Sales increased $6 million (11 percent) to $64 million in Q4 2021 from $58 million in Q4 2020, due to higher electromagnetic compatibility (EMC) chamber projects in Asia and electromagnetic pulse (EMP) filter sales in the Americas. |

[0001104659-21-141206:8k_2_02:46]
|  | · | EBIT increased $0.2 million in Q4 2021 to $9.9 million from $9.7 million in Q4 2020, with a 15 percent EBIT margin. Higher earnings related to volume were partially offset by higher material prices (primarily steel and foam which is utilized in absorber manufacturing). |

[0001104659-21-141206:8k_2_02:47]
|  | · | Entered Orders were a record $74 million in Q4 2021 (book-to-bill of 1.15x) compared to $54 million in Q4 2020. For the year, Test orders were also a record $215 million (book-to-bill of 1.09x), an increase of $40 million (23 percent) over the prior year and resulted in record ending backlog of $133 million. The order growth came from all end-markets and regions, with significant strength in EMC test chambers and EMP filter orders. |

[0001104659-21-141206:8k_2_02:48]
Summary Commentary

[0001104659-21-141206:8k_2_02:49]
In Q4 2021 we continued to see positive signs of
recovery across our end-markets most affected by COVID. Entered orders were up $86 million (50 percent) over the prior Q4 to $259 million,
led by growth in our aerospace, electric utility and Test end-markets. With record ending backlog, we are entering 2022 with confidence
in the long-term growth potential of the end-markets across our portfolio.

[0001104659-21-141206:8k_2_02:50]
Q4 sales were flat to the prior year, with solid
organic growth in Test and renewables and the initial impact from Altanova and Phenix, offset by lower commercial aerospace and Navy sales.
From a margin perspective, our Q4 Adjusted EBITDA margin increased to 19.5 percent from 18.9 percent in the prior year, primarily driven
by the rebound to pre-pandemic margins in USG related to their revenue strength in the quarter.

[0001104659-21-141206:8k_2_02:51]
Driven by our continuing focus on working capital
management and cash conversion, our cash flow from operations increased $15 million (13 percent) over the prior year. Including the impacts
of recent acquisitions, our leverage ratio of 1.03x and $587 million in liquidity at year-end, leave us well-positioned to continue to
fund capital investments, new product development, and acquisition opportunities.

[0001104659-21-141206:8k_2_02:52]
On November 4, 2021, the Company acquired Networks
Electronic Company, LLC (NEco). NEco provides miniature electro-explosive components and subsystems supporting mission, flight, and life-critical
applications to the aerospace and defense end-markets.  Their products are used in aircraft and missiles to perform a variety of
functions including aircrew escape, stores release, fire suppression, and device ignition and detonation.  NEco is based in Chatsworth,
CA and will become part of the A&D segment.  Their 2022 sales are expected to be approximately $7 million with operating margins
in line with the A&D segment. NEco is a nice extension of our A&D product offerings and we continue to evaluate a solid pipeline
of M&A opportunities with the intent to further expand our portfolio.

[0001104659-21-141206:8k_2_02:53]
Vic Richey, Chairman and Chief Executive Officer, commented, “I
want to thank our entire team for their continuing hard work, as we have successfully navigated numerous challenges over the past two
years. Despite significant headwinds, our revenue, Adjusted earnings, and entered orders increased sequentially each quarter throughout
the year. We delivered solid results in 2021 and have positioned the company for future success. It was truly a team effort, and I am
confident that our hard work has prepared us to deliver profitable growth as our end-markets continue to recover.”

[0001104659-21-141206:8k_2_02:54]
Dividend Payment

[0001104659-21-141206:8k_2_02:55]
The next quarterly cash dividend
of $0.08 per share will be paid on January 19, 2022 to stockholders of record on January 4, 2022.

[0001104659-21-141206:8k_2_02:56]
2022 Annual Meeting

[0001104659-21-141206:8k_2_02:57]
The 2022 Annual Meeting of the Company’s
Shareholders will be held on February 3, 2022.

[0001104659-21-141206:8k_2_02:58]
Business Outlook – 2022

[0001104659-21-141206:8k_2_02:59]
Management expects meaningful growth in sales, Adjusted EBIT, and Adjusted
EBITDA across each of the Company’s business segments in 2022. These projections exclude the impact of any additional M&A contributions
throughout the year.

[0001104659-21-141206:8k_2_02:60]
Management’s expectations for growth in 2022 compared to 2021:

[0001104659-21-141206:8k_2_02:61]
|  | · | Net sales are expected to be in the range of $810 to $ 830 million (an increase of 13 to 16 percent) on a consolidated basis, with A&D growing 10 to 12 percent, USG growing 28 to 32 percent (3 to 5 percent organically) and Test growing 3 to 5 percent; |

[0001104659-21-141206:8k_2_02:62]
|  | · | Adjusted EBIT is expected to increase approximately 20 to 25 percent with Adjusted EBIT margins increasing to 13.0 to 13.5 percent of sales; |

[0001104659-21-141206:8k_2_02:63]
|  | · | Adjusted EBITDA is expected to increase approximately 20 to 25 percent with Adjusted EBITDA margins increasing to 19.0 to 19.5 percent of sales; |

[0001104659-21-141206:8k_2_02:64]
|  | · | Interest expense is expected to increase to approximately $4 million in 2022, excluding the impact of any future acquisitions; |

[0001104659-21-141206:8k_2_02:65]
|  | · | Non-cash depreciation and amortization of intangible assets is expected to increase approximately $6 million, or $0.18 per share after-tax, related to previous acquisitions and capital spending. |

[0001104659-21-141206:8k_2_02:66]
|  | · | The effective income tax rate is expected to increase to 23 to 24 percent in 2022. |

[0001104659-21-141206:8k_2_02:67]
|  | · | Management projects 2022 Adjusted EPS to be in the range of $3.10 to $3.20 per share (compared to 2021 Adjusted EPS of $2.59 per share). This increase reflects meaningful sales and earnings growth, partially offset by the additional depreciation and amortization charges and incremental tax expense as noted above. |

[0001104659-21-141206:8k_2_02:68]
|  | · | Given the quarterly variability in the recovery of the aerospace and electric utility end-markets, we expect flat to slightly down EPS in Q1 2022 compared to the prior year. Consistent with prior years, Management expects 2022 revenues and Adjusted EPS to be more back half weighted resulting in the second half growth being stronger than the first half. |

[0001104659-21-141206:8k_2_02:69]
Conference Call

[0001104659-21-141206:8k_2_02:70]
The Company will host a conference call today, November 18, at 4:00
p.m. Central Time, to discuss the Company’s Q4 and 2021 results. A live audio webcast will be available on the Company’s website
at www.escotechnologies.com. Please access the website at least 15 minutes prior to the call to register, download and install any necessary
audio software. A replay of the conference call will be available on the Company’s website noted above or by phone (dial 1-855-859-2056
and enter the pass code 5194808).

[0001104659-21-141206:8k_2_02:71]
Forward-Looking Statements

[0001104659-21-141206:8k_2_02:72]
Statements in this press release regarding the timing
and magnitude of recovery in the Company’s end markets, the continuing impacts of COVID-19 on the Company’s results, sales,
Adjusted SG&A, Adjusted EBIT, Adjusted EBITDA, Adjusted EPS, cash flow, results of cost reduction efforts, margins, growth, the financial
success of the Company, the strength of its end markets, the outlook for the A&D, Test and USG segments, the ability to increase shareholder
value, the timing and success of acquisition efforts, internal investments in new products and solutions, the long-term success of the
Company, and any other statements which are not strictly historical are “forward-looking” statements within the meaning of
the safe harbor provisions of the federal securities laws.

[0001104659-21-141206:8k_2_02:73]
Investors are cautioned that such statements are
only predictions and speak only as of the date of this release, and the Company undertakes no duty to update them except as may be required
by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the
forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment including
but not limited to those described in Item 1A, “Risk Factors”, of the Company’s Annual Report on Form 10-K for the fiscal
year ended September 30, 2020; the availability and acceptance of viable COVID-19 vaccines by enough of the U.S. and world’s population
to curtail the pandemic; the continuing impact of the COVID-19 pandemic and the effects of known or unknown COVID-19 variants including
labor shortages, facility closures, shelter in place policies or quarantines, material shortages, transportation delays, termination or
delays of Company contracts, and the inability of our suppliers or customers to perform; the impacts of Executive Order 14042 and other
vaccine mandates on our employees and businesses; the impacts of natural disasters on the Company’s operations and those of the
Company’s customers and suppliers; the timing and content of future contract awards or customer orders; the appropriation, allocation
and availability of Government funds; the termination for convenience of Government and other customer contracts or orders; weakening
of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies;
competition; intellectual property rights; technical difficulties; the success of the Company’s acquisition efforts; delivery delays
or defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability
of certain raw materials; labor disputes; changes in U.S. tax laws and regulations; other changes in laws and regulations including but
not limited to changes in accounting standards and foreign taxation; changes in interest rates; costs relating to environmental matters
arising from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration;
and the integration of recently acquired businesses.

[0001104659-21-141206:8k_2_02:74]
Non-GAAP Financial Measures

[0001104659-21-141206:8k_2_02:75]
The financial measures Adjusted SG&A, EBIT, Adjusted EBIT, EBITDA,
Adjusted EBITDA and Adjusted EPS are presented in this press release. The Company defines “Adjusted SG&A” as the corresponding
GAAP amounts excluding the net impact of the items described above in Discrete Items and reconciled in the attached Reconciliation of
Non-GAAP Financial Measures, “EBIT” as earnings before interest and taxes, “EBITDA” as earnings before interest,
taxes, depreciation and amortization, “Adjusted EBIT” and “Adjusted EBITDA” as excluding the net impact of the
items described above in Discrete Items, and “Adjusted EPS” as GAAP earnings per share (EPS) excluding the net impact of the
items described above which were ($0.07) per share in Q4 2021.

[0001104659-21-141206:8k_2_02:76]
Adjusted SG&A, EBIT, Adjusted EBIT, EBITDA, Adjusted
EBITDA and Adjusted EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management
believes that Adjusted SG&A is useful in assessing the operational profitability of the Company as it excludes certain one-time charges.
Management believes EBIT, Adjusted EBIT, EBITDA and Adjusted EBITDA are useful in assessing the operational profitability of the Company’s
business segments because they exclude interest, taxes, depreciation and amortization, which are generally accounted for across the entire
Company on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company
as well as incentive compensation. The presentation of Adjusted SG&A, EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS
provides important supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP
financial measures to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of
performance determined in accordance with GAAP.

[0001104659-21-141206:8k_2_02:77]
ESCO, headquartered in St. Louis, Missouri: Manufactures
highly-engineered filtration and fluid control products for the aviation, Navy, space and process markets worldwide, as well as composite-based
products and solutions for Navy, defense and industrial customers; is the industry leader in RF shielding and EMC test products; and provides
diagnostic instruments, software and services for the benefit of industrial power users and the electric utility and renewable energy
industries. Further information regarding ESCO and its subsidiaries is available on the Company’s website at www.escotechnologies.com.

[0001104659-21-141206:8k_2_02:78]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-21-141206:8k_2_02:79]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-21-141206:8k_2_02:80]
(Dollars in thousands, except per share amounts)

[0001104659-21-141206:8k_2_02:81]
|  |  |  | Three Months Ended September 30, 2021 |  |  | Three Months Ended September 30, 2020 |  |
| Net Sales |  |  | $ | 205,478 |  |  |  | 205,586 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |  |
| Cost of sales |  |  |  | 128,260 |  |  |  | 130,656 |  |
| Selling, general and administrative expenses |  |  |  | 44,906 |  |  |  | 40,467 |  |
| Amortization of intangible assets |  |  |  | 6,100 |  |  |  | 5,247 |  |
| Interest expense |  |  |  | 802 |  |  |  | 1,466 |  |
| Other expenses (income), net |  |  |  | 371 |  |  |  | 47,548 |  |
| Total costs and expenses |  |  |  | 180,439 |  |  |  | 225,384 |  |
| Earnings before income taxes |  |  |  | 25,039 |  |  |  | (19,798 | ) |
| Income tax expense |  |  |  | 4,674 |  |  |  | 4,579 |  |
| Earnings (loss) from continuing operations |  |  |  | 20,365 |  |  |  | (24,377 | ) |
| Earnings from discontinued operations, net of tax (benefit) |  |  |  |  |  |  |  |  |  |
| expense of $(502) |  |  |  | - |  |  |  | 502 |  |
| Net earnings |  |  | $ | 20,365 |  |  |  | (23,875 | ) |
| Diluted EPS: |  |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  |  |  |  |  |  |  |  |  |
| Continuing operations |  |  | $ | 0.78 |  |  |  | (0.93 | ) |
| Discontinued operations |  |  |  | 0.00 |  |  |  | 0.02 |  |
| Net earnings |  |  | $ | 0.78 |  |  |  | (0.91 | ) |
| Diluted - As Adjusted Basis |  |  |  |  |  |  |  |  |  |
| Continuing operations |  |  | $ | 0.85 | (1) |  |  | 0.80 | (2) |
| Diluted average common shares O/S: |  |  |  | 26,232 |  |  |  | 26,163 |  |

[0001104659-21-141206:8k_2_02:82]
|  | (1) | Q4 2021 Adjusted EPS excludes $0.07 per share of after-tax charges mainly consisting of purchase accounting adjustments related to the Phenix & Altanova acquisitions, acquisition costs at Corporate, and restructuring costs primarily with the USG segment. |

[0001104659-21-141206:8k_2_02:83]
|  | (2) | Q4 2020 Adjusted EPS excludes $1.55 per share of after-tax charges related to the pension plan termination and $0.18 per share of after-tax charges incurred primarily within the USG segment due to facility consolidation, asset impairment and severance. |

[0001104659-21-141206:8k_2_02:84]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-21-141206:8k_2_02:85]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-21-141206:8k_2_02:86]
(Dollars in thousands, except per share amounts)

[0001104659-21-141206:8k_2_02:87]
|  |  | Year Ended September 30, 2021 |  |  | Year Ended September 30, 2020 |  |
| Net Sales |  | $ | 715,440 |  |  |  | 730,471 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 445,045 |  |  |  | 458,311 |  |
| Selling, general and administrative expenses |  |  | 167,534 |  |  |  | 159,490 |  |
| Amortization of intangible assets |  |  | 20,829 |  |  |  | 21,812 |  |
| Interest expense |  |  | 2,255 |  |  |  | 6,730 |  |
| Other (income) expenses, net |  |  | (894 | ) |  |  | 47,722 |  |
| Total costs and expenses |  |  | 634,769 |  |  |  | 694,065 |  |
| Earnings before income taxes |  |  | 80,671 |  |  |  | 36,406 |  |
| Income tax expense |  |  | 17,175 |  |  |  | 13,510 |  |
| Earnings from continuing operations |  |  | 63,496 |  |  |  | 22,896 |  |
| (Loss) earnings from discontinued operations, net of tax |  |  |  |  |  |  |  |  |
| expense of $269 |  |  | - |  |  |  | (601 | ) |
| Gain on sale of discontinued operations, net of |  |  |  |  |  |  |  |  |
| tax expense of $23,232 |  |  | - |  |  |  | 77,116 |  |
| Earnings from discontinued operations |  |  | - |  |  |  | 76,515 |  |
| Net earnings |  | $ | 63,496 |  |  |  | 99,411 |  |
| Diluted EPS: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 2.42 |  |  |  | 0.88 |  |
| Discontinued operations |  |  | 0.00 |  |  |  | 2.93 |  |
| Net earnings |  | $ | 2.42 |  |  |  | 3.81 |  |
| Diluted - As Adjusted Basis |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 2.59 | (1) |  |  | 2.67 | (2) |
| Diluted average common shares O/S: |  |  | 26,225 |  |  |  | 26,135 |  |

[0001104659-21-141206:8k_2_02:88]
|  | (1) | FY 21 Adjusted EPS excludes $0.17 per share of after-tax charges mainly consisting of one-time compensation and acquisition costs at Corporate, restructuring costs primarily within the USG segment, and purchase accounting adjustments related to the Phenix & Altanova acquisitions, partially offset by the final settlement from the sale of the Doble Watertown facility. |

[0001104659-21-141206:8k_2_02:89]
|  | (2) | FY 20 Adjusted EPS excludes $1.55 per share of after-tax charges related to the pension plan termination and $0.24 per share of after-tax charges primarily within the USG segment related to facility consolidation, asset impairment, severance, and incremental costs associated with COVID-19. |

[0001104659-21-141206:8k_2_02:90]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-21-141206:8k_2_02:91]
Condensed Business Segment Information (Unaudited)

[0001104659-21-141206:8k_2_02:92]
(Dollars in thousands)

[0001104659-21-141206:8k_2_02:93]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | Q4 2021 |  |  | Q4 2020 |  |  | Q4 2021 |  |  | Q4 2020 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 80,105 |  |  |  | 95,169 |  |  |  | 80,105 |  |  |  | 95,169 |  |
| USG |  |  | 61,107 |  |  |  | 52,524 |  |  |  | 61,107 |  |  |  | 52,524 |  |
| Test |  |  | 64,266 |  |  |  | 57,893 |  |  |  | 64,266 |  |  |  | 57,893 |  |
| Totals |  | $ | 205,478 |  |  |  | 205,586 |  |  |  | 205,478 |  |  |  | 205,586 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 14,557 |  |  |  | 18,218 |  |  |  | 14,657 |  |  |  | 18,738 |  |
| USG |  |  | 13,264 |  |  |  | 4,058 |  |  |  | 14,874 |  |  |  | 9,884 |  |
| Test |  |  | 9,855 |  |  |  | 9,718 |  |  |  | 9,855 |  |  |  | 9,718 |  |
| Corporate |  |  | (11,835 | ) |  |  | (50,326 | ) |  |  | (11,181 | ) |  |  | (9,718 | ) |
| Consolidated EBIT |  |  | 25,841 |  |  |  | (18,332 | ) |  |  | 28,205 |  |  |  | 28,622 |  |
| Less: Interest expense |  |  | (802 | ) |  |  | (1,466 | ) |  |  | (802 | ) |  |  | (1,466 | ) |
| Less: Income tax expense |  |  | (4,674 | ) |  |  | (4,579 | ) |  |  | (5,218 | ) |  |  | (6,104 | ) |
| Net earnings from cont ops |  | $ | 20,365 |  |  |  | (24,377 | ) |  |  | 22,185 |  |  |  | 21,052 |  |

[0001104659-21-141206:8k_2_02:94]
Note 1: Adjusted net earnings of $22.2 million in Q4 2021 exclude $1.8 million ($0.07 per share) of after-tax charges mainly consisting of purchase accounting adjustments related to the Phenix & Altanova acquisitions, acquisition costs at Corporate, and restructuring costs primarily within the USG segment.

[0001104659-21-141206:8k_2_02:95]
Note 2: Adjusted net earnings of $21.1 million in Q4 2020 exclude $40.6 million (or $1.55 per share) of after-tax charges related to the pension plan termination and $4.8 million (or $0.18 per share) of after-tax charges incurred primarily within the USG segment due to facility consolidation, asset impairment and severance.

[0001104659-21-141206:8k_2_02:96]
EBITDA Reconciliation to Net earnings from continuing operations:

[0001104659-21-141206:8k_2_02:97]
|  |  |  |  |  |  |  |  | Adjusted |  |  | Adjusted |  |
|  |  | Q4 2021 |  |  | Q4 2020 |  |  | Q4 2021 |  |  | Q4 2020 |  |
| Consolidated EBITDA |  | $ | 37,631 |  |  |  | (8,060 | ) |  |  | 39,995 |  |  |  | 38,894 |  |
| Less: Depr & Amort |  |  | (11,790 | ) |  |  | (10,272 | ) |  |  | (11,790 | ) |  |  | (10,272 | ) |
| Consolidated EBIT |  |  | 25,841 |  |  |  | (18,332 | ) |  |  | 28,205 |  |  |  | 28,622 |  |
| Less: Interest expense |  |  | (802 | ) |  |  | (1,466 | ) |  |  | (802 | ) |  |  | (1,466 | ) |
| Less: Income tax expense |  |  | (4,674 | ) |  |  | (4,579 | ) |  |  | (5,218 | ) |  |  | (6,104 | ) |
| Net earnings from cont ops |  | $ | 20,365 |  |  |  | (24,377 | ) |  |  | 22,185 |  |  |  | 21,052 |  |

[0001104659-21-141206:8k_2_02:98]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-21-141206:8k_2_02:99]
Condensed Business Segment Information (Unaudited)

[0001104659-21-141206:8k_2_02:100]
(Dollars in thousands)

[0001104659-21-141206:8k_2_02:101]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | FY 2021 |  |  | FY 2020 |  |  | FY 2021 |  |  | FY 2020 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 314,824 |  |  |  | 351,876 |  |  |  | 314,824 |  |  |  | 351,876 |  |
| USG |  |  | 202,908 |  |  |  | 191,703 |  |  |  | 202,908 |  |  |  | 191,703 |  |
| Test |  |  | 197,708 |  |  |  | 186,892 |  |  |  | 197,708 |  |  |  | 186,892 |  |
| Totals |  | $ | 715,440 |  |  |  | 730,471 |  |  |  | 715,440 |  |  |  | 730,471 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 56,536 |  |  |  | 69,876 |  |  |  | 57,021 |  |  |  | 71,281 |  |
| USG |  |  | 40,948 |  |  |  | 24,368 |  |  |  | 42,427 |  |  |  | 30,974 |  |
| Test |  |  | 27,636 |  |  |  | 27,201 |  |  |  | 27,636 |  |  |  | 27,270 |  |
| Corporate |  |  | (42,194 | ) |  |  | (78,309 | ) |  |  | (38,167 | ) |  |  | (37,510 | ) |
| Consolidated EBIT |  |  | 82,926 |  |  |  | 43,136 |  |  |  | 88,917 |  |  |  | 92,015 |  |
| Less: Interest expense |  |  | (2,255 | ) |  |  | (6,730 | ) |  |  | (2,255 | ) |  |  | (6,730 | ) |
| Less: Income tax |  |  | (17,175 | ) |  |  | (13,510 | ) |  |  | (18,553 | ) |  |  | (15,497 | ) |
| Net earnings from cont ops |  | $ | 63,496 |  |  |  | 22,896 |  |  |  | 68,109 |  |  |  | 69,788 |  |

[0001104659-21-141206:8k_2_02:102]
Note 1: Adjusted net earnings of $68.1 million in FY 21 exclude $4.6 million ($0.17 per share) of after-tax charges mainly consisting of one-time compensation and acquisition costs at Corporate, restructuring costs primarily within the USG segment, and purchase accounting adjustments related to the Phenix & Altanova acquisitions, partially offset by the final settlement from the sale of the Doble Watertown facility.

[0001104659-21-141206:8k_2_02:103]
Note 2: Adjusted net earnings of $69.8 million in FY 20 exclude $40.6 million (or $1.55 per share) of after-tax charges related to the pension plan termination and $6.3 million (or $.24 per share) of after-tax charges primarily within the USG segment related to facility consolidation, asset impairment, severance, and incremental costs associated with COVID-19.

[0001104659-21-141206:8k_2_02:104]
EBITDA Reconciliation to Net earnings from continuing operations:

[0001104659-21-141206:8k_2_02:105]
|  |  |  |  |  |  |  |  | Adjusted |  |  | Adjusted |  |
|  |  | FY 2021 |  |  | FY 2020 |  |  | FY 2021 |  |  | FY 2020 |  |
| Consolidated EBITDA |  | $ | 124,975 |  |  |  | 84,474 |  |  |  | 130,966 |  |  |  | 133,353 |  |
| Less: Depr & Amort |  |  | (42,049 | ) |  |  | (41,338 | ) |  |  | (42,049 | ) |  |  | (41,338 | ) |
| Consolidated EBIT |  |  | 82,926 |  |  |  | 43,136 |  |  |  | 88,917 |  |  |  | 92,015 |  |
| Less: Interest expense |  |  | (2,255 | ) |  |  | (6,730 | ) |  |  | (2,255 | ) |  |  | (6,730 | ) |
| Less: Income tax expense |  |  | (17,175 | ) |  |  | (13,510 | ) |  |  | (18,553 | ) |  |  | (15,497 | ) |
| Net earnings from cont ops |  | $ | 63,496 |  |  |  | 22,896 |  |  |  | 68,109 |  |  |  | 69,788 |  |

[0001104659-21-141206:8k_2_02:106]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-21-141206:8k_2_02:107]
Condensed Consolidated Balance Sheets (Unaudited)

[0001104659-21-141206:8k_2_02:108]
(Dollars in thousands)

[0001104659-21-141206:8k_2_02:109]
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
| Assets |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 56,232 |  |  |  | 52,560 |  |
| Accounts receivable, net |  |  | 146,341 |  |  |  | 144,082 |  |
| Contract assets |  |  | 93,771 |  |  |  | 94,302 |  |
| Inventories |  |  | 147,148 |  |  |  | 135,296 |  |
| Other current assets |  |  | 22,662 |  |  |  | 17,053 |  |
| Total current assets |  |  | 466,154 |  |  |  | 443,293 |  |
| Property, plant and equipment, net |  |  | 154,265 |  |  |  | 139,870 |  |
| Intangible assets, net |  |  | 409,250 |  |  |  | 346,632 |  |
| Goodwill |  |  | 504,853 |  |  |  | 408,063 |  |
| Operating lease assets |  |  | 31,846 |  |  |  | 21,390 |  |
| Other assets |  |  | 10,977 |  |  |  | 10,938 |  |
|  |  | $ | 1,577,345 |  |  |  | 1,370,186 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt & short-term borrowings |  | $ | 20,000 |  |  |  | 22,368 |  |
| Accounts payable |  |  | 56,669 |  |  |  | 50,525 |  |
| Contract liabilities |  |  | 108,814 |  |  |  | 100,551 |  |
| Other current liabilities |  |  | 92,281 |  |  |  | 82,040 |  |
| Total current liabilities |  |  | 277,764 |  |  |  | 255,484 |  |
| Deferred tax liabilities |  |  | 73,560 |  |  |  | 60,715 |  |
| Non-current operating lease liabilities |  |  | 28,032 |  |  |  | 16,785 |  |
| Other liabilities |  |  | 44,293 |  |  |  | 38,176 |  |
| Long-term debt |  |  | 134,000 |  |  |  | 40,000 |  |
| Shareholders' equity |  |  | 1,019,696 |  |  |  | 959,026 |  |
|  |  | $ | 1,577,345 |  |  |  | 1,370,186 |  |

[0001104659-21-141206:8k_2_02:110]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-21-141206:8k_2_02:111]
Consolidated Statements of Cash Flows (Unaudited)

[0001104659-21-141206:8k_2_02:112]
(Dollars in thousands)

[0001104659-21-141206:8k_2_02:113]
|  |  | Year Ended September 30, 2021 |  |  | Year Ended September 30, 2020 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 63,496 |  |  |  | 99,411 |  |
| Earnings from discontinued operations |  |  | - |  |  |  | (76,515 | ) |
| Adjustments to reconcile net earnings to net cash |  |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 42,049 |  |  |  | 41,338 |  |
| Stock compensation expense |  |  | 6,914 |  |  |  | 5,550 |  |
| Changes in assets and liabilities |  |  | 15,671 |  |  |  | 26,585 |  |
| Gain on sale of building and land |  |  | (1,950 | ) |  |  | - |  |
| Effect of deferred taxes |  |  | (3,041 | ) |  |  | (2,785 | ) |
| Pension plan termination charge |  |  | - |  |  |  | 40,600 |  |
| Pension contributions related to terminated pension plan |  |  | - |  |  |  | (25,650 | ) |
| Net cash provided by operating activities - continuing operations |  |  | 123,139 |  |  |  | 108,534 |  |
| Net cash used by operating activities - discontinued operations |  |  | - |  |  |  | (26,254 | ) |
| Net cash provided by operating activities |  |  | 123,139 |  |  |  | 82,280 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Acquisition of business, net of cash acquired |  |  | (168,903 | ) |  |  | - |  |
| Proceeds from sale of building and land |  |  | 1,950 |  |  |  | - |  |
| Capital expenditures |  |  | (26,705 | ) |  |  | (32,108 | ) |
| Additions to capitalized software |  |  | (8,783 | ) |  |  | (9,023 | ) |
| Net cash used by investing activities - continuing operations |  |  | (202,441 | ) |  |  | (41,131 | ) |
| Proceeds from sale of discontinued operations |  |  | - |  |  |  | 183,812 |  |
| Capital expenditures - discontinued operations |  |  | - |  |  |  | (1,728 | ) |
| Net cash provided by investing activities - discontinued operations |  |  | - |  |  |  | 182,084 |  |
| Net cash (used) provided by investing activities |  |  | (202,441 | ) |  |  | 140,953 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from long-term debt and short-term borrowings |  |  | 216,000 |  |  |  | 12,368 |  |
| Principal payments on long-term debt and short-term borrowings |  |  | (124,368 | ) |  |  | (235,000 | ) |
| Dividends paid |  |  | (8,336 | ) |  |  | (8,323 | ) |
| Other |  |  | (1,823 | ) |  |  | (3,125 | ) |
| Net cash provided (used) by financing activities - continuing operations |  |  | 81,473 |  |  |  | (234,080 | ) |
| Net cash used by financing activities - discontinued operations |  |  | - |  |  |  | (2,140 | ) |
| Net cash provided (used) by financing activities |  |  | 81,473 |  |  |  | (236,220 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 1,501 |  |  |  | 3,739 |  |
| Net increase (decrease) in cash and cash equivalents |  |  | 3,672 |  |  |  | (9,248 | ) |
| Cash and cash equivalents, beginning of period |  |  | 52,560 |  |  |  | 61,808 |  |
| Cash and cash equivalents, end of period |  | $ | 56,232 |  |  |  | 52,560 |  |

[0001104659-21-141206:8k_2_02:114]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-21-141206:8k_2_02:115]
Other Selected Financial Data (Unaudited)

[0001104659-21-141206:8k_2_02:116]
(Dollars in thousands)

[0001104659-21-141206:8k_2_02:117]
| Backlog And Entered Orders - Q4 2021 |  | Aerospace & Defense |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 7/1/21 |  | $ | 358,734 |  |  |  | 56,715 |  |  |  | 123,538 |  |  |  | 538,987 |  |
| Entered Orders |  |  | 88,587 |  |  |  | 96,023 |  |  |  | 73,904 |  |  |  | 258,514 |  |
| Sales |  |  | (80,105 | ) |  |  | (61,107 | ) |  |  | (64,266 | ) |  |  | (205,478 | ) |
| Ending Backlog - 9/30/21 |  | $ | 367,216 |  |  |  | 91,631 |  |  |  | 133,176 |  |  |  | 592,023 |  |

[0001104659-21-141206:8k_2_02:118]
| Backlog And Entered Orders - FY 2021 |  | Aerospace & Defense |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 10/1/20 |  | $ | 344,661 |  |  |  | 50,688 |  |  |  | 115,854 |  |  |  | 511,203 |  |
| Entered Orders |  |  | 337,379 |  |  |  | 243,851 |  |  |  | 215,030 |  |  |  | 796,260 |  |
| Sales |  |  | (314,824 | ) |  |  | (202,908 | ) |  |  | (197,708 | ) |  |  | (715,440 | ) |
| Ending Backlog - 9/30/21 |  | $ | 367,216 |  |  |  | 91,631 |  |  |  | 133,176 |  |  |  | 592,023 |  |

[0001104659-21-141206:8k_2_02:119]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-21-141206:8k_2_02:120]
Reconciliation of Non-GAAP Financial Measures (Unaudited)

[0001104659-21-141206:8k_2_02:121]
| Adjusted Basis Reconciliation - Q4 2021 |  | SG&A |  |  | EPS |  |
| GAAP Basis |  |  | 44,906 |  |  | $ | 0.78 |  |
| Adjustments |  |  |  |  |  |  |  |  |
| Purchase Accounting Adjustments - Phenix & Altanova |  |  | - |  |  | $ | 0.03 |  |
| Acquisition Costs at Corporate |  |  | (654 | ) |  | $ | 0.02 |  |
| Restructuring Costs Primarily within USG |  |  | - |  |  | $ | 0.02 |  |
| Total Adjustments |  |  | (654 | ) |  | $ | 0.07 |  |
| As Adjusted Basis |  |  | 44,252 |  |  | $ | 0.85 |  |

[0001104659-21-141206:8k_2_02:122]
The $0.07 of EPS adjustments per share consists of $2.3 million of pre-tax charges offset by $.5 million of tax benefit for a net impact of $1.8 million.

[0001104659-21-141206:8k_2_02:123]
| Adjusted Basis Reconciliation – 2021 |  | SG&A |  |  | EPS |  |
| GAAP Basis |  |  | 167,534 |  |  | $ | 2.42 |  |
| Adjustments |  |  |  |  |  |  |  |  |
| Management Transition & Acquisition Costs |  |  | (4,027 | ) |  | $ | 0.12 |  |
| Restructuring Costs Primarily within USG |  |  | - |  |  | $ | 0.08 |  |
| Purchase Accounting Adjustments - Phenix & Altanova |  |  | - |  |  | $ | 0.03 |  |
| Settlement from Doble Watertown Facility Sale |  |  | - |  |  | ($ | 0.06 | ) |
| Total Adjustments |  |  | (4,027 | ) |  | $ | 0.17 |  |
| As Adjusted Basis |  |  | 163,507 |  |  | $ | 2.59 |  |

[0001104659-21-141206:8k_2_02:124]
The $0.17
of EPS adjustments per share consists of $6.0 million of pre-tax charges offset by $1.4 million of tax benefit for a net impact of $4.6
million.

[0001104659-21-141206:8k_2_02:125]
| Adjusted Basis Reconciliation – Q4 2020 |  | SG&A |  |  | EPS |  |
| Continuing Ops – GAAP Basis |  |  | 40,467 |  |  | ($ | 0.93 | ) |
| Adjustments (defined below) |  |  | (112 | ) |  | $ | 1.73 |  |
| Continuing Ops – As Adjusted Basis |  |  | 40,355 |  |  | $ | 0.80 |  |

[0001104659-21-141206:8k_2_02:126]
Adjustments
exclude $1.55 per share of charges related to the pension plan termination and $0.18 per share of charges primarily within the USG segment
related to facility consolidation, asset impairment and severance charges.  The $1.73 of EPS adjustments per share consists
of $46.9 million of pre-tax charges offset by $1.5 million of tax benefit for a net impact of $45.4 million.

[0001104659-21-141206:8k_2_02:127]
| Adjusted Basis Reconciliation – 2020 |  | SG&A |  |  | EPS |  |
| Continuing Ops – GAAP Basis |  |  | 159,490 |  |  | $ | 0.88 |  |
| Adjustments (defined below) |  |  | (1,332 | ) |  | $ | 1.79 |  |
| Continuing Ops – As Adjusted Basis |  |  | 158,158 |  |  | $ | 2.67 |  |

[0001104659-21-141206:8k_2_02:128]
Adjustments
exclude $1.55 per share of charges related to the pension plan termination and $0.24 per share of charges primarily within the USG segment
related to facility consolidation, asset impairment, severance charges and incremental costs associated with COVID-19. The $1.79 of EPS
adjustments per share consists of $48.9 million of pre-tax charges offset by $2.0 million of tax benefit for a net impact of $46.9 million.
