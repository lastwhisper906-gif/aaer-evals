# ESE MD&A — 0001410578-21-000447


## mdna

[0001410578-21-000447:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001410578-21-000447:mdna:2]
The following discussion should be read in conjunction with the Consolidated Financial Statements and Notes thereto and refers to our results from continuing operations except where noted.

[0001410578-21-000447:mdna:3]
Selected financial information for each of our business segments is provided in the discussion below and in Note 12 to the Company’s Consolidated Financial Statements.

[0001410578-21-000447:mdna:4]
This section includes comparisons of certain 2021 financial information to the same information for 2020. Year-to-year comparisons of the 2020 financial information to the same information for 2019 are contained in Item 7 of our Form 10-K for 2020 filed with the Securities and Exchange Commission on November 30, 2020 and available through the SEC’s website at https://www.sec.gov/edgar/searchedgar/companysearch.html.

[0001410578-21-000447:mdna:5]
Introduction

[0001410578-21-000447:mdna:6]
We classify our business operations into three segments for financial reporting purposes, although for reporting certain financial information we treat Corporate activities as a separate segment. Our three operating segments during 2021 were Aerospace & Defense (A&D), Utility Solutions Group (USG), and RF Shielding and Test (Test). Our operating segments are comprised of the following primary operating subsidiaries:

[0001410578-21-000447:mdna:7]
|  | ● | A&D: PTI Technologies Inc. (PTI); VACCO Industries (VACCO); Crissair, Inc. (Crissair); Westland Technologies, Inc. (Westland); Mayday Manufacturing Co. (Mayday), Hi-Tech Metals, Inc. (Hi-Tech); and Globe Composite Solutions, LLC (Globe). |

[0001410578-21-000447:mdna:8]
|  | ● | USG: Doble Engineering Company, I.S.A. – Altanova Group S.r.l. and affiliates (Altanova) and Morgan Schaffer Ltd. (collectively, Doble); and NRG Systems, Inc. (NRG). |

[0001410578-21-000447:mdna:9]
|  | ● | Test: ETS-Lindgren Inc. (ETS-Lindgren). |

[0001410578-21-000447:mdna:10]
A&D. PTI, VACCO and Crissair primarily design and manufacture specialty filtration products, including hydraulic filter elements and fluid control devices used in commercial aerospace applications, unique filter mechanisms used in micro-propulsion devices for satellites and custom designed filters for manned aircraft and submarines. Westland and Globe design, develop and manufacture elastomeric-based signature reduction solutions for U.S. naval vessels. Mayday designs and manufactures mission-critical bushings, pins, sleeves and precision-tolerance machined components for landing gear, rotor heads, engine mounts, flight controls, and actuation systems for the aerospace and defense industries.

[0001410578-21-000447:mdna:11]
USG.  Doble develops, manufactures and delivers diagnostic testing solutions that enable electric power grid operators to assess the integrity of high-voltage power delivery equipment. NRG designs and manufactures decision support tools for the renewable energy industry, primarily wind and solar.

[0001410578-21-000447:mdna:12]
Test.  ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy.

[0001410578-21-000447:mdna:13]
We continue to operate with meaningful growth prospects in our primary served markets and with considerable financial flexibility. We continue to focus on new products that incorporate proprietary design and process technologies. Our Management is committed to delivering shareholder value through organic growth, ongoing performance improvement initiatives, and acquisitions.

[0001410578-21-000447:mdna:14]
In December 2019, we sold the businesses comprising our former Technical Packaging segment. We received net proceeds from the sale of approximately $184 million and recorded $76.5 million of after-tax net earnings on the sale in 2020. The Technical Packaging segment is reflected as discontinued operations in the Consolidated Financial Statements and related notes for all periods presented, in accordance with accounting principles generally accepted in the United States of America (GAAP). See Note 3 to the Consolidated Financial Statements for further discussion.

[0001410578-21-000447:mdna:15]
COVID-19 Trends and Uncertainties

[0001410578-21-000447:mdna:16]
The COVID-19 global pandemic has continued to create significant and unprecedented challenges, and during these highly uncertain times, our top priority remains the health and safety of our employees, customers and suppliers, thereby securing the financial well-being of the Company and supporting business continuity. Given our diverse portfolio of strong, durable businesses serving non-discretionary end-markets, the strength and resilience of our business model positions us to continue to support our long-term outlook.

[0001410578-21-000447:mdna:17]
A portion of our workforce has worked from home at times due to COVID-19, however we have not had to redesign or design new internal controls over financial reporting at this time. Depending on the duration of COVID-19, it may become necessary for us to redesign or design new internal controls over financial reporting in a future period. We do not believe such an event will have a material impact on our business.

[0001410578-21-000447:mdna:18]
The economic uncertainty, changes in the propensity for the general public to travel by air, and reductions in demand for commercial aircraft as a result of the COVID-19 pandemic have adversely impacted net sales and operating results in certain of our A&D reporting units. We continue to monitor the impacts of COVID-19 for events or changes in circumstances that indicate the carrying amount of our assets may be impaired.

[0001410578-21-000447:mdna:19]
Throughout 2021, our Navy, defense aerospace, space and Test segment end-markets have remained solid and now we are beginning to see recovery in our core markets most affected by the pandemic. We are encouraged by the growing strength of our entered orders across the commercial aerospace, electric utility and renewable energy end-markets. While there is still uncertainty as to the timing and pace of recovery in the commercial aerospace and electric utility markets, we believe we now have a clearer picture of the near term. Increased U.S. domestic passenger boardings and recent orders for new planes by major airlines are encouraging signs for 2022.

[0001410578-21-000447:mdna:20]
The effects of the COVID-19 pandemic have adversely impacted our net sales and operating results in certain of our A&D reporting units that have a higher concentration of business serving the commercial aerospace industry. For the year ended September 30, 2021, we reviewed our indefinite lived intangible assets, long-lived assets and goodwill for impairment and determined that there was no impairment. The valuation methodology we use involves estimates of discounted cash flows, which are subject to change, and if they change negatively it could result in the need to write down those assets to fair value. We will continue to monitor the impacts of COVID-19 on the fair value of assets. The defense portion of A&D, both military aerospace and navy products, is expected to remain at approximately historical business levels given its backlog coupled with the timing of expected platform deliveries.

[0001410578-21-000447:mdna:21]
See also Item 1A, “Risk Factors” in Part I above, and “Outlook” below for additional information.

[0001410578-21-000447:mdna:22]
Highlights of 2021

[0001410578-21-000447:mdna:23]
|  | ● | Diluted EPS – GAAP for 2021 was $2.42, compared to Diluted EPS – GAAP for 2020 of $3.81, which consisted of $0.88 per share from continuing operations and $2.93 from discontinued operations. |

[0001410578-21-000447:mdna:24]
|  | ● | Sales, net earnings and diluted earnings per share from continuing operations in 2021 were $715.4 million, $63.5 million and $2.42 per share, respectively, compared to sales, net earnings and diluted earnings per share from continuing operations in 2020 of $730.5 million, $22.9 million and $0.88 per share, respectively. |

[0001410578-21-000447:mdna:25]
|  | ● | Diluted EPS – Continuing Operations As Adjusted for 2021 was $2.59 and excludes $6.0 million of pretax charges (or $0.17 per share after tax) consisting of one-time compensation and acquisition related costs at Corporate ($0.12 per share); restructuring costs within the USG segment, primarily facility consolidation charges ($0.08 per share); purchase accounting adjustments related to the Phenix and Altanova acquisitions, primarily inventory step-up charges ($0.03 per share); partially offset by the final settlement from the sale of the Doble Watertown facility ($0.06 per share). Diluted EPS – Continuing Operations As Adjusted for 2020 was $2.67 and excludes the pension plan termination charge of $40.6 million (or $1.55 per share after tax) and $8.3 million of pretax charges (or $0.24 per share after tax) consisting primarily of facility consolidation charges for the Doble Manta facility (including employee severance and compensation benefits), asset impairment charges and the incremental costs associated with the COVID-19 pandemic. See “Non-GAAP Financial Measures” below. |

[0001410578-21-000447:mdna:26]
| ​ | ​ | Fiscal year ended |
| (Dollars in millions) |  | 2021 |  | 2020 |
| Diluted EPS – Continuing Operations GAAP | ​ | $ | 2.42 |  | 0.88 |
| One time compensation & acquisition related costs | ​ |  | 0.12 |  | — |
| Restructuring adjustments | ​ |  | 0.08 |  | 0.24 |
| Purchase accounting adjustments | ​ | ​ | 0.03 |  | — |
| Gain on building sale | ​ | ​ | (0.06) | ​ | — |
| Pension termination adjustment | ​ | ​ | — | ​ | 1.55 |
| Diluted EPS – Continuing Operations As Adjusted | ​ | $ | 2.59 | ​ | 2.67 |

[0001410578-21-000447:mdna:27]
|  | ● | Net cash provided by operating activities from continuing operations was $123.1 million in 2021 compared to $108.5 million in 2020. |

[0001410578-21-000447:mdna:28]
|  | ● | At September 30, 2021, cash on hand was $56.2 million and outstanding debt was $154.0 million, for a net debt position (total debt less cash on hand) of approximately $97.8 million. |

[0001410578-21-000447:mdna:29]
|  | ● | Entered orders for 2021 were $796.3 million (including $29 million of acquired backlog) resulting in a book-to-bill ratio of 1.11x. Backlog at September 30, 2021 was $592.0 million compared to $511.2 million at September 30, 2020. |

[0001410578-21-000447:mdna:30]
|  | ● | The Company declared dividends of $0.32 per share during 2021, totaling $8.3 million in dividend payments. |

[0001410578-21-000447:mdna:31]
Results of Continuing Operations

[0001410578-21-000447:mdna:32]
Net Sales

[0001410578-21-000447:mdna:33]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | Change |  |
| ​ | ​ | Fiscal year ended | ​ | 2021 |  |
| (Dollars in millions) |  | 2021 |  | 2020 |  | vs. 2020 |  |
| A&D | ​ | $ | 314.8 |  | 351.9 |  | (10.5) | % |
| USG | ​ |  | 202.9 |  | 191.7 |  | 5.8 | % |
| Test | ​ |  | 197.7 |  | 186.9 |  | 5.8 | % |
| Total | ​ | $ | 715.4 |  | 730.5 |  | (2.1) | % |

[0001410578-21-000447:mdna:34]
Net sales decreased $15.1 million, or 2.1%, to $715.4 million in 2021 from $730.5 million in 2020. The decrease in net sales in 2021 as compared to 2020 was mainly due to a $37.1 million decrease in the A&D segment, partially offset by an $11.2 million increase in the USG segment, including $4.4 million of sales from the acquisitions of Altanova and the assets of Phenix, and a $10.8 million increase in the Test segment.

[0001410578-21-000447:mdna:35]
A&D.

[0001410578-21-000447:mdna:36]
The $37.1 million, or 10.5%, decrease in net sales in 2021 as compared to 2020 was mainly due to a $16.7 million decrease in net sales at Mayday, an $11.0 million decrease in net sales at Crissair, a $9.8 million decrease in net sales at PTI all primarily driven by the impact of the COVID-19 pandemic, and a $3.7 million decrease in net sales at Westland driven by new product development challenges, partially offset by a $3.7 million increase in net sales at Globe and a $0.4 million increase in net sales at VACCO driven by an increase in navy defense shipments.

[0001410578-21-000447:mdna:37]
20

[0001410578-21-000447:mdna:38]
USG.

[0001410578-21-000447:mdna:39]
The $11.2 million, or 5.8%, increase in net sales in 2021 as compared to 2020 was mainly due to a $7.7 million increase in net sales at NRG driven by renewable energy products and $4.4 million of sales from the acquisitions of Altanova and the assets of Phenix that closed during the fourth quarter of 2021.

[0001410578-21-000447:mdna:40]
Test.

[0001410578-21-000447:mdna:41]
The $10.8 million, or 5.8%, increase in net sales in 2021 as compared to 2020 was mainly due to a $4.1 million increase in net sales from the Company’s Asian operations, $3.7 million increase in net sales from the Company’s U.S. operations and a $3.0 million increase in net sales from the Company’s European operations, primarily driven by the timing of test and measurement chamber projects.

[0001410578-21-000447:mdna:42]
Orders and Backlog

[0001410578-21-000447:mdna:43]
New orders received were $796.3 million in both 2021 and 2020. Order backlog was $592.0 million at September 30, 2021, compared to order backlog of $511.2 million at September 30, 2020. Orders are entered into backlog as firm purchase order commitments are received.

[0001410578-21-000447:mdna:44]
By operating segment, 2021 orders were $337.4 million related to A&D products, $243.9 million related to USG products (including $29 million of acquired backlog), and $215.0 million related to Test products; and 2020 orders were $420.4 million related to A&D products, $200.7 million related to USG products, and $175.3 million related to Test products.

[0001410578-21-000447:mdna:45]
Selling, General and Administrative Expenses

[0001410578-21-000447:mdna:46]
Selling, general and administrative (SG&A) expenses were $167.5 million, or 23.4% of net sales, in 2021, and $159.5 million, or 21.8% of net sales, in 2020.

[0001410578-21-000447:mdna:47]
The increase in SG&A expenses in 2021 as compared to 2020 was mainly due to an increase at Doble due to the return of discretionary spending to more normal levels, the inclusion of SG&A from the Phenix and Altanova acquisitions, compensation expenses due to the transition of key executives, and an increase in acquisition related costs at Corporate.

[0001410578-21-000447:mdna:48]
Amortization of Intangible Assets

[0001410578-21-000447:mdna:49]
Amortization of intangible assets was $20.8 million in 2021 and $21.8 million in 2020, including $14.3 million and $13.0 million of amortization of acquired intangible assets in 2021 and 2020, respectively, related to our acquisitions. The amortization of acquired intangible assets related to acquisitions is included in the Corporate segment’s results. The remaining amortization expenses relate to other identifiable intangible assets (primarily software, patents and licenses), which are included in the respective segment’s operating results. The decrease in amortization expense in 2021 as compared to 2020 was mainly due to a decrease in amortization of capitalized software.

[0001410578-21-000447:mdna:50]
Other Expenses or Income, Net

[0001410578-21-000447:mdna:51]
Other income, net, was $0.9 million in 2021, compared to other expenses, net, of $7.1 million in 2020. The principal components of other, net, in 2021 included a gain of approximately $2 million for the final settlement on the sale of the Doble Watertown, MA property, partially offset by facility consolidation charges within the USG segment (Doble Manta, Morgan Schaffer and Altanova facilities). The principal components of other expenses, net, in 2020 included approximately $8 million of pretax charges consisting primarily of facility consolidation charges for the Doble Manta facility, including employee severance and compensation benefits, and asset impairment charges. There were no other individually significant items included in other expenses, net, in 2021 or 2020.

[0001410578-21-000447:mdna:52]
Non-GAAP Financial Measures

[0001410578-21-000447:mdna:53]
The information reported herein includes the financial measures Diluted EPS – Continuing Operations As Adjusted, which we define as Diluted EPS – Continuing Operations excluding the per-share net impact of one-time compensation and acquisition related costs, facility consolidation charges within the USG segment, and purchase accounting charges related to the Company’s recent acquisitions

[0001410578-21-000447:mdna:54]
in 2021, partially offset by a gain on the final installment of the Double Watertown, MA prrperty sale; and pension plan termination charge and restructuring charges related to our facility consolidation restructuring plans in 2020; EBIT, which we define as earnings before interest and taxes; and EBIT margin, which we define as EBIT expressed as a percentage of net sales. Diluted EPS – Continuing Operations As Adjusted, EBIT on a consolidated basis, and EBIT margin on a consolidated basis are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, we believe that EBIT and EBIT margin provide investors and Management with valuable information for assessing our operating results. Management evaluates the performance of our operating segments based on EBIT and believes that EBIT is useful to investors to demonstrate the operational profitability of our business segments by excluding interest and taxes, which are generally accounted for across the entire company on a consolidated basis. EBIT is also one of the measures Management uses to determine resource allocations and incentive compensation. We believe that the presentation of EBIT, EBIT margin and Diluted EPS – Continuing Operations As Adjusted provides important supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance determined in accordance with GAAP.

[0001410578-21-000447:mdna:55]
EBIT

[0001410578-21-000447:mdna:56]
The reconciliation of EBIT to a GAAP financial measure is as follows:

[0001410578-21-000447:mdna:57]
| (Dollars in millions) |  | 2021 |  | 2020 |
| Net earnings from continuing operations | ​ | $ | 63.5 |  | 22.9 |
| Plus: Interest expense | ​ |  | 2.2 |  | 6.7 |
| Plus: Income tax expense | ​ |  | 17.2 |  | 13.5 |
| EBIT | ​ | $ | 82.9 |  | 43.1 |

[0001410578-21-000447:mdna:58]
EBIT by business segment is as follows:

[0001410578-21-000447:mdna:59]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | Change |  |
| ​ | ​ | Fiscal year ended | ​ | 2021 |  |
| (Dollars in millions) |  | 2021 |  | 2020 |  | vs. 2020 |  |
| A&D | ​ | $ | 56.5 |  | 69.9 |  | (19.2) | % |
| % of net sales | ​ |  | 17.9 | % | 19.9 | % | ​ | ​ |
| USG | ​ |  | 40.9 |  | 24.4 |  | 67.6 | % |
| % of net sales | ​ |  | 20.2 | % | 12.7 | % | ​ | ​ |
| Test | ​ |  | 27.6 |  | 27.2 |  | 1.5 | % |
| % of net sales | ​ |  | 14.0 | % | 14.6 | % | ​ | ​ |
| Corporate | ​ |  | (42.1) |  | (78.4) |  | 46.3 | % |
| Total | ​ | $ | 82.9 |  | 43.1 |  | 92.3 | % |
| % of net sales | ​ |  | 11.6 | % | 5.9 | % |  | ​ |

[0001410578-21-000447:mdna:60]
A&D

[0001410578-21-000447:mdna:61]
The $13.4 million decrease in EBIT in 2021 as compared to 2020 was primarily due to charges at Westland driven by new product development challenges, increased production costs, and product quality issues; lower sales volumes at Mayday, Crissair and PTI; partially offset by an increase in EBIT at VACCO and Globe due to the higher sales volumes mentioned above. In addition, EBIT in 2021 was negatively impacted by a $0.3 million inventory step-up charge related to the acquisition of ATM.

[0001410578-21-000447:mdna:62]
USG

[0001410578-21-000447:mdna:63]
The $16.5 million increase in EBIT in 2021 as compared to 2020 was mainly due to higher sales volumes with a favorable product mix, approximately $2 million final settlement received on the sale of the Doble Watertown property, partially offset by $2.4 million of facility consolidation charges at its Doble Manta, Morgan Schaffer and Altanova facilities, and purchase accounting charges of approximately $1.0 million related to the Phenix and Altanova acquisitions mainly consisting of inventory step-up charges. In addition, NRG’s EBIT increased $3.1 million in 2021 due to higher sales volumes as compared to the prior year.

[0001410578-21-000447:mdna:64]
Test

[0001410578-21-000447:mdna:65]
The $0.4 million increase in EBIT in 2021 as compared to 2020 was primarily due to product mix and increase in sales volumes as mentioned above partially offset by higher material prices.

[0001410578-21-000447:mdna:66]
Corporate

[0001410578-21-000447:mdna:67]
Corporate operating charges included in 2021 consolidated EBIT decreased to $42.1 million as compared to $78.4 million in 2020 mainly due to a $40.6 million pension plan termination charge in 2020 as a result of the decision to terminate and annuitize the Company’s defined benefit pension plan. Corporate’s operating charges were negatively impacted in 2021 due to higher compensation expenses due to the transition of key executives and an increase in acquisition related costs.

[0001410578-21-000447:mdna:68]
The “Reconciliation to Consolidated Totals (Corporate)” in Note 12 to the Consolidated Financial Statements represents Corporate office operating charges.

[0001410578-21-000447:mdna:69]
Interest Expense, Net

[0001410578-21-000447:mdna:70]
Interest expense, net was $2.2 million and $6.7 million in 2021 and 2020, respectively. The decrease in interest expense in 2021 was mainly due to lower average outstanding borrowings and lower average interest rates. Average outstanding borrowings were $71 million in 2021 compared to $176 million in 2020. The weighted average interest rates were 1.20% in 2021 compared to 3.20% in 2020.

[0001410578-21-000447:mdna:71]
Income Tax Expense

[0001410578-21-000447:mdna:72]
The effective tax rates from continuing operations for 2021, 2020 and 2019 were 21.3%, 37.1% and 20.8%, respectively. The 2020 effective tax rate was unfavorably impacted by a pension plan termination charge of $40.6 million which is not deductible for tax purposes, increasing the effective tax rate by 23.4%. The 2020 effective tax rate was favorably impacted by the following:  (1) an increase in the available 2019 foreign tax credit which was attributable to new information and tax planning strategies reducing the 2020 effective tax rate by 1.9%; (2) the release of a valuation allowance of $2.8 million for foreign net operating losses decreasing the effective tax rate by 7.8%; and (3) favorable 2019 state tax return to provision true-ups decreasing the effective tax rate by 1.7%.

[0001410578-21-000447:mdna:73]
The 2017 Tax Cut and Jobs Act (TCJA) made comprehensive changes to U.S. federal income tax laws by moving from a global to a modified territorial tax regime. As a result, cash repatriated to the U.S. is generally no longer subject to U.S. federal income tax. No provision is made for foreign withholding any applicable U.S. income taxes on the undistributed earnings of non-U.S. subsidiaries where these earnings are considered indefinitely invested or otherwise retained for continuing international operations. Determination of the amount of taxes that might be paid on these undistributed earnings if eventually remitted is not practicable.

[0001410578-21-000447:mdna:74]
Acquisitions and Divestiture

[0001410578-21-000447:mdna:75]
Information regarding our acquisitions and divestiture during 2021, 2020 and 2019 is set forth in Notes 2 and 3 to the Consolidated Financial Statements, which Notes are incorporated by reference herein.

[0001410578-21-000447:mdna:76]
All of our acquisitions have been accounted for using the purchase method of accounting, and accordingly, the respective purchase prices were allocated to the assets (including intangible assets) acquired and liabilities assumed based on estimated fair values at the date of acquisition. The financial results from these acquisitions have been included in our financial statements from the date of acquisition.

[0001410578-21-000447:mdna:77]
Capital Resources and Liquidity

[0001410578-21-000447:mdna:78]
Our overall financial position and liquidity are strong. Working capital from continuing operations (current assets less current liabilities) increased to $188.4 million at September 30, 2021 from $187.8 million at September 30, 2020. Inventories increased by $11.9 million during 2021 mainly due to a $14.7 million increase within the USG segment driven by the acquisitions of Altanova and the assets of Phenix. Accounts payable increased by $6.1 million during 2021 mainly due to the USG segment driven by the Altanova and Phenix acquisitions.

[0001410578-21-000447:mdna:79]
Net cash provided by operating activities from continuing operations was $123.1 million in 2021 and $108.5 million in 2020.

[0001410578-21-000447:mdna:80]
Net cash used in investing activities from continuing operations was $202.4 million in 2021 and $41.1 million in 2020. The increase in net cash used in investing activities in 2021 as compared to 2020 was mainly due to the Altanova and Phenix acquisitions totaling approximately $162 million. Capital expenditures from continuing operations were $26.7 million in 2021 and $32.1 million in 2020. The decrease in 2021as compared to 2020 was mainly due to the building improvement additions in 2020 at the new Doble headquarters facility. In addition, the Company incurred expenditures for capitalized software of $8.8 million in 2021 and $9.0 million in 2020.

[0001410578-21-000447:mdna:81]
There were no commitments outstanding that were considered material for capital expenditures at September 30, 2021, except for a commitment to purchase the NRG building for approximately $10 million which closed in the first quarter of fiscal 2022.

[0001410578-21-000447:mdna:82]
Net cash provided by financing activities from continuing operations was $81.5 million in 2021 compared to net cash used by financing activities from continuing operations of $(234.1) million in 2020, primarily due to the increase in borrowings in 2021 as a result of the Company’s recent acquisitions.

[0001410578-21-000447:mdna:83]
Bank Credit Facility

[0001410578-21-000447:mdna:84]
A description of our credit facility (the “Credit Facility”) is set forth in Note 8 to the Consolidated Financial Statements, which Note is incorporated by reference herein.

[0001410578-21-000447:mdna:85]
Cash flow from operations and borrowings under the Credit Facility is expected to provide adequate resources to meet our capital requirements and operational needs both for the next 12 months and for the foreseeable future.

[0001410578-21-000447:mdna:86]
Dividends

[0001410578-21-000447:mdna:87]
Since 2010, we have paid a regular quarterly cash dividend at an annual rate of $0.32 per share. We paid dividends totaling $8.3 million in both 2021 and 2020.

[0001410578-21-000447:mdna:88]
Off-Balance-Sheet Arrangements

[0001410578-21-000447:mdna:89]
We had no off-balance-sheet arrangements outstanding at September 30, 2021.

[0001410578-21-000447:mdna:90]
Share Repurchases

[0001410578-21-000447:mdna:91]
Information about our common stock repurchases is provided in Note 9 to the Consolidated Financial Statements.

[0001410578-21-000447:mdna:92]
Subsequent Event

[0001410578-21-000447:mdna:93]
On November 4, 2021, the Company acquired Networks Electronic Company, LLC. (NEco) which provides miniature electro-explosive devices utilized in mission-critical defense and aerospace applications. NEco is based in Chatsworth, CA and will become part of the A&D segment. Their annual sales are expected to be approximately $7 million in 2022.

[0001410578-21-000447:mdna:94]
Critical Accounting Policies

[0001410578-21-000447:mdna:95]
The preparation of financial statements in conformity with U.S. generally accepted accounting principles (GAAP) requires Management to make estimates and assumptions in certain circumstances that affect amounts reported in the Consolidated Financial Statements. In preparing these financial statements, Management has made its best estimates and judgments of certain amounts included in the Consolidated Financial Statements, giving due consideration to materiality. We do not believe there is a great likelihood that materially different amounts would be reported under different conditions or using different assumptions related to the accounting policies described below. However, application of these accounting policies involves the exercise of judgment and use of assumptions as to future uncertainties and, as a result, actual results could differ from these estimates. Our senior Management discusses the critical accounting policies described below with the Audit and Finance Committee of our Board of Directors on a periodic basis.

[0001410578-21-000447:mdna:96]
The following discussion of critical accounting policies is intended to bring to the attention of readers those accounting policies which Management believes are critical to the Consolidated Financial Statements and other financial disclosure. It is not intended to be a comprehensive list of all significant accounting policies that are more fully described in Note 1 to the Consolidated Financial Statements.

[0001410578-21-000447:mdna:97]
Revenue Recognition

[0001410578-21-000447:mdna:98]
We account for revenue in accordance with ASC Topic 606, Revenue from Contracts with Customers. The unit of account in ASC Topic 606 is a performance obligation. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration, as applicable, which are based on historical, current and forecasted information. The transaction price is allocated to each distinct performance obligation within the contract and recognized as revenue when, or as, the performance obligation is satisfied. Certain of our long-term contracts contain incentive fees that can increase the transaction price. These variable amounts generally are awarded upon achievement of certain performance metrics, program milestones or cost targets and can be based upon customer discretion. We include estimated amounts in the transaction price to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur. The estimated amounts are based on an assessment of our anticipated performance and all other information that is reasonably available to us.

[0001410578-21-000447:mdna:99]
Approximately 57% of the A&D segment’s revenue (25% of consolidated revenue) is recognized over time as the products do not have an alternative use and either we have an enforceable right to payment for costs incurred plus a reasonable margin or the inventory is owned by the customer. Selecting the method to measure progress towards completion for our contracts requires judgment and is based on the nature of the products or services to be provided.

[0001410578-21-000447:mdna:100]
The A&D segment generally uses the cost-to-cost method to measure progress on our contracts, as the rate at which costs are incurred to fulfill a contract best depicts the transfer of control to the customer. Under this method, we measure the extent of progress towards completion based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and we record revenue proportionally as costs are incurred based on an estimated profit margin.

[0001410578-21-000447:mdna:101]
The Test segment generally uses the milestone output method to measure progress on our contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. Under this method, we estimate profit as the difference between total revenue and total estimated costs at completion of a contract and recognize these revenues and costs based on milestones achieved.

[0001410578-21-000447:mdna:102]
Total contract cost estimates are based on current contract specifications and expected engineering requirements and require us to make estimates on expected profit. The estimates on profit are based on judgments we make to project the outcome of future events, and can often span more than one year and include labor productivity and availability, the complexity of the work to be performed, change orders issued by our customers, and other specialized engineering and production related activities. Our cost estimation process is based on historical results of contracts and historical actuals to original estimates, and the application of professional knowledge and experience of engineers and program managers along with finance professionals to these historical results. We review and update our estimates of costs quarterly or more frequently when circumstances significantly change, which can affect the profitability of our contracts.

[0001410578-21-000447:mdna:103]
For contracts where revenue is recognized over time, we recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. We have net revenue recognized in the current year from performance obligations satisfied in the prior year due to changes in our estimated costs to complete the related performance obligations. We recognize anticipated losses on contracts in full in the period in which the losses become known.

[0001410578-21-000447:mdna:104]
The impact of adjustments in contract estimates on our operating earnings can be reflected in either revenue or operating costs and expenses. The aggregate impact of adjustments in contract estimates increased our earnings before income tax and diluted earnings per share by $1.7 million and $0.05 per share, respectively, in 2021.

[0001410578-21-000447:mdna:105]
Income Taxes

[0001410578-21-000447:mdna:106]
We operate in numerous taxing jurisdictions and are subject to examination by various U.S. Federal, state and foreign jurisdictions for various tax periods. Our income tax positions are based on research and interpretations of the income tax laws and rulings in each of

[0001410578-21-000447:mdna:107]
the jurisdictions in which we do business. Due to the subjectivity of interpretations of laws and rulings in each jurisdiction, the differences and interplay in tax laws between those jurisdictions, as well as the inherent uncertainty in estimating the final resolution of complex tax audit matters, Management’s estimates of income tax liabilities may differ from actual payments or assessments.

[0001410578-21-000447:mdna:108]
We account for income taxes under the asset and liability method. We recognize deferred tax assets and liabilities for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. We measure deferred tax assets and liabilities using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. We may reduce deferred tax assets by a valuation allowance if it is more likely than not that some portion of the deferred tax assets will not be realized. We recognize the effect on deferred tax assets and liabilities of a change in tax rates in income in the period that includes the enactment date. We regularly review our deferred tax assets for recoverability and establish a valuation allowance when Management believes it is more likely than not such assets will not be recovered, taking into consideration historical operating results, expectations of future earnings, tax planning strategies, and the expected timing of the reversals of existing temporary differences.

[0001410578-21-000447:mdna:109]
Goodwill and Other Long-Lived Assets

[0001410578-21-000447:mdna:110]
Our Management annually reviews goodwill and other long-lived assets for impairment or whenever events or changes in circumstances indicate the carrying amount may not be recoverable. If we determine that the carrying value of the goodwill and other long-lived assets may not be recoverable, we record a permanent impairment charge for the amount by which the carrying value of the goodwill and other long-lived assets exceeds its fair value. We measure fair value based on a discounted cash flow method using a discount rate determined by Management to be commensurate with the risk inherent in each of our reporting units’ or asset groups’ current business models. Our estimates of cash flows and discount rate are subject to change due to the economic environment, including such factors as interest rates, expected market returns and volatility of markets served. We believe that Management’s estimates of future cash flows and fair value are reasonable; however, changes in estimates could result in impairment charges. At September 30, 2021 we have determined that no goodwill or other long-lived assets were impaired.

[0001410578-21-000447:mdna:111]
We amortize intangible assets with estimable useful lives over their respective estimated useful lives to their estimated residual values, and review them for impairment whenever events or changes in business circumstances indicate the carrying value of the assets may not be recoverable.

[0001410578-21-000447:mdna:112]
Other Matters

[0001410578-21-000447:mdna:113]
Quantitative and Qualitative Disclosures about Market Risk

[0001410578-21-000447:mdna:114]
Market risks relating to our operations result primarily from changes in interest rates and changes in foreign currency exchange rates. We are exposed to market risk related to changes in interest rates, and we selectively use derivative financial instruments, including forward contracts and swaps, to manage these risks. Our Canadian subsidiary Morgan Schaffer has entered into foreign exchange contracts to manage foreign currency risk, because a portion of their revenue is denominated in U.S. dollars. We report all derivative instruments on our balance sheet at fair value. For derivative instruments designated as cash flow hedges, we defer the gain or loss on the derivative in accumulated other comprehensive income until recognized in earnings with the underlying hedged item. See further discussion regarding our market risks in “Market Risk Analysis,” above.
