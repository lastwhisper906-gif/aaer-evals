# ESE note change history — 0001104659-21-062898 → 0001104659-21-102250


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-08-09):
[0001104659-21-102250:note_history:1]
The Company’s results for the three-month and nine-month periods ended June 30, 2021 are not necessarily indicative of the results for the entire 2021 fiscal year. References to the third quarters of 2021 and 2020 represent the fiscal quarters ended June 30, 2021 and 2020, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.
  (was, 2021-05-07, similarity 0.9289):
[0001104659-21-062898:note_history:1]
The Company’s results for the three-month period ended March 31, 2021 are not necessarily indicative of the results for the entire 2021 fiscal year. References to the second quarters of 2021 and 2020 represent the fiscal quarters ended March 31, 2021 and 2020, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-08-09):
[0001104659-21-102250:note_history:2]
| ​ |  | June 30, | ​ | September 30, |
| (In thousands) |  | 2021 |  | 2020 |
| Total borrowings | ​ | $ | 48,000 |  | 62,368 |
| Current portion of long-term debt and short-term borrowings | ​ |  | (20,000) |  | (22,368) |
| Total long-term debt, less current portion | ​ | $ | 28,000 |  | 40,000 |
  (was, 2021-05-07, similarity 0.9822):
[0001104659-21-062898:note_history:2]
| ​ |  | March 31, | ​ | September 30, |
| (In thousands) |  | 2021 |  | 2020 |
| Total borrowings | ​ | $ | 22,000 |  | 62,368 |
| Current portion of long-term debt and short-term borrowings | ​ |  | (20,000) |  | (22,368) |
| Total long-term debt, less current portion | ​ | $ | 2,000 |  | 40,000 |

- changed (2021-08-09):
[0001104659-21-102250:note_history:3]
At June 30, 2021, the Company had approximately $444 million available to borrow under the Credit Facility, plus the $250 million increase option, subject to lender approval, in addition to $78.4 million cash on hand. The Company classified $20.0 million as the current portion of long-term debt as of June 30, 2021, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $8.4 million at June 30, 2021.
  (was, 2021-05-07, similarity 0.9696):
[0001104659-21-062898:note_history:3]
At March 31, 2021, the Company had approximately $468 million available to borrow under the Credit Facility, plus the $250 million increase option, subject to lender approval, in addition to $45.7 million cash on hand. The Company classified $20.0 million as the current portion of long-term debt as of March 31, 2021, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $10.4 million at March 31, 2021.

- changed (2021-08-09):
[0001104659-21-102250:note_history:4]
Interest on borrowings under the Credit Facility is calculated at a spread over either the London Interbank Offered Rate (LIBOR), the New York Federal Reserve Bank Rate or the prime rate, depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The Credit Facility is secured by the unlimited guaranty of the Company’s direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of its direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 1.16% and 1.33% for the three and nine- month periods ending June 30, 2021, respectively, and 3.24% and 3.22% for the three and nine-month periods ending June 30, 2020. As of June 30, 2021, the Company was in compliance with all covenants.
  (was, 2021-05-07, similarity 0.9654):
[0001104659-21-062898:note_history:4]
Interest on borrowings under the Credit Facility is calculated at a spread over either the London Interbank Offered Rate (LIBOR), the New York Federal Reserve Bank Rate or the prime rate, depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The Credit Facility is secured by the unlimited guaranty of the Company’s direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of its direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 1.27% and 1.40% for the three and six- month periods ending March 31, 2021, respectively, and 3.24% and 3.21% for the three and six-month periods ending March 31, 2020. As of March 31, 2021, the Company was in compliance with all covenants.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-08-09):
[0001104659-21-102250:note_history:5]
| ​ |  | June 30, | ​ | September 30, |
| (In thousands) |  | 2021 |  | 2020 |
| Total borrowings | ​ | $ | 48,000 |  | 62,368 |
| Current portion of long-term debt and short-term borrowings | ​ |  | (20,000) |  | (22,368) |
| Total long-term debt, less current portion | ​ | $ | 28,000 |  | 40,000 |
  (was, 2021-05-07, similarity 0.9822):
[0001104659-21-062898:note_history:5]
| ​ |  | March 31, | ​ | September 30, |
| (In thousands) |  | 2021 |  | 2020 |
| Total borrowings | ​ | $ | 22,000 |  | 62,368 |
| Current portion of long-term debt and short-term borrowings | ​ |  | (20,000) |  | (22,368) |
| Total long-term debt, less current portion | ​ | $ | 2,000 |  | 40,000 |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-08-09):
[0001104659-21-102250:note_history:6]
| Three months ended June 30, 2021 |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total | ​ |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 34,708 | ​ | $ | 46,735 | ​ | $ | 42,063 | ​ | $ | 123,506 | ​ |
| U.S. Government | ​ |  | 50,868 | ​ | ​ | 969 | ​ | ​ | 6,051 | ​ |  | 57,888 | ​ |
| Total revenues | ​ | $ | 85,576 | ​ | $ | 47,704 | ​ | $ | 48,114 | ​ | $ | 181,394 | ​ |
| Geographic location: | ​ |  | ​ | ​ | ​ |  | ​ | ​ |  | ​ |  | ​ | ​ |
| United States | ​ | $ | 75,701 | ​ | $ | 32,111 | ​ | $ | 27,719 | ​ | $ | 135,531 | ​ |
| International | ​ |  | 9,875 | ​ | ​ | 15,593 | ​ | ​ | 20,395 | ​ |  | 45,863 | ​ |
| Total revenues | ​ | $ | 85,576 | ​ | $ | 47,704 | ​ | $ | 48,114 | ​ | $ | 181,394 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ |  | ​ | ​ |  | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 37,513 | ​ | $ | 35,242 | ​ | $ | 9,673 | ​ | $ | 82,428 | ​ |
| Over time | ​ |  | 48,063 | ​ | ​ | 12,462 | ​ | ​ | 38,441 | ​ |  | 98,966 | ​ |
| Total revenues | ​ | $ | 85,576 | ​ | $ | 47,704 | ​ | $ | 48,114 | ​ | $ | 181,394 | ​ |
  (was, 2021-05-07, similarity 0.935):
[0001104659-21-062898:note_history:6]
| Three months ended March 31, 2021 |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total | ​ |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 33,973 | ​ | $ | 38,549 | ​ | $ | 39,305 | ​ | $ | 111,827 | ​ |
| U.S. Government | ​ |  | 49,305 | ​ | ​ | 1,006 | ​ | ​ | 4,506 | ​ |  | 54,817 | ​ |
| Total revenues | ​ | $ | 83,278 | ​ | $ | 39,555 | ​ | $ | 43,811 | ​ | $ | 166,644 | ​ |
| Geographic location: | ​ |  |  | ​ | ​ |  | ​ | ​ |  | ​ |  |  | ​ |
| United States | ​ | $ | 73,037 | ​ | $ | 27,445 | ​ | $ | 22,965 | ​ | $ | 123,447 | ​ |
| International | ​ |  | 10,241 | ​ | ​ | 12,110 | ​ | ​ | 20,846 | ​ |  | 43,197 | ​ |
| Total revenues | ​ | $ | 83,278 | ​ | $ | 39,555 | ​ | $ | 43,811 | ​ | $ | 166,644 | ​ |
| Revenue recognition method: | ​ |  |  | ​ | ​ |  | ​ | ​ |  | ​ |  |  | ​ |
| Point in time | ​ | $ | 37,127 | ​ | $ | 27,563 | ​ | $ | 9,248 | ​ | $ | 73,938 | ​ |
| Over time | ​ |  | 46,151 | ​ | ​ | 11,992 | ​ | ​ | 34,563 | ​ |  | 92,706 | ​ |
| Total revenues | ​ | $ | 83,278 | ​ | $ | 39,555 | ​ | $ | 43,811 | ​ | $ | 166,644 | ​ |

- changed (2021-08-09):
[0001104659-21-102250:note_history:7]
| Nine months ended June 30, 2021 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |  |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 95,712 | ​ | $ | 139,149 | ​ | $ | 118,089 | ​ | $ | 352,950 | ​ |
| U.S. Government | ​ |  | 139,008 | ​ |  | 2,650 | ​ |  | 15,354 | ​ |  | 157,012 | ​ |
| Total revenues | ​ | $ | 234,720 | ​ | $ | 141,799 | ​ | $ | 133,443 | ​ | $ | 509,962 | ​ |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  |  | ​ |  | ​ | ​ |
| United States | ​ | $ | 205,527 | ​ | $ | 96,601 | ​ | $ | 73,950 | ​ | $ | 376,078 | ​ |
| International | ​ |  | 29,193 | ​ |  | 45,198 | ​ |  | 59,493 | ​ |  | 133,884 | ​ |
| Total revenues | ​ | $ | 234,720 | ​ | $ | 141,799 | ​ | $ | 133,443 | ​ | $ | 509,962 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  |  | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 103,492 | ​ | $ | 105,173 | ​ | $ | 27,789 | ​ | $ | 236,454 | ​ |
| Over time | ​ |  | 131,228 | ​ |  | 36,626 | ​ |  | 105,654 | ​ |  | 273,508 | ​ |
| Total revenues | ​ | $ | 234,720 | ​ | $ | 141,799 | ​ | $ | 133,443 | ​ | $ | 509,962 | ​ |
  (was, 2021-05-07, similarity 0.9893):
[0001104659-21-062898:note_history:7]
| Six months ended March 31, 2021 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |  |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 62,114 | ​ | $ | 92,414 | ​ | $ | 76,027 | ​ | $ | 230,555 | ​ |
| U.S. Government | ​ |  | 88,055 | ​ |  | 1,681 | ​ |  | 9,302 | ​ |  | 99,038 | ​ |
| Total revenues | ​ | $ | 150,169 | ​ | $ | 94,095 | ​ | $ | 85,329 | ​ | $ | 329,593 | ​ |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  |  | ​ |  |  | ​ |
| United States | ​ | $ | 130,849 | ​ | $ | 64,490 | ​ | $ | 46,231 | ​ | $ | 241,570 | ​ |
| International | ​ |  | 19,320 | ​ |  | 29,605 | ​ |  | 39,098 | ​ |  | 88,023 | ​ |
| Total revenues | ​ | $ | 150,169 | ​ | $ | 94,095 | ​ | $ | 85,329 | ​ | $ | 329,593 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  |  | ​ |  |  | ​ |
| Point in time | ​ | $ | 64,000 | ​ | $ | 69,931 | ​ | $ | 18,116 | ​ | $ | 152,047 | ​ |
| Over time | ​ |  | 86,169 | ​ |  | 24,164 | ​ |  | 67,213 | ​ |  | 177,546 | ​ |
| Total revenues | ​ | $ | 150,169 | ​ | $ | 94,095 | ​ | $ | 85,329 | ​ | $ | 329,593 | ​ |

- changed (2021-08-09):
[0001104659-21-102250:note_history:8]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2020 are presented in the tables below.
  (was, 2021-05-07, similarity 0.9576):
[0001104659-21-062898:note_history:8]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2020 are presented in the tables below.

- changed (2021-08-09):
[0001104659-21-102250:note_history:9]
| Three months ended June 30, 2020 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 37,485 | ​ | $ | 39,740 | ​ | $ | 38,737 | ​ | $ | 115,962 |
| U.S. Government | ​ |  | 46,587 | ​ |  | 2,837 | ​ |  | 7,279 | ​ |  | 56,703 |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 42,577 | ​ | $ | 46,016 | ​ | $ | 172,665 |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| United States | ​ | $ | 73,476 | ​ | $ | 26,499 | ​ | $ | 19,441 | ​ | $ | 119,416 |
| International | ​ |  | 10,596 | ​ |  | 16,078 | ​ |  | 26,575 | ​ |  | 53,249 |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 42,577 | ​ | $ | 46,016 | ​ | $ | 172,665 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 36,461 | ​ | $ | 27,765 | ​ | $ | 9,138 | ​ | $ | 73,364 |
| Over time | ​ |  | 47,611 | ​ |  | 14,812 | ​ |  | 36,878 | ​ |  | 99,301 |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 42,577 | ​ | $ | 46,016 | ​ | $ | 172,665 |
  (was, 2021-05-07, similarity 0.9949):
[0001104659-21-062898:note_history:9]
| Three months ended March 31, 2020 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 51,550 | ​ | $ | 43,736 | ​ | $ | 33,952 | ​ | $ | 129,238 |
| U.S. Government | ​ |  | 43,574 | ​ |  | 32 | ​ |  | 7,648 | ​ |  | 51,254 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 43,768 | ​ | $ | 41,600 | ​ | $ | 180,492 |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| United States | ​ | $ | 81,458 | ​ | $ | 28,706 | ​ | $ | 25,121 | ​ | $ | 135,285 |
| International | ​ |  | 13,666 | ​ |  | 15,062 | ​ |  | 16,479 | ​ |  | 45,207 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 43,768 | ​ | $ | 41,600 | ​ | $ | 180,492 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 46,610 | ​ | $ | 32,209 | ​ | $ | 8,009 | ​ | $ | 86,828 |
| Over time | ​ |  | 48,514 | ​ |  | 11,559 | ​ |  | 33,591 | ​ |  | 93,664 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 43,768 | ​ | $ | 41,600 | ​ | $ | 180,492 |

- changed (2021-08-09):
[0001104659-21-102250:note_history:10]
| Nine months ended June 30, 2020 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 130,817 | ​ | $ | 135,711 | ​ | $ | 107,931 | ​ | $ | 374,459 |
| U.S. Government | ​ |  | 125,890 | ​ |  | 3,468 | ​ |  | 21,068 | ​ |  | 150,426 |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 139,179 | ​ | $ | 128,999 | ​ | $ | 524,885 |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| United States | ​ | $ | 219,640 | ​ | $ | 90,155 | ​ | $ | 69,399 | ​ | $ | 379,194 |
| International | ​ |  | 37,067 | ​ |  | 49,024 | ​ |  | 59,600 | ​ |  | 145,691 |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 139,179 | ​ | $ | 128,999 | ​ | $ | 524,885 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 118,660 | ​ | $ | 100,289 | ​ | $ | 26,157 | ​ | $ | 245,106 |
| Over time | ​ |  | 138,047 | ​ |  | 38,890 | ​ |  | 102,842 | ​ |  | 279,779 |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 139,179 | ​ | $ | 128,999 | ​ | $ | 524,885 |
  (was, 2021-05-07, similarity 0.9911):
[0001104659-21-062898:note_history:10]
| Six months ended March 31, 2020 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 93,417 | ​ | $ | 95,971 | ​ | $ | 69,194 | ​ | $ | 258,582 |
| U.S. Government | ​ |  | 79,218 | ​ |  | 631 | ​ |  | 13,789 | ​ |  | 93,638 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 96,602 | ​ | $ | 82,983 | ​ | $ | 352,220 |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| United States | ​ | $ | 146,164 | ​ | $ | 63,665 | ​ | $ | 49,959 | ​ | $ | 259,788 |
| International | ​ |  | 26,471 | ​ |  | 32,937 | ​ |  | 33,024 | ​ |  | 92,432 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 96,602 | ​ | $ | 82,983 | ​ | $ | 352,220 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 82,897 | ​ | $ | 72,524 | ​ | $ | 17,019 | ​ | $ | 172,440 |
| Over time | ​ |  | 89,738 | ​ |  | 24,078 | ​ |  | 65,964 | ​ |  | 179,780 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 96,602 | ​ | $ | 82,983 | ​ | $ | 352,220 |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-08-09):
[0001104659-21-102250:note_history:11]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2021 are presented in the tables below as the Company believes it best depicts how the nature, amount, timing and
  (was, 2021-05-07, similarity 0.7772):
[0001104659-21-062898:note_history:11]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2020 are presented in the tables below.

- added (2021-08-09):
[0001104659-21-102250:note_history:12]
uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue within each reportable segment on a continuing operations basis.

- changed (2021-08-09):
[0001104659-21-102250:note_history:13]
| Three months ended June 30, 2021 |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total | ​ |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 34,708 | ​ | $ | 46,735 | ​ | $ | 42,063 | ​ | $ | 123,506 | ​ |
| U.S. Government | ​ |  | 50,868 | ​ | ​ | 969 | ​ | ​ | 6,051 | ​ |  | 57,888 | ​ |
| Total revenues | ​ | $ | 85,576 | ​ | $ | 47,704 | ​ | $ | 48,114 | ​ | $ | 181,394 | ​ |
| Geographic location: | ​ |  | ​ | ​ | ​ |  | ​ | ​ |  | ​ |  | ​ | ​ |
| United States | ​ | $ | 75,701 | ​ | $ | 32,111 | ​ | $ | 27,719 | ​ | $ | 135,531 | ​ |
| International | ​ |  | 9,875 | ​ | ​ | 15,593 | ​ | ​ | 20,395 | ​ |  | 45,863 | ​ |
| Total revenues | ​ | $ | 85,576 | ​ | $ | 47,704 | ​ | $ | 48,114 | ​ | $ | 181,394 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ |  | ​ | ​ |  | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 37,513 | ​ | $ | 35,242 | ​ | $ | 9,673 | ​ | $ | 82,428 | ​ |
| Over time | ​ |  | 48,063 | ​ | ​ | 12,462 | ​ | ​ | 38,441 | ​ |  | 98,966 | ​ |
| Total revenues | ​ | $ | 85,576 | ​ | $ | 47,704 | ​ | $ | 48,114 | ​ | $ | 181,394 | ​ |
  (was, 2021-05-07, similarity 0.935):
[0001104659-21-062898:note_history:13]
| Three months ended March 31, 2021 |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total | ​ |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 33,973 | ​ | $ | 38,549 | ​ | $ | 39,305 | ​ | $ | 111,827 | ​ |
| U.S. Government | ​ |  | 49,305 | ​ | ​ | 1,006 | ​ | ​ | 4,506 | ​ |  | 54,817 | ​ |
| Total revenues | ​ | $ | 83,278 | ​ | $ | 39,555 | ​ | $ | 43,811 | ​ | $ | 166,644 | ​ |
| Geographic location: | ​ |  |  | ​ | ​ |  | ​ | ​ |  | ​ |  |  | ​ |
| United States | ​ | $ | 73,037 | ​ | $ | 27,445 | ​ | $ | 22,965 | ​ | $ | 123,447 | ​ |
| International | ​ |  | 10,241 | ​ | ​ | 12,110 | ​ | ​ | 20,846 | ​ |  | 43,197 | ​ |
| Total revenues | ​ | $ | 83,278 | ​ | $ | 39,555 | ​ | $ | 43,811 | ​ | $ | 166,644 | ​ |
| Revenue recognition method: | ​ |  |  | ​ | ​ |  | ​ | ​ |  | ​ |  |  | ​ |
| Point in time | ​ | $ | 37,127 | ​ | $ | 27,563 | ​ | $ | 9,248 | ​ | $ | 73,938 | ​ |
| Over time | ​ |  | 46,151 | ​ | ​ | 11,992 | ​ | ​ | 34,563 | ​ |  | 92,706 | ​ |
| Total revenues | ​ | $ | 83,278 | ​ | $ | 39,555 | ​ | $ | 43,811 | ​ | $ | 166,644 | ​ |

- changed (2021-08-09):
[0001104659-21-102250:note_history:14]
| Nine months ended June 30, 2021 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |  |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 95,712 | ​ | $ | 139,149 | ​ | $ | 118,089 | ​ | $ | 352,950 | ​ |
| U.S. Government | ​ |  | 139,008 | ​ |  | 2,650 | ​ |  | 15,354 | ​ |  | 157,012 | ​ |
| Total revenues | ​ | $ | 234,720 | ​ | $ | 141,799 | ​ | $ | 133,443 | ​ | $ | 509,962 | ​ |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  |  | ​ |  | ​ | ​ |
| United States | ​ | $ | 205,527 | ​ | $ | 96,601 | ​ | $ | 73,950 | ​ | $ | 376,078 | ​ |
| International | ​ |  | 29,193 | ​ |  | 45,198 | ​ |  | 59,493 | ​ |  | 133,884 | ​ |
| Total revenues | ​ | $ | 234,720 | ​ | $ | 141,799 | ​ | $ | 133,443 | ​ | $ | 509,962 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  |  | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 103,492 | ​ | $ | 105,173 | ​ | $ | 27,789 | ​ | $ | 236,454 | ​ |
| Over time | ​ |  | 131,228 | ​ |  | 36,626 | ​ |  | 105,654 | ​ |  | 273,508 | ​ |
| Total revenues | ​ | $ | 234,720 | ​ | $ | 141,799 | ​ | $ | 133,443 | ​ | $ | 509,962 | ​ |
  (was, 2021-05-07, similarity 0.9893):
[0001104659-21-062898:note_history:14]
| Six months ended March 31, 2021 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |  |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 62,114 | ​ | $ | 92,414 | ​ | $ | 76,027 | ​ | $ | 230,555 | ​ |
| U.S. Government | ​ |  | 88,055 | ​ |  | 1,681 | ​ |  | 9,302 | ​ |  | 99,038 | ​ |
| Total revenues | ​ | $ | 150,169 | ​ | $ | 94,095 | ​ | $ | 85,329 | ​ | $ | 329,593 | ​ |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  |  | ​ |  |  | ​ |
| United States | ​ | $ | 130,849 | ​ | $ | 64,490 | ​ | $ | 46,231 | ​ | $ | 241,570 | ​ |
| International | ​ |  | 19,320 | ​ |  | 29,605 | ​ |  | 39,098 | ​ |  | 88,023 | ​ |
| Total revenues | ​ | $ | 150,169 | ​ | $ | 94,095 | ​ | $ | 85,329 | ​ | $ | 329,593 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  |  | ​ |  |  | ​ |
| Point in time | ​ | $ | 64,000 | ​ | $ | 69,931 | ​ | $ | 18,116 | ​ | $ | 152,047 | ​ |
| Over time | ​ |  | 86,169 | ​ |  | 24,164 | ​ |  | 67,213 | ​ |  | 177,546 | ​ |
| Total revenues | ​ | $ | 150,169 | ​ | $ | 94,095 | ​ | $ | 85,329 | ​ | $ | 329,593 | ​ |

- added (2021-08-09):
[0001104659-21-102250:note_history:15]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2020 are presented in the tables below.

- changed (2021-08-09):
[0001104659-21-102250:note_history:16]
| Three months ended June 30, 2020 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 37,485 | ​ | $ | 39,740 | ​ | $ | 38,737 | ​ | $ | 115,962 |
| U.S. Government | ​ |  | 46,587 | ​ |  | 2,837 | ​ |  | 7,279 | ​ |  | 56,703 |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 42,577 | ​ | $ | 46,016 | ​ | $ | 172,665 |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| United States | ​ | $ | 73,476 | ​ | $ | 26,499 | ​ | $ | 19,441 | ​ | $ | 119,416 |
| International | ​ |  | 10,596 | ​ |  | 16,078 | ​ |  | 26,575 | ​ |  | 53,249 |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 42,577 | ​ | $ | 46,016 | ​ | $ | 172,665 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 36,461 | ​ | $ | 27,765 | ​ | $ | 9,138 | ​ | $ | 73,364 |
| Over time | ​ |  | 47,611 | ​ |  | 14,812 | ​ |  | 36,878 | ​ |  | 99,301 |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 42,577 | ​ | $ | 46,016 | ​ | $ | 172,665 |
  (was, 2021-05-07, similarity 0.9949):
[0001104659-21-062898:note_history:16]
| Three months ended March 31, 2020 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 51,550 | ​ | $ | 43,736 | ​ | $ | 33,952 | ​ | $ | 129,238 |
| U.S. Government | ​ |  | 43,574 | ​ |  | 32 | ​ |  | 7,648 | ​ |  | 51,254 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 43,768 | ​ | $ | 41,600 | ​ | $ | 180,492 |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| United States | ​ | $ | 81,458 | ​ | $ | 28,706 | ​ | $ | 25,121 | ​ | $ | 135,285 |
| International | ​ |  | 13,666 | ​ |  | 15,062 | ​ |  | 16,479 | ​ |  | 45,207 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 43,768 | ​ | $ | 41,600 | ​ | $ | 180,492 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 46,610 | ​ | $ | 32,209 | ​ | $ | 8,009 | ​ | $ | 86,828 |
| Over time | ​ |  | 48,514 | ​ |  | 11,559 | ​ |  | 33,591 | ​ |  | 93,664 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 43,768 | ​ | $ | 41,600 | ​ | $ | 180,492 |

- changed (2021-08-09):
[0001104659-21-102250:note_history:17]
| Nine months ended June 30, 2020 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 130,817 | ​ | $ | 135,711 | ​ | $ | 107,931 | ​ | $ | 374,459 |
| U.S. Government | ​ |  | 125,890 | ​ |  | 3,468 | ​ |  | 21,068 | ​ |  | 150,426 |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 139,179 | ​ | $ | 128,999 | ​ | $ | 524,885 |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| United States | ​ | $ | 219,640 | ​ | $ | 90,155 | ​ | $ | 69,399 | ​ | $ | 379,194 |
| International | ​ |  | 37,067 | ​ |  | 49,024 | ​ |  | 59,600 | ​ |  | 145,691 |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 139,179 | ​ | $ | 128,999 | ​ | $ | 524,885 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 118,660 | ​ | $ | 100,289 | ​ | $ | 26,157 | ​ | $ | 245,106 |
| Over time | ​ |  | 138,047 | ​ |  | 38,890 | ​ |  | 102,842 | ​ |  | 279,779 |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 139,179 | ​ | $ | 128,999 | ​ | $ | 524,885 |
  (was, 2021-05-07, similarity 0.9911):
[0001104659-21-062898:note_history:17]
| Six months ended March 31, 2020 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 93,417 | ​ | $ | 95,971 | ​ | $ | 69,194 | ​ | $ | 258,582 |
| U.S. Government | ​ |  | 79,218 | ​ |  | 631 | ​ |  | 13,789 | ​ |  | 93,638 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 96,602 | ​ | $ | 82,983 | ​ | $ | 352,220 |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| United States | ​ | $ | 146,164 | ​ | $ | 63,665 | ​ | $ | 49,959 | ​ | $ | 259,788 |
| International | ​ |  | 26,471 | ​ |  | 32,937 | ​ |  | 33,024 | ​ |  | 92,432 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 96,602 | ​ | $ | 82,983 | ​ | $ | 352,220 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 82,897 | ​ | $ | 72,524 | ​ | $ | 17,019 | ​ | $ | 172,440 |
| Over time | ​ |  | 89,738 | ​ |  | 24,078 | ​ |  | 65,964 | ​ |  | 179,780 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 96,602 | ​ | $ | 82,983 | ​ | $ | 352,220 |

- changed (2021-08-09):
[0001104659-21-102250:note_history:18]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At June 30, 2021, the Company had $539.0 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 70% in the next twelve months.
  (was, 2021-05-07, similarity 0.9935):
[0001104659-21-062898:note_history:18]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At March 31, 2021, the Company had $521.7 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 72% in the next twelve months.

- changed (2021-08-09):
[0001104659-21-102250:note_history:19]
Contract assets and contract liabilities
  (was, 2021-05-07, similarity 0.8732):
[0001104659-21-062898:note_history:19]
Contract assets and liabilities

- changed (2021-08-09):
[0001104659-21-102250:note_history:20]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At June 30, 2021, contract assets and contract liabilities totaled $94.8 million and $105.8 million, respectively. Contract assets and contract liabilities are presented as current in the consolidated balance sheets as it is expected all related transaction activity with customers will be substantially completed within twelve months. During the first nine months of 2021, the Company recognized approximately $75 million in revenues that were included in the contract liabilities balance at September 30, 2020.
  (was, 2021-05-07, similarity 0.9339):
[0001104659-21-062898:note_history:20]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At March 31, 2021, contract assets and liabilities totaled $95.0 million and $106.6 million, respectively. Contract assets and liabilities are presented as current in the consolidated balance sheets as it is expected all related transaction activity with customers will be substantially completed within twelve months. During the first six months of 2021, the Company recognized approximately $56 million in revenues that were included in the contract liabilities balance at September 30, 2020.

- removed (2021-08-09):
[0001104659-21-062898:note_history:21]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2021 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue within each reportable segment on a continuing operations basis.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2021-08-09):
[0001104659-21-102250:note_history:22]
14.  SUBSEQUENT EVENTS

- added (2021-08-09):
[0001104659-21-102250:note_history:23]
On May 20, 2021, the Company announced it had entered into an agreement to acquire I.S.A. Altanova Group S.R.L. (Altanova), a supplier in the field of advanced condition assessment technologies including partial discharge measurement and analysis, as well as test instruments for electrical apparatus. Altanova, which will become part of the USG operating segment, had annual sales of approximately $30 million in 2020. As of June 30, 2021, the Company had 30 million Euros held in an escrow account related to this transaction which will be used to partially fund the acquisition. The transaction was subject to Italian regulatory approval, which was obtained and the transaction closed on July 29, 2021.

- added (2021-08-09):
[0001104659-21-102250:note_history:24]
On August 9, 2021, the Company announced it had acquired the assets of Phenix Technologies, Inc. (Phenix), a manufacturer of stationary and portable high voltage, high current, high power test systems, components and solutions supporting the electric utility industry. Phenix, which will become part of the USG operating segment, had annual sales of approximately $25 million in 2020.
