# ESE notes — 0001410578-21-000447


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001410578-21-000447:notes:1]
1.      Summary of Significant Accounting Policies

[0001410578-21-000447:notes:2]
A.      Principles of Consolidation

[0001410578-21-000447:notes:3]
The Consolidated Financial Statements include the accounts of ESCO Technologies Inc. (ESCO) and its wholly owned subsidiaries. Except where the context indicates otherwise, the terms “Company”, “we”, “our” and “us” are used in this report to refer to ESCO together with its subsidiaries through which its businesses are conducted. All significant intercompany transactions and accounts have been eliminated in consolidation.

[0001410578-21-000447:notes:4]
B.      Basis of Presentation

[0001410578-21-000447:notes:5]
Our fiscal year ends on September 30. Throughout the Consolidated Financial Statements, unless the context indicates otherwise, references to a year (for example 2021) refer to fiscal year ending on September 30 of that year.

[0001410578-21-000447:notes:6]
Our former Technical Packaging segment is reflected as discontinued operations in the Consolidated Financial Statements and related notes for all periods presented, in accordance with accounting principles generally accepted in the United States of America (GAAP).

[0001410578-21-000447:notes:7]
During 2021, the Company identified immaterial errors in the 2020 historical consolidated financial statements of Westland, within the A&D segment. These have been corrected as an immaterial revision of those consolidated financial statements. Specifically, the adjustments include $2.4 million of net sales and contract assets being overstated, and $0.9 million of inventory being overstated and cost of goods sold understated by the same amount, and $0.8 million income tax expense, $0.2 million deferred tax liabilities, and $0.6 million accrued other expense being overstated. The net impact of the above adjustments resulted in a decrease in net earnings from continuing operations, net earnings, comprehensive income and retained earnings of $2.5 million and a decrease of $0.10 in reported basic and diluted earnings per share. This correction also resulted in a reclassification in the 2020 consolidated statement of cash flows between line items of net earnings, changes in assets and liabilities, and effect of deferred taxes totaling $2.6 million in 2020, with no impact to the total net cash provided by operating activities.

[0001410578-21-000447:notes:8]
C.      Nature of Operations

[0001410578-21-000447:notes:9]
We are organized based on the products and services we offer and we currently classify our business operations in three segments for financial reporting purposes:  Aerospace & Defense (A&D), Utility Solutions Group (USG), and RF Shielding and Test (Test).

[0001410578-21-000447:notes:10]
A&D: The companies within this segment primarily design and manufacture specialty filtration products, including hydraulic filter elements and fluid control devices used in commercial aerospace applications; unique filter mechanisms used in micro-propulsion devices for satellites; custom designed filters for manned aircraft and submarines; products and systems to reduce vibration and/or acoustic signatures and otherwise reduce or obscure a vessel’s signature, and other communications, sealing, surface control and hydrodynamic related applications to enhance U.S. Navy maritime survivability; precision-tolerance machined components for the aerospace and defense industry; and metal processing services.

[0001410578-21-000447:notes:11]
USG: The companies within this segment provide diagnostic testing solutions that enable electric power grid operators to assess the integrity of high-voltage power delivery equipment, as well as decision support tools for the renewable energy industry, primarily wind and solar.

[0001410578-21-000447:notes:12]
Test: The companies within this segment provide their customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy.

[0001410578-21-000447:notes:13]
In addition, for reporting certain financial information we treat Corporate activities as a separate segment.

[0001410578-21-000447:notes:14]
D.      Use of Estimates

[0001410578-21-000447:notes:15]
The preparation of financial statements in conformity with GAAP requires Management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.

[0001410578-21-000447:notes:16]
E.      Revenue Recognition

[0001410578-21-000447:notes:17]
On October 1, 2018, we adopted ASU No. 2014-09, Revenue from Contracts with Customers (ASC 606). Significant changes to our policies resulting from the adoption are provided below. We adopted ASC 606 using the modified retrospective transition method applied to contracts that were not substantially complete at the end of fiscal year 2018. We recorded a $5.2 million adjustment to increase retained earnings to reflect the cumulative impact of adopting this standard at the beginning of fiscal year 2019, primarily related to certain long-term contracts in our A&D and Technical Packaging segments that converted to the cost-to-cost method for revenue recognition.

[0001410578-21-000447:notes:18]
Revenue Recognition

[0001410578-21-000447:notes:19]
We recognize revenue when control of the goods or services promised under the contract is transferred to the customer either at a point in time (e.g., upon delivery) or over time (e.g., as we perform under the contract). We account for a contract when it has approval and commitment from both parties, the rights and payment terms of the parties are identified, the contract has commercial substance and collectability of consideration is probable. We review contracts to determine whether there are one or multiple performance obligations. A performance obligation is a promise to transfer a distinct good or service to a customer and represents the unit of accounting for revenue recognition. For contracts with multiple performance obligations, we allocate the expected consideration, or the transaction price, to each performance obligation identified in the contract based on the relative standalone selling price of each performance obligation. We then recognize revenue for the transaction price allocated to the performance obligation when control of the promised goods or services underlying the performance obligation is transferred.

[0001410578-21-000447:notes:20]
Payment terms with our customers vary by the type and location of the customer and the products or services offered. We do not adjust the promised amount of consideration for the effects of significant financing components based on the expectation that the period between when we transfer a promised good or service to a customer and when the customer pays for that good or service will be one year or less. Arrangements with customers that include payment terms extending beyond one year are not significant. We account for shipping and handling costs on a gross basis and include them in net sales. We account for taxes collected from customers and remitted to governmental authorities on a net basis and exclude them from net sales.

[0001410578-21-000447:notes:21]
A&D: Within the A&D segment, approximately 43% of revenues (approximately 19% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial and military customers and have a single performance obligation as there is only one good promised or the promise to transfer the goods or services is not distinct or separately identifiable from other promises in the contract. The transaction price for these contracts reflects our estimate of returns and discounts, which are based on historical, current and forecasted information to determine the expected amount to which we will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to the customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in cost of goods sold in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

[0001410578-21-000447:notes:22]
Approximately 57% of the segment’s revenues (approximately 25% of consolidated revenues) are accounted for over time as the product does not have an alternative use and we have an enforceable right to payment for costs incurred plus a reasonable margin or the inventory is owned by the customer. The related contracts are primarily cost-plus or fixed price contracts related to the design, development and manufacture of complex fluid control products, quiet valves, manifolds, shock and vibration dampening, thermal insulation and systems primarily for the commercial aerospace and military (U.S. Government) markets. The contracts may contain multiple products, which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each

[0001410578-21-000447:notes:23]
product is distinct in context of the contract and will be accounted for as a separate performance obligation. Our contracts are frequently modified for changes in contract specifications and requirements. Most of our contract modifications are for products that are not distinct from the existing contract and are accounted for as part of that existing contract.

[0001410578-21-000447:notes:24]
Contracts with the U.S. Government generally contain clauses that provide lien rights to work-in-process along with clauses that allow the customer to unilaterally terminate the contract for convenience, pay us for costs incurred plus a reasonable profit and take control of any work-in-process. Due to the continuous transfer of control to the U.S. Government, we recognize revenue over the time that we perform under the contract.

[0001410578-21-000447:notes:25]
Selecting the method to measure progress towards completion for the commercial and military contracts requires judgment and is based on the nature of the products or service to be provided. We generally use the cost-to-cost method to measure progress for our Aerospace & Defense segment contracts, as the rate at which costs are incurred to fulfill a contract best depicts the transfer of control to the customer. Under this method, we measure the extent of progress towards completion based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and record revenue proportionally as costs are incurred based on an estimated profit margin.

[0001410578-21-000447:notes:26]
The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Certain of our long-term contracts contain incentive fees that can increase the transaction price. These variable amounts generally are awarded upon achievement of certain performance metrics, program milestones or cost targets and can be based upon customer discretion. We include estimated amounts in the transaction price to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimates of variable consideration and determination of whether to include estimated amounts in the transaction price are based largely on an assessment of our anticipated performance and all other information that is reasonably available to us.

[0001410578-21-000447:notes:27]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to one or more years, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

[0001410578-21-000447:notes:28]
Under the typical payment terms of our long term fixed price contracts, the customer pays us either performance-based or progress payments. Performance-based payments represent interim payments based on quantifiable measures of performance or on the achievement of specified events or milestones. Progress payments are interim payments of costs incurred as the work progresses. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred, which we present as contract assets and contract liabilities, respectively, in the Consolidated Balance Sheets. We classify amounts billed and due from our customers in Accounts receivable, net. For short term fixed price and cost-type contracts, we are generally paid within a short period of time.

[0001410578-21-000447:notes:29]
For contracts where revenue is recognized over time, we recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. We have net revenue recognized in the current year from performance obligations satisfied in the prior year due to changes in our estimated costs to complete the related performance obligations. We recognize anticipated losses on contracts in full in the period in which the losses become known.

[0001410578-21-000447:notes:30]
USG: Within the USG segment, approximately 75% of revenues (approximately 21% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and is accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which we will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. We generally do not treat them as separate performance obligations as these costs fulfill a promise to

[0001410578-21-000447:notes:31]
transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. We record taxes collected from customers and remitted to government authorities on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

[0001410578-21-000447:notes:32]
Approximately 25% of the segment’s revenues (approximately 7% of consolidated revenues) are recognized over time as services are performed. The services accounted for under this method include an obligation to provide testing services using hardware and embedded software, software maintenance, training, lab testing, and consulting services. The related contracts contain a bundle of goods and services that are integrated in the context of the contract. Therefore, the goods and services are not distinct and we have a single performance obligation. Selecting the method to measure progress towards completion for these contracts requires judgment and is based on the nature of the products and service to be provided. We will recognize revenue as a series of distinct services based on each day of providing services (straight-line over the contract term) for our USG segment contracts. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Under the typical payment terms of our service contracts, the customer pays us in advance of when services are performed. Because of the timing difference of revenue recognition and customer payment, which is typically received upon commencement of the contract, these contracts result in deferred revenue, which we present as contract liabilities, in the Consolidated Balance Sheets.

[0001410578-21-000447:notes:33]
Included in this category, approximately 8% of the segment’s revenues (approximately 2% of consolidated revenues) are recognized based on the terms of the software contract. For contracts that transfer a software license to the customer, revenue will be recognized at a point in time. These type of software contracts represent a right to use the software, or a functional license, in which revenue should be recognized upon transfer of the license. For contracts in software as a service (SaaS) arrangements, revenue will be recognized over time. The customer receives and consumes the benefits of the SaaS arrangement through access to the system which is for a stated period. We will recognize revenue based on each day of providing access (straight-line over the contract term). The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Under the typical payment terms of our software contracts, the customer pays us in advance of when services are performed. Because of the timing difference of revenue recognition and customer payment, these contracts result in deferred revenue, which we present as contract liabilities, in the Consolidated Balance Sheets.

[0001410578-21-000447:notes:34]
Test: Within the Test segment, approximately 20% of revenues (approximately 6% of consolidated revenues) are recognized at a point in time when products such as, antennas and probes are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct because the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in the context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which we will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

[0001410578-21-000447:notes:35]
Approximately 80% of the segment’s revenues (approximately 22% of consolidated revenues) are recorded over time as the product does not have an alternative use and we have an enforceable right to payment for costs incurred plus a reasonable margin. Products accounted for under this guidance include the construction and installation of test chambers to a buyer’s specifications that provide its customers with the ability to measure and contain magnetic, electromagnetic and acoustic energy. The goods and services related to each installed test chamber are not distinct due to the significant amount of integration provided and each installed chamber is accounted for as a single performance obligation. Selecting the method to measure progress towards completion for these contracts requires judgment and is based on the nature of the products and service to be provided. We use milestones to measure progress for our Test segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. For arrangements that are accounted for under this guidance, we estimate profit as the difference between total revenue and total

[0001410578-21-000447:notes:36]
estimated cost of a contract and recognize these revenues and costs based primarily on contract milestones. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable.

[0001410578-21-000447:notes:37]
We estimate total contract cost utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to a year, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

[0001410578-21-000447:notes:38]
Under the typical payment terms of our fixed price contracts, the customer pays us either performance-based or progress payments. Performance-based payments represent interim payments based on quantifiable measures of performance or on the achievement of specified events or milestones. Progress payments are interim payments of costs incurred as the work progresses. Because of the timing difference of revenue recognition and customer billing, these contracts result in revenue recognized in excess of billings and billings in excess of costs incurred, which we present as contract assets and contract liabilities, respectively, in the Consolidated Balance Sheets. Amounts billed and due from our customers are classified in Accounts receivable, net.

[0001410578-21-000447:notes:39]
For contracts where revenue is recognized over time, we generally recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. We have net revenue recognized in the current year from performance obligations satisfied in the prior year due to changes in our estimated costs to complete the related performance obligations. We recognize anticipated losses on contracts in full in the period in which the losses become probable and estimable.

[0001410578-21-000447:notes:40]
Contract Assets and Liabilities

[0001410578-21-000447:notes:41]
Contract assets arise from contracts when revenue is recognized over time and the amount of revenue recognized, including our estimate of variable consideration that has been included in the transaction price, exceeds the amount billed to the customer. These amounts are included in contract assets until the right to payment is no longer conditional on events other than the passage of time. These contract assets are reclassified to receivables when the right to consideration becomes unconditional. Contract liabilities include deposits, deferred revenue, upfront payments and billings in excess of revenue recognized. We include liabilities for customer rebates and discounts in other current liabilities in the Consolidated Balance Sheets.

[0001410578-21-000447:notes:42]
See the further discussion of our revenue recognition in Note 15 below.

[0001410578-21-000447:notes:43]
F.      Cash and Cash Equivalents

[0001410578-21-000447:notes:44]
Cash equivalents include temporary investments that are readily convertible into cash, such as money market funds, with original maturities of three months or less.

[0001410578-21-000447:notes:45]
G.      Accounts Receivable

[0001410578-21-000447:notes:46]
We reduce accounts receivable by an allowance for amounts that we estimate are uncollectible in the future. This estimated allowance is based on Management’s evaluation of the financial condition of the customer and historical write-off experience.

[0001410578-21-000447:notes:47]
H.      Inventories

[0001410578-21-000447:notes:48]
We value inventories at the lower of cost (first-in, first-out) or market value. We regularly review inventories for excess quantities and obsolescence based upon historical experience, specific identification of discontinued items, future demand, and market conditions. Inventories under long-term contracts reflect accumulated production costs, factory overhead, initial tooling and other related costs less the portion of such costs charged to cost of sales.

[0001410578-21-000447:notes:49]
I.      Property, Plant and Equipment

[0001410578-21-000447:notes:50]
Property, plant and equipment are recorded at cost. Depreciation and amortization are computed primarily on a straight-line basis over the estimated useful lives of the assets: buildings, 10-40 years; machinery and equipment, 3-10 years; and office furniture and equipment, 3-10 years. Leasehold improvements are amortized over the remaining term of the applicable lease or their estimated useful lives, whichever is shorter. Long-lived tangible assets are reviewed for impairment whenever events or changes in business circumstances indicate the carrying value of the assets may not be recoverable. Impairment losses are recognized based on fair value.

[0001410578-21-000447:notes:51]
J.      Leases

[0001410578-21-000447:notes:52]
Our lease agreements primarily relate to office space, manufacturing facilities, and machinery and equipment. We determine at lease inception whether an arrangement that provides control over the use of an asset is a lease. We recognize at lease commencement a right-of-use (ROU) asset and lease liability based on the present value of the future lease payments over the lease term. We have elected not to recognize a ROU asset and lease liability for leases with terms of 12 months or less. Certain of our leases include options to extend the term of the lease for up to 20 years. When it is reasonably certain that we will exercise the option, Management includes the impact of the option in the lease term for purposes of determining total future lease payments. As most of our lease agreements do not explicitly state the discount rate implicit in the lease, Management uses our incremental borrowing rate on the commencement date to calculate the present value of future payments based on the tenor of each arrangement.

[0001410578-21-000447:notes:53]
K.      Goodwill and Other Long-Lived Intangible Assets

[0001410578-21-000447:notes:54]
Goodwill represents the excess of purchase price over the fair value of net identifiable assets acquired in business acquisitions. Management annually reviews goodwill and other long-lived assets with indefinite useful lives for impairment or whenever events or changes in circumstances indicate the carrying amount may be less than fair value. If we determine that the carrying value of the long-lived asset or reporting unit is less than fair value, we record a permanent impairment charge for the amount by which the carrying value of the long-lived asset exceeds its fair value. We measure the fair value of our reporting units based on a discounted cash flow method using a discount rate determined by Management to be commensurate with the risk inherent in each of our reporting units’ current business models. We determine the fair value of trade names using a generally accepted valuation method based on an income approach called the relief from royalty method. During 2021, Management performed a quantitative impairment analysis, which included a detailed calculation of the fair value of our trade names and reporting units related to certain reporting units within these segments. The results of these impairment analyses indicated that the fair values of the trade names and reporting units are not less than their carrying values. Our estimates of discounted cash flows to derive the fair value were measured in accordance with ASC 350, Intangibles – Goodwill and Other. We are using estimates of discounted cash flows that may change, and if they change negatively it could result in the need to write down those assets to fair value.

[0001410578-21-000447:notes:55]
Other intangible assets represent costs allocated to identifiable intangible assets, principally customer relationships, capitalized software, patents, trademarks, and technology rights. We amortize intangible assets with estimable useful lives over their respective

[0001410578-21-000447:notes:56]
estimated useful lives to their estimated residual values, and review them for impairment whenever events or changes in business circumstances indicate the carrying value of the assets may not be recoverable.

[0001410578-21-000447:notes:57]
See Note 4 regarding goodwill and other intangible assets activity.

[0001410578-21-000447:notes:58]
L.      Capitalized Software

[0001410578-21-000447:notes:59]
Costs incurred for the development of computer software that will be sold, leased, or otherwise marketed are charged to research and development expense when incurred, until technological feasibility has been established for the product. Technological feasibility is typically established upon completion of a detailed program design. Costs incurred after this point are capitalized on a project-by-project basis. Capitalized costs consist of internal and external development costs. Upon general release of the product to customers, we cease capitalization and begin amortization, which is calculated on a project-by-project basis as the greater of (1) the ratio of current gross revenues for a product to the total of current and anticipated future gross revenues for the product or (2) the straight-line method over the estimated economic life of the product. We generally amortize software development costs over a three-to-seven year period based upon the estimated future economic life of the product. Factors we consider in determining the estimated future economic life of the product include anticipated future revenues, and changes in software and hardware technologies. Management annually reviews the carrying values of capitalized costs for impairment or whenever events or changes in circumstances indicate the carrying amount may not be recoverable. If expected cash flows are insufficient to recover the carrying amount of the asset, then we recognize an impairment loss to state the asset at its net realizable value.

[0001410578-21-000447:notes:60]
M.      Income Taxes

[0001410578-21-000447:notes:61]
We account for income taxes under the asset and liability method. We recognize deferred tax assets and liabilities for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. We measure deferred tax assets and liabilities using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. We may reduce deferred tax assets by a valuation allowance if it is more likely than not that some portion or all of the deferred tax assets will not be realized. We recognize the effect on deferred tax assets and liabilities of a change in tax rates in income in the period that includes the enactment date. We regularly review our deferred tax assets for recoverability and establish a valuation allowance when Management believes it is more likely than not such assets will not be recovered, taking into consideration historical operating results, expectations of future earnings, tax planning strategies, and the expected timing of the reversals of existing temporary differences. Our policy is to include interest related to unrecognized tax benefits in income tax expense and penalties in operating expense.

[0001410578-21-000447:notes:62]
N.      Research and Development Costs

[0001410578-21-000447:notes:63]
Company-sponsored research and development costs include research and development and bid and proposal efforts related to our products and services. We charge Company-sponsored product development costs to expense when incurred. Customer-sponsored research and development costs refer to certain situations whereby customers provide funding to support specific contractually defined research and development costs. We account for customer-sponsored research and development costs incurred pursuant to contracts similarly to other program costs. Total Company and customer-sponsored research and development expenses were approximately $15.4 million, $13.3 million and $12.1 million for 2021, 2020 and 2019, respectively.

[0001410578-21-000447:notes:64]
O.      Foreign Currency Translation

[0001410578-21-000447:notes:65]
We translate the financial statements of our foreign operations into U.S. dollars in accordance with FASB ASC Topic 830, Foreign Currency Matters. We record the resulting translation adjustments as a separate component of accumulated other comprehensive income.

[0001410578-21-000447:notes:66]
P.      Earnings Per Share

[0001410578-21-000447:notes:67]
We calculate basic earnings per share using the weighted average number of common shares outstanding during the period. We calculate diluted earnings per share using the weighted average number of common shares outstanding during the period plus shares

[0001410578-21-000447:notes:68]
issuable upon the assumed exercise of dilutive vesting of unvested restricted units (restricted shares) using the treasury stock method. There are no anti-dilutive shares.

[0001410578-21-000447:notes:69]
The number of shares used in the calculation of earnings per share for each year presented is as follows:

[0001410578-21-000447:notes:70]
| (in thousands) |  | 2021 |  | 2020 |  | 2019 |
| Weighted Average Shares Outstanding — Basic |  | 26,046 |  | 26,010 |  | 25,946 |
| Dilutive Restricted Shares | ​ | 179 | ​ | 125 | ​ | 151 |
| Shares — Diluted |  | 26,225 |  | 26,135 |  | 26,097 |

[0001410578-21-000447:notes:71]
Q.      Share-Based Compensation

[0001410578-21-000447:notes:72]
We provide compensation benefits to certain key employees under several share-based plans providing for performance-accelerated, performance-based and/or time-vested restricted stock unit awards, and to non-employee directors under a separate compensation plan for non-employee directors. We measure share-based payment expense at the grant date based on the fair value of the award and recognize it on a straight-line basis over the requisite service period (generally the vesting period of the award).

[0001410578-21-000447:notes:73]
R.      Accumulated Other Comprehensive Loss

[0001410578-21-000447:notes:74]
Accumulated other comprehensive loss of $(2.2) million at September 30, 2021 consisted of currency translation adjustments. Accumulated other comprehensive loss of $(3.7) million at September 30, 2020 consisted of currency translation adjustments.

[0001410578-21-000447:notes:75]
S.      Derivative Financial Instruments

[0001410578-21-000447:notes:76]
We report all derivative financial instruments on the balance sheet at fair value. The accounting for changes in fair value of a derivative instrument depends on whether it has been designated and qualifies as a hedge and on the type of hedge. For each derivative instrument designated as a cash flow hedge, we defer the effective portion of the gain or loss on the derivative in accumulated other comprehensive income until recognized in earnings with the underlying hedged item. Regardless of type, a fully effective hedge will result in no net earnings impact while the derivative is outstanding. To the extent that any hedge is ineffective at offsetting cash flow or fair value changes in the underlying hedged item, there could be a net earnings impact.

[0001410578-21-000447:notes:77]
T.      Fair Value Measurements

[0001410578-21-000447:notes:78]
Fair value is defined as the price at which an asset could be exchanged in a current transaction between knowledgeable, willing parties or the amount that would be paid to transfer a liability to a new obligor, not the amount that would be paid to settle the liability with the creditor. Where available, we base fair value on observable market prices or parameters or derived from such prices or parameters. Where observable prices or inputs are not available, we apply valuation models. These valuation techniques involve some level of Management estimation and judgment, the degree of which is dependent on the price transparency for the instruments or market and the instruments’ complexity.

[0001410578-21-000447:notes:79]
The accounting guidance establishes a three-level hierarchy for disclosure of fair value measurements, based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date, as follows:

[0001410578-21-000447:notes:80]
Level 1 – Inputs to the valuation methodology are quoted prices (unadjusted) for identical assets or liabilities in active markets.

[0001410578-21-000447:notes:81]
Level 2 – Inputs to the valuation methodology include quoted prices for similar assets and liabilities in active markets, and inputs that are observable for the asset or liability, either directly or indirectly, for substantially the full term of the financial instrument.

[0001410578-21-000447:notes:82]
Level 3 – Inputs to the valuation methodology are unobservable and significant to the fair value measurement.

[0001410578-21-000447:notes:83]
Financial Assets and Liabilities

[0001410578-21-000447:notes:84]
We have estimated the fair value of our financial instruments as of September 30, 2021 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, payables and other current assets and liabilities approximate fair value because of the short maturity of those instruments. The carrying amounts due under the revolving credit facility approximate fair value as the interest on outstanding borrowings is calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at our election.

[0001410578-21-000447:notes:85]
Nonfinancial Assets and Liabilities

[0001410578-21-000447:notes:86]
Our nonfinancial assets such as property, plant and equipment, inventories, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during 2021.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001410578-21-000447:notes:87]
2.    Acquisitions

[0001410578-21-000447:notes:88]
2021

[0001410578-21-000447:notes:89]
On August 9, 2021 we acquired the assets of Phenix Technologies, Inc. (Phenix), for a purchase price of approximately $47.2 million in cash. Phenix, based in Accident, Maryland, is a leading designer and manufacturer of high voltage, high current, high power test systems and components and solutions supporting the electric utility industry, high voltage test laboratories, and field service organizations worldwide. Since the date of acquisition, the operating results for the Phenix business have been included as part of the USG segment. The acquisition date fair value of the assets acquired and liabilities assumed were as follows: approximately $2.6 million of accounts receivable, $5.8 million of inventory, $8.0 million of property, plant and equipment, $6.2 million of accounts payable and accrued expenses, $3.7 million for tradenames, $9.6 million of customer relationships and $0.5 million of miscellaneous items. The tradename was determined to have an indefinite useful life and the customer relationships were determined to have a useful life of 13 years. The acquired goodwill of $23.2 million relates to excess value associated with opportunities to expand the services and products that the Company can offer to its customers. The Company estimates approximately $20 million of the goodwill will be deductible for tax purposes. The allocation of the purchase price to acquired assets and assumed liabilities is preliminary as we are in the process of obtaining additional information necessary to identify and determine the fair value of all acquired assets and assumed liabilities and calculate a final residual.

[0001410578-21-000447:notes:90]
On July 29, 2021 we acquired I.S.A. – Altanova Group S.r.l., (Altanova), headquartered in Taino, Italy, for a purchase price of approximately $115 million, net of cash acquired. Altanova is a supplier of diagnostic products, monitoring systems and services related to power generation, transmission and distribution networks, renewable energy and storage, and process industries to customers in more than 100 countries. Since the date of acquisition, the operating results for the Altanova business have been included as part of the USG segment. The acquisition date fair value of the assets acquired and liabilities assumed were as follows: $9.7 million of accounts receivable, $5.6 million of inventory, $1.2 million of property, plant and equipment, $8.0 million of other assets, $12.8 million of accounts payable and accrued expenses, $6.9 million of other liabilities, $16.4 million of deferred tax liabilities, $50.5 million of customer relationships and $4.3 million of tradenames. The tradename was determined to have a useful life of ten years and the customer relationships were determined to have a useful life of twenty years. The acquired goodwill of $71.9 million relates to the excess value associated with opportunities to expand the services and products that the Company can offer to its customers, access to new markets, and synergies anticipated by combining Altanova with existing USG businesses. The Company does not expect the goodwill will be deductible for tax purposes. The allocation of the purchase price to acquired assets and assumed liabilities is preliminary as we are in the process of obtaining additional information necessary to identify and determine the fair value of all acquired assets and assumed liabilities and calculate a final residual.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001410578-21-000447:notes:91]
3.      Technical Packaging Divestiture

[0001410578-21-000447:notes:92]
In December 2019, we completed the sale of our Technical Packaging business segment, consisting of our wholly-owned subsidiaries Thermoform Engineered Quality LLC, Plastique Ltd. and Plastique sp. z o.o. (the “Technical Packaging Business”), to Sonoco

[0001410578-21-000447:notes:93]
Plastics, Inc. and Sonoco Holdings, Inc. (“Buyers”), two wholly-owned subsidiaries of Sonoco Products Company (NYSE:SON). The companies within this segment provide innovative solutions to the medical and commercial markets for thermoformed packages and specialty products using a wide variety of thin gauge plastics and pulp. Results of operations, financial position and cash flows for the Technical Packaging business are reflected as discontinued operations in the Consolidated Financial Statements and related notes for all periods presented.

[0001410578-21-000447:notes:94]
Net sales from the Technical Packaging business were $16.5 million and $86.9 million in 2020 and 2019, respectively. Pretax (loss) earnings from the Technical Packaging business was $(0.3) million and $4.3 million in 2020 and 2019, respectively. We received net proceeds from the sale of approximately $184 million and recorded $76.5 million after-tax net earnings on the sale in 2020. We finalized a contractual working capital adjustment and paid $0.2 million to the buyer during the third quarter of 2020.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001410578-21-000447:notes:95]
4.      Goodwill and Other Intangible Assets

[0001410578-21-000447:notes:96]
Included on the Consolidated Balance Sheets at September 30, 2021 and 2020 are the following intangible assets gross carrying amounts and accumulated amortization:

[0001410578-21-000447:notes:97]
| (Dollars in thousands) |  | 2021 |  | 2020 |
| Goodwill | ​ | $ | 504,853 |  | 408,063 |
| Intangible assets with determinable lives: | ​ |  | ​ | ​ | ​ |
| Patents | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 2,131 | ​ | 2,092 |
| Less: accumulated amortization | ​ |  | 972 | ​ | 858 |
| Net | ​ | $ | 1,159 | ​ | 1,234 |
| Capitalized software | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 93,671 | ​ | 84,888 |
| Less: accumulated amortization | ​ |  | 63,740 | ​ | 57,302 |
| Net | ​ | $ | 29,931 | ​ | 27,586 |
| Customer Relationships | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 288,530 | ​ | 227,178 |
| Less: accumulated amortization | ​ |  | 80,882 | ​ | 67,643 |
| Net | ​ | $ | 207,648 | ​ | 159,535 |
| Other | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 8,680 | ​ | 5,156 |
| Less: accumulated amortization | ​ |  | 4,298 | ​ | 3,260 |
| Net | ​ | $ | 4,382 | ​ | 1,896 |
| Intangible assets with indefinite lives: | ​ |  | ​ | ​ | ​ |
| Trade names | ​ | $ | 166,130 | ​ | 156,381 |

[0001410578-21-000447:notes:98]
We performed our annual evaluation of goodwill and intangible assets for impairment during the fourth quarter of 2021 and concluded that no impairment existed at September 30, 2021. There were no accumulated impairment losses as of September 30, 2021.

[0001410578-21-000447:notes:99]
The changes in the carrying amount of goodwill attributable to each business segment for 2021 and 2020 are as follows:

[0001410578-21-000447:notes:100]
| (Dollars in millions) |  | A&D | ​ | Test |  | USG |  | Total |
| Balance as of September 30, 2019 | ​ | $ | 102.2 |  | ​ | 34.1 |  | 254.0 |  | 390.3 |
| Out-of-period adjustment | ​ | ​ | — | ​ | ​ | — | ​ | 18.0 | ​ | 18.0 |
| Foreign currency translation and other | ​ | ​ | (0.1) | ​ | ​ | — | ​ | (0.1) | ​ | (0.2) |
| Balance as of September 30, 2020 | ​ | $ | 102.1 | ​ | ​ | 34.1 | ​ | 271.9 | ​ | 408.1 |
| Acquisition activity | ​ | ​ | 2.2 | ​ | ​ | — | ​ | 95.2 | ​ | 97.4 |
| Foreign currency translation and other | ​ | ​ | — | ​ | ​ | — | ​ | (0.6) | ​ | (0.6) |
| Balance as of September 30, 2021 | ​ | $ | 104.3 | ​ | ​ | 34.1 | ​ | 366.5 | ​ | 504.9 |

[0001410578-21-000447:notes:101]
Amortization expense related to intangible assets with determinable lives was $20.8 million, $21.8 million and $18.5 million in 2021, 2020 and 2019, respectively. Patents are amortized over the life of the patents, generally ten to twenty years. Capitalized software is amortized over the estimated useful life of the software, generally three to seven years. Customer relationships are generally amortized over thirteen to twenty years.

[0001410578-21-000447:notes:102]
As of September 30, 2020, we reclassified $18.0 million from Morgan Schaffer’s tradename to goodwill to correct a misclassification that originated in the original accounting for the acquisition in fiscal 2017. Management has determined that the effect of this misclassification was not material to the current or any prior periods and it had no impact on our total assets, results of operations or cash flows for any period.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001410578-21-000447:notes:103]
5.      Accounts Receivable

[0001410578-21-000447:notes:104]
Accounts receivable, net of the allowance for doubtful accounts, from continuing operations consisted of the following at September 30, 2021 and 2020:

[0001410578-21-000447:notes:105]
| (Dollars in thousands) |  | 2021 |  | 2020 |
| Commercial | ​ | $ | 128,952 |  | 121,924 |
| U.S. Government and prime contractors | ​ |  | 17,389 |  | 22,158 |
| Total | ​ | $ | 146,341 |  | 144,082 |


## us-gaap:InventoryDisclosureTextBlock

[0001410578-21-000447:notes:106]
6.      Inventories, Net

[0001410578-21-000447:notes:107]
Inventories, net, from continuing operations consisted of the following at September 30, 2021 and 2020:

[0001410578-21-000447:notes:108]
| (Dollars in thousands) |  | 2021 |  | 2020 |
| Finished goods | ​ | $ | 32,998 |  | 28,435 |
| Work in process | ​ |  | 34,201 |  | 29,864 |
| Raw materials | ​ |  | 79,949 |  | 76,997 |
| Total | ​ | $ | 147,148 |  | 135,296 |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001410578-21-000447:notes:109]
7.      Income Tax Expense

[0001410578-21-000447:notes:110]
We allocated total income tax expense (benefit) for the years ended September 30, 2021, 2020 and 2019 to income tax expense as follows:

[0001410578-21-000447:notes:111]
| (Dollars in thousands) |  | 2021 |  | 2020 |  | 2019 |
| Income tax expense from continuing operations | ​ | $ | 17,175 |  | 13,510 |  | 20,388 |
| Income tax expense from discontinued operations | ​ |  | — |  | 23,501 |  | 789 |
| Total income tax expense (benefit) | ​ | $ | 17,175 |  | 37,011 |  | 21,177 |

[0001410578-21-000447:notes:112]
The components of income from continuing operations before income taxes for 2021, 2020 and 2019 consisted of the following:

[0001410578-21-000447:notes:113]
| (Dollars in thousands) |  | 2021 |  | 2020 |  | 2019 |
| United States | ​ | $ | 70,214 |  | 23,951 |  | 87,150 |
| Foreign | ​ |  | 10,457 |  | 12,455 |  | 10,727 |
| Total income before income taxes | ​ | $ | 80,671 |  | 36,406 |  | 97,877 |

[0001410578-21-000447:notes:114]
The principal components of income tax expense (benefit) from continuing operations for 2021, 2020 and 2019 consist of:

[0001410578-21-000447:notes:115]
| (Dollars in thousands) |  | 2021 |  | 2020 |  | 2019 |
| Federal: |  | ​ |  |  |  |  |  |
| Current | ​ | $ | 14,807 |  | 10,495 |  | 13,888 |
| Deferred | ​ |  | (1,598) |  | 1,311 |  | 250 |
| State and local: | ​ |  | ​ |  | ​ |  | ​ |
| Current | ​ |  | 2,257 |  | 1,984 |  | 3,039 |
| Deferred | ​ |  | (786) |  | (932) |  | 98 |
| Foreign: | ​ |  | ​ |  | ​ |  | ​ |
| Current | ​ |  | 2,922 |  | 2,875 |  | 2,439 |
| Deferred | ​ |  | (427) |  | (2,223) |  | 674 |
| Total | ​ | $ | 17,175 |  | 13,510 |  | 20,388 |

[0001410578-21-000447:notes:116]
The actual income tax expense (benefit) from continuing operations for 2021, 2020 and 2019 differs from the expected tax expense for those years (computed by applying the U.S. Federal corporate statutory rate) as follows:

[0001410578-21-000447:notes:117]
| ​ |  | 2021 |  | 2020 |  | 2019 |  |
| Federal corporate statutory rate |  | 21.0 | % | 21.0 | % | 21.0 | % |
| State and local, net of Federal benefits | ​ | 1.9 |  | 2.3 |  | 3.2 | ​ |
| Foreign | ​ | (0.4) |  | 1.3 |  | 0.6 | ​ |
| Research credit | ​ | (0.9) |  | (3.7) |  | (0.8) | ​ |
| Change in uncertain tax positions | ​ | — |  | — |  | (0.1) | ​ |
| Executive compensation | ​ | 0.9 |  | 1.6 |  | 0.3 | ​ |
| Valuation allowance | ​ | — |  | (6.8) |  | (2.4) | ​ |
| GILTI and FDII | ​ | (1.3) | ​ | (2.1) | ​ | (0.6) | ​ |
| Tax reform – impact on U.S. deferred tax assets and liabilities | ​ | — |  | — |  | (0.3) | ​ |
| Tax reform – transition tax | ​ | — |  | — |  | (0.1) | ​ |
| Pension plan termination charge | ​ | — | ​ | 23.4 | ​ | — | ​ |
| Other, net | ​ | 0.1 |  | 0.1 |  | — | ​ |
| Effective income tax rate | ​ | 21.3 | % | 37.1 | % | 20.8 | % |

[0001410578-21-000447:notes:118]
The tax effects of temporary differences that give rise to significant portions of the deferred tax assets and liabilities at September 30, 2021 and 2020 are presented below:

[0001410578-21-000447:notes:119]
| (Dollars in thousands) |  | 2021 |  | 2020 |
| Deferred tax assets: |  | ​ |  |  |  |
| Inventories | ​ | $ | 4,267 |  | 5,007 |
| Pension and other postretirement benefits | ​ |  | 859 |  | 842 |
| Timing differences related to revenue recognition | ​ | ​ | 9,365 | ​ | 4,936 |
| Lease liabilities | ​ | ​ | 7,614 | ​ | 5,220 |
| Net operating and capital loss carryforwards — domestic | ​ |  | 542 |  | 563 |
| Net operating loss carryforward — foreign | ​ |  | 4,279 |  | 3,678 |
| Other compensation-related costs and other cost accruals | ​ |  | 8,174 |  | 8,953 |
| State credit carryforward | ​ |  | 2,639 |  | 2,366 |
| Foreign credit carryforward | ​ | ​ | 192 | ​ | — |
| Total deferred tax assets | ​ |  | 37,931 |  | 31,565 |
| Deferred tax liabilities: | ​ |  | ​ |  | ​ |
| ROU assets | ​ | ​ | (7,614) | ​ | (5,220) |
| Goodwill | ​ |  | (13,746) |  | (7,878) |
| Acquisition intangible assets | ​ |  | (62,052) |  | (52,682) |
| Depreciation, software amortization | ​ |  | (22,418) |  | (21,283) |
| Net deferred tax liabilities before valuation allowance | ​ |  | (67,899) |  | (55,498) |
| Less valuation allowance | ​ |  | (2,011) |  | (1,932) |
| Net deferred tax liabilities | ​ | $ | (69,910) |  | (57,430) |

[0001410578-21-000447:notes:120]
We had a foreign net operating loss (NOL) carryforward of $15.5 million at September 30, 2021, which reflects tax loss carryforwards in Germany, South Africa, Canada, Japan and the United Kingdom. Approximately $13.3 million of the tax loss carryforwards have no expiration date while the remaining $2.1 million will expire between 2031 and 2041. We had net foreign credit carryforwards of $0.2 million, of which all expire in 2041.We had deferred tax assets related to state NOL carryforwards of $0.5 million at September 30, 2021 which expire between 2025 and 2041. We also had net state research and other credit carryforwards of $2.6 million of which $1.9 million expires between 2022 and 2041. The remaining $0.8 million does not have an expiration date.

[0001410578-21-000447:notes:121]
The valuation allowance for deferred tax assets as of September 30, 2021 and 2020 was $2.0 million and $1.9 million, respectively. The net change in the total valuation allowance for each of the years ended September 30, 2021 and 2020 was an increase of $0.1 million and a decrease of $2.6 million, respectively.We established a valuation allowance against state credit carryforwards of $0.6 million at September 30 of both 2021 and 2020. In addition, we established a valuation allowance against state NOL carryforwards that are not expected to be realized in future periods of $0.5 million at September 30 of both 2021 and 2020, respectively. Lastly, we established a valuation allowance against certain NOL carryforwards in foreign jurisdictions which may not be realized in future periods of $0.9 million and $0.8 million at September 30, 2021 and 2020, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001410578-21-000447:notes:122]
8.      Debt

[0001410578-21-000447:notes:123]
Debt consists of the following at September 30, 2021 and 2020:

[0001410578-21-000447:notes:124]
| (Dollars in thousands) |  | 2021 |  | 2020 |
| Total borrowings | ​ | $ | 154,000 |  | 62,368 |
| Current portion of long-term debt and short-term borrowings | ​ |  | (20,000) |  | (22,368) |
| Total long-term debt, less current portion | ​ | $ | 134,000 |  | 40,000 |

[0001410578-21-000447:notes:125]
The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for an increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024.

[0001410578-21-000447:notes:126]
Interest on borrowings under the Credit Facility is calculated at a spread over either the New York Federal Reserve Bank Rate, the prime rate, or the London Interbank Offered Rate (LIBOR), depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The interest rate spreads and the facility fee are subject to increase or decrease depending on the Company's leverage ratio.

[0001410578-21-000447:notes:127]
The Credit Facility is secured by the unlimited guaranty of our direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of our direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. As of September 30, 2021, we were in compliance with all covenants.

[0001410578-21-000447:notes:128]
At September 30, 2021, we had approximately $337 million available to borrow under the Credit Facility, plus the $250 million increase option subject to the lenders’ consent, in addition to $56.2 million cash on hand. We classified $20 million as the current portion of long-term debt as of September 30, 2021, as we intend to repay this amount within the next twelve months; however, we have no contractual obligation to repay such amount during the next twelve months.

[0001410578-21-000447:notes:129]
During 2021 and 2020, our maximum aggregate short-term borrowings at any month-end were $174 million and $281 million, respectively, and the average aggregate short-term borrowings outstanding based on month-end balances were $71.3 million and $175.6 million, respectively. The weighted average interest rates were 1.20%, 3.20% and 3.21% for 2021, 2020 and 2019, respectively. As of September 30, 2021, the interest rate on our debt was 1.06%. The letters of credit issued and outstanding under the Credit Facility totaled $8.5 million and $9.9 million at September 30, 2021 and 2020, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001410578-21-000447:notes:130]
9.      Capital Stock

[0001410578-21-000447:notes:131]
The 30,666,173 and 30,645,625 common shares as presented in the accompanying Consolidated Balance Sheets at September 30, 2021 and 2020 represent the actual number of shares issued at the respective dates. We held 4,604,741and 4,607,911 common shares in treasury at September 30, 2021 and 2020, respectively.

[0001410578-21-000447:notes:132]
In August 2012, our Board of Directors approved a common stock repurchase program authorizing us to repurchase shares of our stock from time to time in Management’s discretion, in the open market or otherwise, up to a maximum total repurchase amount of $100 million (or the maximum amount permitted under our bank credit agreements, if less). After being repeatedly extended by the Company’s Board of Directors, this program expired September 30, 2021.

[0001410578-21-000447:notes:133]
In August 2021, our Board of Directors approved a new common stock repurchase program authorizing us to repurchase shares of our stock from time to time in Management’s discretion, in the open market or otherwise, up to a maximum total repurchase amount of $200 million (or the maximum amount permitted under our bank credit agreements, if less). This program is scheduled to expire September 30, 2024. We did not repurchase any shares in 2021, 2020, or 2019.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001410578-21-000447:notes:134]
10.      Share-Based Compensation

[0001410578-21-000447:notes:135]
We provide compensation benefits to certain key employees under several share-based plans providing for performance-accelerated and/or time-vested restricted stock unit awards, and to non-employee directors under a separate compensation plan for non-employee directors. As of September 30, 2021, our equity compensation plans had a total of 712,092 shares authorized and available for future issuance.

[0001410578-21-000447:notes:136]
Performance-Accelerated Restricted Stock Unit (PARS) Awards and Time-Vested Restricted Stock Unit (RSU) Awards

[0001410578-21-000447:notes:137]
A PARS award represents the right to receive a specified number of shares of Company common stock if and when the award vests. A PARS award is not stock and does not give the recipient any rights as a shareholder until it vests and is paid out in shares of stock. PARS awards currently outstanding have a five-year vesting period, with accelerated vesting if certain targets based on market conditions are achieved. In these cases, if it is probable that the performance condition will be met, the Company recognizes compensation cost on a straight-line basis over the shorter performance period; otherwise, it will recognize compensation cost over the longer service period. Compensation cost for the outstanding PARS awards is being recognized over the shorter performance period, as it is probable the performance condition will be met. The PARS award grants were valued at the stock price on the date of grant.

[0001410578-21-000447:notes:138]
The terms of the RSU awards are similar to those of the PARS awards, but without any provision for acceleration of the vesting date. Each RSU represents the right to receive one share of Company common stock if the recipient remains continuously employed by the

[0001410578-21-000447:notes:139]
Company until the award vests, in this case 3 ½ years after the effective award date. The RSU award grants were valued at the stock price on the date of grant.

[0001410578-21-000447:notes:140]
Pretax compensation expense related to the PARS/RSU awards for continuing operations was $5.6 million, $4.3 million and $4.0 million for 2021, 2020 and 2019, respectively.

[0001410578-21-000447:notes:141]
The following summary presents information regarding outstanding PARS/RSU awards as of the specified dates, and changes during the specified periods:

[0001410578-21-000447:notes:142]
| ​ | ​ | FY 2021 | ​ | FY 2020 | ​ | FY 2019 |
| ​ |  | ​ |  | Estimated |  | ​ |  | Estimated |  | ​ |  | Estimated |
| ​ | ​ | ​ | ​ | Weighted | ​ | ​ | ​ | Weighted | ​ | ​ | ​ | Weighted |
| ​ | ​ | Shares | ​ | Avg. Price | ​ | Shares | ​ | Avg. Price | ​ | Shares | ​ | Avg. Price |
| Nonvested at October 1, |  | 220,300 | ​ | $ | 66.55 |  | 281,004 | ​ | $ | 59.72 |  | 315,544 | ​ | $ | 47.23 |
| Granted |  | 51,476 | ​ |  | 108.05 |  | 45,723 | ​ |  | 74.80 |  | 84,862 | ​ |  | 74.77 |
| Vested |  | (35,753) | ​ |  | 64.40 |  | (89,822) | ​ |  | 50.51 |  | (113,402) | ​ |  | 37.00 |
| Cancelled |  | (9,318) | ​ |  | 70.50 |  | (16,605) | ​ |  | 60.48 |  | (6,000) | ​ |  | 45.20 |
| Nonvested at September 30, |  | 226,705 | ​ | $ | 76.15 |  | 220,300 | ​ | $ | 66.55 |  | 281,004 | ​ | $ | 59.72 |

[0001410578-21-000447:notes:143]
Compensation Plan for Non-Employee Directors

[0001410578-21-000447:notes:144]
In addition to an annual cash retainer, we provide each non-employee director with an annual equity award having a grant date market value of $180,000, based on the NYSE closing price of the Company’s stock on the date of grant. For calendar years prior to 2021, the award consisted of actual shares of Company stock, but beginning in January 2021, the award has been in the form of Restricted Stock Units, each of which represents the right to receive one share of Company stock at the end of a one-year vesting period. At the end of the vesting period, each award will be converted into the right to receive the same number of actual shares of common stock, plus additional shares representing the value of the quarterly dividends which would have accrued on the underlying shares during the vesting period. Compensation expense related to the non-employee director grants was $1.3 million, $1.3 million and $1.1 million for 2021, 2020 and 2019, respectively.

[0001410578-21-000447:notes:145]
Total Share-Based Compensation

[0001410578-21-000447:notes:146]
The total share-based compensation cost that has been recognized in results of operations and included within SG&A from continuing operations was $6.9 million, $5.6 million and $5.1 million for 2021, 2020 and 2019, respectively. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $1.4 million, $1.2 million and $1.1 million for 2021, 2020 and 2019, respectively. As of September 30, 2021, there was $7.9 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a weighted-average period of 1.6 years.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001410578-21-000447:notes:147]
11.      Retirement and Other Benefit Plans

[0001410578-21-000447:notes:148]
Formerly, substantially all our domestic employees were covered by a defined benefit pension plan (the Plan) maintained by the Company. The Plan was frozen in 2003 and no additional benefits have been accrued since that date. On November 14, 2019, our Board of Directors approved a resolution to terminate the Plan effective as of February 29, 2020. In connection with the termination, we contributed $25.7 million of cash to the Plan during 2020, settled approximately $32.4 million of Plan liabilities during 2020 through lump-sum payments from existing plan assets to eligible participants who elected to receive them, and recorded approximately $40.6 million of charges associated with these settlements. During 2020, we settled approximately $69.1 million of Plan liabilities by entering into an agreement to purchase annuities from a third party insurance company . This agreement covered active and former employees and their beneficiaries, with the insurance company assuming the future annuity payments for these individuals.

[0001410578-21-000447:notes:149]
Substantially all our domestic employees are covered by a defined contribution plan maintained by the Company. In addition, we offer unfunded post-retirement pre-Medicare health insurance benefits to a small number of eligible retirees and employees. We formerly provided unfunded post-retirement life insurance to qualifying retired employees who retired before 2005, but ceased providing this coverage on July 31, 2020. There was no financial impact of this plan in 2021.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001410578-21-000447:notes:150]
12.      Business Segment Information

[0001410578-21-000447:notes:151]
We are organized based on the products and services we offer, and we classify our continuing business operations in three reportable segments for financial reporting purposes:  Aerospace & Defense (A&D), Utility Solutions Group (USG) and RF Shielding and Test (Test). In addition, for reporting certain financial information we treat Corporate activities as a separate segment. The former Technical Packaging segment was divested in December 2019 and is reflected as discontinued operations for 2020.

[0001410578-21-000447:notes:152]
The A&D segment’s operations consist of PTI Technologies Inc. (PTI), VACCO Industries (VACCO), Crissair, Inc. (Crissair), Mayday Manufacturing Co. (Mayday), Hi-Tech Metals, Inc. (Hi-Tech), Westland Technologies, Inc. (Westland), and Globe Composite Solutions, LLC (Globe).The companies within this segment primarily design and manufacture specialty filtration, fluid control and naval products, including hydraulic filter elements and fluid control devices used in aerospace and defense applications, unique filter mechanisms used in micro-propulsion devices for satellites, custom designed filters for manned aircraft and submarines, products and systems to reduce vibration and/or acoustic signatures and otherwise reduce or obscure a vessel’s signature, and other communications, sealing, surface control and hydrodynamic related applications to enhance U.S. Navy maritime survivability; precision-tolerance machined components for the aerospace and defense industry; and metal processing services.

[0001410578-21-000447:notes:153]
The USG segment’s operations consist of Doble Engineering Company and related subsidiaries including Morgan Schaffer and Altanova (collectively, Doble), and NRG Systems, Inc. (NRG). Doble is an industry leader in the development, manufacture and delivery of diagnostic testing and data management solutions that enable electric power grid operators to assess the integrity of high-voltage power delivery equipment. It combines three core elements for customers – diagnostic test and condition monitoring instruments, expert consulting, and testing services – and provides access to its large reserve of related empirical knowledge. NRG is a global market leader in the design and manufacture of decision support tools for the renewable energy industry, primarily wind and solar. The recent acquisition of Altanova not only complements our existing products and services but its strong market share in Europe and Asia provides a significant international platform for our USG segment.

[0001410578-21-000447:notes:154]
The Test segment’s operations consist of ETS-Lindgren Inc. and related subsidiaries (ETS-Lindgren). ETS-Lindgren is an industry leader in designing and manufacturing products which provide its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy. It supplies its customers with a broad range of isolated environments and turnkey systems, including RF test facilities, acoustic test enclosures, RF and magnetically shielded rooms, secure communication facilities, RF measurement systems and broadcast and recording studios. Many of these facilities include proprietary features such as shielded doors and windows. ETS-Lindgren also provides the design, program management, installation and integration services required to successfully complete these types of facilities. ETS-Lindgren also supplies customers with a broad range of components including RF absorptive materials, RF filters, active compensation systems, antennas, antenna masts, turntables and electric and magnetic probes, RF test cells, proprietary measurement software and other test accessories required to perform a variety of tests. ETS-Lindgren offers a variety of services including calibration for antennas and field probes, chamber certification, field surveys, customer training and a variety of product tests. ETS-Lindgren serves the acoustics, medical, health and safety, electronics, wireless communications, automotive and defense markets.

[0001410578-21-000447:notes:155]
Accounting policies of the segments are the same as those described in the summary of significant accounting policies in Note 1 to the Consolidated Financial Statements. The operating units within each reporting segment have been aggregated because of similar economic characteristics and meet the other aggregation criteria of FASB ASC 280.

[0001410578-21-000447:notes:156]
We evaluate the performance of our operating units based on EBIT, which is defined as earnings before interest and taxes. EBIT on a consolidated basis is a non-GAAP financial measure. Intersegment sales and transfers are not significant. Segment assets consist primarily of customer receivables, inventories, capitalized software and fixed assets directly associated with the production processes of the segment. Segment depreciation and amortization is based upon the direct assets listed above. The tables below are presented on the basis of continuing operations and exclude discontinued operations.

[0001410578-21-000447:notes:157]
Net Sales

[0001410578-21-000447:notes:158]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2021 |  | 2020 |  | 2019 |
| A&D | ​ | $ | 314.8 |  | 351.9 |  | 325.7 |
| USG | ​ | ​ | 202.9 | ​ | 191.7 | ​ | 211.9 |
| Test | ​ |  | 197.7 |  | 186.9 |  | 188.4 |
| Consolidated totals | ​ | $ | 715.4 |  | 730.5 |  | 726.0 |

[0001410578-21-000447:notes:159]
No customer exceeded 10% of sales in 2021 or 2019 and one customer exceeded 10% of sales in 2020.

[0001410578-21-000447:notes:160]
EBIT

[0001410578-21-000447:notes:161]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2021 |  | 2020 |  | 2019 |
| A&D | ​ | $ | 56.5 |  | 69.9 |  | 70.1 |
| USG | ​ | ​ | 40.9 | ​ | 24.4 | ​ | 52.2 |
| Test | ​ |  | 27.6 |  | 27.2 |  | 25.6 |
| Reconciliation to consolidated totals (Corporate) | ​ |  | (42.1) |  | (78.4) |  | (41.9) |
| Consolidated EBIT | ​ |  | 82.9 |  | 43.1 |  | 106.0 |
| Less: interest expense | ​ |  | (2.2) |  | (6.7) |  | (8.1) |
| Earnings before income tax | ​ | $ | 80.7 |  | 36.4 |  | 97.9 |

[0001410578-21-000447:notes:162]
Identifiable Assets

[0001410578-21-000447:notes:163]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2021 |  | 2020 |
| A&D | ​ | $ | 270.0 |  | 276.2 |
| USG | ​ | ​ | 197.5 | ​ | 144.8 |
| Test | ​ |  | 153.6 |  | 153.0 |
| Corporate | ​ |  | 956.2 |  | 796.2 |
| Consolidated totals | ​ | $ | 1,577.3 |  | 1,370.2 |

[0001410578-21-000447:notes:164]
Corporate consists primarily of deferred taxes, acquired intangible assets including goodwill and cash balances.

[0001410578-21-000447:notes:165]
Capital Expenditures

[0001410578-21-000447:notes:166]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2021 |  | 2020 |  | 2019 |
| A&D | ​ | $ | 10.4 |  | 15.9 |  | 11.7 |
| USG | ​ | ​ | 11.6 | ​ | 12.4 | ​ | 8.5 |
| Test | ​ |  | 4.7 |  | 3.6 |  | 4.0 |
| Corporate | ​ |  | — |  | 0.2 |  | — |
| Consolidated totals | ​ | $ | 26.7 |  | 32.1 |  | 24.2 |

[0001410578-21-000447:notes:167]
In addition to the above amounts, we incurred expenditures for capitalized software of $8.8 million, $9.0 million and $8.4 million in 2021, 2020 and 2019, respectively.

[0001410578-21-000447:notes:168]
Depreciation and Amortization

[0001410578-21-000447:notes:169]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2021 |  | 2020 |  | 2019 |
| A&D | ​ | $ | 10.4 |  | 9.4 |  | 8.3 |
| USG | ​ | ​ | 13.5 | ​ | 14.4 | ​ | 11.3 |
| Test | ​ |  | 5.2 |  | 5.0 |  | 5.1 |
| Corporate | ​ |  | 12.9 |  | 12.5 |  | 11.3 |
| Consolidated totals | ​ | $ | 42.0 |  | 41.3 |  | 36.0 |

[0001410578-21-000447:notes:170]
Depreciation expense of property, plant and equipment was $21.2 million, $19.5 million and $16.5 million for 2021, 2020 and 2019, respectively.

[0001410578-21-000447:notes:171]
Geographic Information

[0001410578-21-000447:notes:172]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2021 |  | 2020 |  | 2019 |
| United States | ​ | $ | 517.0 |  | 529.4 |  | 537.2 |
| Asia | ​ |  | 92.3 |  | 96.3 |  | 86.2 |
| Europe | ​ |  | 53.5 |  | 51.3 |  | 45.0 |
| Canada | ​ |  | 27.0 |  | 31.7 |  | 33.0 |
| India | ​ |  | 12.4 |  | 10.3 |  | 11.7 |
| Other | ​ |  | 13.2 |  | 11.5 |  | 12.9 |
| Consolidated totals | ​ | $ | 715.4 |  | 730.5 |  | 726.0 |

[0001410578-21-000447:notes:173]
Long-Lived Assets

[0001410578-21-000447:notes:174]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2021 |  | 2020 |
| United States | ​ | $ | 141.0 |  | 131.5 |
| Mexico | ​ |  | 3.8 |  | 3.1 |
| Other | ​ |  | 9.5 |  | 5.3 |
| Consolidated totals | ​ | $ | 154.3 |  | 139.9 |

[0001410578-21-000447:notes:175]
We attribute net sales to countries based on the location of the customer. We attribute long-lived assets to countries based on the location of the asset.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001410578-21-000447:notes:176]
13.      Commitments and Contingencies

[0001410578-21-000447:notes:177]
At September 30, 2021, we had $8.5 million in letters of credit outstanding as guarantees of contract performance. The Company also had a commitment to purchase the NRG building for approximately $10 million, which closed in the first quarter of fiscal 2022. As a normal incident of the businesses in which we are engaged, various claims, charges and litigation are asserted or commenced from time to time against us. Additionally, we are currently involved in various stages of investigation and remediation relating to environmental matters. It is the opinion of Management that the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against us are adequately accrued, are covered by insurance or are not likely to have a material adverse effect on our financial results as the estimated exposure to loss is not material.


## ese:OperatingAndFinancingLeasesOfLesseeDisclosureTextBlock

[0001410578-21-000447:notes:178]
14.      Leases

[0001410578-21-000447:notes:179]
Effective October 1, 2019 we adopted ASC 842, Leases. We determine at lease inception whether an arrangement that provides control over the use of an asset is a lease. We recognize at lease commencement a right-of-use (ROU) asset and lease liability based on the present value of the future lease payments over the lease term. We have elected not to recognize a ROU asset and lease liability for leases with terms of 12 months or less. Certain of our leases include options to extend the term of the lease for up to 20 years.

[0001410578-21-000447:notes:180]
When it is reasonably certain that we will exercise the option, Management includes the impact of the option in the lease term for purposes of determining total future lease payments. As most of our lease agreements do not explicitly state the discount rate implicit in the lease, Management uses our incremental borrowing rate on the commencement date to calculate the present value of future payments based on the tenor of each arrangement.

[0001410578-21-000447:notes:181]
Our leases for real estate commonly include escalating payments. We include these variable lease payments in the calculation of our ROU asset and lease liability. In addition to the present value of the future lease payments, the calculation of the ROU asset also includes any deferred rent, lease pre-payments and initial direct costs of obtaining the lease.

[0001410578-21-000447:notes:182]
In addition to the base rent, real estate leases typically contain provisions for common-area maintenance and other similar services, which are considered non-lease components for accounting purposes. Non-lease components are excluded from our ROU assets and lease liabilities and expensed as incurred.

[0001410578-21-000447:notes:183]
Our leases are for office space, manufacturing facilities, and machinery and equipment.

[0001410578-21-000447:notes:184]
The components of lease costs are shown below:

[0001410578-21-000447:notes:185]
| ​ | ​ | Year Ended |  | Year Ended |
| ​ | ​ | September 30, | ​ | September 30, |
| (Dollars in thousands) |  | 2021 |  | 2020 |
| Finance lease cost: |  | ​ |  | ​ | ​ | ​ |
| Amortization | ​ | $ | 2,413 | ​ | $ | 2,056 |
| Interest on lease liabilities | ​ |  | 1,235 | ​ | ​ | 971 |
| Operating lease cost | ​ |  | 5,879 | ​ | ​ | 5,284 |
| Total lease cost | ​ | $ | 9,527 | ​ | $ | 8,311 |

[0001410578-21-000447:notes:186]
Additional information related to leases is shown below:

[0001410578-21-000447:notes:187]
| ​ |  | Year Ended |  | Year Ended |  |
| ​ | ​ | September 30, | ​ | September 30, | ​ |
| (Dollars in thousands) | ​ | 2021 | ​ | 2020 | ​ |
| Cash paid for amounts included in the measurement of lease liabilities: | ​ | ​ | ​ |  | ​ |  |  |
| Operating cash flows from operating leases | ​ | $ | 5,504 | ​ | $ | 5,223 |  |
| Operating cash flows from finance leases | ​ | ​ | 1,228 | ​ |  | 971 |  |
| Financing cash flows from finance leases | ​ | ​ | 1,757 | ​ |  | 1,547 |  |
| Right-of-use assets obtained in exchange for operating lease liabilities | ​ | $ | 15,609 | ​ | $ | 26,244 |  |
| Weighted-average remaining lease term: | ​ | ​ | ​ | ​ |  |  |  |
| Operating leases | ​ | ​ | 10.3 | yrs. |  | 6.0 | yrs. |
| Finance leases | ​ | ​ | 11.7 | yrs. |  | 12.5 | yrs. |
| Weighted-average discount rate: | ​ | ​ | ​ | ​ |  |  |  |
| Operating leases | ​ | ​ | 3.1 | % |  | 3.1 | % |
| Finance leases | ​ | ​ | 4.2 | % |  | 4.3 | % |

[0001410578-21-000447:notes:188]
The table below is a reconciliation of future undiscounted cash flows to the operating and finance lease liabilities, and the related ROU assets, presented on our Consolidated Balance Sheet on September 30, 2021:

[0001410578-21-000447:notes:189]
| (Dollars in thousands) |  | Operating |  | Finance |
| Years Ending September 30: | ​ | Leases | ​ | Leases |
| 2022 | ​ | $ | 5,448 |  | 3,153 |
| 2023 | ​ |  | 4,679 |  | 3,235 |
| 2024 | ​ |  | 4,032 |  | 3,319 |
| 2025 | ​ |  | 3,654 |  | 3,399 |
| 2026 and thereafter | ​ |  | 20,453 |  | 25,516 |
| Total minimum lease payments | ​ | ​ | 38,266 |  | 38,622 |
| Less: amounts representing interest | ​ |  | 5,691 |  | 9,092 |
| Present value of net minimum lease payments | ​ | $ | 32,575 |  | 29,530 |
| Less: current portion of lease obligations | ​ |  | 4,543 |  | 2,180 |
| Non-current portion of lease obligations | ​ |  | 28,032 |  | 27,350 |
| ROU assets | ​ | $ | 31,846 | ​ | 24,964 |

[0001410578-21-000447:notes:190]
The table below is a reconciliation of future undiscounted cash flows to the operating and finance lease liabilities, and the related ROU assets, presented on our Consolidated Balance Sheet on September 30, 2020:

[0001410578-21-000447:notes:191]
| (Dollars in thousands) | ​ | Operating | ​ | Finance | ​ |
| Years Ending September 30: |  | Leases |  | Leases |  |
| 2021 | ​ | $ | 5,614 | ​ | ​ | 2,930 | ​ |
| 2022 | ​ |  | 4,985 | ​ | ​ | 3,011 | ​ |
| 2023 | ​ |  | 3,984 | ​ | ​ | 3,094 | ​ |
| 2024 | ​ |  | 2,438 | ​ | ​ | 3,177 | ​ |
| 2025 and thereafter | ​ |  | 6,984 | ​ | ​ | 28,323 | ​ |
| Total minimum lease payments | ​ | ​ | 24,005 | ​ | ​ | 40,535 | ​ |
| Less: amounts representing interest | ​ |  | 2,211 | ​ | ​ | 10,270 | ​ |
| Present value of net minimum lease payments | ​ | $ | 21,794 | ​ | ​ | 30,265 | ​ |
| Less: current portion of lease obligations | ​ |  | 5,009 | ​ | ​ | 1,937 | ​ |
| Non-current portion of lease obligations | ​ | ​ | 16,785 | ​ | ​ | 28,328 | ​ |
| ROU assets | ​ | $ | 21,390 | ​ | ​ | 26,164 | ​ |

[0001410578-21-000447:notes:192]
We include operating and finance lease liabilities in the Consolidated Balance Sheet in accrued other expenses (current portion) and other liabilities (long-term portion). We include operating lease ROU assets as a caption on the Consolidated Balance Sheet and include finance lease ROU assets in Property, plant and equipment on the Consolidated Balance Sheet.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001410578-21-000447:notes:193]
15.     Revenues

[0001410578-21-000447:notes:194]
| (a) | Disaggregation of Revenues |

[0001410578-21-000447:notes:195]
The tables below present our revenues by customer type, geographic location, and revenue recognition method for the years ended September 30, 2021 and 2020, as we believe this presentation best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables also include a reconciliation of the disaggregated revenue within our reportable segments.

[0001410578-21-000447:notes:196]
| Year Ended September 30, 2021 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 130,217 | ​ |  | 199,111 | ​ |  | 177,601 | ​ |  | 506,929 |
| Government | ​ | ​ | 184,607 | ​ | ​ | 3,797 | ​ | ​ | 20,107 | ​ | ​ | 208,511 |
| Total revenues | ​ | $ | 314,824 | ​ | ​ | 202,908 | ​ | ​ | 197,708 | ​ | ​ | 715,440 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 275,976 | ​ |  | 140,545 | ​ |  | 100,438 | ​ |  | 516,959 |
| International | ​ | ​ | 38,848 | ​ | ​ | 62,363 | ​ | ​ | 97,270 | ​ | ​ | 198,481 |
| Total revenues | ​ | $ | 314,824 | ​ | ​ | 202,908 | ​ | ​ | 197,708 | ​ | ​ | 715,440 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 136,449 | ​ |  | 153,163 | ​ |  | 40,609 | ​ |  | 330,221 |
| Over time | ​ | ​ | 178,375 | ​ | ​ | 49,745 | ​ | ​ | 157,099 | ​ | ​ | 385,219 |
| Total revenues | ​ | $ | 314,824 | ​ | ​ | 202,908 | ​ | ​ | 197,708 | ​ | ​ | 715,440 |

[0001410578-21-000447:notes:197]
| Year Ended September 30, 2020 | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  |
| (In thousands) | ​ | A&D |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 169,484 | ​ | ​ | 184,906 | ​ | ​ | 158,420 | ​ | ​ | 512,810 |
| Government | ​ |  | 182,392 | ​ |  | 6,797 | ​ |  | 28,472 | ​ |  | 217,661 |
| Total revenues | ​ | $ | 351,876 | ​ | ​ | 191,703 | ​ | ​ | 186,892 | ​ | ​ | 730,471 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 302,711 | ​ | ​ | 134,601 | ​ | ​ | 92,105 | ​ | ​ | 529,417 |
| International | ​ |  | 49,165 | ​ |  | 57,102 | ​ |  | 94,787 | ​ |  | 201,054 |
| Total revenues | ​ | $ | 351,876 | ​ | ​ | 191,703 | ​ | ​ | 186,892 | ​ | ​ | 730,471 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 160,402 | ​ | ​ | 144,192 | ​ | ​ | 33,482 | ​ | ​ | 338,076 |
| Over time | ​ |  | 191,474 | ​ |  | 47,511 | ​ |  | 153,410 | ​ |  | 392,395 |
| Total revenues | ​ | $ | 351,876 | ​ | ​ | 191,703 | ​ | ​ | 186,892 | ​ | ​ | 730,471 |

[0001410578-21-000447:notes:198]
| (b) | Remaining Performance Obligations |

[0001410578-21-000447:notes:199]
Our remaining performance obligations, which is the equivalent of our backlog, represent the expected transaction price allocated to our contracts that we expect to recognize as revenue in future periods when we perform under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At September 30, 2021, we had $592 million in remaining performance obligations of which we expect to recognize revenues of 75% in the next twelve months.

[0001410578-21-000447:notes:200]
| (c) | Contract assets and contract liabilities |

[0001410578-21-000447:notes:201]
We report assets and liabilities related to our contracts with customers on a contract-by-contract basis at the end of each reporting period. At September 30, 2021, our contract assets and contract liabilities totaled $93.8 million and $108.8 million, respectively. During 2021, we recognized approximately $82 million in revenues that were included in the contract liabilities balance at September 30, 2020.
