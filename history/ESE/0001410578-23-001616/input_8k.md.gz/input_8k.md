# ESE 8-K — 0001104659-23-088847 filed 2023-08-08

## item codes, every 8-K on or before 2023-08-09

- 2023-08-08 0001104659-23-088847 — 2.02, 7.01, 9.01
- 2023-07-06 0001104659-23-078571 — 5.02, 8.01, 9.01
- 2023-05-09 0001104659-23-057736 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2023-05-05 0001104659-23-056387 — 5.02, 9.01
- 2023-02-08 0001104659-23-014539 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2023-01-06 0001104659-23-001859 — 5.02, 9.01
- 2022-11-22 0001104659-22-121229 — 5.02, 5.03, 8.01, 9.01
- 2022-11-17 0001104659-22-119898 — 2.02, 7.01, 9.01
- 2022-09-12 0001104659-22-099248 — 5.02, 7.01, 9.01
- 2022-08-08 0001104659-22-087247 — 2.02, 5.02, 7.01, 9.01
- 2022-05-09 0001104659-22-057524 — 2.02, 5.02, 7.01, 9.01
- 2022-02-08 0001104659-22-013878 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2021-12-03 0001104659-21-146361 — 4.01, 9.01 — amendment, the index does not say of what
- 2021-11-24 0001104659-21-143568 — 4.01, 9.01
- 2021-11-23 0001104659-21-142871 — 5.02, 8.01
- 2021-11-18 0001104659-21-141206 — 2.02, 7.01, 9.01
- 2021-08-09 0001104659-21-102150 — 2.02, 7.01, 9.01
- 2021-05-04 0001104659-21-060985 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2021-04-05 0001104659-21-046581 — 5.02, 9.01
- 2021-02-08 0001104659-21-013712 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2020-12-09 0001104659-20-133674 — 5.02, 9.01
- 2020-12-07 0001104659-20-132861 — 5.02, 7.01, 9.01
- 2020-11-19 0001104659-20-127352 — 2.02, 5.02, 7.01, 9.01
- 2020-08-10 0001104659-20-092734 — 2.02, 7.01, 9.01
- 2020-05-06 0001104659-20-057442 — 2.02, 7.01, 8.01, 9.01
- 2020-02-04 0001104659-20-010640 — 2.02, 5.07, 7.01, 9.01
- 2020-01-07 0001104659-20-001789 — 2.01, 9.01
- 2019-11-19 0001104659-19-065437 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2019-11-18 0001104659-19-065096 — 1.01, 2.02, 7.01, 9.01
- 2019-09-30 0001144204-19-046523 — 1.01, 1.02, 2.03, 9.01
- 2019-08-08 0001144204-19-038567 — 2.02, 7.01, 9.01
- 2019-05-07 0001144204-19-024241 — 2.02, 5.02, 7.01, 9.01
- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2023-08-09

- none on or before 2023-08-09

## item 2.02 — earnings release, exhibit 99.1

[0001104659-23-088847:8k_2_02:1]
EX-99.1
2
tm2322840d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-23-088847:8k_2_02:2]
Exhibit 99.1

[0001104659-23-088847:8k_2_02:3]
| NEWS FROM |  |

[0001104659-23-088847:8k_2_02:4]
For more information contact:

[0001104659-23-088847:8k_2_02:5]
Kate Lowrey
- VP of Investor Relations

[0001104659-23-088847:8k_2_02:6]
(314) 213-7277
/ klowrey@escotechnologies.com

[0001104659-23-088847:8k_2_02:7]
ESCO
REPORTS THIRD QUARTER FISCAL 2023 RESULTS

[0001104659-23-088847:8k_2_02:8]
- Q3 GAAP EPS $1.08 / Adjusted EPS $1.09
-

[0001104659-23-088847:8k_2_02:9]
- Q3 Sales increase 14% to $249 Million –

[0001104659-23-088847:8k_2_02:10]
ST. LOUIS, August 8, 2023 – ESCO Technologies Inc. (NYSE:
ESE) (ESCO, or the Company) today reported its operating results for the third quarter ended June 30, 2023 (Q3 2023).

[0001104659-23-088847:8k_2_02:11]
Operating
Highlights

[0001104659-23-088847:8k_2_02:12]
|  | · | Q3 2023 GAAP EPS increased 21 percent to $1.08 per share compared to $0.89 per share in Q3 2022. Q3 2023 Adjusted EPS increased 22 percent to $1.09 per share compared to $0.89 per share in Q3 2022. |

[0001104659-23-088847:8k_2_02:13]
|  | · | Q3 2023 Sales increased $29.6 million (13.5 percent) to $248.7 million compared to $219.1 million in Q3 2022. |

[0001104659-23-088847:8k_2_02:14]
|  | · | Q3 2023 Entered Orders decreased $41.6 million (16 percent) versus the prior year period to $213.3 million (book-to-bill of 0.86x), resulting in ending backlog of $705 million. Continuing strength in commercial aerospace, utilities and renewables orders were more than offset by timing related to a few large orders in Q3 2022 that did not repeat. |

[0001104659-23-088847:8k_2_02:15]
|  | · | Net cash provided by operating activities was $29 million YTD 2023. Cash flow improved in the quarter but was negatively impacted by higher working capital requirements (higher accounts receivable related to increased sales and higher inventory related to timing and supply chain issues), along with higher interest and tax payments compared to the prior year. |

[0001104659-23-088847:8k_2_02:16]
|  | · | Net debt (total borrowings less cash on hand) was $92 million, resulting in a 0.71x leverage ratio and $595 million in liquidity at June 30, 2023. |

[0001104659-23-088847:8k_2_02:17]
Bryan
Sayler, Chief Executive Officer and President, commented, “Q3 was another strong quarter with a number of positive
developments. Sales increased 14 percent on the strength of continuing momentum in our aerospace, utility, and renewables
end-markets. A&D and USG both again delivered double digit revenue growth and our Adjusted EBIT and Adjusted EPS both increased
over 20 percent compared to the prior year. We delivered 130 basis points of Adjusted EBIT margin improvement, driven by leverage on
aerospace and USG revenue growth, and at Test where we did a great job delivering higher margins on lower sales.

[0001104659-23-088847:8k_2_02:18]
“My transition to the CEO role has gone very well. The quality
of our businesses continues to shine and it’s a pleasure to work with such a talented team. We have a committed group of
employees that work diligently to drive growth and deliver solid operating results for our company and our shareholders. I want to thank
our employees for their dedication as we all work and grow together as a team.”

[0001104659-23-088847:8k_2_02:19]
Segment Performance

[0001104659-23-088847:8k_2_02:20]
Aerospace & Defense (A&D)

[0001104659-23-088847:8k_2_02:21]
|  | · | Sales increased $10.9 million (12 percent) to $103.5 million in Q3 2023 from $92.6 million in Q3 2022. Sales growth was driven by commercial and defense aerospace, partially offset by lower Navy and space sales in the quarter. Commercial aerospace increased $7.6 million (24 percent) and defense aerospace increased $6.7 million (54 percent) in the quarter. |

[0001104659-23-088847:8k_2_02:22]
|  | · | Q3 2023 EBIT increased $1.0 million to $21.7 million (20.9 percent margin) from $20.7 million (22.4 percent margin) in Q3 2022. There were no adjustments to earnings in either period. The Q3 margin was negatively impacted by lower space and Navy volume and margin erosion on certain space development contracts, which more than offset leverage on aerospace growth in the quarter. |

[0001104659-23-088847:8k_2_02:23]
|  | · | Entered Orders decreased $28 million (26 percent) to $82 million in Q3 2023 compared to $110 million in Q3 2022. The decrease was primarily driven by a $30 million space order (SLS long lead material) that occurred in Q3 2022. Aerospace order strength continued but was mostly offset by a shift in the timing of Virginia Class submarine orders to later in the year. Ending backlog of $414 million has increased $5 million compared to the prior year end. |

[0001104659-23-088847:8k_2_02:24]
Utility Solutions Group (USG)

[0001104659-23-088847:8k_2_02:25]
|  | · | Sales increased $22.8 million (34 percent) to $90.0 million in Q3 2023 from $67.2 million in Q3 2022. Doble’s sales increased by $17.6 million (32 percent) driven by a strong quarter for services, offline testing, protection testing and condition monitoring. NRG sales increased $5.2 million (45 percent) on continued broad strength across the renewables end-market. |

[0001104659-23-088847:8k_2_02:26]
|  | · | EBIT increased $7.3 million in Q3 2023 to $20.4 million from $13.1 million in Q3 2022. Adjusted EBIT increased $7.4 million (56 percent) in Q3 2023 to $20.5 million (22.8 percent margin) from $13.1 million (19.5 percent margin) in Q3 2022. Margins were favorably impacted by leverage on higher revenue and price increases, partially offset by the impacts of wage and material cost inflation and increased commissions, travel, and tradeshow expenses. |

[0001104659-23-088847:8k_2_02:27]
|  | · | Entered Orders increased $11 million (15 percent) to $86 million in Q3 2023. Doble orders increased by $2 million (3 percent) and NRG orders increased by $9 million (67 percent). The strength in renewables orders was driven by continuing momentum in wind and solar project pipelines. Ending backlog of $138 million has increased $10 million compared to the prior year end. |

[0001104659-23-088847:8k_2_02:28]
Test

[0001104659-23-088847:8k_2_02:29]
|  | · | Sales decreased $4.0 million (7 percent) to $55.3 million in Q3 2023 from $59.3 million in Q3 2022. Lower test and measurement volume in China and the U.S and lower filter sales domestically were partially offset by a strong quarter in EMEA and increased service revenue. |

[0001104659-23-088847:8k_2_02:30]
|  | · | EBIT increased $0.2 million in Q3 2023 to $8.6 million (15.6 percent margin) from $8.4 million (14.1 percent margin) in Q3 2022. There were no adjustments in either period. The Q3 margin improvement was driven by price increases and cost reduction efforts, which more than offset the impact of lower volume and wage and material cost inflation. |

[0001104659-23-088847:8k_2_02:31]
|  | · | Entered Orders decreased $24.4 million to $45.9 million in Q3 2023 compared to $70.3 million in Q3 2022. The decrease was primarily due to several large test and measurement orders booked in Q3 2022, and lower test and measurement orders in China related to the resurgence of COVID earlier this year. Ending backlog of $153 million has decreased $5 million compared to the prior year end. |

[0001104659-23-088847:8k_2_02:32]
Share Repurchase Program

[0001104659-23-088847:8k_2_02:33]
During Q3 2023, the Company repurchased approximately 2,000 shares
for $0.2 million. Year-to-date, the company has repurchased approximately 140,000 shares for $12.4 million.

[0001104659-23-088847:8k_2_02:34]
Dividend
Payment

[0001104659-23-088847:8k_2_02:35]
The next quarterly
cash dividend of $0.08 per share will be paid on October 17, 2023 to stockholders of record on October 3, 2023.

[0001104659-23-088847:8k_2_02:36]
Business
Outlook – 2023

[0001104659-23-088847:8k_2_02:37]
On the strength of our results year-to-date and our expectations for
the fourth quarter, we are again raising our full year earnings guidance. We expect Q4 Adjusted EPS in the range of $1.17 to $1.23 which
results in Adjusted 2023 EPS in the range of $3.62 to $3.68 (13 to 15 percent growth). This is based on sales in a range of $940 to $950
million (10 to 11 percent annual growth).

[0001104659-23-088847:8k_2_02:38]
Conference Call

[0001104659-23-088847:8k_2_02:39]
The Company will host a conference call today, August 8, at 4:00
p.m. Central Time, to discuss the Company’s Q3 2023 results. A live audio webcast and an accompanying slide presentation will
be available on ESCO’s investor website at https://investor.escotechnologies.com. For those
unable to participate, a webcast replay will be available after the call on ESCO’s investor website.

[0001104659-23-088847:8k_2_02:40]
Forward-Looking Statements

[0001104659-23-088847:8k_2_02:41]
Investors
are cautioned that such statements are only predictions and speak only as of the date of this release, and the Company undertakes no duty
to update them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ
materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations
and business environment including but not limited to those described in Item 1A, “Risk Factors”, of the Company’s Annual
Report on Form 10-K for the fiscal year ended September 30, 2022; the effects of a resurgence of the COVID-19 pandemic,
or the emergence of another pandemic, including labor shortages, facility closures, shelter in place policies or quarantines, material
shortages, transportation delays, termination or delays of Company contracts, and the inability of our suppliers or customers to perform;
the impacts of climate change and related regulation of greenhouse gases; the impacts of natural disasters on the Company’s operations
and those of the Company’s customers and suppliers; the timing and content of future contract awards or customer orders; the appropriation,
allocation and availability of Government funds; the termination for convenience of Government and other customer contracts or orders;
weakening of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer
insolvencies; competition; intellectual property rights; technical difficulties; the success of the Company’s acquisition efforts;
delivery delays or defaults by customers; performance issues with key customers, suppliers and subcontractors; changes in the costs and
availability of certain raw materials; labor disputes; changes in U.S. tax laws and regulations; other changes in laws and regulations
including but not limited to changes in accounting standards and foreign taxation; changes in interest rates; costs relating to environmental
matters arising from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation
or arbitration; and the integration of recently acquired businesses.

[0001104659-23-088847:8k_2_02:42]
Non-GAAP Financial Measures

[0001104659-23-088847:8k_2_02:43]
The financial measures EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA
and Adjusted EPS are presented in this press release. The Company defines “EBIT” as earnings before interest and taxes, “EBITDA”
as earnings before interest, taxes, depreciation and amortization, “Adjusted EBIT” and “Adjusted EBITDA” as excluding
the net impact of the items described in the attached Reconciliation of Non-GAAP Financial Measures, and “Adjusted EPS” as
GAAP earnings per share (EPS) excluding the net impact of the items described and reconciled in the attached Reconciliation of Non-GAAP
Financial Measures.

[0001104659-23-088847:8k_2_02:44]
EBIT, Adjusted
EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP).
However, Management believes EBIT, Adjusted EBIT, EBITDA and Adjusted EBITDA are useful in assessing the operational profitability of
the Company’s business segments because they exclude interest, taxes, depreciation and amortization, which are generally accounted
for across the entire Company on a consolidated basis. EBIT and EBITDA are also measures used by Management in determining resource allocations
within the Company as well as incentive compensation. The presentation of EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS
provides important supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP
financial measures to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures
of performance determined in accordance with GAAP.

[0001104659-23-088847:8k_2_02:45]
About ESCO Technologies

[0001104659-23-088847:8k_2_02:46]
ESCO is a
global provider of highly engineered products and solutions serving diverse end-markets. It manufactures filtration and fluid control
products for the aviation, Navy, space, and process markets worldwide and composite-based products and solutions for Navy, defense, and
industrial customers. ESCO is the industry leader in RF shielding and EMC test products; and provides diagnostic instruments, software
and services to industrial power users and the electric utility and renewable energy industries. Headquartered in St. Louis, Missouri,
ESCO and its subsidiaries have offices and manufacturing facilities worldwide. For more information on ESCO and its subsidiaries, visit
the Company’s website at www.escotechnologies.com.

[0001104659-23-088847:8k_2_02:47]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-23-088847:8k_2_02:48]
Condensed
Consolidated Statements of Operations (Unaudited)

[0001104659-23-088847:8k_2_02:49]
(Dollars in thousands, except per share amounts)

[0001104659-23-088847:8k_2_02:50]
|  |  | Three Months Ended June 30, 2023 |  |  | Three Months Ended June 30, 2022 |  |
| Net Sales |  | $ | 248,749 |  |  |  | 219,066 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 147,274 |  |  |  | 134,454 |  |
| Selling, general and administrative expenses |  |  | 55,376 |  |  |  | 47,479 |  |
| Amortization of intangible assets |  |  | 7,132 |  |  |  | 6,406 |  |
| Interest expense |  |  | 2,495 |  |  |  | 1,331 |  |
| Other expenses (income), net |  |  | 966 |  |  |  | (106 | ) |
| Total costs and expenses |  |  | 213,243 |  |  |  | 189,564 |  |
| Earnings before income taxes |  |  | 35,506 |  |  |  | 29,502 |  |
| Income tax expense |  |  | 7,563 |  |  |  | 6,329 |  |
| Net earnings |  | $ | 27,943 |  |  |  | 23,173 |  |
| Diluted - GAAP |  | $ | 1.08 |  |  |  | 0.89 |  |
| Diluted - As Adjusted Basis |  | $ | 1.09 | (1) |  |  | 0.89 |  |
| Diluted average common shares O/S: |  |  | 25,827 |  |  |  | 25,950 |  |

[0001104659-23-088847:8k_2_02:51]
| (1) | Q3 2023 Adjusted EPS excludes $0.01 per share of after-tax charges consisting mainly of Corporate acquisition related costs. |

[0001104659-23-088847:8k_2_02:52]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-23-088847:8k_2_02:53]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-23-088847:8k_2_02:54]
(Dollars in thousands, except per share amounts)

[0001104659-23-088847:8k_2_02:55]
|  |  | Nine Months Ended June 30, 2023 |  |  | Nine Months Ended June 30, 2022 |  |
| Net Sales |  | $ | 683,386 |  |  |  | 601,004 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 415,953 |  |  |  | 371,134 |  |
| Selling, general and administrative expenses |  |  | 160,555 |  |  |  | 142,073 |  |
| Amortization of intangible assets |  |  | 21,023 |  |  |  | 19,383 |  |
| Interest expense |  |  | 6,422 |  |  |  | 3,084 |  |
| Other expenses (income), net |  |  | 1,678 |  |  |  | (677 | ) |
| Total costs and expenses |  |  | 605,631 |  |  |  | 534,997 |  |
| Earnings before income taxes |  |  | 77,755 |  |  |  | 66,007 |  |
| Income tax expense |  |  | 17,207 |  |  |  | 14,727 |  |
| Net earnings |  | $ | 60,548 |  |  |  | 51,280 |  |
| Diluted - GAAP |  | $ | 2.34 |  |  |  | 1.97 |  |
| Diluted - As Adjusted Basis |  | $ | 2.45 | (1) |  |  | 2.00 | (2) |
| Diluted average common shares O/S: |  |  | 25,890 |  |  |  | 26,050 |  |

[0001104659-23-088847:8k_2_02:56]
| (1) | YTD Q3 2023 Adjusted EPS excludes $0.11 per share of after-tax charges consisting of $0.06 of executive management transition costs at Corporate, $0.02 of CMT acquisition inventory step-up charges, $0.02 of restructuring charges within the A&D segment and $0.01 of Corporate acquisition related costs. |
| (2) | YTD Q3 2022 Adjusted EPS excludes $0.03 per share of after-tax charges associated with the Altanova & NEco acquisition inventory step-up charges and Corporate acquisition related costs. |

[0001104659-23-088847:8k_2_02:57]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-23-088847:8k_2_02:58]
Condensed Business Segment Information (Unaudited)

[0001104659-23-088847:8k_2_02:59]
(Dollars in thousands)

[0001104659-23-088847:8k_2_02:60]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | Q3 2023 |  |  | Q3 2022 |  |  | Q3 2023 |  |  | Q3 2022 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 103,469 |  |  |  | 92,606 |  |  |  | 103,469 |  |  |  | 92,606 |  |
| USG |  |  | 89,966 |  |  |  | 67,201 |  |  |  | 89,966 |  |  |  | 67,201 |  |
| Test |  |  | 55,314 |  |  |  | 59,259 |  |  |  | 55,314 |  |  |  | 59,259 |  |
| Totals |  | $ | 248,749 |  |  |  | 219,066 |  |  |  | 248,749 |  |  |  | 219,066 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 21,665 |  |  |  | 20,738 |  |  |  | 21,665 |  |  |  | 20,738 |  |
| USG |  |  | 20,351 |  |  |  | 13,135 |  |  |  | 20,481 |  |  |  | 13,135 |  |
| Test |  |  | 8,643 |  |  |  | 8,354 |  |  |  | 8,643 |  |  |  | 8,354 |  |
| Corporate |  |  | (12,658 | ) |  |  | (11,394 | ) |  |  | (12,438 | ) |  |  | (11,394 | ) |
| Consolidated EBIT |  |  | 38,001 |  |  |  | 30,833 |  |  |  | 38,351 |  |  |  | 30,833 |  |
| Less: Interest expense |  |  | (2,495 | ) |  |  | (1,331 | ) |  |  | (2,495 | ) |  |  | (1,331 | ) |
| Less: Income tax expense |  |  | (7,563 | ) |  |  | (6,329 | ) |  |  | (7,643 | ) |  |  | (6,329 | ) |
| Net earnings |  | $ | 27,943 |  |  |  | 23,173 |  |  |  | 28,213 |  |  |  | 23,173 |  |

[0001104659-23-088847:8k_2_02:61]
Note
1: Adjusted net earnings of $28.2 million in Q3 2023 exclude $0.01 per share of after-tax charges consisting mainly of
Corporate acquisition related costs.

[0001104659-23-088847:8k_2_02:62]
| EBITDA Reconciliation to Net earnings: |  |  |  |  | Q3 2023 - |  |  | Q3 2022 - |  |
|  |  | Q3 2023 |  |  | Q3 2022 |  |  | As Adj |  |  | As Adj |  |
| Consolidated EBITDA |  | $ | 50,790 |  |  |  | 42,788 |  |  |  | 51,140 |  |  |  | 42,788 |  |
| Less: Depr & Amort |  |  | (12,789 | ) |  |  | (11,955 | ) |  |  | (12,789 | ) |  |  | (11,955 | ) |
| Consolidated EBIT |  |  | 38,001 |  |  |  | 30,833 |  |  |  | 38,351 |  |  |  | 30,833 |  |
| Less: Interest expense |  |  | (2,495 | ) |  |  | (1,331 | ) |  |  | (2,495 | ) |  |  | (1,331 | ) |
| Less: Income tax expense |  |  | (7,563 | ) |  |  | (6,329 | ) |  |  | (7,643 | ) |  |  | (6,329 | ) |
| Net earnings |  | $ | 27,943 |  |  |  | 23,173 |  |  |  | 28,213 |  |  |  | 23,173 |  |

[0001104659-23-088847:8k_2_02:63]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-23-088847:8k_2_02:64]
Condensed Business Segment Information (Unaudited)

[0001104659-23-088847:8k_2_02:65]
(Dollars in thousands)

[0001104659-23-088847:8k_2_02:66]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | YTD Q3 2023 |  |  | YTD Q3 2022 |  |  | YTD Q3 2023 |  |  | YTD Q3 2022 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 285,434 |  |  |  | 247,671 |  |  |  | 285,434 |  |  |  | 247,671 |  |
| USG |  |  | 240,172 |  |  |  | 194,877 |  |  |  | 240,172 |  |  |  | 194,877 |  |
| Test |  |  | 157,780 |  |  |  | 158,456 |  |  |  | 157,780 |  |  |  | 158,456 |  |
| Totals |  | $ | 683,386 |  |  |  | 601,004 |  |  |  | 683,386 |  |  |  | 601,004 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 52,996 |  |  |  | 45,042 |  |  |  | 53,995 |  |  |  | 45,377 |  |
| USG |  |  | 50,543 |  |  |  | 37,840 |  |  |  | 50,673 |  |  |  | 38,307 |  |
| Test |  |  | 21,280 |  |  |  | 20,813 |  |  |  | 21,280 |  |  |  | 20,813 |  |
| Corporate |  |  | (40,642 | ) |  |  | (34,604 | ) |  |  | (38,129 | ) |  |  | (34,299 | ) |
| Consolidated EBIT |  |  | 84,177 |  |  |  | 69,091 |  |  |  | 87,819 |  |  |  | 70,198 |  |
| Less: Interest expense |  |  | (6,422 | ) |  |  | (3,084 | ) |  |  | (6,422 | ) |  |  | (3,084 | ) |
| Less: Income tax expense |  |  | (17,207 | ) |  |  | (14,727 | ) |  |  | (18,045 | ) |  |  | (14,982 | ) |
| Net earnings |  | $ | 60,548 |  |  |  | 51,280 |  |  |  | 63,352 |  |  |  | 52,132 |  |

[0001104659-23-088847:8k_2_02:67]
Note
1: Adjusted net earnings of $63.4 million in YTD Q3 2023 exclude $0.11 per share of after-tax charges consisting of $0.06 of
executive management transition costs at Corporate, $0.02 of CMT acquisition inventory step-up charges, $0.02 of restructuring
charges within the A&D segment and $0.01 of Corporate acquisition related costs.

[0001104659-23-088847:8k_2_02:68]
Note
2: Adjusted net earnings of $52.1 million in YTD Q3 2022 exclude $0.03 per share of after-tax charges associated with the
Altanova & NEco acquisition inventory step-up charges and Corporate acquisition related costs.

[0001104659-23-088847:8k_2_02:69]
| EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |  |  |  |
|  |  | YTD Q3 2023 |  |  | YTD Q3 2022 |  |  | YTD Q3 2023-As Adj |  |  | YTD Q3 2022-As Adj |  |
| Consolidated EBITDA |  | $ | 121,876 |  |  |  | 105,338 |  |  |  | 125,518 |  |  |  | 106,445 |  |
| Less: Depr & Amort |  |  | (37,699 | ) |  |  | (36,247 | ) |  |  | (37,699 | ) |  |  | (36,247 | ) |
| Consolidated EBIT |  |  | 84,177 |  |  |  | 69,091 |  |  |  | 87,819 |  |  |  | 70,198 |  |
| Less: Interest expense |  |  | (6,422 | ) |  |  | (3,084 | ) |  |  | (6,422 | ) |  |  | (3,084 | ) |
| Less: Income tax expense |  |  | (17,207 | ) |  |  | (14,727 | ) |  |  | (18,045 | ) |  |  | (14,982 | ) |
| Net earnings |  | $ | 60,548 |  |  |  | 51,280 |  |  |  | 63,352 |  |  |  | 52,132 |  |

[0001104659-23-088847:8k_2_02:70]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-23-088847:8k_2_02:71]
Condensed Consolidated Balance Sheets (Unaudited)

[0001104659-23-088847:8k_2_02:72]
(Dollars in thousands)

[0001104659-23-088847:8k_2_02:73]
|  |  | June 30, 2023 |  |  | September 30, 2022 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 56,052 |  |  |  | 97,724 |  |
| Accounts receivable, net |  |  | 192,146 |  |  |  | 164,645 |  |
| Contract assets |  |  | 128,284 |  |  |  | 125,154 |  |
| Inventories |  |  | 192,493 |  |  |  | 162,403 |  |
| Other current assets |  |  | 24,847 |  |  |  | 22,696 |  |
| Total current assets |  |  | 593,822 |  |  |  | 572,622 |  |
| Property, plant and equipment, net |  |  | 155,337 |  |  |  | 155,973 |  |
| Intangible assets, net |  |  | 398,418 |  |  |  | 394,464 |  |
| Goodwill |  |  | 505,590 |  |  |  | 492,709 |  |
| Operating lease assets |  |  | 40,314 |  |  |  | 29,150 |  |
| Other assets |  |  | 10,028 |  |  |  | 9,538 |  |
|  |  | $ | 1,703,509 |  |  |  | 1,654,456 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt |  | $ | 20,000 |  |  |  | 20,000 |  |
| Accounts payable |  |  | 76,761 |  |  |  | 78,746 |  |
| Contract liabilities |  |  | 122,526 |  |  |  | 125,009 |  |
| Other current liabilities |  |  | 89,664 |  |  |  | 94,374 |  |
| Total current liabilities |  |  | 308,951 |  |  |  | 318,129 |  |
| Deferred tax liabilities |  |  | 78,585 |  |  |  | 82,023 |  |
| Non-current operating lease liabilities |  |  | 36,815 |  |  |  | 24,853 |  |
| Other liabilities |  |  | 44,115 |  |  |  | 48,294 |  |
| Long-term debt |  |  | 128,000 |  |  |  | 133,000 |  |
| Shareholders' equity |  |  | 1,107,043 |  |  |  | 1,048,157 |  |
|  |  | $ | 1,703,509 |  |  |  | 1,654,456 |  |

[0001104659-23-088847:8k_2_02:74]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-23-088847:8k_2_02:75]
Consolidated Statements of Cash Flows (Unaudited)

[0001104659-23-088847:8k_2_02:76]
(Dollars in thousands)

[0001104659-23-088847:8k_2_02:77]
|  |  | Nine Months Ended June 30, 2023 |  |  | Nine Months Ended June 30, 2022 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 60,548 |  |  |  | 51,280 |  |
| Adjustments to reconcile net earnings to net cash (used) provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 37,699 |  |  |  | 36,247 |  |
| Stock compensation expense |  |  | 7,007 |  |  |  | 5,318 |  |
| Changes in assets and liabilities |  |  | (72,346 | ) |  |  | (60,172 | ) |
| Effect of deferred taxes |  |  | (3,706 | ) |  |  | 9,020 |  |
| Net cash provided by operating activities |  |  | 29,202 |  |  |  | 41,693 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Acquisition of business, net of cash acquired |  |  | (17,694 | ) |  |  | (15,592 | ) |
| Capital expenditures |  |  | (16,993 | ) |  |  | (25,893 | ) |
| Additions to capitalized software |  |  | (9,263 | ) |  |  | (9,359 | ) |
| Net cash used by investing activities |  |  | (43,950 | ) |  |  | (50,844 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from long-term debt |  |  | 88,000 |  |  |  | 111,000 |  |
| Principal payments on long-term debt and short-term borrowings |  |  | (93,000 | ) |  |  | (64,000 | ) |
| Dividends paid |  |  | (6,189 | ) |  |  | (6,219 | ) |
| Purchases of common stock into treasury |  |  | (12,401 | ) |  |  | (19,878 | ) |
| Other |  |  | (2,557 | ) |  |  | (2,787 | ) |
| Net cash (used) provided by financing activities |  |  | (26,147 | ) |  |  | 18,116 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (777 | ) |  |  | (4,178 | ) |
| Net (decrease) increase in cash and cash equivalents |  |  | (41,672 | ) |  |  | 4,787 |  |
| Cash and cash equivalents, beginning of period |  |  | 97,724 |  |  |  | 56,232 |  |
| Cash and cash equivalents, end of period |  | $ | 56,052 |  |  |  | 61,019 |  |

[0001104659-23-088847:8k_2_02:78]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-23-088847:8k_2_02:79]
Other Selected Financial Data (Unaudited)

[0001104659-23-088847:8k_2_02:80]
(Dollars in thousands)

[0001104659-23-088847:8k_2_02:81]
| Backlog And Entered Orders - Q3 2023 |  | Aerospace & Defense |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 4/1/23 |  | $ | 435,246 |  |  |  | 142,696 |  |  |  | 162,919 |  |  |  | 740,861 |  |
| Entered Orders |  |  | 81,936 |  |  |  | 85,510 |  |  |  | 45,851 |  |  |  | 213,297 |  |
| Sales |  |  | (103,469 | ) |  |  | (89,966 | ) |  |  | (55,314 | ) |  |  | (248,749 | ) |
| Ending Backlog - 6/30/23 |  | $ | 413,713 |  |  |  | 138,240 |  |  |  | 153,456 |  |  |  | 705,409 |  |

[0001104659-23-088847:8k_2_02:82]
| Backlog And Entered Orders - YTD Q3 2023 |  | Aerospace & Defense |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 10/1/22 |  | $ | 408,269 |  |  |  | 128,156 |  |  |  | 158,597 |  |  |  | 695,022 |  |
| Entered Orders |  |  | 290,878 |  |  |  | 250,256 |  |  |  | 152,639 |  |  |  | 693,773 |  |
| Sales |  |  | (285,434 | ) |  |  | (240,172 | ) |  |  | (157,780 | ) |  |  | (683,386 | ) |
| Ending Backlog - 6/30/23 |  | $ | 413,713 |  |  |  | 138,240 |  |  |  | 153,456 |  |  |  | 705,409 |  |

[0001104659-23-088847:8k_2_02:83]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-23-088847:8k_2_02:84]
Reconciliation of Non-GAAP Financial Measures (Unaudited)

[0001104659-23-088847:8k_2_02:85]
| EPS – Adjusted Basis Reconciliation – Q3 2023 |  |  |  |  |
| EPS – GAAP Basis – Q3 2023 |  | $ | 1.08 |  |
| Adjustments (defined below) |  |  | 0.01 |  |
| EPS – As Adjusted Basis – Q3 2023 |  | $ | 1.09 |  |
| Adjustments exclude $0.01 per share consisting mainly of Corporate acquisition related costs in the third quarter of 2023. |  |  |  |  |
| The $0.01 of EPS adjustments per share consists of $350K of pre-tax charges offset by $80K of tax benefit for net impact of $270K. |  |  |  |  |
| EPS – Adjusted Basis Reconciliation – YTD Q3 2023 |  |  |  |  |
| EPS – GAAP Basis – YTD Q3 2023 |  | $ | 2.34 |  |
| Adjustments (defined below) |  |  | 0.11 |  |
| EPS – As Adjusted Basis – YTD Q3 2023 |  | $ | 2.45 |  |
| Adjustments exclude $0.11 per share consisting of executive management transition costs at Corporate, CMT acquisition inventory step-up charges and restructuring charges within the A&D segment, and Corporate acquisition costs in the first nine months of 2023. |  |  |  |  |
| The $0.11 of EPS adjustments per share consists of $3,642K of pre-tax charges offset by $838K of tax benefit for net impact of $2,804K. |  |  |  |  |
| EPS – Adjusted Basis Reconciliation – YTD Q3 2022 |  |  |  |  |
| EPS – GAAP Basis – YTD Q3 2022 |  | $ | 1.97 |  |
| Adjustments (defined below) |  |  | 0.03 |  |
| EPS – As Adjusted Basis – YTD Q3 2022 |  | $ | 2.00 |  |
| Adjustments exclude $0.03 per share consisting of Altanova & NEco acquisition inventory step-up charges and Corporate related acquisition costs in the first nine months of 2022. |  |  |  |  |
| The $0.03 of EPS adjustments per share consists of $1,107K of pre-tax charges offset by $255K of tax benefit for net impact of $852K. |  |  |  |  |
