# ESE notes — 0001410578-23-001616


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001410578-23-001616:notes:1]
[same as prior period, unchanged from 0001410578-23-000960:notes:1]

[0001410578-23-001616:notes:2]
[same as prior period, unchanged from 0001410578-23-000960:notes:2]

[0001410578-23-001616:notes:3]
The Company’s results for the three-month period ended June 30, 2023 are not necessarily indicative of the results for the entire 2023 fiscal year. References to the third quarters of 2023 and 2022 represent the fiscal quarters ended June 30, 2023 and 2022, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:EarningsPerShareTextBlock

[0001410578-23-001616:notes:4]
[same as prior period, unchanged from 0001410578-23-000960:notes:4]

[0001410578-23-001616:notes:5]
[same as prior period, unchanged from 0001410578-23-000960:notes:5]

[0001410578-23-001616:notes:6]
| ​ |  | Three Months | ​ | Nine Months |
| ​ | ​ | Ended June 30, | ​ | Ended June 30, |
| ​ |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Weighted Average Shares Outstanding — Basic |  | 25,757 |  | 25,856 | ​ | 25,808 |  | 25,959 |
| Dilutive Restricted Shares | ​ | 70 | ​ | 94 | ​ | 82 | ​ | 91 |
| Adjusted Shares — Diluted |  | 25,827 |  | 25,950 | ​ | 25,890 |  | 26,050 |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001410578-23-001616:notes:7]
[same as prior period, unchanged from 0001410578-23-000960:notes:7]

[0001410578-23-001616:notes:8]
On February 1, 2023, the Company acquired CMT Materials, LLC and its affiliate Engineered Syntactic Systems, LLC (CMT) for a purchase price of approximately $18 million, net of cash acquired. CMT, based in Attleboro, Massachusetts, is a supplier of syntactic materials for buoyancy and specialty applications. Since the date of acquisition, the operating results for the CMT business have been included as part of Globe in the A&D segment. The acquisition date fair value of the assets acquired and liabilities assumed primarily were as follows: approximately $1.7 million of accounts receivable, $3.0 million of inventory, $1.3 million of property, plant and equipment, $1.2 million of accounts payable and accrued expenses, $7.3 million of identifiable intangible assets, mainly consisting of customer relationships totaling $6.2 million. The acquired goodwill of $5.6 million related to excess value associated with opportunities to expand the services and products that the Company can offer to its customers. The Company anticipates that the goodwill will be deductible for tax purposes. The Company received a $0.2 million working capital settlement during the third quarter of 2023.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001410578-23-001616:notes:9]
[same as prior period, unchanged from 0001410578-23-000960:notes:9]

[0001410578-23-001616:notes:10]
[same as prior period, unchanged from 0001410578-23-000960:notes:10]

[0001410578-23-001616:notes:11]
[same as prior period, unchanged from 0001410578-23-000960:notes:11]

[0001410578-23-001616:notes:12]
Compensation expense related to the PARS/RSU awards was $1.4 million and $6.0 million for the three and nine-month periods ended June 30, 2023, respectively, and $1.6 million and $4.4 million for the corresponding periods in 2022. As of June 30, 2023, there were 196,648 unvested stock units outstanding.

[0001410578-23-001616:notes:13]
[same as prior period, unchanged from 0001410578-23-000960:notes:13]

[0001410578-23-001616:notes:14]
Compensation expense related to the non-employee director grants was $0.3 million and $1.0 million for the three and nine-month periods ended June 30, 2023, respectively, and $0.3 million and $0.9 million for the corresponding periods in 2022.

[0001410578-23-001616:notes:15]
The total share-based compensation cost that has been recognized in the results of operations and included within selling, general and administrative expenses (SG&A) was $1.7 million and $7.0 million for the three and nine-month periods ended June 30, 2023, respectively, and $1.9 million and $5.3 million for the corresponding periods in 2022. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $0.2 million and $0.9 million for the three and nine-month periods ended June 30, 2023, respectively, and $0.4 million and $1.0 million for the corresponding periods in 2022. As of June 30, 2023, there was $10.7 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a remaining weighted-average period of 1.8 years.


## us-gaap:InventoryDisclosureTextBlock

[0001410578-23-001616:notes:16]
[same as prior period, unchanged from 0001410578-23-000960:notes:16]

[0001410578-23-001616:notes:17]
Inventories consist of the following:

[0001410578-23-001616:notes:18]
| ​ | ​ | June 30, | ​ | September 30, |
| (In thousands) |  | 2023 |  | 2022 |
| Finished goods | ​ | $ | 37,082 |  | 32,471 |
| Work in process | ​ |  | 48,579 |  | 38,492 |
| Raw materials | ​ |  | 106,832 |  | 91,440 |
| Total inventories | ​ | $ | 192,493 |  | 162,403 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001410578-23-001616:notes:19]
[same as prior period, unchanged from 0001410578-23-000960:notes:19]

[0001410578-23-001616:notes:20]
Included on the Company’s Consolidated Balance Sheets at June 30, 2023 and September 30, 2022 are the following intangible assets gross carrying amounts and accumulated amortization:

[0001410578-23-001616:notes:21]
| ​ |  | June 30, |  | September 30, |
| (Dollars in thousands) |  | 2023 |  | 2022 |
| Goodwill | ​ | $ | 505,590 |  | 492,709 |
| Intangible assets with determinable lives: | ​ |  | ​ | ​ | ​ |
| Patents | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 2,433 | ​ | 2,353 |
| Less: accumulated amortization | ​ |  | 1,186 | ​ | 1,091 |
| Net | ​ | $ | 1,247 | ​ | 1,262 |
| Capitalized software | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 118,529 | ​ | 106,583 |
| Less: accumulated amortization | ​ |  | 77,308 | ​ | 70,476 |
| Net | ​ | $ | 41,221 | ​ | 36,107 |
| Customer relationships | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 298,110 | ​ | 287,447 |
| Less: accumulated amortization | ​ |  | 109,186 | ​ | 96,921 |
| Net | ​ | $ | 188,924 | ​ | 190,526 |
| Other | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 14,345 | ​ | 13,985 |
| Less: accumulated amortization | ​ |  | 9,271 | ​ | 7,440 |
| Net | ​ | $ | 5,074 | ​ | 6,545 |
| Intangible assets with indefinite lives: | ​ |  | ​ | ​ | ​ |
| Trade names | ​ | $ | 161,952 | ​ | 160,024 |

[0001410578-23-001616:notes:22]
The changes in the carrying amount of goodwill attributable to each business segment for the nine months ended June 30, 2023 is as follows:

[0001410578-23-001616:notes:23]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | Aerospace | ​ | ​ |
| (Dollars in millions) |  | USG |  | Test |  | & Defense |  | Total |
| Balance as of September 30, 2022 | ​ | $ | 348.7 |  | ​ | 34.0 |  | 110.0 |  | 492.7 |
| Acquisition activity and adjustments | ​ | ​ | — | ​ | ​ | — | ​ | 5.6 | ​ | 5.6 |
| Foreign currency translation | ​ | ​ | 7.3 | ​ | ​ | — | ​ | — | ​ | 7.3 |
| Balance as of June 30, 2023 | ​ | $ | 356.0 | ​ | ​ | 34.0 | ​ | 115.6 | ​ | 505.6 |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001410578-23-001616:notes:24]
[same as prior period, unchanged from 0001410578-23-000960:notes:24]

[0001410578-23-001616:notes:25]
[same as prior period, unchanged from 0001410578-23-000960:notes:25]

[0001410578-23-001616:notes:26]
The Aerospace & Defense segment’s operations consist of PTI Technologies Inc. (PTI), VACCO Industries (VACCO), Crissair, Inc. (Crissair), Mayday Manufacturing Co. (Mayday), Globe Composite Solutions, LLC (Globe) and Westland Technologies Inc. (Westland). The companies within this segment primarily design and manufacture specialty filtration, fluid control and naval products, including hydraulic filter elements and fluid control devices used in aerospace and defense applications; unique filter mechanisms used in micro-propulsion devices for satellites, custom designed filters for manned aircraft and submarines; products and systems to reduce vibration and/or acoustic signatures and otherwise reduce or obscure a vessel’s signature, and other communications, sealing, surface control and hydrodynamic related applications to enhance U.S. Navy maritime survivability; precision-tolerance machined components for the aerospace and defense industry; and metal processing services.

[0001410578-23-001616:notes:27]
[same as prior period, unchanged from 0001410578-23-000960:notes:27]

[0001410578-23-001616:notes:28]
[same as prior period, unchanged from 0001410578-23-000960:notes:28]

[0001410578-23-001616:notes:29]
[same as prior period, unchanged from 0001410578-23-000960:notes:29]

[0001410578-23-001616:notes:30]
| ​ | ​ | Three Months | ​ | Nine Months |
| ​ | ​ | Ended June 30, | ​ | Ended June 30, |
| (In thousands) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| NET SALES | ​ | ​ |  | ​ |  | ​ |  | ​ |  |
| Aerospace & Defense | ​ | $ | 103,469 | ​ | 92,606 | ​ | 285,434 | ​ | 247,671 |
| USG | ​ | ​ | 89,966 | ​ | 67,201 | ​ | 240,172 | ​ | 194,877 |
| Test | ​ | ​ | 55,314 | ​ | 59,259 | ​ | 157,780 | ​ | 158,456 |
| Consolidated totals | ​ | $ | 248,749 | ​ | 219,066 | ​ | 683,386 | ​ | 601,004 |
| EBIT | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Aerospace & Defense | ​ | $ | 21,665 | ​ | 20,738 | ​ | 52,996 | ​ | 45,042 |
| USG | ​ | ​ | 20,351 | ​ | 13,135 | ​ | 50,543 | ​ | 37,840 |
| Test | ​ | ​ | 8,643 | ​ | 8,354 | ​ | 21,280 | ​ | 20,813 |
| Corporate (loss) | ​ | ​ | (12,658) | ​ | (11,394) | ​ | (40,642) | ​ | (34,604) |
| Consolidated EBIT | ​ | ​ | 38,001 | ​ | 30,833 | ​ | 84,177 | ​ | 69,091 |
| Less: Interest expense | ​ | ​ | (2,495) | ​ | (1,331) | ​ | (6,422) | ​ | (3,084) |
| Earnings before income taxes | ​ | $ | 35,506 | ​ | 29,502 | ​ | 77,755 | ​ | 66,007 |

[0001410578-23-001616:notes:31]
[same as prior period, unchanged from 0001410578-23-000960:notes:31]

[0001410578-23-001616:notes:32]
[same as prior period, unchanged from 0001410578-23-000960:notes:32]

[0001410578-23-001616:notes:33]
[same as prior period, unchanged from 0001410578-23-000960:notes:33]


## us-gaap:DebtDisclosureTextBlock

[0001410578-23-001616:notes:34]
8.    DEBT

[0001410578-23-001616:notes:35]
The Company’s debt is summarized as follows:

[0001410578-23-001616:notes:36]
| ​ |  | June 30, | ​ | September 30, |
| (In thousands) |  | 2023 |  | 2022 |
| Total borrowings | ​ | $ | 148,000 |  | 153,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 128,000 |  | 133,000 |

[0001410578-23-001616:notes:37]
The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024, with balance due by this date.

[0001410578-23-001616:notes:38]
At June 30, 2023, the Company had approximately $345 million available to borrow under the Credit Facility, plus the $250 million increase option, subject to lenders’ consent, in addition to $56.1 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of June 30, 2023, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $7.4 million at June 30, 2023.

[0001410578-23-001616:notes:39]
Interest on borrowings under the Credit Facility is calculated at a spread over either the Standard Overnight Financing Rate (SOFR) or the prime rate depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The interest rate spreads on the facility and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio.  The weighted average interest rates were 6.05% and 5.57% for the three and nine-month periods ending June 30, 2023, respectively, and 2.20% and 1.57% for the three and nine-month periods ending June 30, 2022. As of June 30, 2023, the Company was in compliance with all covenants.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001410578-23-001616:notes:40]
[same as prior period, unchanged from 0001410578-23-000960:notes:40]

[0001410578-23-001616:notes:41]
The third quarter 2023 effective income tax rate was 21.3% compared to 21.5% in the third quarter of 2022. The effective income tax rate in the first nine months of 2023 was 22.1% compared to 22.3% for the first nine months of 2022. The income tax expense in the third quarter and first nine months of 2023 was favorably impacted by tax return to provision true-ups related to the federal research and development tax credit, decreasing the third quarter and year-to-date rate by 0.9% and 0.4%, respectively.

[0001410578-23-001616:notes:42]
The income tax expense in the third quarter and first nine months of 2022 was favorably impacted by tax return to provision true-ups on U.S. tax on the distribution of foreign earnings, and the re-rating of deferred taxes as a result of a Vermont law change, decreasing the third quarter and year-to-date effective tax rate by 1.6% and 0.7%, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001410578-23-001616:notes:43]
[same as prior period, unchanged from 0001410578-23-000960:notes:42]

[0001410578-23-001616:notes:44]
The change in shareholders’ equity for the first three and nine months of 2023 and 2022 is shown below (in thousands):

[0001410578-23-001616:notes:45]
| ​ | ​ | Three Months Ended June 30, | ​ | Nine Months Ended June 30, |
| ​ |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Common stock | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | 308 | ​ | 307 | ​ | 307 | ​ | 307 |
| Stock plans | ​ | ​ | — | ​ | — | ​ | 1 | ​ | — |
| Ending balance | ​ | ​ | 308 | ​ | 307 | ​ | 308 | ​ | 307 |
| Additional paid-in-capital | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | 304,184 | ​ | 298,353 | ​ | 301,553 | ​ | 297,644 |
| Stock plans | ​ | ​ | 1,371 | ​ | 1,510 | ​ | 4,002 | ​ | 2,219 |
| Ending balance | ​ | ​ | 305,555 | ​ | 299,863 | ​ | 305,555 | ​ | 299,863 |
| Retained earnings | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | 933,499 | ​ | 854,946 | ​ | 905,022 | ​ | 830,989 |
| Net earnings | ​ | ​ | 27,943 | ​ | 23,173 | ​ | 60,548 | ​ | 51,280 |
| Dividends paid | ​ | ​ | (2,061) | ​ | (2,069) | ​ | (6,189) | ​ | (6,219) |
| Ending balance | ​ | ​ | 959,381 | ​ | 876,050 | ​ | 959,381 | ​ | 876,050 |
| Accumulated other comprehensive income (loss) | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | (18,018) | ​ | (7,472) | ​ | (31,764) | ​ | (2,161) |
| Foreign currency translation | ​ | ​ | (821) | ​ | (11,905) | ​ | 12,925 | ​ | (17,216) |
| Ending balance | ​ | ​ | (18,839) | ​ | (19,377) | ​ | (18,839) | ​ | (19,377) |
| Treasury stock | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | (139,178) | ​ | (124,961) | ​ | (126,961) | ​ | (107,083) |
| Share repurchases | ​ | ​ | (184) | ​ | (2,000) | ​ | (12,401) | ​ | (19,878) |
| Ending balance | ​ | ​ | (139,362) | ​ | (126,961) | ​ | (139,362) | ​ | (126,961) |
| Total equity | ​ | ​ | 1,107,043 | ​ | 1,029,882 | ​ | 1,107,043 | ​ | 1,029,882 |


## us-gaap:FairValueDisclosuresTextBlock

[0001410578-23-001616:notes:46]
[same as prior period, unchanged from 0001410578-23-000960:notes:45]

[0001410578-23-001616:notes:47]
[same as prior period, unchanged from 0001410578-23-000960:notes:46]

[0001410578-23-001616:notes:48]
[same as prior period, unchanged from 0001410578-23-000960:notes:47]

[0001410578-23-001616:notes:49]
[same as prior period, unchanged from 0001410578-23-000960:notes:48]

[0001410578-23-001616:notes:50]
[same as prior period, unchanged from 0001410578-23-000960:notes:49]

[0001410578-23-001616:notes:51]
[same as prior period, unchanged from 0001410578-23-000960:notes:50]

[0001410578-23-001616:notes:52]
The Company has estimated the fair value of its financial instruments as of June 30, 2023 and September 30, 2022 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001410578-23-001616:notes:53]
[same as prior period, unchanged from 0001410578-23-000960:notes:52]

[0001410578-23-001616:notes:54]
[same as prior period, unchanged from 0001410578-23-000960:notes:53]

[0001410578-23-001616:notes:55]
[same as prior period, unchanged from 0001410578-23-000960:notes:54]

[0001410578-23-001616:notes:56]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however, they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during the three and nine-month periods ended June 30, 2023.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001410578-23-001616:notes:57]
[same as prior period, unchanged from 0001410578-23-000960:notes:56]

[0001410578-23-001616:notes:58]
[same as prior period, unchanged from 0001410578-23-000960:notes:57]

[0001410578-23-001616:notes:59]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2023 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue within each reportable segment.

[0001410578-23-001616:notes:60]
| Three months ended June 30, 2023 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 51,303 | ​ | $ | 88,442 | ​ | $ | 48,407 | ​ | $ | 188,152 |
| Government | ​ |  | 52,166 | ​ |  | 1,524 | ​ |  | 6,907 | ​ |  | 60,597 |
| Total revenues | ​ | $ | 103,469 | ​ | $ | 89,966 | ​ | $ | 55,314 | ​ | $ | 248,749 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 86,031 | ​ | $ | 55,011 | ​ | $ | 32,246 | ​ | $ | 173,288 |
| International | ​ |  | 17,438 | ​ |  | 34,955 | ​ |  | 23,068 | ​ |  | 75,461 |
| Total revenues | ​ | $ | 103,469 | ​ | $ | 89,966 | ​ | $ | 55,314 | ​ | $ | 248,749 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 48,496 | ​ | $ | 74,128 | ​ | $ | 11,496 | ​ | $ | 134,120 |
| Over time | ​ |  | 54,973 | ​ |  | 15,838 | ​ |  | 43,818 | ​ |  | 114,629 |
| Total revenues | ​ | $ | 103,469 | ​ | $ | 89,966 | ​ | $ | 55,314 | ​ | $ | 248,749 |

[0001410578-23-001616:notes:61]
| Nine months ended June 30, 2023 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial |  | $ | 136,271 | ​ | $ | 236,715 | ​ | $ | 137,587 | ​ | $ | 510,573 |
| Government | ​ | ​ | 149,163 | ​ |  | 3,457 | ​ |  | 20,193 | ​ |  | 172,813 |
| Total revenues |  | $ | 285,434 | ​ | $ | 240,172 | ​ | $ | 157,780 | ​ | $ | 683,386 |
| Geographic location: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States |  | $ | 237,481 | ​ | $ | 154,410 | ​ | $ | 87,253 | ​ | $ | 479,144 |
| International | ​ | ​ | 47,953 | ​ |  | 85,762 | ​ |  | 70,527 | ​ |  | 204,242 |
| Total revenues |  | $ | 285,434 | ​ | $ | 240,172 | ​ | $ | 157,780 | ​ | $ | 683,386 |
| Revenue recognition method: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time |  | $ | 129,355 | ​ | $ | 194,240 | ​ | $ | 32,565 | ​ | $ | 356,160 |
| Over time | ​ | ​ | 156,079 | ​ |  | 45,932 | ​ |  | 125,215 | ​ |  | 327,226 |
| Total revenues |  | $ | 285,434 | ​ | $ | 240,172 | ​ | $ | 157,780 | ​ | $ | 683,386 |

[0001410578-23-001616:notes:62]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2022 are presented in the tables below.

[0001410578-23-001616:notes:63]
| Three months ended June 30, 2022 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 38,918 | ​ | $ | 65,610 | ​ | $ | 54,449 | ​ | $ | 158,977 |
| Government | ​ |  | 53,688 | ​ |  | 1,591 | ​ |  | 4,810 | ​ |  | 60,089 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 79,536 | ​ | $ | 41,822 | ​ | $ | 34,662 | ​ | $ | 156,020 |
| International | ​ |  | 13,070 | ​ |  | 25,379 | ​ |  | 24,597 | ​ |  | 63,046 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 35,238 | ​ | $ | 53,656 | ​ | $ | 15,827 | ​ | $ | 104,721 |
| Over time | ​ |  | 57,368 | ​ |  | 13,545 | ​ |  | 43,432 | ​ |  | 114,345 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |

[0001410578-23-001616:notes:64]
| Nine months ended June 30, 2022 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 100,407 | ​ | $ | 191,832 | ​ | $ | 147,390 | ​ | $ | 439,629 |
| Government | ​ |  | 147,264 | ​ |  | 3,045 | ​ |  | 11,066 | ​ |  | 161,375 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 212,849 | ​ | $ | 122,021 | ​ | $ | 88,708 | ​ | $ | 423,578 |
| International | ​ |  | 34,822 | ​ |  | 72,856 | ​ |  | 69,748 | ​ |  | 177,426 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 99,464 | ​ | $ | 155,693 | ​ | $ | 43,488 | ​ | $ | 298,645 |
| Over time | ​ |  | 148,207 | ​ |  | 39,184 | ​ |  | 114,968 | ​ |  | 302,359 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |

[0001410578-23-001616:notes:65]
[same as prior period, unchanged from 0001410578-23-000960:notes:64]

[0001410578-23-001616:notes:66]
[same as prior period, unchanged from 0001410578-23-000960:notes:65]

[0001410578-23-001616:notes:67]
[same as prior period, unchanged from 0001410578-23-000960:notes:66]

[0001410578-23-001616:notes:68]
[same as prior period, unchanged from 0001410578-23-000960:notes:67]

[0001410578-23-001616:notes:69]
[same as prior period, unchanged from 0001410578-23-000960:notes:68]

[0001410578-23-001616:notes:70]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At June 30, 2023, the Company had $705.4 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 79% in the next twelve months.

[0001410578-23-001616:notes:71]
[same as prior period, unchanged from 0001410578-23-000960:notes:70]

[0001410578-23-001616:notes:72]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred. At June 30, 2023, contract assets and liabilities totaled $128.3 million and $133.6 million, respectively. During the first nine months of 2023, the Company recognized approximately $81 million in revenues that were included in the contract liabilities balance at September 30, 2022. At September 30, 2022, contract assets and liabilities totaled $125.2 million and $137.6 million, respectively.


## ese:OperatingAndFinancingLeasesOfLesseeDisclosureTextBlock

[0001410578-23-001616:notes:73]
[same as prior period, unchanged from 0001410578-23-000960:notes:72]

[0001410578-23-001616:notes:74]
[same as prior period, unchanged from 0001410578-23-000960:notes:73]

[0001410578-23-001616:notes:75]
The Company’s leases for real estate commonly include escalating payments. In addition to the present value of the future lease payments, the calculation of the ROU asset also includes any deferred rent, lease pre-payments and initial direct costs of obtaining the lease.

[0001410578-23-001616:notes:76]
[same as prior period, unchanged from 0001410578-23-000960:notes:75]

[0001410578-23-001616:notes:77]
[same as prior period, unchanged from 0001410578-23-000960:notes:76]

[0001410578-23-001616:notes:78]
[same as prior period, unchanged from 0001410578-23-000960:notes:77]

[0001410578-23-001616:notes:79]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended |
| ​ | ​ | June 30, | ​ | June 30, |
| (Dollars in thousands) |  | 2023 |  | 2022 |
| Finance lease cost | ​ | ​ |  | ​ | ​ |  |
| Amortization of right-of-use assets | ​ | $ | 393 | ​ | $ | 393 |
| Interest on lease liabilities | ​ |  | 230 | ​ |  | 242 |
| Operating lease cost | ​ |  | 1,858 | ​ |  | 1,577 |
| Total lease costs | ​ | $ | 2,481 | ​ | $ | 2,212 |

[0001410578-23-001616:notes:80]
| ​ |  | Nine Months |  | Nine Months |
| ​ | ​ | Ended | ​ | Ended |
| ​ | ​ | June 30, | ​ | June 30, |
| (Dollars in thousands) |  | 2023 |  | 2022 |
| Finance lease cost | ​ | ​ | ​ | ​ | ​ | ​ |
| Amortization of right-of-use assets | ​ | $ | 1,179 | ​ | $ | 1,219 |
| Interest on lease liabilities | ​ |  | 698 | ​ |  | 753 |
| Operating lease cost | ​ |  | 5,356 | ​ |  | 4,731 |
| Total lease costs | ​ | $ | 7,233 | ​ | $ | 6,703 |

[0001410578-23-001616:notes:81]
[same as prior period, unchanged from 0001410578-23-000960:notes:80]

[0001410578-23-001616:notes:82]
| ​ |  | Three Months Ended |  | Three Months Ended |
| ​ | ​ | June 30, | ​ | June 30, |
| (Dollars in thousands) | ​ | 2023 | ​ | 2022 |
| Cash paid for amounts included in the measurement of lease liabilities | ​ | ​ | ​ | ​ | ​ | ​ |
| Operating cash flows from operating leases | ​ | $ | 1,792 | ​ | $ | 1,485 |
| Operating cash flows from finance leases | ​ |  | 230 | ​ |  | 242 |
| Financing cash flows from finance leases | ​ |  | 334 | ​ |  | 307 |
| Right-of-use assets obtained in exchange for operating lease liabilities | ​ |  | 402 | ​ |  | 566 |

[0001410578-23-001616:notes:83]
| ​ | ​ | Nine Months Ended | ​ | Nine Months Ended | ​ |
| ​ | ​ | June 30, | ​ | June 30, | ​ |
| (Dollars in thousands) |  | 2023 |  | 2022 | ​ |
| Cash paid for amounts included in the measurement of lease liabilities | ​ | ​ |  | ​ | ​ |  | ​ |
| Operating cash flows from operating leases | ​ | $ | 5,172 | ​ | $ | 4,521 | ​ |
| Operating cash flows from finance leases | ​ |  | 698 | ​ |  | 753 | ​ |
| Financing cash flows from finance leases | ​ |  | 991 | ​ |  | 971 | ​ |
| Right-of-use assets obtained in exchange for operating lease liabilities | ​ | ​ | 14,984 | ​ | ​ | 1,813 | ​ |
| ​ | ​ | ​ | June 30, 2023 | ​ | ​ | June 30, 2022 | ​ |
| Weighted-average remaining lease term | ​ |  | ​ | ​ |  | ​ | ​ |
| Operating leases | ​ |  | 11.4 | years |  | 9.7 | years |
| Finance leases | ​ |  | 11.3 | years |  | 12.0 | years |
| Weighted-average discount rate | ​ |  | ​ | ​ |  | ​ | ​ |
| Operating leases | ​ |  | 4.42 | % |  | 3.12 | % |
| Finance leases | ​ |  | 4.62 | % |  | 4.59 | % |

[0001410578-23-001616:notes:84]
The following is a reconciliation of future undiscounted cash flows to the operating and finance lease liabilities, and the related ROU assets, presented on our Consolidated Balance Sheet on June 30, 2023:

[0001410578-23-001616:notes:85]
| (Dollars in thousands) | ​ | Operating |  | Finance |
| Years Ending September 30: |  | Leases |  | Leases |
| 2023 (excluding the nine months ended June 30, 2023) | ​ | $ | 1,796 |  | 566 |
| 2024 | ​ |  | 6,458 |  | 2,315 |
| 2025 | ​ |  | 5,168 |  | 2,370 |
| 2026 | ​ |  | 4,300 |  | 2,434 |
| 2027 and thereafter | ​ |  | 36,913 |  | 18,997 |
| Total minimum lease payments | ​ |  | 54,635 |  | 26,682 |
| Less: amounts representing interest | ​ |  | 12,570 |  | 6,491 |
| Present value of net minimum lease payments | ​ | $ | 42,065 |  | 20,191 |
| Less: current portion of lease obligations | ​ |  | 5,250 |  | 1,415 |
| Non-current portion of lease obligations | ​ | ​ | 36,815 |  | 18,776 |
| ROU assets | ​ | $ | 40,314 |  | 16,164 |

[0001410578-23-001616:notes:86]
[same as prior period, unchanged from 0001410578-23-000960:notes:85]
