# ESE note change history — 0001410578-23-000960 → 0001410578-23-001616


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-08-09):
[0001410578-23-001616:note_history:1]
The Company’s results for the three-month period ended June 30, 2023 are not necessarily indicative of the results for the entire 2023 fiscal year. References to the third quarters of 2023 and 2022 represent the fiscal quarters ended June 30, 2023 and 2022, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.
  (was, 2023-05-10, similarity 0.9717):
[0001410578-23-000960:note_history:1]
The Company’s results for the three-month period ended March 31, 2023 are not necessarily indicative of the results for the entire 2023 fiscal year. References to the second quarters of 2023 and 2022 represent the fiscal quarters ended March 31, 2023 and 2022, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-08-09):
[0001410578-23-001616:note_history:2]
| ​ |  | June 30, | ​ | September 30, |
| (In thousands) |  | 2023 |  | 2022 |
| Total borrowings | ​ | $ | 148,000 |  | 153,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 128,000 |  | 133,000 |
  (was, 2023-05-10, similarity 0.9802):
[0001410578-23-000960:note_history:2]
| ​ |  | March 31, | ​ | September 30, |
| (In thousands) |  | 2023 |  | 2022 |
| Total borrowings | ​ | $ | 161,000 |  | 153,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 141,000 |  | 133,000 |

- changed (2023-08-09):
[0001410578-23-001616:note_history:3]
At June 30, 2023, the Company had approximately $345 million available to borrow under the Credit Facility, plus the $250 million increase option, subject to lenders’ consent, in addition to $56.1 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of June 30, 2023, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $7.4 million at June 30, 2023.
  (was, 2023-05-10, similarity 0.9696):
[0001410578-23-000960:note_history:3]
At March 31, 2023, the Company had approximately $332 million available to borrow under the Credit Facility, plus the $250 million increase option, subject to lenders’ consent, in addition to $48.2 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of March 31, 2023, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $7.3 million at March 31, 2023.

- changed (2023-08-09):
[0001410578-23-001616:note_history:4]
Interest on borrowings under the Credit Facility is calculated at a spread over either the Standard Overnight Financing Rate (SOFR) or the prime rate depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The interest rate spreads on the facility and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio.  The weighted average interest rates were 6.05% and 5.57% for the three and nine-month periods ending June 30, 2023, respectively, and 2.20% and 1.57% for the three and nine-month periods ending June 30, 2022. As of June 30, 2023, the Company was in compliance with all covenants.
  (was, 2023-05-10, similarity 0.9541):
[0001410578-23-000960:note_history:4]
Interest on borrowings under the Credit Facility is calculated at a spread over either the Standard Overnight Financing Rate (SOFR) or the prime rate depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The interest rate spreads on the facility and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio.  The weighted average interest rates were 5.97% and 5.33% for the three and six-month periods ending March 31, 2023, respectively, and 1.29% and 1.23% for the three and six-month periods ending March 31, 2022. As of March 31, 2023, the Company was in compliance with all covenants.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-08-09):
[0001410578-23-001616:note_history:5]
| ​ |  | June 30, | ​ | September 30, |
| (In thousands) |  | 2023 |  | 2022 |
| Total borrowings | ​ | $ | 148,000 |  | 153,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 128,000 |  | 133,000 |
  (was, 2023-05-10, similarity 0.9802):
[0001410578-23-000960:note_history:5]
| ​ |  | March 31, | ​ | September 30, |
| (In thousands) |  | 2023 |  | 2022 |
| Total borrowings | ​ | $ | 161,000 |  | 153,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 141,000 |  | 133,000 |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-08-09):
[0001410578-23-001616:note_history:6]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2023 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue within each reportable segment.
  (was, 2023-05-10, similarity 0.9809):
[0001410578-23-000960:note_history:6]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2023 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue within each reportable segment.

- changed (2023-08-09):
[0001410578-23-001616:note_history:7]
| Three months ended June 30, 2023 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 51,303 | ​ | $ | 88,442 | ​ | $ | 48,407 | ​ | $ | 188,152 |
| Government | ​ |  | 52,166 | ​ |  | 1,524 | ​ |  | 6,907 | ​ |  | 60,597 |
| Total revenues | ​ | $ | 103,469 | ​ | $ | 89,966 | ​ | $ | 55,314 | ​ | $ | 248,749 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 86,031 | ​ | $ | 55,011 | ​ | $ | 32,246 | ​ | $ | 173,288 |
| International | ​ |  | 17,438 | ​ |  | 34,955 | ​ |  | 23,068 | ​ |  | 75,461 |
| Total revenues | ​ | $ | 103,469 | ​ | $ | 89,966 | ​ | $ | 55,314 | ​ | $ | 248,749 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 48,496 | ​ | $ | 74,128 | ​ | $ | 11,496 | ​ | $ | 134,120 |
| Over time | ​ |  | 54,973 | ​ |  | 15,838 | ​ |  | 43,818 | ​ |  | 114,629 |
| Total revenues | ​ | $ | 103,469 | ​ | $ | 89,966 | ​ | $ | 55,314 | ​ | $ | 248,749 |
  (was, 2023-05-10, similarity 0.995):
[0001410578-23-000960:note_history:7]
| Three months ended March 31, 2023 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 48,228 | ​ | $ | 78,110 | ​ | $ | 43,188 | ​ | $ | 169,526 |
| Government | ​ |  | 50,754 | ​ |  | 1,051 | ​ |  | 7,805 | ​ |  | 59,610 |
| Total revenues | ​ | $ | 98,982 | ​ | $ | 79,161 | ​ | $ | 50,993 | ​ | $ | 229,136 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 82,516 | ​ | $ | 53,020 | ​ | $ | 27,504 | ​ | $ | 163,040 |
| International | ​ |  | 16,466 | ​ |  | 26,141 | ​ |  | 23,489 | ​ |  | 66,096 |
| Total revenues | ​ | $ | 98,982 | ​ | $ | 79,161 | ​ | $ | 50,993 | ​ | $ | 229,136 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 47,255 | ​ | $ | 64,080 | ​ | $ | 11,968 | ​ | $ | 123,303 |
| Over time | ​ |  | 51,727 | ​ |  | 15,081 | ​ |  | 39,025 | ​ |  | 105,833 |
| Total revenues | ​ | $ | 98,982 | ​ | $ | 79,161 | ​ | $ | 50,993 | ​ | $ | 229,136 |

- changed (2023-08-09):
[0001410578-23-001616:note_history:8]
| Nine months ended June 30, 2023 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial |  | $ | 136,271 | ​ | $ | 236,715 | ​ | $ | 137,587 | ​ | $ | 510,573 |
| Government | ​ | ​ | 149,163 | ​ |  | 3,457 | ​ |  | 20,193 | ​ |  | 172,813 |
| Total revenues |  | $ | 285,434 | ​ | $ | 240,172 | ​ | $ | 157,780 | ​ | $ | 683,386 |
| Geographic location: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States |  | $ | 237,481 | ​ | $ | 154,410 | ​ | $ | 87,253 | ​ | $ | 479,144 |
| International | ​ | ​ | 47,953 | ​ |  | 85,762 | ​ |  | 70,527 | ​ |  | 204,242 |
| Total revenues |  | $ | 285,434 | ​ | $ | 240,172 | ​ | $ | 157,780 | ​ | $ | 683,386 |
| Revenue recognition method: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time |  | $ | 129,355 | ​ | $ | 194,240 | ​ | $ | 32,565 | ​ | $ | 356,160 |
| Over time | ​ | ​ | 156,079 | ​ |  | 45,932 | ​ |  | 125,215 | ​ |  | 327,226 |
| Total revenues |  | $ | 285,434 | ​ | $ | 240,172 | ​ | $ | 157,780 | ​ | $ | 683,386 |
  (was, 2023-05-10, similarity 0.991):
[0001410578-23-000960:note_history:8]
| Six months ended March 31, 2023 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial |  | $ | 84,968 | ​ | $ | 148,273 | ​ | $ | 89,180 | ​ | $ | 322,421 |
| Government | ​ | ​ | 96,997 | ​ |  | 1,933 | ​ |  | 13,286 | ​ |  | 112,216 |
| Total revenues |  | $ | 181,965 | ​ | $ | 150,206 | ​ | $ | 102,466 | ​ | $ | 434,637 |
| Geographic location: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States |  | $ | 151,450 | ​ | $ | 99,399 | ​ | $ | 55,007 | ​ | $ | 305,856 |
| International | ​ | ​ | 30,515 | ​ |  | 50,807 | ​ |  | 47,459 | ​ |  | 128,781 |
| Total revenues |  | $ | 181,965 | ​ | $ | 150,206 | ​ | $ | 102,466 | ​ | $ | 434,637 |
| Revenue recognition method: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time |  | $ | 80,859 | ​ | $ | 120,111 | ​ | $ | 21,069 | ​ | $ | 222,039 |
| Over time | ​ | ​ | 101,106 | ​ |  | 30,095 | ​ |  | 81,397 | ​ |  | 212,598 |
| Total revenues |  | $ | 181,965 | ​ | $ | 150,206 | ​ | $ | 102,466 | ​ | $ | 434,637 |

- changed (2023-08-09):
[0001410578-23-001616:note_history:9]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2022 are presented in the tables below.
  (was, 2023-05-10, similarity 0.9576):
[0001410578-23-000960:note_history:9]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2022 are presented in the tables below.

- changed (2023-08-09):
[0001410578-23-001616:note_history:10]
| Three months ended June 30, 2022 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 38,918 | ​ | $ | 65,610 | ​ | $ | 54,449 | ​ | $ | 158,977 |
| Government | ​ |  | 53,688 | ​ |  | 1,591 | ​ |  | 4,810 | ​ |  | 60,089 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 79,536 | ​ | $ | 41,822 | ​ | $ | 34,662 | ​ | $ | 156,020 |
| International | ​ |  | 13,070 | ​ |  | 25,379 | ​ |  | 24,597 | ​ |  | 63,046 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 35,238 | ​ | $ | 53,656 | ​ | $ | 15,827 | ​ | $ | 104,721 |
| Over time | ​ |  | 57,368 | ​ |  | 13,545 | ​ |  | 43,432 | ​ |  | 114,345 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |
  (was, 2023-05-10, similarity 0.9951):
[0001410578-23-000960:note_history:10]
| Three months ended March 31, 2022 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 33,562 | ​ | $ | 63,379 | ​ | $ | 51,903 | ​ | $ | 148,844 |
| Government | ​ |  | 51,259 | ​ |  | 812 | ​ |  | 4,013 | ​ |  | 56,084 |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 72,621 | ​ | $ | 41,458 | ​ | $ | 31,071 | ​ | $ | 145,150 |
| International | ​ |  | 12,200 | ​ |  | 22,733 | ​ |  | 24,845 | ​ |  | 59,778 |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 35,666 | ​ | $ | 51,202 | ​ | $ | 14,838 | ​ | $ | 101,706 |
| Over time | ​ |  | 49,155 | ​ |  | 12,989 | ​ |  | 41,078 | ​ |  | 103,222 |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 |

- changed (2023-08-09):
[0001410578-23-001616:note_history:11]
| Nine months ended June 30, 2022 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 100,407 | ​ | $ | 191,832 | ​ | $ | 147,390 | ​ | $ | 439,629 |
| Government | ​ |  | 147,264 | ​ |  | 3,045 | ​ |  | 11,066 | ​ |  | 161,375 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 212,849 | ​ | $ | 122,021 | ​ | $ | 88,708 | ​ | $ | 423,578 |
| International | ​ |  | 34,822 | ​ |  | 72,856 | ​ |  | 69,748 | ​ |  | 177,426 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 99,464 | ​ | $ | 155,693 | ​ | $ | 43,488 | ​ | $ | 298,645 |
| Over time | ​ |  | 148,207 | ​ |  | 39,184 | ​ |  | 114,968 | ​ |  | 302,359 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |
  (was, 2023-05-10, similarity 0.9614):
[0001410578-23-000960:note_history:11]
| Six months ended March 31, 2022 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 61,489 | ​ | $ | 126,221 | ​ | $ | 92,941 | ​ | $ | 280,651 |
| Government | ​ |  | 93,576 | ​ |  | 1,455 | ​ |  | 6,256 | ​ |  | 101,287 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 133,313 | ​ | $ | 80,199 | ​ | $ | 54,047 | ​ | $ | 267,559 |
| International | ​ |  | 21,752 | ​ |  | 47,477 | ​ |  | 45,150 | ​ |  | 114,379 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 64,223 | ​ | $ | 102,037 | ​ | $ | 27,660 | ​ | $ | 193,920 |
| Over time | ​ |  | 90,842 | ​ |  | 25,639 | ​ |  | 71,537 | ​ |  | 188,018 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-08-09):
[0001410578-23-001616:note_history:12]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2023 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue within each reportable segment.
  (was, 2023-05-10, similarity 0.9809):
[0001410578-23-000960:note_history:12]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2023 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue within each reportable segment.

- changed (2023-08-09):
[0001410578-23-001616:note_history:13]
| Three months ended June 30, 2023 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 51,303 | ​ | $ | 88,442 | ​ | $ | 48,407 | ​ | $ | 188,152 |
| Government | ​ |  | 52,166 | ​ |  | 1,524 | ​ |  | 6,907 | ​ |  | 60,597 |
| Total revenues | ​ | $ | 103,469 | ​ | $ | 89,966 | ​ | $ | 55,314 | ​ | $ | 248,749 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 86,031 | ​ | $ | 55,011 | ​ | $ | 32,246 | ​ | $ | 173,288 |
| International | ​ |  | 17,438 | ​ |  | 34,955 | ​ |  | 23,068 | ​ |  | 75,461 |
| Total revenues | ​ | $ | 103,469 | ​ | $ | 89,966 | ​ | $ | 55,314 | ​ | $ | 248,749 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 48,496 | ​ | $ | 74,128 | ​ | $ | 11,496 | ​ | $ | 134,120 |
| Over time | ​ |  | 54,973 | ​ |  | 15,838 | ​ |  | 43,818 | ​ |  | 114,629 |
| Total revenues | ​ | $ | 103,469 | ​ | $ | 89,966 | ​ | $ | 55,314 | ​ | $ | 248,749 |
  (was, 2023-05-10, similarity 0.995):
[0001410578-23-000960:note_history:13]
| Three months ended March 31, 2023 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 48,228 | ​ | $ | 78,110 | ​ | $ | 43,188 | ​ | $ | 169,526 |
| Government | ​ |  | 50,754 | ​ |  | 1,051 | ​ |  | 7,805 | ​ |  | 59,610 |
| Total revenues | ​ | $ | 98,982 | ​ | $ | 79,161 | ​ | $ | 50,993 | ​ | $ | 229,136 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 82,516 | ​ | $ | 53,020 | ​ | $ | 27,504 | ​ | $ | 163,040 |
| International | ​ |  | 16,466 | ​ |  | 26,141 | ​ |  | 23,489 | ​ |  | 66,096 |
| Total revenues | ​ | $ | 98,982 | ​ | $ | 79,161 | ​ | $ | 50,993 | ​ | $ | 229,136 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 47,255 | ​ | $ | 64,080 | ​ | $ | 11,968 | ​ | $ | 123,303 |
| Over time | ​ |  | 51,727 | ​ |  | 15,081 | ​ |  | 39,025 | ​ |  | 105,833 |
| Total revenues | ​ | $ | 98,982 | ​ | $ | 79,161 | ​ | $ | 50,993 | ​ | $ | 229,136 |

- changed (2023-08-09):
[0001410578-23-001616:note_history:14]
| Nine months ended June 30, 2023 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial |  | $ | 136,271 | ​ | $ | 236,715 | ​ | $ | 137,587 | ​ | $ | 510,573 |
| Government | ​ | ​ | 149,163 | ​ |  | 3,457 | ​ |  | 20,193 | ​ |  | 172,813 |
| Total revenues |  | $ | 285,434 | ​ | $ | 240,172 | ​ | $ | 157,780 | ​ | $ | 683,386 |
| Geographic location: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States |  | $ | 237,481 | ​ | $ | 154,410 | ​ | $ | 87,253 | ​ | $ | 479,144 |
| International | ​ | ​ | 47,953 | ​ |  | 85,762 | ​ |  | 70,527 | ​ |  | 204,242 |
| Total revenues |  | $ | 285,434 | ​ | $ | 240,172 | ​ | $ | 157,780 | ​ | $ | 683,386 |
| Revenue recognition method: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time |  | $ | 129,355 | ​ | $ | 194,240 | ​ | $ | 32,565 | ​ | $ | 356,160 |
| Over time | ​ | ​ | 156,079 | ​ |  | 45,932 | ​ |  | 125,215 | ​ |  | 327,226 |
| Total revenues |  | $ | 285,434 | ​ | $ | 240,172 | ​ | $ | 157,780 | ​ | $ | 683,386 |
  (was, 2023-05-10, similarity 0.991):
[0001410578-23-000960:note_history:14]
| Six months ended March 31, 2023 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial |  | $ | 84,968 | ​ | $ | 148,273 | ​ | $ | 89,180 | ​ | $ | 322,421 |
| Government | ​ | ​ | 96,997 | ​ |  | 1,933 | ​ |  | 13,286 | ​ |  | 112,216 |
| Total revenues |  | $ | 181,965 | ​ | $ | 150,206 | ​ | $ | 102,466 | ​ | $ | 434,637 |
| Geographic location: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States |  | $ | 151,450 | ​ | $ | 99,399 | ​ | $ | 55,007 | ​ | $ | 305,856 |
| International | ​ | ​ | 30,515 | ​ |  | 50,807 | ​ |  | 47,459 | ​ |  | 128,781 |
| Total revenues |  | $ | 181,965 | ​ | $ | 150,206 | ​ | $ | 102,466 | ​ | $ | 434,637 |
| Revenue recognition method: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time |  | $ | 80,859 | ​ | $ | 120,111 | ​ | $ | 21,069 | ​ | $ | 222,039 |
| Over time | ​ | ​ | 101,106 | ​ |  | 30,095 | ​ |  | 81,397 | ​ |  | 212,598 |
| Total revenues |  | $ | 181,965 | ​ | $ | 150,206 | ​ | $ | 102,466 | ​ | $ | 434,637 |

- changed (2023-08-09):
[0001410578-23-001616:note_history:15]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2022 are presented in the tables below.
  (was, 2023-05-10, similarity 0.9576):
[0001410578-23-000960:note_history:15]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2022 are presented in the tables below.

- changed (2023-08-09):
[0001410578-23-001616:note_history:16]
| Three months ended June 30, 2022 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 38,918 | ​ | $ | 65,610 | ​ | $ | 54,449 | ​ | $ | 158,977 |
| Government | ​ |  | 53,688 | ​ |  | 1,591 | ​ |  | 4,810 | ​ |  | 60,089 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 79,536 | ​ | $ | 41,822 | ​ | $ | 34,662 | ​ | $ | 156,020 |
| International | ​ |  | 13,070 | ​ |  | 25,379 | ​ |  | 24,597 | ​ |  | 63,046 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 35,238 | ​ | $ | 53,656 | ​ | $ | 15,827 | ​ | $ | 104,721 |
| Over time | ​ |  | 57,368 | ​ |  | 13,545 | ​ |  | 43,432 | ​ |  | 114,345 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |
  (was, 2023-05-10, similarity 0.9951):
[0001410578-23-000960:note_history:16]
| Three months ended March 31, 2022 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 33,562 | ​ | $ | 63,379 | ​ | $ | 51,903 | ​ | $ | 148,844 |
| Government | ​ |  | 51,259 | ​ |  | 812 | ​ |  | 4,013 | ​ |  | 56,084 |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 72,621 | ​ | $ | 41,458 | ​ | $ | 31,071 | ​ | $ | 145,150 |
| International | ​ |  | 12,200 | ​ |  | 22,733 | ​ |  | 24,845 | ​ |  | 59,778 |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 35,666 | ​ | $ | 51,202 | ​ | $ | 14,838 | ​ | $ | 101,706 |
| Over time | ​ |  | 49,155 | ​ |  | 12,989 | ​ |  | 41,078 | ​ |  | 103,222 |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 |

- changed (2023-08-09):
[0001410578-23-001616:note_history:17]
| Nine months ended June 30, 2022 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 100,407 | ​ | $ | 191,832 | ​ | $ | 147,390 | ​ | $ | 439,629 |
| Government | ​ |  | 147,264 | ​ |  | 3,045 | ​ |  | 11,066 | ​ |  | 161,375 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 212,849 | ​ | $ | 122,021 | ​ | $ | 88,708 | ​ | $ | 423,578 |
| International | ​ |  | 34,822 | ​ |  | 72,856 | ​ |  | 69,748 | ​ |  | 177,426 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 99,464 | ​ | $ | 155,693 | ​ | $ | 43,488 | ​ | $ | 298,645 |
| Over time | ​ |  | 148,207 | ​ |  | 39,184 | ​ |  | 114,968 | ​ |  | 302,359 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |
  (was, 2023-05-10, similarity 0.9614):
[0001410578-23-000960:note_history:17]
| Six months ended March 31, 2022 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 61,489 | ​ | $ | 126,221 | ​ | $ | 92,941 | ​ | $ | 280,651 |
| Government | ​ |  | 93,576 | ​ |  | 1,455 | ​ |  | 6,256 | ​ |  | 101,287 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 133,313 | ​ | $ | 80,199 | ​ | $ | 54,047 | ​ | $ | 267,559 |
| International | ​ |  | 21,752 | ​ |  | 47,477 | ​ |  | 45,150 | ​ |  | 114,379 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 64,223 | ​ | $ | 102,037 | ​ | $ | 27,660 | ​ | $ | 193,920 |
| Over time | ​ |  | 90,842 | ​ |  | 25,639 | ​ |  | 71,537 | ​ |  | 188,018 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |

- changed (2023-08-09):
[0001410578-23-001616:note_history:18]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At June 30, 2023, the Company had $705.4 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 79% in the next twelve months.
  (was, 2023-05-10, similarity 0.9935):
[0001410578-23-000960:note_history:18]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At March 31, 2023, the Company had $740.9 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 79% in the next twelve months.

- changed (2023-08-09):
[0001410578-23-001616:note_history:19]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred. At June 30, 2023, contract assets and liabilities totaled $128.3 million and $133.6 million, respectively. During the first nine months of 2023, the Company recognized approximately $81 million in revenues that were included in the contract liabilities balance at September 30, 2022. At September 30, 2022, contract assets and liabilities totaled $125.2 million and $137.6 million, respectively.
  (was, 2023-05-10, similarity 0.9885):
[0001410578-23-000960:note_history:19]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred. At March 31, 2023, contract assets and liabilities totaled $128.2 million and $131.7 million, respectively. During the first six months of 2023, the Company recognized approximately $55 million in revenues that were included in the contract liabilities balance at September 30, 2022. At September 30, 2022, contract assets and liabilities totaled $125.2 million and $137.6 million, respectively.
