# ESE MD&A — 0001410578-23-001616


## mdna

[0001410578-23-001616:mdna:1]
[same as prior period, unchanged from 0001410578-23-000960:mdna:1]

[0001410578-23-001616:mdna:2]
[same as prior period, unchanged from 0001410578-23-000960:mdna:2]

[0001410578-23-001616:mdna:3]
References to the third quarters of 2023 and 2022 represent the three-month periods ended June 30, 2023 and 2022, respectively.

[0001410578-23-001616:mdna:4]
[same as prior period, unchanged from 0001410578-23-000960:mdna:4]

[0001410578-23-001616:mdna:5]
In the third quarter of 2023, sales, net earnings and diluted earnings per share were $248.7 million, $27.9 million and $1.08 per share, respectively, compared to $219.1 million, $23.2 million and $0.89 per share, respectively, in the third quarter of 2022. In the first nine months of 2023, sales, net earnings and diluted earnings per share were $683.4 million, $60.5 million and $2.34 per share, respectively, compared to $601.0 million, $51.3 million and $1.97 per share, respectively, in the first nine months of 2022.

[0001410578-23-001616:mdna:6]
[same as prior period, unchanged from 0001410578-23-000960:mdna:6]

[0001410578-23-001616:mdna:7]
In the third quarter of 2023, net sales of $248.7 million were $29.6 million, or 13.5%, higher than the $219.1 million in the third quarter of 2022. In the first nine months of 2023, net sales of $683.4 million were $82.4 million, or 13.7%, higher than the $601.0 million in the first nine months of 2022. The increase in net sales in the third quarter of 2023 as compared to the third quarter of 2022 was due to a $22.8 million increase in the USG segment, and a $10.9 million increase in the Aerospace & Defense segment, partially offset by a $4.0 million decrease in the Test segment. The increase in net sales in the first nine months of 2023 as compared to the first nine months of 2022 was due to a $45.3 million increase in the USG segment, and a $37.8 million increase in the Aerospace & Defense segment, partially offset by a $0.7 million decrease in the Test segment.

[0001410578-23-001616:mdna:8]
[same as prior period, unchanged from 0001410578-23-000960:mdna:8]

[0001410578-23-001616:mdna:9]
In the third quarter of 2023, net sales of $103.5 million were $10.9 million, or 11.8%, higher than the $92.6 million in the third quarter of 2022. In the first nine months of 2023, net sales of $285.4 million were $37.8 million, or 15.2%, higher than the $247.7 million in the first nine months of 2022. The sales increase in the third quarter of 2023 compared to the third quarter of 2022 was mainly due to a $6.5 million increase in net sales at Mayday, a $5.0 million increase in net sales at PTI, a $1.8 million increase in net sales at Globe/Westland combined, and a $3.9 million increase in net sales at Crissair, partially offset by a $6.3 million decrease in net sales at VACCO driven by timing of navy and space projects. The sales increase in the first nine months of 2023 compared to the first nine months of 2022 was mainly due to an $18.3 million increase in net sales at Mayday, a $9.6 million increase in net sales at PTI, an $8.4 million increase in net sales at Crissair, and a $2.6 million increase in net sales at Globe/Westland combined, partially offset by a $1.4 million decrease in net sales at VACCO. The increase in net sales at Mayday, PTI and Crissair in the third quarter and first nine months of 2023 as compared to the corresponding periods of 2022 was primarily due to an increase in commercial and defense aerospace sales driven by the rebound from the COVID-19 pandemic.

[0001410578-23-001616:mdna:10]
[same as prior period, unchanged from 0001410578-23-000960:mdna:10]

[0001410578-23-001616:mdna:11]
In the third quarter of 2023, net sales of $90.0 million were $22.8 million, or 33.9%, higher than the $67.2 million in the third quarter of 2022. In the first nine months of 2023, net sales of $240.2 million were $45.3 million, or 23.2%, higher than the $194.9 million in the first nine months of 2022. The increase in the third quarter and first nine months of 2023 compared to the corresponding periods of 2022 was mainly due to higher shipments of protection testing, condition monitoring and offline testing products and service revenue at Doble and an increase in product sales at NRG.

[0001410578-23-001616:mdna:12]
[same as prior period, unchanged from 0001410578-23-000960:mdna:12]

[0001410578-23-001616:mdna:13]
In the third quarter of 2023, net sales of $55.3 million were $4.0 million, or 6.7%, lower than the $59.3 million in the third quarter of 2022. In the first nine months of 2023, net sales of $157.8 million were $0.7 million, or 0.4%, lower than the $158.5 million in the first nine months of 2022. The decrease in the third quarter of 2023 as compared to the third quarter of 2022 was primarily due to a $4.4 million decrease in sales from the Company’s Asian operations driven by COVID disruptions in China and a $0.7 million decrease from the Company’s U.S. operations, partially offset by a $1.1 million increase in sales from the segment’s European operations due to strength from test and measurement chamber projects. The decrease in the first nine months of 2023 compared to the first nine months of 2022 was due to a $11.4 million decrease in sales from the Company’s Asian operations due to COVID disruptions in China, partially offset by a $10.7 million increase in sales from the segment’s European and U.S. operations due to timing of test and measurement chamber projects.

[0001410578-23-001616:mdna:14]
[same as prior period, unchanged from 0001410578-23-000960:mdna:14]

[0001410578-23-001616:mdna:15]
Backlog was $705.4 million at June 30, 2023 compared with $695.0 million at September 30, 2022. The Company received new orders totaling $213.3 million in the third quarter of 2023 compared to $254.9 million in the third quarter of 2022. Of the new orders received in the third quarter of 2023, $81.9 million related to Aerospace & Defense products, $85.5 million related to USG products, and $45.9 million related to Test products. Of the new orders received in the third quarter of 2022, $110.2 million related to Aerospace & Defense products, $74.4 million related to USG products, and $70.3 million related to Test products.

[0001410578-23-001616:mdna:16]
The Company received new orders totaling $693.8 million in the first nine months of 2023 compared to $715.8 million in the first nine months of 2022. Of the new orders received in the first nine months of 2023, $290.9 million related to Aerospace & Defense products, $250.3 million related to USG products, and $152.6 million related to Test products. Of the new orders received in the first nine months of 2022, $295.0 million related to Aerospace & Defense products, $227.1 million related to USG products, and $193.7 million related to Test products.

[0001410578-23-001616:mdna:17]
[same as prior period, unchanged from 0001410578-23-000960:mdna:17]

[0001410578-23-001616:mdna:18]
Selling, general and administrative (SG&A) expenses for the third quarter of 2023 were $55.4 million (22.3% of net sales), compared with $47.5 million (21.7% of net sales) for the third quarter of 2022. For the first nine months of 2023, SG&A expenses were $160.6 million (23.5% of net sales) compared to $142.1 million (23.6% of net sales) for the first nine months of 2022. The increase in SG&A in the first nine months of 2023 compared to the corresponding periods of 2022 was mainly due to higher expenses at Corporate due to executive management transition costs and professional fees and higher expenses at Doble as a result of increased sales and marketing and event costs.

[0001410578-23-001616:mdna:19]
[same as prior period, unchanged from 0001410578-23-000960:mdna:19]

[0001410578-23-001616:mdna:20]
Amortization of intangible assets was $7.1 million and $21.0 million for the third quarter and first nine months of 2023, respectively, compared to $6.4 million and $19.4 million for the corresponding periods of 2022. Amortization expenses consist of amortization of acquired intangible assets from acquisitions and other identifiable intangible assets (primarily software). The increase in amortization expense in the third quarter and first nine months of 2023 compared to the corresponding periods of 2022 was mainly due to the Company’s recent acquisition of CMT.

[0001410578-23-001616:mdna:21]
[same as prior period, unchanged from 0001410578-23-000960:mdna:21]

[0001410578-23-001616:mdna:22]
Other expenses, net, were $1.0 million in the third quarter of 2023 compared to ($0.1) million of income in the third quarter of 2022. Other expenses, net, were $1.7 million in the first nine months of 2023 compared to ($0.7) million of income in the first nine months of 2022. The principal items included in other expenses, net, in the third quarter and first nine months of 2023 included a bad debt write-off of $0.5 million due to a customer bankruptcy within the A&D segment and approximately $0.5 million of restructuring costs (mainly severance) in the first nine months of 2023. There were no individually significant items in other expenses (income), net, in the third quarter or first nine months of 2022.

[0001410578-23-001616:mdna:23]
[same as prior period, unchanged from 0001410578-23-000960:mdna:23]

[0001410578-23-001616:mdna:24]
The Company evaluates the performance of its operating segments based on EBIT, and provides EBIT on a consolidated basis, which is a non-GAAP financial measure. Please refer to the discussion of non-GAAP financial measures in Note 7 to the Consolidated Financial Statements, above. EBIT was $38.0 million (15.3% of net sales) for the third quarter of 2023 compared to $30.8 million (14.1% of net sales) for the third quarter of 2022. For the first nine months of 2023, EBIT was $84.2 million (12.3% of net sales) compared to $69.1 million (11.5% of net sales) for the first nine months of 2022.

[0001410578-23-001616:mdna:25]
[same as prior period, unchanged from 0001410578-23-000960:mdna:25]

[0001410578-23-001616:mdna:26]
| ​ | ​ | Three Months Ended | ​ | Nine Months Ended |
| ​ | ​ | June 30, | ​ | June 30, |
| (In thousands) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net earnings | ​ | $ | 27,943 | ​ | ​ | 23,173 | ​ | 60,548 | ​ | 51,280 |
| Plus: Interest expense, net | ​ |  | 2,495 | ​ | ​ | 1,331 | ​ | 6,422 | ​ | 3,084 |
| Plus: Income tax expense | ​ |  | 7,563 | ​ | ​ | 6,329 | ​ | 17,207 | ​ | 14,727 |
| Consolidated EBIT | ​ | $ | 38,001 | ​ | ​ | 30,833 | ​ | 84,177 | ​ | 69,091 |

[0001410578-23-001616:mdna:27]
[same as prior period, unchanged from 0001410578-23-000960:mdna:27]

[0001410578-23-001616:mdna:28]
EBIT in the third quarter of 2023 was $21.7 million (20.9% of net sales) compared to $20.7 million (22.4% of net sales) in the third quarter of 2022. EBIT in the first nine months of 2023 was $53.0 million (18.6% of net sales) compared to $45.0 million (18.2% of net sales) in the first nine months of 2022. The increase in EBIT in the third quarter and first nine months of 2023 compared to the corresponding periods of 2022 was mainly due to higher sales volumes at Mayday, PTI, Crissair and Globe partially offset by a decrease in EBIT at VACCO due to lower sales volumes as mentioned above and margin erosion on certain space development contracts. EBIT in the first nine months of 2023 was negatively impacted by a $0.6 million inventory step-up charge related to the CMT acquisition. EBIT in the first nine months of 2022 was negatively impacted by a $0.3 million inventory step-up charge related to the NEco acquisition.

[0001410578-23-001616:mdna:29]
[same as prior period, unchanged from 0001410578-23-000960:mdna:29]

[0001410578-23-001616:mdna:30]
EBIT in the third quarter of 2023 was $20.4 million (22.6% of net sales) compared to $13.1 million (19.5% of net sales) in the third quarter of 2022. EBIT in the first nine months of 2023 was $50.5 million (21.0% of net sales) compared to $37.8 million (19.4% of net sales) in the first nine months of 2022. The increase in EBIT in the third quarter and first nine months of 2023 compared to the corresponding periods of 2022 was mainly due to the higher sales volumes at Doble and NRG as mentioned above and price increases, partially offset by the impacts of wage and material cost inflation and increased commissions, travel, and tradeshow expenses. EBIT in the first nine months of 2022 was negatively impacted by approximately $0.5 million of inventory step-up charges related to the Altanova acquisition.

[0001410578-23-001616:mdna:31]
[same as prior period, unchanged from 0001410578-23-000960:mdna:31]

[0001410578-23-001616:mdna:32]
EBIT in the third quarter of 2023 was $8.6 million (15.6% of net sales) compared to $8.4 million (14.1% of net sales) in the third quarter of 2022. EBIT in the first nine months of 2023 was $21.3 million (13.5% of net sales) compared to $20.8 million (13.1% of net sales) in the first nine months of 2022. The increase in EBIT in the third quarter of 2023 compared to the third quarter of 2022 was primarily due to favorable product mix, price increases and cost reduction efforts in the segment’s U.S. operations, and higher sales volumes mainly from the segment’s European operations. The increase in EBIT in the first nine months of 2023 compared to the first nine months of 2022 was primarily due to the higher sales volumes from the segment’s European operations partially offset by a decrease in EBIT from the segment’s Asian operations due to COVID disruptions in China.

[0001410578-23-001616:mdna:33]
[same as prior period, unchanged from 0001410578-23-000960:mdna:33]

[0001410578-23-001616:mdna:34]
Corporate costs included in EBIT were $12.7 million and $40.6 million in the third quarter and first nine months of 2023, respectively, compared to $11.4 million and $34.6 million in the corresponding periods of 2022. The increase in Corporate costs in the third quarter of 2023 compared to the third quarter of 2022 was mainly due to an increase in medical insurance premiums. The increase in Corporate costs in the first nine months of 2023 compared to the corresponding period of 2022 was mainly due to executive management transition costs, and an increase in medical costs, professional fees and amortization expense of acquired intangible assets related to the CMT acquisition.

[0001410578-23-001616:mdna:35]
[same as prior period, unchanged from 0001410578-23-000960:mdna:35]

[0001410578-23-001616:mdna:36]
Interest expense was $2.5 million and $6.4 million in the third quarter and first nine months of 2023, respectively, and $1.3 million and $3.1 million in the corresponding periods of 2022. The increase in interest expense in the third quarter and first nine months of 2023 compared to the corresponding periods of 2022 was mainly due to higher average interest rates. The weighted average interest rates were 6.05% and 5.57% for the three and nine-month periods ending June 30, 2023, respectively, and 2.20% and 1.57% for the three and nine-month periods ending June 30, 2022.

[0001410578-23-001616:mdna:37]
[same as prior period, unchanged from 0001410578-23-000960:mdna:37]

[0001410578-23-001616:mdna:38]
The third quarter 2023 effective income tax rate was 21.3% compared to 21.5% in the third quarter of 2022. The effective income tax rate in the first nine months of 2023 was 22.1% compared to 22.3% for the first nine months of 2022. The income tax expense in the third quarter and first nine months of 2023 was favorably impacted by tax return to provision true-ups related to the federal research and development tax credit, decreasing the third quarter and year-to-date rate by 0.9% and 0.4%, respectively.

[0001410578-23-001616:mdna:39]
The income tax expense in the third quarter and first nine months of 2022 was favorably impacted by tax return to provision true-ups on U.S. tax on the distribution of foreign earnings, and the re-rating of deferred taxes as a result of a Vermont law change, decreasing the third quarter and year-to-date effective tax rate by 1.6% and 0.7%, respectively.

[0001410578-23-001616:mdna:40]
[same as prior period, unchanged from 0001410578-23-000960:mdna:39]

[0001410578-23-001616:mdna:41]
The Company’s overall financial position and liquidity remains strong. Working capital (current assets less current liabilities) increased to $284.9 million at June 30, 2023 from $254.5 million at September 30, 2022. Inventories increased by $30.0 million during this period mainly due to a $15.4 million increase within the USG segment and a $14.0 million increase within the Aerospace & Defense segment resulting primarily from the timing of receipt of raw materials to meet anticipated demand and an increase in work in process and finished goods inventories due to timing of manufacturing existing orders. Accounts receivable increased $27.5 million during this period mainly due to a $13.0 million increase within the Test segment, a $10.2 million increase within the USG segment and a $4.3 million increase within the A&D segment, due to timing of projects within the Test segment and higher sales volumes in the A&D and USG segments.

[0001410578-23-001616:mdna:42]
Net cash provided by operating activities was $29.2 million and $41.7 million in the first nine months of 2023 and 2022, respectively. The decrease in net cash provided by operating activities in the first nine months of 2023 as compared to the first nine months of 2022 was mainly driven by higher working capital requirements, including an increase in inventories and accounts receivable, and higher tax and interest payments.

[0001410578-23-001616:mdna:43]
Capital expenditures were $17.0 million and $25.9 million in the first nine months of 2023 and 2022, respectively. The decrease in the first nine months of 2023 compared to the prior year period was mainly due to the purchase of the NRG building of approximately $10 million in the first quarter of 2022. In addition, the Company incurred expenditures for capitalized software of $9.3 million and $9.4 million in the first nine months of 2023 and 2022, respectively.

[0001410578-23-001616:mdna:44]
[same as prior period, unchanged from 0001410578-23-000960:mdna:43]

[0001410578-23-001616:mdna:45]
On February 1, 2023, the Company acquired CMT Materials, LLC and its affiliate Engineered Syntactic Systems, LLC (CMT) for a purchase price of approximately $18 million. CMT, based in Attleboro, Massachusetts, is a leading supplier of syntactic materials for buoyancy and specialty applications. Since the date of acquisition, the operating results for the CMT business have been included as part of Globe within the A&D segment.

[0001410578-23-001616:mdna:46]
Credit Facility

[0001410578-23-001616:mdna:47]
At June 30, 2023, the Company had approximately $345 million available to borrow under its bank credit facility, a $250 million increase option, and $56.1 million cash on hand. At June 30, 2023, the Company had $148 million of outstanding borrowings under the credit facility in addition to outstanding letters of credit of $7.4 million. Cash flow from operations and borrowings under the Company’s credit facility are expected to meet the Company’s capital requirements and operational needs for the foreseeable future. The Company’s ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.

[0001410578-23-001616:mdna:48]
[same as prior period, unchanged from 0001410578-23-000960:mdna:47]

[0001410578-23-001616:mdna:49]
During the first nine months of 2023, the Company repurchased approximately 140,000 shares for approximately $12.4 million. For further information on the share repurchases during the third quarter of 2023, see Part II, Item 2 of this Report.

[0001410578-23-001616:mdna:50]
[same as prior period, unchanged from 0001410578-23-000960:mdna:49]

[0001410578-23-001616:mdna:51]
A dividend of $0.08 per share, totaling $2.1 million, was paid on October 18, 2022 to stockholders of record as of October 4, 2022. A dividend of $0.08 per share, totaling $2.1 million, was paid on January 20, 2023 to stockholders of record as of January 5, 2023. A dividend of $0.08 per share, totaling $2.1 million, was paid on April 18, 2023 to stockholders of record as of April 3, 2023. Subsequent to June 30, 2023, a quarterly dividend of $0.08 per share, totaling $2.1 million, was paid on July 19, 2023 to stockholders of record as of July 5, 2023.

[0001410578-23-001616:mdna:52]
CRITICAL ACCOUNTING ESTIMATES

[0001410578-23-001616:mdna:53]
[same as prior period, unchanged from 0001410578-23-000960:mdna:52]

[0001410578-23-001616:mdna:54]
[same as prior period, unchanged from 0001410578-23-000960:mdna:53]

[0001410578-23-001616:mdna:55]
Contingencies

[0001410578-23-001616:mdna:56]
As a normal incident of the business in which the Company is engaged, various claims, charges and litigation are asserted or commenced against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. In the opinion of Management, the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company, are adequately reserved, are covered by insurance, or would not have a material adverse effect on the Company’s results from operations, capital expenditures, or competitive position.

[0001410578-23-001616:mdna:57]
[same as prior period, unchanged from 0001410578-23-000960:mdna:56]

[0001410578-23-001616:mdna:58]
Investors are cautioned that such statements are only predictions and speak only as of the date of this Form 10-Q, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment, including but not limited to those described in Item 1A, “Risk Factors,” of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2022, and the following: the continuing impact of the COVID-19 pandemic including the impacts of known or unknown COVID-19 variants, labor shortages, facility closures, shelter in place policies or quarantines, material shortages, transportation delays, termination or delays of Company contracts and the inability of our suppliers or customers to perform, the impacts of natural disasters on the Company’s operations and those of the Company’s customers and suppliers; the timing and content of future contract awards or customer orders; the appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer contracts or orders; weakening of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer

[0001410578-23-001616:mdna:59]
insolvencies; competition; intellectual property rights; technical difficulties; the availability of selected acquisitions; delivery delays or defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability of certain raw materials; inflationary pressures on the Company’s costs of labor, materials, components and supplies; labor disputes; changes in U.S. tax laws and regulations; other changes in laws and regulations including but not limited to changes in accounting standards and foreign taxation; changes in interest rates; costs relating to environmental matters arising from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the integration of recently acquired businesses.
