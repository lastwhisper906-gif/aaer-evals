# ESE 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001410578-22-003540:item_9a:1]
Item 9A. Controls and Procedures

[0001410578-22-003540:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001410578-22-003540:item_9a:3]
Our Chief Executive Officer and Chief Financial Officer (“Certifying Officers”) carried out an evaluation of the effectiveness of the design and operation of the Company’s disclosure controls and procedures, as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the Exchange Act) as of September 30, 2022. The evaluation was conducted under the supervision and with the participation of the Company’s Management, including the Company’s Chief Executive Officer and Chief Financial Officer, using the Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). Disclosure controls and procedures are designed to ensure that information required to be disclosed by the Company in reports filed or submitted under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the Securities and Exchange Commission’s rules and forms. Based upon that evaluation, the Company’s Chief Executive Officer and Chief Financial Officer concluded that the Company’s disclosure controls and procedures were effective as of September 30, 2022.

[0001410578-22-003540:item_9a:4]
Management’s Report on Internal Control Over Financial Reporting

[0001410578-22-003540:item_9a:5]
Management is responsible for establishing and maintaining adequate internal control over financial reporting, as defined in Rules 13a-15(f) and 15d-15(f) of the Exchange Act. The Company’s Management, with participation of the Certifying Officers, under the oversight of our Board of Directors, evaluated the effectiveness of the Company’s internal control over financial reporting as of September 30, 2022 using the framework in Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).  Because of its inherent limitations, any system of internal control over financial reporting, no matter how well designed, may not prevent or detect misstatement due to the possibility that a control can be circumvented or overridden or that misstatements due to error or fraud may occur that are not detected. Also, because of changes in conditions, internal control effectiveness may vary over time.

[0001410578-22-003540:item_9a:6]
Management assessed the effectiveness of the Company’s internal control over financial reporting as of September 30, 2022, using criteria established in Internal Control – Integrated Framework (2013) issued by COSO and concluded that the Company maintained effective internal control over financial reporting as of September 30, 2022, based on these criteria.

[0001410578-22-003540:item_9a:7]
Our internal control over financial reporting as of September 30, 2022, has been audited by Grant Thornton, an independent registered public accounting firm, as stated in its report which is included herein.

[0001410578-22-003540:item_9a:8]
Changes in Internal Control Over Financial Reporting

[0001410578-22-003540:item_9a:9]
No changes in the Company’s internal control over financial reporting (as defined in Rule 13a-15(f) under the Exchange Act) occurred during the fiscal quarter ended September 30, 2022, that have materially affected, or are reasonably likely to materially affect, the Company’s internal control over financial reporting.
