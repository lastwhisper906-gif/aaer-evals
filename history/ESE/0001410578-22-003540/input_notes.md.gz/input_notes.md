# ESE notes — 0001410578-22-003540


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001410578-22-003540:notes:1]
1.      Summary of Significant Accounting Policies

[0001410578-22-003540:notes:2]
A.      Principles of Consolidation

[0001410578-22-003540:notes:3]
The Consolidated Financial Statements include the accounts of ESCO Technologies Inc. (ESCO) and its wholly owned subsidiaries. Except where the context indicates otherwise, the terms “Company”, “we”, “our” and “us” are used in this report to refer to ESCO together with its subsidiaries through which its businesses are conducted. All significant intercompany transactions and accounts have been eliminated in consolidation.

[0001410578-22-003540:notes:4]
B.      Basis of Presentation

[0001410578-22-003540:notes:5]
Our fiscal year ends on September 30. Throughout the Consolidated Financial Statements, unless the context indicates otherwise, references to a year (for example 2022) refer to fiscal year ending on September 30 of that year. Certain prior period amounts have been reclassified to conform to the current period presentation.

[0001410578-22-003540:notes:6]
Our former Technical Packaging segment is reflected as discontinued operations in the Consolidated Financial Statements and related notes for all periods presented, in accordance with accounting principles generally accepted in the United States of America (GAAP).

[0001410578-22-003540:notes:7]
C.      Nature of Operations

[0001410578-22-003540:notes:8]
We are organized based on the products and services we offer and we currently classify our business operations in three segments for financial reporting purposes:  Aerospace & Defense (A&D), Utility Solutions Group (USG), and RF Shielding and Test (Test).

[0001410578-22-003540:notes:9]
A&D: The companies within this segment primarily design and manufacture specialty filtration products, including hydraulic filter elements and fluid control devices used in commercial aerospace applications; unique filter mechanisms used in micro-propulsion devices for satellites; custom designed filters for manned aircraft and submarines; products and systems to reduce vibration and/or acoustic signatures and otherwise reduce or obscure a vessel’s signature, and other communications, sealing, surface control and hydrodynamic related applications to enhance U.S. Navy maritime survivability; precision-tolerance machined components for the aerospace and defense industry; and metal processing services; and miniature electro-explosive devices for military aircraft ejection seats and missile arming devices.

[0001410578-22-003540:notes:10]
USG: The companies within this segment provide diagnostic testing solutions that enable electric power grid operators to assess the integrity of high-voltage power delivery equipment, as well as decision support tools for the renewable energy industry, primarily wind and solar.

[0001410578-22-003540:notes:11]
Test: The companies within this segment provide their customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy.

[0001410578-22-003540:notes:12]
In addition, for reporting certain financial information we treat Corporate activities as a separate segment.

[0001410578-22-003540:notes:13]
D.      Use of Estimates

[0001410578-22-003540:notes:14]
The preparation of financial statements in conformity with GAAP requires Management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.

[0001410578-22-003540:notes:15]
E.      Revenue Recognition

[0001410578-22-003540:notes:16]
We recognize revenue when control of the goods or services promised under the contract is transferred to the customer either at a point in time (e.g., upon delivery) or over time (e.g., as we perform under the contract). We account for a contract when it has approval and commitment from both parties, the rights and payment terms of the parties are identified, the contract has commercial substance and collectability of consideration is probable. We review contracts to determine whether there are one or multiple performance obligations. A performance obligation is a promise to transfer a distinct good or service to a customer and represents the unit of accounting for revenue recognition. For contracts with multiple performance obligations, we allocate the expected

[0001410578-22-003540:notes:17]
consideration, or the transaction price, to each performance obligation identified in the contract based on the relative standalone selling price of each performance obligation. We then recognize revenue for the transaction price allocated to the performance obligation when control of the promised goods or services underlying the performance obligation is transferred.

[0001410578-22-003540:notes:18]
Payment terms with our customers vary by the type and location of the customer and the products or services offered. We do not adjust the promised amount of consideration for the effects of significant financing components based on the expectation that the period between when we transfer a promised good or service to a customer and when the customer pays for that good or service will be one year or less. Arrangements with customers that include payment terms extending beyond one year are not significant. We account for shipping and handling costs on a gross basis and include them in net sales. We account for taxes collected from customers and remitted to governmental authorities on a net basis and exclude them from net sales.

[0001410578-22-003540:notes:19]
A&D: Within the A&D segment, approximately 40% of revenues (approximately 17% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial and military customers and have a single performance obligation as there is only one good promised or the promise to transfer the goods or services is not distinct or separately identifiable from other promises in the contract. The transaction price for these contracts reflects our estimate of returns and discounts, which are based on historical, current and forecasted information to determine the expected amount to which we will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to the customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in cost of goods sold in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

[0001410578-22-003540:notes:20]
Approximately 60% of the segment’s revenues (approximately 25% of consolidated revenues) are accounted for over time as the product does not have an alternative use and we have an enforceable right to payment for costs incurred plus a reasonable margin or the inventory is owned by the customer. The related contracts are primarily cost-plus or fixed price contracts related to the design, development and manufacture of complex fluid control products, quiet valves, manifolds, shock and vibration dampening, thermal insulation and systems primarily for the commercial aerospace and military (U.S. Government) markets. The contracts may contain multiple products, which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. Our contracts are frequently modified for changes in contract specifications and requirements. Most of our contract modifications are for products that are not distinct from the existing contract and are accounted for as part of that existing contract.

[0001410578-22-003540:notes:21]
Contracts with the U.S. Government generally contain clauses that provide lien rights to work-in-process along with clauses that allow the customer to unilaterally terminate the contract for convenience, pay us for costs incurred plus a reasonable profit and take control of any work-in-process. Due to the continuous transfer of control to the U.S. Government, we recognize revenue over the time that we perform under the contract.

[0001410578-22-003540:notes:22]
Selecting the method to measure progress towards completion for the commercial and military contracts requires judgment and is based on the nature of the products or service to be provided. We generally use the cost-to-cost method to measure progress for our Aerospace & Defense segment contracts, as the rate at which costs are incurred to fulfill a contract best depicts the transfer of control to the customer. Under this method, we measure the extent of progress towards completion based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and record revenue proportionally as costs are incurred based on an estimated profit margin.

[0001410578-22-003540:notes:23]
The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Certain of our long-term contracts contain incentive fees that can increase the transaction price. These variable amounts generally are awarded upon achievement of certain performance metrics, program milestones or cost targets and can be based upon customer discretion. We include estimated amounts in the transaction price to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimates of variable consideration and determination of whether to include estimated

[0001410578-22-003540:notes:24]
amounts in the transaction price are based largely on an assessment of our anticipated performance and all other information that is reasonably available to us.

[0001410578-22-003540:notes:25]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to one or more years, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

[0001410578-22-003540:notes:26]
Under the typical payment terms of our long term fixed price contracts, the customer pays us either performance-based or progress payments. Performance-based payments represent interim payments based on quantifiable measures of performance or on the achievement of specified events or milestones. Progress payments are interim payments of costs incurred as the work progresses. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred, which we present as contract assets and contract liabilities, respectively, in the Consolidated Balance Sheets. We classify amounts billed and due from our customers in Accounts receivable, net. For short term fixed price and cost-type contracts, we are generally paid within a short period of time.

[0001410578-22-003540:notes:27]
For contracts where revenue is recognized over time, we recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. We have net revenue recognized in the current year from performance obligations satisfied in the prior year due to changes in our estimated costs to complete the related performance obligations. We recognize anticipated losses on contracts in full in the period in which the losses become known.

[0001410578-22-003540:notes:28]
USG: Within the USG segment, approximately 80% of revenues (approximately 25% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and is accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which we will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. We generally do not treat them as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general and administrative costs in the period they are incurred. We record taxes collected from customers and remitted to government authorities on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

[0001410578-22-003540:notes:29]
Approximately 20% of the segment’s revenues (approximately 6% of consolidated revenues) are recognized over time as services are performed. The services accounted for under this method include an obligation to provide testing services using hardware and embedded software, software maintenance, training, lab testing, and consulting services. Typically, the related contracts contain a bundle of goods and services that are integrated in the context of the contract. Therefore, the goods and services are not distinct and we have a single performance obligation. Selecting the method to measure progress towards completion for these contracts requires judgment and is based on the nature of the products and service to be provided. We will recognize revenue as a series of distinct services based on each day of providing services (straight-line over the contract term) for our USG segment contracts. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Under the typical payment terms of our service contracts, the customer pays us in advance of when services are performed. Because of the timing difference of revenue recognition and customer payment, which is typically received upon commencement of the contract, these contracts result in deferred revenue, which we present as contract liabilities, in the Consolidated Balance Sheets.

[0001410578-22-003540:notes:30]
Included in this category, approximately 6% of the segment’s revenues (approximately 2% of consolidated revenues) are recognized based on the terms of the software contract. For contracts that transfer a software license to the customer, revenue will be recognized at a point in time. These type of software contracts represent a right to use the software, or a functional license, in which revenue should be recognized upon transfer of the license. For contracts in software as a service (SaaS) arrangements, revenue will be

[0001410578-22-003540:notes:31]
recognized over time. The customer receives and consumes the benefits of the SaaS arrangement through access to the system which is for a stated period. We will recognize revenue based on each day of providing access (straight-line over the contract term). The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Under the typical payment terms of our software contracts, the customer pays us in advance of when services are performed. Because of the timing difference of revenue recognition and customer payment, these contracts result in deferred revenue, which we present as contract liabilities, in the Consolidated Balance Sheets.

[0001410578-22-003540:notes:32]
Test: Within the Test segment, approximately 25% of revenues (approximately 7% of consolidated revenues) are recognized at a point in time when products such as, antennas and probes are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct because the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in the context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which we will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

[0001410578-22-003540:notes:33]
Approximately 75% of the segment’s revenues (approximately 20% of consolidated revenues) are recorded over time as the product does not have an alternative use and we have an enforceable right to payment for costs incurred plus a reasonable margin. Products accounted for under this guidance include the construction and installation of test chambers to a buyer’s specifications that provide its customers with the ability to measure and contain magnetic, electromagnetic and acoustic energy. The goods and services related to each installed test chamber are not distinct due to the significant amount of integration provided and each installed chamber is accounted for as a single performance obligation. Selecting the method to measure progress towards completion for these contracts requires judgment and is based on the nature of the products and service to be provided. We use milestones to measure progress for our Test segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. For arrangements that are accounted for under this guidance, we estimate profit as the difference between total revenue and total estimated cost of a contract and recognize these revenues and costs based primarily on contract milestones. The transaction price for our contracts is typically fixed price and represents our best estimate of the consideration we will receive.

[0001410578-22-003540:notes:34]
We estimate total contract cost utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to a year, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

[0001410578-22-003540:notes:35]
Under the typical payment terms of our fixed price contracts, the customer pays us either based on progress or based on a fixed billing schedule within the contract. Performance-based payments represent interim payments based on noted progress points as the work progresses. Because of the timing difference of revenue recognition and customer billing, these contracts result in revenue recognized in excess of billings and billings in excess of revenue recognized, which we present as contract assets and contract liabilities, respectively, in the Consolidated Balance Sheets. Amounts billed and due from our customers are classified in Accounts receivable, net.

[0001410578-22-003540:notes:36]
For contracts where revenue is recognized over time, we generally recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. We have net revenue recognized in the current year from performance obligations satisfied in the prior year due to changes in our estimated costs to complete the related performance obligations. We recognize anticipated losses on contracts in full in the period in which the losses become probable and estimable.

[0001410578-22-003540:notes:37]
Contract Assets and Liabilities

[0001410578-22-003540:notes:38]
Contract assets arise from contracts when revenue is recognized over time and the amount of revenue recognized, including our estimate of variable consideration that has been included in the transaction price, exceeds the amount billed to the customer. These amounts are included in contract assets until the right to payment is no longer conditional on events other than the passage of time. These contract assets are reclassified to receivables when the right to consideration becomes unconditional. Contract liabilities include deposits, deferred revenue, upfront payments and billings in excess of revenue recognized. We include liabilities for customer rebates and discounts in other current liabilities in the Consolidated Balance Sheets.

[0001410578-22-003540:notes:39]
See the further discussion of our revenue recognition in Note 15 below.

[0001410578-22-003540:notes:40]
F.      Cash and Cash Equivalents

[0001410578-22-003540:notes:41]
Cash equivalents include temporary investments that are readily convertible into cash, such as money market funds, with original maturities of three months or less.

[0001410578-22-003540:notes:42]
G.      Accounts Receivable

[0001410578-22-003540:notes:43]
We reduce accounts receivable by an allowance for amounts that we estimate are uncollectible in the future. This estimated allowance is based on Management’s evaluation of the financial condition of the customer and historical write-off experience.

[0001410578-22-003540:notes:44]
H.      Inventories

[0001410578-22-003540:notes:45]
We value inventories at the lower of cost (first-in, first-out) or net realizable value. We regularly review inventories for excess quantities and obsolescence based upon historical experience, specific identification of discontinued items, future demand, and market conditions. Inventories under long-term contracts reflect accumulated production costs, factory overhead, initial tooling and other related costs less the portion of such costs charged to cost of sales.

[0001410578-22-003540:notes:46]
I.      Property, Plant and Equipment

[0001410578-22-003540:notes:47]
Property, plant and equipment are recorded at cost. Depreciation and amortization are computed primarily on a straight-line basis over the estimated useful lives of the assets: buildings, 10-40 years; machinery and equipment, 3-10 years; and office furniture and equipment, 3-10 years. Leasehold improvements are amortized over the remaining term of the applicable lease or their estimated useful lives, whichever is shorter. Long-lived tangible assets are reviewed for impairment whenever events or changes in business circumstances indicate the carrying value of the assets may not be recoverable. Impairment losses are recognized based on fair value.

[0001410578-22-003540:notes:48]
J.      Leases

[0001410578-22-003540:notes:49]
Our lease agreements primarily relate to office space, manufacturing facilities, and machinery and equipment. We determine at lease inception whether an arrangement that provides control over the use of an asset is a lease. We recognize at lease commencement a right-of-use (ROU) asset and lease liability based on the present value of the future lease payments over the lease term. We have elected not to recognize a ROU asset and lease liability for leases with terms of 12 months or less. Certain of our leases include options to extend the term of the lease for up to 20 years. When it is reasonably certain that we will exercise the option, Management includes the impact of the option in the lease term for purposes of determining total future lease payments. As most of our lease agreements do not explicitly state the discount rate implicit in the lease, Management uses our incremental borrowing rate on the commencement date to calculate the present value of future payments based on the tenor of each arrangement.

[0001410578-22-003540:notes:50]
K.      Goodwill and Other Long-Lived Intangible Assets

[0001410578-22-003540:notes:51]
Goodwill represents the excess of purchase price over the fair value of net identifiable assets acquired in business acquisitions. Management annually reviews goodwill and other long-lived assets with indefinite useful lives for impairment or whenever events or changes in circumstances indicate the carrying amount may be less than fair value. If we determine that the carrying value of the long-lived asset or reporting unit is less than fair value, we record a permanent impairment charge for the amount by which the carrying value of the long-lived asset exceeds its fair value. We measure the fair value of our reporting units based on a discounted cash flow method using a discount rate determined by Management to be commensurate with the risk inherent in each of our reporting units’

[0001410578-22-003540:notes:52]
current business models. We determine the fair value of trade names using a generally accepted valuation method based on an income approach called the relief from royalty method. During 2022, Management performed a quantitative impairment analysis, which included a detailed calculation of the fair value of our trade names and reporting units related to certain reporting units within these segments. A step 0 analysis was performed on the other reporting units for which a quantitative analysis was not performed. The results of these impairment analyses indicated that the fair values of the trade names and reporting units are not less than their carrying values. Our estimates of discounted cash flows to derive the fair value were measured in accordance with ASC 350, Intangibles – Goodwill and Other. We are using estimates of discounted cash flows that may change, and if they change negatively it could result in the need to write down those assets to fair value.

[0001410578-22-003540:notes:53]
Other intangible assets represent costs allocated to identifiable intangible assets, principally customer relationships, capitalized software, patents, trademarks, and technology rights. We amortize intangible assets with estimable useful lives over their respective estimated useful lives to their estimated residual values, and review them for impairment whenever events or changes in business circumstances indicate the carrying value of the assets may not be recoverable.

[0001410578-22-003540:notes:54]
See Note 4 regarding goodwill and other intangible assets activity.

[0001410578-22-003540:notes:55]
L.      Capitalized Software

[0001410578-22-003540:notes:56]
Costs incurred for the development of computer software that will be sold, leased, or otherwise marketed are charged to research and development expense when incurred, until technological feasibility has been established for the product. Technological feasibility is typically established upon completion of a detailed program design. Costs incurred after this point are capitalized on a project-by-project basis. Capitalized costs consist of internal and external development costs. Upon general release of the product to customers, we cease capitalization and begin amortization, which is calculated on a project-by-project basis as the greater of (1) the ratio of current gross revenues for a product to the total of current and anticipated future gross revenues for the product or (2) the straight-line method over the estimated economic life of the product. We generally amortize software development costs over a three-to-seven year period based upon the estimated future economic life of the product. Factors we consider in determining the estimated future economic life of the product include anticipated future revenues, and changes in software and hardware technologies. Management annually reviews the carrying values of capitalized costs for impairment or whenever events or changes in circumstances indicate the carrying amount may not be recoverable. If expected cash flows are insufficient to recover the carrying amount of the asset, then we recognize an impairment loss to state the asset at its net realizable value.

[0001410578-22-003540:notes:57]
M.      Income Taxes

[0001410578-22-003540:notes:58]
We account for income taxes under the asset and liability method. We recognize deferred tax assets and liabilities for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. We measure deferred tax assets and liabilities using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. We may reduce deferred tax assets by a valuation allowance if it is more likely than not that some portion or all of the deferred tax assets will not be realized. We recognize the effect on deferred tax assets and liabilities of a change in tax rates in income in the period that includes the enactment date. We regularly review our deferred tax assets for recoverability and establish a valuation allowance when Management believes it is more likely than not such assets will not be recovered, taking into consideration historical operating results, expectations of future earnings, tax planning strategies, and the expected timing of the reversals of existing temporary differences. Our policy is to include interest related to unrecognized tax benefits in income tax expense and penalties in operating expense.

[0001410578-22-003540:notes:59]
N.      Research and Development Costs

[0001410578-22-003540:notes:60]
Company-sponsored research and development costs include research and development and bid and proposal efforts related to our products and services. We charge Company-sponsored product development costs to expense when incurred. Customer-sponsored research and development costs refer to certain situations whereby customers provide funding to support specific contractually defined research and development costs. We account for customer-sponsored research and development costs incurred pursuant to contracts similarly to other program costs. Total Company and customer-sponsored research and development expenses were approximately $12.3 million, $15.4 million and $13.3 million for 2022, 2021 and 2020, respectively.

[0001410578-22-003540:notes:61]
O.      Foreign Currency Translation

[0001410578-22-003540:notes:62]
We translate the financial statements of our foreign operations into U.S. dollars in accordance with FASB ASC Topic 830, Foreign Currency Matters. We record the resulting translation adjustments as a separate component of accumulated other comprehensive income.

[0001410578-22-003540:notes:63]
P.      Earnings Per Share

[0001410578-22-003540:notes:64]
We calculate basic earnings per share using the weighted average number of common shares outstanding during the period. We calculate diluted earnings per share using the weighted average number of common shares outstanding during the period plus shares issuable upon the assumed exercise of dilutive vesting of unvested restricted units (restricted shares) using the treasury stock method. There are no anti-dilutive shares.

[0001410578-22-003540:notes:65]
The number of shares used in the calculation of earnings per share for each year presented is as follows:

[0001410578-22-003540:notes:66]
| (in thousands) |  | 2022 |  | 2021 |  | 2020 |
| Weighted Average Shares Outstanding — Basic |  | 25,933 |  | 26,046 |  | 26,010 |
| Dilutive Restricted Shares | ​ | 134 | ​ | 179 | ​ | 125 |
| Shares — Diluted |  | 26,067 |  | 26,225 |  | 26,135 |

[0001410578-22-003540:notes:67]
Q.      Share-Based Compensation

[0001410578-22-003540:notes:68]
We provide compensation benefits to certain key employees under several share-based plans providing for performance-accelerated, performance-based and/or time-vested restricted stock unit awards, and to non-employee directors under a separate compensation plan for non-employee directors. We measure share-based payment expense at the grant date based on the fair value of the award and recognize it on a straight-line basis over the requisite service period (generally the vesting period of the award) and/or if the performance criteria are deemed probable.

[0001410578-22-003540:notes:69]
R.      Accumulated Other Comprehensive Loss

[0001410578-22-003540:notes:70]
Accumulated other comprehensive loss of $(31.8) million at September 30, 2022 consisted primarily of currency translation adjustments.

[0001410578-22-003540:notes:71]
S.      Fair Value Measurements

[0001410578-22-003540:notes:72]
Fair value is defined as the price at which an asset could be exchanged in a current transaction between knowledgeable, willing parties or the amount that would be paid to transfer a liability to a new obligor, not the amount that would be paid to settle the liability with the creditor. Where available, we base fair value on observable market prices or parameters or derived from such prices or parameters. Where observable prices or inputs are not available, we apply valuation models. These valuation techniques involve some level of Management estimation and judgment, the degree of which is dependent on the price transparency for the instruments or market and the instruments’ complexity.

[0001410578-22-003540:notes:73]
The accounting guidance establishes a three-level hierarchy for disclosure of fair value measurements, based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date, as follows:

[0001410578-22-003540:notes:74]
Level 1 – Inputs to the valuation methodology are quoted prices (unadjusted) for identical assets or liabilities in active markets.

[0001410578-22-003540:notes:75]
Level 2 – Inputs to the valuation methodology include quoted prices for similar assets and liabilities in active markets, and inputs that are observable for the asset or liability, either directly or indirectly, for substantially the full term of the financial instrument.

[0001410578-22-003540:notes:76]
Level 3 – Inputs to the valuation methodology are unobservable and significant to the fair value measurement.

[0001410578-22-003540:notes:77]
Financial Assets and Liabilities

[0001410578-22-003540:notes:78]
We have estimated the fair value of our financial instruments as of September 30, 2022 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, payables and other current assets and liabilities approximate fair value because of the short maturity of those instruments. The carrying amounts due under the revolving credit facility approximate fair value as the interest on outstanding borrowings is calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at our election.

[0001410578-22-003540:notes:79]
Nonfinancial Assets and Liabilities

[0001410578-22-003540:notes:80]
Our nonfinancial assets such as property, plant and equipment, inventories, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during 2022.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001410578-22-003540:notes:81]
2.    Acquisitions

[0001410578-22-003540:notes:82]
2022

[0001410578-22-003540:notes:83]
On November 4, 2021, we acquired Networks Electronic Company, LLC (NEco) for a purchase price of approximately $15.4 million, net of cash acquired. NEco, based in Chatsworth, California, provides miniature electro-explosive devices utilized in mission-critical defense and aerospace applications. Since the date of acquisition, the operating results for the NEco business have been included as part of PTI in the A&D segment. The acquisition date fair value of the assets acquired and liabilities assumed primarily were as follows: approximately $0.6 million of accounts receivable, $1.5 million of inventory, $0.2 million of property, plant and equipment, $0.7 million of accounts payable and accrued expenses, $8.1 million of identifiable intangible assets, mainly consisting of customer relationships totaling $6.3 million. The acquired goodwill of $5.7 million related to excess value associated with opportunities to expand the services and products that the Company can offer to its customers. We anticipate that the goodwill will be deductible for tax purposes.

[0001410578-22-003540:notes:84]
2021

[0001410578-22-003540:notes:85]
On August 9, 2021 we acquired the assets of Phenix Technologies, Inc. (Phenix), for a purchase price of approximately $47.2 million in cash. Phenix, based in Accident, Maryland, is a leading designer and manufacturer of high voltage, high current, high power test systems and components and solutions supporting the electric utility industry, high voltage test laboratories, and field service organizations worldwide. Since the date of acquisition, the operating results for the Phenix business have been included as part of the USG segment. The acquisition date fair value of the assets acquired and liabilities assumed were as follows: approximately $2.6 million of accounts receivable, $5.8 million of inventory, $8.0 million of property, plant and equipment, $6.2 million of accounts payable and accrued expenses, $3.7 million for tradenames, $9.6 million of customer relationships and $0.5 million of miscellaneous items. The tradename was determined to have an indefinite useful life and the customer relationships were determined to have a useful life of 13 years. The acquired goodwill of $18.7 million relates to excess value associated with opportunities to expand the services and products that the Company can offer to its customers, with approximately $15 million of goodwill deductible for tax purposes. During the fourth quarter of 2022, the Company received $4.6 million upon finalization of the working capital adjustment.

[0001410578-22-003540:notes:86]
On July 29, 2021 we acquired I.S.A. – Altanova Group S.r.l., (Altanova), headquartered in Taino, Italy, for a purchase price of approximately $115 million, net of cash acquired. Altanova is a supplier of diagnostic products, monitoring systems and services related to power generation, transmission and distribution networks, renewable energy and storage, and process industries to customers in more than 100 countries. Since the date of acquisition, the operating results for the Altanova business have been included as part of the USG segment. The acquisition date fair value of the assets acquired and liabilities assumed were as follows: $9.7 million of accounts receivable, $5.6 million of inventory, $1.2 million of property, plant and equipment, $9.0 million of other assets, $12.8 million of accounts payable and accrued expenses, $6.9 million of other liabilities, $16.7 million of deferred tax liabilities, $50.5 million of customer relationships and $4.3 million of tradenames. The tradename was determined to have a useful life of ten years and the customer relationships were determined to have a useful life of twenty years. The acquired goodwill of $71.1 million relates to the excess value associated with opportunities to expand the services and products that the Company can offer to its customers, access to new markets, and synergies anticipated by combining Altanova with existing USG businesses. The goodwill is not deductible for tax purposes.

[0001410578-22-003540:notes:87]
We accounted for these acquisitions using the purchase method of accounting, and accordingly, we allocated the respective purchase prices to the assets (including intangible assets) acquired and liabilities assumed based on estimated fair values at the date of acquisition. We have included the financial results from these acquisitions in our financial statements from the date of acquisition.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001410578-22-003540:notes:88]
3.      Technical Packaging Divestiture

[0001410578-22-003540:notes:89]
In December 2019, we completed the sale of our Technical Packaging business segment, consisting of our wholly-owned subsidiaries Thermoform Engineered Quality LLC, Plastique Ltd. and Plastique sp. z o.o. (the “Technical Packaging Business”), to Sonoco Plastics, Inc. and Sonoco Holdings, Inc. (“Buyers”), two wholly-owned subsidiaries of Sonoco Products Company (NYSE:SON). The companies within this segment provide innovative solutions to the medical and commercial markets for thermoformed packages and specialty products using a wide variety of thin gauge plastics and pulp. Results of operations, financial position and cash flows for the Technical Packaging business are reflected as discontinued operations in the Consolidated Financial Statements and related notes for all periods presented.

[0001410578-22-003540:notes:90]
Net sales and pretax (loss) from the Technical Packaging business were $16.5 million and $(0.3) million, respectively, in 2020. We received net proceeds from the sale of approximately $184 million and recorded $76.5 million after-tax net earnings on the sale in 2020. We finalized a contractual working capital adjustment and paid $0.2 million to the buyer during the third quarter of 2020.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001410578-22-003540:notes:91]
4.      Goodwill and Other Intangible Assets

[0001410578-22-003540:notes:92]
Included on the Consolidated Balance Sheets at September 30, 2022 and 2021 are the following intangible assets gross carrying amounts and accumulated amortization:

[0001410578-22-003540:notes:93]
| (Dollars in thousands) |  | 2022 |  | 2021 |
| Goodwill | ​ | $ | 492,709 | ​ | 504,853 |
| Intangible assets with determinable lives: | ​ |  | ​ | ​ | ​ |
| Patents | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 2,353 | ​ | 2,131 |
| Less: accumulated amortization | ​ |  | 1,091 | ​ | 972 |
| Net | ​ | $ | 1,262 | ​ | 1,159 |
| Capitalized software | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 106,583 | ​ | 93,671 |
| Less: accumulated amortization | ​ |  | 70,476 | ​ | 63,740 |
| Net | ​ | $ | 36,107 | ​ | 29,931 |
| Customer Relationships | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 287,447 | ​ | 288,530 |
| Less: accumulated amortization | ​ |  | 96,921 | ​ | 80,882 |
| Net | ​ | $ | 190,526 | ​ | 207,648 |
| Other | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 13,985 | ​ | 13,177 |
| Less: accumulated amortization | ​ |  | 7,440 | ​ | 4,398 |
| Net | ​ | $ | 6,545 | ​ | 8,779 |
| Intangible assets with indefinite lives: | ​ |  | ​ | ​ | ​ |
| Trade names | ​ | $ | 160,024 | ​ | 161,733 |

[0001410578-22-003540:notes:94]
We performed our annual evaluation of goodwill and intangible assets for impairment during the fourth quarter of 2022 and concluded that no impairment existed at September 30, 2022. There were no accumulated impairment losses as of September 30, 2022.

[0001410578-22-003540:notes:95]
The changes in the carrying amount of goodwill attributable to each business segment for 2022 and 2021 are as follows:

[0001410578-22-003540:notes:96]
| (Dollars in millions) |  | A&D |  | Test |  | USG |  | Total |
| Balance as of September 30, 2020 | ​ | $ | 102.1 |  | ​ | 34.1 |  | 271.9 |  | 408.1 |
| Acquisition activity | ​ | ​ | 2.2 | ​ | ​ | — | ​ | 95.2 | ​ | 97.4 |
| Foreign currency translation and other | ​ | ​ | — | ​ | ​ | — | ​ | (0.6) | ​ | (0.6) |
| Balance as of September 30, 2021 | ​ | $ | 104.3 | ​ | ​ | 34.1 | ​ | 366.5 | ​ | 504.9 |
| Acquisition activity | ​ | ​ | 5.7 | ​ | ​ | — | ​ | (4.7) | ​ | 1.0 |
| Foreign currency translation and other | ​ | ​ | — | ​ | ​ | (0.1) | ​ | (13.1) | ​ | (13.2) |
| Balance as of September 30, 2022 | ​ | $ | 110.0 | ​ | ​ | 34.0 | ​ | 348.7 | ​ | 492.7 |

[0001410578-22-003540:notes:97]
Amortization expense related to intangible assets with determinable lives was $25.9 million, $20.8 million and $21.8 million in 2022, 2021 and 2020, respectively. Patents are amortized over the life of the patents, generally ten to twenty years. Capitalized software is amortized over the estimated useful life of the software, generally three to seven years. Customer relationships are generally amortized over thirteen to twenty years. Intangible asset amortization for fiscal years 2023 through 2027 is estimated at $18.5 million in 2023, and approximately $17 million in years 2024 through 2027.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001410578-22-003540:notes:98]
5.      Accounts Receivable

[0001410578-22-003540:notes:99]
Accounts receivable, net of the allowance for credit losses, consisted of the following at September 30, 2022 and 2021:

[0001410578-22-003540:notes:100]
| (Dollars in thousands) |  | 2022 |  | 2021 |
| Commercial | ​ | $ | 151,565 |  | 128,952 |
| U.S. Government and prime contractors | ​ |  | 13,080 |  | 17,389 |
| Total | ​ | $ | 164,645 |  | 146,341 |


## us-gaap:InventoryDisclosureTextBlock

[0001410578-22-003540:notes:101]
6.      Inventories, Net

[0001410578-22-003540:notes:102]
Inventories, net, from continuing operations consisted of the following at September 30, 2022 and 2021:

[0001410578-22-003540:notes:103]
| (Dollars in thousands) |  | 2022 |  | 2021 |
| Finished goods | ​ | $ | 32,471 |  | 32,998 |
| Work in process | ​ |  | 38,492 |  | 34,201 |
| Raw materials | ​ |  | 91,440 |  | 79,949 |
| Total | ​ | $ | 162,403 |  | 147,148 |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001410578-22-003540:notes:104]
7.      Income Tax Expense

[0001410578-22-003540:notes:105]
We allocated total income tax expense for the years ended September 30, 2022, 2021 and 2020 to income tax expense as follows:

[0001410578-22-003540:notes:106]
| (Dollars in thousands) |  | 2022 |  | 2021 |  | 2020 |
| Income tax expense from continuing operations | ​ | $ | 24,115 |  | 17,175 |  | 13,510 |
| Income tax expense from discontinued operations | ​ |  | — |  | — |  | 23,501 |
| Total income tax expense (benefit) | ​ | $ | 24,115 |  | 17,175 |  | 37,011 |

[0001410578-22-003540:notes:107]
The components of income from continuing operations before income taxes for 2022, 2021 and 2020 consisted of the following:

[0001410578-22-003540:notes:108]
| (Dollars in thousands) |  | 2022 |  | 2021 |  | 2020 |
| United States | ​ | $ | 90,674 |  | 70,214 |  | 23,951 |
| Foreign | ​ |  | 15,761 |  | 10,457 |  | 12,455 |
| Total income before income taxes | ​ | $ | 106,435 |  | 80,671 |  | 36,406 |

[0001410578-22-003540:notes:109]
The principal components of income tax expense (benefit) from continuing operations for 2022, 2021 and 2020 consist of:

[0001410578-22-003540:notes:110]
| (Dollars in thousands) |  | 2022 |  | 2021 |  | 2020 |
| Federal: |  | ​ |  |  |  |  |  |
| Current | ​ | $ | 7,248 |  | 14,807 |  | 10,495 |
| Deferred | ​ |  | 9,752 |  | (1,598) |  | 1,311 |
| State and local: | ​ |  | ​ |  | ​ |  | ​ |
| Current | ​ |  | 1,635 |  | 2,257 |  | 1,984 |
| Deferred | ​ |  | 1,774 |  | (786) |  | (932) |
| Foreign: | ​ |  | ​ |  | ​ |  | ​ |
| Current | ​ |  | 4,645 |  | 2,922 |  | 2,875 |
| Deferred | ​ |  | (939) |  | (427) |  | (2,223) |
| Total | ​ | $ | 24,115 |  | 17,175 |  | 13,510 |

[0001410578-22-003540:notes:111]
The actual income tax expense from continuing operations for 2022, 2021 and 2020 differs from the expected tax expense for those years (computed by applying the U.S. Federal corporate statutory rate) as follows:

[0001410578-22-003540:notes:112]
| ​ |  | 2022 |  | 2021 |  | 2020 |  |
| Federal corporate statutory rate |  | 21.0 | % | 21.0 | % | 21.0 | % |
| State and local, net of Federal benefits | ​ | 2.9 |  | 1.9 |  | 2.3 | ​ |
| Impact of foreign operations | ​ | (0.3) | ​ | (0.4) | ​ | 1.3 | ​ |
| Federal research credit | ​ | (0.3) | ​ | (0.9) | ​ | (3.7) | ​ |
| Executive compensation | ​ | 0.5 |  | 0.9 |  | 1.6 | ​ |
| Valuation allowance | ​ | (0.3) |  | — |  | (6.8) | ​ |
| U.S. tax on GILTI | ​ | 1.8 | ​ | 1.0 | ​ | 3.2 | ​ |
| GILTI foreign tax credits | ​ | (1.5) | ​ | (0.6) | ​ | (2.7) | ​ |
| FDII deduction | ​ | (0.9) | ​ | (1.7) | ​ | (2.6) | ​ |
| Pension plan termination charge | ​ | — | ​ | — | ​ | 23.4 | ​ |
| Other, net | ​ | (0.2) |  | 0.1 |  | 0.1 | ​ |
| Effective income tax rate | ​ | 22.7 | % | 21.3 | % | 37.1 | % |

[0001410578-22-003540:notes:113]
The tax effects of temporary differences that give rise to significant portions of the deferred tax assets and liabilities at September 30, 2022 and 2021 are presented below:

[0001410578-22-003540:notes:114]
| (Dollars in thousands) |  | 2022 |  | 2021 |
| Deferred tax assets: |  | ​ |  |  |  |
| Inventories | ​ | $ | 4,990 |  | 4,267 |
| Pension and other postretirement benefits | ​ |  | 664 |  | 859 |
| Timing differences related to revenue recognition | ​ | ​ | 61 | ​ | 9,365 |
| Lease liabilities | ​ | ​ | 7,073 | ​ | 7,614 |
| Net operating and capital loss carryforwards — domestic | ​ |  | 575 |  | 542 |
| Net operating loss carryforward — foreign | ​ |  | 3,396 |  | 4,279 |
| Other compensation-related costs and other cost accruals | ​ |  | 9,032 |  | 8,174 |
| State credit carryforward | ​ |  | 1,676 |  | 2,639 |
| Foreign credit carryforward | ​ | ​ | 203 | ​ | 192 |
| Total deferred tax assets | ​ |  | 27,670 |  | 37,931 |
| Deferred tax liabilities: | ​ |  | ​ |  | ​ |
| ROU assets | ​ | ​ | (7,073) | ​ | (7,614) |
| Goodwill | ​ |  | (11,691) |  | (13,746) |
| Acquisition intangible assets | ​ |  | (62,051) |  | (62,052) |
| Depreciation, software amortization | ​ |  | (24,503) |  | (22,418) |
| Net deferred tax liabilities before valuation allowance | ​ |  | (77,648) |  | (67,899) |
| Less valuation allowance | ​ |  | (1,208) |  | (2,011) |
| Net deferred tax liabilities | ​ | $ | (78,856) |  | (69,910) |

[0001410578-22-003540:notes:115]
We had a foreign net operating loss (NOL) carryforward of $12.1 million at September 30, 2022, which reflects tax loss carryforwards in Germany, South Africa, Canada, Japan and the United Kingdom. Approximately $10.4 million of the tax loss carryforwards have no expiration date while the remaining $1.7 million will expire between 2031 and 2041. We had net foreign credit carryforwards of $0.2 million, that will expire between 2041 and 2042.We had deferred tax assets related to state NOL carryforwards of $0.6 million at September 30, 2022 which expire between 2025 and 2042. We also had net state research and other credit carryforwards of $1.7 million of which $0.9 million expires between 2024 and 2037. The remaining $0.8 million does not have an expiration date.

[0001410578-22-003540:notes:116]
The valuation allowance for deferred tax assets as of September 30, 2022 and 2021 was $1.2 million and $2.0 million, respectively. The net change in the total valuation allowance for each of the years ended September 30, 2022 and 2021 was a decrease of $0.8 million and an increase of $0.1 million, respectively.We established a valuation allowance against state credit carryforwards of $0.6 million at September 30, 2021. This balance was released as of September 30, 2022. In addition, we maintained a valuation allowance against state NOL carryforwards that are not expected to be realized in future periods of $0.5 million at September 30 of both 2022 and 2021. Lastly, we established a valuation allowance against certain NOL carryforwards in foreign jurisdictions which may not be realized in future periods of $0.7 million and $0.9 million at September 30, 2022 and 2021, respectively.

[0001410578-22-003540:notes:117]
As of September 30, 2022, the Company does not have any material unrecognized tax benefits.


## us-gaap:DebtDisclosureTextBlock

[0001410578-22-003540:notes:118]
8.      Debt

[0001410578-22-003540:notes:119]
Debt consists of the following at September 30, 2022 and 2021:

[0001410578-22-003540:notes:120]
| (Dollars in thousands) |  | 2022 |  | 2021 |
| Total borrowings | ​ | $ | 153,000 |  | 154,000 |
| Current portion of long-term debt and short-term borrowings | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 133,000 |  | 134,000 |

[0001410578-22-003540:notes:121]
The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for an increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024, with balance due by this date.

[0001410578-22-003540:notes:122]
Interest on borrowings under the Credit Facility is calculated at a spread over either the New York Federal Reserve Bank Rate, the prime rate, or the London Interbank Offered Rate (LIBOR), depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The interest rate spreads and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio.

[0001410578-22-003540:notes:123]
The Credit Facility is secured by the unlimited guaranty of our direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of our direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. As of September 30, 2022, we were in compliance with all covenants.

[0001410578-22-003540:notes:124]
At September 30, 2022, we had approximately $339 million available to borrow under the Credit Facility, plus the $250 million increase option subject to the lenders’ consent, in addition to $97.7 million cash on hand. We classified $20 million as the current portion of long-term debt as of September 30, 2022, as we intend to repay this amount within the next twelve months; however, we have no contractual obligation to repay such amount during the next twelve months.

[0001410578-22-003540:notes:125]
During 2022 and 2021, our maximum aggregate short-term borrowings at any month-end were $208 million and $174 million, respectively, and the average aggregate short-term borrowings and outstanding based on month-end balances were $189.8 million and $71.3 million, respectively. The weighted average interest rates were 2.11% and 1.20% for 2022 and 2021, respectively. As of September 30, 2022, the interest rate on our debt was 4.12%. The letters of credit issued and outstanding under the Credit Facility totaled $8.0 million and $8.5 million at September 30, 2022 and 2021, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001410578-22-003540:notes:126]
9.      Capital Stock

[0001410578-22-003540:notes:127]
The 30,707,748 and 30,666,173 common shares as presented in the accompanying Consolidated Balance Sheets at September 30, 2022 and 2021 represent the actual number of shares issued at the respective dates. We held 4,854,997 and 4,604,741 common shares in treasury at September 30, 2022 and 2021, respectively.

[0001410578-22-003540:notes:128]
In August 2021, our Board of Directors approved a new common stock repurchase program authorizing us to repurchase shares of our stock from time to time in Management’s discretion, in the open market or otherwise, up to a maximum total repurchase amount of $200 million (or the maximum amount permitted under our bank credit agreements, if less). This program is scheduled to expire September 30, 2024. We repurchased approximately 257,500 shares under this program in 2022 at an aggregate cost of $20.0 million. We did not repurchase any shares in  2021 or 2020.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001410578-22-003540:notes:129]
10.      Share-Based Compensation

[0001410578-22-003540:notes:130]
We provide compensation benefits to certain key employees under several share-based plans providing for performance-accelerated and/or time-vested restricted stock unit awards, and to non-employee directors under a separate compensation plan for non-employee directors. As of September 30, 2022, our equity compensation plans had a total of 580,437 shares authorized and available for future issuance.

[0001410578-22-003540:notes:131]
Performance-Accelerated Restricted Stock Unit (PARS) Awards, Time-Vested Restricted Stock Unit (RSU) Awards, and Performance Share Unit (PSU) Awards

[0001410578-22-003540:notes:132]
A PARS award represents the right to receive a specified number of shares of Company common stock if and when the award vests. A PARS award is not stock and does not give the recipient any rights as a shareholder until it vests and is paid out in shares of stock. PARS awards currently outstanding have a five-year vesting period, with accelerated vesting if certain targets based on market conditions are achieved. In these cases, if it is probable that the performance condition will be met, the Company recognizes compensation cost on a straight-line basis over the shorter performance period; otherwise, it will recognize compensation cost over the longer service period. Compensation cost for the outstanding PARS awards is being recognized over the shorter performance period, as it is probable the performance condition will be met. The PARS award grants were valued at the stock price on the date of grant.

[0001410578-22-003540:notes:133]
The terms of the RSU awards are similar to those of the PARS awards, but without any provision for acceleration of the vesting date. Each RSU represents the right to receive one share of Company common stock if the recipient remains continuously employed by the Company until the award vests, in this case 3 ½ years after the effective award date. The RSU award grants were valued at the stock price on the date of grant.

[0001410578-22-003540:notes:134]
Beginning in fiscal year 2022, the Company granted PSU awards with a three-year vesting period, with each PSU representing the right to receive one share of Company common stock if certain performance targets are achieved. The targets are based on achieving certain EBITDA metrics and a Total Shareholder return (rTSR) metric over a three-year period.

[0001410578-22-003540:notes:135]
Pretax compensation expense related to the above awards for continuing operations was $6.1 million, $5.6 million and $4.3 million for 2022, 2021 and 2020, respectively.

[0001410578-22-003540:notes:136]
The following summary presents information regarding outstanding share-based compensation awards as of the specified dates, and changes during the specified periods:

[0001410578-22-003540:notes:137]
| ​ | ​ | FY 2022 | ​ | FY 2021 | ​ | FY 2020 |
| ​ |  | ​ |  | Estimated |  | ​ |  | Estimated |  | ​ |  | Estimated |
| ​ | ​ | ​ | ​ | Weighted | ​ | ​ | ​ | Weighted | ​ | ​ | ​ | Weighted |
| ​ | ​ | Shares | ​ | Avg. Price | ​ | Shares | ​ | Avg. Price | ​ | Shares | ​ | Avg. Price |
| Nonvested at October 1, |  | 226,705 | ​ | $ | 76.15 |  | 220,300 | ​ | $ | 66.55 |  | 281,004 | ​ | $ | 59.72 |
| Granted |  | 117,045 | ​ |  | 82.54 |  | 51,476 | ​ |  | 108.05 |  | 45,723 | ​ |  | 74.80 |
| Vested |  | (75,327) | ​ |  | 56.87 |  | (35,753) | ​ |  | 64.40 |  | (89,822) | ​ |  | 50.51 |
| Cancelled |  | (3,056) | ​ |  | 89.51 |  | (9,318) | ​ |  | 70.50 |  | (16,605) | ​ |  | 60.48 |
| Nonvested at September 30, |  | 265,367 | ​ | $ | 84.29 |  | 226,705 | ​ | $ | 76.15 |  | 220,300 | ​ | $ | 66.55 |

[0001410578-22-003540:notes:138]
Compensation Plan for Non-Employee Directors

[0001410578-22-003540:notes:139]
In addition to an annual cash retainer, we provide each non-employee director with an annual equity award having a grant date market value of $180,000, based on the NYSE closing price of the Company’s stock on the date of grant. For calendar years prior to 2021, the award consisted of actual shares of Company stock, but beginning in January 2021, the award has been in the form of Restricted Stock Units, each of which represents the right to receive one share of Company stock at the end of a one-year vesting period. At the end of the vesting period, each award will be converted into the right to receive the same number of actual shares of common stock, plus additional shares representing the value of the quarterly dividends which would have accrued on the underlying shares during the vesting period. Compensation expense related to the non-employee director grants was $1.2 million, $1.3 million and $1.3 million for 2022, 2021 and 2020, respectively.

[0001410578-22-003540:notes:140]
Total Share-Based Compensation

[0001410578-22-003540:notes:141]
The total share-based compensation cost that has been recognized in results of operations and included within SG&A from continuing operations was $7.3 million, $6.9 million and $5.6 million for 2022, 2021 and 2020, respectively. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $1.5 million, $1.4 million and $1.2 million for 2022, 2021 and 2020, respectively. As of September 30, 2022, there was $11.2 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a weighted-average period of 1.7 years.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001410578-22-003540:notes:142]
11.      Retirement and Other Benefit Plans

[0001410578-22-003540:notes:143]
On November 14, 2019, our Board of Directors approved a resolution to terminate the Company’s defined benefit pension plan (the Plan) effective as of February 29, 2020. In connection with the termination, we contributed $25.7 million of cash to the Plan during 2020, settled approximately $32.4 million of Plan liabilities during 2020 through lump-sum payments from existing plan assets to eligible participants who elected to receive them, and recorded approximately $40.6 million of charges associated with these settlements. During 2020, we settled approximately $69.1 million of Plan liabilities by entering into an agreement to purchase annuities from a third-party insurance company. This agreement covered active and former employees and their beneficiaries, with the insurance company assuming the future annuity payments for these individuals.

[0001410578-22-003540:notes:144]
Substantially all our domestic employees are covered by a defined contribution plan maintained by the Company. In addition, we offer unfunded post-retirement pre-Medicare health insurance benefits to a small number of eligible retirees and employees. We formerly provided unfunded post-retirement life insurance to qualifying retired employees who retired before 2005, but ceased providing this coverage on July 31, 2020. There was no financial impact of this plan in 2022.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001410578-22-003540:notes:145]
12.      Business Segment Information

[0001410578-22-003540:notes:146]
We are organized based on the products and services we offer, and we classify our continuing business operations in three reportable segments for financial reporting purposes:  Aerospace & Defense (A&D), Utility Solutions Group (USG) and RF Shielding and Test (Test). In addition, for reporting certain financial information we treat Corporate activities as a separate segment. The former Technical Packaging segment was divested in December 2019 and is reflected as discontinued operations for 2020.

[0001410578-22-003540:notes:147]
The A&D segment’s operations consist of PTI Technologies Inc. (PTI), VACCO Industries (VACCO), Crissair, Inc. (Crissair), Mayday Manufacturing Co. (Mayday), Westland Technologies, Inc. (Westland), Globe Composite Solutions, LLC (Globe) and Networks Electronic Company, LLC (NEco).The companies within this segment primarily design and manufacture specialty filtration, fluid control and naval products, including hydraulic filter elements and fluid control devices used in aerospace and defense applications, unique filter mechanisms used in micro-propulsion devices for satellites, custom designed filters for manned aircraft and submarines, products and systems to reduce vibration and/or acoustic signatures and otherwise reduce or obscure a vessel’s signature, and other communications, sealing, surface control and hydrodynamic related applications to enhance U.S. Navy maritime survivability; precision-tolerance machined components for the aerospace and defense industry; metal processing services; and miniature electro-explosive devices utilized in mission-critical defense and aerospace applications.

[0001410578-22-003540:notes:148]
The USG segment’s operations consist of Doble Engineering Company and related subsidiaries including Morgan Schaffer and Altanova (collectively, Doble), and NRG Systems, Inc. (NRG). Doble is an industry leader in the development, manufacture and delivery of diagnostic testing and data management solutions that enable electric power grid operators to assess the integrity of high-voltage power delivery equipment. It combines three core elements for customers – diagnostic test and condition monitoring instruments, expert consulting, and testing services – and provides access to its large reserve of related empirical knowledge. NRG is a global market leader in the design and manufacture of decision support tools for the renewable energy industry, primarily wind and solar. The recent acquisition of Altanova not only complements our existing products and services but its strong market share in Europe and Asia provides a significant international platform for our USG segment.

[0001410578-22-003540:notes:149]
The Test segment’s operations consist of ETS-Lindgren Inc. and related subsidiaries (ETS-Lindgren). ETS-Lindgren is an industry leader in designing and manufacturing products which provide its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy. It supplies its customers with a broad range of isolated environments and turnkey systems, including RF test facilities, acoustic test enclosures, RF and magnetically shielded rooms, secure communication facilities, RF measurement systems and broadcast and recording studios. Many of these facilities include proprietary features such as shielded doors and windows. ETS-Lindgren also provides the design, program management, installation and integration services required to successfully complete these types of facilities. ETS-Lindgren also supplies customers with a broad range of components including RF absorptive materials, RF filters, active compensation systems, antennas, antenna masts, turntables and electric and magnetic probes, RF test cells, proprietary measurement software and other test accessories required to perform a variety of tests. ETS-Lindgren offers a variety of services including calibration for antennas and field probes, chamber certification, field surveys, customer training and a variety of product tests. ETS-Lindgren serves the acoustics, medical, health and safety, electronics, wireless communications, automotive and defense markets.

[0001410578-22-003540:notes:150]
Accounting policies of the segments are the same as those described in the summary of significant accounting policies in Note 1 to the Consolidated Financial Statements. The operating units within each reporting segment have been aggregated because of similar economic characteristics and meet the other aggregation criteria of FASB ASC 280.

[0001410578-22-003540:notes:151]
We evaluate the performance of our operating units based on EBIT, which is defined as earnings before interest and taxes. EBIT on a consolidated basis is a non-GAAP financial measure. Intersegment sales and transfers are not significant. Segment assets consist primarily of customer receivables, inventories, capitalized software and fixed assets directly associated with the production processes of the segment. Segment depreciation and amortization is based upon the direct assets listed above. The tables below are presented on the basis of continuing operations and exclude discontinued operations.

[0001410578-22-003540:notes:152]
Net Sales

[0001410578-22-003540:notes:153]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2022 |  | 2021 |  | 2020 |
| A&D | ​ | $ | 351.4 |  | 314.8 |  | 351.9 |
| USG | ​ | ​ | 278.4 | ​ | 202.9 | ​ | 191.7 |
| Test | ​ |  | 227.7 |  | 197.7 |  | 186.9 |
| Consolidated totals | ​ | $ | 857.5 |  | 715.4 |  | 730.5 |

[0001410578-22-003540:notes:154]
No customer exceeded 10% of consolidated sales in 2022 or 2021 and one customer exceeded 10% of consolidated sales in 2020.

[0001410578-22-003540:notes:155]
EBIT

[0001410578-22-003540:notes:156]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2022 |  | 2021 |  | 2020 |
| A&D | ​ | $ | 68.4 |  | 56.5 |  | 69.9 |
| USG | ​ | ​ | 57.6 | ​ | 40.9 | ​ | 24.4 |
| Test | ​ |  | 32.6 |  | 27.6 |  | 27.2 |
| Reconciliation to consolidated totals (Corporate) | ​ |  | (47.3) |  | (42.1) |  | (78.4) |
| Consolidated EBIT | ​ |  | 111.3 |  | 82.9 |  | 43.1 |
| Less: interest expense | ​ |  | (4.9) |  | (2.2) |  | (6.7) |
| Earnings before income tax | ​ | $ | 106.4 |  | 80.7 |  | 36.4 |

[0001410578-22-003540:notes:157]
Identifiable Assets

[0001410578-22-003540:notes:158]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2022 |  | 2021 |
| A&D | ​ | $ | 295.2 |  | 270.0 |
| USG | ​ | ​ | 220.0 | ​ | 197.5 |
| Test | ​ |  | 174.6 |  | 153.6 |
| Corporate | ​ |  | 964.7 |  | 956.2 |
| Consolidated totals | ​ | $ | 1,654.5 |  | 1,577.3 |

[0001410578-22-003540:notes:159]
Corporate consists primarily of deferred taxes, acquired intangible assets including goodwill and cash balances.

[0001410578-22-003540:notes:160]
Capital Expenditures

[0001410578-22-003540:notes:161]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2022 |  | 2021 |  | 2020 |
| A&D | ​ | $ | 9.4 |  | 10.4 |  | 15.9 |
| USG | ​ | ​ | 14.4 | ​ | 11.6 | ​ | 12.4 |
| Test | ​ |  | 8.3 |  | 4.7 |  | 3.6 |
| Corporate | ​ |  | — |  | — |  | 0.2 |
| Consolidated totals | ​ | $ | 32.1 |  | 26.7 |  | 32.1 |

[0001410578-22-003540:notes:162]
In addition to the above amounts, we incurred expenditures for capitalized software of $12.9 million, $8.8 million and $9.0 million in 2022, 2021 and 2020, respectively.

[0001410578-22-003540:notes:163]
Depreciation and Amortization

[0001410578-22-003540:notes:164]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2022 |  | 2021 |  | 2020 |
| A&D | ​ | $ | 11.1 |  | 10.4 |  | 9.4 |
| USG | ​ | ​ | 12.6 | ​ | 13.5 | ​ | 14.4 |
| Test | ​ |  | 5.4 |  | 5.2 |  | 5.0 |
| Corporate | ​ |  | 19.2 |  | 12.9 |  | 12.5 |
| Consolidated totals | ​ | $ | 48.3 |  | 42.0 |  | 41.3 |

[0001410578-22-003540:notes:165]
Depreciation expense of property, plant and equipment was $22.4 million, $21.2 million and $19.5 million for 2022, 2021 and 2020, respectively.

[0001410578-22-003540:notes:166]
Geographic Information

[0001410578-22-003540:notes:167]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2022 |  | 2021 |  | 2020 |
| United States | ​ | $ | 603.2 |  | 517.0 |  | 529.4 |
| Asia | ​ |  | 122.4 |  | 92.3 |  | 96.3 |
| Europe | ​ |  | 72.4 |  | 53.5 |  | 51.3 |
| Canada | ​ |  | 31.2 |  | 27.0 |  | 31.7 |
| India | ​ |  | 10.3 |  | 12.4 |  | 10.3 |
| Other | ​ |  | 18.0 |  | 13.2 |  | 11.5 |
| Consolidated totals | ​ | $ | 857.5 |  | 715.4 |  | 730.5 |

[0001410578-22-003540:notes:168]
Long-Lived Assets

[0001410578-22-003540:notes:169]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2022 |  | 2021 |
| United States | ​ | $ | 141.5 |  | 141.0 |
| Mexico | ​ |  | 5.8 |  | 3.8 |
| Other | ​ |  | 8.7 |  | 9.5 |
| Consolidated totals | ​ | $ | 156.0 |  | 154.3 |

[0001410578-22-003540:notes:170]
We attribute net sales to countries based on the location of the customer. We attribute long-lived assets to countries based on the location of the asset.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001410578-22-003540:notes:171]
13.      Commitments and Contingencies

[0001410578-22-003540:notes:172]
At September 30, 2022, we had $8.0 million in letters of credit outstanding as guarantees of contract performance and cash amounts that exceeded federally insured amounts. As a normal incident of the businesses in which we are engaged, various claims, charges and litigation are asserted or commenced from time to time against us. Additionally, we are currently involved in various stages of investigation and remediation relating to environmental matters. It is the opinion of Management that the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against us are adequately accrued, are covered by insurance or are not likely to have a material adverse effect on our financial results as the estimated exposure to loss is not material.


## ese:OperatingAndFinancingLeasesOfLesseeDisclosureTextBlock

[0001410578-22-003540:notes:173]
14.      Leases

[0001410578-22-003540:notes:174]
Effective October 1, 2019 we adopted ASC 842, Leases. We determine at lease inception whether an arrangement that provides control over the use of an asset is a lease. We recognize at lease commencement a right-of-use (ROU) asset and lease liability based on the present value of the future lease payments over the lease term (including anticipated renewals). We have elected not to recognize a ROU asset and lease liability for leases with terms of 12 months or less. Certain of our leases include options to extend the term of the lease for up to 20 years. When it is reasonably certain that we will exercise the option, Management includes the impact of

[0001410578-22-003540:notes:175]
the option in the lease term for purposes of determining total future lease payments. As most of our lease agreements do not explicitly state the discount rate implicit in the lease, Management uses our incremental borrowing rate on the commencement date to calculate the present value of future payments based on the tenor of each arrangement.

[0001410578-22-003540:notes:176]
Our leases for real estate commonly include escalating payments. We include these variable lease payments in the calculation of our ROU asset and lease liability. In addition to the present value of the future lease payments, the calculation of the ROU asset also includes any deferred rent, lease pre-payments and initial direct costs of obtaining the lease.

[0001410578-22-003540:notes:177]
In addition to the base rent, real estate leases typically contain provisions for common-area maintenance and other similar services, which are considered non-lease components for accounting purposes. Non-lease components are excluded from our ROU assets and lease liabilities and expensed as incurred.

[0001410578-22-003540:notes:178]
Our leases are for office space, manufacturing facilities, and machinery and equipment.

[0001410578-22-003540:notes:179]
The components of lease costs are shown below:

[0001410578-22-003540:notes:180]
| ​ | ​ | Year Ended |  | Year Ended |
| ​ | ​ | September 30, | ​ | September 30, |
| (Dollars in thousands) |  | 2022 |  | 2021 |
| Finance lease cost: |  | ​ |  | ​ | ​ | ​ |
| Amortization | ​ | $ | 1,572 | ​ | ​ | 2,413 |
| Interest on lease liabilities | ​ |  | 973 | ​ | ​ | 1,235 |
| Operating lease cost | ​ |  | 6,347 | ​ | ​ | 5,879 |
| Total lease cost | ​ | $ | 8,892 | ​ | ​ | 9,527 |

[0001410578-22-003540:notes:181]
Additional information related to leases is shown below:

[0001410578-22-003540:notes:182]
| ​ |  | Year Ended |  | Year Ended |  |
| ​ | ​ | September 30, | ​ | September 30, | ​ |
| (Dollars in thousands) | ​ | 2022 | ​ | 2021 | ​ |
| Cash paid for amounts included in the measurement of lease liabilities: | ​ | ​ | ​ |  | ​ |  |  |
| Operating cash flows from operating leases | ​ | $ | 6,101 | ​ | ​ | 5,504 |  |
| Operating cash flows from finance leases | ​ | ​ | 973 | ​ | ​ | 1,228 |  |
| Financing cash flows from finance leases | ​ | ​ | 1,224 | ​ | ​ | 1,757 |  |
| Right-of-use assets obtained in exchange for operating lease liabilities | ​ | $ | 4,160 | ​ | ​ | 15,609 |  |
| Weighted-average remaining lease term: | ​ | ​ | ​ | ​ |  | ​ |  |
| Operating leases | ​ | ​ | 9.3 | yrs |  | 10.3 | yrs |
| Finance leases | ​ | ​ | 12.0 | yrs |  | 11.7 | yrs |
| Weighted-average discount rate: | ​ | ​ | ​ | ​ |  | ​ |  |
| Operating leases | ​ | ​ | 3.2 | % |  | 3.1 | % |
| Finance leases | ​ | ​ | 4.6 | % |  | 4.2 | % |

[0001410578-22-003540:notes:183]
The table below is a reconciliation of future undiscounted cash flows to the operating and finance lease liabilities, and the related ROU assets, presented on our Consolidated Balance Sheet on September 30, 2022:

[0001410578-22-003540:notes:184]
| (Dollars in thousands) | ​ | Operating | ​ | Finance |
| Years Ending September 30: |  | Leases |  | Leases |
| 2023 | ​ | $ | 5,953 | ​ | ​ | 2,256 |
| 2024 | ​ |  | 5,132 | ​ | ​ | 2,315 |
| 2025 | ​ |  | 3,790 | ​ | ​ | 2,370 |
| 2026 | ​ |  | 2,881 | ​ | ​ | 2,434 |
| 2027 and thereafter | ​ |  | 17,029 | ​ | ​ | 18,997 |
| Total minimum lease payments | ​ | ​ | 34,785 | ​ | ​ | 28,372 |
| Less: amounts representing interest | ​ |  | 4,760 | ​ | ​ | 7,189 |
| Present value of net minimum lease payments | ​ | $ | 30,025 | ​ | ​ | 21,183 |
| Less: current portion of lease obligations | ​ |  | 5,172 | ​ | ​ | 1,331 |
| Non-current portion of lease obligations | ​ | ​ | 24,853 | ​ | ​ | 19,852 |
| ROU assets | ​ | $ | 29,150 | ​ | ​ | 17,343 |

[0001410578-22-003540:notes:185]
The table below is a reconciliation of future undiscounted cash flows to the operating and finance lease liabilities, and the related ROU assets, presented on our Consolidated Balance Sheet on September 30, 2021:

[0001410578-22-003540:notes:186]
| (Dollars in thousands) |  | Operating |  | Finance |
| Years Ending September 30: | ​ | Leases | ​ | Leases |
| 2022 | ​ | $ | 5,448 |  | 3,153 |
| 2023 | ​ |  | 4,679 |  | 3,235 |
| 2024 | ​ |  | 4,032 |  | 3,319 |
| 2025 | ​ |  | 3,654 |  | 3,399 |
| 2026 and thereafter | ​ |  | 20,453 |  | 25,516 |
| Total minimum lease payments | ​ | ​ | 38,266 |  | 38,622 |
| Less: amounts representing interest | ​ |  | 5,691 |  | 9,092 |
| Present value of net minimum lease payments | ​ | $ | 32,575 |  | 29,530 |
| Less: current portion of lease obligations | ​ |  | 4,543 |  | 2,180 |
| Non-current portion of lease obligations | ​ |  | 28,032 |  | 27,350 |
| ROU assets | ​ | $ | 31,846 | ​ | 24,964 |

[0001410578-22-003540:notes:187]
We include operating and finance lease liabilities in the Consolidated Balance Sheet in accrued other expenses (current portion) and other liabilities (long-term portion). We include operating lease ROU assets as a caption on the Consolidated Balance Sheet and include finance lease ROU assets in Property, plant and equipment on the Consolidated Balance Sheet.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001410578-22-003540:notes:188]
15.     Revenues

[0001410578-22-003540:notes:189]
| (a) | Disaggregation of Revenues |

[0001410578-22-003540:notes:190]
The tables below present our revenues by customer type, geographic location, and revenue recognition method for the years ended September 30, 2022 and 2021, as we believe this presentation best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables also include a reconciliation of the disaggregated revenue within our reportable segments.

[0001410578-22-003540:notes:191]
| Year Ended September 30, 2022 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 144,305 | ​ |  | 272,432 | ​ |  | 209,016 | ​ |  | 625,753 |
| Government | ​ | ​ | 207,108 | ​ | ​ | 5,935 | ​ | ​ | 18,706 | ​ | ​ | 231,749 |
| Total revenues | ​ | $ | 351,413 | ​ | ​ | 278,367 | ​ | ​ | 227,722 | ​ | ​ | 857,502 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 299,158 | ​ |  | 180,586 | ​ |  | 123,428 | ​ |  | 603,172 |
| International | ​ | ​ | 52,255 | ​ | ​ | 97,781 | ​ | ​ | 104,294 | ​ | ​ | 254,330 |
| Total revenues | ​ | $ | 351,413 | ​ | ​ | 278,367 | ​ | ​ | 227,722 | ​ | ​ | 857,502 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 144,039 | ​ |  | 224,502 | ​ |  | 58,522 | ​ |  | 427,063 |
| Over time | ​ | ​ | 207,374 | ​ | ​ | 53,865 | ​ | ​ | 169,200 | ​ | ​ | 430,439 |
| Total revenues | ​ | $ | 351,413 | ​ | ​ | 278,367 | ​ | ​ | 227,722 | ​ | ​ | 857,502 |

[0001410578-22-003540:notes:192]
| Year Ended September 30, 2021 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 130,217 | ​ | ​ | 199,111 | ​ | ​ | 177,601 | ​ | ​ | 506,929 |
| Government | ​ |  | 184,607 | ​ |  | 3,797 | ​ |  | 20,107 | ​ |  | 208,511 |
| Total revenues | ​ | $ | 314,824 | ​ | ​ | 202,908 | ​ | ​ | 197,708 | ​ | ​ | 715,440 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 275,976 | ​ | ​ | 140,545 | ​ | ​ | 100,438 | ​ | ​ | 516,959 |
| International | ​ |  | 38,848 | ​ |  | 62,363 | ​ |  | 97,270 | ​ |  | 198,481 |
| Total revenues | ​ | $ | 314,824 | ​ | ​ | 202,908 | ​ | ​ | 197,708 | ​ | ​ | 715,440 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 136,449 | ​ | ​ | 153,163 | ​ | ​ | 40,609 | ​ | ​ | 330,221 |
| Over time | ​ |  | 178,375 | ​ |  | 49,745 | ​ |  | 157,099 | ​ |  | 385,219 |
| Total revenues | ​ | $ | 314,824 | ​ | ​ | 202,908 | ​ | ​ | 197,708 | ​ | ​ | 715,440 |

[0001410578-22-003540:notes:193]
| (b) | Remaining Performance Obligations |

[0001410578-22-003540:notes:194]
Our remaining performance obligations, which is the equivalent of our backlog, represent the expected transaction price allocated to our contracts that we expect to recognize as revenue in future periods when we perform under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At September 30, 2022, we had $695.0 million in remaining performance obligations of which we expect to recognize revenues of approximately 80% in the next twelve months.

[0001410578-22-003540:notes:195]
| (c) | Contract assets and contract liabilities |

[0001410578-22-003540:notes:196]
We report assets and liabilities related to our contracts with customers on a contract-by-contract basis at the end of each reporting period. At September 30, 2022, our contract assets and contract liabilities totaled $125.2 million and $137.6 million, respectively. At September 30, 2021, our contract assets and contract liabilities totaled $93.8 million and $108.8 million, respectively. During 2022, we recognized approximately $83.8 million in revenues that were included in the contract liabilities balance at September 30, 2021.
