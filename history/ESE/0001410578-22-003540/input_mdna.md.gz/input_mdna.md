# ESE MD&A — 0001410578-22-003540


## mdna

[0001410578-22-003540:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001410578-22-003540:mdna:2]
The following discussion should be read in conjunction with the Consolidated Financial Statements and Notes thereto and refers to our results from continuing operations except where noted.

[0001410578-22-003540:mdna:3]
Selected financial information for each of our business segments is provided in the discussion below and in Note 12 to the Company’s Consolidated Financial Statements.

[0001410578-22-003540:mdna:4]
This section includes comparisons of certain 2022 financial information to the same information for 2021. Year-to-year comparisons of the 2021 financial information to the same information for 2020 are contained in Item 7 of our Form 10-K for 2021 filed with the Securities and Exchange Commission on November 29, 2021 and available through the SEC’s website at https://www.sec.gov/edgar/searchedgar/companysearch.html.

[0001410578-22-003540:mdna:5]
Introduction

[0001410578-22-003540:mdna:6]
We classify our business operations into three segments for financial reporting purposes, although for reporting certain financial information we treat Corporate activities as a separate segment. Our three operating segments during 2022 were Aerospace & Defense (A&D), Utility Solutions Group (USG), and RF Shielding and Test (Test). Our operating segments are comprised of the following primary operating subsidiaries:

[0001410578-22-003540:mdna:7]
|  | ● | A&D: PTI Technologies Inc. (PTI); VACCO Industries (VACCO); Crissair, Inc. (Crissair); Westland Technologies, Inc. (Westland); Mayday Manufacturing Co. (Mayday); Globe Composite Solutions, LLC (Globe); and Networks Electronic Co. (NEco). |

[0001410578-22-003540:mdna:8]
|  | ● | USG: Doble Engineering Company, I.S.A. – Altanova Group S.r.l. and affiliates (Altanova) and Morgan Schaffer Ltd. (collectively, Doble); and NRG Systems, Inc. (NRG). |

[0001410578-22-003540:mdna:9]
|  | ● | Test: ETS-Lindgren Inc. (ETS-Lindgren). |

[0001410578-22-003540:mdna:10]
A&D. PTI, VACCO and Crissair primarily design and manufacture specialty filtration products, including hydraulic filter elements and fluid control devices used in commercial aerospace applications, unique filter mechanisms used in micro-propulsion devices for satellites and custom designed filters for manned aircraft and submarines. Westland and Globe design, develop and manufacture elastomeric-based signature reduction solutions for U.S. naval vessels. Mayday designs and manufactures mission-critical bushings, pins, sleeves and precision-tolerance machined components for landing gear, rotor heads, engine mounts, flight controls, and actuation systems for the aerospace and defense industries.

[0001410578-22-003540:mdna:11]
USG.  Doble develops, manufactures and delivers diagnostic testing solutions that enable electric power grid operators to assess the integrity of high-voltage power delivery equipment. NRG designs and manufactures decision support tools for the renewable energy industry, primarily wind and solar.

[0001410578-22-003540:mdna:12]
Test.  ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy.

[0001410578-22-003540:mdna:13]
We continue to operate with meaningful growth prospects in our primary served markets and with considerable financial flexibility. We continue to focus on new products that incorporate proprietary design and process technologies. Our Management is committed to delivering shareholder value through organic growth, ongoing performance improvement initiatives, and acquisitions.

[0001410578-22-003540:mdna:14]
In December 2019, we sold the businesses comprising our former Technical Packaging segment. We received net proceeds from the sale of approximately $184 million and recorded $76.5 million of after-tax net earnings on the sale in 2020. The Technical Packaging segment is reflected as discontinued operations in the Consolidated Financial Statements and related notes for all periods presented, in accordance with accounting principles generally accepted in the United States of America (GAAP). See Note 3 to the Consolidated Financial Statements for further discussion.

[0001410578-22-003540:mdna:15]
Highlights of 2022

[0001410578-22-003540:mdna:16]
|  | ● | Sales, net earnings and diluted earnings per share in 2022 were $857.5 million, $82.3 million and $3.16 per share, respectively, compared to sales, net earnings and diluted earnings per share in 2021 of $715.4 million, $63.5 million and $2.42 per share, respectively. |

[0001410578-22-003540:mdna:17]
|  | ● | Diluted EPS – GAAP for 2022 was $3.16, compared to Diluted EPS – GAAP for 2021 of $2.42. |

[0001410578-22-003540:mdna:18]
|  | ● | Diluted EPS – As Adjusted for 2022 was $3.21 excluding $1.3 million of pretax charges (or $0.05 per shares after tax), consisting of Altanova and NEco purchase accounting adjustments, severance charges primarily at VACCO and NRG, and acquisition and management transition costs at Corporate. Diluted EPS – As Adjusted for 2021 was $2.59 excluding $6.0 million of pretax charges (or $0.17 per share after tax) consisting of one-time compensation and acquisition related costs at Corporate; restructuring costs within the USG segment, primarily facility consolidation charges; purchase accounting adjustments related to the Phenix and Altanova acquisitions, primarily inventory step-up charges; partially offset by the final settlement from the sale of the Doble Watertown facility. See “Non-GAAP Financial Measures” below. |

[0001410578-22-003540:mdna:19]
| ​ | ​ | Fiscal year ended |
| (Dollars in millions) |  | 2022 |  | 2021 |
| Diluted EPS – GAAP | ​ | $ | 3.16 |  | 2.42 |
| One time compensation & acquisition related costs | ​ |  | 0.02 |  | 0.12 |
| Restructuring adjustments | ​ |  | 0.01 |  | 0.08 |
| Purchase accounting adjustments | ​ | ​ | 0.02 |  | 0.03 |
| Gain on building sale | ​ | ​ | — | ​ | (0.06) |
| Diluted EPS – As Adjusted | ​ | $ | 3.21 | ​ | 2.59 |

[0001410578-22-003540:mdna:20]
|  | ● | Net cash provided by operating activities was $135.3 million in 2022 compared to $123.1 million in 2021. |

[0001410578-22-003540:mdna:21]
|  | ● | At September 30, 2022, cash on hand was $97.7 million and outstanding debt was $153.0 million, for a net debt position (total debt less cash on hand) of approximately $55.3 million. |

[0001410578-22-003540:mdna:22]
|  | ● | Entered orders for 2022 were $960.5 million resulting in a book-to-bill ratio of 1.12x. Backlog at September 30, 2022 was $695.0 million compared to $592.0 million at September 30, 2021. |

[0001410578-22-003540:mdna:23]
|  | ● | The Company declared dividends of $0.32 per share during 2022, totaling $8.3 million in dividend payments. |

[0001410578-22-003540:mdna:24]
Results of Operations

[0001410578-22-003540:mdna:25]
Net Sales

[0001410578-22-003540:mdna:26]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | Change |  |
| ​ | ​ | Fiscal year ended | ​ | 2022 |  |
| (Dollars in millions) |  | 2022 |  | 2021 |  | vs. 2021 |  |
| A&D | ​ | $ | 351.4 |  | 314.8 |  | 11.6 | % |
| USG | ​ |  | 278.4 |  | 202.9 |  | 37.2 | % |
| Test | ​ |  | 227.7 |  | 197.7 |  | 15.2 | % |
| Total | ​ | $ | 857.5 |  | 715.4 |  | 19.9 | % |

[0001410578-22-003540:mdna:27]
Net sales increased $142.1 million, or 19.9%, to $857.5 million in 2022 from $715.4 million in 2021. The increase in net sales in 2022 as compared to 2021 was mainly due to a $75.5 million increase in the USG segment, a $36.6 million increase in the A&D segment, and a $30.0 million increase in the Test segment. Organic sales increased $90 million and recent acquisitions added approximately $52 million of revenue growth in 2022 as compared to 2021.

[0001410578-22-003540:mdna:28]
A&D.

[0001410578-22-003540:mdna:29]
The $36.6 million, or 11.6%, increase in net sales in 2022 as compared to 2021 was mainly due to a $16.4 million increase in net sales at PTI (including $5.2 million from NEco), a $14.1 million increase in net sales at Mayday, both primarily due to an increase in commercial aerospace sales driven by the rebound from the COVID-19 pandemic; a $3.0 million increase in net sales at Westland driven by timing of navy defense projects, a $1.5 million increase in net sales at VACCO, a $0.9 million increase in net sales at Crissair and a $0.7 million increase in net sales at Globe.

[0001410578-22-003540:mdna:30]
19

[0001410578-22-003540:mdna:31]
USG.

[0001410578-22-003540:mdna:32]
The $75.5 million, or 37.2%, increase in net sales in 2022 as compared to 2021 was mainly due to a $46.9 million increase in net sales from the 2021 acquisitions of Altanova and Phenix, a $20 million increase in core Doble products and services; and a $8.2 million increase in net sales at NRG driven by renewable energy products.

[0001410578-22-003540:mdna:33]
Test.

[0001410578-22-003540:mdna:34]
The $30.0 million, or 15.2%, increase in net sales in 2022 as compared to 2021 was mainly due to a $22.3 million increase in net sales from the Company’s U.S. operations, $11.5 million increase in net sales from the Company’s Asian operations both driven by increased medical and industrial shielding and power filter demand, partially offset by a $3.8 million decrease in net sales from the Company’s European operations, primarily driven by the timing of test and measurement chamber projects.

[0001410578-22-003540:mdna:35]
Orders and Backlog

[0001410578-22-003540:mdna:36]
New orders received were $960.5 million in 2022 and $796.3 million in 2021. Order backlog was $695.0 million at September 30, 2022, compared to order backlog of $592.0 million at September 30, 2021. Orders are entered into backlog as firm purchase order commitments are received.

[0001410578-22-003540:mdna:37]
By operating segment, 2022 orders were $392.5 million related to A&D products, $314.9 million related to USG products, and $253.1 million related to Test products; and 2021 orders were $337.4 million related to A&D products, $243.9 million related to USG products (including $29 million of acquired backlog), and $215.0 million related to Test products.

[0001410578-22-003540:mdna:38]
Selling, General and Administrative Expenses

[0001410578-22-003540:mdna:39]
Selling, general and administrative (SG&A) expenses were $195.1 million, or 22.7% of net sales, in 2022, and $167.5 million, or 23.4% of net sales, in 2021. The increase in SG&A expenses in 2022 as compared to 2021 was mainly due to higher expenses at Doble as a result of the SG&A expenses from the Altanova and Phenix acquisitions and the return of discretionary spending to more normal levels (travel, events, etc.) as COVID-19 pandemic related restrictions eased.

[0001410578-22-003540:mdna:40]
Amortization of Intangible Assets

[0001410578-22-003540:mdna:41]
Amortization of intangible assets was $25.9 million in 2022 and $20.8 million in 2021, including $19.3 million and $14.3 million of amortization of acquired intangible assets in 2022 and 2021, respectively, related to our acquisitions. The amortization of acquired intangible assets related to acquisitions is included in the Corporate segment’s results. The remaining amortization expenses relate to other identifiable intangible assets (primarily software, patents and licenses), which are included in the respective segment’s operating results. The increase in amortization expense in 2022 as compared to 2021 was mainly due to the Company’s recent acquisitions of Phenix, Altanova and NEco.

[0001410578-22-003540:mdna:42]
Other Income or Expenses, Net

[0001410578-22-003540:mdna:43]
Other income, net, was $0.3 million in 2022, compared to other income, net, of $0.9 million in 2021. There were no individually significant items in other income, net in 2022. The principal components of other income, net, in 2021 included a gain of approximately $2 million for the final settlement on the sale of the Doble Watertown, MA property, partially offset by facility consolidation charges within the USG segment (Doble Manta, Morgan Schaffer and Altanova facilities).

[0001410578-22-003540:mdna:44]
Non-GAAP Financial Measures

[0001410578-22-003540:mdna:45]
The information reported herein includes the financial measures Diluted EPS As Adjusted, which we define as Diluted EPS excluding the per-share impact of discrete compensation and acquisition related costs, severance charges primarily within the A&D segment, and purchase accounting charges related to the Company’s recent acquisitions (Altanova and NEco) in 2022; the per-share net impact of discrete compensation and acquisition related costs, facility consolidation charges within the USG segment, and purchase accounting charges related to the Company’s recent acquisitions in 2021, partially offset by a gain on the final installment of the Doble Watertown, MA property sale; and pension plan termination charge and restructuring charges related to our facility consolidation restructuring plans in 2020; EBIT, which we define as earnings before interest and taxes; and EBIT margin, which we define as EBIT

[0001410578-22-003540:mdna:46]
expressed as a percentage of net sales. Diluted EPS – Continuing Operations As Adjusted, EBIT on a consolidated basis, and EBIT margin on a consolidated basis are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, we believe that EBIT and EBIT margin provide investors and Management with valuable information for assessing our operating results. Management evaluates the performance of our operating segments based on EBIT and believes that EBIT is useful to investors to demonstrate the operational profitability of our business segments by excluding interest and taxes, which are generally accounted for across the entire company on a consolidated basis. EBIT is also one of the measures Management uses to determine resource allocations and incentive compensation. We believe that the presentation of EBIT, EBIT margin and Diluted EPS – Continuing Operations As Adjusted provides important supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance determined in accordance with GAAP.

[0001410578-22-003540:mdna:47]
EBIT

[0001410578-22-003540:mdna:48]
The reconciliation of EBIT to a GAAP financial measure is as follows:

[0001410578-22-003540:mdna:49]
| (Dollars in millions) |  | 2022 |  | 2021 |
| EBIT | ​ | $ | 111.3 | ​ | 82.9 |
| Less: Interest expense, net | ​ |  | (4.9) |  | (2.2) |
| Less: Income tax expense | ​ |  | (24.1) |  | (17.2) |
| Net earnings | ​ | $ | 82.3 | ​ | 63.5 |

[0001410578-22-003540:mdna:50]
EBIT by business segment is as follows:

[0001410578-22-003540:mdna:51]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | Change |  |
| ​ | ​ | Fiscal year ended | ​ | 2022 |  |
| (Dollars in millions) |  | 2022 |  | 2021 |  | vs. 2021 |  |
| A&D | ​ | $ | 68.4 |  | 56.5 |  | 21.1 | % |
| % of net sales | ​ |  | 19.5 | % | 17.9 | % | ​ | ​ |
| USG | ​ |  | 57.6 |  | 40.9 |  | 40.8 | % |
| % of net sales | ​ |  | 20.7 | % | 20.2 | % | ​ | ​ |
| Test | ​ |  | 32.6 |  | 27.6 |  | 18.1 | % |
| % of net sales | ​ |  | 14.3 | % | 14.0 | % | ​ | ​ |
| Corporate | ​ |  | (47.3) |  | (42.1) |  | (12.4) | % |
| Total | ​ | $ | 111.3 |  | 82.9 |  | 34.3 | % |
| % of net sales | ​ |  | 13.0 | % | 11.6 | % |  | ​ |

[0001410578-22-003540:mdna:52]
A&D

[0001410578-22-003540:mdna:53]
The $11.9 million, or 21.1%, increase in EBIT in 2022 as compared to 2021 was primarily due to higher sales volumes, favorable product mix and price increases at Mayday, Westland, PTI and Globe partially offset by a decrease in EBIT at Crissair and VACCO due to product mix and inflationary pressures. EBIT in 2022 was negatively impacted by a $0.3 million inventory step-up charge related to the NEco acquisition and $0.4 million of severance charges primarily at VACCO.

[0001410578-22-003540:mdna:54]
USG

[0001410578-22-003540:mdna:55]
The $16.7 million, or 40.8%, increase in EBIT in 2022 as compared to 2021 was mainly due to higher sales volumes at Doble and NRG with a favorable product mix and price increases, partially offset by inflationary pressures and increased travel and event costs. EBIT in 2022 was negatively impacted by approximately $0.5 million of inventory step-up charges related to the Altanova acquisition.

[0001410578-22-003540:mdna:56]
Test

[0001410578-22-003540:mdna:57]
The $5.0 million, or 18.1%, increase in EBIT in 2022 as compared to 2021 was primarily due to leverage on higher sales volumes and price increases mainly from the segment’s Asian and U.S. operations partially offset by material cost and wage inflation.

[0001410578-22-003540:mdna:58]
Corporate

[0001410578-22-003540:mdna:59]
Corporate operating charges included in 2022 consolidated EBIT increased to $47.3 million as compared to $42.1 million in 2021 mainly due to an increase in amortization expense of acquired intangible assets related to the Company’s recent acquisitions of Phenix, Altanova and NEco.

[0001410578-22-003540:mdna:60]
The “Reconciliation to Consolidated Totals (Corporate)” in Note 12 to the Consolidated Financial Statements represents Corporate office operating charges.

[0001410578-22-003540:mdna:61]
Interest Expense, Net

[0001410578-22-003540:mdna:62]
Interest expense, net was $4.9 million and $2.3 million in 2022 and 2021, respectively. The increase in interest expense in 2022 was mainly due to higher average outstanding borrowings and higher average interest rates. Average outstanding borrowings were $190 million in 2022 compared to $71 million in 2021. The weighted average interest rates were 2.11% in 2022 compared to 1.20% in 2021.

[0001410578-22-003540:mdna:63]
Income Tax Expense

[0001410578-22-003540:mdna:64]
The effective tax rates from continuing operations for 2022, 2021 and 2020 were 22.7%, 21.3% and 37.1%, respectively. The increase in the 2022 effective tax rate as compared to 2021 was due an increase in state income tax expense and a reduction in research credit benefits, increasing the rate by 1.0% and 0.6%, respectively.

[0001410578-22-003540:mdna:65]
No provision has been made in 2022 for foreign withholding of any applicable U.S. income taxes on the undistributed earnings of non-U.S. subsidiaries where these earnings are considered indefinitely invested or otherwise retained for continuing international operations. Determination of the amount of taxes that might be paid on these undistributed earnings if eventually remitted is not practicable.

[0001410578-22-003540:mdna:66]
Acquisitions and Divestiture

[0001410578-22-003540:mdna:67]
Information regarding our acquisitions and divestiture during 2022, 2021 and 2020 is set forth in Notes 2 and 3 to the Consolidated Financial Statements, which Notes are incorporated by reference herein.

[0001410578-22-003540:mdna:68]
All of our acquisitions have been accounted for using the purchase method of accounting, and accordingly, the respective purchase prices were allocated to the assets (including intangible assets) acquired and liabilities assumed based on estimated fair values at the date of acquisition. The financial results from these acquisitions have been included in our financial statements from the date of acquisition.

[0001410578-22-003540:mdna:69]
Capital Resources and Liquidity

[0001410578-22-003540:mdna:70]
Our overall financial position and liquidity are strong. Working capital (current assets less current liabilities) increased to $254.5 million at September 30, 2022 from $191.2 million at September 30, 2021. Accounts receivable increased by $18.3 million during 2022 mainly due to a $10.4 million increase within the USG segment, a $4.7 million increase within the Test segment and a $3.2 million increase within the A&D segment, driven by timing and higher sales volumes in the current year. Inventories increased by $15.3 million during 2022 mainly due to a $7.9 million increase within the Test segment and an $8.7 million increase within the USG segment resulting primarily from the timing of receipt of raw materials to meet anticipated demand and an increase in work in process inventories due to timing of manufacturing existing orders. Accounts payable increased by $22.1 million during 2022 mainly due to a $9.6 million increase within the Test segment, a $7.1 million increase within the A&D segment and a $4.2 million increase within the USG segment, due to the timing of payments.

[0001410578-22-003540:mdna:71]
Net cash provided by operating activities was $135.3 million in 2022 and $123.1 million in 2021.

[0001410578-22-003540:mdna:72]
Net cash used in investing activities was $55.9 million in 2022 and $202.4 million in 2021. The decrease in net cash used in investing activities in 2022 as compared to 2021 was mainly due to a decrease in amounts spent on acquisitions in 2022. Capital expenditures were $32.1 million in 2022 and $26.7 million in 2021. The increase in 2022 as compared to 2021 was mainly due to the purchase of

[0001410578-22-003540:mdna:73]
the NRG building of approximately $10 million in the first quarter of 2022. In addition, the Company incurred expenditures for capitalized software of $12.9 million in 2022 and $8.8 million in 2021.

[0001410578-22-003540:mdna:74]
There were no commitments outstanding that were considered material for capital expenditures at September 30, 2022.

[0001410578-22-003540:mdna:75]
Net cash used by financing activities was $32 million in 2022 compared to net cash provided by financing activities of $81.5 million in 2021, primarily due to lower borrowings in the current year and repurchases of common stock into treasury.

[0001410578-22-003540:mdna:76]
Bank Credit Facility

[0001410578-22-003540:mdna:77]
A description of our credit facility (the “Credit Facility”) is set forth in Note 8 to the Consolidated Financial Statements, which Note is incorporated by reference herein.

[0001410578-22-003540:mdna:78]
Cash flow from operations and borrowings under the Credit Facility is expected to provide adequate resources to meet our capital requirements and operational needs both for the next 12 months and for the foreseeable future.

[0001410578-22-003540:mdna:79]
Dividends

[0001410578-22-003540:mdna:80]
During both 2022 and 2021 we paid a regular quarterly cash dividend at an annual rate of $0.32 per share, totaling $8.3 million in both 2022 and 2021.

[0001410578-22-003540:mdna:81]
Off-Balance-Sheet Arrangements

[0001410578-22-003540:mdna:82]
We had no off-balance-sheet arrangements outstanding at September 30, 2022.

[0001410578-22-003540:mdna:83]
Share Repurchases

[0001410578-22-003540:mdna:84]
During 2022, the Company repurchased approximately 257,500 shares for approximately $20.0 million.

[0001410578-22-003540:mdna:85]
Critical Accounting Policies

[0001410578-22-003540:mdna:86]
The preparation of financial statements in conformity with U.S. generally accepted accounting principles (GAAP) requires Management to make estimates and assumptions in certain circumstances that affect amounts reported in the Consolidated Financial Statements. In preparing these financial statements, Management has made its best estimates and judgments of certain amounts included in the Consolidated Financial Statements, giving due consideration to materiality. We do not believe there is a great likelihood that materially different amounts would be reported under different conditions or using different assumptions related to the accounting policies described below. However, application of these accounting policies involves the exercise of judgment and use of assumptions as to future uncertainties and, as a result, actual results could differ from these estimates. Our senior Management discusses the critical accounting policies described below with the Audit and Finance Committee of our Board of Directors on a periodic basis.

[0001410578-22-003540:mdna:87]
The following discussion of critical accounting policies is intended to bring to the attention of readers those accounting policies which Management believes are critical to the Consolidated Financial Statements and other financial disclosure. It is not intended to be a comprehensive list of all significant accounting policies that are more fully described in Note 1 to the Consolidated Financial Statements.

[0001410578-22-003540:mdna:88]
Revenue Recognition

[0001410578-22-003540:mdna:89]
We account for revenue in accordance with ASC Topic 606, Revenue from Contracts with Customers. The unit of account in ASC Topic 606 is a performance obligation. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration, as applicable, which are based on historical, current and forecasted information. The transaction price is allocated to each distinct performance obligation within the contract and recognized as revenue when, or as, the performance obligation is satisfied. Certain of our long-term contracts contain incentive fees that can increase the transaction price. These variable amounts generally are awarded upon achievement of certain performance metrics, program milestones or cost targets and can be based upon customer discretion. We include estimated amounts in the transaction price to the

[0001410578-22-003540:mdna:90]
extent it is probable that a significant reversal of cumulative revenue recognized will not occur. The estimated amounts are based on an assessment of our anticipated performance and all other information that is reasonably available to us.

[0001410578-22-003540:mdna:91]
Approximately 60% of the A&D segment’s revenue (25% of consolidated revenue) is recognized over time as the products do not have an alternative use and either we have an enforceable right to payment for costs incurred plus a reasonable margin or the inventory is owned by the customer. Selecting the method to measure progress towards completion for our contracts requires judgment and is based on the nature of the products or services to be provided.

[0001410578-22-003540:mdna:92]
The A&D segment generally uses the cost-to-cost method to measure progress on our contracts, as the rate at which costs are incurred to fulfill a contract best depicts the transfer of control to the customer. Under this method, we measure the extent of progress towards completion based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and we record revenue proportionally as costs are incurred based on an estimated profit margin.

[0001410578-22-003540:mdna:93]
The Test segment generally uses the milestone output method to measure progress on our contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. Under this method, we estimate profit as the difference between total revenue and total estimated costs at completion of a contract and recognize these revenues and costs based on milestones achieved.

[0001410578-22-003540:mdna:94]
Total contract cost estimates are based on current contract specifications and expected engineering requirements and require us to make estimates on expected profit. The estimates on profit are based on judgments we make to project the outcome of future events, and can often span more than one year and include labor productivity and availability, the complexity of the work to be performed, change orders issued by our customers, and other specialized engineering and production related activities. Our cost estimation process is based on historical results of contracts and historical actuals to original estimates, and the application of professional knowledge and experience of engineers and program managers along with finance professionals to these historical results. We review and update our estimates of costs quarterly or more frequently when circumstances significantly change, which can affect the profitability of our contracts.

[0001410578-22-003540:mdna:95]
For contracts where revenue is recognized over time, we recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. We have net revenue recognized in the current year from performance obligations satisfied in the prior year due to changes in our estimated costs to complete the related performance obligations. We recognize anticipated losses on contracts in full in the period in which the losses become known.

[0001410578-22-003540:mdna:96]
The impact of adjustments in contract estimates on our operating earnings can be reflected in either revenue or operating costs and expenses. The aggregate impact of adjustments in contract estimates decreased our earnings before income tax and diluted earnings per share by $0.9 million and $0.03 per share, respectively, in 2022.

[0001410578-22-003540:mdna:97]
Income Taxes

[0001410578-22-003540:mdna:98]
We operate in numerous taxing jurisdictions and are subject to examination by various U.S. Federal, state and foreign jurisdictions for various tax periods. Our income tax positions are based on research and interpretations of the income tax laws and rulings in each of the jurisdictions in which we do business. Due to the subjectivity of interpretations of laws and rulings in each jurisdiction, the differences and interplay in tax laws between those jurisdictions, as well as the inherent uncertainty in estimating the final resolution of complex tax audit matters, Management’s estimates of income tax liabilities may differ from actual payments or assessments.

[0001410578-22-003540:mdna:99]
We account for income taxes under the asset and liability method. We recognize deferred tax assets and liabilities for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. We measure deferred tax assets and liabilities using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. We may reduce deferred tax assets by a valuation allowance if it is more likely than not that some portion of the deferred tax assets will not be realized. We recognize the effect on deferred tax assets and liabilities of a change in tax rates in income in the period that includes the enactment date. We regularly review our deferred tax assets for recoverability and establish a valuation allowance when Management believes it is more likely than not such assets will not be recovered, taking into consideration historical operating results, expectations of future earnings, tax planning strategies, and the expected timing of the reversals of existing temporary differences.

[0001410578-22-003540:mdna:100]
Goodwill and Other Long-Lived Assets

[0001410578-22-003540:mdna:101]
Our Management annually reviews goodwill and other long-lived assets for impairment or whenever events or changes in circumstances indicate the carrying amount may not be recoverable. If we determine that the carrying value of the goodwill and other long-lived assets may not be recoverable, we record a permanent impairment charge for the amount by which the carrying value of the goodwill and other long-lived assets exceeds its fair value. We measure fair value based on a discounted cash flow method using a discount rate determined by Management to be commensurate with the risk inherent in each of our reporting units’ or asset groups’ current business models. Our estimates of cash flows and discount rate are subject to change due to the economic environment, including such factors as interest rates, expected market returns and volatility of markets served. We believe that Management’s estimates of future cash flows and fair value are reasonable; however, changes in estimates could result in impairment charges. At September 30, 2022 we have determined that no goodwill or other long-lived assets were impaired.

[0001410578-22-003540:mdna:102]
We amortize intangible assets with estimable useful lives over their respective estimated useful lives to their estimated residual values, and review them for impairment whenever events or changes in business circumstances indicate the carrying value of the assets may not be recoverable.

[0001410578-22-003540:mdna:103]
Other Matters

[0001410578-22-003540:mdna:104]
Quantitative and Qualitative Disclosures about Market Risk

[0001410578-22-003540:mdna:105]
Market risks relating to our operations result primarily from changes in interest rates and changes in foreign currency exchange rates. We are exposed to market risk related to changes in interest rates, and we selectively use derivative financial instruments, including forward contracts and swaps, to manage these risks. Our Canadian subsidiary Morgan Schaffer has entered into foreign exchange contracts to manage foreign currency risk, because a portion of their revenue is denominated in U.S. dollars. We report all derivative instruments on our balance sheet at fair value. For derivative instruments designated as cash flow hedges, we defer the gain or loss on the derivative in accumulated other comprehensive income until recognized in earnings with the underlying hedged item.
