# ESE 8-K — 0001104659-22-119898 filed 2022-11-17

## item codes, every 8-K on or before 2022-11-29

- 2022-11-22 0001104659-22-121229 — 5.02, 5.03, 8.01, 9.01
- 2022-11-17 0001104659-22-119898 — 2.02, 7.01, 9.01
- 2022-09-12 0001104659-22-099248 — 5.02, 7.01, 9.01
- 2022-08-08 0001104659-22-087247 — 2.02, 5.02, 7.01, 9.01
- 2022-05-09 0001104659-22-057524 — 2.02, 5.02, 7.01, 9.01
- 2022-02-08 0001104659-22-013878 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2021-12-03 0001104659-21-146361 — 4.01, 9.01 — amendment, the index does not say of what
- 2021-11-24 0001104659-21-143568 — 4.01, 9.01
- 2021-11-23 0001104659-21-142871 — 5.02, 8.01
- 2021-11-18 0001104659-21-141206 — 2.02, 7.01, 9.01
- 2021-08-09 0001104659-21-102150 — 2.02, 7.01, 9.01
- 2021-05-04 0001104659-21-060985 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2021-04-05 0001104659-21-046581 — 5.02, 9.01
- 2021-02-08 0001104659-21-013712 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2020-12-09 0001104659-20-133674 — 5.02, 9.01
- 2020-12-07 0001104659-20-132861 — 5.02, 7.01, 9.01
- 2020-11-19 0001104659-20-127352 — 2.02, 5.02, 7.01, 9.01
- 2020-08-10 0001104659-20-092734 — 2.02, 7.01, 9.01
- 2020-05-06 0001104659-20-057442 — 2.02, 7.01, 8.01, 9.01
- 2020-02-04 0001104659-20-010640 — 2.02, 5.07, 7.01, 9.01
- 2020-01-07 0001104659-20-001789 — 2.01, 9.01
- 2019-11-19 0001104659-19-065437 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2019-11-18 0001104659-19-065096 — 1.01, 2.02, 7.01, 9.01
- 2019-09-30 0001144204-19-046523 — 1.01, 1.02, 2.03, 9.01
- 2019-08-08 0001144204-19-038567 — 2.02, 7.01, 9.01
- 2019-05-07 0001144204-19-024241 — 2.02, 5.02, 7.01, 9.01
- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2022-11-29

- none on or before 2022-11-29

## item 2.02 — earnings release, exhibit 99.1

[0001104659-22-119898:8k_2_02:1]
EX-99.1
2
tm2230785d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-22-119898:8k_2_02:2]
Exhibit 99.1

[0001104659-22-119898:8k_2_02:3]
| NEWS FROM |  |

[0001104659-22-119898:8k_2_02:4]
For more information contact:

[0001104659-22-119898:8k_2_02:5]
Kate Lowrey - VP of Investor Relations

[0001104659-22-119898:8k_2_02:6]
(314) 213-7277
/ klowrey@escotechnologies.com

[0001104659-22-119898:8k_2_02:7]
ESCO ANNOUNCES RECORD FOURTH QUARTER AND
FISCAL 2022 RESULTS

[0001104659-22-119898:8k_2_02:8]
- Q4 GAAP EPS $1.19 / Adjusted EPS $1.21
-

[0001104659-22-119898:8k_2_02:9]
- FY 2022 Sales increase 20% to $858 Million
-

[0001104659-22-119898:8k_2_02:10]
- $135 Million in Cash Flow from Operations
in FY 2022 -

[0001104659-22-119898:8k_2_02:11]
ST. LOUIS, November 17, 2022 – ESCO Technologies
Inc. (NYSE: ESE) (ESCO, or the Company) today reported its operating results for the fourth quarter (Q4 2022) and fiscal year (FY 2022)
ended September 30, 2022.

[0001104659-22-119898:8k_2_02:12]
Operating Highlights

[0001104659-22-119898:8k_2_02:13]
|  | · | Q4 2022 GAAP EPS increased $0.41 per share (53 percent) to $1.19 per share compared to $0.78 per share in Q4 2021. Q4 2022 Adjusted EPS increased $0.36 per share (42 percent) to $1.21 per share compared to $0.85 per share in Q4 2021. |
|  | · | FY 2022 GAAP EPS increased $0.74 per share (31 percent) to $3.16 per share compared to $2.42 per share in FY 2021. FY 2022 Adjusted EPS increased $0.62 per share (24 percent) to $3.21 per share compared to $2.59 per share in FY 2021. |
|  | · | Q4 2022 sales increased $51 million (25 percent) to $256 million compared to $205 million in Q4 2021. Organic sales increased $38 million (19 percent) and recent acquisitions added $13 million (6 percent) of revenue growth in the quarter. |
|  | · | FY 2022 sales increased $142 million (20 percent) to $858 million. Organic sales increased $90 million (13 percent) and recent acquisitions added $52 million (7 percent) of revenue growth for the full year. |
|  | · | Q4 2022 entered orders decreased $14 million (5 percent) compared to the prior year period to $245 million (book-to-bill of 0.95x). Full year 2022 entered orders increased $164 million (21 percent) to $961 million (book-to-bill of 1.12x) and resulted in record year-end backlog of $695 million. |
|  | · | Net cash provided by operating activities was $94 million in Q4 and $135 million for the full year, resulting in an increase of $12 million (10 percent) over the prior year. |
|  | · | Net debt (total borrowings less cash on hand) was $55 million, resulting in a leverage ratio of 0.78x and $589 million in available liquidity on September 30, 2022. |

[0001104659-22-119898:8k_2_02:14]
FY 2022 was a record year for sales, Adjusted EBIT,
Adjusted EPS, cash flow from operations, entered orders, and year-end backlog. Entered orders were strong across our end-markets, with
all three business segments reporting a book-to-bill greater than 1.1x. Overall, entered orders increased 21 percent compared to the
prior year and drove record year-end backlog of $695 million. Cash flow from operations was $135 million with a 108 percent free cash
flow conversion rate. Recovery in key end-markets combined with solid orders momentum drove meaningful growth and improved operating
results during the year.

[0001104659-22-119898:8k_2_02:15]
Vic Richey, Chairman and Chief Executive Officer, commented, “Given
the continuing economic disruptions and global headwinds throughout the year, I am very pleased that we were able to deliver outstanding
results from both a growth and profitability perspective. Despite considerable challenges, we were able to exceed our commitments as
communicated at the start of the year. ESCO is an industry leader that serves healthy end-markets, and through the tremendous efforts
of our employees we were able to deliver results we are all very proud of in 2022.”

[0001104659-22-119898:8k_2_02:16]
Segment Performance

[0001104659-22-119898:8k_2_02:17]
Aerospace & Defense (A&D)

[0001104659-22-119898:8k_2_02:18]
| · | Q4 2022 sales increased $24 million (30 percent) to $104 million from $80 million in Q4 2021. Q4 sales growth was the result of strong demand across our commercial and defense aerospace, Navy, and space platforms. FY 2022 sales increased $37 million (12 percent) to $351 million, largely driven by commercial aerospace, which increased $30 million (32 percent) to $123 million. Higher Navy and space sales were partially offset by lower industrial sales compared to the prior year. |
| · | Q4 2022 EBIT increased $8.7 million to $23.3 million from $14.6 million in Q4 2021. Adjusted EBIT increased $8.9 million in Q4 2022 to $23.6 million (22.7 percent margin) from $14.7 million (18.3 percent margin) in Q4 2021. FY 2022 EBIT increased $11.9 million to $68.4 million from $56.5 million in FY 2021. FY 2022 Adjusted EBIT increased $12.0 million to $69.0 million (19.6 percent margin) from $57.0 million (18.1 percent margin) in FY 2021. Margin increases for the quarter and year were driven by higher volumes and price increases, partially offset by inflationary pressures. |
| · | Entered Orders increased $9 million to $97 million in Q4 2022. For the full year entered orders increased $55 million (16 percent) to $392 million (book-to-bill of 1.12). The orders strength was primarily driven by the continuing recovery of commercial aerospace and resulted in record year-end backlog of $408 million. |

[0001104659-22-119898:8k_2_02:19]
Utility Solutions Group (USG)

[0001104659-22-119898:8k_2_02:20]
| · | Q4 sales increased $22 million (37 percent) to $83 million from $61 million in Q4 2021. Organic sales increased $12 million (21 percent) and recent acquisitions Phenix and Altanova contributed $10 million in revenue. FY 2022 sales increased $75 million (37 percent) to $278 million from $203 million in FY 2021. Doble organic sales increased $20 million (12 percent), NRG sales increased $8 million (24 percent), and Phenix and Altanova added $47 million, The organic sales growth was driven by increased electric utility spending and strong demand across our renewables product lines. |

[0001104659-22-119898:8k_2_02:21]
| · | Q4 2022 EBIT increased $6.5 million to $19.8 million from $13.3 million in Q4 2021. Adjusted EBIT increased $4.9 million in Q4 2022 to $19.8 million (23.7 percent margin) from $14.9 million (24.3 percent margin) in Q4 2021. FY 2022 EBIT increased $16.7 million to $57.6 million from $40.9 million in FY 2021. FY 2022 Adjusted EBIT increased $15.7 million to $58.1 million (20.9 percent margin) from $42.4 million (20.9 percent margin) in FY 2021. Adjusted EBIT increases for the quarter and year were largely driven by higher volumes and price increases, partially offset by inflationary pressures, increased travel and conference costs. |
| · | Entered Orders decreased $8 million to $88 million in Q4 2022. Orders for the quarter were lower due to the timing of orders booked related to the backlog acquired with the Phenix and Altanova transactions in Q4 2021. For the full year entered orders increased $71 million to $315 million (book-to-bill of 1.13) and resulted in year-end backlog of $128 million. Orders strength was driven by contributions from Altanova and Phenix, increased electric utility spending and continuing growth in the demand for renewables. |

[0001104659-22-119898:8k_2_02:22]
Test

[0001104659-22-119898:8k_2_02:23]
| · | Q4 2022 sales increased $5 million (8 percent) to $69 million from $64 million in Q4 2021, primarily due to increased medical and industrial shielding and power filter demand. FY 2022 sales increased $30 million (15 percent) to $228 million, driven by increased test and measurement projects, medical and industrial shielding, and power filter demand. |
| · | Q4 2022 EBIT increased $1.9 million to $11.8 million (17.0 percent margin) from $9.9 million (15.3 percent margin) in Q4 2021. FY 2022 EBIT increased $5.0 million to $32.6 million (14.3 percent margin) from $27.6 million (14.0 percent margin) in FY 2021. The increase in profitability was driven by leverage on higher sales and price increases, partially offset by material cost and wage inflation. |
| · | Entered Orders decreased $14 million to $59 million in Q4 2022. Orders were lower during the quarter primarily due to the timing of large power filter orders in Q4 2021. For the full year entered orders increased $38 million to $253 million (book-to-bill of 1.11) and resulted in record year-end backlog of $159 million. The orders strength was driven by medical shielding and global demand for test and measurement projects. |

[0001104659-22-119898:8k_2_02:24]
Share Repurchase Program

[0001104659-22-119898:8k_2_02:25]
The Company did not repurchase any shares of stock
during Q4 2022. During FY 2022 the Company repurchased approximately 257,500 shares for $20 million.

[0001104659-22-119898:8k_2_02:26]
Dividend Payment

[0001104659-22-119898:8k_2_02:27]
The next quarterly cash dividend
of $0.08 per share will be paid on January 20, 2023 to stockholders of record on January 5, 2023.

[0001104659-22-119898:8k_2_02:28]
2023 Annual Meeting

[0001104659-22-119898:8k_2_02:29]
The 2023 Annual Meeting of the Company’s
Shareholders will be held on February 3, 2023.

[0001104659-22-119898:8k_2_02:30]
Business Outlook – FY 2023

[0001104659-22-119898:8k_2_02:31]
Management expects continued growth in sales, Adjusted EBIT, and Adjusted
EBITDA across each of the Company’s business segments in 2023.

[0001104659-22-119898:8k_2_02:32]
Management’s expectations for growth in 2023 compared to 2022:

[0001104659-22-119898:8k_2_02:33]
| · | Net sales are expected to grow 6 to 8 percent and be in the range of $910 to $930 million on a consolidated basis, with A&D growing 10 to 13 percent, USG growing 5 to 7 percent, and Test growing 3 to 5 percent. |
| · | Adjusted EBIT is expected to increase approximately 10 to 15 percent with Adjusted EBIT margins increasing to 13.5 to 14.0 percent of sales. |
| · | Adjusted EBITDA is expected to increase approximately 7 to 12 percent with Adjusted EBITDA margins increasing to 19.0 to 19.5 percent of sales. |
| · | Interest expense is expected to increase approximately $4.3 million to over $9 million (due to higher interest rates) excluding the impact of any future acquisitions. |
| · | The effective income tax rate is expected to be in the range of 22.5 to 23.5 percent in 2023. |
| · | Management projects 2023 Adjusted EPS to increase 7.5 to 12 percent and be in the range of $3.45 to $3.60 per share. This projection reflects margin expansion on the anticipated sales growth, partially offset by increased interest expense. |
| · | Management expects flat to slightly up Adjusted EPS of $0.46 - $0.52 in Q1 2023 compared to the prior year. Consistent with prior years, revenues and Adjusted EPS are expected to grow sequentially throughout the year. |

[0001104659-22-119898:8k_2_02:34]
Management Transition

[0001104659-22-119898:8k_2_02:35]
As previously announced, Vic Richey will be retiring from his roles
as CEO and President at the end of the calendar year. Mr. Richey will continue as Executive Chairman of the Board during a transition
period as current USG President Bryan Sayler assumes the roles of ESCO CEO and President. Richey commented “It’s been a pleasure
to work at ESCO for 37 years and an honor to serve as CEO for the past 20 years. We have accomplished a lot during this time, and I am
very thankful to our employees who have shown extreme dedication and effort over the years. I’d also like to thank our Board of
Directors for their ongoing support of the Company as we worked to create what ESCO is today. I’m very excited about the future
of the Company. Bryan has over 25 years of leadership experience at ESCO and is uniquely qualified to lead the company moving forward.”
Mr. Sayler is currently transitioning from his position as President of the USG segment and will assume the positions of CEO and President
of ESCO on January 1, 2023. “As I step into my new role at ESCO, I’m excited for the opportunity to lead this vibrant organization
as we continue to build upon the strong foundation established under Vic’s leadership,” said Sayler.

[0001104659-22-119898:8k_2_02:36]
Conference Call

[0001104659-22-119898:8k_2_02:37]
The Company will host a conference call today, November 17, at 4:00
p.m. Central Time, to discuss the Company’s Q4 and full year 2022 results. A live audio webcast and an accompanying slide presentation
will be available on ESCO’s investor website at https://investor.escotechnologies.com. For those unable to participate, a webcast
replay will be available after the call on ESCO’s investor website.

[0001104659-22-119898:8k_2_02:38]
Forward-Looking Statements

[0001104659-22-119898:8k_2_02:39]
Statements in this press release regarding the timing
and magnitude of recovery in the Company’s end markets, the continuing impacts of COVID-19 on the Company’s results, sales,
Adjusted EBIT, Adjusted EBITDA, Adjusted EPS, cash flow, results of cost reduction efforts, margins, growth, the financial success of
the Company, the strength of its end markets, the outlook for the A&D, Test and USG segments, the ability to increase shareholder
value, the timing and success of acquisition efforts, internal investments in new products and solutions, the impacts of inflation, the
long-term success of the Company, and any other statements which are not strictly historical are “forward-looking” statements
within the meaning of the safe harbor provisions of the federal securities laws.

[0001104659-22-119898:8k_2_02:40]
Investors are cautioned that such statements
are only predictions and speak only as of the date of this release, and the Company undertakes no duty to update them except as may
be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those
projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business
environment including but not limited to those described in Item 1A, “Risk Factors”, of the Company’s Annual
Report on Form 10-K for the fiscal year ended September 30, 2021; the availability and acceptance of viable COVID-19 vaccines by
enough of the U.S. and world’s population to curtail the pandemic; the continuing impact of the COVID-19 pandemic and the
effects of known or unknown COVID-19 variants including labor shortages, facility closures, shelter in place policies or
quarantines, material shortages, transportation delays, termination or delays of Company contracts, and the inability of our
suppliers or customers to perform; the impacts of Executive Order 14042 and other vaccine mandates on our employees and businesses;
the impacts of natural disasters on the Company’s operations and those of the Company’s customers and suppliers; the
timing and content of future contract awards or customer orders; the appropriation, allocation and availability of Government funds;
the termination for convenience of Government and other customer contracts or orders; weakening of economic conditions in served
markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies; competition;
intellectual property rights; technical difficulties; the success of the Company’s acquisition efforts; delivery delays or
defaults by customers; performance issues with key customers, suppliers and subcontractors; changes in the costs and availability of
certain raw materials; labor disputes; changes in U.S. tax laws and regulations; other changes in laws and regulations including but
not limited to changes in accounting standards and foreign taxation; changes in interest rates; costs relating to environmental
matters arising from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims,
litigation or arbitration; and the integration of recently acquired businesses.

[0001104659-22-119898:8k_2_02:41]
Non-GAAP Financial Measures

[0001104659-22-119898:8k_2_02:42]
The financial measures EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA,
and Adjusted EPS are presented in this press release. The Company defines “EBIT” as earnings before interest and taxes, “EBITDA”
as earnings before interest, taxes, depreciation and amortization, “Adjusted EBIT” and “Adjusted EBITDA” as excluding
the net impact of the items described in the attached Reconciliation of Non-GAAP Financials Measures, and “Adjusted EPS”
as GAAP earnings per share excluding the net impact of the items described and reconciled in the attached Reconciliation of Non-GAAP
Financial Measures.

[0001104659-22-119898:8k_2_02:43]
EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA, and
Adjusted EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management believes
EBIT, Adjusted EBIT, EBITDA, and Adjusted EBITDA are useful in assessing the operational profitability of the Company’s business
segments because they exclude interest, taxes, depreciation, and amortization, which are generally accounted for across the entire Company
on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company as
well as incentive compensation. The presentation of EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA, and Adjusted EPS provides important
supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial
measures to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance
determined in accordance with GAAP.

[0001104659-22-119898:8k_2_02:44]
ESCO is a global provider of highly engineered products and solutions
serving diverse end-markets. It manufactures filtration and fluid control products for the aviation, Navy, space, and process markets
worldwide and composite-based products and solutions for Navy, defense, and industrial customers. ESCO is the industry leader in RF shielding
and EMC test products; and provides diagnostic instruments, software and services to industrial power users and the electric utility
and renewable energy industries. Headquartered in St. Louis, Missouri, ESCO and its subsidiaries have offices and manufacturing facilities
worldwide. For more information on ESCO and its subsidiaries, visit the Company’s website at www.escotechnologies.com.

[0001104659-22-119898:8k_2_02:45]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-22-119898:8k_2_02:46]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-22-119898:8k_2_02:47]
(Dollars in thousands, except per share amounts)

[0001104659-22-119898:8k_2_02:48]
|  |  | Three Months Ended September 30, 2022 |  |  | Three Months Ended September 30, 2021 |  |
| Net Sales |  | $ | 256,498 |  |  |  | 205,478 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 154,323 |  |  |  | 128,260 |  |
| Selling, general and administrative expenses |  |  | 53,054 |  |  |  | 44,906 |  |
| Amortization of intangible assets |  |  | 6,553 |  |  |  | 6,100 |  |
| Interest expense |  |  | 1,767 |  |  |  | 802 |  |
| Other (income) expenses, net |  |  | 373 |  |  |  | 371 |  |
| Total costs and expenses |  |  | 216,070 |  |  |  | 180,439 |  |
| Earnings before income taxes |  |  | 40,428 |  |  |  | 25,039 |  |
| Income tax expense |  |  | 9,388 |  |  |  | 4,674 |  |
| Net earnings |  | $ | 31,040 |  |  |  | 20,365 |  |
| Diluted EPS: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 1.19 |  |  |  | 0.78 |  |
| Diluted - As Adjusted Basis |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 1.21 | (1) |  |  | 0.85 | (2) |
| Diluted average common shares O/S: |  |  | 25,990 |  |  |  | 26,232 |  |

[0001104659-22-119898:8k_2_02:49]
| (1) | Q4 2022 Adjusted EPS excludes $0.02 per share of after-tax severance charges at VACCO and NRG and Corporate management transition costs. |

[0001104659-22-119898:8k_2_02:50]
| (2) | Q4 2021 Adjusted EPS excludes $0.07 per share of after-tax charges mainly consisting of purchase accounting adjustments related to the Phenix & Altanova acquisitions, acquisition costs at Corporate, and restructuring costs primarily within the USG segment. |

[0001104659-22-119898:8k_2_02:51]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-22-119898:8k_2_02:52]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-22-119898:8k_2_02:53]
(Dollars in thousands, except per share amounts)

[0001104659-22-119898:8k_2_02:54]
|  |  | Year Ended September 30, 2022 |  |  | Year Ended September 30, 2021 |  |
| Net Sales |  | $ | 857,502 |  |  |  | 715,440 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 525,457 |  |  |  | 445,045 |  |
| Selling, general and administrative expenses |  |  | 195,127 |  |  |  | 167,534 |  |
| Amortization of intangible assets |  |  | 25,936 |  |  |  | 20,829 |  |
| Interest expense |  |  | 4,851 |  |  |  | 2,255 |  |
| Other (income) expenses, net |  |  | (304 | ) |  |  | (894 | ) |
| Total costs and expenses |  |  | 751,067 |  |  |  | 634,769 |  |
| Earnings before income taxes |  |  | 106,435 |  |  |  | 80,671 |  |
| Income tax expense |  |  | 24,115 |  |  |  | 17,175 |  |
| Net earnings |  | $ | 82,320 |  |  |  | 63,496 |  |
| Diluted EPS: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 3.16 |  |  |  | 2.42 |  |
| Diluted - As Adjusted Basis |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 3.21 | (1) |  |  | 2.59 | (2) |
| Diluted average common shares O/S: |  |  | 26,067 |  |  |  | 26,225 |  |

[0001104659-22-119898:8k_2_02:55]
| (1) | FY 2022 Adjusted EPS excludes $0.05 per share of after-tax charges associated with the Altanova & Neco acquisition inventory step-up charges, severance charges at VACCO and NRG, Corporate acquisition costs and management transition costs. |
| (2) | FY 2021 Adjusted EPS excludes $0.17 per share of after-tax charges mainly consisting of management transition and acquisition costs at Corporate, restructuring costs primarily within the USG segment, and purchase accounting adjustments related to the Phenix & Altanova acquisitions, partially offset by the final settlement from the sale of the Doble Watertown facility. |

[0001104659-22-119898:8k_2_02:56]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-22-119898:8k_2_02:57]
Condensed Business Segment Information (Unaudited)

[0001104659-22-119898:8k_2_02:58]
(Dollars in thousands)

[0001104659-22-119898:8k_2_02:59]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | Q4 2022 |  |  | Q4 2021 |  |  | Q4 2022 |  |  | Q4 2021 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 103,742 |  |  |  | 80,105 |  |  |  | 103,742 |  |  |  | 80,105 |  |
| USG |  |  | 83,490 |  |  |  | 61,107 |  |  |  | 83,490 |  |  |  | 61,107 |  |
| Test |  |  | 69,266 |  |  |  | 64,266 |  |  |  | 69,266 |  |  |  | 64,266 |  |
| Totals |  | $ | 256,498 |  |  |  | 205,478 |  |  |  | 256,498 |  |  |  | 205,478 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 23,310 |  |  |  | 14,557 |  |  |  | 23,590 |  |  |  | 14,657 |  |
| USG |  |  | 19,764 |  |  |  | 13,264 |  |  |  | 19,813 |  |  |  | 14,874 |  |
| Test |  |  | 11,779 |  |  |  | 9,855 |  |  |  | 11,779 |  |  |  | 9,855 |  |
| Corporate |  |  | (12,658 | ) |  |  | (11,835 | ) |  |  | (12,428 | ) |  |  | (11,181 | ) |
| Consolidated EBIT |  |  | 42,195 |  |  |  | 25,841 |  |  |  | 42,754 |  |  |  | 28,205 |  |
| Less: Interest expense |  |  | (1,767 | ) |  |  | (802 | ) |  |  | (1,767 | ) |  |  | (802 | ) |
| Less: Income tax expense |  |  | (9,388 | ) |  |  | (4,674 | ) |  |  | (9,517 | ) |  |  | (5,218 | ) |
| Net earnings |  | $ | 31,040 |  |  |  | 20,365 |  |  |  | 31,470 |  |  |  | 22,185 |  |

[0001104659-22-119898:8k_2_02:60]
Note 1: Adjusted net earnings of $31.5 million
in Q4 2022 exclude $0.4 million (or $0.02 per share) of after-tax severance charges at VACCO and NRG, and Corporate management transition
costs.

[0001104659-22-119898:8k_2_02:61]
Note 2: Adjusted net earnings of $22.2 million in Q4 2021 exclude $1.8 million (or $0.07 per share) of after-tax charges mainly consisting of purchase accounting adjustments related to the Phenix & Altanova acquisitions, and acquisition costs at Corporate.

[0001104659-22-119898:8k_2_02:62]
|  |  |  |  |  |  |  |  | Adjusted |  |  | Adjusted |  |
| EBITDA Reconciliation to Net earnings: |  | Q4 2022 |  |  | Q4 2021 |  |  | Q4 2022 |  |  | Q4 2021 |  |
| Consolidated EBITDA |  | $ | 54,291 |  |  |  | 37,631 |  |  |  | 54,850 |  |  |  | 39,995 |  |
| Less: Depr & Amort |  |  | (12,096 | ) |  |  | (11,790 | ) |  |  | (12,096 | ) |  |  | (11,790 | ) |
| Consolidated EBIT |  |  | 42,195 |  |  |  | 25,841 |  |  |  | 42,754 |  |  |  | 28,205 |  |
| Less: Interest expense |  |  | (1,767 | ) |  |  | (802 | ) |  |  | (1,767 | ) |  |  | (802 | ) |
| Less: Income tax expense |  |  | (9,388 | ) |  |  | (4,674 | ) |  |  | (9,517 | ) |  |  | (5,218 | ) |
| Net earnings |  | $ | 31,040 |  |  |  | 20,365 |  |  |  | 31,470 |  |  |  | 22,185 |  |

[0001104659-22-119898:8k_2_02:63]
SCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-22-119898:8k_2_02:64]
Condensed Business Segment Information (Unaudited)

[0001104659-22-119898:8k_2_02:65]
(Dollars in thousands)

[0001104659-22-119898:8k_2_02:66]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | FY 2022 |  |  | FY 2021 |  |  | FY 2022 |  |  | FY 2021 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 351,413 |  |  |  | 314,824 |  |  |  | 351,413 |  |  |  | 314,824 |  |
| USG |  |  | 278,367 |  |  |  | 202,908 |  |  |  | 278,367 |  |  |  | 202,908 |  |
| Test |  |  | 227,722 |  |  |  | 197,708 |  |  |  | 227,722 |  |  |  | 197,708 |  |
| Totals |  | $ | 857,502 |  |  |  | 715,440 |  |  |  | 857,502 |  |  |  | 715,440 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 68,352 |  |  |  | 56,536 |  |  |  | 68,967 |  |  |  | 57,021 |  |
| USG |  |  | 57,604 |  |  |  | 40,948 |  |  |  | 58,120 |  |  |  | 42,427 |  |
| Test |  |  | 32,592 |  |  |  | 27,636 |  |  |  | 32,592 |  |  |  | 27,636 |  |
| Corporate |  |  | (47,262 | ) |  |  | (42,194 | ) |  |  | (46,727 | ) |  |  | (38,167 | ) |
| Consolidated EBIT |  |  | 111,286 |  |  |  | 82,926 |  |  |  | 112,952 |  |  |  | 88,917 |  |
| Less: Interest expense |  |  | (4,851 | ) |  |  | (2,255 | ) |  |  | (4,851 | ) |  |  | (2,255 | ) |
| Less: Income tax |  |  | (24,115 | ) |  |  | (17,175 | ) |  |  | (24,499 | ) |  |  | (18,553 | ) |
| Net earnings |  | $ | 82,320 |  |  |  | 63,496 |  |  |  | 83,602 |  |  |  | 68,109 |  |

[0001104659-22-119898:8k_2_02:67]
Note 1: Adjusted net earnings of $83.6 million
in FY 2022 exclude $1.3 million (or $0.05 per share) of after-tax charges associated with the Altanova & Neco acquisition inventory
step-up charges, severance charges at VACCO and NRG, and Corporate acquisition and management transition costs.

[0001104659-22-119898:8k_2_02:68]
Note 2: Adjusted net earnings of $68.1 million in FY 2021 exclude $4.6 million ($0.17 per share) of after-tax charges mainly consisting of management transition and acquisition costs at Corporate, restructuring costs primarily within the USG segment, and purchase accounting adjustments related to the Phenix & Altanova acquisitions, partially offset by the final settlement from the sale of the Doble Watertown facility.

[0001104659-22-119898:8k_2_02:69]
|  |  |  |  |  |  |  |  | Adjusted |  |  | Adjusted |  |
| EBITDA Reconciliation to Net earnings: |  | FY 2022 |  |  | FY 2021 |  |  | FY 2022 |  |  | FY 2021 |  |
| Consolidated EBITDA |  | $ | 159,629 |  |  |  | 124,975 |  |  |  | 161,295 |  |  |  | 130,966 |  |
| Less: Depr & Amort |  |  | (48,343 | ) |  |  | (42,049 | ) |  |  | (48,343 | ) |  |  | (42,049 | ) |
| Consolidated EBIT |  |  | 111,286 |  |  |  | 82,926 |  |  |  | 112,952 |  |  |  | 88,917 |  |
| Less: Interest expense |  |  | (4,851 | ) |  |  | (2,255 | ) |  |  | (4,851 | ) |  |  | (2,255 | ) |
| Less: Income tax expense |  |  | (24,115 | ) |  |  | (17,175 | ) |  |  | (24,499 | ) |  |  | (18,553 | ) |
| Net earnings |  | $ | 82,320 |  |  |  | 63,496 |  |  |  | 83,602 |  |  |  | 68,109 |  |

[0001104659-22-119898:8k_2_02:70]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-22-119898:8k_2_02:71]
Condensed Consolidated Balance Sheets (Unaudited)

[0001104659-22-119898:8k_2_02:72]
(Dollars in thousands)

[0001104659-22-119898:8k_2_02:73]
|  |  | September 30, 2022 |  |  | September 30, 2021 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 97,724 |  |  |  | 56,232 |  |
| Accounts receivable, net |  |  | 164,645 |  |  |  | 146,341 |  |
| Contract assets |  |  | 125,154 |  |  |  | 93,771 |  |
| Inventories |  |  | 162,403 |  |  |  | 147,148 |  |
| Other current assets |  |  | 22,696 |  |  |  | 22,662 |  |
| Total current assets |  |  | 572,622 |  |  |  | 466,154 |  |
| Property, plant and equipment, net |  |  | 155,973 |  |  |  | 154,265 |  |
| Intangible assets, net |  |  | 394,464 |  |  |  | 409,250 |  |
| Goodwill |  |  | 492,709 |  |  |  | 504,853 |  |
| Operating lease assets |  |  | 29,150 |  |  |  | 31,846 |  |
| Other assets |  |  | 9,538 |  |  |  | 10,977 |  |
|  |  | $ | 1,654,456 |  |  |  | 1,577,345 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt |  | $ | 20,000 |  |  |  | 20,000 |  |
| Accounts payable |  |  | 78,746 |  |  |  | 56,669 |  |
| Contract liabilities |  |  | 125,009 |  |  |  | 106,045 |  |
| Other current liabilities |  |  | 94,374 |  |  |  | 92,281 |  |
| Total current liabilities |  |  | 318,129 |  |  |  | 274,995 |  |
| Deferred tax liabilities |  |  | 82,023 |  |  |  | 73,560 |  |
| Non-current operating lease liabilities |  |  | 24,853 |  |  |  | 28,032 |  |
| Other liabilities |  |  | 48,294 |  |  |  | 47,062 |  |
| Long-term debt |  |  | 133,000 |  |  |  | 134,000 |  |
| Shareholders' equity |  |  | 1,048,157 |  |  |  | 1,019,696 |  |
|  |  | $ | 1,654,456 |  |  |  | 1,577,345 |  |

[0001104659-22-119898:8k_2_02:74]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-22-119898:8k_2_02:75]
Consolidated Statements of Cash Flows

[0001104659-22-119898:8k_2_02:76]
(Dollars in thousands)

[0001104659-22-119898:8k_2_02:77]
|  |  | Year Ended September 30, 2022 |  |  | Year Ended September 30, 2021 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 82,320 |  |  |  | 63,496 |  |
| Adjustments to reconcile net earnings to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 48,343 |  |  |  | 42,049 |  |
| Stock compensation expense |  |  | 7,320 |  |  |  | 6,914 |  |
| Changes in assets and liabilities |  |  | (11,654 | ) |  |  | 15,671 |  |
| Gain on sale of building and land |  |  | 0 |  |  |  | (1,950 | ) |
| Effect of deferred taxes |  |  | 8,946 |  |  |  | (3,041 | ) |
| Net cash provided by operating activities |  |  | 135,275 |  |  |  | 123,139 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Acquisition of business, net of cash acquired |  |  | (10,906 | ) |  |  | (168,903 | ) |
| Capital expenditures |  |  | (32,101 | ) |  |  | (26,705 | ) |
| Additions to capitalized software |  |  | (12,912 | ) |  |  | (8,783 | ) |
| Proceeds from sale of building and land |  |  | 0 |  |  |  | 1,950 |  |
| Net cash used by investing activities |  |  | (55,919 | ) |  |  | (202,441 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from long-term debt |  |  | 116,000 |  |  |  | 216,000 |  |
| Principal payments on long-term debt and short-term borrowings |  |  | (117,000 | ) |  |  | (124,368 | ) |
| Dividends paid |  |  | (8,268 | ) |  |  | (8,336 | ) |
| Purchases of common stock into treasury |  |  | (19,878 | ) |  |  | 0 |  |
| Other |  |  | (2,976 | ) |  |  | (1,823 | ) |
| Net cash (used) provided by financing activities |  |  | (32,122 | ) |  |  | 81,473 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (5,742 | ) |  |  | 1,501 |  |
| Net increase in cash and cash equivalents |  |  | 41,492 |  |  |  | 3,672 |  |
| Cash and cash equivalents, beginning of period |  |  | 56,232 |  |  |  | 52,560 |  |
| Cash and cash equivalents, end of period |  | $ | 97,724 |  |  |  | 56,232 |  |

[0001104659-22-119898:8k_2_02:78]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-22-119898:8k_2_02:79]
Other Selected Financial Data (Unaudited)

[0001104659-22-119898:8k_2_02:80]
(Dollars in thousands)

[0001104659-22-119898:8k_2_02:81]
| Backlog And Entered Orders - Q4 2022 |  | Aerospace & Defense |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 7/1/22 |  | $ | 414,521 |  |  |  | 123,850 |  |  |  | 168,429 |  |  |  | 706,800 |  |
| Entered Orders |  |  | 97,490 |  |  |  | 87,796 |  |  |  | 59,434 |  |  |  | 244,720 |  |
| Sales |  |  | (103,742 | ) |  |  | (83,490 | ) |  |  | (69,266 | ) |  |  | (256,498 | ) |
| Ending Backlog - 9/30/22 |  | $ | 408,269 |  |  |  | 128,156 |  |  |  | 158,597 |  |  |  | 695,022 |  |

[0001104659-22-119898:8k_2_02:82]
| Backlog And Entered Orders - FY 2022 |  | Aerospace & Defense |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 10/1/21 |  | $ | 367,216 |  |  |  | 91,631 |  |  |  | 133,176 |  |  |  | 592,023 |  |
| Entered Orders |  |  | 392,466 |  |  |  | 314,892 |  |  |  | 253,143 |  |  |  | 960,501 |  |
| Sales |  |  | (351,413 | ) |  |  | (278,367 | ) |  |  | (227,722 | ) |  |  | (857,502 | ) |
| Ending Backlog - 9/30/22 |  | $ | 408,269 |  |  |  | 128,156 |  |  |  | 158,597 |  |  |  | 695,022 |  |

[0001104659-22-119898:8k_2_02:83]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-22-119898:8k_2_02:84]
Reconciliation of Non-GAAP Financial Measures (Unaudited)

[0001104659-22-119898:8k_2_02:85]
| EPS – Adjusted Basis Reconciliation – Q4 2022 |  |  |  |  |
| EPS – GAAP Basis – Q4 2022 |  | $ | 1.19 |  |
| Adjustments (defined below) |  |  | 0.02 |  |
| EPS – As Adjusted Basis – Q4 2022 |  | $ | 1.21 |  |
| Adjustments exclude $0.02 per share consisting of after-tax severance charges at VACCO and NRG and Corporate management transition costs. |  |  |  |  |
| The $0.02 of EPS adjustments per share consists of $0.6 million of pre-tax charges offset by $0.2 million of tax benefit for net impact of $0.4 million. |  |  |  |  |
| EPS – Adjusted Basis Reconciliation – FY 2022 |  |  |  |  |
| EPS – GAAP Basis – FY 2022 |  | $ | 3.16 |  |
| Adjustments (defined below) |  |  | 0.05 |  |
| EPS – As Adjusted Basis – FY 2022 |  | $ | 3.21 |  |
| Adjustments exclude $0.05 per share consisting of Altanova & Neco acquisition inventory step-up charges, severance charges at VACCO and NRG, Corporate acquisition costs and management transition costs. |  |  |  |  |
| The $0.05 of EPS adjustments per share consists of $1.7 million of pre-tax charges offset by $0.4 million of tax benefit for net impact of $1.3 million |  |  |  |  |
| EPS – Adjusted Basis Reconciliation – Q4 2021 |  |  |  |  |
| EPS GAAP Basis – Q4 2021 |  | $ | 0.78 |  |
| Adjustments (defined below) |  |  | 0.07 |  |
| EPS – As Adjusted Basis – Q4 2021 |  | $ | 0.85 |  |
| Adjustments exclude $0.07 per share consisting of purchase accounting adjustments, acquisition costs at Corporate, and restructuring costs primarily within the USG segment. |  |  |  |  |
| The $0.07 of EPS adjustments per share consists of $2.3 million of pre-tax charges offset by $0.5 million of tax benefit for net impact of $1.8 million. |  |  |  |  |
| EPS – Adjusted Basis Reconciliation – FY 2021 |  |  |  |  |
| EPS – GAAP Basis – FY 2021 |  | $ | 2.42 |  |
| Adjustments (defined below) |  |  | 0.17 |  |
| EPS – As Adjusted Basis – FY 2021 |  | $ | 2.59 |  |
| Adjustments exclude $0.17 per share consisting of management transition and acquisition costs, restructuring costs primarily within the USG segment, and purchase accounting adjustments partially offset by the settlement from sale of Doble Watertown facility. |  |  |  |  |
| The $0.17 of EPS adjustments per share consists of $6.0 million of pre-tax charges offset by $1.4 million of tax benefit for net impact of $4.6 million. |  |  |  |  |
