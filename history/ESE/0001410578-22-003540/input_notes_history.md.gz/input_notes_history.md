# ESE note change history — 0001410578-22-001243 → 0001410578-22-002168


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-08-09):
[0001410578-22-002168:note_history:1]
The accompanying consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for consolidated annual financial statements by accounting principles generally accepted in the United States of America (GAAP).
  (was, 2022-05-10, similarity 0.9874):
[0001410578-22-001243:note_history:1]
The accompanying consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP).

- changed (2022-08-09):
[0001410578-22-002168:note_history:2]
The Company’s results for the three-month and nine-month periods ended June 30, 2022 are not necessarily indicative of the results for the entire 2022 fiscal year. References to the third quarters of 2022 and 2021 represent the fiscal quarters ended June 30, 2022 and 2021, respectively. The preparation of consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates. Certain prior period deferred revenue amounts have been reclassified to noncurrent to conform with the current year presentation.
  (was, 2022-05-10, similarity 0.9341):
[0001410578-22-001243:note_history:2]
The Company’s results for the three-month period ended March 31, 2022 are not necessarily indicative of the results for the entire 2022 fiscal year. References to the second quarters of 2022 and 2021 represent the fiscal quarters ended March 31, 2022 and 2021, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates. Certain prior period deferred revenue amounts have been reclassified to noncurrent to conform with the current year presentation.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-09):
[0001410578-22-002168:note_history:3]
| ​ |  | June 30, | ​ | September 30, |
| (In thousands) |  | 2022 |  | 2021 |
| Total borrowings | ​ | $ | 201,000 |  | 154,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 181,000 |  | 134,000 |
  (was, 2022-05-10, similarity 0.9802):
[0001410578-22-001243:note_history:3]
| ​ |  | March 31, | ​ | September 30, |
| (In thousands) |  | 2022 |  | 2021 |
| Total borrowings | ​ | $ | 196,000 |  | 154,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 176,000 |  | 134,000 |

- changed (2022-08-09):
[0001410578-22-002168:note_history:4]
At June 30, 2022, the Company had approximately $291.0 million available to borrow under the Credit Facility, plus the $250 million increase option, subject to lender approval, in addition to $61.0 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of June 30, 2022, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $7.8 million at June 30, 2022.
  (was, 2022-05-10, similarity 0.9696):
[0001410578-22-001243:note_history:4]
At March 31, 2022, the Company had approximately $296 million available to borrow under the Credit Facility, plus the $250 million increase option, subject to lender approval, in addition to $54.3 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of March 31, 2022, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $8.1 million at March 31, 2022.

- changed (2022-08-09):
[0001410578-22-002168:note_history:5]
Interest on borrowings under the Credit Facility is calculated at a spread over either the New York Federal Reserve Bank Rate, the prime rate or the London Interbank Offered Rate (LIBOR), depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The Credit Facility is secured by the unlimited guaranty of the Company’s direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of its direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 2.20% and 1.57% for the three and nine-month periods ending June 30, 2022, respectively, and 1.16% and 1.33% for the three and nine-month periods ending June 30, 2021. As of June 30, 2022, the Company was in compliance with all covenants.
  (was, 2022-05-10, similarity 0.9654):
[0001410578-22-001243:note_history:5]
Interest on borrowings under the Credit Facility is calculated at a spread over either the New York Federal Reserve Bank Rate, the prime rate or the London Interbank Offered Rate (LIBOR), depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The Credit Facility is secured by the unlimited guaranty of the Company’s direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of its direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 1.29% and 1.23% for the three and six-month periods ending March 31, 2022, respectively, and 1.27% and 1.40% for the three and six-month periods ending March 31, 2021. As of March 31, 2022, the Company was in compliance with all covenants.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-09):
[0001410578-22-002168:note_history:6]
| ​ |  | June 30, | ​ | September 30, |
| (In thousands) |  | 2022 |  | 2021 |
| Total borrowings | ​ | $ | 201,000 |  | 154,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 181,000 |  | 134,000 |
  (was, 2022-05-10, similarity 0.9802):
[0001410578-22-001243:note_history:6]
| ​ |  | March 31, | ​ | September 30, |
| (In thousands) |  | 2022 |  | 2021 |
| Total borrowings | ​ | $ | 196,000 |  | 154,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 176,000 |  | 134,000 |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-08-09):
[0001410578-22-002168:note_history:7]
| Three Months Ended June 30, 2022 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 38,918 | ​ | $ | 65,610 | ​ | $ | 54,449 | ​ | $ | 158,977 |
| U.S. Government | ​ |  | 53,688 | ​ |  | 1,591 | ​ |  | 4,810 | ​ |  | 60,089 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |
| ​ | ​ | ​ | ​ | ​ | ​ | 65 | ​ | ​ | ​ | ​ | ​ | ​ |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 79,536 | ​ | $ | 41,822 | ​ | $ | 34,662 | ​ | $ | 156,020 |
| International | ​ |  | 13,070 | ​ |  | 25,379 | ​ |  | 24,597 | ​ |  | 63,046 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 35,238 | ​ | $ | 53,656 | ​ | $ | 15,827 | ​ | $ | 104,721 |
| Over time | ​ |  | 57,368 | ​ |  | 13,545 | ​ |  | 43,432 | ​ |  | 114,345 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |
  (was, 2022-05-10, similarity 0.9519):
[0001410578-22-001243:note_history:7]
| Six months ended March 31, 2022 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 61,489 | ​ | $ | 126,221 | ​ | $ | 92,941 | ​ | $ | 280,651 |
| U.S. Government | ​ |  | 93,576 | ​ |  | 1,455 | ​ |  | 6,256 | ​ |  | 101,287 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 133,313 | ​ | $ | 80,199 | ​ | $ | 54,047 | ​ | $ | 267,559 |
| International | ​ |  | 21,752 | ​ |  | 47,477 | ​ |  | 45,150 | ​ |  | 114,379 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 64,223 | ​ | $ | 102,037 | ​ | $ | 27,660 | ​ | $ | 193,920 |
| Over time | ​ |  | 90,842 | ​ |  | 25,639 | ​ |  | 71,537 | ​ |  | 188,018 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |

- changed (2022-08-09):
[0001410578-22-002168:note_history:8]
| Nine months ended June 30, 2022 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 100,407 | ​ | $ | 191,832 | ​ | $ | 147,390 | ​ | $ | 439,629 |
| U.S. Government | ​ |  | 147,264 | ​ |  | 3,045 | ​ |  | 11,066 | ​ |  | 161,375 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 212,849 | ​ | $ | 122,021 | ​ | $ | 88,708 | ​ | $ | 423,578 |
| International | ​ |  | 34,822 | ​ |  | 72,856 | ​ |  | 69,748 | ​ |  | 177,426 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 99,464 | ​ | $ | 155,693 | ​ | $ | 43,488 | ​ | $ | 298,645 |
| Over time | ​ |  | 148,207 | ​ |  | 39,184 | ​ |  | 114,968 | ​ |  | 302,359 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |
  (was, 2022-05-10, similarity 0.7274):
[0001410578-22-001243:note_history:8]
| Three months ended March 31, 2022 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total |  |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 33,562 | ​ | $ | 63,379 | ​ | $ | 51,903 | ​ | $ | 148,844 | ​ |
| U.S. Government | ​ |  | 51,259 | ​ | ​ | 812 | ​ | ​ | 4,013 | ​ |  | 56,084 | ​ |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 | ​ |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| United States | ​ | $ | 72,621 | ​ | $ | 41,458 | ​ | $ | 31,071 | ​ | $ | 145,150 | ​ |
| International | ​ |  | 12,200 | ​ | ​ | 22,733 | ​ | ​ | 24,845 | ​ |  | 59,778 | ​ |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 35,666 | ​ | $ | 51,202 | ​ | $ | 14,838 | ​ | $ | 101,706 | ​ |
| Over time | ​ |  | 49,155 | ​ | ​ | 12,989 | ​ | ​ | 41,078 | ​ |  | 103,222 | ​ |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 | ​ |

- changed (2022-08-09):
[0001410578-22-002168:note_history:9]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2021 are presented in the tables below.
  (was, 2022-05-10, similarity 0.9576):
[0001410578-22-001243:note_history:9]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2021 are presented in the tables below.

- changed (2022-08-09):
[0001410578-22-002168:note_history:10]
| Three months ended June 30, 2021 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial |  | $ | 34,708 |  | $ | 46,735 |  | $ | 42,063 |  | $ | 123,506 |
| U.S. Government | ​ | ​ | 50,868 | ​ | ​ | 969 | ​ | ​ | 6,051 | ​ | ​ | 57,888 |
| Total revenues |  | $ | 85,576 |  | $ | 47,704 |  | $ | 48,114 |  | $ | 181,394 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States |  | $ | 75,701 |  | $ | 32,111 |  | $ | 27,719 |  | $ | 135,531 |
| International | ​ | ​ | 9,875 | ​ | ​ | 15,593 | ​ | ​ | 20,395 | ​ | ​ | 45,863 |
| Total revenues |  | $ | 85,576 |  | $ | 47,704 |  | $ | 48,114 |  | $ | 181,394 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time |  | $ | 37,513 |  | $ | 35,242 |  | $ | 9,673 |  | $ | 82,428 |
| Over time | ​ | ​ | 48,063 | ​ | ​ | 12,462 | ​ | ​ | 38,441 | ​ | ​ | 98,966 |
| Total revenues |  | $ | 85,576 |  | $ | 47,704 |  | $ | 48,114 |  | $ | 181,394 |
  (was, 2022-05-10, similarity 0.9949):
[0001410578-22-001243:note_history:10]
| Three months ended March 31, 2021 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial |  | $ | 33,223 |  | $ | 38,549 |  | $ | 39,305 |  | $ | 111,077 |
| U.S. Government | ​ | ​ | 49,305 | ​ | ​ | 1,006 | ​ | ​ | 4,506 | ​ | ​ | 54,817 |
| Total revenues |  | $ | 82,528 |  | $ | 39,555 |  | $ | 43,811 |  | $ | 165,894 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States |  | $ | 72,287 |  | $ | 27,445 |  | $ | 22,965 |  | $ | 122,697 |
| International | ​ | ​ | 10,241 | ​ | ​ | 12,110 | ​ | ​ | 20,846 | ​ | ​ | 43,197 |
| Total revenues |  | $ | 82,528 |  | $ | 39,555 |  | $ | 43,811 |  | $ | 165,894 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time |  | $ | 37,127 |  | $ | 27,563 |  | $ | 9,248 |  | $ | 73,938 |
| Over time | ​ | ​ | 45,401 | ​ | ​ | 11,992 | ​ | ​ | 34,563 | ​ | ​ | 91,956 |
| Total revenues |  | $ | 82,528 |  | $ | 39,555 |  | $ | 43,811 |  | $ | 165,894 |

- changed (2022-08-09):
[0001410578-22-002168:note_history:11]
| Nine months ended June 30, 2021 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial |  | $ | 95,712 |  | $ | 139,149 |  | $ | 118,089 |  | $ | 352,950 |
| U.S. Government | ​ | ​ | 139,008 | ​ | ​ | 2,650 | ​ | ​ | 15,354 | ​ | ​ | 157,012 |
| Total revenues |  | $ | 234,720 |  | $ | 141,799 |  | $ | 133,443 |  | $ | 509,962 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States |  | $ | 205,527 |  | $ | 96,601 |  | $ | 73,950 |  | $ | 376,078 |
| International | ​ | ​ | 29,193 | ​ | ​ | 45,198 | ​ | ​ | 59,493 | ​ | ​ | 133,884 |
| Total revenues |  | $ | 234,720 |  | $ | 141,799 |  | $ | 133,443 |  | $ | 509,962 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time |  | $ | 103,492 |  | $ | 105,173 |  | $ | 27,789 |  | $ | 236,454 |
| Over time | ​ | ​ | 131,228 | ​ | ​ | 36,626 | ​ | ​ | 105,654 | ​ | ​ | 273,508 |
| Total revenues |  | $ | 234,720 |  | $ | 141,799 |  | $ | 133,443 |  | $ | 509,962 |
  (was, 2022-05-10, similarity 0.9912):
[0001410578-22-001243:note_history:11]
| Six months ended March 31, 2021 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial |  | $ | 61,089 |  | $ | 92,414 |  | $ | 76,027 |  | $ | 229,530 |
| U.S. Government | ​ | ​ | 88,055 | ​ | ​ | 1,681 | ​ | ​ | 9,302 | ​ | ​ | 99,038 |
| Total revenues |  | $ | 149,144 |  | $ | 94,095 |  | $ | 85,329 |  | $ | 328,568 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States |  | $ | 129,824 |  | $ | 64,490 |  | $ | 46,231 |  | $ | 240,545 |
| International | ​ | ​ | 19,320 | ​ | ​ | 29,605 | ​ | ​ | 39,098 | ​ | ​ | 88,023 |
| Total revenues |  | $ | 149,144 |  | $ | 94,095 |  | $ | 85,329 |  | $ | 328,568 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time |  | $ | 64,000 |  | $ | 69,931 |  | $ | 18,116 |  | $ | 152,047 |
| Over time | ​ | ​ | 85,144 | ​ | ​ | 24,164 | ​ | ​ | 67,213 | ​ | ​ | 176,521 |
| Total revenues |  | $ | 149,144 |  | $ | 94,095 |  | $ | 85,329 |  | $ | 328,568 |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-08-09):
[0001410578-22-002168:note_history:12]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2022 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue within each reportable segment.
  (was, 2022-05-10, similarity 0.9809):
[0001410578-22-001243:note_history:12]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2022 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue within each reportable segment.

- changed (2022-08-09):
[0001410578-22-002168:note_history:13]
| Three Months Ended June 30, 2022 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 38,918 | ​ | $ | 65,610 | ​ | $ | 54,449 | ​ | $ | 158,977 |
| U.S. Government | ​ |  | 53,688 | ​ |  | 1,591 | ​ |  | 4,810 | ​ |  | 60,089 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |
| ​ | ​ | ​ | ​ | ​ | ​ | 65 | ​ | ​ | ​ | ​ | ​ | ​ |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 79,536 | ​ | $ | 41,822 | ​ | $ | 34,662 | ​ | $ | 156,020 |
| International | ​ |  | 13,070 | ​ |  | 25,379 | ​ |  | 24,597 | ​ |  | 63,046 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 35,238 | ​ | $ | 53,656 | ​ | $ | 15,827 | ​ | $ | 104,721 |
| Over time | ​ |  | 57,368 | ​ |  | 13,545 | ​ |  | 43,432 | ​ |  | 114,345 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |
  (was, 2022-05-10, similarity 0.9519):
[0001410578-22-001243:note_history:13]
| Six months ended March 31, 2022 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 61,489 | ​ | $ | 126,221 | ​ | $ | 92,941 | ​ | $ | 280,651 |
| U.S. Government | ​ |  | 93,576 | ​ |  | 1,455 | ​ |  | 6,256 | ​ |  | 101,287 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 133,313 | ​ | $ | 80,199 | ​ | $ | 54,047 | ​ | $ | 267,559 |
| International | ​ |  | 21,752 | ​ |  | 47,477 | ​ |  | 45,150 | ​ |  | 114,379 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 64,223 | ​ | $ | 102,037 | ​ | $ | 27,660 | ​ | $ | 193,920 |
| Over time | ​ |  | 90,842 | ​ |  | 25,639 | ​ |  | 71,537 | ​ |  | 188,018 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |

- changed (2022-08-09):
[0001410578-22-002168:note_history:14]
| Nine months ended June 30, 2022 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 100,407 | ​ | $ | 191,832 | ​ | $ | 147,390 | ​ | $ | 439,629 |
| U.S. Government | ​ |  | 147,264 | ​ |  | 3,045 | ​ |  | 11,066 | ​ |  | 161,375 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 212,849 | ​ | $ | 122,021 | ​ | $ | 88,708 | ​ | $ | 423,578 |
| International | ​ |  | 34,822 | ​ |  | 72,856 | ​ |  | 69,748 | ​ |  | 177,426 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 99,464 | ​ | $ | 155,693 | ​ | $ | 43,488 | ​ | $ | 298,645 |
| Over time | ​ |  | 148,207 | ​ |  | 39,184 | ​ |  | 114,968 | ​ |  | 302,359 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |
  (was, 2022-05-10, similarity 0.7274):
[0001410578-22-001243:note_history:14]
| Three months ended March 31, 2022 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total |  |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 33,562 | ​ | $ | 63,379 | ​ | $ | 51,903 | ​ | $ | 148,844 | ​ |
| U.S. Government | ​ |  | 51,259 | ​ | ​ | 812 | ​ | ​ | 4,013 | ​ |  | 56,084 | ​ |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 | ​ |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| United States | ​ | $ | 72,621 | ​ | $ | 41,458 | ​ | $ | 31,071 | ​ | $ | 145,150 | ​ |
| International | ​ |  | 12,200 | ​ | ​ | 22,733 | ​ | ​ | 24,845 | ​ |  | 59,778 | ​ |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 35,666 | ​ | $ | 51,202 | ​ | $ | 14,838 | ​ | $ | 101,706 | ​ |
| Over time | ​ |  | 49,155 | ​ | ​ | 12,989 | ​ | ​ | 41,078 | ​ |  | 103,222 | ​ |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 | ​ |

- changed (2022-08-09):
[0001410578-22-002168:note_history:15]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2021 are presented in the tables below.
  (was, 2022-05-10, similarity 0.9576):
[0001410578-22-001243:note_history:15]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2021 are presented in the tables below.

- changed (2022-08-09):
[0001410578-22-002168:note_history:16]
| Three months ended June 30, 2021 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial |  | $ | 34,708 |  | $ | 46,735 |  | $ | 42,063 |  | $ | 123,506 |
| U.S. Government | ​ | ​ | 50,868 | ​ | ​ | 969 | ​ | ​ | 6,051 | ​ | ​ | 57,888 |
| Total revenues |  | $ | 85,576 |  | $ | 47,704 |  | $ | 48,114 |  | $ | 181,394 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States |  | $ | 75,701 |  | $ | 32,111 |  | $ | 27,719 |  | $ | 135,531 |
| International | ​ | ​ | 9,875 | ​ | ​ | 15,593 | ​ | ​ | 20,395 | ​ | ​ | 45,863 |
| Total revenues |  | $ | 85,576 |  | $ | 47,704 |  | $ | 48,114 |  | $ | 181,394 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time |  | $ | 37,513 |  | $ | 35,242 |  | $ | 9,673 |  | $ | 82,428 |
| Over time | ​ | ​ | 48,063 | ​ | ​ | 12,462 | ​ | ​ | 38,441 | ​ | ​ | 98,966 |
| Total revenues |  | $ | 85,576 |  | $ | 47,704 |  | $ | 48,114 |  | $ | 181,394 |
  (was, 2022-05-10, similarity 0.9949):
[0001410578-22-001243:note_history:16]
| Three months ended March 31, 2021 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial |  | $ | 33,223 |  | $ | 38,549 |  | $ | 39,305 |  | $ | 111,077 |
| U.S. Government | ​ | ​ | 49,305 | ​ | ​ | 1,006 | ​ | ​ | 4,506 | ​ | ​ | 54,817 |
| Total revenues |  | $ | 82,528 |  | $ | 39,555 |  | $ | 43,811 |  | $ | 165,894 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States |  | $ | 72,287 |  | $ | 27,445 |  | $ | 22,965 |  | $ | 122,697 |
| International | ​ | ​ | 10,241 | ​ | ​ | 12,110 | ​ | ​ | 20,846 | ​ | ​ | 43,197 |
| Total revenues |  | $ | 82,528 |  | $ | 39,555 |  | $ | 43,811 |  | $ | 165,894 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time |  | $ | 37,127 |  | $ | 27,563 |  | $ | 9,248 |  | $ | 73,938 |
| Over time | ​ | ​ | 45,401 | ​ | ​ | 11,992 | ​ | ​ | 34,563 | ​ | ​ | 91,956 |
| Total revenues |  | $ | 82,528 |  | $ | 39,555 |  | $ | 43,811 |  | $ | 165,894 |

- changed (2022-08-09):
[0001410578-22-002168:note_history:17]
| Nine months ended June 30, 2021 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial |  | $ | 95,712 |  | $ | 139,149 |  | $ | 118,089 |  | $ | 352,950 |
| U.S. Government | ​ | ​ | 139,008 | ​ | ​ | 2,650 | ​ | ​ | 15,354 | ​ | ​ | 157,012 |
| Total revenues |  | $ | 234,720 |  | $ | 141,799 |  | $ | 133,443 |  | $ | 509,962 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States |  | $ | 205,527 |  | $ | 96,601 |  | $ | 73,950 |  | $ | 376,078 |
| International | ​ | ​ | 29,193 | ​ | ​ | 45,198 | ​ | ​ | 59,493 | ​ | ​ | 133,884 |
| Total revenues |  | $ | 234,720 |  | $ | 141,799 |  | $ | 133,443 |  | $ | 509,962 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time |  | $ | 103,492 |  | $ | 105,173 |  | $ | 27,789 |  | $ | 236,454 |
| Over time | ​ | ​ | 131,228 | ​ | ​ | 36,626 | ​ | ​ | 105,654 | ​ | ​ | 273,508 |
| Total revenues |  | $ | 234,720 |  | $ | 141,799 |  | $ | 133,443 |  | $ | 509,962 |
  (was, 2022-05-10, similarity 0.9912):
[0001410578-22-001243:note_history:17]
| Six months ended March 31, 2021 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial |  | $ | 61,089 |  | $ | 92,414 |  | $ | 76,027 |  | $ | 229,530 |
| U.S. Government | ​ | ​ | 88,055 | ​ | ​ | 1,681 | ​ | ​ | 9,302 | ​ | ​ | 99,038 |
| Total revenues |  | $ | 149,144 |  | $ | 94,095 |  | $ | 85,329 |  | $ | 328,568 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States |  | $ | 129,824 |  | $ | 64,490 |  | $ | 46,231 |  | $ | 240,545 |
| International | ​ | ​ | 19,320 | ​ | ​ | 29,605 | ​ | ​ | 39,098 | ​ | ​ | 88,023 |
| Total revenues |  | $ | 149,144 |  | $ | 94,095 |  | $ | 85,329 |  | $ | 328,568 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time |  | $ | 64,000 |  | $ | 69,931 |  | $ | 18,116 |  | $ | 152,047 |
| Over time | ​ | ​ | 85,144 | ​ | ​ | 24,164 | ​ | ​ | 67,213 | ​ | ​ | 176,521 |
| Total revenues |  | $ | 149,144 |  | $ | 94,095 |  | $ | 85,329 |  | $ | 328,568 |

- changed (2022-08-09):
[0001410578-22-002168:note_history:18]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At June 30, 2022, the Company had $706.8 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 80% in the next twelve months.
  (was, 2022-05-10, similarity 0.9935):
[0001410578-22-001243:note_history:18]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At March 31, 2022, the Company had $670.9 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 77% in the next twelve months.

- added (2022-08-09):
[0001410578-22-002168:note_history:19]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred. At June 30, 2022, contract assets and liabilities totaled $115.8 million and $122.2 million, respectively. During the first nine months of 2022, the Company recognized approximately $74 million in revenues that were included in the contract liabilities balance at September 30, 2021. The increase in net contract assets in the first nine months of 2022 was due to revenue being recognized for performance completed during the period that exceeded customer billings. The increase in net contract liabilities in the first nine months of 2022 was due to higher payments received in advance of revenue recognition criteria being met under the Company’s contracts with customers. At October 1, 2020, contract assets and liabilities totaled $94.3 million and $100.6 million, respectively.

- removed (2022-08-09):
[0001410578-22-001243:note_history:20]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred. At March 31, 2022, contract assets and liabilities totaled

- removed (2022-08-09):
[0001410578-22-001243:note_history:21]
$111.5 million and $113.0 million, respectively. During the first six months of 2022, the Company recognized approximately $51 million in revenues that were included in the contract liabilities balance at September 30, 2021. The increase in net contract assets in the first six months of 2022 was due to revenue being recognized for performance completed during the period that exceeded customer billings. Other factors that impacted the change in net contract liabilities were immaterial. At October 1, 2020, contract assets and liabilities totaled $94.3 million and $100.6 million, respectively.
