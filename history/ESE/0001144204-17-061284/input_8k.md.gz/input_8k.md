# ESE 8-K — 0000866706-17-000014 filed 2017-11-14

## item codes, every 8-K on or before 2017-11-29

- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2017-11-29

- none on or before 2017-11-29

## item 2.02 — earnings release, exhibit 99.1

[0000866706-17-000014:8k_2_02:1]
EX-99.1
5
earningsrelease.htm

[0000866706-17-000014:8k_2_02:2]
Exhibit 99.1

[0000866706-17-000014:8k_2_02:3]
NEWS FROM

[0000866706-17-000014:8k_2_02:4]
For more information contact:

[0000866706-17-000014:8k_2_02:5]
Kate Lowrey

[0000866706-17-000014:8k_2_02:6]
Director, Investor Relations

[0000866706-17-000014:8k_2_02:7]
ESCO Technologies Inc.

[0000866706-17-000014:8k_2_02:8]
(314) 213-7277

[0000866706-17-000014:8k_2_02:9]
ESCO ANNOUNCES FISCAL 2017 RESULTS

[0000866706-17-000014:8k_2_02:10]
- Net earnings of $54 million and Adjusted EBITDA of $123 million -

[0000866706-17-000014:8k_2_02:11]
-  GAAP EPS $2.07 and Adjusted EPS $2.22 -

[0000866706-17-000014:8k_2_02:12]
ST. LOUIS, November 14, 2017 – ESCO Technologies Inc. (NYSE: ESE) (ESCO, or the Company) today reported its operating results for the fourth quarter (Q4 2017) and fiscal year ended September 30, 2017 (2017), compared to the fourth quarter (Q4 2016) and fiscal year ended September 30, 2016 (2016).

[0000866706-17-000014:8k_2_02:13]
The Company previously announced it acquired Mayday Manufacturing Co. and its affiliate, Hi-Tech Metals, Inc. (collectively Mayday) on November 7, 2016, NRG Systems Inc. (NRG) on May 8, 2017, the assets of Morgan Schaffer Inc. (Morgan Schaffer) on May 25, 2017, and the assets of Vanguard Instruments Company (Vanguard) on August 30, 2017. Net sales, earnings, acquisition costs, non-cash purchase accounting inventory step-up charges, and amortization of intangible assets related to these entities are included in the 2017 operating results from the date of acquisition.

[0000866706-17-000014:8k_2_02:14]
The financial results presented include certain non-GAAP financial measures such as EBIT, EBITDA (defined as earnings before interest, taxes, depreciation and amortization), Adjusted EBITDA (defined as EBITDA excluding certain charges, such as non-cash purchase accounting inventory step up charges, and acquisition costs incurred to complete the transactions), and Adjusted EPS. Any non-GAAP financial measures presented are reconciled to their respective GAAP equivalents.

[0000866706-17-000014:8k_2_02:15]
Management believes these non-GAAP financial measures are useful in assessing the ongoing operational profitability of the Company's business segments, and therefore, allows shareholders better visibility into the Company's underlying operations. See "Non-GAAP Financial Measures" described below.

[0000866706-17-000014:8k_2_02:16]
Earnings Summary – Full Year

[0000866706-17-000014:8k_2_02:17]
| · | 2017 GAAP EPS was $2.07 per share and Adjusted EPS was $2.22 per share, which excludes the ($0.15) per share impact ($6.1 million pretax) of non-cash purchase accounting inventory step-up charges and costs incurred to complete the 2017 acquisitions; |

[0000866706-17-000014:8k_2_02:18]
| · | 2016 GAAP EPS was $1.77 per share and Adjusted EPS was $2.03 per share (the adjustments related to the prior year restructuring charges were described in earlier releases); |

[0000866706-17-000014:8k_2_02:19]
| · | 2017 GAAP net earnings were $54 million compared to $46 million in 2016; and, |

[0000866706-17-000014:8k_2_02:20]
| · | Adjusted EBITDA increased 22 percent to $123 million in 2017 from $101 million in 2016. |

[0000866706-17-000014:8k_2_02:21]
Earnings Summary – Q4

[0000866706-17-000014:8k_2_02:22]
| · | Q4 2017 GAAP EPS was $0.74 per share and Adjusted EPS was $0.79 per share, which excludes ($0.05) per share impact ($1.8 million pretax) of non-cash purchase accounting inventory step-up charges and costs incurred to complete the 2017 acquisitions; |

[0000866706-17-000014:8k_2_02:23]
| · | Q4 2016 GAAP EPS was $0.65 per share and Adjusted EPS was $0.67 per share (the adjustments related to prior year Q4 restructuring charges were described in earlier releases); |

[0000866706-17-000014:8k_2_02:24]
| · | Q4 2017 GAAP net earnings were $19 million compared to $17 million in Q4 2016; and, |

[0000866706-17-000014:8k_2_02:25]
| · | Adjusted EBITDA increased 34 percent to $43 million in Q4 2017 from $32 million in Q4 2016. |

[0000866706-17-000014:8k_2_02:26]
Adjusted EBITDA is reconciled to GAAP net earnings in the Condensed Business Segment Information table below for all periods presented.

[0000866706-17-000014:8k_2_02:27]
Operating Highlights - 2017

[0000866706-17-000014:8k_2_02:28]
| · | 2017 sales increased $115 million (20 percent) to $686 million compared to $571 million in 2016; |

[0000866706-17-000014:8k_2_02:29]
| · | On a segment basis, 2017 Filtration sales increased $72 million, or 35 percent compared to 2016 primarily driven by the contribution of Westland and Mayday sales of $61 million. Technical Packaging sales increased $8 million, or 11 percent compared to 2016 driven by Plastique, and Test sales were $161 million in both periods presented. USG sales increased $35 million, or 27 percent, as Doble sales increased $11 million (9 percent) driven by the additional sales contribution from new products and software solutions, and NRG / Morgan Schaffer / Vanguard contributed $24 million in sales since the dates of acquisition; |

[0000866706-17-000014:8k_2_02:30]
| · | SG&A expenses increased $17 million in 2017 compared to 2016 primarily due to additional expenses related to Westland, Mayday, NRG, Morgan Schaffer and Vanguard in the current period, coupled with additional sales and marketing expenses at Doble to support future revenue growth. Acquisition costs are recorded at Corporate; |

[0000866706-17-000014:8k_2_02:31]
| · | Entered orders were $737 million in 2017 (book-to-bill of 1.07x) reflecting a $51 million (16 percent) increase in backlog during the year and an ending backlog of $377 million at September 30, 2017; |

[0000866706-17-000014:8k_2_02:32]
| · | Filtration orders were $286 million (book-to-bill of 1.03x) in 2017 comprised of recurring commercial aerospace orders and additional space and navy products; |

[0000866706-17-000014:8k_2_02:33]
| · | Test orders were a record $199 million in 2017 (book-to-bill of 1.23x) which reflects increasing momentum in the wireless, electric vehicle, and automotive chamber markets; |

[0000866706-17-000014:8k_2_02:34]
| · | USG orders were $164 million in 2017 (book-to-bill of 1.01x) which reflects increased orders for new products such as the Doble Universal Controller (DUC), on-line monitoring solutions, dissolved gas analyzers (DGA's) and additional software applications; |

[0000866706-17-000014:8k_2_02:35]
| · | Technical Packaging orders were $87 million in 2017 (book-to-bill of 1.05x) driven by higher KAZ, medical, medical device, and pharmaceutical projects; and, |

[0000866706-17-000014:8k_2_02:36]
| · | Net cash provided by operating activities was $67 million in 2017 which resulted in net debt of $229 million (outstanding borrowings less cash on hand) at September 30, 2017 and a 2.2x leverage ratio (gross debt outstanding / Adjusted EBITDA). |

[0000866706-17-000014:8k_2_02:37]
Chairman's Commentary – 2017

[0000866706-17-000014:8k_2_02:38]
Vic Richey, Chairman and Chief Executive Officer, commented, "I'm pleased with the way we wrapped up the year as we delivered EPS and Adjusted EBITDA within our previously expected ranges, and we successfully completed several acquisitions, which remains one of our key strategic goals. I've mentioned this before, but it is worth repeating: Not only did we add great companies to our portfolio, we also added very solid management teams who share our vision and our values.

[0000866706-17-000014:8k_2_02:39]
"Regarding the recent acquisitions, I'm pleased to see the integration is going smoothly and is nearly complete, which supports my enthusiasm for USG's outlook as the group has come together with a unified focus on sales growth, market expansion, new product development, and enhanced operating margins.

[0000866706-17-000014:8k_2_02:40]
"Whenever you add new companies to an existing portfolio, it is never without risk. But I'm thrilled with the way our entire company, legacy entities and new partners, came together and collectively delivered $123 million of Adjusted EBITDA in 2017. This reflects a 22 percent increase over prior year and represents the best year in ESCO's history.

[0000866706-17-000014:8k_2_02:41]
"Touching on a few Q4 operating highlights, Filtration delivered a 22 percent EBIT margin driven by outstanding performance at Crissair and VACCO. Test reported a 16 percent EBIT margin in Q4 and during the past six months of 2017, delivered $89 million in sales at a 15 percent EBIT margin. Doble continued to outperform in Q4 by delivering an EBIT margin above 28 percent as its new products, software and solution offerings continue to gain traction in the utility market.

[0000866706-17-000014:8k_2_02:42]
"Wrapping up the year, a clear highlight for the Company is the strength of our order activity as all four operating segments achieved book-to-bill ratios greater 1.0x, led by Test's nearly $200 million in new business.

[0000866706-17-000014:8k_2_02:43]
"As we enter 2018, we plan to build on the successes we achieved in 2017 and benefit from having aggressively addressed the challenges we faced during the past year, which gives me a favorable view of the future with our goal remaining unchanged – to increase long-term shareholder value."

[0000866706-17-000014:8k_2_02:44]
Dividend Payment

[0000866706-17-000014:8k_2_02:45]
The next quarterly cash dividend of $0.08 per share will be paid on January 19, 2018 to stockholders of record on January 4, 2018.

[0000866706-17-000014:8k_2_02:46]
Board of Directors

[0000866706-17-000014:8k_2_02:47]
Effective November 8, 2017, the Company added an additional independent director, Patrick M. (Pat) Dewar to the Company's Board of Directors.

[0000866706-17-000014:8k_2_02:48]
Mr. Dewar currently serves as Chief Executive  of The Trenton Group LLC. Previously, Mr. Dewar spent 34 years in the Aerospace Sector with GE Aerospace and Lockheed Martin, where he created and led Lockheed Martin International as an Executive Vice President managing over $10 billion in annual revenue. He holds a Master of Science degree in Electrical Engineering from Drexel University as well as a Bachelor of Science degree in Engineering from Swarthmore College. Mr. Dewar is a member of the Council of Foreign Relations and serves as a senior advisor to numerous investment firms on Aerospace & Defense matters.

[0000866706-17-000014:8k_2_02:49]
Mr. Dewar was selected to serve the Company as his extensive strategic and operational experience in the aerospace and defense markets will allow him to assist the board in guiding strategy from the highest level.

[0000866706-17-000014:8k_2_02:50]
Adding a new director further enhances Corporate Governance, facilitates board refreshment, and adds new and relevant experience supplementing existing independent director oversight. The Board of Directors performed extensive diligence in its search, including utilizing a globally recognized executive search firm.

[0000866706-17-000014:8k_2_02:51]
Business Outlook – 2018

[0000866706-17-000014:8k_2_02:52]
With the increased level of M&A activity, Management has placed more emphasis on Adjusted EBITDA as a supplement to EPS as it believes this is a relevant metric to be considered for measuring ongoing operating performance as well as the Company's enterprise valuation. Adjusted EBITDA is also a key financial metric used by Management when determining the appropriate price for acquisitions.

[0000866706-17-000014:8k_2_02:53]
Management continues to see meaningful sales and Adjusted EBITDA growth across each of the Company's business segments and anticipates growth rates in 2018 and beyond that exceed the Company's defined peer group and the broader industrial market.

[0000866706-17-000014:8k_2_02:54]
The details of Management's growth expectations for 2018 compared to 2017 are as follows:

[0000866706-17-000014:8k_2_02:55]
| · | Sales are expected to increase approximately 13 percent driven by: incremental sales from acquisitions being included for a full year; increased commercial aerospace deliveries at PTI, Crissair and Mayday; higher organic sales at USG; significantly higher sales at Test including the catch-up of 2017 deliveries as well as significant new product wins currently in backlog; partially offset by a reduction in lower margin industrial/automotive market product deliveries at PTI as it exits that market; and flat sales in Technical Packaging; |

[0000866706-17-000014:8k_2_02:56]
| · | Adjusted EBITDA is expected to increase between 15 and 17 percent, resulting in Adjusted EBITDA in the range of $141 million to $143 million, compared to 2017 Adjusted EBITDA of $123 million; |

[0000866706-17-000014:8k_2_02:57]
| · | Interest expense on higher debt (acquisition funding) is expected to be approximately $9.5 million, reflecting an increase of $4.9 million (or $0.12 per share) over the $4.6 million of interest expense in 2017; |

[0000866706-17-000014:8k_2_02:58]
| · | Non-cash depreciation and amortization of intangibles is expected to increase approximately $7.1 million (or $0.18 per share after-tax) as a result of the recent acquisitions. Purchase accounting intangible asset amortization charges are recorded at Corporate; |

[0000866706-17-000014:8k_2_02:59]
| · | Income tax expense is expected to increase in 2018 as Management is projecting a 35 percent effective tax rate calculated on higher pretax earnings. Management's expected rate excludes any impact resulting from potential tax reform. When compared to the 33 percent tax rate in 2017, the 2 percent higher rate on the additional pretax earnings negatively impacts 2018 EPS ($0.07 per share); and, |

[0000866706-17-000014:8k_2_02:60]
| · | In summary, Management projects 2018 GAAP EPS to be in the range of $2.30 to $2.40 per share, including the profit contributions from the recent acquisitions, the additional depreciation and amortization charges, higher interest, and incremental tax expense as described above. |

[0000866706-17-000014:8k_2_02:61]
On a quarterly basis, Management expects 2018 operating results to reflect a profile similar to 2017 and previous years, with revenues and EPS being more second-half weighted. As with past years, projected second half 2018 sales and EPS are expected to be significantly stronger than the first half.

[0000866706-17-000014:8k_2_02:62]
Management expects Q1 2018 GAAP EPS to be in the range of $0.28 to $0.33 per share. The timing of quarterly sales and earnings throughout the year, coupled with higher non-cash charges within the respective quarters impacts comparability in Q1.

[0000866706-17-000014:8k_2_02:63]
Chairman's Commentary – 2018

[0000866706-17-000014:8k_2_02:64]
Mr. Richey continued, "Given the expected contribution from our recent acquisitions, coupled with current expectations of organic growth from "legacy" operations, I believe 2018 reflects solid sales, EBIT, EBITDA and EPS growth and positions us well to meet or exceed our shareholder value-creation goals.

[0000866706-17-000014:8k_2_02:65]
"We ended 2017 in a favorable position given our strong backlog and balance sheet, and as we enter the new year, I am very comfortable with our outlook. Our core businesses remain solid and the acquisitions are nearly fully integrated and are contributing at a meaningful level. We enter 2018 with numerous growth opportunities throughout our operating segments as described above.

[0000866706-17-000014:8k_2_02:66]
"I'm especially excited by our growth outlook in Test, where we've worked diligently for the past few years on right-sizing the cost structure and enhancing operating efficiency to allow it to be more competitive and significantly more profitable. Test's current backlog firmly supports our outlook, and I'm happy to report that we were recently notified of two new large chamber wins totaling $30 million from globally recognized customers in the government / defense and automotive markets.

[0000866706-17-000014:8k_2_02:67]
"Additionally, at Westland, we were recently awarded a large, multi-year contract to supply next-generation technology protecting naval vessels in support of our long-term outlook for this growing platform.

[0000866706-17-000014:8k_2_02:68]
"Our market leadership positions and the breadth and diversity of our new product offerings will allow us to continue to grow at levels above our peer averages. Our management teams' focus on profitable growth and ROIC will remain steadfast as we believe these are the key drivers of continued and sustainable share price appreciation."

[0000866706-17-000014:8k_2_02:69]
Conference Call

[0000866706-17-000014:8k_2_02:70]
The Company will host a conference call today, November 14, at 4:00 p.m. Central Time, to discuss the Company's 2017 results. A live audio webcast will be available on the Company's website at www.escotechnologies.com. Please access the website at least 15 minutes prior to the call to register, download and install any necessary audio software. A replay of the conference call will be available for seven days on the Company's website noted above or by phone (dial 1-855-859-2056 and enter the pass code 96067789).

[0000866706-17-000014:8k_2_02:71]
Forward-Looking Statements

[0000866706-17-000014:8k_2_02:72]
Statements in this press release regarding the Company's expected quarterly, 2018 full year and beyond results, revenue and sales growth, EPS, EPS growth, EBIT, EBITDA, Adjusted EBITDA, gross profit, interest expense, non-cash depreciation and amortization of intangibles, corporate costs, effective tax rates, the Company's ability to increase operating margins, realize financial goals and increase shareholder value, the success of acquisition efforts, the size, number and timing of future sales and growth opportunities, the long-term success of the Company, and any other statements which are not strictly historical are "forward-looking" statements within the meaning of the safe harbor provisions of the federal securities laws.

[0000866706-17-000014:8k_2_02:73]
Investors are cautioned that such statements are only predictions and speak only as of the date of this release, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company's actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company's operations and business environment including, but not limited to those described in Item 1A, "Risk Factors", of the Company's Annual Report on Form 10-K for the fiscal year ended September 30, 2016, and the following: the success of the Company's competitors; weakening of economic conditions in served markets; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties; delivery delays or defaults by customers; material changes in the costs and availability of certain raw materials; the appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer contracts; the timing and content of future contract awards or customer orders; performance issues with key customers, suppliers and subcontractors; labor disputes; the impacts of natural disasters on the Company's operations and those of the Company's customers and suppliers; changes in laws and regulations, including but not limited to changes in accounting standards and taxation requirements; changes in interest rates; costs relating to environmental matters arising from current or former facilities; financial exposure in connection with Company guarantees of certain Aclara contracts; the availability of select acquisitions; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the success and integration of recently acquired businesses.

[0000866706-17-000014:8k_2_02:74]
Non-GAAP Financial Measures

[0000866706-17-000014:8k_2_02:75]
The financial measures EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS are presented in this press release. The Company defines "EBIT" as earnings before interest and taxes, "EBITDA" as earnings before interest, taxes, depreciation and amortization, "Adjusted EBITDA" as EBITDA excluding certain defined non-recurring charges, and "Adjusted EPS" as GAAP earnings per share (EPS) excluding the non-recurring charges described above which were $0.05 per share for Q4 2017 and $0.02 per share for Q4 2016.

[0000866706-17-000014:8k_2_02:76]
EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management believes that EBIT, EBITDA and Adjusted EBDITDA are useful in assessing the operational profitability of the Company's business segments because they exclude interest, taxes, depreciation and amortization, which are generally accounted for across the entire Company on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company as well as incentive compensation. The Company believes that the presentation of EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS provides important supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance determined in accordance with GAAP.

[0000866706-17-000014:8k_2_02:77]
ESCO, headquartered in St. Louis: Manufactures highly-engineered filtration and fluid control products for the aviation, space and process markets worldwide; is the industry leader in RF shielding and EMC test products; provides diagnostic instruments, software and services for the benefit of industrial power users and the electric utility and renewable energy industries; and, produces custom thermoformed packaging, pulp-based packaging, and specialty products for medical and commercial markets. Further information regarding ESCO and its subsidiaries is available on the Company's website at www.escotechnologies.com.

[0000866706-17-000014:8k_2_02:78]
-  tables attached

[0000866706-17-000014:8k_2_02:79]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |  |  |  |
| Condensed Consolidated Statements of Operations (Unaudited) |  |  |  |  |
| (Dollars in thousands, except per share amounts) |  |  |  |  |
|  |  | Three Months Ended September 30, 2017 |  |  |  |  |  | Three Months Ended September 30, 2016 |  |  |  |  |
| Net Sales |  | $ | 207,005 |  |  |  |  |  |  | 159,505 |  |  |  |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 129,769 |  |  |  |  |  |  | 96,038 |  |  |  |  |
| Selling, general and administrative expenses |  |  | 41,329 |  |  |  |  |  |  | 34,304 |  |  |  |  |
| Amortization of intangible assets |  |  | 4,790 |  |  |  |  |  |  | 3,090 |  |  |  |  |
| Interest expense |  |  | 1,826 |  |  |  |  |  |  | 391 |  |  |  |  |
| Other (income) expenses, net |  |  | (496 | ) |  |  |  |  |  | 1,365 |  |  |  |  |
| Total costs and expenses |  |  | 177,218 |  |  |  |  |  |  | 135,188 |  |  |  |  |
| Earnings before income taxes |  |  | 29,787 |  |  |  |  |  |  | 24,317 |  |  |  |  |
| Income taxes |  |  | 10,613 |  |  |  |  |  |  | 7,402 |  |  |  |  |
| Net earnings |  | $ | 19,174 |  |  |  |  |  |  | 16,915 |  |  |  |  |
| Diluted EPS - GAAP |  | $ | 0.74 |  |  |  |  |  |  | 0.65 |  |  |  |  |
| Diluted EPS - As Adjusted |  | $ | 0.79 | (1) |  |  |  |  |  |  | 0.67 | (2) |  |  |  |  |
| Diluted average common shares O/S: |  |  | 26,057 |  |  |  |  |  |  |  | 25,935 |  |  |  |  |  |

[0000866706-17-000014:8k_2_02:80]
| (1) | Q4 2017 As Adjusted EPS excluded $1.8 million, pretax (or $0.05 per share) of purchase accounting inventory step up charges and acquisition costs during the fourth quarter of 2017. |  |
| (2) | Q4 2016 As Adjusted EPS excluded $0.8 million, pretax (or $0.02 per share) of restructuring charges incurred at ETS and Doble during the fourth quarter of 2016. |  |

[0000866706-17-000014:8k_2_02:81]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |  |  |  |
| Condensed Consolidated Statements of Operations (Unaudited) |  |  |  |  |
| (Dollars in thousands, except per share amounts) |  |  |  |  |
|  |  | Year Ended September 30, 2017 |  |  |  |  |  | Year Ended September 30, 2016 |  |  |  |  |
| Net Sales |  | $ | 685,740 |  |  |  |  |  |  | 571,459 |  |  |  |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 436,918 |  |  |  |  |  |  | 350,807 |  |  |  |  |
| Selling, general and administrative expenses |  |  | 148,433 |  |  |  |  |  |  | 131,493 |  |  |  |  |
| Amortization of intangible assets |  |  | 16,338 |  |  |  |  |  |  | 11,630 |  |  |  |  |
| Interest expense |  |  | 4,578 |  |  |  |  |  |  | 1,308 |  |  |  |  |
| Other (income) expenses, net |  |  | (680 | ) |  |  |  |  |  | 7,801 |  |  |  |  |
| Total costs and expenses |  |  | 605,587 |  |  |  |  |  |  | 503,039 |  |  |  |  |
| Earnings before income taxes |  |  | 80,153 |  |  |  |  |  |  | 68,420 |  |  |  |  |
| Income taxes |  |  | 26,450 |  |  |  |  |  |  | 22,538 |  |  |  |  |
| Net earnings |  | $ | 53,703 |  |  |  |  |  |  | 45,882 |  |  |  |  |
| Diluted EPS - GAAP |  | $ | 2.07 |  |  |  |  |  |  | 1.77 |  |  |  |  |
| Diluted EPS - As Adjusted |  | $ | 2.22 | (1) |  |  |  |  |  |  | 2.03 | (2) |  |  |  |  |
| Diluted average common shares O/S: |  |  | 25,995 |  |  |  |  |  |  |  | 25,968 |  |  |  |  |  |

[0000866706-17-000014:8k_2_02:82]
| (1) | 2017 As Adjusted EPS excluded $6.1 million, pretax (or $0.15 per share) of purchase accounting inventory step up charges and acquisition costs during fiscal 2017. |  |
| (2) | 2016 As Adjusted EPS excluded $7.8 million, pretax (or $0.26 per share) of restructuring charges incurred at ETS and Doble during fiscal 2016. |  |

[0000866706-17-000014:8k_2_02:83]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Condensed Business Segment Information (Unaudited) |
| (Dollars in thousands) |
|  |  | GAAP |  |  |  |  |  |
|  |  |  | Q4 2017 |  |  |  | Q4 2016 |  |  |  |  |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 80,640 |  |  |  | 61,994 |  |  |  |  |  |
| Test |  |  | 51,115 |  |  |  | 41,903 |  |  |  |  |  |
| USG |  |  | 52,183 |  |  |  | 34,129 |  |  |  |  |  |
| Technical Packaging |  |  | 23,067 |  |  |  | 21,479 |  |  |  |  |  |
| Totals |  | $ | 207,005 |  |  |  | 159,505 |  |  |  |  |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 17,905 |  |  |  | 15,716 |  |  |  |  |  |
| Test |  |  | 8,404 |  |  |  | 5,276 |  |  |  |  |  |
| USG |  |  | 11,010 |  |  |  | 9,502 |  |  |  |  |  |
| Technical Packaging |  |  | 2,836 |  |  |  | 2,590 |  |  |  |  |  |
| Corporate |  |  | (8,542 | ) |  |  | (8,376 | ) |  |  |  |  |
| Consolidated EBIT |  |  | 31,613 |  |  |  | 24,708 |  |  |  |  |  |
| Less: Interest expense |  |  | (1,826 | ) |  |  | (391 | ) |  |  |  |  |
| Less: Income tax expense |  |  | (10,613 | ) |  |  | (7,402 | ) |  |  |  |  |
| Net earnings |  | $ | 19,174 |  |  |  | 16,915 |  |  |  |  |  |

[0000866706-17-000014:8k_2_02:84]
| Note 1: Adjusted net earnings were $20.4 million in Q4 17 which excluded $1.8 million, pretax (or $0.05 per share) net impact from the acquisitions of NRG, Morgan Schaffer & Vanguard during the fourth quarter of 2017. |
| Note 2: Adjusted net earnings were $17.5 million in Q4 16 which excluded $0.8 million, pretax (or $0.02 per share) of net restructuring charges at ETS and Doble during the fourth quarter of 2016. |

[0000866706-17-000014:8k_2_02:85]
| EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |  |  |  |  |
|  |  |  | Q4 2017 |  |  | Q4 2017 - As Adj |  |  |  | Q4 2016 |  | Q4 2016 - As Adj |  |
| Consolidated EBITDA |  | $ | 40,819 |  |  |  | 42,636 |  |  |  | 31,067 |  | 31,905 |  |
| Less: Depr & Amort |  |  | (9,206 | ) |  |  | (9,206 | ) |  |  | (6,359 | ) | (6,359) |  |
| Consolidated EBIT |  |  | 31,613 |  |  |  | 33,430 |  |  |  | 24,708 |  | 25,546 |  |
| Less: Interest expense |  |  | (1,826 | ) |  |  | (1,826 | ) |  |  | (391 | ) | (391) |  |
| Less: Income tax expense |  |  | (10,613 | ) |  |  | (11,249 | ) |  |  | (7,402 | ) | (7,617) |  |
| Net earnings |  | $ | 19,174 |  |  |  | 20,355 |  |  |  | 16,915 |  | 17,538 |  |

[0000866706-17-000014:8k_2_02:86]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Condensed Business Segment Information (Unaudited) |
| (Dollars in thousands) |
|  |  | GAAP |  |  |  |
|  |  | FY 2017 |  |  | FY 2016 |  |  |  |
| Net Sales |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 279,510 |  |  |  | 207,752 |  |  |  |
| Test |  |  | 160,853 |  |  |  | 161,512 |  |  |  |
| USG |  |  | 162,469 |  |  |  | 127,785 |  |  |  |
| Technical Packaging |  |  | 82,908 |  |  |  | 74,410 |  |  |  |
| Totals |  | $ | 685,740 |  |  |  | 571,459 |  |  |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 52,201 |  |  |  | 45,227 |  |  |  |
| Test |  |  | 19,481 |  |  |  | 13,863 |  |  |  |
| USG |  |  | 36,596 |  |  |  | 31,083 |  |  |  |
| Technical Packaging |  |  | 8,495 |  |  |  | 9,625 |  |  |  |
| Corporate |  |  | (32,042 | ) |  |  | (30,070 | ) |  |  |
| Consolidated EBIT |  |  | 84,731 |  |  |  | 69,728 |  |  |  |
| Less: Interest expense |  |  | (4,578 | ) |  |  | (1,308 | ) |  |  |
| Less: Income tax expense |  |  | (26,450 | ) |  |  | (22,538 | ) |  |  |
| Net earnings |  | $ | 53,703 |  |  |  | 45,882 |  |  |  |
| Note 1: Adjusted net earnings were $57.7 million in FY 17 which excluded $6.1 million, pretax (or $0.15 per share) net impact from the acquisitions of Mayday, NRG, Morgan Schaffer & Vanguard during fiscal 2017. |
| Note 2: Adjusted net earnings were $52.8 million in FY 16 which excluded $7.8 million, pretax (or $0.26 per share) of restructuring charges at ETS and Doble during fiscal 2016. |

[0000866706-17-000014:8k_2_02:87]
| EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |  |  |
|  |  | FY 2017 |  |  | FY 2017 - As Adjusted |  | FY 2016 | FY 2016 - As Adjusted |  |
| Consolidated EBITDA |  | $ | 116,960 |  |  |  | 123,044 |  | 93,296 | 101,097 |  |
| Less: Depr & Amort |  |  | (32,229 | ) |  |  | (32,229 | ) | (23,568) | (23,568) |  |
| Consolidated EBIT |  |  | 84,731 |  |  |  | 90,815 |  | 69,728 | 77,529 |  |
| Less: Interest expense |  |  | (4,578 | ) |  |  | (4,578 | ) | (1,308) | (1,308) |  |
| Less: Income tax expense |  |  | (26,450 | ) |  |  | (28,579 | ) | (22,538) | (23,387) |  |
| Net earnings |  | $ | 53,703 |  |  |  | 57,658 |  | 45,882 | 52,834 |  |

[0000866706-17-000014:8k_2_02:88]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Condensed Consolidated Balance Sheets (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  | September 30, 2017 |  |  | September 30, 2016 |  |
| Assets |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 45,516 |  |  |  | 53,825 |  |
| Accounts receivable, net |  |  | 160,580 |  |  |  | 121,486 |  |
| Costs and estimated earnings on |  |  |  |  |  |  |  |  |
| long-term contracts |  |  | 47,286 |  |  |  | 28,746 |  |
| Inventories |  |  | 124,515 |  |  |  | 105,542 |  |
| Other current assets |  |  | 14,895 |  |  |  | 13,884 |  |
| Total current assets |  |  | 392,792 |  |  |  | 323,483 |  |
| Property, plant and equipment, net |  |  | 132,748 |  |  |  | 92,405 |  |
| Intangible assets, net |  |  | 351,134 |  |  |  | 231,759 |  |
| Goodwill |  |  | 377,879 |  |  |  | 323,616 |  |
| Other assets |  |  | 5,891 |  |  |  | 7,108 |  |
|  |  | $ | 1,260,444 |  |  |  | 978,371 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Short-term borrowings and current |  | $ | 20,000 |  |  |  | 20,000 |  |
| maturities of long-term debt |  |  |  |  |  |  |  |  |
| Accounts payable |  |  | 54,789 |  |  |  | 42,074 |  |
| Current portion of deferred revenue |  |  | 28,583 |  |  |  | 27,212 |  |
| Other current liabilities |  |  | 91,597 |  |  |  | 68,790 |  |
| Total current liabilities |  |  | 194,969 |  |  |  | 158,076 |  |
| Deferred tax liabilities |  |  | 86,378 |  |  |  | 69,562 |  |
| Other liabilities |  |  | 52,179 |  |  |  | 45,624 |  |
| Long-term debt |  |  | 255,000 |  |  |  | 90,000 |  |
| Shareholders' equity |  |  | 671,918 |  |  |  | 615,109 |  |
|  |  | $ | 1,260,444 |  |  |  | 978,371 |  |

[0000866706-17-000014:8k_2_02:89]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Consolidated Statements of Cash Flows (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  | Year Ended September 30, 2017 |  |
| Cash flows from operating activities: |  |  |  |
| Net earnings |  | $ | 53,703 |  |
| Adjustments to reconcile net earnings |  |  |  |  |
| to net cash provided by operating activities: |  |  |  |  |
| Depreciation and amortization |  |  | 32,229 |  |
| Stock compensation expense |  |  | 5,444 |  |
| Changes in assets and liabilities |  |  | (19,539 | ) |
| Change in deferred revenue and costs, net |  |  | 1,650 |  |
| Effect of deferred taxes |  |  | 1,360 |  |
| Pension contributions |  |  | (2,677 | ) |
| Other |  |  | (4,830 | ) |
| Net cash provided by operating activities |  |  | 67,340 |  |
| Cash flows from investing activities: |  |  |  |  |
| Acquisition of businesses, net of cash acquired |  |  | (198,628 | ) |
| Capital expenditures |  |  | (29,728 | ) |
| Additions to capitalized software |  |  | (9,002 | ) |
| Proceeds from sale of land |  |  | 1,184 |  |
| Proceeds from life insurance |  |  | 2,307 |  |
| Net cash used by investing activities |  |  | (233,867 | ) |
| Cash flows from financing activities: |  |  |  |  |
| Proceeds from long-term debt |  |  | 257,000 |  |
| Principal payments on long-term debt |  |  | (92,000 | ) |
| Dividends paid |  |  | (8,257 | ) |
| Other |  |  | 20 |  |
| Net cash provided by financing activities |  |  | 156,763 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 1,455 |  |
| Net decrease in cash and cash equivalents |  |  | (8,309 | ) |
| Cash and cash equivalents, beginning of period |  |  | 53,825 |  |
| Cash and cash equivalents, end of period |  | $ | 45,516 |  |

[0000866706-17-000014:8k_2_02:90]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Other Selected Financial Data (Unaudited) |  |
| (Dollars in thousands) |  |
| Backlog And Entered Orders - Q4 FY 2017 |  | Filtration |  |  | Test |  |  | USG |  |  | Technical Packaging |  |  | Total |  |
| Beginning Backlog - 7/1/17 |  | $ | 204,054 |  |  |  | 105,568 |  |  |  | 42,369 |  |  |  | 27,506 |  |  |  | 379,497 |  |
| Entered Orders |  |  | 79,706 |  |  |  | 60,339 |  |  |  | 45,395 |  |  |  | 19,175 |  |  |  | 204,615 |  |
| Sales |  |  | (80,640 | ) |  |  | (51,115 | ) |  |  | (52,183 | ) |  |  | (23,067 | ) |  |  | (207,005 | ) |
| Ending Backlog - 9/30/17 |  | $ | 203,120 |  |  |  | 114,792 |  |  |  | 35,581 |  |  |  | 23,614 |  |  |  | 377,107 |  |
| Backlog And Entered Orders - FY 2017 |  | Filtration |  |  | Test |  |  | USG |  |  | Technical Packaging |  |  | Total |  |
| Beginning Backlog - 10/1/16 |  | $ | 195,801 |  |  |  | 77,032 |  |  |  | 33,744 |  |  |  | 19,654 |  |  |  | 326,231 |  |
| Entered Orders |  |  | 286,829 |  |  |  | 198,613 |  |  |  | 164,306 |  |  |  | 86,868 |  |  |  | 736,616 |  |
| Sales |  |  | (279,510 | ) |  |  | (160,853 | ) |  |  | (162,469 | ) |  |  | (82,908 | ) |  |  | (685,740 | ) |
| Ending Backlog - 9/30/17 |  | $ | 203,120 |  |  |  | 114,792 |  |  |  | 35,581 |  |  |  | 23,614 |  |  |  | 377,107 |  |

## item 5.02 — body, verbatim

[0000866706-17-000014:8k_body:1]
Item 5.02                          Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers

[0000866706-17-000014:8k_body:2]
Election of New Director and Reclassification of Directors

[0000866706-17-000014:8k_body:3]
Effective November 8, 2017 the registrant's Board of Directors, by unanimous written consent pursuant to Section 3.1 of its Bylaws, increased the authorized size of its Board of Directors from seven to eight members and elected Mr. Patrick M. Dewar, age 57, as a director to fill the vacancy thereby created.

[0000866706-17-000014:8k_body:4]
Mr. Dewar currently serves as Chief Executive  of The Trenton Group LLC, headquartered in Trenton, New Jersey. Previously, Mr. Dewar spent 34 years in the Aerospace Sector with GE Aerospace and Lockheed Martin, where he created and led Lockheed Martin International as an Executive Vice President managing over $10 billion in annual revenue. He holds a Master of Science degree in Electrical Engineering from Drexel University as well as a Bachelor of Science degree in Engineering from Swarthmore College. Mr. Dewar is a member of the Council of Foreign Relations and serves as a senior advisor to numerous investment firms on Aerospace & Defense matters.

[0000866706-17-000014:8k_body:5]
Mr. Dewar was selected to serve the Company as his extensive strategic and operational experience in the aerospace and defense markets will allow him to assist the board in guiding strategy from the highest level. The Board of Directors performed extensive diligence in its search, including utilizing a globally recognized executive search firm.

[0000866706-17-000014:8k_body:6]
Mr. Dewar will receive compensation for his service on the Board of Directors and its Committees pursuant to the Registrant's Compensation Plan for Non-Employee Directors, as amended, on the same basis as the Registrant's other directors; provided that his cash compensation for the remainder of calendar 2017 will be prorated at 25% of a full year's fees, and on or about November 17, 2017 he will receive a standard directors' quarterly stock award of 900 shares for the fourth quarter of calendar 2017.

[0000866706-17-000014:8k_body:7]
Mr. Dewar was designated as a Class III Director, to serve for a term ending at the 2020 Annual Meeting of Shareholders. He will also serve on the Audit and Finance Committee of the Board of Directors. In order to retain equality of size among the three director classes as nearly as practicable, Mr. Larry .Solley, previously a Class III director, was reclassified as a Class II Director to serve for a term ending at the 2019 annual meeting of shareholders.

[0000866706-17-000014:8k_body:8]
Amendments to Performance Compensation Plan

[0000866706-17-000014:8k_body:9]
On November 9, 2017 the Compensation and Human Resources Committee of the registrant's Board of Directors amended and restated the registrant's Performance Compensation Plan for selected corporate and subsidiary officers and key managers (the "PCP"), including the registrant's executive officers.  The PCP had last been amended in 2016.  The amendments do not increase the amounts or change the forms of compensation which may be paid to the eligible officers or managers, but primarily expand the terms of the PCP to allow awards under the PCP to qualify for favorable treatment as "performance-based compensation" under Section 162(m) of the Internal Revenue Code (Section 162(m) Awards").  Prior to the amendment, Section 162(m) Awards could be made only under the registrant's separate Incentive Compensation Plan (the "ICP").  The purpose for the amendments was to permit future performance-based cash incentive awards, including those made to the registrant's executive officers on November 9, 2017 described in the next section, to be made under a single plan, the PCP, rather than having to be divided between the PCP and the ICP based on whether they were intended to qualify as Section 162(m) Awards.  It is the registrant's current intention not to make any future awards under the ICP.  A copy of the PCP as restated to incorporate the amendments is attached to this report as Exhibit 10.1, and a copy of the restated PCP marked to indicate the principal substantive changes from the previous version is attached as Exhibit 10.2.

[0000866706-17-000014:8k_body:10]
Fiscal 2018 Executive Officer Base Salaries and Cash Incentive Compensation

[0000866706-17-000014:8k_body:11]
On November 9, 2017, the Human Resources and Compensation Committee (the "Committee") of the Company's Board of Directors approved the following fiscal 2018 base salaries and target cash incentive compensation opportunities for its executive officers:

[0000866706-17-000014:8k_body:12]
Officer

[0000866706-17-000014:8k_body:13]
Fiscal 2018

[0000866706-17-000014:8k_body:14]
Base Salary

[0000866706-17-000014:8k_body:15]
% Increase from

[0000866706-17-000014:8k_body:16]
Fiscal 2017

[0000866706-17-000014:8k_body:17]
Fiscal 2018 Target Cash Incentive Compensation

[0000866706-17-000014:8k_body:18]
% Increase from

[0000866706-17-000014:8k_body:19]
Fiscal 2017

[0000866706-17-000014:8k_body:20]
Victor L. Richey

[0000866706-17-000014:8k_body:21]
$

[0000866706-17-000014:8k_body:22]
824,500

[0000866706-17-000014:8k_body:23]
None

[0000866706-17-000014:8k_body:24]
$

[0000866706-17-000014:8k_body:25]
788,000

[0000866706-17-000014:8k_body:26]
7.4

[0000866706-17-000014:8k_body:27]
%

[0000866706-17-000014:8k_body:28]
Gary E. Muenster

[0000866706-17-000014:8k_body:29]
$

[0000866706-17-000014:8k_body:30]
550,000

[0000866706-17-000014:8k_body:31]
None

[0000866706-17-000014:8k_body:32]
$

[0000866706-17-000014:8k_body:33]
446,700

[0000866706-17-000014:8k_body:34]
8.2

[0000866706-17-000014:8k_body:35]
%

[0000866706-17-000014:8k_body:36]
Alyson S. Barclay

[0000866706-17-000014:8k_body:37]
$

[0000866706-17-000014:8k_body:38]
337,500

[0000866706-17-000014:8k_body:39]
3.5

[0000866706-17-000014:8k_body:40]
%

[0000866706-17-000014:8k_body:41]
$

[0000866706-17-000014:8k_body:42]
209,000

[0000866706-17-000014:8k_body:43]
3.5

[0000866706-17-000014:8k_body:44]
%

[0000866706-17-000014:8k_body:45]
For fiscal 2018 the Committee determined to allocate 100% of the executive officers' cash incentive compensation opportunity to the PCP, as amended (see above).  The Committee also approved the fiscal 2018 performance criteria for determining the percentage of such target incentive compensation opportunity that will actually be earned by the executive officers, depending on actual fiscal 2018 results compared to the criteria.  The Committee established two performance criteria for fiscal 2018:  earnings per share (EPS), weighted at 70% of the total target opportunity, and cash flow, weighted at 30% of the total target opportunity. The actual cash incentive compensation payable under the PCP for fiscal 2018 will range from 0.0 to 2.0 times the target opportunity for EPS and 0.2 to 2.0 times the target opportunity for cash flow, depending on actual 2018 performance, based on a separate matrix for each of the measures.
