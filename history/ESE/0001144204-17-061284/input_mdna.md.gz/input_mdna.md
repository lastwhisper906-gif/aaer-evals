# ESE MD&A — 0001144204-17-061284


## mdna

[0001144204-17-061284:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial
Condition and Results of Operations

[0001144204-17-061284:mdna:2]
The following discussion should be read in conjunction with the
Consolidated Financial Statements included herein and Notes thereto and refers to the Company’s results from continuing operations,
except where noted.

[0001144204-17-061284:mdna:3]
Introduction

[0001144204-17-061284:mdna:4]
ESCO Technologies Inc. and its wholly owned subsidiaries (the Company)
are organized into four operating segments for financial reporting purposes: Filtration/Fluid Flow (Filtration), RF Shielding and
Test (Test), Utility Solutions Group (USG), and Technical Packaging. The Company’s business segments are comprised of the
following primary operating entities:

[0001144204-17-061284:mdna:5]
|  | · | Filtration: PTI Technologies Inc. (PTI); VACCO Industries (VACCO); Crissair, Inc. (Crissair); Westland Technologies, Inc. (Westland); and Mayday Manufacturing Co. (Mayday) and its affiliate Hi-Tech Metals, Inc. (Hi-Tech). |

[0001144204-17-061284:mdna:6]
|  | · | Test: ETS-Lindgren Inc. (ETS-Lindgren). |

[0001144204-17-061284:mdna:7]
|  | · | USG: Doble Engineering Company (Doble); Morgan Schaffer Ltd. (Morgan Schaffer); and NRG Systems, Inc. (NRG). |

[0001144204-17-061284:mdna:8]
|  | · | Technical Packaging: Thermoform Engineered Quality LLC (TEQ); Plastique Limited and Plastique Sp. z o.o. (together, Plastique). |

[0001144204-17-061284:mdna:9]
|  | 17 |  |

[0001144204-17-061284:mdna:10]
Filtration.
PTI, VACCO and Crissair primarily design and manufacture specialty filtration products including hydraulic filter elements and
fluid control devices used in commercial aerospace applications, unique filter mechanisms used in micro-propulsion devices for
satellites and custom designed filters for manned aircraft and submarines. Westland designs, develops and manufactures elastomeric-based
signature reduction solutions for U.S. naval vessels. Mayday designs and manufactures mission-critical bushings, pins, sleeves
and precision-tolerance machined components for landing gear, rotor heads, engine mounts, flight controls, and actuation systems
for the aerospace and defense industries. Hi-Tech is a full-service metal processor serving aerospace suppliers.

[0001144204-17-061284:mdna:11]
Test.
ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and contain magnetic, electromagnetic
and acoustic energy.

[0001144204-17-061284:mdna:12]
USG.
Doble provides high-end, intelligent diagnostic test solutions for the electric power delivery industry and is a leading supplier
of power factor and partial discharge testing instruments used to assess the integrity of high-voltage power delivery equipment.
Morgan Schaffer provides an integrated offering of dissolved gas analysis, oil testing, and data management solutions which enhance
the ability of electric utilities to accurately monitor the health of critical power transformers. NRG designs and manufactures
decision support tools for the renewable energy industry, primarily wind.

[0001144204-17-061284:mdna:13]
Technical
Packaging. The companies within this segment provide innovative solutions to the medical and commercial markets
for thermoformed and precision molded pulp fiber packages and specialty products using a wide variety of thin gauge plastics and
pulp.

[0001144204-17-061284:mdna:14]
The Company continues to operate with meaningful growth
prospects in its primary served markets and with considerable financial flexibility. The Company continues to focus on new
products that incorporate proprietary design and process technologies. Management is committed to delivering shareholder
value through organic growth, ongoing performance improvement initiatives, and acquisitions.

[0001144204-17-061284:mdna:15]
Highlights of 2017 Operations

[0001144204-17-061284:mdna:16]
|  | · | Sales, net earnings and diluted earnings per share in 2017 were $685.7 million, $53.7 million and $2.07 per share, respectively, compared to sales, net earnings and diluted earnings per share in 2016 of $571.5 million, $45.9 million and $1.77 per share, respectively. |

[0001144204-17-061284:mdna:17]
|  | · | Diluted EPS – As Adjusted for 2017 was $2.22 and excludes $6.1 million of pretax charges (or $0.15 per share after tax) consisting of non-cash purchase accounting inventory step-up charges and costs incurred to complete the Company’s 2017 acquisitions, described below. Diluted EPS – As Adjusted for 2016 was $2.03 and excludes $7.8 million of pretax charges (or $0.26 per share after tax) of restructuring charges related to the 2016 Test and Doble restructuring actions. |

[0001144204-17-061284:mdna:18]
|  | · | Net cash provided by operating activities was approximately $67.3 million in 2017 compared to $73.9 million in 2016, mainly due to an increase in working capital. |

[0001144204-17-061284:mdna:19]
|  | · | At September 30, 2017, cash on hand was $45.5 million and outstanding debt was $275 million, for a net debt position (total debt less net cash) of approximately $229.5 million. |

[0001144204-17-061284:mdna:20]
|  | · | Entered orders for 2017 were $736.6 million resulting in a book-to-bill ratio of 1.07x. Backlog at September 30, 2017 was $377.1 million compared to $326.2 million at September 30, 2016. |

[0001144204-17-061284:mdna:21]
|  | · | In August 2017, the Company acquired the assets of Vanguard Instruments Company (Vanguard Instruments), a test equipment provider serving the global electric utility market, located in Ontario, California, for a purchase price of $36.0 million in cash. Since the date of acquisition, the operating results for Vanguard Instruments have been included as a product line of Doble within the Company’s USG segment. |

[0001144204-17-061284:mdna:22]
|  | · | In May 2017, the Company acquired the assets of Morgan Schaffer Inc. (Morgan Schaffer), a global utilities provider located in Montreal, Quebec, Canada for a purchase price of $48.8 million in cash. Morgan Schaffer manufactures an integrated offering of dissolved gas analysis, oil testing, and data management solutions serving the electric utility market. Since the date of acquisition, the operating results for Morgan Schaffer have been included in the Company’s USG segment. |

[0001144204-17-061284:mdna:23]
|  | · | In May 2017, the Company acquired NRG Systems, Inc. (NRG), located in Hinesburg, Vermont, for a purchase price of $38.6 million in cash. NRG is a market leader in the design and manufacture of decision support tools for the renewable energy industry, primarily wind. Since the date of acquisition, the operating results for NRG have been included in the Company’s USG segment. |

[0001144204-17-061284:mdna:24]
|  | 18 |  |

[0001144204-17-061284:mdna:25]
|  | · | In November 2016, the Company acquired aerospace suppliers Mayday Manufacturing Co. (Mayday) and its affiliate, Hi-Tech Metals, Inc. (Hi-Tech), located in Denton, Texas, for a purchase price of approximately $75 million in cash. Mayday is a manufacturer of bushings, pins, sleeves and precision-tolerance machined components for the aerospace and defense industry. Since the date of acquisition, the operating results for Mayday and Hi-Tech have been included in the Company’s Filtration segment. |

[0001144204-17-061284:mdna:26]
|  | · | The Company declared dividends of $0.32 per share during 2017, totaling $8.3 million in dividend payments. |

[0001144204-17-061284:mdna:27]
Results of Operations

[0001144204-17-061284:mdna:28]
Net Sales

[0001144204-17-061284:mdna:29]
|  |  |  |  |  |  |  |  |  |  |  | Change |  |  | Change |  |
|  |  | Fiscal year ended |  |  | 2017 |  |  | 2016 |  |
| (Dollars in millions) |  | 2017 |  |  | 2016 |  |  | 2015 |  |  | vs. 2016 |  |  | vs. 2015 |  |
| Filtration |  | $ | 279.5 |  |  |  | 207.8 |  |  |  | 196.7 |  |  |  | 34.5 | % |  |  | 5.6 | % |
| Test |  |  | 160.9 |  |  |  | 161.5 |  |  |  | 177.6 |  |  |  | (0.4 | )% |  |  | (9.1 | )% |
| USG |  |  | 162.4 |  |  |  | 127.8 |  |  |  | 123.6 |  |  |  | 27.1 | % |  |  | 3.4 | % |
| Technical Packaging |  |  | 82.9 |  |  |  | 74.4 |  |  |  | 39.4 |  |  |  | 11.4 | % |  |  | 88.8 | % |
| Total |  | $ | 685.7 |  |  |  | 571.5 |  |  |  | 537.3 |  |  |  | 20.0 | % |  |  | 6.4 | % |

[0001144204-17-061284:mdna:30]
Net sales increased $114.2 million, or 20.0%, to $685.7 million
in 2017 from $571.5 million in 2016. The increase in net sales in 2017 as compared to 2016 was due to a $71.7 million increase
in the Filtration segment, a $34.6 million increase in the USG segment and an $8.5 million increase in the Technical Packaging
segment, partially offset by a $0.6 million decrease in the Test segment.

[0001144204-17-061284:mdna:31]
Net sales increased $34.2 million, or 6.4%, to $571.5 million in
2016 from $537.3 million in 2015. The increase in net sales in 2016 as compared to 2015 was due to a $35.0 million increase in
the Technical Packaging segment, an $11.1 million increase in the Filtration segment and a $4.2 million increase in the USG segment,
partially offset by a $16.1 million decrease in the Test segment.

[0001144204-17-061284:mdna:32]
Filtration.

[0001144204-17-061284:mdna:33]
The $71.7 million, or 34.5% increase in net sales in 2017 as compared
to 2016 was primarily driven by the Company’s recent acquisitions of Westland and Mayday, described under “Acquisitions”
below, which contributed $21.0 million and $40.0 million, respectively; and a $12.4 million increase at VACCO due to higher shipments
of its defense products including Navy spares, partially offset by a $2.4 million decrease in sales at Crissair due to lower aerospace
shipments.

[0001144204-17-061284:mdna:34]
The $11.1 million, or 5.6%, increase in net sales in 2016 as compared
to 2015 was primarily due to a $4.6 million increase in net sales from Crissair due to higher aerospace shipments, a $2.5 million
increase in net sales from PTI due to higher shipments of aero assemblies and elements, a $1.4 million increase in net sales from
VACCO due to higher shipments of its Space products and a $2.5 million sales contribution from Westland (acquired on September
2, 2016).

[0001144204-17-061284:mdna:35]
Test.

[0001144204-17-061284:mdna:36]
The net sales decrease of $0.6 million in 2017 as compared to 2016
was mainly due to a $6.4 million decrease in net sales from the Company’s European operations due to the 2016 restructuring
activities to close the Test business operating facilities in Germany and England, offset by a $7.5 million increase in net sales
from its U.S. operations related to higher sales volumes of chamber projects.

[0001144204-17-061284:mdna:37]
The net sales decrease of $16.1 million, or 9.1%, in 2016 as compared
to 2015 was mainly due to a $12 million decrease in net sales from the segment’s European operations due to the 2016 restructuring
activities mentioned above and a $10 million decrease in net sales from the segment’s U.S. operations driven by a decrease
in acoustic projects, partially offset by a $6 million increase in net sales from the segment’s Asian operations driven by
timing of projects.

[0001144204-17-061284:mdna:38]
USG.

[0001144204-17-061284:mdna:39]
The net sales increase of $34.6 million, or 27.1% in 2017 as compared
to 2016 was mainly driven by the Company’s 2017 acquisitions of NRG and Morgan Schaffer, described under “Acquisitions”
below, which contributed $16.2 million and $6.5 million, respectively; and an $11.9 million increase in net sales at Doble from
new products and software solutions.

[0001144204-17-061284:mdna:40]
|  | 19 |  |

[0001144204-17-061284:mdna:41]
The net sales increase of $4.2 million, or 3.4%, in

[0001144204-17-061284:mdna:42]
|  | 20 |  |

[0001144204-17-061284:mdna:43]
16 as compared
to 2015 was driven by additional software and service revenue at Doble and the sales contribution from the Enoserv acquisition
(acquired January 2015).

[0001144204-17-061284:mdna:44]
Technical Packaging.

[0001144204-17-061284:mdna:45]
The $8.5 million, or 11.4%, increase in net sales in 2017 as compared
to 2016 was mainly due to the $9.3 million increase in sales contribution from Plastique which was acquired in January 2016 partially
offset by a $0.8 million decrease in net sales from TEQ due to lower shipments to medical customers.

[0001144204-17-061284:mdna:46]
The $35.0 million, or 88.8%, increase in net sales in 2016 as compared
to 2015 was primarily driven by the 2016 acquisitions of Plastique and Fremont, which contributed $22 million and $7 million, respectively,
to 2016 sales and an increase in shipments to commercial customers.

[0001144204-17-061284:mdna:47]
Orders and Backlog

[0001144204-17-061284:mdna:48]
New orders received in 2017 were $736.6 million as compared to $570.2
million in 2016, resulting in order backlog of $377.1 million at September 30, 2017 as compared to order backlog of $326.2 million
at September 30, 2016. Orders are entered into backlog as firm purchase order commitments are received.

[0001144204-17-061284:mdna:49]
In 2017, the Company recorded $286.8 million of orders related to
Filtration products, $198.6 million of orders related to Test products, $164.3 million of orders related to USG products and $86.9
million of orders related to Technical Packaging products. In 2016, the Company recorded $224.7 million of orders related to Filtration
products, $143.4 million of orders related to Test products, $125.3 million of orders related to USG products and $76.8 million
of orders related to Technical Packaging products.

[0001144204-17-061284:mdna:50]
Selling, General and Administrative Expenses

[0001144204-17-061284:mdna:51]
Selling, general and administrative (SG&A) expenses were $148.4
million, or 21.6% of net sales, in 2017; $131.5 million, or 23.0% of net sales, in 2016; and $130.2 million, or 24.2% of net sales,
in 2015.

[0001144204-17-061284:mdna:52]
The increase in SG&A expenses in 2017 as compared to 2016 was
mainly due to an increase in SG&A expenses both within the Filtration segment (due to the acquisitions of Mayday and Westland,
which contributed $9.3 million to the increase) and the USG segment (due to the acquisitions of NRG and Morgan Schaffer, which
contributed $6.9 million to the increase, as well as additional sales and marketing expenses at Doble), partially offset by a decrease
in SG&A expenses in the Test segment (as a result of the 2016 restructuring activities).

[0001144204-17-061284:mdna:53]
The increase in SG&A expenses in 2016 as compared to 2015 was
mainly due to an increase in SG&A expenses both within the Technical Packaging segment (due to the acquisitions of Plastique
and Fremont) and at Corporate (higher acquisition costs, including professional fees), partially offset by a decrease in SG&A
expenses within the Test and USG segments due to the facility consolidations and headcount reductions.

[0001144204-17-061284:mdna:54]
Amortization Of Intangible Assets

[0001144204-17-061284:mdna:55]
Amortization of intangible assets was $16.3 million in 2017, $11.6
million in 2016 and $8.9 million in 2015. Amortization of intangible assets included $8.6 million, $4.9 million and $4.0 million
of amortization of acquired intangible assets in 2017, 2016 and 2015, respectively, related to the Company’s acquisitions.
The amortization of acquired intangible assets related to the Company’s acquisitions is included in the Corporate operating
segment’s results. The remaining amortization expenses relate to other identifiable intangible assets (primarily software,
patents and licenses), which are included in the respective segment’s operating results. The increase in amortization expense
in 2017 as compared to 2016 and 2015 was mainly due to the amortization of intangibles related to the Company’s recent acquisitions
and an increase in software amortization.

[0001144204-17-061284:mdna:56]
Other Expenses (Income), Net

[0001144204-17-061284:mdna:57]
Other income, net, was $0.7 million in 2017, compared to other expenses,
net, of $7.8 million in 2016 and $1.1 million in 2015. The principal components of other income, net, in 2017 included $0.6 million
from the sale of certain intellectual property and $0.4 million related to death benefit insurance proceeds from a former subsidiary.
The principal components of other expenses, net, in 2016 included $4.9 million of restructuring costs related to the Test segment
facility consolidation and $2.2 million of costs related to the USG segment restructuring activities. The restructuring costs mainly
related to severance and compensation benefits, professional fees and asset impairment charges related to abandoned assets. The
principal component of other expenses, net, in 2015 was $0.9 million of severance expenses related to headcount reductions primarily
at VACCO. There were no other individually significant items included in other expenses (income), net, in 2017, 2016 or 2015.

[0001144204-17-061284:mdna:58]
20

[0001144204-17-061284:mdna:59]
Non-GAAP Financial Measures

[0001144204-17-061284:mdna:60]
The information reported herein includes the financial measures
EPS – As Adjusted, which the Company defines as EPS from continuing operations less defined purchase accounting inventory
step-up charges and acquisition costs in 2017 and the restructuring charges related to the Test and Doble restructuring actions
in 2016; EBIT, which the Company defines as earnings before interest and taxes from continuing operations, without adjustment for
the defined purchase accounting inventory step-up charges, acquisition costs and restructuring charges; and EBIT margin, which
the Company defines as EBIT expressed as a percentage of net sales. EPS – As Adjusted, EBIT on a consolidated basis, and
EBIT margin on a consolidated basis are not recognized in accordance with U.S. generally accepted accounting principles (GAAP).
However, the Company believes that EBIT and EBIT margin provide investors and Management with valuable information for assessing
the Company’s operating results. Management evaluates the performance of its operating segments based on EBIT and believes
that EBIT is useful to investors to demonstrate the operational profitability of the Company’s business segments by excluding
interest and taxes, which are generally accounted for across the entire company on a consolidated basis. EBIT is also one of the
measures Management uses to determine resource allocations and incentive compensation. The Company believes that the presentation
of EBIT, EBIT margin and EPS – As Adjusted provides important supplemental information to investors by facilitating comparisons
with other companies, many of which use similar non-GAAP financial measures to supplement their GAAP results. The use of non-GAAP
financial measures is not intended to replace any measures of performance determined in accordance with GAAP.

[0001144204-17-061284:mdna:61]
EBIT

[0001144204-17-061284:mdna:62]
|  |  |  |  |  |  |  |  |  |  |  | Change |  |  | Change |  |
|  |  | Fiscal year ended |  |  | 2017 |  |  | 2016 |  |
| (Dollars in millions) |  | 2017 |  |  | 2016 |  |  | 2015 |  |  | vs. 2016 |  |  | vs. 2015 |  |
| Filtration |  | $ | 52.2 |  |  |  | 45.2 |  |  |  | 41.7 |  |  |  | 15.5 | % |  |  | 8.4 | % |
| % of net sales |  |  | 18.7 | % |  |  | 21.8 | % |  |  | 21.2 | % |  |  |  |  |  |  |  |  |
| Test |  |  | 19.5 |  |  |  | 13.9 |  |  |  | 9.5 |  |  |  | 40.3 | % |  |  | 46.3 | % |
| % of net sales |  |  | 12.1 | % |  |  | 8.6 | % |  |  | 5.3 | % |  |  |  |  |  |  |  |  |
| USG |  |  | 36.6 |  |  |  | 31.1 |  |  |  | 29.6 |  |  |  | 17.7 | % |  |  | 5.1 | % |
| % of net sales |  |  | 22.5 | % |  |  | 24.3 | % |  |  | 23.9 | % |  |  |  |  |  |  |  |  |
| Technical Packaging |  |  | 8.5 |  |  |  | 9.6 |  |  |  | 4.9 |  |  |  | (11.5 | )% |  |  | 95.9 | % |
| % of net sales |  |  | 10.3 | % |  |  | 12.9 | % |  |  | 12.4 | % |  |  |  |  |  |  |  |  |
| Corporate |  |  | (32.1 | ) |  |  | (30.1 | ) |  |  | (23.4 | ) |  |  | 6.6 | % |  |  | 28.6 | % |
| Total |  | $ | 84.7 |  |  |  | 69.7 |  |  |  | 62.3 |  |  |  | 21.5 | % |  |  | 11.9 | % |
| % of net sales |  |  | 12.4 | % |  |  | 12.2 | % |  |  | 11.6 | % |  |  |  |  |  |  |  |  |

[0001144204-17-061284:mdna:63]
The reconciliation of EBIT from continuing operations to a GAAP
financial measure is as follows:

[0001144204-17-061284:mdna:64]
| (Dollars in millions) |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Net earnings from continuing operations |  | $ | 53.7 |  |  |  | 45.9 |  |  |  | 41.7 |  |
| Add: Interest expense |  |  | 4.6 |  |  |  | 1.3 |  |  |  | 0.8 |  |
| Add: Income taxes |  |  | 26.4 |  |  |  | 22.5 |  |  |  | 19.8 |  |
| EBIT |  | $ | 84.7 |  |  |  | 69.7 |  |  |  | 62.3 |  |

[0001144204-17-061284:mdna:65]
Filtration

[0001144204-17-061284:mdna:66]
EBIT increased $7.0 million in 2017 as compared to 2016 mainly due
to the EBIT contribution from the Westland and Mayday acquisitions and an increase at VACCO and PTI due to increased sales volumes.
EBIT as a percent of net sales decreased in 2017 compared to 2016 mainly due to the purchase accounting inventory step-up charge
at Mayday of $1.9 million in 2017 and engineering and development cost growth on certain fixed price development contracts at VACCO.

[0001144204-17-061284:mdna:67]
EBIT increased $3.5 million in 2016 as compared to 2015 mainly due
to the increased sales volumes at Crissair and VACCO and the EBIT contribution from the 2016 acquisition of Westland, partially
offset by lower margins at PTI due to the impact of early stage production volumes.

[0001144204-17-061284:mdna:68]
|  | 21 |  |

[0001144204-17-061284:mdna:69]
Test

[0001144204-17-061284:mdna:70]
The $5.6 million increase in EBIT in 2017 as compared to 2016 was
primarily due to the $5.1 million of restructuring charges incurred in 2016 related to closing the Test business operating facilities
in Germany and England, consisting mainly of employee severance and compensation benefits, professional fees, and asset impairment
charges.

[0001144204-17-061284:mdna:71]
The $4.4 million increase in EBIT in 2016 as compared to 2015 was
mainly due to the higher sales volumes from the segment’s Asian operations and operational improvement initiatives that were
partially offset by $5.1 million of incremental restructuring charges related to closing the Test business operating facilities
in Taufkirchen, Germany and Stevenage, England consisting mainly of employee severance and compensation benefits, professional
fees, and asset impairment charges. In addition, 2015 EBIT was negatively impacted by incremental charges related to the write-down
of certain inventories.

[0001144204-17-061284:mdna:72]
USG

[0001144204-17-061284:mdna:73]
The $5.5 million increase in EBIT in 2017 as compared to 2016 was
primarily due to higher sales volumes and additional contribution from new products and software solutions, as well as the EBIT
contribution from the 2017 acquisitions of NRG, Morgan Schaffer and Vanguard Instruments. EBIT as a percent of net sales decreased
in 2017 compared to 2016 mainly due to the purchase accounting inventory step-up charges at NRG, Morgan Schaffer and Vanguard Instruments
totaling $1.9 million.

[0001144204-17-061284:mdna:74]
The $1.5 million increase in EBIT in 2016 as compared to 2015 was
primarily due to an increase in sales volumes and the full year EBIT contribution from the 2015 acquisition of Enoserv. In addition,
2016 EBIT was negatively impacted by $2.0 million of incremental restructuring charges incurred related to the closing of the Brazil
office consisting mainly of employee severance and compensation benefits and asset write downs.

[0001144204-17-061284:mdna:75]
Technical Packaging

[0001144204-17-061284:mdna:76]
EBIT decreased $1.1 million in 2017 as compared to 2016 mainly due
to higher SG&A expenses at Plastique due to the full year being included in 2017.

[0001144204-17-061284:mdna:77]
EBIT increased $4.7 million in 2016 as compared to 2015 mainly due
to the acquisitions of Plastique and Fremont and the higher sales volumes to commercial and medical customers.

[0001144204-17-061284:mdna:78]
Corporate

[0001144204-17-061284:mdna:79]
Corporate operating charges included in 2017 consolidated
EBIT increased to $32.1 million as compared to $30.1 million in 2016 due to an increase in acquisition related expenses,
mainly from increased amortization of intangible assets on recent acquisitions.

[0001144204-17-061284:mdna:80]
Corporate operating charges included in 2016 consolidated EBIT
increased to $30.1 million as compared to $23.4 million in 2015 due to an increase in professional fees, acquisition related
expenses, and head count related expenses.

[0001144204-17-061284:mdna:81]
The “Reconciliation to Consolidated Totals (Corporate)”
in Note 13 to the Consolidated Financial Statements included herein represents Corporate office operating charges.

[0001144204-17-061284:mdna:82]
Interest Expense, Net

[0001144204-17-061284:mdna:83]
Interest expense was $4.6 million in 2017, $1.3 million in
2016 and $0.8 million in 2015. The increase in interest expense in 2017 as compared to 2016 was due to higher average
outstanding borrowings ($211.3 million compared to $89.2 million) and higher average interest rates (2.1% vs. 1.6%) as a
result of the additional borrowings to fund the Company’s 2017 acquisitions (Mayday, Morgan Schaffer, NRG and Vanguard
Instruments).The increase in interest expense in 2016 as compared to 2015 was due to higher average interest rates (1.6% vs.
1.3%) and higher average outstanding borrowings ($89.2 million vs. $68.5 million) as a result of the additional borrowings to
fund the Company’s 2016 acquisitions (Westland, Plastique and Fremont).

[0001144204-17-061284:mdna:84]
Income Tax Expense

[0001144204-17-061284:mdna:85]
The effective tax rates from continuing operations for 2017, 2016
and 2015 were 33.0%, 32.9% and 32.2%, respectively. The increase in the 2017 effective tax rate as compared to 2016 as well as
the 2016 effective tax rate as compared to 2015 was primarily due to normal tax fluctuations within the ordinary course of business.

[0001144204-17-061284:mdna:86]
|  | 22 |  |

[0001144204-17-061284:mdna:87]
The Company’s foreign subsidiaries had accumulated unremitted
earnings of $48.9 million and cash of $28.4 million at September 30, 2017. No deferred taxes have been provided on these accumulated
unremitted earnings because these funds are not needed to meet the liquidity requirements of the Company’s U.S. operations
and it is the Company’s intention to indefinitely reinvest these earnings in continuing international operations. In the
event these foreign entities’ earnings were distributed, it is estimated that U.S. taxes, net of available foreign tax credits,
of approximately $6.9 million would be due, which would correspondingly reduce the Company’s net earnings. No significant
portion of the Company’s foreign subsidiaries’ earnings was taxed at a rate significantly less than the U.S. statutory
tax rate.

[0001144204-17-061284:mdna:88]
Capital Resources and Liquidity

[0001144204-17-061284:mdna:89]
The Company’s overall financial position and liquidity are
strong. Working capital (current assets less current liabilities) increased to $197.8 million at September 30, 2017, from $165.4
million at September 30, 2016, mainly due to higher accounts receivable and inventory balances. The $39.1 million increase in accounts
receivable at September 30, 2017 was mainly due to a $17.5 million increase within the Filtration segment mainly due to the acquisition
of Mayday and a $16.2 million increase within the USG segment mainly due to the acquisitions of NRG, Morgan Schaffer and Vanguard
Instruments. The $19.0 million increase in inventory at September 30, 2017 was mainly due to a $10.9 million increase in the USG
segment due to the NRG, Morgan Schaffer and Vanguard Instruments acquisitions and a $7.5 million increase in the Filtration segment
due to the Mayday acquisition.

[0001144204-17-061284:mdna:90]
Net cash provided by operating activities from continuing
operations was $67.3 million, $73.9 million and $65.0 million in 2017, 2016 and 2015, respectively; the changes were mainly
due to changes in working capital.

[0001144204-17-061284:mdna:91]
Net cash used in investing activities from continuing operations
was $

[0001144204-17-061284:mdna:92]
|  | 23 |  |

[0001144204-17-061284:mdna:93]
3.9 million, $104.6 million and $39.5 million in 2017, 2016, and 2015, respectively. The increase in net cash used in investing
activities in 2017 as compared to 2016 was due to the Company’s 2017 acquisitions of Mayday, NRG, Morgan Schaffer and Vanguard
Instruments. Capital expenditures for continuing operations were $29.7 million, $13.8 million and $12.4 million in 2017, 2016
and 2015, respectively. The increase in capital expenditures in 2017 as compared to 2016 was mainly due to an increase in machinery
and equipment at VACCO, a facility expansion at Plastique and the capital expenditures specific to the Company’s recently
acquired entities. There were no commitments outstanding that were considered material for capital expenditures at September 30,
2017. In addition, the Company incurred expenditures for capitalized software of $9.0 million, $8.7 million and $6.9 million 2017,
2016 and 2015, respectively. The increase in 2016 as compared to 2015 was mainly due to higher capitalized software expenditures
within the USG and Test segments.

[0001144204-17-061284:mdna:94]
The Company made required pension contributions of $2.7 million,
$0 and $0.7 million in 2017, 2016 and 2015, respectively.

[0001144204-17-061284:mdna:95]
Net cash provided by financing activities was $156.8 million and
$46.2 million in 2017 and 2016, respectively, compared to net cash used by financing activities of $16.6 million in 2015. The increase
in 2017 compared to 2016 and 2015 was mainly due to an increase in borrowings related to the Company’s recent acquisitions.

[0001144204-17-061284:mdna:96]
Acquisitions

[0001144204-17-061284:mdna:97]
2017

[0001144204-17-061284:mdna:98]
On August 30, 2017, the Company acquired the assets of Vanguard
Instruments Company (Vanguard Instruments), a test equipment provider serving the global electric utility market for a purchase
price of $36.0 million in cash. Vanguard Instruments designs, develops and manufactures test equipment which enhances the ability
of electric utilities to accurately measure the health of critical power transformers and circuit breakers. The business, located
in Ontario, California, operates from its current location as a product line of Doble within the Company’s USG segment and
has annualized sales of approximately $14 million. Based on the preliminary purchase price allocation, the Company recorded approximately
$1.8 million of accounts receivable, $2.1 million of inventory, $0.3 million of property, plant and equipment, $0.2 million of
accounts payable and accrued expenses, $10.7 million of goodwill, $3.2 million of trade names and $18.0 million of amortizable
intangible assets consisting of customer relationships with a weighted average life of 15 years.

[0001144204-17-061284:mdna:99]
23

[0001144204-17-061284:mdna:100]
On May 25, 2017, the Company acquired the assets of Morgan
Schaffer Inc. (Morgan Schaffer), a global utilities provider located in Montreal, Quebec, Canada, for a purchase price of
$48.8 million in cash. Morgan Schaffer has annualized sales of approximately $25 million. It designs, develops, manufactures
and markets an integrated offering of dissolved gas analysis, oil testing, and data management solutions which enhance the
ability of electric utilities to accurately monitor the health of critical power transformers. Since the date of acquisition,
the operating results for Morgan Schaffer have been included in the Company’s USG segment. Based on the preliminary
purchase price allocation, the Company recorded approximately $2.5 million of accounts receivable, $5.2 million of inventory,
$1.7 million of property, plant and equipment, $0.4 million of other assets, $4.9 million of accounts payable and accrued
expenses, $4.8 million of goodwill, $35.6 million of trade names and $3.6 million of amortizable intangible assets consisting
of customer relationships and developed technology with a weighted average life of approximately 10 years.

[0001144204-17-061284:mdna:101]
On May 8, 2017, the Company acquired NRG Systems, Inc. (NRG),
located in Hinesburg, Vermont, for a purchase price of $38.6 million in cash. NRG is the global market leader in the design
and manufacture of decision support tools for the renewable energy industry, primarily wind. NRG has annualized sales of
approximately $45 million. Since the date of acquisition, the operating results for NRG have been included in the
Company’s USG segment. Based on the preliminary purchase price allocation, the Company recorded approximately $1.5
million of cash, $4.1 million of accounts receivable, $5.1 million of inventory, $1.0 million of other assets, $9.4 million
of property, plant and equipment (including a capital lease), $4.1 million of accounts payable and accrued expenses, $9.7
million of lease liability, $8.0 million of goodwill, $8.1 million of trade names and $17.2 million of amortizable intangible
assets consisting of customer relationships with a weighted average life of approximately 14 years.

[0001144204-17-061284:mdna:102]
On November 7, 2016, the Company acquired aerospace suppliers Mayday
Manufacturing Co. (Mayday) and its affiliate Hi-Tech Metals, Inc. (Hi-Tech), which share a state-of-the-art, expandable 130,000
square foot facility in Denton, Texas, for a purchase price of approximately $75 million in cash. Mayday is a leading manufacturer
of mission-critical bushings, pins, sleeves and precision-tolerance machined components for landing gear, rotor heads, engine mounts,
flight controls and actuation systems for the aerospace and defense industry. Hi-Tech is a full-service metal processor offering
aerospace OEM’s and Tier 1 suppliers a large portfolio of processing services including anodizing, cadmium and zinc-nickel
plating, organic coatings, non-destructive testing and heat treatment. Mayday and Hi-Tech together have annual sales of approximately
$40 million. Since the date of acquisition, the consolidated operating results for Mayday and Hi-Tech have been included in the
Company’s Filtration segment. Based on the purchase price allocation, the Company recorded approximately $7.3 million of
accounts receivable, $10.6 million of inventory, $16.6 million of property, plant and equipment (including a capital lease), $10.1
million of lease liability, $15.6 million of deferred tax liabilities, $30.2 million of goodwill, $4.8 million of trade names and $32.8 million of amortizable identifiable intangible assets consisting primarily of customer relationships
with a weighted-average life of approximately 20 years.

[0001144204-17-061284:mdna:103]
2016

[0001144204-17-061284:mdna:104]
On September 2, 2016, the Company acquired the stock of Westland
Technologies, Inc. (Westland), located in Modesto, California, for a purchase price of approximately $41 million in cash. Westland
is a market leader in the design, development and manufacture of elastomeric-based signature reduction solutions which enhance
U.S. Naval maritime platform survivability. Westland has annual sales of approximately $25 million. Since the date of acquisition,
the operating results for Westland have been included within the Company’s Filtration segment. Based on the purchase price
allocation, the Company recorded tangible assets, net, of $5.5 million, deferred tax liabilities of $9.5 million, goodwill of $17.9
million, and $28.3 million of identifiable intangible assets primarily consisting of customer relationships.

[0001144204-17-061284:mdna:105]
On January 29, 2016, the Company acquired Plastique, which is headquartered
in Tunbridge Wells, England and has manufacturing locations in Nottingham, England and Poznan, Poland, for a purchase price of
approximately $31.6 million (of which $2.7 million is due over the next two years). Plastique is a market leader in the development
and manufacture of highly-technical thermoformed plastic and precision molded pulp fiber packaging primarily serving pharmaceutical,
personal care, and various specialty end markets. Since the date of acquisition, the operating results for Plastique have been
included within the Company’s Technical Packaging segment. Plastique has annual sales of approximately $35 million. Based
on the purchase price allocation, the Company recorded tangible assets, net, of $9.6 million, goodwill of $10.2 million, and $11.9
million of identifiable intangible assets primarily consisting of customer relationships.

[0001144204-17-061284:mdna:106]
On October 16, 2015, the Company acquired the stock of
Fremont Plastics, Inc. (Fremont) for a purchase price of $10.5 million in cash. The Company also purchased for
$2 million Fremont’s real property located in Fremont, Indiana. Fremont was a developer, manufacturer, promoter and
seller of high quality sterile-ready and non-sterile thin gauge thermoformed medical plastic packaging products. Immediately
following the closing of the transaction, Fremont was merged into TEQ, and therefore since the date of acquisition the
operating results for Fremont have been included as part of TEQ.

[0001144204-17-061284:mdna:107]
|  | 24 |  |

[0001144204-17-061284:mdna:108]
2015

[0001144204-17-061284:mdna:109]
On January 28, 2015, the Company acquired the assets of Enoserv,
LLC (Enoserv), headquartered in Tulsa, Oklahoma, for $20.5 million in cash. Enoserv provides utility customers with high quality,
user-friendly multi-platform software and has annual revenues of approximately $8 million. Since the date of acquisition the operating
results for Enoserv have been included as part of Doble within the Company’s USG segment. Based on the purchase price allocation,
the Company recorded approximately $10.0 million of goodwill and $9.0 million of amortizable identifiable intangible assets consisting
primarily of customer relationships and developed technology.

[0001144204-17-061284:mdna:110]
All of the Company’s acquisitions have been accounted for
using the purchase method of accounting, and accordingly, the respective purchase prices were allocated to the assets (including
intangible assets) acquired and liabilities assumed based on estimated fair values at the date of acquisition. The financial
results from these acquisitions have been included in the Company’s financial statements from the date of acquisition.

[0001144204-17-061284:mdna:111]
Bank Credit Facility

[0001144204-17-061284:mdna:112]
The Company’s existing credit facility (“the Credit
Facility”) matures December 21, 2020. The Credit Facility includes a $450 million revolving line of credit as well as provisions
allowing for the increase of the credit facility commitment amount by an additional $

[0001144204-17-061284:mdna:113]
|  | 25 |  |

[0001144204-17-061284:mdna:114]
0 million, if necessary, with the consent
of the lenders. The bank syndication supporting the facility is comprised of a diverse group of nine banks led by JP Morgan Chase
Bank, N.A., as Administrative Agent.

[0001144204-17-061284:mdna:115]
At September 30, 2017, the Company had approximately $166 million
available to borrow under the Credit Facility, plus the $250 million increase option, in addition to $45.5 million cash on
hand. The Company classified $20.0 million as the current portion of long-term debt as of September 30, 2017, as the Company intends
to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during
the next twelve months.

[0001144204-17-061284:mdna:116]
The Credit Facility requires, as determined by certain financial
ratios, a facility fee ranging from 12.5 to 27.5 basis points per annum on the unused portion. The terms of the facility provide
that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime
rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic
subsidiaries and a 65% pledge of its material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility
include a leverage ratio and an interest coverage ratio. As of September 30, 2017, the Company was in compliance with all bank
covenants.

[0001144204-17-061284:mdna:117]
Cash flow from operations and borrowings under the Credit Facility
are expected to provide adequate resources to meet the Company’s capital requirements and operational needs for the foreseeable
future.

[0001144204-17-061284:mdna:118]
Dividends

[0001144204-17-061284:mdna:119]
Since 2010 the Company has paid a regular quarterly cash dividend
at an annual rate of $0.32 per share. The Company paid dividends of $8.3 million, $8.2 million and $8.4 million in 2017, 2016
and 2015, respectively.

[0001144204-17-061284:mdna:120]
25

[0001144204-17-061284:mdna:121]
Contractual Obligations

[0001144204-17-061284:mdna:122]
The following table shows the Company’s contractual obligations
as of September 30, 2017:

[0001144204-17-061284:mdna:123]
|  |  | Payments due by period |  |
|  |  |  |  |  | Less than |  |  | 1 to 3 |  |  | 3 to 5 |  |  | More than |  |
| (Dollars in millions) |  | Total |  |  | 1 year |  |  | years |  |  | years |  |  | 5 years |  |
| Long-Term Debt Obligation |  | $ | 275.0 |  |  |  | - |  |  |  | - |  |  |  | 275.0 |  |  |  | - |  |
| Estimated Interest Payments (1) |  |  | 31.4 |  |  |  | 8.3 |  |  |  | 15.1 |  |  |  | 7.5 |  |  |  | 0.5 |  |
| Operating Lease Obligations |  |  | 21.7 |  |  |  | 6.4 |  |  |  | 9.1 |  |  |  | 4.7 |  |  |  | 1.5 |  |
| Purchase Obligations (2) |  |  | 9.8 |  |  |  | 8.4 |  |  |  | 1.4 |  |  |  | - |  |  |  | - |  |
| Total |  | $ | 337.9 |  |  |  | 23.1 |  |  |  | 25.6 |  |  |  | 287.2 |  |  |  | 2.0 |  |

[0001144204-17-061284:mdna:124]
|  | (1) | Estimated interest payments for the Company’s debt obligations were calculated based on Management’s determination of the estimated applicable interest rates and payment dates. |

[0001144204-17-061284:mdna:125]
|  | (2) | A purchase obligation is defined as a legally binding and enforceable agreement to purchase goods and services that specifies all significant terms. Since the majority of the Company’s purchase orders can be cancelled, they are not included in the table above. |

[0001144204-17-061284:mdna:126]
As of September 30, 2017, the Company had $0.1 million of liabilities
for uncertain tax positions. The unrecognized tax benefits have been excluded from the table above due to uncertainty as to the
amounts and timing of settlement with taxing authorities.

[0001144204-17-061284:mdna:127]
The Company had no off-balance-sheet arrangements outstanding at
September 30, 2017.

[0001144204-17-061284:mdna:128]
Share Repurchases

[0001144204-17-061284:mdna:129]
In August 2012, the Company’s Board of Directors authorized
a common stock repurchase program under which the Company may repurchase shares of its stock from time to time in its discretion,
in the open market or otherwise, up to a maximum total repurchase amount of $100 million (or such lesser amount as may be permitted
under the Company’s bank credit agreements). This program has been twice extended by the Company’s Board of Directors
and is currently scheduled to expire September 30, 2019. There were no share repurchases in 2017. The Company repurchased approximately
120,000 shares for $4.3 million in 2016 and 517,000 shares for $18.2 million in 2015. At September 30, 2017 approximately $50.4
million remained available for repurchases under the program.

[0001144204-17-061284:mdna:130]
Pension Funding Requirements

[0001144204-17-061284:mdna:131]
The minimum cash funding requirements related to the Company’s
defined benefit pension plans are estimated to be approximately $2.8 million in 2018, $2.8 million in 2019, and $3.1 million in
2020.

[0001144204-17-061284:mdna:132]
Other

[0001144204-17-061284:mdna:133]
As a normal incident of the business in which the Company is engaged,
various claims, charges and litigation are asserted or commenced from time to time against the Company. Additionally, the Company
is currently involved in various stages of investigation and remediation relating to environmental matters. It is the opinion of
Management that the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered
against the Company are adequately reserved for, are covered by insurance or are not likely to have a material adverse effect on
the Company’s results from continuing operations, capital expenditures or competitive position.

[0001144204-17-061284:mdna:134]
Outlook

[0001144204-17-061284:mdna:135]
Management continues to see
meaningful sales and Adjusted EBITDA growth across each of the Company’s business segments and anticipates growth rates in
2018 and beyond that exceed the Company’s defined peer group and the broader industrial market. The details of
Management’s growth expectations for 2018 compared to 2017 are as follows:

[0001144204-17-061284:mdna:136]
|  | · | Sales are expected to increase approximately 13% driven by: incremental sales from acquisitions being included for a full year; increased commercial aerospace deliveries at PTI, Crissair and Mayday; higher organic sales at USG; significantly higher sales at Test including new product wins currently in backlog; partially offset by a reduction in lower margin industrial/automotive market product deliveries at PTI; and flat sales in Technical Packaging. |

[0001144204-17-061284:mdna:137]
|  | 26 |  |

[0001144204-17-061284:mdna:138]
|  | · | Interest expense on higher debt (acquisition funding) is expected to be approximately $9.5 million, reflecting an increase of $4.9 million (or $0.12 per share) over the $4.6 million of interest expense in 2017; |

[0001144204-17-061284:mdna:139]
|  | · | Non-cash depreciation and amortization of intangibles is expected to increase approximately $7.1 million (or $0.18 per share after-tax) as a result of the recent acquisitions. Purchase accounting intangible asset amortization charges are recorded at Corporate; |

[0001144204-17-061284:mdna:140]
|  | · | Income tax expense is expected to increase in 2018 as Management is projecting a 35% effective tax rate calculated on higher pretax earnings. |

[0001144204-17-061284:mdna:141]
|  | · | In summary, Management projects 2018 EPS to be in the range of $2.30 to $2.40 per share, including the profit contributions from the recent acquisitions, the additional depreciation and amortization charges, higher interest, and incremental tax expense as described above. |

[0001144204-17-061284:mdna:142]
On a quarterly basis, Management
expects 2018 operating results to reflect a profile similar to 2017 and previous years, with revenues and EPS being more second-half
weighted. As with past years, projected second half 2018 sales and EPS are expected to be significantly stronger than the first
half. Management expects Q1 2018 EPS to be in the range of $0.28 to $0.33 per share. The timing of quarterly sales and earnings
throughout the year, coupled with higher non-cash charges within the respective quarters impacts comparability in Q1.

[0001144204-17-061284:mdna:143]
Market Risk Analysis

[0001144204-17-061284:mdna:144]
Market Risk Exposure

[0001144204-17-061284:mdna:145]
Market risks relating to the Company’s operations result primarily
from changes in interest rates and changes in foreign currency exchange rates. The Company is exposed to market risk related to
changes in interest rates and selectively uses derivative financial instruments, including forward contracts and swaps, to manage
these risks. During 2016, the Company entered into several forward contracts to purchase pounds sterling (GBP) to hedge two deferred
payments due in connection with the acquisition of Plastique. In 2017, the Company’s Canadian subsidiary Morgan Schaffer
entered into foreign exchange contracts to manage foreign currency risk, as a portion of their revenue is denominated in U.S. dollars.
All derivative instruments are reported on the balance sheet at fair value. For derivative instruments designated as cash flow
hedges, the gain or loss on the derivative is deferred in accumulated other comprehensive income until recognized in earnings with
the underlying hedged item.

[0001144204-17-061284:mdna:146]
The Company has determined that the market risk related to interest
rates with respect to its variable debt is not material. The Company estimates that if market interest rates averaged one percentage
point higher, the effect would have been less than 4% of net earnings for the year ended September 30, 2017.

[0001144204-17-061284:mdna:147]
The following is a summary of the notional transaction amounts and
fair values for the Company’s outstanding derivative financial instruments as of September 30, 2017.

[0001144204-17-061284:mdna:148]
| (In thousands) |  | Notional Amount (Currency) |  | Fair Value (US$) |  |
| Forward contracts |  | 1,859 GBP |  |  | (173 | ) |
| Forward contracts |  | 3,250 USD |  |  | 149 |  |
| Forward contracts |  | 200 EUR |  |  | (5 | ) |

[0001144204-17-061284:mdna:149]
The Company is also subject to foreign currency exchange rate risk
inherent in its sales commitments, anticipated sales, anticipated purchases and assets and liabilities denominated in currencies
other than the U.S. dollar. The foreign currencies most significant to the Company’s operations are the Canadian Dollar and
the Euro. The Company occasionally hedges certain foreign currency commitments by purchasing foreign currency forward contracts.
The Company does not have material foreign currency market risk; net foreign currency transaction gain/loss was less than 2% of
net earnings for 2017, 2016 and 2015.

[0001144204-17-061284:mdna:150]
Critical Accounting Policies

[0001144204-17-061284:mdna:151]
The preparation of financial statements in conformity with U.S.
generally accepted accounting principles (GAAP) requires Management to make estimates and assumptions in certain circumstances
that affect amounts reported in the accompanying Consolidated Financial Statements. In preparing these financial statements, Management
has made its best estimates and judgments of certain amounts included in the Consolidated Financial Statements, giving due consideration
to materiality. The Company does not believe there is a great likelihood that materially different amounts would be reported under
different conditions or using different assumptions related to the accounting policies described below. However, application of
these accounting policies involves the exercise of judgment and use of assumptions as to future uncertainties and, as a result,
actual results could differ from these estimates. The Company’s senior Management discusses the critical accounting policies
described below with the Audit and Finance Committee of the Company’s Board of Directors on a periodic basis.

[0001144204-17-061284:mdna:152]
|  | 27 |  |

[0001144204-17-061284:mdna:153]
The following discussion of critical accounting policies is intended
to bring to the attention of readers those accounting policies which Management believes are critical to the Consolidated Financial
Statements and other financial disclosure. It is not intended to be a comprehensive list of all significant accounting policies
that are more fully described in Note 1 to the Consolidated Financial Statements included herein.

[0001144204-17-061284:mdna:154]
Revenue Recognition

[0001144204-17-061284:mdna:155]
Filtration
Segment: Within the Filtration segment, approximately 86% of revenues (approximately 36% of consolidated
revenues) are recognized when products are delivered (when title and risk of ownership transfers) or when services are performed
for unaffiliated customers.

[0001144204-17-061284:mdna:156]
Approximately 14% of the segment’s revenues (approximately 6% of
consolidated revenues) are recorded under the percentage-of-completion method because the Company manufactures complex
products for aerospace and military customers under production contracts. The majority of these contracts are
cost-reimbursable contracts which provide for the payment of allowable costs incurred during the performance of the contract
plus an incentive fee. The remainder of the contracts are fixed-price contracts. The percentage-of-completion method of
accounting involves the use of various estimating techniques to project costs at completion. These estimates involve various
assumptions and projections relative to the outcome of future events over a period of several years, including future labor
productivity and availability, the nature and complexity of the work to be performed, availability of materials, the impact
of delayed performance, the timing of product deliveries, and estimates of incentive fees based on past experience and
anticipated performance. These estimates are based on Management’s judgment and the Company’s substantial
experience in developing these types of estimates. Changes in underlying assumptions/estimates may adversely affect financial
performance if they increase estimated project costs at completion, or positively affect financial performance if they
decrease estimated project costs at completion. Due to the nature of these contracts and the operating unit’s cost
estimating process, the Company believes that these estimates generally should not be subject to significant variation in the
future. There have been no material changes to these estimates for the financial statement periods presented. The Company
regularly reviews its estimates to assess revisions in contract values and estimated costs at completion.

[0001144204-17-061284:mdna:157]
Test
Segment: Within the Test segment, approximately 30% of revenues (approximately 7% of consolidated revenues) are
recognized when products are delivered (when title and risk of ownership transfers) or when services are performed for unaffiliated
customers.

[0001144204-17-061284:mdna:158]
Approximately 70% of the segment’s revenues (approximately
16% of consolidated revenues) are recorded under the percentage-of-completion method due to the complex nature of the enclosures
that are designed and produced under these contracts. As discussed above, this method of accounting involves the use of various
estimating techniques to project costs at completion, which are based on Management’s judgment and the Company’s substantial
experience in developing these types of estimates. Changes in underlying assumptions/estimates may adversely or positively affect
financial performance in a period. Due to the nature of these contracts and the operating unit’s cost estimating process,
the Company believes that these estimates generally should not be subject to significant variation in the future. There have been
no material changes to these estimates for the financial statement periods presented. The Company regularly reviews its contract
estimates to assess revisions in contract values and estimated costs at completion.

[0001144204-17-061284:mdna:159]
USG
Segment: Within the USG segment, approximately 78% of revenues (approximately 18% of
consolidated revenues) are recognized when products are delivered (when title and risk of ownership transfers) or when
services are performed for unaffiliated customers. Approximately 22% of the segment’s revenues (approximately 5% of
consolidated revenues) are recognized on a straight-line basis over the lease term.

[0001144204-17-061284:mdna:160]
Technical
Packaging Segment: Within the Technical Packaging segment, 100% of revenues (approximately 12%
of consolidated revenues) represent products and services sold and are recognized when products are delivered (when title and risk
of ownership transfers), or when services are performed for unaffiliated customers.

[0001144204-17-061284:mdna:161]
Income Taxes

[0001144204-17-061284:mdna:162]
The Company operates in numerous taxing jurisdictions and is subject
to examination by various U.S. Federal, state and foreign jurisdictions for various tax periods. The Company’s income tax
positions are based on research and interpretations of the income tax laws and rulings in each of the jurisdictions in which the
Company does business. Due to the subjectivity of interpretations of laws and rulings in each jurisdiction, the differences and
interplay in tax laws between those jurisdictions, as well as the inherent uncertainty in estimating the final resolution of complex
tax audit matters, Management’s estimates of income tax liabilities may differ from actual payments or assessments.

[0001144204-17-061284:mdna:163]
|  | 28 |  |

[0001144204-17-061284:mdna:164]
Management regularly assesses the Company’s position with
regard to tax exposures and records liabilities for these uncertain tax positions and related interest and penalties, if any, according
to the principles of Financial Accounting Standards Board (FASB) ASC Topic 740, Income Taxes (ASC 740). The Company
has recorded an accrual that reflects the recognition and measurement process for the financial statement recognition and measurement
of a tax position taken or expected to be taken on a tax return based upon ASC 740. Additional future income tax expense or
benefit may be recognized once the positions are effectively settled. It is the Company’s policy to follow FASB ASC
740-10-45-20 and record the tax effects of changes in the opening balance of unrecognized tax benefits in net earnings from continuing
operations.

[0001144204-17-061284:mdna:165]
At the end of each interim reporting period, Management estimates
the effective tax rate expected to apply to the full fiscal year. The estimated effective tax rate contemplates the expected jurisdiction
where income is earned, as well as tax planning strategies. Current and projected growth in income in higher tax jurisdictions
may result in an increasing effective tax rate over time. If the actual results differ from Management’s estimates, Management
may have to adjust the effective tax rate in the interim period if such determination is made.

[0001144204-17-061284:mdna:166]
Income taxes are accounted for under the asset and liability method.
Deferred tax assets and liabilities are recognized for the future tax consequences attributable to differences between the financial
statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities
are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are
expected to be recovered or settled. Deferred tax assets may be reduced by a valuation allowance if it is more likely than not
that some portion of the deferred tax assets will not be realized. The effect on deferred tax assets and liabilities of a change
in tax rates is recognized in income in the period that includes the enactment date. The Company regularly reviews its deferred
tax assets for recoverability and establishes a valuation allowance when Management believes it is more likely than not such assets
will not be recovered, taking into consideration historical operating results, expectations of future earnings, tax planning strategies,
and the expected timing of the reversals of existing temporary differences.

[0001144204-17-061284:mdna:167]
Goodwill And Other Long-Lived Assets

[0001144204-17-061284:mdna:168]
Management annually reviews goodwill and other long-lived assets
with indefinite useful lives for impairment or whenever events or changes in circumstances indicate the carrying amount may not
be recoverable. If the Company determines that the carrying value of the long-lived asset may not be recoverable, a permanent impairment
charge is recorded for the amount by which the carrying value of the long-lived asset exceeds its fair value. Fair value is measured
based on a discounted cash flow method using a discount rate determined by Management to be commensurate with the risk inherent
in the Company’s current business model. The estimates of cash flows and discount rate are subject to change due to the economic
environment, including such factors as interest rates, expected market returns and volatility of markets served. Management believes
that the estimates of future cash flows and fair value are reasonable; however, changes in estimates could result in impairment
charges. At September 30, 2017, the Company has determined that no reporting units are at risk of goodwill impairment
as the fair value of each reporting unit substantially exceeded its carrying value.

[0001144204-17-061284:mdna:169]
Intangible assets with estimable useful lives are amortized over
their respective estimated useful lives to their estimated residual values, and are reviewed for impairment whenever events or
changes in business circumstances indicate the carrying value of the assets may not be recoverable.

[0001144204-17-061284:mdna:170]
Pension Plans and Other Postretirement Benefit Plans

[0001144204-17-061284:mdna:171]
The measurement of liabilities related to pension plans and other
postretirement benefit plans is based on Management’s assumptions related to future events including interest rates, return
on pension plan assets, and health care cost trend rates. Actual pension plan asset performance will either decrease or increase
unamortized pension losses/gains that will affect net earnings in future years. Depending upon the performance of the equity and
bond markets in 2018, the Company could be required to record a charge to other comprehensive income/loss. In addition, if the
discount rate were decreased by 25 basis points from 3.65% to 3.40%, the projected benefit obligation for the defined benefit plan
would increase by approximately $2.8 million and result in an additional after-tax charge to other comprehensive income/loss
of approximately $1.8 million. The discount rate used in measuring the Company’s pension and postretirement welfare obligations
was developed by matching yields of actual high-quality corporate bonds to expected future pension plan cash flows (benefit payments).
Over 400 Aa-rated, non-callable bonds with a wide range of maturities were used in the analysis. After using the bond yields to
determine the present value of the plan cash flows, a single representative rate that resulted in the same present value was developed.

[0001144204-17-061284:mdna:172]
|  | 29 |  |

[0001144204-17-061284:mdna:173]
Other Matters

[0001144204-17-061284:mdna:174]
Contingencies

[0001144204-17-061284:mdna:175]
As a normal incident of the businesses in which the Company is engaged,
various claims, charges and litigation are asserted or commenced from time to time against the Company. Additionally, the Company
is currently involved in various stages of investigation and remediation relating to environmental matters. It is the opinion of
Management that the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered
against the Company are adequately accrued, are covered by insurance or are not likely to have a material adverse effect on the
Company’s results from continuing operations, capital expenditures, or competitive position.

[0001144204-17-061284:mdna:176]
Quantitative and Qualitative Disclosures About Market Risk

[0001144204-17-061284:mdna:177]
Market risks relating to the Company’s operations result primarily
from changes in interest rates and changes in foreign currency exchange rates. The Company is exposed to market risk related to
changes in interest rates and selectively uses derivative financial instruments, including forward contracts and swaps, to manage
these risks. During 2016 the Company entered into several forward contracts to purchase pounds sterling (GBP) to hedge two deferred
payments (one due in January 2018 and one due in January 2019) due in connection with the acquisition of Plastique. In addition,
the Company’s Canadian subsidiary Morgan Schaffer has entered into foreign exchange contracts to manage foreign currency
risk as a portion of their revenue is denominated in U.S. dollars. All derivative instruments are reported on the balance sheet
at fair value. For derivative instruments designated as cash flow hedges, the gain or loss on the derivative is deferred in accumulated
other comprehensive income until recognized in earnings with the underlying hedged item. See  further discussion regarding the
Company’s market risks in “Market Risk Analysis,” above.

[0001144204-17-061284:mdna:178]
Controls and Procedures

[0001144204-17-061284:mdna:179]
For a description of the Company’s evaluation of its disclosure
controls and procedures, see Item 9A, “Controls and Procedures.”

[0001144204-17-061284:mdna:180]
New Accounting Pronouncements

[0001144204-17-061284:mdna:181]
In January 2017, the FASB issued Accounting Standards Update (ASU)
No. 2017-04, Simplifying the Test for Goodwill Impairment (ASU 2017-04), which eliminates Step 2 from the goodwill impairment
test. Under the amendments in this update, an entity should recognize an impairment charge for the amount by which the carrying
amount exceeds the reporting unit’s fair value; however, the loss recognized should not exceed the total amount of goodwill
allocated to that reporting unit. The new standard is effective for fiscal years beginning after December 15, 2019. Early adoption
is permitted for interim or annual goodwill impairment tests performed on testing dates after January 1, 2017. The Company adopted
this standard in the fourth quarter of 2017 with its annual goodwill impairment tests. The adoption of ASU 2017-04 did not have
an impact on the Company’s Consolidated Financial Statements.

[0001144204-17-061284:mdna:182]
In March 2016, the FASB issued ASU No. 2016-09, Improvements
to Employee Share-Based Payment Accounting, which simplified the income tax consequences, accounting for forfeitures and classification
on the Statements of Consolidated Cash Flows. The Company adopted this standard in the current year resulting in the income tax
expense in the third quarter and fiscal year 2017 being favorably impacted by additional tax benefits on share-based compensation
that vested during the third quarter of 2017 decreasing the effective tax rate by 5.1% and 1.1%, respectively.

[0001144204-17-061284:mdna:183]
In February 2016, the FASB issued ASU No. 2016-062, Leases (Topic
842), which, among other things, requires an entity to recognize lease assets and lease liabilities on the balance sheet and
disclose key information about leasing arrangements. This new standard will increase an entity’s reported assets and liabilities.
The new standard is effective for fiscal years beginning after December 15, 2018 and mandates a modified retrospective transition
period for all entities. The Company is currently assessing the impact of this new standard on its consolidated financial statements
and related disclosures.

[0001144204-17-061284:mdna:184]
|  | 30 |  |

[0001144204-17-061284:mdna:185]
In November 2015, the FASB issued ASU No. 2015-17, Balance Sheet
Classification of Deferred Taxes, which requires entities to present deferred tax assets and deferred tax liabilities as noncurrent
in a classified balance sheet. This new standard is effective for annual periods beginning after December 15, 2016. The Company
adopted this standard during the fourth quarter of 2016 and applied it on a prospective basis.

[0001144204-17-061284:mdna:186]
In May 2014, the FASB issued ASU No. 2014-09, Revenue from Contracts
with Customers, which requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer
of promised goods or services to customers. This guidance has been further clarified and amended. The new standard will be effective
for annual reporting periods beginning after December 15, 2017, and interim periods within those annual periods. The standard permits
the use of either the retrospective or cumulative effect transition method. The Company is currently in the process of calculating
the effect that ASU 2014-09 will have on its consolidated financial statements and related disclosures. The Company has selected
the Cumulative Effect method of transition to the new standard.
