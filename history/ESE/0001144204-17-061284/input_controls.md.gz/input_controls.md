# ESE 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001144204-17-061284:item_9a:1]
Item 9A. Controls and Procedures

[0001144204-17-061284:item_9a:2]
For 2017 the Company carried out an evaluation of the effectiveness
of the design and operation of the Company’s disclosure controls and procedures, as defined in Rules 13a-15(e) and 15d–15(e)
under the Securities Exchange Act of 1934, as amended (the Exchange Act). The evaluation was conducted under the supervision and
with the participation of the Company’s Management, including the Company’s Chief Executive Officer and Chief Financial
Officer, using the Internal Control – Integrated Framework
(2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). Disclosure controls and procedures
are controls and procedures that are designed to ensure that information required to be disclosed in Company reports filed or submitted
under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the Securities and
Exchange Commission’s rules and forms. Based upon that evaluation, the Company’s Chief Executive Officer and Chief
Financial Officer concluded that the Company’s disclosure controls and procedures were effective as of September 30, 2017.

[0001144204-17-061284:item_9a:3]
There were no changes in the Company’s internal control over
financial reporting (as defined in Rule 13a-15(f) under the Exchange Act) during the fiscal quarter ended September 30, 2017 that
have materially affected, or are reasonably likely to materially affect, the Company’s internal control over financial reporting.

[0001144204-17-061284:item_9a:4]
For the remainder of the information required by this item, see
“Management’s Report on Internal Control over Financial Reporting” and the related “Report of Independent
Registered Public Accounting Firm” of KPMG LLP, in the Financial Information section beginning on page F-1 of this Annual
Report, which are incorporated into this Item by reference.
