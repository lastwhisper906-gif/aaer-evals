# ESE notes — 0001144204-17-061284


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001144204-17-061284:notes:1]
|  | 1. | Summary of Significant Accounting Policies |

[0001144204-17-061284:notes:2]
|  | A. | Principles of Consolidation |

[0001144204-17-061284:notes:3]
The Consolidated Financial Statements include the accounts of ESCO Technologies Inc. (ESCO) and its wholly owned subsidiaries (the Company). All significant intercompany transactions and accounts have been eliminated in consolidation.

[0001144204-17-061284:notes:4]
|  | B. | Basis of Presentation |

[0001144204-17-061284:notes:5]
The Company’s fiscal year ends September 30. Throughout these Consolidated Financial Statements, unless the context indicates otherwise, references to a year (for example 2017) refer to the Company’s fiscal year ending on September 30 of that year. Certain prior period amounts have been reclassified to conform to the current period presentation.

[0001144204-17-061284:notes:6]
The Company accounts for shipping and handling costs on a gross basis and they are included in net sales. The Company accounts for taxes collected from customers and remitted to governmental authorities on a net basis and they are excluded from net sales.

[0001144204-17-061284:notes:7]
Aclara is reflected as discontinued operations in the consolidated financial statements and related notes for fiscal 2015, in accordance with accounting principles generally accepted in the United States of America (GAAP).

[0001144204-17-061284:notes:8]
|  | C. | Nature of Operations |

[0001144204-17-061284:notes:9]
The Company is organized based on the products and services it offers, and classifies its business operations in segments for financial reporting purposes. Under the current organization structure, the Company has four segments for financial reporting purposes: Filtration/Fluid Flow (Filtration), RF Shielding and Test (Test), Utility Solutions Group (USG) and Technical Packaging.

[0001144204-17-061284:notes:10]
Filtration: The companies within this segment primarily design and manufacture specialty filtration products including hydraulic filter elements and fluid control devices used in commercial aerospace applications, unique filter mechanisms used in micro-propulsion devices for satellites, custom designed filters for manned aircraft and submarines, elastomeric-based signature reduction solutions to enhance U.S. Navy maritime survivability, precision-tolerance machined components for the aerospace and defense industry, and metal processing services.

[0001144204-17-061284:notes:11]
Test:  ETS-Lindgren Inc. provides its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy.

[0001144204-17-061284:notes:12]
USG: The companies within this segment provide high-end, intelligent, diagnostic test and data management solutions for the electric power delivery industry, and decision support tools for the renewable energy industry, primarily wind.

[0001144204-17-061284:notes:13]
Technical Packaging: The companies within this segment provide innovative solutions to the medical and commercial markets for thermoformed and precision molded pulp fiber packages and specialty products using a wide variety of thin gauge plastics and pulp.

[0001144204-17-061284:notes:14]
|  | D. | Use of Estimates |

[0001144204-17-061284:notes:15]
The preparation of financial statements in conformity with GAAP requires Management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.

[0001144204-17-061284:notes:16]
|  | E. | Revenue Recognition |

[0001144204-17-061284:notes:17]
Filtration: Within the Filtration segment, approximately  86% of revenues (approximately  36% of consolidated revenues) are recognized when products are delivered (when title and risk of ownership transfers) or when services are performed for unaffiliated customers.

[0001144204-17-061284:notes:18]
Approximately  14% of the segment’s revenues (approximately  6% of consolidated revenues) are recorded under the percentage-of-completion method. The majority of these contracts are cost-reimbursable contracts which provide for the payment of allowable costs incurred during the performance of the contract plus an incentive fee. The remainder of the contracts are fixed-price contracts. Products accounted for under this guidance include the design, development and manufacture of complex fluid control products, quiet valves, manifolds and systems primarily for the aerospace and military markets. For fixed-price contracts that are accounted for under this guidance, the Company estimates profit as the difference between total estimated revenue and total estimated cost of a contract and recognizes these revenues and costs based on units delivered. The percentage-of-completion method of accounting involves the use of various techniques to estimate expected costs at completion. These estimates are based on Management’s judgment and the Company’s substantial experience in developing these types of estimates.

[0001144204-17-061284:notes:19]
Test: Within the Test segment, approximately  30% of revenues (approximately 7% of consolidated revenues) are recognized when products are delivered (when title and risk of ownership transfers) or when services are performed for unaffiliated customers.

[0001144204-17-061284:notes:20]
Approximately  70% of the segment’s revenues (approximately  16% of consolidated revenues) are recorded under the percentage-of-completion method due to the complex nature of the enclosures that are designed and produced under these contracts. Products accounted for under this guidance include the construction and installation of complex test chambers to a buyer’s specifications that provide its customers with the ability to measure and contain magnetic, electromagnetic and acoustic energy. As discussed above, for arrangements that are accounted for under this guidance, the Company estimates profit as the difference between total estimated revenue and total estimated cost of a contract and recognizes these revenues and costs based primarily on contract milestones. The percentage-of-completion method of accounting involves the use of various techniques to estimate expected costs at completion. These estimates are based on Management’s judgment and the Company’s substantial experience in developing these types of estimates.

[0001144204-17-061284:notes:21]
USG: Within the USG segment, approximately  78% of revenues (approximately  18% of consolidated revenues) are recognized when products are delivered (when title and risk of ownership transfers), or when services are performed for unaffiliated customers. Approximately  22% of the segment’s revenues (approximately  5% of consolidated revenues) are recognized on a straight-line basis over the lease term.

[0001144204-17-061284:notes:22]
Technical Packaging: Within the Technical Packaging segment,  100% of revenues (approximately  12% of consolidated revenues) are recognized when products are delivered (when title and risk of ownership transfers) or when services are performed for unaffiliated customers.

[0001144204-17-061284:notes:23]
|  | F. | Cash and Cash Equivalents |

[0001144204-17-061284:notes:24]
Cash equivalents include temporary investments that are readily convertible into cash, such as money market funds, with original maturities of three months or less.

[0001144204-17-061284:notes:25]
|  | G. | Accounts Receivable |

[0001144204-17-061284:notes:26]
Accounts receivable have been reduced by an allowance for amounts that the Company estimates are uncollectible in the future. This estimated allowance is based on Management’s evaluation of the financial condition of the customer and historical write-off experience.

[0001144204-17-061284:notes:27]
|  | H. | Costs and Estimated Earnings on Long-Term Contracts |

[0001144204-17-061284:notes:28]
Costs and estimated earnings on long-term contracts represent unbilled revenues, including accrued profits, accounted for under the percentage-of-completion method, net of progress billings.

[0001144204-17-061284:notes:29]
|  | I. | Inventories |

[0001144204-17-061284:notes:30]
Inventories are valued at the lower of cost (first-in, first-out) or market value. Inventories are regularly reviewed for excess quantities and obsolescence based upon historical experience, specific identification of discontinued items, future demand, and market conditions. Inventories under long-term contracts reflect accumulated production costs, factory overhead, initial tooling and other related costs less the portion of such costs charged to cost of sales.

[0001144204-17-061284:notes:31]
|  | J. | Property, Plant and Equipment |

[0001144204-17-061284:notes:32]
Property, plant and equipment are recorded at cost. Depreciation and amortization are computed primarily on a straight-line basis over the estimated useful lives of the assets: buildings,  10-40 years; machinery and equipment,  3-10 years; and office furniture and equipment,  3-10 years. Leasehold improvements are amortized over the remaining term of the applicable lease or their estimated useful lives, whichever is shorter. Long-lived tangible assets are reviewed for impairment whenever events or changes in business circumstances indicate the carrying value of the assets may not be recoverable. Impairment losses are recognized based on fair value.

[0001144204-17-061284:notes:33]
|  | K. | Leases |

[0001144204-17-061284:notes:34]
Lease agreements are evaluated to determine whether they are capital or operating leases in accordance with ASC 840, Leases (ASC 840). When any one of the four test criteria in ASC 840 is met, the lease then qualifies as a capital lease. Capital leases are capitalized at the lower of the net present value of the total amount payable under the leasing agreement (excluding finance charges) or the fair market value of the leased asset. Capital lease assets are depreciated on a straight-line basis, over a period consistent with the Company’s normal depreciation policy for tangible fixed assets. The Company allocates each lease payment between a reduction of the lease obligation and interest expense using the effective interest method. Rent expense for operating leases, which may include free rent or fixed escalation amounts in addition to minimum lease payments, is recognized on a straight-line basis over the duration of the lease term. Capital lease obligations are included within other long-term liabilities (long-term portion) and accrued other expenses (current portion).

[0001144204-17-061284:notes:35]
|  | L. | Goodwill and Other Long-Lived Assets |

[0001144204-17-061284:notes:36]
Goodwill represents the excess of purchase price over the fair value of net identifiable assets acquired in business acquisitions. Management annually reviews goodwill and other long-lived assets with indefinite useful lives for impairment or whenever events or changes in circumstances indicate the carrying amount may not be recoverable. If the Company determines that the carrying value of the long-lived asset may not be recoverable, a permanent impairment charge is recorded for the amount by which the carrying value of the long-lived asset exceeds its fair value. Fair value is measured based on a discounted cash flow method using a discount rate determined by Management to be commensurate with the risk inherent in the Company’s current business model.

[0001144204-17-061284:notes:37]
Other intangible assets represent costs allocated to identifiable intangible assets, principally customer relationships, capitalized software, patents, trademarks, and technology rights. Intangible assets with estimable useful lives are amortized over their respective estimated useful lives to their estimated residual values, and are reviewed for impairment whenever events or changes in business circumstances indicate the carrying value of the assets may not be recoverable. See Note 3 regarding goodwill and other intangible assets activity.

[0001144204-17-061284:notes:38]
|  | M. | Capitalized Software |

[0001144204-17-061284:notes:39]
The costs incurred for the development of computer software that will be sold, leased, or otherwise marketed are charged to expense when incurred as research and development until technological feasibility has been established for the product. Technological feasibility is typically established upon completion of a detailed program design. Costs incurred after this point are capitalized on a project-by-project basis. Capitalized costs consist of internal and external development costs. Upon general release of the product to customers, the Company ceases capitalization and begins amortization, which is calculated on a project-by-project basis as the greater of (1) the ratio of current gross revenues for a product to the total of current and anticipated future gross revenues for the product or (2) the straight-line method over the estimated economic life of the product. The Company generally amortizes the software development costs over a three-to-seven year period based upon the estimated future economic life of the product. Factors considered in determining the estimated future economic life of the product include anticipated future revenues, and changes in software and hardware technologies. Management annually reviews the carrying values of capitalized costs for impairment or whenever events or changes in circumstances indicate the carrying amount may not be recoverable. If expected cash flows are insufficient to recover the carrying amount of the asset, then an impairment loss is recognized to state the asset at its net realizable value.

[0001144204-17-061284:notes:40]
|  | N. | Income Taxes |

[0001144204-17-061284:notes:41]
Income taxes are accounted for under the asset and liability method. Deferred tax assets and liabilities are recognized for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. Deferred tax assets may be reduced by a valuation allowance if it is more likely than not that some portion or all of the deferred tax assets will not be realized. The effect on deferred tax assets and liabilities of a change in tax rates is recognized in income in the period that includes the enactment date. The Company regularly reviews its deferred tax assets for recoverability and establishes a valuation allowance when Management believes it is more likely than not such assets will not be recovered, taking into consideration historical operating results, expectations of future earnings, tax planning strategies, and the expected timing of the reversals of existing temporary differences.

[0001144204-17-061284:notes:42]
|  | O. | Research and Development Costs |

[0001144204-17-061284:notes:43]
Company-sponsored research and development costs include research and development and bid and proposal efforts related to the Company’s products and services. Company-sponsored product development costs are charged to expense when incurred. Customer-sponsored research and development costs incurred pursuant to contracts are accounted for similarly to other program costs. Customer-sponsored research and development costs refer to certain situations whereby customers provide funding to support specific contractually defined research and development costs. Total Company and customer-sponsored research and development expenses were approximately $14.0 million, $12.2 million and $18.1 million for 2017, 2016 and 2015, respectively. These expense amounts exclude certain engineering costs primarily associated with product line extensions, modifications and maintenance, which amounted to approximately $10.4 million, $8.2 million and $8.2 million for 2017, 2016 and 2015, respectively.

[0001144204-17-061284:notes:44]
|  | P. | Foreign Currency Translation |

[0001144204-17-061284:notes:45]
The financial statements of the Company’s foreign operations are translated into U.S. dollars in accordance with FASB ASC Topic 830, Foreign Currency Matters. The resulting translation adjustments are recorded as a separate component of accumulated other comprehensive income.

[0001144204-17-061284:notes:46]
|  | Q. | Earnings Per Share |

[0001144204-17-061284:notes:47]
Basic earnings per share is calculated using the weighted average number of common shares outstanding during the period. Diluted earnings per share is calculated using the weighted average number of common shares outstanding during the period plus shares issuable upon the assumed exercise of dilutive common share options and vesting of performance-accelerated restricted shares using the treasury stock method. There are no anti-dilutive shares.

[0001144204-17-061284:notes:48]
The number of shares used in the calculation of earnings per share for each year presented is as follows:

[0001144204-17-061284:notes:49]
| (in thousands) |  | 2017 |  | 2016 |  | 2015 |  |
| Weighted Average Shares Outstanding — Basic |  |  | 25,774 |  |  | 25,762 |  |  | 26,077 |  |
| Performance- Accelerated Restricted Stock |  |  | 221 |  |  | 206 |  |  | 188 |  |
| Shares — Diluted |  |  | 25,995 |  |  | 25,968 |  |  | 26,265 |  |

[0001144204-17-061284:notes:50]
|  | R. | Share-Based Compensation |

[0001144204-17-061284:notes:51]
The Company provides compensation benefits to certain key employees under several share-based plans providing for employee stock options and/or performance-accelerated restricted shares (restricted shares), and to non-employee directors under a non-employee directors compensation plan. Share-based payment expense is measured at the grant date based on the fair value of the award and is recognized on a straight-line basis over the requisite service period (generally the vesting period of the award).

[0001144204-17-061284:notes:52]
|  | S. | Accumulated Other Comprehensive Loss |

[0001144204-17-061284:notes:53]
Accumulated other comprehensive loss of $(27.3) million at September 30, 2017 consisted of $(28.9) million related to the pension net actuarial loss; $1.7 million related to currency translation adjustments; and $(0.1) million related to forward exchange contracts. Accumulated other comprehensive loss of $(39.3) million at September 30, 2016 consisted of $(34.5) million related to the pension net actuarial loss; $(4.7) million related to currency translation adjustments; and $(0.1) million related to forward exchange contracts.

[0001144204-17-061284:notes:54]
|  | T. | Deferred Revenue And Costs |

[0001144204-17-061284:notes:55]
Deferred revenue and costs are recorded when products or services have been provided or cash has been received but the criteria for revenue recognition have not been met. If there is a customer acceptance provision or there is uncertainty about customer acceptance, revenue and costs are deferred until the customer has accepted the product or service.

[0001144204-17-061284:notes:56]
|  | U. | Derivative Financial Instruments |

[0001144204-17-061284:notes:57]
All derivative financial instruments are reported on the balance sheet at fair value. The accounting for changes in fair value of a derivative instrument depends on whether it has been designated and qualifies as a hedge and on the type of hedge. For each derivative instrument designated as a cash flow hedge, the effective portion of the gain or loss on the derivative is deferred in accumulated other comprehensive income until recognized in earnings with the underlying hedged item. For each derivative instrument designated as a fair value hedge, the gain or loss on the derivative and the offsetting gain or loss on the hedged item are recognized immediately in earnings. Regardless of type, a fully effective hedge will result in no net earnings impact while the derivative is outstanding. To the extent that any hedge is ineffective at offsetting cash flow or fair value changes in the underlying hedged item, there could be a net earnings impact.

[0001144204-17-061284:notes:58]
|  | V. | Fair Value Measurements |

[0001144204-17-061284:notes:59]
Fair value is defined as the price at which an asset could be exchanged in a current transaction between knowledgeable, willing parties or the amount that would be paid to transfer a liability to a new obligor, not the amount that would be paid to settle the liability with the creditor. Where available, fair value is based on observable market prices or parameters or derived from such prices or parameters. Where observable prices or inputs are not available, valuation models are applied. These valuation techniques involve some level of Management estimation and judgment, the degree of which is dependent on the price transparency for the instruments or market and the instruments’ complexity.

[0001144204-17-061284:notes:60]
The accounting guidance establishes a three-level hierarchy for disclosure of fair value measurements, based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date, as follows:

[0001144204-17-061284:notes:61]
Level 1 – Inputs to the valuation methodology are quoted prices (unadjusted) for identical assets or liabilities in active markets.

[0001144204-17-061284:notes:62]
Level 2 –Inputs to the valuation methodology include quoted prices for similar assets and liabilities in active markets, and inputs that are observable for the asset or liability, either directly or indirectly, for substantially the full term of the financial instrument.

[0001144204-17-061284:notes:63]
Level 3 – Inputs to the valuation methodology are unobservable and significant to the fair value measurement.

[0001144204-17-061284:notes:64]
Financial Assets and Liabilities

[0001144204-17-061284:notes:65]
The Company has estimated the fair value of its financial instruments as of September 30, 2017 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables and other current assets and liabilities approximate fair value because of the short maturity of those instruments. The carrying amounts due under the revolving credit facility approximate fair value as the interest on outstanding borrowings is calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election.

[0001144204-17-061284:notes:66]
Nonfinancial Assets and Liabilities

[0001144204-17-061284:notes:67]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during 2017.

[0001144204-17-061284:notes:68]
|  | W. | New Accounting Standards |

[0001144204-17-061284:notes:69]
In January 2017, the FASB issued Accounting Standards Update (ASU) No. 2017-04, Simplifying the Test for Goodwill Impairment (ASU 2017-04), which eliminates Step 2 from the goodwill impairment test. Under the amendments in this update, an entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value; however, the loss recognized should not exceed the total amount of goodwill allocated to that reporting unit. The new standard is effective for fiscal years beginning after December 15, 2019. Early adoption is permitted for interim or annual goodwill impairment test performed on testing dates after January 1, 2017. The Company adopted this standard in the fourth quarter of 2017 with its annual goodwill impairment tests. The adoption of ASU 2017-04 did not have an impact on the Company’s consolidated financial statements.

[0001144204-17-061284:notes:70]
In March 2016, the FASB issued ASU No. 2016-09, Improvements to Employee Share-Based Payment Accounting, which simplified the income tax consequences, accounting for forfeitures and classification on the Statements of Consolidated Cash Flows. The Company adopted this standard in the current year resulting in the income tax expense in the third quarter and fiscal year 2017 being favorably impacted by additional tax benefits on share-based compensation that vested during the third quarter of 2017 decreasing the effective tax rate by  5.1% and  1.1%, respectively.

[0001144204-17-061284:notes:71]
In February 2016, the FASB issued ASU No. 2016-062, Leases (Topic 842), which, among other things, requires an entity to recognize lease assets and lease liabilities on the balance sheet and disclose key information about leasing arrangements. This new standard will increase an entity’s reported assets and liabilities. The new standard is effective for fiscal years beginning after December 15, 2018 and mandates a modified retrospective transition period for all entities. The Company is currently assessing the impact of this new standard on its consolidated financial statements and related disclosures.

[0001144204-17-061284:notes:72]
In November 2015, the FASB issued ASU No. 2015-17, Balance Sheet Classification of Deferred Taxes, which requires entities to present deferred tax assets and deferred tax liabilities as noncurrent in a classified balance sheet. This new standard is effective for annual periods beginning after December 15, 2016. The Company adopted this standard during the fourth quarter of 2016 and applied it on a prospective basis.

[0001144204-17-061284:notes:73]
In May 2014, the FASB issued ASU No. 2014-09, Revenue from Contracts with Customers, which requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. this guidance has been further clarified and amended. The new standard will be effective for annual reporting periods beginning after December 15, 2017, and interim periods within those annual periods. The standard permits the use of either the retrospective or cumulative effect transition method. The Company is currently in the process of calculating the effect that ASU 2014-09 will have on its consolidated financial statements and related disclosures. The Company has selected the Cumulative Effect method of transition to the new standard.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001144204-17-061284:notes:74]
| 3. | Goodwill and Other Intangible Assets |

[0001144204-17-061284:notes:75]
Included on the Company’s Consolidated Balance Sheets at September 30, 2017 and 2016 are the following intangible assets gross carrying amounts and accumulated amortization:

[0001144204-17-061284:notes:76]
| (Dollars in millions) |  | 2017 |  | 2016 |  |
| Goodwill |  | $ | 377.9 |  |  | 323.6 |  |
| Intangible assets with determinable lives: |  |  |  |  |  |  |  |
| Patents |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 1.0 |  |  | 1.0 |  |
| Less: accumulated amortization |  |  | 0.8 |  |  | 0.8 |  |
| Net |  | $ | 0.2 |  |  | 0.2 |  |
| Capitalized software |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 63.0 |  |  | 54.0 |  |
| Less: accumulated amortization |  |  | 34.4 |  |  | 26.7 |  |
| Net |  | $ | 28.6 |  |  | 27.3 |  |
| Customer Relationships |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 181.9 |  |  | 111.9 |  |
| Less: accumulated amortization |  |  | 37.4 |  |  | 28.6 |  |
| Net |  | $ | 144.5 |  |  | 83.3 |  |
| Other |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 5.4 |  |  | 2.8 |  |
| Less: accumulated amortization |  |  | 1.4 |  |  | 0.9 |  |
| Net |  | $ | 4.0 |  |  | 1.9 |  |
| Intangible assets with indefinite lives: |  |  |  |  |  |  |  |
| Trade names |  | $ | 173.8 |  |  | 119.1 |  |

[0001144204-17-061284:notes:77]
The Company performed its annual evaluation of goodwill and intangible assets for impairment during the fourth quarter of 2017 and concluded no impairment existed at September 30, 2017 and there are no accumulated impairment losses as of September 30, 2017.

[0001144204-17-061284:notes:78]
The changes in the carrying amount of goodwill attributable to each business segment for 2017 and 2016 are as follows:

[0001144204-17-061284:notes:79]
|  |  |  |  |  |  |  |  | Technical |  |  |  |
| (Dollars in millions) |  | Filtration |  | Test |  | USG |  | Packaging |  | Total |  |
| Balance as of September 30, 2015 |  | $ | 26.0 |  |  | 34.2 |  |  | 226.2 |  |  | 4.8 |  |  | 291.2 |  |
| Acquisition activity |  |  | 17.9 |  |  | – |  |  | – |  |  | 14.5 |  |  | 32.4 |  |
| Foreign currency translation and other |  |  | – |  |  | (0.1) |  |  | – |  |  | 0.1 |  |  | – |  |
| Balance as of September 30, 2016 |  |  | 43.9 |  |  | 34.1 |  |  | 226.2 |  |  | 19.4 |  |  | 323.6 |  |
| Acquisition activity |  |  | 29.8 |  |  | – |  |  | 23.6 |  |  | – |  |  | 53.4 |  |
| Foreign currency translation and other |  |  | – |  |  | – |  |  | 0.4 |  |  | 0.5 |  |  | 0.9 |  |
| Balance as of September 30, 2017 |  | $ | 73.7 |  |  | 34.1 |  |  | 250.2 |  |  | 19.9 |  |  | 377.9 |  |

[0001144204-17-061284:notes:80]
Amortization expense related to intangible assets with determinable lives was $16.3 million, $11.6 million and $8.9 million in 2017, 2016 and 2015, respectively. Patents are amortized over the life of the patents, generally 17 years. Capitalized software is amortized over the estimated useful life of the software, generally three to seven years. Customer relationships are generally amortized over fifteen to twenty years. Intangible asset amortization for fiscal years 2018 through 2022 is estimated at approximately $20 million per year.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001144204-17-061284:notes:81]
| 4. | Accounts Receivable |

[0001144204-17-061284:notes:82]
Accounts receivable, net of the allowance for doubtful accounts, consist of the following at September 30, 2017 and 2016:

[0001144204-17-061284:notes:83]
| (Dollars in thousands) |  | 2017 |  | 2016 |  |
| Commercial |  | $ | 152,265 |  |  | 112,280 |  |
| U.S. Government and prime contractors |  |  | 8,315 |  |  | 9,206 |  |
| Total |  | $ | 160,580 |  |  | 121,486 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001144204-17-061284:notes:84]
| 5. | Inventories |

[0001144204-17-061284:notes:85]
Inventories consist of the following at September 30, 2017 and 2016:

[0001144204-17-061284:notes:86]
| (Dollars in thousands) |  | 2017 |  | 2016 |  |
| Finished goods |  | $ | 28,127 |  |  | 20,502 |  |
| Work in process |  |  | 43,750 |  |  | 37,922 |  |
| Raw materials |  |  | 52,638 |  |  | 47,118 |  |
| Total |  | $ | 124,515 |  |  | 105,542 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001144204-17-061284:notes:87]
| 7. | Income Tax Expense |

[0001144204-17-061284:notes:88]
Total income tax expense (benefit) for 2017, 2016 and 2015 was allocated to income tax expense as follows:

[0001144204-17-061284:notes:89]
| (Dollars in thousands) |  | 2017 |  | 2016 |  | 2015 |  |
| Income tax expense from Continuing Operations |  | $ | 26,450 |  |  | 22,538 |  |  | 19,785 |  |
| Income tax expense from Discontinued Operations |  |  | – |  |  | – |  |  | 390 |  |
| Total income tax expense |  | $ | 26,450 |  |  | 22,538 |  |  | 20,175 |  |

[0001144204-17-061284:notes:90]
The components of income from continuing operations before income taxes for 2017, 2016 and 2015 consisted of the following:

[0001144204-17-061284:notes:91]
| (Dollars in thousands) |  | 2017 |  | 2016 |  | 2015 |  |
| United States |  | $ | 72,353 |  |  | 62,353 |  |  | 56,661 |  |
| Foreign |  |  | 7,800 |  |  | 6,067 |  |  | 4,860 |  |
| Total income before income taxes |  | $ | 80,153 |  |  | 68,420 |  |  | 61,521 |  |

[0001144204-17-061284:notes:92]
The principal components of income tax expense (benefit) from continuing operations for 2017, 2016 and 2015 consist of:

[0001144204-17-061284:notes:93]
| (Dollars in thousands) |  | 2017 |  | 2016 |  | 2015 |  |
| Federal: |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 21,448 |  |  | 19,236 |  |  | 11,906 |  |
| Deferred |  |  | 628 |  |  | (909) |  |  | 5,406 |  |
| State and local: |  |  |  |  |  |  |  |  |  |  |
| Current |  |  | 1,795 |  |  | 1,674 |  |  | 867 |  |
| Deferred |  |  | (49) |  |  | (222) |  |  | 16 |  |
| Foreign: |  |  |  |  |  |  |  |  |  |  |
| Current |  |  | 4,450 |  |  | 1,899 |  |  | 1,525 |  |
| Deferred |  |  | (1,822) |  |  | 860 |  |  | 65 |  |
| Total |  | $ | 26,450 |  |  | 22,538 |  |  | 19,785 |  |

[0001144204-17-061284:notes:94]
The actual income tax expense (benefit) from continuing operations for 2017, 2016 and 2015 differs from the expected tax expense for those years (computed by applying the U.S. Federal corporate statutory rate) as follows:

[0001144204-17-061284:notes:95]
|  |  | 2017 |  | 2016 |  | 2015 |  |
| Federal corporate statutory rate |  |  | 35.0 | % |  | 35.0 | % |  | 35.0 | % |
| State and local, net of Federal benefits |  |  | 2.4 |  |  | 2.0 |  |  | 1.2 |  |
| Foreign |  |  | (0.1) |  |  | (1.0) |  |  | (1.5) |  |
| Research credit |  |  | (1.1) |  |  | (2.5) |  |  | (1.8) |  |
| Domestic production deduction |  |  | (2.7) |  |  | (2.8) |  |  | (2.6) |  |
| Change in uncertain tax positions |  |  | – |  |  | – |  |  | (0.2) |  |
| Executive compensation |  |  | (0.1) |  |  | 0.9 |  |  | 0.9 |  |
| Valuation allowance |  |  | (0.3) |  |  | 1.8 |  |  | 1.0 |  |
| Other, net |  |  | (0.1) |  |  | (0.5) |  |  | 0.2 |  |
| Effective income tax rate |  |  | 33.0 | % |  | 32.9 | % |  | 32.2 | % |

[0001144204-17-061284:notes:96]
The tax effects of temporary differences that give rise to significant portions of the deferred tax assets and liabilities at September 30, 2017 and 2016 are presented below:

[0001144204-17-061284:notes:97]
| (Dollars in thousands) |  | 2017 |  | 2016 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |
| Inventories |  | $ | 9,639 |  |  | 7,553 |  |
| Pension and other postretirement benefits |  |  | 11,345 |  |  | 13,978 |  |
| Net operating and capital loss carryforwards — domestic |  |  | 501 |  |  | 372 |  |
| Net operating loss carryforward — foreign |  |  | 4,486 |  |  | 4,991 |  |
| Other compensation-related costs and other cost accruals |  |  | 12,104 |  |  | 13,678 |  |
| State credit carryforward |  |  | 2,098 |  |  | 1,944 |  |
| Total deferred tax assets |  |  | 40,173 |  |  | 42,516 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |
| Goodwill |  |  | (4,874) |  |  | (15,528) |  |
| Acquisition assets |  |  | (91,752) |  |  | (69,934) |  |
| Depreciation, software amortization |  |  | (24,092) |  |  | (20,285) |  |
| Net deferred tax liabilities before valuation allowance |  |  | (80,545) |  |  | (63,231) |  |
| Less valuation allowance |  |  | (4,440) |  |  | (5,711) |  |
| Net deferred tax liabilities |  | $ | (84,985) |  |  | (68,942) |  |

[0001144204-17-061284:notes:98]
The Company has a foreign net operating loss (NOL) carryforward of $18.2 million at September 30, 2017, which reflects tax loss carryforwards in Germany, India, Finland, China, South Africa, Japan, Canada and the United Kingdom. $15.0 million of the tax loss carryforwards have no expiration date while the remaining $3.2 million will expire between 2019 and 2038. The Company has deferred tax assets related to state NOL carryforwards of $0.5 million at September 30, 2017 which expire between 2025 and 2037. The Company also has net state research and other credit carryforwards of $2.1 million of which $1.7 million expires between 2025 and 2037. The remaining $0.4 million does not have an expiration date.

[0001144204-17-061284:notes:99]
The valuation allowance for deferred tax assets as of September 30, 2017 and 2016 was $4.4 million and $5.7 million, respectively. The net change in the total valuation allowance for each of the years ended September 30, 2017 and 2016 was a decrease of $1.3 million and an increase of $1.6 million, respectively. The Company has established a valuation allowance against state credit carryforwards of $0.4 million and $0.6 million at September 30, 2017 and 2016. In addition, the Company has established a valuation allowance against state NOL carryforwards that are not expected to be realized in future periods of $0.4 million and $0.3 million at September 30, 2017 and 2016. Lastly, the Company has established a valuation allowance against certain NOL carryforwards in foreign jurisdictions which may not be realized in future periods. The valuation allowance established against the foreign NOL carryforwards was $3.7 million and $4.8 million at September 30, 2017 and 2016, respectively.

[0001144204-17-061284:notes:100]
ETS-Lindgren Oy, Finland, has recorded a deferred tax asset of $0.3 million reflecting the benefit of $2.8 million in loss carryforwards, which expire in varying amounts between 2024 and 2027. Realization is dependent on generating sufficient taxable income prior to expiration of the loss carryforwards. Although realization is not assured, Management believes it is more likely than not that all of the deferred tax asset will be realized. The amount of the deferred tax asset considered realizable, however, could be reduced in the near term if estimates of future taxable income during the carryforward period are reduced.

[0001144204-17-061284:notes:101]
The Company’s foreign subsidiaries have accumulated unremitted earnings of $48.9 million and cash of $28.4 million at September 30, 2017. No deferred taxes have been provided on these accumulated unremitted earnings because these funds are not needed to meet the liquidity requirements of the Company’s U.S. operations and it is the Company’s intention to indefinitely reinvest these earnings in continuing international operations. In the event these foreign entities’ earnings were distributed, it is estimated that U.S. taxes, net of available foreign tax credits, of approximately $6.9 million would be due, which would correspondingly reduce the Company’s net earnings. No significant portion of the Company’s foreign subsidiaries’ earnings was taxed at a very low tax rate.

[0001144204-17-061284:notes:102]
The Company had $0.1 million of unrecognized benefits as of both September 30, 2017 and 2016, which, if recognized, would affect the Company’s effective tax rate. The Company does not anticipate a material change in the amount of unrecognized tax benefits in the next 12 months. The Company’s policy is to include interest related to unrecognized tax benefits in income tax expense and penalties in operating expense. As of September 30, 2017, 2016 and 2015, the Company had zero accrued interest related to uncertain tax positions on its Consolidated Balance Sheets. No significant penalties have been accrued.

[0001144204-17-061284:notes:103]
The principal jurisdictions for which the Company files income tax returns are U.S. Federal and the various city, state, and international locations where the Company has operations. The U.S. Federal tax years for the periods ended September 30, 2014 and forward remain subject to income tax examination. Various state tax years for the periods ended September 30, 2013 and forward remain subject to income tax examinations. The Company is subject to income tax in many jurisdictions outside the United States, none of which is individually significant.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001144204-17-061284:notes:104]
Debt consists of the following at September 30, 2017 and 2016:

[0001144204-17-061284:notes:105]
| (Dollars in thousands) |  | 2017 |  | 2016 |  |
| Revolving credit facility, including current portion |  | $ | 275,000 |  |  | 110,000 |  |
| Current portion of long-term debt |  |  | (20,000) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 255,000 |  |  | 90,000 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001144204-17-061284:notes:106]
| 9. | Capital Stock |

[0001144204-17-061284:notes:107]
The  30,468,824 and  30,364,183 common shares as presented in the accompanying Consolidated Balance Sheets at September 30, 2017 and 2016 represent the actual number of shares issued at the respective dates. The Company held  4,635,622 and  4,647,322 common shares in treasury at September 30, 2017 and 2016, respectively.

[0001144204-17-061284:notes:108]
In August 2012, the Company’s Board of Directors authorized a common stock repurchase program under which the Company may repurchase shares of its stock from time to time in its discretion, in the open market or otherwise, up to a maximum total repurchase amount of $100 million (or such lesser amount as may be permitted under the Company’s bank credit agreements). This program has been repeatedly extended by the Company’s Board of Directors and is currently scheduled to expire September 30, 2019. There were no share repurchases in 2017. The Company repurchased approximately  120,000 shares for $4.3 million in 2016 and  517,000 shares for $18.2 million in 2015.


## us-gaap:ScheduleOfNonvestedShareActivityTableTextBlock

[0001144204-17-061284:notes:109]
The following summary presents information regarding outstanding PARS awards as of the specified dates, and changes during the specified periods:

[0001144204-17-061284:notes:110]
|  |  | FY 2017 |  | FY 2016 |  | FY 2015 |  |
|  |  |  |  | Estimated |  |  |  | Estimated |  |  |  | Estimated |  |
|  |  |  |  | Weighted |  |  |  | Weighted |  |  |  | Weighted |  |
|  |  | Shares |  | Avg. Price |  | Shares |  | Avg. Price |  | Shares |  | Avg. Price |  |
| Nonvested at October 1, |  |  | 427,438 |  | $ | 35.40 |  |  | 326,536 |  | $ | 35.29 |  |  | 332,340 |  | $ | 32.23 |  |
| Granted |  |  | 110,422 |  |  | 51.16 |  |  | 120,902 |  |  | 35.75 |  |  | 123,501 |  |  | 34.33 |  |
| Vested |  |  | (202,035) |  |  | 35.78 |  |  | (8,000) |  |  | 36.06 |  |  | (129,305) |  |  | 26.66 |  |
| Cancelled |  |  | – |  |  | – |  |  | (12,000) |  |  | 35.47 |  |  | – |  |  | – |  |
| Nonvested at September 30, |  |  | 335,825 |  | $ | 40.35 |  |  | 427,438 |  | $ | 35.40 |  |  | 326,536 |  | $ | 35.29 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001144204-17-061284:notes:111]
| 12. | Derivative Financial Instruments |

[0001144204-17-061284:notes:112]
Market risks relating to the Company’s operations result primarily from changes in interest rates and changes in foreign currency exchange rates. The Company is exposed to market risk related to changes in interest rates and selectively uses derivative financial instruments, including forward contracts and swaps, to manage these risks. During 2016, the Company entered into several forward contracts to purchase pounds sterling (GBP) to hedge two deferred payments due in connection with the acquisition of Plastique. In addition, the Company’s Canadian subsidiary Morgan Schaffer enters into foreign exchange contracts to manage foreign currency risk as a portion of their revenue is denominated in U.S. dollars. The Company expects hedging gains or losses to be essentially offset by losses or gains on the related underlying exposures. The amounts ultimately recognized may differ for open positions, which remain subject to ongoing market price fluctuations until settlement. For derivative instruments designated as cash flow hedges, the gain or loss on the derivative is deferred in accumulated other comprehensive income until recognized in earnings with the underlying hedged item. The fair value of the foreign currency derivative is classified in accrued expenses on the Company’s Consolidated Balance Sheets. The forward contracts listed below will be recognized within the next twelve months except for  700 GBP which will be recognized in 2019. The following is a summary of the notional transaction amounts and fair values for the Company’s outstanding derivative financial instruments as of September 30, 2017.

[0001144204-17-061284:notes:113]
|  |  | Notional Amount |  | Fair Value |  |
| (In thousands) |  | (Currency) |  | (US$) |  |
| Forward contracts |  | 1,859 GBP |  |  | (173) |  |
| Forward contracts |  | 3,250 USD |  |  | 149 |  |
| Forward contracts |  | 200 EUR |  |  | (5) |  |

[0001144204-17-061284:notes:114]
Fair value of financial instruments

[0001144204-17-061284:notes:115]
The Company’s forward contracts are classified within Level 2 of the valuation hierarchy in accordance with FASB Accounting Standards Codification (ASC) 825, as presented below as of September 30, 2017:

[0001144204-17-061284:notes:116]
| (In thousands) |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Forward contracts |  | $ | – |  |  | (29) |  |  | – |  |  | (29) |  |

[0001144204-17-061284:notes:117]
Valuation was based on third party evidence of similarly priced derivative instruments. There are no master netting arrangements with financial parties.


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001144204-17-061284:notes:118]
Long-Lived Assets

[0001144204-17-061284:notes:119]
| (Dollars in millions) |  |  |  |  |  |
| Year ended September 30, |  | 2017 |  | 2016 |  |
| United States |  | $ | 111.5 |  |  | 79.9 |  |
| Europe |  |  | 16.8 |  |  | 11.7 |  |
| Other |  |  | 4.4 |  |  | 0.8 |  |
| Consolidated totals |  | $ | 132.7 |  |  | 92.4 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001144204-17-061284:notes:120]
Geographic Information

[0001144204-17-061284:notes:121]
Net Sales

[0001144204-17-061284:notes:122]
| (Dollars in millions) |  |  |  |  |  |  |  |
| Year ended September 30, |  | 2017 |  | 2016 |  | 2015 |  |
| United States |  | $ | 503.1 |  |  | 403.6 |  |  | 385.5 |  |
| Asia |  |  | 69.8 |  |  | 68.1 |  |  | 70.4 |  |
| Europe |  |  | 75.4 |  |  | 71.6 |  |  | 46.6 |  |
| Canada |  |  | 22.2 |  |  | 12.9 |  |  | 11.6 |  |
| India |  |  | 4.8 |  |  | 2.9 |  |  | 4.3 |  |
| Other |  |  | 10.4 |  |  | 12.4 |  |  | 18.9 |  |
| Consolidated totals |  | $ | 685.7 |  |  | 571.5 |  |  | 537.3 |  |


## ese:ScheduleOfDepreciationAndAmortizationsTableTextBlock

[0001144204-17-061284:notes:123]
Depreciation and Amortization

[0001144204-17-061284:notes:124]
| (Dollars in millions) |  |  |  |  |  |  |  |
| Year ended September 30, |  | 2017 |  | 2016 |  | 2015 |  |
| Filtration |  | $ | 6.6 |  |  | 4.0 |  |  | 3.8 |  |
| Test |  |  | 3.6 |  |  | 3.6 |  |  | 3.1 |  |
| USG |  |  | 9.8 |  |  | 8.1 |  |  | 6.2 |  |
| Technical Packaging |  |  | 3.5 |  |  | 2.9 |  |  | 1.4 |  |
| Corporate |  |  | 8.7 |  |  | 5.0 |  |  | 4.1 |  |
| Consolidated totals |  | $ | 32.2 |  |  | 23.6 |  |  | 18.6 |  |


## ese:ScheduleOfCapitalExpenditureTableTextBlock

[0001144204-17-061284:notes:125]
Capital Expenditures

[0001144204-17-061284:notes:126]
| (Dollars in millions) |  |  |  |  |  |  |  |
| Year ended September 30, |  | 2017 |  | 2016 |  | 2015 |  |
| Filtration |  | $ | 10.2 |  |  | 3.3 |  |  | 5.0 |  |
| Test |  |  | 4.5 |  |  | 3.3 |  |  | 3.1 |  |
| USG |  |  | 7.6 |  |  | 3.3 |  |  | 3.3 |  |
| Technical Packaging |  |  | 7.4 |  |  | 3.9 |  |  | 1.0 |  |
| Corporate |  |  | – |  |  | – |  |  | – |  |
| Consolidated totals |  | $ | 29.7 |  |  | 13.8 |  |  | 12.4 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001144204-17-061284:notes:127]
| (Dollars in millions) |  |  |  |  |  |  |  |
| Year ended September 30, |  | 2017 |  | 2016 |  | 2015 |  |
| Filtration |  | $ | 279.5 |  |  | 207.8 |  |  | 196.7 |  |
| Test |  |  | 160.9 |  |  | 161.5 |  |  | 177.6 |  |
| USG |  |  | 162.4 |  |  | 127.8 |  |  | 123.6 |  |
| Technical Packaging |  |  | 82.9 |  |  | 74.4 |  |  | 39.4 |  |
| Consolidated totals |  | $ | 685.7 |  |  | 571.5 |  |  | 537.3 |  |

[0001144204-17-061284:notes:128]
No customer exceeded  10% of sales in 2017 or 2016.

[0001144204-17-061284:notes:129]
EBIT

[0001144204-17-061284:notes:130]
| (Dollars in millions) |  |  |  |  |  |  |  |
| Year ended September 30, |  | 2017 |  | 2016 |  | 2015 |  |
| Filtration |  | $ | 52.2 |  |  | 45.2 |  |  | 41.7 |  |
| Test |  |  | 19.5 |  |  | 13.9 |  |  | 9.5 |  |
| USG |  |  | 36.6 |  |  | 31.1 |  |  | 29.6 |  |
| Technical Packaging |  |  | 8.5 |  |  | 9.6 |  |  | 4.9 |  |
| Reconciliation to consolidated totals (Corporate) |  |  | (32.1) |  |  | (30.1) |  |  | (23.4) |  |
| Consolidated EBIT |  |  | 84.7 |  |  | 69.7 |  |  | 62.3 |  |
| Less: interest expense |  |  | (4.6) |  |  | (1.3) |  |  | (0.8) |  |
| Earnings before income tax |  | $ | 80.1 |  |  | 68.4 |  |  | 61.5 |  |


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0001144204-17-061284:notes:131]
Identifiable Assets

[0001144204-17-061284:notes:132]
| (Dollars in millions) |  |  |  |  |  |
| Year ended September 30, |  | 2017 |  | 2016 |  |
| Filtration |  | $ | 194.2 |  |  | 143.5 |  |
| Test |  |  | 132.2 |  |  | 110.9 |  |
| USG |  |  | 175.5 |  |  | 85.4 |  |
| Technical Packaging |  |  | 47.1 |  |  | 40.9 |  |
| Corporate – Goodwill |  |  | 377.9 |  |  | 323.6 |  |
| Corporate – Other assets |  |  | 333.5 |  |  | 274.1 |  |
| Consolidated totals |  | $ | 1,260.4 |  |  | 978.4 |  |


## us-gaap:ScheduleOfFutureMinimumRentalPaymentsForOperatingLeasesTableTextBlock

[0001144204-17-061284:notes:133]
Future aggregate minimum lease payments under operating leases that have initial or remaining non-cancelable lease terms in excess of one year as of September 30, 2017, are:

[0001144204-17-061284:notes:134]
| (Dollars in thousands) |  |  |  |
| Years ending September 30: |  |  |  |
| 2018 |  |  | 6,361 |  |
| 2019 |  |  | 5,340 |  |
| 2020 |  |  | 3,733 |  |
| 2021 |  |  | 2,653 |  |
| 2022 and thereafter |  |  | 3,647 |  |
| Total |  | $ | 21,734 |  |


## us-gaap:CapitalLeasesInFinancialStatementsOfLesseeDisclosureTextBlock

[0001144204-17-061284:notes:135]
| 15. | Capital Leases |

[0001144204-17-061284:notes:136]
The Company leases certain real property, equipment and machinery under capital leases, primarily associated with the 2017 acquisitions of NRG and Mayday. The facility leases expire in  2029 and the machinery leases expire in  2020. As of September 30, 2017, the net carrying value and accumulated depreciation of the assets under capital leases recorded by the Company were $16.1 million and $0.8 million, respectively. Capital lease obligations are included within other long-term liabilities (long-term portion) and accrued other expenses (current portion).  Remaining payments due on the Company’s capital lease obligations as of September 30, 2017, are:

[0001144204-17-061284:notes:137]
| (Dollars in thousands) |  |  |  |
| Years ending September 30: |  |  |  |
| 2018 |  | $ | 1,883 |  |
| 2019 |  |  | 1,922 |  |
| 2020 |  |  | 1,914 |  |
| 2021 |  |  | 1,858 |  |
| 2022 and thereafter |  |  | 15,977 |  |
| Total minimum lease payments |  |  | 23,554 |  |
| Less: amounts representing interest |  |  | 4,233 |  |
| Present value of net minimum lease payments |  |  | 19,321 |  |
| Current portion of capital lease obligations |  |  | 1,370 |  |
| Non-current portion of capital lease obligations |  | $ | 17,951 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001144204-17-061284:notes:138]
| 16. | Quarterly Financial Information (Unaudited) |

[0001144204-17-061284:notes:139]
|  |  | First |  | Second |  | Third |  | Fourth |  | Fiscal |  |
| (Dollars in thousands, except per share amounts) |  | Quarter |  | Quarter |  | Quarter |  | Quarter |  | Year |  |
| 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 146,368 |  |  | 161,178 |  |  | 171,189 |  |  | 207,005 |  |  | 685,740 |  |
| Net earnings |  |  | 10,727 |  |  | 11,157 |  |  | 12,645 |  |  | 19,174 |  |  | 53,703 |  |
| Basic earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings |  |  | 0.42 |  |  | 0.43 |  |  | 0.49 |  |  | 0.74 |  |  | 2.08 |  |
| Diluted earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings |  |  | 0.41 |  |  | 0.43 |  |  | 0.49 |  |  | 0.74 |  |  | 2.07 |  |
| Dividends declared per common share |  | $ | 0.08 |  |  | 0.08 |  |  | 0.08 |  |  | 0.08 |  |  | 0.32 |  |
| 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 132,833 |  |  | 138,930 |  |  | 140,191 |  |  | 159,505 |  |  | 571,459 |  |
| Net earnings |  |  | 8,829 |  |  | 8,610 |  |  | 11,528 |  |  | 16,915 |  |  | 45,882 |  |
| Basic earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings |  |  | 0.34 |  |  | 0.33 |  |  | 0.45 |  |  | 0.66 |  |  | 1.78 |  |
| Diluted earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings |  |  | 0.34 |  |  | 0.33 |  |  | 0.44 |  |  | 0.65 |  |  | 1.77 |  |
| Dividends declared per common share |  | $ | 0.08 |  |  | 0.08 |  |  | 0.08 |  |  | 0.08 |  |  | 0.32 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001144204-17-061284:notes:140]
| 11. | Retirement and Other Benefit Plans |

[0001144204-17-061284:notes:141]
Substantially all domestic employees were covered by a defined contribution pension plan maintained by the Company. Effective December 31, 2003, the Company’s defined benefit plan was frozen and no additional benefits have been accrued after that date. As a result, the accumulated benefit obligation and projected benefit obligation are equal. These frozen retirement income benefits are provided to employees under defined benefit pay-related and flat-dollar plans, which are noncontributory. The annual contributions to the defined benefit retirement plan equal or exceed the minimum funding requirements of the Employee Retirement Income Security Act. In addition to providing retirement income benefits, the Company provides unfunded postretirement health and life insurance benefits to certain retirees. To qualify, an employee must retire at age 55 or later and the employee’s age plus service must equal or exceed 75. Retiree contributions are defined as a percentage of medical premiums. Consequently, retiree contributions increase with increases in the medical premiums. The life insurance plans are noncontributory and provide coverage of a flat dollar amount for qualifying retired employees. Effective December 31, 2004, no new retirees were eligible for life insurance benefits.

[0001144204-17-061284:notes:142]
The Company uses a measurement date of September 30 for its pension and other postretirement benefit plans. The Company has an accrued benefit liability of $0.6 million and $0.7 million at September 30, 2017 and 2016, respectively, related to its other postretirement benefit obligations. All other information related to its postretirement benefit plans is not considered material to the Company’s results of operations or financial condition.

[0001144204-17-061284:notes:143]
The following tables provide a reconciliation of the changes in the pension plans and fair value of assets over the two-year period ended September 30, 2017, and a statement of the funded status as of September 30, 2017 and 2016:

[0001144204-17-061284:notes:144]
| (Dollars in millions) |  |  |  |  |  |
| Reconciliation of benefit obligation |  | 2017 |  | 2016 |  |
| Net benefit obligation at beginning of year |  | $ | 100.6 |  |  | 93.6 |  |
| Interest cost |  |  | 3.2 |  |  | 3.9 |  |
| Actuarial (gain) loss |  |  | (4.1) |  |  | 11.1 |  |
| Gross benefits paid |  |  | (4.4) |  |  | (7.8) |  |
| Settlements |  |  | – |  |  | (0.2) |  |
| Net benefit obligation at end of year |  | $ | 95.3 |  |  | 100.6 |  |

[0001144204-17-061284:notes:145]
| (Dollars in millions) |  |  |  |  |  |
| Reconciliation of fair value of plan assets |  | 2017 |  | 2016 |  |
| Fair value of plan assets at beginning of year |  | $ | 60.6 |  |  | 63.0 |  |
| Actual return on plan assets |  |  | 5.9 |  |  | 5.1 |  |
| Employer contributions |  |  | 2.9 |  |  | 0.5 |  |
| Gross benefits paid |  |  | (4.4) |  |  | (7.8) |  |
| Settlements |  |  | – |  |  | (0.2) |  |
| Fair value of plan assets at end of year |  | $ | 65.0 |  |  | 60.6 |  |

[0001144204-17-061284:notes:146]
| (Dollars in millions) |  |  |  |  |  |
| Funded Status |  | 2017 |  | 2016 |  |
| Funded status at end of year |  | $ | (30.3) |  |  | (40.0) |  |
| Accrued benefit cost |  |  | (30.3) |  |  | (40.0) |  |
| Amounts recognized in the Balance Sheet consist of: |  |  |  |  |  |  |  |
| Current liability |  |  | (0.2) |  |  | (0.2) |  |
| Noncurrent liability |  |  | (30.1) |  |  | (39.8) |  |
| Accumulated other comprehensive (income)/loss (before tax effect) |  |  | 47.4 |  |  | 56.0 |  |
| Amounts recognized in accumulated other comprehensive (income)/loss consist of: |  |  |  |  |  |  |  |
| Net actuarial loss |  |  | 47.4 |  |  | 56.0 |  |
| Accumulated other comprehensive (income)/loss (before tax effect) |  | $ | 47.4 |  |  | 56.0 |  |

[0001144204-17-061284:notes:147]
The estimated amount that will be amortized from accumulated other comprehensive (income) loss into net periodic benefit cost (income) in 2018 is $2.3 million.

[0001144204-17-061284:notes:148]
The following table provides the components of net periodic benefit cost for the plans for 2017, 2016 and 2015:

[0001144204-17-061284:notes:149]
| (Dollars in millions) |  | 2017 |  | 2016 |  | 2015 |  |
| Service cost |  | $ | – |  |  | – |  |  | – |  |
| Interest cost |  |  | 3.2 |  |  | 3.9 |  |  | 3.8 |  |
| Expected return on plan assets |  |  | (3.9) |  |  | (4.4) |  |  | (4.5) |  |
| Net actuarial loss |  |  | 2.6 |  |  | 2.0 |  |  | 1.8 |  |
| Net periodic benefit cost |  |  | 1.9 |  |  | 1.5 |  |  | 1.1 |  |
| Defined contribution plans |  |  | 6.3 |  |  | 5.2 |  |  | 5.0 |  |
| Total |  | $ | 8.2 |  |  | 6.7 |  |  | 6.1 |  |

[0001144204-17-061284:notes:150]
The discount rate used in measuring the Company’s pension obligations was developed by matching yields of actual high-quality corporate bonds to expected future pension plan cash flows (benefit payments). Over 400 Aa-rated, non-callable bonds with a wide range of maturities were used in the analysis. After using the bond yields to determine the present value of the plan cash flows, a single representative rate that resulted in the same present value was developed. The expected long-term rate of return on plan assets assumption was determined by reviewing the actual investment return of the plans since inception and evaluating those returns in relation to expectations of various investment organizations to determine whether long-term future returns are expected to differ significantly from the past.

[0001144204-17-061284:notes:151]
The following weighted-average assumptions were used to determine the net periodic benefit cost for the pension plans:

[0001144204-17-061284:notes:152]
|  |  | 2017 |  | 2016 |  | 2015 |  |
| Discount rate |  |  | 3.25 | % |  | 4.25 | % |  | 4.25 | % |
| Rate of increase in compensation levels |  |  | N/A |  |  | N/A |  |  | N/A |  |
| Expected long-term rate of return on assets |  |  | 3.25 | % |  | 6.75 | % |  | 6.75 | % |

[0001144204-17-061284:notes:153]
The following weighted-average assumptions were used to determine the net periodic benefit obligations for the pension plans:

[0001144204-17-061284:notes:154]
|  |  | 2017 |  | 2016 |  |
| Discount rate |  |  | 3.65 | % |  | 3.25 | % |
| Rate of increase in compensation levels |  |  | N/A |  |  | N/A |  |

[0001144204-17-061284:notes:155]
The assumed rate of increase in compensation levels is not applicable in 2017, 2016 and 2015 as the plan was frozen in earlier years.

[0001144204-17-061284:notes:156]
The asset allocation for the Company’s pension plans at the end of 2017 and 2016, and the Company’s acceptable range and the target allocation for 2018, by asset category, are as follows:

[0001144204-17-061284:notes:157]
|  |  | Target |  |  |  |  | Percentage of Plan Assets at |  |
|  |  | Allocation |  | Acceptable |  | Year-end |  |
| Asset Category |  | 2018 |  | Range |  | 2017 |  | 2016 |  |
| Return seeking |  |  | 60 | % |  | 55-65 | % |  | 62 | % |  | 59 | % |
| Liability hedging |  |  | 40 | % |  | 35-45 | % |  | 35 | % |  | 38 | % |
| Cash/cash equivalents |  |  | – |  |  | 0-5 | % |  | 3 | % |  | 3 | % |

[0001144204-17-061284:notes:158]
The Company’s pension plan assets are managed by outside investment managers and assets are rebalanced when the target ranges are exceeded. Pension plan assets consist principally of funds which invest in marketable securities including common stocks, bonds, and interest-bearing deposits. The Company’s investment strategy with respect to pension assets is to achieve a total rate of return (income and capital appreciation) that is sufficient to accomplish the purpose of providing retirement benefits to all eligible and future retirees of the pension plan. The Company regularly monitors performance and compliance with investment guidelines.

[0001144204-17-061284:notes:159]
Fair Value of Financial Measurements

[0001144204-17-061284:notes:160]
The fair values of the Company’s defined benefit plan investments as of September 30, 2017 and 2016, by asset category, were as follows:

[0001144204-17-061284:notes:161]
| (Dollars in millions) |  | 2017 |  | 2016 |  |
| Investments at fair value: |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1.9 |  |  | 1.6 |  |
| Common and preferred stock funds: |  |  |  |  |  |  |  |
| Domestic large capitalization |  |  | 10.6 |  |  | 8.9 |  |
| Domestic small-/mid-capitalization |  |  | 3.3 |  |  | 2.7 |  |
| International funds |  |  | 14.3 |  |  | 12.3 |  |
| Fixed income funds |  |  | 30.7 |  |  | 30.6 |  |
| Real estate investment funds |  |  | 4.2 |  |  | 4.5 |  |
| Total investments at fair value |  | $ | 65.0 |  |  | 60.6 |  |

[0001144204-17-061284:notes:162]
The following methods were used to estimate the fair value of each class of financial instrument:

[0001144204-17-061284:notes:163]
Cash and cash equivalents: The carrying value of cash represents fair value as it consists of actual currency.

[0001144204-17-061284:notes:164]
Investment Funds: The fair value of the investment funds, which offer daily redemptions, is determined based on the published net asset value of the funds as a practical expedient for fair value.

[0001144204-17-061284:notes:165]
Expected Cash Flows

[0001144204-17-061284:notes:166]
Information about the expected cash flows for the pension and other postretirement benefit plans follows:

[0001144204-17-061284:notes:167]
|  |  | Pension |  | Other |  |
| (Dollars in millions) |  | Benefits |  | Benefits |  |
| Expected Employer Contributions — 2018 |  | $ | 3.0 |  |  | 0.1 |  |
| Expected Benefit Payments: |  |  |  |  |  |  |  |
| 2018 |  |  | 4.9 |  |  | 0.1 |  |
| 2019 |  |  | 5.1 |  |  | 0.1 |  |
| 2020 |  |  | 5.7 |  |  | 0.1 |  |
| 2021 |  |  | 5.4 |  |  | 0.1 |  |
| 2022 |  |  | 5.6 |  |  | 0.1 |  |
| 2023-2027 |  | $ | 29.5 |  |  | 0.3 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001144204-17-061284:notes:168]
| 6. | Related Parties |

[0001144204-17-061284:notes:169]
One of the Company’s directors is an officer at a customer of the Company’s subsidiary Doble. Doble sells products, leases equipment and provides testing services to the customer in the ordinary course of Doble’s business. The total amount of these sales were approximately $3.6 million, $1.4 million and $0.8 million during fiscal 2017, 2016 and 2015, respectively. All transactions between Doble and the customer are intended to be and have been consistent with Doble’s normal commercial terms offered to its customers, and the Company’s Board of Directors has determined that the relationship between the Company and the customer is not material and did not impair either the Company’s or the director’s independence.


## us-gaap:DebtDisclosureTextBlock

[0001144204-17-061284:notes:170]
| 8. | Debt |

[0001144204-17-061284:notes:171]
The Company’s existing credit facility (“the Credit Facility”) matures December 21, 2020. The Credit Facility includes a $450 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of nine banks led by JP Morgan Chase Bank, N.A., as Administrative Agent.

[0001144204-17-061284:notes:172]
At September 30, 2017, the Company had approximately $166 million available to borrow under the Credit Facility, plus the $250 million increase option, in addition to $45.5 million cash on hand. The Company classified $20.0 million as the current portion of long-term debt as of September 30, 2017, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months.

[0001144204-17-061284:notes:173]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from  12.5 to  27.5 basis points per annum on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a  65% pledge of its material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. As of September 30, 2017, the Company was in compliance with all bank covenants.

[0001144204-17-061284:notes:174]
During 2017 and 2016, the maximum aggregate short-term borrowings at any month-end were $298 million and $110 million, respectively, and the average aggregate short-term borrowings outstanding based on month-end balances were $211.3 million and $89.2 million, respectively. The weighted average interest rates were  2.09%,  1.58% and  1.27% for 2017, 2016 and 2015, respectively. The letters of credit issued and outstanding under the Credit Facility totaled $9.7 million and $4.9 million at September 30, 2017 and 2016, respectively.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001144204-17-061284:notes:175]
| 10. | Share-Based Compensation |

[0001144204-17-061284:notes:176]
The Company provides compensation benefits to certain key employees under several share-based plans providing for performance-accelerated restricted share unit (PARS) awards, and to non-employee directors under a non-employee directors compensation plan. The Company has no stock options currently outstanding. As of September 30, 2017, the Company had  1,072,401 shares available for future issuance under equity compensation plans.

[0001144204-17-061284:notes:177]
Performance-Accelerated Restricted Share Unit Awards

[0001144204-17-061284:notes:178]
A PARS award represents the right to receive a specified number of shares of Company common stock if and when the award vests. A PARS award is not stock and does not give the recipient any rights as a shareholder until it vests and is paid out in shares of stock. PARS awards currently outstanding have a five-year vesting period, with accelerated vesting if certain targets based on market conditions are achieved. In these cases, if it is probable that the performance condition will be met, the Company recognizes compensation cost on a straight-line basis over the shorter performance period; otherwise, it will recognize compensation cost over the longer service period. Compensation cost for the majority of the outstanding PARS awards is being recognized over the shorter performance period as it is probable the performance condition will be met. The PARS award grants were valued at the stock price on the date of grant. Pretax compensation expense related to the PARS awards for continuing operations was $4.4 million, $3.9 million and $4.0 million for 2017, 2016 and 2015, respectively.

[0001144204-17-061284:notes:179]
Non-Employee Directors Plan

[0001144204-17-061284:notes:180]
In 2017 the non-employee directors compensation plan provided to each non-employee director a retainer of  900 common shares per quarter. Non-employee director grants were valued at the stock price on the date of grant and were issued from the Company’s treasury stock. Compensation expense related to the non-employee director grants was $1.0 million, $0.8 million and $0.8 million for 2017, 2016 and 2015, respectively.

[0001144204-17-061284:notes:181]
Total Share-Based Compensation

[0001144204-17-061284:notes:182]
The total share-based compensation cost that has been recognized in results of operations and included within SG&A from continuing operations was $5.4 million, $4.7 million and $4.8 million for 2017, 2016 and 2015, respectively. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $1.8 million, $1.3 million and $1.6 million for 2017, 2016 and 2015, respectively. As of September 30, 2017, there was $6.3 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a weighted-average period of  1.5years.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001144204-17-061284:notes:183]
| 14. | Commitments and Contingencies |

[0001144204-17-061284:notes:184]
The Company leases certain real property, equipment and machinery under non-cancelable operating leases. Rental expense under these operating leases was $6.8 million, $6.0 million and $5.2 million for 2017, 2016 and 2015, respectively. Future aggregate minimum lease payments under operating leases that have initial or remaining non-cancelable lease terms in excess of one year as of September 30, 2017, are:

[0001144204-17-061284:notes:185]
At September 30, 2017, the Company had $9.7 million in letters of credit outstanding as guarantees of contract performance. As a normal incident of the businesses in which the Company is engaged, various claims, charges and litigation are asserted or commenced from time to time against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. It is the opinion of Management that the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company are adequately accrued, are covered by insurance or are not likely to have a material adverse effect on the Company’s results from continuing operations, capital expenditures or competitive position.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001144204-17-061284:notes:186]
| 13. | Business Segment Information |

[0001144204-17-061284:notes:187]
The Company is organized based on the products and services it offers, and classifies its business operations in segments for financial reporting purposes. Currently, the Company has four reporting segments: Filtration/Fluid Flow (Filtration), RF Shielding and Test (Test), Utility Solutions Group (USG) and Technical Packaging.

[0001144204-17-061284:notes:188]
The Filtration segment’s operations consist of: PTI Technologies Inc. (PTI), VACCO Industries (VACCO), Crissair, Inc. (Crissair), Mayday Manufacturing Co. (Mayday), Hi-Tech Metals, Inc. (Hi-Tech) and Westland Technologies, Inc. (Westland). PTI, VACCO and Crissair design and manufacture specialty filtration products including hydraulic filter elements and fluid control devices used in commercial aerospace applications, unique filter mechanisms used in micro-propulsion devices for satellites and custom designed filters for manned aircraft and submarines. Mayday designs and manufactures mission-critical bushings, pins, sleeves and precision-tolerance machined components for landing gear, rotor heads, engine mounts, flight controls, and actuation systems for the aerospace and defense industries. Hi-Tech is a full-service metal processor offering aerospace OEM’s and Tier 1 suppliers, a large portfolio of processing services including anodizing, cadmium and zinc-nickel plating, organic coatings, non-destructive testing, and heat treatment. Westland designs, develops and manufactures elastomeric-based signature reduction solutions for U.S. naval vessels.

[0001144204-17-061284:notes:189]
The Test segment’s operations consist of ETS-Lindgren Inc. and related subsidiaries (ETS-Lindgren). ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy. ETS-Lindgren also manufactures radio frequency shielding products and components used by manufacturers of medical equipment, communications systems, electronic products, and shielded rooms for high-security data processing and secure communication.

[0001144204-17-061284:notes:190]
The USG segment’s operations consist of Doble Engineering Company and related subsidiaries (Doble), Morgan Schaffer Ltd. (Morgan Schaffer), and NRG Systems, Inc. (NRG). Doble provides high-end, intelligent diagnostic test solutions for the electric power delivery industry and is a leading supplier of power factor and partial discharge testing instruments used to assess the integrity of high-voltage power delivery equipment. Morgan Schaffer provides an integrated offering of dissolved gas analysis, oil testing, and data management solutions which enhance the ability of electric utilities to accurately monitor the health of critical power transformers. NRG designs and manufactures decision support tools for the renewable energy industry, primarily wind.

[0001144204-17-061284:notes:191]
The Technical Packaging segment’s operations consist of Thermoform Engineered Quality LLC (TEQ) and Plastique. The companies within this segment provide innovative solutions to the medical and commercial markets for thermoformed and precision molded pulp fiber packages and specialty products using a wide variety of thin gauge plastics and pulp.

[0001144204-17-061284:notes:192]
Accounting policies of the segments are the same as those described in the summary of significant accounting policies in Note 1 to the Consolidated Financial Statements. The operating units within each reporting segment have been aggregated because of similar economic characteristics and meet the other aggregation criteria of FASB ASC 280.

[0001144204-17-061284:notes:193]
The Company evaluates the performance of its operating units based on EBIT, which is defined as earnings before interest and taxes. EBIT on a consolidated basis is a non-GAAP financial measure; see “Non-GAAP Financial Measures” in Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations.” Intersegment sales and transfers are not significant. Segment assets consist primarily of customer receivables, inventories, capitalized software and fixed assets directly associated with the production processes of the segment. Segment depreciation and amortization is based upon the direct assets listed above.

[0001144204-17-061284:notes:194]
Corporate assets consist primarily of goodwill, deferred taxes, acquired intangible assets and cash balances.

[0001144204-17-061284:notes:195]
In addition to the above amounts, the Company incurred expenditures for capitalized software of $9.0 million, $8.7 million and $6.9 million in 2017, 2016 and 2015, respectively.

[0001144204-17-061284:notes:196]
Depreciation expense of property, plant and equipment was $15.9 million, $11.9 million and $9.7 million for 2017, 2016 and 2015, respectively.

[0001144204-17-061284:notes:197]
Net sales are attributed to countries based on location of customer. Long-lived assets are attributed to countries based on location of the asset.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001144204-17-061284:notes:198]
| 2. | Acquisitions |

[0001144204-17-061284:notes:199]
2017

[0001144204-17-061284:notes:200]
On August 30, 2017, the Company acquired the assets of Vanguard Instruments Company (Vanguard Instruments), a test equipment provider serving the global electric utility market, located in Ontario, California, for a purchase price of $36.0 million in cash. Vanguard Instruments has annualized sales of approximately $14 million. Since the date of acquisition, the operating results for Vanguard Instruments have been included as a product line of Doble within the Company’s USG segment. Based on the preliminary purchase price allocation, the Company recorded approximately $1.8 million of accounts receivable, $2.1 million of inventory, $0.3 million of property, plant and equipment, $0.2 million of accounts payable and accrued expenses, $10.7 million of goodwill, $3.2 million of tradenames and $18.0 million of amortizable intangible assets consisting of customer relationships with a weighted average life of  15 years.

[0001144204-17-061284:notes:201]
On May 25, 2017, the Company acquired the assets of Morgan Schaffer Inc. (Morgan Schaffer), a global utilities provider located in Montreal, Quebec, Canada, for a purchase price of $48.8 million in cash. Morgan Schaffer has annualized sales of approximately $25 million. It designs, develops, manufactures and markets an integrated offering of dissolved gas analysis, oil testing, and data management solutions which enhance the ability of electric utilities to accurately monitor the health of critical power transformers. Since the date of acquisition, the operating results for Morgan Schaffer have been included in the Company’s USG segment. Based on the preliminary purchase price allocation, the Company recorded approximately $2.5 million of accounts receivable, $5.2 million of inventory, $1.7 million of property, plant and equipment, $0.4 million of other assets, $4.9 million of accounts payable and accrued expenses, $4.8 million of goodwill, $35.6 million of trade names and $3.6 million of amortizable intangible assets consisting of customer relationships and developed technology with a weighted average life of approximately 10 years.

[0001144204-17-061284:notes:202]
On May 8, 2017, the Company acquired NRG Systems, Inc. (NRG), located in Hinesburg, Vermont, for a purchase price of $38.6 million in cash. NRG is the global market leader in the design and manufacture of decision support tools for the renewable energy industry, primarily wind. NRG has annualized sales of approximately $45 million. Since the date of acquisition, the operating results for NRG have been included in the Company’s USG segment. Based on the preliminary purchase price allocation, the Company recorded approximately $1.5 million of cash, $4.1 million of accounts receivable, $5.1 million of inventory, $1.0 million of other assets, $9.4 million of property, plant and equipment (including a capital lease), $4.1 million of accounts payable and accrued expenses, $9.7 million of lease liability, $8.0 million of goodwill, $8.1 million of trade names and $17.2 million of amortizable intangible assets consisting of customer relationships with a weighted average life of approximately  14 years.

[0001144204-17-061284:notes:203]
On November 7, 2016, the Company acquired aerospace suppliers Mayday Manufacturing Co. (Mayday) and its affiliate, Hi-Tech Metals, Inc. (Hi-Tech), which share a state-of-the-art, expandable  130,000 square foot facility in Denton, Texas, for a purchase price of approximately $75 million in cash. Mayday is a leading manufacturer of mission-critical bushings, pins, sleeves and precision-tolerance machined components for landing gear, rotor heads, engine mounts, flight controls and actuation systems for the aerospace and defense industry. Hi-Tech is a full-service metal processor offering aerospace OEM’s and Tier 1 suppliers a large portfolio of processing services including anodizing, cadmium and zinc-nickel plating, organic coatings, non-destructive testing and heat treatment. Mayday and Hi-Tech together have annual sales of approximately $40 million. Since the date of acquisition, the consolidated operating results for Mayday and Hi-Tech have been included in the Company’s Filtration segment. Based on the purchase price allocation, the Company recorded approximately $7.3 million of accounts receivable, $10.6 million of inventory, $16.6 million of property, plant and equipment (including a capital lease), $10.1 million of lease liability, $15.6 million of deferred tax liabilities, $30.2 million of goodwill, $4.8 million of trade names and $32.8 million of amortizable identifiable intangible assets consisting primarily of customer relationships with a weighted-average life of approximately 20 years.

[0001144204-17-061284:notes:204]
2016

[0001144204-17-061284:notes:205]
On September 2, 2016, the Company acquired the stock of Westland Technologies, Inc. (Westland), located in Modesto, California, for a purchase price of approximately $41 million in cash. Westland is a market leader in the design, development and manufacture of elastomeric-based signature reduction solutions which enhance U.S. Naval maritime platform survivability. Westland has annual sales of approximately $25 million. Since the date of acquisition, the operating results for Westland have been included within the Company’s Filtration segment. Based on the purchase price allocation, the Company recorded tangible assets, net, of $5.5 million, deferred tax liabilities of $9.5 million, goodwill of $17.9 million, and $28.3 million of identifiable intangible assets primarily consisting of customer relationships.

[0001144204-17-061284:notes:206]
On January 29, 2016, the Company acquired Plastique Limited and Plastique Sp. z o.o. (together, Plastique), headquartered in Tunbridge Wells, England with manufacturing locations in Nottingham, England and Poznan, Poland, for a purchase price of approximately $31.6 million (of which $2.7 million is due over the next two years, one payment in January 2018 and one in January 2019). Plastique is a market leader in the development and manufacture of highly-technical thermoformed plastic and precision molded pulp fiber packaging primarily serving pharmaceutical, personal care, and various specialty end markets. Since the date of acquisition, the operating results for Plastique have been included within the Company’s Technical Packaging segment. Plastique has annual sales of approximately $35 million. Based on the purchase price allocation, the Company recorded tangible assets, net, of $9.6 million, goodwill of $10.2 million, and $11.9 million of identifiable intangible assets primarily consisting of customer relationships.

[0001144204-17-061284:notes:207]
On October 16, 2015, the Company acquired the stock of Fremont Plastics, Inc. (Fremont) for a purchase price of $10.5 million in cash. The Company also purchased for $2 million Fremont’s real property located in Fremont, Indiana. Fremont was a developer, manufacturer, promoter and seller of high quality sterile-ready and non-sterile thin gauge thermoformed medical plastic packaging products. Immediately following the closing of the transaction, Fremont was merged into TEQ, and therefore since the date of acquisition the operating results for Fremont have been included as part of TEQ.

[0001144204-17-061284:notes:208]
2015

[0001144204-17-061284:notes:209]
On January 28, 2015, the Company acquired the assets of Enoserv LLC (Enoserv), headquartered in Tulsa, Oklahoma, for $20.5 million in cash. Enoserv provides utility customers with high quality, user-friendly multi-platform software and has annual revenues of approximately $8 million. Since the date of acquisition the operating results for Enoserv have been included as part of Doble within the Company’s USG segment. Based on the purchase price allocation, the Company recorded approximately $10.0 million of goodwill and $9.0 million of amortizable identifiable intangible assets consisting primarily of customer relationships and developed technology.

[0001144204-17-061284:notes:210]
All of the Company’s acquisitions have been accounted for using the purchase method of accounting and accordingly, the respective purchase prices were allocated to the assets (including intangible assets) acquired and liabilities assumed based on estimated fair values at the date of acquisition. The financial results from these acquisitions have been included in the Company’s financial statements from the date of acquisition.

[0001144204-17-061284:notes:211]
Unaudited pro forma sales and earnings before tax were $746.0 million and $84.5 million, respectively, for 2017, and $695.0 million and $76.2 million, respectively, for 2016. These pro forma amounts reflect the Company’s consolidated results of operations as if the 2017 acquisitions of Vanguard Instruments, Morgan Schaffer, NRG and Mayday had occurred on October 1, 2015. The pro forma financial information was prepared based on historical financial information and has been adjusted to give effect to pro forma adjustments that are (i) directly attributable to the above acquisitions, (ii) factually supportable and (iii) expected to have a continuing impact on the combined results. The pro forma information uses estimates and assumptions based on information available at the time. Management believes the estimates and assumptions to be reasonable; however, actual results may differ significantly from this pro forma information. The pro forma information is not intended to reflect the actual results that would have occurred had the companies actually been combined during the periods presented. The pro forma results for the years ended September 30, 2017 and 2016 primarily include additional amortization expense related to the fair value of acquired identifiable intangible assets and additional interest expense related to the incremental debt issued in conjunction with the 2017 acquisitions. The pro forma results for the year ended September 30, 2017 also included non-recurring adjustments of $3.8 million related to additional costs of goods sold due to the increase of inventory to fair value at the acquisition date in connection with the preliminary purchase accounting for inventory.

[0001144204-17-061284:notes:212]
The goodwill recorded for the Mayday, Westland, Plastique and Fremont acquisitions mentioned above is not expected to be deductible for U.S. Federal or state income tax purposes. The goodwill recorded for the Vanguard Instruments, NRG and Enoserv acquisitions mentioned above is expected to be deductible for U.S. Federal and state income tax purposes. The goodwill recorded for the Morgan Schaffer acquisition is expected to be deductible for Canadian income tax purposes.
