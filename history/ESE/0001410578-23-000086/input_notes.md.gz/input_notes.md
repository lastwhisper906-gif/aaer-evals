# ESE notes — 0001410578-23-000086


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001410578-23-000086:notes:1]
[same as prior period, unchanged from 0001410578-22-002168:notes:1]

[0001410578-23-000086:notes:2]
The accompanying consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP).

[0001410578-23-000086:notes:3]
The Company’s results for the three-month period ended December 31, 2022 are not necessarily indicative of the results for the entire 2023 fiscal year. References to the first quarters of 2023 and 2022 represent the fiscal quarters ended December 31, 2022 and 2021, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:EarningsPerShareTextBlock

[0001410578-23-000086:notes:4]
[same as prior period, unchanged from 0001410578-22-002168:notes:4]

[0001410578-23-000086:notes:5]
[same as prior period, unchanged from 0001410578-22-002168:notes:5]

[0001410578-23-000086:notes:6]
| ​ |  | Three Months |
| ​ | ​ | Ended December 31, |
| ​ |  | 2022 |  | 2021 |
| Weighted Average Shares Outstanding — Basic |  | 25,863 |  | 26,060 |
| Dilutive Restricted Shares | ​ | 80 | ​ | 82 |
| Adjusted Shares — Diluted |  | 25,943 |  | 26,142 |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001410578-23-000086:notes:7]
3.    SHARE-BASED COMPENSATION

[0001410578-23-000086:notes:8]
The Company provides compensation benefits to certain key employees under several share-based plans providing for performance-accelerated and/or time-vested restricted stock unit awards, and to non-employee directors under a separate compensation plan for non-employee directors.

[0001410578-23-000086:notes:9]
Performance-Accelerated Restricted Stock Unit (PARS) Awards, Time-Vested Restricted Stock Unit (RSU) Awards, and Performance Share Unit (PSU) Awards

[0001410578-23-000086:notes:10]
Compensation expense related to these awards was $1.6 million and $1.4 million for the three-month periods ended December 31, 2022 and 2021, respectively. There were 223,233 non-vested shares outstanding as of December 31, 2022.

[0001410578-23-000086:notes:11]
[same as prior period, unchanged from 0001410578-22-002168:notes:13]

[0001410578-23-000086:notes:12]
Compensation expense related to the non-employee director grants was $0.3 million and $0.3 million for the three-month periods ended December 31, 2022 and 2021, respectively.

[0001410578-23-000086:notes:13]
The total share-based compensation cost that has been recognized in the results of operations and included within selling, general and administrative expenses (SG&A) was $1.9 million and $1.7 million for the three-month periods ended December 31, 2022 and 2021, respectively. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $0.1 million and $0.4 million for the three-month periods ended December 31, 2022 and 2021, respectively. As of December 31, 2022 there was $12.0 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a remaining weighted-average period of 2.0 years.


## us-gaap:InventoryDisclosureTextBlock

[0001410578-23-000086:notes:14]
4.    INVENTORIES

[0001410578-23-000086:notes:15]
[same as prior period, unchanged from 0001410578-22-002168:notes:17]

[0001410578-23-000086:notes:16]
| ​ | ​ | December 31, | ​ | September 30, |
| (In thousands) |  | 2022 |  | 2022 |
| Finished goods | ​ | $ | 31,723 |  | 32,471 |
| Work in process | ​ |  | 46,514 |  | 38,492 |
| Raw materials | ​ |  | 103,506 |  | 91,440 |
| Total inventories, net | ​ | $ | 181,743 |  | 162,403 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001410578-23-000086:notes:17]
| 5. | GOODWILL AND OTHER INTANGIBLE ASSETS |

[0001410578-23-000086:notes:18]
Included on the Company’s Consolidated Balance Sheets at December 31, 2022 and September 30, 2022 are the following intangible assets gross carrying amounts and accumulated amortization from continuing operations:

[0001410578-23-000086:notes:19]
| ​ |  | December 31, |  | September 30, |
| (Dollars in thousands) |  | 2022 |  | 2022 |
| Goodwill | ​ | $ | 498,383 |  | 492,709 |
| Intangible assets with determinable lives: | ​ |  | ​ | ​ | ​ |
| Patents | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 2,373 | ​ | 2,353 |
| Less: accumulated amortization | ​ |  | 1,122 | ​ | 1,091 |
| Net | ​ | $ | 1,251 | ​ | 1,262 |
| Capitalized software | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 109,379 | ​ | 106,583 |
| Less: accumulated amortization | ​ |  | 72,605 | ​ | 70,476 |
| Net | ​ | $ | 36,774 | ​ | 36,107 |
| Customer relationships | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 291,067 | ​ | 287,447 |
| Less: accumulated amortization | ​ |  | 100,910 | ​ | 96,921 |
| Net | ​ | $ | 190,157 | ​ | 190,526 |
| Other | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 14,322 | ​ | 13,985 |
| Less: accumulated amortization | ​ |  | 8,066 | ​ | 7,440 |
| Net | ​ | $ | 6,256 | ​ | 6,545 |
| Intangible assets with indefinite lives: | ​ |  | ​ | ​ | ​ |
| Trade names | ​ | $ | 160,386 | ​ | 160,024 |

[0001410578-23-000086:notes:20]
The changes in the carrying amount of goodwill attributable to each business segment for the three months ended December 31, 2022 is as follows:

[0001410578-23-000086:notes:21]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | Aerospace | ​ | ​ |
| (Dollars in millions) |  | USG |  | Test |  | & Defense |  | Total |
| Balance as of September 30, 2022 | ​ | $ | 348.7 |  | ​ | 34.0 |  | 110.0 |  | 492.7 |
| Foreign currency translation | ​ | ​ | 5.7 | ​ | ​ | — | ​ | — | ​ | 5.7 |
| Balance as of December 31, 2022 | ​ | $ | 354.4 | ​ | ​ | 34.0 | ​ | 110.0 | ​ | 498.4 |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001410578-23-000086:notes:22]
6.    BUSINESS SEGMENT INFORMATION

[0001410578-23-000086:notes:23]
The Company is organized based on the products and services that it offers and classifies its business operations in three reportable segments for financial reporting purposes: Aerospace & Defense (A&D), Utility Solutions Group (USG) and RF Shielding and Test (Test).The A&D segment’s operations consist of PTI Technologies Inc. (PTI), VACCO Industries (VACCO), Crissair, Inc. (Crissair), Mayday Manufacturing Co. (Mayday), Westland Technologies, Inc. (Westland) and Globe Composite Solutions, LLC (Globe). The companies within this segment primarily design and manufacture specialty filtration, fluid control and naval products, including hydraulic filter elements and fluid control devices used in aerospace and defense applications; unique filter mechanisms used in micro-propulsion devices for satellites, custom designed filters for manned aircraft and submarines, products and systems to reduce vibration and/or acoustic signatures and otherwise reduce or obscure a vessel’s signature, and other communications, sealing, surface control and hydrodynamic related applications to enhance U.S. Navy maritime survivability; precision-tolerance machined components for the aerospace and defense industry; and metal processing services.

[0001410578-23-000086:notes:24]
The USG segment’s operations consist primarily of Doble Engineering Company and related subsidiaries including Morgan Schaffer and Altanova (collectively, Doble), and NRG Systems, Inc. (NRG). Doble is an industry leader in the development, manufacture and delivery of diagnostic testing and data management solutions that enable electric power grid operators to assess the integrity of high voltage power delivery equipment. It combines three core elements for customers – diagnostic test and condition monitoring instruments, expert consulting, and testing services – and provides access to its large reserve of related empirical knowledge. NRG is a global market leader in the design and manufacture of decision support tools for the renewable energy industry, primarily wind and solar.

[0001410578-23-000086:notes:25]
[same as prior period, unchanged from 0001410578-22-002168:notes:28]

[0001410578-23-000086:notes:26]
Management evaluates and measures the performance of its reportable segments based on “Net Sales” and “EBIT”, which are detailed in the table below. EBIT is defined as earnings from continuing operations before interest and taxes. The table below is presented on the basis of continuing operations and excludes discontinued operations.

[0001410578-23-000086:notes:27]
| ​ | ​ | Three Months |
| ​ | ​ | Ended December 31, |
| (In thousands) |  | 2022 |  | 2021 |
| NET SALES | ​ | ​ |  | ​ |  |
| Aerospace & Defense | ​ | $ | 82,983 | ​ | 70,244 |
| USG | ​ | ​ | 71,045 | ​ | 63,485 |
| Test | ​ | ​ | 51,473 | ​ | 43,281 |
| Consolidated totals | ​ | $ | 205,501 | ​ | 177,010 |
| EBIT | ​ | ​ | ​ | ​ | ​ |
| Aerospace & Defense | ​ | $ | 12,536 | ​ | 9,955 |
| USG | ​ | ​ | 16,131 | ​ | 13,391 |
| Test | ​ | ​ | 5,411 | ​ | 3,965 |
| Corporate (loss) | ​ | ​ | (13,521) | ​ | (11,741) |
| Consolidated EBIT | ​ | ​ | 20,557 | ​ | 15,570 |
| Less: Interest expense | ​ | ​ | (1,658) | ​ | (733) |
| Earnings before income taxes | ​ | $ | 18,899 | ​ | 14,837 |

[0001410578-23-000086:notes:28]
[same as prior period, unchanged from 0001410578-22-002168:notes:31]

[0001410578-23-000086:notes:29]
[same as prior period, unchanged from 0001410578-22-002168:notes:32]

[0001410578-23-000086:notes:30]
[same as prior period, unchanged from 0001410578-22-002168:notes:33]


## us-gaap:DebtDisclosureTextBlock

[0001410578-23-000086:notes:31]
7.    DEBT

[0001410578-23-000086:notes:32]
The Company’s debt is summarized as follows:

[0001410578-23-000086:notes:33]
| ​ |  | December 31, | ​ | September 30, |
| (In thousands) |  | 2022 |  | 2022 |
| Total borrowings | ​ | $ | 132,000 |  | 153,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 112,000 |  | 133,000 |

[0001410578-23-000086:notes:34]
The Credit Facility includes a $500 million revolving line of credit, as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024, with balance due by this date.

[0001410578-23-000086:notes:35]
At December 31, 2022, the Company had approximately $360 million available to borrow under the Credit Facility, plus the $250 million increase option subject to lenders’ consent, in addition to $51.9 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of December 31, 2022, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $8.2 million at December 31, 2022.

[0001410578-23-000086:notes:36]
Interest on borrowings under the Credit Facility is calculated at a spread over either the New York Federal Reserve Bank Rate, the prime rate, or the London Interbank Offered Rate (LIBOR), depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The interest rate spreads on the facility and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio.  The weighted average interest rates were 4.56% and 1.17% for the three-month periods ending December 31, 2022 and 2021, respectively. As of December 31, 2022, the Company was in compliance with all covenants.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001410578-23-000086:notes:37]
8.    INCOME TAX EXPENSE

[0001410578-23-000086:notes:38]
The first quarter 2023 effective income tax rate was 22.1% compared to 22.3% in the first quarter of 2022. The income tax expense in the first quarter of 2023 was favorably impacted by excess tax benefit related to the vesting of share-based compensation and the release of a valuation allowance on acquired federal net operating losses, decreasing the effective tax rate for the quarter by 1.3%.Income tax expense in the first quarter of 2022 was favorably impacted by excess tax benefit related to the vesting of share-based compensation, decreasing the effective tax rate for the quarter by 1.7%.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001410578-23-000086:notes:39]
9.    SHAREHOLDERS’ EQUITY

[0001410578-23-000086:notes:40]
The change in shareholders’ equity for the first three months ended December 31, 2022 and 2021 is shown below (in thousands):

[0001410578-23-000086:notes:41]
| ​ | ​ | Three Months Ended December 31, |
| ​ |  | 2022 |  | 2021 |
| Common stock | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | $ | 307 | ​ | 307 |
| Stock plans | ​ | ​ | — | ​ | — |
| Ending balance | ​ | ​ | 307 | ​ | 307 |
| Additional paid-in-capital | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | 301,553 | ​ | 297,644 |
| Stock plans | ​ | ​ | (856) | ​ | (1,367) |
| Ending balance | ​ | ​ | 300,697 | ​ | 296,277 |
| Retained earnings | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | 905,022 | ​ | 830,989 |
| Net earnings common stockholders | ​ | ​ | 14,727 | ​ | 11,524 |
| Dividends paid | ​ | ​ | (2,067) | ​ | (2,079) |
| Ending balance | ​ | ​ | 917,682 | ​ | 840,434 |
| Accumulated other comprehensive income (loss) | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | (31,764) | ​ | (2,161) |
| Foreign currency translation | ​ | ​ | 11,513 | ​ | (2,500) |
| Ending balance | ​ | ​ | (20,251) | ​ | (4,661) |
| Treasury stock | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | (126,961) | ​ | (107,083) |
| Share repurchases | ​ | ​ | (5,076) | ​ | (9,997) |
| Ending balance | ​ | ​ | (132,037) | ​ | (117,080) |
| Total equity | ​ | $ | 1,066,398 | ​ | 1,015,277 |


## us-gaap:FairValueDisclosuresTextBlock

[0001410578-23-000086:notes:42]
10.  FAIR VALUE MEASUREMENTS

[0001410578-23-000086:notes:43]
[same as prior period, unchanged from 0001410578-22-002168:notes:46]

[0001410578-23-000086:notes:44]
[same as prior period, unchanged from 0001410578-22-002168:notes:47]

[0001410578-23-000086:notes:45]
[same as prior period, unchanged from 0001410578-22-002168:notes:48]

[0001410578-23-000086:notes:46]
[same as prior period, unchanged from 0001410578-22-002168:notes:49]

[0001410578-23-000086:notes:47]
[same as prior period, unchanged from 0001410578-22-002168:notes:50]

[0001410578-23-000086:notes:48]
The Company has estimated the fair value of its financial instruments as of December 31, 2022 and September 30, 2022 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001410578-23-000086:notes:49]
[same as prior period, unchanged from 0001410578-22-002168:notes:52]

[0001410578-23-000086:notes:50]
[same as prior period, unchanged from 0001410578-22-002168:notes:53]

[0001410578-23-000086:notes:51]
[same as prior period, unchanged from 0001410578-22-002168:notes:54]

[0001410578-23-000086:notes:52]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during the three-month period ended December 31, 2022.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001410578-23-000086:notes:53]
11.  REVENUES

[0001410578-23-000086:notes:54]
[same as prior period, unchanged from 0001410578-22-002168:notes:57]

[0001410578-23-000086:notes:55]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2022 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within each reportable segment.

[0001410578-23-000086:notes:56]
| ​ | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 36,740 | ​ | $ | 70,162 | ​ | $ | 45,992 | ​ | $ | 152,894 |
| U.S. Government | ​ |  | 46,243 | ​ |  | 883 | ​ |  | 5,481 | ​ |  | 52,607 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 68,934 | ​ | $ | 46,379 | ​ | $ | 27,503 | ​ | $ | 142,816 |
| International | ​ |  | 14,049 | ​ |  | 24,666 | ​ |  | 23,970 | ​ |  | 62,685 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 33,604 | ​ | $ | 56,031 | ​ | $ | 9,101 | ​ | $ | 98,736 |
| Over time | ​ |  | 49,379 | ​ |  | 15,014 | ​ |  | 42,372 | ​ |  | 106,765 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |

[0001410578-23-000086:notes:57]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2021 are presented in the table below:

[0001410578-23-000086:notes:58]
| ​ | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial |  | $ | 28,075 | ​ | $ | 62,842 | ​ | $ | 41,037 | ​ | $ | 131,954 |
| U.S. Government | ​ | ​ | 42,169 | ​ |  | 643 | ​ |  | 2,244 | ​ |  | 45,056 |
| Total revenues |  | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 |
| Geographic location: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States |  | $ | 60,687 | ​ | $ | 38,741 | ​ | $ | 22,975 | ​ | $ | 122,403 |
| International | ​ | ​ | 9,557 | ​ |  | 24,744 | ​ |  | 20,306 | ​ |  | 54,607 |
| Total revenues |  | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 |
| Revenue recognition method: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time |  | $ | 28,558 | ​ | $ | 50,835 | ​ | $ | 12,821 | ​ | $ | 92,214 |
| Over time | ​ | ​ | 41,686 | ​ |  | 12,650 | ​ |  | 30,460 | ​ |  | 84,796 |
| Total revenues |  | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 |

[0001410578-23-000086:notes:59]
[same as prior period, unchanged from 0001410578-22-002168:notes:64]

[0001410578-23-000086:notes:60]
[same as prior period, unchanged from 0001410578-22-002168:notes:65]

[0001410578-23-000086:notes:61]
[same as prior period, unchanged from 0001410578-22-002168:notes:66]

[0001410578-23-000086:notes:62]
[same as prior period, unchanged from 0001410578-22-002168:notes:67]

[0001410578-23-000086:notes:63]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At December 31, 2022, the Company had $718.4 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 80% in the next twelve months.

[0001410578-23-000086:notes:64]
[same as prior period, unchanged from 0001410578-22-002168:notes:69]

[0001410578-23-000086:notes:65]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred. At December 31, 2022, contract assets and liabilities totaled $122.5 million and $133.6 million, respectively. During the first quarter of 2023, the Company recognized approximately $31.0 million in revenues that were included in the contract liabilities balance at September 30, 2022. At September 30, 2022, contract assets and liabilities totaled $125.2 million and $137.6 million, respectively.


## ese:OperatingAndFinancingLeasesOfLesseeDisclosureTextBlock

[0001410578-23-000086:notes:66]
12.  LEASES

[0001410578-23-000086:notes:67]
[same as prior period, unchanged from 0001410578-22-002168:notes:72]

[0001410578-23-000086:notes:68]
[same as prior period, unchanged from 0001410578-22-002168:notes:73]

[0001410578-23-000086:notes:69]
In addition to the base rent, real estate leases typically contain provisions for common-area maintenance and other similar services, which are considered non-lease components for accounting purposes. Non-lease components are excluded from ROU assets and lease liabilities and expensed as incurred.

[0001410578-23-000086:notes:70]
[same as prior period, unchanged from 0001410578-22-002168:notes:75]

[0001410578-23-000086:notes:71]
[same as prior period, unchanged from 0001410578-22-002168:notes:76]

[0001410578-23-000086:notes:72]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended |
| ​ | ​ | December 31, | ​ | December 31, |
| (Dollars in thousands) |  | 2022 |  | 2021 |
| Finance lease cost | ​ | ​ |  | ​ | ​ |  |
| Amortization of right-of-use assets | ​ | $ | 393 | ​ | ​ | 433 |
| Interest on lease liabilities | ​ |  | 236 | ​ |  | 267 |
| Operating lease cost | ​ |  | 1,645 | ​ |  | 1,561 |
| Total lease costs | ​ | $ | 2,274 | ​ | ​ | 2,261 |

[0001410578-23-000086:notes:73]
[same as prior period, unchanged from 0001410578-22-002168:notes:79]

[0001410578-23-000086:notes:74]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended | ​ |
| ​ | ​ | December 31, | ​ | December 31, | ​ |
| (Dollars in thousands) |  | 2022 |  | 2021 | ​ |
| Cash paid for amounts included in the measurement of lease liabilities | ​ | ​ |  | ​ | ​ |  | ​ |
| Operating cash flows from operating leases | ​ | $ | 1,601 | ​ | ​ | 1,503 | ​ |
| Operating cash flows from finance leases | ​ |  | 236 | ​ |  | 267 | ​ |
| Financing cash flows from finance leases | ​ |  | 327 | ​ |  | 361 | ​ |
| Right-of-use assets obtained in exchange for lease liabilities | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Operating leases | ​ | $ | 13,964 | ​ | ​ | 901 | ​ |
| Weighted-average remaining lease term | ​ |  | ​ | ​ |  | ​ | ​ |
| Operating leases | ​ |  | 11.6 | years |  | 9.9 | years |
| Finance leases | ​ |  | 11.7 | years |  | 12.5 | years |
| Weighted-average discount rate | ​ |  | ​ | ​ |  | ​ | ​ |
| Operating leases | ​ |  | 4.36 | % |  | 3.12 | % |
| Finance leases | ​ |  | 4.60 | % |  | 4.58 | % |

[0001410578-23-000086:notes:75]
The following is a reconciliation of future undiscounted cash flows to the operating and finance lease liabilities, and the related ROU assets, presented on the Consolidated Balance Sheet on December 31, 2022:

[0001410578-23-000086:notes:76]
| (Dollars in thousands) | ​ | Operating |  | Finance |
| Years Ending September 30: |  | Leases |  | Leases |
| 2023 (excluding the three months ended December 31, 2022) | ​ | $ | 5,303 |  | 1,693 |
| 2024 | ​ |  | 6,280 |  | 2,315 |
| 2025 | ​ |  | 4,955 |  | 2,370 |
| 2026 | ​ |  | 4,073 |  | 2,434 |
| 2027 and thereafter | ​ |  | 36,443 |  | 18,997 |
| Total minimum lease payments | ​ |  | 57,054 |  | 27,809 |
| Less: amounts representing interest | ​ |  | 13,296 |  | 6,954 |
| Present value of net minimum lease payments | ​ | $ | 43,758 |  | 20,855 |
| Less: current portion of lease obligations | ​ |  | 5,412 |  | 1,359 |
| Non-current portion of lease obligations | ​ | $ | 38,346 |  | 19,496 |
| ROU assets | ​ | $ | 42,156 |  | 16,950 |

[0001410578-23-000086:notes:77]
Operating lease liabilities are included on the Consolidated Balance Sheet in accrued other expenses (current portion) and as a caption on the Consolidated Balance Sheet (long-term portion). Finance lease liabilities are included on the Consolidated Balance Sheet in accrued other expenses (current portion) and other liabilities (long-term portion). Operating lease ROU assets are included as a caption on the Consolidated Balance Sheet and finance lease ROU assets are included in Property, plant and equipment on the Consolidated Balance sheet.
