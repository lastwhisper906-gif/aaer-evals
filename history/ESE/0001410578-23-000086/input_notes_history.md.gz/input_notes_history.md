# ESE note change history — 0001410578-22-002168 → 0001410578-23-000086


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-02-09):
[0001410578-23-000086:note_history:1]
The accompanying consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP).
  (was, 2022-08-09, similarity 0.9874):
[0001410578-22-002168:note_history:1]
The accompanying consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for consolidated annual financial statements by accounting principles generally accepted in the United States of America (GAAP).

- changed (2023-02-09):
[0001410578-23-000086:note_history:2]
The Company’s results for the three-month period ended December 31, 2022 are not necessarily indicative of the results for the entire 2023 fiscal year. References to the first quarters of 2023 and 2022 represent the fiscal quarters ended December 31, 2022 and 2021, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.
  (was, 2022-08-09, similarity 0.8043):
[0001410578-22-002168:note_history:2]
The Company’s results for the three-month and nine-month periods ended June 30, 2022 are not necessarily indicative of the results for the entire 2022 fiscal year. References to the third quarters of 2022 and 2021 represent the fiscal quarters ended June 30, 2022 and 2021, respectively. The preparation of consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates. Certain prior period deferred revenue amounts have been reclassified to noncurrent to conform with the current year presentation.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-02-09):
[0001410578-23-000086:note_history:3]
| ​ |  | December 31, | ​ | September 30, |
| (In thousands) |  | 2022 |  | 2022 |
| Total borrowings | ​ | $ | 132,000 |  | 153,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 112,000 |  | 133,000 |
  (was, 2022-08-09, similarity 0.9738):
[0001410578-22-002168:note_history:3]
| ​ |  | June 30, | ​ | September 30, |
| (In thousands) |  | 2022 |  | 2021 |
| Total borrowings | ​ | $ | 201,000 |  | 154,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 181,000 |  | 134,000 |

- changed (2023-02-09):
[0001410578-23-000086:note_history:4]
The Credit Facility includes a $500 million revolving line of credit, as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024, with balance due by this date.
  (was, 2022-08-09, similarity 0.9637):
[0001410578-22-002168:note_history:4]
The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024.

- added (2023-02-09):
[0001410578-23-000086:note_history:5]
At December 31, 2022, the Company had approximately $360 million available to borrow under the Credit Facility, plus the $250 million increase option subject to lenders’ consent, in addition to $51.9 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of December 31, 2022, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $8.2 million at December 31, 2022.

- added (2023-02-09):
[0001410578-23-000086:note_history:6]
Interest on borrowings under the Credit Facility is calculated at a spread over either the New York Federal Reserve Bank Rate, the prime rate, or the London Interbank Offered Rate (LIBOR), depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The interest rate spreads on the facility and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio.  The weighted average interest rates were 4.56% and 1.17% for the three-month periods ending December 31, 2022 and 2021, respectively. As of December 31, 2022, the Company was in compliance with all covenants.

- removed (2023-02-09):
[0001410578-22-002168:note_history:7]
At June 30, 2022, the Company had approximately $291.0 million available to borrow under the Credit Facility, plus the $250 million increase option, subject to lender approval, in addition to $61.0 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of June 30, 2022, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $7.8 million at June 30, 2022.

- removed (2023-02-09):
[0001410578-22-002168:note_history:8]
Interest on borrowings under the Credit Facility is calculated at a spread over either the New York Federal Reserve Bank Rate, the prime rate or the London Interbank Offered Rate (LIBOR), depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The Credit Facility is secured by the unlimited guaranty of the Company’s direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of its direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 2.20% and 1.57% for the three and nine-month periods ending June 30, 2022, respectively, and 1.16% and 1.33% for the three and nine-month periods ending June 30, 2021. As of June 30, 2022, the Company was in compliance with all covenants.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-02-09):
[0001410578-23-000086:note_history:9]
| ​ |  | December 31, | ​ | September 30, |
| (In thousands) |  | 2022 |  | 2022 |
| Total borrowings | ​ | $ | 132,000 |  | 153,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 112,000 |  | 133,000 |
  (was, 2022-08-09, similarity 0.9738):
[0001410578-22-002168:note_history:9]
| ​ |  | June 30, | ​ | September 30, |
| (In thousands) |  | 2022 |  | 2021 |
| Total borrowings | ​ | $ | 201,000 |  | 154,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 181,000 |  | 134,000 |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-02-09):
[0001410578-23-000086:note_history:10]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2022 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within each reportable segment.

- changed (2023-02-09):
[0001410578-23-000086:note_history:11]
| ​ | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 36,740 | ​ | $ | 70,162 | ​ | $ | 45,992 | ​ | $ | 152,894 |
| U.S. Government | ​ |  | 46,243 | ​ |  | 883 | ​ |  | 5,481 | ​ |  | 52,607 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 68,934 | ​ | $ | 46,379 | ​ | $ | 27,503 | ​ | $ | 142,816 |
| International | ​ |  | 14,049 | ​ |  | 24,666 | ​ |  | 23,970 | ​ |  | 62,685 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 33,604 | ​ | $ | 56,031 | ​ | $ | 9,101 | ​ | $ | 98,736 |
| Over time | ​ |  | 49,379 | ​ |  | 15,014 | ​ |  | 42,372 | ​ |  | 106,765 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |
  (was, 2022-08-09, similarity 0.9848):
[0001410578-22-002168:note_history:11]
| Nine months ended June 30, 2022 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 100,407 | ​ | $ | 191,832 | ​ | $ | 147,390 | ​ | $ | 439,629 |
| U.S. Government | ​ |  | 147,264 | ​ |  | 3,045 | ​ |  | 11,066 | ​ |  | 161,375 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 212,849 | ​ | $ | 122,021 | ​ | $ | 88,708 | ​ | $ | 423,578 |
| International | ​ |  | 34,822 | ​ |  | 72,856 | ​ |  | 69,748 | ​ |  | 177,426 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 99,464 | ​ | $ | 155,693 | ​ | $ | 43,488 | ​ | $ | 298,645 |
| Over time | ​ |  | 148,207 | ​ |  | 39,184 | ​ |  | 114,968 | ​ |  | 302,359 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |

- changed (2023-02-09):
[0001410578-23-000086:note_history:12]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2021 are presented in the table below:
  (was, 2022-08-09, similarity 0.9288):
[0001410578-22-002168:note_history:12]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2021 are presented in the tables below.

- changed (2023-02-09):
[0001410578-23-000086:note_history:13]
| ​ | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial |  | $ | 28,075 | ​ | $ | 62,842 | ​ | $ | 41,037 | ​ | $ | 131,954 |
| U.S. Government | ​ | ​ | 42,169 | ​ |  | 643 | ​ |  | 2,244 | ​ |  | 45,056 |
| Total revenues |  | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 |
| Geographic location: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States |  | $ | 60,687 | ​ | $ | 38,741 | ​ | $ | 22,975 | ​ | $ | 122,403 |
| International | ​ | ​ | 9,557 | ​ |  | 24,744 | ​ |  | 20,306 | ​ |  | 54,607 |
| Total revenues |  | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 |
| Revenue recognition method: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time |  | $ | 28,558 | ​ | $ | 50,835 | ​ | $ | 12,821 | ​ | $ | 92,214 |
| Over time | ​ | ​ | 41,686 | ​ |  | 12,650 | ​ |  | 30,460 | ​ |  | 84,796 |
| Total revenues |  | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 |
  (was, 2022-08-09, similarity 0.8156):
[0001410578-22-002168:note_history:13]
| Three Months Ended June 30, 2022 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 38,918 | ​ | $ | 65,610 | ​ | $ | 54,449 | ​ | $ | 158,977 |
| U.S. Government | ​ |  | 53,688 | ​ |  | 1,591 | ​ |  | 4,810 | ​ |  | 60,089 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |
| ​ | ​ | ​ | ​ | ​ | ​ | 65 | ​ | ​ | ​ | ​ | ​ | ​ |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 79,536 | ​ | $ | 41,822 | ​ | $ | 34,662 | ​ | $ | 156,020 |
| International | ​ |  | 13,070 | ​ |  | 25,379 | ​ |  | 24,597 | ​ |  | 63,046 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 35,238 | ​ | $ | 53,656 | ​ | $ | 15,827 | ​ | $ | 104,721 |
| Over time | ​ |  | 57,368 | ​ |  | 13,545 | ​ |  | 43,432 | ​ |  | 114,345 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |

- removed (2023-02-09):
[0001410578-22-002168:note_history:14]
| Three months ended June 30, 2021 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial |  | $ | 34,708 |  | $ | 46,735 |  | $ | 42,063 |  | $ | 123,506 |
| U.S. Government | ​ | ​ | 50,868 | ​ | ​ | 969 | ​ | ​ | 6,051 | ​ | ​ | 57,888 |
| Total revenues |  | $ | 85,576 |  | $ | 47,704 |  | $ | 48,114 |  | $ | 181,394 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States |  | $ | 75,701 |  | $ | 32,111 |  | $ | 27,719 |  | $ | 135,531 |
| International | ​ | ​ | 9,875 | ​ | ​ | 15,593 | ​ | ​ | 20,395 | ​ | ​ | 45,863 |
| Total revenues |  | $ | 85,576 |  | $ | 47,704 |  | $ | 48,114 |  | $ | 181,394 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time |  | $ | 37,513 |  | $ | 35,242 |  | $ | 9,673 |  | $ | 82,428 |
| Over time | ​ | ​ | 48,063 | ​ | ​ | 12,462 | ​ | ​ | 38,441 | ​ | ​ | 98,966 |
| Total revenues |  | $ | 85,576 |  | $ | 47,704 |  | $ | 48,114 |  | $ | 181,394 |

- removed (2023-02-09):
[0001410578-22-002168:note_history:15]
| Nine months ended June 30, 2021 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial |  | $ | 95,712 |  | $ | 139,149 |  | $ | 118,089 |  | $ | 352,950 |
| U.S. Government | ​ | ​ | 139,008 | ​ | ​ | 2,650 | ​ | ​ | 15,354 | ​ | ​ | 157,012 |
| Total revenues |  | $ | 234,720 |  | $ | 141,799 |  | $ | 133,443 |  | $ | 509,962 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States |  | $ | 205,527 |  | $ | 96,601 |  | $ | 73,950 |  | $ | 376,078 |
| International | ​ | ​ | 29,193 | ​ | ​ | 45,198 | ​ | ​ | 59,493 | ​ | ​ | 133,884 |
| Total revenues |  | $ | 234,720 |  | $ | 141,799 |  | $ | 133,443 |  | $ | 509,962 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time |  | $ | 103,492 |  | $ | 105,173 |  | $ | 27,789 |  | $ | 236,454 |
| Over time | ​ | ​ | 131,228 | ​ | ​ | 36,626 | ​ | ​ | 105,654 | ​ | ​ | 273,508 |
| Total revenues |  | $ | 234,720 |  | $ | 141,799 |  | $ | 133,443 |  | $ | 509,962 |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-02-09):
[0001410578-23-000086:note_history:16]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2022 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within each reportable segment.
  (was, 2022-08-09, similarity 0.953):
[0001410578-22-002168:note_history:16]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2022 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue within each reportable segment.

- changed (2023-02-09):
[0001410578-23-000086:note_history:17]
| ​ | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 36,740 | ​ | $ | 70,162 | ​ | $ | 45,992 | ​ | $ | 152,894 |
| U.S. Government | ​ |  | 46,243 | ​ |  | 883 | ​ |  | 5,481 | ​ |  | 52,607 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 68,934 | ​ | $ | 46,379 | ​ | $ | 27,503 | ​ | $ | 142,816 |
| International | ​ |  | 14,049 | ​ |  | 24,666 | ​ |  | 23,970 | ​ |  | 62,685 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 33,604 | ​ | $ | 56,031 | ​ | $ | 9,101 | ​ | $ | 98,736 |
| Over time | ​ |  | 49,379 | ​ |  | 15,014 | ​ |  | 42,372 | ​ |  | 106,765 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |
  (was, 2022-08-09, similarity 0.9848):
[0001410578-22-002168:note_history:17]
| Nine months ended June 30, 2022 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 100,407 | ​ | $ | 191,832 | ​ | $ | 147,390 | ​ | $ | 439,629 |
| U.S. Government | ​ |  | 147,264 | ​ |  | 3,045 | ​ |  | 11,066 | ​ |  | 161,375 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 212,849 | ​ | $ | 122,021 | ​ | $ | 88,708 | ​ | $ | 423,578 |
| International | ​ |  | 34,822 | ​ |  | 72,856 | ​ |  | 69,748 | ​ |  | 177,426 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 99,464 | ​ | $ | 155,693 | ​ | $ | 43,488 | ​ | $ | 298,645 |
| Over time | ​ |  | 148,207 | ​ |  | 39,184 | ​ |  | 114,968 | ​ |  | 302,359 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |

- changed (2023-02-09):
[0001410578-23-000086:note_history:18]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2021 are presented in the table below:
  (was, 2022-08-09, similarity 0.9288):
[0001410578-22-002168:note_history:18]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2021 are presented in the tables below.

- changed (2023-02-09):
[0001410578-23-000086:note_history:19]
| ​ | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial |  | $ | 28,075 | ​ | $ | 62,842 | ​ | $ | 41,037 | ​ | $ | 131,954 |
| U.S. Government | ​ | ​ | 42,169 | ​ |  | 643 | ​ |  | 2,244 | ​ |  | 45,056 |
| Total revenues |  | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 |
| Geographic location: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States |  | $ | 60,687 | ​ | $ | 38,741 | ​ | $ | 22,975 | ​ | $ | 122,403 |
| International | ​ | ​ | 9,557 | ​ |  | 24,744 | ​ |  | 20,306 | ​ |  | 54,607 |
| Total revenues |  | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 |
| Revenue recognition method: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time |  | $ | 28,558 | ​ | $ | 50,835 | ​ | $ | 12,821 | ​ | $ | 92,214 |
| Over time | ​ | ​ | 41,686 | ​ |  | 12,650 | ​ |  | 30,460 | ​ |  | 84,796 |
| Total revenues |  | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 |
  (was, 2022-08-09, similarity 0.8156):
[0001410578-22-002168:note_history:19]
| Three Months Ended June 30, 2022 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 38,918 | ​ | $ | 65,610 | ​ | $ | 54,449 | ​ | $ | 158,977 |
| U.S. Government | ​ |  | 53,688 | ​ |  | 1,591 | ​ |  | 4,810 | ​ |  | 60,089 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |
| ​ | ​ | ​ | ​ | ​ | ​ | 65 | ​ | ​ | ​ | ​ | ​ | ​ |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 79,536 | ​ | $ | 41,822 | ​ | $ | 34,662 | ​ | $ | 156,020 |
| International | ​ |  | 13,070 | ​ |  | 25,379 | ​ |  | 24,597 | ​ |  | 63,046 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 35,238 | ​ | $ | 53,656 | ​ | $ | 15,827 | ​ | $ | 104,721 |
| Over time | ​ |  | 57,368 | ​ |  | 13,545 | ​ |  | 43,432 | ​ |  | 114,345 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |

- changed (2023-02-09):
[0001410578-23-000086:note_history:20]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At December 31, 2022, the Company had $718.4 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 80% in the next twelve months.
  (was, 2022-08-09, similarity 0.9914):
[0001410578-22-002168:note_history:20]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At June 30, 2022, the Company had $706.8 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 80% in the next twelve months.

- changed (2023-02-09):
[0001410578-23-000086:note_history:21]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred. At December 31, 2022, contract assets and liabilities totaled $122.5 million and $133.6 million, respectively. During the first quarter of 2023, the Company recognized approximately $31.0 million in revenues that were included in the contract liabilities balance at September 30, 2022. At September 30, 2022, contract assets and liabilities totaled $125.2 million and $137.6 million, respectively.
  (was, 2022-08-09, similarity 0.7569):
[0001410578-22-002168:note_history:21]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred. At June 30, 2022, contract assets and liabilities totaled $115.8 million and $122.2 million, respectively. During the first nine months of 2022, the Company recognized approximately $74 million in revenues that were included in the contract liabilities balance at September 30, 2021. The increase in net contract assets in the first nine months of 2022 was due to revenue being recognized for performance completed during the period that exceeded customer billings. The increase in net contract liabilities in the first nine months of 2022 was due to higher payments received in advance of revenue recognition criteria being met under the Company’s contracts with customers. At October 1, 2020, contract assets and liabilities totaled $94.3 million and $100.6 million, respectively.

- removed (2023-02-09):
[0001410578-22-002168:note_history:22]
| Three months ended June 30, 2021 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial |  | $ | 34,708 |  | $ | 46,735 |  | $ | 42,063 |  | $ | 123,506 |
| U.S. Government | ​ | ​ | 50,868 | ​ | ​ | 969 | ​ | ​ | 6,051 | ​ | ​ | 57,888 |
| Total revenues |  | $ | 85,576 |  | $ | 47,704 |  | $ | 48,114 |  | $ | 181,394 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States |  | $ | 75,701 |  | $ | 32,111 |  | $ | 27,719 |  | $ | 135,531 |
| International | ​ | ​ | 9,875 | ​ | ​ | 15,593 | ​ | ​ | 20,395 | ​ | ​ | 45,863 |
| Total revenues |  | $ | 85,576 |  | $ | 47,704 |  | $ | 48,114 |  | $ | 181,394 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time |  | $ | 37,513 |  | $ | 35,242 |  | $ | 9,673 |  | $ | 82,428 |
| Over time | ​ | ​ | 48,063 | ​ | ​ | 12,462 | ​ | ​ | 38,441 | ​ | ​ | 98,966 |
| Total revenues |  | $ | 85,576 |  | $ | 47,704 |  | $ | 48,114 |  | $ | 181,394 |

- removed (2023-02-09):
[0001410578-22-002168:note_history:23]
| Nine months ended June 30, 2021 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial |  | $ | 95,712 |  | $ | 139,149 |  | $ | 118,089 |  | $ | 352,950 |
| U.S. Government | ​ | ​ | 139,008 | ​ | ​ | 2,650 | ​ | ​ | 15,354 | ​ | ​ | 157,012 |
| Total revenues |  | $ | 234,720 |  | $ | 141,799 |  | $ | 133,443 |  | $ | 509,962 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States |  | $ | 205,527 |  | $ | 96,601 |  | $ | 73,950 |  | $ | 376,078 |
| International | ​ | ​ | 29,193 | ​ | ​ | 45,198 | ​ | ​ | 59,493 | ​ | ​ | 133,884 |
| Total revenues |  | $ | 234,720 |  | $ | 141,799 |  | $ | 133,443 |  | $ | 509,962 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time |  | $ | 103,492 |  | $ | 105,173 |  | $ | 27,789 |  | $ | 236,454 |
| Over time | ​ | ​ | 131,228 | ​ | ​ | 36,626 | ​ | ​ | 105,654 | ​ | ​ | 273,508 |
| Total revenues |  | $ | 234,720 |  | $ | 141,799 |  | $ | 133,443 |  | $ | 509,962 |
