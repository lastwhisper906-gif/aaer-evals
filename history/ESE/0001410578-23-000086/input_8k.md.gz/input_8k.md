# ESE 8-K — 0001104659-23-014539 filed 2023-02-08

## item codes, every 8-K on or before 2023-02-09

- 2023-02-08 0001104659-23-014539 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2023-01-06 0001104659-23-001859 — 5.02, 9.01
- 2022-11-22 0001104659-22-121229 — 5.02, 5.03, 8.01, 9.01
- 2022-11-17 0001104659-22-119898 — 2.02, 7.01, 9.01
- 2022-09-12 0001104659-22-099248 — 5.02, 7.01, 9.01
- 2022-08-08 0001104659-22-087247 — 2.02, 5.02, 7.01, 9.01
- 2022-05-09 0001104659-22-057524 — 2.02, 5.02, 7.01, 9.01
- 2022-02-08 0001104659-22-013878 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2021-12-03 0001104659-21-146361 — 4.01, 9.01 — amendment, the index does not say of what
- 2021-11-24 0001104659-21-143568 — 4.01, 9.01
- 2021-11-23 0001104659-21-142871 — 5.02, 8.01
- 2021-11-18 0001104659-21-141206 — 2.02, 7.01, 9.01
- 2021-08-09 0001104659-21-102150 — 2.02, 7.01, 9.01
- 2021-05-04 0001104659-21-060985 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2021-04-05 0001104659-21-046581 — 5.02, 9.01
- 2021-02-08 0001104659-21-013712 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2020-12-09 0001104659-20-133674 — 5.02, 9.01
- 2020-12-07 0001104659-20-132861 — 5.02, 7.01, 9.01
- 2020-11-19 0001104659-20-127352 — 2.02, 5.02, 7.01, 9.01
- 2020-08-10 0001104659-20-092734 — 2.02, 7.01, 9.01
- 2020-05-06 0001104659-20-057442 — 2.02, 7.01, 8.01, 9.01
- 2020-02-04 0001104659-20-010640 — 2.02, 5.07, 7.01, 9.01
- 2020-01-07 0001104659-20-001789 — 2.01, 9.01
- 2019-11-19 0001104659-19-065437 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2019-11-18 0001104659-19-065096 — 1.01, 2.02, 7.01, 9.01
- 2019-09-30 0001144204-19-046523 — 1.01, 1.02, 2.03, 9.01
- 2019-08-08 0001144204-19-038567 — 2.02, 7.01, 9.01
- 2019-05-07 0001144204-19-024241 — 2.02, 5.02, 7.01, 9.01
- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2023-02-09

- none on or before 2023-02-09

## item 2.02 — earnings release, exhibit 99.1

[0001104659-23-014539:8k_2_02:1]
EX-99.1
3
tm235767d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-23-014539:8k_2_02:2]
Exhibit 99.1

[0001104659-23-014539:8k_2_02:3]
| NEWS FROM |  |

[0001104659-23-014539:8k_2_02:4]
For more information contact:

[0001104659-23-014539:8k_2_02:5]
Kate Lowrey - VP of Investor Relations

[0001104659-23-014539:8k_2_02:6]
(314) 213-7277
/ klowrey@escotechnologies.com

[0001104659-23-014539:8k_2_02:7]
ESCO REPORTS FIRST QUARTER FISCAL 2023
RESULTS

[0001104659-23-014539:8k_2_02:8]
- Q1 GAAP EPS $0.57 / Adjusted EPS $0.60
-

[0001104659-23-014539:8k_2_02:9]
- Q1 Sales increase 16% to $206 Million -

[0001104659-23-014539:8k_2_02:10]
- $229 Million in Q1 Orders / Book-to-bill
of 1.11x -

[0001104659-23-014539:8k_2_02:11]
ST. LOUIS, February 8, 2023 – ESCO Technologies
Inc. (NYSE: ESE) (ESCO, or the Company) today reported its operating results for the first quarter ended December 31, 2022 (Q1 2023).

[0001104659-23-014539:8k_2_02:12]
Operating Highlights

[0001104659-23-014539:8k_2_02:13]
|  | · | Q1 2023 GAAP EPS increased 30 percent to $0.57 per share compared to $0.44 per share in Q1 2022. Q1 2023 Adjusted EPS also increased 30 percent to $0.60 per share compared to $0.46 per share in Q1 2022. |

[0001104659-23-014539:8k_2_02:14]
|  | · | Q1 2023 Sales increased $28.5 million (16.1 percent) to $205.5 million compared to $177.0 million in Q1 2022. |

[0001104659-23-014539:8k_2_02:15]
|  | · | Q1 2023 Entered Orders increased $4.5 million (2 percent) over the prior year period to $228.9 million (book-to-bill of 1.11x), resulting in record backlog of $718 million. |

[0001104659-23-014539:8k_2_02:16]
|  | · | Net cash used by operating activities was $9 million in Q1 2023, as cash flow was negatively impacted by higher inventory related to increased backlog, lower accrued expenses related to the timing of payments in the quarter, and the effect of deferred taxes. |

[0001104659-23-014539:8k_2_02:17]
|  | · | Net debt (total borrowings less cash on hand) was $80 million, resulting in a 0.72x leverage ratio and $610 million in liquidity at December 31, 2022. |

[0001104659-23-014539:8k_2_02:18]
Bryan Sayler, Chief Executive Officer and President,
commented, “Our fiscal year got off to a strong start with double digit revenue growth and improved operating margins across all
three of our business segments. We saw broad strength across our end-markets, highlighted by 30 percent growth in commercial aerospace
and 45 percent growth in renewables revenue compared to the prior year. While we continue to feel some pressures related to supply chain
performance and labor shortages, our teams across the Company are navigating those challenges well and have executed at a high level.

[0001104659-23-014539:8k_2_02:19]
“We had another solid quarter for entered orders,
driven by strength across our commercial aerospace, Navy, electric utility, and renewables end-markets. With $229 million in orders and
a book-to-bill of 1.11x, our record ending backlog of $718 million gives us confidence as we work toward delivering the guidance for 2023
that was communicated in November.”

[0001104659-23-014539:8k_2_02:20]
Segment Performance

[0001104659-23-014539:8k_2_02:21]
Aerospace & Defense (A&D)

[0001104659-23-014539:8k_2_02:22]
|  | · | Sales increased $12.8 million (18 percent) to $83.0 million in Q1 2023 from $70.2 million in Q1 2022. Revenues were strong across all end-markets, led by commercial aerospace sales which increased $6.9 million (30 percent) to $30.0 million in the quarter. In addition, sales to defense aerospace, Navy, and space markets also achieved double digit growth compared to the prior year Q1. |

[0001104659-23-014539:8k_2_02:23]
|  | · | Q1 2023 EBIT increased $2.5 million to $12.5 million from $10.0 million in Q1 2022. Adjusted EBIT also increased $2.5 million in Q1 2023 to $12.7 million (15.3 percent margin) from $10.2 million (14.4 percent margin) in Q1 2022. |

[0001104659-23-014539:8k_2_02:24]
|  | · | Entered Orders increased $7 million (8 percent) to $97 million in Q1 2023 compared to $90 million in Q1 2022. The increase in orders was driven by Columbia and Virginia Class funding and a strong quarter for Navy spares. The orders strength in the quarter resulted in a segment book-to-bill of 1.17x and record ending backlog of $423 million. |

[0001104659-23-014539:8k_2_02:25]
Utility Solutions Group (USG)

[0001104659-23-014539:8k_2_02:26]
|  | · | Sales increased $7.5 million (12 percent) to $71.0 million in Q1 2023 from $63.5 million in Q1 2022. Doble’s sales increased by $3.0 million (6 percent) driven by a strong quarter for protection testing, both instruments and PowerBase™ software. NRG sales increased $4.5 million (45 percent) on continued strength in the renewables end-market. |

[0001104659-23-014539:8k_2_02:27]
|  | · | EBIT increased $2.7 million in Q1 2023 to $16.1 million from $13.4 million in Q1 2022. There were no adjustments to Q1 2023 EBIT of $16.1 million (22.7 percent margin), which increased $2.3 million from Q1 2022 Adjusted EBIT of $13.8 million (21.8 percent margin). |

[0001104659-23-014539:8k_2_02:28]
|  | · | Entered Orders increased $14 million (21 percent) to $80 million in Q1 2023. The orders growth was primarily driven by a $10 million (18 percent) increase at Doble related to strong calendar year-end utility spending. Continuing strength in protection testing (hardware and software) and condition monitoring and services opportunities driven by Altanova in EMEA contributed to the orders growth in the quarter. NRG orders increased by $4 million (35 percent) related to continuing strength in wind and solar. USG’s book-to-bill of 1.13x in the quarter resulted in ending backlog of $137 million. |

[0001104659-23-014539:8k_2_02:29]
Test

[0001104659-23-014539:8k_2_02:30]
|  | · | Sales increased $8.2 million (19 percent) to $51.5 million in Q1 2023 from $43.3 million in Q1 2022, primarily due to increased test and measurement projects in the U.S and Europe and domestic medical shielding. |

[0001104659-23-014539:8k_2_02:31]
|  | · | EBIT increased $1.4 million in Q1 2023 to $5.4 million (10.5 percent margin) from $4.0 million (9.2 percent margin) in Q1 2022. There were no adjustments in either year for the Test segment. |

[0001104659-23-014539:8k_2_02:32]
|  | · | Entered Orders decreased $16.4 million to $51.5 million in Q1 2023 compared to $67.9 million in Q1 2022. The decrease was due to large orders related to power filters and test and measurement projects in the U.S. and China in the prior year quarter. Test’s book-to-bill of 1.0x resulted in flat ending backlog of $159 million compared to the prior year end. |

[0001104659-23-014539:8k_2_02:33]
Share Repurchase Program

[0001104659-23-014539:8k_2_02:34]
During Q1 2023, the Company repurchased approximately
58,000 shares for $5.1 million, of which $4.1 million was paid in the quarter and the remainder settled in January, 2023.

[0001104659-23-014539:8k_2_02:35]
Dividend Payment

[0001104659-23-014539:8k_2_02:36]
The next quarterly cash dividend
of $0.08 per share will be paid on April 18, 2023 to stockholders of record on April 3, 2023.

[0001104659-23-014539:8k_2_02:37]
Business Outlook – 2023

[0001104659-23-014539:8k_2_02:38]
Management’s expectations for 2023 remain consistent with the
details outlined in our November 17, 2022, release.  Our 2023 guidance represents mid-single digit revenue growth driving Adjusted
EBIT and Adjusted EBITDA margin expansion, despite continuing inflationary pressures and higher interest rates.

[0001104659-23-014539:8k_2_02:39]
The strength of our Q1 results gives us added confidence
in our 2023 forecast and we are narrowing our full year guidance to $3.50 to $3.60. Consistent with prior years, revenues and Adjusted
EPS are expected to grow sequentially throughout the year. Our expectation is for Q2 Adjusted EPS to be in the range of $0.68 to $0.74
per share.

[0001104659-23-014539:8k_2_02:40]
Acquisition Update

[0001104659-23-014539:8k_2_02:41]
On February 1, 2023, the Company
acquired CMT Materials, LLC and its affiliate Engineered Syntactic Systems, LLC (CMT). CMT, based in Attleboro, Massachusetts, is a leading
supplier of syntactic materials for buoyancy and specialty applications. They are experts in designing and manufacturing custom syntactic
foam components and systems, which are utilized in industrial, oceanographic, military, and naval applications. CMT brings proprietary
technology and capabilities to our A&D business and will strengthen our offerings on underwater platforms for the Navy. The business
has annualized sales of approximately $15 million and will become part of Globe Composite Solutions within our A&D segment.

[0001104659-23-014539:8k_2_02:42]
Conference Call

[0001104659-23-014539:8k_2_02:43]
The Company will host a conference call today, February 8, at 4:00
p.m. Central Time, to discuss the Company’s Q1 2023 results. A live audio webcast and an accompanying slide presentation will be
available on ESCO’s investor website at https://investor.escotechnologies.com. For those unable to participate, a webcast replay
will be available after the call on ESCO’s investor website.

[0001104659-23-014539:8k_2_02:44]
Forward-Looking Statements

[0001104659-23-014539:8k_2_02:45]
Investors are cautioned that such statements are
only predictions and speak only as of the date of this release, and the Company undertakes no duty to update them except as may be required
by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the
forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment including
but not limited to those described in Item 1A, “Risk Factors”, of the Company’s Annual Report on Form 10-K for the fiscal
year ended September 30, 2022; the availability and acceptance of viable COVID-19 vaccines by enough of the U.S. and world’s population
to curtail the pandemic; the continuing impact of the COVID-19 pandemic and the effects of known or unknown COVID-19 variants including
labor shortages, facility closures, shelter in place policies or quarantines, material shortages, transportation delays, termination or
delays of Company contracts, and the inability of our suppliers or customers to perform; the impacts of natural disasters on the Company’s
operations and those of the Company’s customers and suppliers; the timing and content of future contract awards or customer orders;
the appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer contracts
or orders; weakening of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands
or customer insolvencies; competition; intellectual property rights; technical difficulties; the success of the Company’s acquisition
efforts; delivery delays or defaults by customers; performance issues with key customers, suppliers and subcontractors; changes in the
costs and availability of certain raw materials; labor disputes; changes in U.S. tax laws and regulations; other changes in laws and regulations
including but not limited to changes in accounting standards and foreign taxation; changes in interest rates; costs relating to environmental
matters arising from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation
or arbitration; and the integration of recently acquired businesses.

[0001104659-23-014539:8k_2_02:46]
Non-GAAP Financial Measures

[0001104659-23-014539:8k_2_02:47]
The financial measures EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA
and Adjusted EPS are presented in this press release. The Company defines “EBIT” as earnings before interest and taxes, “EBITDA”
as earnings before interest, taxes, depreciation and amortization, “Adjusted EBIT” and “Adjusted EBITDA” as excluding
the net impact of the items described in the attached Reconciliation of Non-GAAP Financial Measures, and “Adjusted EPS” as
GAAP earnings per share (EPS) excluding the net impact of the items described and reconciled in the attached Reconciliation of Non-GAAP
Financial Measures.

[0001104659-23-014539:8k_2_02:48]
EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA and
Adjusted EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management believes
EBIT, Adjusted EBIT, EBITDA and Adjusted EBITDA are useful in assessing the operational profitability of the Company’s business
segments because they exclude interest, taxes, depreciation and amortization, which are generally accounted for across the entire Company
on a consolidated basis. EBIT and EBITDA are also measures used by Management in determining resource allocations within the Company as
well as incentive compensation. The presentation of EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS provides important supplemental
information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures to supplement
their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance determined in accordance
with GAAP.

[0001104659-23-014539:8k_2_02:49]
ESCO is a global provider of highly engineered products and solutions
serving diverse end-markets. It manufactures filtration and fluid control products for the aviation, Navy, space, and process markets
worldwide and composite-based products and solutions for Navy, defense, and industrial customers. ESCO is the industry leader in RF shielding
and EMC test products; and provides diagnostic instruments, software and services to industrial power users and the electric utility and
renewable energy industries. Headquartered in St. Louis, Missouri, ESCO and its subsidiaries have offices and manufacturing facilities
worldwide. For more information on ESCO and its subsidiaries, visit the Company’s website at www.escotechnologies.com.

[0001104659-23-014539:8k_2_02:50]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Condensed Consolidated Statements of Operations (Unaudited) |
| (Dollars in thousands, except per share amounts) |

[0001104659-23-014539:8k_2_02:51]
|  |  | Three Months Ended December 31, 2022 |  |  | Three Months Ended December 31, 2021 |  |
| Net Sales |  | $ | 205,501 |  |  |  | 177,010 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 126,383 |  |  |  | 108,305 |  |
| Selling, general and administrative expenses |  |  | 51,302 |  |  |  | 46,635 |  |
| Amortization of intangible assets |  |  | 6,861 |  |  |  | 6,467 |  |
| Interest expense |  |  | 1,658 |  |  |  | 733 |  |
| Other expenses, net |  |  | 398 |  |  |  | 33 |  |
| Total costs and expenses |  |  | 186,602 |  |  |  | 162,173 |  |
| Earnings before income taxes |  |  | 18,899 |  |  |  | 14,837 |  |
| Income tax expense |  |  | 4,172 |  |  |  | 3,313 |  |
| Net earnings |  | $ | 14,727 |  |  |  | 11,524 |  |
| Diluted - GAAP |  | $ | 0.57 |  |  |  | 0.44 |  |
| Diluted - As Adjusted Basis |  | $ | 0.60 | (1) |  |  | 0.46 | (2) |
| Diluted average common shares O/S: |  |  | 25,943 |  |  |  | 26,142 |  |

[0001104659-23-014539:8k_2_02:52]
| (1) |  | Q1 2023 Adjusted EPS excludes $0.03 per share of after-tax charges associated with executive management transition costs at Corporate and restructuring charges within the A&D segment. |
| (2) |  | Q1 2022 Adjusted EPS excludes $0.02 per share of after-tax charges associated with the Altanova & NEco acquisition inventory step-up charges and Corporate acquisition related costs. |

[0001104659-23-014539:8k_2_02:53]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Condensed Business Segment Information (Unaudited) |
| (Dollars in thousands) |

[0001104659-23-014539:8k_2_02:54]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | Q1 2023 |  |  | Q1 2022 |  |  | Q1 2023 |  |  | Q1 2022 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 82,983 |  |  |  | 70,244 |  |  |  | 82,983 |  |  |  | 70,244 |  |
| USG |  |  | 71,045 |  |  |  | 63,485 |  |  |  | 71,045 |  |  |  | 63,485 |  |
| Test |  |  | 51,473 |  |  |  | 43,281 |  |  |  | 51,473 |  |  |  | 43,281 |  |
| Totals |  | $ | 205,501 |  |  |  | 177,010 |  |  |  | 205,501 |  |  |  | 177,010 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 12,536 |  |  |  | 9,955 |  |  |  | 12,735 |  |  |  | 10,150 |  |
| USG |  |  | 16,131 |  |  |  | 13,391 |  |  |  | 16,131 |  |  |  | 13,841 |  |
| Test |  |  | 5,411 |  |  |  | 3,965 |  |  |  | 5,411 |  |  |  | 3,965 |  |
| Corporate |  |  | (13,521 | ) |  |  | (11,741 | ) |  |  | (12,728 | ) |  |  | (11,561 | ) |
| Consolidated EBIT |  |  | 20,557 |  |  |  | 15,570 |  |  |  | 21,549 |  |  |  | 16,395 |  |
| Less: Interest expense |  |  | (1,658 | ) |  |  | (733 | ) |  |  | (1,658 | ) |  |  | (733 | ) |
| Less: Income tax expense |  |  | (4,172 | ) |  |  | (3,313 | ) |  |  | (4,400 | ) |  |  | (3,503 | ) |
| Net earnings |  | $ | 14,727 |  |  |  | 11,524 |  |  |  | 15,491 |  |  |  | 12,159 |  |

[0001104659-23-014539:8k_2_02:55]
Note 1: Adjusted net earnings were $15.5 million in Q1 2023 which excludes
$0.03 per share of after-tax charges associated with executive management transition costs at Corporate and restructuring charges within
the A&D segment.

[0001104659-23-014539:8k_2_02:56]
Note 2: Adjusted net earnings were $12.2 million in Q1 2022 which excludes
$0.02 per share of after-tax charges associated with the Altanova & NEco acquisition inventory step-up charges and Corporate acquisition
related costs.

[0001104659-23-014539:8k_2_02:57]
EBITDA Reconciliation to Net earnings:

[0001104659-23-014539:8k_2_02:58]
|  |  |  |  |  |  |  |  | Q1 2023 |  |  | Q1 2022 |  |
|  |  | Q1 2023 |  |  | Q1 2022 |  |  | - As Adj |  |  | - As Adj |  |
| Consolidated EBITDA |  | $ | 32,924 |  |  |  | 27,742 |  |  |  | 33,916 |  |  |  | 28,567 |  |
| Less: Depr & Amort |  |  | (12,367 | ) |  |  | (12,172 | ) |  |  | (12,367 | ) |  |  | (12,172 | ) |
| Consolidated EBIT |  |  | 20,557 |  |  |  | 15,570 |  |  |  | 21,549 |  |  |  | 16,395 |  |
| Less: Interest expense |  |  | (1,658 | ) |  |  | (733 | ) |  |  | (1,658 | ) |  |  | (733 | ) |
| Less: Income tax expense |  |  | (4,172 | ) |  |  | (3,313 | ) |  |  | (4,400 | ) |  |  | (3,503 | ) |
| Net earnings |  | $ | 14,727 |  |  |  | 11,524 |  |  |  | 15,491 |  |  |  | 12,159 |  |

[0001104659-23-014539:8k_2_02:59]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Condensed Consolidated Balance Sheets (Unaudited) |
| (Dollars in thousands) |

[0001104659-23-014539:8k_2_02:60]
|  |  | December 31, 2022 |  |  | September 30, 2022 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 51,922 |  |  |  | 97,724 |  |
| Accounts receivable, net |  |  | 159,658 |  |  |  | 164,645 |  |
| Contract assets |  |  | 122,518 |  |  |  | 125,154 |  |
| Inventories |  |  | 181,743 |  |  |  | 162,403 |  |
| Other current assets |  |  | 18,930 |  |  |  | 22,696 |  |
| Total current assets |  |  | 534,771 |  |  |  | 572,622 |  |
| Property, plant and equipment, net |  |  | 155,722 |  |  |  | 155,973 |  |
| Intangible assets, net |  |  | 394,824 |  |  |  | 394,464 |  |
| Goodwill |  |  | 498,383 |  |  |  | 492,709 |  |
| Operating lease assets |  |  | 42,156 |  |  |  | 29,150 |  |
| Other assets |  |  | 10,133 |  |  |  | 9,538 |  |
|  |  | $ | 1,635,989 |  |  |  | 1,654,456 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt |  | $ | 20,000 |  |  |  | 20,000 |  |
| Accounts payable |  |  | 73,770 |  |  |  | 78,746 |  |
| Contract liabilities |  |  | 121,220 |  |  |  | 125,009 |  |
| Other current liabilities |  |  | 77,770 |  |  |  | 94,374 |  |
| Total current liabilities |  |  | 292,760 |  |  |  | 318,129 |  |
| Deferred tax liabilities |  |  | 81,213 |  |  |  | 82,023 |  |
| Non-current operating lease liabilities |  |  | 38,346 |  |  |  | 24,853 |  |
| Other liabilities |  |  | 45,272 |  |  |  | 48,294 |  |
| Long-term debt |  |  | 112,000 |  |  |  | 133,000 |  |
| Shareholders' equity |  |  | 1,066,398 |  |  |  | 1,048,157 |  |
|  |  | $ | 1,635,989 |  |  |  | 1,654,456 |  |

[0001104659-23-014539:8k_2_02:61]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Consolidated Statements of Cash Flows (Unaudited) |
| (Dollars in thousands) |

[0001104659-23-014539:8k_2_02:62]
|  |  | Quarter Ended December 31, 2022 |  |  | Quarter Ended December 31, 2021 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 14,727 |  |  |  | 11,524 |  |
| Adjustments to reconcile net earnings to net cash |  |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 12,367 |  |  |  | 12,172 |  |
| Stock compensation expense |  |  | 1,860 |  |  |  | 1,685 |  |
| Changes in assets and liabilities |  |  | (36,920 | ) |  |  | (30,837 | ) |
| Effect of deferred taxes |  |  | (1,042 | ) |  |  | 7,402 |  |
| Net cash (used) provided by operating activities |  |  | (9,008 | ) |  |  | 1,946 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Acquisition of business, net of cash acquired |  |  | - |  |  |  | (15,592 | ) |
| Capital expenditures |  |  | (4,791 | ) |  |  | (14,133 | ) |
| Additions to capitalized software |  |  | (2,795 | ) |  |  | (1,958 | ) |
| Net cash used by investing activities |  |  | (7,586 | ) |  |  | (31,683 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from long-term debt |  |  | 17,000 |  |  |  | 74,000 |  |
| Principal payments on long-term debt and short-term borrowings |  |  | (38,000 | ) |  |  | (30,000 | ) |
| Dividends paid |  |  | (2,067 | ) |  |  | (2,079 | ) |
| Purchases of common stock into treasury |  |  | (4,147 | ) |  |  | (9,997 | ) |
| Other |  |  | (2,412 | ) |  |  | (2,737 | ) |
| Net cash (used) provided by financing activities |  |  | (29,626 | ) |  |  | 29,187 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 418 |  |  |  | 33 |  |
| Net decrease in cash and cash equivalents |  |  | (45,802 | ) |  |  | (517 | ) |
| Cash and cash equivalents, beginning of period |  |  | 97,724 |  |  |  | 56,232 |  |
| Cash and cash equivalents, end of period |  | $ | 51,922 |  |  |  | 55,715 |  |

[0001104659-23-014539:8k_2_02:63]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Other Selected Financial Data (Unaudited) |
| (Dollars in thousands) |

[0001104659-23-014539:8k_2_02:64]
| Backlog And Entered Orders - Q1 2023 |  | Aerospace & Defense |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 10/1/22 |  | $ | 408,269 |  |  |  | 128,156 |  |  |  | 158,597 |  |  |  | 695,022 |  |
| Entered Orders |  |  | 97,265 |  |  |  | 80,175 |  |  |  | 51,460 |  |  |  | 228,900 |  |
| Sales |  |  | (82,983 | ) |  |  | (71,045 | ) |  |  | (51,473 | ) |  |  | (205,501 | ) |
| Ending Backlog - 12/31/22 |  | $ | 422,551 |  |  |  | 137,286 |  |  |  | 158,584 |  |  |  | 718,421 |  |

[0001104659-23-014539:8k_2_02:65]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Reconciliation of Non-GAAP Financial Measures (Unaudited) |

[0001104659-23-014539:8k_2_02:66]
| EPS – Adjusted Basis Reconciliation – Q1 2023 |  |  |  |  |
| EPS – GAAP Basis – Q1 2023 |  | $ | 0.57 |  |
| Adjustments (defined below) |  |  | 0.03 |  |
| EPS – As Adjusted Basis – Q1 2023 |  | $ | 0.60 |  |
| Adjustments exclude $0.03 per share consisting of executive management transition |  |  |  |  |
| costs at Corporate and restructuring charges within the A&D segment. |  |  |  |  |
| The $0.03 of EPS adjustments per share consists of $992K of pre-tax charges |  |  |  |  |
| offset by $228K of tax benefit for net impact of $764K. |  |  |  |  |
| EPS – Adjusted Basis Reconciliation – Q1 2022 |  |  |  |  |
| EPS – GAAP Basis – Q1 2022 |  | $ | 0.44 |  |
| Adjustments (defined below) |  |  | 0.02 |  |
| EPS – As Adjusted Basis – Q1 2022 |  | $ | 0.46 |  |
| Adjustments exclude $0.02 per share consisting of Altanova & Neco acquisition inventory |  |  |  |  |
| step-up charges and Corporate related acquisition costs in the first quarter of 2022. |  |  |  |  |
| The $0.02 of EPS adjustments per share consists of $825K of pre-tax charges |  |  |  |  |
| offset by $190K of tax benefit for net impact of $635K. |  |  |  |  |

## item 5.02 — body, verbatim

[0001104659-23-014539:8k_body:1]
Item 5.02

[0001104659-23-014539:8k_body:2]
Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers

[0001104659-23-014539:8k_body:3]
In recognition of his exemplary service to the Company during 2021
and 2022, on February 2, 2023 the Human Resources and Compensation Committee of the Company’s Board of Directors approved a special
award of 2,507 time-vested Restricted Stock Units (RSUs) to the Company’s CFO Christopher L. Tucker, effective February 3, 2023
subject to shareholder approval of the extended 2018 Omnibus Incentive Plan (which was duly obtained as noted in Item 5.07 below). The
number of RSUs was based on $250,000 divided by the Company’s NYSE closing stock price on the effective date. The other terms of
the award are substantially the same as those of the annual RSU awards granted to the named executive officers in May 2022 pursuant to
the Company’s current annual LTI program, except that (a) the award will vest on November 5, 2025 (which is the same vesting date
as for the May 2022 RSU Awards), and (b) on each dividend date during the award period, a dollar amount equal to the dividends payable
on a number of shares equal to the number of RSUs will be accrued, and the total accrued amount will be paid to the recipient in cash
upon vesting of the Award.
