# ESE MD&A — 0001410578-23-000086


## mdna

[0001410578-23-000086:mdna:1]
[same as prior period, unchanged from 0001410578-22-002168:mdna:1]

[0001410578-23-000086:mdna:2]
[same as prior period, unchanged from 0001410578-22-002168:mdna:6]

[0001410578-23-000086:mdna:3]
References to the first quarters of 2023 and 2022 represent the three-month periods ended December 31, 2022 and 2021, respectively.

[0001410578-23-000086:mdna:4]
[same as prior period, unchanged from 0001410578-22-002168:mdna:8]

[0001410578-23-000086:mdna:5]
Sales, net earnings and diluted earnings per share were $205.5 million, $14.7 million and $0.57 per share, respectively, in the first quarter of 2023 compared to $177.0 million, $11.5 million and $0.44 per share, respectively, in the first quarter of 2022.

[0001410578-23-000086:mdna:6]
[same as prior period, unchanged from 0001410578-22-002168:mdna:10]

[0001410578-23-000086:mdna:7]
Net sales increased $28.5 million, or 16.1%, to $205.5 million in the first quarter of 2023 from $177.0 million in the first quarter of 2022. The increase in net sales in the first quarter of 2023 as compared to the first quarter of 2022 was due to a $12.8 million increase in the Aerospace & Defense segment, an $8.2 million increase in the Test segment, and a $7.5 million increase in the USG segment.

[0001410578-23-000086:mdna:8]
[same as prior period, unchanged from 0001410578-22-002168:mdna:12]

[0001410578-23-000086:mdna:9]
Net sales of $83.0 million in the first quarter of 2023 were $12.8 million, or 18.2%, higher than the $70.2 million in the first quarter of 2022. The sales increase in the first quarter of 2023 compared to the first quarter of 2022 was primarily due to an approximately $9.2 million increase in aerospace shipments at Mayday, Crissair and PTI and a $5.0 million increase in net sales at VACCO and Globe driven by navy sales, partially offset by a $1.6 million decrease in navy sales at Westland.

[0001410578-23-000086:mdna:10]
[same as prior period, unchanged from 0001410578-22-002168:mdna:14]

[0001410578-23-000086:mdna:11]
Net sales of $71.0 million in the first quarter of 2023 were $7.5 million, or 11.8% higher than the $63.5 million in the first quarter of 2022. The increase in the first quarter of 2023 compared to the first quarter of 2022 was mainly due to a $4.5 million increase in net sales at NRG driven by continued strength in the renewables end-market and a $3.0 million increase at Doble driven by higher sales of protection testing instruments and software.

[0001410578-23-000086:mdna:12]
[same as prior period, unchanged from 0001410578-22-002168:mdna:16]

[0001410578-23-000086:mdna:13]
Net sales of $51.5 million in the first quarter of 2023 were $8.2 million, or 18.9%, higher than the $43.3 million in the first quarter of 2022. The increase in the first quarter of 2022 compared to the first quarter of 2021 was primarily due to $5.8 million of higher sales from the segment’s U.S operations and $3.4 million of higher sales from the segment’s European operations partially offset by $1.0 million of lower sales from the segment’s Asian operations, all due to the timing of test and measurement chamber projects.

[0001410578-23-000086:mdna:14]
[same as prior period, unchanged from 0001410578-22-002168:mdna:18]

[0001410578-23-000086:mdna:15]
Backlog was $718.4 million at December 31, 2022 compared with $695.0 million at September 30, 2022. The Company received new orders totaling $228.9 million in the first quarter of 2023 compared to $224.4 million in the first quarter of 2022. Of the new orders received in the first quarter of 2023, $97.3 million related to Aerospace & Defense products, $80.2 million related to USG products, and $51.4 million related to Test products. Of the new orders received in the first quarter of 2022, $90.2 million related to Aerospace & Defense products, $66.2 million related to USG products, and $68.0 million related to Test products.

[0001410578-23-000086:mdna:16]
[same as prior period, unchanged from 0001410578-22-002168:mdna:21]

[0001410578-23-000086:mdna:17]
Selling, general and administrative (SG&A) expenses were $51.3 million (25.0% of net sales) for the first quarter of 2023, compared with $46.6 million (26.3% of net sales) for the first quarter of 2022. The increase in SG&A in the first quarter of 2023 compared to the first quarter of 2022 was mainly due to higher expenses at Corporate due to the executive management transition (primarily relocation and recruiting costs) and an increase within the A&D and USG segments due to higher sales and commissions.

[0001410578-23-000086:mdna:18]
[same as prior period, unchanged from 0001410578-22-002168:mdna:23]

[0001410578-23-000086:mdna:19]
Amortization of intangible assets was $6.9 million and $6.5 million for the first quarter of 2023 and 2022, respectively. Amortization expenses consist of amortization of acquired intangible assets from acquisitions and other identifiable intangible assets (primarily software). The increase in amortization expense in the first quarter of 2023 compared to the first quarter of 2022 was mainly due to an increase in amortization of capitalized software.

[0001410578-23-000086:mdna:20]
OTHER EXPENSES, NET

[0001410578-23-000086:mdna:21]
Other expenses, net, were $0.4 million in the first quarter of 2023 compared to other expenses, net, of $0.1 million in the first quarter of 2022. The principal component of other expenses, net, in the first quarter of 2023 included approximately $0.2 million of restructuring charges within the A&D segment. There were no individually significant items in other expenses (income), net, in the first quarter of 2022.

[0001410578-23-000086:mdna:22]
[same as prior period, unchanged from 0001410578-22-002168:mdna:28]

[0001410578-23-000086:mdna:23]
The Company evaluates the performance of its operating segments based on EBIT, and provides EBIT on a consolidated basis, which is a non-GAAP financial measure. Please refer to the discussion of non-GAAP financial measures in Note 6 to the Consolidated Financial Statements, above. EBIT was $20.6 million (10.0% of net sales) for the first quarter of 2023 compared to $15.6 million (8.8% of net sales) for the first quarter of 2022.

[0001410578-23-000086:mdna:24]
The following table presents a reconciliation of EBIT to a GAAP financial measure:

[0001410578-23-000086:mdna:25]
| ​ | ​ | Three Months Ended |
| ​ | ​ | December 31, |
| (In thousands) |  | 2022 |  | 2021 |
| Net earnings | ​ | $ | 14,727 | ​ | ​ | 11,524 |
| Plus: Interest expense, net | ​ |  | 1,658 | ​ | ​ | 733 |
| Plus: Income tax expense | ​ |  | 4,172 | ​ | ​ | 3,313 |
| Consolidated EBIT | ​ | $ | 20,557 | ​ | ​ | 15,570 |

[0001410578-23-000086:mdna:26]
[same as prior period, unchanged from 0001410578-22-002168:mdna:32]

[0001410578-23-000086:mdna:27]
EBIT was $12.5 million (15.1% of net sales) in the first quarter of 2023 compared to $10.0 million (14.2% of net sales) in the first quarter of 2022. The increase in EBIT in the first quarter of 2023 compared to the first quarter of 2022 was mainly due to higher sales volumes at Mayday, Crissair & PTI partially offset by a decrease in EBIT at Westland due to the lower sales volumes mentioned above. In addition, EBIT in the first quarter of 2023 was negatively impacted by a $0.2 million of restructuring charges (primarily severance) within the A&D segment.

[0001410578-23-000086:mdna:28]
[same as prior period, unchanged from 0001410578-22-002168:mdna:34]

[0001410578-23-000086:mdna:29]
EBIT was $16.1 million (22.7% of net sales) in the first quarter of 2023 compared to $13.4 million (21.1% of net sales) in the first quarter of 2022. The increase in EBIT in the first quarter of 2023 compared to the first quarter of 2022 was mainly due to the higher sales volumes at both Doble and NRG in the first quarter of 2023.

[0001410578-23-000086:mdna:30]
[same as prior period, unchanged from 0001410578-22-002168:mdna:36]

[0001410578-23-000086:mdna:31]
EBIT was $5.4 million (10.5% of net sales) in the first quarter of 2023 compared to $4.0 million (9.2% of net sales) in the first quarter of 2022. The increase in EBIT in the first quarter of 2023 compared to the first quarter of 2022 was primarily due to higher sales volumes from the segment’s U.S. and European operations.

[0001410578-23-000086:mdna:32]
[same as prior period, unchanged from 0001410578-22-002168:mdna:38]

[0001410578-23-000086:mdna:33]
Corporate costs included in EBIT were $13.5 million and $11.7 million in the first quarter of 2023 and 2022, respectively. The increase in Corporate costs in the first quarter of 2023 compared to the first quarter of 2022 was mainly due to approximately $0.8 million of management transition costs (mainly relocation and recruiting) related to the Company’s CEO transition.

[0001410578-23-000086:mdna:34]
[same as prior period, unchanged from 0001410578-22-002168:mdna:41]

[0001410578-23-000086:mdna:35]
Interest expense was $1.7 million and $0.7 million in the first quarter of 2023 and 2022, respectively. The increase in interest expense in the first quarter of 2023 as compared to the first quarter of 2022 was mainly due to higher average interest rates (4.56% in the first quarter of 2023 compared to 1.17% in the first quarter of 2022).

[0001410578-23-000086:mdna:36]
[same as prior period, unchanged from 0001410578-22-002168:mdna:43]

[0001410578-23-000086:mdna:37]
The effective income tax rate was 22.1% in the first quarter of 2023 compared to 22.3% in the first quarter of 2022. Income tax expense in the first quarter of 2023 was favorably impacted by excess tax benefit related to the vesting of share-based compensation and the release of a valuation allowance on acquired federal net operating losses, decreasing the effective tax rate for the quarter by 1.3%. Income tax expense in the first quarter of 2022 was favorably impacted by excess tax benefit related to the vesting of share-based compensation, decreasing the effective tax rate for the quarter by 1.7%.

[0001410578-23-000086:mdna:38]
[same as prior period, unchanged from 0001410578-22-002168:mdna:45]

[0001410578-23-000086:mdna:39]
The Company’s overall financial position and liquidity remain strong. Working capital (current assets less current liabilities) decreased to $242.0 million at December 31, 2022 from $254.5 million at September 30, 2022  mainly driven by a decrease in cash including repayment of debt. Inventories increased by $19.3 million during this period mainly due to an $11.0 million increase within the USG segment, a $4.3 million increase within the Aerospace & Defense segment and a $4.0 million increase within the Test segment resulting primarily from the timing of receipt of raw materials to meet anticipated demand and an increase in work in process inventories due to timing of manufacturing existing orders. Accrued salaries decreased by $13.2 million due to timing of salaries and bonus payments.

[0001410578-23-000086:mdna:40]
Net cash used by operating activities was $(9.0) million and net cash provided by operating activities was $1.9 million in the first quarters of 2023 and 2022, respectively. The decrease in net cash provided by operating activities in the first quarter of 2023 as compared to the first quarter of 2022 was mainly driven by higher inventory balances, lower accounts payable and accrued expenses and the effect of deferred taxes.

[0001410578-23-000086:mdna:41]
Capital expenditures were $4.8 million and $14.1 million in the first quarters of 2023 and 2022, respectively. The decrease in the first quarter of 2023 was mainly due to the purchase of the NRG building of approximately $10 million in the first quarter of 2022. In addition, the Company incurred expenditures for capitalized software of approximately $2.8 million and $2.0 million in the first quarters of 2023 and 2022, respectively.

[0001410578-23-000086:mdna:42]
Credit Facility

[0001410578-23-000086:mdna:43]
At December 31, 2022, the Company had approximately $360 million available to borrow under its bank credit facility, a $250 million increase option, and $51.9 million cash on hand. At December 31, 2022, the Company had $132 million of outstanding borrowings under the credit facility in addition to outstanding letters of credit of $8.2 million. Cash flow from operations and borrowings under the Company’s credit facility are expected to meet the Company’s capital requirements and operational needs for the foreseeable future. The Company’s ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.

[0001410578-23-000086:mdna:44]
[same as prior period, unchanged from 0001410578-22-002168:mdna:54]

[0001410578-23-000086:mdna:45]
During the first quarter of 2023, the Company repurchased approximately 58,000 shares for $5.1 million, of which $4.1 million was paid during the quarter and the remainder was settled in January 2023. For further information on the share repurchases during the first quarter of 2023, see Part II, Item 2 of this Report.

[0001410578-23-000086:mdna:46]
[same as prior period, unchanged from 0001410578-22-002168:mdna:56]

[0001410578-23-000086:mdna:47]
A dividend of $0.08 per share, totaling $2.1 million, was paid on October 18, 2022 to stockholders of record as of October 4, 2022. Subsequent to December 31, 2022, a quarterly dividend of $0.08 per share, totaling $2.1 million, was paid on January 20, 2023 to stockholders of record as of January 5, 2023.

[0001410578-23-000086:mdna:48]
Subsequent Event

[0001410578-23-000086:mdna:49]
On February 1, 2023, the Company acquired CMT Materials, LLC and its affiliate Engineered Syntactic Systems, LLC (CMT) for a purchase price of $18 million. CMT, based in Attleboro, Massachusetts, is a leading supplier of syntactic materials for buoyancy and specialty applications. The business has annualized sales of approximately $15 million and will become part of Globe within the A&D segment.

[0001410578-23-000086:mdna:50]
[same as prior period, unchanged from 0001410578-22-002168:mdna:58]

[0001410578-23-000086:mdna:51]
Management has evaluated the accounting policies used in the preparation of the Company’s financial statements and related notes and believes those policies to be reasonable and appropriate. Certain of these accounting policies require the application of significant judgment by Management in selecting appropriate assumptions for calculating financial estimates. By their nature, these judgments are subject to an inherent degree of uncertainty. These judgments are based on historical experience, trends in the industry, information provided by customers and information available from other outside sources, as appropriate. The most significant areas involving Management judgments and estimates may be found in the Critical Accounting Policies section of Management’s Discussion and Analysis and in Note 1 to the Consolidated Financial Statements contained in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2022.

[0001410578-23-000086:mdna:52]
[same as prior period, unchanged from 0001410578-22-002168:mdna:60]

[0001410578-23-000086:mdna:53]
Contingencies

[0001410578-23-000086:mdna:54]
As a normal incident of the business in which the Company is engaged, various claims, charges and litigation are asserted or commenced against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. In the opinion of Management, the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company, are adequately reserved, are covered by insurance, or would not have a material adverse effect on the Company’s results from operations, capital expenditures, or competitive position.

[0001410578-23-000086:mdna:55]
[same as prior period, unchanged from 0001410578-22-002168:mdna:63]

[0001410578-23-000086:mdna:56]
Investors are cautioned that such statements are only predictions and speak only as of the date of this Form 10-Q, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment, including but not limited to those described in Item 1A, “Risk Factors,” of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2022, and the following: the continuing impact of the COVID-19 pandemic including the effects of known or unknown COVID-19 variants, labor shortages, facility closures, shelter in place policies or quarantines, material shortages, transportation delays, termination or delays of Company contracts and the inability of our suppliers or customers to perform; the impacts of natural disasters on the Company’s operations and those of the Company’s customers and suppliers; the timing and content of future contract awards or customer orders; the appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer contracts or orders; weakening

[0001410578-23-000086:mdna:57]
of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties; the availability of selected acquisitions; delivery delays or defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability of certain raw materials; inflationary pressures on the Company’s costs of materials, components and supplies; labor disputes; changes in U.S. tax laws and regulations; other changes in laws and regulations including but not limited to changes in accounting standards and foreign taxation; changes in interest rates; costs relating to environmental matters arising from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the integration of recently acquired businesses.
