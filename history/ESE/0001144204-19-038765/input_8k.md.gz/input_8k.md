# ESE 8-K — 0001144204-19-038567 filed 2019-08-08

## item codes, every 8-K on or before 2019-08-09

- 2019-08-08 0001144204-19-038567 — 2.02, 7.01, 9.01
- 2019-05-07 0001144204-19-024241 — 2.02, 5.02, 7.01, 9.01
- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2019-08-09

- none on or before 2019-08-09

## item 2.02 — earnings release, exhibit 99.1

[0001144204-19-038567:8k_2_02:1]
EX-99.1
2
tv526435_ex99-1.htm
EXHIBIT 99.1

[0001144204-19-038567:8k_2_02:2]
EXHIBIT 99.1

[0001144204-19-038567:8k_2_02:3]
| NEWS FROM |  |

[0001144204-19-038567:8k_2_02:4]
For more information contact:

[0001144204-19-038567:8k_2_02:5]
Kate Lowrey

[0001144204-19-038567:8k_2_02:6]
Director, Investor Relations

[0001144204-19-038567:8k_2_02:7]
ESCO Technologies Inc.

[0001144204-19-038567:8k_2_02:8]
(314)
213-7277

[0001144204-19-038567:8k_2_02:9]
ESCO ANNOUNCES THIRD QUARTER FISCAL
2019 RESULTS

[0001144204-19-038567:8k_2_02:10]
- Q3 GAAP EPS $0.77 (Includes $0.04
of Cost Reduction Charges) -

[0001144204-19-038567:8k_2_02:11]
- Q3 Adjusted EPS $0.81 (Beats Guidance
and Consensus / 11 Percent above Q3 2018) –

[0001144204-19-038567:8k_2_02:12]
ST. LOUIS, August 8, 2019 – ESCO Technologies
Inc. (NYSE: ESE) (ESCO, or the Company) today reported its operating results for the third quarter ended June 30, 2019 (Q3 2019),
compared to the quarter ended June 30, 2018 (Q3 2018).

[0001144204-19-038567:8k_2_02:13]
The financial results presented include
certain non-GAAP financial measures such as EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS, as defined within the “Non-GAAP
Financial Measures” described below. Any non-GAAP financial measures presented are reconciled to their respective GAAP equivalents.

[0001144204-19-038567:8k_2_02:14]
Management believes these non-GAAP financial
measures are useful in assessing the ongoing operational profitability of the Company’s business segments, and therefore,
allow shareholders better visibility into the Company’s underlying operations. See “Non-GAAP Financial Measures”
described below.

[0001144204-19-038567:8k_2_02:15]
Earnings Summary

[0001144204-19-038567:8k_2_02:16]
Q3 2019 GAAP EPS of $0.77 per share included
$0.04 per share of previously described cost reduction charges in Technical Packaging and at Doble, and costs incurred to move
the aircraft / aerospace business from VACCO to PTI. The $0.04 per share was excluded when determining Q3 2019 Adjusted EPS of
$0.81 per share. GAAP net earnings were $20 million in Q3 2019.

[0001144204-19-038567:8k_2_02:17]
Q3 2018 GAAP EPS and Adjusted EPS were $0.73
per share with GAAP net earnings of $19 million.

[0001144204-19-038567:8k_2_02:18]
Q3 2019 Adjusted EPS of $0.81 per share
exceeded Management’s previous guidance of $0.75 to $0.80 per share, and increased 11 percent over Q3 2018 Adjusted EPS
of $0.73 per share.

[0001144204-19-038567:8k_2_02:19]
Adjusted EBITDA was $38 million in Q3 2019,
reflecting a 9 percent increase over Q3 2018 Adjusted EBITDA of $35 million.

[0001144204-19-038567:8k_2_02:20]
YTD 2019 GAAP EPS was $2.15 per share (favorably
impacted by the gain on the Doble building sale) compared to YTD 2018 GAAP EPS of $2.45 per share (favorably impacted by the one-time
benefit recognized as a result of U.S. Tax Reform).

[0001144204-19-038567:8k_2_02:21]
YTD 2019 Adjusted EPS increased 32 percent
to $2.04 per share compared to $1.55 per share YTD 2018. Adjusted EPS in both periods excludes the one-time gains net of certain
restructuring charges identified earlier.

[0001144204-19-038567:8k_2_02:22]
YTD 2019 Adjusted EBITDA was $100 million,
reflecting a 15 percent increase over YTD 2018 Adjusted EBITDA of $87 million.

[0001144204-19-038567:8k_2_02:23]
Operating Highlights

[0001144204-19-038567:8k_2_02:24]
|  | · | Q3 2019 sales increased 4 percent to $200 million compared to $192 million in Q3 2018 and YTD 2019 sales increased 7 percent to $576 million compared to $540 million YTD 2018. |

[0001144204-19-038567:8k_2_02:25]
|  | · | On a segment basis, Q3 2019 Filtration sales exceeded expectations and increased 19 percent from Q3 2018 with all operating units contributing to the growth driven by significantly higher aerospace (commercial and defense) and navy sales. Test sales decreased in Q3 2019 as a result of the timing of the completion of large projects within the respective periods. USG sales from Doble increased 8 percent, while NRG’s sales to renewable energy customers decreased, resulting in a net decrease in USG sales. Technical Packaging sales were generally flat due to the timing of new product introductions. |

[0001144204-19-038567:8k_2_02:26]
|  | · | SG&A expenses increased in Q3 2019 compared to Q3 2018 primarily as a result of higher sales commissions and normal cost of living adjustments, partially offset by cost reductions. |

[0001144204-19-038567:8k_2_02:27]
|  | · | Entered orders were $196 million in Q3 2019 (book-to-bill of 0.98x) and were $626 million YTD 2019 (book-to-bill of 1.09x) which resulted in an ending backlog of $432 million at June 30, 2019, an increase of $50 million, or 13 percent, from September 30, 2018. |

[0001144204-19-038567:8k_2_02:28]
|  | · | The Q3 2019 effective income tax rate was generally consistent with the rate in Q3 2018. |

[0001144204-19-038567:8k_2_02:29]
|  | · | 2019 net cash provided by operating activities was $37 million resulting in $179 million of net debt outstanding (total borrowings less cash on hand) at June 30, 2019, and a 1.5x leverage ratio. Cash flow in Q3 was negatively impacted by the timing of several large cash receipts at VACCO related to Navy projects in process which will be received in Q4 2019. |

[0001144204-19-038567:8k_2_02:30]
Chairman’s Commentary –
Q3 2019

[0001144204-19-038567:8k_2_02:31]
Vic Richey, Chairman and Chief Executive
Officer, commented, “I’m pleased with our Q3 operating results, which once again came in above expectations and resulted
in Adjusted EPS exceeding the top end of our guidance range. Solid operational performance across the Company drove the Q3 results
as all four operating segments exceeded their Adjusted EBIT commitments during the Quarter. Our Filtration businesses exceeded
our profit expectations by over 12 percent, and Doble, within the USG segment, beat expectations on higher than expected sales
in Q3.

[0001144204-19-038567:8k_2_02:32]
“Comparing Q3 2019 to Q3 2018, we
increased sales by 4 percent driven by the nearly 20 percent sales growth in Filtration, partially muted by the timing of sales
recognized on a few large projects in the Test business, and continued headwinds in our renewable energy business.

[0001144204-19-038567:8k_2_02:33]
“We improved our YTD 2019 Adjusted
EBITDA by 15 percent as every operating segment improved their margins over YTD 2018. Our outlook for the balance of the year remains
solid.

[0001144204-19-038567:8k_2_02:34]
“We announced the acquisition of Globe
Composite Solutions, LLC (Globe) in early July and I’m very happy with the progress we are making in bringing them on board.
The initial phases of integration are off to a great start and I’m excited to work with the outstanding leadership team and
the dedicated employees that I met earlier this month. Globe’s products, processes and customer relationships are an excellent
addition to our portfolio and our complementary skill sets will allow us to create additional avenues for meaningful growth across
our shared customer base.

[0001144204-19-038567:8k_2_02:35]
“On the M&A front we continue
to evaluate a robust pipeline of opportunities in both Filtration and USG and continue to work these aggressively, and I remain
hopeful that we will be able to add to our portfolio in the near future. Consistent with our history, we will remain prudent and
committed to our disciplined approach of balancing ROIC and protecting our balance sheet.

[0001144204-19-038567:8k_2_02:36]
“The Doble headquarters relocation
from Watertown to Marlborough is going smoothly and we expect to be moved in and fully operational by December 31, 2019. The Doble
team is looking forward to having all of its Boston area staff co-located in a single, customer-friendly facility as we all believe
this will further enhance our operational efficiency and effectiveness, while lowering our facility operating costs.

[0001144204-19-038567:8k_2_02:37]
“As we look to wrap up 2019, we plan
to build on the successes we achieved this year and expect to continue benefitting from our disciplined operating culture and our
lower cost structure. Our solid market positions and tangible growth opportunities across the Company provide us with a favorable
view of the future with our goal remaining unchanged – to increase long-term shareholder value.”

[0001144204-19-038567:8k_2_02:38]
Dividend Payment

[0001144204-19-038567:8k_2_02:39]
The
next quarterly cash dividend of $0.08 per share will be paid on October 17, 2019 to stockholders of record on October 3, 2019.

[0001144204-19-038567:8k_2_02:40]
Previously Disclosed Cost Reduction
/ Restructuring Actions

[0001144204-19-038567:8k_2_02:41]
Refer to the Company’s November 15,
2018 earnings release for details of the cost reduction and restructuring actions related to the Doble building sale and relocation,
Technical Packaging’s cost reduction actions, and VACCO’s aircraft / aerospace business move to PTI.

[0001144204-19-038567:8k_2_02:42]
All of these actions are intended to improve
operating efficiency, enhance ROIC, generate additional free cash flow, and enhance the Company’s competitiveness across
several end-markets, thereby, accelerating sales and earnings growth in the future.

[0001144204-19-038567:8k_2_02:43]
Updated Business Outlook – 2019

[0001144204-19-038567:8k_2_02:44]
Management’s expects 2019 Adjusted
EPS in the range of $3.05 to $3.10 per share, which is consistent with the details outlined in the Business Outlook presented in
the May 7, 2019 release. The expected operating results from the previously announced acquisition of Globe are not reflected in
the Adjusted EPS range noted above as Globe’s detailed financial plan is currently in the process of being finalized.

[0001144204-19-038567:8k_2_02:45]
The timing of quarterly sales and earnings
throughout 2019 compared to 2018 impacts the quarterly comparisons as 2019’s growth is more balanced on a quarterly basis
compared to the heavily weighted second half profile reported in 2018.

[0001144204-19-038567:8k_2_02:46]
Conference Call

[0001144204-19-038567:8k_2_02:47]
The Company will host a conference call
today, August 8, at 4:00 p.m. Central Time, to discuss the Company’s Q3 2019 results. A live audio webcast will be available
on the Company’s website at www.escotechnologies.com. Please access the website at least 15 minutes prior to the call to
register, download and install any necessary audio software. A replay of the conference call will be available on the Company’s
website noted above or by phone (dial 1-855-859-2056 and enter the pass code 3855869).

[0001144204-19-038567:8k_2_02:48]
Forward-Looking Statements

[0001144204-19-038567:8k_2_02:49]
Statements in this press release regarding
the timing and amounts of the Company’s expected quarterly, 2019 full year and beyond results, revenue and sales growth,
EPS, Adjusted EPS, EPS growth, cash, EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA, the realization of operational efficiencies,
the Company’s competitiveness and the costs and savings resulting from operational improvements and cost reduction actions,
the Company’s ability to increase operating margins, realize financial goals and increase shareholder value, the success
of acquisition efforts, the long-term success of the Company, and any other statements which are not strictly historical are “forward-looking”
statements within the meaning of the safe harbor provisions of the federal securities laws.

[0001144204-19-038567:8k_2_02:50]
Investors are cautioned that such statements
are only predictions and speak only as of the date of this release, and the Company undertakes no duty to update them except as
may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from
those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and
business environment including but not limited to those described in Item 1A, “Risk Factors”, of the Company’s
Annual Report on Form 10-K for the fiscal year ended September 30, 2018, and the following: the success of the Company’s
competitors; weakening of economic conditions in served markets; changes in customer demands or customer insolvencies; competition;
intellectual property rights; technical difficulties; delivery delays or defaults by customers; material changes in the costs and
availability of certain raw materials; the appropriation, allocation and availability of Government funds; the termination for
convenience of Government and other customer contracts; the timing and content of future contract awards or customer orders; performance
issues with key customers, suppliers and subcontractors; labor disputes; the impacts of natural disasters on the Company’s
operations and those of the Company’s customers and suppliers; changes in laws and regulations, including but not limited
to changes in accounting standards, taxation requirements, and new or modified tariffs; changes in interest rates; costs relating
to environmental matters arising from current or former facilities; financial exposure in connection with Company guarantees of
certain Aclara contracts; the availability of select acquisitions; and the uncertainty regarding the ultimate resolution of current
disputes, claims, litigation or arbitration.

[0001144204-19-038567:8k_2_02:51]
Non-GAAP Financial Measures

[0001144204-19-038567:8k_2_02:52]
The financial measures EBIT, EBITDA, Adjusted
EBITDA and Adjusted EPS are presented in this press release. The Company defines “EBIT” as earnings before interest
and taxes, “EBITDA” as earnings before interest, taxes, depreciation and amortization, “Adjusted EBITDA”
as EBITDA excluding certain defined charges, and “Adjusted EPS” as GAAP earnings per share (EPS) excluding the net
impact of the items described above which were $0.04 per share in Q3 2019.

[0001144204-19-038567:8k_2_02:53]
EBIT, EBITDA, Adjusted EBITDA and Adjusted
EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management believes that
EBIT, EBITDA and Adjusted EBITDA are useful in assessing the operational profitability of the Company’s business segments
because they exclude interest, taxes, depreciation and amortization, which are generally accounted for across the entire Company
on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company
as well as incentive compensation. The Company believes that the presentation of EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS
provides important supplemental information to investors by facilitating comparisons with other companies, many of which use similar
non-GAAP financial measures to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace
any measures of performance determined in accordance with GAAP.

[0001144204-19-038567:8k_2_02:54]
ESCO, headquartered in St. Louis, Missouri:
Manufactures highly-engineered filtration and fluid control products for the aviation, space and process markets worldwide; is
the industry leader in RF shielding and EMC test products; provides diagnostic instruments, software and services for the benefit
of industrial power users and the electric utility and renewable energy industries; and, produces custom thermoformed packaging,
pulp-based packaging, and specialty products for medical and commercial markets. Further information regarding ESCO and its subsidiaries
is available on the Company’s website at www.escotechnologies.com.

[0001144204-19-038567:8k_2_02:55]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001144204-19-038567:8k_2_02:56]
Condensed Consolidated Statements of Operations
(Unaudited)

[0001144204-19-038567:8k_2_02:57]
(Dollars in thousands, except per share
amounts)

[0001144204-19-038567:8k_2_02:58]
|  |  | Three Months Ended June 30, 2019 |  |  |  | Three Months Ended June 30, 2018 |  |
| Net Sales |  | $ | 199,766 |  |  |  |  | 192,223 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 122,172 |  |  |  |  | 122,805 |  |
| Selling, general and administrative expenses |  |  | 43,400 |  |  |  |  | 39,910 |  |
| Amortization of intangible assets |  |  | 4,693 |  |  |  |  | 4,605 |  |
| Interest expense |  |  | 1,973 |  |  |  |  | 2,243 |  |
| Other (income) expenses, net |  |  | 2,636 |  |  |  |  | (656 | ) |
| Total costs and expenses |  |  | 174,874 |  |  |  |  | 168,907 |  |
| Earnings before income taxes |  |  | 24,892 |  |  |  |  | 23,316 |  |
| Income taxes |  |  | 4,825 |  |  |  |  | 4,297 |  |
| Net earnings |  | $ | 20,067 |  |  |  |  | 19,019 |  |
| Diluted EPS - GAAP |  | $ | 0.77 |  |  |  |  | 0.73 |  |
| Diluted EPS - As Adjusted |  | $ | 0.81 |  | (1) |  |  | 0.73 |  |
| Diluted average common shares O/S: |  |  | 26,109 |  |  |  |  | 26,050 |  |

[0001144204-19-038567:8k_2_02:59]
|  | (1) | Q3 2019 Adjusted EPS excluded $0.04 per share net impact of restructuring charges incurred primarily at Plastique, Doble and PTI/VACCO during the third quarter of 2019. |

[0001144204-19-038567:8k_2_02:60]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001144204-19-038567:8k_2_02:61]
Condensed Consolidated Statements of Operations (Unaudited)

[0001144204-19-038567:8k_2_02:62]
(Dollars in thousands, except per share amounts)

[0001144204-19-038567:8k_2_02:63]
|  |  | Nine Months Ended June 30, 2019 |  |  |  | Nine Months Ended June 30, 2018 |  |
| Net Sales |  | $ | 576,312 |  |  |  |  | 540,496 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 363,026 |  |  |  |  | 346,911 |  |
| Selling, general and administrative expenses |  |  | 126,066 |  |  |  |  | 122,813 |  |
| Amortization of intangible assets |  |  | 13,965 |  |  |  |  | 13,615 |  |
| Interest expense |  |  | 5,788 |  |  |  |  | 6,464 |  |
| Other (income) expenses, net |  |  | (2,037 | ) |  |  |  | 992 |  |
| Total costs and expenses |  |  | 506,808 |  |  |  |  | 490,795 |  |
| Earnings before income taxes |  |  | 69,504 |  |  |  |  | 49,701 |  |
| Income taxes |  |  | 13,323 |  |  |  |  | (13,983 | ) |
| Net earnings |  | $ | 56,181 |  |  |  |  | 63,684 |  |
| Diluted EPS - GAAP |  | $ | 2.15 |  |  |  |  | 2.45 |  |
| Diluted EPS - As Adjusted |  | $ | 2.04 |  | (1) |  |  | 1.55 | (2) |
| Diluted average common shares O/S: |  | $ | 26,090 |  |  |  |  | 26,042 |  |

[0001144204-19-038567:8k_2_02:64]
|  | (1) | YTD Q3 2019 Adjusted EPS excluded $0.11 per share net impact mainly from the gain on the sale of the Doble Watertown property partially offset by certain restructuring charges primarily at Plastique, PTI/VACCO & Doble. |

[0001144204-19-038567:8k_2_02:65]
|  | (2) | YTD Q3 2018 Adjusted EPS excluded $0.90 per share net impact of the $25 million tax benefit recorded related to U.S. Tax Reform partially offset by restructuring charges incurred at Doble & PTI during the first nine months of 2018. |

[0001144204-19-038567:8k_2_02:66]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001144204-19-038567:8k_2_02:67]
Condensed Business Segment Information (Unaudited)

[0001144204-19-038567:8k_2_02:68]
(Dollars in thousands)

[0001144204-19-038567:8k_2_02:69]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | Q3 2019 |  |  | Q3 2018 |  |  | Q3 2019 |  |  | Q3 2018 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 83,067 |  |  |  | 69,721 |  |  |  | 83,067 |  |  |  | 69,721 |  |
| Test |  |  | 42,298 |  |  |  | 45,034 |  |  |  | 42,298 |  |  |  | 45,034 |  |
| USG |  |  | 52,894 |  |  |  | 55,489 |  |  |  | 52,894 |  |  |  | 55,489 |  |
| Technical Packaging |  |  | 21,507 |  |  |  | 21,979 |  |  |  | 21,507 |  |  |  | 21,979 |  |
| Totals |  | $ | 199,766 |  |  |  | 192,223 |  |  |  | 199,766 |  |  |  | 192,223 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 19,039 |  |  |  | 14,292 |  |  |  | 19,344 |  |  |  | 14,292 |  |
| Test |  |  | 5,927 |  |  |  | 5,902 |  |  |  | 5,927 |  |  |  | 5,902 |  |
| USG |  |  | 10,148 |  |  |  | 11,528 |  |  |  | 10,467 |  |  |  | 11,528 |  |
| Technical Packaging |  |  | 1,625 |  |  |  | 2,505 |  |  |  | 2,268 |  |  |  | 2,505 |  |
| Corporate |  |  | (9,874 | ) |  |  | (8,668 | ) |  |  | (9,679 | ) |  |  | (8,668 | ) |
| Consolidated EBIT |  |  | 26,865 |  |  |  | 25,559 |  |  |  | 28,327 |  |  |  | 25,559 |  |
| Less: Interest expense |  |  | (1,973 | ) |  |  | (2,243 | ) |  |  | (1,973 | ) |  |  | (2,243 | ) |
| Less: Income tax expense |  |  | (4,825 | ) |  |  | (4,297 | ) |  |  | (5,126 | ) |  |  | (4,297 | ) |
| Net earnings |  | $ | 20,067 |  |  |  | 19,019 |  |  |  | 21,228 |  |  |  | 19,019 |  |
| Note 1: Adjusted net earnings were $21.2 million in Q3 '19 which excluded $1.4 million (or $0.04 per share) net impact of the restructuring charges incurred at Doble, Plastique, PTI and VACCO during the third quarter of 2019. |  |

[0001144204-19-038567:8k_2_02:70]
| EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  | Adjusted |  |
|  |  | Q3 2019 |  |  | Q3 2018 |  |  | Q3 2019 |  |
| Consolidated EBITDA |  | $ | 36,849 |  |  |  | 35,111 |  |  |  | 38,311 |  |
| Less: Depr & Amort |  |  | (9,984 | ) |  |  | (9,552 | ) |  |  | (9,984 | ) |
| Consolidated EBIT |  |  | 26,865 |  |  |  | 25,559 |  |  |  | 28,327 |  |
| Less: Interest expense |  |  | (1,973 | ) |  |  | (2,243 | ) |  |  | (1,973 | ) |
| Less: Income tax expense |  |  | (4,825 | ) |  |  | (4,297 | ) |  |  | (5,126 | ) |
| Net earnings |  | $ | 20,067 |  |  |  | 19,019 |  |  |  | 21,228 |  |

[0001144204-19-038567:8k_2_02:71]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001144204-19-038567:8k_2_02:72]
Condensed Business Segment Information (Unaudited)

[0001144204-19-038567:8k_2_02:73]
(Dollars in thousands)

[0001144204-19-038567:8k_2_02:74]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | YTD Q3 |  |  | YTD Q3 |  |  | YTD Q3 |  |  | YTD Q3 |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 228,769 |  |  |  | 195,531 |  |  |  | 228,769 |  |  |  | 195,531 |  |
| Test |  |  | 126,459 |  |  |  | 123,368 |  |  |  | 126,459 |  |  |  | 123,368 |  |
| USG |  |  | 157,639 |  |  |  | 157,942 |  |  |  | 157,639 |  |  |  | 157,942 |  |
| Technical Packaging |  |  | 63,445 |  |  |  | 63,655 |  |  |  | 63,445 |  |  |  | 63,655 |  |
| Totals |  | $ | 576,312 |  |  |  | 540,496 |  |  |  | 576,312 |  |  |  | 540,496 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 47,092 |  |  |  | 35,056 |  |  |  | 47,857 |  |  |  | 35,504 |  |
| Test |  |  | 14,791 |  |  |  | 13,797 |  |  |  | 14,791 |  |  |  | 13,797 |  |
| USG |  |  | 40,461 |  |  |  | 27,805 |  |  |  | 33,567 |  |  |  | 30,074 |  |
| Technical Packaging |  |  | 3,333 |  |  |  | 5,355 |  |  |  | 4,664 |  |  |  | 5,355 |  |
| Corporate |  |  | (30,385 | ) |  |  | (25,848 | ) |  |  | (29,716 | ) |  |  | (25,977 | ) |
| Consolidated EBIT |  |  | 75,292 |  |  |  | 56,165 |  |  |  | 71,163 |  |  |  | 58,753 |  |
| Less: Interest expense |  |  | (5,788 | ) |  |  | (6,464 | ) |  |  | (5,788 | ) |  |  | (6,464 | ) |
| Less: Income tax |  |  | (13,323 | ) |  |  | 13,983 |  |  |  | (12,025 | ) |  |  | (11,002 | ) |
| Net earnings |  | $ | 56,181 |  |  |  | 63,684 |  |  |  | 53,350 |  |  |  | 41,287 |  |
| Note 1: Adjusted net earnings were $53.4 million in YTD Q3 '19 which excluded $2.8 million (or $0.11 per share) net impact of the gain on the sale of the Doble Watertown property partially offset by charges related to restructuring actions at Doble, Plastique, PTI & VACCO. |  |
| Note 2: Adjusted net earnings were $41.3 million in YTD Q3 '18 which excluded $2.7 million (or $0.10 per share) net impact of the restructuring charges incurred at Doble and PTI during the first nine months of 2018, and the $25 million (or $1.00 per share) tax benefit recorded related to U.S. Tax Reform. |  |

[0001144204-19-038567:8k_2_02:75]
| EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  | Adjusted |  |  | Adjusted |  |
|  |  | YTD Q3 |  |  | YTD Q3 |  |  | YTD Q3 |  |  | YTD Q3 |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Consolidated EBITDA |  | $ | 104,055 |  |  |  | 84,515 |  |  |  | 99,926 |  |  |  | 87,103 |  |
| Less: Depr & Amort |  |  | (28,763 | ) |  |  | (28,350 | ) |  |  | (28,763 | ) |  |  | (28,350 | ) |
| Consolidated EBIT |  |  | 75,292 |  |  |  | 56,165 |  |  |  | 71,163 |  |  |  | 58,753 |  |
| Less: Interest expense |  |  | (5,788 | ) |  |  | (6,464 | ) |  |  | (5,788 | ) |  |  | (6,464 | ) |
| (Less) Plus: Income tax |  |  | (13,323 | ) |  |  | 13,983 |  |  |  | (12,025 | ) |  |  | (11,002 | ) |
| Net earnings |  | $ | 56,181 |  |  |  | 63,684 |  |  |  | 53,350 |  |  |  | 41,287 |  |

[0001144204-19-038567:8k_2_02:76]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001144204-19-038567:8k_2_02:77]
Condensed Consolidated Balance Sheets (Unaudited)

[0001144204-19-038567:8k_2_02:78]
(Dollars in thousands)

[0001144204-19-038567:8k_2_02:79]
|  |  | June 30, 2019 |  |  | September 30, 2018 |  |
| Assets |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 38,956 |  |  |  | 30,477 |  |
| Accounts receivable, net |  |  | 168,675 |  |  |  | 163,740 |  |
| Contract assets |  |  | 99,499 |  |  |  | 53,034 |  |
| Inventories |  |  | 126,816 |  |  |  | 135,416 |  |
| Other current assets |  |  | 16,260 |  |  |  | 13,356 |  |
| Total current assets |  |  | 450,206 |  |  |  | 396,023 |  |
| Property, plant and equipment, net |  |  | 151,545 |  |  |  | 134,954 |  |
| Intangible assets, net |  |  | 336,625 |  |  |  | 345,353 |  |
| Goodwill |  |  | 381,683 |  |  |  | 381,652 |  |
| Other assets |  |  | 6,036 |  |  |  | 7,140 |  |
|  |  | $ | 1,326,095 |  |  |  | 1,265,122 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Short-term borrowings and current |  | $ | 20,921 |  |  |  | 20,000 |  |
| maturities of long-term debt |  |  |  |  |  |  |  |  |
| Accounts payable |  |  | 59,329 |  |  |  | 63,033 |  |
| Contract liabilities |  |  | 53,758 |  |  |  | 49,035 |  |
| Other current liabilities |  |  | 65,728 |  |  |  | 68,462 |  |
| Total current liabilities |  |  | 199,736 |  |  |  | 200,530 |  |
| Deferred tax liabilities |  |  | 66,286 |  |  |  | 64,794 |  |
| Other liabilities |  |  | 51,266 |  |  |  | 40,388 |  |
| Long-term debt |  |  | 197,000 |  |  |  | 200,000 |  |
| Shareholders' equity |  |  | 811,807 |  |  |  | 759,410 |  |
|  |  | $ | 1,326,095 |  |  |  | 1,265,122 |  |

[0001144204-19-038567:8k_2_02:80]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001144204-19-038567:8k_2_02:81]
Consolidated Statements of Cash Flows (Unaudited)

[0001144204-19-038567:8k_2_02:82]
(Dollars in thousands)

[0001144204-19-038567:8k_2_02:83]
|  |  | Nine Months Ended June 30, 2019 |  |
| Cash flows from operating activities: |  |  |  |  |
| Net earnings |  | $ | 56,181 |  |
| Adjustments to reconcile net earnings |  |  |  |  |
| to net cash provided by operating activities: |  |  |  |  |
| Depreciation and amortization |  |  | 28,763 |  |
| Stock compensation expense |  |  | 3,878 |  |
| Changes in assets and liabilities |  |  | (41,851 | ) |
| Change in PP&E from gain on building sale |  |  | (8,922 | ) |
| Pension contributions |  |  | (2,500 | ) |
| Effect of deferred taxes |  |  | 1,492 |  |
| Net cash provided by operating activities |  |  | 37,041 |  |
| Cash flows from investing activities: |  |  |  |  |
| Acquisition of business |  |  | (937 | ) |
| Capital expenditures |  |  | (26,457 | ) |
| Additions to capitalized software |  |  | (6,207 | ) |
| Proceeds from sale of building and land |  |  | 17,201 |  |
| Net cash used by investing activities |  |  | (16,400 | ) |
| Cash flows from financing activities: |  |  |  |  |
| Proceeds from long-term debt and short-term borrowings |  |  | 32,921 |  |
| Principal payments on long-term debt |  |  | (35,000 | ) |
| Dividends paid |  |  | (6,223 | ) |
| Other |  |  | (3,234 | ) |
| Net cash used by financing activities |  |  | (11,536 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (626 | ) |
| Net increase in cash and cash equivalents |  |  | 8,479 |  |
| Cash and cash equivalents, beginning of period |  |  | 30,477 |  |
| Cash and cash equivalents, end of period |  | $ | 38,956 |  |

[0001144204-19-038567:8k_2_02:84]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001144204-19-038567:8k_2_02:85]
Other Selected Financial Data (Unaudited)

[0001144204-19-038567:8k_2_02:86]
(Dollars in thousands)

[0001144204-19-038567:8k_2_02:87]
| Backlog And Entered Orders - Q3 FY 2019 |  | Filtration |  |  | Test |  |  | USG |  |  | Technical Packaging |  |  | Total |  |
| Beginning Backlog - 4/1/19 |  | $ | 243,007 |  |  |  | 141,205 |  |  |  | 39,019 |  |  |  | 12,832 |  |  |  | 436,063 |  |
| Entered Orders |  |  | 71,210 |  |  |  | 44,128 |  |  |  | 55,404 |  |  |  | 25,412 |  |  |  | 196,154 |  |
| Sales |  |  | (83,067 | ) |  |  | (42,298 | ) |  |  | (52,894 | ) |  |  | (21,507 | ) |  |  | (199,766 | ) |
| Ending Backlog - 6/30/19 |  | $ | 231,150 |  |  |  | 143,035 |  |  |  | 41,529 |  |  |  | 16,737 |  |  |  | 432,451 |  |
| Backlog And Entered Orders - YTD Q3 FY 2019 |  |  | Filtration |  |  |  | Test |  |  |  | USG |  |  |  | Technical Packaging |  |  |  | Total |  |
| Beginning Backlog - 10/1/18 |  | $ | 204,227 |  |  |  | 122,350 |  |  |  | 40,727 |  |  |  | 15,467 |  |  |  | 382,771 |  |
| Entered Orders |  |  | 255,692 |  |  |  | 147,144 |  |  |  | 158,441 |  |  |  | 64,715 |  |  |  | 625,992 |  |
| Sales |  |  | (228,769 | ) |  |  | (126,459 | ) |  |  | (157,639 | ) |  |  | (63,445 | ) |  |  | (576,312 | ) |
| Ending Backlog - 6/30/19 |  | $ | 231,150 |  |  |  | 143,035 |  |  |  | 41,529 |  |  |  | 16,737 |  |  |  | 432,451 |  |
