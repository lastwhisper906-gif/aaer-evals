# ESE notes — 0001144204-19-038765


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001144204-19-038765:notes:1]
1.    BASIS OF PRESENTATION

[0001144204-19-038765:notes:2]
The accompanying consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP). For further information, refer to the consolidated financial statements and related notes included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2018.

[0001144204-19-038765:notes:3]
The Company’s results for the three and nine-month periods ended June 30, 2019 are not necessarily indicative of the results for the entire 2019 fiscal year. References to the third quarters of 2019 and 2018 represent the fiscal quarters ended June 30, 2019 and 2018, respectively.

[0001144204-19-038765:notes:4]
[same as prior period, unchanged from 0001144204-19-024737:notes:134]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001144204-19-038765:notes:5]
2.    SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES UPDATE

[0001144204-19-038765:notes:6]
Our significant accounting policies are included in Note 1 of our Annual Report on Form 10-K for the year ended September 30, 2018. On October 1, 2018, we adopted ASU No. 2014-09, Revenue from Contracts with Customers (ASC 606). Significant changes to our policies resulting from the adoption are provided below. We adopted ASC 606 using the modified retrospective transition method applied to contracts that were not substantially complete at the end of fiscal year 2018. We recorded a $4.2 million adjustment to increase retained earnings to reflect the cumulative impact of adopting this standard at the beginning of fiscal year 2019, primarily related to certain long-term contracts our Filtration and Technical Packaging segments have that converted to the cost-to-cost method for revenue recognition. The comparative information has not been restated and is reported under the accounting standards in effect for those periods. A reconciliation of the financial statement line items impacted for the three and nine months ended June 30, 2019 under ASC 606 to the prior accounting standards is provided in Note 14.

[0001144204-19-038765:notes:7]
[same as prior period, unchanged from 0001144204-19-024737:notes:5]

[0001144204-19-038765:notes:8]
[same as prior period, unchanged from 0001144204-19-024737:notes:6]

[0001144204-19-038765:notes:9]
Payment terms with customers vary by the type and location of the customer and the products or services offered. The Company does not adjust the promised amount of consideration for the effects of significant financing components based on the expectation that the period between when the Company transfers a promised good or service to a customer and when the customer pays for that good or service will be one year or less. Arrangements with customers that include payment terms extending beyond one year are not significant.

[0001144204-19-038765:notes:10]
Filtration: Within the Filtration segment, approximately 48% of revenues (approximately 18% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial and military customers and have a single performance obligation as there is only one good promised or the promise to transfer the goods or services is not distinct or separately identifiable from other promises in the contract. The transaction price for these contracts reflects our estimate of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

[0001144204-19-038765:notes:11]
Approximately 52% of the segment’s revenues (approximately 19% of consolidated revenues) are accounted for over time as the product does not have an alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin or the inventory is owned by the customer. The related contracts are primarily cost-plus or fixed price contracts related to the design, development and manufacture of complex fluid control products, quiet valves, manifolds, shock and vibration dampening, thermal insulation and systems primarily for the commercial aerospace and military (U.S. Government) markets. The contracts may contain multiple products, which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. Our contracts are frequently modified for changes in contract specifications and requirements. Most of our contract modifications are for products that are not distinct from the existing contract and are accounted for as part of that existing contract.

[0001144204-19-038765:notes:12]
[same as prior period, unchanged from 0001144204-19-024737:notes:16]

[0001144204-19-038765:notes:13]
[same as prior period, unchanged from 0001144204-19-024737:notes:17]

[0001144204-19-038765:notes:14]
[same as prior period, unchanged from 0001144204-19-024737:notes:18]

[0001144204-19-038765:notes:15]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to one or more years, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

[0001144204-19-038765:notes:16]
[same as prior period, unchanged from 0001144204-19-024737:notes:20]

[0001144204-19-038765:notes:17]
[same as prior period, unchanged from 0001144204-19-024737:notes:21]

[0001144204-19-038765:notes:18]
Test: Within the Test segment, approximately 25% of revenues (approximately 6% of consolidated revenues) are recognized at a point in time when products such as, antennas and probes are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

[0001144204-19-038765:notes:19]
Approximately 75% of the segment’s revenues (approximately 17% of consolidated revenues) are recorded over time as the product does not have an alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin. Products accounted for under this guidance include the construction and installation of test chambers to a buyer’s specifications that provide its customers with the ability to measure and contain magnetic, electromagnetic and acoustic energy. The goods and services related to each installed test chamber are not distinct due to the significant amount of integration provided and each installed chamber is accounted for as a single performance obligation. Selecting the method to measure progress towards completion for these contracts requires judgment and is based on the nature of the products and service to be provided. We use milestones to measure progress for our Test segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. For arrangements that are accounted for under this guidance, the Company estimates profit as the difference between total revenue and total estimated cost of a contract and recognizes these revenues and costs based primarily on contract milestones. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable.

[0001144204-19-038765:notes:20]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to a year, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

[0001144204-19-038765:notes:21]
[same as prior period, unchanged from 0001144204-19-024737:notes:26]

[0001144204-19-038765:notes:22]
[same as prior period, unchanged from 0001144204-19-024737:notes:27]

[0001144204-19-038765:notes:23]
USG: Within the USG segment, approximately 80% of revenues (approximately 24% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

[0001144204-19-038765:notes:24]
[same as prior period, unchanged from 0001144204-19-024737:notes:31]

[0001144204-19-038765:notes:25]
[same as prior period, unchanged from 0001144204-19-024737:notes:32]

[0001144204-19-038765:notes:26]
Technical Packaging: Within the Technical Packaging segment, 100% of the revenues (approximately 10% of consolidated revenues) are recognized over time as the product does not have an alternative use and the Company has an enforceable right to payment. Selecting the method to measure progress towards completion for the contracts requires judgment and is based on the nature of the products to be provided. We use the cost-to-cost method to measure progress for our Technical Packaging segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. Under this measure, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and revenue is recorded proportionally as costs are incurred. The transaction price for our contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant.

[0001144204-19-038765:notes:27]
[same as prior period, unchanged from 0001144204-19-024737:notes:35]

[0001144204-19-038765:notes:28]
[same as prior period, unchanged from 0001144204-19-024737:notes:36]

[0001144204-19-038765:notes:29]
[same as prior period, unchanged from 0001144204-19-024737:notes:37]

[0001144204-19-038765:notes:30]
[same as prior period, unchanged from 0001144204-19-024737:notes:38]

[0001144204-19-038765:notes:31]
[same as prior period, unchanged from 0001144204-19-024737:notes:39]


## us-gaap:EarningsPerShareTextBlock

[0001144204-19-038765:notes:32]
3.    EARNINGS PER SHARE (EPS)

[0001144204-19-038765:notes:33]
[same as prior period, unchanged from 0001144204-19-024737:notes:41]

[0001144204-19-038765:notes:34]
| ​ | ​ | Three Months | ​ | Nine Months |
| ​ | ​ | Ended June 30, | ​ | Ended June 30, |
| ​ |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Weighted Average Shares Outstanding - Basic | ​ | 25,971 | ​ | 25,900 | ​ | 25,935 | ​ | 25,862 |
| Dilutive Options and Restricted Shares |  | 138 |  | 150 |  | 155 |  | 180 |
| Adjusted Shares - Diluted |  | 26,109 |  | 26,050 |  | 26,090 |  | 26,042 |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001144204-19-038765:notes:35]
4.    SHARE-BASED COMPENSATION

[0001144204-19-038765:notes:36]
[same as prior period, unchanged from 0001144204-19-024737:notes:44]

[0001144204-19-038765:notes:37]
[same as prior period, unchanged from 0001144204-19-024737:notes:45]

[0001144204-19-038765:notes:38]
Compensation expense related to the restricted share awards was $1.0 million and $3.1 million for the three and nine-month periods ended June 30, 2019, respectively, and $0.9 million and $3.1 million for the corresponding periods of 2018. There were 280,504 non-vested shares outstanding as of June 30, 2019.

[0001144204-19-038765:notes:39]
[same as prior period, unchanged from 0001144204-19-024737:notes:47]

[0001144204-19-038765:notes:40]
Compensation expense related to the non-employee director grants was $0.3 million and $0.8 million for the three and nine-month periods ended June 30, 2019, respectively, and $0.3 million and $0.8 million for the corresponding periods of 2018.

[0001144204-19-038765:notes:41]
The total share-based compensation cost that has been recognized in the results of operations and included within selling, general and administrative expenses (SG&A) was $1.3 million and $3.9 million for the three and nine-month periods ended June 30, 2019, respectively, and $1.2 million and $3.9 million for the three and nine-month periods ended June 30, 2018. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $0.2 million and $0.8 million for the three and nine-month periods ended June 30, 2019, respectively, and $0.2 million and $0.9 million for the three and nine-month periods ended June 30, 2018, respectively. As of June 30, 2019, there was $10.7 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a remaining weighted-average period of 2.1 years.


## us-gaap:InventoryDisclosureTextBlock

[0001144204-19-038765:notes:42]
5.    INVENTORIES

[0001144204-19-038765:notes:43]
[same as prior period, unchanged from 0001144204-19-024737:notes:51]

[0001144204-19-038765:notes:44]
| ​ | ​ | June 30, | ​ | September 30, |
| (In thousands) |  | 2019 |  | 2018 |
| Finished goods | ​ | $ | 18,583 |  | 26,678 |
| Work in process | ​ |  | 42,678 |  | 47,765 |
| Raw materials | ​ |  | 65,555 |  | 60,973 |
| Total inventories | ​ | $ | 126,816 |  | 135,416 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001144204-19-038765:notes:45]
6.    GOODWILL AND OTHER INTANGIBLE ASSETS

[0001144204-19-038765:notes:46]
Included on the Company’s Consolidated Balance Sheets at June 30, 2019 and September 30, 2018 are the following intangible assets gross carrying amounts and accumulated amortization:

[0001144204-19-038765:notes:47]
| ​ | ​ | June 30, | ​ | September 30, |
| (Dollars in thousands) |  | 2019 |  | 2018 |
| Goodwill | ​ | $ | 381,683 |  | 381,652 |
| Intangible assets with determinable lives: | ​ |  | ​ |  |  |
| Patents | ​ |  | ​ |  |  |
| Gross carrying amount | ​ | $ | 1,880 |  | 1,833 |
| Less: accumulated amortization | ​ |  | 873 |  | 791 |
| Net | ​ | $ | 1,007 |  | 1,042 |
| Capitalized software | ​ |  | ​ |  |  |
| Gross carrying amount | ​ | $ | 77,502 |  | 71,294 |
| Less: accumulated amortization | ​ |  | 47,206 |  | 41,624 |
| Net | ​ | $ | 30,296 |  | 29,670 |
| Customer relationships | ​ |  | ​ |  |  |
| Gross carrying amount | ​ | $ | 185,135 |  | 185,333 |
| Less: accumulated amortization | ​ |  | 55,641 |  | 47,802 |
| Net | ​ | $ | 129,494 |  | 137,531 |
| Other | ​ |  | ​ |  |  |
| Gross carrying amount | ​ | $ | 5,382 |  | 5,468 |
| Less: accumulated amortization | ​ |  | 2,518 |  | 2,056 |
| Net | ​ | $ | 2,864 |  | 3,412 |
| Intangible assets with indefinite lives: | ​ |  | ​ |  |  |
| Trade names | ​ | $ | 172,964 |  | 173,698 |

[0001144204-19-038765:notes:48]
The changes in the carrying amount of goodwill attributable to each business segment for the nine months ended June 30, 2019 is as follows:

[0001144204-19-038765:notes:49]
| (Dollars in millions) |  | USG |  | Test |  | Filtration |  | Packaging |  | Total |
| Balance as of September 30, 2018 |  | ​ | 254.1 |  | 34.1 |  | 73.7 |  | 19.8 |  | 381.7 |
| Foreign currency translation |  | ​ | 0.2 |  | — |  | — |  | (0.2) |  | — |
| Balance as of June 30, 2019 | ​ | $ | 254.3 |  | 34.1 |  | 73.7 |  | 19.6 |  | 381.7 |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001144204-19-038765:notes:50]
7.    BUSINESS SEGMENT INFORMATION

[0001144204-19-038765:notes:51]
The Company is organized based on the products and services that it offers, and classifies its business operations in four reportable segments for financial reporting purposes: Filtration/Fluid Flow (Filtration), RF Shielding and Test (Test), Utility Solutions Group (USG) and Technical Packaging. The Filtration segment’s operations consist of PTI Technologies Inc. (PTI), VACCO Industries (VACCO), Crissair, Inc. (Crissair), Westland Technologies Inc. (Westland), and Mayday Manufacturing Co. and its affiliate Hi-Tech Metals, Inc. (collectively referred to as Mayday). The companies within this segment primarily design and manufacture specialty filtration products, including hydraulic filter elements used in commercial aerospace applications, unique filter mechanisms used in micro-propulsion devices for satellites and custom designed filters for manned and unmanned aircraft; manufacture elastomeric-based signature reduction solutions for the U.S. Navy; and manufacture landing gear components for the aerospace and defense industry. The Test segment’s operations consist primarily of ETS-Lindgren Inc.

[0001144204-19-038765:notes:52]
(ETS-Lindgren). ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy. The USG segment’s operations consist primarily of Doble Engineering Company (Doble), Morgan Schaffer Inc. (Morgan Schaffer), and NRG Systems, Inc. (NRG). Doble provides high-end, intelligent diagnostic test solutions for the electric power delivery industry and is a leading supplier of partial discharge testing instruments used to assess the integrity of high voltage power delivery equipment. Morgan Schaffer provides an integrated offering of dissolved gas analysis, oil testing, and data management solutions for the electric power industry. NRG designs and manufactures decision support tools for the renewable energy industry, primarily wind. The Technical Packaging segment’s operations consist of Thermoform Engineered Quality LLC (TEQ) and Plastique Limited and Plastique Sp. z o.o. (together, Plastique). The companies within this segment provide innovative solutions to the medical and commercial markets for thermoformed packages and specialty products using a wide variety of thin gauge plastics and pulp.

[0001144204-19-038765:notes:53]
[same as prior period, unchanged from 0001144204-19-024737:notes:60]

[0001144204-19-038765:notes:54]
| ​ | ​ | Three Months | ​ | Nine Months |
| ​ | ​ | Ended June 30, | ​ | Ended June 30, |
| (In thousands) |  | 2019 |  | 2018 |  | 2019 | 2018 |
| NET SALES |  | ​ |  |  |  |  |  |  |  |
| Filtration | ​ | $ | 83,067 |  | 69,721 |  | 228,769 |  | 195,531 |
| Test | ​ |  | 42,298 |  | 45,034 |  | 126,459 |  | 123,368 |
| USG | ​ |  | 52,894 |  | 55,489 |  | 157,639 |  | 157,942 |
| Technical Packaging | ​ |  | 21,507 |  | 21,979 |  | 63,445 |  | 63,655 |
| Consolidated totals | ​ | $ | 199,766 |  | 192,223 |  | 576,312 |  | 540,496 |
| EBIT | ​ |  | ​ |  |  |  | ​ |  |  |
| Filtration | ​ | $ | 19,039 |  | 14,292 |  | 47,092 |  | 35,056 |
| Test | ​ |  | 5,927 |  | 5,902 |  | 14,791 |  | 13,797 |
| USG | ​ |  | 10,148 |  | 11,528 |  | 40,461 |  | 27,805 |
| Technical Packaging | ​ |  | 1,625 |  | 2,505 |  | 3,333 |  | 5,355 |
| Corporate (loss) | ​ |  | (9,874) |  | (8,668) |  | (30,385) |  | (25,848) |
| Consolidated EBIT | ​ |  | 26,865 |  | 25,559 |  | 75,292 |  | 56,165 |
| Less: Interest expense | ​ |  | (1,973) |  | (2,243) |  | (5,788) |  | (6,464) |
| Earnings before income taxes | ​ | $ | 24,892 |  | 23,316 |  | 69,504 |  | 49,701 |

[0001144204-19-038765:notes:55]
[same as prior period, unchanged from 0001144204-19-024737:notes:62]

[0001144204-19-038765:notes:56]
The financial measure “EBIT” is presented in the above table and elsewhere in this Report. EBIT on a consolidated basis is a non-GAAP financial measure. Management believes that EBIT is useful in assessing the operational profitability of the Company’s business segments because it excludes interest and taxes, which are generally accounted for across the entire Company on a consolidated basis. EBIT is also one of the measures used by

[0001144204-19-038765:notes:57]
management in determining resource allocations within the Company as well as incentive compensation. A reconciliation of EBIT to net earnings is set forth in Item 2, Management’s Discussion and Analysis of Financial Condition and Results of Operations – EBIT.

[0001144204-19-038765:notes:58]
[same as prior period, unchanged from 0001144204-19-024737:notes:64]


## us-gaap:DebtDisclosureTextBlock

[0001144204-19-038765:notes:59]
8.    DEBT

[0001144204-19-038765:notes:60]
The Company’s debt is summarized as follows:

[0001144204-19-038765:notes:61]
| ​ | ​ | June 30, | ​ | September 30, |
| (In thousands) |  | 2019 |  | 2018 |
| Total borrowings | ​ | $ | 217,921 |  | 220,000 |
| Short-term borrowings and current portion of long-term debt | ​ |  | (20,921) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 197,000 |  | 200,000 |

[0001144204-19-038765:notes:62]
The Company’s existing credit facility (“the Credit Facility”) matures December 21, 2020. The Credit Facility includes a $450 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of nine banks led by JPMorgan Chase Bank, N.A., as Administrative Agent.

[0001144204-19-038765:notes:63]
At June 30, 2019, the Company had approximately $225 million available to borrow under the Credit Facility, and a $250 million increase option, in addition to $39.0 million cash on hand. At June 30, 2019, the Company had $217.0 million of outstanding borrowings under the Credit Facility, and $0.9 million of short-term borrowing in addition to outstanding letters of credit of $7.2 million. The Company classified $20.9 million as the current portion of long-term debt as of June 30, 2019, as the Company intends to repay this amount within the next twelve month period; however, the Company has no contractual obligation to repay such amount during the next twelve month period.

[0001144204-19-038765:notes:64]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from 12.5 to 27.5 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a 65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 3.21% and 3.22% for the three and nine-month periods ending June 30, 2019, respectively, and 3.17% and 2.97% for the corresponding periods of 2018. At June 30, 2019, the Company was in compliance with all debt covenants.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001144204-19-038765:notes:65]
9.    INCOME TAX EXPENSE

[0001144204-19-038765:notes:66]
The third quarter 2019 effective income tax rate was 19.4% compared to 18.4% in the third quarter of 2018. The income tax expense for the first nine months of 2019 was $13.3 million compared to income tax benefit of $14.0 million for the first nine months of 2018. The effective income tax rate for the first nine months of 2019 was 19.2% compared to (28.1)% for the first nine months of 2018.

[0001144204-19-038765:notes:67]
The income tax expense in the third quarter and first nine months of 2019 was favorably impacted by tax planning strategies to increase foreign tax credits claimed retrospectively. The Company reduced the valuation allowance for excess foreign tax credits by $2.4 million ($2.3 million in the second quarter of 2019 and $0.1 million in third quarter of 2019) and recorded an amended return benefit of $0.3 million ($0.2 million in the second quarter of 2019 and $0.1 million in the third quarter of 2019) which favorably impacted the third quarter and year-to-date effective

[0001144204-19-038765:notes:68]
tax rate by 1.0% and 4.1%, respectively. Income tax expense in the third quarter of 2019 and first nine months of 2019 was also favorably impacted by additional tax benefits on share-based compensation that vested during the quarter decreasing the effective tax rate by 1.8% and 0.7%, respectively. A non-automatic accounting method change filed with the 2018 tax return was approved by the Internal Revenue Service during the third quarter of 2019 and favorably impacted the third quarter and year-to-date effective tax rate by 1.0% and 0.4%, respectively.

[0001144204-19-038765:notes:69]
H.R. 1, Tax Cuts and Jobs Act (“TCJA”), was signed into law on December 22, 2017. The total impact of the TCJA in the third quarter and first nine months of 2018 was a net expense of $0.1 million and a net benefit of $24.3 million, respectively. The impacts were as follows: First, the Company’s 2018 federal statutory rate dropped from 35.0% to 24.5% which required an adjustment to the value of its deferred tax assets and liabilities. This adjustment ($30.3 million provisional amount recorded in the first quarter of 2018 and $0.4 million provisional amount in the third quarter of 2018) favorably impacted the third quarter and year-to-date effective tax rate by 1.5% and 61.7%, respectively. Second, the TCJA subjected the Company’s cumulative foreign earnings to deferral income tax ($4.1 million provisional amount of which $2.9 million was recorded in the first quarter of 2018, $0.7 million was recorded in the third quarter of 2018 and $0.5 million in the third quarter of 2019) which unfavorably impacted the third quarter and year-to-date effective tax rate by 2.1% and 8.2%, respectively.

[0001144204-19-038765:notes:70]
In the first quarter of 2018, the Company recorded a $2.3 million provisional estimate of the income tax effects of the future repatriation of the cumulative earnings of its foreign subsidiaries which unfavorably impacted the year-to-date effective tax rate by 4.7%. An additional $7.5 million pension contribution for the 2017 plan year was approved during the second quarter of 2018 increasing the value of the deferred tax liability by $1.0 million. This favorable adjustment, net of the $0.3 million unfavorable impact to the 2017 Domestic Production Deduction, favorably impacted the year-to-date effective tax rate by 1.6%. An accounting method change was filed with the 2017 tax return which resulted in an additional deferred tax liability to be adjusted as a result of the TCJA. A favorable adjustment, net of the $0.3 million unfavorable impact to the 2018 Domestic Production deduction, favorably impacted the third quarter and year-to-date effective tax rate by 2.9% and 1.4%, respectively. The income tax expense in the third quarter and first nine months of 2018 was favorably impacted by return to provision true-ups decreasing the third quarter and year-to-date effective tax rate by 1.4% and 0.7%, respectively. Income tax expense in the third quarter and first nine months of 2018 was also favorably impacted by additional tax benefits on share-based compensation that vested during the quarter decreasing the effective tax rate by 1.9% and 0.9%, respectively.

[0001144204-19-038765:notes:71]
[same as prior period, unchanged from 0001144204-19-024737:notes:77]


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001144204-19-038765:notes:72]
10.  SHAREHOLDERS’ EQUITY

[0001144204-19-038765:notes:73]
The change in shareholders’ equity for the first nine months of 2019 and 2018 is shown below (in thousands):

[0001144204-19-038765:notes:74]
| ​ | ​ | Three Months Ended June 30, | ​ | Nine Months Ended June 30, |
| ​ |  | 2018 |  | 2019 |  | 2018 |  | 2019 |
| Common stock | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 305 | ​ | 305 | ​ | 305 | ​ | 305 |
| Stock plans | ​ | — | ​ | 1 | ​ | — | ​ | 1 |
| Ending balance | ​ | 305 | ​ | 306 | ​ | 305 | ​ | 306 |
| Additional paid-in-capital | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 292,404 | ​ | 293,612 | ​ | 289,785 | ​ | 291,190 |
| Stock plans | ​ | (2,298) | ​ | (2,408) | ​ | 321 | ​ | 14 |
| Ending balance | ​ | 290,106 | ​ | 291,204 | ​ | 290,106 | ​ | 291,204 |
| Retained earnings | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 557,249 | ​ | 643,018 | ​ | 516,718 | ​ | 606,836 |
| Net earnings common stockholders | ​ | 19,019 | ​ | 20,067 | ​ | 63,684 | ​ | 56,181 |
| Dividends paid | ​ | (2,076) | ​ | (2,082) | ​ | (6,210) | ​ | (6,227) |
| Adoption of accounting standards updates | ​ | — | ​ | — | ​ | — | ​ | 4,213 |
| Ending balance | ​ | 574,192 | ​ | 661,003 | ​ | 574,192 | ​ | 661,003 |
| Accumulated other comprehensive income (loss) | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | (23,028) | ​ | (35,280) | ​ | (27,308) | ​ | (31,528) |
| Foreign currency translation | ​ | (6,865) | ​ | 1,840 | ​ | (2,801) | ​ | (2,013) |
| Pension | ​ | — | ​ | — | ​ | 61 | ​ | — |
| Forward exchange contracts | ​ | (62) | ​ | (7) | ​ | 93 | ​ | 94 |
| Ending balance | ​ | (29,955) | ​ | (33,447) | ​ | (29,955) | ​ | (33,447) |
| Treasury stock | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | (107,394) | ​ | (107,259) | ​ | (107,582) | ​ | (107,394) |
| Issued under stock plans | ​ | — | ​ | — | ​ | 188 | ​ | 135 |
| Ending balance | ​ | (107,394) | ​ | (107,259) | ​ | (107,394) | ​ | (107,259) |
| Total equity | ​ | 727,254 | ​ | 811,807 | ​ | 727,254 | ​ | 811,807 |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001144204-19-038765:notes:75]
11.  RETIREMENT PLANS

[0001144204-19-038765:notes:76]
A summary of net periodic benefit expense for the Company’s defined benefit plans for the three and nine-month periods ended June 30, 2019 and 2018 is shown in the following table. Net periodic benefit cost for each period presented is comprised of the following:

[0001144204-19-038765:notes:77]
| ​ | ​ | Three Months | ​ | Nine Months |
| ​ | ​ | Ended June 30, | ​ | Ended June 30, |
| (In thousands) |  | 2019 |  | 2018 |  | 2019 | ​ | 2018 |
| Defined benefit plans | ​ | ​ |  | ​ |  | ​ |  | ​ |  |
| Interest cost | ​ | $ | 875 |  | 821 |  | 2,626 |  | 2,461 |
| Expected return on assets | ​ |  | (1,086) |  | (975) |  | (3,259) |  | (2,924) |
| Amortization of: | ​ |  | ​ |  |  |  | ​ |  |  |
| Prior service cost | ​ |  | — |  | — |  | — |  | — |
| Actuarial loss | ​ |  | 487 |  | 548 |  | 1,461 |  | 1,644 |
| Net periodic benefit cost | ​ | $ | 276 |  | 394 |  | 828 |  | 1,181 |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001144204-19-038765:notes:78]
12.  DERIVATIVE FINANCIAL INSTRUMENTS

[0001144204-19-038765:notes:79]
[same as prior period, unchanged from 0001144204-19-024737:notes:85]

[0001144204-19-038765:notes:80]
The following is a summary of the notional transaction amounts and fair values for the Company’s outstanding derivative financial instruments by risk category and instrument type as of June 30, 2019:

[0001144204-19-038765:notes:81]
| ​ | ​ | ​ | ​ | Fair | ​ | ​ | ​ | ​ |  |
| ​ | ​ | Notional | ​ | Value | ​ | Float | ​ | Fix |  |
| (In thousands) |  | amount |  | (US$) |  | Rate |  | Rate |  |
| Forward contracts |  | 6,000 |  | USD |  | (4) |  |  |  |  | ​ |
| Interest rate swap |  | 150,000 |  | USD |  | 6 |  | 2.38 | % | 2.09 | % |
| Interest rate swap * |  | 150,000 |  | USD |  | (1,041) |  | N/A |  | 2.24 | % |

[0001144204-19-038765:notes:82]
*This swap represents a forward contract and will be effective in November 2019.


## us-gaap:FairValueDisclosuresTextBlock

[0001144204-19-038765:notes:83]
13.  FAIR VALUE MEASUREMENTS

[0001144204-19-038765:notes:84]
[same as prior period, unchanged from 0001144204-19-024737:notes:90]

[0001144204-19-038765:notes:85]
|  | ● | Level 1 – inputs to the valuation methodology are quoted prices (unadjusted) for identical assets or liabilities in active markets. |

[0001144204-19-038765:notes:86]
|  | ● | Level 2 – inputs to the valuation methodology include quoted prices for similar assets and liabilities in active markets, and inputs that are observable for the asset or liability, either directly or indirectly, for substantially the full term of the financial instrument. |

[0001144204-19-038765:notes:87]
|  | ● | Level 3 – inputs to the valuation methodology are unobservable and significant to the fair value measurement. |

[0001144204-19-038765:notes:88]
[same as prior period, unchanged from 0001144204-19-024737:notes:94]

[0001144204-19-038765:notes:89]
The Company has estimated the fair value of its financial instruments as of June 30, 2019 and September 30, 2018 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, debt and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001144204-19-038765:notes:90]
[same as prior period, unchanged from 0001144204-19-024737:notes:96]

[0001144204-19-038765:notes:91]
The Company’s forward contracts are classified within Level 2 of the valuation hierarchy in accordance with FASB Accounting Standards Codification (ASC) 825, as presented below as of June 30, 2019:

[0001144204-19-038765:notes:92]
| (In thousands) |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets (Liabilities): |  | ​ |  |  |  |  | ​ |  |  |  |
| Forward contracts | ​ | $ | — |  | (1,039) | ​ | $ | — |  | (1,039) |

[0001144204-19-038765:notes:93]
[same as prior period, unchanged from 0001144204-19-024737:notes:104]

[0001144204-19-038765:notes:94]
[same as prior period, unchanged from 0001144204-19-024737:notes:105]

[0001144204-19-038765:notes:95]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during the three and nine-month periods ended June 30, 2019.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001144204-19-038765:notes:96]
14.  REVENUES

[0001144204-19-038765:notes:97]
Disaggregation of Revenues

[0001144204-19-038765:notes:98]
Our revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2019 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within our reportable segments.

[0001144204-19-038765:notes:99]
| Three Months Ended June 30, 2019 |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | Technical |  | ​ | ​ |
| (In thousands) | ​ | Filtration | ​ | Test | ​ | USG | ​ | Packaging | ​ | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 47,482 | ​ | $ | 37,980 | ​ | $ | 52,065 | ​ | $ | 21,507 | ​ | $ | 159,034 |
| Government | ​ |  | 35,585 | ​ |  | 4,318 | ​ |  | 829 | ​ |  | — | ​ |  | 40,732 |
| Total revenues | ​ | $ | 83,067 | ​ | $ | 42,298 | ​ | $ | 52,894 | ​ | $ | 21,507 | ​ | $ | 199,766 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 69,872 | ​ | $ | 26,923 | ​ | $ | 38,414 | ​ | $ | 11,559 | ​ | $ | 146,268 |
| International | ​ |  | 13,195 | ​ |  | 15,375 | ​ |  | 14,480 | ​ |  | 9,948 | ​ |  | 53,498 |
| Total revenues | ​ | $ | 83,067 | ​ | $ | 42,298 | ​ | $ | 52,894 | ​ | $ | 21,507 | ​ | $ | 199,766 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 41,633 | ​ | $ | 6,485 | ​ | $ | 40,968 | ​ | $ | — | ​ | $ | 89,092 |
| Over time | ​ |  | 41,434 | ​ |  | 35,813 | ​ |  | 11,926 | ​ |  | 21,507 | ​ |  | 110,674 |
| Total revenues | ​ | $ | 83,067 | ​ | $ | 42,298 | ​ | $ | 52,894 | ​ | $ | 21,507 | ​ | $ | 199,766 |

[0001144204-19-038765:notes:100]
| Nine Months Ended June 30, 2019 |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | Technical |  | ​ | ​ |
| (In thousands) | ​ | Filtration | ​ | Test | ​ | USG | ​ | Packaging | ​ | Total |
| Customer type: |  | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |  |
| Commercial | ​ | $ | 131,112 | ​ | $ | 111,577 | ​ | $ | 154,240 | ​ | $ | 63,251 | ​ | $ | 460,180 |
| Government | ​ |  | 97,657 | ​ |  | 14,882 | ​ |  | 3,399 | ​ |  | 194 | ​ |  | 116,132 |
| Total revenues | ​ | $ | 228,769 | ​ | $ | 126,459 | ​ | $ | 157,639 | ​ | $ | 63,445 | ​ | $ | 576,312 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 190,701 | ​ | $ | 82,072 | ​ | $ | 112,289 | ​ | $ | 32,865 | ​ | $ | 417,927 |
| International | ​ |  | 38,068 | ​ |  | 44,387 | ​ |  | 45,350 | ​ |  | 30,580 | ​ |  | 158,385 |

[0001144204-19-038765:notes:101]
| Total revenues | ​ | $ | 228,769 | ​ | $ | 126,459 | ​ | $ | 157,639 | ​ | $ | 63,445 | ​ | $ | 576,312 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 115,852 | ​ | $ | 29,092 | ​ | $ | 122,075 | ​ | $ | - | ​ | $ | 267,021 |
| Over time | ​ |  | 112,917 | ​ |  | 97,367 | ​ |  | 35,564 | ​ |  | 63,445 | ​ |  | 309,291 |
| Total revenues | ​ | $ | 228,769 | ​ | $ | 126,459 | ​ | $ | 157,639 | ​ | $ | 63,445 | ​ | $ | 576,312 |

[0001144204-19-038765:notes:102]
Remaining Performance Obligations

[0001144204-19-038765:notes:103]
Our remaining performance obligations, which is the equivalent of our backlog, represent the expected transaction price allocated to our contracts that we expect to recognize as revenue in future periods when we perform under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At June 30, 2019, we had $432.5 million in remaining performance obligations of which we expect to recognize revenues of 83% in the next twelve months.

[0001144204-19-038765:notes:104]
Contract assets and liabilities

[0001144204-19-038765:notes:105]
Assets and liabilities related to our contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At June 30, 2019, contract assets and liabilities totaled $99.5 million and $53.8 million, respectively. Upon adoption of ASC 606 on October 1, 2018, contract assets and liabilities related to our contracts with customers were $87 million and $51 million, respectively. During the first nine months of 2019, we recognized approximately $35 million in revenues that were included in the contract liabilities balance at the adoption date.

[0001144204-19-038765:notes:106]
Reconciliation of ASC 606 to Prior Accounting Standards

[0001144204-19-038765:notes:107]
The amount by which each financial statement line item is affected in 2019 as a result of applying the new accounting standard as discussed in Note 2 is presented below:

[0001144204-19-038765:notes:108]
| ​ | ​ | June 30, 2019 |
| ​ |  | ​ | ​ |  | Effect of the |  | ​ | ​ |
| ​ | ​ | ​ | ​ |  | adoption of |  | Under Prior |
| (In thousands) | ​ | As Reported |  | ASC 606 | ​ | Accounting |
| Consolidated Balance Sheets |  | ​ |  |  | ​ |  |  | ​ |  |
| Contract assets (1) | ​ | $ | 99,499 | ​ | $ | (43,576) | ​ | $ | 55,923 |
| Inventories | ​ |  | 126,816 | ​ |  | 36,089 | ​ |  | 162,905 |
| Total current assets | ​ |  | 450,206 | ​ |  | (7,487) | ​ |  | 442,719 |
| Total assets | ​ |  | 1,326,095 | ​ |  | (7,487) | ​ |  | 1,318,608 |
| Contract liabilities (2) | ​ |  | 53,758 | ​ |  | 4,549 | ​ |  | 58,307 |
| Total current liabilities | ​ |  | 199,736 | ​ |  | 4,549 | ​ |  | 204,285 |
| Deferred tax liabilities | ​ |  | 66,286 | ​ |  | (1,678) | ​ |  | 64,608 |
| Total liabilities | ​ |  | 514,288 | ​ |  | 2,871 | ​ |  | 517,159 |
| Retained earnings | ​ |  | 661,003 | ​ |  | (10,358) | ​ |  | 650,645 |
| Total shareholders’ equity | ​ |  | 811,807 | ​ |  | (10,358) | ​ |  | 801,449 |
| Total liabilities and shareholders’ equity | ​ | $ | 1,326,095 | ​ |  | (7,487) | ​ |  | 1,318,608 |

[0001144204-19-038765:notes:109]
|  | (1) | Previously “cost and estimated earnings on long-term contracts” |

[0001144204-19-038765:notes:110]
|  | (2) | Previously “advance payments on long-term contracts” and “current portion of deferred revenue” |

[0001144204-19-038765:notes:111]
| ​ | ​ | Three Months Ended |
| ​ | ​ | June 30, 2019 |
| ​ |  | ​ | ​ |  | Effect of the |  | ​ | ​ |
| ​ | ​ | ​ | ​ |  | adoption of |  | Under Prior |
| (In thousands, except per share amounts) | ​ | As Reported |  | ASC 606 | ​ | Accounting |
| Consolidated Statements of Operations | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net sales | ​ | $ | 199,766 | ​ | $ | (4,008) | ​ | $ | 195,758 |
| Cost of sales | ​ |  | 122,172 | ​ |  | (1,380) | ​ |  | 120,792 |
| Total costs and expenses | ​ |  | 174,874 | ​ |  | (1,380) | ​ |  | 173,494 |
| Earnings before income tax | ​ |  | 24,892 | ​ |  | (2,628) | ​ |  | 22,264 |
| Income tax expense (benefit) | ​ |  | 4,825 | ​ |  | (399) | ​ |  | 4,426 |
| Net earnings | ​ | ​ | 20,067 | ​ | ​ | (2,229) | ​ | ​ | 17,838 |
| Earnings per share: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Basic: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net earnings | ​ | $ | 0.77 | ​ | $ | (0.08) | ​ | $ | 0.69 |
| Diluted: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net earnings | ​ | $ | 0.77 | ​ | $ | (0.08) | ​ | $ | 0.69 |
| Consolidated Statements of Comprehensive Income | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net earnings | ​ | $ | 20,067 | ​ | $ | (2,229) | ​ | $ | 17,838 |
| Comprehensive income | ​ |  | 21,899 | ​ |  | (2,229) | ​ |  | 19,670 |

[0001144204-19-038765:notes:112]
| ​ | ​ | Nine Months Ended |
| ​ | ​ | June 30, 2019 |
| ​ |  | ​ | ​ |  | Effect of the |  | ​ | ​ |
| ​ | ​ | ​ | ​ |  | adoption of |  | Under Prior |
| (In thousands, except per share amounts) | ​ | As Reported |  | ASC 606 | ​ | Accounting |
| Consolidated Statements of Operations | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net sales | ​ | $ | 576,312 | ​ | $ | (9,787) | ​ | $ | 566,525 |
| Cost of sales | ​ |  | 363,026 | ​ |  | (8,360) | ​ |  | 354,666 |
| Total costs and expenses | ​ |  | 506,808 | ​ |  | (8,360) | ​ |  | 498,448 |
| Earnings before income tax | ​ |  | 69,504 | ​ |  | (1,427) | ​ |  | 68,077 |
| Income tax expense (benefit) | ​ |  | 13,323 | ​ |  | (171) | ​ |  | 13,152 |
| Net earnings | ​ |  | 56,181 | ​ |  | (1,256) | ​ |  | 54,925 |
| Earnings per share: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Basic: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net earnings | ​ | $ | 2.17 | ​ | $ | (0.05) | ​ | $ | 2.12 |
| Diluted: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net earnings | ​ | $ | 2.15 | ​ | $ | (0.04) | ​ | $ | 2.11 |
| Consolidated Statements of Comprehensive Income | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net earnings | ​ | $ | 56,181 | ​ | $ | (1,256) | ​ | $ | 54,925 |
| Comprehensive income | ​ |  | 54,262 | ​ |  | (1,256) | ​ |  | 53,006 |
| Consolidated Statements of Cash flows | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net earnings | ​ | $ | 56,181 | ​ | $ | (1,256) | ​ | $ | 54,925 |
| Adjustments to reconcile net earnings to net cash provided by operating activities: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Change in assets and liabilities | ​ | $ | (41,851) | ​ | ​ | 1,256 | ​ | $ | (40,595) |
| Net cash provided by operating activities | ​ |  | 37,041 | ​ |  | — | ​ |  | 37,041 |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001144204-19-038765:notes:113]
15.  NEW ACCOUNTING STANDARDS

[0001144204-19-038765:notes:114]
In February 2016, the FASB issued ASU No. 2016-062, “Leases” (ASU 2016-02) which supersedes ASC 840, “Leases” and creates a new topic, ASC 842 “Leases.” Subsequent to the issuance of ASU 2016-02, ASC 842 was amended by various updates that amend and clarify the impact and implementation of the aforementioned update. These updates require lessees to recognize a lease liability and a lease asset for all leases, including operating leases, with a term greater than 12 months on its balance sheet. Upon initial application, the provisions of these updates are required to be applied using the modified retrospective method which requires retrospective adoption to each prior

[0001144204-19-038765:notes:115]
reporting period presented with the cumulative effect of adoption recorded to the earliest reporting period presented. An optional transition method can be utilized which requires retrospective adoption beginning on the date of adoption with the cumulative effect of initially applying these updates recognized at the date of initial adoption. These updates also expand the required quantitative and qualitative disclosures surrounding leases. These updates are effective for fiscal years beginning after December 15, 2018 and interim periods within those fiscal years, with earlier application permitted. We expect to adopt these updates on October 1, 2019 using the optional transition method. We continue to evaluate the impact these updates will have on our consolidated financial statements. Based upon the analysis and preliminary evaluation of the standard, we estimate the adoption will result in the addition of assets and liabilities of less than $30 million to our consolidated balance sheet, with no significant change to our consolidated statements of operations or cash flows. We believe the updates will also have an impact on our accounting policies, internal controls and disclosures related to leases.

[0001144204-19-038765:notes:116]
In October 2016, the FASB issued ASU No. 2016-16, Intra-Entity Transfers of Assets Other Than Inventory, which eliminates the exception for all intra-entity sale of assets other than inventory. This standard is effective for annual periods beginning after December 15, 2017. There was no significant impact to the Company’s consolidated financial statements as a result of adopting this new standard.


## us-gaap:SubsequentEventsTextBlock

[0001144204-19-038765:notes:117]
16.  SUBSEQUENT EVENT

[0001144204-19-038765:notes:118]
On July 2, 2019, the Company acquired Globe Composite Solutions, LLC (Globe), a supplier of mission-critical composite-based products and solutions for navy, defense, and industrial customers. Globe’s operating results from date of acquisition will be included in the Company’s Filtration segment.
