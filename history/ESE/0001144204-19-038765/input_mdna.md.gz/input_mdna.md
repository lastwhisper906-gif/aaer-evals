# ESE MD&A — 0001144204-19-038765


## mdna

[0001144204-19-038765:mdna:1]
ITEM 2. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001144204-19-038765:mdna:2]
[same as prior period, unchanged from 0001144204-19-024737:mdna:2]

[0001144204-19-038765:mdna:3]
References to the third quarters of 2019 and 2018 represent the three-month periods ended June 30, 2019 and 2018, respectively.

[0001144204-19-038765:mdna:4]
[same as prior period, unchanged from 0001144204-19-024737:mdna:4]

[0001144204-19-038765:mdna:5]
In the third quarter of 2019, sales, net earnings and diluted earnings per share were $199.8 million, $20.1 million and $0.77 per share, respectively, compared to $192.2 million, $19.0 million and $0.73 per share, respectively, in the third quarter of 2018. In the first nine months of 2019, sales, net earnings and diluted earnings per share were $576.3 million, $56.2 million and $2.15, respectively, compared to $540.5 million, $63.7 million and $2.45 per share, respectively, in the first nine months of 2018.

[0001144204-19-038765:mdna:6]
[same as prior period, unchanged from 0001144204-19-024737:mdna:6]

[0001144204-19-038765:mdna:7]
In the third quarter of 2019, net sales of $199.8 million were $7.6 million, or 4.0%, higher than the $192.2 million in the third quarter of 2018. In the first nine months of 2019, net sales of $576.3 million were $35.8 million, or 6.6%, higher than the $540.5 million in the first nine months of 2018. The increase in net sales in the third quarter of 2019 as compared to the third quarter of 2018 was due to a $13.4 million increase in the Filtration segment, partially offset by a $2.7 million decrease in the Test segment, a $2.6 million decrease in the USG segment and a $0.5 million decrease in the Technical Packaging segment. The increase in net sales in the first nine months of 2019 as compared to the first nine months of 2018 was due to a $33.3 million increase in the Filtration segment, and a $3.1 million increase in the Test segment, partially offset by a $0.3 million decrease in the USG segment and a $0.2 million decrease in the Technical Packaging segment.

[0001144204-19-038765:mdna:8]
[same as prior period, unchanged from 0001144204-19-024737:mdna:8]

[0001144204-19-038765:mdna:9]
In the third quarter of 2019, net sales of $83.1 million were $13.4 million, or 19.2%, higher than the $69.7 million in the third quarter of 2018. In the first nine months of 2019, net sales of $228.8 million were $33.3 million, or 17.0%, higher than the $195.5 million in the first nine months of 2018. The increase in the third quarter of 2019 compared to the third quarter of 2018 was mainly due to a $6.7 million increase in net sales at PTI due to higher aerospace assembly and element shipments, a $3.3 million increase in net sales at VACCO due to higher shipments of space products and defense spares, a $2.2 million increase in net sales at Crissair due to higher aerospace shipments, and a $1.5 million increase in net sales at Mayday due to higher aerospace shipments, partially offset by a $0.3 million decrease in net sales at Westland due to timing of shipments. The increase in the first nine months of 2019 compared to the first nine months of 2018 was primarily due to an a $11.7 million increase in net sales at PTI due to higher aerospace assembly and element shipments, $10.2 million increase in net sales at Crissair due to higher aerospace shipments, a $4.9 million increase in net sales at Mayday due to higher aerospace shipments $3.3 million increase in net sales at Westland due to timing of shipments on government programs and a $3.2 million increase in net sales at VACCO due to higher shipments of defense spares.

[0001144204-19-038765:mdna:10]
[same as prior period, unchanged from 0001144204-19-024737:mdna:10]

[0001144204-19-038765:mdna:11]
In the third quarter of 2019, net sales of $42.3 million were $2.7 million, or 6.0%, lower than the $45.0 million in the third quarter of 2018. In the first nine months of 2019, net sales of $126.5 million were $3.1 million, or 2.5%, higher than the $123.4 million in the first nine months of 2018. The decrease in the third quarter of 2019 compared to the third quarter of 2018 was primarily due to lower sales from the segment’s U.S. operations due to timing of test and measurement chamber projects.  The increase in the first nine months of 2019 compared to the first nine months of 2018 was primarily due to higher sales from the segment’s Asian and U.S. operations due to the timing of test and measurement chamber projects.

[0001144204-19-038765:mdna:12]
[same as prior period, unchanged from 0001144204-19-024737:mdna:12]

[0001144204-19-038765:mdna:13]
In the third quarter of 2019, net sales of $52.9 million were $2.6 million, or 4.7%, lower than the $55.5 million in the third quarter of 2018. In the first nine months of 2019, net sales of $157.6 million were $0.3 million lower than the $157.9 million in the first nine months of 2018. The decrease in the third quarter and first nine months of 2019 compared to the corresponding periods of 2018 was mainly due to lower sales at NRG due to continued softness in the renewable energy market.

[0001144204-19-038765:mdna:14]
[same as prior period, unchanged from 0001144204-19-024737:mdna:14]

[0001144204-19-038765:mdna:15]
In the third quarter of 2019, net sales of $21.5 million were $0.5 million, or 2.3%, lower than the $22.0 million in the third quarter of 2018. In the first nine months of 2019, net sales of $63.4 million were $0.3 million lower than the $63.7 million in the first nine months of 2018. The decrease in the third quarter and first nine months of 2019 compared to the corresponding periods of 2018 was primarily due to the decrease in net sales from Plastique due to timing of projects.

[0001144204-19-038765:mdna:16]
[same as prior period, unchanged from 0001144204-19-024737:mdna:16]

[0001144204-19-038765:mdna:17]
Backlog was $432.5 million at June 30, 2019 compared with $382.8 million at September 30, 2018. The Company received new orders totaling $196.2 million in the third quarter of 2019 compared to $201.1 million in the third quarter of 2018. Of the new orders received in the third quarter of 2019, $71.2 million related to Filtration products, $44.1 million related to Test products, $55.4 million related to USG products, and $25.4 million related to Technical Packaging products. Of the new orders received in the third quarter of 2018, $85.9 million related to Filtration products, $37.9 million related to Test products, $57.8 million related to USG products, and $19.5 million related to Technical Packaging products.

[0001144204-19-038765:mdna:18]
The Company received new orders totaling $626.0 million in the first nine months of 2019 compared to $588.9 million in the first nine months of 2018. Of the new orders received in the first nine months of 2019, $255.7 million related to Filtration products, $147.1 million related to Test products, $158.5 million related to USG products, and $64.7 million related to Technical Packaging products. Of the new orders received in the first nine months of 2018, $219.1 million related to Filtration products, $144.2 million related to Test products, $168.0 million related to USG products, and $57.6 million related to Technical Packaging products.

[0001144204-19-038765:mdna:19]
[same as prior period, unchanged from 0001144204-19-024737:mdna:19]

[0001144204-19-038765:mdna:20]
Selling, general and administrative (SG&A) expenses for the third quarter of 2019 were $43.4 million (21.7% of net sales), compared with $39.9 million (20.8% of net sales) for the third quarter of 2018. For the first nine months of 2019, SG&A expenses were $126.1 million (21.9% of net sales) compared to $122.8 million (22.7% of net sales) for the first nine months of 2018. The increase in SG&A in the third quarter and first nine months of 2019 compared to the corresponding periods of 2018 was mainly due to an increase in the USG segment due to higher sales commissions including additional sales and marketing expenses to support future revenue growth.

[0001144204-19-038765:mdna:21]
[same as prior period, unchanged from 0001144204-19-024737:mdna:21]

[0001144204-19-038765:mdna:22]
Amortization of intangible assets was $4.7 million and $14.0 million for the third quarter and first nine months of 2019, respectively, compared to $4.6 million and $13.6 million for the corresponding periods of 2018. Amortization expenses consist of amortization of acquired intangible assets from acquisitions and other identifiable intangible assets (primarily software). The increase in amortization expense in the first nine months of 2019 compared to the first nine months of 2018 was mainly due to an increase in amortization of intangibles related to the Manta acquisition.

[0001144204-19-038765:mdna:23]
[same as prior period, unchanged from 0001144204-19-024737:mdna:23]

[0001144204-19-038765:mdna:24]
Other expenses, net, was $2.6 million in the third quarter of 2019 compared to other income, net, of $0.7 million in the third quarter of 2018. The principal components in other expenses, net, in the third quarter of 2019 were $1.2 million of restructuring charges related to the closure of Plastique’s headquarters in Tunbridge Wells, UK; the consolidation of

[0001144204-19-038765:mdna:25]
VACCO’s aircraft/aerospace business into PTI’s aerospace facility in Oxnard, California; the completion of other restructuring activities begun in 2018; and losses on derivative instruments. The principal component in other income, net, in the third quarter of 2018 was a gain on derivative instruments of $0.5 million.

[0001144204-19-038765:mdna:26]
Other income, net, was $2.0 million in the first nine months of 2019 compared to other expenses, net, of $1.0 million in the first nine months of 2018. The principal component in other income, net, in the first nine months of 2019 was a gain of approximately $8 million on the sale of the Doble Watertown, MA building and land, partially offset by certain restructuring activities at Doble, PTI, VACCO and Plastique and losses on derivative instruments. The principal components in other expenses, net, in the first nine months of 2018 were $2.1 million of charges related to the USG segment restructuring activities as mentioned above, partially offset by gains on derivative instruments.

[0001144204-19-038765:mdna:27]
[same as prior period, unchanged from 0001144204-19-024737:mdna:26]

[0001144204-19-038765:mdna:28]
The Company evaluates the performance of its operating segments based on EBIT, and provides EBIT on a consolidated basis, which is a non-GAAP financial measure. Please refer to the discussion of non-GAAP financial measures in Note 7 to the Consolidated Financial Statements, above. EBIT was $26.9 million (13.4% of net sales) for the third quarter of 2019 compared to $25.6 million (13.3% of net sales) for the third quarter of 2018. For the first nine months of 2019, EBIT was $75.3 million (13.1% of net sales) compared to $56.2 million (10.4% of net sales) for the first nine months of 2018.

[0001144204-19-038765:mdna:29]
The following table presents a reconciliation of EBIT to net earnings.

[0001144204-19-038765:mdna:30]
| ​ | ​ | Three Months Ended | ​ | Nine Months Ended |
| ​ | ​ | June 30, | ​ | June 30, |
| (In thousands) |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Consolidated EBIT | ​ | $ | 26,865 | ​ | 25,559 | ​ | 75,292 | ​ | 56,165 |
| Less: Interest expense, net | ​ |  | (1,973) |  | (2,243) |  | (5,788) |  | (6,464) |
| (Less) Plus: Income tax | ​ |  | (4,825) |  | (4,297) |  | (13,323) |  | 13,983 |
| Net earnings | ​ | $ | 20,067 |  | 19,019 |  | 56,181 |  | 63,684 |

[0001144204-19-038765:mdna:31]
[same as prior period, unchanged from 0001144204-19-024737:mdna:30]

[0001144204-19-038765:mdna:32]
EBIT in the third quarter of 2019 was $19.0 million (22.9% of net sales) compared to $14.3 million (20.5% of net sales) in the third quarter of 2018. EBIT in the first nine months of 2019 was $47.1 million (20.6% of net sales) compared to $35.1 million (17.9% of net sales) in the first nine months of 2018. The increase in EBIT in the third quarter and first nine months of 2019 compared to the corresponding periods of 2018 was mainly due to an increase across all companies within the segment due to the higher sales volumes as mentioned above. EBIT in the third quarter and first nine months of 2019 was negatively impacted by restructuring charges incurred related to the consolidation of VACCO’s aircraft/aerospace business into PTI’s aerospace facility in Oxnard, California, ($0.3 million in the third quarter of 2019 and $0.8 million in the first nine months of 2019). These charges consisted primarily of severance and compensation benefits.

[0001144204-19-038765:mdna:33]
[same as prior period, unchanged from 0001144204-19-024737:mdna:32]

[0001144204-19-038765:mdna:34]
EBIT in the third quarter of 2019 was $5.9 million (14.0% of net sales) compared to $5.9 million (13.1% of net sales) in the third quarter of 2018. EBIT in the first nine months of 2019 was $14.8 million (11.7% of net sales) compared to $13.8 million (11.2% of net sales) in the first nine months of 2018. The increase in EBIT in the first nine months of 2019 compared to the first nine months of 2018 was primarily due to the increased sales volumes mainly from the segment’s Asian operations.

[0001144204-19-038765:mdna:35]
[same as prior period, unchanged from 0001144204-19-024737:mdna:34]

[0001144204-19-038765:mdna:36]
EBIT in the third quarter of 2019 was $10.1 million (19.2% of net sales) compared to $11.5 million (20.8% of net sales) in the third quarter of 2018. EBIT in the first nine months of 2019 was $40.5 million (25.7% of net sales) compared to

[0001144204-19-038765:mdna:37]
EBIT of $27.8 million (17.6% of net sales) in the first nine months of 2018. The increase in EBIT in the third quarter and first nine months of 2019 compared to the corresponding periods of 2018 was mainly due to the gain on sale of the Doble Watertown facility of approximately $8 million in the first quarter of 2019, as well as an increase in EBIT from Morgan Schaffer and Manta product lines partially offset by a decrease in EBIT from NRG due to market softness.

[0001144204-19-038765:mdna:38]
[same as prior period, unchanged from 0001144204-19-024737:mdna:36]

[0001144204-19-038765:mdna:39]
EBIT in the third quarter of 2019 was $1.6 million (7.6% of net sales) compared to $2.5 million (11.4% of net sales) in the third quarter of 2018. EBIT in the first nine months of 2019 was $3.3 million (5.3% of net sales) compared to $5.4 million (8.4% of net sales) in the first nine months of 2018. The decrease in EBIT in the third quarter and first nine months of 2019 compared to the corresponding periods of 2018 was mainly due to the restructuring charges incurred related to the Plastique facility consolidation, ($0.6 million in the third quarter of 2019 and $1.3 million in the first nine months of 2019). These charges consisted primarily of severance and compensation benefits and asset impairment charges.

[0001144204-19-038765:mdna:40]
[same as prior period, unchanged from 0001144204-19-024737:mdna:38]

[0001144204-19-038765:mdna:41]
Corporate costs included in EBIT were $9.9 million and $30.4 million in the third quarter and first nine months of 2019, respectively, compared to $8.7 million and $25.8 million in the corresponding periods of 2018. The increase in Corporate costs in the third quarter and first nine months of 2019 compared to the corresponding periods of 2018 was primarily due to higher professional fees, acquisition costs and timing of other Corporate costs recorded in the first nine months of 2019.

[0001144204-19-038765:mdna:42]
[same as prior period, unchanged from 0001144204-19-024737:mdna:40]

[0001144204-19-038765:mdna:43]
Interest expense was $2.0 million and $5.9 million in the third quarter and first nine months of 2019, respectively, and $2.2 million and $6.5 million in the corresponding periods of 2018. The decrease in interest expense in the first nine months of 2019 compared to the first nine months of 2018 was mainly due to lower average outstanding borrowings ($216 million compared to $263 million).

[0001144204-19-038765:mdna:44]
[same as prior period, unchanged from 0001144204-19-024737:mdna:42]

[0001144204-19-038765:mdna:45]
The third quarter 2019 effective income tax rate was 19.4% compared to 18.4% in the third quarter of 2018. The income tax expense for the first nine months of 2019 was $13.3 million compared to income tax benefit of $14.0 million for the first nine months of 2018. The effective income tax rate for the first nine months of 2019 was 19.2% compared to (28.1%) for the first nine months of 2018. The income tax expense in the third quarter and first nine months of 2019 was favorably impacted by tax planning strategies to increase foreign tax credits claimed retrospectively. The Company reduced the valuation allowance for excess foreign tax credits by $2.4 million ($2.3 million in the second quarter of 2019 and $0.1 million in third quarter of 2019) and recorded an amended return benefit of $0.3 million ($0.2 million in the second quarter of 2019 and $0.1 million in the third quarter of 2019) which favorably impacted the third quarter and year-to-date effective tax rate by 1.0% and 4.1%, respectively.   Income tax expense in the third quarter of 2019 and first nine months of 2019 was also favorably impacted by additional tax benefits on share-based compensation that vested during the quarter decreasing the effective tax rate by 1.8% and 0.7%, respectively.  A non-automatic accounting method change filed with the 2018 tax return was approved by the Internal Revenue Service during the third quarter of 2019 and favorably impacted the third quarter and year-to-date effective tax rate by 1.0% and 0.4%, respectively.

[0001144204-19-038765:mdna:46]
H.R. 1, Tax Cuts and Jobs Act (“TCJA”), was signed into law on December 22, 2017.  The total impact of the TCJA in the third quarter and first nine months of 2018 was a net expense of $0.1 million and a net benefit of $24.3 million, respectively.  The impacts were as follows: First, the Company’s 2018 federal statutory rate dropped from 35.0% to 24.5% which required an adjustment to the value of its deferred tax assets and liabilities.  This adjustment ($30.3 million provisional amount recorded in the first quarter of 2018 and $0.4 million provisional amount in the third quarter of 2018) favorably impacted the third quarter and year-to-date effective tax rate by 1.5% and 61.7%, respectively.  Second, the TCJA subjected the Company’s cumulative foreign earnings to deferral income tax ($4.1 million provisional amount of which $2.9 million was recorded in the first quarter of 2018, $0.7 million was recorded in the third quarter of 2018 and

[0001144204-19-038765:mdna:47]
$0.5 million in the third quarter of 2019) which unfavorably impacted the third quarter and year-to-date effective tax rate by 2.1% and 8.2%, respectively.

[0001144204-19-038765:mdna:48]
In the first quarter of 2018, the Company recorded a $2.3 million provisional estimate of the income tax effects of the future repatriation of the cumulative earnings of its foreign subsidiaries which unfavorably impacted the year-to-date effective tax rate by 4.7%.  An additional $7.5 million pension contribution for the 2017 plan year was approved during the second quarter of 2018 increasing the value of the deferred tax liability by $1.0 million.  This favorable adjustment, net of the $0.3 million unfavorable impact to the 2017 Domestic Production Deduction, favorably impacted the year-to-date effective tax rate by 1.6%. An accounting method change was filed with the 2017 tax return which resulted in an additional deferred tax liability to be adjusted as a result of the TCJA. A favorable adjustment, net of the $0.3 million unfavorable impact to the 2018 Domestic Production deduction, favorably impacted the third quarter and year-to-date effective tax rate by 2.9% and 1.4%, respectively. The income tax expense in the third quarter and first nine months of 2018 was favorably impacted by return to provision true-ups decreasing the third quarter and year-to-date effective tax rate by 1.4% and 0.7%, respectively.  Income tax expense in the third quarter and first nine months of 2018 was also favorably impacted by additional tax benefits on share-based compensation that vested during the quarter decreasing the effective tax rate by 1.9% and 0.9%, respectively.

[0001144204-19-038765:mdna:49]
Provisions under the TCJA that became effective for the Company in the current fiscal year include a further reduction in the U.S. statutory rate to 21%, a new minimum tax on global intangible low-taxed income (“GILTI”), the benefit of the deduction for foreign-derived intangible income (“FDII”), and changes to IRC Section 162(m) related to the deductibility of executive compensation.

[0001144204-19-038765:mdna:50]
[same as prior period, unchanged from 0001144204-19-024737:mdna:47]

[0001144204-19-038765:mdna:51]
The Company’s overall financial position and liquidity remains strong. Working capital (current assets less current liabilities) increased to $250.5 million at June 30, 2019 from $195.5 million at September 30, 2018. Inventories decreased by $8.6 million during this period mainly due to a $12.7 million decrease within the Filtration segment resulting primarily from the adoption of ASU No. 2014-09, Revenue from Contracts with Customers (ASC 606). Contract assets increased $46.5 million in the first nine months of 2019 mainly due to the adoption of ASC 606 within the Filtration segment.

[0001144204-19-038765:mdna:52]
Net cash provided by operating activities was $37.0 million and $53.9 million in the first nine months of 2019 and 2018, respectively. The decrease in net cash provided by operating activities in the first nine months of 2019 as compared to the first nine months of 2018 was due to higher working capital requirements.

[0001144204-19-038765:mdna:53]
Capital expenditures were $26.5 million and $15.5 million in the first nine months of 2019 and 2018, respectively. The increase in the first nine months of 2019 was mainly due to a $9.1 million facility expansion at TEQ. In addition, the Company incurred expenditures for capitalized software of $6.2 million and $7.1 million in the first nine months of 2019 and 2018, respectively.

[0001144204-19-038765:mdna:54]
Credit Facility

[0001144204-19-038765:mdna:55]
At June 30, 2019, the Company had approximately $225 million available to borrow under its bank credit facility, a $250 million increase option, and $39.0 million cash on hand. At June 30, 2019, the Company had $217.0 million of outstanding borrowings under the Credit Facility, and $0.9 million of short-term borrowing in addition to outstanding letters of credit of $7.2 million. Cash flow from operations and borrowings under the Company’s credit facility are expected to meet the Company’s capital requirements and operational needs for the foreseeable future. The Company’s ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.

[0001144204-19-038765:mdna:56]
[same as prior period, unchanged from 0001144204-19-024737:mdna:53]

[0001144204-19-038765:mdna:57]
In February 2016, the FASB issued ASU No. 2016-062, “Leases” (ASU 2016-02) which supersedes ASC 840, “Leases” and creates a new topic, ASC 842 “Leases.” Subsequent to the issuance of ASU 2016-02, ASC 842 was amended by

[0001144204-19-038765:mdna:58]
various updates that amend and clarify the impact and implementation of the aforementioned update. These updates require lessees to recognize a lease liability and a lease asset for all leases, including operating leases, with a term greater than 12 months on its balance sheet. Upon initial application, the provisions of these updates are required to be applied using the modified retrospective method which requires retrospective adoption to each prior reporting period presented with the cumulative effect of adoption recorded to the earliest reporting period presented. An optional transition method can be utilized which requires retrospective adoption beginning on the date of adoption with the cumulative effect of initially applying these updates recognized at the date of initial adoption. These updates also expand the required quantitative and qualitative disclosures surrounding leases. These updates are effective for fiscal years beginning after December 15, 2018 and interim periods within those fiscal years, with earlier application permitted. We expect to adopt these updates on October 1, 2019 using the optional transition method. We continue to evaluate the impact these updates will have on our consolidated financial statements. Based upon the analysis and preliminary evaluation of the standard, we estimate the adoption will result in the addition of assets and liabilities of less than $30 million to our consolidated balance sheet, with no significant change to our consolidated statements of operations or cash flows. We believe the updates will also have an impact on our accounting policies, internal controls and disclosures related to leases.

[0001144204-19-038765:mdna:59]
In October 2016, the FASB issued ASU No. 2016-16, Intra-Entity Transfers of Assets Other Than Inventory, which eliminates the exception for all intra-entity sale of assets other than inventory. This standard is effective for annual periods beginning after December 15, 2017. There was no significant impact to the Company’s consolidated financial statements as a result of adopting this new standard.

[0001144204-19-038765:mdna:60]
Acquisition

[0001144204-19-038765:mdna:61]
During the third quarter of 2019, the Company paid a deferred payment of $0.9 million in connection with the 2016 acquisition of Plastique.

[0001144204-19-038765:mdna:62]
Subsequent Event

[0001144204-19-038765:mdna:63]
On July 2, 2019, the Company acquired Globe Composite Solutions, LLC (Globe), a supplier of mission-critical composite-based products and solutions for navy, defense, and industrial customers. Globe’s operating results from date of acquisition will be included in the Company’s Filtration segment.

[0001144204-19-038765:mdna:64]
[same as prior period, unchanged from 0001144204-19-024737:mdna:56]

[0001144204-19-038765:mdna:65]
A quarterly dividend of $0.08 per share, totaling $2.1 million, was paid on April 18, 2019 to stockholders of record as of April 3, 2019. Subsequent to June 30, 2019, a quarterly dividend of $0.08 per share, totaling $2.1 million, was paid on July 19, 2019 to stockholders of record as of July 5, 2019.

[0001144204-19-038765:mdna:66]
[same as prior period, unchanged from 0001144204-19-024737:mdna:58]

[0001144204-19-038765:mdna:67]
Management’s current expectations for 2019 remain consistent with the details outlined in the Business Outlook in the previous release and expects 2019 Adjusted EPS guidance in the range of $3.05 to $3.10 per share. Management is excluding the following expected adjustments to 2019 GAAP EPS: A pre-tax gain from the October 2018 sale of Doble’s headquarters building in Watertown, Massachusetts; and pre-tax costs related to the relocation of Doble’s headquarters, the closure of Plastique’s headquarters in Tunbridge Wells, UK and the consolidation of its product design and administrative functions into its facilities in Nottingham, UK and Poznan, Poland; the consolidation of VACCO’s aircraft/aerospace business into PTI’s aerospace facility in Oxnard, California; and the completion of other restructuring activities begun in 2018.

[0001144204-19-038765:mdna:68]
[same as prior period, unchanged from 0001144204-19-024737:mdna:60]

[0001144204-19-038765:mdna:69]
Management has evaluated the accounting policies used in the preparation of the Company’s financial statements and related notes and believes those policies to be reasonable and appropriate. Certain of these accounting policies require the application of significant judgment by management in selecting appropriate assumptions for calculating financial estimates. By their nature, these judgments are subject to an inherent degree of uncertainty. These judgments are based

[0001144204-19-038765:mdna:70]
on historical experience, trends in the industry, information provided by customers and information available from other outside sources, as appropriate. The most significant areas involving management judgments and estimates may be found in the Critical Accounting Policies section of Management’s Discussion and Analysis and in Note 1 to the Consolidated Financial Statements contained in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2018.

[0001144204-19-038765:mdna:71]
[same as prior period, unchanged from 0001144204-19-024737:mdna:62]

[0001144204-19-038765:mdna:72]
Contingencies

[0001144204-19-038765:mdna:73]
As a normal incident of the business in which the Company is engaged, various claims, charges and litigation are asserted or commenced against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. In the opinion of management, the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company, are adequately reserved, are covered by insurance, or would not have a material adverse effect on the Company’s results from operations, capital expenditures, or competitive position.

[0001144204-19-038765:mdna:74]
[same as prior period, unchanged from 0001144204-19-024737:mdna:65]

[0001144204-19-038765:mdna:75]
Investors are cautioned that such statements are only predictions and speak only as of the date of this Form 10-Q, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment, including but not limited to those described in Item 1A, “Risk Factors,” of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2018, and the following: the impacts of natural disasters on the Company’s operations and those of the Company’s customers and suppliers; the timing and content of future contract awards or customer orders; the appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer contracts or orders; financial exposure in connection with Company guarantees of certain Aclara contracts; weakening of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties; the availability of selected acquisitions; delivery delays or defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability of certain raw materials; labor disputes; changes in U.S. tax laws and regulations; other changes in laws and regulations including but not limited to changes in accounting standards and foreign taxation; changes in interest rates; costs relating to environmental matters arising from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the integration of recently acquired businesses.
