# ESE note change history — 0001104659-26-011932 → 0001104659-26-058482


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-05-11):
[0001104659-26-058482:note_history:1]
The accompanying condensed consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The condensed consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP). For further information refer to the consolidated financial statements and related notes included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2025.
  (was, 2026-02-09, similarity 0.9929):
[0001104659-26-011932:note_history:1]
The accompanying condensed consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP). For further information refer to the consolidated financial statements and related notes included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2025.

- changed (2026-05-11):
[0001104659-26-058482:note_history:2]
The Company’s results for the three and six-month periods ended March 31, 2026 are not necessarily indicative of the results for the entire 2026 fiscal year. References to the second quarters of 2026 and 2025 represent the fiscal quarters ended March 31, 2026 and 2025, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.
  (was, 2026-02-09, similarity 0.9383):
[0001104659-26-011932:note_history:2]
The Company’s results for the three-month period ended December 31, 2025 are not necessarily indicative of the results for the entire 2026 fiscal year. References to the first quarters of 2026 and 2025 represent the fiscal quarters ended December 31, 2025 and 2024, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-05-11):
[0001104659-26-058482:note_history:3]
| ​ | ​ ​ ​ | March 31, | ​ | September 30, |
| (In thousands) | ​ ​ ​ | 2026 | ​ ​ ​ | 2025 |
| Revolving credit facility | ​ | $ | 45,000 | ​ | 25,000 |
| Incremental facility (Term loan A) | ​ | ​ | 100,000 | ​ | 161,000 |
| Total borrowings | ​ | $ | 145,000 | ​ | 186,000 |
| Current portion of long-term debt | ​ | ​ | (20,000) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 125,000 | ​ | 166,000 |

- changed (2026-05-11):
[0001104659-26-058482:note_history:4]
On August 5, 2024, the Company and certain of its subsidiaries entered into Amendment No. 1 to the Credit Facility which, among other things, (i) implements a senior incremental delayed draw term loan credit facility in an aggregate principal amount of up to $375 million (the “Incremental Facility”), and (ii) permits the direct or indirect acquisition by the Registrant or certain of its subsidiaries of all the issued and outstanding shares of PMES I Limited, Measurement Systems, Inc., EMS Development Corporation, and DNE Technologies, Inc. (the “Maritime Acquisition”), pursuant to and in accordance with the terms and conditions of that certain Sale and Purchase Agreement, dated July 8, 2024. During the third quarter of 2025, the proceeds of the loans drawn under the Incremental Facility were applied to pay a portion of the cash consideration for the Maritime Acquisition and other customary fees, premiums, expenses and costs incurred in connection with the acquisition. The Incremental Facility matures August 30, 2028, with balance due by this date.
  (was, 2026-02-09, similarity 0.8899):
[0001104659-26-011932:note_history:4]
On August 5, 2024, the Company and certain of its subsidiaries entered into Amendment No. 1 (the “Amendment”) to the Credit Facility which, among other things, (i) implements a senior incremental delayed draw term loan credit facility in an aggregate principal amount of up to $375 million (the “Incremental Facility”), and (ii) permits the direct or indirect acquisition by the Registrant or certain of its subsidiaries of all the issued and outstanding shares of PMES I Limited, Measurement Systems, Inc., EMS Development Corporation, and DNE Technologies, Inc. (the “Maritime Acquisition”), pursuant to and in accordance with the terms and conditions of that certain Sale and Purchase Agreement, dated July 8, 2024, among Ultra Electronics Holdings Limited, as parent seller, the Registrant, as guarantor, and certain of the Registrant’s subsidiaries as buyers. During the third quarter of 2025, the proceeds of the loans drawn under the Incremental Facility were applied to pay a portion of the cash consideration for the Maritime Acquisition and other customary fees, premiums, expenses and costs incurred in connection with the acquisition.

- added (2026-05-11):
[0001104659-26-058482:note_history:5]
At March 31, 2026, the Company had approximately $440 million available to borrow under the Credit Facility, plus the $250 million increase option subject to the lenders’ consent, in addition to $92.3 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of March 31, 2026, as the Company intends to repay this amount as obligated by the repayment terms of the Incremental Facility within the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $14.5 million at March 31, 2026.

- changed (2026-05-11):
[0001104659-26-058482:note_history:6]
Interest on borrowings under the Credit Facility and the Incremental Facility is calculated at a spread ranging from 0.25% to 2.25% over either an Adjusted Term SOFR Rate, Adjusted EURIBOR Rate, Adjusted CDOR Rate, Alternate Base Rate or Daily Simple RFR, at the Company’s election. The Credit Facility also requires a facility fee ranging from 12.5 to 25 basis points per annum. The interest rate spreads and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio. The weighted average interest rates under the Credit Facility were 5.06% and 5.28% for the three and six-month periods ending March 31, 2026, respectively, and 5.77% and 5.95% for the three- and six-month periods ending March 31, 2025. The weighted average interest rate under the Incremental Facility was 5.27% and 5.44% for the three and six-month periods ending March 31, 2026. As of March 31, 2026, the Company was in compliance with all covenants.
  (was, 2026-02-09, similarity 0.6829):
[0001104659-26-011932:note_history:6]
Interest on borrowings under the Credit Facility is calculated at a spread over either an Adjusted Term SOFR Rate, Adjusted EURIBOR Rate, Adjusted CDOR Rate, Alternate Base Rate or Daily Simple RFR, at the Company’s election. The Credit Facility also requires a facility fee ranging from 12.5 to 25 basis points per annum. The interest rate spreads and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio. The weighted average interest rates under the Credit Facility were 5.7% and 6.1% for the three-month periods ending December 31, 2025 and 2024, respectively. The weighted average interest rate under the Incremental Facility was 5.6% for the three-month period ending December 31, 2025. As of December 31, 2025, the Company was in compliance with all covenants.

- removed (2026-05-11):
[0001104659-26-011932:note_history:7]
| ​ | ​ ​ ​ | December 31, | ​ | September 30, |
| (In thousands) | ​ ​ ​ | 2025 | ​ ​ ​ | 2025 |
| Revolving credit facility and short-term borrowings | ​ | ​ | 20,511 | ​ | 25,000 |
| Incremental facility (Term loan A) | ​ | ​ | 125,000 | ​ | 161,000 |
| Total borrowings | ​ | $ | 145,511 | ​ | 186,000 |
| Current portion of long-term debt and short-term borrowings | ​ | ​ | (20,511) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 125,000 | ​ | 166,000 |

- removed (2026-05-11):
[0001104659-26-011932:note_history:8]
At December 31, 2025, the Company had approximately $469 million available to borrow under the Credit Facility, excluding the Incremental Facility, plus the $250 million increase option subject to the lenders’ consent, in addition to $103.8 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of December 31, 2025, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. In addition, the Company had $0.5 million of short-term borrowings at its foreign locations outstanding as of December 31, 2025. The letters of credit issued and outstanding under the Credit Facility totaled $10.7 million at December 31, 2025.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-05-11):
[0001104659-26-058482:note_history:9]
| ​ | ​ ​ ​ | March 31, | ​ | September 30, |
| (In thousands) | ​ ​ ​ | 2026 | ​ ​ ​ | 2025 |
| Revolving credit facility | ​ | $ | 45,000 | ​ | 25,000 |
| Incremental facility (Term loan A) | ​ | ​ | 100,000 | ​ | 161,000 |
| Total borrowings | ​ | $ | 145,000 | ​ | 186,000 |
| Current portion of long-term debt | ​ | ​ | (20,000) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 125,000 | ​ | 166,000 |

- removed (2026-05-11):
[0001104659-26-011932:note_history:10]
| ​ | ​ ​ ​ | December 31, | ​ | September 30, |
| (In thousands) | ​ ​ ​ | 2025 | ​ ​ ​ | 2025 |
| Revolving credit facility and short-term borrowings | ​ | ​ | 20,511 | ​ | 25,000 |
| Incremental facility (Term loan A) | ​ | ​ | 125,000 | ​ | 161,000 |
| Total borrowings | ​ | $ | 145,511 | ​ | 186,000 |
| Current portion of long-term debt and short-term borrowings | ​ | ​ | (20,511) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 125,000 | ​ | 166,000 |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2026-05-11):
[0001104659-26-058482:note_history:11]
Two of the Company’s directors are officers at two customers of the Company’s Doble subsidiary. Doble sells products, leases equipment and provides testing services in the ordinary course of Doble’s business. The total amount of these sales to these two customers was approximately $1.0 million and $2.3 million for the three- and six-month periods ending March 31, 2026. All transactions between Doble and the two customers are intended to be and have been consistent with Doble’s normal commercial terms offered to its customers, and the Company’s Board of Directors has determined that the relationships between the Company and the customers are not material and did not impair the Company’s or the directors’ independence.
  (was, 2026-02-09, similarity 0.9092):
[0001104659-26-011932:note_history:11]
Two of the Company’s directors are officers at two customers of the Company’s Doble subsidiary. Doble sells products, leases equipment and provides testing services in the ordinary course of Doble’s business. The total amount of these sales was approximately $1.3 million during the first quarter of fiscal 2026. All transactions between Doble and the two customers are intended to be and have been consistent with Doble’s normal commercial terms offered to its customers, and the Company’s Board of Directors has determined that the relationships between the Company and the customers are not material and did not impair the Company’s or the directors’ independence.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2026-05-11):
[0001104659-26-058482:note_history:12]
The tables below present our revenues from continuing operations by customer type, geographic location, and revenue recognition method for the three and six-month periods ending March 31, 2026, as we believe this presentation best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors.

- changed (2026-05-11):
[0001104659-26-058482:note_history:13]
| Three months ended March 31, 2026 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) | ​ ​ ​ | A&D | ​ ​ ​ | USG | ​ ​ ​ | Test | ​ ​ ​ | Total |
| Customer type: |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |
| Commercial | ​ | $ | 55,937 | ​ | ​ | 89,982 | ​ | ​ | 55,229 | ​ | ​ | 201,148 |
| Government | ​ | ​ | 94,373 | ​ | ​ | 3,547 | ​ | ​ | 10,273 | ​ | ​ | 108,193 |
| Total revenues | ​ | $ | 150,310 | ​ | ​ | 93,529 | ​ | ​ | 65,502 | ​ | ​ | 309,341 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 99,609 | ​ | ​ | 58,873 | ​ | ​ | 40,584 | ​ | ​ | 199,066 |
| International | ​ | ​ | 50,701 | ​ | ​ | 34,656 | ​ | ​ | 24,918 | ​ | ​ | 110,275 |
| Total revenues | ​ | $ | 150,310 | ​ | ​ | 93,529 | ​ | ​ | 65,502 | ​ | ​ | 309,341 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 69,877 | ​ | ​ | 75,227 | ​ | ​ | 15,188 | ​ | ​ | 160,292 |
| Over time | ​ | ​ | 80,433 | ​ | ​ | 18,302 | ​ | ​ | 50,314 | ​ | ​ | 149,049 |
| Total revenues | ​ | $ | 150,310 | ​ | ​ | 93,529 | ​ | ​ | 65,502 | ​ | ​ | 309,341 |
  (was, 2026-02-09, similarity 0.7856):
[0001104659-26-011932:note_history:13]
| (In thousands) | ​ ​ ​ | A&D | ​ ​ ​ | USG | ​ ​ ​ | Test | ​ ​ ​ | Total |
| Customer type: |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |
| Commercial | ​ | $ | 45,796 | ​ | $ | 85,739 | ​ | $ | 46,317 | ​ | $ | 177,852 |
| Government | ​ | ​ | 98,033 | ​ | ​ | 1,745 | ​ | ​ | 12,029 | ​ | ​ | 111,807 |
| Total revenues | ​ | $ | 143,829 | ​ | $ | 87,484 | ​ | $ | 58,346 | ​ | $ | 289,659 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 92,786 | ​ | $ | 60,724 | ​ | $ | 36,482 | ​ | $ | 189,992 |
| International | ​ | ​ | 51,043 | ​ | ​ | 26,760 | ​ | ​ | 21,864 | ​ | ​ | 99,667 |
| Total revenues | ​ | $ | 143,829 | ​ | $ | 87,484 | ​ | $ | 58,346 | ​ | $ | 289,659 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 66,534 | ​ | $ | 68,289 | ​ | $ | 9,217 | ​ | $ | 144,040 |
| Over time | ​ | ​ | 77,295 | ​ | ​ | 19,195 | ​ | ​ | 49,129 | ​ | ​ | 145,619 |
| Total revenues | ​ | $ | 143,829 | ​ | $ | 87,484 | ​ | $ | 58,346 | ​ | $ | 289,659 |

- changed (2026-05-11):
[0001104659-26-058482:note_history:14]
| Six months ended March 31, 2026 | ​ | ​ | ​ | ​ ​ ​ | ​ | ​ | ​ ​ ​ | ​ | ​ | ​ ​ ​ | ​ |
| (In thousands) | ​ ​ ​ | A&D | ​ ​ ​ | USG | ​ ​ ​ | Test | ​ ​ ​ | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 101,733 | ​ | ​ | 175,721 | ​ | ​ | 101,546 | ​ | ​ | 379,000 |
| Government | ​ | ​ | 192,406 | ​ | ​ | 5,292 | ​ | ​ | 22,302 | ​ | ​ | 220,000 |
| Total revenues | ​ | $ | 294,139 | ​ | ​ | 181,013 | ​ | ​ | 123,848 | ​ | ​ | 599,000 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 192,396 | ​ | ​ | 119,597 | ​ | ​ | 77,066 | ​ | ​ | 389,059 |
| International | ​ | ​ | 101,743 | ​ | ​ | 61,416 | ​ | ​ | 46,782 | ​ | ​ | 209,941 |
| Total revenues | ​ | $ | 294,139 | ​ | ​ | 181,013 | ​ | ​ | 123,848 | ​ | ​ | 599,000 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 136,412 | ​ | ​ | 143,515 | ​ | ​ | 27,304 | ​ | ​ | 307,231 |
| Over time | ​ | ​ | 157,727 | ​ | ​ | 37,498 | ​ | ​ | 96,544 | ​ | ​ | 291,769 |
| Total revenues | ​ | $ | 294,139 | ​ | ​ | 181,013 | ​ | ​ | 123,848 | ​ | ​ | 599,000 |
  (was, 2026-02-09, similarity 0.7849):
[0001104659-26-011932:note_history:14]
| (In thousands) | ​ ​ ​ | A&D | ​ ​ ​ | USG | ​ ​ ​ | Test | ​ ​ ​ | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 45,755 | ​ | $ | 84,279 | ​ | $ | 36,349 | ​ | $ | 166,383 |
| Government | ​ | ​ | 36,113 | ​ | ​ | 2,381 | ​ | ​ | 9,716 | ​ | ​ | 48,210 |
| Total revenues | ​ | $ | 81,868 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 214,593 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 65,314 | ​ | $ | 59,917 | ​ | $ | 28,630 | ​ | $ | 153,861 |
| International | ​ | ​ | 16,554 | ​ | ​ | 26,743 | ​ | ​ | 17,435 | ​ | ​ | 60,732 |
| Total revenues | ​ | $ | 81,868 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 214,593 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 46,995 | ​ | $ | 69,278 | ​ | $ | 9,791 | ​ | $ | 126,064 |
| Over time | ​ | ​ | 34,873 | ​ | ​ | 17,382 | ​ | ​ | 36,274 | ​ | ​ | 88,529 |
| Total revenues | ​ | $ | 81,868 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 214,593 |

- changed (2026-05-11):
[0001104659-26-058482:note_history:15]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2025 are presented in the tables below from continuing operations.
  (was, 2026-02-09, similarity 0.8629):
[0001104659-26-011932:note_history:15]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2024 are presented in the table below:

- added (2026-05-11):
[0001104659-26-058482:note_history:16]
| Three months ended March 31, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) | ​ ​ ​ | A&D | ​ ​ ​ | USG | ​ ​ ​ | Test | ​ ​ ​ | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 48,702 | ​ | ​ | 89,649 | ​ | ​ | 37,891 | ​ | ​ | 176,242 |
| Government | ​ |  | 40,925 | ​ | ​ | 1,118 | ​ | ​ | 13,492 | ​ | ​ | 55,535 |
| Total revenues | ​ | $ | 89,627 | ​ | ​ | 90,767 | ​ | ​ | 51,383 | ​ | ​ | 231,777 |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 66,612 | ​ | ​ | 54,944 | ​ | ​ | 32,267 | ​ | ​ | 153,823 |
| International | ​ |  | 23,015 | ​ | ​ | 35,823 | ​ | ​ | 19,116 | ​ | ​ | 77,954 |
| Total revenues | ​ | $ | 89,627 | ​ | ​ | 90,767 | ​ | ​ | 51,383 | ​ | ​ | 231,777 |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 52,364 | ​ | ​ | 73,002 | ​ | ​ | 11,607 | ​ | ​ | 136,973 |
| Over time | ​ |  | 37,263 | ​ | ​ | 17,765 | ​ | ​ | 39,776 | ​ | ​ | 94,804 |
| Total revenues | ​ | $ | 89,627 | ​ | ​ | 90,767 | ​ | ​ | 51,383 | ​ | ​ | 231,777 |

- added (2026-05-11):
[0001104659-26-058482:note_history:17]
| Six months ended March 31, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) | ​ ​ ​ | A&D | ​ ​ ​ | USG | ​ ​ ​ | Test | ​ ​ ​ | Total |
| Customer type: |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |
| Commercial | ​ | $ | 94,458 | ​ | ​ | 173,928 | ​ | ​ | 74,240 | ​ | ​ | 342,626 |
| Government | ​ |  | 77,037 | ​ | ​ | 3,499 | ​ | ​ | 23,208 | ​ | ​ | 103,744 |
| Total revenues | ​ | $ | 171,495 | ​ | ​ | 177,427 | ​ | ​ | 97,448 | ​ | ​ | 446,370 |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 131,926 | ​ | ​ | 114,860 | ​ | ​ | 60,897 | ​ | ​ | 307,683 |
| International | ​ |  | 39,569 | ​ | ​ | 62,567 | ​ | ​ | 36,551 | ​ | ​ | 138,687 |
| Total revenues | ​ | $ | 171,495 | ​ | ​ | 177,427 | ​ | ​ | 97,448 | ​ | ​ | 446,370 |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 99,359 | ​ | ​ | 142,280 | ​ | ​ | 21,398 | ​ | ​ | 263,037 |
| Over time | ​ |  | 72,136 | ​ | ​ | 35,147 | ​ | ​ | 76,050 | ​ | ​ | 183,333 |
| Total revenues | ​ | $ | 171,495 | ​ | ​ | 177,427 | ​ | ​ | 97,448 | ​ | ​ | 446,370 |

- removed (2026-05-11):
[0001104659-26-011932:note_history:18]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2025 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within each reportable segment.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2026-05-11):
[0001104659-26-058482:note_history:19]
The tables below present our revenues from continuing operations by customer type, geographic location, and revenue recognition method for the three and six-month periods ending March 31, 2026, as we believe this presentation best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors.

- changed (2026-05-11):
[0001104659-26-058482:note_history:20]
| Three months ended March 31, 2026 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) | ​ ​ ​ | A&D | ​ ​ ​ | USG | ​ ​ ​ | Test | ​ ​ ​ | Total |
| Customer type: |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |
| Commercial | ​ | $ | 55,937 | ​ | ​ | 89,982 | ​ | ​ | 55,229 | ​ | ​ | 201,148 |
| Government | ​ | ​ | 94,373 | ​ | ​ | 3,547 | ​ | ​ | 10,273 | ​ | ​ | 108,193 |
| Total revenues | ​ | $ | 150,310 | ​ | ​ | 93,529 | ​ | ​ | 65,502 | ​ | ​ | 309,341 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 99,609 | ​ | ​ | 58,873 | ​ | ​ | 40,584 | ​ | ​ | 199,066 |
| International | ​ | ​ | 50,701 | ​ | ​ | 34,656 | ​ | ​ | 24,918 | ​ | ​ | 110,275 |
| Total revenues | ​ | $ | 150,310 | ​ | ​ | 93,529 | ​ | ​ | 65,502 | ​ | ​ | 309,341 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 69,877 | ​ | ​ | 75,227 | ​ | ​ | 15,188 | ​ | ​ | 160,292 |
| Over time | ​ | ​ | 80,433 | ​ | ​ | 18,302 | ​ | ​ | 50,314 | ​ | ​ | 149,049 |
| Total revenues | ​ | $ | 150,310 | ​ | ​ | 93,529 | ​ | ​ | 65,502 | ​ | ​ | 309,341 |
  (was, 2026-02-09, similarity 0.7856):
[0001104659-26-011932:note_history:20]
| (In thousands) | ​ ​ ​ | A&D | ​ ​ ​ | USG | ​ ​ ​ | Test | ​ ​ ​ | Total |
| Customer type: |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |
| Commercial | ​ | $ | 45,796 | ​ | $ | 85,739 | ​ | $ | 46,317 | ​ | $ | 177,852 |
| Government | ​ | ​ | 98,033 | ​ | ​ | 1,745 | ​ | ​ | 12,029 | ​ | ​ | 111,807 |
| Total revenues | ​ | $ | 143,829 | ​ | $ | 87,484 | ​ | $ | 58,346 | ​ | $ | 289,659 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 92,786 | ​ | $ | 60,724 | ​ | $ | 36,482 | ​ | $ | 189,992 |
| International | ​ | ​ | 51,043 | ​ | ​ | 26,760 | ​ | ​ | 21,864 | ​ | ​ | 99,667 |
| Total revenues | ​ | $ | 143,829 | ​ | $ | 87,484 | ​ | $ | 58,346 | ​ | $ | 289,659 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 66,534 | ​ | $ | 68,289 | ​ | $ | 9,217 | ​ | $ | 144,040 |
| Over time | ​ | ​ | 77,295 | ​ | ​ | 19,195 | ​ | ​ | 49,129 | ​ | ​ | 145,619 |
| Total revenues | ​ | $ | 143,829 | ​ | $ | 87,484 | ​ | $ | 58,346 | ​ | $ | 289,659 |

- changed (2026-05-11):
[0001104659-26-058482:note_history:21]
| Six months ended March 31, 2026 | ​ | ​ | ​ | ​ ​ ​ | ​ | ​ | ​ ​ ​ | ​ | ​ | ​ ​ ​ | ​ |
| (In thousands) | ​ ​ ​ | A&D | ​ ​ ​ | USG | ​ ​ ​ | Test | ​ ​ ​ | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 101,733 | ​ | ​ | 175,721 | ​ | ​ | 101,546 | ​ | ​ | 379,000 |
| Government | ​ | ​ | 192,406 | ​ | ​ | 5,292 | ​ | ​ | 22,302 | ​ | ​ | 220,000 |
| Total revenues | ​ | $ | 294,139 | ​ | ​ | 181,013 | ​ | ​ | 123,848 | ​ | ​ | 599,000 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 192,396 | ​ | ​ | 119,597 | ​ | ​ | 77,066 | ​ | ​ | 389,059 |
| International | ​ | ​ | 101,743 | ​ | ​ | 61,416 | ​ | ​ | 46,782 | ​ | ​ | 209,941 |
| Total revenues | ​ | $ | 294,139 | ​ | ​ | 181,013 | ​ | ​ | 123,848 | ​ | ​ | 599,000 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 136,412 | ​ | ​ | 143,515 | ​ | ​ | 27,304 | ​ | ​ | 307,231 |
| Over time | ​ | ​ | 157,727 | ​ | ​ | 37,498 | ​ | ​ | 96,544 | ​ | ​ | 291,769 |
| Total revenues | ​ | $ | 294,139 | ​ | ​ | 181,013 | ​ | ​ | 123,848 | ​ | ​ | 599,000 |
  (was, 2026-02-09, similarity 0.7849):
[0001104659-26-011932:note_history:21]
| (In thousands) | ​ ​ ​ | A&D | ​ ​ ​ | USG | ​ ​ ​ | Test | ​ ​ ​ | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 45,755 | ​ | $ | 84,279 | ​ | $ | 36,349 | ​ | $ | 166,383 |
| Government | ​ | ​ | 36,113 | ​ | ​ | 2,381 | ​ | ​ | 9,716 | ​ | ​ | 48,210 |
| Total revenues | ​ | $ | 81,868 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 214,593 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 65,314 | ​ | $ | 59,917 | ​ | $ | 28,630 | ​ | $ | 153,861 |
| International | ​ | ​ | 16,554 | ​ | ​ | 26,743 | ​ | ​ | 17,435 | ​ | ​ | 60,732 |
| Total revenues | ​ | $ | 81,868 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 214,593 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 46,995 | ​ | $ | 69,278 | ​ | $ | 9,791 | ​ | $ | 126,064 |
| Over time | ​ | ​ | 34,873 | ​ | ​ | 17,382 | ​ | ​ | 36,274 | ​ | ​ | 88,529 |
| Total revenues | ​ | $ | 81,868 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 214,593 |

- changed (2026-05-11):
[0001104659-26-058482:note_history:22]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2025 are presented in the tables below from continuing operations.
  (was, 2026-02-09, similarity 0.8629):
[0001104659-26-011932:note_history:22]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2024 are presented in the table below:

- added (2026-05-11):
[0001104659-26-058482:note_history:23]
| Three months ended March 31, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) | ​ ​ ​ | A&D | ​ ​ ​ | USG | ​ ​ ​ | Test | ​ ​ ​ | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 48,702 | ​ | ​ | 89,649 | ​ | ​ | 37,891 | ​ | ​ | 176,242 |
| Government | ​ |  | 40,925 | ​ | ​ | 1,118 | ​ | ​ | 13,492 | ​ | ​ | 55,535 |
| Total revenues | ​ | $ | 89,627 | ​ | ​ | 90,767 | ​ | ​ | 51,383 | ​ | ​ | 231,777 |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 66,612 | ​ | ​ | 54,944 | ​ | ​ | 32,267 | ​ | ​ | 153,823 |
| International | ​ |  | 23,015 | ​ | ​ | 35,823 | ​ | ​ | 19,116 | ​ | ​ | 77,954 |
| Total revenues | ​ | $ | 89,627 | ​ | ​ | 90,767 | ​ | ​ | 51,383 | ​ | ​ | 231,777 |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 52,364 | ​ | ​ | 73,002 | ​ | ​ | 11,607 | ​ | ​ | 136,973 |
| Over time | ​ |  | 37,263 | ​ | ​ | 17,765 | ​ | ​ | 39,776 | ​ | ​ | 94,804 |
| Total revenues | ​ | $ | 89,627 | ​ | ​ | 90,767 | ​ | ​ | 51,383 | ​ | ​ | 231,777 |

- added (2026-05-11):
[0001104659-26-058482:note_history:24]
| Six months ended March 31, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) | ​ ​ ​ | A&D | ​ ​ ​ | USG | ​ ​ ​ | Test | ​ ​ ​ | Total |
| Customer type: |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |
| Commercial | ​ | $ | 94,458 | ​ | ​ | 173,928 | ​ | ​ | 74,240 | ​ | ​ | 342,626 |
| Government | ​ |  | 77,037 | ​ | ​ | 3,499 | ​ | ​ | 23,208 | ​ | ​ | 103,744 |
| Total revenues | ​ | $ | 171,495 | ​ | ​ | 177,427 | ​ | ​ | 97,448 | ​ | ​ | 446,370 |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 131,926 | ​ | ​ | 114,860 | ​ | ​ | 60,897 | ​ | ​ | 307,683 |
| International | ​ |  | 39,569 | ​ | ​ | 62,567 | ​ | ​ | 36,551 | ​ | ​ | 138,687 |
| Total revenues | ​ | $ | 171,495 | ​ | ​ | 177,427 | ​ | ​ | 97,448 | ​ | ​ | 446,370 |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 99,359 | ​ | ​ | 142,280 | ​ | ​ | 21,398 | ​ | ​ | 263,037 |
| Over time | ​ |  | 72,136 | ​ | ​ | 35,147 | ​ | ​ | 76,050 | ​ | ​ | 183,333 |
| Total revenues | ​ | $ | 171,495 | ​ | ​ | 177,427 | ​ | ​ | 97,448 | ​ | ​ | 446,370 |

- changed (2026-05-11):
[0001104659-26-058482:note_history:25]
Remaining Unsatisfied Performance Obligations
  (was, 2026-02-09, similarity 0.8462):
[0001104659-26-011932:note_history:25]
Remaining Performance Obligations

- added (2026-05-11):
[0001104659-26-058482:note_history:26]
Remaining unsatisfied performance obligations, as defined by ASC 606 and align with our backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At March 31, 2026, the Company had $1,470.0 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 55% in the next twelve months.

- changed (2026-05-11):
[0001104659-26-058482:note_history:27]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At March 31, 2026, contract assets, contract liabilities and accounts receivable totaled $103.5 million, $275.6 million and $256.8 million, respectively. During the first six months of 2026, the Company recognized approximately $56 million in revenues that were included in the contract liabilities balance at September 30, 2025. At September 30, 2025, contract assets, contract liabilities and accounts receivable from continuing operations totaled $90.7 million, $224.7 million and $253.6 million, respectively.
  (was, 2026-02-09, similarity 0.8848):
[0001104659-26-011932:note_history:27]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At December 31, 2025, contract assets, contract liabilities and accounts receivable totaled $88.7 million, $259.5 million and $245.3 million, respectively. During the first quarter of 2026, the Company recognized approximately $37.7 million in revenues that were included in the contract liabilities balance at September 30, 2025. At September 30, 2025, contract assets, contract liabilities and accounts receivable totaled $90.7 million, $224.7 million and $253.6 million, respectively.

- removed (2026-05-11):
[0001104659-26-011932:note_history:28]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2025 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within each reportable segment.

- removed (2026-05-11):
[0001104659-26-011932:note_history:29]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to performance obligations that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At December 31, 2025, the Company had $1,401.1 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 58% in the next twelve months.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2026-05-11):
[0001104659-26-058482:note_history:30]
15.  SUBSEQUENT EVENT

- added (2026-05-11):
[0001104659-26-058482:note_history:31]
On April 15, 2026, the Company signed a definitive agreement to acquire the Megger Group Limited (Megger) business of TBG AG. Megger is a global provider of testing, monitoring, and data-driven solutions for utilities and critical electric infrastructure, including industrial, transportation, data center and renewable end markets. Under the terms of the agreement, ESCO will acquire Megger for total consideration of approximately $2.35 billion, consisting of $0.9 billion in cash and ESCO equity valued at approximately $1.4 billion. The cash portion will be funded through existing cash on hand and incremental debt, with committed financing in place. The Company expects to complete the acquisition in the first quarter of fiscal 2027. Megger will become part of the Company’s Utility Solution Group (USG) segment. See further discussion of the transaction and financing arrangements in the Company’s Form 8-K’s filed April 15, 2026 and April 16, 2026.
