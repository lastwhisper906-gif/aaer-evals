# ESE 8-K — 0001104659-26-057162 filed 2026-05-07

## item codes, every 8-K on or before 2026-05-11

- 2026-05-07 0001104659-26-057162 — 2.02, 7.01, 9.01
- 2026-04-16 0001104659-26-044425 — 1.01, 3.02, 9.01
- 2026-04-15 0001104659-26-043869 — 2.02, 7.01, 9.01
- 2026-02-05 0001104659-26-010899 — 2.02, 5.07, 7.01, 9.01
- 2025-11-20 0001104659-25-114614 — 2.02, 5.02, 7.01, 9.01
- 2025-08-07 0001104659-25-075202 — 2.02, 7.01, 9.01
- 2025-05-07 0001104659-25-045548 — 2.02, 7.01, 9.01
- 2025-04-28 0001104659-25-039819 — 2.01, 7.01, 9.01
- 2025-02-06 0001104659-25-010118 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2024-11-14 0001104659-24-118951 — 2.02, 5.02, 7.01, 9.01
- 2024-10-18 0001104659-24-109788 — 5.02
- 2024-10-01 0001104659-24-104776 — 5.02
- 2024-08-07 0001104659-24-086768 — 1.01, 2.02, 5.02, 7.01, 9.01
- 2024-07-08 0001104659-24-078312 — 1.01, 7.01, 9.01
- 2024-05-09 0001104659-24-059341 — 2.02, 7.01, 9.01
- 2024-02-08 0001104659-24-012294 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2023-11-20 0001104659-23-119761 — 5.02, 9.01
- 2023-11-16 0001104659-23-119126 — 2.02, 7.01, 9.01
- 2023-10-03 0001104659-23-106090 — 5.02, 9.01
- 2023-09-06 0001104659-23-098463 — 1.01, 2.03, 9.01
- 2023-08-08 0001104659-23-088847 — 2.02, 7.01, 9.01
- 2023-07-06 0001104659-23-078571 — 5.02, 8.01, 9.01
- 2023-05-09 0001104659-23-057736 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2023-05-05 0001104659-23-056387 — 5.02, 9.01
- 2023-02-08 0001104659-23-014539 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2023-01-06 0001104659-23-001859 — 5.02, 9.01
- 2022-11-22 0001104659-22-121229 — 5.02, 5.03, 8.01, 9.01
- 2022-11-17 0001104659-22-119898 — 2.02, 7.01, 9.01
- 2022-09-12 0001104659-22-099248 — 5.02, 7.01, 9.01
- 2022-08-08 0001104659-22-087247 — 2.02, 5.02, 7.01, 9.01
- 2022-05-09 0001104659-22-057524 — 2.02, 5.02, 7.01, 9.01
- 2022-02-08 0001104659-22-013878 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2021-12-03 0001104659-21-146361 — 4.01, 9.01 — amendment, the index does not say of what
- 2021-11-24 0001104659-21-143568 — 4.01, 9.01
- 2021-11-23 0001104659-21-142871 — 5.02, 8.01
- 2021-11-18 0001104659-21-141206 — 2.02, 7.01, 9.01
- 2021-08-09 0001104659-21-102150 — 2.02, 7.01, 9.01
- 2021-05-04 0001104659-21-060985 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2021-04-05 0001104659-21-046581 — 5.02, 9.01
- 2021-02-08 0001104659-21-013712 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2020-12-09 0001104659-20-133674 — 5.02, 9.01
- 2020-12-07 0001104659-20-132861 — 5.02, 7.01, 9.01
- 2020-11-19 0001104659-20-127352 — 2.02, 5.02, 7.01, 9.01
- 2020-08-10 0001104659-20-092734 — 2.02, 7.01, 9.01
- 2020-05-06 0001104659-20-057442 — 2.02, 7.01, 8.01, 9.01
- 2020-02-04 0001104659-20-010640 — 2.02, 5.07, 7.01, 9.01
- 2020-01-07 0001104659-20-001789 — 2.01, 9.01
- 2019-11-19 0001104659-19-065437 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2019-11-18 0001104659-19-065096 — 1.01, 2.02, 7.01, 9.01
- 2019-09-30 0001144204-19-046523 — 1.01, 1.02, 2.03, 9.01
- 2019-08-08 0001144204-19-038567 — 2.02, 7.01, 9.01
- 2019-05-07 0001144204-19-024241 — 2.02, 5.02, 7.01, 9.01
- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2026-05-11

- none on or before 2026-05-11

## item 2.02 — earnings release, exhibit 99.1

[0001104659-26-057162:8k_2_02:1]
EX-99.1
2
tm2613615d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-26-057162:8k_2_02:2]
Exhibit 99.1

[0001104659-26-057162:8k_2_02:3]
| NEWS FROM |  |

[0001104659-26-057162:8k_2_02:4]
For more information contact:

[0001104659-26-057162:8k_2_02:5]
Kate Lowrey - VP of Investor Relations

[0001104659-26-057162:8k_2_02:6]
(314)
213-7277 / klowrey@escotechnologies.com

[0001104659-26-057162:8k_2_02:7]
ESCO REPORTS
SECOND QUARTER FISCAL 2026 RESULTS

[0001104659-26-057162:8k_2_02:8]
- Q2 Sales increase 33% to $309 Million -

[0001104659-26-057162:8k_2_02:9]
- Q2 Entered Orders increase 42% to $378
Million -

[0001104659-26-057162:8k_2_02:10]
- Q2 GAAP EPS from Continuing Operations
increases 26% to $1.29 -

[0001104659-26-057162:8k_2_02:11]
- Q2 Adjusted EPS from Continuing Operations
increases 63% to $1.91 -

[0001104659-26-057162:8k_2_02:12]
ST. LOUIS, May 7, 2026 – ESCO Technologies Inc. (NYSE: ESE) (ESCO,
or the Company) today reported its operating results for the second quarter ended March 31, 2026 (Q2 2026).

[0001104659-26-057162:8k_2_02:13]
Operating
Highlights

[0001104659-26-057162:8k_2_02:14]
|  | · | Q2 2026 Sales increased $78 million (33.5 percent) to $309 million compared to $232 million in Q2 2025. Q2 2026 organic sales increased $30 million (12.8 percent) and Maritime contributed $48 million (20.7 percent) of revenue growth in the quarter. |

[0001104659-26-057162:8k_2_02:15]
|  | · | Q2 2026 GAAP EPS from Continuing Operations increased 26.5 percent to $1.29 per share compared to $1.02 per share in Q2 2025. Q2 2026 Adjusted EPS from Continuing Operations increased 63.2 percent to $1.91 per share compared to $1.17 per share in Q2 2025. |

[0001104659-26-057162:8k_2_02:16]
|  | · | Q2 2026 Entered Orders increased $113 million (42.4 percent) to $378 million (book-to-bill of 1.22), resulting in record backlog of $1.5 billion. |

[0001104659-26-057162:8k_2_02:17]
|  | · | Net cash provided by operating activities was $135 million YTD, an increase of $88 million compared to the prior year period. |

[0001104659-26-057162:8k_2_02:18]
Bryan
Sayler, Chief Executive Officer and President, commented, “Q2 was another excellent quarter, highlighted by $378 million in orders,
33% revenue growth, and 320 basis points of Adjusted EBITDA margin expansion. We saw broad-based revenue strength across our Navy, aerospace,
Test, and utilities markets. It has been particularly encouraging to see a strong rebound in our Test business, with increasing
orders driving solid revenue growth across many of their served markets.

[0001104659-26-057162:8k_2_02:19]
“We believe this quarter’s results further
demonstrate the strength of our strategic positioning and our ability to execute consistently and deliver sustainable value. ESCO has
taken concrete steps to strengthen our business portfolio and we remain positive about the long-term outlook for our target markets. Across
these markets, durable demand drivers continue to be in place, and we are excited for the future.”

[0001104659-26-057162:8k_2_02:20]
Segment Performance

[0001104659-26-057162:8k_2_02:21]
Aerospace & Defense (A&D)

[0001104659-26-057162:8k_2_02:22]
|  | · | Q2 2026 sales increased $60.7 million (67.7 percent) to $150.3 million from $89.6 million in Q2 2025. Organic sales increased $12.9 million (14.3 percent) and Maritime added $47.8 million (53.4 percent) of revenue growth in the quarter. Quarterly sales growth was led by strong performance in Navy, commercial aerospace, and military aerospace. |

[0001104659-26-057162:8k_2_02:23]
|  | · | Q2 2026 EBIT increased $18.8 million to $43.0 million from $24.2 million in Q2 2025. Adjusted EBIT increased $18.9 million in Q2 2026 to $43.1 million (28.6 percent margin) from $24.2 million (27.0 percent margin) in Q2 2025. The 78 percent increase in Adjusted EBIT was driven by the addition of Maritime as well as leverage on higher volume, and price increases, partially offset by inflationary pressures and unfavorable mix. |

[0001104659-26-057162:8k_2_02:24]
|  | · | Q2 2026 entered orders increased $87.3 million (90.4 percent) to $183.8 million (book-to-bill of 1.22), resulting in record backlog of $1.1 billion. Orders strength in the quarter was primarily driven by $53 million in orders at Maritime, $24 million in Virginia Class orders at Globe, and higher commercial aerospace OEM orders. |

[0001104659-26-057162:8k_2_02:25]
Utility Solutions Group (USG)

[0001104659-26-057162:8k_2_02:26]
|  | · | Q2 2026 sales increased $2.7 million (3.0 percent) to $93.5 million from $90.8 million in Q2 2025. Doble sales increased by $8.4 million (11.3 percent) while NRG sales decreased by $5.7 million (35.8 percent). Sales growth in the quarter was driven by higher protection testing, offline test equipment, and services revenue at Doble, partially offset by lower wind and solar revenue at NRG. |

[0001104659-26-057162:8k_2_02:27]
|  | · | Q2 2026 EBIT increased $1.7 million to $22.5 million from $20.8 million in Q2 2025. Adjusted EBIT increased $2.2 million in Q2 2026 to $23.1 million (24.7 percent margin) from $20.9 million (23.0 percent margin) in Q2 2025. The 11 percent increase in Adjusted EBIT was driven by leverage on higher volume at Doble, price increases, and mix, partially offset by deleverage on lower volume at NRG and inflationary pressures. |

[0001104659-26-057162:8k_2_02:28]
|  | · | Q2 2026 entered orders increased $9.1 million (9.9 percent) to $101.3 million (book-to-bill of 1.08), resulting in backlog of $162.5 million. Doble orders increased $15.5 million (20.3 percent) to $92.1 million due to strength in services, offline test equipment, and condition monitoring orders. NRG orders decreased $6.4 million (41.3 percent) to $9.2 million, primarily due to lower wind and solar orders. |

[0001104659-26-057162:8k_2_02:29]
RF Test & Measurement (Test)

[0001104659-26-057162:8k_2_02:30]
|  | · | Q2 2026 sales increased $14.1 million (27.5 percent) to $65.5 million from $51.4 million in Q2 2025. Sales growth in the quarter was primarily driven by higher U.S Test & Measurement (EMC) and filter sales for government funded data centers. |

[0001104659-26-057162:8k_2_02:31]
|  | · | Q2 2026 EBIT increased $2.4 million to $8.8 million from $6.4 million in Q2 2025. Q2 2026 Adjusted EBIT increased $3.7 million to $10.1 million (15.4 percent margin) from $6.4 million (12.4 percent margin) in Q2 2025. The 59 percent increase in Adjusted EBIT was driven by leverage on higher volume and price increases, partially offset by inflationary pressures. |

[0001104659-26-057162:8k_2_02:32]
|  | · | Q2 2026 entered orders increased $16.1 million (21.0 percent) to $93.1 million (book-to-bill of 1.42), resulting in ending backlog of $232.5 million. Orders strength in the quarter was driven by higher Test and Measurement (EMC) orders in the U.S. and EMEA, filter orders for government funded data centers, and multiple industrial shielding projects. |

[0001104659-26-057162:8k_2_02:33]
Megger Acquisition

[0001104659-26-057162:8k_2_02:34]
As announced on April 15, 2026, ESCO has agreed to
acquire Megger Group Limited. Megger will become part of ESCO’s Utility Solutions Group, creating a business of substantial scale
and expanding our capabilities as a valued partner to utilities worldwide. All filings for regulatory approval are underway and we anticipate
closing on the transaction in Q1 of fiscal 2027.

[0001104659-26-057162:8k_2_02:35]
Business
Outlook – FY 2026

[0001104659-26-057162:8k_2_02:36]
FY 2026 Sales and Adjusted EPS Guidance Update:

[0001104659-26-057162:8k_2_02:37]
|  | · | Maintaining full year FY 2026 revenue guidance of $1.29 to $1.33 billion (18 to 21 percent growth over the prior year). |
|  | · | Raising full year Adjusted EPS guidance to be in the range of $8.00 - $8.25 per share (33 to 37 percent growth), which reflects a midpoint increase of $0.48 per share from our initial November guidance ($7.50 - $7.80) and $0.10 per share from our more recent February guidance update ($7.90 - $8.15). |
|  | · | Q3’26 Adjusted EPS is expected to be in the range of $2.05 - $2.15 per share (28 to 34 percent growth compared to Q3’25 Adjusted EPS). |

[0001104659-26-057162:8k_2_02:38]
Dividend
Payment

[0001104659-26-057162:8k_2_02:39]
The next quarterly
cash dividend of $0.08 per share will be paid on July 17, 2026 to stockholders of record on July
2, 2026.

[0001104659-26-057162:8k_2_02:40]
Conference Call

[0001104659-26-057162:8k_2_02:41]
The
Company will host a conference call today, May 7, at 4:00 p.m. Central Time, to discuss the Company’s Q2 2026 results. A live audio
webcast and an accompanying slide presentation will be available in the Investor Center of ESCO’s website. Participants may
also access the webcast using this registration link. For those unable to participate, a webcast replay will be available after the call
in the Investor Center of ESCO’s website.

[0001104659-26-057162:8k_2_02:42]
Forward-Looking Statements

[0001104659-26-057162:8k_2_02:43]
Investors
are cautioned that such statements are only predictions and speak only as of the date of this release, and the Company undertakes no duty
to update them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ
materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations
and business environment including but not limited to those described in Item 1A, “Risk Factors”, of the Company’s Annual
Report on Form 10-K for the fiscal year ended September 30, 2025 and the following: the impacts of climate change and related regulation
of greenhouse gases; the impacts of labor disputes, civil disorder, wars including the conflicts involving Iran and Lebanon, elections,
political changes, tariffs and trade disputes, terrorist activities, cyberattacks or natural disasters on the Company’s operations
and those of the Company’s customers and suppliers; disruptions in manufacturing or delivery arrangements due to shortages or unavailability
of materials or components; restrictions or closures of critical supply routes such as the Strait of Hormuz; other supply chain disruptions;
inability to access work sites; the timing and content of future contract awards or customer orders; the timely appropriation, allocation
and availability of Government funds; the termination for convenience of Government and other customer contracts or orders; weakening
of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies;
competition; intellectual property rights; technical difficulties or data breaches; the availability of acquisitions; delivery delays
or defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability
of certain raw materials; material changes in the cost of credit; changes in laws and regulations including but not limited to changes
in accounting standards and taxation; changes in interest, inflation and employment rates; costs relating to environmental matters arising
from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration;
and the integration and performance of acquired businesses.

[0001104659-26-057162:8k_2_02:44]
Non-GAAP Financial Measures

[0001104659-26-057162:8k_2_02:45]
The financial measures EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA,
and Adjusted EPS are presented in this press release. The Company defines “EBIT” as earnings before interest and taxes, “EBITDA”
as earnings before interest, taxes, depreciation and amortization, “Adjusted EBIT” and “Adjusted EBITDA” as excluding
the net impact of the items described in the attached Reconciliation of Non-GAAP Financial Measures, and “Adjusted EPS” as
GAAP earnings per share excluding the net impact of the items described and reconciled in the attached Reconciliation of Non-GAAP Financial
Measures.

[0001104659-26-057162:8k_2_02:46]
EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA, and
Adjusted EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management believes
EBIT, Adjusted EBIT, EBITDA, and Adjusted EBITDA are useful in assessing the operational profitability of the Company’s business
segments because they exclude interest, taxes, depreciation, and amortization, which are generally accounted for across the entire Company
on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company as
well as incentive compensation. The presentation of EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA, and Adjusted EPS provides important
supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures
to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance determined
in accordance with GAAP.

[0001104659-26-057162:8k_2_02:47]
About ESCO

[0001104659-26-057162:8k_2_02:48]
ESCO
Technologies is a global provider of highly engineered products and solutions serving diverse end-markets. It manufactures filtration
and fluid control products, advanced composites, as well as signature and power management solutions for aviation, Navy, and industrial
customers. ESCO is an industry leader in designing and manufacturing RF test and measurement products and systems; and provides diagnostic
instruments, software and services to industrial power users and the electric utility and renewable energy industries. Headquartered in
St. Louis, Missouri, ESCO and its subsidiaries have offices and manufacturing facilities worldwide. For more information on ESCO and its
subsidiaries, visit ESCO’s website at www.escotechnologies.com.

[0001104659-26-057162:8k_2_02:49]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-26-057162:8k_2_02:50]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-26-057162:8k_2_02:51]
(Dollars
in thousands, except per share amounts)

[0001104659-26-057162:8k_2_02:52]
|  |  | Three Months Ended March 31, 2026 |  |  | Three Months Ended March 31, 2025 |  |
| Net Sales |  | $ | 309,341 |  |  |  | 231,777 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 178,026 |  |  |  | 132,504 |  |
| Selling, general and administrative expenses |  |  | 62,830 |  |  |  | 54,294 |  |
| Amortization of intangible assets |  |  | 20,420 |  |  |  | 7,989 |  |
| Interest expense |  |  | 2,399 |  |  |  | 2,195 |  |
| Other expenses (income), net |  |  | 1,802 |  |  |  | 375 |  |
| Total costs and expenses |  |  | 265,477 |  |  |  | 197,357 |  |
| Earnings before income taxes |  |  | 43,864 |  |  |  | 34,420 |  |
| Income tax expense |  |  | 10,308 |  |  |  | 8,037 |  |
| Earnings from continuing operations |  |  | 33,556 |  |  |  | 26,383 |  |
| Earnings from discontinued operations, net of tax expense of $363 and $1,429, respectively |  |  | 1,177 |  |  |  | 4,650 |  |
| Net earnings |  | $ | 34,733 |  |  |  | 31,033 |  |
| Diluted - GAAP |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 1.29 |  |  |  | 1.02 |  |
| Discontinued operations |  |  | 0.05 |  |  |  | 0.18 |  |
| Net earnings |  | $ | 1.34 |  |  |  | 1.20 |  |
| Diluted - As Adjusted Basis |  |  |  |  |  |  |  |  |
| Continuing Operations |  |  | $1.91 | (1) |  |  | 1.17 | (2) |
| Diluted average common shares O/S: |  |  | 25,938 |  |  |  | 25,877 |  |

[0001104659-26-057162:8k_2_02:53]
| (1) | Q2 2026 Adjusted EPS from continuing operations excludes $0.62 per share of after-tax charges consisting of: $0.06 of Test & USG segment restructuring charges, $0.03 of Corporate acquisition costs and $0.53 of acquisition related amortization. |
| (2) | Q2 2025 Adjusted EPS from continuing operations excludes $0.15 per share of after-tax charges consisting primarily of acquisition related amortization. |

[0001104659-26-057162:8k_2_02:54]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-26-057162:8k_2_02:55]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-26-057162:8k_2_02:56]
(Dollars in thousands, except per share amounts)

[0001104659-26-057162:8k_2_02:57]
|  |  | Six Months Ended March 31, 2026 |  |  | Six Months Ended March 31, 2025 |  |
| Net Sales |  | $ | 599,000 |  |  |  | 446,370 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 347,766 |  |  |  | 256,718 |  |
| Selling, general and administrative expenses |  |  | 124,037 |  |  |  | 109,263 |  |
| Amortization of intangible assets |  |  | 40,744 |  |  |  | 15,982 |  |
| Interest expense |  |  | 5,279 |  |  |  | 4,452 |  |
| Other expenses (income), net |  |  | 1,832 |  |  |  | (262 | ) |
| Total costs and expenses |  |  | 519,658 |  |  |  | 386,153 |  |
| Earnings before income taxes |  |  | 79,342 |  |  |  | 60,217 |  |
| Income tax expense |  |  | 17,095 |  |  |  | 13,527 |  |
| Earnings from continuing operations |  |  | 62,247 |  |  |  | 46,690 |  |
| Earnings from discontinued operations, net of tax expense of $363 and $2,407, respectively |  |  | 1,177 |  |  |  | 7,816 |  |
| Net earnings |  | $ | 63,424 |  |  |  | 54,506 |  |
| Diluted - GAAP |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 2.40 |  |  |  | 1.81 |  |
| Discontinued operations |  |  | 0.05 |  |  |  | 0.30 |  |
| Net earnings |  | $ | 2.45 |  |  |  | 2.11 |  |
| Diluted - As Adjusted Basis |  |  |  |  |  |  |  |  |
| Continuing Operations |  | $ | 3.55 | (1) |  |  | 2.12 | (2) |
| Diluted average common shares O/S: |  |  | 25,909 |  |  |  | 25,854 |  |

[0001104659-26-057162:8k_2_02:58]
| (1) | YTD Q2 2026 Adjusted EPS from continuing operations excludes $1.15 per share of after-tax charges consisting primarily of: $0.07 of restructuring charges within Test, USG & A&D segments, $0.03 of Corporate acquisition costs and $1.05 of acquisition related amortization. |
| (2) | YTD Q2 2025 Adjusted EPS from continuing operations excludes $0.31 per share of after-tax charges consisting of: $0.01 of restructuring charges within the Test segment and $0.30 of acquisition related amortization. |

[0001104659-26-057162:8k_2_02:59]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-26-057162:8k_2_02:60]
Condensed Business Segment Information (Unaudited) - Continuing Operations basis

[0001104659-26-057162:8k_2_02:61]
(Dollars in thousands)

[0001104659-26-057162:8k_2_02:62]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | Q2 2026 |  |  | Q2 2025 |  |  | Q2 2026 |  |  | Q2 2025 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 150,310 |  |  |  | 89,627 |  |  |  | 150,310 |  |  |  | 89,627 |  |
| USG |  |  | 93,529 |  |  |  | 90,767 |  |  |  | 93,529 |  |  |  | 90,767 |  |
| Test |  |  | 65,502 |  |  |  | 51,383 |  |  |  | 65,502 |  |  |  | 51,383 |  |
| Totals |  | $ | 309,341 |  |  |  | 231,777 |  |  |  | 309,341 |  |  |  | 231,777 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 42,967 |  |  |  | 24,217 |  |  |  | 43,062 |  |  |  | 24,219 |  |
| USG |  |  | 22,486 |  |  |  | 20,779 |  |  |  | 23,068 |  |  |  | 20,862 |  |
| Test |  |  | 8,773 |  |  |  | 6,369 |  |  |  | 10,095 |  |  |  | 6,369 |  |
| Corporate |  |  | (27,963 | ) |  |  | (14,750 | ) |  |  | (9,011 | ) |  |  | (9,648 | ) |
| Consolidated EBIT |  |  | 46,263 |  |  |  | 36,615 |  |  |  | 67,214 |  |  |  | 41,802 |  |
| Less: Interest expense |  |  | (2,399 | ) |  |  | (2,195 | ) |  |  | (2,399 | ) |  |  | (2,195 | ) |
| Less: Income tax expense |  |  | (10,308 | ) |  |  | (8,037 | ) |  |  | (15,126 | ) |  |  | (9,230 | ) |
| Net earnings |  | $ | 33,556 |  |  |  | 26,383 |  |  |  | 49,689 |  |  |  | 30,377 |  |

[0001104659-26-057162:8k_2_02:63]
Note 1: Adjusted net earnings of $49.7 million in Q2 2026 exclude $16.2 million (or $0.62 per share) of after-tax charges consisting of: $0.06 of Test & USG segment restructuring charges, $0.03 of Corporate acquisition costs and $0.53 of acquisition related amortization.

[0001104659-26-057162:8k_2_02:64]
Note 2: Adjusted net earnings of $30.4 million in Q2 2025 exclude $4.0 million (or $0.15 per share) of after-tax charges consisting primarily of acquisition related amortization.

[0001104659-26-057162:8k_2_02:65]
| EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |  | Q2 2026 - |  |  | Q2 2025 - |  |
|  |  | Q2 2026 |  |  | Q2 2025 |  |  | As Adj |  |  | As Adj |  |
| Consolidated EBITDA |  | $ | 73,100 |  |  |  | 49,685 |  |  |  | 76,380 |  |  |  | 49,912 |  |
| Less: Depr & Amort |  |  | (26,837 | ) |  |  | (13,070 | ) |  |  | (9,166 | ) |  |  | (8,110 | ) |
| Consolidated EBIT |  |  | 46,263 |  |  |  | 36,615 |  |  |  | 67,214 |  |  |  | 41,802 |  |
| Less: Interest expense |  |  | (2,399 | ) |  |  | (2,195 | ) |  |  | (2,399 | ) |  |  | (2,195 | ) |
| Less: Income tax expense |  |  | (10,308 | ) |  |  | (8,037 | ) |  |  | (15,126 | ) |  |  | (9,230 | ) |
| Net earnings |  | $ | 33,556 |  |  |  | 26,383 |  |  |  | 49,689 |  |  |  | 30,377 |  |

[0001104659-26-057162:8k_2_02:66]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-26-057162:8k_2_02:67]
Condensed Business Segment Information (Unaudited) - Continuing Operations basis

[0001104659-26-057162:8k_2_02:68]
(Dollars in thousands)

[0001104659-26-057162:8k_2_02:69]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | YTD |  |  | YTD |  |  | YTD |  |  | YTD |  |
|  |  | Q2 2026 |  |  | Q2 2025 |  |  | Q2 2026 |  |  | Q2 2025 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 294,139 |  |  |  | 171,495 |  |  |  | 294,139 |  |  |  | 171,495 |  |
| USG |  |  | 181,013 |  |  |  | 177,427 |  |  |  | 181,013 |  |  |  | 177,427 |  |
| Test |  |  | 123,848 |  |  |  | 97,448 |  |  |  | 123,848 |  |  |  | 97,448 |  |
| Totals |  | $ | 599,000 |  |  |  | 446,370 |  |  |  | 599,000 |  |  |  | 446,370 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 80,954 |  |  |  | 41,669 |  |  |  | 81,195 |  |  |  | 41,697 |  |
| USG |  |  | 42,015 |  |  |  | 41,268 |  |  |  | 42,647 |  |  |  | 41,351 |  |
| Test |  |  | 16,815 |  |  |  | 10,791 |  |  |  | 18,137 |  |  |  | 11,256 |  |
| Corporate |  |  | (55,163 | ) |  |  | (29,059 | ) |  |  | (18,644 | ) |  |  | (18,958 | ) |
| Consolidated EBIT |  |  | 84,621 |  |  |  | 64,669 |  |  |  | 123,335 |  |  |  | 75,346 |  |
| Less: Interest expense |  |  | (5,279 | ) |  |  | (4,452 | ) |  |  | (5,279 | ) |  |  | (4,452 | ) |
| Less: Income tax |  |  | (17,095 | ) |  |  | (13,527 | ) |  |  | (25,998 | ) |  |  | (15,983 | ) |
| Net earnings |  | $ | 62,247 |  |  |  | 46,690 |  |  |  | 92,058 |  |  |  | 54,911 |  |

[0001104659-26-057162:8k_2_02:70]
Note
1: Adjusted net earnings of $92.1 million in YTD 2025 exclude $29.8 million (or $1.15 per share) of after-tax charges consisting of:
$0.07 of restructuring charges within Test, USG, A&D segments, $0.03 of Corporate acquisition costs and $1.05 of acquisition related
amortization.

[0001104659-26-057162:8k_2_02:71]
Note
2: Adjusted net earnings of $54.9 million in YTD 2025 exclude $8.2 million (or $0.31 per share) of after-tax charges consisting of: $0.01
of restructuring charges within the Test segment and $0.30 of acquisition related amortization.

[0001104659-26-057162:8k_2_02:72]
| EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |  | YTD |  |  | YTD |  |
|  |  | YTD |  |  | YTD |  |  | Q2 2026 - |  |  | Q2 2025 - |  |
|  |  | Q2 2026 |  |  | Q2 2025 |  |  | As Adj |  |  | As Adj |  |
| Consolidated EBITDA |  | $ | 137,951 |  |  |  | 90,710 |  |  |  | 141,427 |  |  |  | 91,430 |  |
| Less: Depr & Amort |  |  | (53,330 | ) |  |  | (26,041 | ) |  |  | (18,092 | ) |  |  | (16,084 | ) |
| Consolidated EBIT |  |  | 84,621 |  |  |  | 64,669 |  |  |  | 123,335 |  |  |  | 75,346 |  |
| Less: Interest expense |  |  | (5,279 | ) |  |  | (4,452 | ) |  |  | (5,279 | ) |  |  | (4,452 | ) |
| Less: Income tax expense |  |  | (17,095 | ) |  |  | (13,527 | ) |  |  | (25,998 | ) |  |  | (15,983 | ) |
| Net earnings |  | $ | 62,247 |  |  |  | 46,690 |  |  |  | 92,058 |  |  |  | 54,911 |  |

[0001104659-26-057162:8k_2_02:73]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-26-057162:8k_2_02:74]
Condensed Consolidated Balance Sheets (Unaudited)

[0001104659-26-057162:8k_2_02:75]
(Dollars in thousands)

[0001104659-26-057162:8k_2_02:76]
|  |  | March 31, 2026 |  |  | September 30 2025 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 92,252 |  |  |  | 101,350 |  |
| Accounts receivable, net |  |  | 256,835 |  |  |  | 253,554 |  |
| Contract assets |  |  | 103,532 |  |  |  | 90,730 |  |
| Inventories |  |  | 237,090 |  |  |  | 217,807 |  |
| Other current assets |  |  | 37,084 |  |  |  | 25,065 |  |
| Total current assets |  |  | 726,793 |  |  |  | 688,506 |  |
| Property, plant and equipment, net |  |  | 170,860 |  |  |  | 172,493 |  |
| Intangible assets, net |  |  | 682,372 |  |  |  | 723,973 |  |
| Goodwill |  |  | 761,181 |  |  |  | 761,931 |  |
| Operating lease assets |  |  | 48,977 |  |  |  | 47,707 |  |
| Other assets |  |  | 15,622 |  |  |  | 15,778 |  |
|  |  | $ | 2,405,805 |  |  |  | 2,410,388 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt |  | $ | 20,000 |  |  |  | 20,000 |  |
| Accounts payable |  |  | 106,677 |  |  |  | 96,534 |  |
| Contract liabilities |  |  | 269,402 |  |  |  | 216,590 |  |
| Current income tax payable |  |  | 5,619 |  |  |  | 62,007 |  |
| Other current liabilities |  |  | 98,667 |  |  |  | 113,017 |  |
| Total current liabilities |  |  | 500,365 |  |  |  | 508,148 |  |
| Deferred tax liabilities |  |  | 115,140 |  |  |  | 112,390 |  |
| Non-current operating lease liabilities |  |  | 45,707 |  |  |  | 44,403 |  |
| Other liabilities |  |  | 34,173 |  |  |  | 38,576 |  |
| Long-term debt |  |  | 125,000 |  |  |  | 166,000 |  |
| Shareholders’ equity |  |  | 1,585,420 |  |  |  | 1,540,871 |  |
|  |  | $ | 2,405,805 |  |  |  | 2,410,388 |  |

[0001104659-26-057162:8k_2_02:77]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-26-057162:8k_2_02:78]
Consolidated Statements of Cash Flows (Unaudited)

[0001104659-26-057162:8k_2_02:79]
(Dollars in thousands)

[0001104659-26-057162:8k_2_02:80]
|  |  | Six Months Ended March 31, 2026 |  |  | Six Months Ended March 31, 2025 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 63,424 |  |  |  | 54,506 |  |
| (Earnings) loss from discontinued operations |  |  | (1,177 | ) |  |  | (7,816 | ) |
| Adjustments to reconcile net earnings to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 53,330 |  |  |  | 26,041 |  |
| Stock compensation expense |  |  | 6,565 |  |  |  | 5,323 |  |
| Changes in assets and liabilities |  |  | 7,304 |  |  |  | (30,033 | ) |
| Effect of deferred taxes |  |  | 5,176 |  |  |  | (1,714 | ) |
| Net cash provided by operating activities - continuing operations |  |  | 134,622 |  |  |  | 46,307 |  |
| Net cash used by operating activities - discontinued operations |  |  | (59,340 | ) |  |  | 11,968 |  |
| Net cash provided by operating activities |  |  | 75,282 |  |  |  | 58,275 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Acquisition of business, net of cash acquired |  |  | (10,232 | ) |  |  | - |  |
| Capital expenditures |  |  | (13,134 | ) |  |  | (14,864 | ) |
| Additions to capitalized software and other |  |  | (4,801 | ) |  |  | (5,465 | ) |
| Net cash used by investing activities - continuing operations |  |  | (28,167 | ) |  |  | (20,329 | ) |
| Net cash provided by investing activities - discontinued operations |  |  | 1,540 |  |  |  | (486 | ) |
| Net cash used by investing activities |  |  | (26,627 | ) |  |  | (20,815 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from long-term debt and short term borrowings |  |  | 110,000 |  |  |  | 66,000 |  |
| Principal payments on long-term debt and short-term borrowings |  |  | (151,000 | ) |  |  | (100,000 | ) |
| Dividends paid |  |  | (4,143 | ) |  |  | (4,130 | ) |
| Other |  |  | (10,645 | ) |  |  | (6,146 | ) |
| Net cash used by financing activities |  |  | (55,788 | ) |  |  | (44,276 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (1,965 | ) |  |  | (1,750 | ) |
| Net decrease in cash and cash equivalents |  |  | (9,098 | ) |  |  | (8,566 | ) |
| Cash and cash equivalents, beginning of period |  |  | 101,350 |  |  |  | 65,963 |  |
| Cash and cash equivalents, end of period |  | $ | 92,252 |  |  |  | 57,397 |  |

[0001104659-26-057162:8k_2_02:81]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-26-057162:8k_2_02:82]
Other Selected Financial Data (Unaudited)

[0001104659-26-057162:8k_2_02:83]
(Dollars in thousands)

[0001104659-26-057162:8k_2_02:84]
| Backlog And Entered Orders - Q2 2026 |  | A&D |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 1/1/26 |  | $ | 1,041,514 |  |  |  | 154,772 |  |  |  | 204,863 |  |  |  | 1,401,149 |  |
| Entered Orders |  |  | 183,783 |  |  |  | 101,267 |  |  |  | 93,146 |  |  |  | 378,196 |  |
| Sales |  |  | (150,310 | ) |  |  | (93,529 | ) |  |  | (65,502 | ) |  |  | (309,341 | ) |
| Ending Backlog - 3/31/26 |  | $ | 1,074,987 |  |  |  | 162,510 |  |  |  | 232,507 |  |  |  | 1,470,004 |  |

[0001104659-26-057162:8k_2_02:85]
| Backlog And Entered Orders - YTD Q2 2026 |  | A&D |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 10/1/25 |  | $ | 803,002 |  |  |  | 143,460 |  |  |  | 187,175 |  |  |  | 1,133,637 |  |
| Entered Orders |  |  | 566,124 |  |  |  | 200,063 |  |  |  | 169,180 |  |  |  | 935,367 |  |
| Sales |  |  | (294,139 | ) |  |  | (181,013 | ) |  |  | (123,848 | ) |  |  | (599,000 | ) |
| Ending Backlog - 3/31/26 |  | $ | 1,074,987 |  |  |  | 162,510 |  |  |  | 232,507 |  |  |  | 1,470,004 |  |

[0001104659-26-057162:8k_2_02:86]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-26-057162:8k_2_02:87]
Reconciliation of Non-GAAP Financial Measures (Unaudited)

[0001104659-26-057162:8k_2_02:88]
| EPS – Adjusted Basis Reconciliation – Q2 2026 |  |  |  |  |
| EPS Continuing Operations – GAAP Basis – Q2 2026 |  | $ | 1.29 |  |
| Adjustments (defined below) |  |  | 0.62 |  |
| EPS Continuing Operations – As Adjusted Basis – Q2 2026 |  | $ | 1.91 |  |

[0001104659-26-057162:8k_2_02:89]
Adjustments
of $0.62 per share consist of: $0.06 of restructuring charges within the Test & USG segments, $0.03 of Corporate acquisition costs
 and $0.53 of acquisition related amortization.

[0001104659-26-057162:8k_2_02:90]
| EPS – Adjusted Basis Reconciliation – Q2 2025 |  |  |  |  |
| EPS Continuing Operations– GAAP Basis – Q2 2025 |  | $ | 1.02 |  |
| Adjustments (defined below) |  |  | 0.15 |  |
| EPS Continuing Operations– As Adjusted Basis – Q2 2025 |  | $ | 1.17 |  |

[0001104659-26-057162:8k_2_02:91]
Adjustments
of $0.15 per share consist of acquisition related amortization.

[0001104659-26-057162:8k_2_02:92]
| EPS – Adjusted Basis Reconciliation – YTD Q2 2026 |  |  |  |  |
| EPS Continuing Operations – GAAP Basis – YTD Q2 2026 |  | $ | 2.40 |  |
| Adjustments (defined below) |  |  | 1.15 |  |
| EPS Continuing Operations – As Adjusted Basis – YTD Q2 2026 |  | $ | 3.55 |  |

[0001104659-26-057162:8k_2_02:93]
Adjustments
of $1.15 per share consist of: $0.07 of restructuring charges within the Test, USG and A&D segments, $0.03 of Corporate acquisition
 costs and $1.05 of acquisition related amortization.

[0001104659-26-057162:8k_2_02:94]
| EPS – Adjusted Basis Reconciliation – YTD Q2 2025 |  |  |  |  |
| EPS Continuing Operations– GAAP Basis – YTD Q2 2025 |  | $ | 1.81 |  |
| Adjustments (defined below) |  |  | 0.31 |  |
| EPS Continuing Operations– As Adjusted Basis – YTD Q2 2025 |  | $ | 2.12 |  |

[0001104659-26-057162:8k_2_02:95]
Adjustments
of $0.31 per share consist of: $0.01 of restructuring charges within the Test segment, and $0.30 of acquisition related amortization.
