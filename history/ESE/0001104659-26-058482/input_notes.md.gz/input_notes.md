# ESE notes — 0001104659-26-058482


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001104659-26-058482:notes:1]
[same as prior period, unchanged from 0001104659-26-011932:notes:1]

[0001104659-26-058482:notes:2]
The accompanying condensed consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The condensed consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP). For further information refer to the consolidated financial statements and related notes included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2025.

[0001104659-26-058482:notes:3]
The Company’s results for the three and six-month periods ended March 31, 2026 are not necessarily indicative of the results for the entire 2026 fiscal year. References to the second quarters of 2026 and 2025 represent the fiscal quarters ended March 31, 2026 and 2025, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:EarningsPerShareTextBlock

[0001104659-26-058482:notes:4]
[same as prior period, unchanged from 0001104659-26-011932:notes:4]

[0001104659-26-058482:notes:5]
Basic EPS is calculated using the weighted average number of common shares outstanding during the period. Diluted EPS is calculated using the weighted average number of common shares outstanding during the period plus shares issuable upon the assumed exercise of unvested performance-based share awards and time-vested restricted shares by using the treasury stock method. The number of shares used in the calculation of earnings per share for each period presented is as follows (in thousands):

[0001104659-26-058482:notes:6]
| ​ | ​ ​ ​ | Three Months | ​ | Six Months |
| ​ | ​ | Ended March 31, | ​ | Ended March 31, |
| ​ | ​ ​ ​ | 2026 | ​ ​ ​ | 2025 | ​ ​ ​ | 2026 | ​ ​ ​ | 2025 |
| Weighted Average Shares Outstanding — Basic |  | 25,902 | ​ | 25,816 | ​ | 25,877 | ​ | 25,798 |
| Dilutive Shares | ​ | 36 | ​ | 61 | ​ | 32 | ​ | 57 |
| Adjusted Shares — Diluted |  | 25,938 | ​ | 25,877 | ​ | 25,909 | ​ | 25,855 |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001104659-26-058482:notes:7]
[same as prior period, unchanged from 0001104659-26-011932:notes:7]

[0001104659-26-058482:notes:8]
The Company provides compensation benefits to certain key employees under several share-based plans providing for a combination of performance-based share unit (PSU) awards and time-vested restricted share unit (RSU) awards and to non-employee directors under a separate compensation plan.

[0001104659-26-058482:notes:9]
Performance Share Unit (PSU) Awards and Time-Vested Restricted Stock Unit (RSU) Awards

[0001104659-26-058482:notes:10]
Compensation expense related to these awards was $3.0 million and $5.9 million for the three and six-month periods ended March 31, 2026, respectively, and $2.4 million and $4.6 million for the corresponding periods in 2025. As of March 31, 2026, there were 169,191 unvested stock units outstanding.

[0001104659-26-058482:notes:11]
[same as prior period, unchanged from 0001104659-26-011932:notes:11]

[0001104659-26-058482:notes:12]
Compensation expense related to the non-employee director grants was $0.3 million and $0.6 million for the three and six-month periods ended March 31, 2026, respectively, and $0.4 million and $0.7 million for the corresponding periods in 2025.

[0001104659-26-058482:notes:13]
The total share-based compensation cost that has been recognized in the results of operations and included within selling, general and administrative expenses (SG&A) was $3.3 million and $6.6 million for the three and six-month periods ended March 31, 2026, respectively, and $2.8 million and $5.3 million for the corresponding periods in 2025. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $0.7 million and $1.4 million for the three- and six-month periods ended March 31, 2026, respectively, and $0.6 million and $1.1 million for the corresponding periods in 2025. As of March 31, 2026, there was $18.8 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a remaining weighted-average period of 1.8 years.


## us-gaap:InventoryDisclosureTextBlock

[0001104659-26-058482:notes:14]
[same as prior period, unchanged from 0001104659-26-011932:notes:14]

[0001104659-26-058482:notes:15]
Inventories from continuing operations consist of the following:

[0001104659-26-058482:notes:16]
| ​ | ​ | March 31, | ​ | September 30, |
| (In thousands) | ​ ​ ​ | 2026 | ​ ​ ​ | 2025 |
| Finished goods | ​ | $ | 50,740 | ​ | 52,644 |
| Work in process | ​ | ​ | 63,243 | ​ | 46,825 |
| Raw materials | ​ | ​ | 123,107 | ​ | 118,338 |
| Total inventories | ​ | $ | 237,090 | ​ | 217,807 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001104659-26-058482:notes:17]
[same as prior period, unchanged from 0001104659-26-011932:notes:17]

[0001104659-26-058482:notes:18]
Included on the Company’s condensed Consolidated Balance Sheets at March 31, 2026 and September 30, 2025 are the following intangible assets gross carrying amounts and accumulated amortization from continuing operations:

[0001104659-26-058482:notes:19]
| ​ | ​ ​ ​ | March 31, | ​ ​ ​ | September 30, |
| (Dollars in thousands) | ​ ​ ​ | 2026 | ​ ​ ​ | 2025 |
| Goodwill | ​ | $ | 761,181 | ​ | 761,931 |
| Intangible assets with determinable lives: | ​ |  | ​ | ​ | ​ |
| Patents | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 7,618 | ​ | 7,607 |
| Less: accumulated amortization | ​ |  | 2,030 | ​ | 1,775 |
| Net | ​ | $ | 5,588 | ​ | 5,832 |
| Capitalized software | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 143,307 | ​ | 138,144 |
| Less: accumulated amortization | ​ |  | 106,097 | ​ | 100,818 |
| Net | ​ | $ | 37,210 | ​ | 37,326 |
| Customer relationships | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 620,238 | ​ | 625,535 |
| Less: accumulated amortization | ​ |  | 178,987 | ​ | 159,543 |
| Net | ​ | $ | 441,251 | ​ | 465,992 |
| Other | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 76,331 | ​ | 76,991 |
| Less: accumulated amortization | ​ |  | 40,595 | ​ | 24,829 |
| Net | ​ | $ | 35,736 | ​ | 52,162 |
| Intangible assets with indefinite lives: | ​ |  | ​ | ​ | ​ |
| Trade names | ​ | $ | 162,587 | ​ | 162,661 |

[0001104659-26-058482:notes:20]
The changes in the carrying amount of goodwill attributable to each business segment from continuing operations for the six months ended March 31, 2026 is as follows:

[0001104659-26-058482:notes:21]
| (Dollars in millions) | ​ ​ ​ | A&D | ​ ​ ​ | Test | ​ ​ ​ | USG | ​ ​ ​ | Total |
| Balance as of September 30, 2025 | ​ | $ | 334.0 |  | 67.8 |  | 360.1 |  | 761.9 |
| Acquisition activity and other | ​ | ​ | 5.1 | ​ | — | ​ | — | ​ | 5.1 |
| Foreign currency translation | ​ | ​ | (3.3) | ​ | (0.9) | ​ | (1.6) | ​ | (5.8) |
| Balance as of March 31, 2026 | ​ | $ | 335.8 |  | 66.9 |  | 358.5 |  | 761.2 |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001104659-26-058482:notes:22]
[same as prior period, unchanged from 0001104659-26-011932:notes:23]

[0001104659-26-058482:notes:23]
We adopted the provisions of ASU 2023-07 Segment Reporting for the year ended September 30, 2025. We are organized based on the products and services we offer, and we classify our business operations in three reportable segments for financial reporting purposes: Aerospace & Defense (A&D), Utility Solutions Group (USG) and RF Test & Measurement (Test). Corporate is not a reportable segment, but it is included for reconciliation purposes.

[0001104659-26-058482:notes:24]
The A&D segment’s operations consist of PTI, Crissair, Globe, Mayday, and Maritime. Previously, A&D also included VACCO Industries which was sold in July 2025 and is reported in discontinued operations. The companies within this segment primarily design and manufacture specialty filtration, fluid control and naval products, including hydraulic filter elements and fluid control devices used in aerospace and defense applications; custom designed filters for manned aircraft and submarines; products and systems to reduce vibration and/or acoustic signatures and otherwise reduce or obscure a vessel’s signature, power management and control equipment; sealing, surface control and hydrodynamic related applications to enhance U.S. and UK Navy maritime survivability; precision-tolerance machined components for the aerospace and defense industry; metal processing services; and miniature electro-explosive devices utilized in mission-critical defense and aerospace applications.

[0001104659-26-058482:notes:25]
[same as prior period, unchanged from 0001104659-26-011932:notes:26]

[0001104659-26-058482:notes:26]
The Test segment’s operations consist of ETS-Lindgren Inc., including its related subsidiaries, and MPE Limited (collectively, ETS-Lindgren). ETS-Lindgren is an industry leader in designing and manufacturing products and systems to measure and control RF energy. It serves the medical, health and safety, electronics, wireless communications, automotive and defense markets, supplying a broad range of turnkey systems, including RF test facilities and measurement systems, RF and magnetically shielded rooms and secure communication facilities, and providing the design, program management, installation and integration services required to successfully complete these types of facilities. It also supplies a broad range of components including RF absorptive materials, filters, antennas, field probes, test cells, proprietary measurement software and other test accessories required to perform a variety of tests and measurements, and offers a variety of services including calibration and product tests.

[0001104659-26-058482:notes:27]
[same as prior period, unchanged from 0001104659-26-011932:notes:28]

[0001104659-26-058482:notes:28]
[same as prior period, unchanged from 0001104659-26-011932:notes:29]

[0001104659-26-058482:notes:29]
[same as prior period, unchanged from 0001104659-26-011932:notes:30]

[0001104659-26-058482:notes:30]
| Three Months Ended March 31, 2026 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | Segment |  |
| (In thousands) | ​ ​ ​ | A&D | ​ ​ ​ | USG | ​ ​ ​ | Test | ​ ​ ​ | Total |  |
| Net Sales | ​ | $ | 150,310 |  | 93,529 |  | 65,502 | ​ |  | 309,341 | ​ |
| Cost of sales | ​ |  | 90,200 |  | 43,343 |  | 44,482 | ​ |  | ​ | ​ |
| SG&A expense | ​ |  | 16,976 |  | 24,871 |  | 10,235 | ​ |  | ​ | ​ |
| Amortization of intangible assets | ​ |  | 161 |  | 2,035 |  | 508 | ​ |  | ​ | ​ |
| Other expenses (income), net | ​ |  | 6 |  | 794 |  | 1,504 | ​ |  | ​ | ​ |
| Segment profit (loss) | ​ | $ | 42,967 |  | 22,486 |  | 8,773 | ​ |  | 74,226 | ​ |
| Depreciation and Amortization | ​ | $ | 3,465 |  | 4,126 |  | 1,465 | ​ |  | 9,056 | ​ |
| Segment Assets | ​ | $ | 402,119 |  | 280,735 |  | 196,281 | ​ |  | 879,135 | ​ |
| Capital Expenditures | ​ | $ | 5,542 |  | 1,062 |  | 618 | ​ |  | 7,222 | ​ |
| Reconciliation of segment profit to Earnings before Income Taxes | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Segment profit total from above | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | $ | 74,226 | ​ |
| Less: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Unallocated Corporate SG&A and Other expense (income), net | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | (10,247) | ​ |
| Unallocated amortization of intangible assets | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | (17,716) | ​ |
| Interest expense, net | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | (2,399) | ​ |
| Earnings before Income Taxes | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | $ | 43,864 | ​ |
| Reconciliation of segment depreciation and amortization to consolidated totals | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Segment Depreciation and Amortization | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | $ | 9,056 | ​ |
| Add: Corporate Depreciation and Amortization | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | 17,781 | ​ |
| Consolidated totals | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | $ | 26,837 | ​ |
| Reconciliation of segment assets to consolidated totals | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Segment Assets total | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | $ | 879,135 | ​ |
| Add: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Goodwill not allocated to segments | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | 761,181 | ​ |
| Acquired intangible assets not allocated to segments | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | 639,574 | (1) |
| Other unallocated amounts | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | 125,915 | ​ |
| Consolidated totals | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | $ | 2,405,805 | ​ |

[0001104659-26-058482:notes:31]
| (1) | Consists of customer relationships, trade names and other intangible assets. See Note 5 for details. |

[0001104659-26-058482:notes:32]
| Reconciliation of segment capital expenditures to consolidated totals | ​ ​ ​ | ​ | ​ |
| Segment Capital Expenditures | ​ | $ | 7,222 |
| Add: Corporate Capital Expenditures | ​ |  | 10 |
| Consolidated totals | ​ | $ | 7,232 |

[0001104659-26-058482:notes:33]
| Six Months Ended March 31, 2026 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | Segment |  |
| (In thousands) | ​ ​ ​ | A&D | ​ ​ ​ | USG | ​ ​ ​ | Test | ​ ​ ​ | Total |  |
| Net Sales | ​ | $ | 294,139 |  | 181,013 |  | 123,848 | ​ |  | 599,000 | ​ |
| Cost of sales | ​ |  | 180,271 |  | 83,273 |  | 84,221 | ​ |  | ​ | ​ |
| SG&A expense | ​ |  | 32,509 |  | 50,914 |  | 19,887 | ​ |  | ​ | ​ |
| Amortization of intangible assets | ​ |  | 316 |  | 4,078 |  | 1,022 | ​ |  | ​ | ​ |
| Other expenses (income), net | ​ |  | 89 |  | 733 |  | 1,903 | ​ |  | ​ | ​ |
| Segment profit (loss) | ​ | $ | 80,954 |  | 42,015 |  | 16,815 | ​ |  | 139,784 | ​ |
| Depreciation and Amortization | ​ | $ | 6,747 |  | 8,206 |  | 2,921 | ​ |  | 17,874 | ​ |
| Segment Assets | ​ | $ | 402,119 |  | 280,735 |  | 196,281 | ​ |  | 879,135 | ​ |
| Capital Expenditures | ​ | $ | 9,454 | ​ | 2,632 | ​ | 991 | ​ | ​ | 13,077 | ​ |
| Reconciliation of segment profit to Earnings before Income Taxes | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Segment profit total from above | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | $ | 139,784 | ​ |
| Less: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Unallocated Corporate SG&A and Other expense (income), net | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | (19,836) | ​ |
| Unallocated amortization of intangible assets | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | (35,327) | ​ |
| Interest expense, net | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | (5,279) | ​ |
| Earnings before Income Taxes | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | $ | 79,342 | ​ |
| Reconciliation of segment depreciation and amortization to consolidated totals | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Segment Depreciation and Amortization | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | $ | 17,874 | ​ |
| Add: Corporate Depreciation and Amortization | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | 35,456 | ​ |
| Consolidated totals | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | $ | 53,330 | ​ |
| Reconciliation of segment assets to consolidated totals | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Segment Assets total | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | $ | 879,135 | ​ |
| Add: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Goodwill not allocated to segments | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | 761,181 | ​ |
| Acquired intangible assets not allocated to segments | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | 639,574 | (1) |
| Other unallocated amounts | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | 125,915 | ​ |
| Consolidated totals | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | $ | 2,405,805 | ​ |

[0001104659-26-058482:notes:34]
| Reconciliation of segment capital expenditures to consolidated totals | ​ ​ ​ | ​ | ​ |
| Segment Capital Expenditures | ​ | $ | 13,077 |
| Add: Corporate Capital Expenditures | ​ |  | 57 |
| Consolidated totals | ​ | $ | 13,134 |

[0001104659-26-058482:notes:35]
| Three Months Ended March 31, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | Segment |
| (In thousands) | ​ ​ ​ | A&D | ​ ​ ​ | USG | ​ ​ ​ | Test | ​ ​ ​ | Total |
| Net Sales | ​ | $ | 89,627 |  | 90,767 |  | 51,383 | ​ |  | 231,777 |
| Cost of sales | ​ |  | 54,603 |  | 43,422 |  | 34,609 | ​ |  | ​ |
| SG&A expense | ​ |  | 10,594 |  | 24,343 |  | 9,699 | ​ |  | ​ |
| Amortization of intangible assets | ​ |  | 328 |  | 2,018 |  | 454 | ​ |  | ​ |
| Other expenses (income), net | ​ |  | (115) |  | 205 |  | 252 | ​ |  | ​ |
| Segment profit (loss) | ​ | $ | 24,217 |  | 20,779 |  | 6,369 | ​ |  | 51,365 |
| Depreciation and Amortization | ​ | $ | 2,836 |  | 3,864 |  | 1,354 | ​ |  | 8,054 |
| Segment Assets | ​ | $ | 283,061 |  | 280,884 |  | 173,481 | ​ |  | 737,426 |
| Capital Expenditures | ​ | $ | 3,489 |  | 3,596 |  | 1,635 | ​ |  | 8,720 |
| Reconciliation of segment profit to Earnings before Income Taxes | ​ |  | ​ |  | ​ |  | ​ | ​ |  | ​ |
| Segment profit total from above | ​ | ​ | ​ |  | ​ |  | ​ | ​ | $ | 51,365 |
| Less: | ​ | ​ | ​ |  | ​ |  | ​ | ​ |  | ​ |
| Unallocated Corporate SG&A and Other expense (income), net | ​ | ​ | ​ |  | ​ |  | ​ | ​ |  | (9,561) |
| Unallocated amortization of intangible assets | ​ | ​ | ​ |  | ​ |  | ​ | ​ |  | (5,189) |
| Interest expense, net | ​ | ​ | ​ |  | ​ |  | ​ | ​ |  | (2,195) |
| Earnings before Income Taxes | ​ | ​ | ​ |  | ​ |  | ​ | ​ | $ | 34,420 |
| Reconciliation of segment depreciation and amortization to consolidated totals | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Segment Depreciation and Amortization | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | $ | 8,054 |
| Add: Corporate Depreciation and Amortization | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | 5,016 |
| Consolidated totals | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | $ | 13,070 |
| Reconciliation of segment assets to consolidated totals | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |
| Segment Assets total | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | $ | 737,426 |
| Add: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |
| Goodwill not allocated to segments | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | 526,258 |
| Acquired intangible assets not allocated to segments | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | 348,607 |
| Other unallocated amounts | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | 83,871 |
| Consolidated totals | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | $ | 1,696,162 |

[0001104659-26-058482:notes:36]
| Reconciliation of segment capital expenditures to consolidated totals | ​ ​ ​ | ​ | ​ |
| Segment Capital Expenditures | ​ | $ | 8,720 |
| Add: Corporate Capital Expenditures | ​ |  | 852 |
| Consolidated totals | ​ | $ | 9,572 |

[0001104659-26-058482:notes:37]
| Six Months Ended March 31, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | Segment |
| (In thousands) | ​ ​ ​ | A&D | ​ ​ ​ | USG | ​ ​ ​ | Test | ​ ​ ​ | Total |
| Net Sales | ​ | $ | 171,495 |  | 177,427 |  | 97,448 | ​ |  | 446,370 |
| Cost of sales | ​ |  | 108,116 |  | 82,760 |  | 65,972 | ​ |  | ​ |
| SG&A expense | ​ |  | 21,462 |  | 50,259 |  | 18,749 | ​ |  | ​ |
| Amortization of intangible assets | ​ |  | 541 |  | 4,090 |  | 1,076 | ​ |  | ​ |
| Other expenses (income), net | ​ |  | (293) |  | (950) |  | 860 | ​ |  | ​ |
| Segment profit (loss) | ​ | $ | 41,669 |  | 41,268 |  | 10,791 | ​ |  | 93,728 |
| Depreciation and Amortization | ​ | $ | 5,486 |  | 7,752 |  | 2,729 | ​ |  | 15,967 |
| Segment Assets | ​ | $ | 283,061 |  | 280,884 |  | 173,481 | ​ |  | 737,426 |
| Capital Expenditures | ​ | $ | 5,922 |  | 5,585 |  | 2,505 | ​ |  | 14,012 |
| Reconciliation of segment profit to Earnings before Income Taxes | ​ |  | ​ |  | ​ |  | ​ | ​ |  | ​ |
| Segment profit total from above | ​ | ​ | ​ |  | ​ |  | ​ | ​ | $ | 93,728 |
| Less: | ​ | ​ | ​ |  | ​ |  | ​ | ​ |  | ​ |
| Unallocated Corporate SG&A and Other expense (income), net | ​ | ​ | ​ |  | ​ |  | ​ | ​ |  | (18,784) |
| Unallocated amortization of intangible assets | ​ | ​ | ​ |  | ​ |  | ​ | ​ |  | (10,275) |
| Interest expense, net | ​ | ​ | ​ |  | ​ |  | ​ | ​ |  | (4,452) |
| Earnings before Income Taxes | ​ | ​ | ​ |  | ​ |  | ​ | ​ | $ | 60,217 |
| Reconciliation of segment depreciation and amortization to consolidated totals | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Segment Depreciation and Amortization | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | $ | 15,967 |
| Add: Corporate Depreciation and Amortization | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | 10,074 |
| Consolidated totals | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | $ | 26,041 |
| Reconciliation of segment assets to consolidated totals | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |
| Segment Assets total | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | $ | 737,426 |
| Add: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |
| Goodwill not allocated to segments | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | 526,258 |
| Acquired intangible assets not allocated to segments | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | 348,607 |
| Other unallocated amounts | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | 83,871 |
| Consolidated totals | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | $ | 1,696,162 |

[0001104659-26-058482:notes:38]
| Reconciliation of segment capital expenditures to consolidated totals | ​ ​ ​ | ​ | ​ |
| Segment Capital Expenditures | ​ | $ | 14,012 |
| Add: Corporate Capital Expenditures | ​ |  | 852 |
| Consolidated totals | ​ | $ | 14,864 |

[0001104659-26-058482:notes:39]
[same as prior period, unchanged from 0001104659-26-011932:notes:33]

[0001104659-26-058482:notes:40]
[same as prior period, unchanged from 0001104659-26-011932:notes:34]

[0001104659-26-058482:notes:41]
[same as prior period, unchanged from 0001104659-26-011932:notes:35]


## us-gaap:DebtDisclosureTextBlock

[0001104659-26-058482:notes:42]
7.    DEBT

[0001104659-26-058482:notes:43]
The Company’s debt is summarized as follows:

[0001104659-26-058482:notes:44]
| ​ | ​ ​ ​ | March 31, | ​ | September 30, |
| (In thousands) | ​ ​ ​ | 2026 | ​ ​ ​ | 2025 |
| Revolving credit facility | ​ | $ | 45,000 | ​ | 25,000 |
| Incremental facility (Term loan A) | ​ | ​ | 100,000 | ​ | 161,000 |
| Total borrowings | ​ | $ | 145,000 | ​ | 186,000 |
| Current portion of long-term debt | ​ | ​ | (20,000) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 125,000 | ​ | 166,000 |

[0001104659-26-058482:notes:45]
The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of seven banks led by JP Morgan Chase Bank, N.A., as administrative agent, Bank of America, N.A., as syndication agent, and Commerce Bank and TD Bank, N.A. as co-documentation agents. The Credit Facility matures August 30, 2028, with balance due by this date.

[0001104659-26-058482:notes:46]
On August 5, 2024, the Company and certain of its subsidiaries entered into Amendment No. 1 to the Credit Facility which, among other things, (i) implements a senior incremental delayed draw term loan credit facility in an aggregate principal amount of up to $375 million (the “Incremental Facility”), and (ii) permits the direct or indirect acquisition by the Registrant or certain of its subsidiaries of all the issued and outstanding shares of PMES I Limited, Measurement Systems, Inc., EMS Development Corporation, and DNE Technologies, Inc. (the “Maritime Acquisition”), pursuant to and in accordance with the terms and conditions of that certain Sale and Purchase Agreement, dated July 8, 2024. During the third quarter of 2025, the proceeds of the loans drawn under the Incremental Facility were applied to pay a portion of the cash consideration for the Maritime Acquisition and other customary fees, premiums, expenses and costs incurred in connection with the acquisition. The Incremental Facility matures August 30, 2028, with balance due by this date.

[0001104659-26-058482:notes:47]
At March 31, 2026, the Company had approximately $440 million available to borrow under the Credit Facility, plus the $250 million increase option subject to the lenders’ consent, in addition to $92.3 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of March 31, 2026, as the Company intends to repay this amount as obligated by the repayment terms of the Incremental Facility within the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $14.5 million at March 31, 2026.

[0001104659-26-058482:notes:48]
Interest on borrowings under the Credit Facility and the Incremental Facility is calculated at a spread ranging from 0.25% to 2.25% over either an Adjusted Term SOFR Rate, Adjusted EURIBOR Rate, Adjusted CDOR Rate, Alternate Base Rate or Daily Simple RFR, at the Company’s election. The Credit Facility also requires a facility fee ranging from 12.5 to 25 basis points per annum. The interest rate spreads and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio. The weighted average interest rates under the Credit Facility were 5.06% and 5.28% for the three and six-month periods ending March 31, 2026, respectively, and 5.77% and 5.95% for the three- and six-month periods ending March 31, 2025. The weighted average interest rate under the Incremental Facility was 5.27% and 5.44% for the three and six-month periods ending March 31, 2026. As of March 31, 2026, the Company was in compliance with all covenants.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001104659-26-058482:notes:49]
[same as prior period, unchanged from 0001104659-26-011932:notes:43]

[0001104659-26-058482:notes:50]
The second quarter 2026 effective income tax rate from continuing operations was 23.5% compared to 23.3% in the second quarter of 2025. The effective income tax rate from continuing operations in the first six months of 2026 was 21.5% compared to 22.5% for the first six months of 2025. Income tax expense in the first six months of 2026 was favorably impacted by additional tax benefits related to the vesting of share-based compensation awards.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001104659-26-058482:notes:51]
[same as prior period, unchanged from 0001104659-26-011932:notes:45]

[0001104659-26-058482:notes:52]
The change in shareholders’ equity for the first three and six months of 2026 and 2025 is shown below (in thousands):

[0001104659-26-058482:notes:53]
| ​ | ​ | Three Months Ended March 31, | ​ | Six Months Ended March 31, |
| ​ | ​ ​ ​ | 2026 | ​ ​ ​ | 2025 | ​ ​ ​ | 2026 | ​ ​ ​ | 2025 |
| Common stock | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | $ | 309 | ​ | 309 | ​ | 309 | ​ | 308 |
| Stock plans | ​ | ​ | 1 | ​ | — | ​ | 1 | ​ | 1 |
| Ending balance | ​ | $ | 310 | ​ | 309 | ​ | 310 | ​ | 309 |
| Additional paid-in-capital | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | $ | 308,929 | ​ | 308,143 | ​ | 316,194 | ​ | 311,942 |
| Stock plans | ​ | ​ | 3,375 | ​ | 3,295 | ​ | (3,890) | ​ | (504) |
| Ending balance | ​ | $ | 312,304 | ​ | 311,438 | ​ | 312,304 | ​ | 311,438 |
| Retained earnings | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | $ | 1,400,530 | ​ | 1,104,359 | ​ | 1,373,911 | ​ | 1,082,950 |
| Net earnings common stockholders | ​ | ​ | 34,733 | ​ | 31,033 | ​ | 63,424 | ​ | 54,506 |
| Dividends paid | ​ | ​ | (2,071) | ​ | (2,066) | ​ | (4,143) | ​ | (4,130) |
| Ending balance | ​ | $ | 1,433,192 | ​ | 1,133,326 | ​ | 1,433,192 | ​ | 1,133,326 |
| Accumulated other comprehensive income (loss) | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | $ | (1,829) | ​ | (28,803) | ​ | (2,468) | ​ | (10,775) |
| Foreign currency translation | ​ | ​ | (11,482) | ​ | 8,133 | ​ | (10,843) | ​ | (9,895) |
| Ending balance | ​ | $ | (13,311) | ​ | (20,670) | ​ | (13,311) | ​ | (20,670) |
| Treasury stock | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | $ | (147,075) | ​ | (147,075) | ​ | (147,075) | ​ | (147,075) |
| Share repurchases | ​ | ​ | — | ​ | — | ​ | — | ​ | — |
| Ending balance | ​ | $ | (147,075) | ​ | (147,075) | ​ | (147,075) | ​ | (147,075) |
| Total equity | ​ | $ | 1,585,420 | ​ | 1,277,328 | ​ | 1,585,420 | ​ | 1,277,328 |


## us-gaap:FairValueDisclosuresTextBlock

[0001104659-26-058482:notes:54]
[same as prior period, unchanged from 0001104659-26-011932:notes:48]

[0001104659-26-058482:notes:55]
[same as prior period, unchanged from 0001104659-26-011932:notes:49]

[0001104659-26-058482:notes:56]
[same as prior period, unchanged from 0001104659-26-011932:notes:50]

[0001104659-26-058482:notes:57]
[same as prior period, unchanged from 0001104659-26-011932:notes:51]

[0001104659-26-058482:notes:58]
[same as prior period, unchanged from 0001104659-26-011932:notes:52]

[0001104659-26-058482:notes:59]
[same as prior period, unchanged from 0001104659-26-011932:notes:53]

[0001104659-26-058482:notes:60]
The Company has estimated the fair value of its financial instruments as of March 31, 2026 and September 30, 2025 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001104659-26-058482:notes:61]
[same as prior period, unchanged from 0001104659-26-011932:notes:55]

[0001104659-26-058482:notes:62]
[same as prior period, unchanged from 0001104659-26-011932:notes:56]

[0001104659-26-058482:notes:63]
[same as prior period, unchanged from 0001104659-26-011932:notes:57]

[0001104659-26-058482:notes:64]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however, they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during the three and six-month periods ended March 31, 2026.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001104659-26-058482:notes:65]
[same as prior period, unchanged from 0001104659-26-011932:notes:59]

[0001104659-26-058482:notes:66]
[same as prior period, unchanged from 0001104659-26-011932:notes:60]

[0001104659-26-058482:notes:67]
The tables below present our revenues from continuing operations by customer type, geographic location, and revenue recognition method for the three and six-month periods ending March 31, 2026, as we believe this presentation best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors.

[0001104659-26-058482:notes:68]
| Three months ended March 31, 2026 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) | ​ ​ ​ | A&D | ​ ​ ​ | USG | ​ ​ ​ | Test | ​ ​ ​ | Total |
| Customer type: |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |
| Commercial | ​ | $ | 55,937 | ​ | ​ | 89,982 | ​ | ​ | 55,229 | ​ | ​ | 201,148 |
| Government | ​ | ​ | 94,373 | ​ | ​ | 3,547 | ​ | ​ | 10,273 | ​ | ​ | 108,193 |
| Total revenues | ​ | $ | 150,310 | ​ | ​ | 93,529 | ​ | ​ | 65,502 | ​ | ​ | 309,341 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 99,609 | ​ | ​ | 58,873 | ​ | ​ | 40,584 | ​ | ​ | 199,066 |
| International | ​ | ​ | 50,701 | ​ | ​ | 34,656 | ​ | ​ | 24,918 | ​ | ​ | 110,275 |
| Total revenues | ​ | $ | 150,310 | ​ | ​ | 93,529 | ​ | ​ | 65,502 | ​ | ​ | 309,341 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 69,877 | ​ | ​ | 75,227 | ​ | ​ | 15,188 | ​ | ​ | 160,292 |
| Over time | ​ | ​ | 80,433 | ​ | ​ | 18,302 | ​ | ​ | 50,314 | ​ | ​ | 149,049 |
| Total revenues | ​ | $ | 150,310 | ​ | ​ | 93,529 | ​ | ​ | 65,502 | ​ | ​ | 309,341 |

[0001104659-26-058482:notes:69]
| Six months ended March 31, 2026 | ​ | ​ | ​ | ​ ​ ​ | ​ | ​ | ​ ​ ​ | ​ | ​ | ​ ​ ​ | ​ |
| (In thousands) | ​ ​ ​ | A&D | ​ ​ ​ | USG | ​ ​ ​ | Test | ​ ​ ​ | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 101,733 | ​ | ​ | 175,721 | ​ | ​ | 101,546 | ​ | ​ | 379,000 |
| Government | ​ | ​ | 192,406 | ​ | ​ | 5,292 | ​ | ​ | 22,302 | ​ | ​ | 220,000 |
| Total revenues | ​ | $ | 294,139 | ​ | ​ | 181,013 | ​ | ​ | 123,848 | ​ | ​ | 599,000 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 192,396 | ​ | ​ | 119,597 | ​ | ​ | 77,066 | ​ | ​ | 389,059 |
| International | ​ | ​ | 101,743 | ​ | ​ | 61,416 | ​ | ​ | 46,782 | ​ | ​ | 209,941 |
| Total revenues | ​ | $ | 294,139 | ​ | ​ | 181,013 | ​ | ​ | 123,848 | ​ | ​ | 599,000 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 136,412 | ​ | ​ | 143,515 | ​ | ​ | 27,304 | ​ | ​ | 307,231 |
| Over time | ​ | ​ | 157,727 | ​ | ​ | 37,498 | ​ | ​ | 96,544 | ​ | ​ | 291,769 |
| Total revenues | ​ | $ | 294,139 | ​ | ​ | 181,013 | ​ | ​ | 123,848 | ​ | ​ | 599,000 |

[0001104659-26-058482:notes:70]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2025 are presented in the tables below from continuing operations.

[0001104659-26-058482:notes:71]
| Three months ended March 31, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) | ​ ​ ​ | A&D | ​ ​ ​ | USG | ​ ​ ​ | Test | ​ ​ ​ | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 48,702 | ​ | ​ | 89,649 | ​ | ​ | 37,891 | ​ | ​ | 176,242 |
| Government | ​ |  | 40,925 | ​ | ​ | 1,118 | ​ | ​ | 13,492 | ​ | ​ | 55,535 |
| Total revenues | ​ | $ | 89,627 | ​ | ​ | 90,767 | ​ | ​ | 51,383 | ​ | ​ | 231,777 |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 66,612 | ​ | ​ | 54,944 | ​ | ​ | 32,267 | ​ | ​ | 153,823 |
| International | ​ |  | 23,015 | ​ | ​ | 35,823 | ​ | ​ | 19,116 | ​ | ​ | 77,954 |
| Total revenues | ​ | $ | 89,627 | ​ | ​ | 90,767 | ​ | ​ | 51,383 | ​ | ​ | 231,777 |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 52,364 | ​ | ​ | 73,002 | ​ | ​ | 11,607 | ​ | ​ | 136,973 |
| Over time | ​ |  | 37,263 | ​ | ​ | 17,765 | ​ | ​ | 39,776 | ​ | ​ | 94,804 |
| Total revenues | ​ | $ | 89,627 | ​ | ​ | 90,767 | ​ | ​ | 51,383 | ​ | ​ | 231,777 |

[0001104659-26-058482:notes:72]
| Six months ended March 31, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) | ​ ​ ​ | A&D | ​ ​ ​ | USG | ​ ​ ​ | Test | ​ ​ ​ | Total |
| Customer type: |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |
| Commercial | ​ | $ | 94,458 | ​ | ​ | 173,928 | ​ | ​ | 74,240 | ​ | ​ | 342,626 |
| Government | ​ |  | 77,037 | ​ | ​ | 3,499 | ​ | ​ | 23,208 | ​ | ​ | 103,744 |
| Total revenues | ​ | $ | 171,495 | ​ | ​ | 177,427 | ​ | ​ | 97,448 | ​ | ​ | 446,370 |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 131,926 | ​ | ​ | 114,860 | ​ | ​ | 60,897 | ​ | ​ | 307,683 |
| International | ​ |  | 39,569 | ​ | ​ | 62,567 | ​ | ​ | 36,551 | ​ | ​ | 138,687 |
| Total revenues | ​ | $ | 171,495 | ​ | ​ | 177,427 | ​ | ​ | 97,448 | ​ | ​ | 446,370 |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 99,359 | ​ | ​ | 142,280 | ​ | ​ | 21,398 | ​ | ​ | 263,037 |
| Over time | ​ |  | 72,136 | ​ | ​ | 35,147 | ​ | ​ | 76,050 | ​ | ​ | 183,333 |
| Total revenues | ​ | $ | 171,495 | ​ | ​ | 177,427 | ​ | ​ | 97,448 | ​ | ​ | 446,370 |

[0001104659-26-058482:notes:73]
[same as prior period, unchanged from 0001104659-26-011932:notes:65]

[0001104659-26-058482:notes:74]
[same as prior period, unchanged from 0001104659-26-011932:notes:66]

[0001104659-26-058482:notes:75]
[same as prior period, unchanged from 0001104659-26-011932:notes:67]

[0001104659-26-058482:notes:76]
Remaining Unsatisfied Performance Obligations

[0001104659-26-058482:notes:77]
Remaining unsatisfied performance obligations, as defined by ASC 606 and align with our backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At March 31, 2026, the Company had $1,470.0 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 55% in the next twelve months.

[0001104659-26-058482:notes:78]
[same as prior period, unchanged from 0001104659-26-011932:notes:70]

[0001104659-26-058482:notes:79]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At March 31, 2026, contract assets, contract liabilities and accounts receivable totaled $103.5 million, $275.6 million and $256.8 million, respectively. During the first six months of 2026, the Company recognized approximately $56 million in revenues that were included in the contract liabilities balance at September 30, 2025. At September 30, 2025, contract assets, contract liabilities and accounts receivable from continuing operations totaled $90.7 million, $224.7 million and $253.6 million, respectively.


## ese:OperatingAndFinancingLeasesOfLesseeDisclosureTextBlock

[0001104659-26-058482:notes:80]
[same as prior period, unchanged from 0001104659-26-011932:notes:72]

[0001104659-26-058482:notes:81]
[same as prior period, unchanged from 0001104659-26-011932:notes:73]

[0001104659-26-058482:notes:82]
[same as prior period, unchanged from 0001104659-26-011932:notes:74]

[0001104659-26-058482:notes:83]
In addition to the base rent, real estate leases typically contain provisions for common-area maintenance and other similar services, which are considered non-lease components for accounting purposes. Non-lease components are excluded from our ROU assets and lease liabilities and expensed as incurred.

[0001104659-26-058482:notes:84]
[same as prior period, unchanged from 0001104659-26-011932:notes:76]

[0001104659-26-058482:notes:85]
[same as prior period, unchanged from 0001104659-26-011932:notes:77]

[0001104659-26-058482:notes:86]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended |
| ​ | ​ | March 31, | ​ | March 31, |
| (Dollars in thousands) | ​ ​ ​ | 2026 | ​ ​ ​ | 2025 |
| Finance lease cost | ​ | ​ | ​ | ​ | ​ | ​ |
| Amortization of right-of-use assets | ​ | $ | 372 | ​ | ​ | 372 |
| Interest on lease liabilities | ​ | ​ | 188 | ​ | ​ | 202 |
| Operating lease cost | ​ | ​ | 2,204 | ​ | ​ | 1,731 |
| Total lease costs | ​ | $ | 2,764 | ​ | ​ | 2,305 |

[0001104659-26-058482:notes:87]
| ​ | ​ | Six Months Ended | ​ | Six Months Ended |
| ​ | ​ | March 31, | ​ | March 31, |
| (Dollars in thousands) | ​ ​ ​ | 2026 | ​ ​ ​ | 2025 |
| Finance lease cost | ​ | ​ | ​ | ​ | ​ | ​ |
| Amortization of right-of-use assets | ​ | $ | 744 | ​ | ​ | 744 |
| Interest on lease liabilities | ​ |  | 379 | ​ | ​ | 408 |
| Operating lease cost | ​ |  | 4,432 | ​ | ​ | 3,461 |
| Total lease costs | ​ | $ | 5,555 | ​ | ​ | 4,613 |

[0001104659-26-058482:notes:88]
[same as prior period, unchanged from 0001104659-26-011932:notes:79]

[0001104659-26-058482:notes:89]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended |
| ​ | ​ | March 31, | ​ | March 31, |
| (Dollars in thousands) | ​ ​ ​ | 2026 | ​ ​ ​ | 2025 |
| Cash paid for amounts included in the measurement of lease liabilities | ​ | ​ | ​ | ​ | ​ | ​ |
| Operating cash flows from operating leases | ​ | $ | 2,121 | ​ | ​ | 1,668 |
| Operating cash flows from finance leases | ​ | $ | 188 | ​ | ​ | 202 |
| Financing cash flows from finance leases | ​ | $ | 386 | ​ | ​ | 355 |
| Right-of-use assets obtained in exchange for operating lease liabilities | ​ | $ | 4,144 | ​ | ​ | 1,040 |

[0001104659-26-058482:notes:90]
| ​ | ​ | Six Months Ended | ​ | Six Months Ended |
| ​ | ​ | March 31, | ​ | March 31, |
| (Dollars in thousands) | ​ ​ ​ | 2026 | ​ ​ ​ | 2025 |
| Cash paid for amounts included in the measurement of lease liabilities | ​ | ​ | ​ | ​ | ​ | ​ |
| Operating cash flows from operating leases | ​ | $ | 4,117 | ​ | ​ | 3,313 |
| Operating cash flows from finance leases | ​ | $ | 379 | ​ |  | 408 |
| Financing cash flows from finance leases | ​ | $ | 767 | ​ |  | 706 |
| Right-of-use assets obtained in exchange for operating lease liabilities | ​ | $ | 4,609 | ​ | ​ | 3,972 |

[0001104659-26-058482:notes:91]
| ​ | ​ | March 31, | ​ ​ ​ | March 31, | ​ |
| ​ | ​ ​ ​ | 2026 | ​ | 2025 | ​ |
| Weighted-average remaining lease term | ​ | ​ | ​ | ​ | ​ |
| Operating leases |  | 9.1 | years | 10.2 | years |
| Finance leases |  | 9.3 | years | 10.0 | years |
| Weighted-average discount rate |  | ​ |  | ​ |  |
| Operating leases |  | 4.85 | % | 4.68 | % |
| Finance leases |  | 4.77 | % | 4.72 | % |

[0001104659-26-058482:notes:92]
The following is a reconciliation of future undiscounted cash flows to the operating and finance lease liabilities, and the related ROU assets, presented on our condensed Consolidated Balance Sheet on March 31, 2026:

[0001104659-26-058482:notes:93]
| (Dollars in thousands) | ​ | Operating | ​ | Finance |
| Years Ending September 30: | ​ ​ ​ | Leases | ​ ​ ​ | Leases |
| 2026 (excluding the six months ended March 31, 2026) | ​ | $ | 4,240 | ​ | 1,150 |
| 2027 | ​ | ​ | 8,306 | ​ | 2,357 |
| 2028 | ​ | ​ | 8,132 | ​ | 2,417 |
| 2029 | ​ | ​ | 6,647 | ​ | 2,478 |
| 2030 and thereafter | ​ | ​ | 37,651 | ​ | 11,575 |
| Total minimum lease payments | ​ | ​ | 64,976 | ​ | 19,977 |
| Less: amounts representing interest | ​ | ​ | 13,092 | ​ | 4,191 |
| Present value of net minimum lease payments | ​ | $ | 51,884 | ​ | 15,786 |
| Less: current portion of lease obligations | ​ | ​ | 6,177 | ​ | 1,616 |
| Non-current portion of lease obligations | ​ | ​ | 45,707 | ​ | 14,170 |
| ROU assets | ​ | $ | 48,977 | ​ | 11,450 |

[0001104659-26-058482:notes:94]
Operating lease liabilities are included in the condensed Consolidated Balance Sheet in accrued other expenses (current portion) and as a caption on the Consolidated Balance Sheet (long-term portion). Finance lease liabilities are included on the Consolidated Balance Sheet in accrued other expenses (current portion) and other liabilities (long-term portion). Operating lease ROU assets are included as a caption on the Consolidated Balance Sheet and finance lease ROU assets are included in property, plant and equipment on the Consolidated Balance sheet.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001104659-26-058482:notes:95]
13.  NEW ACCOUNTING PRONOUNCEMENTS

[0001104659-26-058482:notes:96]
In November 2024, the FASB issued ASU 2024-03, “Disaggregation of Income Statement Expenses,” which requires disaggregated disclosure of income statement expenses for public business entities. The ASU does not change the expense captions an entity presents on the face of the income statement, rather, it requires disaggregation of certain expense captions into specified categories in disclosures within the footnotes to the financial statements. This ASU will be effective for fiscal years beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027. Other than additional disclosure, we do not expect a change to our consolidated statements of operations, financial position, or cash flows.

[0001104659-26-058482:notes:97]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures,” which provides qualitative and quantitative updates to the rate reconciliation and income taxes paid disclosures. This ASU will be effective for fiscal years beginning after December 15, 2024. Other than additional disclosure, we do not expect a change to our consolidated statements of operations, financial position, or cash flows.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001104659-26-058482:notes:98]
14.  RELATED PARTIES

[0001104659-26-058482:notes:99]
Two of the Company’s directors are officers at two customers of the Company’s Doble subsidiary. Doble sells products, leases equipment and provides testing services in the ordinary course of Doble’s business. The total amount of these sales to these two customers was approximately $1.0 million and $2.3 million for the three- and six-month periods ending March 31, 2026. All transactions between Doble and the two customers are intended to be and have been consistent with Doble’s normal commercial terms offered to its customers, and the Company’s Board of Directors has determined that the relationships between the Company and the customers are not material and did not impair the Company’s or the directors’ independence.


## us-gaap:SubsequentEventsTextBlock

[0001104659-26-058482:notes:100]
15.  SUBSEQUENT EVENT

[0001104659-26-058482:notes:101]
On April 15, 2026, the Company signed a definitive agreement to acquire the Megger Group Limited (Megger) business of TBG AG. Megger is a global provider of testing, monitoring, and data-driven solutions for utilities and critical electric infrastructure, including industrial, transportation, data center and renewable end markets. Under the terms of the agreement, ESCO will acquire Megger for total consideration of approximately $2.35 billion, consisting of $0.9 billion in cash and ESCO equity valued at approximately $1.4 billion. The cash portion will be funded through existing cash on hand and incremental debt, with committed financing in place. The Company expects to complete the acquisition in the first quarter of fiscal 2027. Megger will become part of the Company’s Utility Solution Group (USG) segment. See further discussion of the transaction and financing arrangements in the Company’s Form 8-K’s filed April 15, 2026 and April 16, 2026.
