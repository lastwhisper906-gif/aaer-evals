# ESE MD&A — 0001104659-26-058482


## mdna

[0001104659-26-058482:mdna:1]
[same as prior period, unchanged from 0001104659-26-011932:mdna:1]

[0001104659-26-058482:mdna:2]
[same as prior period, unchanged from 0001104659-26-011932:mdna:2]

[0001104659-26-058482:mdna:3]
The following discussion refers to the Company’s results from continuing operations, except where noted. References to the second quarters of 2026 and 2025 represent the three-month periods ended March 31, 2026 and 2025, respectively.

[0001104659-26-058482:mdna:4]
[same as prior period, unchanged from 0001104659-26-011932:mdna:4]

[0001104659-26-058482:mdna:5]
In the second quarter of 2026, sales, net earnings and diluted earnings per share were $309.3 million, $33.6 million and $1.29 per share, respectively, compared to $231.8 million, $26.4 million and $1.02 per share, respectively, in the second quarter of 2025. In the first six months of 2026, sales, net earnings and diluted earnings per share were $599.0 million, $62.2 million and $2.40 per share, respectively, compared to $446.4 million, $46.7 million and $1.81 per share, respectively, in the first six months of 2025.

[0001104659-26-058482:mdna:6]
[same as prior period, unchanged from 0001104659-26-011932:mdna:6]

[0001104659-26-058482:mdna:7]
In the second quarter of 2026, net sales of $309.3 million were $77.5 million, or 33.4%, higher than the $231.8 million in the second quarter of 2025. In the first six months of 2026, net sales of $599.0 million were $152.6 million, or 34.2%, higher than the $446.4 million in the first six months of 2025. The increase in net sales in the second quarter of 2026 as compared to the second quarter of 2025 was due to a $60.7 million increase in the A&D segment, a $14.1 million increase in the Test segment and a $2.7 million increase in the USG segment. The increase in net sales in the first six months of 2026 as compared to the first six months of 2025 was due to a $122.6 million increase in the A&D segment, a $26.4 million increase in the Test segment and a $3.6 million increase in the USG segment.

[0001104659-26-058482:mdna:8]
[same as prior period, unchanged from 0001104659-26-011932:mdna:8]

[0001104659-26-058482:mdna:9]
In the second quarter of 2026, net sales of $150.3 million were $60.7 million, or 67.7%, higher than the $89.6 million in the second quarter of 2025. In the first six months of 2026, net sales of $294.1 million were $122.6 million, or 71.5%, higher than the $171.5 million in the first six months of 2025. The sales increase in the second quarter of 2026 compared to the second quarter of 2025 was mainly due to a $44.3 million increase in navy revenues and a $14.0 million increase in aerospace revenues (defense and commercial). Maritime contributed $47.8 million of revenue growth in the second quarter of 2026. The sales increase in the first six months of 2026 compared to the first six months of 2025 was mainly due to a $88.5 million increase in navy revenues, a $29.8 million increase in aerospace revenues (defense and commercial) and a $3.3 million increase in industrial shipments. Maritime contributed $98.4 million of revenue growth in the first six months of 2026.

[0001104659-26-058482:mdna:10]
[same as prior period, unchanged from 0001104659-26-011932:mdna:10]

[0001104659-26-058482:mdna:11]
In the second quarter of 2026, net sales of $93.5 million were $2.7 million, or 3.0%, higher than the $90.8 million in the second quarter of 2025. In the first six months of 2026, net sales of $181.0 million were $3.6 million, or 2.0%, higher than the $177.4 million in the first six months of 2025. The increase in the second quarter of 2026 compared to the second quarter of 2025 was due to an $8.4 million increase in net sales at Doble driven by higher sales of protection testing, offline products and services, partially offset by a $5.7 million decrease in net sales at NRG driven by lower shipments of solar and wind products due to weakness in the renewables market. The increase in the first six months of 2026 compared to the corresponding period of 2025 was due to a $12.5 million increase in net sales at Doble driven by higher sales of condition monitoring and offline products, partially offset by an $8.9 million decrease in net sales at NRG for the reasons mentioned above.

[0001104659-26-058482:mdna:12]
[same as prior period, unchanged from 0001104659-26-011932:mdna:12]

[0001104659-26-058482:mdna:13]
In the second quarter of 2026, net sales of $65.5 million were $14.1 million, or 27.4%, higher than the $51.4 million in the second quarter of 2025. In the first six months of 2026, net sales of $123.8 million were $26.4 million, or 27.1%, higher than the $97.4 million in the first six months of 2025. The increase in the second quarter of 2026 as compared to the second quarter of 2025 was due to a $10.1 million increase in sales from the segment’s U.S. operations, a $2.8 million increase in sales from the segment’s Asian operations, and a $1.2 million increase from the segment’s European operations; due to higher Test and Measurement and filters volumes. The increase in the first six months of 2026 compared to the first six months of 2025 was due to a $20.2 million increase in sales from the segment’s U.S. operations, a $4.2 million increase from the segment’s European operations and a $2.0 million increase in sales from the segment’s Asian operations for the reasons mentioned above.

[0001104659-26-058482:mdna:14]
[same as prior period, unchanged from 0001104659-26-011932:mdna:14]

[0001104659-26-058482:mdna:15]
Backlog was $1,470.0 million at March 31, 2026 compared with $1,133.6 million at September 30, 2025. The Company received new orders totaling $378.2 million in the second quarter of 2026 compared to $265.7 million in the second quarter of 2025. Of the new orders received in the second quarter of 2026, $183.8 million related to A&D products, $101.3 million related to USG products, and $93.1 million related to Test products. Of the new orders received in the second quarter of 2025, $96.5 million related to A&D products, $92.2 million related to USG products, and $77.0 million related to Test products.

[0001104659-26-058482:mdna:16]
The Company received new orders totaling $935.4 million in the first six months of 2026 compared to $494.9 million in the first six months of 2025. Of the new orders received in the first six months of 2026, $566.1 million related to A&D products, $200.1 million related to USG products, and $169.2 million related to Test products. Of the new orders received in the first six months of 2025, $171.3 million related to A&D products, $181.8 million related to USG products, and $141.8 million related to Test products.

[0001104659-26-058482:mdna:17]
[same as prior period, unchanged from 0001104659-26-011932:mdna:16]

[0001104659-26-058482:mdna:18]
Selling, general and administrative (SG&A) expenses for the second quarter of 2026 were $62.8 million (20.3% of net sales), compared with $54.3 million (23.4% of net sales) for the second quarter of 2025. For the first six months of 2026, SG&A expenses were $124.0 million (20.7% of net sales) compared to $109.3 million (24.5% of net sales) for the first six months of 2025. The increase in SG&A in the second quarter and first six months of 2026 compared to the corresponding periods of 2025 was mainly due to an increase within the A&D segment due to the Maritime acquisition; increased expenses at all three business segments primarily related to higher sales and inflationary impacts and an increase at Corporate mainly due to acquisition costs. SG&A as a percentage of net sales decreased in the second quarter and first six months of 2026 within all three business segments.

[0001104659-26-058482:mdna:19]
[same as prior period, unchanged from 0001104659-26-011932:mdna:18]

[0001104659-26-058482:mdna:20]
Amortization of intangible assets was $20.4 million and $40.7 million for the second quarter and first six months of 2026, respectively, compared to $8.0 million and $16.0 million for the corresponding periods of 2025. Amortization expenses consist of amortization of acquired intangible assets from acquisitions and other identifiable intangible assets (primarily software). The increase in amortization expense in the second quarter and first six months of 2026 compared to the corresponding periods of 2025 was mainly due to an increase in amortization of intangible assets related to the Maritime acquisition.

[0001104659-26-058482:mdna:21]
OTHER EXPENSES (INCOME), NET

[0001104659-26-058482:mdna:22]
Other expenses, net, was $1.8 million in the second quarter of 2026 compared with $0.4 million in the second quarter of 2025. Other expenses, net, was $1.8 million in the first six months of 2026 compared to other (income) of ($0.3) million in the first six months of 2025. The principal components of other expenses, net, in the second quarter and first six months of 2026 included $1.3 million of restructuring charges within the Test segment due to the exit of the acoustics product line (primarily asset write-offs, contract termination charges and severance), and $0.6 million of restructuring charges (primarily severance) within the USG segment. There were no individually significant items in other expenses (income), net, in the second quarter of 2025. The principal component of other expenses, net, in the first six months of 2025 was approximately $0.5 million of restructuring charges (primarily severance) within the Test and USG segments.

[0001104659-26-058482:mdna:23]
[same as prior period, unchanged from 0001104659-26-011932:mdna:22]

[0001104659-26-058482:mdna:24]
The Company evaluates the performance of its operating segments based on EBIT, and provides EBIT on a consolidated basis. EBIT is a non-GAAP financial measure. Please refer to the discussion of non-GAAP financial measures in Note 6 to the condensed Consolidated Financial Statements, above. EBIT was $46.3 million (15.0% of net sales) for the second quarter of 2026 compared to $36.6 million (15.8% of net sales) for the second quarter of 2025. For the first six months of 2026, EBIT was $84.6 million (14.1% of net sales) compared to $64.7 million (14.5% of net sales) for the first six months of 2025.

[0001104659-26-058482:mdna:25]
The following table presents a reconciliation of EBIT from continuing operations to net earnings.

[0001104659-26-058482:mdna:26]
| ​ | ​ | Three Months Ended | ​ | Six Months Ended |
| ​ | ​ | March 31, | ​ | March 31, |
| (In thousands) | ​ ​ ​ | 2026 | ​ ​ ​ | 2025 | ​ ​ ​ | 2026 | ​ ​ ​ | 2025 |
| Net earnings | ​ | $ | 33,556 | ​ | ​ | 26,383 | ​ | 62,247 | ​ | 46,690 |
| Plus: Interest expense, net | ​ | ​ | 2,399 | ​ | ​ | 2,195 | ​ | 5,279 | ​ | 4,452 |
| Plus: Income tax expense | ​ | ​ | 10,308 | ​ | ​ | 8,037 | ​ | 17,095 | ​ | 13,527 |
| Consolidated EBIT from continuing operations | ​ | $ | 46,263 | ​ | ​ | 36,615 | ​ | 84,621 | ​ | 64,669 |

[0001104659-26-058482:mdna:27]
[same as prior period, unchanged from 0001104659-26-011932:mdna:26]

[0001104659-26-058482:mdna:28]
EBIT in the second quarter of 2026 was $43.0 million (28.6% of net sales) compared to $24.2 million (27.0% of net sales) in the second quarter of 2025. EBIT in the first six months of 2026 was $81.0 million (27.5% of net sales) compared to $41.7 million (24.3% of net sales) in the first six months of 2025. The increase in EBIT in the second quarter and first six months of 2026 compared to the corresponding periods of 2025 was mainly driven by leverage on higher sales volumes as mentioned above, and price increases, partially offset by inflationary pressures and unfavorable mix.

[0001104659-26-058482:mdna:29]
[same as prior period, unchanged from 0001104659-26-011932:mdna:28]

[0001104659-26-058482:mdna:30]
EBIT in the second quarter of 2026 was $22.5 million (24.0% of net sales) compared to $20.8 million (22.9% of net sales) in the second quarter of 2025. EBIT in the first six months of 2026 was $42.0 million (23.2% of net sales) compared to $41.3 million (23.3% of net sales) in the first six months of 2025. The increase in EBIT in the second quarter and first six months of 2026 compared to the corresponding periods of 2025 was mainly driven by leverage on higher sales volumes at Doble and price increases and mix, partially offset by lower sales volumes at NRG, and inflationary pressures. EBIT was negatively impacted by $0.6 million of restructuring charges (primarily severance) in the first six months of 2026.

[0001104659-26-058482:mdna:31]
[same as prior period, unchanged from 0001104659-26-011932:mdna:30]

[0001104659-26-058482:mdna:32]
EBIT in the second quarter of 2026 was $8.8 million (13.4% of net sales) compared to $6.4 million (12.4% of net sales) in the second quarter of 2025. EBIT in the first six months of 2026 was $16.8 million (13.6% of net sales) compared to $10.8 million (11.1% of net sales) in the first six months of 2025. The increase in EBIT in the second quarter and first six months of 2026 compared to the corresponding periods of 2025 was mainly due to higher sales volumes and price increases partially offset by inflationary pressures. EBIT was negatively impacted by $1.3 million and $0.4 million in the first six months of 2026 and 2025, respectively, by restructuring charges (primarily asset write-offs, contract termination charges and severance).

[0001104659-26-058482:mdna:33]
[same as prior period, unchanged from 0001104659-26-011932:mdna:32]

[0001104659-26-058482:mdna:34]
Corporate costs included in EBIT were $28.0 million and $55.2 million in the second quarter and first six months of 2026, respectively, compared to $14.8 million and $29.1 million in the corresponding periods of 2025. The increase in Corporate costs in the second quarter and first six months of 2026 compared to the corresponding periods of 2025 was mainly due to an increase in acquisition related amortization due to the Maritime acquisition, and an increase in share-based compensation costs and acquisition related costs.

[0001104659-26-058482:mdna:35]
[same as prior period, unchanged from 0001104659-26-011932:mdna:34]

[0001104659-26-058482:mdna:36]
Interest expense was $2.4 million and $5.3 million in the second quarter and first six months of 2026, respectively, and $2.2 million and $4.5 million in the corresponding periods of 2025. The increase in interest expense in the second quarter and first six months of 2026 compared to the corresponding periods of 2025 was mainly due to higher average outstanding borrowings due to the Maritime acquisition in April 2025. The weighted average outstanding borrowings were $168 million and $170 million for the three and six-month periods ending March 31, 2026 and $100 million and $111 million for the three and six-month periods ending March 31, 2025.

[0001104659-26-058482:mdna:37]
[same as prior period, unchanged from 0001104659-26-011932:mdna:36]

[0001104659-26-058482:mdna:38]
The second quarter 2026 effective income tax rate was 23.5% compared to 23.3% in the second quarter of 2025. The effective income tax rate in the first six months of 2026 was 21.5% compared to 22.5% for the first six months of 2025. Income tax expense in the first six months of 2026 was favorably impacted by additional tax benefits related to the vesting of share-based compensation awards.

[0001104659-26-058482:mdna:39]
[same as prior period, unchanged from 0001104659-26-011932:mdna:38]

[0001104659-26-058482:mdna:40]
The Company’s overall financial position and liquidity remain strong. Working capital (current assets less current liabilities) increased to $226.4 million at March 31, 2026 from $180.4 million at September 30, 2025. Inventories increased $19.3 million during this period due to a $7.7 million increase within the A&D segment, a $9.1 million increase within the USG segment and a $2.5 million increase within the Test segment primarily from an increase in work-in-process and raw materials inventories due to timing of manufacturing existing orders. Contract assets increased $12.8 million primarily within the A&D segment (Maritime) due to timing. Contract liabilities increased $52.8 million primarily within the A&D segment (Globe and Maritime) due to timing of payments received from customers.

[0001104659-26-058482:mdna:41]
Net cash provided by operating activities from continuing operations was $134.6 million and $46.3 million in the first six months of 2026 and 2025, respectively. The increase in net cash provided by operating activities in the first six months of 2026 as compared to the first six months of 2025 was mainly driven by lower working capital requirements and higher earnings.

[0001104659-26-058482:mdna:42]
Capital expenditures for continuing operations were $13.1 million and $14.9 million in the first six months of 2026 and 2025, respectively. In addition, the Company incurred expenditures for capitalized software and other intangible assets from continuing operations of $4.8 million and $5.5 million in the first six months of 2026 and 2025, respectively.

[0001104659-26-058482:mdna:43]
Credit Facility

[0001104659-26-058482:mdna:44]
At March 31, 2026, the Company had approximately $440 million available to borrow under its bank credit facility, a $250 million increase option, and $92.3 million cash on hand. At March 31, 2026, the Company had $145 million of outstanding borrowings under the Credit Facility and Incremental Facility in addition to outstanding letters of credit of $14.5 million. Cash flow from operations and borrowings under the Company’s credit facility are expected to meet the Company’s capital requirements and operational needs for the foreseeable future. The Company’s ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.

[0001104659-26-058482:mdna:45]
[same as prior period, unchanged from 0001104659-26-011932:mdna:42]

[0001104659-26-058482:mdna:46]
During the first six months of fiscal 2026, the Company paid $10.2 million consisting of a $5.1 million working capital settlement and a $5.1 million group tax relief payment, both related to the Maritime acquisition.

[0001104659-26-058482:mdna:47]
Divestiture

[0001104659-26-058482:mdna:48]
During the second quarter of 2026, the Company received a $1.5 million, net, working capital settlement related to the sale of VACCO. In addition, during the second quarter of 2026, the Company paid approximately $59 million in cash taxes related to the gain on sale of VACCO.

[0001104659-26-058482:mdna:49]
Subsequent Event

[0001104659-26-058482:mdna:50]
On April 15, 2026, the Company signed a definitive agreement to acquire the Megger Group Limited (Megger) business of TBG AG. Megger is a global provider of testing, monitoring, and data-driven solutions for utilities and critical electric infrastructure, including industrial, transportation, data center and renewable end markets. Under the terms of the agreement, ESCO will acquire Megger for total consideration of approximately $2.35 billion, consisting of $0.9 billion in cash and ESCO equity valued at approximately $1.4 billion. The cash portion will be funded through existing cash on hand and incremental debt, with committed financing in place. The Company expects to complete the acquisition in the first quarter of fiscal 2027. Megger will become part of the Company’s Utility Solution Group (USG) segment. See further discussion of the transaction and financing arrangements in the Company’s Form 8-K’s filed April 15, 2026 and April 16, 2026.

[0001104659-26-058482:mdna:51]
[same as prior period, unchanged from 0001104659-26-011932:mdna:46]

[0001104659-26-058482:mdna:52]
A dividend of $0.08 per share, totaling $2.1 million, was paid on October 16, 2025 to stockholders of record as of October 2, 2025. A dividend of $0.08 per share, totaling $2.1 million, was paid on January 16, 2026 to stockholders of record as of January 2, 2026. Subsequent to March 31, 2026, a quarterly dividend of $0.08 per share, totaling $2.1 million, was paid on April 17, 2026 to stockholders of record as of April 2, 2026.

[0001104659-26-058482:mdna:53]
[same as prior period, unchanged from 0001104659-26-011932:mdna:48]

[0001104659-26-058482:mdna:54]
Management has evaluated the accounting policies used in the preparation of the Company’s financial statements and related notes and believes those policies to be reasonable and appropriate. Certain of these accounting policies require the application of significant judgment by Management in selecting appropriate assumptions for calculating financial estimates. By their nature, these judgments are subject to an inherent degree of uncertainty. These judgments are based on historical experience, trends in the industry, information provided by customers and information available from other outside sources, as appropriate. The most significant areas involving Management judgments and estimates may be found in the Critical Accounting Policies section of Management’s Discussion and Analysis and in Note 1 to the condensed Consolidated Financial Statements contained in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2025.

[0001104659-26-058482:mdna:55]
[same as prior period, unchanged from 0001104659-26-011932:mdna:50]

[0001104659-26-058482:mdna:56]
Contingencies

[0001104659-26-058482:mdna:57]
As a normal incident of the business in which the Company is engaged, various claims, charges and litigation are asserted or commenced against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. In the opinion of Management, the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company, are adequately reserved, are covered by insurance, or would not have a material adverse effect on the Company’s results from operations, capital expenditures, or competitive position.

[0001104659-26-058482:mdna:58]
[same as prior period, unchanged from 0001104659-26-011932:mdna:53]

[0001104659-26-058482:mdna:59]
Investors are cautioned that such statements are only predictions and speak only as of the date of this Form 10-Q, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment, including but not limited to those described in Item 1A, “Risk Factors,” of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2025, and the following: the impacts of climate change and related regulation of greenhouse gases; the impacts of labor disputes, civil disorder, wars including the conflicts involving Iran and Lebanon, elections, political changes, tariffs and trade disputes, terrorist activities, cyberattacks or natural disasters on the Company’s operations and those of the Company’s customers and suppliers; disruptions in manufacturing or delivery arrangements due to shortages or unavailability of materials or components; restrictions or closures of critical supply routes such as the Strait of Hormuz; other supply chain disruptions; inability to access work sites; the timing and content of future contract awards or customer orders; the timely appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer contracts or orders; weakening of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties or data breaches; the availability of selected acquisitions; delivery delays or defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability of certain raw materials; material changes in the cost of credit; changes in laws and regulations including but not limited to changes in accounting standards and taxation; changes in interest, inflation and employment rates; costs relating to environmental matters arising from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the integration and performance of recently acquired businesses.
