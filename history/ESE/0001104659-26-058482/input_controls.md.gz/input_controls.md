# ESE 10-Q controls and the auditor's report


## item_4_controls

[0001104659-26-058482:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0001104659-26-058482:item_4_controls:2]
The Company carried out an evaluation, under the supervision and with the participation of Management, including the Company’s Chief Executive Officer and Chief Financial Officer, of the effectiveness of the design and operation of the Company’s disclosure controls and procedures as of the end of the period covered by this report. Based upon that evaluation, the Company’s Chief Executive Officer and Chief Financial Officer concluded that the Company’s disclosure controls and procedures were effective as of that date. During 2025, the Company acquired the Signature Management & Power business (Maritime). The Company is currently in the process of integrating Maritime into its assessment of its internal control over financial reporting. In accordance with the SEC’s published guidance, Management’s assessment, and conclusions on the effectiveness of our disclosure controls and procedures as of March 31, 2026, excludes an assessment of the internal control over financial reporting of Maritime. Disclosure controls and procedures are controls and procedures that are designed to ensure that information required to be disclosed in Company reports filed or submitted under the Securities Exchange Act of 1934 (the “Exchange Act”) is recorded, processed, summarized and reported within the time periods specified in the Securities and Exchange Commission’s rules and forms. Other than as described above with respect to Maritime, there has been no change in the Company’s internal control over financial reporting (as defined in Rule 13a-15(f) under the Exchange Act) during the period covered by this report that has materially affected, or is reasonably likely to materially affect, the Company’s internal control over financial reporting.

[0001104659-26-058482:item_4_controls:3]
26
