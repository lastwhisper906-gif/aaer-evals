# ESE 8-K — 0001144204-18-006014 filed 2018-02-06

## item codes, every 8-K on or before 2018-02-07

- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2018-02-07

- none on or before 2018-02-07

## item 2.02 — earnings release, exhibit 99.1

[0001144204-18-006014:8k_2_02:1]
EX-99.1
3
tv484880_ex99-1.htm
EXHIBIT 99.1

[0001144204-18-006014:8k_2_02:2]
Exhibit 99.1

[0001144204-18-006014:8k_2_02:3]
| NEWS FROM |  |

[0001144204-18-006014:8k_2_02:4]
| For more information contact: |  |
| Kate Lowrey |  |
| Director, Investor Relations |  |
| ESCO Technologies Inc. |  |
| (314) 213-7277 |  |

[0001144204-18-006014:8k_2_02:5]
ESCO ANNOUNCES FIRST QUARTER FISCAL
2018 RESULTS

[0001144204-18-006014:8k_2_02:6]
- GAAP EPS $1.33 Driven By Large Tax
Benefit -

[0001144204-18-006014:8k_2_02:7]
- Adjusted EPS $0.33 at Top of Guidance
Range -

[0001144204-18-006014:8k_2_02:8]
ST. LOUIS, February 6, 2018 – ESCO Technologies Inc.
(NYSE: ESE) (ESCO, or the Company) today reported its operating results for the first quarter ended December 31, 2017 (Q1 2018),
compared to the first quarter ended December 31, 2016 (Q1 2017).

[0001144204-18-006014:8k_2_02:9]
The financial results presented include
certain non-GAAP financial measures such as EBIT, EBITDA (defined as earnings before interest, taxes, depreciation and amortization),
Adjusted EBITDA (defined as EBITDA excluding certain defined non-recurring charges) and Adjusted EPS. Any non-GAAP financial measures
presented are reconciled to their respective GAAP equivalents.

[0001144204-18-006014:8k_2_02:10]
Management believes these non-GAAP financial
measures are useful in assessing the ongoing operational profitability of the Company’s business segments, and therefore,
allow shareholders better visibility into the Company’s underlying operations. See “Non-GAAP Financial Measures”
described below.

[0001144204-18-006014:8k_2_02:11]
GAAP EPS of $1.33 per share reflects the
estimated impact of the December 2017 “Tax Cuts and Jobs Act” (U.S. Tax Reform) which resulted in a Q1 2018 net tax
benefit of approximately $25 million, or $1.00 per share, which is excluded when determining Adjusted EPS. GAAP net earnings were
$35 million in Q1 2018.

[0001144204-18-006014:8k_2_02:12]
Q1 2018 Adjusted EPS of $0.33 per
share compares favorably to Management’s November 2017 guidance of $0.28 to $0.33 per share. Achieving the high end of
the guidance range resulted from the Filtration and USG segments stronger than expected operating performance, with Test and
Technical Packaging generally on plan.

[0001144204-18-006014:8k_2_02:13]
EBITDA was $24 million in Q1 2018 and was
also at the high end of previous expectations.

[0001144204-18-006014:8k_2_02:14]
Management believes the financial impact
of U.S. Tax Reform will be beneficial to the Company’s operating results and cash flow in 2018 and beyond, and as a result,
is raising its 2018 GAAP EPS guidance from the previously communicated $2.30 to $2.40 per share, to $3.55 to $3.65 per share, and
is introducing 2018 Adjusted EPS guidance in the range of $2.65 to $2.75 per share.

[0001144204-18-006014:8k_2_02:15]
Operating Highlights

[0001144204-18-006014:8k_2_02:16]
|  | · | Q1 2018 sales increased $27 million (19 percent) to $173 million compared to $146 million in Q1 2017; |

[0001144204-18-006014:8k_2_02:17]
|  | · | On a segment basis, Q1 2018 Filtration sales increased nominally and were consistent with previous expectations. Commercial aerospace and space sales increased, industrial/automotive sales decreased at PTI as previously communicated, and Westland’s navy sales decreased due to the quarterly timing of large projects. Test sales increased $4 million, or 11 percent driven by its strong backlog, and Technical Packaging sales increased $2 million, or 11 percent as a result of new programs. USG sales increased $20 million, or 57 percent, driven by the recent acquisitions and the continued strength of new products and software at Doble. NRG sales were below plan as certain customers delayed project deliveries in December until U.S. Tax Reform was finalized, which when signed, removed the uncertainty within the renewable energy industry; |

[0001144204-18-006014:8k_2_02:18]
|  | · | SG&A expenses increased $8 million in Q1 2018 primarily due to the inclusion of the 2017 acquisitions in the current period, coupled with additional sales, marketing, R&D, and bid and proposal costs incurred to support future revenue growth; |

[0001144204-18-006014:8k_2_02:19]
|  | · | Amortization of intangible assets increased $1 million due to the 2017 acquisitions; |

[0001144204-18-006014:8k_2_02:20]
|  | · | Entered orders were $201 million in Q1 2018 (book-to-bill of 1.16x) reflecting a $27 million (7 percent) increase in backlog during the Quarter and an ending backlog of $404 million at December 31, 2017; |

[0001144204-18-006014:8k_2_02:21]
|  | · | Filtration orders were $65 million (book-to-bill of 1.09x) comprised of recurring commercial aerospace orders and additional space and navy products; |

[0001144204-18-006014:8k_2_02:22]
|  | · | Test orders were $58 million (book-to-bill of 1.55x) which reflects continued strength in the wireless, government and defense, electric vehicle, and automotive chamber markets; |

[0001144204-18-006014:8k_2_02:23]
|  | · | USG orders were $58 million (book-to-bill of 1.03x) which reflects increased orders for new products and solutions across the segment; |

[0001144204-18-006014:8k_2_02:24]
|  | · | Technical Packaging orders were $19 million (book-to-bill of 0.95x), and of special note, the KAZ program was extended another three years; |

[0001144204-18-006014:8k_2_02:25]
|  | · | The Q1 2018 income tax rates were (170.8) percent on a GAAP basis due to the above noted $25 million net tax benefit recorded, and 33.5 percent on an Adjusted basis when excluding the net tax benefit. The Adjusted rate is consistent with the 33.5 percent tax rate recorded in Q1 2017; and, |

[0001144204-18-006014:8k_2_02:26]
|  | · | Net cash provided by operating activities was $18 million in Q1 2018 resulting in $218 million of net debt (outstanding borrowings less cash on hand) at December 31, 2017 and a 2.1x leverage ratio. Management is planning to repatriate a substantial portion of its foreign cash (currently $32 million) to pay down its outstanding debt and for other corporate purposes. |

[0001144204-18-006014:8k_2_02:27]
Chairman’s Commentary –
Q1 2018

[0001144204-18-006014:8k_2_02:28]
Vic Richey, Chairman and Chief Executive
Officer, commented, “I’m pleased with the start of the year as Q1’s operating results came in at the high end
of our range, and Q1 cash flow and entered orders exceeded our original expectations.

[0001144204-18-006014:8k_2_02:29]
“USG’s recent acquisitions remain
on track and the integrations are nearly complete, which continues to support my enthusiasm for USG’s growth outlook and enhanced
operating margins. The integration and consolidation of our sales channels, including our global rep and distributor network, has
gone very well and we are already seeing the positive impact of these actions across the entire segment platform.

[0001144204-18-006014:8k_2_02:30]
“Realizing the success of this integration
so quickly has allowed us to identify other opportunities to significantly reduce USG’s
operating costs and expand future margins. We are finalizing this cost/benefit analysis in USG, as well as in Filtration resulting
from PTI exiting its low margin industrial/automotive market.

[0001144204-18-006014:8k_2_02:31]
“We expect to incur a pretax
charge of approximately $2 to $3 million in Q2 for these cost reduction actions, and considering the significant annual
ongoing cost savings we expect to achieve as a result, the economic payback is essentially one year.

[0001144204-18-006014:8k_2_02:32]
“Touching on a few Q1 operating
highlights, as noted earlier, we came in at the top of our guidance range as Filtration and USG exceeded plan, with Test and
Technical Packaging essentially meeting plan. Our November guidance for Q1 2018 projected EPS to be lower compared to prior
year Q1 for the specific items communicated previously. A clear highlight is that we achieved Q1 2018 EBITDA of $24.2 million
which was above the prior year, despite the quarterly earnings profile being more back half weighted in 2018.

[0001144204-18-006014:8k_2_02:33]
“Another clear highlight continues
to be the strength of our order activity and backlog growth supporting our second half of the year. All four operating segments
recorded significant orders, led by Test with nearly $60 million in new business.

[0001144204-18-006014:8k_2_02:34]
“Our operating cash flow was also
well ahead of plan which allowed us to pay down debt sooner than expected. With the new tax laws, we expect to generate and/or
retain a substantially higher amount of cash than in past years. This bodes well for supporting our continuing acquisition strategy,
as we balance our M&A actions with our debt levels and leverage ratios as we are committed to maintaining a prudent balance
sheet.

[0001144204-18-006014:8k_2_02:35]
“Our market positions
and continued growth opportunities across the Company provide me with a favorable view of the future with our goal remaining
unchanged – to increase long-term shareholder value.”

[0001144204-18-006014:8k_2_02:36]
Dividend Payment

[0001144204-18-006014:8k_2_02:37]
The next
quarterly cash dividend of $0.08 per share will be paid on April 18, 2018 to stockholders of record on April 3, 2018.

[0001144204-18-006014:8k_2_02:38]
Business Outlook – 2018

[0001144204-18-006014:8k_2_02:39]
With the significant level of M&A
activity completed over the past 18 months, coupled with the positive earnings and cash flow impact of U.S. Tax Reform,
Management will continue to emphasize Adjusted EBITDA as a supplement to net income and Adjusted EPS as a supplement to
GAAP EPS as it believes these are relevant metrics to be considered for measuring ongoing operating performance as well as
the Company’s enterprise valuation.

[0001144204-18-006014:8k_2_02:40]
Management continues to see meaningful sales
and Adjusted EBITDA growth across each of the Company’s business segments and anticipates growth rates in 2018 and beyond
that are projected to exceed the Company’s defined peer group and the broader industrial market.

[0001144204-18-006014:8k_2_02:41]
Excluding the favorable EPS impact of U.S.
Tax Reform, the details of Management’s growth expectations for 2018 compared to 2017 are consistent with the November guidance
and are repeated here for convenience:

[0001144204-18-006014:8k_2_02:42]
|  | · | Sales are expected to increase approximately 13 percent driven by: incremental sales from acquisitions being included for a full year; increased commercial aerospace deliveries at PTI, Crissair and Mayday; higher organic sales at USG; significantly higher sales at Test including the catch-up of 2017 deliveries as well as significant new product wins currently in backlog; partially offset by a reduction in lower margin industrial/automotive market product deliveries at PTI as it exits that market; and flat sales in Technical Packaging; |

[0001144204-18-006014:8k_2_02:43]
|  | · | Adjusted EBITDA is expected to increase between 15 and 17 percent, resulting in Adjusted EBITDA in the range of $141 million to $143 million, compared to 2017 Adjusted EBITDA of $123 million; |

[0001144204-18-006014:8k_2_02:44]
|  | · | Interest expense on higher debt (acquisition funding) is expected to be approximately $9.5 million, reflecting an increase of $4.9 million (or $0.12 per share) over the $4.6 million of interest expense in 2017; |

[0001144204-18-006014:8k_2_02:45]
|  | · | Non-cash depreciation and amortization of intangibles is expected to increase approximately $7.1 million (or $0.18 per share after-tax) as a result of the recent acquisitions. Purchase accounting intangible asset amortization charges are recorded at Corporate; |

[0001144204-18-006014:8k_2_02:46]
|  | · | Income tax expense is expected to significantly decrease in 2018 due to the recent tax law changes. The expense is expected to be lower as a result of an estimated Quarterly tax rate of approximately 26 percent projected over the remainder of 2018, and the large, one time net benefit recorded in Q1 2018; and, |

[0001144204-18-006014:8k_2_02:47]
|  | · | In summary, Management projects 2018 GAAP EPS in the range of $3.55 to $3.65 per share, and Adjusted EPS in the range of $2.65 to $2.75 per share, reflecting the profit contributions from the recent acquisitions, additional depreciation and amortization charges, higher interest costs, the discrete cost reduction charges described above in Filtration and USG, and, adjusting for the Q1 2018 one-time / incremental net tax benefits resulting from U.S. Tax Reform and the noted cost reduction charges described above. |

[0001144204-18-006014:8k_2_02:48]
On a quarterly basis, Management continues
to expect the balance of 2018’s revenues, operating results and EPS to be significantly second-half weighted compared to
the first half.

[0001144204-18-006014:8k_2_02:49]
Management expects Q2 2018 GAAP EPS in
the range of $0.30 to $0.35 per share (reflecting the above noted cost reduction charges in Filtration and USG), and Q2 2018 Adjusted
EPS in the range of $0.38 to $0.43 per share.

[0001144204-18-006014:8k_2_02:50]
The timing of quarterly sales and earnings
throughout the year, coupled with higher non-cash charges within the respective quarters impacts comparability in Q2.

[0001144204-18-006014:8k_2_02:51]
Chairman’s Commentary –
2018

[0001144204-18-006014:8k_2_02:52]
Mr. Richey continued, “Given the
expected contribution from our 2017 acquisitions, coupled with anticipated organic growth from “legacy”
operations, and supplemented by the favorable earnings and cash flow impact from U.S. Tax Reform, I continue to believe that
2018 will reflect solid sales, EBIT, EBITDA and EPS growth and position us well to meet or exceed our shareholder
value-creation goals.

[0001144204-18-006014:8k_2_02:53]
“Our market leadership positions and
the breadth and diversity of our new product offerings will allow us to continue to grow at levels above our peer averages. Our
management teams’ focus on profitable growth and ROIC will remain steadfast as we believe these are the key drivers of continued
and sustainable share price appreciation.”

[0001144204-18-006014:8k_2_02:54]
Conference Call

[0001144204-18-006014:8k_2_02:55]
The Company will host a conference call
today, February 6, at 4:00 p.m. Central Time, to discuss the Company’s Q1 2018 results. A live audio webcast will be available
on the Company’s website at www.escotechnologies.com. Please access the website at least 15 minutes prior to the call
to register, download and install any necessary audio software. A replay of the conference call will be available for seven days
on the Company’s website noted above or by phone (dial 1-855-859-2056 and enter the pass code 1085239).

[0001144204-18-006014:8k_2_02:56]
Forward-Looking Statements

[0001144204-18-006014:8k_2_02:57]
Statements in this press release regarding
the Company’s expected quarterly, 2018 full year and beyond results, revenue and sales growth, EPS, Adjusted EPS, EPS growth,
cash, EBIT, EBITDA, Adjusted EBITDA, gross profit, interest expense, non-cash depreciation and amortization of intangibles, corporate
costs, income tax expense, effective tax rates, income tax expense, cash generation, repatriation of foreign cash and the uses
of such cash, the impacts of U.S. Tax Reform, margin expansion and savings resulting from cost reduction actions, the Company’s
ability to increase operating margins, realize financial goals and increase shareholder value, the success of acquisition efforts,
the size, number and timing of future sales and growth opportunities, the long-term success of the Company, and any other statements
which are not strictly historical are “forward-looking” statements within the meaning of the safe harbor provisions
of the federal securities laws.

[0001144204-18-006014:8k_2_02:58]
Investors are cautioned that such
statements are only predictions and speak only as of the date of this release, and the Company undertakes no duty to update
them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ
materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the
Company’s operations and business environment including, but not limited to those described in Item 1A, “Risk
Factors”, of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2017, and the
following: the success of the Company’s competitors; weakening of economic conditions in served markets; changes in
customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties; delivery delays
or defaults by customers; material changes in the costs and availability of certain raw materials; the appropriation,
allocation and availability of Government funds; the termination for convenience of Government and other customer contracts;
the timing and content of future contract awards or customer orders; performance issues with key customers, suppliers and
subcontractors; labor disputes; the impacts of natural disasters on the Company’s operations and those of the
Company’s customers and suppliers; changes in laws and regulations, including but not limited to changes in accounting
standards and taxation requirements; legal and foreign tax requirements impacting the repatriation of cash in foreign
locations; changes in interest rates; costs relating to environmental matters arising from current or former facilities;
financial exposure in connection with Company guarantees of certain Aclara contracts; the availability of select
acquisitions; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the
success and integration of recently acquired businesses.

[0001144204-18-006014:8k_2_02:59]
Non-GAAP Financial Measures

[0001144204-18-006014:8k_2_02:60]
The financial measures EBIT, EBITDA, Adjusted
EBITDA and Adjusted EPS are presented in this press release. The Company defines “EBIT” as earnings before interest
and taxes, “EBITDA” as earnings before interest, taxes, depreciation and amortization, “Adjusted EBITDA”
as EBITDA excluding certain defined non-recurring charges, and “Adjusted EPS” as GAAP earnings per share (EPS) excluding
the charges described above which were $1.00 per share for Q1 2018.

[0001144204-18-006014:8k_2_02:61]
EBIT, EBITDA, Adjusted EBITDA and Adjusted
EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management believes that
EBIT, EBITDA and Adjusted EBITDA are useful in assessing the operational profitability of the Company’s business segments
because they exclude interest, taxes, depreciation and amortization, which are generally accounted for across the entire Company
on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company
as well as incentive compensation. The Company believes that the presentation of EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS
provides important supplemental information to investors by facilitating comparisons with other companies, many of which use similar
non-GAAP financial measures to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace
any measures of performance determined in accordance with GAAP.

[0001144204-18-006014:8k_2_02:62]
ESCO, headquartered in St. Louis: Manufactures
highly-engineered filtration and fluid control products for the aviation, space and process markets worldwide; is the industry
leader in RF shielding and EMC test products; provides diagnostic instruments, software and services for the benefit of industrial
power users and the electric utility and renewable energy industries; and, produces custom thermoformed packaging, pulp-based
packaging, and specialty products for medical and commercial markets. Further information regarding ESCO and its subsidiaries
is available on the Company’s website at www.escotechnologies.com.

[0001144204-18-006014:8k_2_02:63]
- tables attached -

[0001144204-18-006014:8k_2_02:64]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001144204-18-006014:8k_2_02:65]
Condensed Consolidated Statements of Operations
(Unaudited)

[0001144204-18-006014:8k_2_02:66]
(Dollars in thousands, except per share
amounts)

[0001144204-18-006014:8k_2_02:67]
|  |  | Three Months Ended December 31, 2017 |  |  | Three Months Ended December 31, 2016 |  |
| Net Sales |  | $ | 173,495 |  |  |  | 146,368 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 111,736 |  |  |  | 92,914 |  |
| Selling, general and administrative expenses |  |  | 42,154 |  |  |  | 33,762 |  |
| Amortization of intangible assets |  |  | 4,446 |  |  |  | 3,649 |  |
| Interest expense |  |  | 2,185 |  |  |  | 684 |  |
| Other expenses (income), net |  |  | 173 |  |  |  | (766 | ) |
| Total costs and expenses |  |  | 160,694 |  |  |  | 130,243 |  |
| Earnings before income taxes |  |  | 12,801 |  |  |  | 16,125 |  |
| Income tax (benefit) expense |  |  | (21,870 | ) |  |  | 5,398 |  |
| Net earnings |  | $ | 34,671 |  |  |  | 10,727 |  |
| Diluted EPS - GAAP |  | $ | 1.33 | (1) |  |  | 0.41 |  |
| Diluted average common shares O/S: |  |  | 26,080 |  |  |  | 25,979 |  |

[0001144204-18-006014:8k_2_02:68]
|  | (1) | Q1 '18 GAAP EPS included $25 million, (or $1.00 per share) of net tax benefit recorded related to the December 2017 "Tax Cuts and Jobs Act" (U.S. Tax Reform). Excluding this impact, Adjusted EPS was $0.33 per share. |

[0001144204-18-006014:8k_2_02:69]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001144204-18-006014:8k_2_02:70]
Condensed Business Segment Information (Unaudited)

[0001144204-18-006014:8k_2_02:71]
(Dollars in thousands)

[0001144204-18-006014:8k_2_02:72]
|  |  | GAAP |  |
|  |  | Q1 2018 |  |  | Q1 2017 |  |
| Net Sales |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 60,035 |  |  |  | 58,785 |  |
| Test |  |  | 37,530 |  |  |  | 33,827 |  |
| USG |  |  | 55,754 |  |  |  | 35,556 |  |
| Technical Packaging |  |  | 20,176 |  |  |  | 18,200 |  |
| Totals |  | $ | 173,495 |  |  |  | 146,368 |  |
| EBIT |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 9,645 |  |  |  | 10,726 |  |
| Test |  |  | 2,596 |  |  |  | 2,425 |  |
| USG |  |  | 10,651 |  |  |  | 9,674 |  |
| Technical Packaging |  |  | 965 |  |  |  | 1,031 |  |
| Corporate |  |  | (8,871 | ) |  |  | (7,047 | ) |
| Consolidated EBIT |  |  | 14,986 |  |  |  | 16,809 |  |
| Less: Interest expense |  |  | (2,185 | ) |  |  | (684 | ) |
| Plus (Less): Income tax |  |  | 21,870 |  |  |  | (5,398 | ) |
| Net earnings |  | $ | 34,671 |  |  |  | 10,727 |  |

[0001144204-18-006014:8k_2_02:73]
EBITDA Reconciliation to Net earnings:

[0001144204-18-006014:8k_2_02:74]
|  |  | Q1 2018 |  |  | Q1 2017 |  |
| Consolidated EBITDA |  | $ | 24,212 |  |  |  | 23,897 |  |
| Less: Depr & Amort |  |  | (9,226 | ) |  |  | (7,088 | ) |
| Consolidated EBIT |  |  | 14,986 |  |  |  | 16,809 |  |
| Less: Interest expense |  |  | (2,185 | ) |  |  | (684 | ) |
| Plus (Less): Income tax |  |  | 21,870 |  |  |  | (5,398 | ) |
| Net earnings |  | $ | 34,671 |  |  |  | 10,727 |  |

[0001144204-18-006014:8k_2_02:75]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001144204-18-006014:8k_2_02:76]
Condensed Consolidated Balance Sheets (Unaudited)

[0001144204-18-006014:8k_2_02:77]
(Dollars in thousands)

[0001144204-18-006014:8k_2_02:78]
|  |  | December 31, 2017 |  |  | September 30, 2017 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 41,600 |  |  |  | 45,516 |  |
| Accounts receivable, net |  |  | 148,502 |  |  |  | 160,580 |  |
| Costs and estimated earnings on long-term contracts |  |  | 39,045 |  |  |  | 47,286 |  |
| Inventories |  |  | 130,579 |  |  |  | 124,515 |  |
| Other current assets |  |  | 13,301 |  |  |  | 14,895 |  |
| Total current assets |  |  | 373,027 |  |  |  | 392,792 |  |
| Property, plant and equipment, net |  |  | 132,790 |  |  |  | 132,748 |  |
| Intangible assets, net |  |  | 347,578 |  |  |  | 351,134 |  |
| Goodwill |  |  | 378,510 |  |  |  | 377,879 |  |
| Other assets |  |  | 5,843 |  |  |  | 5,891 |  |
|  |  | $ | 1,237,748 |  |  |  | 1,260,444 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Short-term borrowings and current maturities of long-term debt |  | $ | 20,000 |  |  |  | 20,000 |  |
| Accounts payable |  |  | 48,766 |  |  |  | 54,789 |  |
| Current portion of deferred revenue |  |  | 25,447 |  |  |  | 28,583 |  |
| Other current liabilities |  |  | 83,819 |  |  |  | 91,597 |  |
| Total current liabilities |  |  | 178,032 |  |  |  | 194,969 |  |
| Deferred tax liabilities |  |  | 57,877 |  |  |  | 86,378 |  |
| Other liabilities |  |  | 54,770 |  |  |  | 52,179 |  |
| Long-term debt |  |  | 240,000 |  |  |  | 255,000 |  |
| Shareholders’ equity |  |  | 707,069 |  |  |  | 671,918 |  |
|  |  | $ | 1,237,748 |  |  |  | 1,260,444 |  |

[0001144204-18-006014:8k_2_02:79]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001144204-18-006014:8k_2_02:80]
Consolidated Statements of Cash Flows (Unaudited)

[0001144204-18-006014:8k_2_02:81]
(Dollars in thousands)

[0001144204-18-006014:8k_2_02:82]
|  |  | Three Months Ended December 31, 2017 |  |
| Cash flows from operating activities: |  |  |  |  |
| Net earnings |  | $ | 34,671 |  |
| Adjustments to reconcile net earnings to net cash provided by operating activities: |  |  |  |  |
| Depreciation and amortization |  |  | 9,226 |  |
| Stock compensation expense |  |  | 1,353 |  |
| Changes in assets and liabilities |  |  | 4,507 |  |
| Effect of deferred taxes |  |  | (28,501 | ) |
| Change in deferred revenue and costs, net |  |  | (3,099 | ) |
| Pension contributions |  |  | (360 | ) |
| Net cash provided by operating activities |  |  | 17,797 |  |
| Cash flows from investing activities: |  |  |  |  |
| Acquisition of businesses, net of cash acquired |  |  | (233 | ) |
| Capital expenditures |  |  | (3,606 | ) |
| Additions to capitalized software |  |  | (2,083 | ) |
| Net cash used by investing activities |  |  | (5,922 | ) |
| Cash flows from financing activities: |  |  |  |  |
| Proceeds from long-term debt |  |  | 15,000 |  |
| Principal payments on long-term debt |  |  | (30,000 | ) |
| Dividends paid |  |  | (2,067 | ) |
| Other |  |  | 17 |  |
| Net cash used by financing activities |  |  | (17,050 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 1,259 |  |
| Net decrease in cash and cash equivalents |  |  | (3,916 | ) |
| Cash and cash equivalents, beginning of period |  |  | 45,516 |  |
| Cash and cash equivalents, end of period |  | $ | 41,600 |  |

[0001144204-18-006014:8k_2_02:83]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001144204-18-006014:8k_2_02:84]
Other Selected Financial Data (Unaudited)

[0001144204-18-006014:8k_2_02:85]
(Dollars in thousands)

[0001144204-18-006014:8k_2_02:86]
| Backlog And Entered Orders - Q1 FY 2018 |  | Filtration |  |  | Test |  |  | USG |  |  | Technical Packaging |  |  | Total |  |
| Beginning Backlog - 10/1/17 |  | $ | 203,120 |  |  |  | 114,792 |  |  |  | 35,581 |  |  |  | 23,614 |  |  |  | 377,107 |  |
| Entered Orders |  |  | 65,395 |  |  |  | 58,290 |  |  |  | 57,645 |  |  |  | 19,205 |  |  |  | 200,535 |  |
| Sales |  |  | (60,035 | ) |  |  | (37,530 | ) |  |  | (55,754 | ) |  |  | (20,176 | ) |  |  | (173,495 | ) |
| Ending Backlog - 12/31/17 |  | $ | 208,480 |  |  |  | 135,552 |  |  |  | 37,472 |  |  |  | 22,643 |  |  |  | 404,147 |  |

## item 5.02 — body, verbatim

[0001144204-18-006014:8k_body:1]
Item 5.02 Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers

[0001144204-18-006014:8k_body:2]
On February 2, 2018, the Registrant’s shareholders approved
the Registrant’s 2018 Omnibus Incentive Plan (the “Plan”), by the vote set forth in Item 5.07, below. The Plan
had been approved and adopted by the Registrant’s Board of Directors on November 9, 2017 subject to shareholder approval.
The Plan replaces the Registrant’s 2013 Incentive Compensation Plan (the “2013 Plan”), which terminated as to
new awards upon shareholder approval of the Plan.

[0001144204-18-006014:8k_body:3]
The Plan, which is attached as Exhibit 10.1 to this report and
is more fully described in the Proxy Statement for the Registrant’s 2018 Annual Meeting filed with the Securities and Exchange
Commission on December 14, 2017, permits the Registrant’s Human Resources and Compensation Committee (the “Committee”)
to grant awards based on shares of the Registrant’s common stock, as well as cash awards, to facilitate effective employee
incentive arrangements, subject to limits on the numbers of shares specified for certain types of awards. Awards may be granted
in the form of stock options (including incentive stock options), tandem stock appreciation rights, performance-accelerated restricted
stock awards, other restricted stock awards, other stock-based awards, and cash-based awards. The Committee may delegate to the
Registrant’s chief executive officer the authority to grant a limited number of stock options, and may delegate to the Registrant’s
Executive Committee the authority to grant a limited number of other stock based awards, only to employees who are not reporting
persons under Section 16 of the Exchange Act or covered employees (as defined in Section 162(m) of the Code). The number of shares
with respect to which stock options and tandem stock appreciation rights may be granted to any individual during any calendar year
may not exceed 150,000 shares.

[0001144204-18-006014:8k_body:4]
The total number of authorized but unissued shares of the Registrant’s
common stock allocated for awards under the Plan is 977,878, of which 350,000 are newly-authorized shares; the remaining 627,878
shares have been rolled over from the 2013 Plan, under which they were previously authorized but not awarded prior to its termination.
Of these 627,878 shares, 100,000 shares may be used under the 2018 Plan only for stock options or other awards which require the
participant to make a payment to the Registrant in order to receive actual shares, which is the same restriction that applied to
the shares under the 2013 Plan. Another 400,000 shares previously authorized under the 2013 Plan have been de-authorized and will
not be rolled over into the Plan. The Registrant may, in its discretion, use either treasury shares or authorized but unissued
shares for awards.

[0001144204-18-006014:8k_body:5]
No awards may be granted under the Plan after February 2, 2023,
which is five years after its approval by the Registrant’s shareholders, or such earlier date as the Plan may be terminated
by the Registrant’s Board of Directors or the Committee.
