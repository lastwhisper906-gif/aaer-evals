# ESE notes — 0001144204-18-006187


## us-gaap:ScheduleOfWeightedAverageNumberOfSharesTableTextBlock

[0001144204-18-006187:notes:1]
[same as prior period, unchanged from 0001144204-17-041277:notes:20]

[0001144204-18-006187:notes:2]
|  |  | Three Months Ended December 31, |  |
|  |  | 2017 |  | 2016 |  |
| Weighted Average Shares Outstanding - Basic |  |  | 25,836 |  |  | 25,720 |  |
| Dilutive Options and Restricted Shares |  |  | 244 |  |  | 259 |  |
| Adjusted Shares - Diluted |  |  | 26,080 |  |  | 25,979 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001144204-18-006187:notes:3]
Inventories consist of the following:

[0001144204-18-006187:notes:4]
| (In thousands) |  | December 31, 2017 |  | September 30, 2017 |  |
| Finished goods |  | $ | 29,013 |  |  | 28,127 |  |
| Work in process |  |  | 46,668 |  |  | 43,750 |  |
| Raw materials |  |  | 54,898 |  |  | 52,638 |  |
| Total inventories |  | $ | 130,579 |  |  | 124,515 |  |


## us-gaap:ScheduleOfIntangibleAssetsAndGoodwillTableTextBlock

[0001144204-18-006187:notes:5]
Included on the Company’s Consolidated Balance Sheets at December 31, 2017 and September 30, 2017 are the following intangible assets gross carrying amounts and accumulated amortization:

[0001144204-18-006187:notes:6]
| (Dollars in thousands) |  | December 31, 2017 |  | September 30, 2017 |  |
| Goodwill |  | $ | 378,510 |  |  | 377,879 |  |
| Intangible assets with determinable lives: |  |  |  |  |  |  |  |
| Patents |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 928 |  |  | 928 |  |
| Less accumulated amortization |  |  | 757 |  |  | 750 |  |
| Net |  | $ | 171 |  |  | 178 |  |
| Capitalized software |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 63,842 |  |  | 63,007 |  |
| Less accumulated amortization |  |  | 36,081 |  |  | 34,382 |  |
| Net |  | $ | 27,761 |  |  | 28,625 |  |
| Customer relationships |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 182,266 |  |  | 181,891 |  |
| Less accumulated amortization |  |  | 39,922 |  |  | 37,364 |  |
| Net |  | $ | 142,344 |  |  | 144,527 |  |
| Other |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 5,336 |  |  | 5,373 |  |
| Less accumulated amortization |  |  | 1,565 |  |  | 1,383 |  |
| Net |  | $ | 3,771 |  |  | 3,990 |  |
| Intangible assets with indefinite lives: |  |  |  |  |  |  |  |
| Trade names |  | $ | 173,531 |  |  | 173,813 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0001144204-18-006187:notes:7]
The changes in the carrying amount of goodwill attributable to each business segment for the three months ended December 31, 2017 is as follows:

[0001144204-18-006187:notes:8]
| (Dollars in millions) |  | USG |  | Test |  | Filtration |  | Packaging |  | Total |  |
| Balance as of September 30, 2017 |  |  | 250.2 |  |  | 34.1 |  |  | 73.7 |  |  | 19.9 |  |  | 377.9 |  |
| Acquisition activity – working capital adj |  |  | 0.2 |  |  | - |  |  | - |  |  | - |  |  | 0.2 |  |
| Foreign currency translation and other |  |  | - |  |  | - |  |  | - |  |  | 0.4 |  |  | 0.4 |  |
| Balance as of December 31, 2017 |  | $ | 250.4 |  |  | 34.1 |  |  | 73.7 |  |  | 20.3 |  |  | 378.5 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001144204-18-006187:notes:9]
| 8. | INCOME TAX EXPENSE |

[0001144204-18-006187:notes:10]
Income tax benefit in the first quarter of 2018 was $21.9 million compared to income tax expense of $5.4 million in the first quarter of 2017. The first quarter 2018 effective income tax rate was (170.8%) compared to  33.5% in the first quarter of 2017. H.R. 1, Tax Cuts and Jobs Act (“TCJA”), was signed into law on December 22, 2017. The total impact of the TCJA in the first quarter of 2018 was a net benefit of $25.1 million. The impacts were as follows: First, the Company’s 2018 federal statutory rate dropped from  35.0% to  24.5% which requires an adjustment to the value of its deferred tax assets and liabilities since the first quarter of 2018 is the period that includes the enactment date. This adjustment ($30.3 million provisional amount) favorably impacted the first quarter effective tax rate by  236.8%. Second, the TCJA subjects the Company’s cumulative foreign earnings to federal income tax ($2.9 million provisional amount) which unfavorably impacted the first quarter effective tax rate by  22.8%. The Company also recorded a $2.3 million provisional estimate of the income tax effects of the future repatriation of the cumulative earnings of its foreign subsidiaries which unfavorably impacted the first quarter effective tax rate by  18.3%.

[0001144204-18-006187:notes:11]
Staff Accounting Bulletin No. 118 (SAB 118) was issued by the SEC effective December 22, 2017. SAB 118 allows registrants to record provisional amounts of the income tax effects of the TCJA where the information necessary to complete the accounting under ASC Topic 740 is not available but the amounts are based on reasonable estimates. SAB 118 permits registrants to record adjustments to its provisional amounts during the measurement period (which cannot exceed one year).

[0001144204-18-006187:notes:12]
The Company was able to determine reasonable estimates of the TCJA income tax effects. However, the Company was unable to complete the accounting under ASC Topic 740 for the change in the value of the Company’s deferred tax assets and liabilities as it needs more time to collect and analyze information primarily related to depreciation expense, pension liability, and percentage of completion revenue recognition. The Company was also unable to complete the accounting under ASC Topic 740 for the income tax effects of subjecting the Company’s cumulative foreign earnings to federal income tax as it needs more time to collect and analyze information to compute the cumulative balance of earnings subject to the tax and the amount of foreign tax credit that is available to offset the tax.

[0001144204-18-006187:notes:13]
Since the TCJA subjected the Company’s cumulative foreign earnings to U.S. tax, repatriation of those earnings generally provides that no additional federal tax will be imposed. However, the permissible amount of repatriation can be restricted by local law and a repatriation can result in tax expense due to local country withholding tax, U.S. state tax, and changes in foreign exchange rates. The Company is evaluating these considerations to determine the amount of its foreign subsidiaries’ cumulative earnings it intends to indefinitely reinvest.

[0001144204-18-006187:notes:14]
The TCJA includes a tax on global intangible low-taxed income (“GILTI”). The Company expects it will be subject to this tax. At its January 10, 2018 meeting, the FASB staff indicated that companies should make and disclose a policy election as to whether they will recognize deferred taxes for basis differences expected to reverse as GILTI or whether they will account for GILTI as period costs if and when incurred. Because there are interpretative questions associated with the approach that involves recognizing deferred taxes, the Company will undertake an evaluation of these questions and make the accounting policy election during the SAB 118 measurement period.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001144204-18-006187:notes:15]
Management evaluates and measures the performance of its reportable segments based on “Net Sales” and “EBIT”, which are detailed in the table below. EBIT is defined as earnings before interest and taxes.

[0001144204-18-006187:notes:16]
| (In thousands) |  | Three Months Ended December 31, |  |
|  |  | 2017 |  | 2016 |  |
| NET SALES |  |  |  |  |  |  |  |
| Filtration |  | $ | 60,035 |  |  | 58,785 |  |
| Test |  |  | 37,530 |  |  | 33,827 |  |
| USG |  |  | 55,754 |  |  | 35,556 |  |
| Technical Packaging |  |  | 20,176 |  |  | 18,200 |  |
| Consolidated totals |  | $ | 173,495 |  |  | 146,368 |  |
| EBIT |  |  |  |  |  |  |  |
| Filtration |  | $ | 9,645 |  |  | 10,726 |  |
| Test |  |  | 2,596 |  |  | 2,425 |  |
| USG |  |  | 10,651 |  |  | 9,674 |  |
| Technical Packaging |  |  | 965 |  |  | 1,031 |  |
| Corporate (loss) |  |  | (8,871) |  |  | (7,047) |  |
| Consolidated EBIT |  |  | 14,986 |  |  | 16,809 |  |
| Less: Interest expense, net |  |  | (2,185) |  |  | (684) |  |
| Earnings before income taxes |  | $ | 12,801 |  |  | 16,125 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001144204-18-006187:notes:17]
| 9. | SHAREHOLDERS’ EQUITY |

[0001144204-18-006187:notes:18]
The change in shareholders’ equity for the first three months of 2018 is shown below (in thousands):

[0001144204-18-006187:notes:19]
| Balance at September 30, 2017 |  | $ | 671,918 |  |
| Net earnings |  |  | 34,671 |  |
| Other comprehensive income |  |  | 1,305 |  |
| Cash dividends |  |  | (2,067) |  |
| Stock compensation plans |  |  | 1,242 |  |
| Balance at December 31, 2017 |  | $ | 707,069 |  |


## us-gaap:ScheduleOfDebtTableTextBlock

[0001144204-18-006187:notes:20]
The Company’s debt is summarized as follows:

[0001144204-18-006187:notes:21]
| (In thousands) |  | December 31, 2017 |  | September 30, 2017 |  |
| Total borrowings |  | $ | 260,000 |  |  | 275,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 240,000 |  |  | 255,000 |  |


## us-gaap:ScheduleOfChangesInProjectedBenefitObligationsTableTextBlock

[0001144204-18-006187:notes:22]
A summary of net periodic benefit expense for the Company’s defined benefit plans for the three-month periods ended December 31, 2017 and 2016 is shown in the following table. Net periodic benefit cost for each period presented is comprised of the following:

[0001144204-18-006187:notes:23]
|  |  | Three Months Ended December 31, |  |
| (In thousands) |  | 2017 |  | 2016 |  |
| Defined benefit plans |  |  |  |  |  |  |  |
| Interest cost |  | $ | 820 |  |  | 965 |  |
| Expected return on assets |  |  | (975) |  |  | (1,094) |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost |  |  | - |  |  | 3 |  |
| Actuarial loss |  |  | 549 |  |  | 505 |  |
| Net periodic benefit cost |  | $ | 394 |  |  | 379 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001144204-18-006187:notes:24]
| 10. | RETIREMENT PLANS |


## us-gaap:ScheduleOfNotionalAmountsOfOutstandingDerivativePositionsTableTextBlock

[0001144204-18-006187:notes:25]
The following is a summary of the notional transaction amounts and fair values for the Company’s outstanding derivative financial instruments by risk category and instrument type as of December 31, 2017:

[0001144204-18-006187:notes:26]
| (In thousands) |  | Notional amount |  |  |  | Fair Value (US$) |  | Float Rate |  | Fix Rate |  |
| Forward contracts |  |  | 1,859 |  | GBP |  |  | (156) |  |  |  |  |  |  |  |
| Forward contracts |  |  | 5,250 |  | USD |  |  | 33 |  |  |  |  |  |  |  |
| Forward contracts |  |  | 200 |  | EUR |  |  | (10) |  |  |  |  |  |  |  |
| Interest rate swap |  |  | 150,000 |  | USD |  |  | (80) |  |  | 1.51 | % |  | 1.80 | % |
| Interest rate swap * |  |  | 150,000 |  | USD |  |  | 28 |  |  | N/A |  |  | 2.09 | % |
| Interest rate swap ** |  |  | 150,000 |  | USD |  |  | (20) |  |  | N/A |  |  | 2.24 | % |

[0001144204-18-006187:notes:27]
*This swap represents a forward contract and will be effective in November 2018.

[0001144204-18-006187:notes:28]
**This swap represents a forward contract and will be effective in November 2019.


## us-gaap:ScheduleOfDerivativeLiabilitiesAtFairValueTableTextBlock

[0001144204-18-006187:notes:29]
The Company’s forward contracts are classified within Level 2 of the valuation hierarchy in accordance with FASB Accounting Standards Codification (ASC) 825, as presented below as of December 31, 2017:

[0001144204-18-006187:notes:30]
| (In thousands) |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Forward contracts and swaps |  | $ | - |  |  | (205) |  | $ | - |  |  | (205) |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001144204-18-006187:notes:31]
| 1. | BASIS OF PRESENTATION |

[0001144204-18-006187:notes:32]
The accompanying consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP). For further information, refer to the consolidated financial statements and related notes included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2017.

[0001144204-18-006187:notes:33]
The Company’s results for the three-month periods ended December 31, 2017 are not necessarily indicative of the results for the entire 2018 fiscal year. References to the first quarters of 2018 and 2017 represent the fiscal quarters ended December 31, 2017 and 2016, respectively.

[0001144204-18-006187:notes:34]
[same as prior period, unchanged from 0001144204-17-041277:notes:4]


## us-gaap:EarningsPerShareTextBlock

[0001144204-18-006187:notes:35]
| 2. | EARNINGS PER SHARE (EPS) |

[0001144204-18-006187:notes:36]
Basic EPS is calculated using the weighted average number of common shares outstanding during the period. Diluted EPS is calculated using the weighted average number of common shares outstanding during the period plus shares issuable upon the assumed exercise of dilutive common share options and vesting of performance-accelerated restricted shares (restricted shares) by using the treasury stock method. There are no anti-dilutive shares.  The number of shares used in the calculation of earnings per share for each period presented is as follows (in thousands):


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001144204-18-006187:notes:37]
| 3. | SHARE-BASED COMPENSATION |

[0001144204-18-006187:notes:38]
[same as prior period, unchanged from 0001144204-17-041277:notes:23]

[0001144204-18-006187:notes:39]
[same as prior period, unchanged from 0001144204-17-041277:notes:24]

[0001144204-18-006187:notes:40]
Compensation expense related to the restricted share awards was $1.1 million and $1.2 million for the three-month periods ended December 31, 2017 and 2016, respectively. There were  337,325 non-vested shares outstanding as of December 31, 2017.

[0001144204-18-006187:notes:41]
[same as prior period, unchanged from 0001144204-17-041277:notes:26]

[0001144204-18-006187:notes:42]
Compensation expense related to the non-employee director grants was $0.3 million and $0.2 million for the three-month periods ended December 31, 2017 and 2016, respectively.

[0001144204-18-006187:notes:43]
The total share-based compensation cost that has been recognized in the results of operations and included within selling, general and administrative expenses (SG&A) was $1.4 million and $1.4 million for the three -month periods ended December 31, 2017 and 2016, respectively. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $0.4 million and $0.5 million for the three-month periods ended December 31, 2017 and 2016, respectively. As of December 31, 2017, there was $5.3 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a remaining weighted-average period of  1.3 years.


## us-gaap:InventoryDisclosureTextBlock

[0001144204-18-006187:notes:44]
| 4. | INVENTORIES |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001144204-18-006187:notes:45]
| 5. | GOODWILL AND OTHER INTANGIBLE ASSETS |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001144204-18-006187:notes:46]
| 6. | BUSINESS SEGMENT INFORMATION |

[0001144204-18-006187:notes:47]
The Company is organized based on the products and services that it offers, and classifies its business operations in four segments for financial reporting purposes: Filtration/Fluid Flow (Filtration), RF Shielding and Test (Test), Utility Solutions Group (USG) and Technical Packaging. The Filtration segment’s operations consist of PTI Technologies Inc. (PTI), VACCO Industries (VACCO), Crissair, Inc. (Crissair), Westland Technologies Inc. (Westland), and Mayday Manufacturing Co. and its affiliate Hi-Tech Metals, Inc. (collectively referred to as Mayday). The companies within this segment primarily design and manufacture specialty filtration products, including hydraulic filter elements used in commercial aerospace applications, unique filter mechanisms used in micro-propulsion devices for satellites and custom designed filters for manned and unmanned aircraft; manufacture elastomeric-based signature reduction solutions for the U.S. Navy; and manufacture landing gear components for the aerospace and defense industry. The Test segment’s operations consist primarily of ETS-Lindgren Inc. (ETS-Lindgren). ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy. The USG segment’s operations consist primarily of Doble Engineering Company (Doble), Morgan Schaffer Inc. (Morgan Schaffer), and NRG Systems, Inc. (NRG). Doble provides high-end, intelligent diagnostic test solutions for the electric power delivery industry and is a leading supplier of partial discharge testing instruments used to assess the integrity of high voltage power delivery equipment. Morgan Schaffer provides an integrated offering of dissolved gas analysis, oil testing, and data management solutions for the electric power industry. NRG designs and manufactures decision support tools for the renewable energy industry, primarily wind. The Technical Packaging segment’s operations consist of Thermoform Engineered Quality LLC (TEQ) and Plastique Limited and Plastique Sp. z o.o. (together, Plastique). The companies within this segment provide innovative solutions to the medical and commercial markets for thermoformed packages and specialty products using a wide variety of thin gauge plastics and pulp.

[0001144204-18-006187:notes:48]
[same as prior period, unchanged from 0001144204-17-041277:notes:41]

[0001144204-18-006187:notes:49]
The financial measure “EBIT” is presented in the above table and elsewhere in this Report. EBIT on a consolidated basis is a non-GAAP financial measure. Management believes that EBIT is useful in assessing the operational profitability of the Company’s business segments because it excludes interest and taxes, which are generally accounted for across the entire Company on a consolidated basis. EBIT is also one of the measures used by management in determining resource allocations within the Company as well as incentive compensation. A reconciliation of EBIT to GAAP net earnings is set forth in Item 2, Management’s Discussion and Analysis of Financial Condition and Results of Operations – EBIT.

[0001144204-18-006187:notes:50]
[same as prior period, unchanged from 0001144204-17-041277:notes:43]


## us-gaap:DebtDisclosureTextBlock

[0001144204-18-006187:notes:51]
| 7. | DEBT |

[0001144204-18-006187:notes:52]
The Company’s existing credit facility (“the Credit Facility”) matures December 21, 2020. The Credit Facility includes a $450 million revolving line of credit as well as provisions allowing for the increase of the facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of nine banks led by JPMorgan Chase Bank, N.A., as Administrative Agent.

[0001144204-18-006187:notes:53]
At December 31, 2017, the Company had approximately $181 million available to borrow under the Credit Facility, and a $250 million increase option, in addition to $41.6 million cash on hand. At December 31, 2017, the Company had $260 million of outstanding borrowings under the Credit Facility in addition to outstanding letters of credit of $9.0 million. The Company classified $20.0 million as the current portion of long-term debt as of December 31, 2017, as the Company intends to repay this amount within the next twelve month period; however, the Company has no contractual obligation to repay such amount during the next twelve month period.

[0001144204-18-006187:notes:54]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from  12.5 to  27.5 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a  65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were  2.74% and  1.61% for the three-month periods ending December 31, 2017 and 2016, respectively. At December 31, 2017, the Company was in compliance with all debt covenants.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001144204-18-006187:notes:55]
| 11. | DERIVATIVE FINANCIAL INSTRUMENTS |

[0001144204-18-006187:notes:56]
Market risks relating to the Company’s operations result primarily from changes in interest rates and changes in foreign currency exchange rates. The Company is exposed to market risk related to changes in interest rates and selectively uses derivative financial instruments, including forward contracts and swaps, to manage these risks. During 2016, the Company entered into several forward contracts to purchase pounds sterling (GBP) to hedge two deferred payments due in connection with the acquisition of Plastique. During the first quarter of 2018, the Company entered into three interest rate swaps with a notional amount of $150 million to hedge some of its exposure to variability in future LIBOR-based interest payments on variable rate debt. In addition, the Company’s Canadian subsidiary Morgan Schaffer enters into foreign exchange contracts to manage foreign currency risk as a portion of their revenue is denominated in U.S. dollars. The Company expects hedging gains or losses to be essentially offset by losses or gains on the related underlying exposures. All derivative instruments are reported in either accrued expenses or other receivables on the balance sheet at fair value. The interest rate swaps entered into during the first quarter of 2018 were not designated as cash flow hedges and, therefore, the gain or loss on the derivative is reflected in earnings each period.


## us-gaap:FairValueDisclosuresTextBlock

[0001144204-18-006187:notes:57]
| 12. | FAIR VALUE MEASUREMENTS |

[0001144204-18-006187:notes:58]
[same as prior period, unchanged from 0001144204-17-041277:notes:54]

[0001144204-18-006187:notes:59]
[same as prior period, unchanged from 0001144204-17-041277:notes:55]

[0001144204-18-006187:notes:60]
[same as prior period, unchanged from 0001144204-17-041277:notes:56]

[0001144204-18-006187:notes:61]
The Company has estimated the fair value of its financial instruments as of December 31, 2017 and September 30, 2017 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, debt and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001144204-18-006187:notes:62]
[same as prior period, unchanged from 0001144204-17-041277:notes:58]

[0001144204-18-006187:notes:63]
[same as prior period, unchanged from 0001144204-17-041277:notes:59]

[0001144204-18-006187:notes:64]
[same as prior period, unchanged from 0001144204-17-041277:notes:60]

[0001144204-18-006187:notes:65]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during the three-month period ended December 31, 2017.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001144204-18-006187:notes:66]
| 13. | NEW ACCOUNTING STANDARDS |

[0001144204-18-006187:notes:67]
In March 2017, the FASB issued ASU 2017-07, Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost, which updates ASC 715,  Compensation – Retirement Benefits. This update permits only the service cost component of net periodic pension and postretirement expense to be reported with other compensation costs, while all other components are required to be reported separately in other deductions, outside any subtotal of operating income. These updates are effective for fiscal years beginning after December 15, 2017, with early adoption permitted, and must be adopted on a retrospective basis. The updates change presentation only and will not impact the Company’s results of operations.

[0001144204-18-006187:notes:68]
In August 2017, the FASB issued ASU 2017-12, Targeted Improvements to Accounting for Hedge Activities, which updates ASC 815, Derivatives and Hedging. This update is intended to amend the hedge accounting model to enable entities to better align the economics of risk management activities and financial reporting. The updates eliminate the requirement to separately measure and report hedge ineffectiveness and simplify hedge documentation and effectiveness assessment requirements. These updates are effective for fiscal years beginning after December 15, 2018, with early adoption permitted, and must be adopted using a modified retrospective approach. These updates are not expected to materially impact the Company’s results of operations.

[0001144204-18-006187:notes:69]
In February 2016, the FASB issued ASU No. 2016-062, Leases (Topic 842), which, among other things, requires an entity to recognize lease assets and lease liabilities on the balance sheet and disclose key information about leasing arrangements. This standard will increase an entities’ reported assets and liabilities. The standard is effective for fiscal years beginning after December 15, 2018 and mandates a modified retrospective transition period for all entities. The Company is currently assessing the impact of this standard on its consolidated financial statements and related disclosures.

[0001144204-18-006187:notes:70]
In May 2014, the FASB issued ASU No. 2014-09,  Revenue from Contracts with Customers, which requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. This guidance has been further clarified and amended. The new standard will be effective for annual reporting periods beginning after December 15, 2017, and interim periods within those annual periods. The standard permits the use of either the retrospective or cumulative effect transition method. The Company is currently in the process of evaluating the effect that ASU 2014-09 will have on its consolidated financial statements and related disclosures. The Company has selected the Cumulative Effect method of transition to the new standard.
