# ESE note change history — 0001144204-17-041277 → 0001144204-18-006187


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-02-07):
[0001144204-18-006187:note_history:1]
| 1. | BASIS OF PRESENTATION |
  (was, 2017-08-08, similarity 0.9667):
[0001144204-17-041277:note_history:1]
|  | 1. | BASIS OF PRESENTATION |

- changed (2018-02-07):
[0001144204-18-006187:note_history:2]
The Company’s results for the three-month periods ended December 31, 2017 are not necessarily indicative of the results for the entire 2018 fiscal year. References to the first quarters of 2018 and 2017 represent the fiscal quarters ended December 31, 2017 and 2016, respectively.
  (was, 2017-08-08, similarity 0.9165):
[0001144204-17-041277:note_history:2]
The Company’s results for the three and nine-month periods ended June 30, 2017 are not necessarily indicative of the results for the entire 2017 fiscal year. References to the third quarters of 2017 and 2016 represent the fiscal quarters ended June 30, 2017 and 2016, respectively.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-02-07):
[0001144204-18-006187:note_history:3]
| 7. | DEBT |
  (was, 2017-08-08, similarity 0.9231):
[0001144204-17-041277:note_history:3]
|  | 8. | DEBT |

- added (2018-02-07):
[0001144204-18-006187:note_history:4]
| (In thousands) |  | December 31, 2017 |  | September 30, 2017 |  |
| Total borrowings |  | $ | 260,000 |  |  | 275,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 240,000 |  |  | 255,000 |  |

- added (2018-02-07):
[0001144204-18-006187:note_history:5]
At December 31, 2017, the Company had approximately $181 million available to borrow under the Credit Facility, and a $250 million increase option, in addition to $41.6 million cash on hand. At December 31, 2017, the Company had $260 million of outstanding borrowings under the Credit Facility in addition to outstanding letters of credit of $9.0 million. The Company classified $20.0 million as the current portion of long-term debt as of December 31, 2017, as the Company intends to repay this amount within the next twelve month period; however, the Company has no contractual obligation to repay such amount during the next twelve month period.

- changed (2018-02-07):
[0001144204-18-006187:note_history:6]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from  12.5 to  27.5 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a  65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were  2.74% and  1.61% for the three-month periods ending December 31, 2017 and 2016, respectively. At December 31, 2017, the Company was in compliance with all debt covenants.
  (was, 2017-08-08, similarity 0.8684):
[0001144204-17-041277:note_history:6]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from  12.5 to  27.5 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a  65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were  2.11% and  1.90% for the three and nine-month periods ending June 30, 2017, respectively, and  1.50% and  1.58% for the corresponding periods of 2016. At June 30, 2017, the Company was in compliance with all debt covenants.

- removed (2018-02-07):
[0001144204-17-041277:note_history:7]
|  |  | June 30, |  | September 30, |  |
| (In thousands) |  | 2017 |  | 2016 |  |
| Total borrowings |  | $ | 265,000 |  |  | 110,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 245,000 |  |  | 90,000 |  |

- removed (2018-02-07):
[0001144204-17-041277:note_history:8]
At June 30, 2017, the Company had approximately $178 million available to borrow under the Credit Facility, and a $250 million increase option, in addition to $48.5 million cash on hand. At June 30, 2017, the Company had $265 million of outstanding borrowings under the Credit Facility in addition to outstanding letters of credit of $7.2 million. The Company classified $20.0 million as the current portion of long-term debt as of June 30, 2017, as the Company intends to repay this amount within the next twelve month period; however, the Company has no contractual obligation to repay such amount during the next twelve month period.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2018-02-07):
[0001144204-18-006187:note_history:9]
| (In thousands) |  | December 31, 2017 |  | September 30, 2017 |  |
| Total borrowings |  | $ | 260,000 |  |  | 275,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 240,000 |  |  | 255,000 |  |

- removed (2018-02-07):
[0001144204-17-041277:note_history:10]
|  |  | June 30, |  | September 30, |  |
| (In thousands) |  | 2017 |  | 2016 |  |
| Total borrowings |  | $ | 265,000 |  |  | 110,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 245,000 |  |  | 90,000 |  |
