# ESE MD&A — 0001144204-18-006187


## mdna

[0001144204-18-006187:mdna:1]
[same as prior period, unchanged from 0001144204-17-041277:mdna:1]

[0001144204-18-006187:mdna:2]
[same as prior period, unchanged from 0001144204-17-041277:mdna:2]

[0001144204-18-006187:mdna:3]
References to the first quarters of 2018 and 2017 represent
the three-month periods ended December 31, 2017 and 2016, respectively.

[0001144204-18-006187:mdna:4]
[same as prior period, unchanged from 0001144204-17-041277:mdna:4]

[0001144204-18-006187:mdna:5]
In the first quarter of 2018, sales, net earnings and diluted
earnings per share were $173.5 million, $34.7 million and $1.33 per share, respectively, compared to $146.4 million, $10.7 million
and $0.41 per share, respectively, in the first quarter of 2017. The increase in net earnings and diluted earnings per share in
the first quarter of 2018 as compared to the first quarter of 2017 was mainly due to the $25.1 million net tax benefit the Company
recorded as a result of the Tax Cuts and Jobs Act that was signed into law on December 22, 2017.

[0001144204-18-006187:mdna:6]
[same as prior period, unchanged from 0001144204-17-041277:mdna:6]

[0001144204-18-006187:mdna:7]
Net sales increased $27.1 million, or 18.5%, to $173.5 million
in the first quarter of 2018 from $146.4 million in the first quarter of 2017. The increase in net sales in the first quarter of
2018 as compared to the first quarter of 2017 was due to a $20.2 million increase in the USG segment, a $3.7 million increase in
the Test segment, a $2.0 million increase in the Technical Packaging segment and a $1.2 million increase in the Filtration segment.

[0001144204-18-006187:mdna:8]
[same as prior period, unchanged from 0001144204-17-041277:mdna:8]

[0001144204-18-006187:mdna:9]
In the first quarter of 2018, net sales of $60.0 million were
$1.2 million, or 2.1%, higher than net sales of $58.8 million in the first quarter of 2017. The sales increase in the first quarter
of 2018 compared to the first quarter of 2017 was mainly due to the $5.7 million sales contributions from the Company’s acquisition
of Mayday and a $2.2 million increase in net sales at VACCO due to higher shipments of its space products, partially offset by
a $3.9 million decrease in sales at Westland due to timing of orders, a $2.2 million decrease in sales at PTI due to lower aerospace
assembly and industrial/automotive shipments and a $0.6 million decrease in sales at Crissair due to lower aerospace shipments.

[0001144204-18-006187:mdna:10]
|  | 13 |

[0001144204-18-006187:mdna:11]
[same as prior period, unchanged from 0001144204-17-041277:mdna:11]

[0001144204-18-006187:mdna:12]
In the first quarter of 2018, net sales of $37.5 million were
$3.7 million, or 10.9%, higher than the $33.8 million recorded in the first quarter of 2017. The increase in the first quarter
of 2018 compared to the first quarter of 2017 was primarily due to higher sales from the segment’s U.S. operations due to
the timing of test and measurement chamber projects.

[0001144204-18-006187:mdna:13]
[same as prior period, unchanged from 0001144204-17-041277:mdna:13]

[0001144204-18-006187:mdna:14]
Net sales increased $20.2 million, or 56.8%, to $55.8 million
in the first quarter of 2018 from $35.6 million in the first quarter of 2017. The increase in the first quarter of 2018 compared
to the first quarter of 2017 was mainly driven by the $19 million sales contribution from the NRG, Morgan Schaffer and Vanguard
acquisitions and new products and software solutions at Doble.

[0001144204-18-006187:mdna:15]
[same as prior period, unchanged from 0001144204-17-041277:mdna:15]

[0001144204-18-006187:mdna:16]
In the first quarter of 2018, net sales of $20.2 million were
$2.0 million, or 10.9% higher than the $18.2 million recorded in the first quarter of 2017. The increase in the first quarter of
2018 compared to the first quarter of 2017 was mainly due to a $1.1 million increase in net sales at TEQ due to higher shipments
to medical customers and a $0.9 million increase in net sales at Plastique.

[0001144204-18-006187:mdna:17]
[same as prior period, unchanged from 0001144204-17-041277:mdna:17]

[0001144204-18-006187:mdna:18]
Backlog was $404.1 million at December 31, 2017 compared with
$377.1 million at September 30, 2017. The Company received new orders totaling $200.5 million in the first quarter of 2018 compared
to $182.9 million in the first quarter of 2017. Of the new orders received in the first quarter of 2018, $65.4 million related
to Filtration products, $58.3 million related to Test products, $57.6 million related to USG products, and $19.2 million related
to Technical Packaging products. Of the new orders received in the first quarter of 2017, $67.5 million related to Filtration products,
$56.0 million related to Test products, $39.5 million related to USG products, and $19.9 million related to Technical Packaging
products

[0001144204-18-006187:mdna:19]
[same as prior period, unchanged from 0001144204-17-041277:mdna:22]

[0001144204-18-006187:mdna:20]
Selling, general and administrative (SG&A) expenses for
the first quarter of 2018 were $42.2 million (24.3% of net sales), compared with $33.8 million (23.1% of net sales) for the first
quarter of 2017. The increase in SG&A expenses in the first quarter of 2018 compared to the first quarter of 2017 was mainly
due to an increase in the USG and Filtration segments due to the Company’s recent acquisitions, and additional sales and
marketing expenses at Doble to support future revenue growth.

[0001144204-18-006187:mdna:21]
|  | 14 |

[0001144204-18-006187:mdna:22]
[same as prior period, unchanged from 0001144204-17-041277:mdna:25]

[0001144204-18-006187:mdna:23]
Amortization of intangible assets was $4.4 million and $3.6
million for the first quarters of 2018 and 2017, respectively. Amortization expenses consist of amortization of acquired intangible
assets from acquisitions and other identifiable intangible assets (primarily software). The increase in amortization expense in
the first quarter of 2018 compared to the first quarter of 2017 was mainly due to an increase in amortization of intangibles related
to the Morgan Schaffer, NRG, and Mayday acquisitions.

[0001144204-18-006187:mdna:24]
OTHER EXPENSES (INCOME), NET

[0001144204-18-006187:mdna:25]
Other expenses, net, were $0.2 million in the first quarter
of 2018 compared to other income, net, of $0.8 million in the first quarter of 2017. There were no significant items in other expenses,
net, in the first quarter of 2018. The principal component of other income, net, in the first quarter of 2017 was $0.4 million
of income related to death benefit insurance proceeds from a former subsidiary.

[0001144204-18-006187:mdna:26]
[same as prior period, unchanged from 0001144204-17-041277:mdna:29]

[0001144204-18-006187:mdna:27]
The Company evaluates the performance of its operating segments
based on EBIT, and provides EBIT on a consolidated basis, which is a non-GAAP financial measure. Please refer to the discussion
of non-GAAP financial measures in Note 6 to the Consolidated Financial Statements, above. EBIT was $15.0 million (8.6% of net sales)
for the first quarter of 2018 compared to $16.8 million (11.5% of net sales) for the first quarter of 2017.

[0001144204-18-006187:mdna:28]
[same as prior period, unchanged from 0001144204-17-041277:mdna:31]

[0001144204-18-006187:mdna:29]
| (In thousands) |  | Three Months Ended December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Consolidated EBIT |  | $ | 14,986 |  |  |  | 16,809 |  |
| Less: Interest expense, net |  |  | (2,185 | ) |  |  | (684 | ) |
| Plus (Less): Income tax |  |  | 21,870 |  |  |  | (5,398 | ) |
| Net earnings |  | $ | 34,671 |  |  |  | 10,727 |  |

[0001144204-18-006187:mdna:30]
[same as prior period, unchanged from 0001144204-17-041277:mdna:33]

[0001144204-18-006187:mdna:31]
EBIT in the first quarter of 2018 was $9.6 million (16.1% of
net sales) compared to $10.7 million (18.2% of net sales) in the first quarter of 2017. The decrease in EBIT dollars and as a percent
of net sales in the first quarter of 2018 compared to the first quarter of 2017 was mainly due to lower sales volumes at Westland,
PTI and Crissair, partially offset by an increase in EBIT at Mayday and VACCO due to increased sales volumes at these subsidiaries.

[0001144204-18-006187:mdna:32]
[same as prior period, unchanged from 0001144204-17-041277:mdna:35]

[0001144204-18-006187:mdna:33]
EBIT in the first quarter of 2018 was $2.6 million (6.9% of
net sales) compared to $2.4 million (7.2% of net sales) in the first quarter of 2017. EBIT increased in the first quarter of 2018
compared to the first quarter of 2017 primarily due to increased sales volumes.

[0001144204-18-006187:mdna:34]
|  | 15 |

[0001144204-18-006187:mdna:35]
[same as prior period, unchanged from 0001144204-17-041277:mdna:38]

[0001144204-18-006187:mdna:36]
EBIT in the first quarter of 2018 was $10.7 million (19.1% of
net sales) compared to $9.7 million (27.1% of net sales) in the first quarter of 2017. The increase in EBIT in the first quarter
of 2018 compared to the first quarter of 2017 was mainly due to higher sales volumes as well as the EBIT contribution from NRG
(May 8, 2017 acquisition), Morgan Schaffer (May 25, 2017 acquisition) and Vanguard (August 30, 2017 acquisition). The decrease
in EBIT as a percent of net sales in the first quarter of 2018 compared to the first quarter of 2017 was primarily due to the change
in product mix as a result of the recent acquisitions of NRG, Morgan Schaffer and Vanguard.

[0001144204-18-006187:mdna:37]
[same as prior period, unchanged from 0001144204-17-041277:mdna:44]

[0001144204-18-006187:mdna:38]
EBIT in the first quarter of 2018 was $1.0 million (4.8% of
net sales) compared to $1.0 million (5.7% of net sales) in the first quarter of 2017. The decrease in EBIT as a percent of net
sales in the first quarter of 2018 compared to the first quarter of 2017 was mainly due to product mix at
Plastique.

[0001144204-18-006187:mdna:39]
[same as prior period, unchanged from 0001144204-17-041277:mdna:46]

[0001144204-18-006187:mdna:40]
Corporate costs included in EBIT were $8.9 million and $7.0
million in the first quarter of 2018 and 2017, respectively. The increase in Corporate costs in the first quarter of 2018 compared
to the first quarter of 2017 was primarily due to higher professional fees and an increase in amortization of intangible assets
related to recent acquisitions.

[0001144204-18-006187:mdna:41]
[same as prior period, unchanged from 0001144204-17-041277:mdna:48]

[0001144204-18-006187:mdna:42]
Interest expense, net was $2.2 million and $0.7 million in the
first quarter of 2018 and 2017, respectively. The increase in interest expense in the first quarter of 2018 compared to the first
quarter of 2017 was mainly due to higher average outstanding borrowings ($265.7 million compared to $

[0001144204-18-006187:mdna:43]
|  | 16 |

[0001144204-18-006187:mdna:44]
0.3 million) and higher
average interest rates (2.7% vs. 1.6%) as a result of the additional borrowings to fund the Company’s 20

[0001144204-18-006187:mdna:45]
|  | 17 |

[0001144204-18-006187:mdna:46]
acquisitions.

[0001144204-18-006187:mdna:47]
[same as prior period, unchanged from 0001144204-17-041277:mdna:50]

[0001144204-18-006187:mdna:48]
Income tax benefit in the first quarter of 20

[0001144204-18-006187:mdna:49]
|  | 18 |

[0001144204-18-006187:mdna:50]
was $21.9 million
compared to income tax expense of $5.4 million in the first quarter of 2017. The first quarter 2018 effective income tax rate was
(170.8%) compared to 33.5% in the first quarter of 2017. H.R. 1, Tax Cuts and Jobs Act (“TCJA”), was signed
into law on December 22, 2017. The total impact of the TCJA in the first quarter of 2018 was a net benefit of $25.1 million. The
impacts were as follows: First, the Company’s 2018 federal statutory rate dropped from 35.0% to 24.5% which requires an adjustment
to the value of its deferred tax assets and liabilities since the first quarter of 2018 is the period that includes the enactment
date. This adjustment ($30.3 million provisional amount) favorably impacted the first quarter effective tax rate by 236.8%. Second,
the TCJA subjects the Company’s cumulative foreign earnings to federal income tax ($2.9 million provisional amount) which
unfavorably impacted the first quarter effective tax rate by 22.8%. The Company also recorded a $2.3 million provisional estimate
of the income tax effects of the future repatriation of the cumulative earnings of its foreign subsidiaries which unfavorably impacted
the first quarter effective tax rate by 18.3%.

[0001144204-18-006187:mdna:51]
The Company was able to determine reasonable estimates of the
TCJA income tax effects. However, the Company was unable to complete the accounting under ASC Topic 740 for the change in the value
of the Company’s deferred tax assets and liabilities as it needs more time to collect and analyze information primarily related
to depreciation expense, pension liability, and percentage of completion revenue recognition. The Company was also unable to complete
the accounting under ASC Topic 740 for the income tax effects of subjecting the Company’s cumulative foreign earnings to
federal income tax as it needs more time to collect and analyze information to compute the cumulative balance of earnings subject
to the tax and the amount of foreign tax credit that is available to offset the tax.

[0001144204-18-006187:mdna:52]
Since the TCJA subjected the Company’s cumulative foreign
earnings to U.S. tax, repatriation of those earnings generally provides that no additional federal tax will be imposed. However,
the permissible amount of repatriation can be restricted by local law and a repatriation can result in tax expense due to local
country withholding tax, U.S. state tax, and changes in foreign exchange rates. The Company is evaluating these considerations
to determine the amount of its foreign subsidiaries’ cumulative earnings it intends to indefinitely reinvest.

[0001144204-18-006187:mdna:53]
[same as prior period, unchanged from 0001144204-17-041277:mdna:55]

[0001144204-18-006187:mdna:54]
The TCJA includes a tax on global intangible low-taxed income
(“GILTI”). The Company expects it will be subject to this tax. At its January 10, 2018 meeting, the FASB staff indicated
that companies should make and disclose a policy election as to whether they will recognize deferred taxes for basis differences
expected to reverse as GILTI or whether they will account for GILTI as period costs if and when incurred. Because there are interpretative
questions associated with the approach that involves recognizing deferred taxes, the Company will undertake an evaluation of these
questions and make the accounting policy election during the SAB 118 measurement period.

[0001144204-18-006187:mdna:55]
During the three-month period ended December 31, 2017, there
were no material changes in the unrecognized tax benefits. The Company does not anticipate a material change in the amount of unrecognized
tax benefits in the next twelve months.

[0001144204-18-006187:mdna:56]
TCJA moved the U.S. to a federal tax system that will no longer
tax dividends from foreign corporations to U.S. corporations. The cost of transitioning to this new tax system is a deemed repatriation
of cumulative foreign earnings, the “Foreign Earnings Toll Charge”, the estimated tax cost of which was recorded in
the first quarter of 2018. The actual repatriation of foreign earnings triggers foreign dividend withholding taxes and U.S. state
taxes, the estimated cost of which was recorded in the first quarter of 2018.

[0001144204-18-006187:mdna:57]
[same as prior period, unchanged from 0001144204-17-041277:mdna:56]

[0001144204-18-006187:mdna:58]
The Company’s overall financial position and liquidity
remains strong. Working capital (current assets less current liabilities) decreased to $

[0001144204-18-006187:mdna:59]
|  | 19 |

[0001144204-18-006187:mdna:60]
5.0 million at December 31, 2017 from
$197.8 million at September 30, 2017. Accounts receivable decreased $12.1 million primarily related to an $11.9 million decrease
within the Filtration segment due to timing of collections and lower sales volumes in the first quarter of 2018 compared to the
fourth quarter of 2017. Inventories increased by $6.1 million during this period mainly due to a $3.3 million increase within the
Filtration segment to support new aerospace platforms.

[0001144204-18-006187:mdna:61]
Net cash provided by operating activities was $17.8 million
and $15.7 million in the first quarter of 2018 and 2017, respectively.

[0001144204-18-006187:mdna:62]
Capital expenditures were $3.6 million and $7.0 million in the
first quarter of 2018 and 2017, respectively. The decrease in the first quarter of 2018 was mainly due to machinery and equipment
additions at VACCO ($1.7 million) and Plastique ($1.3 million) during the first quarter of 2017. In addition, the Company incurred
expenditures for capitalized software of $2.1 million and $1.4 million in the first quarter of 2018 and 2017, respectively.

[0001144204-18-006187:mdna:63]
Credit Facility

[0001144204-18-006187:mdna:64]
At December 31, 2017, the Company had approximately $181 million
available to borrow under its Credit Facility, a $250 million increase option, and $41.6 million cash on hand. At December 31,
2017, the Company had $260.0 million of outstanding borrowings under the Credit Facility in addition to outstanding letters of
credit of $9.0 million. Cash flow from operations and borrowings under the Company’s Credit Facility are expected to meet
the Company’s capital requirements and operational needs for the foreseeable future. The Company’s ability to access
the additional $250 million increase option of the facility is subject to acceptance by participating or other outside banks.

[0001144204-18-006187:mdna:65]
[same as prior period, unchanged from 0001144204-17-041277:mdna:66]

[0001144204-18-006187:mdna:66]
In March 2017, the FASB issued ASU 2017-07, Improving the
Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost, which updates ASC 715, Compensation
– Retirement Benefits. This update permits only the service cost component of net periodic pension and postretirement
expense to be reported with other compensation costs, while all other components are required to be reported separately in other
deductions, outside any subtotal of operating income. These updates are effective for fiscal years beginning after December 15,
2017, with early adoption permitted, and must be adopted on a retrospective basis. The updates change presentation only and will
not impact the Company’s results of operations.

[0001144204-18-006187:mdna:67]
In August 2017, the FASB issued ASU 2017-12, Targeted Improvements
to Accounting for Hedge Activities, which updates ASC 815, Derivatives and Hedging. This update is intended to amend
the hedge accounting model to enable entities to better align the economics of risk management activities and financial reporting.
The updates eliminate the requirement to separately measure and report hedge ineffectiveness and simplify hedge documentation and
effectiveness assessment requirements. These updates are effective for fiscal years beginning after December 15, 2018, with early
adoption permitted, and must be adopted using a modified retrospective approach. These updates are not expected to materially impact
the Company’s results of operations.

[0001144204-18-006187:mdna:68]
In February 2016, the FASB issued ASU No. 2016-062, Leases
(Topic 842), which, among other things, requires an entity to recognize lease assets and lease liabilities on the balance sheet
and disclose key information about leasing arrangements. This standard will increase an entities’ reported assets and liabilities.
The standard is effective for fiscal years beginning after December 15, 2018 and mandates a modified retrospective transition period
for all entities. The Company is currently assessing the impact of this standard on its consolidated financial statements and related
disclosures.

[0001144204-18-006187:mdna:69]
In May 2014, the FASB issued ASU No. 2014-09, Revenue from
Contracts with Customers, which requires an entity to recognize the amount of revenue to which it expects to be entitled for
the transfer of promised goods or services to customers. This guidance has been further clarified and amended. The new standard
will be effective for annual reporting periods beginning after December 15, 2017, and interim periods within those annual periods.
The standard permits the use of either the retrospective or cumulative effect transition method. The Company is currently in the
process of evaluating the effect that ASU 2014-09 will have on its consolidated financial statements and related disclosures. The
Company has selected the Cumulative Effect method of transition to the new standard.

[0001144204-18-006187:mdna:70]
[same as prior period, unchanged from 0001144204-17-041277:mdna:78]

[0001144204-18-006187:mdna:71]
[same as prior period, unchanged from 0001144204-17-041277:mdna:72]

[0001144204-18-006187:mdna:72]
A dividend of $0.08 per share, totaling $2.1 million, was paid
on October 17, 2017 to stockholders of record as of October 3, 2017. Following the end of the first quarter, the quarterly dividend
of $0.08 per share, or $2.1 million, was paid on January 19, 2018 to stockholders of record as of January 4, 2018.

[0001144204-18-006187:mdna:73]
[same as prior period, unchanged from 0001144204-17-041277:mdna:76]

[0001144204-18-006187:mdna:74]
Management projects 2018 GAAP EPS to be in the range of $3.55
to $3.65 per share and Adjusted EPS to be in the range of $2.65 to $2.75 per share, reflecting the profit contributions from the
recent acquisitions, additional depreciation and amortization charges, higher interest costs, the discrete cost reduction charges
in USG and Filtration described below and, adjusting for the first quarter 2018 one-time / incremental net tax benefits resulting
from U.S. Tax Reform and the cost reduction charges described below. Management expects the 2018 second quarter GAAP EPS to be
in the range of $0.30 to $0.35 per share (including approximately $2 million to $3 million of pretax charges in the USG and Filtration
segments relating to certain cost reduction initiatives) and Adjusted EPS to be in the range of $0.38 to $0.43 per share.

[0001144204-18-006187:mdna:75]
[same as prior period, unchanged from 0001144204-17-041277:mdna:79]

[0001144204-18-006187:mdna:76]
Management has evaluated the accounting policies used in the
preparation of the Company’s financial statements and related notes and believes those policies to be reasonable and appropriate.
Certain of these accounting policies require the application of significant judgment by Management in selecting appropriate assumptions
for calculating financial estimates. By their nature, these judgments are subject to an inherent degree of uncertainty. These judgments
are based on historical experience, trends in the industry, information provided by customers and information available from other
outside sources, as appropriate. The most significant areas involving Management judgments and estimates may be found in the Critical
Accounting Policies section of Management’s Discussion and Analysis.

[0001144204-18-006187:mdna:77]
[same as prior period, unchanged from 0001144204-17-041277:mdna:81]

[0001144204-18-006187:mdna:78]
Contingencies

[0001144204-18-006187:mdna:79]
As a normal incident of the business in which the Company is
engaged, various claims, charges and litigation are asserted or commenced against the Company. Additionally, the Company is currently
involved in various stages of investigation and remediation relating to environmental matters. In the opinion of Management, the
aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company,
are adequately reserved, are covered by insurance, or would not have a material adverse effect on the Company’s results from
operations, capital expenditures, or competitive position.

[0001144204-18-006187:mdna:80]
[same as prior period, unchanged from 0001144204-17-041277:mdna:84]

[0001144204-18-006187:mdna:81]
18

[0001144204-18-006187:mdna:82]
Investors are cautioned that such statements are only predictions
and speak only as of the date of this Form 10-Q, and the Company undertakes no duty to update them except as may be required by
applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in
the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment,
including but not limited to those described in Item 1A, “Risk Factors,” of the Company’s Annual Report on Form
10-K for the fiscal year ended September 30, 2017, and the following: the impacts of natural disasters on the Company’s operations
and those of the Company’s customers and suppliers; the timing and content of future contract awards or customer orders;
the appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer
contracts or orders; financial exposure in connection with Company guarantees of certain Aclara contracts; weakening of economic
conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies;
competition; intellectual property rights; technical difficulties; the availability of select acquisitions; delivery delays or
defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability
of certain raw materials; labor disputes; final analysis of the impacts of the TCJA; changes in U.S. tax laws and regulations;
other changes in laws and regulations including but not limited to changes in accounting standards and foreign taxation; changes
in interest rates; costs relating to environmental matters arising from current or former facilities; uncertainty regarding the
ultimate resolution of current disputes, claims, litigation or arbitration; and the integration of recently acquired businesses.
