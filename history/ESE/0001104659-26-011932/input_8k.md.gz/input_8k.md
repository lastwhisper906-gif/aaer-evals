# ESE 8-K — 0001104659-26-010899 filed 2026-02-05

## item codes, every 8-K on or before 2026-02-09

- 2026-02-05 0001104659-26-010899 — 2.02, 5.07, 7.01, 9.01
- 2025-11-20 0001104659-25-114614 — 2.02, 5.02, 7.01, 9.01
- 2025-08-07 0001104659-25-075202 — 2.02, 7.01, 9.01
- 2025-05-07 0001104659-25-045548 — 2.02, 7.01, 9.01
- 2025-04-28 0001104659-25-039819 — 2.01, 7.01, 9.01
- 2025-02-06 0001104659-25-010118 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2024-11-14 0001104659-24-118951 — 2.02, 5.02, 7.01, 9.01
- 2024-10-18 0001104659-24-109788 — 5.02
- 2024-10-01 0001104659-24-104776 — 5.02
- 2024-08-07 0001104659-24-086768 — 1.01, 2.02, 5.02, 7.01, 9.01
- 2024-07-08 0001104659-24-078312 — 1.01, 7.01, 9.01
- 2024-05-09 0001104659-24-059341 — 2.02, 7.01, 9.01
- 2024-02-08 0001104659-24-012294 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2023-11-20 0001104659-23-119761 — 5.02, 9.01
- 2023-11-16 0001104659-23-119126 — 2.02, 7.01, 9.01
- 2023-10-03 0001104659-23-106090 — 5.02, 9.01
- 2023-09-06 0001104659-23-098463 — 1.01, 2.03, 9.01
- 2023-08-08 0001104659-23-088847 — 2.02, 7.01, 9.01
- 2023-07-06 0001104659-23-078571 — 5.02, 8.01, 9.01
- 2023-05-09 0001104659-23-057736 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2023-05-05 0001104659-23-056387 — 5.02, 9.01
- 2023-02-08 0001104659-23-014539 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2023-01-06 0001104659-23-001859 — 5.02, 9.01
- 2022-11-22 0001104659-22-121229 — 5.02, 5.03, 8.01, 9.01
- 2022-11-17 0001104659-22-119898 — 2.02, 7.01, 9.01
- 2022-09-12 0001104659-22-099248 — 5.02, 7.01, 9.01
- 2022-08-08 0001104659-22-087247 — 2.02, 5.02, 7.01, 9.01
- 2022-05-09 0001104659-22-057524 — 2.02, 5.02, 7.01, 9.01
- 2022-02-08 0001104659-22-013878 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2021-12-03 0001104659-21-146361 — 4.01, 9.01 — amendment, the index does not say of what
- 2021-11-24 0001104659-21-143568 — 4.01, 9.01
- 2021-11-23 0001104659-21-142871 — 5.02, 8.01
- 2021-11-18 0001104659-21-141206 — 2.02, 7.01, 9.01
- 2021-08-09 0001104659-21-102150 — 2.02, 7.01, 9.01
- 2021-05-04 0001104659-21-060985 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2021-04-05 0001104659-21-046581 — 5.02, 9.01
- 2021-02-08 0001104659-21-013712 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2020-12-09 0001104659-20-133674 — 5.02, 9.01
- 2020-12-07 0001104659-20-132861 — 5.02, 7.01, 9.01
- 2020-11-19 0001104659-20-127352 — 2.02, 5.02, 7.01, 9.01
- 2020-08-10 0001104659-20-092734 — 2.02, 7.01, 9.01
- 2020-05-06 0001104659-20-057442 — 2.02, 7.01, 8.01, 9.01
- 2020-02-04 0001104659-20-010640 — 2.02, 5.07, 7.01, 9.01
- 2020-01-07 0001104659-20-001789 — 2.01, 9.01
- 2019-11-19 0001104659-19-065437 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2019-11-18 0001104659-19-065096 — 1.01, 2.02, 7.01, 9.01
- 2019-09-30 0001144204-19-046523 — 1.01, 1.02, 2.03, 9.01
- 2019-08-08 0001144204-19-038567 — 2.02, 7.01, 9.01
- 2019-05-07 0001144204-19-024241 — 2.02, 5.02, 7.01, 9.01
- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2026-02-09

- none on or before 2026-02-09

## item 2.02 — earnings release, exhibit 99.1

[0001104659-26-010899:8k_2_02:1]
EX-99.1
3
tm264950d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-26-010899:8k_2_02:2]
Exhibit 99.1

[0001104659-26-010899:8k_2_02:3]
| NEWS FROM |  |

[0001104659-26-010899:8k_2_02:4]
For more information contact:

[0001104659-26-010899:8k_2_02:5]
Kate Lowrey - VP of Investor Relations

[0001104659-26-010899:8k_2_02:6]
(314) 213-7277 / klowrey@escotechnologies.com

[0001104659-26-010899:8k_2_02:7]
ESCO REPORTS
FIRST QUARTER FISCAL 2026 RESULTS

[0001104659-26-010899:8k_2_02:8]
- Q1 Sales
increase 35% to $290 Million

[0001104659-26-010899:8k_2_02:9]
- Q1 Entered
Orders increase 143% to $557 Million

[0001104659-26-010899:8k_2_02:10]
- Q1 GAAP
EPS from Continuing Operations increases 41% to $1.11 -

[0001104659-26-010899:8k_2_02:11]
- Q1 Adjusted
EPS from Continuing Operations increases 73% to $1.64 -

[0001104659-26-010899:8k_2_02:12]
ST. LOUIS, February 5, 2026 –
ESCO Technologies Inc. (NYSE: ESE) (ESCO, or the Company) today reported its operating results for the first quarter ended December 31,
2025 (Q1 2026).

[0001104659-26-010899:8k_2_02:13]
Operating Highlights

[0001104659-26-010899:8k_2_02:14]
|  | · | Q1 2026 Sales increased $75 million (35.0 percent) to $290 million compared to $215 million in Q1 2025. Q1 2026 organic sales increased $24 million (11.4 percent) and Maritime contributed $51 million (23.6 percent) of revenue growth in the quarter. |

[0001104659-26-010899:8k_2_02:15]
|  | · | Q1 2026 GAAP EPS from Continuing Operations increased 40.5 percent to $1.11 per share compared to $0.79 per share in Q1 2025. Q1 2026 Adjusted EPS from Continuing Operations increased 72.6 percent to $1.64 per share compared to $0.95 per share in Q1 2025. |

[0001104659-26-010899:8k_2_02:16]
|  | · | Q1 2026 Entered Orders increased $328 million (143.0 percent) to $557 million (book-to-bill of 1.92x), resulting in record backlog of $1.4 billion. |

[0001104659-26-010899:8k_2_02:17]
|  | · | Net Cash provided by Operating Activities from Continuing Operations was $69 million in Q1 2026, an increase of $40 million compared to the prior year period. |

[0001104659-26-010899:8k_2_02:18]
Bryan Sayler, Chief Executive Officer
and President, commented, “Our fiscal year got off to an outstanding start as we delivered over $550 million in orders, 35 percent
revenue growth, 320 basis points of Adjusted EBITDA margin expansion, and a 73 percent increase in Adjusted EPS compared to the prior
year. We continue to see favorable end-market conditions, which is reflected in the excellent orders and sales performance. Organic orders
increased by 39 percent as all three businesses continue to see a positive environment for growth.

[0001104659-26-010899:8k_2_02:19]
“Our solid operating results were
driven by disciplined execution from our team. This performance highlights the strength of our strategic positioning and our capacity
to generate sustainable value in attractive markets. It was a great way to start the year, with continuing momentum across our businesses
giving us the confidence to raise our full year earnings guidance.”

[0001104659-26-010899:8k_2_02:20]
Segment Performance

[0001104659-26-010899:8k_2_02:21]
Aerospace & Defense (A&D)

[0001104659-26-010899:8k_2_02:22]
|  | · | Q1 2026 sales increased $62 million (75.7 percent) to $144 million from $82 million in Q1 2025. Organic sales increased $11 million (13.9 percent) and Maritime added $51 million (61.8 percent) of revenue growth in the quarter. Quarterly sales growth was led by strong performance in Navy, along with military and commercial aerospace. |

[0001104659-26-010899:8k_2_02:23]
|  | · | Q1 2026 EBIT increased $20.5 million to $38.0 million from $17.5 million in Q1 2025. Adjusted EBIT increased $20.6 million in Q1 2026 to $38.1 million (26.5 percent margin) from $17.5 million (21.3 percent margin) in Q1 2025. The 118 percent increase in Adjusted EBIT was driven by the addition of Maritime as well as leverage on higher volume, price increases, and favorable mix, partially offset by inflationary pressures. |

[0001104659-26-010899:8k_2_02:24]
|  | · | Q1 2026 entered orders increased $307 million (410.8 percent) to $382.3 million (book-to-bill of 2.66), resulting in record backlog of over $1.0 billion. This orders strength was broad based, including $238 million at Maritime, Virginia Class Block VI funding at Globe, and robust commercial and defense aerospace demand. |

[0001104659-26-010899:8k_2_02:25]
Utility Solutions Group (USG)

[0001104659-26-010899:8k_2_02:26]
|  | · | Q1 2026 sales increased $1 million (1.0 percent) to $87 million from $86 million in Q1 2025. Doble sales increased by $4 million (5.8 percent) while NRG sales decreased by $3 million (22.4 percent). Sales growth in the quarter was driven by higher condition monitoring, offline test equipment, and services revenue at Doble, partially offset by lower renewables revenue at NRG. |

[0001104659-26-010899:8k_2_02:27]
|  | · | Q1 2026 EBIT decreased $1.0 million to $19.5 million from $20.5 million in Q1 2025. Adjusted EBIT decreased $0.9 million in Q1 2026 to $19.6 million (22.4 percent margin) from $20.5 million (23.6 percent margin) in Q1 2025. The decrease in Adjusted EBIT was driven by deleverage on lower renewables volume, unfavorable mix, and inflationary pressures, partially offset by price increases and leverage on higher volume at Doble. |

[0001104659-26-010899:8k_2_02:28]
|  | · | Q1 2026 entered orders increased $9 million (10.3 percent) to $99 million (book-to-bill of 1.13), resulting in backlog of $155 million. Doble orders increased $11 million (14.8 percent) to $84 million due to strength in services, condition monitoring and offline test equipment orders. NRG orders decreased $2 million (10.2 percent) to $15 million compared to Q1 2025, primarily due to lower wind orders in the U.S. and China, partially offset by higher solar orders. |

[0001104659-26-010899:8k_2_02:29]
RF Test & Measurement (Test)

[0001104659-26-010899:8k_2_02:30]
|  | · | Q1 2026 sales increased $12 million (26.7 percent) to $58 million from $46 million in Q1 2025. Sales growth in the quarter was largely driven by higher U.S. and European Test & Measurement (EMC) and filters volume. |

[0001104659-26-010899:8k_2_02:31]
|  | · | Q1 2026 EBIT increased $3.6 million to $8.0 million from $4.4 million in Q1 2025. Q1 2026 Adjusted EBIT increased $3.1 million to $8.0 million (13.8 percent margin) from $4.9 million (10.6 percent margin) in Q1 2025. The 65 percent increase in Adjusted EBIT margin was driven by leverage on higher volume and price increases, partially offset by inflationary pressures. |

[0001104659-26-010899:8k_2_02:32]
|  | · | Q1 2026 entered orders increased $11 million (17.3 percent) to $76 million (book-to-bill of 1.30), resulting in ending backlog of $205 million. Orders strength in the quarter was primarily driven by higher Test & Measurement (EMC), industrial shielding, and medical shielding orders in the U.S and a large Test and Measurement (EMC) chamber order in Japan. |

[0001104659-26-010899:8k_2_02:33]
Business Outlook – FY 2026

[0001104659-26-010899:8k_2_02:34]
FY 2026 Sales and Adjusted EPS Guidance
Update:

[0001104659-26-010899:8k_2_02:35]
|  | · | FY 2026 full year revenue guidance is being increased by $20 million and is now expected to be in the range of $1.29 to $1.33 billion (18 to 21 percent sales growth over the prior year). |

[0001104659-26-010899:8k_2_02:36]
|  | o | A&D revenue guidance is being increased and is expected to grow 34 to 39 percent (from 33 to 38 percent) including 7 to 9 percent organic growth (from 6 to 8 percent) plus Maritime revenue of $230 to $245 million |

[0001104659-26-010899:8k_2_02:37]
|  | o | Maintaining USG revenue growth expectation of 4 to 6 percent |

[0001104659-26-010899:8k_2_02:38]
|  | o | Increasing Test revenue growth expectation to 9 to 11 percent (from 3 to 5 percent) |

[0001104659-26-010899:8k_2_02:39]
|  | · | Adjusting the effective income tax rate to be in the range of 23.0 to 23.5 percent (from 23.7 to 24.1 percent) in 2026. |

[0001104659-26-010899:8k_2_02:40]
|  | · | Raising full year Adjusted EPS guidance to be in the range of $7.90 - $8.15 per share (31 to 35 percent growth), which reflects a midpoint increase of $0.38 from initial November guidance of $7.50 - $7.80 per share. |

[0001104659-26-010899:8k_2_02:41]
|  | · | Q2’26 Adjusted EPS is expected to be in the range of $1.75 - 1.85 per share (50 to 58 percent growth compared to Q2’25 Adjusted EPS). |

[0001104659-26-010899:8k_2_02:42]
Dividend Payment

[0001104659-26-010899:8k_2_02:43]
The next quarterly cash dividend of
$0.08 per share will be paid on April 17, 2026 to stockholders of record on April 2, 2026.

[0001104659-26-010899:8k_2_02:44]
Conference Call

[0001104659-26-010899:8k_2_02:45]
The Company will host a conference call
today, February 5, at 4:00 p.m. Central Time, to discuss the Company’s Q1 2026 results. A live audio webcast and an accompanying
slide presentation will be available in the Investor Center of ESCO’s website. Participants may also access the webcast
using this registration link. For those unable to participate, a webcast replay will be available after the call in the Investor
Center of ESCO’s website.

[0001104659-26-010899:8k_2_02:46]
Forward-Looking Statements

[0001104659-26-010899:8k_2_02:47]
Investors are cautioned that such statements
are only predictions and speak only as of the date of this release, and the Company undertakes no duty to update them except as may be
required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected
in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment
including but not limited to those described in Item 1A, “Risk Factors”, of the Company’s Annual Report on Form 10-K
for the fiscal year ended September 30, 2025 and the following: the impacts of climate change and related regulation of greenhouse
gases; the impacts of labor disputes, civil disorder, wars, elections, political changes, tariffs and trade disputes, terrorist activities,
cyberattacks or natural disasters on the Company’s operations and those of the Company’s customers and suppliers; disruptions
in manufacturing or delivery arrangements due to shortages or unavailability of materials or components or supply chain disruptions;
inability to access work sites; the timing and content of future contract awards or customer orders; the timely appropriation, allocation
and availability of Government funds; the termination for convenience of Government and other customer contracts or orders; weakening
of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies;
competition; intellectual property rights; technical difficulties or data breaches; the availability of acquisitions; delivery delays
or defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability
of certain raw materials; material changes in the cost of credit; changes in laws and regulations including but not limited to changes
in accounting standards and taxation; changes in interest, inflation and employment rates; costs relating to environmental matters arising
from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration;
and the integration and performance of acquired businesses.

[0001104659-26-010899:8k_2_02:48]
Non-GAAP Financial Measures

[0001104659-26-010899:8k_2_02:49]
The financial measures EBIT, Adjusted
EBIT, EBITDA, Adjusted EBITDA, and Adjusted EPS are presented in this press release. The Company defines “EBIT” as earnings
before interest and taxes, “EBITDA” as earnings before interest, taxes, depreciation and amortization, “Adjusted EBIT”
and “Adjusted EBITDA” as excluding the net impact of the items described in the attached Reconciliation of Non-GAAP Financial
Measures, and “Adjusted EPS” as GAAP earnings per share excluding the net impact of the items described and reconciled in
the attached Reconciliation of Non-GAAP Financial Measures.

[0001104659-26-010899:8k_2_02:50]
EBIT, Adjusted EBIT, EBITDA, Adjusted
EBITDA, and Adjusted EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management
believes EBIT, Adjusted EBIT, EBITDA, and Adjusted EBITDA are useful in assessing the operational profitability of the Company’s
business segments because they exclude interest, taxes, depreciation, and amortization, which are generally accounted for across the
entire Company on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within
the Company as well as incentive compensation. The presentation of EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA, and Adjusted EPS provides
important supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP
financial measures to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of
performance determined in accordance with GAAP.

[0001104659-26-010899:8k_2_02:51]
About ESCO

[0001104659-26-010899:8k_2_02:52]
ESCO Technologies is a global provider
of highly engineered products and solutions serving diverse end-markets. It manufactures filtration and fluid control products, advanced
composites, as well as signature and power management solutions for aviation, Navy, and industrial customers. ESCO is an industry leader
in designing and manufacturing RF test and measurement products and systems; and provides diagnostic instruments, software and services
to industrial power users and the electric utility and renewable energy industries. Headquartered in St. Louis, Missouri, ESCO and its
subsidiaries have offices and manufacturing facilities worldwide. For more information on ESCO and its subsidiaries, visit ESCO’s
website at www.escotechnologies.com.

[0001104659-26-010899:8k_2_02:53]
ESCO
TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-26-010899:8k_2_02:54]
Condensed
Consolidated Statements of Operations (Unaudited)

[0001104659-26-010899:8k_2_02:55]
(Dollars
in thousands, except per share amounts)

[0001104659-26-010899:8k_2_02:56]
|  |  | Three Months Ended December 31, 2025 |  |  | Three Months Ended December 31, 2024 |  |
| Net Sales |  | $ | 289,659 |  |  |  | 214,593 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 169,740 |  |  |  | 124,214 |  |
| Selling, general and administrative expenses |  |  | 61,207 |  |  |  | 54,969 |  |
| Amortization of intangible assets |  |  | 20,324 |  |  |  | 7,993 |  |
| Interest expense |  |  | 2,880 |  |  |  | 2,257 |  |
| Other expenses (income), net |  |  | 30 |  |  |  | (637 | ) |
| Total costs and expenses |  |  | 254,181 |  |  |  | 188,796 |  |
| Earnings before income taxes |  |  | 35,478 |  |  |  | 25,797 |  |
| Income tax expense |  |  | 6,787 |  |  |  | 5,490 |  |
| Net earnings from continuing operations |  |  | 28,691 |  |  |  | 20,307 |  |
| Earnings from discontinued operations, net of tax expense of $978 |  |  | - |  |  |  | 3,166 |  |
| Net earnings from discontinued operations |  |  | - |  |  |  | 3,166 |  |
| Net earnings |  | $ | 28,691 |  |  |  | 23,473 |  |
| Diluted - GAAP |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 1.11 |  |  |  | 0.79 |  |
| Discontinued operations |  |  | 0.00 |  |  |  | 0.12 |  |
| Net earnings |  | $ | 1.11 |  |  |  | 0.91 |  |
| Diluted - As Adjusted Basis |  |  |  |  |  |  |  |  |
| Continuing Operations |  | $ | 1.64 | (1) |  |  | 0.95 | (2) |
| Diluted average common shares O/S: |  |  | 25,882 |  |  |  | 25,834 |  |

[0001104659-26-010899:8k_2_02:57]
|  | (1) | Q1 2026 Adjusted EPS excludes $0.53 per share of after-tax charges consisting of: $0.01 of restructuring charges primarily within the A&D segment and $0.52 of acquisition related amortization. |

[0001104659-26-010899:8k_2_02:58]
| (2) | Q1 2025 Adjusted EPS from continuing operations excludes $0.16 per share of after-tax charges consisting of: $0.01 of restructuring charges within the Test segment and $0.15 of acquisition related amortization. |

[0001104659-26-010899:8k_2_02:59]
ESCO
TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-26-010899:8k_2_02:60]
Condensed
Business Segment Information (Unaudited) - Continuing Operations Basis

[0001104659-26-010899:8k_2_02:61]
(Dollars
in thousands)

[0001104659-26-010899:8k_2_02:62]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | Q1 2026 |  |  | Q1 2025 |  |  | Q1 2026 |  |  | Q1 2025 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 143,829 |  |  |  | 81,868 |  |  |  | 143,829 |  |  |  | 81,868 |  |
| USG |  |  | 87,484 |  |  |  | 86,660 |  |  |  | 87,484 |  |  |  | 86,660 |  |
| Test |  |  | 58,346 |  |  |  | 46,065 |  |  |  | 58,346 |  |  |  | 46,065 |  |
| Totals |  | $ | 289,659 |  |  |  | 214,593 |  |  |  | 289,659 |  |  |  | 214,593 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 37,987 |  |  |  | 17,452 |  |  |  | 38,133 |  |  |  | 17,478 |  |
| USG |  |  | 19,529 |  |  |  | 20,489 |  |  |  | 19,579 |  |  |  | 20,489 |  |
| Test |  |  | 8,042 |  |  |  | 4,422 |  |  |  | 8,042 |  |  |  | 4,887 |  |
| Corporate |  |  | (27,200 | ) |  |  | (14,309 | ) |  |  | (9,633 | ) |  |  | (9,310 | ) |
| Consolidated EBIT |  |  | 38,358 |  |  |  | 28,054 |  |  |  | 56,121 |  |  |  | 33,544 |  |
| Less: Interest expense |  |  | (2,880 | ) |  |  | (2,257 | ) |  |  | (2,880 | ) |  |  | (2,257 | ) |
| Less: Income tax expense |  |  | (6,787 | ) |  |  | (5,490 | ) |  |  | (10,872 | ) |  |  | (6,752 | ) |
| Net earnings |  | $ | 28,691 |  |  |  | 20,307 |  |  |  | 42,369 |  |  |  | 24,535 |  |

[0001104659-26-010899:8k_2_02:63]
Note
1: Adjusted net earnings of $42.4 million in Q1 2026 exclude $13.7 million (or $0.53 per share) of after-tax charges consisting of: $0.01
of restructuring charges primarily within the A&D segment and $0.52 of acquisition related amortization.

[0001104659-26-010899:8k_2_02:64]
Note
2: Adjusted net earnings of $24.5 million in Q1 2025 exclude $4.2 million (or $0.16 per share) of after-tax charges consisting of $0.01
of restructuring charges within the Test segment and $0.15 of acquisition related amortization.

[0001104659-26-010899:8k_2_02:65]
| EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |  | Q1 2026 - |  |  | Q1 2025 - |  |
|  |  | Q1 2026 |  |  | Q1 2025 |  |  | As Adj |  |  | As Adj |  |
| Consolidated EBITDA |  | $ | 64,851 |  |  |  | 41,025 |  |  |  | 65,047 |  |  |  | 41,518 |  |
| Less: Depr & Amort |  |  | (26,493 | ) |  |  | (12,971 | ) |  |  | (8,926 | ) |  |  | (7,974 | ) |
| Consolidated EBIT |  |  | 38,358 |  |  |  | 28,054 |  |  |  | 56,121 |  |  |  | 33,544 |  |
| Less: Interest expense |  |  | (2,880 | ) |  |  | (2,257 | ) |  |  | (2,880 | ) |  |  | (2,257 | ) |
| Less: Income tax expense |  |  | (6,787 | ) |  |  | (5,490 | ) |  |  | (10,872 | ) |  |  | (6,752 | ) |
| Net earnings |  | $ | 28,691 |  |  |  | 20,307 |  |  |  | 42,369 |  |  |  | 24,535 |  |

[0001104659-26-010899:8k_2_02:66]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Condensed Consolidated Balance Sheets (Unaudited) |
| (Dollars in thousands) |
|  |  |  | December 31, 2025 |  |  |  | September 30, 2025 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 103,824 |  |  |  | 101,350 |  |
| Accounts receivable, net |  |  | 245,328 |  |  |  | 253,554 |  |
| Contract assets |  |  | 88,662 |  |  |  | 90,730 |  |
| Inventories |  |  | 227,153 |  |  |  | 217,807 |  |
| Other current assets |  |  | 24,686 |  |  |  | 25,065 |  |
| Total current assets |  |  | 689,653 |  |  |  | 688,506 |  |
| Property, plant and equipment, net |  |  | 171,810 |  |  |  | 172,493 |  |
| Intangible assets, net |  |  | 706,383 |  |  |  | 723,973 |  |
| Goodwill |  |  | 767,375 |  |  |  | 761,931 |  |
| Operating lease assets |  |  | 46,592 |  |  |  | 47,707 |  |
| Other assets |  |  | 17,186 |  |  |  | 15,778 |  |
|  |  | $ | 2,398,999 |  |  |  | 2,410,388 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt and short-term borrowings |  | $ | 20,511 |  |  |  | 20,000 |  |
| Accounts payable |  |  | 92,291 |  |  |  | 96,534 |  |
| Contract liabilities |  |  | 252,360 |  |  |  | 216,590 |  |
| Current income tax payable |  |  | 60,478 |  |  |  | 62,007 |  |
| Other current liabilities |  |  | 92,753 |  |  |  | 113,017 |  |
| Total current liabilities |  |  | 518,393 |  |  |  | 508,148 |  |
| Deferred tax liabilities |  |  | 115,776 |  |  |  | 112,390 |  |
| Non-current operating lease liabilities |  |  | 43,466 |  |  |  | 44,403 |  |
| Other liabilities |  |  | 35,500 |  |  |  | 38,576 |  |
| Long-term debt |  |  | 125,000 |  |  |  | 166,000 |  |
| Shareholders’ equity |  |  | 1,560,864 |  |  |  | 1,540,871 |  |
|  |  | $ | 2,398,999 |  |  |  | 2,410,388 |  |

[0001104659-26-010899:8k_2_02:67]
ESCO
TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-26-010899:8k_2_02:68]
Consolidated
Statements of Cash Flows (Unaudited)

[0001104659-26-010899:8k_2_02:69]
(Dollars
in thousands)

[0001104659-26-010899:8k_2_02:70]
|  |  | Three Months Ended December 31, 2025 |  |  | Three Months Ended December 31, 2024 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 28,691 |  |  |  | 23,473 |  |
| (Earnings) loss from discontinued operations |  |  | - |  |  |  | (3,166 | ) |
| Adjustments to reconcile net earnings to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 26,493 |  |  |  | 12,971 |  |
| Stock compensation expense |  |  | 3,233 |  |  |  | 2,524 |  |
| Changes in assets and liabilities |  |  | 7,056 |  |  |  | (8,171 | ) |
| Effect of deferred taxes |  |  | 3,388 |  |  |  | 1,521 |  |
| Net cash provided by operating activities - continuing operations |  |  | 68,861 |  |  |  | 29,152 |  |
| Net cash provided by operating activities - discontinued operations |  |  | - |  |  |  | 5,022 |  |
| Net cash provided by operating activities |  |  | 68,861 |  |  |  | 34,174 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Acquisition of business, net of cash acquired |  |  | (5,134 | ) |  |  | - |  |
| Capital expenditures |  |  | (5,902 | ) |  |  | (5,124 | ) |
| Additions to capitalized software and other |  |  | (2,196 | ) |  |  | (2,587 | ) |
| Net cash used by investing activities - continuing operations |  |  | (13,232 | ) |  |  | (7,711 | ) |
| Net cash used by investing activities - discontinued operations |  |  | - |  |  |  | (84 | ) |
| Net cash used by investing activities |  |  | (13,232 | ) |  |  | (7,795 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from long-term debt and short-term borrowings |  |  | 52,511 |  |  |  | 42,000 |  |
| Principal payments on long-term debt and short-term borrowings |  |  | (93,000 | ) |  |  | (52,000 | ) |
| Dividends paid |  |  | (2,072 | ) |  |  | (2,064 | ) |
| Other |  |  | (10,609 | ) |  |  | (6,031 | ) |
| Net cash provided by financing activities |  |  | (53,170 | ) |  |  | (18,095 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 15 |  |  |  | (2,963 | ) |
| Net increase in cash and cash equivalents |  |  | 2,474 |  |  |  | 5,321 |  |
| Cash and cash equivalents, beginning of period |  |  | 101,350 |  |  |  | 65,963 |  |
| Cash and cash equivalents, end of period |  | $ | 103,824 |  |  |  | 71,284 |  |

[0001104659-26-010899:8k_2_02:71]
ESCO
TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-26-010899:8k_2_02:72]
Other
Selected Financial Data (Unaudited)

[0001104659-26-010899:8k_2_02:73]
(Dollars
in thousands)

[0001104659-26-010899:8k_2_02:74]
| Backlog And Entered Orders - Q1 2026 |  | A&D |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 10/1/25 |  | $ | 803,002 |  |  |  | 143,460 |  |  |  | 187,175 |  |  |  | 1,133,637 |  |
| Entered Orders |  |  | 382,341 |  |  |  | 98,796 |  |  |  | 76,034 |  |  |  | 557,171 |  |
| Sales |  |  | (143,829 | ) |  |  | (87,484 | ) |  |  | (58,346 | ) |  |  | (289,659 | ) |
| Ending Backlog - 12/31/25 |  | $ | 1,041,514 |  |  |  | 154,772 |  |  |  | 204,863 |  |  |  | 1,401,149 |  |

[0001104659-26-010899:8k_2_02:75]
ESCO
TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-26-010899:8k_2_02:76]
Reconciliation
of Non-GAAP Financial Measures (Unaudited)

[0001104659-26-010899:8k_2_02:77]
| EPS – Adjusted Basis Reconciliation – Q1 2026 |  |  |  |
| EPS – GAAP Basis – Q1 2026 |  | $ | 1.11 |  |
| Adjustments (defined below) |  |  | 0.53 |  |
| EPS – As Adjusted Basis – Q1 2026 |  | $ | 1.64 |  |

[0001104659-26-010899:8k_2_02:78]
Adjustments exclude
$0.53 per share consisting primarily of: $0.01 of restructuring charges within the A&D segment and $0.52 of acquisition related amortization.

[0001104659-26-010899:8k_2_02:79]
| EPS – Adjusted Basis Reconciliation – Q1 2025 |  |  |  |  |
| EPS Continuing Operations– GAAP Basis – Q1 2025 |  | $ | 0.79 |  |
| Adjustments (defined below) |  |  | 0.16 |  |
| EPS Continuing Operations– As Adjusted Basis – Q1 2025 |  | $ | 0.95 |  |

[0001104659-26-010899:8k_2_02:80]
Adjustments
exclude $0.16 per share consisting primarily of: $0.01 of restructuring charges within the Test segment and $0.15 of acquisition related
amortization.
