# ESE MD&A — 0001104659-26-011932


## mdna

[0001104659-26-011932:mdna:1]
[same as prior period, unchanged from 0001410578-25-001667:mdna:1]

[0001104659-26-011932:mdna:2]
[same as prior period, unchanged from 0001410578-25-001667:mdna:2]

[0001104659-26-011932:mdna:3]
References to the first quarters of 2026 and 2025 represent the three-month periods ended December 31, 2025 and 2024, respectively.

[0001104659-26-011932:mdna:4]
[same as prior period, unchanged from 0001410578-25-001667:mdna:4]

[0001104659-26-011932:mdna:5]
Sales, net earnings and diluted earnings per share from continuing operations were $289.7 million, $28.7 million and $1.11 per share, respectively, in the first quarter of 2026 compared to $214.6 million, $20.3 million and $0.79 per share, respectively, in the first quarter of 2025.

[0001104659-26-011932:mdna:6]
[same as prior period, unchanged from 0001410578-25-001667:mdna:6]

[0001104659-26-011932:mdna:7]
Net sales increased $75.1 million, or 35.0%, to $289.7 million in the first quarter of 2026 from $214.6 million in the first quarter of 2025. The increase in net sales in the first quarter of 2026 as compared to the first quarter of 2025 was due to a $61.9 million increase in the A&D segment, a $12.2 million increase in the Test segment, and a $0.8 million increase in the USG segment.

[0001104659-26-011932:mdna:8]
[same as prior period, unchanged from 0001410578-25-001667:mdna:8]

[0001104659-26-011932:mdna:9]
Net sales of $143.8 million in the first quarter of 2026 were $61.9 million, or 75.6%, higher than the $81.9 million in the first quarter of 2025. The sales increase in the first quarter of 2026 compared to the first quarter of 2025 was primarily due to a $44.2 million increase in navy revenues and a $15.8 million increase in aerospace revenues (defense and commercial). Maritime contributed $50.6 million of revenue growth in the first quarter of 2026.

[0001104659-26-011932:mdna:10]
[same as prior period, unchanged from 0001410578-25-001667:mdna:10]

[0001104659-26-011932:mdna:11]
Net sales of $87.5 million in the first quarter of 2026 were $0.8 million, or 0.9% higher than the $86.7 million in the first quarter of 2025. The increase in the first quarter of 2026 compared to the first quarter of 2025 was mainly due to a $4.1 million increase in net sales at Doble driven by higher sales of condition monitoring and offline products, partially offset by a $3.3 million decrease in net sales at NRG driven by lower shipments of solar and wind products due to renewables market weakness.

[0001104659-26-011932:mdna:12]
[same as prior period, unchanged from 0001410578-25-001667:mdna:12]

[0001104659-26-011932:mdna:13]
Net sales of $58.3 million in the first quarter of 2026 were $12.2 million, or 26.5%, higher than the $46.1 million in the first quarter of 2025. The increase in the first quarter of 2026 compared to the first quarter of 2025 was primarily due to $13.0 million of higher sales from the segment’s U.S. and European operations mainly driven by higher test and measurement and filters volumes partially offset by a $0.8 million decrease from the segment’s Asian operations.

[0001104659-26-011932:mdna:14]
[same as prior period, unchanged from 0001410578-25-001667:mdna:14]

[0001104659-26-011932:mdna:15]
Backlog was $1,401.1 million at December 31, 2025 compared with $1,133.6 million at September 30, 2025. The Company received new orders totaling $557.2 million in the first quarter of 2026 compared to $229.2 million from continuing operations in the first quarter of 2025. Of the new orders received in the first quarter of 2026, $382.3 million related to A&D products, $98.8 million related to USG products, and $76.1 million related to Test products. Of the new orders received in the first quarter of 2025, $74.8 million related to A&D products, $89.6 million related to USG products, and $64.8 million related to Test products.

[0001104659-26-011932:mdna:16]
[same as prior period, unchanged from 0001410578-25-001667:mdna:17]

[0001104659-26-011932:mdna:17]
Selling, general and administrative (SG&A) expenses from continuing operations were $61.2 million (21.1% of net sales) for the first quarter of 2026, compared with $55.0 million (25.6% of net sales) for the first quarter of 2025. The increase in SG&A in the first quarter of 2026 compared to the first quarter of 2025 was mainly due to an increase within the A&D segment primarily due to the Maritime acquisition. SG&A as a percentage of net sales decreased in the first quarter of 2026 compared to the first quarter of 2025 within all three business segments.

[0001104659-26-011932:mdna:18]
[same as prior period, unchanged from 0001410578-25-001667:mdna:19]

[0001104659-26-011932:mdna:19]
Amortization of intangible assets was $20.3 million and $8.0 million for the first quarter of 2026 and 2025, respectively. Amortization expenses consist of amortization of acquired intangible assets from acquisitions and other identifiable intangible assets (primarily software). The increase in amortization expense in the first quarter of 2026 compared to the first quarter of 2025 was mainly due to an increase in amortization of intangible assets related to the Maritime acquisition.

[0001104659-26-011932:mdna:20]
OTHER (INCOME) EXPENSES, NET

[0001104659-26-011932:mdna:21]
Other expenses, net, was $0.1 million in the first quarter of 2026 compared to other (income), net, of ($0.6) million in the first quarter of 2025. There were no individually significant items in other expenses (income), net, in the first quarter of 2026 or 2025.

[0001104659-26-011932:mdna:22]
[same as prior period, unchanged from 0001410578-25-001667:mdna:23]

[0001104659-26-011932:mdna:23]
The Company evaluates the performance of its operating segments based on EBIT, and provides EBIT on a consolidated basis, which is a non-GAAP financial measure. Please refer to the discussion of non-GAAP financial measures in Note 6 to the Consolidated Financial Statements, above. EBIT from continuing operations was $38.4 million (13.2% of net sales) for the first quarter of 2026 compared to $28.1 million (13.1% of net sales) for the first quarter of 2025.

[0001104659-26-011932:mdna:24]
The following table presents a reconciliation of EBIT from continuing operations to a GAAP financial measure:

[0001104659-26-011932:mdna:25]
| ​ | ​ | Three Months Ended |
| ​ | ​ | December 31, |
| (In thousands) | ​ ​ ​ | 2025 | ​ ​ ​ | 2024 |
| Net earnings from continuing operations | ​ | $ | 28,691 | ​ | ​ | 20,307 |
| Plus: Interest expense, net | ​ | ​ | 2,880 | ​ | ​ | 2,257 |
| Plus: Income tax expense | ​ | ​ | 6,787 | ​ | ​ | 5,490 |
| Consolidated EBIT | ​ | $ | 38,358 | ​ | ​ | 28,054 |

[0001104659-26-011932:mdna:26]
[same as prior period, unchanged from 0001410578-25-001667:mdna:27]

[0001104659-26-011932:mdna:27]
EBIT was $38.0 million (26.4% of net sales) in the first quarter of 2026 compared to $17.5 million (21.3% of net sales) in the first quarter of 2025. The increase in EBIT in the first quarter of 2026 compared to the first quarter of 2025 was mainly due to higher sales volumes as mentioned above, favorable mix and price increases, partially offset by inflationary pressures. In addition, EBIT in the first quarter of 2026 was negatively impacted by $0.1 million of restructuring charges.

[0001104659-26-011932:mdna:28]
[same as prior period, unchanged from 0001410578-25-001667:mdna:29]

[0001104659-26-011932:mdna:29]
EBIT was $19.5 million (22.3% of net sales) in the first quarter of 2026 compared to $20.5 million (23.6% of net sales) in the first quarter of 2025. The decrease in EBIT in the first quarter of 2026 compared to the first quarter of 2025 was mainly due to the lower sales volumes at NRG, unfavorable product mix and inflationary pressures partially offset by an increase in EBIT at Doble due to higher sales volumes.

[0001104659-26-011932:mdna:30]
[same as prior period, unchanged from 0001410578-25-001667:mdna:31]

[0001104659-26-011932:mdna:31]
EBIT was $8.0 million (13.8% of net sales) in the first quarter of 2026 compared to $4.4 million (9.6% of net sales) in the first quarter of 2025. The increase in EBIT in the first quarter of 2026 compared to the first quarter of 2025 was primarily driven by the higher sales volumes from the segment’s U.S. and European operations and price increases, partially offset by inflationary pressures and unfavorable mix.

[0001104659-26-011932:mdna:32]
[same as prior period, unchanged from 0001410578-25-001667:mdna:33]

[0001104659-26-011932:mdna:33]
Corporate costs included in EBIT were $27.2 million and $14.3 million in the first quarter of 2026 and 2025, respectively. The increase in Corporate costs in the first quarter of 2026 compared to the first quarter of 2025 was mainly due to increases in acquisition related amortization and share based compensation costs.

[0001104659-26-011932:mdna:34]
[same as prior period, unchanged from 0001410578-25-001667:mdna:35]

[0001104659-26-011932:mdna:35]
Interest expense was $2.9 million and $2.3 million in the first quarter of 2026 and 2025, respectively. The increase in interest expense in the first quarter of 2026 as compared to the first quarter of 2025 was mainly due to higher average outstanding borrowings ($171 million in the first quarter of 2026 compared to $122 million in the first quarter of 2025).

[0001104659-26-011932:mdna:36]
[same as prior period, unchanged from 0001410578-25-001667:mdna:37]

[0001104659-26-011932:mdna:37]
The effective income tax rate from continuing operations was 19.1% in the first quarter of 2026 compared to 21.3% in the first quarter of 2025. Income tax expense in the first quarter of 2026 was favorably impacted by additional tax benefits related to the vesting of share-based compensation awards.

[0001104659-26-011932:mdna:38]
[same as prior period, unchanged from 0001410578-25-001667:mdna:39]

[0001104659-26-011932:mdna:39]
The Company’s overall financial position and liquidity remain strong. Working capital (current assets less current liabilities) decreased to $171.3 million at December 31, 2025 from $180.4 million at September 30, 2025. Accounts receivable decreased $8.2 million during this period mainly due to a $4.7 million decrease within the Test segment and a $4.6 million decrease within the USG segment due to strong cash collections during the quarter. Inventories increased $9.3 million during this period mainly due to a $5.0 million increase within the USG segment, a $3.4 million increase within the Test segment and a $0.9 million increase within the A&D segment primarily from an increase in work in process inventories due to timing of manufacturing existing orders. Contract liabilities increased $35.8 million primarily within the A&D segment due to timing of payments received under long-term contracts.

[0001104659-26-011932:mdna:40]
Net cash provided by operating activities from continuing operations was $68.9 million and $29.2 million in the first quarters of 2026 and 2025, respectively. The increase in net cash provided by operating activities in the first quarter of 2026 as compared to the first quarter of 2025 was mainly driven by an increase in net earnings and an increase in contract liabilities.

[0001104659-26-011932:mdna:41]
Capital expenditures from continuing operations were $5.9 million and $5.1 million in the first quarters of 2026 and 2025, respectively. The increase in the first quarter of 2026 was mainly due to an increase in building improvements and machinery & equipment within the A&D segment. In addition, the Company incurred expenditures for capitalized software of approximately $2.2 million and $2.6 million in the first quarters of 2026 and 2025, respectively.

[0001104659-26-011932:mdna:42]
[same as prior period, unchanged from 0001410578-25-001667:mdna:45]

[0001104659-26-011932:mdna:43]
During the first quarter fiscal 2026, the Company paid approximately $5 million for the final working capital settlement in connection with the Maritime acquisition.

[0001104659-26-011932:mdna:44]
Credit Facility

[0001104659-26-011932:mdna:45]
At December 31, 2025, the Company had approximately $469 million available to borrow under its bank credit facility, excluding the Incremental Facility, plus a $250 million increase option, and $103.8 million cash on hand. At December 31, 2025, the Company had $145.5 million of outstanding borrowings under the Credit facility, Incremental facility and short-term borrowings at its foreign locations, in addition to outstanding letters of credit of $10.7 million. Cash flow from operations and borrowings under the Company’s credit facility are expected to meet the Company’s capital requirements and operational needs for the foreseeable future. The Company’s ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.

[0001104659-26-011932:mdna:46]
[same as prior period, unchanged from 0001410578-25-001667:mdna:49]

[0001104659-26-011932:mdna:47]
A dividend of $0.08 per share, totaling $2.1 million, was paid on October 16, 2025 to stockholders of record as of October 2, 2025. Subsequent to December 31, 2025, a quarterly dividend of $0.08 per share, totaling $2.1 million, was paid on January 16, 2026 to stockholders of record as of January 2, 2026.

[0001104659-26-011932:mdna:48]
[same as prior period, unchanged from 0001410578-25-001667:mdna:51]

[0001104659-26-011932:mdna:49]
Management has evaluated the accounting policies used in the preparation of the Company’s financial statements and related notes and believes those policies to be reasonable and appropriate. Certain of these accounting policies require the application of significant judgment by Management in selecting appropriate assumptions for calculating financial estimates. By their nature, these judgments are subject to an inherent degree of uncertainty. These judgments are based on historical experience, trends in the industry, information provided by customers and information available from other outside sources, as appropriate. The most significant areas involving Management judgments and estimates may be found in the Critical Accounting Policies section of Management’s Discussion and Analysis and in Note 1 to the Consolidated Financial Statements contained in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2025.

[0001104659-26-011932:mdna:50]
[same as prior period, unchanged from 0001410578-25-001667:mdna:53]

[0001104659-26-011932:mdna:51]
Contingencies

[0001104659-26-011932:mdna:52]
As a normal incident of the business in which the Company is engaged, various claims, charges and litigation are asserted or commenced against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. In the opinion of Management, the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company, are adequately reserved, are covered by insurance, or would not have a material adverse effect on the Company’s results from operations, capital expenditures, or competitive position.

[0001104659-26-011932:mdna:53]
[same as prior period, unchanged from 0001410578-25-001667:mdna:56]

[0001104659-26-011932:mdna:54]
Investors are cautioned that such statements are only predictions and speak only as of the date of this Form 10-Q, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment, including but not limited to those described in Item 1A, “Risk Factors,” of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2025, and the following: the impacts of climate change and related regulation of greenhouse gases; the impacts of labor disputes, civil disorder, wars, elections, political changes, tariffs and trade disputes, terrorist activities, cyberattacks or natural disasters on the Company’s operations and those of the Company’s customers and suppliers; disruptions in manufacturing or delivery arrangements due to shortages or unavailability of materials or components; or supply chain disruptions; inability to access work sites; the timing and content of future contract awards or customer orders; the timely appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer contracts or orders; weakening of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties or data breaches; the availability of selected acquisitions; delivery delays or defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability of certain raw materials; material changes in the cost of credit; changes in laws and regulations including but not limited to changes in accounting standards and taxation; changes in interest rates; costs relating to environmental matters arising from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the integration and performance of recently acquired businesses.
