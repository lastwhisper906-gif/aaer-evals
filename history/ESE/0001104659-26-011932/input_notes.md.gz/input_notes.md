# ESE notes — 0001104659-26-011932


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001104659-26-011932:notes:1]
[same as prior period, unchanged from 0001410578-25-001667:notes:1]

[0001104659-26-011932:notes:2]
The accompanying condensed consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP). For further information refer to the consolidated financial statements and related notes included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2025.

[0001104659-26-011932:notes:3]
The Company’s results for the three-month period ended December 31, 2025 are not necessarily indicative of the results for the entire 2026 fiscal year. References to the first quarters of 2026 and 2025 represent the fiscal quarters ended December 31, 2025 and 2024, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:EarningsPerShareTextBlock

[0001104659-26-011932:notes:4]
[same as prior period, unchanged from 0001410578-25-001667:notes:4]

[0001104659-26-011932:notes:5]
Basic EPS is calculated using the weighted average number of common shares outstanding during the period. Diluted EPS is calculated using the weighted average number of common shares outstanding during the period plus shares issuable upon the assumed dilutive vesting of unvested performance-based share awards and time-vested restricted shares by using the treasury stock method. The number of shares used in the calculation of earnings per share for each period presented is as follows (in thousands):

[0001104659-26-011932:notes:6]
| ​ | ​ ​ ​ | Three Months |
| ​ | ​ | Ended December 31, |
| ​ | ​ ​ ​ | 2025 | ​ ​ ​ | 2024 |
| Weighted Average Shares Outstanding — Basic |  | 25,855 | ​ | 25,781 |
| Dilutive Shares | ​ | 27 | ​ | 53 |
| Adjusted Shares — Diluted |  | 25,882 | ​ | 25,834 |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001104659-26-011932:notes:7]
3.    SHARE-BASED COMPENSATION

[0001104659-26-011932:notes:8]
The Company provides compensation benefits to certain key employees under several share-based plans providing for a combination of performance-based share unit (PSU) awards and time-vested restricted share unit (RSU) awards, and to non-employee directors under a separate compensation plan.

[0001104659-26-011932:notes:9]
PSU and RSU Awards

[0001104659-26-011932:notes:10]
Compensation expense related to these awards was $2.9 million and $2.2 million for the three-month periods ended December 31, 2025 and 2024, respectively. There were 173,478 non-vested shares outstanding as of December 31, 2025.

[0001104659-26-011932:notes:11]
[same as prior period, unchanged from 0001410578-25-001667:notes:19]

[0001104659-26-011932:notes:12]
Compensation expense related to the non-employee director grants was $0.3 million and $0.3 million for the three-month periods ended December 31, 2025 and 2024, respectively.

[0001104659-26-011932:notes:13]
The total share-based compensation cost that has been recognized in the results of operations and included within selling, general and administrative expenses (SG&A) was $3.2 million and $2.5 million for the three-month periods ended December 31, 2025 and 2024, respectively. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $0.7 million and $0.8 million for the three-month periods ended December 31, 2025 and 2024, respectively. As of December 31, 2025 there was approximately $22 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a remaining weighted-average period of 2.0 years.


## us-gaap:InventoryDisclosureTextBlock

[0001104659-26-011932:notes:14]
4.    INVENTORIES

[0001104659-26-011932:notes:15]
Inventories consist of the following:

[0001104659-26-011932:notes:16]
| ​ | ​ | December 31, | ​ | September 30, |
| (In thousands) | ​ ​ ​ | 2025 | ​ ​ ​ | 2025 |
| Finished goods | ​ | $ | 51,803 | ​ | 52,644 |
| Work in process | ​ | ​ | 55,085 | ​ | 46,825 |
| Raw materials | ​ | ​ | 120,265 | ​ | 118,338 |
| Total inventories | ​ | $ | 227,153 | ​ | 217,807 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001104659-26-011932:notes:17]
| 5. | GOODWILL AND OTHER INTANGIBLE ASSETS |

[0001104659-26-011932:notes:18]
Included on the Company’s Consolidated Balance Sheets at December 31, 2025 and September 30, 2025 are the following intangible assets gross carrying amounts and accumulated amortization from continuing operations:

[0001104659-26-011932:notes:19]
| ​ | ​ ​ ​ | December 31, | ​ ​ ​ | September 30, |
| (Dollars in thousands) | ​ ​ ​ | 2025 | ​ ​ ​ | 2025 |
| Goodwill | ​ | $ | 767,375 | ​ | 761,931 |
| Intangible assets with determinable lives: | ​ |  | ​ | ​ | ​ |
| Patents | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 7,611 | ​ | 7,607 |
| Less: accumulated amortization | ​ |  | 1,902 | ​ | 1,775 |
| Net | ​ | $ | 5,709 | ​ | 5,832 |
| Capitalized software | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 140,746 | ​ | 138,144 |
| Less: accumulated amortization | ​ |  | 103,462 | ​ | 100,818 |
| Net | ​ | $ | 37,284 | ​ | 37,326 |
| Customer relationships | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 625,477 | ​ | 625,535 |
| Less: accumulated amortization | ​ |  | 169,244 | ​ | 159,543 |
| Net | ​ | $ | 456,233 | ​ | 465,992 |
| Other | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 76,914 | ​ | 76,991 |
| Less: accumulated amortization | ​ |  | 32,681 | ​ | 24,829 |
| Net | ​ | $ | 44,233 | ​ | 52,162 |
| Intangible assets with indefinite lives: | ​ |  | ​ | ​ | ​ |
| Trade names | ​ | $ | 162,924 | ​ | 162,661 |

[0001104659-26-011932:notes:20]
The changes in the carrying amount of goodwill attributable to each business segment for the three months ended December 31, 2025 are as follows:

[0001104659-26-011932:notes:21]
| (Dollars in millions) | ​ ​ ​ | A&D | ​ ​ ​ | Test | ​ | USG | ​ ​ ​ | Total |
| Balance as of September 30, 2025 | ​ | $ | 334.0 |  | ​ | 67.8 |  | 360.1 |  | 761.9 |
| Acquisition activity and other | ​ | ​ | 5.1 | ​ | ​ | — | ​ | — | ​ | 5.1 |
| Foreign currency translation | ​ | ​ | — | ​ | ​ | — | ​ | 0.4 | ​ | 0.4 |
| Balance as of December 31, 2025 | ​ | $ | 339.1 |  | ​ | 67.8 |  | 360.5 |  | 767.4 |

[0001104659-26-011932:notes:22]
During the first quarter of fiscal 2026, the Company paid approximately $5 million for the final working capital settlement in connection with the Maritime acquisition.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001104659-26-011932:notes:23]
6.    BUSINESS SEGMENT INFORMATION

[0001104659-26-011932:notes:24]
We adopted the provisions of ASU 2023-07 Segment Reporting for the year ended September 30, 2025. We are organized based on the products and services we offer, and we classify our business operations in three reportable segments for financial reporting purposes: Aerospace & Defense (A&D), Utility Solutions Group (USG) and RF Test & Measurement (Test). Corporate is not a reportable segment, but it is included for reconciliation purposes.

[0001104659-26-011932:notes:25]
The A&D segment’s operations consist of PTI, Crissair, Globe, Mayday, and Maritime. Previously, A&D also included VACCO Industries which is now being reported in discontinued operations. The companies within this segment primarily design and manufacture specialty filtration, fluid control and naval products, including hydraulic filter elements and fluid control devices used in aerospace and defense applications; custom designed filters for manned aircraft and submarines; products and systems to reduce vibration and/or acoustic signatures and otherwise reduce or obscure a vessel’s signature, power management and control equipment; sealing, surface control and hydrodynamic related applications to enhance U.S. and UK Navy maritime survivability; precision-tolerance machined components for the aerospace and defense industry; metal processing services; and miniature electro-explosive devices utilized in mission-critical defense and aerospace applications.

[0001104659-26-011932:notes:26]
The USG segment’s operations consist of Doble Engineering Company and related subsidiaries including Morgan Schaffer and Altanova/ISA (collectively, Doble), and NRG. Doble is an industry leader in the development, manufacture and delivery of diagnostic testing and data management solutions that enable electric power grid operators to assess the integrity of high-voltage power delivery equipment, and Altanova/ISA’s strong market presence in Europe and Asia provides Doble with a significant international platform. Doble combines three core elements for customers – diagnostic test and condition monitoring instruments, expert consulting, and testing services – and provides access to its large reserve of related empirical knowledge. NRG is a global market leader in the design and manufacture of decision support tools for the renewable energy industry, primarily wind and solar.

[0001104659-26-011932:notes:27]
The Test segment’s operations consist of ETS-Lindgren Inc., including its related subsidiaries, and MPE Limited (collectively, ETS - Lindgren). ETS-Lindgren is an industry leader in designing and manufacturing products and systems to measure and control RF energy. It serves the medical, health and safety, electronics, wireless communications, automotive and defense markets, supplying a broad range of turnkey systems, including RF test facilities and measurement systems, RF and magnetically shielded rooms and secure communication facilities, and providing the design, program management, installation and integration services required to successfully complete these types of facilities. It also supplies a broad range of components including RF absorptive materials, filters, antennas, field probes, test cells, proprietary measurement software and other test accessories required to perform a variety of tests and measurements, and offers a variety of services including calibration and product tests.

[0001104659-26-011932:notes:28]
Accounting policies of the segments are the same as those described in the summary of significant accounting policies in Note 1 to the Consolidated Financial Statements in the Company’s Form 10-K for the year ended September 30, 2025. The operating units within each reporting segment have been aggregated because of similar economic characteristics and meet the other aggregation criteria of FASB ASC 280, Segment Reporting.

[0001104659-26-011932:notes:29]
Measurement of Segment Results

[0001104659-26-011932:notes:30]
Our CODM, who is our Chief Executive Officer, evaluates each segment’s performance and allocates resources based on segment EBIT, which is defined as earnings before interest and taxes. EBIT on a consolidated basis is a non-GAAP financial measure and is reconciled to consolidated earnings before income taxes below for continuing operations. Intersegment sales and transfers are not significant. Segment assets consist primarily of customer receivables, inventories, capitalized software and fixed assets directly associated with the production processes of the segment. Segment depreciation and amortization is based upon the direct assets listed above. Corporate assets consist primarily of acquired intangible assets including goodwill, deferred taxes and cash balances. The tables below are presented on the basis of continuing operations and exclude discontinued operations.

[0001104659-26-011932:notes:31]
| Quarter Ended December 31, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | Segment | ​ | ​ | ​ | ​ |
| (In thousands) | ​ ​ ​ | A&D | ​ ​ ​ | USG | ​ ​ ​ | Test | ​ ​ ​ | Total | ​ ​ ​ | Corporate | ​ ​ ​ | Total |
| Sales | ​ | $ | 143,829 |  | 87,484 |  | 58,346 |  | 289,659 | ​ |  | — | ​ |  | 289,659 |
| Cost of sales | ​ |  | 90,071 |  | 39,930 |  | 39,739 |  | 169,740 | ​ |  | — | ​ |  | 169,740 |
| SG&A expense | ​ |  | 15,533 |  | 26,043 |  | 9,652 |  | 51,228 | ​ |  | 9,979 | ​ |  | 61,207 |
| Amortization of intangible assets | ​ |  | 155 |  | 2,043 |  | 514 |  | 2,712 | ​ |  | 17,612 | ​ |  | 20,324 |
| Other expense (income), net | ​ |  | 83 |  | (61) |  | 399 |  | 421 | ​ |  | (391) | ​ |  | 30 |
| Segment profit (loss) | ​ | $ | 37,987 |  | 19,529 |  | 8,042 |  | 65,558 | ​ |  | (27,200) | ​ |  | 38,358 |
| Interest expense | ​ | ​ | ​ |  | ​ |  | ​ |  | ​ | ​ | $ | 2,880 | ​ |  | 2,880 |
| Earnings before income taxes | ​ | ​ | ​ |  | ​ |  | ​ |  | ​ | ​ |  | ​ | ​ | $ | 35,478 |
| Depreciation and amortization | ​ | $ | 3,282 |  | 4,080 |  | 1,456 |  | 8,818 | ​ |  | 17,675 | ​ |  | 26,493 |
| Segment assets | ​ |  | 368,902 |  | 278,132 |  | 197,594 |  | 844,628 | ​ |  | 1,554,371 | ​ |  | 2,398,999 |
| Capital expenditures | ​ | $ | 3,912 |  | 1,570 |  | 373 |  | 5,855 | ​ |  | 47 | ​ |  | 5,902 |

[0001104659-26-011932:notes:32]
| Quarter Ended December 31, 2024 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | Segment | ​ | ​ | ​ | ​ |
| (In thousands) | ​ ​ ​ | A&D | ​ ​ ​ | USG | ​ ​ ​ | Test | ​ ​ ​ | Total | ​ ​ ​ | Corporate | ​ ​ ​ | Total |
| Sales | ​ | $ | 81,868 |  | 86,660 |  | 46,065 |  | 214,593 |  | ​ | — | ​ |  | 214,593 |
| Cost of sales | ​ |  | 53,513 |  | 39,338 |  | 31,363 |  | 124,214 |  | ​ | — | ​ |  | 124,214 |
| SG&A expense | ​ |  | 10,868 |  | 25,916 |  | 9,050 |  | 45,834 |  | ​ | 9,135 | ​ |  | 54,969 |
| Amortization of intangible assets | ​ |  | 213 |  | 2,072 |  | 622 |  | 2,907 |  | ​ | 5,086 | ​ |  | 7,993 |
| Other expense (income), net | ​ |  | (178) |  | (1,155) |  | 608 |  | (725) |  | ​ | 88 | ​ |  | (637) |
| Segment profit (loss) | ​ | $ | 17,452 |  | 20,489 |  | 4,422 |  | 42,363 |  | ​ | (14,309) | ​ |  | 28,054 |
| Interest expense | ​ | ​ | ​ |  | ​ |  | ​ |  | ​ |  | $ | 2,257 | ​ |  | 2,257 |
| Earnings before income taxes | ​ | ​ | ​ |  | ​ |  | ​ |  | ​ |  | ​ | ​ | ​ | $ | 25,797 |
| Depreciation and amortization | ​ | $ | 2,650 |  | 3,888 |  | 1,375 |  | 7,913 |  | ​ | 5,058 | ​ |  | 12,971 |
| Segment assets | ​ |  | 267,549 |  | 280,071 |  | 163,352 |  | 710,972 |  | ​ | 959,720 | ​ |  | 1,670,692 |
| Capital expenditures | ​ | $ | 2,464 |  | 1,990 |  | 670 |  | 5,124 |  | ​ | — | ​ |  | 5,124 |

[0001104659-26-011932:notes:33]
[same as prior period, unchanged from 0001410578-25-001667:notes:36]

[0001104659-26-011932:notes:34]
The financial measure “EBIT” is presented in the above tables and elsewhere in this Report. EBIT on a consolidated basis is a non-GAAP financial measure. Management believes that EBIT is useful in assessing the operational profitability of the Company’s business segments because it excludes interest and taxes, which are generally accounted for across the entire Company on a consolidated basis. EBIT is also one of the measures used by management in determining resource allocations within the Company as well as incentive compensation. A reconciliation of EBIT to net earnings is set forth in Item 2, Management’s Discussion and Analysis of Financial Condition and Results of Operations – EBIT.

[0001104659-26-011932:notes:35]
[same as prior period, unchanged from 0001410578-25-001667:notes:38]


## us-gaap:DebtDisclosureTextBlock

[0001104659-26-011932:notes:36]
7.    DEBT

[0001104659-26-011932:notes:37]
The Company’s debt is summarized as follows:

[0001104659-26-011932:notes:38]
| ​ | ​ ​ ​ | December 31, | ​ | September 30, |
| (In thousands) | ​ ​ ​ | 2025 | ​ ​ ​ | 2025 |
| Revolving credit facility and short-term borrowings | ​ | ​ | 20,511 | ​ | 25,000 |
| Incremental facility (Term loan A) | ​ | ​ | 125,000 | ​ | 161,000 |
| Total borrowings | ​ | $ | 145,511 | ​ | 186,000 |
| Current portion of long-term debt and short-term borrowings | ​ | ​ | (20,511) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 125,000 | ​ | 166,000 |

[0001104659-26-011932:notes:39]
The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of seven banks led by JP Morgan Chase Bank, N.A., as administrative agent, Bank of America, N.A., as syndication agent, and Commerce Bank and TD Bank, N.A. as co-documentation agents. The Credit Facility matures August 30, 2028, with balance due by this date.

[0001104659-26-011932:notes:40]
On August 5, 2024, the Company and certain of its subsidiaries entered into Amendment No. 1 (the “Amendment”) to the Credit Facility which, among other things, (i) implements a senior incremental delayed draw term loan credit facility in an aggregate principal amount of up to $375 million (the “Incremental Facility”), and (ii) permits the direct or indirect acquisition by the Registrant or certain of its subsidiaries of all the issued and outstanding shares of PMES I Limited, Measurement Systems, Inc., EMS Development Corporation, and DNE Technologies, Inc. (the “Maritime Acquisition”), pursuant to and in accordance with the terms and conditions of that certain Sale and Purchase Agreement, dated July 8, 2024, among Ultra Electronics Holdings Limited, as parent seller, the Registrant, as guarantor, and certain of the Registrant’s subsidiaries as buyers. During the third quarter of 2025, the proceeds of the loans drawn under the Incremental Facility were applied to pay a portion of the cash consideration for the Maritime Acquisition and other customary fees, premiums, expenses and costs incurred in connection with the acquisition.

[0001104659-26-011932:notes:41]
At December 31, 2025, the Company had approximately $469 million available to borrow under the Credit Facility, excluding the Incremental Facility, plus the $250 million increase option subject to the lenders’ consent, in addition to $103.8 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of December 31, 2025, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. In addition, the Company had $0.5 million of short-term borrowings at its foreign locations outstanding as of December 31, 2025. The letters of credit issued and outstanding under the Credit Facility totaled $10.7 million at December 31, 2025.

[0001104659-26-011932:notes:42]
Interest on borrowings under the Credit Facility is calculated at a spread over either an Adjusted Term SOFR Rate, Adjusted EURIBOR Rate, Adjusted CDOR Rate, Alternate Base Rate or Daily Simple RFR, at the Company’s election. The Credit Facility also requires a facility fee ranging from 12.5 to 25 basis points per annum. The interest rate spreads and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio. The weighted average interest rates under the Credit Facility were 5.7% and 6.1% for the three-month periods ending December 31, 2025 and 2024, respectively. The weighted average interest rate under the Incremental Facility was 5.6% for the three-month period ending December 31, 2025. As of December 31, 2025, the Company was in compliance with all covenants.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001104659-26-011932:notes:43]
8.   INCOME TAX EXPENSE

[0001104659-26-011932:notes:44]
The first quarter 2026 effective income tax rate from continuing operations was 19.1% compared to 21.3% in the first quarter of 2025. Income tax expense in the first quarter of 2026 was favorably impacted by additional tax benefits related to the vesting of share-based compensation awards.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001104659-26-011932:notes:45]
9.   SHAREHOLDERS’ EQUITY

[0001104659-26-011932:notes:46]
The change in shareholders’ equity for the first three months ended December 31, 2025 and 2024 is shown below (in thousands):

[0001104659-26-011932:notes:47]
| ​ | ​ | Three Months Ended December 31, |
| ​ | ​ ​ ​ | 2025 | ​ ​ ​ | 2024 |
| Common stock | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | $ | 309 | ​ | 308 |
| Stock plans | ​ | ​ | — | ​ | 1 |
| Ending balance | ​ | ​ | 309 | ​ | 309 |
| Additional paid-in-capital | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | 316,194 | ​ | 311,942 |
| Stock plans | ​ | ​ | (7,265) | ​ | (3,799) |
| Ending balance | ​ | ​ | 308,929 | ​ | 308,143 |
| Retained earnings | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | 1,373,911 | ​ | 1,082,950 |
| Net earnings common stockholders | ​ | ​ | 28,691 | ​ | 23,473 |
| Dividends paid | ​ | ​ | (2,072) | ​ | (2,064) |
| Ending balance | ​ | ​ | 1,400,530 | ​ | 1,104,359 |
| Accumulated other comprehensive income (loss) | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | (2,468) | ​ | (10,775) |
| Foreign currency translation | ​ | ​ | 639 | ​ | (18,028) |
| Ending balance | ​ | ​ | (1,829) | ​ | (28,803) |
| Treasury stock | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | (147,075) | ​ | (147,075) |
| Share repurchases | ​ | ​ | — | ​ | — |
| Ending balance | ​ | ​ | (147,075) | ​ | (147,075) |
| Total equity | ​ | $ | 1,560,864 | ​ | 1,236,933 |


## us-gaap:FairValueDisclosuresTextBlock

[0001104659-26-011932:notes:48]
10.  FAIR VALUE MEASUREMENTS

[0001104659-26-011932:notes:49]
[same as prior period, unchanged from 0001410578-25-001667:notes:54]

[0001104659-26-011932:notes:50]
[same as prior period, unchanged from 0001410578-25-001667:notes:55]

[0001104659-26-011932:notes:51]
[same as prior period, unchanged from 0001410578-25-001667:notes:56]

[0001104659-26-011932:notes:52]
[same as prior period, unchanged from 0001410578-25-001667:notes:57]

[0001104659-26-011932:notes:53]
[same as prior period, unchanged from 0001410578-25-001667:notes:58]

[0001104659-26-011932:notes:54]
The Company has estimated the fair value of its financial instruments as of December 31, 2025 and September 30, 2025 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001104659-26-011932:notes:55]
[same as prior period, unchanged from 0001410578-25-001667:notes:60]

[0001104659-26-011932:notes:56]
The Company’s forward contracts and interest rate swaps are classified within Level 2 of the valuation hierarchy in accordance with FASB Accounting Standards Codification (ASC) 825 and are immaterial.

[0001104659-26-011932:notes:57]
[same as prior period, unchanged from 0001410578-25-001667:notes:62]

[0001104659-26-011932:notes:58]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however, they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during the three-month period ended December 31, 2025.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001104659-26-011932:notes:59]
11.  REVENUES

[0001104659-26-011932:notes:60]
[same as prior period, unchanged from 0001410578-25-001667:notes:65]

[0001104659-26-011932:notes:61]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2025 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within each reportable segment.

[0001104659-26-011932:notes:62]
| (In thousands) | ​ ​ ​ | A&D | ​ ​ ​ | USG | ​ ​ ​ | Test | ​ ​ ​ | Total |
| Customer type: |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |
| Commercial | ​ | $ | 45,796 | ​ | $ | 85,739 | ​ | $ | 46,317 | ​ | $ | 177,852 |
| Government | ​ | ​ | 98,033 | ​ | ​ | 1,745 | ​ | ​ | 12,029 | ​ | ​ | 111,807 |
| Total revenues | ​ | $ | 143,829 | ​ | $ | 87,484 | ​ | $ | 58,346 | ​ | $ | 289,659 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 92,786 | ​ | $ | 60,724 | ​ | $ | 36,482 | ​ | $ | 189,992 |
| International | ​ | ​ | 51,043 | ​ | ​ | 26,760 | ​ | ​ | 21,864 | ​ | ​ | 99,667 |
| Total revenues | ​ | $ | 143,829 | ​ | $ | 87,484 | ​ | $ | 58,346 | ​ | $ | 289,659 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 66,534 | ​ | $ | 68,289 | ​ | $ | 9,217 | ​ | $ | 144,040 |
| Over time | ​ | ​ | 77,295 | ​ | ​ | 19,195 | ​ | ​ | 49,129 | ​ | ​ | 145,619 |
| Total revenues | ​ | $ | 143,829 | ​ | $ | 87,484 | ​ | $ | 58,346 | ​ | $ | 289,659 |

[0001104659-26-011932:notes:63]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2024 are presented in the table below:

[0001104659-26-011932:notes:64]
| (In thousands) | ​ ​ ​ | A&D | ​ ​ ​ | USG | ​ ​ ​ | Test | ​ ​ ​ | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 45,755 | ​ | $ | 84,279 | ​ | $ | 36,349 | ​ | $ | 166,383 |
| Government | ​ | ​ | 36,113 | ​ | ​ | 2,381 | ​ | ​ | 9,716 | ​ | ​ | 48,210 |
| Total revenues | ​ | $ | 81,868 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 214,593 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 65,314 | ​ | $ | 59,917 | ​ | $ | 28,630 | ​ | $ | 153,861 |
| International | ​ | ​ | 16,554 | ​ | ​ | 26,743 | ​ | ​ | 17,435 | ​ | ​ | 60,732 |
| Total revenues | ​ | $ | 81,868 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 214,593 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 46,995 | ​ | $ | 69,278 | ​ | $ | 9,791 | ​ | $ | 126,064 |
| Over time | ​ | ​ | 34,873 | ​ | ​ | 17,382 | ​ | ​ | 36,274 | ​ | ​ | 88,529 |
| Total revenues | ​ | $ | 81,868 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 214,593 |

[0001104659-26-011932:notes:65]
[same as prior period, unchanged from 0001410578-25-001667:notes:72]

[0001104659-26-011932:notes:66]
[same as prior period, unchanged from 0001410578-25-001667:notes:73]

[0001104659-26-011932:notes:67]
[same as prior period, unchanged from 0001410578-25-001667:notes:74]

[0001104659-26-011932:notes:68]
[same as prior period, unchanged from 0001410578-25-001667:notes:75]

[0001104659-26-011932:notes:69]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to performance obligations that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At December 31, 2025, the Company had $1,401.1 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 58% in the next twelve months.

[0001104659-26-011932:notes:70]
[same as prior period, unchanged from 0001410578-25-001667:notes:77]

[0001104659-26-011932:notes:71]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At December 31, 2025, contract assets, contract liabilities and accounts receivable totaled $88.7 million, $259.5 million and $245.3 million, respectively. During the first quarter of 2026, the Company recognized approximately $37.7 million in revenues that were included in the contract liabilities balance at September 30, 2025. At September 30, 2025, contract assets, contract liabilities and accounts receivable totaled $90.7 million, $224.7 million and $253.6 million, respectively.


## ese:OperatingAndFinancingLeasesOfLesseeDisclosureTextBlock

[0001104659-26-011932:notes:72]
12.  LEASES

[0001104659-26-011932:notes:73]
[same as prior period, unchanged from 0001410578-25-001667:notes:80]

[0001104659-26-011932:notes:74]
[same as prior period, unchanged from 0001410578-25-001667:notes:81]

[0001104659-26-011932:notes:75]
In addition to the base rent, real estate leases typically contain provisions for common-area maintenance and other similar services, which are considered non-lease components for accounting purposes. Non-lease components are excluded from ROU assets and lease liabilities and expensed as incurred.

[0001104659-26-011932:notes:76]
[same as prior period, unchanged from 0001410578-25-001667:notes:83]

[0001104659-26-011932:notes:77]
[same as prior period, unchanged from 0001410578-25-001667:notes:84]

[0001104659-26-011932:notes:78]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended |
| ​ | ​ | December 31, | ​ | December 31, |
| (Dollars in thousands) | ​ ​ ​ | 2025 | ​ ​ ​ | 2024 |
| Finance lease cost | ​ | ​ | ​ | ​ | ​ |
| Amortization of right-of-use assets | ​ | $ | 372 | ​ | 372 |
| Interest on lease liabilities | ​ | ​ | 192 | ​ | 206 |
| Operating lease cost | ​ | ​ | 2,229 | ​ | 1,714 |
| Total lease costs | ​ | $ | 2,793 | ​ | 2,292 |

[0001104659-26-011932:notes:79]
[same as prior period, unchanged from 0001410578-25-001667:notes:87]

[0001104659-26-011932:notes:80]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended |
| ​ | ​ | December 31, | ​ | December 31, |
| (Dollars in thousands) | ​ ​ ​ | 2025 | ​ ​ ​ | 2024 |
| Cash paid for amounts included in the measurement of lease liabilities | ​ | ​ | ​ | ​ | ​ |
| Operating cash flows from operating leases | ​ | $ | 1,996 | ​ | 1,665 |
| Operating cash flows from finance leases | ​ | ​ | 192 | ​ | 206 |
| Financing cash flows from finance leases | ​ | ​ | 382 | ​ | 351 |
| Right-of-use assets obtained in exchange for lease liabilities | ​ | ​ | ​ | ​ | ​ |
| Operating leases | ​ | $ | 465 | ​ | 1,776 |

[0001104659-26-011932:notes:81]
| ​ | ​ ​ ​ | Three Months Ended | ​ | Three Months Ended | ​ |
| ​ | ​ | December 31, | ​ ​ ​ | December 31, | ​ |
| ​ | ​ | 2025 | ​ | 2024 | ​ |
| Weighted-average remaining lease term | ​ | ​ | ​ | ​ | ​ |
| Operating leases |  | 9.1 | years | 8.5 | years |
| Finance leases |  | 9.5 | years | 10.2 | years |
| Weighted-average discount rate |  | ​ |  | ​ |  |
| Operating leases |  | 4.7 | % | 4.4 | % |
| Finance leases |  | 4.7 | % | 4.7 | % |

[0001104659-26-011932:notes:82]
The following is a reconciliation of future undiscounted cash flows to the operating and finance lease liabilities, and the related ROU assets, presented on the Consolidated Balance Sheet on December 31, 2025:

[0001104659-26-011932:notes:83]
| (Dollars in thousands) | ​ | Operating | ​ ​ ​ | Finance |
| Years Ending September 30: | ​ ​ ​ | Leases | ​ ​ ​ | Leases |
| 2026(excluding the three months ended December 31, 2025) | ​ | $ | 6,056 | ​ | 1,723 |
| 2027 | ​ | ​ | 7,824 | ​ | 2,357 |
| 2028 | ​ | ​ | 7,696 | ​ | 2,417 |
| 2029 | ​ | ​ | 6,234 | ​ | 2,478 |
| 2030 and thereafter | ​ | ​ | 33,708 | ​ | 11,575 |
| Total minimum lease payments | ​ | ​ | 61,518 | ​ | 20,550 |
| Less: amounts representing interest | ​ | ​ | 12,098 | ​ | 4,379 |
| Present value of net minimum lease payments | ​ | $ | 49,420 | ​ | 16,171 |
| Less: current portion of lease obligations | ​ | ​ | 5,954 | ​ | 1,584 |
| Non-current portion of lease obligations | ​ | $ | 43,466 | ​ | 14,587 |
| ROU assets | ​ | $ | 46,592 | ​ | 11,822 |

[0001104659-26-011932:notes:84]
Operating lease liabilities are included on the Consolidated Balance Sheet in accrued other expenses (current portion) and as a caption on the Consolidated Balance Sheet (long-term portion). Finance lease liabilities are included on the Consolidated Balance Sheet in accrued other expenses (current portion) and other liabilities (long-term portion). Operating lease ROU assets are included as a caption on the Consolidated Balance Sheet and finance lease ROU assets are included in Property, plant and equipment on the Consolidated Balance sheet.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001104659-26-011932:notes:85]
13.  RECENT ACCOUNTING PRONOUNCEMENTS

[0001104659-26-011932:notes:86]
In November 2024, the FASB issued ASU 2024-03, “Disaggregation of Income Statement Expenses,” which requires disaggregated disclosure of income statement expenses for public business entities. The ASU does not change the expense captions an entity presents on the face of the income statement; rather, it requires disaggregation of certain expense captions into specified categories in disclosures within the footnotes to the financial statements. This ASU will be effective for fiscal years beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027. Other than additional disclosure, we do not expect a change to our consolidated statements of operations, financial position, or cash flows.

[0001104659-26-011932:notes:87]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures,” which provides qualitative and quantitative updates to the rate reconciliation and income taxes paid disclosures. This ASU will be effective for fiscal years beginning after December 15, 2024. Other than additional disclosure, we do not expect a change to our consolidated statements of operations, financial position, or cash flows.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001104659-26-011932:notes:88]
14.  RELATED PARTIES

[0001104659-26-011932:notes:89]
Two of the Company’s directors are officers at two customers of the Company’s Doble subsidiary. Doble sells products, leases equipment and provides testing services in the ordinary course of Doble’s business. The total amount of these sales was approximately $1.3 million during the first quarter of fiscal 2026. All transactions between Doble and the two customers are intended to be and have been consistent with Doble’s normal commercial terms offered to its customers, and the Company’s Board of Directors has determined that the relationships between the Company and the customers are not material and did not impair the Company’s or the directors’ independence.
