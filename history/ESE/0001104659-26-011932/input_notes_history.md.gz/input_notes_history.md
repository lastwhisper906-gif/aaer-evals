# ESE note change history — 0001410578-25-001667 → 0001104659-26-011932


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-02-09):
[0001104659-26-011932:note_history:1]
The accompanying condensed consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP). For further information refer to the consolidated financial statements and related notes included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2025.
  (was, 2025-08-11, similarity 0.9929):
[0001410578-25-001667:note_history:1]
The accompanying condensed consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The condensed consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP). For further information refer to the consolidated financial statements and related notes included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2024.

- changed (2026-02-09):
[0001104659-26-011932:note_history:2]
The Company’s results for the three-month period ended December 31, 2025 are not necessarily indicative of the results for the entire 2026 fiscal year. References to the first quarters of 2026 and 2025 represent the fiscal quarters ended December 31, 2025 and 2024, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.
  (was, 2025-08-11, similarity 0.9646):
[0001410578-25-001667:note_history:2]
The Company’s results for the three-month period ended June 30, 2025 are not necessarily indicative of the results for the entire 2025 fiscal year. References to the third quarters of 2025 and 2024 represent the fiscal quarters ended June 30, 2025 and 2024, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-02-09):
[0001104659-26-011932:note_history:3]
| ​ | ​ ​ ​ | December 31, | ​ | September 30, |
| (In thousands) | ​ ​ ​ | 2025 | ​ ​ ​ | 2025 |
| Revolving credit facility and short-term borrowings | ​ | ​ | 20,511 | ​ | 25,000 |
| Incremental facility (Term loan A) | ​ | ​ | 125,000 | ​ | 161,000 |
| Total borrowings | ​ | $ | 145,511 | ​ | 186,000 |
| Current portion of long-term debt and short-term borrowings | ​ | ​ | (20,511) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 125,000 | ​ | 166,000 |

- changed (2026-02-09):
[0001104659-26-011932:note_history:4]
On August 5, 2024, the Company and certain of its subsidiaries entered into Amendment No. 1 (the “Amendment”) to the Credit Facility which, among other things, (i) implements a senior incremental delayed draw term loan credit facility in an aggregate principal amount of up to $375 million (the “Incremental Facility”), and (ii) permits the direct or indirect acquisition by the Registrant or certain of its subsidiaries of all the issued and outstanding shares of PMES I Limited, Measurement Systems, Inc., EMS Development Corporation, and DNE Technologies, Inc. (the “Maritime Acquisition”), pursuant to and in accordance with the terms and conditions of that certain Sale and Purchase Agreement, dated July 8, 2024, among Ultra Electronics Holdings Limited, as parent seller, the Registrant, as guarantor, and certain of the Registrant’s subsidiaries as buyers. During the third quarter of 2025, the proceeds of the loans drawn under the Incremental Facility were applied to pay a portion of the cash consideration for the Maritime Acquisition and other customary fees, premiums, expenses and costs incurred in connection with the acquisition.
  (was, 2025-08-11, similarity 0.6029):
[0001410578-25-001667:note_history:4]
On August 5, 2024, the Company and certain of its subsidiaries entered into Amendment No. 1 to the Credit Facility which, among other things, (i) implements a senior incremental delayed draw term loan credit facility in an aggregate principal amount of up to $375 million (the “Incremental Facility”), and (ii) permits the direct or indirect acquisition by the Registrant or certain of its subsidiaries of all the issued and outstanding shares of Ultra PMES Limited, Measurement Systems, Inc., EMS Development

- added (2026-02-09):
[0001104659-26-011932:note_history:5]
At December 31, 2025, the Company had approximately $469 million available to borrow under the Credit Facility, excluding the Incremental Facility, plus the $250 million increase option subject to the lenders’ consent, in addition to $103.8 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of December 31, 2025, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. In addition, the Company had $0.5 million of short-term borrowings at its foreign locations outstanding as of December 31, 2025. The letters of credit issued and outstanding under the Credit Facility totaled $10.7 million at December 31, 2025.

- changed (2026-02-09):
[0001104659-26-011932:note_history:6]
Interest on borrowings under the Credit Facility is calculated at a spread over either an Adjusted Term SOFR Rate, Adjusted EURIBOR Rate, Adjusted CDOR Rate, Alternate Base Rate or Daily Simple RFR, at the Company’s election. The Credit Facility also requires a facility fee ranging from 12.5 to 25 basis points per annum. The interest rate spreads and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio. The weighted average interest rates under the Credit Facility were 5.7% and 6.1% for the three-month periods ending December 31, 2025 and 2024, respectively. The weighted average interest rate under the Incremental Facility was 5.6% for the three-month period ending December 31, 2025. As of December 31, 2025, the Company was in compliance with all covenants.
  (was, 2025-08-11, similarity 0.6497):
[0001410578-25-001667:note_history:6]
Interest on borrowings under the Credit Facility and the Incremental Facility is calculated at a spread ranging from 0.25% to 2.25% over either an Adjusted Term SOFR Rate, Adjusted EURIBOR Rate, Adjusted CDOR Rate, Alternate Base Rate or Daily Simple RFR, at the Company’s election. The Credit Facility also requires a facility fee ranging from 12.5 to 25 basis points per annum on the unused portion. The interest rate spreads and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio. The weighted average interest rates under the Credit Facility were 6.03% and 5.99% for the three and nine-month periods ending June 30, 2025, respectively, and 6.71% and 6.75% for the three and nine-month periods ending June 30, 2024. The weighted average interest rate under the Incremental Facility was 6.42% for the three-month period ending June 30, 2025. As of June 30, 2025, the Company was in compliance with all covenants.

- removed (2026-02-09):
[0001410578-25-001667:note_history:7]
| ​ |  | June 30, | ​ | September 30, |
| (In thousands) |  | 2025 |  | 2024 |
| Revolving credit facility | ​ | ​ | 155,000 | ​ | 122,000 |
| Incremental facility (Term loan A) | ​ | ​ | 370,000 | ​ | — |
| Total borrowings | ​ | $ | 525,000 | ​ | 122,000 |
| Current portion of long-term debt | ​ | ​ | (20,000) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 505,000 | ​ | 102,000 |

- removed (2026-02-09):
[0001410578-25-001667:note_history:8]
Corporation, and DNE Technologies, Inc. (the “SM&P Acquisition), pursuant to and in accordance with the terms and conditions of that certain Sale and Purchase Agreement, dated July 8, 2024. During the third quarter of 2025, the proceeds of the loans drawn under the Incremental Facility were applied to pay a portion of the cash consideration for the Maritime Acquisition and other customary fees, premiums, expenses and costs incurred in connection with the acquisition. The Incremental Facility matures August 30, 2028, with balance due by this date.

- removed (2026-02-09):
[0001410578-25-001667:note_history:9]
At June 30, 2025, the Company had approximately $338 million available to borrow under the Credit Facility, plus the $250 million increase option subject to the lenders’ consent, in addition to $78.7 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of June 30, 2025, as the Company intends to repay this amount as obligated by the repayment terms of the Incremental Facility within the next twelve months. The Company is obligated to repay the Incremental Facility Loan on the last day of each fiscal quarter, commencing on September 30, 2025 (the first full quarter ending after the Funding Date), in an amount equal to (a) 1.25% of the original aggregate principal amount of the Loans for each of the first twelve fiscal quarters ending after the Funding date, and (b) 1.875% of the original aggregate principal amount of the Loans for each fiscal quarter thereafter until the Maturity Date. The letters of credit issued and outstanding under the Credit Facility totaled $7.2 million at June 30, 2025.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-02-09):
[0001104659-26-011932:note_history:10]
| ​ | ​ ​ ​ | December 31, | ​ | September 30, |
| (In thousands) | ​ ​ ​ | 2025 | ​ ​ ​ | 2025 |
| Revolving credit facility and short-term borrowings | ​ | ​ | 20,511 | ​ | 25,000 |
| Incremental facility (Term loan A) | ​ | ​ | 125,000 | ​ | 161,000 |
| Total borrowings | ​ | $ | 145,511 | ​ | 186,000 |
| Current portion of long-term debt and short-term borrowings | ​ | ​ | (20,511) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 125,000 | ​ | 166,000 |

- removed (2026-02-09):
[0001410578-25-001667:note_history:11]
| ​ |  | June 30, | ​ | September 30, |
| (In thousands) |  | 2025 |  | 2024 |
| Revolving credit facility | ​ | ​ | 155,000 | ​ | 122,000 |
| Incremental facility (Term loan A) | ​ | ​ | 370,000 | ​ | — |
| Total borrowings | ​ | $ | 525,000 | ​ | 122,000 |
| Current portion of long-term debt | ​ | ​ | (20,000) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 505,000 | ​ | 102,000 |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: no_prior_note, score: 0.0

- added (2026-02-09):
[0001104659-26-011932:note_history:12]
14.  RELATED PARTIES

- added (2026-02-09):
[0001104659-26-011932:note_history:13]
Two of the Company’s directors are officers at two customers of the Company’s Doble subsidiary. Doble sells products, leases equipment and provides testing services in the ordinary course of Doble’s business. The total amount of these sales was approximately $1.3 million during the first quarter of fiscal 2026. All transactions between Doble and the two customers are intended to be and have been consistent with Doble’s normal commercial terms offered to its customers, and the Company’s Board of Directors has determined that the relationships between the Company and the customers are not material and did not impair the Company’s or the directors’ independence.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2026-02-09):
[0001104659-26-011932:note_history:14]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2025 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within each reportable segment.

- changed (2026-02-09):
[0001104659-26-011932:note_history:15]
| (In thousands) | ​ ​ ​ | A&D | ​ ​ ​ | USG | ​ ​ ​ | Test | ​ ​ ​ | Total |
| Customer type: |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |
| Commercial | ​ | $ | 45,796 | ​ | $ | 85,739 | ​ | $ | 46,317 | ​ | $ | 177,852 |
| Government | ​ | ​ | 98,033 | ​ | ​ | 1,745 | ​ | ​ | 12,029 | ​ | ​ | 111,807 |
| Total revenues | ​ | $ | 143,829 | ​ | $ | 87,484 | ​ | $ | 58,346 | ​ | $ | 289,659 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 92,786 | ​ | $ | 60,724 | ​ | $ | 36,482 | ​ | $ | 189,992 |
| International | ​ | ​ | 51,043 | ​ | ​ | 26,760 | ​ | ​ | 21,864 | ​ | ​ | 99,667 |
| Total revenues | ​ | $ | 143,829 | ​ | $ | 87,484 | ​ | $ | 58,346 | ​ | $ | 289,659 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 66,534 | ​ | $ | 68,289 | ​ | $ | 9,217 | ​ | $ | 144,040 |
| Over time | ​ | ​ | 77,295 | ​ | ​ | 19,195 | ​ | ​ | 49,129 | ​ | ​ | 145,619 |
| Total revenues | ​ | $ | 143,829 | ​ | $ | 87,484 | ​ | $ | 58,346 | ​ | $ | 289,659 |
  (was, 2025-08-11, similarity 0.9033):
[0001410578-25-001667:note_history:15]
| Three months ended June 30, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 57,297 | ​ | $ | 87,653 | ​ | $ | 50,591 | ​ | $ | 195,541 |
| Government | ​ | ​ | 79,027 | ​ | ​ | 4,704 | ​ | ​ | 17,072 | ​ | ​ | 100,803 |
| Total revenues | ​ | $ | 136,324 | ​ | $ | 92,357 | ​ | $ | 67,663 | ​ | $ | 296,344 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 94,518 | ​ | $ | 63,062 | ​ | $ | 36,188 | ​ | $ | 193,768 |
| International | ​ | ​ | 41,806 | ​ | ​ | 29,295 | ​ | ​ | 31,475 | ​ | ​ | 102,576 |
| Total revenues | ​ | $ | 136,324 | ​ | $ | 92,357 | ​ | $ | 67,663 | ​ | $ | 296,344 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 66,833 | ​ | $ | 74,143 | ​ | $ | 11,123 | ​ | $ | 152,099 |
| Over time | ​ | ​ | 69,491 | ​ | ​ | 18,214 | ​ | ​ | 56,540 | ​ | ​ | 144,245 |
| Total revenues | ​ | $ | 136,324 | ​ | $ | 92,357 | ​ | $ | 67,663 | ​ | $ | 296,344 |

- added (2026-02-09):
[0001104659-26-011932:note_history:16]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2024 are presented in the table below:

- changed (2026-02-09):
[0001104659-26-011932:note_history:17]
| (In thousands) | ​ ​ ​ | A&D | ​ ​ ​ | USG | ​ ​ ​ | Test | ​ ​ ​ | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 45,755 | ​ | $ | 84,279 | ​ | $ | 36,349 | ​ | $ | 166,383 |
| Government | ​ | ​ | 36,113 | ​ | ​ | 2,381 | ​ | ​ | 9,716 | ​ | ​ | 48,210 |
| Total revenues | ​ | $ | 81,868 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 214,593 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 65,314 | ​ | $ | 59,917 | ​ | $ | 28,630 | ​ | $ | 153,861 |
| International | ​ | ​ | 16,554 | ​ | ​ | 26,743 | ​ | ​ | 17,435 | ​ | ​ | 60,732 |
| Total revenues | ​ | $ | 81,868 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 214,593 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 46,995 | ​ | $ | 69,278 | ​ | $ | 9,791 | ​ | $ | 126,064 |
| Over time | ​ | ​ | 34,873 | ​ | ​ | 17,382 | ​ | ​ | 36,274 | ​ | ​ | 88,529 |
| Total revenues | ​ | $ | 81,868 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 214,593 |
  (was, 2025-08-11, similarity 0.9394):
[0001410578-25-001667:note_history:17]
| Three months ended June 30, 2024 | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 43,927 | ​ | $ | 88,076 | ​ | $ | 42,327 | ​ | $ | 174,330 |
| Government | ​ | ​ | 43,308 | ​ | ​ | 2,201 | ​ | ​ | 13,729 | ​ | ​ | 59,238 |
| Total revenues | ​ | $ | 87,235 | ​ | $ | 90,277 | ​ | $ | 56,056 | ​ | $ | 233,568 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 69,228 | ​ | $ | 54,063 | ​ | $ | 32,575 | ​ | $ | 155,866 |
| International | ​ | ​ | 18,007 | ​ | ​ | 36,214 | ​ | ​ | 23,481 | ​ | ​ | 77,702 |
| Total revenues | ​ | $ | 87,235 | ​ | $ | 90,277 | ​ | $ | 56,056 | ​ | $ | 233,568 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 51,234 | ​ | $ | 72,985 | ​ | $ | 11,426 | ​ | $ | 135,645 |
| Over time | ​ | ​ | 36,001 | ​ | ​ | 17,292 | ​ | ​ | 44,630 | ​ | ​ | 97,923 |
| Total revenues | ​ | $ | 87,235 | ​ | $ | 90,277 | ​ | $ | 56,056 | ​ | $ | 233,568 |

- removed (2026-02-09):
[0001410578-25-001667:note_history:18]
| Nine months ended June 30, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 151,756 | ​ | $ | 261,581 | ​ | $ | 124,831 | ​ | $ | 538,168 |
| Government | ​ | ​ | 156,063 | ​ | ​ | 8,203 | ​ | ​ | 40,280 | ​ | ​ | 204,546 |
| Total revenues | ​ | $ | 307,819 | ​ | $ | 269,784 | ​ | $ | 165,111 | ​ | $ | 742,714 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 226,444 | ​ | $ | 173,121 | ​ | $ | 97,086 | ​ | $ | 496,651 |
| International | ​ | ​ | 81,375 | ​ | ​ | 96,663 | ​ | ​ | 68,025 | ​ | ​ | 246,063 |
| Total revenues | ​ | $ | 307,819 | ​ | $ | 269,784 | ​ | $ | 165,111 | ​ | $ | 742,714 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 166,191 | ​ | $ | 216,423 | ​ | $ | 32,522 | ​ | $ | 415,136 |
| Over time | ​ | ​ | 141,628 | ​ | ​ | 53,361 | ​ | ​ | 132,589 | ​ | ​ | 327,578 |
| Total revenues | ​ | $ | 307,819 | ​ | $ | 269,784 | ​ | $ | 165,111 | ​ | $ | 742,714 |

- removed (2026-02-09):
[0001410578-25-001667:note_history:19]
| Nine months ended June 30, 2024 | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 126,191 | ​ | $ | 254,765 | ​ | $ | 111,951 | ​ | $ | 492,907 |
| Government | ​ |  | 115,088 | ​ |  | 5,805 | ​ |  | 31,821 | ​ |  | 152,714 |
| Total revenues | ​ | $ | 241,279 | ​ | $ | 260,570 | ​ | $ | 143,772 | ​ | $ | 645,621 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 190,264 | ​ | $ | 165,789 | ​ | $ | 82,370 | ​ | $ | 438,423 |
| International | ​ |  | 51,015 | ​ |  | 94,781 | ​ |  | 61,402 | ​ |  | 207,198 |
| Total revenues | ​ | $ | 241,279 | ​ | $ | 260,570 | ​ | $ | 143,772 | ​ | $ | 645,621 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 137,769 | ​ | $ | 209,973 | ​ | $ | 29,706 | ​ | $ | 377,448 |
| Over time | ​ |  | 103,510 | ​ |  | 50,597 | ​ |  | 114,066 | ​ |  | 268,173 |
| Total revenues | ​ | $ | 241,279 | ​ | $ | 260,570 | ​ | $ | 143,772 | ​ | $ | 645,621 |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-02-09):
[0001104659-26-011932:note_history:20]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2025 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within each reportable segment.
  (was, 2025-08-11, similarity 0.9229):
[0001410578-25-001667:note_history:20]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2025 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue from continuing operations within each reportable segment.

- changed (2026-02-09):
[0001104659-26-011932:note_history:21]
| (In thousands) | ​ ​ ​ | A&D | ​ ​ ​ | USG | ​ ​ ​ | Test | ​ ​ ​ | Total |
| Customer type: |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |
| Commercial | ​ | $ | 45,796 | ​ | $ | 85,739 | ​ | $ | 46,317 | ​ | $ | 177,852 |
| Government | ​ | ​ | 98,033 | ​ | ​ | 1,745 | ​ | ​ | 12,029 | ​ | ​ | 111,807 |
| Total revenues | ​ | $ | 143,829 | ​ | $ | 87,484 | ​ | $ | 58,346 | ​ | $ | 289,659 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 92,786 | ​ | $ | 60,724 | ​ | $ | 36,482 | ​ | $ | 189,992 |
| International | ​ | ​ | 51,043 | ​ | ​ | 26,760 | ​ | ​ | 21,864 | ​ | ​ | 99,667 |
| Total revenues | ​ | $ | 143,829 | ​ | $ | 87,484 | ​ | $ | 58,346 | ​ | $ | 289,659 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 66,534 | ​ | $ | 68,289 | ​ | $ | 9,217 | ​ | $ | 144,040 |
| Over time | ​ | ​ | 77,295 | ​ | ​ | 19,195 | ​ | ​ | 49,129 | ​ | ​ | 145,619 |
| Total revenues | ​ | $ | 143,829 | ​ | $ | 87,484 | ​ | $ | 58,346 | ​ | $ | 289,659 |
  (was, 2025-08-11, similarity 0.9033):
[0001410578-25-001667:note_history:21]
| Three months ended June 30, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 57,297 | ​ | $ | 87,653 | ​ | $ | 50,591 | ​ | $ | 195,541 |
| Government | ​ | ​ | 79,027 | ​ | ​ | 4,704 | ​ | ​ | 17,072 | ​ | ​ | 100,803 |
| Total revenues | ​ | $ | 136,324 | ​ | $ | 92,357 | ​ | $ | 67,663 | ​ | $ | 296,344 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 94,518 | ​ | $ | 63,062 | ​ | $ | 36,188 | ​ | $ | 193,768 |
| International | ​ | ​ | 41,806 | ​ | ​ | 29,295 | ​ | ​ | 31,475 | ​ | ​ | 102,576 |
| Total revenues | ​ | $ | 136,324 | ​ | $ | 92,357 | ​ | $ | 67,663 | ​ | $ | 296,344 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 66,833 | ​ | $ | 74,143 | ​ | $ | 11,123 | ​ | $ | 152,099 |
| Over time | ​ | ​ | 69,491 | ​ | ​ | 18,214 | ​ | ​ | 56,540 | ​ | ​ | 144,245 |
| Total revenues | ​ | $ | 136,324 | ​ | $ | 92,357 | ​ | $ | 67,663 | ​ | $ | 296,344 |

- changed (2026-02-09):
[0001104659-26-011932:note_history:22]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2024 are presented in the table below:
  (was, 2025-08-11, similarity 0.9288):
[0001410578-25-001667:note_history:22]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2024 are presented in the tables below.

- changed (2026-02-09):
[0001104659-26-011932:note_history:23]
| (In thousands) | ​ ​ ​ | A&D | ​ ​ ​ | USG | ​ ​ ​ | Test | ​ ​ ​ | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 45,755 | ​ | $ | 84,279 | ​ | $ | 36,349 | ​ | $ | 166,383 |
| Government | ​ | ​ | 36,113 | ​ | ​ | 2,381 | ​ | ​ | 9,716 | ​ | ​ | 48,210 |
| Total revenues | ​ | $ | 81,868 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 214,593 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 65,314 | ​ | $ | 59,917 | ​ | $ | 28,630 | ​ | $ | 153,861 |
| International | ​ | ​ | 16,554 | ​ | ​ | 26,743 | ​ | ​ | 17,435 | ​ | ​ | 60,732 |
| Total revenues | ​ | $ | 81,868 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 214,593 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 46,995 | ​ | $ | 69,278 | ​ | $ | 9,791 | ​ | $ | 126,064 |
| Over time | ​ | ​ | 34,873 | ​ | ​ | 17,382 | ​ | ​ | 36,274 | ​ | ​ | 88,529 |
| Total revenues | ​ | $ | 81,868 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 214,593 |
  (was, 2025-08-11, similarity 0.9394):
[0001410578-25-001667:note_history:23]
| Three months ended June 30, 2024 | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 43,927 | ​ | $ | 88,076 | ​ | $ | 42,327 | ​ | $ | 174,330 |
| Government | ​ | ​ | 43,308 | ​ | ​ | 2,201 | ​ | ​ | 13,729 | ​ | ​ | 59,238 |
| Total revenues | ​ | $ | 87,235 | ​ | $ | 90,277 | ​ | $ | 56,056 | ​ | $ | 233,568 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 69,228 | ​ | $ | 54,063 | ​ | $ | 32,575 | ​ | $ | 155,866 |
| International | ​ | ​ | 18,007 | ​ | ​ | 36,214 | ​ | ​ | 23,481 | ​ | ​ | 77,702 |
| Total revenues | ​ | $ | 87,235 | ​ | $ | 90,277 | ​ | $ | 56,056 | ​ | $ | 233,568 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 51,234 | ​ | $ | 72,985 | ​ | $ | 11,426 | ​ | $ | 135,645 |
| Over time | ​ | ​ | 36,001 | ​ | ​ | 17,292 | ​ | ​ | 44,630 | ​ | ​ | 97,923 |
| Total revenues | ​ | $ | 87,235 | ​ | $ | 90,277 | ​ | $ | 56,056 | ​ | $ | 233,568 |

- added (2026-02-09):
[0001104659-26-011932:note_history:24]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to performance obligations that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At December 31, 2025, the Company had $1,401.1 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 58% in the next twelve months.

- changed (2026-02-09):
[0001104659-26-011932:note_history:25]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At December 31, 2025, contract assets, contract liabilities and accounts receivable totaled $88.7 million, $259.5 million and $245.3 million, respectively. During the first quarter of 2026, the Company recognized approximately $37.7 million in revenues that were included in the contract liabilities balance at September 30, 2025. At September 30, 2025, contract assets, contract liabilities and accounts receivable totaled $90.7 million, $224.7 million and $253.6 million, respectively.
  (was, 2025-08-11, similarity 0.9309):
[0001410578-25-001667:note_history:25]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At June 30, 2025, contract assets, contract liabilities and accounts receivable from continuing operations totaled $91.7 million, $214.1 million and $238.0 million, respectively. During the first nine months of 2025, the Company recognized approximately $54 million in revenues that were included in the contract liabilities balance at September 30, 2024. At September 30, 2024, contract assets, contract liabilities and accounts receivable from continuing operations totaled $66.7 million, $90.3 million and $222.1 million, respectively.

- removed (2026-02-09):
[0001410578-25-001667:note_history:26]
| Nine months ended June 30, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 151,756 | ​ | $ | 261,581 | ​ | $ | 124,831 | ​ | $ | 538,168 |
| Government | ​ | ​ | 156,063 | ​ | ​ | 8,203 | ​ | ​ | 40,280 | ​ | ​ | 204,546 |
| Total revenues | ​ | $ | 307,819 | ​ | $ | 269,784 | ​ | $ | 165,111 | ​ | $ | 742,714 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 226,444 | ​ | $ | 173,121 | ​ | $ | 97,086 | ​ | $ | 496,651 |
| International | ​ | ​ | 81,375 | ​ | ​ | 96,663 | ​ | ​ | 68,025 | ​ | ​ | 246,063 |
| Total revenues | ​ | $ | 307,819 | ​ | $ | 269,784 | ​ | $ | 165,111 | ​ | $ | 742,714 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 166,191 | ​ | $ | 216,423 | ​ | $ | 32,522 | ​ | $ | 415,136 |
| Over time | ​ | ​ | 141,628 | ​ | ​ | 53,361 | ​ | ​ | 132,589 | ​ | ​ | 327,578 |
| Total revenues | ​ | $ | 307,819 | ​ | $ | 269,784 | ​ | $ | 165,111 | ​ | $ | 742,714 |

- removed (2026-02-09):
[0001410578-25-001667:note_history:27]
| Nine months ended June 30, 2024 | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 126,191 | ​ | $ | 254,765 | ​ | $ | 111,951 | ​ | $ | 492,907 |
| Government | ​ |  | 115,088 | ​ |  | 5,805 | ​ |  | 31,821 | ​ |  | 152,714 |
| Total revenues | ​ | $ | 241,279 | ​ | $ | 260,570 | ​ | $ | 143,772 | ​ | $ | 645,621 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 190,264 | ​ | $ | 165,789 | ​ | $ | 82,370 | ​ | $ | 438,423 |
| International | ​ |  | 51,015 | ​ |  | 94,781 | ​ |  | 61,402 | ​ |  | 207,198 |
| Total revenues | ​ | $ | 241,279 | ​ | $ | 260,570 | ​ | $ | 143,772 | ​ | $ | 645,621 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 137,769 | ​ | $ | 209,973 | ​ | $ | 29,706 | ​ | $ | 377,448 |
| Over time | ​ |  | 103,510 | ​ |  | 50,597 | ​ |  | 114,066 | ​ |  | 268,173 |
| Total revenues | ​ | $ | 241,279 | ​ | $ | 260,570 | ​ | $ | 143,772 | ​ | $ | 645,621 |

- removed (2026-02-09):
[0001410578-25-001667:note_history:28]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At June 30, 2025, the Company had $1,165.4 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 66% in the next twelve months.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2026-02-09):
[0001410578-25-001667:note_history:29]
16. SUBSEQUENT EVENT

- removed (2026-02-09):
[0001410578-25-001667:note_history:30]
See subsequent event item noted in footnote 4 related to the Company’s divestiture of VACCO.
