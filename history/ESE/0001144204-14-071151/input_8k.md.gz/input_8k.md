# ESE 8-K — 0000866706-14-000015 filed 2014-11-13

## item codes, every 8-K on or before 2014-11-26

- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2014-11-26

- none on or before 2014-11-26

## item 2.02 — earnings release, exhibit 99.1

[0000866706-14-000015:8k_2_02:1]
EX-99.1
2
escopressrelease.htm
ESCO TECHNOLOGIES PRESS RELEASE

[0000866706-14-000015:8k_2_02:2]
escopressrelease.htm

[0000866706-14-000015:8k_2_02:3]
EXHIBIT 99.1

[0000866706-14-000015:8k_2_02:4]
NEWS FROM

[0000866706-14-000015:8k_2_02:5]
For more information contact:

[0000866706-14-000015:8k_2_02:6]
Kate Lowrey

[0000866706-14-000015:8k_2_02:7]
Director, Investor Relations

[0000866706-14-000015:8k_2_02:8]
ESCO Technologies Inc.

[0000866706-14-000015:8k_2_02:9]
(314) 213-7277

[0000866706-14-000015:8k_2_02:10]
ESCO ANNOUNCES FISCAL YEAR 2014 RESULTS

[0000866706-14-000015:8k_2_02:11]
ST. LOUIS, November 13, 2014 – ESCO Technologies Inc. (NYSE: ESE) (ESCO or the “Company”) today reported its operating results for the fourth quarter and fiscal year ended September 30, 2014.

[0000866706-14-000015:8k_2_02:12]
The 2014 results are presented on a Continuing Operations –As Adjusted basis, consistent with the 2013 presentation. The 2014 results exclude $1.7 million, or $0.05 per share, of charges related to the exit and relocation of Crissair’s Palmdale, California (Filtration segment) operation into the Canyon Engineering facility in Valencia, California. This move was completed as of September 30, 2014. The move impacted the fourth quarter results by ($0.02) per share, and ($0.05) per share for the full year.

[0000866706-14-000015:8k_2_02:13]
Management believes EPS from Continuing Operations – As Adjusted is more representative of the Company’s 2014 ongoing performance and allows shareholders better visibility into the Company’s underlying operations.

[0000866706-14-000015:8k_2_02:14]
All references to Continuing Operations exclude Aclara Technologies LLC, which was divested on March 28, 2014. Aclara’s results for all periods presented are included as Discontinued Operations as described below.

[0000866706-14-000015:8k_2_02:15]
EPS Summary

[0000866706-14-000015:8k_2_02:16]
EPS from Continuing Operations –As Adjusted for the fourth quarter ended September 30, 2014 was $0.51 per share and reflects the add-back of $0.02 per share of non-operating charges related to the Crissair consolidation. Management previously provided EPS guidance from Continuing Operations – As Adjusted in the range of $0.44 to $0.48 per share for the fourth quarter of 2014.

[0000866706-14-000015:8k_2_02:17]
EPS from Continuing Operations –As Adjusted was $0.59 per share in the fourth quarter of 2013, which reflects an add-back of $0.07 per share related to 2013’s actions.

[0000866706-14-000015:8k_2_02:18]
For the year ended September 30, 2014, EPS from Continuing Operations – As Adjusted was $1.65 per share, which reflects a $0.05 per share add-back of non-operating charges, compared to EPS from Continuing Operations – As Adjusted of $1.47 per share in 2013, which reflects a $0.30 per share add-back of non-operating charges.

[0000866706-14-000015:8k_2_02:19]
Continuing Operations Highlights

[0000866706-14-000015:8k_2_02:20]
| · | Q4 2014 sales increased $6 million, or 5 percent to $151 million compared to $145 million in Q4 2013; |

[0000866706-14-000015:8k_2_02:21]
| · | 2014 sales increased $41 million, or 8 percent to $531 million compared to $490 million in 2013. Compared to 2013, Filtration sales increased 9 percent, Test sales increased 9 percent, and Utility Solutions Group (USG, or Doble) sales increased 6 percent; |

[0000866706-14-000015:8k_2_02:22]
| · | The annual effective tax rates used for calculating EPS from Continuing Operations – As Adjusted were 31.6 percent in 2014 and 31.4 percent in 2013; |

[0000866706-14-000015:8k_2_02:23]
| · | GAAP EPS from Continuing Operations was $1.60 per share in 2014, compared to $1.17 per share in 2013; |

[0000866706-14-000015:8k_2_02:24]
| · | Net cash provided by operating activities (Continuing Operations) was $45 million in 2014, compared to $37 million in 2013, resulting in a net debt position of $5 million at September 30, 2014; |

[0000866706-14-000015:8k_2_02:25]
| · | Q4 2014 Orders were $162 million (book-to-bill of 1.07x), and total year orders were $562 million (book-to-bill of 1.06x), resulting in an order backlog of $303 million at September 30, 2014 (reflecting a $31 million and 11 percent annual increase); |

[0000866706-14-000015:8k_2_02:26]
| · | The Company returned $20.5 million to shareholders through dividends ($8.5 million) and share repurchases ($12 million, and 350,000 shares) during 2014. |

[0000866706-14-000015:8k_2_02:27]
Chairman’s Commentary – FY 2014

[0000866706-14-000015:8k_2_02:28]
Vic Richey, Chairman and Chief Executive Officer, commented, “I’m very pleased with our 2014 operating results and our overall performance throughout the year. We set several aggressive operating targets at the beginning of the year and I’m proud to say that we exceeded our expectations on EPS, cash flow and orders.

[0000866706-14-000015:8k_2_02:29]
“Our goals at the start of 2014 were straightforward: sell Aclara, pay down debt, successfully execute our operating plan, and deliver solid EPS performance. We accomplished each of these goals and all three operating segments contributed to 2014’s success.

[0000866706-14-000015:8k_2_02:30]
“Although we are smaller from a revenue perspective without Aclara, 2014 has shown that we can be more profitable, stable and predictable. With our current mix of businesses, we have far less volatility and considerably better visibility, which allows us to focus our full attention on execution and growth.

[0000866706-14-000015:8k_2_02:31]
“While we were not able to close any acquisitions during 2014, we looked at a number of opportunities, passed on some, lost some on price, and continue to actively work several others. While acquisitions are key to supplementing our growth, we will remain disciplined in this area to ensure we can generate an appropriate and attractive return on these investments.”

[0000866706-14-000015:8k_2_02:32]
Discontinued Operations

[0000866706-14-000015:8k_2_02:33]
The Company completed the Aclara divestiture on March 28, 2014 and used the proceeds to significantly pay down its outstanding debt. The results of operations for Aclara prior to its divestiture, and the net loss on sale are reflected in the financial statements as Discontinued Operations and Assets Held for Sale. The Company and the buyer have not yet reached agreement on the final working capital adjustment.

[0000866706-14-000015:8k_2_02:34]
Capital Allocation – Share Repurchase

[0000866706-14-000015:8k_2_02:35]
The Company has sufficient available liquidity under its existing credit facility to support its strategy of profitable organic growth, accretive acquisitions around its existing core businesses, and opportunistic repurchases of outstanding shares. The Company expects to accelerate the realization of shareholder value through these various means.

[0000866706-14-000015:8k_2_02:36]
During the fourth quarter of 2014, the Company spent $8.4 million to repurchase 245,000 shares on the open market. As noted above, 2014 share repurchases totaled $12 million and 350,000 shares.  Subsequent to fiscal year-end, in October 2014, the Company spent an additional $1.2 million on share repurchases, bringing the total to $13.2 million and 385,000 shares.

[0000866706-14-000015:8k_2_02:37]
The Board of Directors has authorized share repurchases to continue through September 30, 2015.

[0000866706-14-000015:8k_2_02:38]
Dividend Payment

[0000866706-14-000015:8k_2_02:39]
The next quarterly cash dividend of $0.08 per share will be paid on January 16, 2014 to stockholders of record on January 2, 2014.

[0000866706-14-000015:8k_2_02:40]
Business Outlook – Fiscal Year 2015 (and 3 Year Update)

[0000866706-14-000015:8k_2_02:41]
Management continues to see sales, EBIT, and EPS growth across the business segments consistent with the three-year expectations communicated in the Company’s September 9, 2014 Analyst Day Presentation (included on the Company’s website).

[0000866706-14-000015:8k_2_02:42]
The Company’s goals and expectations through 2017 reflect compound annual sales growth of 10 percent, with compound annual EPS growth of 15 percent, with approximately 80 percent of the growth being organic and approximately 20 percent coming from future acquisitions.

[0000866706-14-000015:8k_2_02:43]
While 2015 expectations reflect lower than normal growth due to timing issues on two large programs, and a higher expected tax rate, the three-year outlook remains unchanged.

[0000866706-14-000015:8k_2_02:44]
The 2015 sales outlook is expected to be muted by lower Space sales at VACCO (SLS program timing) and the lower project sales at TEQ related to its KAZ/Thermoscan project (introduction of Generation 2 product).

[0000866706-14-000015:8k_2_02:45]
The SLS (launch vehicles) program remains a critical project for NASA, and while the overall project revenues increased over the remaining life of the development stage, the customer recently informed the Company that the 2015 revenues are expected to be lower than 2014 as NASA has decided to smooth the spending timeline over the next 3 years. This is expected to result in lower revenues in 2015 ($10 million less than the original plan) and higher revenues in 2016 (by $10 million) and 2017 (by $5 million) compared to earlier project timelines.

[0000866706-14-000015:8k_2_02:46]
During 2014, the KAZ project at TEQ was extended an additional three years and an additional $30 million of anticipated revenues were added to the overall project bringing the total expected revenues to approximately $80 million. The original contract covered five years of production beginning in October 2010 with approximately $50 million of revenues. The 2014 extension included an upgrade to a next generation (Gen 2) probe cover to be compatible with a newly designed thermometer. In conjunction with further product design enhancements occurring during the first quarter of 2015, TEQ’s production revenue from the KAZ project will be temporarily limited, resulting in approximately $3 million of sales being pushed into future years.

[0000866706-14-000015:8k_2_02:47]
During 2015, the Company’s effective tax rate is expected to be 35 percent, compared to the adjusted effective tax rate of 31.6 percent in 2014.

[0000866706-14-000015:8k_2_02:48]
As a result of the above noted items, Management expects 2015 sales growth of 2 to 5 percent, EBIT growth of 8 to 10 percent, and EPS in the range of $1.70 to $1.80 per share.

[0000866706-14-000015:8k_2_02:49]
The segment expectations for 2015 are presented in summary fashion:

[0000866706-14-000015:8k_2_02:50]
| · | Filtration sales are expected to be lower than 2014 due to the VACCO and TEQ items noted above. Partially offsetting VACCO and TEQ, PTI and Crissair sales are expected to increase approximately 7 percent and 5 percent, respectively, with EBIT dollars expected to increase approximately 10 percent at both locations. Segment EBIT margin is expected to increase to approximately 19 percent of sales; |

[0000866706-14-000015:8k_2_02:51]
| · | Test sales are expected to increase between 5 and 7 percent, with EBIT dollars expected to increase between 15 and 17 percent, resulting in an expected EBIT margin of approximately 13 percent of sales; and, |

[0000866706-14-000015:8k_2_02:52]
| · | Doble sales are expected to increase between 8 and 10 percent with an expected EBIT margin percentage increasing to approximately 24 percent of sales. |

[0000866706-14-000015:8k_2_02:53]
On a quarterly basis, Management expects 2015 revenues and EPS to reflect a profile similar to 2014, including the EPS being more second half weighted. First quarter 2015 EPS is expected to be in the range of $0.28 to $0.33 per share.

[0000866706-14-000015:8k_2_02:54]
Chairman’s Commentary – FY 2015

[0000866706-14-000015:8k_2_02:55]
“While I’m disappointed with the impact that the VACCO and TEQ timing items have on 2015, it is clear to me that the deferred benefit expected to be realized in 2016 and 2017 from these programs will outweigh the short-term pressure.

[0000866706-14-000015:8k_2_02:56]
“I’m excited to see the growth at Doble and Test as it validates the investments we made in both groups over the past years. Doble’s new products and new geographies show great promise as they move forward. Test’s global reach, supplemented with the prospects in the EMP market, have us poised for growth over the foreseeable future. In Filtration, we are nearing the acceleration of production and launch of the new aerospace platforms such as the Airbus A-350, along with the regional jets and business jets. I’m excited to see the revenue and profit potential these bring to our near-term outlook.

[0000866706-14-000015:8k_2_02:57]
“I firmly believe our market leadership positions across the three segments, along with the breadth of our new product offerings, will continue to allow us to grow organically at a meaningful level. As such, we remain committed to our three year targets.

[0000866706-14-000015:8k_2_02:58]
“Consistent with our stated goals, in 2015 we intend to supplement our organic growth through disciplined acquisitions around our existing core as we continue to actively explore growth opportunities. We will continue to invest in new products and solutions which will allow us to retain and expand our leadership positions in all of our operations, and we will continue to support our Capital Allocation Strategy by returning cash to shareholders.

[0000866706-14-000015:8k_2_02:59]
“I continue to maintain a favorable view of our future and our goal remains the same – to increase long-term shareholder value.”

[0000866706-14-000015:8k_2_02:60]
Conference Call

[0000866706-14-000015:8k_2_02:61]
The Company will host a conference call today, November 13, at 4:00 p.m. Central Time, to discuss the Company’s 2014 results from Continuing Operations. A live audio webcast will be available on the Company’s website at www.escotechnologies.com. Please access the website at least 15 minutes prior to the call to register, download and install any necessary audio software. A replay of the conference call will be available for seven days on the Company’s website noted above or by phone (dial 1-888-843-7419 and enter the pass code 38243312).

[0000866706-14-000015:8k_2_02:62]
Forward-Looking Statements

[0000866706-14-000015:8k_2_02:63]
Statements in this press release regarding the Company’s expected 2015 and beyond revenue and sales growth, EBIT, EBIT Margin, effective tax rates, EPS, NASA spending, the Company’s ability to increase shareholder value, the success of acquisition efforts, the success of new products and solutions, the size, number and timing of growth opportunities in the future, the specific actions initiated as a result of the Capital Allocation Strategy including but not limited to the declaration of dividends and share repurchases, the long-term success of the Company, and any other statements which are not strictly historical are “forward-looking” statements within the meaning of the safe harbor provisions of the federal securities laws. Investors are cautioned that such statements are only predictions and speak only as of the date of this release, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations.

[0000866706-14-000015:8k_2_02:64]
The Company’s actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment including, but not limited to: those described in Item 1A, “Risk Factors”, of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2013; and the following: the success of the Company’s competitors; site readiness issues with Test segment customers; weakening of economic conditions in served markets; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties; unforeseen charges impacting corporate operating expenses; delivery delays or defaults by customers; the performance of the Company’s international operations; material changes in the costs and availability of certain raw materials; the appropriation and allocation of Government funds; the termination for convenience of Government and other customer contracts; timing and content of future contract awards and customer orders; containment of engineering and development costs; performance issues with key customers, suppliers and subcontractors; labor disputes; the impacts of natural disasters on the Company’s operations and those of the Company’s customers and suppliers; changes in laws and regulations, including but not limited to changes in accounting standards and taxation requirements; costs relating to environmental matters arising from current or former facilities; financial exposure in connection with Company guarantees of certain Aclara contracts; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the Company’s successful execution of profit improvement initiatives and restructuring activities.

[0000866706-14-000015:8k_2_02:65]
Non-GAAP Financial Measures

[0000866706-14-000015:8k_2_02:66]
The financial measures EBIT, EBIT margin, EPS – “As Adjusted” and EPS – from Continuing Operations “As Adjusted” are presented in this press release. The Company defines EBIT as earnings before interest and taxes from continuing operations, EBIT margin as a percent of net sales, EPS – “As Adjusted” and EPS – from Continuing Operations “As Adjusted” as GAAP EPS less the Filtration segment restructuring charges (representing $0.02 per share during the fourth quarter of 2014, and $0.05 per share during fiscal year 2014). EBIT, EBIT margin, EPS – “As Adjusted” and EPS – from Continuing Operations “As Adjusted” are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management believes that EBIT and EBIT margin are useful in assessing the operational profitability of the Company’s business segments because they exclude interest and taxes, which are generally accounted for across the entire Company on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company as well as incentive compensation. The Company believes that the presentation of EBIT, EBIT margin, EPS – “As Adjusted” and EPS – from Continuing Operations “As Adjusted” provides important supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance determined in accordance with GAAP.

[0000866706-14-000015:8k_2_02:67]
ESCO, headquartered in St. Louis, provides engineered filtration products to the aviation, space and process markets worldwide and is the industry leader in RF shielding and EMC test products. In addition, the Company provides diagnostic instruments, services and the world’s premier library of statistically significant apparatus test results for the benefit of energy generation, transmission, and delivery companies and industrial power users worldwide. Further information regarding ESCO and its subsidiaries is available on the Company’s website at www.escotechnologies.com.

[0000866706-14-000015:8k_2_02:68]
- tables attached –

[0000866706-14-000015:8k_2_02:69]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |  |  |  |
| Condensed Consolidated Statements of Operations (Unaudited) |  |  |  |  |
| (Dollars in thousands, except per share amounts) |  |  |  |  |
|  |  |  | Three Months Ended September 30, 2014 |  |  |  |  |  | Three Months Ended September 30, 2013 |  |  |  |  |
| Net Sales |  |  |  | 151,413 |  |  |  |  |  |  | 144,600 |  |  |  |  |

[0000866706-14-000015:8k_2_02:70]
| Cost and Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Cost of sales |  |  | 92,613 |  |  |  |  |  |  | 86,658 |  |  |  |  |
|  | Selling, general and administrative expenses |  |  | 35,717 |  |  |  |  |  |  | 33,011 |  |  |  |  |
|  | Amortization of intangible assets |  |  | 1,697 |  |  |  |  |  |  | 1,637 |  |  |  |  |
|  | Interest expense |  |  | 73 |  |  |  |  |  |  | 695 |  |  |  |  |
|  | Other (income) expenses, net |  |  | 1,342 |  |  |  |  |  |  | 2,193 |  |  |  |  |
|  | Total costs and expenses |  |  | 131,442 |  |  |  |  |  |  | 124,194 |  |  |  |  |
| Earnings before income taxes |  |  | 19,971 |  |  |  |  |  |  | 20,406 |  |  |  |  |
| Income taxes |  |  | 7,044 |  |  |  |  |  |  | 6,526 |  |  |  |  |
|  | Net earnings from continuing operations |  |  | 12,927 |  |  |  |  |  |  | 13,880 |  |  |  |  |
| Loss from discontinued operations, net of tax |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | benefit of $1,613 in 2013 |  |  | 0 |  |  |  |  |  |  | (46,185 | ) |  |  |  |
| Loss on sale of discontinued operations, |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | net of tax benefit of $2,248 in 2014 |  |  | (1,619 | ) |  |  |  |  |  | 0 |  |  |  |  |
|  | Net loss from discontinued operations |  |  | (1,619 | ) |  |  |  |  |  | (46,185 | ) |  |  |  |
|  | Net earnings (loss) |  | $ | 11,308 |  |  |  |  |  |  | (32,305 | ) |  |  |  |
| Earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Diluted - GAAP |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Continuing operations |  |  | 0.49 |  |  |  |  |  |  | 0.52 |  |  |  |  |
|  | Discontinued operations |  |  | (0.06 | ) |  |  |  |  |  | (1.73 | ) |  |  |  |
|  | Net earnings |  | $ | 0.43 |  |  |  |  |  |  | (1.21 | ) |  |  |  |
|  | Diluted - As Adjusted Basis |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Continuing operations |  | $ | 0.51 |  | (1) |  |  |  |  |  | 0.59 |  | (2) |  |  |  |
| Average common shares O/S: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Diluted |  |  | 26,509 |  |  |  |  |  |  |  | 26,777 |  |  |  |  |  |

[0000866706-14-000015:8k_2_02:71]
| (1) | Adjusted basis includes $1.0 million (or $0.02 per share) of add back adjustments |  |  |  |  |  |
|  | for restructuring charges incurred at Crissair during the fourth quarter of fiscal 2014. |  |  |  |  |  |
| (2) | Adjusted basis includes $2.0 million (or $0.07 per share) of add back adjustments |  |  |  |  |  |
|  | for restructuring charges incurred at ETS and Doble Lemke during the fourth |  |  |  |  |  |
|  | quarter of fiscal 2013. |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000866706-14-000015:8k_2_02:72]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |  |
| Condensed Consolidated Statements of Operations (Unaudited) |  |  |
| (Dollars in thousands, except per share amounts) |  |  |
|  |  | Year Ended September 30, 2014 |  |  |  | Year Ended September 30, 2013 |  |  |
| Net Sales |  |  | 531,120 |  |  |  |  | 490,079 |  |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 323,939 |  |  |  |  | 295,863 |  |  |
| Selling, general and administrative expenses |  |  | 134,899 |  |  |  |  | 129,809 |  |  |
| Amortization of intangible assets |  |  | 6,744 |  |  |  |  | 6,179 |  |  |
| Interest expense |  |  | 1,567 |  |  |  |  | 2,693 |  |  |
| Other (income) expenses, net |  |  | 1,764 |  |  |  |  | 5,940 |  |  |
| Total costs and expenses |  |  | 468,913 |  |  |  |  | 440,484 |  |  |
| Earnings before income taxes |  |  | 62,207 |  |  |  |  | 49,595 |  |  |
| Income taxes |  |  | 19,594 |  |  |  |  | 18,335 |  |  |
| Net earnings from continuing operations |  |  | 42,613 |  |  |  |  | 31,260 |  |  |
| Earnings (loss) from discontinued operations, |  |  |  |  |  |  |  |  |  |  |
| net of tax expense (benefit) of $5,713 |  |  |  |  |  |  |  |  |  |  |
| and $(6,825), respectively |  |  | 9,858 |  |  |  |  | (56,863 | ) |  |
| Loss on sale of discontinued operations, |  |  |  |  |  |  |  |  |  |  |
| net of tax benefit of $11,747 |  |  | (52,061 | ) |  |  |  | 0 |  |  |
| Net loss from discontinued operations |  |  | (42,203 | ) |  |  |  | (56,863 | ) |  |
| Net earnings (loss) |  | $ | 410 |  |  |  |  | (25,603 | ) |  |
| Earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  |  | 1.60 |  |  |  |  | 1.17 |  |  |
| Discontinued operations |  |  | (1.58 | ) |  |  |  | (2.13 | ) |  |
| Net (loss) earnings |  | $ | 0.02 |  |  |  |  | (0.96 | ) |  |
| Diluted - As Adjusted Basis |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 1.65 | (1) |  |  |  | 1.47 | (2) |  |
| Average common shares O/S: |  |  |  |  |  |  |  |  |  |  |
| Diluted |  |  | 26,644 |  |  |  |  | 26,802 |  |  |

[0000866706-14-000015:8k_2_02:73]
| (1) | Adjusted basis includes $1.7 million (or $0.05 per share) of add back adjustments for |  |
|  | restructuring charges incurred at Crissair during the year ended September 30, 2014. |  |
| (2) | Adjusted basis includes $7.5 million (or $0.30 per share) of add back adjustments |  |
|  | for restructuring charges incurred at ETS and Doble Lemke during the year ended |  |
|  | September 30, 2013. |  |  |  |  |  |  |

[0000866706-14-000015:8k_2_02:74]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Condensed Business Segment Information (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  | Three Months Ended September 30, GAAP |  |  | Adjustments |  |  |  |  |  | Three Months Ended September 30, As Adjusted |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  |  |  |  | 2013 |  |  |  |  |  | 2014 |  |  | 2013 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 62,088 |  |  |  | 60,348 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 62,088 |  |  |  | 60,348 |  |
| Test |  |  | 56,224 |  |  |  | 54,011 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 56,224 |  |  |  | 54,011 |  |
| Utility Solutions Group |  |  | 33,101 |  |  |  | 30,241 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 33,101 |  |  |  | 30,241 |  |
| Totals |  | $ | 151,413 |  |  |  | 144,600 |  |  |  | 0 |  |  |  |  |  |  | 0 |  |  |  |  |  |  | 151,413 |  |  |  | 144,600 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 11,528 |  |  |  | 11,971 |  |  |  | 1,002 |  | (1) |  |  |  |  |  |  |  |  |  |  |  |  | 12,530 |  |  |  | 11,971 |  |
| Test |  |  | 8,199 |  |  |  | 9,389 |  |  |  |  |  |  |  |  |  |  |  | 54 |  | (2) |  |  |  |  |  | 8,199 |  |  |  | 9,443 |  |
| Utility Solutions Group |  |  | 7,733 |  |  |  | 6,847 |  |  |  |  |  |  |  |  |  |  |  | 1,930 |  | (3) |  |  |  |  |  | 7,733 |  |  |  | 8,777 |  |
| Corporate |  |  | (7,416 | ) |  |  | (7,106 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (7,416 | ) |  |  | (7,106 | ) |
| Consolidated EBIT |  |  | 20,044 |  |  |  | 21,101 |  |  |  | 1,002 |  |  |  |  |  |  |  | 1,984 |  |  |  |  |  |  |  | 21,046 |  |  |  | 23,085 |  |
| Less: Interest expense |  |  | (73 | ) |  |  | (695 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (73 | ) |  |  | (695 | ) |
| Earnings before income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| taxes from Cont Ops |  | $ | 19,971 |  |  |  | 20,406 |  |  |  | 1,002 |  |  |  |  |  |  |  | 1,984 |  |  |  |  |  |  |  | 20,973 |  |  |  | 22,390 |  |
| Note: The above table is presented on a continuing operations basis. |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Note: Depreciation and amortization expense was $4.1 million and $3.9 million |  |  |  |  |  |  |  |  |  |  |  |  |  |
| for the quarters ended September 30, 2014 and 2013, respectively. |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000866706-14-000015:8k_2_02:75]
|  | (1) | Includes $1.0 million (or $0.02) of restructuring charges at Crissair during the fourth quarter 2014. |  |
|  | (2) | Includes $0.1 million (or $0.00) of restructuring charges for ETS during the fourth quarter 2013. |  |  |
|  | (3) | Includes $1.9 million (or $0.07) of restructuring charges for Doble Lemke during the fourth |  |  |
|  |  | quarter 2013. |  |  |  |  |  |  |  |  |  |  |  |  |

[0000866706-14-000015:8k_2_02:76]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Condensed Business Segment Information (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  | Year Ended September 30, GAAP |  |  | Adjustments |  |  |  |  |  | Year Ended September 30, As Adjusted |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  |  |  |  | 2013 |  |  |  |  |  | 2014 |  |  | 2013 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 233,697 |  |  |  | 214,089 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 233,697 |  |  |  | 214,089 |  |
| Test |  |  | 181,755 |  |  |  | 166,689 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 181,755 |  |  |  | 166,689 |  |
| Utility Solutions Group |  |  | 115,668 |  |  |  | 109,301 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 115,668 |  |  |  | 109,301 |  |
| Totals |  | $ | 531,120 |  |  |  | 490,079 |  |  |  | 0 |  |  |  |  |  |  | 0 |  |  |  |  |  |  | 531,120 |  |  |  | 490,079 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 41,406 |  |  |  | 42,355 |  |  |  | 1,725 |  | (1) |  |  |  |  |  |  |  |  |  |  |  |  | 43,131 |  |  |  | 42,355 |  |
| Test |  |  | 21,083 |  |  |  | 16,311 |  |  |  |  |  |  |  |  |  |  |  | 3,424 |  | (2) |  |  |  |  |  | 21,083 |  |  |  | 19,735 |  |
| Utility Solutions Group |  |  | 26,624 |  |  |  | 21,583 |  |  |  |  |  |  |  |  |  |  |  | 2,625 |  | (3) |  |  |  |  |  | 26,624 |  |  |  | 24,208 |  |
| Corporate |  |  | (25,339 | ) |  |  | (27,961 | ) |  |  |  |  |  |  |  |  |  |  | 1,500 |  | (4) |  |  |  |  |  | (25,339 | ) |  |  | (26,461 | ) |
| Consolidated EBIT |  |  | 63,774 |  |  |  | 52,288 |  |  |  | 1,725 |  |  |  |  |  |  |  | 7,549 |  |  |  |  |  |  |  | 65,499 |  |  |  | 59,837 |  |
| Less: Interest expense |  |  | (1,567 | ) |  |  | (2,693 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (1,567 | ) |  |  | (2,693 | ) |
| Earnings before income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| taxes from Cont Ops |  | $ | 62,207 |  |  |  | 49,595 |  |  |  | 1,725 |  |  |  |  |  |  |  | 7,549 |  |  |  |  |  |  |  | 63,932 |  |  |  | 57,144 |  |

[0000866706-14-000015:8k_2_02:77]
|  | Note: The above table is presented on a continuing operations basis. |  |  |  |  |  |
|  | Note: Depreciation and amortization expense was $16.4 million and $14.8 million for |  |  |  |
|  |  | the years ended September 30, 2014 and 2013, respectively. |  |  |  |  |  |  |
|  | (1) | Includes $1.7 million (or $0.05) of restructuring charges at Crissair during the year ended September 30, 2014. |
|  | (2) | Includes $3.4 million (or $0.08) of restructuring charges for ETS during the year ended September 30, 2013. |
|  | (3) | Includes $2.6 million (or $0.10) of restructuring charges for Doble Lemke during the year ended September 30, 2013. |
|  | (4) | Includes $1.5 million (or $0.05) of restructuring charges for Doble Lemke during the year ended September 30, 2013. |

[0000866706-14-000015:8k_2_02:78]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Condensed Consolidated Balance Sheets (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  |  | September 30, 2014 |  |  | September 30, 2013 |  |
| Assets |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 35,131 |  |  |  | 42,850 |  |
| Accounts receivable, net |  |  | 105,449 |  |  |  | 91,980 |  |
| Costs and estimated earnings on |  |  |  |  |  |  |  |  |
|  | long-term contracts |  |  | 27,798 |  |  |  | 20,717 |  |
| Inventories |  |  | 94,292 |  |  |  | 90,228 |  |
| Current portion of deferred tax assets |  |  | 19,946 |  |  |  | 23,349 |  |
| Other current assets |  |  | 13,337 |  |  |  | 15,930 |  |
| Assets held for sale - current |  |  | 0 |  |  |  | 108,867 |  |
|  | Total current assets |  |  | 295,953 |  |  |  | 393,921 |  |
| Property, plant and equipment, net |  |  | 76,465 |  |  |  | 75,536 |  |
| Intangible assets, net |  |  | 182,063 |  |  |  | 180,217 |  |
| Goodwill |  |  | 282,337 |  |  |  | 282,949 |  |
| Other assets |  |  | 9,088 |  |  |  | 9,469 |  |
| Assets held for sale - other |  |  | 0 |  |  |  | 150,236 |  |
|  |  |  | $ | 845,906 |  |  |  | 1,092,328 |  |

[0000866706-14-000015:8k_2_02:79]
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |
| Current maturities of long-term debt |  | $ | 20,000 |  |  |  | 50,000 |  |
| Accounts payable |  |  | 40,328 |  |  |  | 38,537 |  |
| Current portion of deferred revenue |  |  | 19,895 |  |  |  | 17,508 |  |
| Other current liabilities |  |  | 66,877 |  |  |  | 60,726 |  |
| Liabilities held for sale - current |  |  | 0 |  |  |  | 63,585 |  |
| Total current liabilities |  |  | 147,100 |  |  |  | 230,356 |  |
| Deferred tax liabilities |  |  | 77,440 |  |  |  | 99,795 |  |
| Other liabilities |  |  | 21,195 |  |  |  | 22,437 |  |
| Long-term debt |  |  | 20,000 |  |  |  | 122,000 |  |
| Liabilities held for sale - other |  |  | 0 |  |  |  | 16,026 |  |
| Shareholders' equity |  |  | 580,171 |  |  |  | 601,714 |  |
|  |  | $ | 845,906 |  |  |  | 1,092,328 |  |

[0000866706-14-000015:8k_2_02:80]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Consolidated Statements of Cash Flows (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  | Year Ended September 30, 2014 |  |
| Cash flows from operating activities: |  |  |  |
| Net earnings |  | $ | 410 |  |
| Adjustments to reconcile net earnings |  |  |  |  |
| to net cash provided by operating activities: |  |  |  |  |
| Net loss from discontinued operations |  |  | 42,203 |  |
| Depreciation and amortization |  |  | 16,362 |  |
| Stock compensation expense |  |  | 4,815 |  |
| Changes in current assets and liabilities |  |  | (14,150 | ) |
| Pension contributions |  |  | (2,700 | ) |
| Change in deferred revenue and costs, net |  |  | 2,458 |  |
| Effect of deferred taxes |  |  | (2,664 | ) |
| Change in uncertain tax position liability |  |  | (1,603 | ) |
| Other |  |  | (246 | ) |
| Net cash provided by operating activities - continuing operations |  |  | 44,885 |  |
| Net cash used by operating activities - discontinued operations |  |  | (1,443 | ) |
| Net cash provided by operating activities |  |  | 43,442 |  |
| Cash flows from investing activities: |  |  |  |  |
| Capital expenditures |  |  | (12,714 | ) |
| Additions to capitalized software |  |  | (8,629 | ) |
| Net cash used by investing activities - continuing operations |  |  | (21,343 | ) |
| Net cash provided by investing activities - discontinued operations |  |  | 123,512 |  |
| Net cash provided by investing activities |  |  | 102,169 |  |
| Cash flows from financing activities: |  |  |  |  |
| Proceeds from long-term debt |  |  | 84,000 |  |
| Principal payments on long-term debt |  |  | (216,000 | ) |
| Dividends paid |  |  | (8,472 | ) |
| Purchases of common stock into treasury |  |  | (11,970 | ) |
| Other |  |  | (45 | ) |
| Net cash used by financing activities |  |  | (152,487 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (843 | ) |
| Net decrease in cash and cash equivalents |  |  | (7,719 | ) |
| Cash and cash equivalents, beginning of period |  |  | 42,850 |  |
| Cash and cash equivalents, end of period |  | $ | 35,131 |  |

[0000866706-14-000015:8k_2_02:81]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Other Selected Financial Data (Unaudited) |  |
| (Dollars in thousands) |  |
| Backlog And Entered Orders - Q4 FY 2014 |  | USG |  |  | Test |  |  | Filtration |  |  | Total |  |
| Beginning Backlog - 7/1/14 |  | $ | 28,421 |  |  |  | 102,853 |  |  |  | 161,449 |  |  |  | 292,723 |  |
| Entered Orders |  |  | 37,773 |  |  |  | 44,110 |  |  |  | 79,702 |  |  |  | 161,585 |  |
| Sales |  |  | (33,101 | ) |  |  | (56,224 | ) |  |  | (62,088 | ) |  |  | (151,413 | ) |
| Ending Backlog - 9/30/14 |  | $ | 33,093 |  |  |  | 90,739 |  |  |  | 179,063 |  |  |  | 302,895 |  |
| Backlog And Entered Orders - FY 2014 |  | USG |  |  | Test |  |  | Filtration |  |  | Total |  |
| Beginning Backlog - 10/1/13 |  | $ | 24,047 |  |  |  | 90,427 |  |  |  | 157,675 |  |  |  | 272,149 |  |
| Entered Orders |  |  | 124,714 |  |  |  | 182,067 |  |  |  | 255,085 |  |  |  | 561,866 |  |
| Sales |  |  | (115,668 | ) |  |  | (181,755 | ) |  |  | (233,697 | ) |  |  | (531,120 | ) |
| Ending Backlog - 9/30/14 |  | $ | 33,093 |  |  |  | 90,739 |  |  |  | 179,063 |  |  |  | 302,895 |  |

[0000866706-14-000015:8k_2_02:82]
| Note: The above table is presented on a continuing operations basis and excludes Aclara. |  |  |  |  |  |

[0000866706-14-000015:8k_2_02:83]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Reconciliation of Non-GAAP Financial Measures (Unaudited) |  |
| EPS – Adjusted Basis Reconciliation – Q4 FY 2014 |  |  |  |
| EPS from Continuing Ops – GAAP Basis – Q4 2014 |  | $ | 0.49 |  |
| Adjustments (defined below) |  |  | 0.02 |  |
| EPS from Continuing Ops – As Adjusted Basis – Q4 2014 |  | $ | 0.51 |  |
| Adjustments exclude $0.02 per share consisting of restructuring costs |  |  |  |  |
| associated with the Filtration segment facility consolidation. |  |  |  |  |
| EPS – Adjusted Basis Reconciliation – FY 2014 |  |  |  |  |
| EPS from Continuing Ops – GAAP Basis – FY 2014 |  | $ | 1.60 |  |
| Adjustments (defined below) |  |  | 0.05 |  |
| EPS from Continuing Ops – As Adjusted Basis – FY 2014 |  | $ | 1.65 |  |

[0000866706-14-000015:8k_2_02:84]
|  | Adjustments exclude $0.05 per share consisting of restructuring costs |  |  |  |
|  | associated with the Filtration segment facility consolidation. |  |  |  |

## item 5.02 — body, verbatim

[0000866706-14-000015:8k_body:1]
Item 5.02                      Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers

[0000866706-14-000015:8k_body:2]
Fiscal Year 2015 Cash Incentive Compensation Criteria for Executive Officers

[0000866706-14-000015:8k_body:3]
On November 12, 2014, the Human Resources and Compensation Committee (the “Committee”) of the Registrant’s Board of Directors approved the performance criteria for determining the fiscal 2015 cash incentive compensation for its executive officers, in relation to the previously-approved target cash incentive compensation opportunities of $550,000 for V.L. Richey, Jr. (40% of fiscal 2015 target total cash compensation), $333,000 for G.E. Muenster (38% of fiscal 2015 target total cash compensation) and $160,000 for A.S. Barclay (33% of fiscal 2015 target total cash compensation).

[0000866706-14-000015:8k_body:4]
The Company has two cash incentive compensation plans: (i) the Incentive Compensation Plan (the “ICP”) and (ii) the Performance Compensation Plan for Executive Officers (the “PCP”). For fiscal 2015 the Committee determined to allocate 50% of the executive officers’ cash incentive compensation opportunity to the ICP, and 50% to the PCP.

[0000866706-14-000015:8k_body:5]
Under the ICP, the Committee established Company earnings per share (“EPS”) as the single criterion for measuring performance.  The actual cash incentive compensation payable under the ICP for fiscal 2015 will range from 0.0 to 2.0 times the ICP share of the target opportunity depending on actual 2015 EPS, based on a matrix specifying particular EPS thresholds.

[0000866706-14-000015:8k_body:6]
Under the PCP, the Committee established three Company performance measures:  Cash, weighted at 25% of the total target opportunity; Entered Orders, weighted at 15% of the total target opportunity; and Return on Invested Capital, weighted at 10% of the total target opportunity. The actual cash incentive compensation payable under the PCP for fiscal 2015 will range from 0.2 to 2.0 times the PCP share of the target opportunity depending on actual 2015 performance, based on a separate matrix for each of the three measures.
