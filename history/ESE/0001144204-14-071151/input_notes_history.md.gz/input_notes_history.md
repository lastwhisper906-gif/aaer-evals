# ESE note change history — 0001144204-14-028471 → 0001144204-14-047939


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-08-08):
[0001144204-14-047939:note_history:1]
The Company’s business is typically not impacted by seasonality; however, the results for the three and nine-month periods ended June 30, 2014 are not necessarily indicative of the results for the entire 2014 fiscal year. References to the third quarters of 2014 and 2013 represent the fiscal quarters ended June 30, 2014 and 2013, respectively.
  (was, 2014-05-08, similarity 0.9474):
[0001144204-14-028471:note_history:1]
The Company’s business is typically not impacted by seasonality; however, the results for the three and six-month periods ended March 31, 2014 are not necessarily indicative of the results for the entire 2014 fiscal year. References to the second quarters of 2014 and 2013 represent the fiscal quarters ended March 31, 2014 and 2013, respectively.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-08-08):
[0001144204-14-047939:note_history:2]
| (In thousands) |  | June 30, 2014 |  |  | September 30, 2013 |  |
| Total borrowings |  | $ | 48,000 |  |  |  | 172,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000 | ) |  |  | (50,000 | ) |
| Total long-term debt, less current portion |  | $ | 28,000 |  |  |  | 122,000 |  |
  (was, 2014-05-08, similarity 0.8862):
[0001144204-14-028471:note_history:2]
| (In thousands) |  | March 31, 2014 |  | September 30, 2013 |  |
| Total borrowings |  | $ | 40,000 |  |  | 172,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (40,000) |  |  | (50,000) |  |
| Total long-term debt, less current portion |  | $ | - |  |  | 122,000 |  |

- added (2014-08-08):
[0001144204-14-047939:note_history:3]
At June 30, 2014, the Company had approximately $393 million available to borrow under the credit facility, and a $250 million increase option, in addition to $40.2 million cash on hand. At June 30, 2014, the Company had $48 million of outstanding borrowings under the credit facility in addition to outstanding letters of credit of $8.7 million. The Company’s ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.

- changed (2014-08-08):
[0001144204-14-047939:note_history:4]
The credit facility requires, as determined by certain financial ratios, a facility fee ranging from 17.5 to 35.0 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a 65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the credit facility also include a leverage ratio and an interest coverage ratio. At June 30, 2014, the Company was in compliance with all debt covenants.
  (was, 2014-05-08, similarity 0.9935):
[0001144204-14-028471:note_history:4]
The credit facility requires, as determined by certain financial ratios, a facility fee ranging from  17.5 to  35.0 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a  65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the credit facility also include a leverage ratio and an interest coverage ratio. At March 31, 2014, the Company was in compliance with all debt covenants.

- removed (2014-08-08):
[0001144204-14-028471:note_history:5]
At March 31, 2014, the Company had approximately $402 million available to borrow under the credit facility, and a $250 million increase option, in addition to $36.4 million cash on hand. At March 31, 2014, the Company had $40 million of outstanding borrowings under the credit facility in addition to outstanding letters of credit of $8.4 million. The Company’s ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-08-08):
[0001144204-14-047939:note_history:6]
| (In thousands) |  | June 30, 2014 |  |  | September 30, 2013 |  |
| Total borrowings |  | $ | 48,000 |  |  |  | 172,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000 | ) |  |  | (50,000 | ) |
| Total long-term debt, less current portion |  | $ | 28,000 |  |  |  | 122,000 |  |
  (was, 2014-05-08, similarity 0.8898):
[0001144204-14-028471:note_history:6]
| (In thousands) |  | March 31, 2014 |  | September 30, 2013 |  |
| Total borrowings |  | $ | 40,000 |  |  | 172,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (40,000) |  |  | (50,000) |  |
| Total long-term debt, less current portion |  | $ | - |  |  | 122,000 |
