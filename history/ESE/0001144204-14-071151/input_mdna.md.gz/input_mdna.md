# ESE MD&A — 0001144204-14-071151


## mdna

[0001144204-14-071151:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial
Condition and Results of Operations

[0001144204-14-071151:mdna:2]
The following discussion should be read in conjunction with
the Consolidated Financial Statements included herein and Notes thereto and refers to the Company’s results from continuing
operations, except where noted. On March 28, 20

[0001144204-14-071151:mdna:3]
| 14 |

[0001144204-14-071151:mdna:4]
, the Company completed the sale of Aclara Technologies LLC (Aclara) to an affiliate
of Sun Capital Partners, Inc. The divestiture generated approximately $135 million of gross cash proceeds. The cash proceeds were
used to pay down a significant portion of the Company’s outstanding debt under its revolving credit facility. At September
30, 2014, the Company had a net debt position of approximately $5 million (net debt position is defined as total debt less net
cash).

[0001144204-14-071151:mdna:5]
The parties have not reached agreement on the calculation of
the final working capital adjustment as the buyer has proposed several adjustments to the working capital estimate calculated
at closing. The Company is currently working with the buyer relating to its proposed adjustments; however, the final working capital
adjustment cannot be determined at this time. Aclara is reflected as discontinued operations and/or assets/liabilities held for
sale in the financial statements and related notes for all periods shown.

[0001144204-14-071151:mdna:6]
14

[0001144204-14-071151:mdna:7]
Aclara’s pretax (loss) earnings recorded in discontinued
operations was $(48.2) million, $(62.1) million and $19.5 million for 2014, 2013 and 2012, respectively.
Aclara’s net sales were $129.6 million, $184.5 million and $209.7 million for 2014, 2013 and
2012, respectively. Aclara’s operations were included within the Company’s USG segment prior to the classification
as discontinued operations.

[0001144204-14-071151:mdna:8]
The years 2014, 2013 and 2012 refer to the fiscal years ended
September 30, 2014, 2013 and 2012, respectively, and are used throughout the document.

[0001144204-14-071151:mdna:9]
Introduction

[0001144204-14-071151:mdna:10]
ESCO Technologies Inc. and its wholly owned subsidiaries (the
Company) are organized into three reportable operating segments: Filtration/Fluid Flow (Filtration), RF Shielding and Test (Test),
and Utility Solutions Group (USG). The Company’s business segments are comprised of the following primary operating entities:

[0001144204-14-071151:mdna:11]
|  | Ÿ | Filtration: PTI Technologies Inc. (PTI), VACCO Industries (VACCO), Crissair, Inc. (Crissair) and Thermoform Engineered Quality LLC (TEQ), |

[0001144204-14-071151:mdna:12]
|  | Ÿ | Test: ETS-Lindgren Inc. (ETS-Lindgren), |

[0001144204-14-071151:mdna:13]
|  | Ÿ | USG: Doble Engineering Company (Doble). |

[0001144204-14-071151:mdna:14]
Filtration.
The companies within this segment primarily design and manufacture specialty filtration products including hydraulic
filter elements and fluid control devices used in commercial aerospace applications, unique filter mechanisms used in micro-propulsion
devices for satellites and custom designed filters for manned aircraft and submarines.

[0001144204-14-071151:mdna:15]
Test.
ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and contain
magnetic, electromagnetic and acoustic energy.

[0001144204-14-071151:mdna:16]
USG.
Doble provides high-end, intelligent diagnostic test solutions for the electric power delivery industry and is
a leading supplier of power factor and partial discharge testing instruments used to assess the integrity of high-voltage power
delivery equipment.

[0001144204-14-071151:mdna:17]
The Company continues to operate with meaningful growth prospects
in its primary served markets and with considerable financial flexibility. The Company continues to focus on new products that
incorporate proprietary design and process technologies. Management is committed to delivering shareholder value through internal
growth, ongoing performance improvement initiatives, and acquisitions.

[0001144204-14-071151:mdna:18]
Highlights of 2014 Continuing Operations

[0001144204-14-071151:mdna:19]
|  | Ÿ | Sales, net earnings from continuing operations and diluted earnings per share from continuing operations were $531.1 million, $42.6 million and $1.60 per share, respectively, compared to sales, net earnings and diluted earnings per share of $490.1 million, $31.3 million and $1.17 per share in 2013. |

[0001144204-14-071151:mdna:20]
|  | Ÿ | Diluted earnings per share from continuing operations on an adjusted basis was $1.65 per share in 2014 which excludes $0.05 per share of restructuring costs related to the exit and relocation of Crissair’s Palmdale, California operation into the Canyon facility in Valencia, California. This move was completed as of September 30, 2014. Management believes EPS-As Adjusted is more representative of the Company’s 2014 ongoing performance and allows shareholders better visibility into the Company’s underlying operations. |

[0001144204-14-071151:mdna:21]
|  | Ÿ | Net cash provided by operating activities from continuing operations was approximately $45 million in 2014. |

[0001144204-14-071151:mdna:22]
|  | Ÿ | At September 30, 2014, cash on hand was $35.1 million and outstanding debt was $40.0 million, for a net debt position of approximately $5 million. |

[0001144204-14-071151:mdna:23]
|  | Ÿ | 2014 entered orders from continuing operations were $561.9 million resulting in a book-to-bill ratio of 1.06x. Backlog from continuing operations at September 30, 2014 was $302.9 million compared to $272.1 million at September 30, 2013. |

[0001144204-14-071151:mdna:24]
|  | Ÿ | During 2014, the Company repurchased approximately 350,000 shares of its common stock for $12.0 million. |

[0001144204-14-071151:mdna:25]
|  | Ÿ | The Company declared dividends of $0.32 per share, totaling $8.5 million in payments during 2014. |

[0001144204-14-071151:mdna:26]
| 15 |

[0001144204-14-071151:mdna:27]
Results of Continuing Operations

[0001144204-14-071151:mdna:28]
Net Sales

[0001144204-14-071151:mdna:29]
|  |  |  |  |  |  |  |  |  |  |  | Change |  |  | Change |  |
|  |  | Fiscal year ended |  |  | 2014 |  |  | 2013 |  |
| (Dollars in millions) |  | 2014 |  |  | 2013 |  |  | 2012 |  |  | vs.2013 |  |  | vs.2012 |  |
| Filtration |  | $ | 233.7 |  |  |  | 214.1 |  |  |  | 194.8 |  |  |  | 9.2 | % |  |  | 9.9 | % |
| Test |  |  | 181.8 |  |  |  | 166.7 |  |  |  | 175.9 |  |  |  | 9.1 | % |  |  | (5.2 | )% |
| USG |  |  | 115.6 |  |  |  | 109.3 |  |  |  | 108.0 |  |  |  | 5.8 | % |  |  | 1.2 | % |
| Total |  | $ | 531.1 |  |  |  | 490.1 |  |  |  | 478.7 |  |  |  | 8.4 | % |  |  | 2.4 | % |

[0001144204-14-071151:mdna:30]
Net sales increased $41.0 million, or 8.4%, to $531.1 million
in 2014 from $490.1 million in 2013. Net sales increased $11.4 million, or 2.4%, to $490.1 million in 2013 from $478.7 million
in 2012. The increase in net sales in 2014 as compared to 2013 was due to: a $19.6 million increase in the Filtration segment;
a $15.1 million increase in the Test segment; and a $6.3 million increase in the USG segment. The increase in net sales in 2013
as compared to 2012 was due to: a $19.3 million increase in the Filtration segment; a $1.3 million increase in the USG segment;
partially offset by a $9.2 million decrease in the Test segment.

[0001144204-14-071151:mdna:31]
Filtration.
The $19.6 million, or 9.2%, increase in net sales in 2014 as compared to 2013 was due to: a $10.2 million increase
in net sales from VACCO due to higher shipments of its space products; an $8.5 million increase in net sales at Crissair mainly
due to the Canyon acquisition and higher aerospace product shipments; and a $0.9 million increase in net sales at TEQ due to higher
shipments to commercial customers.

[0001144204-14-071151:mdna:32]
The $19.3 million, or 9.9%, increase in net sales in 2013
as compared to 2012 was due to: a $

[0001144204-14-071151:mdna:33]
| 16 |

[0001144204-14-071151:mdna:34]
.2 million increase in net sales from VACCO due to higher shipments of its space and
defense products; a $6.7 million increase in net sales at Crissair (the 2013 acquisition of Canyon contributed $3.3 million
of this increase); partially offset by a $3.2 million decrease in net sales at PTI driven by lower shipments of aerospace
elements and couplings, and a $0.4 million decrease in net sales at TEQ.

[0001144204-14-071151:mdna:35]
Test.
The net sales increase of $15.1 million, or 9.1%, in 2014 as compared to 2013 was due to: a $12.9 million increase
in net sales from the segment’s U.S. operations mainly due to a large automotive chamber project, and projects in the test
and measurement market; a $3.3 million increase in net sales from the segment’s European operations; partially offset by
a $1.1 million decrease in net sales from the Company’s Asian operations due to timing of projects.

[0001144204-14-071151:mdna:36]
The sales decrease of $9.2 million, or 5.2%, in 2013 as compared
to 2012 was due to: an $8 million decrease in net sales from the segment’s European operations due to timing of projects
and softness in the European economy; a $6.4 million decrease in net sales from the Company’s Asian operations due to timing
of chamber projects; partially offset by a $5.2 million increase in net sales from the segment’s U.S. operations due to
an increase in projects in the EMP (electro-magnetic pulse) market.

[0001144204-14-071151:mdna:37]
USG.
 The net sales increase of $6.3 million, or 5.8%, in 2014 as compared to 2013, and the sales increase of $1.3 million,
or 1.2%, in 2013 as compared to 2012 were both driven by an increase in service revenues at Doble.

[0001144204-14-071151:mdna:38]
Orders and Backlog

[0001144204-14-071151:mdna:39]
New orders received from continuing operations in 2014 were
$561.9 million as compared to $516.7 million in 2013, resulting in order backlog of $302.9 million at September 30, 2014,
as compared to order backlog of $272.1 million at September 30, 2013. In 2014, the Company recorded $255.1 million of
orders related to Filtration products, $182.1 million related to Test products, and $124.7 million related to USG products.
Orders are entered into backlog as firm purchase order commitments are received.

[0001144204-14-071151:mdna:40]
In 2013, the Company recorded $232.1 million of orders related
to Filtration products, $177.7 million related to Test products, and $106.9 million related to USG products.

[0001144204-14-071151:mdna:41]
Selling, General and Administrative Expenses

[0001144204-14-071151:mdna:42]
Selling, general and administrative (SG&A) expenses were
$134.9 million, or 25.4% of net sales, in 2014, $129.8 million, or 26.5% of net sales, in 2013, and $128.2 million, or 26.8% of
net sales, in 2012. The increase in SG&A expenses in 2014 as compared to 2013 was mainly due to the acquisition of Canyon
Engineering in June 2013, higher engineering costs in the Filtration segment related to the recently announced new aerospace platform
wins, higher commissions within the Test segment, and higher marketing and selling expenses within the USG segment; partially
offset by lower SG&A expenses at Corporate.

[0001144204-14-071151:mdna:43]
16

[0001144204-14-071151:mdna:44]
The increase in SG&A expenses in 2013 as compared to 2012
was mainly due to an increase in professional fees and acquisition costs incurred at the Corporate level.

[0001144204-14-071151:mdna:45]
Amortization Of Intangible Assets

[0001144204-14-071151:mdna:46]
Amortization of intangible assets was $6.7 million in 2014,
$6.2 million in 2013 and $5.7 million in 2012. Amortization of intangible assets included $3.4 million, $3.2 million and $3.8
million of amortization of acquired intangible assets in 2014, 2013 and 2012, respectively, related to the Company’s acquisitions.
The amortization of acquired intangible assets related to the Company’s acquisitions is included in the Corporate operating
segment’s results. The remaining amortization expenses consist of other identifiable intangible assets (primarily software,
patents and licenses) and are included in the respective segment’s operating results.

[0001144204-14-071151:mdna:47]
Other Expenses (Income), Net

[0001144204-14-071151:mdna:48]
Other expenses (income), net, were $1.8 million in 2014, $5.9 million
in 2013 and $(4.4) million in 2012, respectively. The principal components of other expenses (income), net, in 2014 included $1.7
million of costs related to the exit and relocation of Crissair’s Palmdale, California operation into the Canyon facility
in Valencia, California. This move was completed as of September 30, 2014. The principal components of other expenses (income),
net, in 2013 included $4.1 million of restructuring costs related to the closure of the Doble Lemke facility in Germany; $2.6
million of restructuring costs within the Test segment as a result of the closure of the Glendale Heights, Illinois facility;
and a $0.8 million gain on the sale of machinery and equipment within the Filtration segment. The principal component of
 other expenses (income), net, in 2012 was $(4.5) million of income representing a revaluation of the earnout liability related
to the Xtensible acquisition. There were no other individually significant items included in other expenses (income), net, in
2014, 2013 or 2012.

[0001144204-14-071151:mdna:49]
Earnings Before Interest and Taxes (EBIT)

[0001144204-14-071151:mdna:50]
The information reported herein includes the financial measures
EBIT, EBIT as a percentage of net sales (EBIT margin), and EPS on an adjusted basis from continuing operations. The Company defines
EBIT as earnings before interest and taxes from continuing operations, and defines EPS on an adjusted basis from continuing operations
as GAAP EPS from continuing operations less defined restructuring charges. EBIT, and EBIT margin on a consolidated basis and EPS
on an adjusted basis are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, the
Company believes that EBIT and EBIT margin provide investors and Management with a valuable alternative method for assessing the
Company’s operating results. Management evaluates the performance of its operating segments based on EBIT and believes that
EBIT is useful to investors to demonstrate the operational profitability of the Company’s business segments by excluding
interest and taxes, which are generally accounted for across the entire company on a consolidated basis. EBIT is also one of the
measures Management uses to determine resource allocations and incentive compensation. The Company believes that the presentation
of EBIT, EBIT margin and EPS on an adjusted basis provides important supplemental information to investors by facilitating comparisons
with other companies, many of which use similar non-GAAP financial measures to supplement their GAAP results. The use of non-GAAP
financial measures is not intended to replace any measures of performance determined in accordance with GAAP.

[0001144204-14-071151:mdna:51]
EBIT

[0001144204-14-071151:mdna:52]
|  |  |  |  |  |  |  |  |  |  |  | Change |  |  | Change |  |
|  |  | Fiscal year ended |  |  | 2014 |  |  | 2013 |  |
| (Dollars in millions) |  | 2014 |  |  | 2013 |  |  | 2012 |  |  | vs. 2013 |  |  | vs. 2012 |  |
| Filtration |  | $ | 41.4 |  |  |  | 42.4 |  |  |  | 38.0 |  |  |  | (2.4 | )% |  |  | 11.6 | % |
| % of net sales |  |  | 17.7 | % |  |  | 19.8 | % |  |  | 19.5 | % |  |  |  |  |  |  |  |  |
| Test |  |  | 21.1 |  |  |  | 16.3 |  |  |  | 14.0 |  |  |  | 29.4 | % |  |  | 16.4 | % |
| % of net sales |  |  | 11.6 | % |  |  | 9.8 | % |  |  | 8.0 | % |  |  |  |  |  |  |  |  |
| USG |  |  | 26.6 |  |  |  | 21.6 |  |  |  | 25.9 |  |  |  | 23.1 | % |  |  | (16.6 | )% |
| % of net sales |  |  | 23.0 | % |  |  | 19.8 | % |  |  | 24.0 | % |  |  |  |  |  |  |  |  |
| Corporate |  |  | (25.3 | ) |  |  | (28.0 | ) |  |  | (23.2 | ) |  |  | (9.6 | )% |  |  | (20.7 | )% |
| Total |  | $ | 63.8 |  |  |  | 52.3 |  |  |  | 54.7 |  |  |  | 22.0 | % |  |  | (4.4 | )% |
| % of net sales |  |  | 12.0 | % |  |  | 10.7 | % |  |  | 11.4 | % |  |  |  |  |  |  |  |  |

[0001144204-14-071151:mdna:53]
| 17 |

[0001144204-14-071151:mdna:54]
The reconciliation of EBIT from continuing operations to a
GAAP financial measure is as follows:

[0001144204-14-071151:mdna:55]
| (Dollars in millions) |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| EBIT |  | $ | 63.8 |  |  |  | 52.3 |  |  |  | 54.7 |  |
| Less: Interest expense |  |  | (1.6 | ) |  |  | (2.7 | ) |  |  | (2.5 | ) |
| Less: Income taxes |  |  | (19.6 | ) |  |  | (18.3 | ) |  |  | (17.4 | ) |
| Net earnings from continuing operations |  | $ | 42.6 |  |  |  | 31.3 |  |  |  | 34.8 |  |

[0001144204-14-071151:mdna:56]
Filtration

[0001144204-14-071151:mdna:57]
EBIT decreased $1.0 million in 2014 as compared to 2013 primarily
due to $1.7 million of costs related to the exit and relocation of Crissair’s Palmdale, California operation into the Canyon
facility in Valencia, California consisting mainly of a facility lease termination charge, severance expenses and manufacturing
inefficiencies resulting from the disruption. This move was completed as of September 30, 2014.

[0001144204-14-071151:mdna:58]
EBIT increased $4.4 million in 2013 as compared to 2012 primarily
due to the additional sales volumes at VACCO and Crissair as noted earlier.

[0001144204-14-071151:mdna:59]
Test

[0001144204-14-071151:mdna:60]
The $4.8 million increase in EBIT in 2014 as compared to 2013
was due to the additional sales volumes from the segment’s U.S. operations and the cost savings achieved as a result of
the 2013 domestic facility consolidation. Approximately $3.4 million of restructuring costs were incurred in 2013 related to the
domestic facility consolidation.

[0001144204-14-071151:mdna:61]
The $2.3 million increase in EBIT in 2013 as compared to 2012
was due to product price increases and the savings being realized from the domestic facility consolidation. The increase
was partially offset by approximately $3.4 million of restructuring costs consisting mainly of a facility lease termination charge,
severance and relocation expenses and manufacturing inefficiencies resulting from the disruption.

[0001144204-14-071151:mdna:62]
USG

[0001144204-14-071151:mdna:63]
The $5.0 million increase in EBIT in 2014 as compared to 2013
was mainly due to an increase in sales volumes and a decrease in restructuring costs that were incurred in 2013 related to the
closure of the Doble Lemke manufacturing operation.

[0001144204-14-071151:mdna:64]
The $4.3 million decrease in EBIT in 2013 as compared to 2012
was mainly due to $2.6 million of restructuring costs related to the closure of the manufacturing operation in Germany (Doble
Lemke GmbH) and relocation of its partial discharge products and intellectual property to its existing lower cost locations in
Europe. These shut-down costs consisted of personnel costs, asset impairment charges, and move related costs. In addition, a $4.5
million gain was recorded in 2012 related to the revaluation of the earnout liability related to the Xtensible acquisition.

[0001144204-14-071151:mdna:65]
Corporate

[0001144204-14-071151:mdna:66]
Corporate operating charges included in consolidated EBIT decreased
to $25.3 million as compared to $28 million in 2013 mainly due to a decrease in professional fees and acquisition-related costs.

[0001144204-14-071151:mdna:67]
Corporate operating charges included in consolidated EBIT increased
to $28 million as compared to $23.2 million in 2012 mainly due to a $1.5 million pretax write-down of a Doble Lemke trade name
and an increase in professional fees and acquisition costs.

[0001144204-14-071151:mdna:68]
The “Reconciliation to Consolidated Totals (Corporate)”
in Note 15 to the Consolidated Financial Statements included herein represents Corporate office operating charges.

[0001144204-14-071151:mdna:69]
Interest Expense, Net

[0001144204-14-071151:mdna:70]
Interest expense was $1.6 million in 2014, $2.7 million in
2013, and $2.5 million in 2012. The decrease in interest expense in 2014 as compared to 2013 was due to lower average interest
rates (1.5% vs. 1.6%) and lower average outstanding borrowings ($103 million vs. $171 million). The increase in interest expense
in 2013 as compared to 2012 was due to higher average interest rates (1.6% vs. 1.2%) and higher average outstanding borrowings
($171 million vs. $126 million).

[0001144204-14-071151:mdna:71]
| 18 |

[0001144204-14-071151:mdna:72]
Income Tax Expense

[0001144204-14-071151:mdna:73]
The effective tax rate from continuing operations for 2014,
2013 and 2012 was 31.5%, 37.0% and 33.4%, respectively. The decrease in the 2014 effective tax rate as compared to 2013 was primarily
due to: the release of accruals related to uncertain tax positions as a result of the lapse of statute of limitations and the
closing of a U.S. taxing authority’s examination of the Company’s research credit claims which reduced the 2014 effective
tax rate by 2.9%; the December 31, 2013 expiration of the research tax credit which increased the 2014 effective tax rate by 1.4%;
and an adjustment to the foreign valuation allowance which increased the 2013 effective tax rate by 3.3%.

[0001144204-14-071151:mdna:74]
The increase in the 2013 effective tax rate as compared to
2012 was primarily due to: an adjustment to the foreign valuation allowance which increased the 2013 effective tax rate by 3.3%;
the extension of the research tax credit as a result of the American Taxpayer Relief Act of 2012 which reduced the 2013 effective
tax rate by 2.2%; a purchase accounting charge which increased the 2012 effective tax rate by 1.0%; and the release of accruals
related to uncertain tax positions as a result of the lapse of statute of limitations which reduced the 2012 effective tax rate
by 3.7%.

[0001144204-14-071151:mdna:75]
The Company’s foreign subsidiaries have accumulated unremitted
earnings of $32.6 million and cash of $27.0 million at September 30, 2014. No deferred taxes have been provided on these accumulated
unremitted earnings because these funds are not needed to meet the liquidity requirements of the Company’s U.S. operations
and it is the Company’s intention to indefinitely reinvest these earnings in continuing international operations. In the
event these foreign entities’ earnings were distributed, it is estimated that U.S. taxes, net of available foreign tax credits,
of approximately $4.7 million would be due, which would correspondingly reduce the Company’s net earnings. No significant
portion of the Company’s foreign subsidiaries’ earnings was taxed at a very low tax rate.

[0001144204-14-071151:mdna:76]
Capital Resources and Liquidity

[0001144204-14-071151:mdna:77]
The Company’s overall financial position and liquidity
are strong. Working capital (current assets less current liabilities) decreased to $148.9 million at September 30, 2014, from
$163.6 million at September 30, 2013, mainly due to the sale of Aclara partially offset by higher accounts receivable and inventory
balances. The $13.5 million increase in accounts receivable at September 30, 2014, was mainly due to: a $6.3 million increase
within the USG segment, a $4.1 million increase within the Filtration segment and a $1.9 million increase in the Test segment
all due to the increase of sales in the fourth quarter. The $4.1 million increase in inventory at September 30, 2014, was mainly
due to a $3.4 million increase in the Test segment due to timing of receipt of raw materials to meet increased sales volumes.

[0001144204-14-071151:mdna:78]
Net cash provided by operating activities from continuing operations
was $44.9 million, $37.1 million and $46.1 million in 2014, 2013 and 2012, respectively. The increase in 2014 as compared to 2013
was mainly due to an increase in net earnings and lower operating working capital requirements. The decrease in 2013 as compared
to 2012 was due to a decrease in net earnings and higher operating working capital requirements.

[0001144204-14-071151:mdna:79]
Capital expenditures from continuing operations were $12.7 million,
$13.9 million and $10.8 million in 2014, 2013 and 2012, respectively. The decrease in 2014 as compared to 2013 was mainly
due to the 2013 purchase of the ETS-Lindgren facility in Minocqua, Wisconsin for $1.2 million. The increase in 2013 as compared
to 2012 was mainly due to the purchase of the ETS-Lindgren facility in Minocqua, Wisconsin for $1.2 million and an increase
in manufacturing equipment within the Filtration segment of approximately $2 million mainly due to the Felix Tool acquisition.
There were no commitments outstanding that were considered material for capital expenditures at September 30, 2014. In addition,
the Company incurred expenditures for capitalized software of $8.6 million, $8.4 million and $5.3 million in 2014, 2013 and
2012, respectively. The increase in 2014 as compared to 2013 was not material. The increase in 2013 as compared to 2012 was mainly
attributable to the Test segment’s software development.

[0001144204-14-071151:mdna:80]
The Company made required pension contributions of $2.7 million,
$3.9 million and $4.8 million in 2014, 2013 and 2012, respectively.

[0001144204-14-071151:mdna:81]
Divestiture

[0001144204-14-071151:mdna:82]
On March 28, 2014, the Company completed the sale of Aclara
Technologies LLC (Aclara) to an affiliate of Sun Capital Partners, Inc. The divestiture generated approximately $135 million of
gross cash proceeds. The cash proceeds were used to pay down a significant portion of the Company’s outstanding debt under
its revolving credit facility. At September 30, 2014, the Company had a net debt position (total debt less net cash) of approximately $5 million.

[0001144204-14-071151:mdna:83]
| 19 |

[0001144204-14-071151:mdna:84]
Acquisitions

[0001144204-14-071151:mdna:85]
| 20 |

[0001144204-14-071151:mdna:86]
13

[0001144204-14-071151:mdna:87]
On June 26, 2013, the Company acquired the stock of Canyon
Engineering Products, Inc. (Canyon) for $9.2 million in cash, and additionally, purchased Canyon’s 70,000 square foot manufacturing
facility located in Valencia, California for $7 million. Canyon designs and manufactures precision fluid control devices primarily
for the aerospace industry and Canyon’s products, technology and customers are very similar to Crissair, Inc. The operating
results for Canyon, since the date of acquisition, are included as part of Crissair, Inc. within the Company’s Filtration
segment. The Company recorded approximately $1.3 million of goodwill related to the transaction and $1.7 million of amortizable
identifiable intangible assets consisting primarily of customer relationships.

[0001144204-14-071151:mdna:88]
On December 21, 2012, the Company acquired the assets of Felix
Tool & Engineering, Inc. (Felix Tool) for a purchase price of $1.2 million in cash. Felix Tool is engaged in the design, manufacture
and sale of customized perforated tubes for filtration applications in the aerospace and fluid power industry. The purchase price
was allocated to property, plant and equipment and inventory based on fair market value at the date of acquisition and there were
no intangible assets recorded upon the transaction. The operating results for the business, since the date of acquisition, are
included within PTI in the Filtration segment.

[0001144204-14-071151:mdna:89]
On December 10, 2012, the Company acquired the assets of Finepoint
Marketing, Inc. (Finepoint) for a purchase price of $2.5 million. Finepoint is the electric power industry’s leading conference
provider focused on medium and high voltage circuit breakers, as well as related substation and switchgear topics. The operating
results for the business, since the date of acquisition, are included as part of Doble in the USG segment. The Company recorded
approximately $1.3 million of goodwill as a result of the transaction and $1.2 million of amortizable identifiable intangible
assets consisting of customer relationships.

[0001144204-14-071151:mdna:90]
All of the Company’s acquisitions have been accounted
for using the purchase method of accounting, and accordingly, the respective purchase prices were allocated to the assets (including
intangible assets) acquired and liabilities assumed based on estimated fair values at the date of acquisition. The financial
results from these acquisitions have been included in the Company’s financial statements from the date of acquisition.

[0001144204-14-071151:mdna:91]
Bank Credit Facility

[0001144204-14-071151:mdna:92]
The Company maintains a $450 million revolving credit facility
with JPMorgan Chase Bank, N.A., as administrative agent, PNC Bank, N.A., as syndication agent, and eight other participating lenders,
with a maturity date of May 14, 2017 (the “Credit Facility”). Through a credit facility expansion option, the Company
may elect to increase the size of the Credit Facility by entering into incremental term loans, in any agreed currency, at a minimum
of $25 million each up to a maximum of $250 million aggregate; the Company’s ability to access this increase option is subject
to acceptance by participating or other outside banks. The Company’s sale of Aclara did not impact the covenants or the
amount of availability under the Credit Facility.

[0001144204-14-071151:mdna:93]
At September 30, 2014, the Company had approximately
$399 million available to borrow under the Credit Facility, plus the  $250 million increase option, in addition to
$35.1 million cash on hand. The Company classified $20 million as the current portion of short-term debt as of September
30, 2014, as the Company intends to repay this amount within the next 12 months; however, the Company has no contractual
obligation to repay such amount during the next twelve months.

[0001144204-14-071151:mdna:94]
The Credit Facility requires, as determined by certain financial
ratios, a facility fee ranging from 17.5 to 35 basis points per annum on the unused portion. The terms of the facility provide
that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime
rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic
subsidiaries and a 65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit
Facility include a leverage ratio and an interest coverage ratio. As of September 30, 2014, the Company was in compliance with
all bank covenants.

[0001144204-14-071151:mdna:95]
Cash flow from operations and borrowings under the Credit
Facility are expected to provide adequate resources to meet the Company’s capital requirements and operational needs for
the foreseeable future.

[0001144204-14-071151:mdna:96]
Dividends

[0001144204-14-071151:mdna:97]
Since 2010 the Company has paid a regular quarterly cash dividend
at an annual rate of $0.32 per share. The Company paid dividends of $8.5 million, $8.5 million and $8.6 million in 2014,
2013 and 2012, respectively.

[0001144204-14-071151:mdna:98]
20

[0001144204-14-071151:mdna:99]
2015 and Three Year Outlook

[0001144204-14-071151:mdna:100]
The Company’s goals and expectations through fiscal 2017
reflect compound annual sales growth of 10 percent and compound annual EPS growth of 15 percent, with approximately 80 percent
of the growth being organic and approximately 20 percent coming from future acquisitions. While expectations for fiscal 2015 reflect
lower than normal growth due to timing issues on two large programs, and a higher expected tax rate, the three-year outlook remains
unchanged.

[0001144204-14-071151:mdna:101]
The 2015 sales outlook is muted by the expectation of
lower Space sales at VACCO and lower sales at TEQ related to its KAZ thermometer probe cover project. Regarding VACCO, while
the Company expects the SLS launch vehicle program to remain a critical project for NASA and expects overall project revenues
to increase over the remaining life of the development stage, the customer recently informed the Company that NASA has
decided to smooth the SLS spending timeline over the next three  years. This will result in VACCO’s expected
revenues being approximately $10 million lower in 2015, but approximately $10 million higher in 2016 and approximately $5
million higher in 2017, than indicated by earlier project timelines. At TEQ, during 2014 the KAZ project was extended from
five years to eight years, with total expected project revenues increasing from approximately $50 million to approximately
$80 million; however, because the extension included an upgrade to a next generation probe cover to be compatible with a
newly designed thermometer, the Company expects product design enhancements during the first quarter of 2015 to temporarily
limit TEQ’s production revenue from the KAZ project, resulting in approximately $3 million of sales being pushed into
future years.

[0001144204-14-071151:mdna:102]
As a result of the above items, Management expects 2015 sales
growth of 2% to 5% and EPS in the range of $1.70 to $1.80 per share. By segment: Filtration sales are expected to be lower than
in 2014 due to the VACCO and TEQ items noted above, but partially offsetting these, PTI and Crissair sales are expected to increase
approximately 7% and 5%, respectively, Test sales are expected to increase between 5% and 7%, and USG sales are expected to increase
between 8% and 10%. On a quarterly basis, Management expects 2015 revenues and EPS to reflect a profile similar to 2014, including
EPS being more second-half weighted.

[0001144204-14-071151:mdna:103]
For 2015, the Company’s effective tax rate is
expected to be 35 percent, compared to the adjusted effective tax rate of 31.6 percent in 2014.

[0001144204-14-071151:mdna:104]
Contractual Obligations

[0001144204-14-071151:mdna:105]
The following table shows the Company’s contractual obligations
as of September 30, 2014:

[0001144204-14-071151:mdna:106]
|  |  | Payments due by period |  |
|  |  |  |  |  | Less than |  |  | 1 to 3 |  |  | 3 to 5 |  |  | More than |  |
| (Dollars in millions) |  | Total |  |  | 1 year |  |  | years |  |  | years |  |  | 5 years |  |
| Long-Term Debt Obligation |  | $ | 40.0 |  |  |  | — |  |  |  | 40.0 |  |  |  | — |  |  |  | — |  |
| Estimated Interest Payments (1) |  |  | 0.7 |  |  |  | 0.5 |  |  |  | 0.2 |  |  |  | — |  |  |  | — |  |
| Operating Lease Obligations |  |  | 15.9 |  |  |  | 5.0 |  |  |  | 6.4 |  |  |  | 3.6 |  |  |  | 0.9 |  |
| Purchase Obligations (2) |  |  | 7.0 |  |  |  | 6.7 |  |  |  | 0.3 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 63.6 |  |  |  | 12.2 |  |  |  | 46.9 |  |  |  | 3.6 |  |  |  | 0.9 |  |

[0001144204-14-071151:mdna:107]
|  | (1) | Estimated interest payments for the Company’s debt obligations were calculated based on Management’s determination of the estimated applicable interest rates and payment dates. |

[0001144204-14-071151:mdna:108]
|  | (2) | A purchase obligation is defined as a legally binding and enforceable agreement to purchase goods and services that specifies all significant terms. Since the majority of the Company’s purchase orders can be cancelled, they are not included in the table above. |

[0001144204-14-071151:mdna:109]
As of September 30, 2014, the Company had $0.5 million of liabilities
for uncertain tax positions. The unrecognized tax benefits have been excluded from the table above due to uncertainty as to the
amounts and timing of settlement with taxing authorities.

[0001144204-14-071151:mdna:110]
The Company has no off-balance-sheet arrangements outstanding
at September 30, 2014.

[0001144204-14-071151:mdna:111]
Share Repurchases

[0001144204-14-071151:mdna:112]
In August 2012, the Company’s Board of Directors authorized
a common stock repurchase program under which the Company may repurchase shares of its stock from time to time in its discretion,
in the open market or otherwise, up to a maximum total repurchase amount of $100 million (or such lesser amount as may be permitted
under the Company’s bank credit agreements). This program has been twice extended by the Company’s Board of Directors
and is currently scheduled to expire September 30, 2015. There currently is no repurchase program which the Company has determined
to terminate prior to the program’s expiration, or under which the Company does not intend to make further purchases. The
Company repurchased approximately 350,000 shares for $12.0 million in 2014, 270,000 shares for $9.7 million in 2013, and 150,000
shares for $5.4 million in 2012.

[0001144204-14-071151:mdna:113]
| 21 |

[0001144204-14-071151:mdna:114]
Pension Funding Requirements

[0001144204-14-071151:mdna:115]
The minimum cash funding requirements related to the Company’s
defined benefit pension plans are estimated to be approximately $0.7 million in 2015, and zero in both 2016 and 2017.

[0001144204-14-071151:mdna:116]
Other

[0001144204-14-071151:mdna:117]
Management believes that, for the periods presented, inflation
has not had a material effect on the Company’s results of operations.

[0001144204-14-071151:mdna:118]
As a normal incident of the business in which the Company is
engaged, various claims, charges and litigation are asserted or commenced from time to time against the Company. Additionally,
the Company is currently involved in various stages of investigation and remediation relating to environmental matters. It is
the opinion of Management that the aggregate costs involved in the resolution of these matters, and final judgments, if any, which
might be rendered against the Company are adequately reserved for, are covered by insurance, or are not likely to have a material
adverse effect on the Company’s results from continuing operations, capital expenditures, or competitive position.

[0001144204-14-071151:mdna:119]
Market Risk Analysis

[0001144204-14-071151:mdna:120]
Market Risk Exposure

[0001144204-14-071151:mdna:121]
Market risks relating to the Company’s operations
result primarily from changes in interest rates and changes in foreign currency exchange rates. The Company is exposed to
market risk related to changes in interest rates and selectively uses derivative financial instruments, including forward
contracts and swaps, to manage these risks. All derivative instruments are reported on the balance sheet at fair value. In
June 2014, the Company entered into a forward contract to sell 10.9 million Euros (US$14.7 million) on November 3, 2014
to hedge the foreign currency risk related to an intercompany transaction. Gains and losses on foreign currency derivatives
are reported in other expenses (income), net, on the Company’s Consolidated Statements of Operations. The Company has
determined that the market risk related to interest rates with respect to its variable debt is not material. The Company
estimates that if market interest rates averaged one percentage point higher, the effect would have been less than 2% of net
earnings for the year ended September 30, 2014. The following is a summary of the notional transaction amounts and fair
values for the Company’s outstanding derivative financial instruments as of September 30, 2014.

[0001144204-14-071151:mdna:122]
| (In thousands) |  | Notional Amount (Euros) |  |  | Fair Value (US$) |  |
| Forward contract |  |  | 10,891 |  |  |  | 927 |  |

[0001144204-14-071151:mdna:123]
The Company is also subject to foreign currency exchange rate
risk inherent in its sales commitments, anticipated sales, anticipated purchases and assets and liabilities denominated in currencies
other than the U.S. dollar. The foreign currency most significant to the Company’s operations is the Euro. Net sales to
customers outside of the United States were $157.1 million, $153.7 million, and $162.1 million in 2014, 2013 and 2012, respectively.
The Company occasionally hedges certain foreign currency commitments by purchasing foreign currency forward contracts. The Company
does not have material foreign currency market risk (e.g. net foreign currency transaction gain/loss was less than 2% of net earnings
for fiscal years 2014, 2013 and 2012).

[0001144204-14-071151:mdna:124]
| 22 |

[0001144204-14-071151:mdna:125]
Critical Accounting Policies

[0001144204-14-071151:mdna:126]
The preparation of financial statements in conformity with
U.S. generally accepted accounting principles (GAAP) requires Management to make estimates and assumptions in certain circumstances
that affect amounts reported in the accompanying Consolidated Financial Statements. In preparing these financial statements, Management
has made its best estimates and judgments of certain amounts included in the Consolidated Financial Statements, giving due consideration
to materiality. The Company does not believe there is a great likelihood that materially different amounts would be reported under
different conditions or using different assumptions related to the accounting policies described below. However, application of
these accounting policies involves the exercise of judgment and use of assumptions as to future uncertainties and, as a result,
actual results could differ from these estimates. The Company’s senior Management discusses the critical accounting policies
described below with the Audit and Finance Committee of the Company’s Board of Directors on a periodic basis.

[0001144204-14-071151:mdna:127]
The following discussion of critical accounting policies is
intended to bring to the attention of readers those accounting policies which Management believes are critical to the Consolidated
Financial Statements and other financial disclosure. It is not intended to be a comprehensive list of all significant accounting
policies that are more fully described in Note 1 of the Notes to Consolidated Financial Statements included herein.

[0001144204-14-071151:mdna:128]
Revenue Recognition

[0001144204-14-071151:mdna:129]
Filtration
Segment: Within the Filtration segment, approximately 85% of segment revenues (approximately 37% of consolidated
revenues) are recognized when products are delivered (when title and risk of ownership transfers) or when services are performed
for unaffiliated customers.

[0001144204-14-071151:mdna:130]
Approximately 15% of segment revenues (approximately 7% of
consolidated revenues) are recorded under the percentage-of-completion provisions because the Company manufactures complex products
for aerospace and military customers under production contracts. The percentage-of-completion method of accounting involves the
use of various estimating techniques to project costs at completion. These estimates involve various assumptions and projections
relative to the outcome of future events over a period of several years, including future labor productivity and availability,
the nature and complexity of the work to be performed, availability of materials, the impact of delayed performance, and the timing
of product deliveries. These estimates are based on Management’s judgment and the Company’s substantial experience
in developing these types of estimates. Changes in underlying assumptions/estimates may adversely affect financial performance
if they increase estimated project costs at completion, or positively affect financial performance if they decrease estimated
project costs at completion. Due to the nature of these contracts and the operating unit’s cost estimating process, the
Company believes that these estimates generally should not be subject to significant variation in the future. There have been
no material changes to these estimates for the financial statement periods presented. The Company regularly reviews its estimates
to assess revisions in contract values and estimated costs at completion.

[0001144204-14-071151:mdna:131]
Test
Segment: Within the Test segment, approximately 40% of revenues (approximately 14% of consolidated revenues)
are recognized when products are delivered (when title and risk of ownership transfers) or when services are performed for unaffiliated
customers. Certain arrangements contain multiple elements and the application of the guidance requires judgment as to whether
the deliverables can be divided into more than one unit of accounting and whether the separate units of accounting have value
to the customer on a stand-alone basis. Changes to these elements could affect the timing of revenue recognition. There have been
no material changes to these elements for the financial statement periods presented.

[0001144204-14-071151:mdna:132]
Approximately 60% of the segment’s revenues (approximately
20% of consolidated revenues) are recorded under the percentage-of-completion method due to the complex nature of the enclosures
that are designed and produced under these contracts. As discussed above, this method of accounting involves the use of various
estimating techniques to project costs at completion, which are based on Management’s judgment and the Company’s substantial
experience in developing these types of estimates. Changes in underlying assumptions/estimates may adversely or positively affect
financial performance in a period. Due to the nature of these contracts and the operating unit’s cost estimating process,
the Company believes that these estimates generally should not be subject to significant variation in the future. There have been
no material changes to these estimates for the financial statement periods presented. The Company regularly reviews its contract
estimates to assess revisions in contract values and estimated costs at completion.

[0001144204-14-071151:mdna:133]
USG
Segment: Within the USG segment, approximately 100% of the segment’s revenues (approximately 22% of consolidated
revenues) represent products and services sold under a single element arrangement and are recognized when products are delivered
(when title and risk of ownership transfers), when services are performed for unaffiliated customers or on a straight-line basis
over the lease term.

[0001144204-14-071151:mdna:134]
Inventory

[0001144204-14-071151:mdna:135]
Inventories are valued at the lower of cost (first-in, first-out)
or market value. Management regularly reviews inventories on hand compared to historical usage and estimated future usage and
sales. The Company estimates an inventory reserve for excess quantities and obsolete items based on specific identification and
historical write-offs, taking into account future demand and market conditions. The Company’s reserves for excess and obsolete
inventory were $3.9 million and $3.4 million at September 30, 2014 and 2013, respectively. If actual demand or market conditions
in the future are less favorable than those estimated, additional inventory write-downs may be required.

[0001144204-14-071151:mdna:136]
| 23 |

[0001144204-14-071151:mdna:137]
Income Taxes

[0001144204-14-071151:mdna:138]
The Company operates in numerous taxing jurisdictions and is
subject to examination by various U.S. Federal, state and foreign jurisdictions for various tax periods. Additionally, the Company
has retained tax liabilities and the rights to tax refunds in connection with various divestitures of businesses in prior years.
The Company’s income tax positions are based on research and interpretations of the income tax laws and rulings in each
of the jurisdictions in which the Company does business. Due to the subjectivity of interpretations of laws and rulings in each
jurisdiction, the differences and interplay in tax laws between those jurisdictions, as well as the inherent uncertainty in estimating
the final resolution of complex tax audit matters, Management’s estimates of income tax liabilities may differ from actual
payments or assessments.

[0001144204-14-071151:mdna:139]
Management regularly assesses the Company’s position
with regard to tax exposures and records liabilities for these uncertain tax positions and related interest and penalties, if
any, according to the principles of Financial Accounting Standards Board (FASB) ASC Topic 740, Income Taxes (ASC 740).
The Company has recorded an accrual that reflects the recognition and measurement process for the financial statement recognition
and measurement of a tax position taken or expected to be taken on a tax return based upon ASC 740. Additional future income
tax expense or benefit may be recognized once the positions are effectively settled. It is the Company’s policy to
follow FASB ASC 740-10-45-20 and record the tax effects of changes in the opening balance of unrecognized tax benefits in net
earnings from continuing operations.

[0001144204-14-071151:mdna:140]
At the end of each interim reporting period, Management estimates
the effective tax rate expected to apply to the full fiscal year. The estimated effective tax rate contemplates the expected jurisdiction
where income is earned, as well as tax planning strategies. Current and projected growth in income in higher tax jurisdictions
may result in an increasing effective tax rate over time. If the actual results differ from Management’s estimates, Management
may have to adjust the effective tax rate in the interim period if such determination is made.

[0001144204-14-071151:mdna:141]
Income taxes are accounted for under the asset and liability
method. Deferred tax assets and liabilities are recognized for the future tax consequences attributable to differences between
the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets
and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary
differences are expected to be recovered or settled. Deferred tax assets may be reduced by a valuation allowance if it is more
likely than not that some portion of the deferred tax assets will not be realized. The effect on deferred tax assets and liabilities
of a change in tax rates is recognized in income in the period that includes the enactment date. The Company regularly reviews
its deferred tax assets for recoverability and establishes a valuation allowance when Management believes it is more likely than
not such assets will not be recovered, taking into consideration historical operating results, expectations of future earnings,
tax planning strategies, and the expected timing of the reversals of existing temporary differences.

[0001144204-14-071151:mdna:142]
Goodwill And Other Long-Lived Assets

[0001144204-14-071151:mdna:143]
Management annually reviews goodwill and other long-lived assets
with indefinite useful lives for impairment or whenever events or changes in circumstances indicate the carrying amount may not
be recoverable. If the Company determines that the carrying value of the long-lived asset may not be recoverable, a permanent
impairment charge is recorded for the amount by which the carrying value of the long-lived asset exceeds its fair value. Fair
value is measured based on a discounted cash flow method using a discount rate determined by Management to be commensurate with
the risk inherent in the Company’s current business model. The estimates of cash flows and discount rate are subject to
change due to the economic environment, including such factors as interest rates, expected market returns and volatility of markets
served. Management believes that the estimates of future cash flows and fair value are reasonable; however, changes in estimates
could result in impairment charges. At September 30, 2014, the Company has determined that no reporting units are at
risk of material goodwill impairment as the fair value of each reporting unit substantially exceeded its carrying value.

[0001144204-14-071151:mdna:144]
Intangible assets with estimable useful lives are amortized
over their respective estimated useful lives to their estimated residual values, and are reviewed annually for impairment.

[0001144204-14-071151:mdna:145]
| 24 |

[0001144204-14-071151:mdna:146]
Pension Plans and Other Postretirement Benefit Plans

[0001144204-14-071151:mdna:147]
The measurement of liabilities related to pension plans and
other postretirement benefit plans is based on Management’s assumptions related to future events including interest rates,
return on pension plan assets, and health care cost trend rates. Actual pension plan asset performance will either decrease or
increase unamortized pension losses/gains that will affect net earnings in future years. Depending upon the performance of the
equity and bond markets in 2015, the Company could be required to record a charge to other comprehensive income/loss. In addition,
if the discount rate were decreased by

[0001144204-14-071151:mdna:148]
| 25 |

[0001144204-14-071151:mdna:149]
basis points from 4.25% to 4.0%, the projected benefit obligation for the defined benefit
plan would increase by approximately $2.8 million and result in an additional after-tax charge to other comprehensive income/loss
of approximately $1.7 million. The discount rate used in measuring the Company’s pension and postretirement welfare obligations
was developed by matching yields of actual high-quality corporate bonds to expected future pension plan cash flows (benefit payments).
Over 400 Aa-rated, non-callable bonds with a wide range of maturities were used in the analysis. After using the bond yields to
determine the present value of the plan cash flows, a single representative rate that resulted in the same present value was developed.

[0001144204-14-071151:mdna:150]
Other Matters

[0001144204-14-071151:mdna:151]
Contingencies

[0001144204-14-071151:mdna:152]
As a normal incident of the businesses in which the Company
is engaged, various claims, charges and litigation are asserted or commenced from time to time against the Company. Additionally,
the Company is currently involved in various stages of investigation and remediation relating to environmental matters. It is
the opinion of Management that the aggregate costs involved in the resolution of these matters, and final judgments, if any, which
might be rendered against the Company are adequately reserved for, are covered by insurance, or are not likely to have a material
adverse effect on the Company’s results from continuing operations, capital expenditures, or competitive position. Because
the final Aclara working capital adjustment has not been agreed upon, the Company is unable to determine its impact on the results
from discontinued operations.

[0001144204-14-071151:mdna:153]
Quantitative and Qualitative Disclosures About Market
Risk

[0001144204-14-071151:mdna:154]
Market risks relating to the Company’s operations result
primarily from changes in interest rates and changes in foreign currency exchange rates. The Company is exposed to market risk
related to changes in interest rates and selectively uses derivative financial instruments, including forward contracts and swaps,
to manage these risks. All derivative instruments are reported on the balance sheet at fair value. In June 2014, the Company entered
into a forward contract to sell 10.9 million Euros ($14.7 million USD) on November 3, 2014 to hedge the foreign currency risk
related to an intercompany transaction. Gains and losses on foreign currency derivatives are reported in other (income) expenses,
net, on the Company’s Consolidated Statements of Operations. See the further discussion regarding the Company’s market
risks in “Market Risk Analysis,” above.

[0001144204-14-071151:mdna:155]
Controls and Procedures

[0001144204-14-071151:mdna:156]
For a description of the Company’s evaluation of its
disclosure controls and procedures, see Item 9A, “Controls and Procedures,” below.

[0001144204-14-071151:mdna:157]
New Accounting Pronouncements

[0001144204-14-071151:mdna:158]
In April 2014, the FASB issued Accounting Standards Update
(ASU) No. 2014-08 (ASU 2014-08), Reporting Discontinued Operations and Disclosures of Disposals of Components of an
Entity, which amends ASC 205, Presentation of Financial Statements and ASC 360, Property, Plant, and Equipment. This
update changes the criteria for a disposal transaction to qualify as a discontinued operation, and expands the disclosure requirements
surrounding discontinued operations. ASU 2014-08 is effective for fiscal years beginning after December 15, 2014. It will
not have a material effect on the Company’s consolidated financial statements.

[0001144204-14-071151:mdna:159]
25

[0001144204-14-071151:mdna:160]
In May 2014, the FASB issued ASU No. 2014-09 (ASU 2014-09),
Revenue from Contracts with Customers, which requires an entity to recognize the amount of revenue to which it expects to be entitled
for the transfer of promised goods or services to customers. ASU 2014-09 will replace most existing revenue recognition guidance
in U.S. GAAP when it becomes effective. The new standard is effective for annual reporting periods beginning after December 15,
2016. Early application is not permitted. The standard permits the use of either the retrospective or cumulative effect transition
method. The Company is evaluating the effect that ASU 2014-09 will have on its consolidated financial statements and related
disclosures. The Company has not yet selected a transition method nor has it determined the effect of the standard on its ongoing
financial reporting.
