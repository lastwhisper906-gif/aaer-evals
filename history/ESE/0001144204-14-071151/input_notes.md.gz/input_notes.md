# ESE notes — 0001144204-14-071151


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001144204-14-071151:notes:1]
|  | 2. | Aclara Divestiture |

[0001144204-14-071151:notes:2]
On March 28, 2014, the Company completed the sale of Aclara to an affiliate of Sun Capital Partners, Inc. The divestiture generated approximately $135 million of gross cash proceeds. As of March 28, 2014, the Company expected to receive an additional $10 million related to specific Aclara receivables retained by ESCO. As of September 30, 2014, the Company has received approximately $8.5 million of collections related to these specific Aclara receivables and the remaining outstanding receivables totaling $1.5 million were included in Other Current Assets on the Company’s Consolidated Balance Sheet as of September 30, 2014. In addition, as of March 28, 2014, the Company expected to receive an estimated working capital adjustment of approximately $5 million, however, the parties have not reached agreement on the calculation of the final working capital adjustment. The risk in negotiation has been considered in the Company’s consolidated financial statements. Aclara is reflected as discontinued operations and/or assets/liabilities held for sale in the consolidated financial statements and related notes for all periods presented.

[0001144204-14-071151:notes:3]
Aclara’s pretax (loss) earnings recorded in discontinued operations was $(48.2) million, $(62.1) million and $19.5 million for the years ended September 30, 2014, 2013 and 2012, respectively. The 2014 pretax loss consisted of Aclara’s pretax earnings from its results of operations of $15.6 million and a pretax loss of $63.8 million on the sale of Aclara. The 2013 pretax loss was due to the $48 million goodwill impairment charge recorded in the fourth quarter of 2013; lower sales volumes; and changes in product mix (higher shipments of lower margin gas products). Aclara’s net sales were $129.6 million, $184.5 million and $209.7 million for the years ended September 30, 2014, 2013 and 2012, respectively. Aclara’s operations were included within the Company’s USG segment prior to the classification as discontinued operations.

[0001144204-14-071151:notes:4]
The major classes of Aclara assets and liabilities held for sale included in the Consolidated Balance Sheets at September 30, 2013 are shown below:

[0001144204-14-071151:notes:5]
| (Dollars in millions) |  | 2013 |  |
| Assets: |  |  |  |  |
| Accounts receivable, net |  | $ | 55.5 |  |
| Inventories |  |  | 34.9 |  |
| Other current assets |  |  | 18.5 |  |
| Current assets |  |  | 108.9 |  |
| Net property, plant & equipment |  |  | 14.5 |  |
| Intangible assets, net |  |  | 66.0 |  |
| Goodwill |  |  | 57.9 |  |
| Other assets |  |  | 11.8 |  |
| Total assets |  |  | 259.1 |  |
| Liabilities: |  |  |  |  |
| Accounts payable |  |  | 22.2 |  |
| Accrued expenses and other current liabilities |  |  | 41.4 |  |
| Current liabilities |  |  | 63.6 |  |
| Other liabilities |  |  | 16.0 |  |
| Total liabilities |  | $ | 79.6 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001144204-14-071151:notes:6]
|  | 11. | Share-Based Compensation |

[0001144204-14-071151:notes:7]
The Company provides compensation benefits to certain key employees under several share-based plans providing for employee stock options and/or performance-accelerated restricted shares (restricted shares), and to non-employee directors under a non-employee directors compensation plan.

[0001144204-14-071151:notes:8]
Stock Option Plans

[0001144204-14-071151:notes:9]
The Company’s stock option awards have generally been subject to graded vesting over a three-year service period. All outstanding options were granted at prices equal to fair market value at the date of grant. Beginning in fiscal 2004, the options granted have had a five-year contractual life from date of issuance. The Company recognizes compensation cost on a straight-line basis over the requisite service period for the entire award.

[0001144204-14-071151:notes:10]
The fair value of each option award is estimated as of the date of grant using the Black-Scholes option pricing model. Expected volatility is based on historical volatility of ESCO’s stock calculated over the expected term of the option. The Company utilizes historical company data to develop its expected term assumption. The risk-free rate for the expected term of the option is based on the U.S. Treasury yield curve in effect at the date of grant.

[0001144204-14-071151:notes:11]
Information regarding stock options awarded under the option plans is as follows:

[0001144204-14-071151:notes:12]
|  |  | FY 2014 |  | FY 2013 |  | FY 2012 |  |
|  |  |  |  |  | Estimated |  |  |  |  | Estimated |  |  |  |  | Estimated |  |
|  |  |  |  |  | Weighted |  |  |  |  | Weighted |  |  |  |  | Weighted |  |
|  |  | Shares |  | Avg. Price |  | Shares |  | Avg. Price |  | Shares |  | Avg. Price |  |
| October 1, |  |  | 67,350 |  | $ | 37.39 |  |  | 125,816 |  |  | 36.29 |  |  | 435,054 |  |  | 35.58 |  |
| Granted |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Exercised |  |  | — |  | $ | — |  |  | (51,116) |  |  | 34.70 |  |  | (100,872) |  |  | 14.98 |  |
| Cancelled |  |  | (67,350) |  | $ | 37.39 |  |  | (7,350) |  |  | 37.30 |  |  | (208,366) |  |  | 45.18 |  |
| September 30, |  |  | — |  | $ | — |  |  | 67,350 |  |  | 37.39 |  |  | 125,816 |  |  | 36.29 |  |
| At September 30, |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Reserved for future grant |  |  | 500,000 |  |  |  |  |  | 500,000 |  |  |  |  |  | 1,301,090 |  |  |  |  |
| Exercisable |  |  | — |  | $ | — |  |  | 67,350 |  |  | 37.39 |  |  | 125,149 |  |  | 36.31 |  |

[0001144204-14-071151:notes:13]
The aggregate intrinsic value of stock options exercised during 2013 and 2012 was $0.3 million and $2 million, respectively; no stock options were exercised during 2014. No stock options were granted during 2014, 2013 or 2012, and no stock options were outstanding at September 30, 2014.

[0001144204-14-071151:notes:14]
Performance-Accelerated Restricted Share Awards

[0001144204-14-071151:notes:15]
The performance-accelerated restricted shares (restricted shares) have a five-year term with accelerated vesting if certain targets based on market conditions are achieved. In these cases, if it is probable that the performance condition will be met, the Company recognizes compensation cost on a straight-line basis over the shorter performance period; otherwise, it will recognize compensation cost over the longer service period. Compensation cost for the majority of the outstanding restricted share awards is being recognized over the shorter performance period as it is probable the performance condition will be met. The restricted share award grants were valued at the stock price on the date of grant. Pretax compensation expense related to the restricted share awards for continuing operations was $4.1 million, $4 million and $3.8 million for the fiscal years ended September 30, 2014, 2013 and 2012, respectively.

[0001144204-14-071151:notes:16]
The following summary presents information regarding outstanding restricted share awards as of September 30, 2014, and changes during the period then ended:

[0001144204-14-071151:notes:17]
|  |  |  |  |  | Weighted |  |
|  |  | Shares |  | Average Price |  |
| Nonvested at September 30, 2013 |  |  | 425,245 |  | $ | 33.29 |  |
| Granted |  |  | 109,404 |  |  | 33.12 |  |
| Vested |  |  | (168,809) |  |  | 35.13 |  |
| Cancelled |  |  | (33,500) |  |  | 34.08 |  |
| Nonvested at September 30, 2014 |  |  | 332,340 |  | $ | 32.23 |  |

[0001144204-14-071151:notes:18]
Non-Employee Directors Plan

[0001144204-14-071151:notes:19]
The non-employee directors compensation plan provides to each non-employee director a retainer of  900 common shares per quarter. Compensation expense related to the non-employee director grants was $0.7 million, $0.6 million and $0.6 million for the years ended September 30, 2014, 2013 and 2012, respectively.

[0001144204-14-071151:notes:20]
Total Share-Based Compensation

[0001144204-14-071151:notes:21]
The total share-based compensation cost that has been recognized in results of operations and included within SG&A from continuing operations was $4.8 million, $4.6 million and $4.4 million for the years ended September 30, 2014, 2013 and 2012, respectively. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $1.3 million, $1.3 million and $1.6 million for the years ended September 30, 2014, 2013 and 2012, respectively. The Company has elected to use tax law ordering rules when calculating the income tax benefit associated with its share-based payment arrangements. In addition, the Company elected to use the simplified method of calculating the pool of excess tax benefits available to absorb tax deficiencies recognized. As of September 30, 2014, there was $4.7 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a weighted-average period of  1.5 years.


## us-gaap:InventoryDisclosureTextBlock

[0001144204-14-071151:notes:22]
|  | 6. | Inventories |

[0001144204-14-071151:notes:23]
Inventories consist of the following at September 30, 2014 and 2013:

[0001144204-14-071151:notes:24]
| (Dollars in thousands) |  | 2014 |  | 2013 |  |
| Finished goods |  | $ | 18,949 |  |  | 20,925 |  |
| Work in process — including long-term contracts |  |  | 31,634 |  |  | 30,884 |  |
| Raw materials |  |  | 43,709 |  |  | 38,419 |  |
| Total |  | $ | 94,292 |  |  | 90,228 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001144204-14-071151:notes:25]
|  | 15. | Business Segment Information |

[0001144204-14-071151:notes:26]
The Company is organized based on the products and services it offers. Under this organizational structure, the Company has three reporting segments: Filtration/Fluid Flow (Filtration), RF Shielding and Test (Test), and Utility Solutions Group (USG).

[0001144204-14-071151:notes:27]
The Filtration segment’s operations consist of: PTI Technologies Inc., VACCO Industries, Crissair, Inc. and Thermoform Engineered Quality LLC. The companies within this segment design and manufacture specialty filtration products including hydraulic filter elements and fluid control devices used in commercial aerospace applications, unique filter mechanisms used in micro-propulsion devices for satellites and custom designed filters for manned aircraft and submarines.

[0001144204-14-071151:notes:28]
Test segment operations consist of ETS-Lindgren Inc. (ETS-Lindgren). ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy. ETS-Lindgren also manufactures radio frequency shielding products and components used by manufacturers of medical equipment, communications systems, electronic products, and shielded rooms for high-security data processing and secure communication.

[0001144204-14-071151:notes:29]
The USG segment’s operations consist of Doble Engineering Company (Doble). Doble provides high-end, intelligent diagnostic test solutions for the electric power delivery industry and is a leading supplier of power factor and partial discharge testing instruments used to assess the integrity of high-voltage power delivery equipment. Previously, USG also included Aclara Technologies LLC. See Note 2.

[0001144204-14-071151:notes:30]
Accounting policies of the segments are the same as those described in the summary of significant accounting policies in Note 1 to the Consolidated Financial Statements. The operating units within each reporting segment have been aggregated because of similar economic characteristics and meet the other aggregation criteria of FASB ASC 280.

[0001144204-14-071151:notes:31]
The Company evaluates the performance of its operating units based on EBIT, which is defined as: Earnings Before Interest and Taxes. Intersegment sales and transfers are not significant. Segment assets consist primarily of customer receivables, inventories, capitalized software and fixed assets directly associated with the production processes of the segment. Segment depreciation and amortization is based upon the direct assets listed above.

[0001144204-14-071151:notes:32]
Net Sales

[0001144204-14-071151:notes:33]
| (Dollars in millions) |  |  |  |  |  |  |  |  |  |
| Year ended September 30, |  | 2014 |  | 2013 |  | 2012 |  |
| Filtration |  | $ | 233.7 |  |  | 214.1 |  |  | 194.8 |  |
| Test |  |  | 181.8 |  |  | 166.7 |  |  | 175.9 |  |
| USG |  |  | 115.6 |  |  | 109.3 |  |  | 108.0 |  |
| Consolidated totals |  | $ | 531.1 |  |  | 490.1 |  |  | 478.7 |  |

[0001144204-14-071151:notes:34]
One customer exceeded   10% of sales in 2014; no customer exceeded 10% of sales in 2013 or 2012.

[0001144204-14-071151:notes:35]
EBIT

[0001144204-14-071151:notes:36]
| (Dollars in millions) |  |  |  |  |  |  |  |  |  |
| Year ended September 30, |  | 2014 |  | 2013 |  | 2012 |  |
| Filtration |  | $ | 41.4 |  |  | 42.4 |  |  | 38.0 |  |
| Test |  |  | 21.1 |  |  | 16.3 |  |  | 14.0 |  |
| USG |  |  | 26.6 |  |  | 21.6 |  |  | 25.9 |  |
| Reconciliation to consolidated totals (Corporate) |  |  | (25.3) |  |  | (28.0) |  |  | (23.2) |  |
| Consolidated EBIT |  |  | 63.8 |  |  | 52.3 |  |  | 54.7 |  |
| Less: interest expense |  |  | (1.6) |  |  | (2.7) |  |  | (2.5) |  |
| Earnings before income tax |  | $ | 62.2 |  |  | 49.6 |  |  | 52.2 |  |

[0001144204-14-071151:notes:37]
Identifiable Assets

[0001144204-14-071151:notes:38]
| (Dollars in millions) |  |  |  |  |  |  |
| Year ended September 30, |  | 2014 |  | 2013 |  |
| Filtration |  | $ | 131.5 |  |  | 122.9 |  |
| Test |  |  | 114.6 |  |  | 102.4 |  |
| USG |  |  | 98.6 |  |  | 72.3 |  |
| Corporate (includes assets held for sale) |  |  | 501.2 |  |  | 794.7 |  |
| Consolidated totals |  | $ | 845.9 |  |  | 1,092.3 |  |

[0001144204-14-071151:notes:39]
Corporate assets consist primarily of goodwill, deferred taxes, acquired intangible assets, cash balances and assets held for sale.

[0001144204-14-071151:notes:40]
Capital Expenditures

[0001144204-14-071151:notes:41]
| (Dollars in millions) |  |  |  |  |  |  |  |  |  |
| Year ended September 30, |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Filtration |  | $ | 7.0 |  |  | 6.6 |  |  | 4.4 |  |
| Test |  |  | 1.4 |  |  | 3.2 |  |  | 2.2 |  |
| USG |  |  | 4.1 |  |  | 3.9 |  |  | 3.6 |  |
| Corporate |  |  | 0.2 |  |  | 0.2 |  |  | 0.6 |  |
| Consolidated totals |  | $ | 12.7 |  |  | 13.9 |  |  | 10.8 |  |

[0001144204-14-071151:notes:42]
In addition to the above amounts, the Company incurred expenditures for capitalized software of $8.6 million, $8.4 million and $5.3 million in 2014, 2013 and 2012, respectively.

[0001144204-14-071151:notes:43]
Depreciation and Amortization

[0001144204-14-071151:notes:44]
| (Dollars in millions) |  |  |  |  |  |  |  |  |  |
| Year ended September 30, |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Filtration |  | $ | 5.2 |  |  | 4.2 |  |  | 3.9 |  |
| Test |  |  | 2.7 |  |  | 2.5 |  |  | 2.5 |  |
| USG |  |  | 4.8 |  |  | 4.6 |  |  | 3.4 |  |
| Corporate |  |  | 3.7 |  |  | 3.5 |  |  | 4.7 |  |
| Consolidated totals |  | $ | 16.4 |  |  | 14.8 |  |  | 14.5 |  |

[0001144204-14-071151:notes:45]
Geographic Information

[0001144204-14-071151:notes:46]
| (Dollars in millions) |  |  |  |  |  |  |  |  |  |
| Year ended September 30, |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| United States |  | $ | 374.0 |  |  | 336.4 |  |  | 316.6 |  |
| Asia |  |  | 59.9 |  |  | 59.5 |  |  | 66.3 |  |
| Europe |  |  | 62.0 |  |  | 51.5 |  |  | 61.7 |  |
| Canada |  |  | 10.4 |  |  | 14.3 |  |  | 12.6 |  |
| India |  |  | 3.3 |  |  | 10.2 |  |  | 7.5 |  |
| Other |  |  | 21.5 |  |  | 18.2 |  |  | 14.0 |  |
| Consolidated totals |  | $ | 531.1 |  |  | 490.1 |  |  | 478.7 |  |

[0001144204-14-071151:notes:47]
Long-Lived Assets

[0001144204-14-071151:notes:48]
| (Dollars in millions) |  |  |  |  |  |  |
| Year ended September 30, |  | 2014 |  |  | 2013 |  |
| United States |  | $ | 73.6 |  |  | 72.8 |  |
| Europe |  |  | 2.2 |  |  | 2.2 |  |
| Other |  |  | 0.7 |  |  | 0.5 |  |
| Consolidated totals |  | $ | 76.5 |  |  | 75.5 |  |

[0001144204-14-071151:notes:49]
Net sales are attributed to countries based on location of customer. Long-lived assets are attributed to countries based on location of the asset.


## us-gaap:DebtDisclosureTextBlock

[0001144204-14-071151:notes:50]
|  | 9. | Debt |

[0001144204-14-071151:notes:51]
Debt consists of the following at September 30, 2014 and 2013:

[0001144204-14-071151:notes:52]
| (Dollars in thousands) |  | 2014 |  | 2013 |  |
| Revolving credit facility, including current portion |  | $ | 40,000 |  |  | 172,000 |  |
| Current portion of long-term debt |  |  | (20,000) |  |  | (50,000) |  |
| Total long-term debt, less current portion |  | $ | 20,000 |  |  | 122,000 |  |

[0001144204-14-071151:notes:53]
On May 14, 2012, the Company entered into a new $450 million five-year revolving credit facility with JPMorgan Chase Bank, N.A., as administrative agent, PNC Bank, N.A., as syndication agent, and eight other participating lenders (the “Credit Facility”). The Credit Facility replaced the Company’s $330 million revolving credit facility that would otherwise have matured in November, 2012. Through a credit facility expansion option, the Company may elect to increase the size of the Credit Facility by entering into incremental term loans, in any agreed currency, at a minimum of $25 million each up to a maximum of $250 million aggregate. The Company’s ability to access the additional $250 million increase option of the Credit Facility is subject to acceptance by participating or other outside banks.

[0001144204-14-071151:notes:54]
At September 30, 2014, the Company had approximately $399 million available to borrow under the Credit Facility, plus a $250 million increase option, in addition to $35.1 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of September 30, 2014, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months.

[0001144204-14-071151:notes:55]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from  17.5 to 35 basis points per annum on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a  65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. During 2014 and 2013, the maximum aggregate short-term borrowings at any month-end were $187 million and $191 million, respectively; the average aggregate short-term borrowings outstanding based on month-end balances were $103 million and $171 million, respectively; and the weighted average interest rates were  1.48%,  1.55% and  1.20% for 2014, 2013 and 2012, respectively. The letters of credit issued and outstanding under the Credit Facility totaled $11 million and $13 million at September 30, 2014 and 2013, respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001144204-14-071151:notes:56]
|  | 8. | Income Tax Expense |

[0001144204-14-071151:notes:57]
Total income tax expense (benefit) for the years ended September 30, 2014, 2013 and 2012 was allocated to income tax expense as follows:

[0001144204-14-071151:notes:58]
| (Dollars in thousands) |  | 2014 |  | 2013 |  | 2012 |  |
| Income tax expense from Continuing Operations |  | $ | 19,594 |  |  | 18,335 |  |  | 17,408 |  |
| Income tax (benefit) expense from Discontinued Operations |  |  | (6,034) |  |  | (5,215) |  |  | 7,397 |  |
| Total income tax expense |  | $ | 13,560 |  |  | 13,120 |  |  | 24,805 |  |

[0001144204-14-071151:notes:59]
The components of income from continuing operations before income taxes consisted of the following for the years ended September 30:

[0001144204-14-071151:notes:60]
| (Dollars in thousands) |  | 2014 |  | 2013 |  | 2012 |  |
| United States |  | $ | 56,196 |  |  | 43,159 |  |  | 46,883 |  |
| Foreign |  |  | 6,011 |  |  | 6,436 |  |  | 5,299 |  |
| Total income before income taxes |  | $ | 62,207 |  |  | 49,595 |  |  | 52,182 |  |

[0001144204-14-071151:notes:61]
The principal components of income tax expense (benefit) from continuing operations for the years ended September 30, 2014, 2013 and 2012 consist of:

[0001144204-14-071151:notes:62]
| (Dollars in thousands) |  | 2014 |  | 2013 |  | 2012 |  |
| Federal: |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 18,756 |  |  | 10,723 |  |  | 11,144 |  |
| Deferred |  |  | (2,442) |  |  | 2,942 |  |  | 2,954 |  |
| State and local: |  |  |  |  |  |  |  |  |  |  |
| Current |  |  | 1,397 |  |  | 896 |  |  | 1,372 |  |
| Deferred |  |  | (245) |  |  | 642 |  |  | 309 |  |
| Foreign: |  |  |  |  |  |  |  |  |  |  |
| Current |  |  | 2,044 |  |  | 2,033 |  |  | 1,863 |  |
| Deferred |  |  | 84 |  |  | 1,099 |  |  | (234) |  |
| Total |  | $ | 19,594 |  |  | 18,335 |  |  | 17,408 |  |

[0001144204-14-071151:notes:63]
The actual income tax expense (benefit) from continuing operations for the years ended September 30, 2014, 2013 and 2012 differs from the expected tax expense for those years (computed by applying the U.S. Federal corporate statutory rate) as follows:

[0001144204-14-071151:notes:64]
|  |  | 2014 |  | 2013 |  | 2012 |  |
| Federal corporate statutory rate |  |  | 35.0 | % | 35.0 | % | 35.0 | % |
| State and local, net of Federal benefits |  |  | 2.0 |  | 2.7 |  | 3.3 |  |
| Foreign |  |  | (1.7) |  | (1.9) |  | (0.7) |  |
| Research credit |  |  | (1.0) |  | (2.5) |  | (0.3) |  |
| Domestic production deduction |  |  | (2.9) |  | (2.5) |  | (2.4) |  |
| Change in uncertain tax positions |  |  | (2.9) |  | 0.1 |  | (3.6) |  |
| Purchase accounting adjustment |  |  | — |  | — |  | 1.0 |  |
| Executive compensation |  |  | 1.3 |  | 1.8 |  | 0.6 |  |
| Valuation allowance |  |  | 1.3 |  | 4.0 |  | 0.2 |  |
| Other, net |  |  | 0.4 |  | 0.3 |  | 0.3 |  |
| Effective income tax rate |  |  | 31.5 | % | 37.0 | % | 33.4 | % |

[0001144204-14-071151:notes:65]
The tax effects of temporary differences that give rise to significant portions of the deferred tax assets and liabilities at September 30, 2014 and 2013 are presented below:

[0001144204-14-071151:notes:66]
| (Dollars in thousands) |  | 2014 |  | 2013 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |
| Inventories, long-term contract accounting, contract cost reserves and other |  | $ | 7,710 |  |  | 6,825 |  |
| Pension and other postretirement benefits |  |  | 6,974 |  |  | 7,417 |  |
| Net operating loss carryforward — domestic |  |  | 658 |  |  | 848 |  |
| Net operating loss carryforward — foreign |  |  | 4,702 |  |  | 3,955 |  |
| Capital loss carryforward |  |  | — |  |  | 240 |  |
| Other compensation-related costs and other cost accruals |  |  | 13,996 |  |  | 19,325 |  |
| State credit carryforward |  |  | 1,276 |  |  | 1,099 |  |
| Total deferred tax assets |  |  | 35,316 |  |  | 39,709 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |
| Goodwill |  |  | (14,338) |  |  | (14,576) |  |
| Acquisition assets |  |  | (57,795) |  |  | (61,403) |  |
| Depreciation, software amortization |  |  | (16,380) |  |  | (36,396) |  |
| Net deferred tax liabilities before valuation allowance |  |  | (53,197) |  |  | (72,666) |  |
| Less valuation allowance |  |  | (4,297) |  |  | (3,780) |  |
| Net deferred tax liabilities |  | $ | (57,494) |  |  | (76,446) |  |

[0001144204-14-071151:notes:67]
The Company has a foreign net operating loss carryforward of $18.2 million at September 30, 2014, which reflects tax loss carryforwards in Brazil, Germany, India, Japan, Finland, China and the United Kingdom. $16.4 million of the tax loss carryforwards have no expiration date while the remaining $1.8 million will expire between 2016 and 2024. The Company has state net operating loss carryforwards of $0.3 million at September 30, 2014 which expire between 2020 and 2033. The Company also has net state research and other credit carryforwards of $1.3 million of which $0.9 million expires between 2025 and 2034. The remaining $0.4 million does not have an expiration date.

[0001144204-14-071151:notes:68]
The valuation allowance for deferred tax assets as of September 30, 2014 and 2013 was $4.3 million and $3.8 million, respectively. The net change in the total valuation allowance for each of the years ended September 30, 2014 and 2013 was an increase of $0.5 million and an increase of $2.8 million, respectively. The Company has established a valuation allowance against state credit carryforwards of $0.4 million at both September 30, 2014 and 2013. In addition, the Company has established a valuation allowance against state net operating loss (NOL) carryforwards that are not expected to be realized in future periods of $0.3 million and $0.4 million at September 30, 2014 and 2013, respectively. Lastly, the Company has established a valuation allowance against certain NOL carryforwards in foreign jurisdictions which may not be realized in future periods. The valuation allowance established against the foreign NOL carryforwards was $3.6 million and $2.8 million at September 30, 2014, and 2013, respectively. The Company classifies its valuation allowance related to deferred taxes on a pro rata basis by taxing jurisdiction.

[0001144204-14-071151:notes:69]
The Company’s foreign subsidiaries have accumulated unremitted earnings of $32.6 million and cash of $27.0 million at September 30, 2014. No deferred taxes have been provided on these accumulated unremitted earnings because these funds are not needed to meet the liquidity requirements of the Company’s U.S. operations and it is the Company’s intention to indefinitely reinvest these earnings in continuing international operations. In the event these foreign entities’ earnings were distributed, it is estimated that U.S. taxes, net of available foreign tax credits, of approximately $4.7 million would be due, which would correspondingly reduce the Company’s net earnings. No significant portion of the Company’s foreign subsidiaries’ earnings was taxed at a very low tax rate.

[0001144204-14-071151:notes:70]
As of September 30, 2014, the Company had $0.5 million of unrecognized benefits (see table below), which, net of Federal benefit, if recognized, would affect the Company’s effective tax rate.

[0001144204-14-071151:notes:71]
A reconciliation of the Company’s unrecognized tax benefits for the years ended September 30, 2014 and 2013 is presented in the table below:

[0001144204-14-071151:notes:72]
| (Dollars in millions) |  | 2014 |  | 2013 |  |
| Balance as of October 1, |  | $ | 2.2 |  |  | 1.8 |  |
| Increases related to prior year tax positions |  |  | — |  |  | 0.5 |  |
| Decreases related to prior year tax positions |  |  | (0.7) |  |  | — |  |
| Increases related to current year tax positions |  |  | — |  |  | 0.2 |  |
| Decreases related to settlements with taxing authorities |  |  | — |  |  | (0.1) |  |
| Lapse of statute of limitations |  |  | (1.0) |  |  | (0.2) |  |
| Balance as of September 30, |  | $ | 0.5 |  |  | 2.2 |  |

[0001144204-14-071151:notes:73]
The Company anticipates a $0.1 million reduction in the amount of unrecognized tax benefits in the next 12 months as a result of a lapse of the applicable statute of limitations. The Company’s policy is to include interest related to unrecognized tax benefits in income tax expense and penalties in operating expense. As of September 30, 2014, 2013 and 2012, the Company had accrued interest related to uncertain tax positions of zero, $0.1 million and $0.1 million, respectively, net of Federal income tax benefit, on its Consolidated Balance Sheet. No significant penalties have been accrued.

[0001144204-14-071151:notes:74]
The principal jurisdictions for which the Company files income tax returns are U.S. Federal and the various city, state, and international locations where the Company has operations. The U.S. Federal tax years for the periods ended September 30, 2011 and forward remain subject to income tax examination. In the second quarter of 2014, the Internal Revenue Service completed their examination of the Company’s U.S. Federal income tax return for the period ended September 30, 2011; no adjustments were proposed. Various state tax years for the periods ended September 30, 2010 and forward remain subject to income tax examinations. The Company is subject to income tax in many jurisdictions outside the United States, none of which is individually material to the Company’s financial position, statements of cash flows, or results of operations.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001144204-14-071151:notes:75]
|  | 13. | Derivative Financial Instruments |

[0001144204-14-071151:notes:76]
Market risks relating to the Company’s operations result primarily from changes in interest rates and changes in foreign currency exchange rates. The Company is exposed to market risk related to changes in interest rates and selectively uses derivative financial instruments, including forward contracts and swaps, to manage these risks. In June 2014, the Company entered into a forward contract to sell  10.9 million Euros (US$  14.7 million) on November 3, 2014 to hedge the foreign currency risk related to an intercompany transaction. The Company expects hedging gains or losses to be essentially offset by losses or gains on the related underlying exposures. The amounts ultimately recognized may differ for open positions, which remain subject to ongoing market price fluctuations until settlement. Gains and losses on foreign currency derivatives are reported in other expenses (income), net, on the Company’s Consolidated Statements of Operations. The fair value of the foreign currency derivative is classified in accounts receivable on the Company’s Consolidated Balance Sheet.  The following is a summary of the notional transaction amounts and fair values for the Company’s outstanding derivative financial instruments as of September 30, 2014.

[0001144204-14-071151:notes:77]
|  |  | Notional |  |  |  |  |
|  |  | Amount |  | Fair Value |  |
| (In thousands) |  | (Euros) |  | (US$) |  |
| Forward contract |  |  | 10,891 |  |  | 927 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001144204-14-071151:notes:78]
|  | 16. | Commitments and Contingencies |

[0001144204-14-071151:notes:79]
At September 30, 2014, the Company had $11.2 million in letters of credit outstanding as guarantees of contract performance. As a normal incident of the businesses in which the Company is engaged, various claims, charges and litigation are asserted or commenced from time to time against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. It is the opinion of Management that the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company are adequately reserved for, are covered by insurance, or are not likely to have a material adverse effect on the Company’s results from continuing operations, capital expenditures, or competitive position. Because the final Aclara working capital adjustment has not been agreed upon, the Company is unable to determine its impact on the results from discontinued operations.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001144204-14-071151:notes:80]
|  | 7. | Property, Plant and Equipment |

[0001144204-14-071151:notes:81]
Depreciation expense of property, plant and equipment for the years ended September 30, 2014, 2013 and 2012 was $9.6 million, $8.6 million and $8.1 million, respectively.

[0001144204-14-071151:notes:82]
The Company leases certain real property, equipment and machinery under noncancelable operating leases. Rental expense under these operating leases for the years ended September 30, 2014, 2013 and 2012 was $5.3 million, $5 million and $5 million, respectively.  Future aggregate minimum lease payments under operating leases that have initial or remaining noncancelable lease terms in excess of one year as of September 30, 2014, are:

[0001144204-14-071151:notes:83]
| (Dollars in thousands) |  |  |  |
| Years ending September 30: |  |  |  |
| 2015 |  | $ | 4,995 |  |
| 2016 |  |  | 3,807 |  |
| 2017 |  |  | 2,555 |  |
| 2018 |  |  | 2,101 |  |
| 2019 and thereafter |  |  | 2,412 |  |
| Total |  | $ | 15,870 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001144204-14-071151:notes:84]
|  | 1. | Summary of Significant Accounting Policies |

[0001144204-14-071151:notes:85]
|  | A. | Principles of Consolidation |

[0001144204-14-071151:notes:86]
The Consolidated Financial Statements include the accounts of ESCO Technologies Inc. (ESCO) and its wholly owned subsidiaries (the Company). All significant intercompany transactions and accounts have been eliminated in consolidation.

[0001144204-14-071151:notes:87]
|  | B. | Basis of Presentation |

[0001144204-14-071151:notes:88]
Fair values of the Company’s financial instruments are estimated by reference to quoted prices from market sources and financial institutions, as well as other valuation techniques. The estimated fair value of each class of financial instruments approximated the related carrying value at September 30, 2014 and 2013.

[0001144204-14-071151:notes:89]
Aclara is reflected as discontinued operations and/or assets/liabilities held for sale in the consolidated financial statements and related notes for all periods presented, in accordance with accounting principles generally accepted in the United States of America (GAAP). Prior period amounts have been reclassified to conform to the current period presentation. See Note 2.

[0001144204-14-071151:notes:90]
|  | C. | Nature of Continuing Operations |

[0001144204-14-071151:notes:91]
The Company has three reportable segments: Filtration/Fluid Flow (Filtration), RF Shielding and Test (Test), and Utility Solutions Group (USG).

[0001144204-14-071151:notes:92]
Filtration: The companies within this segment primarily design and manufacture specialty filtration products including hydraulic filter elements and fluid control devices used in commercial aerospace applications, unique filter mechanisms used in micro-propulsion devices for satellites and custom designed filters for manned aircraft and submarines.

[0001144204-14-071151:notes:93]
Test: ETS-Lindgren Inc. (ETS-Lindgren) is an industry leader in providing its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy.

[0001144204-14-071151:notes:94]
USG:Doble Engineering Company (Doble) provides high-end, intelligent, diagnostic test solutions for the electric power delivery industry.

[0001144204-14-071151:notes:95]
|  | D. | Use of Estimates |

[0001144204-14-071151:notes:96]
The preparation of financial statements in conformity with GAAP requires Management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. The Company regularly evaluates the estimates and assumptions related to the allowance for doubtful trade receivables, inventory obsolescence, warranty reserves, value of equity-based awards, goodwill and purchased intangible asset valuations, asset impairments, employee benefit plan liabilities, income tax liabilities and assets and related valuation allowances, uncertain tax positions, estimates on long-term contracts, and litigation and other loss contingencies. Actual results could differ from those estimates.

[0001144204-14-071151:notes:97]
|  | E. | Revenue Recognition |

[0001144204-14-071151:notes:98]
Filtration: Within the Filtration segment, approximately  85% of revenues (approximately  37% of consolidated revenues) are recognized when products are delivered (when title and risk of ownership transfers) or when services are performed for unaffiliated customers.

[0001144204-14-071151:notes:99]
Approximately  15% of segment revenues (approximately 7% of consolidated revenues) are recorded under the percentage-of-completion method. Products accounted for under this guidance include the design, development and manufacture of complex fluid control products, quiet valves, manifolds and systems primarily for the aerospace and military markets. For arrangements that are accounted for under this guidance, the Company estimates profit as the difference between total estimated revenue and total estimated cost of a contract and recognizes these revenues and costs based on units delivered. The percentage-of-completion method of accounting involves the use of various techniques to estimate expected costs at completion.

[0001144204-14-071151:notes:100]
Test: Within the Test segment, approximately  40% of revenues (approximately  14% of consolidated revenues) are recognized when products are delivered (when title and risk of ownership transfers) or when services are performed for unaffiliated customers. Certain arrangements contain multiple elements generally consisting of materials and installation services used in the construction and installation of standard shielded enclosures to measure and contain magnetic and electromagnetic energy. The installation process does not involve changes to the features or capabilities of the equipment and does not require proprietary information about the equipment in order for the installed equipment to perform to specifications.

[0001144204-14-071151:notes:101]
Approximately  60% of the segment’s revenues (approximately  20% of consolidated revenues) are recorded under the percentage-of-completion method due to the complex nature of the enclosures that are designed and produced under these contracts. Products accounted for under this guidance include the construction and installation of complex test chambers to a buyer’s specifications that provide its customers with the ability to measure and contain magnetic, electromagnetic and acoustic energy. As discussed above, for arrangements that are accounted for under this guidance, the Company estimates profit as the difference between total estimated revenue and total estimated cost of a contract and recognizes these revenues and costs based on either (a) units delivered or (b) contract milestones. If a reliable measure of output cannot be established (which applies to less than 2% of Test segment revenues or 1% of consolidated revenues), input measures (e.g., costs incurred) are used to recognize revenue. Given the nature of the Company’s operations related to these contracts, costs incurred represent an appropriate measure of progress towards completion.

[0001144204-14-071151:notes:102]
The percentage-of-completion method of accounting involves the use of various techniques to estimate expected costs at completion. These estimates are based on Management’s judgment and the Company’s substantial experience in developing these types of estimates.

[0001144204-14-071151:notes:103]
USG:  Within the USG segment, approximately  100% of segment revenues (approximately  22% of consolidated revenues) are recognized when products are delivered (when title and risk of ownership transfers), when services are performed for unaffiliated customers or on a straight-line basis over the lease term.

[0001144204-14-071151:notes:104]
|  | F. | Cash and Cash Equivalents |

[0001144204-14-071151:notes:105]
Cash equivalents include temporary investments that are readily convertible into cash, such as money market funds.

[0001144204-14-071151:notes:106]
|  | G. | Accounts Receivable |

[0001144204-14-071151:notes:107]
Accounts receivable have been reduced by an allowance for amounts that the Company estimates are uncollectible in the future. This estimated allowance is based on Management’s evaluation of the financial condition of the customer and historical write-off experience.

[0001144204-14-071151:notes:108]
|  | H. | Costs and Estimated Earnings on Long-Term Contracts |

[0001144204-14-071151:notes:109]
Costs and estimated earnings on long-term contracts represent unbilled revenues, including accrued profits, accounted for under the percentage-of-completion method, net of progress billings.

[0001144204-14-071151:notes:110]
|  | I. | Inventories |

[0001144204-14-071151:notes:111]
Inventories are valued at the lower of cost (first-in, first-out) or market value. Inventories are regularly reviewed for excess quantities and obsolescence based upon historical experience, specific identification of discontinued items, future demand, and market conditions. Inventories under long-term contracts reflect accumulated production costs, factory overhead, initial tooling and other related costs less the portion of such costs charged to cost of sales and any unliquidated progress payments.

[0001144204-14-071151:notes:112]
|  | J. | Property, Plant and Equipment |

[0001144204-14-071151:notes:113]
Property, plant and equipment are recorded at cost. Depreciation and amortization are computed primarily on a straight-line basis over the estimated useful lives of the assets: buildings,  10-40 years; machinery and equipment,  3-10 years; and office furniture and equipment,  3-10 years. Leasehold improvements are amortized over the remaining term of the applicable lease or their estimated useful lives, whichever is shorter. Long-lived tangible assets are reviewed for impairment whenever events or changes in business circumstances indicate the carrying value of the assets may not be recoverable. Impairment losses are recognized based on fair value.

[0001144204-14-071151:notes:114]
|  | K. | Goodwill and Other Long-Lived Assets |

[0001144204-14-071151:notes:115]
Goodwill represents the excess of purchase costs over the fair value of net identifiable assets acquired in business acquisitions. Management annually reviews goodwill and other long-lived assets with indefinite useful lives for impairment or whenever events or changes in circumstances indicate the carrying amount may not be recoverable. If the Company determines that the carrying value of the long-lived asset may not be recoverable, a permanent impairment charge is recorded for the amount by which the carrying value of the long-lived asset exceeds its fair value. Fair value is measured based on a discounted cash flow method using a discount rate determined by Management to be commensurate with the risk inherent in the Company’s current business model. See Note 2.

[0001144204-14-071151:notes:116]
Other intangible assets represent costs allocated to identifiable intangible assets, principally capitalized software, patents, trademarks, and technology rights. See Note 4 regarding goodwill and other intangible assets activity.

[0001144204-14-071151:notes:117]
|  | L. | Capitalized Software |

[0001144204-14-071151:notes:118]
The costs incurred for the development of computer software that will be sold, leased, or otherwise marketed are charged to expense when incurred as research and development until technological feasibility has been established for the product. Technological feasibility is typically established upon completion of a detailed program design. Costs incurred after this point are capitalized on a project-by-project basis. Capitalized costs consist of internal and external development costs. Upon general release of the product to customers, the Company ceases capitalization and begins amortization, which is calculated on a project-by-project basis as the greater of (1) the ratio of current gross revenues for a product to the total of current and anticipated future gross revenues for the product or (2) the straight-line method over the estimated economic life of the product. The Company generally amortizes the software development costs over a three-to-seven year period based upon the estimated future economic life of the product. Factors considered in determining the estimated future economic life of the product include anticipated future revenues, and changes in software and hardware technologies. Management annually reviews the carrying values of capitalized costs for impairment or whenever events or changes in circumstances indicate the carrying amount may not be recoverable. If expected cash flows are insufficient to recover the carrying amount of the asset, then an impairment loss is recognized to state the asset at its net realizable value.

[0001144204-14-071151:notes:119]
M.    Income Taxes

[0001144204-14-071151:notes:120]
Income taxes are accounted for under the asset and liability method. Deferred tax assets and liabilities are recognized for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. Deferred tax assets may be reduced by a valuation allowance if it is more likely than not that some portion or all of the deferred tax assets will not be realized. The effect on deferred tax assets and liabilities of a change in tax rates is recognized in income in the period that includes the enactment date. The Company regularly reviews its deferred tax assets for recoverability and establishes a valuation allowance when Management believes it is more likely than not such assets will not be recovered, taking into consideration historical operating results, expectations of future earnings, tax planning strategies, and the expected timing of the reversals of existing temporary differences.

[0001144204-14-071151:notes:121]
|  | N. | Research and Development Costs |

[0001144204-14-071151:notes:122]
Company-sponsored research and development costs include research and development and bid and proposal efforts related to the Company’s products and services. Company-sponsored product development costs are charged to expense when incurred. Customer-sponsored research and development costs incurred pursuant to contracts are accounted for similarly to other program costs. Customer-sponsored research and development costs refer to certain situations whereby customers provide funding to support specific contractually defined research and development costs.

[0001144204-14-071151:notes:123]
|  | O. | Foreign Currency Translation |

[0001144204-14-071151:notes:124]
The financial statements of the Company’s foreign operations are translated into U.S. dollars in accordance with FASB ASC Topic 830, Foreign Currency Matters. The resulting translation adjustments are recorded as a separate component of accumulated other comprehensive income.

[0001144204-14-071151:notes:125]
|  | P. | Earnings Per Share |

[0001144204-14-071151:notes:126]
Basic earnings per share is calculated using the weighted average number of common shares outstanding during the period. Diluted earnings per share is calculated using the weighted average number of common shares outstanding during the period plus shares issuable upon the assumed exercise of dilutive common share options and vesting of performance-accelerated restricted shares using the treasury stock method.

[0001144204-14-071151:notes:127]
The number of shares used in the calculation of earnings per share for each year presented is as follows:

[0001144204-14-071151:notes:128]
| (in thousands) |  | 2014 |  | 2013 |  | 2012 |  |
| Weighted Average Shares Outstanding — Basic |  |  | 26,447 |  |  | 26,450 |  |  | 26,699 |  |
| Dilutive Options and Performance- Accelerated Restricted Stock |  |  | 197 |  |  | 352 |  |  | 331 |  |
| Shares — Diluted |  |  | 26,644 |  |  | 26,802 |  |  | 27,030 |  |

[0001144204-14-071151:notes:129]
Options to purchase  1,433 shares at a price of $37.54 were outstanding during the year ended September 30, 2014, but were not included in the respective computation of diluted EPS because the options’ exercise price was greater than the average market price of the common shares. Options to purchase  78,166 shares at prices ranging from $36.70-$37.98 were outstanding during the year ended September 30, 2013, but were not included in the respective computation of diluted EPS because the options’ exercise price was greater than the average market price of the common shares. Options to purchase  126,787 shares at prices ranging from $35.69-$45.81 were outstanding during the year ended September 30, 2012, but were not included in the respective computation of diluted EPS because the options’ exercise price was greater than the average market price of the common shares. These options expired in various periods through 2014.

[0001144204-14-071151:notes:130]
Approximately  135,000,  156,000 and  175,000 restricted shares were outstanding but unearned at September 30, 2014, 2013 and 2012, respectively, and therefore were not included in the respective years’ computations of diluted EPS.

[0001144204-14-071151:notes:131]
|  | Q. | Share-Based Compensation |

[0001144204-14-071151:notes:132]
The Company provides compensation benefits to certain key employees under several share-based plans providing for employee stock options and/or performance-accelerated restricted shares (restricted shares), and to non-employee directors under a non-employee directors compensation plan. Share-based payment expense is measured at the grant date based on the fair value of the award and is recognized on a straight-line basis over the requisite service period (generally the vesting period of the award).

[0001144204-14-071151:notes:133]
|  | R. | Accumulated Other Comprehensive Loss |

[0001144204-14-071151:notes:134]
Accumulated other comprehensive loss of $(19.2) million at September 30, 2014, consisted of $(22.3) million related to the pension net actuarial loss; and $3.1 million related to currency translation adjustments. Accumulated other comprehensive loss of $(16.7) million at September 30, 2013, consisted of $(20.6) million related to the pension net actuarial loss; and $3.9 million related to currency translation adjustments.

[0001144204-14-071151:notes:135]
|  | S. | Deferred Revenue And Costs |

[0001144204-14-071151:notes:136]
Deferred revenue and costs are recorded when products or services have been provided but the criteria for revenue recognition have not been met. If there is a customer acceptance provision or there is uncertainty about customer acceptance, revenue and costs are deferred until the customer has accepted the product or service.

[0001144204-14-071151:notes:137]
|  | T. | Derivative Financial Instruments |

[0001144204-14-071151:notes:138]
All derivative financial instruments are reported on the balance sheet at fair value. The accounting for changes in fair value of a derivative instrument depends on whether it has been designated and qualifies as a hedge and on the type of hedge. For each derivative instrument designated as a cash flow hedge, the effective portion of the gain or loss on the derivative is deferred in accumulated other comprehensive income until recognized in earnings with the underlying hedged item. For each derivative instrument designated as a fair value hedge, the gain or loss on the derivative and the offsetting gain or loss on the hedged item are recognized immediately in earnings. Regardless of type, a fully effective hedge will result in no net earnings impact while the derivative is outstanding. To the extent that any hedge is ineffective at offsetting cash flow or fair value changes in the underlying hedged item, there could be a net earnings impact.

[0001144204-14-071151:notes:139]
|  | U. | Fair Value of Financial Measurements |

[0001144204-14-071151:notes:140]
Fair value is defined as the price at which an asset could be exchanged in a current transaction between knowledgeable, willing parties or the amount that would be paid to transfer a liability to a new obligor, not the amount that would be paid to settle the liability with the creditor. Where available, fair value is based on observable market prices or parameters or derived from such prices or parameters. Where observable prices or inputs are not available, valuation models are applied. These valuation techniques involve some level of Management estimation and judgment, the degree of which is dependent on the price transparency for the instruments or market and the instruments’ complexity.

[0001144204-14-071151:notes:141]
Assets and liabilities recorded at fair value in the consolidated balance sheets are categorized based upon the level of judgment associated with the inputs used to measure their fair value. Hierarchical levels, defined by ASC 820, and directly related to the amount of subjectivity associated with the inputs to fair valuation of these assets and liabilities, are as follows:

[0001144204-14-071151:notes:142]
Level 1 – Inputs were unadjusted, quoted prices in active markets for identical assets or liabilities at the measurement date.

[0001144204-14-071151:notes:143]
Level 2 – Inputs (other than quoted prices included in Level 1) were either directly or indirectly observable for the asset or liability through correlation with market data at the measurement date and for the duration of the instrument’s anticipated life.

[0001144204-14-071151:notes:144]
Level 3 – Inputs reflected Management’s best estimate of what market participants would use in pricing the asset or liability at the measurement date.

[0001144204-14-071151:notes:145]
V.    New Accounting Standards

[0001144204-14-071151:notes:146]
In April 2014, the FASB issued Accounting Standards Update (ASU) No. 2014-08 (ASU 2014-08), Reporting Discontinued Operations and Disclosures of Disposals of Components of an Entity, which amends ASC 205, Presentation of Financial Statements and ASC 360, Property, Plant, and Equipment. This update changes the criteria for a disposal transaction to qualify as a discontinued operation, and expands the disclosure requirements surrounding discontinued operations. ASU 2014-08 is effective for fiscal years beginning after December 15, 2014. It will not have a material effect on the Company’s consolidated financial statements.

[0001144204-14-071151:notes:147]
In May 2014, the FASB issued ASU No. 2014-09 (ASU 2014-09), Revenue from Contracts with Customers, which requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. ASU 2014-09 will replace most existing revenue recognition guidance in U.S. GAAP when it becomes effective. The new standard is effective for annual reporting periods beginning after December 15, 2016. Early application is not permitted. The standard permits the use of either the retrospective or cumulative effect transition method. The Company is evaluating the effect that ASU 2014-09 will have on its consolidated financial statements and related disclosures. The Company has not yet selected a transition method nor has it determined the effect of the standard on its ongoing financial reporting.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001144204-14-071151:notes:148]
|  | 17. | Quarterly Financial Information (Unaudited) |

[0001144204-14-071151:notes:149]
|  |  | First |  | Second |  | Third |  | Fourth |  | Fiscal |  |
| (Dollars in thousands, except per share amounts) |  | Quarter |  | Quarter |  | Quarter |  | Quarter |  | Year |  |
| 2014 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 124,450 |  |  | 124,762 |  |  | 130,495 |  |  | 151,413 |  |  | 531,120 |  |
| Net earnings from continuing operations |  |  | 8,832 |  |  | 9,264 |  |  | 11,590 |  |  | 12,927 |  |  | 42,613 |  |
| Net (loss) earnings from discontinued operations |  |  | 2,357 |  |  | (42,941) |  |  | — |  |  | (1,619) |  |  | (42,203) |  |
| Net earnings (loss) |  |  | 11,189 |  |  | (33,677) |  |  | 11,590 |  |  | 11,308 |  |  | 410 |  |
| Basic earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings from continuing operations |  |  | 0.33 |  |  | 0.35 |  |  | 0.44 |  |  | 0.49 |  |  | 1.61 |  |
| Net (loss) earnings from discontinued operations |  |  | 0.09 |  |  | (1.62) |  |  | — |  |  | (0.06) |  |  | (1.59) |  |
| Net earnings (loss) |  |  | 0.42 |  |  | (1.27) |  |  | 0.44 |  |  | 0.43 |  |  | 0.02 |  |
| Diluted earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings from continuing operations |  |  | 0.33 |  |  | 0.35 |  |  | 0.43 |  |  | 0.49 |  |  | 1.60 |  |
| Net (loss) earnings from discontinued operations |  |  | 0.09 |  |  | (1.61) |  |  | — |  |  | (0.06) |  |  | (1.58) |  |
| Net earnings (loss) |  |  | 0.42 |  |  | (1.26) |  |  | 0.43 |  |  | 0.43 |  |  | 0.02 |  |
| Dividends declared per common share |  | $ | 0.08 |  |  | 0.08 |  |  | 0.08 |  |  | 0.08 |  |  | 0.32 |  |
| 2013 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 110,518 |  |  | 118,039 |  |  | 116,922 |  |  | 144,600 |  |  | 490,079 |  |
| Net earnings from continuing operations |  |  | 5,343 |  |  | 5,523 |  |  | 6,514 |  |  | 13,880 |  |  | 31,260 |  |
| Net (loss) earnings from discontinued operations |  |  | (5,097) |  |  | (3,964) |  |  | (1,617) |  |  | (46,185) |  |  | (56,863) |  |
| Net (loss) earnings |  |  | 246 |  |  | 1,559 |  |  | 4,897 |  |  | (32,305) |  |  | (25,603) |  |
| Basic earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings from continuing operations |  |  | 0.20 |  |  | 0.21 |  |  | 0.25 |  |  | 0.52 |  |  | 1.18 |  |
| Net (loss) earnings from discontinued operations |  |  | (0.19) |  |  | (0.15) |  |  | (0.06) |  |  | (1.75) |  |  | (2.15) |  |
| Net (loss) earnings |  |  | 0.01 |  |  | 0.06 |  |  | 0.19 |  |  | (1.23) |  |  | (0.97) |  |
| Diluted earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings from continuing operations |  |  | 0.20 |  |  | 0.21 |  |  | 0.24 |  |  | 0.52 |  |  | 1.17 |  |
| Net (loss) earnings from discontinued operations |  |  | (0.19) |  |  | (0.15) |  |  | (0.06) |  |  | (1.73) |  |  | (2.13) |  |
| Net (loss) earnings |  |  | 0.01 |  |  | 0.06 |  |  | 0.18 |  |  | (1.21) |  |  | (0.96) |  |
| Dividends declared per common share |  | $ | 0.08 |  |  | 0.08 |  |  | 0.08 |  |  | 0.08 |  |  | 0.32 |  |

[0001144204-14-071151:notes:150]
See Notes 2 and 3 for discussion of divestiture and acquisition activity. Beginning in the third quarter of 2013, Aclara was classified as discontinued operations and assets/liabilities held for sale. Prior period amounts have been reclassified to conform to the current period presentation.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001144204-14-071151:notes:151]
|  | 5. | Accounts Receivable |

[0001144204-14-071151:notes:152]
Accounts receivable, net of the allowance for doubtful accounts, consist of the following at September 30, 2014 and 2013:

[0001144204-14-071151:notes:153]
| (Dollars in thousands) |  | 2014 |  | 2013 |  |
| Commercial |  | $ | 101,153 |  |  | 88,938 |  |
| U.S. Government and prime contractors |  |  | 4,296 |  |  | 3,042 |  |
| Total |  | $ | 105,449 |  |  | 91,980 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001144204-14-071151:notes:154]
|  | 3. | Acquisitions |

[0001144204-14-071151:notes:155]
2013

[0001144204-14-071151:notes:156]
On June 26, 2013, the Company acquired the stock of Canyon Engineering Products, Inc. (Canyon) for $9.2 million in cash, and additionally, purchased Canyon’s  70,000 square foot manufacturing facility located in Valencia, California, for $7 million. Canyon designs and manufactures precision fluid control devices primarily for the aerospace industry and Canyon’s products, technology and customers are very similar to Crissair, Inc. The operating results for Canyon, since the date of acquisition, are included as part of Crissair, Inc. within ESCO’s Filtration segment. The Company recorded approximately $1.3 million of goodwill related to the transaction and $1.7 million of amortizable identifiable intangible assets consisting primarily of customer relationships.

[0001144204-14-071151:notes:157]
On December 21, 2012, the Company acquired the assets of Felix Tool & Engineering, Inc. (Felix Tool) for a purchase price of $1.2 million in cash. Felix Tool is engaged in the design, manufacture and sale of customized perforated tubes for filtration applications in the aerospace and fluid power industry. The purchase price was allocated to property, plant and equipment and inventory based on fair market value at the date of acquisition and there were no intangible assets recorded upon the transaction. The operating results for the business, since the date of acquisition, are included within PTI Technologies Inc. in the Filtration segment.

[0001144204-14-071151:notes:158]
On December 10, 2012, the Company acquired the assets of Finepoint Marketing, Inc. (Finepoint) for a purchase price of $2.5 million. Finepoint is the electric power industry’s leading conference provider focused on medium and high voltage circuit breakers, as well as related substation and switchgear topics. The operating results for the business, since the date of acquisition, are included as a part of Doble in the USG segment. The Company recorded approximately $1.3 million of goodwill as a result of the transaction and $1.2 million of amortizable identifiable intangible assets consisting of customer relationships.

[0001144204-14-071151:notes:159]
All of the Company’s acquisitions have been accounted for using the purchase method of accounting and accordingly, the respective purchase prices were allocated to the assets (including intangible assets) acquired and liabilities assumed based on estimated fair values at the date of acquisition. The financial results from these acquisitions have been included in the Company’s financial statements from the date of acquisition. Pro forma financial information related to the Company’s acquisitions was not presented as it was not significant to the Company’s results of operations. None of the goodwill recorded as part of the acquisitions mentioned above is expected to be deductible for U.S. Federal or state income tax purposes.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001144204-14-071151:notes:160]
|  | 14. | Other Financial Data |

[0001144204-14-071151:notes:161]
Items charged to continuing operations during the years ended September 30, 2014, 2013 and 2012 included the following:

[0001144204-14-071151:notes:162]
| (Dollars in thousands) |  |  | 2014 |  | 2013 |  | 2012 |  |
| Salaries and wages (including fringes) |  | $ | 158,333 |  | 151,805 |  | 138,192 |  |
| Maintenance and repairs |  |  | 4,638 |  | 4,368 |  | 4,248 |  |
| Research and development (R&D) costs: |  |  |  |  |  |  |  |  |
| Company-sponsored |  |  | 16,880 |  | 12,704 |  | 14,293 |  |
| Customer-sponsored |  |  | 11,586 |  | 15,014 |  | 9,171 |  |
| Total R&D |  |  | 28,466 |  | 27,718 |  | 23,464 |  |
| Other engineering costs |  |  | 12,484 |  | 7,715 |  | 12,217 |  |
| Total R&D and other engineering costs |  | $ | 40,950 |  | 35,433 |  | 35,681 |  |
| As a % of net sales |  |  | 7.7 | % | 7.2 | % | 7.5 | % |

[0001144204-14-071151:notes:163]
A reconciliation of the changes in accrued product warranty liability for the years ended September 30, 2014, 2013 and 2012 is as follows:

[0001144204-14-071151:notes:164]
| (Dollars in thousands) |  | 2014 |  | 2013 |  | 2012 |  |
| Balance as of October 1, |  | $ | 1,880 |  | 1,536 |  | 2,120 |  |
| Additions charged to expense |  |  | 239 |  | 1,048 |  | 197 |  |
| Deductions |  |  | (639) |  | (704) |  | (781) |  |
| Balance as of September 30, |  | $ | 1,480 |  | 1,880 |  | 1,536 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001144204-14-071151:notes:165]
|  | 4. | Goodwill and Other Intangible Assets |

[0001144204-14-071151:notes:166]
Included on the Company’s Consolidated Balance Sheets at September 30, 2014 and 2013 are the following intangible assets gross carrying amounts and accumulated amortization:

[0001144204-14-071151:notes:167]
| (Dollars in millions) |  | 2014 |  | 2013 |  |
| Goodwill |  | $ | 282.3 |  |  | 282.9 |  |
| Intangible assets with determinable lives: |  |  |  |  |  |  |  |
| Patents |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 1.0 |  |  | 0.9 |  |
| Less: accumulated amortization |  |  | 0.8 |  |  | 0.6 |  |
| Net |  | $ | 0.2 |  |  | 0.3 |  |
| Capitalized software |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 37.4 |  |  | 28.7 |  |
| Less: accumulated amortization |  |  | 15.2 |  |  | 11.9 |  |
| Net |  | $ | 22.2 |  |  | 16.8 |  |
| Customer Relationships |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 64.1 |  |  | 64.1 |  |
| Less: accumulated amortization |  |  | 21.2 |  |  | 17.9 |  |
| Net |  | $ | 42.9 |  |  | 46.2 |  |
| Other |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 0.4 |  |  | 0.4 |  |
| Less: accumulated amortization |  |  | 0.2 |  |  | 0.2 |  |
| Net |  | $ | 0.2 |  |  | 0.2 |  |
| Intangible assets with indefinite lives: |  |  |  |  |  |  |  |
| Trade names |  | $ | 116.6 |  |  | 116.7 |  |

[0001144204-14-071151:notes:168]
The Company performed its annual evaluation of goodwill and intangible assets for impairment during the fourth quarter of fiscal 2014 and concluded no impairment existed at September 30, 2014.

[0001144204-14-071151:notes:169]
The changes in the carrying amount of goodwill attributable to each business segment for the years ended September 30, 2014 and 2013 are as follows:

[0001144204-14-071151:notes:170]
| (Dollars in millions) |  | USG |  |  | Test |  | Filtration |  | Total |  |
| Balance as of September 30, 2012 |  | $ | 215.6 |  |  | 34.7 |  |  | 29.3 |  |  | 279.6 |  |
| Acquisitions/adjustments |  |  | 1.7 |  |  | 0.3 |  |  | 1.3 |  |  | 3.3 |  |
| Balance as of September 30, 2013 |  |  | 217.3 |  |  | 35.0 |  |  | 30.6 |  |  | 282.9 |  |
| Adjustments |  |  | (0.5) |  |  | (0.3) |  |  | 0.2 |  |  | (0.6) |  |
| Balance as of September 30, 2014 |  | $ | 216.8 |  |  | 34.7 |  |  | 30.8 |  |  | 282.3 |  |

[0001144204-14-071151:notes:171]
Amortization expense related to intangible assets with determinable lives was $6.7 million, $6.2 million and $5.7 million in 2014, 2013 and 2012, respectively. Patents are amortized over the life of the patents, generally 17 years. Capitalized software is amortized over the estimated useful life of the software, generally three to seven years. Customer relationships are generally amortized over twenty years. Intangible asset amortization for fiscal years 2015 through 2019 is estimated at approximately $6.7 million per year.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001144204-14-071151:notes:172]
|  | 10. | Capital Stock |

[0001144204-14-071151:notes:173]
The  30,247,512 and  30,147,504 common shares as presented in the accompanying Consolidated Balance Sheets at September 30, 2014 and 2013 represent the actual number of shares issued at the respective dates. The Company held  4,040,532 and  3,707,407 common shares in treasury at September 30, 2014 and 2013, respectively.

[0001144204-14-071151:notes:174]
In August 2012, the Company’s Board of Directors authorized a common stock repurchase program under which the Company may repurchase shares of its stock from time to time in its discretion, in the open market or otherwise, up to a maximum total repurchase amount of $100 million (or such lesser amount as may be permitted under the Company’s bank credit agreements). This program has been twice extended by the Company’s Board of Directors and is currently scheduled to expire September 30, 2015. The Company repurchased approximately  350,000 shares for $12.0 million in 2014;  270,000 shares for $9.7 million in 2013; and  150,000 shares for $5.4 million in 2012.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001144204-14-071151:notes:175]
|  | 12. | Retirement and Other Benefit Plans |

[0001144204-14-071151:notes:176]
Substantially all domestic employees were covered by a defined contribution pension plan maintained by the Company. Effective December 31, 2003, the Company’s defined benefit plan was frozen and no additional benefits have been accrued after that date. As a result, the accumulated benefit obligation and projected benefit obligation are equal. These frozen retirement income benefits are provided to employees under defined benefit pay-related and flat-dollar plans, which are noncontributory. In conjunction with the acquisition of Doble, the Company assumed responsibility for its defined benefit plan and has frozen the plan effective December 31, 2008, and no additional benefits have been accrued after that date. Effective October 1, 2009, the Company’s defined benefit plan and Doble’s benefit plan were merged into one plan. The annual contributions to the defined benefit retirement plans equal or exceed the minimum funding requirements of the Employee Retirement Income Security Act. In addition to providing retirement income benefits, the Company provides unfunded postretirement health and life insurance benefits to certain retirees. To qualify, an employee must retire at age 55 or later and the employee’s age plus service must equal or exceed 75. Retiree contributions are defined as a percentage of medical premiums. Consequently, retiree contributions increase with increases in the medical premiums. The life insurance plans are noncontributory and provide coverage of a flat dollar amount for qualifying retired employees. Effective December 31, 2004, no new retirees were eligible for life insurance benefits.

[0001144204-14-071151:notes:177]
The Company uses a measurement date of September 30 for its pension and other postretirement benefit plans. The Company has an accrued benefit liability of $0.9 million and $0.7 million at September 30, 2014 and 2013, respectively, related to its other postretirement benefit obligations. All other information related to its postretirement benefit plans is not considered material to the Company’s results of operations or financial condition.

[0001144204-14-071151:notes:178]
The following tables provide a reconciliation of the changes in the pension plans and fair value of assets over the two-year period ended September 30, 2014, and a statement of the funded status as of September 30, 2014 and 2013:

[0001144204-14-071151:notes:179]
| (Dollars in millions) |  |  |  |  |  |  |
| Reconciliation of benefit obligation |  | 2014 |  | 2013 |  |
| Net benefit obligation at beginning of year |  | $ | 87.2 |  |  | 97.1 |  |
| Service cost |  |  | — |  |  | 0.1 |  |
| Interest cost |  |  | 4.0 |  |  | 3.6 |  |
| Actuarial (gain) loss |  |  | 5.1 |  |  | (9.7) |  |
| Settlements |  |  | — |  |  | (0.3) |  |
| Gross benefits paid |  |  | (3.8) |  |  | (3.6) |  |
| Net benefit obligation at end of year |  | $ | 92.5 |  |  | 87.2 |  |

[0001144204-14-071151:notes:180]
| (Dollars in millions) |  |  |  |  |  |  |
| Reconciliation of fair value of plan assets |  | 2014 |  | 2013 |  |
| Fair value of plan assets at beginning of year |  | $ | 67.9 |  |  | 61.1 |  |
| Actual return on plan assets |  |  | 5.9 |  |  | 6.2 |  |
| Employer contributions |  |  | 3.0 |  |  | 4.5 |  |
| Gross benefits paid |  |  | (3.8) |  |  | (3.9) |  |
| Fair value of plan assets at end of year |  | $ | 73.0 |  |  | 67.9 |  |

[0001144204-14-071151:notes:181]
| (Dollars in millions) |  |  |  |  |  |  |
| Funded Status |  | 2014 |  | 2013 |  |
| Funded status at end of year |  | $ | (19.5) |  |  | (19.3) |  |
| Unrecognized prior service cost |  |  | — |  |  | — |  |
| Unrecognized net actuarial (gain) loss |  |  | — |  |  | — |  |
| Accrued benefit cost |  |  | (19.5) |  |  | (19.3) |  |
| Amounts recognized in the Balance Sheet consist of: |  |  |  |  |  |  |  |
| Noncurrent asset |  |  | — |  |  | — |  |
| Current liability |  |  | (0.3) |  |  | (0.3) |  |
| Noncurrent liability |  |  | (19.2) |  |  | (19.0) |  |
| Accumulated other comprehensive (income)/loss (before tax effect) |  |  | 36.7 |  |  | 34.8 |  |
| Amounts recognized in Accumulated Other Comprehensive (Income)/Loss consist of: |  |  |  |  |  |  |  |
| Net actuarial loss |  |  | 36.7 |  |  | 34.8 |  |
| Prior service cost |  |  | — |  |  | — |  |
| Accumulated Other Comprehensive (Income)/Loss (before tax effect) |  | $ | 36.7 |  |  | 34.8 |  |

[0001144204-14-071151:notes:182]
The following table provides the components of net periodic benefit cost for the plans for the years ended September 30, 2014, 2013 and 2012:

[0001144204-14-071151:notes:183]
| (Dollars in millions) |  | 2014 |  | 2013 |  | 2012 |  |
| Service cost |  | $ | — |  |  | 0.1 |  |  | 0.1 |  |
| Interest cost |  |  | 4.0 |  |  | 3.6 |  |  | 3.8 |  |
| Expected return on plan assets |  |  | (4.4) |  |  | (4.4) |  |  | (4.1) |  |
| Net actuarial loss |  |  | 1.6 |  |  | 2.1 |  |  | 1.5 |  |
| Settlement gain |  |  | — |  |  | (0.1) |  |  | — |  |
| Net periodic benefit cost |  |  | 1.2 |  |  | 1.3 |  |  | 1.3 |  |
| Defined contribution plans |  |  | 3.3 |  |  | 4.6 |  |  | 4.5 |  |
| Total |  | $ | 4.5 |  |  | 5.9 |  |  | 5.8 |  |

[0001144204-14-071151:notes:184]
The discount rate used in measuring the Company’s pension obligations was developed by matching yields of actual high-quality corporate bonds to expected future pension plan cash flows (benefit payments). Over 400 Aa-rated, non-callable bonds with a wide range of maturities were used in the analysis. After using the bond yields to determine the present value of the plan cash flows, a single representative rate that resulted in the same present value was developed. The expected long-term rate of return on plan assets assumption was determined by reviewing the actual investment return of the plans since inception and evaluating those returns in relation to expectations of various investment organizations to determine whether long-term future returns are expected to differ significantly from the past.

[0001144204-14-071151:notes:185]
The following weighted-average assumptions were used to determine the net periodic benefit cost for the pension plans:

[0001144204-14-071151:notes:186]
|  |  | 2014 |  | 2013 |  | 2012 |  |
| Discount rate |  |  | 4.75 | % |  | 3.75 | % |  | 4.50 | % |
| Rate of increase in compensation levels |  |  | N/A |  |  | N/A |  |  | N/A |  |
| Expected long-term rate of return on assets |  |  | 7.00 | % |  | 7.50 | % |  | 7.50 | % |

[0001144204-14-071151:notes:187]
The following weighted-average assumptions were used to determine the net periodic benefit obligations for the pension plans:

[0001144204-14-071151:notes:188]
|  |  | 2014 |  | 2013 |  |
| Discount rate |  |  | 4.25 | % |  | 4.75 | % |
| Rate of increase in compensation levels |  |  | N/A |  |  | N/A |  |

[0001144204-14-071151:notes:189]
The assumed rate of increase in compensation levels is not applicable in 2014, 2013 and 2012 as the plan was frozen in earlier years.

[0001144204-14-071151:notes:190]
The asset allocation for the Company’s pension plans at the end of 2014 and 2013, the Company’s acceptable range and the target allocation for 2015, by asset category, follows:

[0001144204-14-071151:notes:191]
|  |  |  |  |  |  | Percentage of Plan Assets |  |
|  |  |  |  |  |  | at Year-end |  |
|  |  | Target |  |  |  |  |  |  |  |  |  |  |
|  |  | Allocation |  | Acceptable |  |  |  |  |  |  |  |
| Asset Category |  | 2015 |  | Range |  | 2014 |  | 2013 |  |
| Equity securities |  |  | 38 | % |  | 34-42 | % |  | 35 | % |  | 34 | % |
| Fixed income |  |  | 62 | % |  | 58-66 | % |  | 64 | % |  | 65 | % |
| Cash/cash equivalents |  |  | 0 | % |  | 0-5 | % |  | 1 | % |  | 1 | % |

[0001144204-14-071151:notes:192]
The Company’s pension plan assets are managed by outside investment managers and assets are rebalanced when the target ranges are exceeded. Pension plan assets consist principally of funds which invest in marketable securities including common stocks, bonds, and interest-bearing deposits. The Company’s investment strategy with respect to pension assets is to achieve a total rate of return (income and capital appreciation) that is sufficient to accomplish the purpose of providing retirement benefits to all eligible and future retirees of the pension plan. The Company regularly monitors performance and compliance with investment guidelines.

[0001144204-14-071151:notes:193]
Fair Value of Financial Measurements

[0001144204-14-071151:notes:194]
Assets and liabilities recorded at fair value in the consolidated balance sheets are categorized based upon the level of judgment associated with the inputs used to measure their fair value. Hierarchical levels are directly related to the amount of subjectivity associated with the inputs to fair valuation of these assets and liabilities. The Company is required to separately disclose assets and liabilities measured at fair value on a recurring basis, from those measured at fair value on a nonrecurring basis.

[0001144204-14-071151:notes:195]
The fair values of the Company’s defined benefit plan investments as of September 30, 2014, by asset category, were as follows:

[0001144204-14-071151:notes:196]
| (Dollars in millions) |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  |
| Investments at fair value: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 0.8 |  |  | — |  |  | — |  |  | 0.8 |  |
| Common and preferred stock funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Domestic large capitalization |  |  | 5.8 |  |  | — |  |  | — |  |  | 5.8 |  |
| Domestic small/mid capitalization |  |  | 6.8 |  |  | — |  |  | — |  |  | 6.8 |  |
| International funds |  |  | 10.5 |  |  | — |  |  | — |  |  | 10.5 |  |
| Fixed income funds |  |  | 46.8 |  |  | — |  |  | — |  |  | 46.8 |  |
| Real estate investment funds |  |  | 2.3 |  |  | — |  |  | — |  |  | 2.3 |  |
| Total investments at fair value |  | $ | 73.0 |  |  | — |  |  | — |  |  | 73.0 |  |

[0001144204-14-071151:notes:197]
The fair values of the Company’s defined benefit plan investments as of September 30, 2013, by asset category, were as follows:

[0001144204-14-071151:notes:198]
| (Dollars in millions) |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  |
| Investments at fair value: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 0.9 |  |  | — |  |  | — |  |  | 0.9 |  |
| Common and preferred stock funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Domestic large capitalization |  |  | 4.8 |  |  | — |  |  | — |  |  | 4.8 |  |
| Domestic small/mid capitalization |  |  | 6.5 |  |  | — |  |  | — |  |  | 6.5 |  |
| International funds |  |  | 9.7 |  |  | — |  |  | — |  |  | 9.7 |  |
| Fixed income funds |  |  | 43.8 |  |  | — |  |  | — |  |  | 43.8 |  |
| Real estate investment funds |  |  | 2.2 |  |  | — |  |  | — |  |  | 2.2 |  |
| Total investments at fair value |  | $ | 67.9 |  |  | — |  |  | — |  |  | 67.9 |  |

[0001144204-14-071151:notes:199]
The following methods were used to estimate the fair value of each class of financial instrument:

[0001144204-14-071151:notes:200]
Cash and cash equivalents: The carrying value of cash represents fair value as it consists of actual currency.

[0001144204-14-071151:notes:201]
Investment funds: The fair value of the investment funds, which are classified as Level 1, is determined based on the published net asset value of the funds.

[0001144204-14-071151:notes:202]
There were no defined benefit plan investments classified as Level 2 or Level 3 during 2014 or 2013.

[0001144204-14-071151:notes:203]
Expected Cash Flows

[0001144204-14-071151:notes:204]
Information about the expected cash flows for the pension and other postretirement benefit plans follows:

[0001144204-14-071151:notes:205]
|  |  | Pension | Other |  |
| (Dollars in millions) |  | Benefits | Benefits |  |
| Expected Employer Contributions — 2015 |  | $ | 0.9 |  |  | 0.1 |  |
| Expected Benefit Payments: |  |  |  |  |  |  |  |
| 2015 |  |  | 4.4 |  |  | 0.1 |  |
| 2016 |  |  | 4.9 |  |  | 0.1 |  |
| 2017 |  |  | 4.9 |  |  | 0.1 |  |
| 2018 |  |  | 5.0 |  |  | 0.1 |  |
| 2019 |  |  | 5.2 |  |  | 0.1 |  |
| 2020-2024 |  | $ | 29.0 |  |  | 0.4 |  |


## us-gaap:ScheduleOfExpectedBenefitPaymentsTableTextBlock

[0001144204-14-071151:notes:206]
|  |  | Pension |  | Other |  |
| (Dollars in millions) |  | Benefits |  | Benefits |  |
| Expected Employer Contributions — 2015 |  | $ | 0.9 |  |  | 0.1 |  |
| Expected Benefit Payments: |  |  |  |  |  |  |  |
| 2015 |  |  | 4.4 |  |  | 0.1 |  |
| 2016 |  |  | 4.9 |  |  | 0.1 |  |
| 2017 |  |  | 4.9 |  |  | 0.1 |  |
| 2018 |  |  | 5.0 |  |  | 0,1 |  |
| 2019 |  |  | 5.2 |  |  | 0.1 |  |
| 2020-2024 |  | $ | 29.0 |  |  | 0.4 |  |
