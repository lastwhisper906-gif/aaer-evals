# ESE notes — 0001410578-22-002168


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001410578-22-002168:notes:1]
[same as prior period, unchanged from 0001410578-22-001243:notes:1]

[0001410578-22-002168:notes:2]
The accompanying consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for consolidated annual financial statements by accounting principles generally accepted in the United States of America (GAAP).

[0001410578-22-002168:notes:3]
The Company’s results for the three-month and nine-month periods ended June 30, 2022 are not necessarily indicative of the results for the entire 2022 fiscal year. References to the third quarters of 2022 and 2021 represent the fiscal quarters ended June 30, 2022 and 2021, respectively. The preparation of consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates. Certain prior period deferred revenue amounts have been reclassified to noncurrent to conform with the current year presentation.


## us-gaap:EarningsPerShareTextBlock

[0001410578-22-002168:notes:4]
[same as prior period, unchanged from 0001410578-22-001243:notes:4]

[0001410578-22-002168:notes:5]
[same as prior period, unchanged from 0001410578-22-001243:notes:5]

[0001410578-22-002168:notes:6]
| ​ |  | Three Months |  | Nine Months |
| ​ | ​ | Ended June 30, | ​ | Ended June 30, |
| ​ |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Weighted Average Shares Outstanding — Basic |  | 25,856 |  | 26,045 | ​ | 25,959 | ​ | 26,040 |
| Dilutive Restricted Shares | ​ | 94 | ​ | 169 | ​ | 91 | ​ | 159 |
| Weighted Average Shares Outstanding — Diluted |  | 25,950 |  | 26,214 | ​ | 26,050 | ​ | 26,199 |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001410578-22-002168:notes:7]
[same as prior period, unchanged from 0001410578-22-001243:notes:7]

[0001410578-22-002168:notes:8]
On November 4, 2021, the Company acquired Networks Electronic Company, LLC (NEco) for a purchase price of approximately $15.4 million, net of cash acquired. NEco, based in Chatsworth, California, provides miniature electro-explosive devices utilized in mission-critical defense and aerospace applications. Since the date of acquisition, the operating results for the NEco business have been included as part of PTI in the A&D segment. The acquisition date fair value of the assets acquired and liabilities assumed primarily were as follows: approximately $0.6 million of accounts receivable, $1.5 million of inventory, $0.2 million of property, plant and equipment, $0.7 million of accounts payable and accrued expenses, $8.1 million of identifiable intangible assets, mainly consisting of customer relationships totaling $6.3 million. The acquired goodwill of $5.7 million related to excess value associated with opportunities to expand the services and products that the Company can offer to its customers. The Company anticipates that the goodwill will be deductible for tax purposes.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001410578-22-002168:notes:9]
[same as prior period, unchanged from 0001410578-22-001243:notes:9]

[0001410578-22-002168:notes:10]
[same as prior period, unchanged from 0001410578-22-001243:notes:10]

[0001410578-22-002168:notes:11]
[same as prior period, unchanged from 0001410578-22-001243:notes:11]

[0001410578-22-002168:notes:12]
Compensation expense related to the PARS/RSU awards was $1.6 million and $4.4 million for the three and nine-month periods ended June 30, 2022, respectively, and $2.5 million and $4.5 million for the corresponding periods in 2021. As of June 30, 2022, there were 265,643 unvested stock units outstanding.

[0001410578-22-002168:notes:13]
[same as prior period, unchanged from 0001410578-22-001243:notes:13]

[0001410578-22-002168:notes:14]
Compensation expense related to the non-employee director grants was $0.3 million and $0.9 million for the three and nine-month periods ended June 30, 2022, respectively, and $0.3 million and $1.0 million for the corresponding periods in 2021.

[0001410578-22-002168:notes:15]
The total share-based compensation cost that has been recognized in the results of operations and included within selling, general and administrative expenses (SG&A) was $1.9 million and $5.3 million for the three and nine-month periods ended June 30, 2022, respectively, and $2.8 million and $5.5 million for the corresponding periods in 2021. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $0.4 million and $1.0 million for the three and nine-month periods ended June 30, 2022, respectively, and $0.4 million and $1.1 million for the corresponding periods in 2021. As of June 30, 2022, there was $12.9 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a remaining weighted-average period of 1.9 years.


## us-gaap:InventoryDisclosureTextBlock

[0001410578-22-002168:notes:16]
[same as prior period, unchanged from 0001410578-22-001243:notes:16]

[0001410578-22-002168:notes:17]
[same as prior period, unchanged from 0001410578-22-001243:notes:17]

[0001410578-22-002168:notes:18]
| ​ | ​ | June 30, | ​ | September 30, |
| (In thousands) |  | 2022 |  | 2021 |
| Finished goods | ​ | $ | 39,904 |  | 32,998 |
| Work in process | ​ |  | 43,408 |  | 34,201 |
| Raw materials | ​ |  | 94,856 |  | 79,949 |
| Total inventories, net | ​ | $ | 178,168 |  | 147,148 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001410578-22-002168:notes:19]
[same as prior period, unchanged from 0001410578-22-001243:notes:19]

[0001410578-22-002168:notes:20]
Included on the Company’s Consolidated Balance Sheets at June 30, 2022 and September 30, 2021 are the following intangible assets gross carrying amounts and accumulated amortization:

[0001410578-22-002168:notes:21]
| ​ |  | June 30, |  | September 30, |
| (Dollars in thousands) |  | 2022 |  | 2021 |
| Goodwill | ​ | $ | 503,439 |  | 504,853 |
| Intangible assets with determinable lives: | ​ |  | ​ | ​ | ​ |
| Patents | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 2,246 | ​ | 2,131 |
| Less: accumulated amortization | ​ |  | 1,059 | ​ | 972 |
| Net | ​ | $ | 1,187 | ​ | 1,159 |
| Capitalized software | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 103,030 | ​ | 93,671 |
| Less: accumulated amortization | ​ |  | 68,643 | ​ | 63,740 |
| Net | ​ | $ | 34,387 | ​ | 29,931 |
| Customer relationships | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 290,133 | ​ | 288,530 |
| Less: accumulated amortization | ​ |  | 92,943 | ​ | 80,882 |
| Net | ​ | $ | 197,190 | ​ | 207,648 |
| Other | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 13,885 | ​ | 13,080 |
| Less: accumulated amortization | ​ |  | 6,629 | ​ | 4,301 |
| Net | ​ | $ | 7,256 | ​ | 8,779 |
| Intangible assets with indefinite lives: | ​ |  | ​ | ​ | ​ |
| Trade names | ​ | $ | 161,317 | ​ | 161,733 |

[0001410578-22-002168:notes:22]
The changes in the carrying amount of goodwill attributable to each business segment for the nine months ended June 30, 2022 is as follows:

[0001410578-22-002168:notes:23]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | Aerospace | ​ | ​ |
| (Dollars in millions) |  | USG |  | Test |  | & Defense |  | Total |
| Balance as of September 30, 2021 | ​ | ​ | 366.5 |  | ​ | 34.1 |  | 104.3 |  | 504.9 |
| Acquisition activity and adjustments | ​ | ​ | — | ​ | ​ | — | ​ | 5.7 | ​ | 5.7 |
| Foreign currency translation | ​ | ​ | (7.2) | ​ | ​ | — | ​ | — | ​ | (7.2) |
| Balance as of June 30, 2022 | ​ | $ | 359.3 | ​ | ​ | 34.1 | ​ | 110.0 | ​ | 503.4 |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001410578-22-002168:notes:24]
[same as prior period, unchanged from 0001410578-22-001243:notes:24]

[0001410578-22-002168:notes:25]
[same as prior period, unchanged from 0001410578-22-001243:notes:25]

[0001410578-22-002168:notes:26]
[same as prior period, unchanged from 0001410578-22-001243:notes:26]

[0001410578-22-002168:notes:27]
[same as prior period, unchanged from 0001410578-22-001243:notes:27]

[0001410578-22-002168:notes:28]
[same as prior period, unchanged from 0001410578-22-001243:notes:28]

[0001410578-22-002168:notes:29]
[same as prior period, unchanged from 0001410578-22-001243:notes:29]

[0001410578-22-002168:notes:30]
| ​ | ​ | Three Months | ​ | Nine Months |
| ​ | ​ | Ended June 30, | ​ | Ended June 30, |
| (In thousands) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| NET SALES | ​ | ​ |  | ​ |  | ​ |  | ​ |  |
| Aerospace & Defense | ​ | $ | 92,606 | ​ | 85,576 | ​ | 247,671 | ​ | 234,720 |
| USG | ​ | ​ | 67,201 | ​ | 47,704 | ​ | 194,877 | ​ | 141,799 |
| Test | ​ | ​ | 59,259 | ​ | 48,114 | ​ | 158,456 | ​ | 133,443 |
| Consolidated totals | ​ | $ | 219,066 | ​ | 181,394 | ​ | 601,004 | ​ | 509,962 |
| EBIT | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Aerospace & Defense | ​ | $ | 20,738 | ​ | 16,714 | ​ | 45,042 | ​ | 41,980 |
| USG | ​ | ​ | 13,135 | ​ | 8,227 | ​ | 37,840 | ​ | 27,683 |
| Test | ​ | ​ | 8,354 | ​ | 6,751 | ​ | 20,813 | ​ | 17,781 |
| Corporate (loss) | ​ | ​ | (11,394) | ​ | (12,269) | ​ | (34,604) | ​ | (30,359) |
| Consolidated EBIT | ​ | ​ | 30,833 | ​ | 19,423 | ​ | 69,091 | ​ | 57,085 |
| Less: Interest expense | ​ | ​ | (1,331) | ​ | (480) | ​ | (3,084) | ​ | (1,453) |
| Earnings before income taxes | ​ | $ | 29,502 | ​ | 18,943 | ​ | 66,007 | ​ | 55,632 |

[0001410578-22-002168:notes:31]
[same as prior period, unchanged from 0001410578-22-001243:notes:31]

[0001410578-22-002168:notes:32]
[same as prior period, unchanged from 0001410578-22-001243:notes:32]

[0001410578-22-002168:notes:33]
[same as prior period, unchanged from 0001410578-22-001243:notes:33]


## us-gaap:DebtDisclosureTextBlock

[0001410578-22-002168:notes:34]
8.    DEBT

[0001410578-22-002168:notes:35]
The Company’s debt is summarized as follows:

[0001410578-22-002168:notes:36]
| ​ |  | June 30, | ​ | September 30, |
| (In thousands) |  | 2022 |  | 2021 |
| Total borrowings | ​ | $ | 201,000 |  | 154,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 181,000 |  | 134,000 |

[0001410578-22-002168:notes:37]
The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024.

[0001410578-22-002168:notes:38]
At June 30, 2022, the Company had approximately $291.0 million available to borrow under the Credit Facility, plus the $250 million increase option, subject to lender approval, in addition to $61.0 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of June 30, 2022, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $7.8 million at June 30, 2022.

[0001410578-22-002168:notes:39]
Interest on borrowings under the Credit Facility is calculated at a spread over either the New York Federal Reserve Bank Rate, the prime rate or the London Interbank Offered Rate (LIBOR), depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The Credit Facility is secured by the unlimited guaranty of the Company’s direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of its direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 2.20% and 1.57% for the three and nine-month periods ending June 30, 2022, respectively, and 1.16% and 1.33% for the three and nine-month periods ending June 30, 2021. As of June 30, 2022, the Company was in compliance with all covenants.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001410578-22-002168:notes:40]
[same as prior period, unchanged from 0001410578-22-001243:notes:40]

[0001410578-22-002168:notes:41]
The third quarter 2022 effective income tax rate was 21.5% compared to 21.3% in the third quarter of 2021. The effective income tax rate in the first nine months of 2022 was 22.3% compared to 22.5% for the first nine months of 2021. The income tax expense in the third quarter and first nine months of 2022 was favorably impacted by tax return to provision true-ups on U.S. tax on the distribution of foreign earnings and the re-rating of deferred taxes as a result of a Vermont law change, decreasing the third quarter and year-to-date effective tax rate by 1.6% and 0.7%, respectively. The income tax expense in the third quarter and first nine months of 2021 was favorably impacted by a tax return to provision true-up for foreign derived intangible income and other 2020 true-ups decreasing the third quarter and year-to-date effective tax rate by 3.9% and 1.2% respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001410578-22-002168:notes:42]
[same as prior period, unchanged from 0001410578-22-001243:notes:42]

[0001410578-22-002168:notes:43]
The change in shareholders’ equity for the third quarter and first nine months of 2022 and 2021 is shown below (in thousands):

[0001410578-22-002168:notes:44]
| ​ | ​ | Three Months Ended June 30, | ​ | Nine Months Ended June 30, |
| ​ |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Common stock | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 307 | ​ | 306 | ​ | 307 | ​ | 306 |
| Stock plans | ​ | — | ​ | 1 | ​ | — | ​ | 1 |
| Ending balance | ​ | 307 | ​ | 307 | ​ | 307 | ​ | 307 |
| Additional paid-in-capital | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 298,353 | ​ | 295,796 | ​ | 297,644 | ​ | 293,682 |
| Stock plans | ​ | 1,510 | ​ | 782 | ​ | 2,219 | ​ | 2,896 |
| Ending balance | ​ | 299,863 | ​ | 296,578 | ​ | 299,863 | ​ | 296,578 |
| Retained earnings | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 854,946 | ​ | 799,884 | ​ | 830,989 | ​ | 775,829 |
| Net earnings common stockholders | ​ | 23,173 | ​ | 14,909 | ​ | 51,280 | ​ | 43,131 |
| Dividends paid | ​ | (2,069) | ​ | (2,084) | ​ | (6,219) | ​ | (6,251) |
| Ending balance | ​ | 876,050 | ​ | 812,709 | ​ | 876,050 | ​ | 812,709 |
| Accumulated other comprehensive income (loss) | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | (7,472) | ​ | 1,808 | ​ | (2,161) | ​ | (3,657) |
| Foreign currency translation | ​ | (11,905) | ​ | 535 | ​ | (17,216) | ​ | 6,000 |
| Ending balance | ​ | (19,377) | ​ | 2,343 | ​ | (19,377) | ​ | 2,343 |
| Treasury stock | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | (124,961) | ​ | (107,134) | ​ | (107,083) | ​ | (107,134) |
| Issued under stock plans /(repurchased) | ​ | (2,000) | ​ | 51 | ​ | (19,878) | ​ | 51 |
| Ending balance | ​ | (126,961) | ​ | (107,083) | ​ | (126,961) | ​ | (107,083) |
| Total equity | ​ | 1,029,882 | ​ | 1,004,854 | ​ | 1,029,882 | ​ | 1,004,854 |


## us-gaap:FairValueDisclosuresTextBlock

[0001410578-22-002168:notes:45]
[same as prior period, unchanged from 0001410578-22-001243:notes:45]

[0001410578-22-002168:notes:46]
[same as prior period, unchanged from 0001410578-22-001243:notes:46]

[0001410578-22-002168:notes:47]
[same as prior period, unchanged from 0001410578-22-001243:notes:47]

[0001410578-22-002168:notes:48]
[same as prior period, unchanged from 0001410578-22-001243:notes:48]

[0001410578-22-002168:notes:49]
[same as prior period, unchanged from 0001410578-22-001243:notes:49]

[0001410578-22-002168:notes:50]
[same as prior period, unchanged from 0001410578-22-001243:notes:50]

[0001410578-22-002168:notes:51]
The Company has estimated the fair value of its financial instruments as of June 30, 2022 and September 30, 2021 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001410578-22-002168:notes:52]
[same as prior period, unchanged from 0001410578-22-001243:notes:52]

[0001410578-22-002168:notes:53]
[same as prior period, unchanged from 0001410578-22-001243:notes:53]

[0001410578-22-002168:notes:54]
[same as prior period, unchanged from 0001410578-22-001243:notes:54]

[0001410578-22-002168:notes:55]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during the three and nine-month periods ended June 30, 2022 and 2021.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001410578-22-002168:notes:56]
[same as prior period, unchanged from 0001410578-22-001243:notes:56]

[0001410578-22-002168:notes:57]
[same as prior period, unchanged from 0001410578-22-001243:notes:57]

[0001410578-22-002168:notes:58]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2022 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue within each reportable segment.

[0001410578-22-002168:notes:59]
| Three Months Ended June 30, 2022 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 38,918 | ​ | $ | 65,610 | ​ | $ | 54,449 | ​ | $ | 158,977 |
| U.S. Government | ​ |  | 53,688 | ​ |  | 1,591 | ​ |  | 4,810 | ​ |  | 60,089 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |
| ​ | ​ | ​ | ​ | ​ | ​ | 65 | ​ | ​ | ​ | ​ | ​ | ​ |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 79,536 | ​ | $ | 41,822 | ​ | $ | 34,662 | ​ | $ | 156,020 |
| International | ​ |  | 13,070 | ​ |  | 25,379 | ​ |  | 24,597 | ​ |  | 63,046 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 35,238 | ​ | $ | 53,656 | ​ | $ | 15,827 | ​ | $ | 104,721 |
| Over time | ​ |  | 57,368 | ​ |  | 13,545 | ​ |  | 43,432 | ​ |  | 114,345 |
| Total revenues | ​ | $ | 92,606 | ​ | $ | 67,201 | ​ | $ | 59,259 | ​ | $ | 219,066 |

[0001410578-22-002168:notes:60]
| Nine months ended June 30, 2022 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 100,407 | ​ | $ | 191,832 | ​ | $ | 147,390 | ​ | $ | 439,629 |
| U.S. Government | ​ |  | 147,264 | ​ |  | 3,045 | ​ |  | 11,066 | ​ |  | 161,375 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 212,849 | ​ | $ | 122,021 | ​ | $ | 88,708 | ​ | $ | 423,578 |
| International | ​ |  | 34,822 | ​ |  | 72,856 | ​ |  | 69,748 | ​ |  | 177,426 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 99,464 | ​ | $ | 155,693 | ​ | $ | 43,488 | ​ | $ | 298,645 |
| Over time | ​ |  | 148,207 | ​ |  | 39,184 | ​ |  | 114,968 | ​ |  | 302,359 |
| Total revenues | ​ | $ | 247,671 | ​ | $ | 194,877 | ​ | $ | 158,456 | ​ | $ | 601,004 |

[0001410578-22-002168:notes:61]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2021 are presented in the tables below.

[0001410578-22-002168:notes:62]
| Three months ended June 30, 2021 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial |  | $ | 34,708 |  | $ | 46,735 |  | $ | 42,063 |  | $ | 123,506 |
| U.S. Government | ​ | ​ | 50,868 | ​ | ​ | 969 | ​ | ​ | 6,051 | ​ | ​ | 57,888 |
| Total revenues |  | $ | 85,576 |  | $ | 47,704 |  | $ | 48,114 |  | $ | 181,394 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States |  | $ | 75,701 |  | $ | 32,111 |  | $ | 27,719 |  | $ | 135,531 |
| International | ​ | ​ | 9,875 | ​ | ​ | 15,593 | ​ | ​ | 20,395 | ​ | ​ | 45,863 |
| Total revenues |  | $ | 85,576 |  | $ | 47,704 |  | $ | 48,114 |  | $ | 181,394 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time |  | $ | 37,513 |  | $ | 35,242 |  | $ | 9,673 |  | $ | 82,428 |
| Over time | ​ | ​ | 48,063 | ​ | ​ | 12,462 | ​ | ​ | 38,441 | ​ | ​ | 98,966 |
| Total revenues |  | $ | 85,576 |  | $ | 47,704 |  | $ | 48,114 |  | $ | 181,394 |

[0001410578-22-002168:notes:63]
| Nine months ended June 30, 2021 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial |  | $ | 95,712 |  | $ | 139,149 |  | $ | 118,089 |  | $ | 352,950 |
| U.S. Government | ​ | ​ | 139,008 | ​ | ​ | 2,650 | ​ | ​ | 15,354 | ​ | ​ | 157,012 |
| Total revenues |  | $ | 234,720 |  | $ | 141,799 |  | $ | 133,443 |  | $ | 509,962 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States |  | $ | 205,527 |  | $ | 96,601 |  | $ | 73,950 |  | $ | 376,078 |
| International | ​ | ​ | 29,193 | ​ | ​ | 45,198 | ​ | ​ | 59,493 | ​ | ​ | 133,884 |
| Total revenues |  | $ | 234,720 |  | $ | 141,799 |  | $ | 133,443 |  | $ | 509,962 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time |  | $ | 103,492 |  | $ | 105,173 |  | $ | 27,789 |  | $ | 236,454 |
| Over time | ​ | ​ | 131,228 | ​ | ​ | 36,626 | ​ | ​ | 105,654 | ​ | ​ | 273,508 |
| Total revenues |  | $ | 234,720 |  | $ | 141,799 |  | $ | 133,443 |  | $ | 509,962 |

[0001410578-22-002168:notes:64]
[same as prior period, unchanged from 0001410578-22-001243:notes:64]

[0001410578-22-002168:notes:65]
[same as prior period, unchanged from 0001410578-22-001243:notes:65]

[0001410578-22-002168:notes:66]
[same as prior period, unchanged from 0001410578-22-001243:notes:66]

[0001410578-22-002168:notes:67]
[same as prior period, unchanged from 0001410578-22-001243:notes:67]

[0001410578-22-002168:notes:68]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At June 30, 2022, the Company had $706.8 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 80% in the next twelve months.

[0001410578-22-002168:notes:69]
[same as prior period, unchanged from 0001410578-22-001243:notes:69]

[0001410578-22-002168:notes:70]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred. At June 30, 2022, contract assets and liabilities totaled $115.8 million and $122.2 million, respectively. During the first nine months of 2022, the Company recognized approximately $74 million in revenues that were included in the contract liabilities balance at September 30, 2021. The increase in net contract assets in the first nine months of 2022 was due to revenue being recognized for performance completed during the period that exceeded customer billings. The increase in net contract liabilities in the first nine months of 2022 was due to higher payments received in advance of revenue recognition criteria being met under the Company’s contracts with customers. At October 1, 2020, contract assets and liabilities totaled $94.3 million and $100.6 million, respectively.


## ese:OperatingAndFinancingLeasesOfLesseeDisclosureTextBlock

[0001410578-22-002168:notes:71]
[same as prior period, unchanged from 0001410578-22-001243:notes:72]

[0001410578-22-002168:notes:72]
[same as prior period, unchanged from 0001410578-22-001243:notes:73]

[0001410578-22-002168:notes:73]
[same as prior period, unchanged from 0001410578-22-001243:notes:74]

[0001410578-22-002168:notes:74]
[same as prior period, unchanged from 0001410578-22-001243:notes:75]

[0001410578-22-002168:notes:75]
[same as prior period, unchanged from 0001410578-22-001243:notes:76]

[0001410578-22-002168:notes:76]
[same as prior period, unchanged from 0001410578-22-001243:notes:77]

[0001410578-22-002168:notes:77]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended |
| ​ | ​ | June 30, | ​ | June 30, |
| (Dollars in thousands) |  | 2022 |  | 2021 |
| Finance lease cost | ​ | ​ |  | ​ | ​ |  |
| Amortization of right-of-use assets | ​ | $ | 393 | ​ | $ | 492 |
| Interest on lease liabilities | ​ |  | 242 | ​ |  | 306 |
| Operating lease cost | ​ |  | 2,104 | ​ |  | 1,471 |
| Total lease costs | ​ | $ | 2,739 | ​ | $ | 2,269 |

[0001410578-22-002168:notes:78]
| ​ |  | Nine Months |  | Nine Months |
| ​ | ​ | Ended | ​ | Ended |
| ​ | ​ | June 30, | ​ | June 30, |
| (Dollars in thousands) |  | 2022 |  | 2021 |
| Finance lease cost | ​ | ​ | ​ | ​ | ​ | ​ |
| Amortization of right-of-use assets |  | $ | 1,179 |  | $ | 1,477 |
| Interest on lease liabilities | ​ | ​ | 734 | ​ | ​ | 929 |
| Operating lease cost | ​ | ​ | 4,709 | ​ | ​ | 4,347 |
| Total lease costs |  | $ | 6,622 |  | $ | 6,753 |

[0001410578-22-002168:notes:79]
[same as prior period, unchanged from 0001410578-22-001243:notes:80]

[0001410578-22-002168:notes:80]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended |
| ​ | ​ | June 30, | ​ | June 30, |
| (Dollars in thousands) |  | 2022 |  | 2021 |
| Cash paid for amounts included in the measurement of lease liabilities | ​ | ​ |  | ​ | ​ |  |
| Operating cash flows from operating leases | ​ | $ | 1,989 | ​ | $ | 1,320 |
| Operating cash flows from finance leases | ​ |  | 242 | ​ |  | 306 |
| Financing cash flows from finance leases | ​ |  | 307 | ​ |  | 428 |
| Right-of-use assets obtained in exchange for operating lease liabilities | ​ | ​ | 760 | ​ | ​ | 12,780 |

[0001410578-22-002168:notes:81]
| ​ |  | Nine Months Ended |  | Nine Months Ended |
| ​ | ​ | June 30, | ​ | June 30, |
| (Dollars in thousands) |  | 2022 |  | 2021 |
| Cash paid for amounts included in the measurement of lease liabilities | ​ | ​ | ​ | ​ | ​ | ​ |
| Operating cash flows from operating leases |  | $ | 4,502 |  | $ | 4,102 |
| Operating cash flows from finance leases | ​ | ​ | 734 | ​ | ​ | 915 |
| Financing cash flows from finance leases | ​ | ​ | 911 | ​ | ​ | 1,261 |
| Right-of-use assets obtained in exchange for operating lease liabilities | ​ | ​ | 1,813 | ​ | ​ | 12,780 |

[0001410578-22-002168:notes:82]
| ​ |  | June 30, 2022 |  | June 30, 2021 | ​ |
| Weighted-average remaining lease term | ​ | ​ | ​ | ​ | ​ |
| Operating leases |  | 9.8 | years | 10.3 | years |
| Finance leases |  | 12.3 | years | 11.9 | years |
| Weighted-average discount rate |  | ​ |  | ​ | ​ |
| Operating leases |  | 3.11 | % | 3.12 | % |
| Finance leases |  | 4.59 | % | 4.31 | % |

[0001410578-22-002168:notes:83]
The following is a reconciliation of future undiscounted cash flows to the operating and finance lease liabilities, and the related ROU assets, presented on our Consolidated Balance Sheet on June 30, 2022:

[0001410578-22-002168:notes:84]
| (Dollars in thousands) | ​ | Operating |  | Finance |
| Years Ending September 30: |  | Leases |  | Leases |
| 2022 (excluding the nine months ended June 30, 2022) | ​ | $ | 1,316 |  | 552 |
| 2023 | ​ |  | 5,126 |  | 2,256 |
| 2024 | ​ |  | 4,330 |  | 2,315 |
| 2025 | ​ |  | 3,751 |  | 2,370 |
| 2026 and thereafter | ​ |  | 20,251 |  | 21,431 |
| Total minimum lease payments | ​ |  | 34,774 |  | 28,924 |
| Less: amounts representing interest | ​ |  | 4,999 |  | 7,429 |
| Present value of net minimum lease payments | ​ | $ | 29,775 |  | 21,495 |
| Less: current portion of lease obligations | ​ |  | 4,566 |  | 1,304 |
| Non-current portion of lease obligations | ​ | ​ | 25,209 |  | 20,191 |
| ROU assets | ​ | $ | 28,922 |  | 17,736 |

[0001410578-22-002168:notes:85]
Operating lease liabilities are included in the Consolidated Balance Sheet in accrued other expenses (current portion) and as a caption on the Consolidated Balance Sheet (long-term portion). Finance lease liabilities are included on the Consolidated Balance Sheet in accrued other expenses (current portion) and other liabilities (long-term portion). Operating lease ROU assets are included as a caption on the Consolidated Balance Sheet and finance lease ROU assets are included in Property, plant and equipment on the Consolidated Balance Sheets.
