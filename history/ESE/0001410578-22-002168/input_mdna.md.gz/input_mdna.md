# ESE MD&A — 0001410578-22-002168


## mdna

[0001410578-22-002168:mdna:1]
[same as prior period, unchanged from 0001410578-22-001243:mdna:1]

[0001410578-22-002168:mdna:2]
[same as prior period, unchanged from 0001410578-22-001243:mdna:2]

[0001410578-22-002168:mdna:3]
The COVID-19 global pandemic has continued to create unprecedented challenges, including constraints on the Company’s supply chain. The economic uncertainty, changes in the propensity for the general public to travel by air, and reductions in demand for commercial aircraft as a result of the COVID-19 pandemic have adversely impacted net sales and operating results in certain of our A&D reporting units since the pandemic began. Additionally, the electric utility market has been impacted by reduced domestic electricity consumption related to the pandemic, which in turn impacts utility spending on investments in grid maintenance and testing.

[0001410578-22-002168:mdna:4]
Throughout 2021 and the first nine months of 2022, our Navy, defense aerospace, space and Test segment end-markets have remained solid and we are seeing recovery in our core markets most affected by the pandemic. We are encouraged by the growing strength of our entered orders across the commercial aerospace, electric utility and renewable energy end-markets.

[0001410578-22-002168:mdna:5]
We are also monitoring the impacts of COVID-19 on the fair value of assets. We do not currently anticipate any material asset impairments as a result of the COVID-19 global pandemic. We determined that there was no impairment for the three and nine-month periods ended June 30, 2022. We will continue to monitor the impacts of COVID-19 on the fair value of assets. For further discussion, refer to Management’s Discussion and Analysis contained in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2021.

[0001410578-22-002168:mdna:6]
[same as prior period, unchanged from 0001410578-22-001243:mdna:6]

[0001410578-22-002168:mdna:7]
References to the third quarters of 2022 and 2021 represent the three-month periods ended June 30, 2022 and 2021, respectively.

[0001410578-22-002168:mdna:8]
[same as prior period, unchanged from 0001410578-22-001243:mdna:8]

[0001410578-22-002168:mdna:9]
In the third quarter of 2022, sales, net earnings and diluted earnings per share were $219.1 million, $23.2 million and $0.89 per share, respectively, compared to $181.4 million, $14.9 million and $0.57 per share, respectively, in the third quarter of 2021. In the first nine months of 2022, sales, net earnings and diluted earnings per share were $601.0 million, $51.3 million and $1.97 per share, respectively, compared to $510.0 million, $43.1 million and $1.65 per share, respectively, in the first nine months of 2021.

[0001410578-22-002168:mdna:10]
[same as prior period, unchanged from 0001410578-22-001243:mdna:10]

[0001410578-22-002168:mdna:11]
In the third quarter of 2022, net sales of $219.1 million were $37.7 million, or 20.8%, higher than the $181.4 million in the third quarter of 2021. In the first nine months of 2022, net sales of $601.0 million were $91.0 million, or 17.8%, higher than the $510.0 million in the first nine months of 2021. The increase in net sales in the third quarter of 2022 as compared to the third quarter of 2021 was due to a $19.5 million increase in the USG segment, an $11.2 million increase in the Test segment, and a $7.0 million increase in the Aerospace & Defense segment. The increase in net sales in the first nine months of 2022 as compared to the first nine months of 2021 was due to a $53.1 million increase in the USG segment, a $25.0 million increase in the Test segment, and a $13.0 million increase in the Aerospace & Defense segment.

[0001410578-22-002168:mdna:12]
[same as prior period, unchanged from 0001410578-22-001243:mdna:12]

[0001410578-22-002168:mdna:13]
In the third quarter of 2022, net sales of $92.6 million were $7.0 million, or 8.2%, higher than the $85.6 million in the third quarter of 2021. In the first nine months of 2022, net sales of $247.7 million were $12.9 million, or 5.5%, higher than the $234.7 million in the first nine months of 2021. The sales increase in the third quarter of 2022 compared to the third quarter of 2021 was mainly due to a $3.9 million increase in net sales at Mayday primarily driven by an increase in commercial aerospace sales, a $3.1 million increase in net sales at VACCO driven by higher navy defense products, a $0.8 million increase in net sales at PTI, a $0.4 million increase in net sales at Globe, partially offset by a $1.2 million decrease in net sales at Westland. The sales increase in the first nine months of 2022 compared to the first nine months of 2021 was mainly due to a $8.5 million increase in net sales at Mayday, a $6.2 million increase in net sales at PTI, both primarily due to an increase in commercial aerospace sales driven by the rebound from the COVID-19 pandemic, a $2.1 million increase in net sales at Westland, and a $0.6 million increase in net sales at Globe, partially offset by a $4.5 million decrease in net sales at VACCO driven by timing of navy defense projects.

[0001410578-22-002168:mdna:14]
[same as prior period, unchanged from 0001410578-22-001243:mdna:14]

[0001410578-22-002168:mdna:15]
In the third quarter of 2022, net sales of $67.2 million were $19.5 million, or 40.9%, higher than the $47.7 million in the third quarter of 2021. In the first nine months of 2022, net sales of $194.9 million were $53.1 million, or 37.4%, higher than the $141.8 million in the first nine months of 2021. The increase in the third quarter and first nine months of 2022 compared to the corresponding periods of 2021 was mainly due to higher product and service revenue at Doble primarily driven by the acquisitions of Altanova and Phenix, and an increase in product sales at NRG. The revenue contribution from the Altanova and Phenix acquisitions totaled $11.5 million and $36.5 million for the third quarter and first nine months of 2022, respectively.

[0001410578-22-002168:mdna:16]
[same as prior period, unchanged from 0001410578-22-001243:mdna:16]

[0001410578-22-002168:mdna:17]
In the third quarter of 2022, net sales of $59.3 million were $11.2 million, or 23.3%, higher than the $48.1 million in the third quarter of 2021. In the first nine months of 2022, net sales of $158.4 million were $25.0 million, or 18.7%, higher than the $133.4 million in the first nine months of 2021. The increase in the third quarter of 2022 as compared to the third quarter of 2021 was primarily due to higher sales from the Company’s U.S. and Asian operations totaling $11.8 million partially offset by a $0.6 million decrease in sales from the segment’s European operations due to the timing of test and measurement chamber projects. The increase in the first nine months of 2022 compared to the first nine months of 2021 was due to higher sales from the Company’s Asian and U.S. operations totaling $29.1 million partially offset by a $4.1 million decrease in sales from the segment’s European operations due to the timing of test and measurement chamber projects.

[0001410578-22-002168:mdna:18]
[same as prior period, unchanged from 0001410578-22-001243:mdna:18]

[0001410578-22-002168:mdna:19]
Backlog was $706.8 million at June 30, 2022 compared with $592.0 million at September 30, 2021. The Company received new orders totaling $254.9 million in the third quarter of 2022 compared to $203.8 million in the third quarter of 2021. Of the new orders received in the third quarter of 2022, $110.2 million related to Aerospace & Defense products, $74.4 million related to USG products, and $70.3 million related to Test products. Of the new orders received in the third quarter of 2021, $95.1 million related to Aerospace & Defense products, $55.5 million related to USG products, and $53.2 million related to Test products.

[0001410578-22-002168:mdna:20]
The Company received new orders totaling $715.8 million in the first nine months of 2022 compared to $537.7 million in the first nine months of 2021. Of the new orders received in the first nine months of 2022, $295.0 million related to Aerospace & Defense products, $227.1 million related to USG products, and $193.7 million related to Test products. Of the new orders received in the first nine months of 2021, $248.8 million related to Aerospace & Defense products, $147.8 million related to USG products, and $141.1 million related to Test products.

[0001410578-22-002168:mdna:21]
[same as prior period, unchanged from 0001410578-22-001243:mdna:21]

[0001410578-22-002168:mdna:22]
Selling, general and administrative (SG&A) expenses for the third quarter of 2022 were $47.5 million (21.7% of net sales), compared with $42.9 million (23.6% of net sales) for the third quarter of 2021. For the first nine months of 2022, SG&A expenses were $142.1 million (23.6% of net sales) compared to $122.6 million (24.0% of net sales) for the first nine months of 2021. The increase in SG&A in the third quarter and first nine months of 2022 compared to the corresponding periods of 2021 was mainly due to higher expenses at Doble as a result of the SG&A contribution from the Altanova and Phenix acquisitions.

[0001410578-22-002168:mdna:23]
[same as prior period, unchanged from 0001410578-22-001243:mdna:23]

[0001410578-22-002168:mdna:24]
Amortization of intangible assets was $6.4 million and $19.4 million for the third quarter and first nine months of 2022, respectively, compared to $4.9 million and $14.7 million for the corresponding periods of 2021. Amortization expenses consist of amortization of acquired intangible assets from acquisitions and other identifiable intangible assets (primarily software). The increase in amortization expense in the third quarter and first nine months of 2022 compared to the corresponding periods of 2021 was mainly due to the Company’s recent acquisitions of Phenix, Altanova and NEco.

[0001410578-22-002168:mdna:25]
OTHER (INCOME) EXPENSES, NET

[0001410578-22-002168:mdna:26]
Other income, net, was $0.1 million of income in the third quarter of 2022 compared to $0.6 million of expenses in the third quarter of 2021. There were no individually significant items in other income, net, in the third quarter of 2022. The principal component of other (income) expenses, net, in the third quarter of 2021 was $0.5 million of facility consolidation charges for the Doble Morgan Schaffer facility.

[0001410578-22-002168:mdna:27]
Other income, net, was $0.7 million of income in the first nine months of 2022 compared to $1.3 million of income in the first nine months of 2021. There were no individually significant items in other income, net, in the first nine months of 2022. The principal component of other income, net, in the first nine months of 2021 was a gain of approximately $2 million for the final settlement on the sale of the Doble Watertown, MA building, partially offset by facility consolidation charges for the Doble Manta facility and Morgan Schaffer facilities.

[0001410578-22-002168:mdna:28]
[same as prior period, unchanged from 0001410578-22-001243:mdna:29]

[0001410578-22-002168:mdna:29]
The Company evaluates the performance of its operating segments based on EBIT, and provides EBIT on a consolidated basis, which is a non-GAAP financial measure. Please refer to the discussion of non-GAAP financial measures in Note 7 to the Consolidated Financial Statements, above. EBIT was $30.8 million (14.1% of net sales) for the third quarter of 2022 compared to $19.4 million (10.7% of net sales) for the third quarter of 2021. For the first nine months of 2022, EBIT was $69.1 million (11.5% of net sales) compared to $57.1 million (11.2% of net sales) for the first nine months of 2021.

[0001410578-22-002168:mdna:30]
[same as prior period, unchanged from 0001410578-22-001243:mdna:31]

[0001410578-22-002168:mdna:31]
| ​ | ​ | Three Months Ended | ​ | Nine Months Ended |
| ​ | ​ | June 30, | ​ | June 30, |
| (In thousands) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Consolidated EBIT | ​ | $ | 30,833 | ​ | ​ | 19,423 | ​ | 69,091 | ​ | 57,085 |
| Less: Interest expense, net | ​ |  | (1,331) | ​ | ​ | (480) | ​ | (3,084) | ​ | (1,453) |
| Less: Income tax expense | ​ |  | (6,329) | ​ | ​ | (4,034) | ​ | (14,727) | ​ | (12,501) |
| Net earnings | ​ | $ | 23,173 | ​ | ​ | 14,909 | ​ | 51,280 | ​ | 43,131 |

[0001410578-22-002168:mdna:32]
[same as prior period, unchanged from 0001410578-22-001243:mdna:33]

[0001410578-22-002168:mdna:33]
EBIT in the third quarter of 2022 was $20.7 million (22.4% of net sales) compared to $16.7 million (19.5% of net sales) in the third quarter of 2021. EBIT in the first nine months of 2022 was $45.0 million (18.2% of net sales) compared to $42.0 million (17.9% of net sales) in the first nine months of 2021. The increase in EBIT in the third quarter of 2022 compared to the corresponding period of 2021 was mainly due to improved operating performance at Westland and higher sales volumes at Mayday, VACCO and Globe. The increase in EBIT for the first nine months of 2022 compared to the corresponding period of 2021 was mainly due to favorable product mix and higher sales volumes at Mayday, Westland and Globe partially offset by a decrease in EBIT at VACCO and Crissair due to product mix and lower sales volumes. EBIT in the first nine months of 2022 was negatively impacted by a $0.3 million inventory step-up charge related to the NEco acquisition. EBIT in the first nine months of 2021 was negatively impacted by a $0.3 million inventory step-up charge related to the ATM acquisition.

[0001410578-22-002168:mdna:34]
[same as prior period, unchanged from 0001410578-22-001243:mdna:35]

[0001410578-22-002168:mdna:35]
EBIT in the third quarter of 2022 was $13.1 million (19.5% of net sales) compared to $8.2 million (17.2% of net sales) in the third quarter of 2021. EBIT in the first nine months of 2022 was $37.8 million (19.4% of net sales) compared to $27.7 million (19.5% of net sales) in the first nine months of 2021. The increase in EBIT in the third quarter and first nine months of 2022 compared to the corresponding periods of 2021 was mainly due to the higher sales volumes at Doble and NRG as mentioned above. EBIT in the first nine months of 2022 was negatively impacted by approximately $0.5 million of inventory step-up charges related to the Altanova acquisition.

[0001410578-22-002168:mdna:36]
[same as prior period, unchanged from 0001410578-22-001243:mdna:37]

[0001410578-22-002168:mdna:37]
EBIT in the third quarter of 2022 was $8.4 million (14.1% of net sales) compared to $6.8 million (14.0% of net sales) in the third quarter of 2021. EBIT in the first nine months of 2022 was $20.8 million (13.1% of net sales) compared to $17.8 million (13.3% of net sales) in the first nine months of 2021. The increase in EBIT in the third quarter and first nine months of 2022 compared to the corresponding periods of 2021 was primarily due to product mix and higher margins on projects mainly from the segment’s Asian and U.S. operations.

[0001410578-22-002168:mdna:38]
[same as prior period, unchanged from 0001410578-22-001243:mdna:39]

[0001410578-22-002168:mdna:39]
Corporate costs included in EBIT were $11.4 million and $34.6 million in the third quarter and first nine months of 2022, respectively, compared to $12.3 million and $30.4 million in the corresponding periods of 2021. The decrease in Corporate costs in the third quarter of 2022 compared to the prior year quarter was due to executive transition related compensation and acquisition costs in 2021. The

[0001410578-22-002168:mdna:40]
increase in Corporate costs in the first nine months of 2022 compared to the corresponding period of 2021 was mainly due to the increase in amortization expense of acquired intangible assets related to the Company’s recent acquisitions of Phenix, Altanova and NEco.

[0001410578-22-002168:mdna:41]
[same as prior period, unchanged from 0001410578-22-001243:mdna:41]

[0001410578-22-002168:mdna:42]
Interest expense was $1.3 million and $3.1 million in the third quarter and first nine months of 2022, respectively, and $0.5 million and $1.5 million in the corresponding periods of 2021. The increase in interest expense in the third quarter and first nine months of 2022 compared to the corresponding periods of 2021 was mainly due to higher average outstanding borrowings. Average outstanding borrowings were $205 million and $195 million in the third quarter and first nine months of 2022, respectively, and $39 million and $44 million in the corresponding periods of 2021.

[0001410578-22-002168:mdna:43]
[same as prior period, unchanged from 0001410578-22-001243:mdna:43]

[0001410578-22-002168:mdna:44]
The third quarter 2022 effective income tax rate was 21.5% compared to 21.3% in the third quarter of 2021. The effective income tax rate in the first nine months of 2022 was 22.3% compared to 22.5% for the first nine months of 2021. The income tax expense in the third quarter and first nine months of 2022 was favorably impacted by tax return to provision true-ups on U.S. tax on the distribution of foreign earnings and the re-rating of deferred taxes as a result of a Vermont law change, decreasing the third quarter and year-to-date effective tax rate by 1.6% and 0.7%, respectively. The income tax expense in the third quarter and first nine months of 2021 was favorably impacted by a tax return to provision true-up for foreign derived intangible income and other 2020 true-ups decreasing the third quarter and year-to-date effective tax rate by 3.9% and 1.2% respectively.

[0001410578-22-002168:mdna:45]
[same as prior period, unchanged from 0001410578-22-001243:mdna:45]

[0001410578-22-002168:mdna:46]
The Company's overall financial position and liquidity remains strong. Working capital (current assets less current liabilities) increased to $261.4 million at June 30, 2022 from $191.2 million at September 30, 2021. Inventories increased by $31.0 million during this period due to a $14.0 million increase within the USG segment, an $11.9 million increase within the Test segment and a $5.1 million increase within the Aerospace & Defense segment resulting primarily from the timing of receipt of raw materials to meet anticipated demand and an increase in work in process inventories due to timing of manufacturing existing orders. Accounts receivable increased by $22.4 million during this period due to a $14.9 million increase within the Aerospace & Defense segment, a $4.2 million increase within the Test segment and a $3.3 million increase within the USG segment, due to timing of sales and collections.

[0001410578-22-002168:mdna:47]
Net cash provided by operating activities was $41.7 million and $75.4 million in the first nine months of 2022 and 2021, respectively. The decrease in net cash provided by operating activities in the first nine months of 2022 as compared to the first nine months of 2021 was mainly driven by higher working capital requirements.

[0001410578-22-002168:mdna:48]
Capital expenditures were $25.9 million and $17.9 million in the first nine months of 2022 and 2021, respectively. The increase in the first nine months of 2022 compared to the prior year period was mainly due to the purchase of the NRG building of approximately $10 million in the first quarter of 2022. In addition, the Company incurred expenditures for capitalized software of $9.4 million and $6.5 million in the first nine months of 2022 and 2021, respectively.

[0001410578-22-002168:mdna:49]
[same as prior period, unchanged from 0001410578-22-001243:mdna:49]

[0001410578-22-002168:mdna:50]
On November 4, 2021, the Company acquired Networks Electronic Company, LLC (NEco) for a purchase price of approximately $15.4 million, net of cash acquired. NEco, based in Chatsworth, California, provides miniature electro-explosive devices utilized in mission-critical defense and aerospace applications. Since the date of acquisition, the operating results for the NEco business have been included as part of PTI in the A&D segment.

[0001410578-22-002168:mdna:51]
Credit Facility

[0001410578-22-002168:mdna:52]
At June 30, 2022, the Company had approximately $291.0 million available to borrow under its bank credit facility, a $250 million increase option subject to lender approval, and $61.0 million cash on hand. At June 30, 2022, the Company had $201.0 million of outstanding borrowings under the credit facility in addition to outstanding letters of credit of $7.8 million. Cash flow from operations and borrowings under the Company’s credit facility are expected to meet the Company’s capital requirements and operational needs

[0001410578-22-002168:mdna:53]
for the foreseeable future. The Company’s ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.

[0001410578-22-002168:mdna:54]
[same as prior period, unchanged from 0001410578-22-001243:mdna:53]

[0001410578-22-002168:mdna:55]
During the first nine months of 2022, the Company repurchased approximately 257,000 shares for approximately $20.0 million. For further information on the share repurchases during the third quarter of 2022, see Part II, Item 2 of this Report.

[0001410578-22-002168:mdna:56]
[same as prior period, unchanged from 0001410578-22-001243:mdna:55]

[0001410578-22-002168:mdna:57]
A dividend of $0.08 per share, totaling $2.1 million, was paid on October 15, 2021 to stockholders of record as of October 1, 2021. A dividend of $0.08 per share, totaling $2.1 million, was paid on January 19, 2022 to stockholders of record as of January 4, 2022. A dividend of $0.08 per share, totaling $2.1 million, was paid on April 19, 2022 to stockholders of record as of April 4, 2022. Subsequent to June 30, 2022, a quarterly dividend of $0.08 per share, totaling $2.1 million, was paid on July 19, 2022 to stockholders of record as of July 5, 2022.

[0001410578-22-002168:mdna:58]
[same as prior period, unchanged from 0001410578-22-001243:mdna:57]

[0001410578-22-002168:mdna:59]
[same as prior period, unchanged from 0001410578-22-001243:mdna:58]

[0001410578-22-002168:mdna:60]
[same as prior period, unchanged from 0001410578-22-001243:mdna:59]

[0001410578-22-002168:mdna:61]
Contingencies

[0001410578-22-002168:mdna:62]
As a normal incident of the business in which the Company is engaged, various claims, charges and litigation are asserted or commenced against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. In the opinion of Management, the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company, are adequately reserved, are covered by insurance, or would not have a material adverse effect on the Company’s results from operations, capital expenditures, or competitive position.

[0001410578-22-002168:mdna:63]
[same as prior period, unchanged from 0001410578-22-001243:mdna:62]

[0001410578-22-002168:mdna:64]
Investors are cautioned that such statements are only predictions and speak only as of the date of this Form 10-Q, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment, including but not limited to those described in Item 1A, “Risk Factors,” of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2021, and the following: the continuing impact of the COVID-19 pandemic including the impacts of known or unknown COVID-19 variants, labor shortages, facility closures, shelter in place policies or quarantines, material shortages, transportation delays, termination or delays of Company contracts and the inability of our suppliers or customers to perform, the impacts of natural disasters on the Company’s operations and those of the Company’s customers and suppliers; the timing and content of future contract awards or customer orders; the appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer contracts or orders; weakening of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties; the availability of selected acquisitions; delivery delays or defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability of certain raw materials; inflationary pressures on the Company’s costs of materials, components and supplies; labor disputes; changes in U.S. tax laws and regulations; other changes in laws and regulations including but not limited to changes in accounting standards and foreign taxation; changes in interest rates; costs relating to environmental matters arising from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the integration of recently acquired businesses.
