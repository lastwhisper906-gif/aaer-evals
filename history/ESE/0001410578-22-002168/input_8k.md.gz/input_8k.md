# ESE 8-K — 0001104659-22-087247 filed 2022-08-08

## item codes, every 8-K on or before 2022-08-09

- 2022-08-08 0001104659-22-087247 — 2.02, 5.02, 7.01, 9.01
- 2022-05-09 0001104659-22-057524 — 2.02, 5.02, 7.01, 9.01
- 2022-02-08 0001104659-22-013878 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2021-12-03 0001104659-21-146361 — 4.01, 9.01 — amendment, the index does not say of what
- 2021-11-24 0001104659-21-143568 — 4.01, 9.01
- 2021-11-23 0001104659-21-142871 — 5.02, 8.01
- 2021-11-18 0001104659-21-141206 — 2.02, 7.01, 9.01
- 2021-08-09 0001104659-21-102150 — 2.02, 7.01, 9.01
- 2021-05-04 0001104659-21-060985 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2021-04-05 0001104659-21-046581 — 5.02, 9.01
- 2021-02-08 0001104659-21-013712 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2020-12-09 0001104659-20-133674 — 5.02, 9.01
- 2020-12-07 0001104659-20-132861 — 5.02, 7.01, 9.01
- 2020-11-19 0001104659-20-127352 — 2.02, 5.02, 7.01, 9.01
- 2020-08-10 0001104659-20-092734 — 2.02, 7.01, 9.01
- 2020-05-06 0001104659-20-057442 — 2.02, 7.01, 8.01, 9.01
- 2020-02-04 0001104659-20-010640 — 2.02, 5.07, 7.01, 9.01
- 2020-01-07 0001104659-20-001789 — 2.01, 9.01
- 2019-11-19 0001104659-19-065437 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2019-11-18 0001104659-19-065096 — 1.01, 2.02, 7.01, 9.01
- 2019-09-30 0001144204-19-046523 — 1.01, 1.02, 2.03, 9.01
- 2019-08-08 0001144204-19-038567 — 2.02, 7.01, 9.01
- 2019-05-07 0001144204-19-024241 — 2.02, 5.02, 7.01, 9.01
- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2022-08-09

- none on or before 2022-08-09

## item 2.02 — earnings release, exhibit 99.1

[0001104659-22-087247:8k_2_02:1]
EX-99.1
2
tm2222705d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-22-087247:8k_2_02:2]
Exhibit 99.1

[0001104659-22-087247:8k_2_02:3]
| NEWS FROM |  |

[0001104659-22-087247:8k_2_02:4]
For more information contact:

[0001104659-22-087247:8k_2_02:5]
Kate Lowrey

[0001104659-22-087247:8k_2_02:6]
Vice President of Investor Relations

[0001104659-22-087247:8k_2_02:7]
ESCO Technologies Inc.

[0001104659-22-087247:8k_2_02:8]
(314) 213-7277

[0001104659-22-087247:8k_2_02:9]
ESCO REPORTS THIRD QUARTER FISCAL 2022 RESULTS

[0001104659-22-087247:8k_2_02:10]
- Q3 2022 GAAP EPS $0.89 -

[0001104659-22-087247:8k_2_02:11]
- Q3 Sales increase 21% to $219 Million -

[0001104659-22-087247:8k_2_02:12]
- $255 Million in Q3 Orders / Book-to-bill
of 1.16x -

[0001104659-22-087247:8k_2_02:13]
ST. LOUIS, August 8, 2022 – ESCO Technologies
Inc. (NYSE: ESE) (ESCO, or the Company) today reported its operating results for the third quarter ended June 30, 2022 (Q3 2022) compared
to the third quarter ended June 30, 2021 (Q3 2021).

[0001104659-22-087247:8k_2_02:14]
Operating Highlights

[0001104659-22-087247:8k_2_02:15]
|  | · | Q3 2022 GAAP EPS was $0.89 per share compared to $0.57 in Q3 2021, an increase of 56 percent. There were no adjustments to Q3 2022 earnings. Q3 2022 EPS of $0.89 increased $0.22 per share (33 percent) compared to Adjusted EPS of $0.67 per share in Q3 2021. |

[0001104659-22-087247:8k_2_02:16]
|  | · | Q3 2022 Sales of $219.1 million increased $37.7 million (20.8 percent) compared to $181.4 million in Q3 2021. Organic sales increased $25.1 million (13.8 percent) and recent acquisitions added $12.6 million (7.0 percent) of revenue growth in the quarter. |

[0001104659-22-087247:8k_2_02:17]
|  | · | Q3 2022 Entered Orders increased $51.1 million (25 percent) over the prior year period to $254.9 million (book-to-bill of 1.16x), resulting in record backlog of $707 million. |

[0001104659-22-087247:8k_2_02:18]
|  | · | Net cash provided by operating activities was $42 million YTD 2022, as operating working capital investments more than offset earnings increases. |

[0001104659-22-087247:8k_2_02:19]
|  | · | Net debt (total borrowings less cash on hand) was $140 million, resulting in a 1.22x leverage ratio and $541 million in liquidity at June 30, 2022. |

[0001104659-22-087247:8k_2_02:20]
Vic Richey, Chairman and Chief Executive Officer,
commented, “Our global team delivered a very strong quarter of sales, earnings, orders and backlog growth. Business conditions have
remained strong and that helped drive a 21 percent sales increase and a 33 percent increase in Adjusted EPS.

[0001104659-22-087247:8k_2_02:21]
“I am very pleased that we were able to deliver
higher profit margins in line with pre-pandemic levels, while continuing to work through this challenging operational environment. To
deliver these results, our teams continued to work diligently to find ways to reduce costs, redesign products, secure sourcing alternatives,
and implement price increases to drive profit improvement. Through the combined efforts of employees across the company, we were able
to support our customers and deliver strong results in the quarter.

[0001104659-22-087247:8k_2_02:22]
“Our Q3 orders were excellent, particularly
in our test and measurement, space, commercial aerospace, electric utility, and renewables end-markets. This broad and continuing orders
growth across all three business segments shows the strength of our product offerings and end-markets. Our year-to-date orders of $716
million are up 33 percent over the prior year, and give us confidence in our growth outlook going forward.”

[0001104659-22-087247:8k_2_02:23]
Segment Performance

[0001104659-22-087247:8k_2_02:24]
Aerospace & Defense (A&D)

[0001104659-22-087247:8k_2_02:25]
|  | · | Sales increased $7.0 million (8 percent) to $92.6 million in Q3 2022 from $85.6 million in Q3 2021. The Q3 sales growth was primarily driven by commercial aerospace, which increased $8.4 million (35 percent) to $32.0 million. Commercial aerospace sales growth was driven by the 737 production ramp, increased MRO activity at Mayday, and the NEco acquisition. Higher Navy and space sales in the quarter were offset by lower defense aerospace and industrial sales compared to the prior year. |

[0001104659-22-087247:8k_2_02:26]
|  | · | EBIT increased $4.0 million in Q3 2022 to $20.7 million (22.4 percent margin) from $16.7 million (19.6 percent margin) in Q3 2021. The margin increase was driven by higher volume, price increases and cost reductions, partially offset by material and wage inflation. |

[0001104659-22-087247:8k_2_02:27]
|  | · | Entered Orders increased $15 million to $110 million in Q3 2022 (book-to-bill of 1.19x) compared to $95 million in Q3 2021. The orders strength was driven by funding for long lead material on the Space Launch System (SLS) shipsets 4-6 and the continuing recovery of commercial aerospace. The 16 percent increase in orders over the prior year quarter resulted in record backlog of $415 million. |

[0001104659-22-087247:8k_2_02:28]
Utility Solutions Group (USG)

[0001104659-22-087247:8k_2_02:29]
|  | · | Sales increased $19.5 million (41 percent) to $67.2 million in Q3 2022 from $47.7 million in Q3 2021. Recent acquisitions Phenix and Altanova contributed $11.6 million in revenue and Doble organic sales increased $4.8 million (12 percent). The organic sales growth was driven by a recovery in demand for services, and a strong quarter for Protection Testing and Morgan Schaffer products. In addition, NRG sales increased $3.1 million (37 percent) on continued strength in the renewables end-market. |

[0001104659-22-087247:8k_2_02:30]
|  | · | EBIT increased $4.9 million in Q3 2022 to $13.1 million from $8.2 million in Q3 2021. There were no adjustments to Q3 2022 EBIT of $13.1 million (19.5 percent margin), which increased $4.4 million from Q3 2021 Adjusted EBIT of $8.7 million (18.3 percent margin). The margin increase was primarily driven by leverage on higher revenue and price increases, partially offset by wage and material cost inflation. |
|  | · | Entered Orders increased $19 million to $74 million in Q3 2022 (book-to-bill of 1.11x). The orders strength was primarily driven by Altanova and Phenix, and a $5 million (49 percent) increase in renewables orders at NRG. The 34 percent increase in orders over the prior year quarter resulted in backlog of $124 million. |

[0001104659-22-087247:8k_2_02:31]
Test

[0001104659-22-087247:8k_2_02:32]
|  | · | Sales increased $11.1 million (23 percent) to $59.2 million in Q3 2022 from $48.1 million in Q3 2021, primarily due to increased power filter and test and measurement chamber volume. |

[0001104659-22-087247:8k_2_02:33]
|  | · | EBIT increased $1.6 million in Q3 2022 to $8.4 million (14.1 percent margin) from $6.8 million (14.0 percent margin) in Q3 2021. The increase in profitability was driven by leverage on higher sales and price increases, partially offset by material cost and wage inflation. |

[0001104659-22-087247:8k_2_02:34]
|  | · | Entered Orders were $70 million in Q3 2022 (book-to-bill of 1.19x) compared to $53 million in Q3 2021. The order growth was driven by global demand for test and measurement projects. The $17 million (32 percent) increase in orders over the prior year resulted in record backlog of $168 million. |

[0001104659-22-087247:8k_2_02:35]
Share Repurchase Program

[0001104659-22-087247:8k_2_02:36]
As previously announced in our August 9, 2021 press
release, the Company’s Board of Directors approved a new stock repurchase program. During Q3 2022, the Company repurchased approximately
28,500 shares for $2 million. As of June 30, 2022, the Company has repurchased approximately 257,500 shares for $20 million year-to-date.

[0001104659-22-087247:8k_2_02:37]
Dividend Payment

[0001104659-22-087247:8k_2_02:38]
The next quarterly cash dividend
of $0.08 per share will be paid on October 18, 2022 to stockholders of record on October 4, 2022.

[0001104659-22-087247:8k_2_02:39]
Business Outlook – 2022

[0001104659-22-087247:8k_2_02:40]
Management’s expectations for 2022 remain consistent with the
details outlined in our November 18, 2021 release.  Our 2022 guidance represented meaningful growth in sales, Adjusted EBIT, and
Adjusted EBITDA across each of the Company’s business segments.

[0001104659-22-087247:8k_2_02:41]
Our year-to-date results have been consistent
with our guidance as presented in November. Our continuing order strength is driving revenue growth and margin expansion and gives
us confidence that we are on track to deliver a solid Q4 in line with that initial guidance. Our
expectation is for Q4 Adjusted EPS to be in the range of $1.12 to $1.18 per share, representing growth of 32 to 39 percent over the
prior year. This remains consistent with our full year guidance but narrows the Adjusted EPS to a range of $3.12 to
$3.18.

[0001104659-22-087247:8k_2_02:42]
Conference Call

[0001104659-22-087247:8k_2_02:43]
The Company will host a conference call today, August 8, at 4:00 p.m.
Central Time, to discuss the Company’s Q3 2022 results. A live audio webcast and an accompanying slide presentation will be available
on ESCO’s investor website at https://investor.escotechnologies.com. For those unable to participate, a webcast replay will be available
after the call on ESCO’s investor website.

[0001104659-22-087247:8k_2_02:44]
Forward-Looking Statements

[0001104659-22-087247:8k_2_02:45]
Statements in this press release regarding the timing
and magnitude of recovery in the Company’s end markets, the continuing impacts of COVID-19 on the Company’s results, sales,
Adjusted SG&A, Adjusted EBIT, Adjusted EBITDA, Adjusted EPS, cash flow, results of cost reduction efforts, margins, growth, the financial
success of the Company, the strength of its end markets, the outlook for the A&D, Test and USG segments, the ability to increase shareholder
value, the timing and success of acquisition efforts, internal investments in new products and solutions, the impacts of inflation, the
long-term success of the Company, and any other statements which are not strictly historical are “forward-looking” statements
within the meaning of the safe harbor provisions of the federal securities laws.

[0001104659-22-087247:8k_2_02:46]
Investors are cautioned that such statements
are only predictions and speak only as of the date of this release, and the Company undertakes no duty to update them except as may
be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those
projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business
environment including but not limited to those described in Item 1A, “Risk Factors”, of the Company’s Annual
Report on Form 10-K for the fiscal year ended September 30, 2021; the availability and acceptance of viable COVID-19 vaccines by
enough of the U.S. and world’s population to curtail the pandemic; the continuing impact of the COVID-19 pandemic and the
effects of known or unknown COVID-19 variants including labor shortages, facility closures, shelter in place policies or
quarantines, material shortages, transportation delays, termination or delays of Company contracts, and the inability of our
suppliers or customers to perform; the impacts of Executive Order 14042 and other vaccine mandates on our employees and businesses;
the impacts of natural disasters on the Company’s operations and those of the Company’s customers and suppliers; the
timing and content of future contract awards or customer orders; the appropriation, allocation and availability of Government funds;
the termination for convenience of Government and other customer contracts or orders; weakening of economic conditions in served
markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies; competition;
intellectual property rights; technical difficulties; the success of the Company’s acquisition efforts; delivery delays or
defaults by customers; performance issues with key customers, suppliers and subcontractors; changes in the costs and availability of
certain raw materials; labor disputes; changes in U.S. tax laws and regulations; other changes in laws and regulations including but
not limited to changes in accounting standards and foreign taxation; changes in interest rates; costs relating to environmental
matters arising from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims,
litigation or arbitration; and the integration of recently acquired businesses.

[0001104659-22-087247:8k_2_02:47]
Non-GAAP Financial Measures

[0001104659-22-087247:8k_2_02:48]
The financial measures EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA
and Adjusted EPS are presented in this press release. The Company defines “EBIT” as earnings before interest and taxes, “EBITDA”
as earnings before interest, taxes, depreciation and amortization, “Adjusted EBIT” and “Adjusted EBITDA” as excluding
the net impact of the items described in the attached Reconciliation of Non-GAAP Financials Measures, and “Adjusted EPS” as
GAAP earnings per share (EPS) excluding the net impact of the items described and reconciled in the attached Reconciliation of Non-GAAP
Financial Measures.

[0001104659-22-087247:8k_2_02:49]
EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA and
Adjusted EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management believes
EBIT, Adjusted EBIT, EBITDA and Adjusted EBITDA are useful in assessing the operational profitability of the Company’s business
segments because they exclude interest, taxes, depreciation and amortization, which are generally accounted for across the entire Company
on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company as
well as incentive compensation. The presentation of EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS provides important supplemental
information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures to supplement
their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance determined in accordance
with GAAP.

[0001104659-22-087247:8k_2_02:50]
ESCO, headquartered in St. Louis, Missouri: Manufactures
highly-engineered filtration and fluid control products for the aviation, Navy, space and process markets worldwide, as well as composite-based
products and solutions for Navy, defense and industrial customers; is the industry leader in RF shielding and EMC test products; and provides
diagnostic instruments, software and services for the benefit of industrial power users and the electric utility and renewable energy
industries. Further information regarding ESCO and its subsidiaries is available on the Company’s website at www.escotechnologies.com.

[0001104659-22-087247:8k_2_02:51]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-22-087247:8k_2_02:52]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-22-087247:8k_2_02:53]
(Dollars in thousands, except per share amounts)

[0001104659-22-087247:8k_2_02:54]
|  |  | Three Months Ended June 30, 2022 |  |  | Three Months Ended June 30, 2021 |  |
| Net Sales |  | $ | 219,066 |  |  |  | 181,394 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 134,454 |  |  |  | 113,610 |  |
| Selling, general and administrative expenses |  |  | 47,479 |  |  |  | 42,882 |  |
| Amortization of intangible assets |  |  | 6,406 |  |  |  | 4,864 |  |
| Interest expense |  |  | 1,331 |  |  |  | 480 |  |
| Other (income) expenses, net |  |  | (106 | ) |  |  | 615 |  |
| Total costs and expenses |  |  | 189,564 |  |  |  | 162,451 |  |
| Earnings before income taxes |  |  | 29,502 |  |  |  | 18,943 |  |
| Income tax expense |  |  | 6,329 |  |  |  | 4,034 |  |
| Net earnings |  | $ | 23,173 |  |  |  | 14,909 |  |
| Diluted EPS: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 0.89 |  |  |  | 0.57 |  |
| Diluted - As Adjusted Basis |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 0.89 |  |  |  | 0.67 | (1) |
| Diluted average common shares O/S: |  |  | 25,950 |  |  |  | 26,214 |  |

[0001104659-22-087247:8k_2_02:55]
|  | (1) | Q3 2021 Adjusted EPS excludes $0.10 per share of after-tax charges incurred at Corporate due to management transition and acquisition costs, and charges related to the USG (Morgan Schaffer) facility move. |

[0001104659-22-087247:8k_2_02:56]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-22-087247:8k_2_02:57]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-22-087247:8k_2_02:58]
(Dollars in thousands, except per share amounts)

[0001104659-22-087247:8k_2_02:59]
|  |  | Nine Months Ended June 30, 2022 |  |  | Nine Months Ended June 30, 2021 |  |
| Net Sales |  | $ | 601,004 |  |  |  | 509,962 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 371,134 |  |  |  | 316,785 |  |
| Selling, general and administrative expenses |  |  | 142,073 |  |  |  | 122,628 |  |
| Amortization of intangible assets |  |  | 19,383 |  |  |  | 14,729 |  |
| Interest expense |  |  | 3,084 |  |  |  | 1,453 |  |
| Other (income) expenses, net |  |  | (677 | ) |  |  | (1,265 | ) |
| Total costs and expenses |  |  | 534,997 |  |  |  | 454,330 |  |
| Earnings before income taxes |  |  | 66,007 |  |  |  | 55,632 |  |
| Income tax expense |  |  | 14,727 |  |  |  | 12,501 |  |
| Net earnings |  | $ | 51,280 |  |  |  | 43,131 |  |
| Diluted EPS: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 1.97 |  |  |  | 1.65 |  |
| Diluted - As Adjusted Basis |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 2.00 | (1) |  |  | 1.75 | (2) |
| Diluted average common shares O/S: |  |  | 26,050 |  |  |  | 26,199 |  |

[0001104659-22-087247:8k_2_02:60]
|  | (1) | YTD Q3 2022 Adjusted EPS excludes $0.03 per share of after-tax charges associated with the Altanova & Neco acquisition inventory step-up charges and Corporate acquisition related costs. |

[0001104659-22-087247:8k_2_02:61]
|  | (2) | YTD Q3 2021 Adjusted EPS excludes $0.10 per share consisting of after-tax charges incurred at Corporate due to management transition and acquisition costs, an ATM acquisition inventory step-up charge, and charges related to the USG (Doble Manta & Morgan Schaffer) facility consolidations, partially offset by the final settlement from the sale of the Doble Watertown facility. |

[0001104659-22-087247:8k_2_02:62]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-22-087247:8k_2_02:63]
Condensed Business Segment Information (Unaudited)

[0001104659-22-087247:8k_2_02:64]
(Dollars in thousands)

[0001104659-22-087247:8k_2_02:65]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | Q3 2022 |  |  | Q3 2021 |  |  | Q3 2022 |  |  | Q3 2021 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 92,606 |  |  |  | 85,576 |  |  |  | 92,606 |  |  |  | 85,576 |  |
| USG |  |  | 67,201 |  |  |  | 47,704 |  |  |  | 67,201 |  |  |  | 47,704 |  |
| Test |  |  | 59,259 |  |  |  | 48,114 |  |  |  | 59,259 |  |  |  | 48,114 |  |
| Totals |  | $ | 219,066 |  |  |  | 181,394 |  |  |  | 219,066 |  |  |  | 181,394 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 20,738 |  |  |  | 16,714 |  |  |  | 20,738 |  |  |  | 16,739 |  |
| USG |  |  | 13,135 |  |  |  | 8,227 |  |  |  | 13,135 |  |  |  | 8,710 |  |
| Test |  |  | 8,354 |  |  |  | 6,751 |  |  |  | 8,354 |  |  |  | 6,751 |  |
| Corporate |  |  | (11,394 | ) |  |  | (12,269 | ) |  |  | (11,394 | ) |  |  | (9,246 | ) |
| Consolidated EBIT |  |  | 30,833 |  |  |  | 19,423 |  |  |  | 30,833 |  |  |  | 22,954 |  |
| Less: Interest expense |  |  | (1,331 | ) |  |  | (480 | ) |  |  | (1,331 | ) |  |  | (480 | ) |
| Less: Income tax expense |  |  | (6,329 | ) |  |  | (4,034 | ) |  |  | (6,329 | ) |  |  | (4,846 | ) |
| Net earnings |  | $ | 23,173 |  |  |  | 14,909 |  |  |  | 23,173 |  |  |  | 17,628 |  |

[0001104659-22-087247:8k_2_02:66]
Note 1: Adjusted net earnings of $17.6 million
in Q3 2021 excludes $0.10 per share of after-tax charges incurred at Corporate due to management transition and acquisition costs, and
charges related to the USG (Morgan Schaffer) facility move.

[0001104659-22-087247:8k_2_02:67]
| EBITDA Reconciliation to Net earnings: |  |  |  |  | Adjusted |  |  | Adjusted |  |
|  |  | Q3 2022 |  |  | Q3 2021 |  |  | Q3 2022 |  |  | Q3 2021 |  |
| Consolidated EBITDA |  | $ | 42,788 |  |  |  | 29,567 |  |  |  | 42,788 |  |  |  | 33,098 |  |
| Less: Depr & Amort |  |  | (11,955 | ) |  |  | (10,144 | ) |  |  | (11,955 | ) |  |  | (10,144 | ) |
| Consolidated EBIT |  |  | 30,833 |  |  |  | 19,423 |  |  |  | 30,833 |  |  |  | 22,954 |  |
| Less: Interest expense |  |  | (1,331 | ) |  |  | (480 | ) |  |  | (1,331 | ) |  |  | (480 | ) |
| Less: Income tax expense |  |  | (6,329 | ) |  |  | (4,034 | ) |  |  | (6,329 | ) |  |  | (4,846 | ) |
| Net earnings |  | $ | 23,173 |  |  |  | 14,909 |  |  |  | 23,173 |  |  |  | 17,628 |  |

[0001104659-22-087247:8k_2_02:68]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-22-087247:8k_2_02:69]
Condensed Business Segment Information (Unaudited)

[0001104659-22-087247:8k_2_02:70]
(Dollars in thousands)

[0001104659-22-087247:8k_2_02:71]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | YTD Q3 2022 |  |  | YTD Q3 2021 |  |  | YTD Q3 2022 |  |  | YTD Q3 2021 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 247,671 |  |  |  | 234,720 |  |  |  | 247,671 |  |  |  | 234,720 |  |
| USG |  |  | 194,877 |  |  |  | 141,799 |  |  |  | 194,877 |  |  |  | 141,799 |  |
| Test |  |  | 158,456 |  |  |  | 133,443 |  |  |  | 158,456 |  |  |  | 133,443 |  |
| Totals |  | $ | 601,004 |  |  |  | 509,962 |  |  |  | 601,004 |  |  |  | 509,962 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 45,042 |  |  |  | 41,980 |  |  |  | 45,377 |  |  |  | 42,365 |  |
| USG |  |  | 37,840 |  |  |  | 27,683 |  |  |  | 38,307 |  |  |  | 27,552 |  |
| Test |  |  | 20,813 |  |  |  | 17,781 |  |  |  | 20,813 |  |  |  | 17,781 |  |
| Corporate |  |  | (34,604 | ) |  |  | (30,359 | ) |  |  | (34,299 | ) |  |  | (26,986 | ) |
| Consolidated EBIT |  |  | 69,091 |  |  |  | 57,085 |  |  |  | 70,198 |  |  |  | 60,712 |  |
| Less: Interest expense |  |  | (3,084 | ) |  |  | (1,453 | ) |  |  | (3,084 | ) |  |  | (1,453 | ) |
| Less: Income tax |  |  | (14,727 | ) |  |  | (12,501 | ) |  |  | (14,982 | ) |  |  | (13,335 | ) |
| Net earnings |  | $ | 51,280 |  |  |  | 43,131 |  |  |  | 52,132 |  |  |  | 45,924 |  |

[0001104659-22-087247:8k_2_02:72]
Note 1: Adjusted net earnings of $52.1 million
in YTD Q3 2022 excludes $0.03 per share of after-tax charges associated with the Altanova & Neco acquisition inventory step-up charges
and Corporate acquisition related costs.

[0001104659-22-087247:8k_2_02:73]
Note 2: Adjusted net earnings of $45.9 million
in YTD Q3 2021 excludes $0.10 per share consisting of after-tax charges incurred at Corporate due to management transition and acquisition
costs, an ATM acquisition inventory step-up charge, and charges related to USG (Manta and Morgan Schaffer) facility consolidations, partially
offset by the final settlement from the sale of the Doble Watertown facility.

[0001104659-22-087247:8k_2_02:74]
| EBITDA Reconciliation to Net earnings: |  |  |  |  | Adjusted |  |  | Adjusted |  |
|  |  | YTD Q3 2022 |  |  | YTD Q3 2021 |  |  | YTD Q3 2022 |  |  | YTD Q3 2021 |  |
| Consolidated EBITDA |  | $ | 105,338 |  |  |  | 87,344 |  |  |  | 106,445 |  |  |  | 90,971 |  |
| Less: Depr & Amort |  |  | (36,247 | ) |  |  | (30,259 | ) |  |  | (36,247 | ) |  |  | (30,259 | ) |
| Consolidated EBIT |  |  | 69,091 |  |  |  | 57,085 |  |  |  | 70,198 |  |  |  | 60,712 |  |
| Less: Interest expense |  |  | (3,084 | ) |  |  | (1,453 | ) |  |  | (3,084 | ) |  |  | (1,453 | ) |
| Less: Income tax expense |  |  | (14,727 | ) |  |  | (12,501 | ) |  |  | (14,982 | ) |  |  | (13,335 | ) |
| Net earnings |  | $ | 51,280 |  |  |  | 43,131 |  |  |  | 52,132 |  |  |  | 45,924 |  |

[0001104659-22-087247:8k_2_02:75]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-22-087247:8k_2_02:76]
Condensed Consolidated Balance Sheets (Unaudited)

[0001104659-22-087247:8k_2_02:77]
(Dollars in thousands)

[0001104659-22-087247:8k_2_02:78]
|  |  | June 30, 2022 |  |  | September 30, 2021 |  |
| Assets |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 61,019 |  |  |  | 56,232 |  |
| Accounts receivable, net |  |  | 168,720 |  |  |  | 146,341 |  |
| Contract assets |  |  | 115,840 |  |  |  | 93,771 |  |
| Inventories |  |  | 178,168 |  |  |  | 147,148 |  |
| Other current assets |  |  | 29,718 |  |  |  | 22,662 |  |
| Total current assets |  |  | 553,465 |  |  |  | 466,154 |  |
| Property, plant and equipment, net |  |  | 155,961 |  |  |  | 154,265 |  |
| Intangible assets, net |  |  | 401,337 |  |  |  | 409,250 |  |
| Goodwill |  |  | 503,439 |  |  |  | 504,853 |  |
| Operating lease assets |  |  | 28,922 |  |  |  | 31,846 |  |
| Other assets |  |  | 9,562 |  |  |  | 10,977 |  |
|  |  | $ | 1,652,686 |  |  |  | 1,577,345 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt |  | $ | 20,000 |  |  |  | 20,000 |  |
| Accounts payable |  |  | 70,748 |  |  |  | 56,669 |  |
| Contract liabilities |  |  | 117,863 |  |  |  | 106,045 |  |
| Other current liabilities |  |  | 83,484 |  |  |  | 92,281 |  |
| Total current liabilities |  |  | 292,095 |  |  |  | 274,995 |  |
| Deferred tax liabilities |  |  | 82,580 |  |  |  | 73,560 |  |
| Non-current operating lease liabilities |  |  | 25,209 |  |  |  | 28,032 |  |
| Other liabilities |  |  | 41,920 |  |  |  | 47,062 |  |
| Long-term debt |  |  | 181,000 |  |  |  | 134,000 |  |
| Shareholders' equity |  |  | 1,029,882 |  |  |  | 1,019,696 |  |
|  |  | $ | 1,652,686 |  |  |  | 1,577,345 |  |

[0001104659-22-087247:8k_2_02:79]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-22-087247:8k_2_02:80]
Consolidated Statements of Cash Flows (Unaudited)

[0001104659-22-087247:8k_2_02:81]
(Dollars in thousands)

[0001104659-22-087247:8k_2_02:82]
|  |  | Nine Months Ended June 30, 2022 |  |  | Nine Months Ended June 30, 2021 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 51,280 |  |  |  | 43,131 |  |
| Adjustments to reconcile net earnings to net cash |  |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 36,247 |  |  |  | 30,259 |  |
| Stock compensation expense |  |  | 5,318 |  |  |  | 5,386 |  |
| Changes in assets and liabilities |  |  | (60,172 | ) |  |  | 2,520 |  |
| Gain on sale of building and land |  |  | - |  |  |  | (1,950 | ) |
| Effect of deferred taxes |  |  | 9,020 |  |  |  | (3,946 | ) |
| Net cash provided by operating activities |  |  | 41,693 |  |  |  | 75,400 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Acquisition of business, net of cash acquired |  |  | (15,592 | ) |  |  | (6,684 | ) |
| Capital expenditures |  |  | (25,893 | ) |  |  | (17,887 | ) |
| Additions to capitalized software |  |  | (9,359 | ) |  |  | (6,500 | ) |
| Proceeds from sale of building and land |  |  | - |  |  |  | 1,950 |  |
| Net cash used by investing activities |  |  | (50,844 | ) |  |  | (29,121 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from long-term debt |  |  | 111,000 |  |  |  | 80,000 |  |
| Principal payments on long-term debt and short-term borrowings |  |  | (64,000 | ) |  |  | (94,368 | ) |
| Dividends paid |  |  | (6,219 | ) |  |  | (6,249 | ) |
| Purchases of common stock into treasury |  |  | (19,878 | ) |  |  | - |  |
| Other |  |  | (2,787 | ) |  |  | (1,674 | ) |
| Net cash provided (used) by financing activities |  |  | 18,116 |  |  |  | (22,291 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (4,178 | ) |  |  | 1,811 |  |
| Net increase in cash and cash equivalents |  |  | 4,787 |  |  |  | 25,799 |  |
| Cash and cash equivalents, beginning of period |  |  | 56,232 |  |  |  | 52,560 |  |
| Cash and cash equivalents, end of period |  | $ | 61,019 |  |  |  | 78,359 |  |

[0001104659-22-087247:8k_2_02:83]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-22-087247:8k_2_02:84]
Other Selected Financial Data (Unaudited)

[0001104659-22-087247:8k_2_02:85]
(Dollars in thousands)

[0001104659-22-087247:8k_2_02:86]
| Backlog And Entered Orders - Q3 2022 |  | Aerospace & Defense |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 4/1/22 |  | $ | 396,902 |  |  |  | 116,676 |  |  |  | 157,371 |  |  |  | 670,949 |  |
| Entered Orders |  |  | 110,225 |  |  |  | 74,375 |  |  |  | 70,317 |  |  |  | 254,917 |  |
| Sales |  |  | (92,606 | ) |  |  | (67,201 | ) |  |  | (59,259 | ) |  |  | (219,066 | ) |
| Ending Backlog - 6/30/22 |  | $ | 414,521 |  |  |  | 123,850 |  |  |  | 168,429 |  |  |  | 706,800 |  |
| Backlog And Entered Orders - YTD Q3 2022 |  |  | Aerospace & Defense |  |  |  | USG |  |  |  | Test |  |  |  | Total |  |
| Beginning Backlog - 10/1/21 |  | $ | 367,216 |  |  |  | 91,631 |  |  |  | 133,176 |  |  |  | 592,023 |  |
| Entered Orders |  |  | 294,976 |  |  |  | 227,096 |  |  |  | 193,709 |  |  |  | 715,781 |  |
| Sales |  |  | (247,671 | ) |  |  | (194,877 | ) |  |  | (158,456 | ) |  |  | (601,004 | ) |
| Ending Backlog - 6/30/22 |  | $ | 414,521 |  |  |  | 123,850 |  |  |  | 168,429 |  |  |  | 706,800 |  |

[0001104659-22-087247:8k_2_02:87]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-22-087247:8k_2_02:88]
Reconciliation of Non-GAAP Financial Measures (Unaudited)

[0001104659-22-087247:8k_2_02:89]
| EPS – Adjusted Basis Reconciliation – YTD Q3 2022 |  |  |  |
| EPS – GAAP Basis – YTD Q3 2022 |  | $ | 1.97 |  |
| Adjustments (defined below) |  |  | 0.03 |  |
| EPS – As Adjusted Basis – YTD Q3 2022 |  | $ | 2.00 |  |

[0001104659-22-087247:8k_2_02:90]
Adjustments exclude $0.03 per share consisting
of Altanova & Neco acquisition inventory   step-up charges and Corporate related acquisition costs in the first nine months
of 2022. The $0.03 of EPS adjustments per share consists of $1,107K of pre-tax charges   offset by $255K of tax benefit for net
impact of $852K.

[0001104659-22-087247:8k_2_02:91]
| EPS – Adjusted Basis Reconciliation – Q3 2021 |  |  |  |
| EPS GAAP Basis – Q3 2021 |  | $ | 0.57 |  |
| Adjustments (defined below) |  |  | 0.10 |  |
| EPS – As Adjusted Basis – Q3 2021 |  | $ | 0.67 |  |

[0001104659-22-087247:8k_2_02:92]
Adjustments exclude $0.10 per share consisting of management
transition and   acquisition costs, and USG facility consolidation charges in the third quarter of 2021. The $0.10 of EPS
adjustments per share consists of $3.5 million of pre-tax charges offset by $0.8 million of tax benefit for net impact of $2.7
million.

[0001104659-22-087247:8k_2_02:93]
| EPS – Adjusted Basis Reconciliation – YTD Q3 2021 |  |  |  |
| EPS – GAAP Basis – YTD Q3 2021 |  | $ | 1.65 |  |
| Adjustments (defined below) |  |  | 0.10 |  |
| EPS – As Adjusted Basis – YTD Q3 2021 |  | $ | 1.75 |  |

[0001104659-22-087247:8k_2_02:94]
Adjustments exclude $0.10 per
share consisting of management transition and acquisition costs, USG facility consolidation charges and ATM
inventory step-up charge in the first nine months of 2021. The $0.10 of EPS adjustments
per share consists of $3.6 million of pre-tax charges offset by $0.8 million of tax benefit for net impact
of $2.8 million.

## item 5.02 — body, verbatim

[0001104659-22-087247:8k_body:1]
Item 5.02

[0001104659-22-087247:8k_body:2]
Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements
of Certain Officers

[0001104659-22-087247:8k_body:3]
Changes in Compensation for Non-Employee Directors

[0001104659-22-087247:8k_body:4]
On
August 4, 2022 the Company’s Board of Directors approved certain changes in the compensation program for non-employee directors
which had been proposed by the Human Resources and Compensation Committee based on the Committee’s review of prevailing practices
regarding director compensation. The changes were made pursuant to and consistent with the Company’s Sub-Plan for Compensation of
Non-Employee Directors.

[0001104659-22-087247:8k_body:5]
Beginning with calendar year 2023, the timing and amount of
the non-management directors’ annual compensation will be changed as follows:

[0001104659-22-087247:8k_body:6]
·

[0001104659-22-087247:8k_body:7]
The award and payment dates of the annual Retainer Fee and the additional cash fees payable for service
as Committee Chairs and as Lead Director will be moved from early January to the first NYSE trading day after conclusion of the Company’s
Annual Meeting of Shareholders; and

[0001104659-22-087247:8k_body:8]
·

[0001104659-22-087247:8k_body:9]
The additional annual cash fees payable for service as Committee Chairs will be increased as follows:

[0001104659-22-087247:8k_body:10]
Audit and Finance Committee Chair

[0001104659-22-087247:8k_body:11]
$12,500 (previously $7,000)

[0001104659-22-087247:8k_body:12]
Human Resources and Compensation Committee Chair

[0001104659-22-087247:8k_body:13]
$10,000 (previously $5,000)

[0001104659-22-087247:8k_body:14]
Nominating and Corporate Governance Committee Chair

[0001104659-22-087247:8k_body:15]
$8,000 (previously $5,000)

[0001104659-22-087247:8k_body:16]
The additional annual cash fee for the Lead Director was
not changed.
