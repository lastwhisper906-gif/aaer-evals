# ESE MD&A — 0001410578-22-000098


## mdna

[0001410578-22-000098:mdna:1]
[same as prior period, unchanged from 0001104659-21-102250:mdna:1]

[0001410578-22-000098:mdna:2]
[same as prior period, unchanged from 0001104659-21-102250:mdna:5]

[0001410578-22-000098:mdna:3]
References to the first quarters of 2022 and 2021 represent the three-month periods ended December 31, 2021 and 2020, respectively.

[0001410578-22-000098:mdna:4]
[same as prior period, unchanged from 0001104659-21-102250:mdna:2]

[0001410578-22-000098:mdna:5]
The COVID-19 global pandemic has continued to create significant and unprecedented challenges, and during these highly uncertain times, our top priority remains the health and safety of our employees, customers and suppliers, thereby securing the financial well-being of the Company and supporting business continuity. The economic uncertainty, changes in the propensity for the general public to travel by air, and reductions in demand for commercial aircraft as a result of the COVID-19 pandemic have adversely impacted net sales and operating results in certain of our A&D reporting units. Additionally, the electric utility market has been impacted by reduced domestic electricity consumption related to the pandemic, which in turn impacts utility spending on investments in grid maintenance and testing.

[0001410578-22-000098:mdna:6]
Throughout 2021 and the first quarter of 2022, our Navy, defense aerospace, space and Test segment end-markets have remained solid and now we are beginning to see recovery in our core markets most affected by the pandemic. We are encouraged by the growing strength of our entered orders across the commercial aerospace, electric utility and renewable energy end-markets. While there is still uncertainty as to the timing and pace of recovery in the commercial aerospace and electric utility markets, we have seen these markets begin to stabilize and expect strong growth in the second half of fiscal 2022.

[0001410578-22-000098:mdna:7]
We are also monitoring the impacts of COVID-19 on the fair value of assets. We do not currently anticipate any material asset impairments as a result of the COVID-19 global pandemic. We determined that there was no impairment for the three months ended December 31, 2021. We will continue to monitor the impacts of COVID-19 on the fair value of assets. For further discussion, refer to Management’s Discussion and Analysis contained in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2021.

[0001410578-22-000098:mdna:8]
[same as prior period, unchanged from 0001104659-21-102250:mdna:7]

[0001410578-22-000098:mdna:9]
Sales, net earnings and diluted earnings per share were $177.0 million, $11.5 million and $0.44 per share, respectively, in the first quarter of 2022 compared to $162.7 million, $12.8 million and $0.49 per share, respectively, in the first quarter of 2021.

[0001410578-22-000098:mdna:10]
[same as prior period, unchanged from 0001104659-21-102250:mdna:9]

[0001410578-22-000098:mdna:11]
Net sales increased $14.3 million, or 8.8%, to $177.0 million in the first quarter of 2022 from $162.7 million in the first quarter of 2021. The increase in net sales in the first quarter of 2022 as compared to the first quarter of 2021 was due to an $8.9 million increase in the USG segment, a $3.6 million increase in the Aerospace & Defense segment, and a $1.8 million increase in the Test segment.

[0001410578-22-000098:mdna:12]
[same as prior period, unchanged from 0001104659-21-102250:mdna:11]

[0001410578-22-000098:mdna:13]
Net sales of $70.2 million in the first quarter of 2022 were $3.6 million, or 5.4%, higher than the $66.6 million in the first quarter of 2021. The sales increase in the first quarter of 2022 compared to the first quarter of 2021 was primarily due to an approximately $6.1 million increase in aerospace shipments at PTI and Mayday and a $2.6 million increase in navy sales at Westland, partially offset by a $4.5 million decrease in navy and space sales from VACCO and Globe due to supply chain issues and a $0.6 million decrease in aerospace shipments at Crissair.

[0001410578-22-000098:mdna:14]
[same as prior period, unchanged from 0001104659-21-102250:mdna:14]

[0001410578-22-000098:mdna:15]
Net sales of $63.5 million in the first quarter of 2022 were $8.9 million, or 16.4% higher than the $54.5 million in the first quarter of 2021. The increase in the first quarter of 2022 compared to the first quarter of 2021 was mainly due to the recent acquisitions of Altanova and Phenix which contributed $14.5 million in sales partially offset by lower sales of core Doble products, and a $1.7 million increase in net sales at NRG driven by solar products.

[0001410578-22-000098:mdna:16]
[same as prior period, unchanged from 0001104659-21-102250:mdna:16]

[0001410578-22-000098:mdna:17]
Net sales of $43.3 million in the first quarter of 2022 were $1.8 million, or 4.2%, higher than the $41.5 million in the first quarter of 2021. The increase in the first quarter of 2022 compared to the first quarter of 2021 was primarily due to $5.3 million of higher sales from the segment’s Asian operations partially offset by $3.5 million of lower sales from the segment’s U.S. and European operations, both due to the timing of test and measurement chamber projects.

[0001410578-22-000098:mdna:18]
[same as prior period, unchanged from 0001104659-21-102250:mdna:18]

[0001410578-22-000098:mdna:19]
Backlog was $639.4 million at December 31, 2021 compared with $592.0 million at September 30, 2021. The Company received new orders totaling $224.4 million in the first quarter of 2022 compared to $157.6 million in the first quarter of 2021. Of the new orders received in the first quarter of 2022, $90.2 million related to Aerospace & Defense products, $66.2 million related to USG products, and $68.0 million related to Test products. Of the new orders received in the first quarter of 2021, $65.4 million related to Aerospace & Defense products, $48.7 million related to USG products, and $43.5 million related to Test products.

[0001410578-22-000098:mdna:20]
[same as prior period, unchanged from 0001104659-21-102250:mdna:21]

[0001410578-22-000098:mdna:21]
Selling, general and administrative (SG&A) expenses were $46.6 million (26.3% of net sales) for the first quarter of 2022, compared with $41.0 million (25.2% of net sales) for the first quarter of 2021. The increase in SG&A in the first quarter of 2022 compared to the first quarter of 2021 was mainly due to higher expenses at Doble as a result of the SG&A contribution from the Altanova and Phenix acquisitions and higher expenses at Corporate due to acquisition related costs and professional fees.

[0001410578-22-000098:mdna:22]
[same as prior period, unchanged from 0001104659-21-102250:mdna:23]

[0001410578-22-000098:mdna:23]
Amortization of intangible assets was $6.5 million and $4.9 million for the first quarter of 2022 and 2021, respectively. Amortization expenses consist of amortization of acquired intangible assets from acquisitions and other identifiable intangible assets (primarily software). The increase in amortization expense in the first quarter of 2022 compared to the first quarter of 2021 was mainly due to the Company’s recent acquisitions of Phenix, Altanova and NEco.

[0001410578-22-000098:mdna:24]
OTHER EXPENSES, NET

[0001410578-22-000098:mdna:25]
Other expenses, net, were $0.1 million in the first quarter of 2022 compared to other expenses, net, of $0.1 million in the first quarter of 2021. There were no individually significant items in other expenses (income), net, in the first quarter of 2022. The principal component of other expenses, net, in the first quarter of 2021 included approximately $0.7 million of facility consolidation charges for the Doble Manta facility, including employee severance and lease termination charges.

[0001410578-22-000098:mdna:26]
[same as prior period, unchanged from 0001104659-21-102250:mdna:28]

[0001410578-22-000098:mdna:27]
The Company evaluates the performance of its operating segments based on EBIT, and provides EBIT on a consolidated basis, which is a non-GAAP financial measure. Please refer to the discussion of non-GAAP financial measures in Note 7 to the Consolidated Financial Statements, above. EBIT was $15.6 million (8.8% of net sales) for the first quarter of 2022 compared to $17.1 million (10.5% of net sales) for the first quarter of 2021.

[0001410578-22-000098:mdna:28]
The following table presents a reconciliation of EBIT to a GAAP financial measure:

[0001410578-22-000098:mdna:29]
| ​ | ​ | Three Months Ended |
| ​ | ​ | December 31, |
| (In thousands) |  | 2021 | ​ | 2020 |
| Net earnings | ​ | $ | 11,524 | ​ | ​ | 12,818 |
| Plus: Interest expense, net | ​ |  | 733 |  | ​ | 541 |
| Plus: Income tax expense | ​ |  | 3,313 |  |  | 3,722 |
| Consolidated EBIT | ​ | $ | 15,570 |  | ​ | 17,081 |

[0001410578-22-000098:mdna:30]
– Aerospace & Defense

[0001410578-22-000098:mdna:31]
EBIT was $10.0 million (14.2% of net sales) in the first quarter of 2022 compared to $8.3 million (12.4% of net sales) in the first quarter of 2021. The increase in EBIT in the first quarter of 2022 compared to the first quarter of 2021 was mainly due to higher sales volumes at PTI, Westland and Mayday partially offset a decrease in EBIT at VACCO, Crissair and Globe due to the lower sales volumes mentioned above. In addition, EBIT in the first quarter of 2022 was negatively impacted by a $0.1 million inventory step-up charge related to the NEco acquisition.

[0001410578-22-000098:mdna:32]
– USG

[0001410578-22-000098:mdna:33]
EBIT was $13.4 million (21.1% of net sales) in the first quarter of 2022 compared to $12.7 million (23.3% of net sales) in the first quarter of 2021. The increase in EBIT in the first quarter of 2022 compared to the first quarter of 2021 was mainly due to the higher sales volumes in the first quarter of 2022. EBIT in the first quarter of 2022 was negatively impacted by approximately $0.5 million of inventory step-up charges related to the Altanova acquisition.

[0001410578-22-000098:mdna:34]
– Test

[0001410578-22-000098:mdna:35]
EBIT was $4.0 million (9.2% of net sales) in the first quarter of 2022 compared to $5.3 million (12.9% of net sales) in the first quarter of 2021. The decrease in EBIT in the first quarter of 2022 compared to the first quarter of 2021 was primarily due to lower sales volumes from the segment’s U.S. and European operations and higher material and labor costs which have negatively impacted EBIT.

[0001410578-22-000098:mdna:36]
– Corporate

[0001410578-22-000098:mdna:37]
Corporate costs included in EBIT were $11.7 million and $9.3 million in the first quarter of 2022 and 2021, respectively. The increase in Corporate costs in the first quarter of 2022 compared to the first quarter of 2021 was mainly due to the increase in amortization expense of acquired intangible assets related to the Company’s recent acquisitions of Phenix, Altanova and NEco.

[0001410578-22-000098:mdna:38]
[same as prior period, unchanged from 0001104659-21-102250:mdna:40]

[0001410578-22-000098:mdna:39]
Interest expense was $0.7 million and $0.5 million in the first quarter of 2022 and 2021, respectively. The increase in interest expense in the first quarter of 2022 as compared to the first quarter of 2021 was mainly due to higher average outstanding borrowings ($183 million compared to $70 million).

[0001410578-22-000098:mdna:40]
[same as prior period, unchanged from 0001104659-21-102250:mdna:42]

[0001410578-22-000098:mdna:41]
The effective income tax rate was 22.3% in the first quarter of 2022 compared to 22.5% in the first quarter of 2021. Income tax expense in the first quarter of 2022 was favorably impacted by excess tax benefit related to the vesting of share based compensation, decreasing the effective tax rate for the quarter by 1.7%.

[0001410578-22-000098:mdna:42]
[same as prior period, unchanged from 0001104659-21-102250:mdna:45]

[0001410578-22-000098:mdna:43]
The Company’s overall financial position and liquidity remain strong. Working capital from continuing operations (current assets less current liabilities) increased to $218.9 million at December 31, 2021 from $188.4 million at September 30, 2021. Inventories increased by $17.9 million during this period mainly due to an $8.8 million increase within the Test segment, a $4.6 million increase within the Aerospace & Defense segment and a $4.5 million increase within the USG segment resulting primarily from the timing of receipt of raw materials to meet anticipated demand and an increase in work in process inventories due to timing of manufacturing existing orders.

[0001410578-22-000098:mdna:44]
Net cash provided by operating activities was $1.9 million and $24.8 million in the first quarters of 2022 and 2021, respectively. The decrease in net cash provided by operating activities in the first quarter of 2022 as compared to the first quarter of 2021 was driven by higher working capital requirements.

[0001410578-22-000098:mdna:45]
Capital expenditures were $14.1 million and $6.0 million in the first quarters of 2022 and 2021, respectively. The increase in the first quarter of 2022 was mainly due to the purchase of the NRG building of approximately $10 million in the first quarter of 2022. In addition, the Company incurred expenditures for capitalized software of approximately $2.0 million and $1.6 million in the first quarters of 2022 and 2021, respectively.

[0001410578-22-000098:mdna:46]
Acquisition

[0001410578-22-000098:mdna:47]
On November 4, 2021, the Company acquired Networks Electronic Company, LLC (NEco) for a purchase price of approximately $15.2 million, net of cash acquired. NEco, based in Chatsworth, California, provides miniature electro-explosive devices utilized in mission-critical defense and aerospace applications. Since the date of acquisition, the operating results for the NEco business have been included as part of PTI in the A&D segment.

[0001410578-22-000098:mdna:48]
Credit Facility

[0001410578-22-000098:mdna:49]
At December 31, 2021, the Company had approximately $291 million available to borrow under its bank credit facility, a $250 million increase option subject to lender approval, and $55.7 million cash on hand. At December 31, 2021, the Company had $198 million of outstanding borrowings under the credit facility and short-term borrowings in addition to outstanding letters of credit of $10.7 million. Cash flow from operations and borrowings under the Company’s credit facility are expected to meet the Company’s capital requirements and operational needs for the foreseeable future. The Company’s ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.

[0001410578-22-000098:mdna:50]
Share Repurchases

[0001410578-22-000098:mdna:51]
During the first quarter of 2022, the Company repurchased approximately 116,000 shares for $10.0 million. For further information on the share repurchases during the first quarter of 2022, see Part II, Item 2 of this Report.

[0001410578-22-000098:mdna:52]
[same as prior period, unchanged from 0001104659-21-102250:mdna:54]

[0001410578-22-000098:mdna:53]
A dividend of $0.08 per share, totaling $2.1 million, was paid on October 15, 2021 to stockholders of record as of October 1, 2021. Subsequent to December 31, 2021, a quarterly dividend of $0.08 per share, totaling $2.1 million, was paid on January 19, 2022 to stockholders of record as of January 4, 2022.

[0001410578-22-000098:mdna:54]
[same as prior period, unchanged from 0001104659-21-102250:mdna:58]

[0001410578-22-000098:mdna:55]
Management has evaluated the accounting policies used in the preparation of the Company’s financial statements and related notes and believes those policies to be reasonable and appropriate. Certain of these accounting policies require the application of significant judgment by Management in selecting appropriate assumptions for calculating financial estimates. By their nature, these judgments are subject to an inherent degree of uncertainty. These judgments are based on historical experience, trends in the industry, information provided by customers and information available from other outside sources, as appropriate. The most significant areas involving Management judgments and estimates may be found in the Critical Accounting Policies section of Management’s Discussion and Analysis and in Note 1 to the Consolidated Financial Statements contained in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2021.

[0001410578-22-000098:mdna:56]
[same as prior period, unchanged from 0001104659-21-102250:mdna:60]

[0001410578-22-000098:mdna:57]
Contingencies

[0001410578-22-000098:mdna:58]
As a normal incident of the business in which the Company is engaged, various claims, charges and litigation are asserted or commenced against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. In the opinion of Management, the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company, are adequately reserved, are covered by insurance, or would not have a material adverse effect on the Company’s results from operations, capital expenditures, or competitive position.

[0001410578-22-000098:mdna:59]
[same as prior period, unchanged from 0001104659-21-102250:mdna:63]

[0001410578-22-000098:mdna:60]
Investors are cautioned that such statements are only predictions and speak only as of the date of this Form 10-Q, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment, including but not limited to those described in Item 1A, “Risk Factors,” of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2021, and the following: the continuing impact of the COVID-19 pandemic including the effects of known or unknown COVID-19 variants, labor shortages, facility closures, shelter in place policies or quarantines, material shortages, transportation delays, termination or delays of Company contracts and the inability of our suppliers or customers to perform; the impacts of natural disasters on the Company’s operations and those of the Company’s customers and suppliers; the timing and content of future contract awards or customer orders; the appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer contracts or orders; weakening of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties; the availability of selected acquisitions; delivery delays or defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability of certain raw materials; labor disputes; changes in U.S. tax laws and regulations; other changes in laws and regulations including but not limited to changes in accounting standards and foreign taxation; changes in interest rates; costs relating to environmental matters arising from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the integration of recently acquired businesses.
