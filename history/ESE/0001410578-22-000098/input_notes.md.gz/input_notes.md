# ESE notes — 0001410578-22-000098


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001410578-22-000098:notes:1]
[same as prior period, unchanged from 0001104659-21-102250:notes:1]

[0001410578-22-000098:notes:2]
The accompanying consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP).

[0001410578-22-000098:notes:3]
The Company’s results for the three-month period ended December 31, 2021 are not necessarily indicative of the results for the entire 2022 fiscal year. References to the first quarters of 2022 and 2021 represent the fiscal quarters ended December 31, 2021 and 2020, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:EarningsPerShareTextBlock

[0001410578-22-000098:notes:4]
[same as prior period, unchanged from 0001104659-21-102250:notes:4]

[0001410578-22-000098:notes:5]
Basic EPS is calculated using the weighted average number of common shares outstanding during the period. Diluted EPS is calculated using the weighted average number of common shares outstanding during the period plus shares issuable upon the assumed exercise of dilutive common share options and vesting of performance-accelerated restricted shares (restricted shares) by using the treasury stock method. The number of shares used in the calculation of earnings per share for each period presented is as follows (in thousands):

[0001410578-22-000098:notes:6]
| ​ |  | Three Months |
| ​ | ​ | Ended December 31, |
| ​ | ​ | 2021 |  | 2020 |
| Weighted Average Shares Outstanding — Basic |  | 26,060 |  | 26,038 |
| Dilutive Restricted Shares | ​ | 82 | ​ | 144 |
| Adjusted Shares — Diluted |  | 26,142 |  | 26,182 |

[0001410578-22-000098:notes:7]
| 1. | ​ |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001410578-22-000098:notes:8]
3.    ACQUISITION

[0001410578-22-000098:notes:9]
On November 4, 2021, the Company acquired Networks Electronic Company, LLC (NEco) for a purchase price of approximately $15.2 million, net of cash acquired. NEco, based in Chatsworth, California, provides miniature electro-explosive devices utilized in mission-critical defense and aerospace applications. Since the date of acquisition, the operating results for the NEco business have been included as part of PTI in the A&D segment. The acquisition date fair value of the assets acquired and liabilities assumed primarily were as follows: approximately $0.6 million of accounts receivable, $1.5 million of inventory, $0.2 million of property, plant and equipment, $0.7 million of accounts payable and accrued expenses, $8.1 million of identifiable intangible assets, mainly consisting of customer relationships totaling $6.3 million. The acquired goodwill of $5.7 million related to excess value associated with opportunities to expand the services and products that the Company can offer to its customers. The Company anticipates that the goodwill will be deductible for tax purposes.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001410578-22-000098:notes:10]
4.    SHARE-BASED COMPENSATION

[0001410578-22-000098:notes:11]
The Company provides compensation benefits to certain key employees under several share-based plans providing for performance-accelerated and/or time-vested restricted stock unit awards, and to non-employee directors under a separate compensation plan for non-employee directors.

[0001410578-22-000098:notes:12]
Performance-Accelerated Restricted Stock Unit (PARS) Awards and Time-Vested Restricted Stock Unit (RSU) Awards

[0001410578-22-000098:notes:13]
Compensation expense related to the PARS/RSU awards was $1.4 million and $1.1 million for the three-month periods ended December 31, 2021 and 2020, respectively. There were 208,354 non-vested shares outstanding as of December 31, 2021.

[0001410578-22-000098:notes:14]
[same as prior period, unchanged from 0001104659-21-102250:notes:11]

[0001410578-22-000098:notes:15]
Compensation expense related to the non-employee director grants was $0.3 million and $0.3 million for the three-month periods ended December 31, 2021 and 2020, respectively.

[0001410578-22-000098:notes:16]
The total share-based compensation cost that has been recognized in the results of operations and included within selling, general and administrative expenses (SG&A) was $1.7 million and $1.4 million for the three-month periods ended December 31, 2021 and 2020, respectively. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $0.4 million and $0.3 million for the three-month periods ended December 31, 2021 and 2020, respectively. As of December 31, 2021, there was $12.2 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a remaining weighted-average period of 2.4 years.


## us-gaap:InventoryDisclosureTextBlock

[0001410578-22-000098:notes:17]
5.    INVENTORIES

[0001410578-22-000098:notes:18]
[same as prior period, unchanged from 0001104659-21-102250:notes:16]

[0001410578-22-000098:notes:19]
| ​ |  | December 31, |  | September 30, |
| (In thousands) |  | 2021 |  | 2021 |
| Finished goods | ​ | $ | 34,629 |  | 32,998 |
| Work in process | ​ |  | 42,485 |  | 34,201 |
| Raw materials | ​ |  | 87,907 |  | 79,949 |
| Total inventories, net | ​ | $ | 165,021 |  | 147,148 |

[0001410578-22-000098:notes:20]
| 2. | ​ |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001410578-22-000098:notes:21]
| 6. | GOODWILL AND OTHER INTANGIBLE ASSETS |

[0001410578-22-000098:notes:22]
Included on the Company’s Consolidated Balance Sheets at December 31, 2021 and September 30, 2021 are the following intangible assets gross carrying amounts and accumulated amortization from continuing operations:

[0001410578-22-000098:notes:23]
| ​ |  | December 31, |  | September 30, |
| (Dollars in thousands) |  | 2021 |  | 2021 |
| Goodwill | ​ | $ | 509,268 |  | 504,853 |
| Intangible assets with determinable lives: | ​ |  | ​ | ​ | ​ |
| Patents | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 2,170 | ​ | 2,131 |
| Less: accumulated amortization | ​ |  | 1,000 | ​ | 972 |
| Net | ​ | $ | 1,170 | ​ | 1,159 |
| Capitalized software | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 95,629 | ​ | 93,671 |
| Less: accumulated amortization | ​ |  | 65,366 | ​ | 63,740 |
| Net | ​ | $ | 30,263 | ​ | 29,931 |
| Customer relationships | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 293,819 | ​ | 288,530 |
| Less: accumulated amortization | ​ |  | 84,893 | ​ | 80,882 |
| Net | ​ | $ | 208,926 | ​ | 207,648 |
| Other | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 14,663 | ​ | 13,080 |
| Less: accumulated amortization | ​ |  | 5,100 | ​ | 4,301 |
| Net | ​ | $ | 9,563 | ​ | 8,779 |
| Intangible assets with indefinite lives: | ​ |  | ​ | ​ | ​ |
| Trade names | ​ | $ | 161,757 | ​ | 161,733 |

[0001410578-22-000098:notes:24]
The changes in the carrying amount of goodwill attributable to each business segment for the three months ended December 31, 2021 is as follows:

[0001410578-22-000098:notes:25]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | Aerospace | ​ | ​ |
| (Dollars in millions) |  | USG | ​ | Test |  | & Defense |  | Total |
| Balance as of September 30, 2021 | ​ | $ | 366.5 |  | ​ | 34.1 |  | 104.3 |  | 504.9 |
| Acquisition activity and adjustments | ​ | ​ | 0.2 | ​ | ​ | — | ​ | 5.7 | ​ | 5.9 |
| Foreign currency translation | ​ | ​ | (1.5) | ​ | ​ | — | ​ | — | ​ | (1.5) |
| Balance as of December 31, 2021 | ​ | $ | 365.2 | ​ | ​ | 34.1 | ​ | 110.0 | ​ | 509.3 |

[0001410578-22-000098:notes:26]
| 3. | ​ |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001410578-22-000098:notes:27]
7.    BUSINESS SEGMENT INFORMATION

[0001410578-22-000098:notes:28]
The Company is organized based on the products and services that it offers and classifies its business operations in three reportable segments for financial reporting purposes: Aerospace & Defense (A&D), Utility Solutions Group (USG) and RF Shielding and Test (Test). The A&D segment’s operations consist of PTI Technologies Inc. (PTI), VACCO Industries (VACCO), Crissair, Inc. (Crissair), Mayday Manufacturing Co. (Mayday), Westland Technologies, Inc. (Westland) and Globe Composite Solutions, LLC (Globe). The companies within this segment primarily design and manufacture specialty filtration, fluid control and naval products, including hydraulic filter elements and fluid control devices used in aerospace and defense applications; unique filter mechanisms used in micro-propulsion devices for satellites, custom designed filters for manned aircraft and submarines, products and systems to reduce vibration and/or acoustic signatures and otherwise reduce or obscure a vessel’s signature, and other communications, sealing, surface control and hydrodynamic related applications to enhance U.S. Navy maritime survivability; precision-tolerance machined components for the aerospace and defense industry; and metal processing services.

[0001410578-22-000098:notes:29]
The USG segment’s operations consist primarily of Doble Engineering Company and related subsidiaries including Morgan Schaffer and Altanova (collectively, Doble), and NRG Systems, Inc. (NRG). Doble is an industry leader in the development, manufacture and delivery of diagnostic testing and data management solutions that enable electric power grid operators to assess the integrity of high voltage power delivery equipment. It combines three core elements for customers – diagnostic test and condition monitoring instruments, expert consulting, and testing services – and provides access to its large reserve of related empirical knowledge. NRG is a global market leader in the design and manufacture of decision support tools for the renewable energy industry, primarily wind and solar.

[0001410578-22-000098:notes:30]
The Test segment’s operations consist primarily of ETS-Lindgren Inc. and related subsidiaries (ETS-Lindgren). ETS-Lindgren is an industry leader in designing and manufacturing products which provide its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy. ETS-Lindgren also manufactures radio frequency shielding products and components used by manufacturers of medical equipment, communications systems, electronic products, and shielded rooms for high-security data processing and secure communication.

[0001410578-22-000098:notes:31]
[same as prior period, unchanged from 0001104659-21-102250:notes:26]

[0001410578-22-000098:notes:32]
| ​ | ​ | Three Months |
| ​ | ​ | Ended December 31, |
| (In thousands) |  | 2021 |  | 2020 |
| NET SALES | ​ | ​ |  | ​ |  |
| Aerospace & Defense | ​ | $ | 70,244 | ​ | 66,616 |
| USG | ​ | ​ | 63,485 | ​ | 54,540 |
| Test | ​ | ​ | 43,281 | ​ | 41,518 |
| Consolidated totals | ​ | $ | 177,010 | ​ | 162,674 |
| EBIT | ​ | ​ | ​ | ​ | ​ |
| Aerospace & Defense | ​ | $ | 9,955 | ​ | 8,260 |
| USG | ​ | ​ | 13,391 | ​ | 12,731 |
| Test | ​ | ​ | 3,965 | ​ | 5,342 |
| Corporate (loss) | ​ | ​ | (11,741) | ​ | (9,252) |
| Consolidated EBIT | ​ | ​ | 15,570 | ​ | 17,081 |
| Less: Interest expense | ​ | ​ | (733) | ​ | (541) |
| Earnings before income taxes | ​ | $ | 14,837 | ​ | 16,540 |

[0001410578-22-000098:notes:33]
[same as prior period, unchanged from 0001104659-21-102250:notes:28]

[0001410578-22-000098:notes:34]
The financial measure “EBIT” is presented in the above table and elsewhere in this Report. EBIT on a consolidated basis is a non-GAAP financial measure. Management believes that EBIT is useful in assessing the operational profitability of the Company’s business segments because it excludes interest and taxes, which are generally accounted for across the entire Company on a consolidated basis. EBIT is also one of the measures used by management in determining resource allocations within the Company as well as incentive compensation. A reconciliation of EBIT to net earnings from continuing operations is set forth in Item 2, Management’s Discussion and Analysis of Financial Condition and Results of Operations – EBIT.

[0001410578-22-000098:notes:35]
[same as prior period, unchanged from 0001104659-21-102250:notes:30]


## us-gaap:DebtDisclosureTextBlock

[0001410578-22-000098:notes:36]
8.    DEBT

[0001410578-22-000098:notes:37]
The Company’s debt is summarized as follows:

[0001410578-22-000098:notes:38]
| ​ |  | December 31, | ​ | September 30, |
| (In thousands) |  | 2021 |  | 2021 |
| Total borrowings | ​ | $ | 198,000 |  | 154,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 178,000 |  | 134,000 |

[0001410578-22-000098:notes:39]
The Credit Facility includes a $500 million revolving line of credit, as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024.

[0001410578-22-000098:notes:40]
At December 31, 2021, the Company had approximately $291 million available to borrow under the Credit Facility, plus the $250 million increase option, in addition to $55.7 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of December 31, 2021, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $10.7 million at December 31, 2021.

[0001410578-22-000098:notes:41]
Interest on borrowings under the Credit Facility is calculated at a spread over either the New York Federal Reserve Bank Rate, the prime rate, or the London Interbank Offered Rate (LIBOR), depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The Credit Facility is secured by the unlimited guaranty of the Company’s direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of its direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 1.17% and 1.45% for the three-month periods ending December 31, 2021 and 2020, respectively. As of December 31, 2021, the Company was in compliance with all covenants.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001410578-22-000098:notes:42]
9.    INCOME TAX EXPENSE

[0001410578-22-000098:notes:43]
The first quarter 2022 effective income tax rate was 22.3% compared to 22.5% in the first quarter of 2021. Income tax expense in the first quarter of 2022 was favorably impacted by excess tax benefit related to the vesting of share based compensation, decreasing the effective tax rate for the quarter by 1.7%.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001410578-22-000098:notes:44]
10.  SHAREHOLDERS’ EQUITY

[0001410578-22-000098:notes:45]
The change in shareholders’ equity for the first three months ended December 31, 2021 and 2020 is shown below (in thousands):

[0001410578-22-000098:notes:46]
| ​ | ​ | Three Months Ended December 31, |
| ​ |  | 2021 |  | 2020 |
| Common stock | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | $ | 307 | ​ | 306 |
| Stock plans | ​ | ​ | — | ​ | — |
| Ending balance | ​ | ​ | 307 | ​ | 306 |
| Additional paid-in-capital | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | 297,644 | ​ | 293,682 |
| Stock plans | ​ | ​ | (1,367) | ​ | 1,053 |
| Ending balance | ​ | ​ | 296,277 | ​ | 294,735 |
| Retained earnings | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | 830,989 | ​ | 775,829 |
| Net earnings common stockholders | ​ | ​ | 11,524 | ​ | 12,818 |
| Dividends paid | ​ | ​ | (2,079) | ​ | (2,084) |
| Ending balance | ​ | ​ | 840,434 | ​ | 786,563 |
| Accumulated other comprehensive income (loss) | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | (2,161) | ​ | (3,657) |
| Foreign currency translation | ​ | ​ | (2,500) | ​ | 5,349 |
| Ending balance | ​ | ​ | (4,661) | ​ | 1,692 |
| Treasury stock | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | (107,083) | ​ | (107,134) |
| Share repurchases | ​ | ​ | (9,997) | ​ | — |
| Ending balance | ​ | ​ | (117,080) | ​ | (107,134) |
| Total equity | ​ | $ | 1,015,277 | ​ | 976,162 |


## us-gaap:FairValueDisclosuresTextBlock

[0001410578-22-000098:notes:47]
11.  FAIR VALUE MEASUREMENTS

[0001410578-22-000098:notes:48]
[same as prior period, unchanged from 0001104659-21-102250:notes:44]

[0001410578-22-000098:notes:49]
[same as prior period, unchanged from 0001104659-21-102250:notes:45]

[0001410578-22-000098:notes:50]
[same as prior period, unchanged from 0001104659-21-102250:notes:46]

[0001410578-22-000098:notes:51]
[same as prior period, unchanged from 0001104659-21-102250:notes:47]

[0001410578-22-000098:notes:52]
[same as prior period, unchanged from 0001104659-21-102250:notes:48]

[0001410578-22-000098:notes:53]
The Company has estimated the fair value of its financial instruments as of December 31, 2021 and September 30, 2021 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001410578-22-000098:notes:54]
[same as prior period, unchanged from 0001104659-21-102250:notes:50]

[0001410578-22-000098:notes:55]
The Company’s forward contracts and interest rate swaps are classified within Level 2 of the valuation hierarchy in accordance with FASB Accounting Standards Codification (ASC) 825, and are immaterial.

[0001410578-22-000098:notes:56]
[same as prior period, unchanged from 0001104659-21-102250:notes:54]

[0001410578-22-000098:notes:57]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during the three-month period ended December 31, 2021.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001410578-22-000098:notes:58]
12.  REVENUES

[0001410578-22-000098:notes:59]
[same as prior period, unchanged from 0001104659-21-102250:notes:57]

[0001410578-22-000098:notes:60]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2021 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within each reportable segment.

[0001410578-22-000098:notes:61]
| ​ | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total |  |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 28,075 | ​ | $ | 62,842 | ​ | $ | 41,037 | ​ | $ | 131,954 | ​ |
| U.S. Government | ​ |  | 42,169 | ​ | ​ | 643 | ​ | ​ | 2,244 | ​ |  | 45,056 | ​ |
| Total revenues | ​ | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 | ​ |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| United States | ​ | $ | 60,687 | ​ | $ | 38,741 | ​ | $ | 22,975 | ​ | $ | 122,403 | ​ |
| International | ​ |  | 9,557 | ​ | ​ | 24,744 | ​ | ​ | 20,306 | ​ |  | 54,607 | ​ |
| Total revenues | ​ | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 28,558 | ​ | $ | 50,835 | ​ | $ | 12,821 | ​ | $ | 92,214 | ​ |
| Over time | ​ |  | 41,686 | ​ | ​ | 12,650 | ​ | ​ | 30,460 | ​ |  | 84,796 | ​ |
| Total revenues | ​ | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 | ​ |

[0001410578-22-000098:notes:62]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2020 are presented in the table below:

[0001410578-22-000098:notes:63]
| ​ | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 27,604 | ​ | $ | 53,864 | ​ | $ | 36,722 | ​ | $ | 118,190 |
| U.S. Government | ​ |  | 39,012 | ​ |  | 676 | ​ |  | 4,796 | ​ |  | 44,484 |
| Total revenues | ​ | $ | 66,616 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,674 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 57,538 | ​ | $ | 37,045 | ​ | $ | 23,266 | ​ | $ | 117,849 |
| International | ​ |  | 9,078 | ​ |  | 17,495 | ​ |  | 18,252 | ​ |  | 44,825 |
| Total revenues | ​ | $ | 66,616 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,674 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 26,946 | ​ | $ | 42,367 | ​ | $ | 8,868 | ​ | $ | 78,181 |
| Over time | ​ |  | 39,670 | ​ |  | 12,173 | ​ |  | 32,650 | ​ |  | 84,493 |
| Total revenues | ​ | $ | 66,616 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,674 |

[0001410578-22-000098:notes:64]
Revenue Recognition

[0001410578-22-000098:notes:65]
Payment terms with our customers vary by the type and location of the customer and the products or services offered. Arrangements with customers that include payment terms extending beyond one year are not significant. The transaction price for these contracts reflects our estimate of returns and discounts, which are based on historical, current and forecasted information to determine the expected amount to which we will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation. Under the typical payment terms of our long term fixed price contracts, the customer pays us either performance-based or progress payments. Performance-based payments represent interim payments based on quantifiable measures of performance or on the achievement of specified events or milestones. Progress payments are interim payments of costs incurred as the work progresses.

[0001410578-22-000098:notes:66]
For our overtime revenue recognized using the output method of costs incurred, contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to one or more years, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change. In addition, in the USG segment, we recognize revenue as a series of distinct services based on each day of providing services (straight-line over the contract term) for certain of our USG segment contracts. Under the typical payment terms of our service contracts, the customer pays us in advance of when services are performed. In addition, in the Test segment, we use milestones to measure progress for our Test segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts.

[0001410578-22-000098:notes:67]
[same as prior period, unchanged from 0001104659-21-102250:notes:65]

[0001410578-22-000098:notes:68]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At December 31, 2021, the Company had $639.4 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 77% in the next twelve months.

[0001410578-22-000098:notes:69]
Contract assets and liabilities

[0001410578-22-000098:notes:70]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred. At December 31, 2021, contract assets and liabilities totaled $100.9 million and $111.6 million, respectively. During the first quarter of 2022, the Company recognized approximately $29 million in revenues that were included in the contract liabilities balance at September 30, 2021. The increase in net contract assets in the first quarter of 2022 was due to revenue being recognized for performance completed during the period that exceeded customer billings. Other factors that impacted the change in net contract liabilities were immaterial. At October 1, 2020, contract assets and liabilities totaled $94.3 million and $100.6 million, respectively.


## ese:OperatingAndFinancingLeasesOfLesseeDisclosureTextBlock

[0001410578-22-000098:notes:71]
13.  LEASES

[0001410578-22-000098:notes:72]
The Company determines at lease inception whether an arrangement that provides control over the use of an asset is a lease. The Company recognizes at lease commencement a right-of-use (ROU) asset and lease liability based on the present value of the future lease payments over the lease term. The Company has elected not to recognize a ROU asset and lease liability for leases with terms of 12 months or less. Certain of the Company’s leases include options to extend the term of the lease for up to 20 years. When it is reasonably certain that the Company will exercise the option, Management includes the impact of the option in the lease term for purposes of determining total future lease payments. As most of the Company’s lease agreements do not explicitly state the discount rate implicit in the lease, Management uses the Company’s incremental borrowing rate on the commencement date to calculate the present value of future payments based on the tenor of each arrangement.

[0001410578-22-000098:notes:73]
The Company’s leases for real estate commonly include escalating payments. These variable lease payments are included in the calculation of the ROU asset and lease liability. In addition to the present value of the future lease payments, the calculation of the ROU asset also includes any deferred rent, lease pre-payments and initial direct costs of obtaining the lease.

[0001410578-22-000098:notes:74]
In addition to the base rent, real estate leases typically contain provisions for common-area maintenance and other similar services, which are considered non-lease components for accounting purposes. Non-lease components are excluded from ROU assets and lease liabilities and expensed as incurred.

[0001410578-22-000098:notes:75]
The Company’s leases are for office space, manufacturing facilities, and machinery and equipment.

[0001410578-22-000098:notes:76]
The components of lease costs are shown below:

[0001410578-22-000098:notes:77]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended |
| ​ | ​ | December 31, | ​ | December 31, |
| (Dollars in thousands) |  | 2021 |  | 2020 |
| Finance lease cost | ​ | ​ |  | ​ | ​ |  |
| Amortization of right-of-use assets | ​ | $ | 607 | ​ | ​ | 492 |
| Interest on lease liabilities | ​ |  | 302 | ​ |  | 313 |
| Operating lease cost | ​ |  | 1,561 | ​ |  | 1,452 |
| Total lease costs | ​ | $ | 2,470 | ​ | ​ | 2,257 |

[0001410578-22-000098:notes:78]
Additional information related to leases are shown below:

[0001410578-22-000098:notes:79]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended | ​ |
| ​ | ​ | December 31, | ​ | December 31, | ​ |
| (Dollars in thousands) |  | 2021 |  | 2020 | ​ |
| Cash paid for amounts included in the measurement of lease liabilities | ​ | ​ |  | ​ | ​ |  | ​ |
| Operating cash flows from operating leases | ​ | $ | 1,503 | ​ | ​ | 1,425 | ​ |
| Operating cash flows from finance leases | ​ |  | 248 | ​ |  | 313 | ​ |
| Financing cash flows from finance leases | ​ |  | 301 | ​ |  | 417 | ​ |
| Right-of-use assets obtained in exchange for lease liabilities | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Operating leases | ​ | $ | 901 | ​ | ​ | — | ​ |
| Weighted-average remaining lease term | ​ |  | ​ | ​ |  | ​ | ​ |
| Operating leases | ​ |  | 9.9 | years |  | 5.9 | years |
| Finance leases | ​ |  | 12.7 | years |  | 12.3 | years |
| Weighted-average discount rate | ​ |  | ​ | ​ |  | ​ | ​ |
| Operating leases | ​ |  | 3.12 | % |  | 3.10 | % |
| Finance leases | ​ |  | 4.58 | % |  | 4.30 | % |

[0001410578-22-000098:notes:80]
The following is a reconciliation of future undiscounted cash flows to the operating and finance lease liabilities, and the related ROU assets, presented on the Consolidated Balance Sheet on December 31, 2021:

[0001410578-22-000098:notes:81]
| (Dollars in thousands) | ​ | Operating |  | Finance |
| Years Ending September 30: |  | Leases |  | Leases |
| 2022 (excluding the three months ended December 31, 2021) | ​ | $ | 4,313 |  | 1,599 |
| 2023 | ​ |  | 5,094 |  | 2,189 |
| 2024 | ​ |  | 4,136 |  | 2,248 |
| 2025 | ​ |  | 3,640 |  | 2,304 |
| 2026 and thereafter | ​ |  | 19,246 |  | 21,649 |
| Total minimum lease payments | ​ |  | 36,429 |  | 29,989 |
| Less: amounts representing interest | ​ |  | 5,374 |  | 7,915 |
| Present value of net minimum lease payments | ​ | $ | 31,055 |  | 22,074 |
| Less: current portion of lease obligations | ​ |  | 4,346 |  | 1,250 |
| Non-current portion of lease obligations | ​ | $ | 26,709 |  | 20,824 |
| ROU assets | ​ | $ | 31,117 |  | 18,523 |

[0001410578-22-000098:notes:82]
Operating lease liabilities are included on the Consolidated Balance Sheet in accrued other expenses (current portion) and as a caption on the Consolidated Balance Sheet (long-term portion). Finance lease liabilities are included on the Consolidated Balance Sheet in accrued other expenses (current portion) and other liabilities (long-term portion). Operating lease ROU assets are included as a caption on the Consolidated Balance Sheet and finance lease ROU assets are included in Property, plant and equipment on the Consolidated Balance sheet.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001410578-22-000098:notes:83]
14.  ADJUSTED QUARTERLY FINANCIAL INFORMATION

[0001410578-22-000098:notes:84]
During 2021, the Company identified immaterial errors in the historical consolidated financial statements of Westland, within the A&D segment, that are being corrected as an immaterial revision of those financial statements. Specifically, the adjustments include net sales being overstated by $0.3 million in the first quarter of 2021, along with inventory being overstated and cost of goods sold being understated by $0.8 million in the first quarter of 2021. The tax impact of correcting these errors was a reduction in tax expense of $0.2 million in the first quarter of 2021. The table below shows the impact of these adjustments to the first quarter of 2021. Management has determined that these adjustments are not material to the prior year period.

[0001410578-22-000098:notes:85]
| ​ |  | First Quarter |  | First Quarter |
| (Dollars in thousands, except per share amounts) | ​ | (As Reported) | ​ | (As Adjusted) |
| 2021 | ​ | ​ | ​ | ​ | ​ |
| Net sales | ​ | $ | 162,949 |  | 162,674 |
| Cost of sales | ​ |  | 98,777 |  | 99,622 |
| Earnings before income taxes | ​ |  | 17,660 |  | 16,540 |
| Income tax expense | ​ |  | 3,974 |  | 3,722 |
| Net earnings | ​ |  | 13,686 |  | 12,818 |
| Diluted earnings (loss) per share: | ​ |  |  |  |  |
| Net earnings | ​ | $ | 0.52 |  | 0.49 |
