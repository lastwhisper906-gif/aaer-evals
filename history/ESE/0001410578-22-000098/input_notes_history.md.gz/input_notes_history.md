# ESE note change history — 0001104659-21-102250 → 0001410578-22-000098


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-02-09):
[0001410578-22-000098:note_history:1]
The accompanying consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP).
  (was, 2021-08-09, similarity 0.7378):
[0001104659-21-102250:note_history:1]
The accompanying consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP). As a result of the pension plan termination referenced in the fourth quarter of 2020, certain prior year amounts have been reclassified to conform with the current year presentation. For further information, refer to the consolidated financial statements and related notes included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2020.

- changed (2022-02-09):
[0001410578-22-000098:note_history:2]
The Company’s results for the three-month period ended December 31, 2021 are not necessarily indicative of the results for the entire 2022 fiscal year. References to the first quarters of 2022 and 2021 represent the fiscal quarters ended December 31, 2021 and 2020, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.
  (was, 2021-08-09, similarity 0.9221):
[0001104659-21-102250:note_history:2]
The Company’s results for the three-month and nine-month periods ended June 30, 2021 are not necessarily indicative of the results for the entire 2021 fiscal year. References to the third quarters of 2021 and 2020 represent the fiscal quarters ended June 30, 2021 and 2020, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-02-09):
[0001410578-22-000098:note_history:3]
| ​ |  | December 31, | ​ | September 30, |
| (In thousands) |  | 2021 |  | 2021 |
| Total borrowings | ​ | $ | 198,000 |  | 154,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 178,000 |  | 134,000 |

- changed (2022-02-09):
[0001410578-22-000098:note_history:4]
The Credit Facility includes a $500 million revolving line of credit, as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024.
  (was, 2021-08-09, similarity 0.9988):
[0001104659-21-102250:note_history:4]
The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024.

- added (2022-02-09):
[0001410578-22-000098:note_history:5]
At December 31, 2021, the Company had approximately $291 million available to borrow under the Credit Facility, plus the $250 million increase option, in addition to $55.7 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of December 31, 2021, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $10.7 million at December 31, 2021.

- changed (2022-02-09):
[0001410578-22-000098:note_history:6]
Interest on borrowings under the Credit Facility is calculated at a spread over either the New York Federal Reserve Bank Rate, the prime rate, or the London Interbank Offered Rate (LIBOR), depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The Credit Facility is secured by the unlimited guaranty of the Company’s direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of its direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 1.17% and 1.45% for the three-month periods ending December 31, 2021 and 2020, respectively. As of December 31, 2021, the Company was in compliance with all covenants.
  (was, 2021-08-09, similarity 0.7625):
[0001104659-21-102250:note_history:6]
Interest on borrowings under the Credit Facility is calculated at a spread over either the London Interbank Offered Rate (LIBOR), the New York Federal Reserve Bank Rate or the prime rate, depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The Credit Facility is secured by the unlimited guaranty of the Company’s direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of its direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 1.16% and 1.33% for the three and nine- month periods ending June 30, 2021, respectively, and 3.24% and 3.22% for the three and nine-month periods ending June 30, 2020. As of June 30, 2021, the Company was in compliance with all covenants.

- removed (2022-02-09):
[0001104659-21-102250:note_history:7]
| ​ |  | June 30, | ​ | September 30, |
| (In thousands) |  | 2021 |  | 2020 |
| Total borrowings | ​ | $ | 48,000 |  | 62,368 |
| Current portion of long-term debt and short-term borrowings | ​ |  | (20,000) |  | (22,368) |
| Total long-term debt, less current portion | ​ | $ | 28,000 |  | 40,000 |

- removed (2022-02-09):
[0001104659-21-102250:note_history:8]
At June 30, 2021, the Company had approximately $444 million available to borrow under the Credit Facility, plus the $250 million increase option, subject to lender approval, in addition to $78.4 million cash on hand. The Company classified $20.0 million as the current portion of long-term debt as of June 30, 2021, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $8.4 million at June 30, 2021.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-02-09):
[0001410578-22-000098:note_history:9]
| ​ |  | December 31, | ​ | September 30, |
| (In thousands) |  | 2021 |  | 2021 |
| Total borrowings | ​ | $ | 198,000 |  | 154,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 178,000 |  | 134,000 |

- removed (2022-02-09):
[0001104659-21-102250:note_history:10]
| ​ |  | June 30, | ​ | September 30, |
| (In thousands) |  | 2021 |  | 2020 |
| Total borrowings | ​ | $ | 48,000 |  | 62,368 |
| Current portion of long-term debt and short-term borrowings | ​ |  | (20,000) |  | (22,368) |
| Total long-term debt, less current portion | ​ | $ | 28,000 |  | 40,000 |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-02-09):
[0001410578-22-000098:note_history:11]
| ​ | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total |  |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 28,075 | ​ | $ | 62,842 | ​ | $ | 41,037 | ​ | $ | 131,954 | ​ |
| U.S. Government | ​ |  | 42,169 | ​ | ​ | 643 | ​ | ​ | 2,244 | ​ |  | 45,056 | ​ |
| Total revenues | ​ | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 | ​ |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| United States | ​ | $ | 60,687 | ​ | $ | 38,741 | ​ | $ | 22,975 | ​ | $ | 122,403 | ​ |
| International | ​ |  | 9,557 | ​ | ​ | 24,744 | ​ | ​ | 20,306 | ​ |  | 54,607 | ​ |
| Total revenues | ​ | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 28,558 | ​ | $ | 50,835 | ​ | $ | 12,821 | ​ | $ | 92,214 | ​ |
| Over time | ​ |  | 41,686 | ​ | ​ | 12,650 | ​ | ​ | 30,460 | ​ |  | 84,796 | ​ |
| Total revenues | ​ | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 | ​ |
  (was, 2021-08-09, similarity 0.9353):
[0001104659-21-102250:note_history:11]
| Three months ended June 30, 2021 |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total | ​ |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 34,708 | ​ | $ | 46,735 | ​ | $ | 42,063 | ​ | $ | 123,506 | ​ |
| U.S. Government | ​ |  | 50,868 | ​ | ​ | 969 | ​ | ​ | 6,051 | ​ |  | 57,888 | ​ |
| Total revenues | ​ | $ | 85,576 | ​ | $ | 47,704 | ​ | $ | 48,114 | ​ | $ | 181,394 | ​ |
| Geographic location: | ​ |  | ​ | ​ | ​ |  | ​ | ​ |  | ​ |  | ​ | ​ |
| United States | ​ | $ | 75,701 | ​ | $ | 32,111 | ​ | $ | 27,719 | ​ | $ | 135,531 | ​ |
| International | ​ |  | 9,875 | ​ | ​ | 15,593 | ​ | ​ | 20,395 | ​ |  | 45,863 | ​ |
| Total revenues | ​ | $ | 85,576 | ​ | $ | 47,704 | ​ | $ | 48,114 | ​ | $ | 181,394 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ |  | ​ | ​ |  | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 37,513 | ​ | $ | 35,242 | ​ | $ | 9,673 | ​ | $ | 82,428 | ​ |
| Over time | ​ |  | 48,063 | ​ | ​ | 12,462 | ​ | ​ | 38,441 | ​ |  | 98,966 | ​ |
| Total revenues | ​ | $ | 85,576 | ​ | $ | 47,704 | ​ | $ | 48,114 | ​ | $ | 181,394 | ​ |

- changed (2022-02-09):
[0001410578-22-000098:note_history:12]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2020 are presented in the table below:
  (was, 2021-08-09, similarity 0.9288):
[0001104659-21-102250:note_history:12]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2020 are presented in the tables below.

- changed (2022-02-09):
[0001410578-22-000098:note_history:13]
| ​ | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 27,604 | ​ | $ | 53,864 | ​ | $ | 36,722 | ​ | $ | 118,190 |
| U.S. Government | ​ |  | 39,012 | ​ |  | 676 | ​ |  | 4,796 | ​ |  | 44,484 |
| Total revenues | ​ | $ | 66,616 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,674 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 57,538 | ​ | $ | 37,045 | ​ | $ | 23,266 | ​ | $ | 117,849 |
| International | ​ |  | 9,078 | ​ |  | 17,495 | ​ |  | 18,252 | ​ |  | 44,825 |
| Total revenues | ​ | $ | 66,616 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,674 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 26,946 | ​ | $ | 42,367 | ​ | $ | 8,868 | ​ | $ | 78,181 |
| Over time | ​ |  | 39,670 | ​ |  | 12,173 | ​ |  | 32,650 | ​ |  | 84,493 |
| Total revenues | ​ | $ | 66,616 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,674 |
  (was, 2021-08-09, similarity 0.9226):
[0001104659-21-102250:note_history:13]
| Three months ended June 30, 2020 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 37,485 | ​ | $ | 39,740 | ​ | $ | 38,737 | ​ | $ | 115,962 |
| U.S. Government | ​ |  | 46,587 | ​ |  | 2,837 | ​ |  | 7,279 | ​ |  | 56,703 |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 42,577 | ​ | $ | 46,016 | ​ | $ | 172,665 |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| United States | ​ | $ | 73,476 | ​ | $ | 26,499 | ​ | $ | 19,441 | ​ | $ | 119,416 |
| International | ​ |  | 10,596 | ​ |  | 16,078 | ​ |  | 26,575 | ​ |  | 53,249 |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 42,577 | ​ | $ | 46,016 | ​ | $ | 172,665 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 36,461 | ​ | $ | 27,765 | ​ | $ | 9,138 | ​ | $ | 73,364 |
| Over time | ​ |  | 47,611 | ​ |  | 14,812 | ​ |  | 36,878 | ​ |  | 99,301 |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 42,577 | ​ | $ | 46,016 | ​ | $ | 172,665 |

- added (2022-02-09):
[0001410578-22-000098:note_history:14]
Revenue Recognition

- added (2022-02-09):
[0001410578-22-000098:note_history:15]
Payment terms with our customers vary by the type and location of the customer and the products or services offered. Arrangements with customers that include payment terms extending beyond one year are not significant. The transaction price for these contracts reflects our estimate of returns and discounts, which are based on historical, current and forecasted information to determine the expected amount to which we will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation. Under the typical payment terms of our long term fixed price contracts, the customer pays us either performance-based or progress payments. Performance-based payments represent interim payments based on quantifiable measures of performance or on the achievement of specified events or milestones. Progress payments are interim payments of costs incurred as the work progresses.

- added (2022-02-09):
[0001410578-22-000098:note_history:16]
For our overtime revenue recognized using the output method of costs incurred, contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to one or more years, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change. In addition, in the USG segment, we recognize revenue as a series of distinct services based on each day of providing services (straight-line over the contract term) for certain of our USG segment contracts. Under the typical payment terms of our service contracts, the customer pays us in advance of when services are performed. In addition, in the Test segment, we use milestones to measure progress for our Test segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts.

- removed (2022-02-09):
[0001104659-21-102250:note_history:17]
| Nine months ended June 30, 2021 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |  |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 95,712 | ​ | $ | 139,149 | ​ | $ | 118,089 | ​ | $ | 352,950 | ​ |
| U.S. Government | ​ |  | 139,008 | ​ |  | 2,650 | ​ |  | 15,354 | ​ |  | 157,012 | ​ |
| Total revenues | ​ | $ | 234,720 | ​ | $ | 141,799 | ​ | $ | 133,443 | ​ | $ | 509,962 | ​ |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  |  | ​ |  | ​ | ​ |
| United States | ​ | $ | 205,527 | ​ | $ | 96,601 | ​ | $ | 73,950 | ​ | $ | 376,078 | ​ |
| International | ​ |  | 29,193 | ​ |  | 45,198 | ​ |  | 59,493 | ​ |  | 133,884 | ​ |
| Total revenues | ​ | $ | 234,720 | ​ | $ | 141,799 | ​ | $ | 133,443 | ​ | $ | 509,962 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  |  | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 103,492 | ​ | $ | 105,173 | ​ | $ | 27,789 | ​ | $ | 236,454 | ​ |
| Over time | ​ |  | 131,228 | ​ |  | 36,626 | ​ |  | 105,654 | ​ |  | 273,508 | ​ |
| Total revenues | ​ | $ | 234,720 | ​ | $ | 141,799 | ​ | $ | 133,443 | ​ | $ | 509,962 | ​ |

- removed (2022-02-09):
[0001104659-21-102250:note_history:18]
| Nine months ended June 30, 2020 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 130,817 | ​ | $ | 135,711 | ​ | $ | 107,931 | ​ | $ | 374,459 |
| U.S. Government | ​ |  | 125,890 | ​ |  | 3,468 | ​ |  | 21,068 | ​ |  | 150,426 |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 139,179 | ​ | $ | 128,999 | ​ | $ | 524,885 |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| United States | ​ | $ | 219,640 | ​ | $ | 90,155 | ​ | $ | 69,399 | ​ | $ | 379,194 |
| International | ​ |  | 37,067 | ​ |  | 49,024 | ​ |  | 59,600 | ​ |  | 145,691 |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 139,179 | ​ | $ | 128,999 | ​ | $ | 524,885 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 118,660 | ​ | $ | 100,289 | ​ | $ | 26,157 | ​ | $ | 245,106 |
| Over time | ​ |  | 138,047 | ​ |  | 38,890 | ​ |  | 102,842 | ​ |  | 279,779 |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 139,179 | ​ | $ | 128,999 | ​ | $ | 524,885 |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-02-09):
[0001410578-22-000098:note_history:19]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2021 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within each reportable segment.
  (was, 2021-08-09, similarity 0.6462):
[0001104659-21-102250:note_history:19]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2021 are presented in the tables below as the Company believes it best depicts how the nature, amount, timing and

- changed (2022-02-09):
[0001410578-22-000098:note_history:20]
| ​ | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total |  |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 28,075 | ​ | $ | 62,842 | ​ | $ | 41,037 | ​ | $ | 131,954 | ​ |
| U.S. Government | ​ |  | 42,169 | ​ | ​ | 643 | ​ | ​ | 2,244 | ​ |  | 45,056 | ​ |
| Total revenues | ​ | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 | ​ |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| United States | ​ | $ | 60,687 | ​ | $ | 38,741 | ​ | $ | 22,975 | ​ | $ | 122,403 | ​ |
| International | ​ |  | 9,557 | ​ | ​ | 24,744 | ​ | ​ | 20,306 | ​ |  | 54,607 | ​ |
| Total revenues | ​ | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 28,558 | ​ | $ | 50,835 | ​ | $ | 12,821 | ​ | $ | 92,214 | ​ |
| Over time | ​ |  | 41,686 | ​ | ​ | 12,650 | ​ | ​ | 30,460 | ​ |  | 84,796 | ​ |
| Total revenues | ​ | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 | ​ |
  (was, 2021-08-09, similarity 0.9353):
[0001104659-21-102250:note_history:20]
| Three months ended June 30, 2021 |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total | ​ |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 34,708 | ​ | $ | 46,735 | ​ | $ | 42,063 | ​ | $ | 123,506 | ​ |
| U.S. Government | ​ |  | 50,868 | ​ | ​ | 969 | ​ | ​ | 6,051 | ​ |  | 57,888 | ​ |
| Total revenues | ​ | $ | 85,576 | ​ | $ | 47,704 | ​ | $ | 48,114 | ​ | $ | 181,394 | ​ |
| Geographic location: | ​ |  | ​ | ​ | ​ |  | ​ | ​ |  | ​ |  | ​ | ​ |
| United States | ​ | $ | 75,701 | ​ | $ | 32,111 | ​ | $ | 27,719 | ​ | $ | 135,531 | ​ |
| International | ​ |  | 9,875 | ​ | ​ | 15,593 | ​ | ​ | 20,395 | ​ |  | 45,863 | ​ |
| Total revenues | ​ | $ | 85,576 | ​ | $ | 47,704 | ​ | $ | 48,114 | ​ | $ | 181,394 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ |  | ​ | ​ |  | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 37,513 | ​ | $ | 35,242 | ​ | $ | 9,673 | ​ | $ | 82,428 | ​ |
| Over time | ​ |  | 48,063 | ​ | ​ | 12,462 | ​ | ​ | 38,441 | ​ |  | 98,966 | ​ |
| Total revenues | ​ | $ | 85,576 | ​ | $ | 47,704 | ​ | $ | 48,114 | ​ | $ | 181,394 | ​ |

- changed (2022-02-09):
[0001410578-22-000098:note_history:21]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2020 are presented in the table below:
  (was, 2021-08-09, similarity 0.9288):
[0001104659-21-102250:note_history:21]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2020 are presented in the tables below.

- changed (2022-02-09):
[0001410578-22-000098:note_history:22]
| ​ | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 27,604 | ​ | $ | 53,864 | ​ | $ | 36,722 | ​ | $ | 118,190 |
| U.S. Government | ​ |  | 39,012 | ​ |  | 676 | ​ |  | 4,796 | ​ |  | 44,484 |
| Total revenues | ​ | $ | 66,616 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,674 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 57,538 | ​ | $ | 37,045 | ​ | $ | 23,266 | ​ | $ | 117,849 |
| International | ​ |  | 9,078 | ​ |  | 17,495 | ​ |  | 18,252 | ​ |  | 44,825 |
| Total revenues | ​ | $ | 66,616 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,674 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 26,946 | ​ | $ | 42,367 | ​ | $ | 8,868 | ​ | $ | 78,181 |
| Over time | ​ |  | 39,670 | ​ |  | 12,173 | ​ |  | 32,650 | ​ |  | 84,493 |
| Total revenues | ​ | $ | 66,616 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,674 |
  (was, 2021-08-09, similarity 0.9226):
[0001104659-21-102250:note_history:22]
| Three months ended June 30, 2020 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 37,485 | ​ | $ | 39,740 | ​ | $ | 38,737 | ​ | $ | 115,962 |
| U.S. Government | ​ |  | 46,587 | ​ |  | 2,837 | ​ |  | 7,279 | ​ |  | 56,703 |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 42,577 | ​ | $ | 46,016 | ​ | $ | 172,665 |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| United States | ​ | $ | 73,476 | ​ | $ | 26,499 | ​ | $ | 19,441 | ​ | $ | 119,416 |
| International | ​ |  | 10,596 | ​ |  | 16,078 | ​ |  | 26,575 | ​ |  | 53,249 |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 42,577 | ​ | $ | 46,016 | ​ | $ | 172,665 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 36,461 | ​ | $ | 27,765 | ​ | $ | 9,138 | ​ | $ | 73,364 |
| Over time | ​ |  | 47,611 | ​ |  | 14,812 | ​ |  | 36,878 | ​ |  | 99,301 |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 42,577 | ​ | $ | 46,016 | ​ | $ | 172,665 |

- added (2022-02-09):
[0001410578-22-000098:note_history:23]
Revenue Recognition

- added (2022-02-09):
[0001410578-22-000098:note_history:24]
Payment terms with our customers vary by the type and location of the customer and the products or services offered. Arrangements with customers that include payment terms extending beyond one year are not significant. The transaction price for these contracts reflects our estimate of returns and discounts, which are based on historical, current and forecasted information to determine the expected amount to which we will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation. Under the typical payment terms of our long term fixed price contracts, the customer pays us either performance-based or progress payments. Performance-based payments represent interim payments based on quantifiable measures of performance or on the achievement of specified events or milestones. Progress payments are interim payments of costs incurred as the work progresses.

- added (2022-02-09):
[0001410578-22-000098:note_history:25]
For our overtime revenue recognized using the output method of costs incurred, contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to one or more years, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change. In addition, in the USG segment, we recognize revenue as a series of distinct services based on each day of providing services (straight-line over the contract term) for certain of our USG segment contracts. Under the typical payment terms of our service contracts, the customer pays us in advance of when services are performed. In addition, in the Test segment, we use milestones to measure progress for our Test segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts.

- changed (2022-02-09):
[0001410578-22-000098:note_history:26]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At December 31, 2021, the Company had $639.4 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 77% in the next twelve months.
  (was, 2021-08-09, similarity 0.9914):
[0001104659-21-102250:note_history:26]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At June 30, 2021, the Company had $539.0 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 70% in the next twelve months.

- changed (2022-02-09):
[0001410578-22-000098:note_history:27]
Contract assets and liabilities
  (was, 2021-08-09, similarity 0.8732):
[0001104659-21-102250:note_history:27]
Contract assets and contract liabilities

- added (2022-02-09):
[0001410578-22-000098:note_history:28]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred. At December 31, 2021, contract assets and liabilities totaled $100.9 million and $111.6 million, respectively. During the first quarter of 2022, the Company recognized approximately $29 million in revenues that were included in the contract liabilities balance at September 30, 2021. The increase in net contract assets in the first quarter of 2022 was due to revenue being recognized for performance completed during the period that exceeded customer billings. Other factors that impacted the change in net contract liabilities were immaterial. At October 1, 2020, contract assets and liabilities totaled $94.3 million and $100.6 million, respectively.

- removed (2022-02-09):
[0001104659-21-102250:note_history:29]
uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue within each reportable segment on a continuing operations basis.

- removed (2022-02-09):
[0001104659-21-102250:note_history:30]
| Nine months ended June 30, 2021 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |  |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 95,712 | ​ | $ | 139,149 | ​ | $ | 118,089 | ​ | $ | 352,950 | ​ |
| U.S. Government | ​ |  | 139,008 | ​ |  | 2,650 | ​ |  | 15,354 | ​ |  | 157,012 | ​ |
| Total revenues | ​ | $ | 234,720 | ​ | $ | 141,799 | ​ | $ | 133,443 | ​ | $ | 509,962 | ​ |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  |  | ​ |  | ​ | ​ |
| United States | ​ | $ | 205,527 | ​ | $ | 96,601 | ​ | $ | 73,950 | ​ | $ | 376,078 | ​ |
| International | ​ |  | 29,193 | ​ |  | 45,198 | ​ |  | 59,493 | ​ |  | 133,884 | ​ |
| Total revenues | ​ | $ | 234,720 | ​ | $ | 141,799 | ​ | $ | 133,443 | ​ | $ | 509,962 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  |  | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 103,492 | ​ | $ | 105,173 | ​ | $ | 27,789 | ​ | $ | 236,454 | ​ |
| Over time | ​ |  | 131,228 | ​ |  | 36,626 | ​ |  | 105,654 | ​ |  | 273,508 | ​ |
| Total revenues | ​ | $ | 234,720 | ​ | $ | 141,799 | ​ | $ | 133,443 | ​ | $ | 509,962 | ​ |

- removed (2022-02-09):
[0001104659-21-102250:note_history:31]
| Nine months ended June 30, 2020 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 130,817 | ​ | $ | 135,711 | ​ | $ | 107,931 | ​ | $ | 374,459 |
| U.S. Government | ​ |  | 125,890 | ​ |  | 3,468 | ​ |  | 21,068 | ​ |  | 150,426 |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 139,179 | ​ | $ | 128,999 | ​ | $ | 524,885 |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| United States | ​ | $ | 219,640 | ​ | $ | 90,155 | ​ | $ | 69,399 | ​ | $ | 379,194 |
| International | ​ |  | 37,067 | ​ |  | 49,024 | ​ |  | 59,600 | ​ |  | 145,691 |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 139,179 | ​ | $ | 128,999 | ​ | $ | 524,885 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 118,660 | ​ | $ | 100,289 | ​ | $ | 26,157 | ​ | $ | 245,106 |
| Over time | ​ |  | 138,047 | ​ |  | 38,890 | ​ |  | 102,842 | ​ |  | 279,779 |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 139,179 | ​ | $ | 128,999 | ​ | $ | 524,885 |

- removed (2022-02-09):
[0001104659-21-102250:note_history:32]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At June 30, 2021, contract assets and contract liabilities totaled $94.8 million and $105.8 million, respectively. Contract assets and contract liabilities are presented as current in the consolidated balance sheets as it is expected all related transaction activity with customers will be substantially completed within twelve months. During the first nine months of 2021, the Company recognized approximately $75 million in revenues that were included in the contract liabilities balance at September 30, 2020.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2022-02-09):
[0001104659-21-102250:note_history:33]
14.  SUBSEQUENT EVENTS

- removed (2022-02-09):
[0001104659-21-102250:note_history:34]
On May 20, 2021, the Company announced it had entered into an agreement to acquire I.S.A. Altanova Group S.R.L. (Altanova), a supplier in the field of advanced condition assessment technologies including partial discharge measurement and analysis, as well as test instruments for electrical apparatus. Altanova, which will become part of the USG operating segment, had annual sales of approximately $30 million in 2020. As of June 30, 2021, the Company had 30 million Euros held in an escrow account related to this transaction which will be used to partially fund the acquisition. The transaction was subject to Italian regulatory approval, which was obtained and the transaction closed on July 29, 2021.

- removed (2022-02-09):
[0001104659-21-102250:note_history:35]
On August 9, 2021, the Company announced it had acquired the assets of Phenix Technologies, Inc. (Phenix), a manufacturer of stationary and portable high voltage, high current, high power test systems, components and solutions supporting the electric utility industry. Phenix, which will become part of the USG operating segment, had annual sales of approximately $25 million in 2020.
