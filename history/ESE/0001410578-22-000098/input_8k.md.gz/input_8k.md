# ESE 8-K — 0001104659-22-013878 filed 2022-02-08

## item codes, every 8-K on or before 2022-02-09

- 2022-02-08 0001104659-22-013878 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2021-12-03 0001104659-21-146361 — 4.01, 9.01 — amendment, the index does not say of what
- 2021-11-24 0001104659-21-143568 — 4.01, 9.01
- 2021-11-23 0001104659-21-142871 — 5.02, 8.01
- 2021-11-18 0001104659-21-141206 — 2.02, 7.01, 9.01
- 2021-08-09 0001104659-21-102150 — 2.02, 7.01, 9.01
- 2021-05-04 0001104659-21-060985 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2021-04-05 0001104659-21-046581 — 5.02, 9.01
- 2021-02-08 0001104659-21-013712 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2020-12-09 0001104659-20-133674 — 5.02, 9.01
- 2020-12-07 0001104659-20-132861 — 5.02, 7.01, 9.01
- 2020-11-19 0001104659-20-127352 — 2.02, 5.02, 7.01, 9.01
- 2020-08-10 0001104659-20-092734 — 2.02, 7.01, 9.01
- 2020-05-06 0001104659-20-057442 — 2.02, 7.01, 8.01, 9.01
- 2020-02-04 0001104659-20-010640 — 2.02, 5.07, 7.01, 9.01
- 2020-01-07 0001104659-20-001789 — 2.01, 9.01
- 2019-11-19 0001104659-19-065437 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2019-11-18 0001104659-19-065096 — 1.01, 2.02, 7.01, 9.01
- 2019-09-30 0001144204-19-046523 — 1.01, 1.02, 2.03, 9.01
- 2019-08-08 0001144204-19-038567 — 2.02, 7.01, 9.01
- 2019-05-07 0001144204-19-024241 — 2.02, 5.02, 7.01, 9.01
- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2022-02-09

- none on or before 2022-02-09

## item 2.02 — earnings release, exhibit 99.1

[0001104659-22-013878:8k_2_02:1]
EX-99.1
2
tm225779d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-22-013878:8k_2_02:2]
Exhibit 99.1

[0001104659-22-013878:8k_2_02:3]
| NEWS FROM |  |

[0001104659-22-013878:8k_2_02:4]
For more information contact:

[0001104659-22-013878:8k_2_02:5]
Kate Lowrey

[0001104659-22-013878:8k_2_02:6]
Vice President of Investor Relations

[0001104659-22-013878:8k_2_02:7]
ESCO Technologies Inc.

[0001104659-22-013878:8k_2_02:8]
(314)
213-7277

[0001104659-22-013878:8k_2_02:9]
ESCO ANNOUNCES
FIRST QUARTER FISCAL 2022 RESULTS

[0001104659-22-013878:8k_2_02:10]
- Q1 GAAP EPS $0.44 and Adjusted EPS $0.46
-

[0001104659-22-013878:8k_2_02:11]
- $224 Million in Q1 Orders - Book-to-bill
of 1.27x -

[0001104659-22-013878:8k_2_02:12]
-$177M in Sales - 8.8% increase over Q1 2021
–

[0001104659-22-013878:8k_2_02:13]
ST. LOUIS, February 8, 2022 – ESCO Technologies
Inc. (NYSE: ESE) (ESCO, or the Company) today reported its operating results for the first quarter ended December 31, 2021 (Q1 2022) compared
to the first quarter ended December 31, 2020 (Q1 2021).

[0001104659-22-013878:8k_2_02:14]
Vic
Richey, Chairman and Chief Executive Officer, commented, “We continue to see business conditions stabilize as we
delivered solid sales growth and strong entered orders in the quarter. Our teams worked diligently during the quarter to address
ongoing labor and material availability challenges and I want to thank all of our employees for their efforts to effectively respond
to these disruptions and support our customers. We estimate these labor and supply chain constraints impacted our sales in the first
quarter by $5 to $8 million. We view these as timing issues that we will manage during the course of the year, and we are very
encouraged by the continuing order strength across all three of our business segments. Our solid orders growth and record ending
backlog give us confidence that we are on track to deliver our stated revenue and earnings goals for the year.

[0001104659-22-013878:8k_2_02:15]
“The integration of our recent acquisitions has gotten off to
a good start. As previously announced, Altanova and Phenix were acquired during our fiscal 2021 fourth quarter, and are now part of our
USG segment. We continue to make good progress on aligning our product and channel strategies around the world to drive growth in the
global utility markets. In Q1 we also announced that the A&D group had acquired NEco. This company will fit in nicely within ESCO’s
PTI subsidiary and bring complementary product technologies as well as strong customer relationships. We are very pleased to welcome these
three companies and their teams to ESCO and we are confident of the value they can bring to our company over time.”

[0001104659-22-013878:8k_2_02:16]
Earnings Summary

[0001104659-22-013878:8k_2_02:17]
Q1 2022 GAAP EPS was $0.44 per share (GAAP net earnings of $11.5 million)
and included the net earnings impact of the Q1 2022 Discrete Items described below. Excluding the net earnings impact of the Discrete
Items, Q1 2022 Adjusted EPS was $0.46 per share.

[0001104659-22-013878:8k_2_02:18]
Q1 2021 GAAP EPS was $0.49 per share (GAAP net earnings of $12.8 million)
and included the net earnings impact of the Q1 2021 Discrete Items described below. Excluding the net earnings impact of the Discrete
Items, Q1 2021 Adjusted EPS was $0.52 per share.

[0001104659-22-013878:8k_2_02:19]
Discrete Items

[0001104659-22-013878:8k_2_02:20]
The
financial results presented include certain non-GAAP financial measures such as EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA and
Adjusted EPS, as defined within the “Non-GAAP Financial Measures” described below. Any non-GAAP financial measures presented
are reconciled to their respective GAAP equivalents. Management believes these non-GAAP financial measures are useful in assessing the
ongoing operational profitability of the Company’s business segments, and therefore, allow shareholders better visibility into the
Company’s underlying operations. See “Non-GAAP Financial Measures” described below.

[0001104659-22-013878:8k_2_02:21]
During Q1 2022, the Company incurred $0.6 million
($0.02 per share) of after-tax charges associated with the Altanova and NEco acquisition inventory step-up charges and acquisition related
costs at Corporate. These costs are excluded from the calculation of Q1 2022 Adjusted EBITDA and Adjusted EPS.

[0001104659-22-013878:8k_2_02:22]
During Q1 2021, the Company incurred $0.8 million
($0.03 per share) of after-tax charges associated with the Doble Manta facility consolidation ($0.02 per share) and ATM acquisition inventory
step-up ($0.01 per share). These costs are excluded from the calculation of Q1 2021 Adjusted EBITDA and Adjusted EPS.

[0001104659-22-013878:8k_2_02:23]
Operating
Highlights

[0001104659-22-013878:8k_2_02:24]
|  | · | Q1 2022 Sales of $177.0 million increased $14.3 million (8.8 percent) compared to Q1 2021. Sales increased $15.4 million related to recent acquisitions (9.5 percent) and decreased $1.1 million (0.6 percent) organically during the quarter. Organic sales growth of $2.7 million in A&D and $1.8 million in Test was offset by a decrease of $5.6 million in USG, of which approximately $3 million related to shipment delays caused by supply chain issues. |

[0001104659-22-013878:8k_2_02:25]
|  | · | Gross margin remained consistent at 38.8 percent in both Q1 2022 and Q1 2021, despite the negative impact of wage and material cost inflation in the first quarter of 2022. |

[0001104659-22-013878:8k_2_02:26]
|  | · | SG&A expenses increased $5.6 million in Q1 2022 compared to Q1 2021. This increase was primarily due to the SG&A contribution from recent acquisitions and wage inflation. |

[0001104659-22-013878:8k_2_02:27]
|  | · | Interest expense increased $0.2 million in Q1 2022 compared to the prior year period related to higher debt outstanding. |

[0001104659-22-013878:8k_2_02:28]
|  | · | The Q1 2022 effective income tax rate was 22.3 percent versus 22.5 percent in the prior year period. |

[0001104659-22-013878:8k_2_02:29]
|  | · | Q1 2022 Entered Orders increased $66 million (42 percent) over the prior year period to $224 million (book-to-bill of 1.27x). Ending backlog increased $47 million (8 percent) in the quarter, with significant order strength across all three business segments. |

[0001104659-22-013878:8k_2_02:30]
|  | · | Net cash provided by operating activities was $2 million in Q1 2022, a decrease of $23 million from the prior year period mainly due to changes in contract assets and liabilities related to revenue recognized for performance completed and the decrease in milestone payments received in the current quarter. Cash flow was also negatively impacted by a decrease in accrued expenses due to timing of payments in the quarter. |

[0001104659-22-013878:8k_2_02:31]
|  | · | Net debt (total borrowings less cash on hand) was $142 million with a 1.34x leverage ratio and $541 million in liquidity at December 31, 2021. |

[0001104659-22-013878:8k_2_02:32]
Segment Performance

[0001104659-22-013878:8k_2_02:33]
Aerospace & Defense (A&D)

[0001104659-22-013878:8k_2_02:34]
|  | · | Sales increased $3.6 million (5 percent) to $70.2 million in Q1 2022 from $66.6 million in Q1 2021, due to strong growth in commercial and military aerospace, partially offset by $2 to $5 million of shipment delays due to supply chain and labor availability issues. The NEco acquisition added $0.9 million to the sales growth. |

[0001104659-22-013878:8k_2_02:35]
|  | · | EBIT increased $1.7 million in Q1 2022 to $10.0 million, with a 14.2 percent EBIT margin. Adjusted EBIT increased $1.6 million in Q1 2022 to $10.2 million from $8.6 million in Q1 2021, with a 14.4 percent Adjusted EBIT margin in Q1 2022 compared to 12.9 percent in prior year Q1. The profit improvement was driven by price increases and leverage on higher aerospace revenue, partially offset by inflation and lower industrial sales. |

[0001104659-22-013878:8k_2_02:36]
|  | · | Entered Orders were $90 million in Q1 2022 (book-to-bill of 1.28x) compared to $65 million in Q1 2021. It was the third consecutive quarter of solid order growth in aerospace. The order strength was driven in the commercial market by the 737 production ramp up and A350 orders, and in the defense market by F-35 and V22 Osprey orders. Overall, A&D orders increased 38 percent in the quarter compared to the prior year and resulted in a $20 million increase in ending backlog to $387 million. |

[0001104659-22-013878:8k_2_02:37]
Utility Solutions Group (USG)

[0001104659-22-013878:8k_2_02:38]
|  | · | Sales increased $9.0 million (17 percent) to $63.5 million in Q1 2022 from $54.5 million in Q1 2021. Sales increased $14.5 million related to the contribution from the Altanova and Phenix acquisitions. USG organic sales decreased by $5.6 million due to lower sales at Doble, of which approximately $3 million was the result of the previously stated shipment delays related to component shortages. In addition, Q1 2021 sales benefitted from strong year-end buying from our core utility customers that was not repeated in Q1 2022. NRG’s revenue increased 21 percent as the renewables markets continue to have high levels of activity. |

[0001104659-22-013878:8k_2_02:39]
|  | · | EBIT increased $0.7 million in Q1 2022 to $13.4 million from $12.7 million in Q1 2021. Adjusted EBIT increased $0.4 million in Q1 2022 to $13.8 million from $13.4 million in Q1 2021, with a 21.8 percent Adjusted EBIT margin in Q1 2022 versus 24.5 percent in the prior year. The increase in Adjusted EBIT was primarily due to the sales contribution from Phenix and Altanova, price increases, and leverage on higher renewables revenue, partially offset by wage and material cost inflation and lower organic sales at Doble. |

[0001104659-22-013878:8k_2_02:40]
|  | · | Entered Orders were $66 million in Q1 2022 (book-to-bill of 1.04). The $18 million (36 percent) increase in Q1 2022 orders resulted in ending backlog of $94 million. The orders growth was driven by $14 million in Phenix and Altanova orders, a $3 million increase in renewables and a $1 million increase in core Doble products and services. |

[0001104659-22-013878:8k_2_02:41]
Test

[0001104659-22-013878:8k_2_02:42]
|  | · | Sales increased $1.8 million (4 percent) to $43.3 million in Q1 2022 from $41.5 million in Q1 2021, due to price increases and revenue growth related to Test and Measurement projects in China and power filters in the U.S. |

[0001104659-22-013878:8k_2_02:43]
|  | · | EBIT decreased $1.3 million in Q1 2022 to $4.0 million from $5.3 million in Q1 2021, with a 9.2 percent EBIT margin. Increased profit related to volume and price increases was more than offset by material cost increases and wage inflation. |

[0001104659-22-013878:8k_2_02:44]
|  | • | Entered Orders were $68 million in Q1 2022 (book-to-bill of 1.57x) compared to $43 million in Q1 2021. The order growth was driven by test and measurement and power filter orders domestically and large projects in Europe. The $25 million (56 percent) increase in Q1 2022 orders resulted in an ending backlog of $158 million. |

[0001104659-22-013878:8k_2_02:45]
Summary Commentary

[0001104659-22-013878:8k_2_02:46]
In Q1 2022, entered orders were up $66 million (42
percent) over the prior year to $224 million, due to the initial impact of our recent acquisitions, and growth in our commercial and defense
aerospace, renewables and Test end-markets.

[0001104659-22-013878:8k_2_02:47]
In USG, orders and revenue growth were driven by
renewables and recent acquisitions as the overall electric utility market continues to be impacted by reduced domestic electricity consumption
related to the pandemic, which in turn impacts utility spending on investments in grid maintenance and testing. We remain confident in
the long-term growth potential of the global utility market. The drive for de-carbonization, digitization of grid assets, and more resilient
power systems will require significant investments in the future. Our USG segment is well positioned to serve the global utility market
with products and solutions that range from supporting renewable energy generation, to maintaining and protecting transmission and distribution
assets.

[0001104659-22-013878:8k_2_02:48]
Q1
2022 sales increased 8.8 percent over the prior year, on the strength of recent acquisitions, and solid organic growth in our aerospace,
renewables, and Test end-markets, partially offset by lower core Doble sales. Q1 Adjusted EBITDA margin decreased to 16.1 percent
from 17.3 percent in the prior year, primarily driven by wage and material cost inflation partially offset by price increases and leverage
from revenue growth.

[0001104659-22-013878:8k_2_02:49]
Vic Richey, Chairman and Chief Executive Officer, commented, “Despite
ongoing headwinds in the quarter, our orders and revenue strength, and solid leadership position in the niche end-markets that we serve
gives us confidence that we are well positioned to deliver profitable long-term growth and shareholder value as our end-markets continue
to recover.”

[0001104659-22-013878:8k_2_02:50]
Dividend
Payment

[0001104659-22-013878:8k_2_02:51]
The next quarterly
cash dividend of $0.08 per share will be paid on April 19, 2022 to stockholders of record on
April 4, 2022.

[0001104659-22-013878:8k_2_02:52]
Share Repurchase Program

[0001104659-22-013878:8k_2_02:53]
As previously announced in our August 9, 2021 press
release, the Company’s Board of Directors approved a new stock repurchase program. During Q1 2022, the Company repurchased approximately
116,000 shares for $10 million.

[0001104659-22-013878:8k_2_02:54]
Business
Outlook – 2022

[0001104659-22-013878:8k_2_02:55]
Management’s expectations for 2022 remain consistent with the
details outlined in our November 18, 2021 release.  Our 2022 guidance represents meaningful growth in sales, Adjusted EBIT, and Adjusted
EBITDA across each of the Company’s business segments.

[0001104659-22-013878:8k_2_02:56]
As
mentioned previously, our Q1 2022 revenue was negatively impacted by labor and material availability issues in certain parts of
our business. These are viewed as timing issues that we expect to address during the year, and we are maintaining our outlook for 2022
of adjusted earnings per share in the range of $3.10 to $3.20. This EPS outlook is predicated on sales in the range of $815 to $835 million
(an increase of 14 to 17 percent). Despite the short-term challenges, we expect modest EPS growth in Q2. We are working to increase capacity
in certain parts of the business and to manage supply chain challenges. As these areas continue to improve, we expect the second half
sales and profitability to ramp up significantly.

[0001104659-22-013878:8k_2_02:57]
Conference Call

[0001104659-22-013878:8k_2_02:58]
The
Company will host a conference call today, February 8, at 4:00 p.m. Central Time, to discuss the Company’s Q1 2022 results. A live
audio webcast will be available on the Company’s website at www.escotechnologies.com. Please access the website at least
15 minutes prior to the call to register, download and install any necessary audio software. A replay of the conference call will be available
on the Company’s website noted above or by phone (dial 1-855-859-2056 and enter the pass code 5014737).

[0001104659-22-013878:8k_2_02:59]
Forward-Looking Statements

[0001104659-22-013878:8k_2_02:60]
Statements
in this press release regarding the timing and magnitude of recovery in the Company’s end markets, the continuing impacts
of COVID-19 on the Company’s results, sales, Adjusted SG&A, Adjusted EBIT, Adjusted EBITDA, Adjusted EPS, cash flow, results
of cost reduction efforts, margins, growth, the financial success of the Company, the strength of its end markets, the outlook for the
A&D, Test and USG segments, the ability to increase shareholder value, the timing and success of acquisition efforts, internal investments
in new products and solutions, the long-term success of the Company, and any other statements which are not strictly historical are “forward-looking”
statements within the meaning of the safe harbor provisions of the federal securities laws.

[0001104659-22-013878:8k_2_02:61]
Investors
are cautioned that such statements are only predictions and speak only as of the date of this release, and the Company undertakes no duty
to update them except as may be required by applicable laws or regulations.  The Company’s actual results in the future
may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s
operations and business environment including but not limited to those described in Item 1A, “Risk Factors”, of the Company’s
Annual Report on Form 10-K for the fiscal year ended September 30, 2021; the availability and acceptance of viable COVID-19 vaccines by
enough of the U.S. and world’s population to curtail the pandemic; the continuing impact of the COVID-19 pandemic and the effects
of known or unknown COVID-19 variants including labor shortages, facility closures, shelter in place policies or quarantines, material
shortages, transportation delays, termination or delays of Company contracts, and the inability of our suppliers or customers to perform;
the impacts of Executive Order 14042 and other vaccine mandates on our employees and businesses; the impacts of natural disasters on the
Company’s operations and those of the Company’s customers and suppliers; the timing and content of future contract awards
or customer orders; the appropriation, allocation and availability of Government funds; the termination for convenience of Government
and other customer contracts or orders; weakening of economic conditions in served markets; the success of the Company’s competitors;
changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties; the success of
the Company’s acquisition efforts; delivery delays or defaults by customers; performance issues with key customers, suppliers and
subcontractors; changes in the costs and availability of certain raw materials; labor disputes; changes in U.S. tax laws and regulations;
other changes in laws and regulations including but not limited to changes in accounting standards and foreign taxation; changes in interest
rates; costs relating to environmental matters arising from current or former facilities; uncertainty regarding the ultimate resolution
of current disputes, claims, litigation or arbitration; and the integration of recently acquired businesses.

[0001104659-22-013878:8k_2_02:62]
Non-GAAP Financial Measures

[0001104659-22-013878:8k_2_02:63]
The
financial measures EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS are presented in this press release. The Company
defines “EBIT” as earnings before interest and taxes, “EBITDA” as earnings before interest, taxes, depreciation
and amortization, “Adjusted EBIT” and “Adjusted EBITDA” as excluding the net impact of the items described above
in Discrete Items, and “Adjusted EPS” as GAAP earnings per share (EPS) excluding the net impact of the items described above
in Discrete Items and reconciled in the attached Reconciliation of Non-GAAP Financial Measures, which were ($0.02) per share in Q1 2022.

[0001104659-22-013878:8k_2_02:64]
EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA and
Adjusted EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management believes
EBIT, Adjusted EBIT, EBITDA and Adjusted EBITDA are useful in assessing the operational profitability of the Company’s business
segments because they exclude interest, taxes, depreciation and amortization, which are generally accounted for across the entire Company
on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company as
well as incentive compensation. The presentation of EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS provides important supplemental
information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures to supplement
their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance determined in accordance
with GAAP.

[0001104659-22-013878:8k_2_02:65]
ESCO,
headquartered in St. Louis, Missouri: Manufactures highly-engineered filtration and fluid control products for the aviation, Navy, space
and process markets worldwide, as well as composite-based products and solutions for Navy, defense and industrial customers; is the industry
leader in RF shielding and EMC test products; and provides diagnostic instruments, software and services for the benefit of industrial
power users and the electric utility and renewable energy industries. Further information regarding ESCO and its subsidiaries is available
on the Company’s website at www.escotechnologies.com.

[0001104659-22-013878:8k_2_02:66]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-22-013878:8k_2_02:67]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-22-013878:8k_2_02:68]
(Dollars in thousands, except per share amounts)

[0001104659-22-013878:8k_2_02:69]
|  |  | Three Months Ended December 31, 2021 |  |  | Three Months Ended December 31, 2020 |  |
| Net Sales |  | $ | 177,010 |  |  |  | 162,674 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 108,305 |  |  |  | 99,622 |  |
| Selling, general and administrative expenses |  |  | 46,635 |  |  |  | 41,000 |  |
| Amortization of intangible assets |  |  | 6,467 |  |  |  | 4,948 |  |
| Interest expense |  |  | 733 |  |  |  | 541 |  |
| Other expenses, net |  |  | 33 |  |  |  | 23 |  |
| Total costs and expenses |  |  | 162,173 |  |  |  | 146,134 |  |
| Earnings before income taxes |  |  | 14,837 |  |  |  | 16,540 |  |
| Income tax expense |  |  | 3,313 |  |  |  | 3,722 |  |
| Net earnings |  | $ | 11,524 |  |  |  | 12,818 |  |
| Diluted - GAAP |  | $ | 0.44 |  |  |  | 0.49 |  |
| Diluted - As Adjusted Basis |  | $ | 0.46 | (1) |  |  | 0.52 | (2) |
| Diluted average common shares O/S: |  |  | 26,142 |  |  |  | 26,182 |  |

[0001104659-22-013878:8k_2_02:70]
(1) Q1 2022 Adjusted EPS excludes $0.02 per share of after-tax charges associated with the Altanova & NEco acquisition inventory step-up charges and Corporate acquisition related costs.

[0001104659-22-013878:8k_2_02:71]
(2) Q1 2021 Adjusted EPS excludes $0.03 per share of after-tax charges associated with the Doble Manta facility consolidation and ATM acquisition inventory step-up.

[0001104659-22-013878:8k_2_02:72]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-22-013878:8k_2_02:73]
Condensed Business Segment Information (Unaudited)

[0001104659-22-013878:8k_2_02:74]
(Dollars in thousands)

[0001104659-22-013878:8k_2_02:75]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | Q1 2022 |  |  | Q1 2021 |  |  | Q1 2022 |  |  | Q1 2021 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 70,244 |  |  |  | 66,616 |  |  |  | 70,244 |  |  |  | 66,616 |  |
| USG |  |  | 63,485 |  |  |  | 54,540 |  |  |  | 63,485 |  |  |  | 54,540 |  |
| Test |  |  | 43,281 |  |  |  | 41,518 |  |  |  | 43,281 |  |  |  | 41,518 |  |
| Totals |  | $ | 177,010 |  |  |  | 162,674 |  |  |  | 177,010 |  |  |  | 162,674 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 9,955 |  |  |  | 8,260 |  |  |  | 10,150 |  |  |  | 8,580 |  |
| USG |  |  | 13,391 |  |  |  | 12,731 |  |  |  | 13,841 |  |  |  | 13,381 |  |
| Test |  |  | 3,965 |  |  |  | 5,342 |  |  |  | 3,965 |  |  |  | 5,342 |  |
| Corporate |  |  | (11,741 | ) |  |  | (9,252 | ) |  |  | (11,561 | ) |  |  | (9,192 | ) |
| Consolidated EBIT |  |  | 15,570 |  |  |  | 17,081 |  |  |  | 16,395 |  |  |  | 18,111 |  |
| Less: Interest expense |  |  | (733 | ) |  |  | (541 | ) |  |  | (733 | ) |  |  | (541 | ) |
| Less: Income tax expense |  |  | (3,313 | ) |  |  | (3,722 | ) |  |  | (3,503 | ) |  |  | (3,959 | ) |
| Net earnings |  |  | 11,524 |  |  |  | 12,818 |  |  |  | 12,159 |  |  |  | 13,611 |  |

[0001104659-22-013878:8k_2_02:76]
Note 1: Adjusted net earnings were $12.2 million in Q1 2022 which excludes $0.02 per share of after-tax charges associated with the Altanova & NEco acquisition inventory step-up charges and Corporate acquisition related costs.

[0001104659-22-013878:8k_2_02:77]
Note 2: Adjusted net earnings were $13.6 million in Q1 2021 which excludes $0.03 per share of after-tax charges associated with the Doble Manta facility consolidation and ATM acquisition inventory step-up.

[0001104659-22-013878:8k_2_02:78]
| EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  | Q1 2022 |  |  |  |  |  | Q1 2021 |  |
|  |  | Q1 2022 |  |  | - As Adj |  |  | Q1 2021 |  |  | - As Adj |  |
| Consolidated EBITDA |  | $ | 27,742 |  |  |  | 28,567 |  |  |  | 27,093 |  |  |  | 28,123 |  |
| Less: Depr & Amort |  |  | (12,172 | ) |  |  | (12,172 | ) |  |  | (10,012 | ) |  |  | (10,012 | ) |
| Consolidated EBIT |  |  | 15,570 |  |  |  | 16,395 |  |  |  | 17,081 |  |  |  | 18,111 |  |
| Less: Interest expense |  |  | (733 | ) |  |  | (733 | ) |  |  | (541 | ) |  |  | (541 | ) |
| Less: Income tax expense |  |  | (3,313 | ) |  |  | (3,503 | ) |  |  | (3,722 | ) |  |  | (3,959 | ) |
| Net earnings |  | $ | 11,524 |  |  |  | 12,159 |  |  |  | 12,818 |  |  |  | 13,611 |  |

[0001104659-22-013878:8k_2_02:79]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-22-013878:8k_2_02:80]
Condensed Consolidated Balance Sheets (Unaudited)

[0001104659-22-013878:8k_2_02:81]
(Dollars in thousands)

[0001104659-22-013878:8k_2_02:82]
|  |  | December 31, 2021 |  |  | September 30, 2021 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 55,715 |  |  |  | 56,232 |  |
| Accounts receivable, net |  |  | 135,874 |  |  |  | 146,341 |  |
| Contract assets |  |  | 100,863 |  |  |  | 93,771 |  |
| Inventories |  |  | 165,021 |  |  |  | 147,148 |  |
| Other current assets |  |  | 27,329 |  |  |  | 22,662 |  |
| Total current assets |  |  | 484,802 |  |  |  | 466,154 |  |
| Property, plant and equipment, net |  |  | 155,712 |  |  |  | 154,265 |  |
| Intangible assets, net |  |  | 411,679 |  |  |  | 409,250 |  |
| Goodwill |  |  | 509,268 |  |  |  | 504,853 |  |
| Operating lease assets |  |  | 31,117 |  |  |  | 31,846 |  |
| Other assets |  |  | 11,638 |  |  |  | 10,977 |  |
|  |  | $ | 1,604,216 |  |  |  | 1,577,345 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt |  | $ | 20,000 |  |  |  | 20,000 |  |
| Accounts payable |  |  | 63,651 |  |  |  | 56,669 |  |
| Contract liabilities |  |  | 111,596 |  |  |  | 108,814 |  |
| Other current liabilities |  |  | 70,627 |  |  |  | 92,281 |  |
| Total current liabilities |  |  | 265,874 |  |  |  | 277,764 |  |
| Deferred tax liabilities |  |  | 80,962 |  |  |  | 73,560 |  |
| Non-current operating lease liabilities |  |  | 26,709 |  |  |  | 28,032 |  |
| Other liabilities |  |  | 37,394 |  |  |  | 44,293 |  |
| Long-term debt |  |  | 178,000 |  |  |  | 134,000 |  |
| Shareholders' equity |  |  | 1,015,277 |  |  |  | 1,019,696 |  |
|  |  | $ | 1,604,216 |  |  |  | 1,577,345 |  |

[0001104659-22-013878:8k_2_02:83]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Consolidated Statements of Cash Flows (Unaudited) |
| (Dollars in thousands) |
|  |  |  | Quarter Ended December 31, 2021 |  |  |  | Quarter Ended December 31, 2020 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 11,524 |  |  |  | 12,818 |  |
| Adjustments to reconcile net earnings to net cash |  |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 12,172 |  |  |  | 10,012 |  |
| Stock compensation expense |  |  | 1,685 |  |  |  | 1,368 |  |
| Changes in assets and liabilities |  |  | (30,837 | ) |  |  | 1,132 |  |
| Effect of deferred taxes |  |  | 7,402 |  |  |  | (538 | ) |
| Net cash provided by operating activities |  |  | 1,946 |  |  |  | 24,792 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Acquisition of business, net of cash acquired |  |  | (15,592 | ) |  |  | (6,508 | ) |
| Capital expenditures |  |  | (14,133 | ) |  |  | (5,973 | ) |
| Additions to capitalized software |  |  | (1,958 | ) |  |  | (1,554 | ) |
| Net cash used by investing activities |  |  | (31,683 | ) |  |  | (14,035 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from long-term debt |  |  | 74,000 |  |  |  | 30,000 |  |
| Principal payments on long-term debt and short-term borrowings |  |  | (30,000 | ) |  |  | (36,525 | ) |
| Dividends paid |  |  | (2,079 | ) |  |  | (2,084 | ) |
| Purchases of common stock into treasury |  |  | (9,997 | ) |  |  | 0 |  |
| Other |  |  | (2,737 | ) |  |  | 0 |  |
| Net cash provided (used) by financing activities |  |  | 29,187 |  |  |  | (8,609 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 33 |  |  |  | 2,654 |  |
| Net (decrease) increase in cash and cash equivalents |  |  | (517 | ) |  |  | 4,802 |  |
| Cash and cash equivalents, beginning of period |  |  | 56,232 |  |  |  | 52,560 |  |
| Cash and cash equivalents, end of period |  | $ | 55,715 |  |  |  | 57,362 |  |

[0001104659-22-013878:8k_2_02:84]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Other Selected Financial Data (Unaudited) |
| (Dollars in thousands) |
| Backlog And Entered Orders - Q1 2022 |  |  | Aerospace & Defense |  |  |  | USG |  |  |  | Test |  |  |  | Total |  |
| Beginning Backlog - 10/1/21 |  | $ | 367,216 |  |  |  | 91,631 |  |  |  | 133,176 |  |  |  | 592,023 |  |
| Entered Orders |  |  | 90,201 |  |  |  | 66,236 |  |  |  | 67,949 |  |  |  | 224,386 |  |
| Sales |  |  | (70,244 | ) |  |  | (63,485 | ) |  |  | (43,281 | ) |  |  | (177,010 | ) |
| Ending Backlog - 12/31/21 |  | $ | 387,173 |  |  |  | 94,382 |  |  |  | 157,844 |  |  |  | 639,399 |  |

[0001104659-22-013878:8k_2_02:85]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-22-013878:8k_2_02:86]
Reconciliation of Non-GAAP Financial Measures (Unaudited)

[0001104659-22-013878:8k_2_02:87]
| EPS – Adjusted Basis Reconciliation – Q1 2022 |  |  |  |
| EPS – GAAP Basis – Q1 2022 |  | $ | 0.44 |  |
| Adjustments (defined below) |  |  | 0.02 |  |
| EPS – As Adjusted Basis – Q1 2022 |  | $ | 0.46 |  |

[0001104659-22-013878:8k_2_02:88]
Adjustments exclude $0.02 per share consisting of Altanova & NEco acquisition inventory step-up charges and Corporate acquisition related costs in the first quarter of 2022.  The $0.02 of EPS adjustments per share consists of $825K of pre-tax charges offset by $190K of tax benefit for a net impact of $635K.

[0001104659-22-013878:8k_2_02:89]
| EPS – Adjusted Basis Reconciliation – Q1 2021 |  |  |  |
| EPS GAAP Basis – Q1 2021 |  | $ | 0.49 |  |
| Adjustments (defined below) |  |  | 0.03 |  |
| EPS – As Adjusted Basis – Q1 2021 |  | $ | 0.52 |  |

[0001104659-22-013878:8k_2_02:90]
Adjustments exclude $0.03 per share consisting of move costs associated with the Doble Manta facility consolidation and ATM acquisition inventory step-up in the first quarter of 2021.  The $0.03 of EPS adjustments per share consists of $1,030K of pre-tax charges offset by $237K of tax benefits for a net impact of $793K.
