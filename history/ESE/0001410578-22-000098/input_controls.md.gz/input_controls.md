# ESE 10-Q controls and the auditor's report


## item_4_controls

[0001410578-22-000098:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0001410578-22-000098:item_4_controls:2]
The Company carried out an evaluation, under the supervision and with the participation of Management, including the Company’s Chief Executive Officer and Chief Financial Officer, of the effectiveness of the design and operation of the Company’s disclosure controls and procedures as of the end of the period covered by this report. Based upon that evaluation, the Company’s Chief Executive Officer and Chief Financial Officer concluded that the Company’s disclosure controls and procedures were effective as of that date. Disclosure controls and procedures are controls and procedures that are designed to ensure that information required to be disclosed in Company reports filed or submitted under the Securities Exchange Act of 1934 (the “Exchange Act”) is recorded, processed, summarized and reported within the time periods specified in the Securities and Exchange Commission’s rules and forms.

[0001410578-22-000098:item_4_controls:3]
21

[0001410578-22-000098:item_4_controls:4]
As previously disclosed in Part II Item 9A in the Company’s Annual Report on Form 10-K for the year ended September 30, 2021, Management concluded there were material weaknesses in the Company’s internal control over financial reporting at a reporting unit within the Company’s Aerospace & Defense (A&D) segment, related to an ineffective design and implementation of certain controls over revenue recognition and the accumulation of inventory costs and the determination of inventory carrying values. Remedial actions have been identified and implemented to address these controls including the following: a) Dedicated additional resources to improve the Company’s risk assessment process to ensure that it is comprehensive, continuous, and designed to identify and assess changes that could significantly impact internal control over financial reporting; b) Improved Company policies, procedures and system and process controls related to inventory costing and revenue recognition; and c) Provided additional risk assessment training to the A&D segment finance department on the applicable financial reporting requirements and related accounting policies. During the first quarter of 2022, we completed our testing of the operating effectiveness of the implemented controls and found them to be effective. As a result, we have concluded the material weaknesses have been remediated as of December 31, 2021.

[0001410578-22-000098:item_4_controls:5]
Except for the changes in connection with our implementation of the remediation plan discussed above, there have been no other changes in the Company’s internal control over financial reporting (as defined in Rule 13a-15(f) under the Exchange Act) during the period covered by this report that has materially affected, or is reasonably likely to materially affect, the Company’s internal control over financial reporting.
