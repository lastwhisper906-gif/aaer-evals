# ESE notes — 0001144204-15-068633


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001144204-15-068633:notes:1]
|  | 1. | Summary of Significant Accounting Policies |

[0001144204-15-068633:notes:2]
|  | A. | Principles of Consolidation |

[0001144204-15-068633:notes:3]
The Consolidated Financial Statements include the accounts of ESCO Technologies Inc. (ESCO) and its wholly owned subsidiaries (the Company). All significant intercompany transactions and accounts have been eliminated in consolidation.

[0001144204-15-068633:notes:4]
|  | B. | Basis of Presentation |

[0001144204-15-068633:notes:5]
The Company’s fiscal year ends September 30. Throughout these Consolidated Financial Statements, unless the context indicates otherwise, references to a year (for example 2015) refer to the Company’s fiscal year ending on September 30 of that year.

[0001144204-15-068633:notes:6]
Aclara is reflected as discontinued operations and/or assets/liabilities held for sale in the consolidated financial statements and related notes for all periods presented, in accordance with accounting principles generally accepted in the United States of America (GAAP). Prior period amounts have been reclassified to conform to the current period presentation. See Note 2.

[0001144204-15-068633:notes:7]
|  | C. | Nature of Continuing Operations |

[0001144204-15-068633:notes:8]
The Company has three reportable segments: Filtration/Fluid Flow (Filtration), RF Shielding and Test (Test), and Utility Solutions Group (USG).

[0001144204-15-068633:notes:9]
Filtration: The companies within this segment primarily design and manufacture specialty filtration products including hydraulic filter elements and fluid control devices used in commercial aerospace applications, unique filter mechanisms used in micro-propulsion devices for satellites and custom designed filters for manned aircraft and submarines.

[0001144204-15-068633:notes:10]
Test: ETS-Lindgren Inc. (ETS-Lindgren) is an industry leader in providing its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy.

[0001144204-15-068633:notes:11]
USG:Doble Engineering Company (Doble) provides high-end, intelligent, diagnostic test solutions for the electric power delivery industry.

[0001144204-15-068633:notes:12]
|  | D. | Use of Estimates |

[0001144204-15-068633:notes:13]
The preparation of financial statements in conformity with GAAP requires Management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. The Company regularly evaluates the estimates and assumptions related to the allowance for doubtful trade receivables, inventory obsolescence, warranty reserves, value of equity-based awards, goodwill and purchased intangible asset valuations, asset impairments, employee benefit plan liabilities, income tax liabilities and assets and related valuation allowances, uncertain tax positions, estimates on long-term contracts, and litigation and other loss contingencies. Actual results could differ from those estimates.

[0001144204-15-068633:notes:14]
|  | E. | Revenue Recognition |

[0001144204-15-068633:notes:15]
Filtration:  Within the Filtration segment, approximately  87% of revenues (approximately  38% of consolidated revenues) are recognized when products are delivered (when title and risk of ownership transfers) or when services are performed for unaffiliated customers.

[0001144204-15-068633:notes:16]
Approximately  13% of segment revenues (approximately 6% of consolidated revenues) are recorded under the percentage-of-completion method. Products accounted for under this guidance include the design, development and manufacture of complex fluid control products, quiet valves, manifolds and systems primarily for the aerospace and military markets. For arrangements that are accounted for under this guidance, the Company estimates profit as the difference between total estimated revenue and total estimated cost of a contract and recognizes these revenues and costs based on units delivered. The percentage-of-completion method of accounting involves the use of various techniques to estimate expected costs at completion.

[0001144204-15-068633:notes:17]
Test: Within the Test segment, approximately  27% of revenues (approximately 9% of consolidated revenues) are recognized when products are delivered (when title and risk of ownership transfers) or when services are performed for unaffiliated customers.

[0001144204-15-068633:notes:18]
Approximately  73% of the segment’s revenues (approximately  24% of consolidated revenues) are recorded under the percentage-of-completion method due to the complex nature of the enclosures that are designed and produced under these contracts. Products accounted for under this guidance include the construction and installation of complex test chambers to a buyer’s specifications that provide its customers with the ability to measure and contain magnetic, electromagnetic and acoustic energy. As discussed above, for arrangements that are accounted for under this guidance, the Company estimates profit as the difference between total estimated revenue and total estimated cost of a contract and recognizes these revenues and costs based primarily on either (a) units delivered or (b) contract milestones.

[0001144204-15-068633:notes:19]
The percentage-of-completion method of accounting involves the use of various techniques to estimate expected costs at completion. These estimates are based on Management’s judgment and the Company’s substantial experience in developing these types of estimates.

[0001144204-15-068633:notes:20]
USG: Within the USG segment, approximately  100% of segment revenues (approximately  23% of consolidated revenues) are recognized when products are delivered (when title and risk of ownership transfers), when services are performed for unaffiliated customers or on a straight-line basis over the lease term.

[0001144204-15-068633:notes:21]
|  | F. | Cash and Cash Equivalents |

[0001144204-15-068633:notes:22]
Cash equivalents include temporary investments that are readily convertible into cash, such as money market funds.

[0001144204-15-068633:notes:23]
|  | G. | Accounts Receivable |

[0001144204-15-068633:notes:24]
Accounts receivable have been reduced by an allowance for amounts that the Company estimates are uncollectible in the future. This estimated allowance is based on Management’s evaluation of the financial condition of the customer and historical write-off experience.

[0001144204-15-068633:notes:25]
|  | H. | Costs and Estimated Earnings on Long-Term Contracts |

[0001144204-15-068633:notes:26]
Costs and estimated earnings on long-term contracts represent unbilled revenues, including accrued profits, accounted for under the percentage-of-completion method, net of progress billings.

[0001144204-15-068633:notes:27]
|  | I. | Inventories |

[0001144204-15-068633:notes:28]
Inventories are valued at the lower of cost (first-in, first-out) or market value. Inventories are regularly reviewed for excess quantities and obsolescence based upon historical experience, specific identification of discontinued items, future demand, and market conditions. Inventories under long-term contracts reflect accumulated production costs, factory overhead, initial tooling and other related costs less the portion of such costs charged to cost of sales and any unliquidated progress payments.

[0001144204-15-068633:notes:29]
|  | J. | Property, Plant and Equipment |

[0001144204-15-068633:notes:30]
Property, plant and equipment are recorded at cost. Depreciation and amortization are computed primarily on a straight-line basis over the estimated useful lives of the assets: buildings,  10-40 years; machinery and equipment,  3-10 years; and office furniture and equipment,  3-10 years. Leasehold improvements are amortized over the remaining term of the applicable lease or their estimated useful lives, whichever is shorter. Long-lived tangible assets are reviewed for impairment whenever events or changes in business circumstances indicate the carrying value of the assets may not be recoverable. Impairment losses are recognized based on fair value.

[0001144204-15-068633:notes:31]
|  | K. | Goodwill and Other Long-Lived Assets |

[0001144204-15-068633:notes:32]
Goodwill represents the excess of purchase costs over the fair value of net identifiable assets acquired in business acquisitions. Management annually reviews goodwill and other long-lived assets with indefinite useful lives for impairment or whenever events or changes in circumstances indicate the carrying amount may not be recoverable. If the Company determines that the carrying value of the long-lived asset may not be recoverable, a permanent impairment charge is recorded for the amount by which the carrying value of the long-lived asset exceeds its fair value. Fair value is measured based on a discounted cash flow method using a discount rate determined by Management to be commensurate with the risk inherent in the Company’s current business model. See Note 2.

[0001144204-15-068633:notes:33]
Other intangible assets represent costs allocated to identifiable intangible assets, principally capitalized software, patents, trademarks, and technology rights. See Note 4 regarding goodwill and other intangible assets activity.

[0001144204-15-068633:notes:34]
|  | L. | Capitalized Software |

[0001144204-15-068633:notes:35]
The costs incurred for the development of computer software that will be sold, leased, or otherwise marketed are charged to expense when incurred as research and development until technological feasibility has been established for the product. Technological feasibility is typically established upon completion of a detailed program design. Costs incurred after this point are capitalized on a project-by-project basis. Capitalized costs consist of internal and external development costs. Upon general release of the product to customers, the Company ceases capitalization and begins amortization, which is calculated on a project-by-project basis as the greater of (1) the ratio of current gross revenues for a product to the total of current and anticipated future gross revenues for the product or (2) the straight-line method over the estimated economic life of the product. The Company generally amortizes the software development costs over a three-to-seven year period based upon the estimated future economic life of the product. Factors considered in determining the estimated future economic life of the product include anticipated future revenues, and changes in software and hardware technologies. Management annually reviews the carrying values of capitalized costs for impairment or whenever events or changes in circumstances indicate the carrying amount may not be recoverable. If expected cash flows are insufficient to recover the carrying amount of the asset, then an impairment loss is recognized to state the asset at its net realizable value.

[0001144204-15-068633:notes:36]
|  | M. | Income Taxes |

[0001144204-15-068633:notes:37]
Income taxes are accounted for under the asset and liability method. Deferred tax assets and liabilities are recognized for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. Deferred tax assets may be reduced by a valuation allowance if it is more likely than not that some portion or all of the deferred tax assets will not be realized. The effect on deferred tax assets and liabilities of a change in tax rates is recognized in income in the period that includes the enactment date. The Company regularly reviews its deferred tax assets for recoverability and establishes a valuation allowance when Management believes it is more likely than not such assets will not be recovered, taking into consideration historical operating results, expectations of future earnings, tax planning strategies, and the expected timing of the reversals of existing temporary differences.

[0001144204-15-068633:notes:38]
|  | N. | Research and Development Costs |

[0001144204-15-068633:notes:39]
Company-sponsored research and development costs include research and development and bid and proposal efforts related to the Company’s products and services. Company-sponsored product development costs are charged to expense when incurred. Customer-sponsored research and development costs incurred pursuant to contracts are accounted for similarly to other program costs. Customer-sponsored research and development costs refer to certain situations whereby customers provide funding to support specific contractually defined research and development costs.

[0001144204-15-068633:notes:40]
|  | O. | Foreign Currency Translation |

[0001144204-15-068633:notes:41]
The financial statements of the Company’s foreign operations are translated into U.S. dollars in accordance with FASB ASC Topic 830, Foreign Currency Matters. The resulting translation adjustments are recorded as a separate component of accumulated other comprehensive income.

[0001144204-15-068633:notes:42]
|  | P. | Earnings Per Share |

[0001144204-15-068633:notes:43]
Basic earnings per share is calculated using the weighted average number of common shares outstanding during the period. Diluted earnings per share is calculated using the weighted average number of common shares outstanding during the period plus shares issuable upon the assumed exercise of dilutive common share options and vesting of performance-accelerated restricted shares using the treasury stock method.

[0001144204-15-068633:notes:44]
The number of shares used in the calculation of earnings per share for each year presented is as follows:

[0001144204-15-068633:notes:45]
| (in thousands) |  | 2015 |  | 2014 |  | 2013 |  |
| Weighted Average Shares Outstanding — Basic |  |  | 26,077 |  |  | 26,447 |  |  | 26,450 |  |
| Dilutive Options and Performance- Accelerated Restricted Stock |  |  | 188 |  |  | 197 |  |  | 352 |  |
| Shares — Diluted |  |  | 26,265 |  |  | 26,644 |  |  | 26,802 |  |

[0001144204-15-068633:notes:46]
Options to purchase  1,433 shares at a price of $37.54 were outstanding during the year ended September 30, 2014, but were not included in the respective computation of diluted EPS because the options’ exercise price was greater than the average market price of the common shares. Options to purchase  78,166 shares at prices ranging from $36.70-$37.98 were outstanding during the year ended September 30, 2013, but were not included in the respective computation of diluted EPS because the options’ exercise price was greater than the average market price of the common shares. All of the outstanding options had expired by the end of 2014.

[0001144204-15-068633:notes:47]
Approximately  131,000,  135,000 and  156,000 restricted shares were outstanding but unearned at September 30, 2015, 2014 and 2013, respectively, and therefore were not included in the respective years’ computations of diluted EPS.

[0001144204-15-068633:notes:48]
|  | Q. | Share-Based Compensation |

[0001144204-15-068633:notes:49]
The Company provides compensation benefits to certain key employees under several share-based plans providing for employee stock options and/or performance-accelerated restricted shares (restricted shares), and to non-employee directors under a non-employee directors compensation plan. Share-based payment expense is measured at the grant date based on the fair value of the award and is recognized on a straight-line basis over the requisite service period (generally the vesting period of the award).

[0001144204-15-068633:notes:50]
|  | R. | Accumulated Other Comprehensive Loss |

[0001144204-15-068633:notes:51]
Accumulated other comprehensive loss of $(32.5) million at September 30, 2015 consisted of $(29.2) million related to the pension net actuarial loss; $(3.2) million related to currency translation adjustments; and $(0.1) million related to forward exchange contracts. Accumulated other comprehensive loss of $(19.2) million at September 30, 2014 consisted of $(22.3) million related to the pension net actuarial loss; and $3.1 million related to currency translation adjustments.

[0001144204-15-068633:notes:52]
|  | S. | Deferred Revenue And Costs |

[0001144204-15-068633:notes:53]
Deferred revenue and costs are recorded when products or services have been provided but the criteria for revenue recognition have not been met. If there is a customer acceptance provision or there is uncertainty about customer acceptance, revenue and costs are deferred until the customer has accepted the product or service.

[0001144204-15-068633:notes:54]
|  | T. | Derivative Financial Instruments |

[0001144204-15-068633:notes:55]
All derivative financial instruments are reported on the balance sheet at fair value. The accounting for changes in fair value of a derivative instrument depends on whether it has been designated and qualifies as a hedge and on the type of hedge. For each derivative instrument designated as a cash flow hedge, the effective portion of the gain or loss on the derivative is deferred in accumulated other comprehensive income until recognized in earnings with the underlying hedged item. For each derivative instrument designated as a fair value hedge, the gain or loss on the derivative and the offsetting gain or loss on the hedged item are recognized immediately in earnings. Regardless of type, a fully effective hedge will result in no net earnings impact while the derivative is outstanding. To the extent that any hedge is ineffective at offsetting cash flow or fair value changes in the underlying hedged item, there could be a net earnings impact.

[0001144204-15-068633:notes:56]
|  | U. | Fair Value Measurements |

[0001144204-15-068633:notes:57]
Fair value is defined as the price at which an asset could be exchanged in a current transaction between knowledgeable, willing parties or the amount that would be paid to transfer a liability to a new obligor, not the amount that would be paid to settle the liability with the creditor. Where available, fair value is based on observable market prices or parameters or derived from such prices or parameters. Where observable prices or inputs are not available, valuation models are applied. These valuation techniques involve some level of Management estimation and judgment, the degree of which is dependent on the price transparency for the instruments or market and the instruments’ complexity.

[0001144204-15-068633:notes:58]
The accounting guidance establishes a three-level hierarchy for disclosure of fair value measurements, based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date, as follows:

[0001144204-15-068633:notes:59]
Level 1 – Inputs to the valuation methodology are quoted prices (unadjusted) for identical assets or liabilities in active markets.

[0001144204-15-068633:notes:60]
Level 2 –Inputs to the valuation methodology include quoted prices for similar assets and liabilities in active markets, and inputs that are observable for the asset or liability, either directly or indirectly, for substantially the full term of the financial instrument.

[0001144204-15-068633:notes:61]
Level 3 – Inputs to the valuation methodology are unobservable and significant to the fair value measurement.

[0001144204-15-068633:notes:62]
Financial Assets and Liabilities

[0001144204-15-068633:notes:63]
The Company has estimated the fair value of its financial instruments as of September 30, 2015 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, debt and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001144204-15-068633:notes:64]
Nonfinancial Assets and Liabilities

[0001144204-15-068633:notes:65]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during 2015.

[0001144204-15-068633:notes:66]
|  | V. | New Accounting Standards |

[0001144204-15-068633:notes:67]
In April 2015, the FASB issued ASU No. 2015-03, Interest – Imputation of Interest (Subtopic 835-30), which requires that debt issuance costs be presented in the balance sheet as a direct deduction from the carrying amount of debt liability, consistent with debt discounts or premiums. The new standard is effective for fiscal years beginning after December 15, 2015, and interim periods within fiscal years beginning after December 15, 2016. Early adoption is permitted and will be applied on a retrospective basis. We have evaluated the impact of this standard and do not anticipate a material impact on our consolidated financial statements and related disclosures upon adoption.

[0001144204-15-068633:notes:68]
In July 2015, the FASB affirmed its proposed one-year deferral of ASU No. 2014-09, Revenue from Contracts with Customers, which requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. The new standard will be effective for annual reporting periods beginning after December 15, 2017, and interim periods within those annual periods. Early application is not permitted. The standard permits the use of either the retrospective or cumulative effect transition method. The Company is currently in the process of evaluating the effect that ASU 2014-09 will have on its consolidated financial statements and related disclosures and selecting the method of transition to the new standard.

[0001144204-15-068633:notes:69]
In July 2015, the FASB issued ASU No. 2015-11, Inventory (Topic 330): Simplifying the Measurement of Inventory, which requires entities to measure most inventory “at the lower of cost and net realizable value,” thereby simplifying the current guidance under which an entity must measure inventory at the lower of cost or market. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. The new standard is effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years. ASU 2015-11 should be applied prospectively with earlier application permitted as of the beginning of an interim or annual reporting period. The Company is currently assessing the impact of this new standard on its consolidated financial statements and related disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001144204-15-068633:notes:70]
|  | 3. | Acquisitions |

[0001144204-15-068633:notes:71]
2015

[0001144204-15-068633:notes:72]
On January 28, 2015, the Company acquired the assets of Enoserv LLC (Enoserv), headquartered in Tulsa, Oklahoma, for $20.5 million in cash. Enoserv provides utility customers with high quality, user-friendly multi-platform software and has annual revenues of approximately $8 million. Since the date of acquisition the operating results for Enoserv have been included as part of Doble within the Company’s USG segment. Based on the preliminary purchase price allocation, the Company recorded approximately $10.0 million of goodwill and $9.0 million of amortizable identifiable intangible assets consisting primarily of customer relationships and developed technology.

[0001144204-15-068633:notes:73]
2013

[0001144204-15-068633:notes:74]
During 2013, the Company made three acquisitions:

[0001144204-15-068633:notes:75]
•     It acquired the stock of Canyon Engineering Products, Inc. (“Canyon”) for $9.2 million in cash, and purchased Canyon’s  70,000 square foot manufacturing facility in Valencia, California for $7 million in cash. The Company recorded approximately $1.3 million of goodwill related to the transaction and $1.7 million of amortizable identifiable intangible assets consisting primarily of customer relationships. Canyon’s products, technology and customers were very similar to those of Crissair, Inc. The operating results for Canyon since the date of acquisition were included as part of Crissair within the Company’s Filtration segment, and during 2014, Canyon’s and Crissair’s operations were completely consolidated into the Valencia facility.

[0001144204-15-068633:notes:76]
•     It acquired the assets of Felix Tool & Engineering, Inc. (“Felix Tool”) for a purchase price of $1.2 million in cash. The purchase price was allocated to property, plant and equipment and inventory based on fair market value at the date of acquisition and there were no intangible assets recorded upon the transaction. Felix Tool was engaged in the design, manufacture and sale of customized perforated tubes for filtration applications in the aerospace and fluid power industry, and the operating results for this business since the date of acquisition have been included as part of PTI in the Filtration segment.

[0001144204-15-068633:notes:77]
|  | • | It acquired the assets of Finepoint Marketing, Inc. (“Finepoint”) for a purchase price of $2.5 million. The Company recorded approximately $1.3 million of goodwill as a result of the transaction and $1.2 million of amortizable identifiable intangible assets consisting of customer relationships. Finepoint was the electric power industry’s leading conference provider focused on medium and high voltage circuit breakers, as well as related substation and switchgear topics, and the operating results for this business since the date of acquisition have been included as part of Doble in the USG segment. |

[0001144204-15-068633:notes:78]
All of the Company’s acquisitions have been accounted for using the purchase method of accounting and accordingly, the respective purchase prices were allocated to the assets (including intangible assets) acquired and liabilities assumed based on estimated fair values at the date of acquisition. The financial results from these acquisitions have been included in the Company’s financial statements from the date of acquisition. Pro forma financial information related to the Company’s acquisitions was not presented as it was not significant to the Company’s results of operations. None of the goodwill recorded as part of the acquisitions mentioned above is expected to be deductible for U.S. Federal or state income tax purposes.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001144204-15-068633:notes:79]
|  | 18. | Quarterly Financial Information (Unaudited) |

[0001144204-15-068633:notes:80]
|  |  | First |  | Second |  | Third |  | Fourth |  | Fiscal |  |
| (Dollars in thousands, except per share amounts) |  | Quarter |  | Quarter |  | Quarter |  | Quarter |  | Year |  |
| 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 120,547 |  |  | 128,941 |  |  | 134,191 |  |  | 153,612 |  |  | 537,291 |  |
| Net earnings from continuing operations |  |  | 10,023 |  |  | 7,982 |  |  | 10,748 |  |  | 12,983 |  |  | 41,736 |  |
| Net (loss) earnings from discontinued operations |  |  | — |  |  | (372) |  |  | 1,148 |  |  | — |  |  | 776 |  |
| Net earnings |  |  | 10,023 |  |  | 7,610 |  |  | 11,896 |  |  | 12,983 |  |  | 42,512 |  |
| Basic earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings from continuing operations |  |  | 0.38 |  |  | 0.31 |  |  | 0.41 |  |  | 0.50 |  |  | 1.60 |  |
| Net (loss) earnings from discontinued operations |  |  | — |  |  | (0.01) |  |  | 0.04 |  |  | — |  |  | 0.03 |  |
| Net earnings |  |  | 0.38 |  |  | 0.30 |  |  | 0.45 |  |  | 0.50 |  |  | 1.63 |  |
| Diluted earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings from continuing operations |  |  | 0.38 |  |  | 0.30 |  |  | 0.41 |  |  | 0.50 |  |  | 1.59 |  |
| Net (loss) earnings from discontinued operations |  |  | — |  |  | (0.01) |  |  | 0.04 |  |  | — |  |  | 0.03 |  |
| Net earnings |  |  | 0.38 |  |  | 0.29 |  |  | 0.45 |  |  | 0.50 |  |  | 1.62 |  |
| Dividends declared per common share |  | $ | 0.08 |  |  | 0.08 |  |  | 0.08 |  |  | 0.08 |  |  | 0.32 |  |
| 2014 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 124,450 |  |  | 124,762 |  |  | 130,495 |  |  | 151,413 |  |  | 531,120 |  |
| Net earnings from continuing operations |  |  | 8,832 |  |  | 9,264 |  |  | 11,590 |  |  | 12,927 |  |  | 42,613 |  |
| Net (loss) earnings from discontinued operations |  |  | 2,357 |  |  | (42,941) |  |  | — |  |  | (1,619) |  |  | (42,203) |  |
| Net (loss) earnings |  |  | 11,189 |  |  | (33,677) |  |  | 11,590 |  |  | 11,308 |  |  | 410 |  |
| Basic earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings from continuing operations |  |  | 0.33 |  |  | 0.35 |  |  | 0.44 |  |  | 0.49 |  |  | 1.61 |  |
| Net (loss) earnings from discontinued operations |  |  | 0.09 |  |  | (1.62) |  |  | — |  |  | (0.06) |  |  | (1.59) |  |
| Net (loss) earnings |  |  | 0.42 |  |  | (1.27) |  |  | 0.44 |  |  | 0.43 |  |  | 0.02 |  |
| Diluted earnings (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings from continuing operations |  |  | 0.33 |  |  | 0.35 |  |  | 0.43 |  |  | 0.49 |  |  | 1.60 |  |
| Net (loss) earnings from discontinued operations |  |  | 0.09 |  |  | (1.61) |  |  | — |  |  | (0.06) |  |  | (1.58) |  |
| Net (loss) earnings |  |  | 0.42 |  |  | (1.26) |  |  | 0.43 |  |  | 0.43 |  |  | 0.02 |  |
| Dividends declared per common share |  | $ | 0.08 |  |  | 0.08 |  |  | 0.08 |  |  | 0.08 |  |  | 0.32 |  |

[0001144204-15-068633:notes:81]
During the fourth quarter of 2015, the Company disclosed certain non-cash charges related to the Test segment. Of these pretax charges, $4.3 million related to inventory and cost of goods sold resulting from the incorrect capitalization of certain costs in periods prior to the fourth quarter of 2015 that resulted in inventory being overstated and cost of goods sold being understated. Management determined $1.2 million (pretax) related to the first quarter of 2015 and $1.0 million (pretax) related to the second quarter of 2015; therefore, the 2015 quarterly results above have been adjusted to reflect these amounts in the proper periods. The fourth quarter of 2015 includes the remaining $2.1 million (pretax) of charges relating to prior years. These charges were not considered material to the previously-issued financial statements for the prior years and prior quarters within 2015. See the table below for the impact of the adjustments on the previously reported first and second quarters of 2015:

[0001144204-15-068633:notes:82]
|  |  | Q1 as Reported |  | Q1 as Adjusted |  | Q2 as Reported |  | Q2 as Adjusted |  |
| Cost of sales |  | $ | 70,420 |  |  | 71,621 |  |  | 80,140 |  |  | 81,142 |  |
| Earnings before income taxes |  |  | 14,776 |  |  | 13,575 |  |  | 13,791 |  |  | 12,789 |  |
| Income tax expense |  |  | 3,948 |  |  | 3,552 |  |  | 5,144 |  |  | 4,807 |  |
| Net earnings from continuing operations |  |  | 10,828 |  |  | 10,023 |  |  | 8,647 |  |  | 7,982 |  |
| Diluted net earnings per share |  | $ | 0.41 |  |  | 0.38 |  |  | 0.32 |  |  | 0.29 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001144204-15-068633:notes:83]
|  | 4. | Goodwill and Other Intangible Assets |

[0001144204-15-068633:notes:84]
Included on the Company’s Consolidated Balance Sheets at September 30, 2015 and 2014 are the following intangible assets gross carrying amounts and accumulated amortization:

[0001144204-15-068633:notes:85]
| (Dollars in millions) |  | 2015 |  | 2014 |  |
| Goodwill |  | $ | 291.2 |  |  | 282.3 |  |
| Intangible assets with determinable lives: |  |  |  |  |  |  |  |
| Patents |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 1.0 |  |  | 1.0 |  |
| Less: accumulated amortization |  |  | 0.8 |  |  | 0.8 |  |
| Net |  | $ | 0.2 |  |  | 0.2 |  |
| Capitalized software |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 45.5 |  |  | 37.4 |  |
| Less: accumulated amortization |  |  | 20.1 |  |  | 15.2 |  |
| Net |  | $ | 25.4 |  |  | 22.2 |  |
| Customer Relationships |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 70.5 |  |  | 64.1 |  |
| Less: accumulated amortization |  |  | 24.7 |  |  | 21.2 |  |
| Net |  | $ | 45.8 |  |  | 42.9 |  |
| Other |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 2.6 |  |  | 0.4 |  |
| Less: accumulated amortization |  |  | 0.4 |  |  | 0.2 |  |
| Net |  | $ | 2.2 |  |  | 0.2 |  |
| Intangible assets with indefinite lives: |  |  |  |  |  |  |  |
| Trade names |  | $ | 117.1 |  |  | 116.6 |  |

[0001144204-15-068633:notes:86]
The Company performed its annual evaluation of goodwill and intangible assets for impairment during the fourth quarter of 2015 and concluded no impairment existed at September 30, 2015.

[0001144204-15-068633:notes:87]
The changes in the carrying amount of goodwill attributable to each business segment for 2015 and 2014 are as follows:

[0001144204-15-068633:notes:88]
| (Dollars in millions) |  | USG |  | Test |  | Filtration |  | Total |  |
| Balance as of September 30, 2013 |  | $ | 217.3 |  |  | 35.0 |  |  | 30.6 |  |  | 282.9 |  |
| Acquisitions/adjustments |  |  | (0.5) |  |  | (0.3) |  |  | 0.2 |  |  | (0.6) |  |
| Balance as of September 30, 2014 |  |  | 216.8 |  |  | 34.7 |  |  | 30.8 |  |  | 282.3 |  |
| Adjustments |  |  | 9.4 |  |  | (0.5) |  |  | - |  |  | 8.9 |  |
| Balance as of September 30, 2015 |  | $ | 226.2 |  |  | 34.2 |  |  | 30.8 |  |  | 291.2 |  |

[0001144204-15-068633:notes:89]
Amortization expense related to intangible assets with determinable lives was $8.9 million, $6.7 million and $6.2 million in 2015, 2014 and 2013, respectively. Patents are amortized over the life of the patents, generally 17 years. Capitalized software is amortized over the estimated useful life of the software, generally three to seven years. Customer relationships are generally amortized over twenty years. Intangible asset amortization for fiscal years 2016 through 2020 is estimated at approximately $9.0 million per year.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001144204-15-068633:notes:90]
|  | 5. | Accounts Receivable |

[0001144204-15-068633:notes:91]
Accounts receivable, net of the allowance for doubtful accounts, consist of the following at September 30, 2015 and 2014:

[0001144204-15-068633:notes:92]
| (Dollars in thousands) |  | 2015 |  | 2014 |  |
| Commercial |  | $ | 99,083 |  |  | 101,153 |  |
| U.S. Government and prime contractors |  |  | 3,524 |  |  | 4,296 |  |
| Total |  | $ | 102,607 |  |  | 105,449 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001144204-15-068633:notes:93]
|  | 6. | Inventories |

[0001144204-15-068633:notes:94]
Inventories consist of the following at September 30, 2015 and 2014:

[0001144204-15-068633:notes:95]
| (Dollars in thousands) |  | 2015 |  | 2014 |  |
| Finished goods |  | $ | 19,120 |  |  | 18,949 |  |
| Work in process — including long-term contracts |  |  | 33,176 |  |  | 31,634 |  |
| Raw materials |  |  | 47,490 |  |  | 43,709 |  |
| Total |  | $ | 99,786 |  |  | 94,292 |  |


## us-gaap:ScheduleOfFutureMinimumRentalPaymentsForOperatingLeasesTableTextBlock

[0001144204-15-068633:notes:96]
Future aggregate minimum lease payments under operating leases that have initial or remaining non-cancelable lease terms in excess of one year as of September 30, 2015, are:

[0001144204-15-068633:notes:97]
| (Dollars in thousands) |  |  |  |
| Years ending September 30: |  |  |  |
| 2016 |  |  | 4,750 |  |
| 2017 |  |  | 3,565 |  |
| 2018 |  |  | 2,772 |  |
| 2019 |  |  | 2,007 |  |
| 2020 and thereafter |  |  | 1,458 |  |
| Total |  | $ | 14,552 |  |


## us-gaap:ScheduleOfErrorCorrectionsAndPriorPeriodAdjustmentsTextBlock

[0001144204-15-068633:notes:98]
The financial statements for the prior years have not been restated on the basis that the amounts are not material to the prior periods. See the table below for the 2015 quarterly reconciliation:


## us-gaap:IncomeTaxDisclosureTextBlock

[0001144204-15-068633:notes:99]
|  | 8. | Income Tax Expense |

[0001144204-15-068633:notes:100]
Total income tax expense (benefit) for 2015, 2014 and 2013 was allocated to income tax expense as follows:

[0001144204-15-068633:notes:101]
| (Dollars in thousands) |  | 2015 |  | 2014 |  | 2013 |  |
| Income tax expense from Continuing Operations |  | $ | 19,785 |  |  | 19,594 |  |  | 18,335 |  |
| Income tax (benefit) expense from Discontinued Operations |  |  | 390 |  |  | (6,034) |  |  | (5,215) |  |
| Total income tax expense |  | $ | 20,175 |  |  | 13,560 |  |  | 13,120 |  |

[0001144204-15-068633:notes:102]
The components of income from continuing operations before income taxes for 2015, 2014 and 2013 consisted of the following:

[0001144204-15-068633:notes:103]
| (Dollars in thousands) |  | 2015 |  | 2014 |  | 2013 |  |
| United States |  | $ | 56,661 |  |  | 56,196 |  |  | 43,159 |  |
| Foreign |  |  | 4,860 |  |  | 6,011 |  |  | 6,436 |  |
| Total income before income taxes |  | $ | 61,521 |  |  | 62,207 |  |  | 49,595 |  |

[0001144204-15-068633:notes:104]
The principal components of income tax expense (benefit) from continuing operations for 2015, 2014 and 2013 consist of:

[0001144204-15-068633:notes:105]
| (Dollars in thousands) |  | 2015 |  | 2014 |  | 2013 |  |
| Federal: |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 11,906 |  |  | 18,756 |  |  | 10,723 |  |
| Deferred |  |  | 5,406 |  |  | (2,442) |  |  | 2,942 |  |
| State and local: |  |  |  |  |  |  |  |  |  |  |
| Current |  |  | 867 |  |  | 1,397 |  |  | 896 |  |
| Deferred |  |  | 16 |  |  | (245) |  |  | 642 |  |
| Foreign: |  |  |  |  |  |  |  |  |  |  |
| Current |  |  | 1,525 |  |  | 2,044 |  |  | 2,033 |  |
| Deferred |  |  | 65 |  |  | 84 |  |  | 1,099 |  |
| Total |  | $ | 19,785 |  |  | 19,594 |  |  | 18,335 |  |

[0001144204-15-068633:notes:106]
The actual income tax expense (benefit) from continuing operations for 2015, 2014 and 2013 differs from the expected tax expense for those years (computed by applying the U.S. Federal corporate statutory rate) as follows:

[0001144204-15-068633:notes:107]
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Federal corporate statutory rate |  |  | 35.0 | % |  | 35.0 | % |  | 35.0 | % |
| State and local, net of Federal benefits |  |  | 1.2 |  |  | 2.0 |  |  | 2.7 |  |
| Foreign |  |  | (1.5) |  |  | (1.7) |  |  | (1.9) |  |
| Research credit |  |  | (1.8) |  |  | (1.0) |  |  | (2.5) |  |
| Domestic production deduction |  |  | (2.6) |  |  | (2.9) |  |  | (2.5) |  |
| Change in uncertain tax positions |  |  | (0.2) |  |  | (2.9) |  |  | 0.1 |  |
| Executive compensation |  |  | 0.9 |  |  | 1.3 |  |  | 1.8 |  |
| Valuation allowance |  |  | 1.0 |  |  | 1.3 |  |  | 4.0 |  |
| Other, net |  |  | 0.2 |  |  | 0.4 |  |  | 0.3 |  |
| Effective income tax rate |  |  | 32.2 | % |  | 31.5 | % |  | 37.0 | % |

[0001144204-15-068633:notes:108]
The tax effects of temporary differences that give rise to significant portions of the deferred tax assets and liabilities at September 30, 2015 and 2014 are presented below:

[0001144204-15-068633:notes:109]
| (Dollars in thousands) |  | 2015 |  | 2014 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |
| Inventories |  | $ | 6,336 |  |  | 7,710 |  |
| Pension and other postretirement benefits |  |  | 11,663 |  |  | 6,974 |  |
| Net operating loss carryforward — domestic |  |  | 520 |  |  | 658 |  |
| Net operating loss carryforward — foreign |  |  | 4,135 |  |  | 4,702 |  |
| Other compensation-related costs and other cost accruals |  |  | 11,785 |  |  | 13,996 |  |
| State credit carryforward |  |  | 1,704 |  |  | 1,276 |  |
| Total deferred tax assets |  |  | 36,143 |  |  | 35,316 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |
| Goodwill |  |  | (14,829) |  |  | (14,338) |  |
| Acquisition assets |  |  | (57,415) |  |  | (57,795) |  |
| Depreciation, software amortization |  |  | (18,681) |  |  | (16,380) |  |
| Net deferred tax liabilities before valuation allowance |  |  | (54,782) |  |  | (53,197) |  |
| Less valuation allowance |  |  | (4,129) |  |  | (4,297) |  |
| Net deferred tax liabilities |  | $ | (58,911) |  |  | (57,494) |  |

[0001144204-15-068633:notes:110]
The Company has a foreign net operating loss carryforward of $16.5 million at September 30, 2015, which reflects tax loss carryforwards in Brazil, Germany, India, Finland, China and the United Kingdom. $15.1 million of the tax loss carryforwards have no expiration date while the remaining $1.4 million will expire between 2017 and 2025. The Company has state net operating loss carryforwards of $0.3 million at September 30, 2015 which expire between 2020 and 2033. The Company also has net state research and other credit carryforwards of $1.7 million of which $1.3 million expires between 2025 and 2035. The remaining $0.4 million does not have an expiration date.

[0001144204-15-068633:notes:111]
The valuation allowance for deferred tax assets as of September 30, 2015 and 2014 was $4.1 million and $4.3 million, respectively. The net change in the total valuation allowance for each of the years ended September 30, 2015 and 2014 was a decrease of $0.2 million and an increase of $0.5 million, respectively. The Company has established a valuation allowance against state credit carryforwards of $0.5 million and $0.4 million at September 30, 2015 and 2014. In addition, the Company has established a valuation allowance against state net operating loss (NOL) carryforwards that are not expected to be realized in future periods of $0.3 million at both September 30, 2015 and 2014, respectively. Lastly, the Company has established a valuation allowance against certain NOL carryforwards in foreign jurisdictions which may not be realized in future periods. The valuation allowance established against the foreign NOL carryforwards was $3.3 million and $3.6 million at September 30, 2015, and 2014, respectively. The Company classifies its valuation allowance related to deferred taxes on a pro rata basis by taxing jurisdiction.

[0001144204-15-068633:notes:112]
The Company’s foreign subsidiaries have accumulated unremitted earnings of $35.3 million and cash of $31.5 million at September 30, 2015. No deferred taxes have been provided on these accumulated unremitted earnings because these funds are not needed to meet the liquidity requirements of the Company’s U.S. operations and it is the Company’s intention to indefinitely reinvest these earnings in continuing international operations. In the event these foreign entities’ earnings were distributed, it is estimated that U.S. taxes, net of available foreign tax credits, of approximately $4.9 million would be due, which would correspondingly reduce the Company’s net earnings. No significant portion of the Company’s foreign subsidiaries’ earnings was taxed at a very low tax rate.

[0001144204-15-068633:notes:113]
As of September 30, 2015, the Company had $0.1 million of unrecognized benefits (see table below), which, net of Federal benefit, if recognized, would affect the Company’s effective tax rate.

[0001144204-15-068633:notes:114]
A reconciliation of the Company’s unrecognized tax benefits for the years ended September 30, 2015 and 2014 is presented in the table below:

[0001144204-15-068633:notes:115]
| (Dollars in millions) |  | 2015 |  | 2014 |  |
| Balance as of October 1, |  | $ | 0.5 |  |  | 2.2 |  |
| Decreases related to prior year tax positions |  |  | (0.1) |  |  | (0.7) |  |
| Decreases related to settlements with taxing authorities |  |  | (0.2) |  |  | — |  |
| Lapse of statute of limitations |  |  | (0.1) |  |  | (1.0) |  |
| Balance as of September 30, |  | $ | 0.1 |  |  | 0.5 |  |

[0001144204-15-068633:notes:116]
The Company does not anticipate a material change in the amount of unrecognized tax benefits in the next 12 months. The Company’s policy is to include interest related to unrecognized tax benefits in income tax expense and penalties in operating expense. As of September 30, 2015, 2014 and 2013, the Company had accrued interest related to uncertain tax positions of zero, zero and $0.1 million, respectively, net of Federal income tax benefit, on its Consolidated Balance Sheet. No significant penalties have been accrued.

[0001144204-15-068633:notes:117]
The principal jurisdictions for which the Company files income tax returns are U.S. Federal and the various city, state, and international locations where the Company has operations. The U.S. Federal tax years for the periods ended September 30, 2012 and forward remain subject to income tax examination. Various state tax years for the periods ended September 30, 2011 and forward remain subject to income tax examinations. The Company is subject to income tax in many jurisdictions outside the United States, none of which is individually material to the Company’s financial position, statements of cash flows, or results of operations.


## us-gaap:DebtDisclosureTextBlock

[0001144204-15-068633:notes:118]
|  | 9. | Debt |

[0001144204-15-068633:notes:119]
Debt consists of the following at September 30, 2015 and 2014:

[0001144204-15-068633:notes:120]
| (Dollars in thousands) |  | 2015 |  | 2014 |  |
| Revolving credit facility, including current portion |  | $ | 50,000 |  |  | 40,000 |  |
| Current portion of long-term debt |  |  | (20,000) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 30,000 |  |  | 20,000 |  |

[0001144204-15-068633:notes:121]
On May 14, 2012, the Company entered into a new $450 million five-year revolving credit facility with JPMorgan Chase Bank, N.A., as administrative agent, PNC Bank, N.A., as syndication agent, and eight other participating lenders (the “Credit Facility”). Through a credit facility expansion option, the Company may elect to increase the size of the Credit Facility by entering into incremental term loans, in any agreed currency, at a minimum of $25 million each up to a maximum of $250 million aggregate. The Company’s ability to access the additional $250 million increase option of the Credit Facility is subject to acceptance by participating or other outside banks.

[0001144204-15-068633:notes:122]
At September 30, 2015, the Company had approximately $392 million available to borrow under the Credit Facility, plus a $250 million increase option, in addition to $39.4 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of September 30, 2015, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months.

[0001144204-15-068633:notes:123]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from  17.5 to 35 basis points per annum on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a  65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. During 2015 and 2014, the maximum aggregate short-term borrowings at any month-end were $83 million and $187 million, respectively; the average aggregate short-term borrowings outstanding based on month-end balances were $68.5 million and $103 million, respectively; and the weighted average interest rates were  1.27%,  1.48% and  1.55% for 2015, 2014 and 2013, respectively. The letters of credit issued and outstanding under the Credit Facility totaled $8.0 million and $11 million at September 30, 2015 and 2014, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001144204-15-068633:notes:124]
|  | 10. | Capital Stock |

[0001144204-15-068633:notes:125]
The 30,358,864 and 30,247,512 common shares as presented in the accompanying Consolidated Balance Sheets at September 30, 2015 and 2014 represent the actual number of shares issued at the respective dates. The Company held 4,542,214 and 4,040,532 common shares in treasury at September 30, 2015 and 2014, respectively.

[0001144204-15-068633:notes:126]
In August 2012, the Company’s Board of Directors authorized a common stock repurchase program under which the Company may repurchase shares of its stock from time to time in its discretion, in the open market or otherwise, up to a maximum total repurchase amount of $100 million (or such lesser amount as may be permitted under the Company’s bank credit agreements). This program has been repeatedly extended by the Company’s Board of Directors and is currently scheduled to expire September 30, 2017. The Company repurchased approximately 517,000 shares for $18.2 million in 2015; 350,000 shares for $12.0 million in 2014; and 270,000 shares for $9.7 million in 2013.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001144204-15-068633:notes:127]
|  | 11. | Share-Based Compensation |

[0001144204-15-068633:notes:128]
The Company provides compensation benefits to certain key employees under several share-based plans providing for employee stock options and/or performance-accelerated restricted shares (restricted shares), and to non-employee directors under a non-employee directors compensation plan.

[0001144204-15-068633:notes:129]
Performance-Accelerated Restricted Share Awards

[0001144204-15-068633:notes:130]
The performance-accelerated restricted shares (restricted shares) have a five-year term with accelerated vesting if certain targets based on market conditions are achieved. In these cases, if it is probable that the performance condition will be met, the Company recognizes compensation cost on a straight-line basis over the shorter performance period; otherwise, it will recognize compensation cost over the longer service period. Compensation cost for the majority of the outstanding restricted share awards is being recognized over the shorter performance period as it is probable the performance condition will be met. The restricted share award grants were valued at the stock price on the date of grant. Pretax compensation expense related to the restricted share awards for continuing operations was $4.0 million, $4.1 million and $4 million for 2015, 2014 and 2013, respectively.

[0001144204-15-068633:notes:131]
The following summary presents information regarding outstanding restricted share awards as of September 30, 2015, and changes during the period then ended:

[0001144204-15-068633:notes:132]
|  |  |  |  | Weighted |  |
|  |  | Shares |  | Average Price |  |
| Nonvested at September 30, 2014 |  |  | 332,340 |  | $ | 32.23 |  |
| Granted |  |  | 123,501 |  |  | 34.33 |  |
| Vested |  |  | (129,305) |  |  | 26.66 |  |
| Cancelled |  |  | – |  |  | – |  |
| Nonvested at September 30, 2015 |  |  | 326,536 |  | $ | 35.29 |  |

[0001144204-15-068633:notes:133]
Non-Employee Directors Plan

[0001144204-15-068633:notes:134]
The non-employee directors compensation plan provides to each non-employee director a retainer of  900 common shares per quarter. Compensation expense related to the non-employee director grants was $0.8 million, $0.7 million and $0.6 million for 2015, 2014 and 2013, respectively.

[0001144204-15-068633:notes:135]
Stock Option Plans

[0001144204-15-068633:notes:136]
The Company’s stock option awards have generally been subject to graded vesting over a three-year service period. All outstanding options were granted at prices equal to fair market value at the date of grant. Beginning in fiscal 2004, the options granted have had a five-year contractual life from date of issuance. The Company recognizes compensation cost on a straight-line basis over the requisite service period for the entire award.

[0001144204-15-068633:notes:137]
The fair value of each option award is estimated as of the date of grant using the Black-Scholes option pricing model. Expected volatility is based on historical volatility of the Company’s stock calculated over the expected term of the option. The Company utilizes historical company data to develop its expected term assumption. The risk-free rate for the expected term of the option is based on the U.S. Treasury yield curve in effect at the date of grant.

[0001144204-15-068633:notes:138]
Information regarding stock options awarded under the option plans is as follows:

[0001144204-15-068633:notes:139]
|  |  | FY 2015 |  | FY 2014 |  | FY 2013 |  |
|  |  |  |  |  | Estimated |  |  |  |  | Estimated |  |  |  |  | Estimated |  |
|  |  |  |  |  | Weighted |  |  |  |  | Weighted |  |  |  |  | Weighted |  |
|  |  | Shares |  | Avg. Price |  | Shares |  | Avg. Price |  | Shares |  | Avg. Price |  |
| Outstanding October 1, |  |  | — |  | $ | — |  |  | 67,350 |  | $ | 37.39 |  |  | 125,816 |  | $ | 36.29 |  |
| Granted |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Exercised |  |  | — |  | $ | — |  |  | — |  | $ | — |  |  | (51,116) |  | $ | 34.70 |  |
| Cancelled |  |  | — |  | $ | — |  |  | (67,350) |  | $ | 37.39 |  |  | (7,350) |  | $ | 37.30 |  |
| Outstanding September 30, |  |  | — |  | $ | — |  |  | — |  | $ | — |  |  | 67,350 |  | $ | 37.39 |  |
| At September 30, |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Reserved for future grant |  |  | 500,000 |  |  |  |  |  | 500,000 |  |  |  |  |  | 500,000 |  |  |  |  |
| Exercisable |  |  | — |  | $ | — |  |  | — |  | $ | — |  |  | 67,350 |  | $ | 37.39 |  |

[0001144204-15-068633:notes:140]
The aggregate intrinsic value of stock options exercised during 2013 was $0.3 million; no stock options were exercised during 2015 or 2014. No stock options were granted during 2015, 2014 or 2013, and no stock options were outstanding at September 30, 2015 or 2014.

[0001144204-15-068633:notes:141]
Total Share-Based Compensation

[0001144204-15-068633:notes:142]
The total share-based compensation cost that has been recognized in results of operations and included within SG&A from continuing operations was $4.8 million, $4.8 million and $4.6 million for 2015, 2014 and 2013, respectively. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $1.6 million, $1.3 million and $1.3 million for 2015, 2014 and 2013, respectively. The Company has elected to use tax law ordering rules when calculating the income tax benefit associated with its share-based payment arrangements. In addition, the Company elected to use the simplified method of calculating the pool of excess tax benefits available to absorb tax deficiencies recognized. As of September 30, 2015, there was $5.0 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a weighted-average period of  1.5 years.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001144204-15-068633:notes:143]
|  | 12. | Retirement and Other Benefit Plans |

[0001144204-15-068633:notes:144]
Substantially all domestic employees were covered by a defined contribution pension plan maintained by the Company. Effective December 31, 2003, the Company’s defined benefit plan was frozen and no additional benefits have been accrued after that date. As a result, the accumulated benefit obligation and projected benefit obligation are equal. These frozen retirement income benefits are provided to employees under defined benefit pay-related and flat-dollar plans, which are noncontributory. In conjunction with the acquisition of Doble, the Company assumed responsibility for its defined benefit plan and has frozen the plan effective December 31, 2008, and no additional benefits have been accrued after that date. Effective October 1, 2009, the Company’s defined benefit plan and Doble’s benefit plan were merged into one plan. The annual contributions to the defined benefit retirement plans equal or exceed the minimum funding requirements of the Employee Retirement Income Security Act. In addition to providing retirement income benefits, the Company provides unfunded postretirement health and life insurance benefits to certain retirees. To qualify, an employee must retire at age 55 or later and the employee’s age plus service must equal or exceed 75. Retiree contributions are defined as a percentage of medical premiums. Consequently, retiree contributions increase with increases in the medical premiums. The life insurance plans are noncontributory and provide coverage of a flat dollar amount for qualifying retired employees. Effective December 31, 2004, no new retirees were eligible for life insurance benefits.

[0001144204-15-068633:notes:145]
The Company uses a measurement date of September 30 for its pension and other postretirement benefit plans. The Company has an accrued benefit liability of $0.9 million and $0.9 million at September 30, 2015 and 2014, respectively, related to its other postretirement benefit obligations. All other information related to its postretirement benefit plans is not considered material to the Company’s results of operations or financial condition.

[0001144204-15-068633:notes:146]
The following tables provide a reconciliation of the changes in the pension plans and fair value of assets over the two-year period ended September 30, 2015, and a statement of the funded status as of September 30, 2015 and 2014:

[0001144204-15-068633:notes:147]
| (Dollars in millions) |  |  |  |  |  |
| Reconciliation of benefit obligation |  | 2015 |  | 2014 |  |
| Net benefit obligation at beginning of year |  | $ | 92.5 |  |  | 87.2 |  |
| Interest cost |  |  | 3.8 |  |  | 4.0 |  |
| Actuarial (gain) loss |  |  | 4.5 |  |  | 5.1 |  |
| Gross benefits paid |  |  | (7.2) |  |  | (3.8) |  |
| Net benefit obligation at end of year |  | $ | 93.6 |  |  | 92.5 |  |

[0001144204-15-068633:notes:148]
| (Dollars in millions) |  |  |  |  |  |
| Reconciliation of fair value of plan assets |  | 2015 |  | 2014 |  |
| Fair value of plan assets at beginning of year |  | $ | 73.0 |  |  | 67.9 |  |
| Actual return on plan assets |  |  | (3.7) |  |  | 5.9 |  |
| Employer contributions |  |  | 0.9 |  |  | 3.0 |  |
| Gross benefits paid |  |  | (7.2) |  |  | (3.8) |  |
| Fair value of plan assets at end of year |  | $ | 63.0 |  |  | 73.0 |  |

[0001144204-15-068633:notes:149]
| (Dollars in millions) |  |  |  |  |  |
| Funded Status |  | 2015 |  | 2014 |  |
| Funded status at end of year |  | $ | (30.6) |  |  | (19.5) |  |
| Accrued benefit cost |  |  | (30.6) |  |  | (19.5) |  |
| Amounts recognized in the Balance Sheet consist of: |  |  |  |  |  |  |  |
| Current liability |  |  | (0.2) |  |  | (0.3) |  |
| Noncurrent liability |  |  | (30.4) |  |  | (19.2) |  |
| Accumulated other comprehensive (income)/loss (before tax effect) |  |  | 47.6 |  |  | 36.7 |  |
| Amounts recognized in Accumulated Other Comprehensive (Income)/Loss consist of: |  |  |  |  |  |  |  |
| Net actuarial loss |  |  | 47.6 |  |  | 36.7 |  |
| Accumulated Other Comprehensive (Income)/Loss (before tax effect) |  | $ | 47.6 |  |  | 36.7 |  |

[0001144204-15-068633:notes:150]
The following table provides the components of net periodic benefit cost for the plans for 2015, 2014 and 2013:

[0001144204-15-068633:notes:151]
| (Dollars in millions) |  | 2015 |  | 2014 |  | 2013 |  |
| Service cost |  | $ | — |  |  | — |  |  | 0.1 |  |
| Interest cost |  |  | 3.8 |  |  | 4.0 |  |  | 3.6 |  |
| Expected return on plan assets |  |  | (4.5) |  |  | (4.4) |  |  | (4.4) |  |
| Net actuarial loss |  |  | 1.8 |  |  | 1.6 |  |  | 2.1 |  |
| Settlement gain |  |  | — |  |  | — |  |  | (0.1) |  |
| Net periodic benefit cost |  |  | 1.1 |  |  | 1.2 |  |  | 1.3 |  |
| Defined contribution plans |  |  | 3.4 |  |  | 3.3 |  |  | 4.6 |  |
| Total |  | $ | 4.5 |  |  | 4.5 |  |  | 5.9 |  |

[0001144204-15-068633:notes:152]
The discount rate used in measuring the Company’s pension obligations was developed by matching yields of actual high-quality corporate bonds to expected future pension plan cash flows (benefit payments). Over 400 Aa-rated, non-callable bonds with a wide range of maturities were used in the analysis. After using the bond yields to determine the present value of the plan cash flows, a single representative rate that resulted in the same present value was developed. The expected long-term rate of return on plan assets assumption was determined by reviewing the actual investment return of the plans since inception and evaluating those returns in relation to expectations of various investment organizations to determine whether long-term future returns are expected to differ significantly from the past.

[0001144204-15-068633:notes:153]
The following weighted-average assumptions were used to determine the net periodic benefit cost for the pension plans:

[0001144204-15-068633:notes:154]
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Discount rate |  |  | 4.25 | % |  |  | 4.75 | % |  |  | 3.75 | % |
| Rate of increase in compensation levels |  |  | N/A |  |  |  | N/A |  |  |  | N/A |  |
| Expected long-term rate of return on assets |  |  | 6.75 | % |  |  | 7.00 | % |  |  | 7.50 | % |

[0001144204-15-068633:notes:155]
The following weighted-average assumptions were used to determine the net periodic benefit obligations for the pension plans:

[0001144204-15-068633:notes:156]
|  |  | 2015 |  |  | 2014 |  |
| Discount rate |  |  | 4.25 | % |  |  | 4.25 | % |
| Rate of increase in compensation levels |  |  | N/A |  |  |  | N/A |  |

[0001144204-15-068633:notes:157]
The assumed rate of increase in compensation levels is not applicable in 2015, 2014 and 2013 as the plan was frozen in earlier years.

[0001144204-15-068633:notes:158]
The asset allocation for the Company’s pension plans at the end of 2015 and 2014, the Company’s acceptable range and the target allocation for 2016, by asset category, follows:

[0001144204-15-068633:notes:159]
|  |  | Target |  |  |  |  |  | Percentage of Plan Assets |  |
|  |  | Allocation |  |  | Acceptable |  | at Year-end |  |
| Asset Category |  | 2016 |  |  | Range |  | 2015 |  | 2014 |  |
| Equity securities |  |  | 60 | % |  |  | 55-65 | % |  | 62 | % |  | 35 | % |
| Fixed income |  |  | 40 | % |  |  | 35-45 | % |  | 37 | % |  | 64 | % |
| Cash/cash equivalents |  |  | 0 | % |  |  | 0-5 | % |  | 1 | % |  | 1 | % |

[0001144204-15-068633:notes:160]
The Company’s pension plan assets are managed by outside investment managers and assets are rebalanced when the target ranges are exceeded. Pension plan assets consist principally of funds which invest in marketable securities including common stocks, bonds, and interest-bearing deposits. The Company’s investment strategy with respect to pension assets is to achieve a total rate of return (income and capital appreciation) that is sufficient to accomplish the purpose of providing retirement benefits to all eligible and future retirees of the pension plan. The Company regularly monitors performance and compliance with investment guidelines.

[0001144204-15-068633:notes:161]
Fair Value of Financial Measurements

[0001144204-15-068633:notes:162]
In May 2015, the FASB issued ASU 2015-07, Fair Value Measurement (Topic 820): Disclosures for Investments in Certain Entities that Calculate Net Asset Value per Share (or its Equivalent), which permits investments measured at net asset value, as a practical expedient for fair value, to be excluded from the fair value hierarchy. The new guidance requires reporting entities to reconcile the fair value hierarchy disclosure to the balance sheet by disclosing the amount of investments measured using the practical expedient, The standard is required to be adopted in annual periods beginning after December 15, 2015 and interim periods within those annual periods. Early adoption is permitted. This guidance must be applied retrospectively to all periods presented. The Company elected to early adopt this guidance for 2015.

[0001144204-15-068633:notes:163]
The fair values of the Company’s defined benefit plan investments as of September 30, 2015 and 2014, by asset category, were as follows:

[0001144204-15-068633:notes:164]
| (Dollars in millions) |  | 2015 |  | 2014 |  |
| Investments at fair value: |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 0.8 |  |  | 0.8 |  |
| Common and preferred stock funds: |  |  |  |  |  |  |  |
| Domestic large capitalization |  |  | 9.9 |  |  | 5.8 |  |
| Domestic small/mid capitalization |  |  | 3.3 |  |  | 6.8 |  |
| International funds |  |  | 13.5 |  |  | 10.5 |  |
| Fixed income funds |  |  | 31.1 |  |  | 46.8 |  |
| Real estate investment funds |  |  | 4.4 |  |  | 2.3 |  |
| Total investments at fair value |  | $ | 63.0 |  |  | 73.0 |  |

[0001144204-15-068633:notes:165]
The following methods were used to estimate the fair value of each class of financial instrument:

[0001144204-15-068633:notes:166]
Cash and cash equivalents: The carrying value of cash represents fair value as it consists of actual currency.

[0001144204-15-068633:notes:167]
Investment Funds: The fair value of the investment funds, which offer daily redemptions, is determined based on the published net asset value of the funds as a practical expedient for fair value.

[0001144204-15-068633:notes:168]
Expected Cash Flows

[0001144204-15-068633:notes:169]
Information about the expected cash flows for the pension and other postretirement benefit plans follows:

[0001144204-15-068633:notes:170]
|  |  | Pension |  | Other |  |
| (Dollars in millions) |  | Benefits |  | Benefits |  |
| Expected Employer Contributions — 2016 |  | $ | — |  |  | 0.1 |  |
| Expected Benefit Payments: |  |  |  |  |  |  |  |
| 2016 |  |  | 4.9 |  |  | 0.1 |  |
| 2017 |  |  | 4.9 |  |  | 0.1 |  |
| 2018 |  |  | 5.0 |  |  | 0.1 |  |
| 2019 |  |  | 5.2 |  |  | 0.1 |  |
| 2020 |  |  | 5.8 |  |  | 0.1 |  |
| 2021-2025 |  | $ | 29.3 |  |  | 0.4 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001144204-15-068633:notes:171]
|  | 15. | Business Segment Information |

[0001144204-15-068633:notes:172]
The Company is organized based on the products and services it offers. Under this organizational structure, the Company has three reporting segments: Filtration/Fluid Flow (Filtration), RF Shielding and Test (Test), and Utility Solutions Group (USG).

[0001144204-15-068633:notes:173]
The Filtration segment’s operations consist of: PTI Technologies Inc., VACCO Industries (VACCO), Crissair, Inc. (Crissair) and Thermoform Engineered Quality LLC (TEQ). The companies in this segment primarily design and manufacture specialty filtration products including hydraulic filter elements and fluid control devices used in commercial aerospace applications, unique filter mechanisms used in micro-propulsion devices for satellites and custom designed filters for manned aircraft and submarines.

[0001144204-15-068633:notes:174]
Test segment operations consist of ETS-Lindgren Inc. (ETS-Lindgren). ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy. ETS-Lindgren also manufactures radio frequency shielding products and components used by manufacturers of medical equipment, communications systems, electronic products, and shielded rooms for high-security data processing and secure communication.

[0001144204-15-068633:notes:175]
The USG segment’s operations consist of Doble Engineering Company (Doble). Doble provides high-end, intelligent diagnostic test solutions for the electric power delivery industry and is a leading supplier of power factor and partial discharge testing instruments used to assess the integrity of high-voltage power delivery equipment. Previously, USG also included Aclara Technologies LLC. See Note 2.

[0001144204-15-068633:notes:176]
Accounting policies of the segments are the same as those described in the summary of significant accounting policies in Note 1 to the Consolidated Financial Statements. The operating units within each reporting segment have been aggregated because of similar economic characteristics and meet the other aggregation criteria of FASB ASC 280.

[0001144204-15-068633:notes:177]
The Company evaluates the performance of its operating units based on EBIT, which is defined as: Earnings Before Interest and Taxes. Intersegment sales and transfers are not significant. Segment assets consist primarily of customer receivables, inventories, capitalized software and fixed assets directly associated with the production processes of the segment. Segment depreciation and amortization is based upon the direct assets listed above.

[0001144204-15-068633:notes:178]
Net Sales

[0001144204-15-068633:notes:179]
| (Dollars in millions) |  |  |  |  |  |  |  |
| Year ended September 30, |  | 2015 |  | 2014 |  | 2013 |  |
| Filtration |  | $ | 236.1 |  |  | 233.7 |  |  | 214.1 |  |
| Test |  |  | 177.6 |  |  | 181.8 |  |  | 166.7 |  |
| USG |  |  | 123.6 |  |  | 115.6 |  |  | 109.3 |  |
| Consolidated totals |  | $ | 537.3 |  |  | 531.1 |  |  | 490.1 |  |

[0001144204-15-068633:notes:180]
No customer exceeded  10% of sales in 2015 or 2013; one customer exceeded  10% of sales in 2014.

[0001144204-15-068633:notes:181]
EBIT

[0001144204-15-068633:notes:182]
| (Dollars in millions) |  |  |  |  |  |  |  |
| Year ended September 30, |  | 2015 |  | 2014 |  | 2013 |  |
| Filtration |  | $ | 46.6 |  |  | 41.4 |  |  | 42.4 |  |
| Test |  |  | 9.5 |  |  | 21.1 |  |  | 16.3 |  |
| USG |  |  | 29.6 |  |  | 26.6 |  |  | 21.6 |  |
| Reconciliation to consolidated totals (Corporate) |  |  | (23.4) |  |  | (25.3) |  |  | (28.0) |  |
| Consolidated EBIT |  |  | 62.3 |  |  | 63.8 |  |  | 52.3 |  |
| Less: interest expense |  |  | (0.8) |  |  | (1.6) |  |  | (2.7) |  |
| Earnings before income tax |  | $ | 61.5 |  |  | 62.2 |  |  | 49.6 |  |

[0001144204-15-068633:notes:183]
Identifiable Assets

[0001144204-15-068633:notes:184]
| (Dollars in millions) |  |  |  |  |  |
| Year ended September 30, |  | 2015 |  | 2014 |  |
| Filtration |  | $ | 141.8 |  |  | 131.5 |  |
| Test |  |  | 117.8 |  |  | 114.6 |  |
| USG |  |  | 80.6 |  |  | 98.6 |  |
| Corporate |  |  | 524.0 |  |  | 501.2 |  |
| Consolidated totals |  | $ | 864.2 |  |  | 845.9 |  |

[0001144204-15-068633:notes:185]
Corporate assets consist primarily of goodwill, deferred taxes, acquired intangible assets, cash balances and assets held for sale.

[0001144204-15-068633:notes:186]
Capital Expenditures

[0001144204-15-068633:notes:187]
| (Dollars in millions) |  |  |  |  |  |  |  |
| Year ended September 30, |  | 2015 |  | 2014 |  | 2013 |  |
| Filtration |  | $ | 6.0 |  |  | 7.0 |  |  | 6.6 |  |
| Test |  |  | 3.1 |  |  | 1.4 |  |  | 3.2 |  |
| USG |  |  | 3.3 |  |  | 4.1 |  |  | 3.9 |  |
| Corporate |  |  | – |  |  | 0.2 |  |  | 0.2 |  |
| Consolidated totals |  | $ | 12.4 |  |  | 12.7 |  |  | 13.9 |  |

[0001144204-15-068633:notes:188]
In addition to the above amounts, the Company incurred expenditures for capitalized software of $6.9 million, $8.6 million and $8.4 million in 2015, 2014 and 2013, respectively.

[0001144204-15-068633:notes:189]
Depreciation and Amortization

[0001144204-15-068633:notes:190]
| (Dollars in millions) |  |  |  |  |  |  |  |
| Year ended September 30, |  | 2015 |  | 2014 |  | 2013 |  |
| Filtration |  | $ | 5.2 |  |  | 5.2 |  |  | 4.2 |  |
| Test |  |  | 3.1 |  |  | 2.7 |  |  | 2.5 |  |
| USG |  |  | 6.2 |  |  | 4.8 |  |  | 4.6 |  |
| Corporate |  |  | 4.1 |  |  | 3.7 |  |  | 3.5 |  |
| Consolidated totals |  | $ | 18.6 |  |  | 16.4 |  |  | 14.8 |  |

[0001144204-15-068633:notes:191]
Geographic Information

[0001144204-15-068633:notes:192]
| (Dollars in millions) |  |  |  |  |  |  |  |
| Year ended September 30, |  | 2015 |  | 2014 |  | 2013 |  |
| United States |  | $ | 385.5 |  |  | 374.0 |  |  | 336.4 |  |
| Asia |  |  | 70.4 |  |  | 59.9 |  |  | 59.5 |  |
| Europe |  |  | 46.6 |  |  | 62.0 |  |  | 51.5 |  |
| Canada |  |  | 11.6 |  |  | 10.4 |  |  | 14.3 |  |
| India |  |  | 4.3 |  |  | 3.3 |  |  | 10.2 |  |
| Other |  |  | 18.9 |  |  | 21.5 |  |  | 18.2 |  |
| Consolidated totals |  | $ | 537.3 |  |  | 531.1 |  |  | 490.1 |  |

[0001144204-15-068633:notes:193]
Long-Lived Assets

[0001144204-15-068633:notes:194]
| (Dollars in millions) |  |  |  |  |  |
| Year ended September 30, |  | 2015 |  | 2014 |  |
| United States |  | $ | 74.5 |  |  | 73.6 |  |
| Europe |  |  | 2.1 |  |  | 2.2 |  |
| Other |  |  | 0.8 |  |  | 0.7 |  |
| Consolidated totals |  | $ | 77.4 |  |  | 76.5 |  |

[0001144204-15-068633:notes:195]
Net sales are attributed to countries based on location of customer. Long-lived assets are attributed to countries based on location of the asset.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001144204-15-068633:notes:196]
|  | 13. | Derivative Financial Instruments |

[0001144204-15-068633:notes:197]
Market risks relating to the Company’s operations result primarily from changes in interest rates and changes in foreign currency exchange rates. The Company is exposed to market risk related to changes in interest rates and selectively uses derivative financial instruments, including forward contracts and swaps, to manage these risks. During 2015, the Company entered into several forward contracts to purchase Euros to hedge the foreign currency risk related to Euro denominated inventory payments. The Company expects hedging gains or losses to be essentially offset by losses or gains on the related underlying exposures. The amounts ultimately recognized may differ for open positions, which remain subject to ongoing market price fluctuations until settlement. The derivative instruments are designated as cash flow hedges and the gain or loss on the derivative is deferred in accumulated other comprehensive income until recognized in earnings with the underlying hedged item. The fair value of the foreign currency derivative is classified in accrued expenses on the Company’s Consolidated Balance Sheet.  The following is a summary of the notional transaction amounts and fair values for the Company’s outstanding derivative financial instruments as of September 30, 2015.

[0001144204-15-068633:notes:198]
|  |  | Notional |  |  |  |  |
|  |  | Amount |  | Fair Value |  |
| (In thousands) |  | (Euros) |  | (US$) |  |
| Forward contracts |  |  | 1,289 |  |  | (94) |  |

[0001144204-15-068633:notes:199]
Fair value of financial instruments

[0001144204-15-068633:notes:200]
The Company’s forward contracts are classified within Level 2 of the valuation hierarchy in accordance with FASB Accounting Standards Codification (ASC) 825, as presented below as of September 30, 2015:

[0001144204-15-068633:notes:201]
| (In thousands) |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Forward contracts |  | $ | – |  |  | 94 |  |  | – |  |  | 94 |  |

[0001144204-15-068633:notes:202]
Valuation was based on third party evidence of similarly priced derivative instruments.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001144204-15-068633:notes:203]
|  | 14. | Other Financial Data |

[0001144204-15-068633:notes:204]
Items charged to continuing operations during 2015, 2014 and 2013 included the following:

[0001144204-15-068633:notes:205]
| (Dollars in thousands) |  | 2015 |  | 2014 |  | 2013 |  |
| Salaries and wages (including fringes) |  | $ | 152,853 |  |  | 158,333 |  |  | 151,805 |  |
| Maintenance and repairs |  |  | 4,700 |  |  | 4,638 |  |  | 4,368 |  |
| Research and development (R&D) costs: |  |  |  |  |  |  |  |  |  |  |
| Company-sponsored |  |  | 16,728 |  |  | 16,880 |  |  | 12,704 |  |
| Customer-sponsored |  |  | 6,776 |  |  | 11,586 |  |  | 15,014 |  |
| Total R&D |  |  | 23,504 |  |  | 28,466 |  |  | 27,718 |  |
| Other engineering costs |  |  | 13,899 |  |  | 12,484 |  |  | 7,715 |  |
| Total R&D and other engineering costs |  |  | 37,403 |  |  | 40,950 |  |  | 35,433 |  |
| As a % of net sales |  |  | 7.0 | % |  | 7.7 | % |  | 7.2 | % |

[0001144204-15-068633:notes:206]
A reconciliation of the changes in accrued product warranty liability for 2015, 2014 and 2013 is as follows:

[0001144204-15-068633:notes:207]
| (Dollars in thousands) |  | 2015 |  | 2014 |  | 2013 |  |
| Balance as of October 1, |  | $ | 1,480 |  |  | 1,880 |  |  | 1,536 |  |
| Additions charged to expense |  |  | 754 |  |  | 239 |  |  | 1,048 |  |
| Deductions |  |  | (467) |  |  | (639) |  |  | (704) |  |
| Balance as of September 30, |  | $ | 1,767 |  |  | 1,480 |  |  | 1,880 |  |


## us-gaap:SubsequentEventsTextBlock

[0001144204-15-068633:notes:208]
|  | 17. | Subsequent Event |

[0001144204-15-068633:notes:209]
On October 16, 2015, the Company acquired the stock of Fremont Plastics, Inc. (Fremont) for a purchase price of $10.5 million in cash. The Company also purchased the real property, located in Fremont, Indiana for $2 million, where Fremont conducts its operations. Fremont develops, manufactures, promotes and sells high quality sterile-ready and non-sterile thin gauge thermoformed medical plastic packaging products. Since the date of acquisition the operating results for Fremont have been included as part of TEQ.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001144204-15-068633:notes:210]
|  | 16. | Commitments and Contingencies |

[0001144204-15-068633:notes:211]
At September 30, 2015, the Company had $8.0 million in letters of credit outstanding as guarantees of contract performance. At September 30, 2015, the Company had $6.3 million of outstanding firm purchase obligations to purchase goods and services. As a normal incident of the businesses in which the Company is engaged, various claims, charges and litigation are asserted or commenced from time to time against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. It is the opinion of Management that the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company are adequately reserved for, are covered by insurance, or are not likely to have a material adverse effect on the Company’s results from continuing operations, capital expenditures, or competitive position.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001144204-15-068633:notes:212]
|  | 7. | Property, Plant and Equipment |

[0001144204-15-068633:notes:213]
Depreciation expense of property, plant and equipment was $9.7 million, $9.6 million and $8.6 million for 2015, 2014 and 2013, respectively.

[0001144204-15-068633:notes:214]
The Company leases certain real property, equipment and machinery under non-cancelable operating leases. Rental expense under these operating leases was $5.2 million, $5.3 million and $5.0 million for 2015, 2014 and 2013, respectively.  Future aggregate minimum lease payments under operating leases that have initial or remaining non-cancelable lease terms in excess of one year as of September 30, 2015, are:


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001144204-15-068633:notes:215]
|  | 2. | Aclara Divestiture |

[0001144204-15-068633:notes:216]
On March 28, 2014, the Company completed the sale of Aclara to an affiliate of Sun Capital Partners, Inc. The divestiture generated approximately $135 million of gross cash proceeds. A disagreement between the parties over the calculation of the final working capital adjustment was finally resolved by arbitration on June 15, 2015, resulting in a cash payment to the Company of $2.3 million. Aclara is reflected as discontinued operations in the consolidated financial statements and related notes for all periods presented.

[0001144204-15-068633:notes:217]
Aclara’s pretax earnings (loss) recorded in discontinued operations was $1.2 million, $(48.2) million and $(62.1) million for the years ended September 30, 2015, 2014 and 2013, respectively. The 2014 pretax loss consisted of Aclara’s pretax earnings from its results of operations of $15.6 million and a pretax loss of $63.8 million on the sale of Aclara. The 2013 pretax loss was due to a $48 million goodwill impairment charge recorded in the fourth quarter of 2013; lower sales volumes; and changes in product mix (higher shipments of lower margin gas products). Aclara’s net sales were $129.6 million and $184.5 million for the years ended September 30, 2014 and 2013, respectively. Aclara’s operations were included within the Company’s USG segment prior to the classification as discontinued operations.
