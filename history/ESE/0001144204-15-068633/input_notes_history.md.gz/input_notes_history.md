# ESE note change history — 0001144204-15-028220 → 0001144204-15-047840


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-08-10):
[0001144204-15-047840:note_history:1]
The Company’s business is typically not impacted by seasonality; however, the results for the three and nine-month periods ended June 30, 2015 are not necessarily indicative of the results for the entire 2015 fiscal year. References to the third quarters of 2015 and 2014 represent the fiscal quarters ended June 30, 2015 and 2014, respectively.
  (was, 2015-05-07, similarity 0.9474):
[0001144204-15-028220:note_history:1]
The Company’s business is typically not impacted by seasonality; however, the results for the three and six-month periods ended March 31, 2015 are not necessarily indicative of the results for the entire 2015 fiscal year. References to the second quarters of 2015 and 2014 represent the fiscal quarters ended March 31, 2015 and 2014, respectively.

- changed (2015-08-10):
[0001144204-15-047840:note_history:2]
On March 28, 2014, the Company completed the sale of Aclara Technologies LLC (Aclara) to an affiliate of Sun Capital Partners. A disagreement between the parties over the calculation of the final working capital adjustment was finally resolved by arbitration on June 15, 2015, resulting in a cash payment to the Company of $2.3 million. Aclara is reflected as discontinued operations in the consolidated financial statements and related notes for the periods presented, in accordance with accounting principles generally accepted in the United States of America (GAAP).
  (was, 2015-05-07, similarity 0.7775):
[0001144204-15-028220:note_history:2]
On March 28, 2014, the Company completed the sale of Aclara Technologies LLC (Aclara) to an affiliate of Sun Capital Partners. Aclara is reflected as discontinued operations in the consolidated financial statements and related notes for the periods presented, in accordance with accounting principles generally accepted in the United States of America (GAAP).


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-08-10):
[0001144204-15-047840:note_history:3]
|  |  | June 30, |  | September 30, |  |
| (In thousands) |  | 2015 |  | 2014 |  |
| Total borrowings |  | $ | 65,407 |  |  | 40,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,407) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 45,000 |  |  | 20,000 |  |
  (was, 2015-05-07, similarity 0.8752):
[0001144204-15-028220:note_history:3]
| (In thousands) |  | March 31, 2015 |  | September 30, 2014 |  |
| Total borrowings |  | $ | 73,000 |  |  | 40,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 53,000 |  |  | 20,000 |  |

- added (2015-08-10):
[0001144204-15-047840:note_history:4]
At June 30, 2015, the Company had approximately $376 million available to borrow under the credit facility, and a $250 million increase option, in addition to $36.9 million cash on hand. At June 30, 2015, the Company had $65 million of outstanding borrowings under the credit facility in addition to outstanding letters of credit of $8.7 million. The Company’s ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.

- changed (2015-08-10):
[0001144204-15-047840:note_history:5]
The credit facility requires, as determined by certain financial ratios, a facility fee ranging from  17.5 to  35.0 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a  65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the credit facility also include a leverage ratio and an interest coverage ratio. The weighted average interest rates were  1.14% and  1.28% for the three and nine-month periods ending June 30, 2015, respectively. At June 30, 2015, the Company was in compliance with all debt covenants.
  (was, 2015-05-07, similarity 0.8388):
[0001144204-15-028220:note_history:5]
The credit facility requires, as determined by certain financial ratios, a facility fee ranging from  17.5 to  35.0 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a  65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the credit facility also include a leverage ratio and an interest coverage ratio. At March 31, 2015, the Company was in compliance with all debt covenants.

- removed (2015-08-10):
[0001144204-15-028220:note_history:6]
At March 31, 2015, the Company had approximately $365 million available to borrow under the credit facility, and a $250 million increase option, in addition to $34.7 million cash on hand. At March 31, 2015, the Company had $73.0 million of outstanding borrowings under the credit facility in addition to outstanding letters of credit of $11.7 million. The Company’s ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-08-10):
[0001144204-15-047840:note_history:7]
|  |  | June 30, |  | September 30, |  |
| (In thousands) |  | 2015 |  | 2014 |  |
| Total borrowings |  | $ | 65,407 |  |  | 40,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,407) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 45,000 |  |  | 20,000 |  |
  (was, 2015-05-07, similarity 0.8752):
[0001144204-15-028220:note_history:7]
| (In thousands) |  | March 31, 2015 |  | September 30, 2014 |  |
| Total borrowings |  | $ | 73,000 |  |  | 40,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 53,000 |  |  | 20,000 |  |
