# ESE MD&A — 0001144204-15-068633


## mdna

[0001144204-15-068633:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial
Condition and Results of Operations

[0001144204-15-068633:mdna:2]
The following discussion should be read in conjunction with
the Consolidated Financial Statements included herein and Notes thereto and refers to the Company’s results from continuing
operations, except where noted. In the second quarter of 2014, the Company completed the sale of Aclara Technologies LLC (Aclara)
to an affiliate of Sun Capital Partners, Inc. A disagreement between the parties over the calculation of the final working capital
adjustment was finally resolved by arbitration on June 15, 2015, resulting in a cash payment to the Company of $2.3 million. Aclara
is reflected as discontinued operations in the financial statements and related notes for all periods shown.

[0001144204-15-068633:mdna:3]
Introduction

[0001144204-15-068633:mdna:4]
ESCO Technologies Inc. and its wholly owned subsidiaries (the
Company) are organized into three reportable operating segments: Filtration/Fluid Flow (Filtration), RF Shielding and Test (Test),
and Utility Solutions Group (USG). The Company’s business segments are comprised of the following primary operating entities:

[0001144204-15-068633:mdna:5]
|  | · | Filtration: PTI Technologies Inc. (PTI), VACCO Industries (VACCO), Crissair, Inc. (Crissair) and Thermoform Engineered Quality LLC (TEQ). |

[0001144204-15-068633:mdna:6]
|  | · | Test: ETS-Lindgren Inc. (ETS-Lindgren). |

[0001144204-15-068633:mdna:7]
|  | · | USG: Doble Engineering Company (Doble). |

[0001144204-15-068633:mdna:8]
|  | 17 |  |

[0001144204-15-068633:mdna:9]
Filtration.
The companies within this segment primarily design and manufacture specialty filtration products including hydraulic filter elements
and fluid control devices used in commercial aerospace applications, unique filter mechanisms used in micro-propulsion devices
for satellites and custom designed filters for manned aircraft and submarines.

[0001144204-15-068633:mdna:10]
Test.
ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and contain magnetic, electromagnetic
and acoustic energy.

[0001144204-15-068633:mdna:11]
USG.
Doble provides high-end, intelligent diagnostic test solutions for the electric power delivery industry and is a leading supplier
of power factor and partial discharge testing instruments used to assess the integrity of high-voltage power delivery equipment.

[0001144204-15-068633:mdna:12]
The Company continues to operate with meaningful growth prospects
in its primary served markets and with considerable financial flexibility. The Company continues to focus on new products that
incorporate proprietary design and process technologies. Management is committed to delivering shareholder value through internal
growth, ongoing performance improvement initiatives, and acquisitions.

[0001144204-15-068633:mdna:13]
Highlights of 2015 Continuing Operations

[0001144204-15-068633:mdna:14]
|  | · | Sales, net earnings from continuing operations and diluted earnings per share from continuing operations were $537.3 million, $41.7 million and $1.59 per share, respectively, compared to sales, net earnings and diluted earnings per share of $531.1 million, $42.6 million and $1.60 per share in 2014. |

[0001144204-15-068633:mdna:15]
|  | · | Net cash provided by operating activities from continuing operations was approximately $65.0 million in 2015, compared to $44.9 million in 2014. |

[0001144204-15-068633:mdna:16]
|  | · | At September 30, 2015, cash on hand was $39.4 million and outstanding debt was $50.0 million, for a net debt position (total debt less net cash) of approximately $10.6 million. |

[0001144204-15-068633:mdna:17]
|  | · | 2015 entered orders were $561.9 million resulting in a book-to-bill ratio of 1.05x. Backlog at September 30, 2015 was $327.5 million compared to $302.9 million at September 30, 2014. |

[0001144204-15-068633:mdna:18]
|  | · | In January 2015, the Company acquired the assets of Enoserv for $20.5 million in cash. Enoserv provides customers with high quality, user-friendly multi-platform software primarily for the utility industry. The operating results for Enoserv, since the date of acquisition, are included as part of Doble. |

[0001144204-15-068633:mdna:19]
|  | · | During 2015, the Company repurchased approximately 517,000 shares of its common stock for $18.2 million. |

[0001144204-15-068633:mdna:20]
|  | · | The Company declared dividends of $0.32 per share, totaling $8.4 million in payments during 2015. |

[0001144204-15-068633:mdna:21]
Results of Continuing Operations

[0001144204-15-068633:mdna:22]
Net Sales

[0001144204-15-068633:mdna:23]
|  |  |  |  |  |  |  |  |  |  |  | Change |  |  | Change |  |
|  |  | Fiscal year ended |  |  | 2015 |  |  | 2014 |  |
| (Dollars in millions) |  | 2015 |  |  | 2014 |  |  | 2013 |  |  | vs. 2014 |  |  | vs. 2013 |  |
| Filtration |  | $ | 236.1 |  |  |  | 233.7 |  |  |  | 214.1 |  |  |  | 1.0 | % |  |  | 9.2 | % |
| Test |  |  | 177.6 |  |  |  | 181.8 |  |  |  | 166.7 |  |  |  | (2.3 | )% |  |  | 9.1 | % |
| USG |  |  | 123.6 |  |  |  | 115.6 |  |  |  | 109.3 |  |  |  | 6.9 | % |  |  | 5.8 | % |
| Total |  | $ | 537.3 |  |  |  | 531.1 |  |  |  | 490.1 |  |  |  | 1.2 | % |  |  | 8.4 | % |

[0001144204-15-068633:mdna:24]
Net sales increased $6.2 million, or 1.2%, to $537.3
million in 2015 from $531.1 million in 2014. The increase in net sales in 2015 as compared to 2014 was due to an $8.0 million
increase in the USG segment and a $2.4 million increase in the Filtration segment, partially offset by a $4.2 million
decrease in the Test segment.

[0001144204-15-068633:mdna:25]
Net sales increased $41.0 million, or 8.4%, to $531.1 million
in 2014 from $490.1 million in 2013. The increase in net sales in 2014 as compared to 2013 was due to a $19.6 million increase
in the Filtration segment, a $15.1 million increase in the Test segment, and a $6.3 million increase in the USG segment.

[0001144204-15-068633:mdna:26]
|  | 18 |  |

[0001144204-15-068633:mdna:27]
Filtration.

[0001144204-15-068633:mdna:28]
The $2.4 million, or 1.0%, increase in net sales in 2015
as compared to 2014 was primarily due to a $7.7 million increase in net sales from PTI due to higher shipments of aero
assemblies and industrial products and  a $2.2 million increase in net sales from TEQ due to higher shipments to medical
customers, partially offset by a $7.4 million decrease in net sales from VACCO due to lower shipments of its Space products,
primarily the Boeing Space Launch system.

[0001144204-15-068633:mdna:29]
The $

[0001144204-15-068633:mdna:30]
|  | 19 |  |

[0001144204-15-068633:mdna:31]
.6 million, or 9.2%, increase in net sales in 2014 as
compared to 2013 was due to a $10.2 million increase in net sales from VACCO due to higher shipments of its Space products, an
$8.5 million increase in net sales at Crissair mainly due to the Canyon acquisition and higher aerospace product shipments, and
a $0.9 million increase in net sales at TEQ due to higher shipments to commercial customers.

[0001144204-15-068633:mdna:32]
Test.

[0001144204-15-068633:mdna:33]
The net sales decrease of $4.2 million, or 2.3%, in 2015
as compared to 2014 was due to a $6.2 million decrease in net sales from the segment’s U.S. operations, mainly due to
overall softness in the domestic shielding market, and a $1.1 million decrease in net sales from the segment’s European
operations, partially offset by a $2.9 million increase in net sales from the Company’s Asian operations due to timing
of projects.

[0001144204-15-068633:mdna:34]
The net sales increase of $15.1 million, or 9.1%, in 2014
as compared to 2013 was due to a $12.9 million increase in net sales from the segment’s U.S. operations, mainly due to
a large automotive chamber project and projects in the test and measurement market, and a $3.3 million increase in net sales
from the segment’s European operations, partially offset by a $1.1 million decrease in net sales from the
Company’s Asian operations due to timing of projects.

[0001144204-15-068633:mdna:35]
USG.

[0001144204-15-068633:mdna:36]
The net sales increase of $8.0 million, or 6.9%, in 2015 as
compared to 2014 was driven by a $4.6 million contribution from the Enoserv acquisition (acquired January 28, 2015), higher shipments
of the F and M series products, and additional service revenue at Doble.

[0001144204-15-068633:mdna:37]
The net sales increase of $6.3 million, or 5.8%, in 2014 as
compared to 2013 was driven by an increase in service revenues at Doble.

[0001144204-15-068633:mdna:38]
Orders and Backlog

[0001144204-15-068633:mdna:39]
New orders received in 2015 were $561.9 million as compared
to $561.9 million in 2014, resulting in order backlog of $327.5 million at September 30, 2015, as compared to order backlog
of $302.9 million at September 30, 2014. In 2015, the Company recorded $253.2 million of orders related to Filtration products,
$182.0 million related to Test products, and $126.7 million related to USG products. Orders are entered into backlog
as firm purchase order commitments are received.

[0001144204-15-068633:mdna:40]
In 2014, the Company recorded $255.1 million of orders
related to Filtration products, $182.1 million related to Test products, and $124.7 million related to USG products.

[0001144204-15-068633:mdna:41]
Selling, General and Administrative Expenses

[0001144204-15-068633:mdna:42]
Selling, general and administrative (SG&A) expenses were
$130.2 million, or 24.2% of net sales, in 2015, $134.9 million, or 25.4% of net sales, in 2014, and $129.8 million, or 26.5% of
net sales, in 2013. The decrease in SG&A expenses in 2015 as compared to 2014 was mainly due to a decrease in SG&A expenses
within the Test segment and the Filtration segment driven by the recent facility consolidations and headcount reductions.

[0001144204-15-068633:mdna:43]
The increase in SG&A expenses in 2014 as compared to 2013
was mainly due to the acquisition of Canyon Engineering in June 2013, higher engineering costs in the Filtration segment related
to aerospace platform wins, higher commissions within the Test segment, and higher marketing and selling
expenses within the USG segment; partially offset by lower SG&A expenses at Corporate.

[0001144204-15-068633:mdna:44]
Amortization Of Intangible Assets

[0001144204-15-068633:mdna:45]
Amortization of intangible assets was $8.9 million in 2015,
$6.7 million in 2014 and $6.2 million in 2013. Amortization of intangible assets included $4.0 million, $3.4 million and $3.2 million
of amortization of acquired intangible assets in 2015, 2014 and 2013, respectively, related to the Company’s acquisitions.
The amortization of acquired intangible assets related to the Company’s acquisitions is included in the Corporate operating
segment’s results. The remaining amortization expenses consist of other identifiable intangible assets (primarily software,
patents and licenses) and are included in the respective segment’s operating results. The increase in amortization expense
in 2015 as compared to 2014 was mainly due to an increase in software amortization and the amortization of intangibles related
to the Enoserv acquisition.

[0001144204-15-068633:mdna:46]
19

[0001144204-15-068633:mdna:47]
Other Expenses (Income), Net

[0001144204-15-068633:mdna:48]
Other expenses (income), net, were $1.1 million in 2015, $1.8
million in 2014 and $5.9 million in 2013. The principal component of other expenses (income), net, in 2015 included $0.9 million
of severance expenses related to headcount reductions primarily at VACCO, a $0.5 million increase to the Company’s allowance
for bad debts primarily within the Test segment, partially offset by $0.5 million of income related to death benefit insurance
proceeds from a former subsidiary. The principal components of other expenses (income), net, in 2014 included $1.7 million of costs
related to the exit and relocation of Crissair’s Palmdale, California operation into the Canyon facility in Valencia, California.
The principal components of other expenses (income), net, in 2013 included $4.1 million of restructuring costs related to the closure
of the Doble Lemke facility in Germany; $2.6 million of restructuring costs within the Test segment as a result of the closure
of the Glendale Heights, Illinois facility; and a $0.8 million gain on the sale of machinery and equipment within the Filtration
segment. There were no other individually significant items included in other expenses (income), net, in 2015, 2014 or 2013.

[0001144204-15-068633:mdna:49]
Non-GAAP Financial Measures

[0001144204-15-068633:mdna:50]
The information reported herein includes the financial measures
EBIT, EBIT as a percentage of net sales (“EBIT margin”), and EPS on an adjusted basis from continuing operations (“EPS
– As Adjusted”). The Company defines EBIT as earnings before interest and taxes from continuing operations, and defines
EPS – As Adjusted as GAAP EPS from continuing operations less defined restructuring charges. EBIT, EBIT margin and EPS –
As Adjusted are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, the Company believes
that EBIT and EBIT margin provide investors and Management with a valuable alternative method for assessing the Company’s
operating results. Management evaluates the performance of its operating segments based on EBIT and believes that EBIT is useful
to investors to demonstrate the operational profitability of the Company’s business segments by excluding interest and taxes,
which are generally accounted for across the entire company on a consolidated basis. EBIT is also one of the measures Management
uses to determine resource allocations and incentive compensation. The Company believes that the presentation of EBIT, EBIT margin
and EPS – As Adjusted provides important supplemental information to investors by facilitating comparisons with other companies,
many of which use similar non-GAAP financial measures to supplement their GAAP results. The use of non-GAAP financial measures
is not intended to replace any measures of performance determined in accordance with GAAP.

[0001144204-15-068633:mdna:51]
EBIT

[0001144204-15-068633:mdna:52]
|  |  |  |  |  |  |  |  |  |  |  | Change |  |  | Change |  |
|  |  | Fiscal year ended |  |  | 2015 |  |  | 2014 |  |
| (Dollars in millions) |  | 2015 |  |  | 2014 |  |  | 2013 |  |  | vs. 2014 |  |  | vs. 2013 |  |
| Filtration |  | $ | 46.6 |  |  |  | 41.4 |  |  |  | 42.4 |  |  |  | 12.6 | % |  |  | (2.4 | )% |
| % of net sales |  |  | 19.7 | % |  |  | 17.7 | % |  |  | 19.8 | % |  |  |  |  |  |  |  |  |
| Test |  |  | 9.5 |  |  |  | 21.1 |  |  |  | 16.3 |  |  |  | (55.0 | )% |  |  | 29.4 | % |
| % of net sales |  |  | 5.3 | % |  |  | 11.6 | % |  |  | 9.8 | % |  |  |  |  |  |  |  |  |
| USG |  |  | 29.6 |  |  |  | 26.6 |  |  |  | 21.6 |  |  |  | 11.3 | % |  |  | 23.1 | % |
| % of net sales |  |  | 23.9 | % |  |  | 23.0 | % |  |  | 19.8 | % |  |  |  |  |  |  |  |  |
| Corporate |  |  | (23.4 | ) |  |  | (25.3 | ) |  |  | (28.0 | ) |  |  | (7.5 | )% |  |  | (9.6 | )% |
| Total |  | $ | 62.3 |  |  |  | 63.8 |  |  |  | 52.3 |  |  |  | (2.4 | )% |  |  | 22.0 | % |
| % of net sales |  |  | 11.6 | % |  |  | 12.0 | % |  |  | 10.7 | % |  |  |  |  |  |  |  |  |

[0001144204-15-068633:mdna:53]
The reconciliation of EBIT from continuing operations to a GAAP
financial measure is as follows:

[0001144204-15-068633:mdna:54]
| (Dollars in millions) |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| EBIT |  | $ | 62.3 |  |  |  | 63.8 |  |  |  | 52.3 |  |
| Less: Interest expense |  |  | (0.8 | ) |  |  | (1.6 | ) |  |  | (2.7 | ) |
| Less: Income taxes |  |  | (19.8 | ) |  |  | (19.6 | ) |  |  | (18.3 | ) |
| Net earnings from continuing operations |  | $ | 41.7 |  |  |  | 42.6 |  |  |  | 31.3 |  |

[0001144204-15-068633:mdna:55]
|  | 20 |  |

[0001144204-15-068633:mdna:56]
Filtration

[0001144204-15-068633:mdna:57]
EBIT increased $5.2 million in 2015 as compared to 2014 primarily
due to the increased sales volumes at PTI and a decrease in restructuring costs that were incurred at Crissair in 2014 related
to the exit and relocation of Crissair’s Palmdale, California operation into the Canyon facility in Valencia, California.

[0001144204-15-068633:mdna:58]
EBIT decreased $1.0 million in 2014 as compared to 2013 primarily
due to $1.7 million of costs related to the exit and relocation of Crissair’s Palmdale, California operation into the Canyon
facility in Valencia, California consisting mainly of a facility lease termination charge, severance expenses and manufacturing
inefficiencies resulting from the disruption. This move was completed as of September 30, 2014.

[0001144204-15-068633:mdna:59]
Test

[0001144204-15-068633:mdna:60]
The $11.6 million decrease in EBIT in 2015 as compared
to 2014 was mainly due to the lower sales volumes from the segment’s U.S. and European operations, changes in product
mix, and incremental charges related to the write-down of certain inventories and charges related to legal
costs incurred in defense of patents.

[0001144204-15-068633:mdna:61]
The $4.8 million increase in EBIT in 2014 as compared to 2013
was due to the additional sales volumes from the segment’s U.S. operations and the cost savings achieved as a result of the
2013 domestic facility consolidation. Approximately $3.4 million of restructuring costs were incurred in 2013 related to the domestic
facility consolidation.

[0001144204-15-068633:mdna:62]
USG

[0001144204-15-068633:mdna:63]
The $3.0 million increase in EBIT in 2015 as compared to 2014
was mainly due to an increase in sales volumes and the EBIT contribution from the current year acquisition of Enoserv.

[0001144204-15-068633:mdna:64]
The $5.0 million increase in EBIT in 2014 as compared to 2013
was mainly due to an increase in sales volumes and a decrease in restructuring costs that were incurred in 2013 related to the
closure of the Doble Lemke manufacturing operation.

[0001144204-15-068633:mdna:65]
Corporate

[0001144204-15-068633:mdna:66]
Corporate operating charges included in consolidated EBIT decreased
to $23.4 million as compared to $25.3 million in 2014 mainly due to a decrease in professional fees and salaries expense.

[0001144204-15-068633:mdna:67]
Corporate operating charges included in consolidated EBIT decreased
to $25.3 million as compared to $28 million in 2013 mainly due to a decrease in professional fees and acquisition-related costs.

[0001144204-15-068633:mdna:68]
The “Reconciliation to Consolidated Totals (Corporate)”
in Note 15 to the Consolidated Financial Statements included herein represents Corporate office operating charges.

[0001144204-15-068633:mdna:69]
Interest Expense, Net

[0001144204-15-068633:mdna:70]
Interest expense was $0.8 million in 2015, $1.6 million in 2014,
and $2.7 million in 2013. The decrease in interest expense in 2015 as compared to 2014 was due to lower average interest rates
(1.3% vs. 1.5%) and lower average outstanding borrowings ($68.5 million vs. $ 103 million). The decrease in interest expense in
2014 as compared to 2013 was due to lower average interest rates (1.5% vs. 1.6%) and lower average outstanding borrowings ($103
million vs. $171 million).

[0001144204-15-068633:mdna:71]
Income Tax Expense

[0001144204-15-068633:mdna:72]
The effective tax rate from continuing operations for
2015, 2014 and 2013 was 32.2%, 31.5% and 37.0%, respectively. The increase in the 2015 effective tax rate as compared to 2014
was primarily due to: the extension of the research credit as a result of the Tax Increase Prevention Act of 2014 which
reduced the 2015 effective tax rate by 0.8%; offset by the release of accruals related to uncertain tax positions as a result
of the lapse of statute of limitations and the closing of a U.S. taxing authority’s examination of the Company’s
research credit claims which reduced the 2014 effective tax rate by 2.6%.

[0001144204-15-068633:mdna:73]
The decrease in the 2014 effective tax rate as compared to 2013
was primarily due to: the release of accruals related to uncertain tax positions as a result of the lapse of statute of limitations
and the closing of a U.S. taxing authority’s examination of the Company’s research credit claims which reduced the
2014 effective tax rate by 2.9%; the December 31, 2013 expiration of the research tax credit which increased the 2014 effective
tax rate by 1.4%; and an adjustment to the foreign valuation allowance which increased the 2013 effective tax rate by 3.3%.

[0001144204-15-068633:mdna:74]
|  | 21 |  |

[0001144204-15-068633:mdna:75]
The Company’s foreign subsidiaries had accumulated unremitted
earnings of $35.3 million and cash of $31.5 million at September 30, 2015. No deferred taxes have been provided on these accumulated
unremitted earnings because these funds are not needed to meet the liquidity requirements of the Company’s U.S. operations
and it is the Company’s intention to indefinitely reinvest these earnings in continuing international operations. In the
event these foreign entities’ earnings were distributed, it is estimated that U.S. taxes, net of available foreign tax credits,
of approximately $4.9 million would be due, which would correspondingly reduce the Company’s net earnings. No significant
portion of the Company’s foreign subsidiaries’ earnings was taxed at a very low tax rate.

[0001144204-15-068633:mdna:76]
Capital Resources and Liquidity

[0001144204-15-068633:mdna:77]
The Company’s overall financial position and liquidity
are strong. Working capital (current assets less current liabilities) increased to $155.0 million at September 30, 2015, from $148.9
million at September 30, 2014, mainly due to higher inventory balances. The $2.8 million decrease in accounts receivable at September
30, 2015, was mainly due to: a $7.4 million decrease within the USG segment due to increased collections in the fourth quarter
of 2015; partially offset by a $3.4 million increase within the Filtration segment and a $1.7 million increase in the Test segment
due to the timing of sales. The $5.5 million increase in inventory at September 30, 2015, was mainly due to a $6.7 million increase
in the Filtration segment due to timing of receipt of raw materials to meet increased sales volumes and new product introductions,
partially offset by a $2.0 million decrease in the Test segment.

[0001144204-15-068633:mdna:78]
Net cash provided by operating activities from continuing operations
was $65.0 million, $44.9 million and $37.1 million in 2015, 2014 and 2013, respectively. The increase in 2015 as compared to the
prior year periods was mainly due to lower operating working capital requirements.

[0001144204-15-068633:mdna:79]
Capital expenditures from continuing operations were $12.4 million,
$12.7 million and $13.9 million in 2015, 2014 and 2013, respectively. The decrease in 2015 as compared to 2014 was not material.
The decrease in 2014 as compared to 2013 was mainly due to the 2013 purchase of the ETS-Lindgren facility in Minocqua, Wisconsin
for $1.2 million. There were no commitments outstanding that were considered material for capital expenditures at September 30,
2015. In addition, the Company incurred expenditures for capitalized software of $6.9 million, $8.6 million and $8.4 million
in 2015, 2014 and 2013, respectively. The decrease in 2015 as compared to 2014 was mainly due to lower capitalized software expenditures
at Doble. The increase in 2014 as compared to 2013 was not material.

[0001144204-15-068633:mdna:80]
The Company made required pension contributions of $0.7 million,
$2.7 million and $3.9 million in 2015, 2014 and 2013, respectively.

[0001144204-15-068633:mdna:81]
Divestiture

[0001144204-15-068633:mdna:82]
In March 2014, the Company completed the sale of Aclara Technologies
LLC (Aclara) to an affiliate of Sun Capital Partners, Inc. A disagreement between the parties over the calculation of the final
working capital adjustment was finally resolved by arbitration on June 15, 2015, resulting in a cash payment to the Company of
$2.3 million in 2015. For more information about the Aclara divestiture, see Note 2 to the Consolidated Financial Statements included
in this Report.

[0001144204-15-068633:mdna:83]
Acquisitions

[0001144204-15-068633:mdna:84]
2015

[0001144204-15-068633:mdna:85]
On January 28, 2015, the Company acquired the assets of Enoserv,
LLC (Enoserv), headquartered in Tulsa, Oklahoma, for $20.5 million in cash. Enoserv provides utility customers with high quality,
user-friendly multi-platform software and has annual revenues of approximately $8 million. Since the date of acquisition the operating
results for Enoserv have been included as part of Doble within the Company’s USG segment. Based on the purchase price allocation,
the Company recorded approximately $10.0 million of goodwill and $9.0 million of amortizable identifiable intangible assets consisting
primarily of customer relationships and developed technology.

[0001144204-15-068633:mdna:86]
All of the Company’s acquisitions have been accounted
for using the purchase method of accounting, and accordingly, the respective purchase prices were allocated to the assets (including
intangible assets) acquired and liabilities assumed based on estimated fair values at the date of acquisition. The financial
results from these acquisitions have been included in the Company’s financial statements from the date of acquisition.

[0001144204-15-068633:mdna:87]
|  | 22 |  |

[0001144204-15-068633:mdna:88]
Subsequent Event

[0001144204-15-068633:mdna:89]
On October 16, 2015, the Company acquired the stock of Fremont
Plastics, Inc. (“Fremont”) for a purchase price of $10.5 million in cash. The Company also purchased for $2 million
the real property located in Fremont, Indiana where Fremont’s operations are located. Fremont develops, manufactures, promotes
and sells high quality sterile-ready and non-sterile thin gauge thermoformed medical plastic packaging products. Immediately following
the closing of the transaction, Fremont was merged into TEQ, and since the date of acquisition the operating results for Fremont
have been included as part of TEQ.

[0001144204-15-068633:mdna:90]
Bank Credit Facility

[0001144204-15-068633:mdna:91]
The Company maintains a $450 million revolving credit facility
with JPMorgan Chase Bank, N.A., as administrative agent, PNC Bank, N.A., as syndication agent, and eight other participating lenders,
with a maturity date of May 14, 2017 (the “Credit Facility”). Through a credit facility expansion option, the Company
may elect to increase the size of the Credit Facility by entering into incremental term loans, in any agreed currency, at a minimum
of $25 million each up to a maximum of $250 million aggregate; the Company’s ability to access this increase option is subject
to acceptance by participating or other outside banks.

[0001144204-15-068633:mdna:92]
At September 30, 2015, the Company had approximately $392 million
available to borrow under the Credit Facility, plus the $250 million increase option, in addition to $39.4 million cash on
hand. The Company classified $20.0 million as the current portion of short-term debt as of September 30, 2015, as the Company
intends to repay this amount within the next 12 months; however, the Company has no contractual obligation to repay such amount
during the next twelve months.

[0001144204-15-068633:mdna:93]
The Credit Facility requires, as determined by certain financial
ratios, a facility fee ranging from 17.5 to 35 basis points per annum on the unused portion. The terms of the facility provide
that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime
rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic
subsidiaries and a 65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility
include a leverage ratio and an interest coverage ratio. As of September 30, 2015, the Company was in compliance with all bank
covenants.

[0001144204-15-068633:mdna:94]
Cash flow from operations and borrowings under the Credit Facility
are expected to provide adequate resources to meet the Company’s capital requirements and operational needs for the foreseeable
future.

[0001144204-15-068633:mdna:95]
Dividends

[0001144204-15-068633:mdna:96]
Since 2010 the Company has paid a regular quarterly cash dividend
at an annual rate of $0.32 per share. The Company paid dividends of $8.4 million, $8.5 million and $8.5 million in 2015, 2014
and 2013, respectively.

[0001144204-15-068633:mdna:97]
Outlook

[0001144204-15-068633:mdna:98]
The Company’s goals and expectations through 2017 reflect
compound annual sales growth of 10 percent, with compound annual EPS growth of 15 percent, with approximately 80 percent of the
growth being organic and approximately 20 percent coming from acquisitions.

[0001144204-15-068633:mdna:99]
Management expects 2016 EPS – As Adjusted to be in the
range of $1.90 to $2.00 per share, which excludes the 2016 restructuring charges described below.

[0001144204-15-068633:mdna:100]
|  | · | Closing the Test business operating facilities located in Taufkirchen, Germany and Stevenage, England and consolidating their operations into other existing Test facilities; |

[0001144204-15-068633:mdna:101]
|  | · | Eliminating certain underperforming product line offerings in Test, primarily related to lower margin international shielding end-markets; |

[0001144204-15-068633:mdna:102]
|  | · | Reducing the Test business domestic (U.S.) headcount to further streamline operations; and |

[0001144204-15-068633:mdna:103]
|  | · | Within the USG segment, closing the Doble-Brazil operating office and consolidating Doble’s South American sales and support activities into a lower cost operating structure, and rationalizing administrative costs at other operating locations. |

[0001144204-15-068633:mdna:104]
The costs to implement these actions in 2016 are expected to
be approximately $9 million, or $0.24 per share, and are expected to be incurred throughout the first half of the year as the actions
are anticipated to be substantially complete by March 31, 2016. During implementation, the cost savings are expected to be greater
than $6 million in 2016, and when completed, annual and recurring cost savings of $8 million are projected in 2017 and beyond.

[0001144204-15-068633:mdna:105]
The 2016 segment expectations are presented below:

[0001144204-15-068633:mdna:106]
|  | 23 |  |

[0001144204-15-068633:mdna:107]
|  | · | Filtration sales are expected to grow in the high single-digits with EBIT margins generally consistent with 2015. The sales growth is driven by the continued strength of the commercial aerospace market and significantly higher Space (SLS) sales at VACCO; |

[0001144204-15-068633:mdna:108]
|  | · | Test sales are expected to be flat, to slightly up, with a significant increase in adjusted EBIT margins. The full EBIT effect of the cost savings from the European facility consolidation will be realized in the second half of the year; |

[0001144204-15-068633:mdna:109]
|  | · | Doble sales are expected to increase greater than 10 percent with adjusted EBIT margins greater than 26 percent. The sales growth is driven by increased demand for services, additional new product sales, higher software and solutions implementations, and higher foreign sourced revenues. The increased margins are driven by a favorable sales mix on the increased revenues; and |

[0001144204-15-068633:mdna:110]
|  | · | The 2016 effective annual tax rate is expected to be approximately 35 percent. |

[0001144204-15-068633:mdna:111]
On a quarterly basis, Management expects 2016 revenues and EPS
– As Adjusted to reflect a profile similar to 2015, including EPS – As Adjusted being more second half weighted. The
majority of the 2016 restructuring charges will be incurred during the first half of the year, negatively impacting GAAP EPS on
a quarterly basis. Q1 2016 EPS – As Adjusted is expected to be in the range of $0.34 to $0.39 per share, excluding the Q1
impact of the 2016 restructuring charges.

[0001144204-15-068633:mdna:112]
Contractual Obligations

[0001144204-15-068633:mdna:113]
The following table shows the Company’s contractual obligations
as of September 30, 2015:

[0001144204-15-068633:mdna:114]
|  |  | Payments due by period |  |
|  |  |  |  |  | Less than |  |  | 1 to 3 |  |  | 3 to 5 |  |  | More than |  |
| (Dollars in millions) |  | Total |  |  | 1 year |  |  | years |  |  | years |  |  | 5 years |  |
| Long-Term Debt Obligation |  | $ | 50.0 |  |  |  | – |  |  |  | 50.0 |  |  |  | – |  |  |  | – |  |
| Estimated Interest Payments (1) |  |  | 1.1 |  |  |  | 0.7 |  |  |  | 0.4 |  |  |  | – |  |  |  | – |  |
| Operating Lease Obligations |  |  | 14.6 |  |  |  | 4.8 |  |  |  | 6.3 |  |  |  | 3.2 |  |  |  | 0.3 |  |
| Purchase Obligations (2) |  |  | 6.3 |  |  |  | 6.2 |  |  |  | 0.1 |  |  |  | – |  |  |  | – |  |
| Total |  | $ | 72.0 |  |  |  | 11.7 |  |  |  | 56.8 |  |  |  | 3.2 |  |  |  | 0.3 |  |

[0001144204-15-068633:mdna:115]
|  | (1) | Estimated interest payments for the Company’s debt obligations were calculated based on Management’s determination of the estimated applicable interest rates and payment dates. |

[0001144204-15-068633:mdna:116]
|  | (2) | A purchase obligation is defined as a legally binding and enforceable agreement to purchase goods and services that specifies all significant terms. Since the majority of the Company’s purchase orders can be cancelled, they are not included in the table above. |

[0001144204-15-068633:mdna:117]
As of September 30, 2015, the Company had $0.1 million of liabilities
for uncertain tax positions. The unrecognized tax benefits have been excluded from the table above due to uncertainty as to the
amounts and timing of settlement with taxing authorities.

[0001144204-15-068633:mdna:118]
The Company has no off-balance-sheet arrangements outstanding
at September 30, 2015.

[0001144204-15-068633:mdna:119]
Share Repurchases

[0001144204-15-068633:mdna:120]
In August 2012, the Company’s Board of Directors authorized
a common stock repurchase program under which the Company may repurchase shares of its stock from time to time in its discretion,
in the open market or otherwise, up to a maximum total repurchase amount of $100 million (or such lesser amount as may be permitted
under the Company’s bank credit agreements). This program has been twice extended by the Company’s Board of Directors
and is currently scheduled to expire September 30, 2017. The Company repurchased approximately 517,000 shares for $18.2 million
in 2015, 350,000 shares for $12.0 million in 2014, and 270,000 shares for $9.7 million in 2013.

[0001144204-15-068633:mdna:121]
Pension Funding Requirements

[0001144204-15-068633:mdna:122]
The minimum cash funding requirements related to the Company’s
defined benefit pension plans are estimated to be zero in 2016, and approximately $0.5 million in 2017 and $2.9 million in 2018..

[0001144204-15-068633:mdna:123]
|  | 24 |  |

[0001144204-15-068633:mdna:124]
Other

[0001144204-15-068633:mdna:125]
Management believes that, for the periods presented, inflation
has not had a material effect on the Company’s results of operations.

[0001144204-15-068633:mdna:126]
As a normal incident of the business in which the Company is
engaged, various claims, charges and litigation are asserted or commenced from time to time against the Company. Additionally,
the Company is currently involved in various stages of investigation and remediation relating to environmental matters. It is the
opinion of Management that the aggregate costs involved in the resolution of these matters, and final judgments, if any, which
might be rendered against the Company are adequately reserved for, are covered by insurance, or are not likely to have a material
adverse effect on the Company’s results from continuing operations, capital expenditures, or competitive position.

[0001144204-15-068633:mdna:127]
Market Risk Analysis

[0001144204-15-068633:mdna:128]
Market Risk Exposure

[0001144204-15-068633:mdna:129]
Market risks relating to the Company’s operations result
primarily from changes in interest rates and changes in foreign currency exchange rates. The Company is exposed to market risk
related to changes in interest rates and selectively uses derivative financial instruments, including forward contracts and swaps,
to manage these risks. During the second quarter of 2015, the Company entered into several forward contracts to purchase Euros
to hedge the foreign currency risk related to Euro denominated inventory payments. All derivative instruments are reported on the
balance sheet at fair value. The derivative instruments are designated as cash flow hedges and the gain or loss on the derivative
is deferred in accumulated other comprehensive income until recognized in earnings with the underlying hedged item.

[0001144204-15-068633:mdna:130]
The Company has determined that the market risk related to interest
rates with respect to its variable debt is not material. The Company estimates that if market interest rates averaged one percentage
point higher, the effect would have been less than 2% of net earnings for the year ended September 30, 2015. The following is a
summary of the notional transaction amounts and fair values for the Company’s outstanding derivative financial instruments
as of September 30, 2015.

[0001144204-15-068633:mdna:131]
| (In thousands) |  | Notional Amount (Euros) |  |  | Fair Value (US$) |  |
| Forward contracts |  |  | 1,289 |  |  |  | (94 | ) |

[0001144204-15-068633:mdna:132]
The Company is also subject to foreign currency exchange rate
risk inherent in its sales commitments, anticipated sales, anticipated purchases and assets and liabilities denominated in currencies
other than the U.S. dollar. The foreign currency most significant to the Company’s operations is the Euro. Net sales to customers
outside of the United States were $151.8 million, $157.1 million, and $153.7 million in 2015, 2014 and 2013, respectively. The
Company occasionally hedges certain foreign currency commitments by purchasing foreign currency forward contracts. The Company
does not have material foreign currency market risk (e.g. net foreign currency transaction gain/loss was less than 2% of net earnings
for 2015, 2014 and 2013).

[0001144204-15-068633:mdna:133]
Critical Accounting Policies

[0001144204-15-068633:mdna:134]
The preparation of financial statements in conformity with U.S.
generally accepted accounting principles (GAAP) requires Management to make estimates and assumptions in certain circumstances
that affect amounts reported in the accompanying Consolidated Financial Statements. In preparing these financial statements, Management
has made its best estimates and judgments of certain amounts included in the Consolidated Financial Statements, giving due consideration
to materiality. The Company does not believe there is a great likelihood that materially different amounts would be reported under
different conditions or using different assumptions related to the accounting policies described below. However, application of
these accounting policies involves the exercise of judgment and use of assumptions as to future uncertainties and, as a result,
actual results could differ from these estimates. The Company’s senior Management discusses the critical accounting policies
described below with the Audit and Finance Committee of the Company’s Board of Directors on a periodic basis.

[0001144204-15-068633:mdna:135]
The following discussion of critical accounting policies is
intended to bring to the attention of readers those accounting policies which Management believes are critical to the Consolidated
Financial Statements and other financial disclosure. It is not intended to be a comprehensive list of all significant accounting
policies that are more fully described in Note 1 to the Consolidated Financial Statements included herein.

[0001144204-15-068633:mdna:136]
|  | 25 |  |

[0001144204-15-068633:mdna:137]
Revenue Recognition

[0001144204-15-068633:mdna:138]
Filtration
Segment: Within the Filtration segment, approximately 87% of segment revenues (approximately 38% of consolidated
revenues) are recognized when products are delivered (when title and risk of ownership transfers) or when services are performed
for unaffiliated customers.

[0001144204-15-068633:mdna:139]
Approximately 13% of segment revenues (approximately 6% of consolidated
revenues) are recorded under the percentage-of-completion provisions because the Company manufactures complex products for aerospace
and military customers under production contracts. The percentage-of-completion method of accounting involves the use of various
estimating techniques to project costs at completion. These estimates involve various assumptions and projections relative to the
outcome of future events over a period of several years, including future labor productivity and availability, the nature and complexity
of the work to be performed, availability of materials, the impact of delayed performance, and the timing of product deliveries.
These estimates are based on Management’s judgment and the Company’s substantial experience in developing these types
of estimates. Changes in underlying assumptions/estimates may adversely affect financial performance if they increase estimated
project costs at completion, or positively affect financial performance if they decrease estimated project costs at completion.
Due to the nature of these contracts and the operating unit’s cost estimating process, the Company believes that these estimates
generally should not be subject to significant variation in the future. There have been no material changes to these estimates
for the financial statement periods presented. The Company regularly reviews its estimates to assess revisions in contract values
and estimated costs at completion.

[0001144204-15-068633:mdna:140]
Test
Segment: Within the Test segment, approximately 27% of revenues (approximately 9% of consolidated revenues)
are recognized when products are delivered (when title and risk of ownership transfers) or when services are performed for unaffiliated
customers.

[0001144204-15-068633:mdna:141]
Approximately 73% of the segment’s revenues (approximately
24% of consolidated revenues) are recorded under the percentage-of-completion method due to the complex nature of the enclosures
that are designed and produced under these contracts. As discussed above, this method of accounting involves the use of various
estimating techniques to project costs at completion, which are based on Management’s judgment and the Company’s substantial
experience in developing these types of estimates. Changes in underlying assumptions/estimates may adversely or positively affect
financial performance in a period. Due to the nature of these contracts and the operating unit’s cost estimating process,
the Company believes that these estimates generally should not be subject to significant variation in the future. There have been
no material changes to these estimates for the financial statement periods presented. The Company regularly reviews its contract
estimates to assess revisions in contract values and estimated costs at completion.

[0001144204-15-068633:mdna:142]
USG
Segment: Within the USG segment, approximately 100% of the segment’s revenues (approximately 23% of consolidated
revenues) represent products and services sold under a single element arrangement and are recognized when products are delivered
(when title and risk of ownership transfers), when services are performed for unaffiliated customers or on a straight-line basis
over the lease term.

[0001144204-15-068633:mdna:143]
Inventory

[0001144204-15-068633:mdna:144]
Inventories are valued at the lower of cost (first-in, first-out)
or market value. Management regularly reviews inventories on hand compared to historical usage and estimated future usage and sales.
The Company’s businesses review inventory for obsolescence, make appropriate provisions and dispose of obsolete inventory
on a regular basis. Various factors are considered in these reviews, including sales history and recent trends, industry conditions,
and general economic conditions.

[0001144204-15-068633:mdna:145]
Income Taxes

[0001144204-15-068633:mdna:146]
The Company operates in numerous taxing jurisdictions and is
subject to examination by various U.S. Federal, state and foreign jurisdictions for various tax periods. Additionally, the Company
has retained tax liabilities and the rights to tax refunds in connection with various divestitures of businesses in prior years.
The Company’s income tax positions are based on research and interpretations of the income tax laws and rulings in each of
the jurisdictions in which the Company does business. Due to the subjectivity of interpretations of laws and rulings in each jurisdiction,
the differences and interplay in tax laws between those jurisdictions, as well as the inherent uncertainty in estimating the final
resolution of complex tax audit matters, Management’s estimates of income tax liabilities may differ from actual payments
or assessments.

[0001144204-15-068633:mdna:147]
|  | 26 |  |

[0001144204-15-068633:mdna:148]
Management regularly assesses the Company’s position with
regard to tax exposures and records liabilities for these uncertain tax positions and related interest and penalties, if any, according
to the principles of Financial Accounting Standards Board (FASB) ASC Topic 740, Income Taxes (ASC 740). The Company
has recorded an accrual that reflects the recognition and measurement process for the financial statement recognition and measurement
of a tax position taken or expected to be taken on a tax return based upon ASC 740. Additional future income tax expense or
benefit may be recognized once the positions are effectively settled. It is the Company’s policy to follow FASB ASC
740-10-45-20 and record the tax effects of changes in the opening balance of unrecognized tax benefits in net earnings from continuing
operations.

[0001144204-15-068633:mdna:149]
At the end of each interim reporting period, Management estimates
the effective tax rate expected to apply to the full fiscal year. The estimated effective tax rate contemplates the expected jurisdiction
where income is earned, as well as tax planning strategies. Current and projected growth in income in higher tax jurisdictions
may result in an increasing effective tax rate over time. If the actual results differ from Management’s estimates, Management
may have to adjust the effective tax rate in the interim period if such determination is made.

[0001144204-15-068633:mdna:150]
Income taxes are accounted for under the asset and liability
method. Deferred tax assets and liabilities are recognized for the future tax consequences attributable to differences between
the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets
and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary
differences are expected to be recovered or settled. Deferred tax assets may be reduced by a valuation allowance if it is more
likely than not that some portion of the deferred tax assets will not be realized. The effect on deferred tax assets and liabilities
of a change in tax rates is recognized in income in the period that includes the enactment date. The Company regularly reviews
its deferred tax assets for recoverability and establishes a valuation allowance when Management believes it is more likely than
not such assets will not be recovered, taking into consideration historical operating results, expectations of future earnings,
tax planning strategies, and the expected timing of the reversals of existing temporary differences.

[0001144204-15-068633:mdna:151]
Goodwill And Other Long-Lived Assets

[0001144204-15-068633:mdna:152]
Management annually reviews goodwill and other long-lived assets
with indefinite useful lives for impairment or whenever events or changes in circumstances indicate the carrying amount may not
be recoverable. If the Company determines that the carrying value of the long-lived asset may not be recoverable, a permanent impairment
charge is recorded for the amount by which the carrying value of the long-lived asset exceeds its fair value. Fair value is measured
based on a discounted cash flow method using a discount rate determined by Management to be commensurate with the risk inherent
in the Company’s current business model. The estimates of cash flows and discount rate are subject to change due to the economic
environment, including such factors as interest rates, expected market returns and volatility of markets served. Management believes
that the estimates of future cash flows and fair value are reasonable; however, changes in estimates could result in impairment
charges. At September 30, 2015, the Company has determined that no reporting units are at risk of material goodwill impairment
as the fair value of each reporting unit substantially exceeded its carrying value.

[0001144204-15-068633:mdna:153]
Intangible assets with estimable useful lives are amortized
over their respective estimated useful lives to their estimated residual values, and are reviewed annually for impairment.

[0001144204-15-068633:mdna:154]
Pension Plans and Other Postretirement Benefit Plans

[0001144204-15-068633:mdna:155]
The measurement of liabilities related to pension plans and
other postretirement benefit plans is based on Management’s assumptions related to future events including interest rates,
return on pension plan assets, and health care cost trend rates. Actual pension plan asset performance will either decrease or
increase unamortized pension losses/gains that will affect net earnings in future years. Depending upon the performance of the
equity and bond markets in 2016, the Company could be required to record a charge to other comprehensive income/loss. In addition,
if the discount rate were decreased by 25 basis points from 4.25% to 4.0%, the projected benefit obligation for the defined benefit
plan would increase by approximately $2.8 million and result in an additional after-tax charge to other comprehensive income/loss
of approximately $1.7 million. The discount rate used in measuring the Company’s pension and postretirement welfare obligations
was developed by matching yields of actual high-quality corporate bonds to expected future pension plan cash flows (benefit payments).
Over 400 Aa-rated, non-callable bonds with a wide range of maturities were used in the analysis. After using the bond yields to
determine the present value of the plan cash flows, a single representative rate that resulted in the same present value was developed.

[0001144204-15-068633:mdna:156]
|  | 27 |  |

[0001144204-15-068633:mdna:157]
Other Matters

[0001144204-15-068633:mdna:158]
Contingencies

[0001144204-15-068633:mdna:159]
As a normal incident of the businesses in which the Company
is engaged, various claims, charges and litigation are asserted or commenced from time to time against the Company. Additionally,
the Company is currently involved in various stages of investigation and remediation relating to environmental matters. It is the
opinion of Management that the aggregate costs involved in the resolution of these matters, and final judgments, if any, which
might be rendered against the Company are adequately reserved for, are covered by insurance, or are not likely to have a material
adverse effect on the Company’s results from continuing operations, capital expenditures, or competitive position.

[0001144204-15-068633:mdna:160]
Quantitative and Qualitative Disclosures About Market
Risk

[0001144204-15-068633:mdna:161]
Market risks relating to the Company’s operations result
primarily from changes in interest rates and changes in foreign currency exchange rates. The Company is exposed to market risk
related to changes in interest rates and selectively uses derivative financial instruments, including forward contracts and swaps,
to manage these risks. During the second quarter of 2015 the Company entered into several forward contracts to purchase Euros to
hedge the foreign currency risk related to Euro denominated inventory payments. All derivative instruments are reported on the
balance sheet at fair value. The derivative instruments are designated as cash flow hedges and the gain or loss on the derivative
is deferred in accumulated other comprehensive income until recognized in earnings with the underlying hedged item. See the further
discussion regarding the Company’s market risks in “Market Risk Analysis,” above.

[0001144204-15-068633:mdna:162]
Controls and Procedures

[0001144204-15-068633:mdna:163]
For a description of the Company’s evaluation of its disclosure
controls and procedures1, see Item 9A, “Controls and Procedures,” below.

[0001144204-15-068633:mdna:164]
New Accounting Pronouncements

[0001144204-15-068633:mdna:165]
In April 2015, the FASB issued ASU No. 2015-03, Interest
– Imputation of Interest (Subtopic 835-30), which requires that debt issuance costs be presented in the balance sheet
as a direct deduction from the carrying amount of debt liability, consistent with debt discounts or premiums. The new standard
is effective for fiscal years beginning after December 15, 2015, and interim periods within fiscal years beginning after December
15, 2016. Early adoption is permitted and will be applied on a retrospective basis. We have evaluated the impact of this standard
and do not anticipate a material impact on our consolidated financial statements and related disclosures upon adoption.

[0001144204-15-068633:mdna:166]
In July 2015, the FASB affirmed its proposed one-year deferral
of ASU No. 2014-09, Revenue from Contracts with Customers, which requires an entity to recognize the amount of revenue
to which it expects to be entitled for the transfer of promised goods or services to customers. The new standard will be effective
for annual reporting periods beginning after December 15, 2017, and interim periods within those annual periods. Early application
is not permitted. The standard permits the use of either the retrospective or cumulative effect transition method. The Company
is currently in the process of evaluating the effect that ASU 2014-09 will have on its consolidated financial statements and
related disclosures and selecting the method of transition to the new standard.

[0001144204-15-068633:mdna:167]
In July 2015, the FASB issued ASU No. 2015-11, Inventory
(Topic 330): Simplifying the Measurement of Inventory, which requires entities to measure most inventory “at the lower
of cost and net realizable value,” thereby simplifying the current guidance under which an entity must measure inventory
at the lower of cost or market. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably
predictable costs of completion, disposal and transportation. The new standard is effective for fiscal years beginning after December
15, 2016, including interim periods within those fiscal years. ASU 2015-11 should be applied prospectively with earlier application
permitted as of the beginning of an interim or annual reporting period. The Company is currently assessing the impact of this new
standard on its consolidated financial statements and related disclosures.

[0001144204-15-068633:mdna:168]
|  | 28 |  |
