# ESE 8-K — 0000866706-15-000012 filed 2015-11-12

## item codes, every 8-K on or before 2015-11-30

- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2015-11-30

- none on or before 2015-11-30

## item 2.02 — earnings release, exhibit 99.1

[0000866706-15-000012:8k_2_02:1]
EX-99.1
5
escopressrelease.htm
ESCO PRESS RELEASE

[0000866706-15-000012:8k_2_02:2]
escopressrelease.htm

[0000866706-15-000012:8k_2_02:3]
EXHIBIT 99.1

[0000866706-15-000012:8k_2_02:4]
NEWS FROM

[0000866706-15-000012:8k_2_02:5]
For more information contact:

[0000866706-15-000012:8k_2_02:6]
Kate Lowrey

[0000866706-15-000012:8k_2_02:7]
Director, Investor Relations

[0000866706-15-000012:8k_2_02:8]
ESCO Technologies Inc.

[0000866706-15-000012:8k_2_02:9]
(314) 213-7277

[0000866706-15-000012:8k_2_02:10]
ESCO ANNOUNCES FISCAL 2015 RESULTS

[0000866706-15-000012:8k_2_02:11]
ST. LOUIS, November 12, 2015 – ESCO Technologies Inc. (NYSE: ESE) (ESCO or the “Company”) today reported its operating results for the year ended September 30, 2015 (2015).

[0000866706-15-000012:8k_2_02:12]
The 2015 results from Continuing Operations include the $5.6 million of previously disclosed non-cash charges related to the Test business.

[0000866706-15-000012:8k_2_02:13]
The 2014 results are described on a Continuing Operations – As Adjusted basis consistent with the prior year presentation, and exclude $1.7 million, or $0.05 per share, of charges related to the exit and relocation of Crissair’s (Filtration segment) California manufacturing facilities completed in September 2014.

[0000866706-15-000012:8k_2_02:14]
All references to Continuing Operations exclude Aclara Technologies LLC, which was divested on March 28, 2014. Aclara’s results are presented as Discontinued Operations.

[0000866706-15-000012:8k_2_02:15]
Management believes EPS – As Adjusted is more representative of the Company’s ongoing performance and allows shareholders better visibility into the Company’s underlying operations.

[0000866706-15-000012:8k_2_02:16]
EPS Summary

[0000866706-15-000012:8k_2_02:17]
2015 EPS from Continuing Operations was $1.59 per share, which was negatively impacted by the previously disclosed non-cash charges related to the Test business. Net earnings from Discontinued Operations added $0.03 per share in 2015, resulting in GAAP EPS of $1.62 per share.

[0000866706-15-000012:8k_2_02:18]
2014 EPS from Continuing Operations – As Adjusted was $1.65 per share, which excludes the $0.05 per share of charges related to the Crissair consolidation noted above which are added back to EPS from Continuing Operations of $1.60 per share. The net loss from Discontinued Operations was ($1.58) per share in 2014 resulting in GAAP EPS of $0.02 per share.

[0000866706-15-000012:8k_2_02:19]
Continuing Operations Highlights – 2015

[0000866706-15-000012:8k_2_02:20]
| · | Sales increased $6 million to $537 million compared to $531 million in 2014. Utility Solutions Group (USG, or Doble) sales increased $8 million, Filtration sales increased $2 million, despite the previously described decrease in expected SLS Space program sales at VACCO, and Test sales decreased $4 million during the year due to lower sales within the global shielding market; |

[0000866706-15-000012:8k_2_02:21]
| · | Gross margin percentage was 38 percent compared to 39 percent in 2014. Doble and Filtration gross margins increased as a result of the additional sales volume and improved manufacturing efficiencies, coupled with a strong and favorable product mix. The Doble and Filtration margin increases were offset by lower gross margins in Test which were driven by the lower shielding sales, and the $5 million of incremental charges referenced earlier which were included in cost of sales; |

[0000866706-15-000012:8k_2_02:22]
| · | SG&A decreased $5 million in 2015, primarily driven by numerous cost reduction initiatives implemented within Test; a lower operating cost structure at Crissair (Filtration segment) resulting from the facility consolidation; and lower Corporate expenses. These reductions were partially offset by additional international sales and marketing expenses incurred at Doble to support its near-term growth opportunities; |

[0000866706-15-000012:8k_2_02:23]
| · | The effective tax rate was 32.2 percent in 2015 compared to 31.5 percent in 2014; |

[0000866706-15-000012:8k_2_02:24]
| · | Orders were $562 million (book-to-bill of 1.05x) reflecting a $25 million, or 8 percent, increase in backlog during the year, which resulted in an ending backlog of $328 million at September 30, 2015; |

[0000866706-15-000012:8k_2_02:25]
| · | Filtration orders were $253 million (book-to-bill of 1.07x) and included a significant amount of commercial aerospace orders (A-350, other new platform wins, etc.) at PTI, increased Space orders at VACCO (SLS), and higher orders at TEQ (KAZ Gen 2); |

[0000866706-15-000012:8k_2_02:26]
| · | Doble’s orders were $127 million (book-to-bill of 1.03x) and included additional services business in the Middle East (Saudi Arabia) and solid domestic product, software and solution bookings; |

[0000866706-15-000012:8k_2_02:27]
| · | Test orders were $182 million (book-to-bill of 1.02x) which reflects the large automotive chamber award in Asia as well as solid demand for its other suites of products; and |

[0000866706-15-000012:8k_2_02:28]
| · | Net debt at September 30, 2015 was $11 million ($39 million of cash and $50 million of borrowings), and includes $21 million spent on the ENOSERV acquisition and $27 million spent on stock repurchases and dividends. |

[0000866706-15-000012:8k_2_02:29]
Chairman’s Commentary - FY 2015

[0000866706-15-000012:8k_2_02:30]
Vic Richey, Chairman and Chief Executive Officer, commented, “With the exception of the softness in the Test shielding market, our 2015 performance was solid and met, or exceeded, our financial expectations. Doble continued to make a significant contribution with another strong year as its EBIT increased $3 million, resulting in a 24 percent EBIT margin. Doble’s new product offerings continue to gain meaningful traction, and its international growth strategy is generating meaningful sales well ahead of plan.

[0000866706-15-000012:8k_2_02:31]
“Filtration’s EBIT increased $5 million in 2015, resulting in a 20 percent EBIT margin. Both PTI and Crissair reported significant increases in sales and EBIT as both are benefitting from the continued strength of the commercial aerospace upcycle and the initial production ramp up of recent new platform wins such as the A-350. Another positive was that Vacco was able to recapture a significant portion of its Space business sales (SLS program timing) from the decreased sales expectations noted at the beginning of the year.

[0000866706-15-000012:8k_2_02:32]
“The Test results were disappointing as we continued to experience softness in one of our higher margin product lines throughout the year, and in the second half of 2015, we recorded certain non-cash charges which significantly impacted Test’s EBIT margins.

[0000866706-15-000012:8k_2_02:33]
“To address the Test business issues, we initiated several significant and aggressive cost reduction actions which we announced in our October 8th release. These actions are intended to significantly enhance our ability to achieve our previously stated goals, as we are implementing specific and sustainable measures designed to increase our operating results in 2016 and beyond. We expect these actions to increase our operational efficiency, improve profitability, and increase ROIC. We remain confident that Test can achieve EBIT margins in the low-to-mid teens once the planned actions are fully implemented.

[0000866706-15-000012:8k_2_02:34]
“Across the company, strong orders and solid cash flow continued to be a bright spot during 2015 as our ending backlog increased $25 million, or eight percent, during the year which bodes well for supporting our 2016 outlook. I’m pleased to report that all three of our operating segments delivered a positive book-to-bill in 2015.

[0000866706-15-000012:8k_2_02:35]
“Our strong cash flow allowed us to significantly increase our cash returned to shareholders in support of our stated capital allocation goals.

[0000866706-15-000012:8k_2_02:36]
“We continue to review numerous acquisition opportunities and are confident we will be successful in adding to our existing portfolio in the near-term. Acquisitions remain a key element to supplement our growth, and while recent purchase multiples in certain segments appear extraordinary, we will remain disciplined in our approach to ensure we can generate an attractive return on these investments.

[0000866706-15-000012:8k_2_02:37]
“We continue to have a favorable view of our future and our goal remains the same – to increase long-term shareholder value.”

[0000866706-15-000012:8k_2_02:38]
Discontinued Operations

[0000866706-15-000012:8k_2_02:39]
The Company completed the Aclara divestiture on March 28, 2014 and used the proceeds to significantly pay down its outstanding debt. The results of operations for Aclara are reflected in the financial statements as Discontinued Operations.

[0000866706-15-000012:8k_2_02:40]
Share Repurchase

[0000866706-15-000012:8k_2_02:41]
During 2015, the Company spent $18.2 million to repurchase approximately 520,000 of its outstanding shares on the open market. The Company’s share repurchase authorization was extended through September 30, 2017, and Management expects to continue to opportunistically repurchase its shares under this authorization.

[0000866706-15-000012:8k_2_02:42]
Dividend Payment

[0000866706-15-000012:8k_2_02:43]
The next quarterly cash dividend of $0.08 per share will be paid on January 19, 2016 to stockholders of record on January 4, 2016.

[0000866706-15-000012:8k_2_02:44]
Acquisition Update

[0000866706-15-000012:8k_2_02:45]
On October 16, 2015, the Company acquired the stock of Fremont Plastics Inc. (Fremont), a custom thermoform packaging business located in Fremont, Indiana. Fremont has a long and successful history of providing superior products and solutions to the Healthcare market.

[0000866706-15-000012:8k_2_02:46]
Fremont’s value proposition lies in the design and manufacture of medical device components, sterile barrier packaging for medical devices and procedure kits, as well as contract packaging services for medical OEM’s and distributors.

[0000866706-15-000012:8k_2_02:47]
Fremont operates seven thermoforming machines in two class 100,000 controlled clean rooms within its 40,000 square foot facility.

[0000866706-15-000012:8k_2_02:48]
The Company is currently evaluating several additional acquisition opportunities which are in various stages of diligence. Management remains confident that it will be successful in closing additional acquisitions during fiscal 2016.

[0000866706-15-000012:8k_2_02:49]
2016 Restructuring Actions (Previously Disclosed)

[0000866706-15-000012:8k_2_02:50]
The 2016 restructuring actions detailed in the Company’s October 8, 2015 release, include:

[0000866706-15-000012:8k_2_02:51]
| · | Closing the Test business operating facilities located in Taufkirchen, Germany and Stevenage, England and consolidating their operations into other existing Test facilities; |

[0000866706-15-000012:8k_2_02:52]
| · | Eliminating certain underperforming product line offerings in Test, primarily related to lower margin international shielding end-markets; |

[0000866706-15-000012:8k_2_02:53]
| · | Reducing the Test business domestic (U.S.) headcount to further streamline operations; and |

[0000866706-15-000012:8k_2_02:54]
| · | Within the USG segment, closing the Doble-Brazil operating office and consolidating Doble’s South American sales and support activities into a lower cost operating structure, and rationalizing administrative costs at other operating locations. |

[0000866706-15-000012:8k_2_02:55]
The costs to implement these actions in 2016 are expected to be approximately $9 million, or $0.24 per share, and are expected to be incurred throughout the first half of the year as the actions are anticipated to be substantially complete by March 31, 2016.

[0000866706-15-000012:8k_2_02:56]
These costs will be specifically quantified and called out separately as part of Management’s 2016 guidance noted below, and will be identified within the quarterly earnings reports in 2016 where Management will present its results on an EPS – As Adjusted basis, and will reconcile these amounts to their respective GAAP equivalents.

[0000866706-15-000012:8k_2_02:57]
The cost savings are expected to be greater than $6 million in 2016, and when completed, annual and recurring cost savings of approximately $8 million are projected in 2017 and beyond. The cost of these restructuring activities are expected to be recovered over the next 12 months once completed.

[0000866706-15-000012:8k_2_02:58]
The cash and non-cash restructuring costs relate to employee severance and compensation benefits, facility exit and lease termination costs, deferred tax asset write-offs, moving costs, professional fees, and asset impairment charges related to abandoned assets.

[0000866706-15-000012:8k_2_02:59]
Management expects these actions, when fully implemented, to result in the Test business EBIT margins increasing into the low-to-mid teens.

[0000866706-15-000012:8k_2_02:60]
Business Outlook – Fiscal Year 2016

[0000866706-15-000012:8k_2_02:61]
Management continues to see meaningful sales, EBIT, and EPS growth across the business segments consistent with the expectations communicated in the Company’s September 2014 Analyst Day Presentation (included on the Company’s website).

[0000866706-15-000012:8k_2_02:62]
The Company’s goals and expectations through 2017 reflect compound annual sales growth of 10 percent, with compound annual EPS growth of 15 percent, with approximately 80 percent of the growth being organic and approximately 20 percent coming from acquisitions.

[0000866706-15-000012:8k_2_02:63]
Management expects 2016 EPS – As Adjusted to be in the range of $1.90 to $2.00 per share, which excludes the 2016 restructuring charges (approximately $9 million pretax) described above.

[0000866706-15-000012:8k_2_02:64]
The 2016 segment expectations are presented in summary fashion:

[0000866706-15-000012:8k_2_02:65]
| · | Filtration sales are expected to grow in the high single-digits with EBIT margins generally consistent with 2015. The sales growth is driven by the continued strength of the commercial aerospace market and significantly higher Space (SLS) sales at Vacco; |

[0000866706-15-000012:8k_2_02:66]
| · | Test sales are expected to be flat, to slightly up, with a significant increase in adjusted EBIT margins. The full EBIT effect of the cost saving actions will be realized in the second half of the year; |

[0000866706-15-000012:8k_2_02:67]
| · | Doble sales are expected to increase greater than 10 percent with a corresponding increase in adjusted EBIT margins. The sales growth is driven by increased demand for services, additional new product sales, higher software and solutions implementations, and higher foreign sourced revenues. The increased margins are driven by a favorable sales mix on the increased revenues; and |

[0000866706-15-000012:8k_2_02:68]
| · | The 2016 annual effective tax rate is expected to be approximately 35 percent. |

[0000866706-15-000012:8k_2_02:69]
On a quarterly basis, Management expects 2016 revenues and EPS – As Adjusted to reflect a profile similar to 2015, including EPS – As Adjusted being more second half weighted. The majority of the 2016 restructuring charges will be incurred during the first half of the year, negatively impacting GAAP EPS on a quarterly basis.

[0000866706-15-000012:8k_2_02:70]
Q1 2016 EPS – As Adjusted is expected to be in the range of $0.34 to $0.39 per share, excluding the Q1 impact of the 2016 restructuring charges.

[0000866706-15-000012:8k_2_02:71]
Chairman’s Commentary - FY 2016

[0000866706-15-000012:8k_2_02:72]
Mr. Richey continued, “The growth we are expecting in 2016 puts us on track to meet our stated sales and EPS goals that were communicated at the Analyst Day, and firmly plants the foundation for continued growth beyond this year.

[0000866706-15-000012:8k_2_02:73]
“I’m excited to see the continued strength at Doble and Filtration as it continues to validate the investments we’ve made over the past few years to enhance and accelerate a sustainable growth outlook.

[0000866706-15-000012:8k_2_02:74]
“Filtration is now realizing the benefits of the initial production increases related to its new aerospace platform wins, supplemented by additional Space program wins and the stabilization of the SLS program. Each of these opportunities are expected to expand future growth as these programs have lengthy production runs.

[0000866706-15-000012:8k_2_02:75]
“Doble continues to gain momentum from its new product introductions, coupled with expanding its international reach. We expect to see additional sales and EBIT margin expansion opportunities in the future as the world-wide grid’s aging infrastructure and the expanding need for reliable delivery of electricity, will put Doble at the forefront to assist customers in addressing their needs and providing world-class solutions.

[0000866706-15-000012:8k_2_02:76]
“Given the current restructuring actions underway in Test, I’m confident that having a significantly lower operating cost structure, and narrowing our focus to higher margin products and geographies will meaningfully improve our future operating margins and increase our competitive position across our end-markets.

[0000866706-15-000012:8k_2_02:77]
“I firmly believe our market leadership positions, along with the breadth and diversity of our new product offerings, will continue to allow us to grow organically at meaningful levels. With this backdrop, we remain committed to our three year growth targets and EPS goals.”

[0000866706-15-000012:8k_2_02:78]
Conference Call

[0000866706-15-000012:8k_2_02:79]
The Company will host a conference call today, November 12, at 4:00 p.m. Central Time, to discuss the Company’s 2015 results. A live audio webcast will be available on the Company’s website at www.escotechnologies.com. Please access the website at least 15 minutes prior to the call to register, download and install any necessary audio software. A replay of the conference call will be available for seven days on the Company’s website noted above or by phone (dial 1-855-859-2056 and enter the pass code 52001180).

[0000866706-15-000012:8k_2_02:80]
Forward-Looking Statements

[0000866706-15-000012:8k_2_02:81]
Statements in this press release regarding the Company’s expected 2016 and beyond operating results, revenue and sales growth, EBIT, EBIT margins, ROIC, corporate costs, the timing, benefits, costs and savings associated with the cost reduction activities and restructuring actions, effective tax rates, EPS, EPS – As Adjusted, EPS growth, the Company’s ability to increase operating margins, realize financial goals and increase shareholder value, the success of acquisition efforts, the success of new products and solutions, the size, number and timing of future sales and growth opportunities, the specific actions initiated as a result of the Capital Allocation Strategy including but not limited to the declaration of dividends and share repurchases, the long-term success of the Company, and any other statements which are not strictly historical are “forward-looking” statements within the meaning of the safe harbor provisions of the federal securities laws.

[0000866706-15-000012:8k_2_02:82]
Investors are cautioned that such statements are only predictions and speak only as of the date of this release, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment including, but not limited to those described in Item 1A, “Risk Factors”, of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2014, and the following: the success of the Company’s competitors; site readiness issues with Test segment customers; weakening of economic conditions in served markets; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties; unforeseen charges impacting corporate operating expenses; delivery delays or defaults by customers; the performance of the Company’s international operations; material changes in the costs and availability of certain raw materials; the appropriation and allocation of Government funds; the termination for convenience of Government and other customer contracts; the timing and content of future contract awards or customer orders; containment of engineering and development costs; performance issues with key customers, suppliers and subcontractors; labor disputes; the impacts of natural disasters on the Company’s operations and those of the Company’s customers and suppliers; changes in laws and regulations, including but not limited to changes in accounting standards and taxation requirements; costs relating to environmental matters arising from current or former facilities; financial exposure in connection with Company guarantees of certain Aclara contracts; the availability of select acquisitions; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the Company’s successful execution of cost reduction and profit improvement initiatives and restructuring activities.

[0000866706-15-000012:8k_2_02:83]
Non-GAAP Financial Measures

[0000866706-15-000012:8k_2_02:84]
The financial measures EBIT, EBIT margin, EPS – “As Adjusted” and EPS – from Continuing Operations “As Adjusted” are presented in this press release. The Company defines EBIT as earnings before interest and taxes from continuing operations, EBIT margin as a percent of net sales, EPS – “As Adjusted” and EPS – from Continuing Operations “As Adjusted” as GAAP EPS less the 2014 Filtration segment restructuring charges of $0.05 per share.

[0000866706-15-000012:8k_2_02:85]
EBIT, EBIT margin, EPS – “As Adjusted” and EPS – from Continuing Operations “As Adjusted” are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management believes that EBIT and EBIT margin are useful in assessing the operational profitability of the Company’s business segments because they exclude interest and taxes, which are generally accounted for across the entire Company on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company as well as incentive compensation. The Company believes that the presentation of EBIT, EBIT margin, EPS – “As Adjusted” and EPS – from Continuing Operations “As Adjusted” provides important supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance determined in accordance with GAAP. A reconciliation of these non-GAAP financial measures to the corresponding GAAP measures is included in the attached tables.

[0000866706-15-000012:8k_2_02:86]
ESCO, headquartered in St. Louis, provides engineered filtration products to the aviation, space and process markets worldwide and is the industry leader in RF shielding and EMC test products. In addition, the Company provides diagnostic instruments, services and the world’s premier library of statistically significant apparatus test results for the benefit of energy generation, transmission, and delivery companies and industrial power users worldwide. Further information regarding ESCO and its subsidiaries is available on the Company’s website at www.escotechnologies.com.

[0000866706-15-000012:8k_2_02:87]
-  tables attached

[0000866706-15-000012:8k_2_02:88]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Condensed Consolidated Statements of Operations (Unaudited) |  |
| (Dollars in thousands, except per share amounts) |  |
|  |  | Year Ended September 30, 2015 |  |  | Year Ended September 30, 2014 |  |
| Net Sales |  |  | 537,291 |  |  |  | 531,120 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 334,850 |  |  |  | 323,939 |  |
| Selling, general and administrative expenses |  |  | 130,166 |  |  |  | 134,899 |  |
| Amortization of intangible assets |  |  | 8,850 |  |  |  | 6,744 |  |
| Interest expense |  |  | 785 |  |  |  | 1,567 |  |
| Other (income) expenses, net |  |  | 1,119 |  |  |  | 1,764 |  |
| Total costs and expenses |  |  | 475,770 |  |  |  | 468,913 |  |
| Earnings before income taxes |  |  | 61,521 |  |  |  | 62,207 |  |
| Income taxes |  |  | 19,785 |  |  |  | 19,594 |  |
| Net earnings from continuing operations |  |  | 41,736 |  |  |  | 42,613 |  |
| Earnings from discontinued operations, net of tax |  |  |  |  |  |  |  |  |
| expense of $5,713 |  |  | 0 |  |  |  | 9,858 |  |
| Gain (loss) on sale of discontinued operations, net of tax |  |  |  |  |  |  |  |  |
| expense (benefit) of $390 and $(11,747), respectively |  |  | 776 |  |  |  | (52,061 | ) |
| Net earnings (loss) from discontinued operations |  |  | 776 |  |  |  | (42,203 | ) |
| Net earnings |  | $ | 42,512 |  |  |  | 410 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |
| Diluted |  |  |  |  |  |  |  |  |
| Continuing operations |  |  | 1.59 |  |  |  | 1.60 |  |
| Discontinued operations |  |  | 0.03 |  |  |  | (1.58 | ) |
| Net earnings |  | $ | 1.62 |  |  |  | 0.02 |  |
| Average common shares O/S: |  |  |  |  |  |  |  |  |
| Diluted |  |  | 26,265 |  |  |  | 26,644 |  |

[0000866706-15-000012:8k_2_02:89]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Condensed Business Segment Information (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  | Year Ended September 30 |  |
|  |  | 2015 |  |  | 2014 |  |
| Net Sales |  |  |  |  |  |  |
| Filtration |  | $ | 236,124 |  |  |  | 233,697 |  |
| Test |  |  | 177,611 |  |  |  | 181,755 |  |
| Utility Solutions Group |  |  | 123,556 |  |  |  | 115,668 |  |
| Totals |  | $ | 537,291 |  |  |  | 531,120 |  |
| EBIT |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 46,561 |  |  |  | 41,406 |  |
| Test |  |  | 9,540 |  |  |  | 21,083 |  |
| Utility Solutions Group |  |  | 29,637 |  |  |  | 26,624 |  |
| Corporate |  |  | (23,432 | ) |  |  | (25,339 | ) |
| Consolidated EBIT |  |  | 62,306 |  |  |  | 63,774 |  |
| Less: Interest expense |  |  | (785 | ) |  |  | (1,567 | ) |
| Less: Income tax expense |  |  | (19,785 | ) |  |  | (19,594 | ) |
| Net earnings from |  |  |  |  |  |  |  |  |
| Continuing Operations |  | $ | 41,736 |  |  |  | 42,613 |  |

[0000866706-15-000012:8k_2_02:90]
| Note: | The above table is presented on a continuing operations basis. |  |
| Note: | Depreciation and amortization expense was $18.6 million and $16.4 million for the years ended September 30, 2015 and 2014, respectively. |  |

[0000866706-15-000012:8k_2_02:91]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Condensed Consolidated Balance Sheets (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  | September 30, 2015 |  |  | September 30, 2014 |  |
| Assets |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 39,411 |  |  |  | 35,131 |  |
| Accounts receivable, net |  |  | 102,607 |  |  |  | 105,449 |  |
| Costs and estimated earnings on |  |  |  |  |  |  |  |  |
| long-term contracts |  |  | 28,387 |  |  |  | 27,798 |  |
| Inventories |  |  | 99,786 |  |  |  | 94,292 |  |
| Current portion of deferred tax assets |  |  | 15,558 |  |  |  | 19,946 |  |
| Other current assets |  |  | 12,502 |  |  |  | 13,337 |  |
| Total current assets |  |  | 298,251 |  |  |  | 295,953 |  |
| Property, plant and equipment, net |  |  | 77,358 |  |  |  | 76,465 |  |
| Intangible assets, net |  |  | 190,748 |  |  |  | 182,063 |  |
| Goodwill |  |  | 291,157 |  |  |  | 282,337 |  |
| Other assets |  |  | 6,694 |  |  |  | 9,088 |  |
|  |  | $ | 864,208 |  |  |  | 845,906 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt |  | $ | 20,000 |  |  |  | 20,000 |  |
| Accounts payable |  |  | 37,863 |  |  |  | 40,328 |  |
| Current portion of deferred revenue |  |  | 21,498 |  |  |  | 19,895 |  |
| Other current liabilities |  |  | 63,850 |  |  |  | 66,877 |  |
| Total current liabilities |  |  | 143,211 |  |  |  | 147,100 |  |
| Deferred tax liabilities |  |  | 74,469 |  |  |  | 77,440 |  |
| Other liabilities |  |  | 32,346 |  |  |  | 21,195 |  |
| Long-term debt |  |  | 30,000 |  |  |  | 20,000 |  |
| Shareholders' equity |  |  | 584,182 |  |  |  | 580,171 |  |
|  |  | $ | 864,208 |  |  |  | 845,906 |  |

[0000866706-15-000012:8k_2_02:92]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Consolidated Statements of Cash Flows (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  | Year Ended September 30, 2015 |  |
| Cash flows from operating activities: |  |  |  |
| Net earnings |  | $ | 42,512 |  |
| Adjustments to reconcile net earnings |  |  |  |  |
| to net cash provided by operating activities: |  |  |  |  |
| Net earnings from discontinued operations, net of tax |  |  | (776 | ) |
| Depreciation and amortization |  |  | 18,584 |  |
| Stock compensation expense |  |  | 4,779 |  |
| Changes in assets and liabilities |  |  | (745 | ) |
| Effect of deferred taxes |  |  | 1,417 |  |
| Other |  |  | (794 | ) |
| Net cash provided by operating activities - continuing operations |  |  | 64,977 |  |
| Net cash provided by operating activities - discontinued operations |  |  | 776 |  |
| Net cash provided by operating activities |  |  | 65,753 |  |
| Cash flows from investing activities: |  |  |  |  |
| Acquisition of business |  |  | (20,500 | ) |
| Capital expenditures |  |  | (12,444 | ) |
| Additions to capitalized software |  |  | (6,901 | ) |
| Net cash used by investing activities |  |  | (39,845 | ) |
| Cash flows from financing activities: |  |  |  |  |
| Proceeds from long-term debt |  |  | 106,000 |  |
| Principal payments on long-term debt |  |  | (96,000 | ) |
| Dividends paid |  |  | (8,369 | ) |
| Purchases of common stock into treasury |  |  | (18,248 | ) |
| Other |  |  | (24 | ) |
| Net cash used by financing activities |  |  | (16,641 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (4,987 | ) |
| Net increase in cash and cash equivalents |  |  | 4,280 |  |
| Cash and cash equivalents, beginning of period |  |  | 35,131 |  |
| Cash and cash equivalents, end of period |  | $ | 39,411 |  |

[0000866706-15-000012:8k_2_02:93]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Other Selected Financial Data (Unaudited) |  |
| (Dollars in thousands) |  |
| Backlog And Entered Orders - Q4 FY 2015 |  | USG |  |  | Test |  |  | Filtration |  |  | Total |  |
| Beginning Backlog - 7/1/15 |  | $ | 29,281 |  |  |  | 112,640 |  |  |  | 192,535 |  |  |  | 334,456 |  |
| Entered Orders |  |  | 37,658 |  |  |  | 35,650 |  |  |  | 73,358 |  |  |  | 146,666 |  |
| Sales |  |  | (30,667 | ) |  |  | (53,161 | ) |  |  | (69,784 | ) |  |  | (153,612 | ) |
| Ending Backlog - 9/30/15 |  | $ | 36,272 |  |  |  | 95,129 |  |  |  | 196,109 |  |  |  | 327,510 |  |
| Backlog And Entered Orders - FY 2015 |  | USG |  |  | Test |  |  | Filtration |  |  | Total |  |
| Beginning Backlog - 10/1/14 |  | $ | 33,093 |  |  |  | 90,739 |  |  |  | 179,063 |  |  |  | 302,895 |  |
| Entered Orders |  |  | 126,735 |  |  |  | 182,001 |  |  |  | 253,170 |  |  |  | 561,906 |  |
| Sales |  |  | (123,556 | ) |  |  | (177,611 | ) |  |  | (236,124 | ) |  |  | (537,291 | ) |
| Ending Backlog - 9/30/15 |  | $ | 36,272 |  |  |  | 95,129 |  |  |  | 196,109 |  |  |  | 327,510 |  |

## item 5.02 — body, verbatim

[0000866706-15-000012:8k_body:1]
Item 5.02                      Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers

[0000866706-15-000012:8k_body:2]
Fiscal 2016 Executive Officer Base Salaries and Cash Incentive Compensation

[0000866706-15-000012:8k_body:3]
On November 11, 2015, the Human Resources and Compensation Committee (the “Committee”) of the Company’s Board of Directors approved the fiscal 2016 base salaries and target cash incentive compensation opportunities for its executive officers:

[0000866706-15-000012:8k_body:4]
Officer

[0000866706-15-000012:8k_body:5]
Fiscal 2016

[0000866706-15-000012:8k_body:6]
Base Salary

[0000866706-15-000012:8k_body:7]
Fiscal 2016 Target Cash Incentive Compensation

[0000866706-15-000012:8k_body:8]
Victor L. Richey

[0000866706-15-000012:8k_body:9]
$824,500

[0000866706-15-000012:8k_body:10]
$605,000

[0000866706-15-000012:8k_body:11]
Gary E. Muenster

[0000866706-15-000012:8k_body:12]
$550,000

[0000866706-15-000012:8k_body:13]
$368,300

[0000866706-15-000012:8k_body:14]
Alyson S. Barclay

[0000866706-15-000012:8k_body:15]
$326,000

[0000866706-15-000012:8k_body:16]
$179,400

[0000866706-15-000012:8k_body:17]
The Company has two cash incentive compensation plans: (i) the Incentive Compensation Plan (the “ICP”) and (ii) the Performance Compensation Plan for Executive Officers (the “PCP”). For fiscal 2016 the Committee determined to allocate 50% of the executive officers’ cash incentive compensation opportunity to the ICP, and 50% to the PCP.  The Committee also approved the fiscal 2016 performance criteria for determining the percentage of such target incentive compensation opportunity that will be actually earned by the executive officers, depending on actual fiscal 2016 results compared to the criteria.

[0000866706-15-000012:8k_body:18]
Under the ICP, the Committee established Company earnings per share (“EPS”) as the single criterion for measuring performance, the same as for fiscal 2015.  The actual cash incentive compensation payable under the ICP for fiscal 2016 will range from 0.0 to 2.0 times the ICP share of the target opportunity depending on actual 2016 EPS, based on a matrix specifying particular EPS thresholds.

[0000866706-15-000012:8k_body:19]
Under the PCP, the Committee established the same three Company performance measures as for fiscal 2015:  Cash, weighted at 25% of the total target opportunity; Entered Orders, weighted at 15% of the total target opportunity; and Return on Invested Capital, weighted at 10% of the total target opportunity. The actual cash incentive compensation payable under the PCP for fiscal 2016 will range from 0.2 to 2.0 times the PCP share of the target opportunity depending on actual 2016 performance, based on a separate matrix for each of the three measures.

[0000866706-15-000012:8k_body:20]
Modifications to Long-Term Incentive Compensation Awards

[0000866706-15-000012:8k_body:21]
On November 11, 2015, the Committee approved amendments to the Company’s standard form of Award Agreement for long-term incentive compensation awards granted under the Company’s 2013 Incentive Compensation Plan (the “Incentive Plan”) to the Company’s executive officers and certain other management personnel, effective beginning with the awards granted on that date.  The amended form of Award Agreement is included herein as Exhibit 10.1.

[0000866706-15-000012:8k_body:22]
In addition to clarifying and updating certain language in the award forms, the amendments:

[0000866706-15-000012:8k_body:23]
·

[0000866706-15-000012:8k_body:24]
Eliminate any accelerated payout if the specified stock price targets are not achieved by the end of the fourth fiscal year of the Award, but retain the provision that the remaining portion of the Award will become distributable at the end of the five-year award period;

[0000866706-15-000012:8k_body:25]
·

[0000866706-15-000012:8k_body:26]
Protect the Award recipients in the event of a Change of Control (as defined in the Award) by permitting them to retain the benefits of the Award if, within 90 days prior to the Change of Control and at the request of the new controlling party, their employment is terminated or the Incentive Plan is modified to reduce or eliminate the benefits provided by the Award, and provided that the Change of Control actually occurs;

[0000866706-15-000012:8k_body:27]
·

[0000866706-15-000012:8k_body:28]
Modify the Change in Control provisions to provide that the value of the Award will be paid in cash rather than Company common stock; that the amount will be based on the average value of the Company’s stock over the ten trading date prior to the Change of Control; and that this amount will be paid within 30 days after the Change of  Control.

[0000866706-15-000012:8k_body:29]
·

[0000866706-15-000012:8k_body:30]
Reflect provisions already in the Incentive Plan permitting the Committee in its sole discretion to authorize a full or partial payment in the event of the Award holder’s death, disability, retirement or otherwise prior to completion of the Award term.

[0000866706-15-000012:8k_body:31]
The Committee also approved conforming amendments to the Company’s outstanding long-term incentive compensation awards granted in 2012, 2013 and 2014, the form of which is included herein as Exhibit 10.2.

[0000866706-15-000012:8k_body:32]
Amendment and Restatement of Severance Plan

[0000866706-15-000012:8k_body:33]
On November 11, 2015, the Committee amended and restated the existing Severance Plan for the Company’s executive officers (the “Severance Plan”), a copy of which is included herein as Exhibit 10.3.

[0000866706-15-000012:8k_body:34]
The amendments do not change the current “double trigger” requirement under the Severance Plan; i.e. for benefits to be payable under the Severance Plan, (i) a Change of Control must occur, as defined in the Severance Plan, and (ii) the executive’s employment must be terminated by the employer without “Cause” or by the executive for “Good Reason” (as those terms are defined in the Severance Plan) within 90 days before or up to two years after the Change of Control. However, in addition to clarifying and updating certain language in the Severance Plan, the amendments:

[0000866706-15-000012:8k_body:35]
·

[0000866706-15-000012:8k_body:36]
Modify the employment termination provisions by adding language that the Change of Control must actually occur before or within 90 days after the termination, and that the termination must be at the request of the new controlling party;

[0000866706-15-000012:8k_body:37]
·

[0000866706-15-000012:8k_body:38]
Clarify that the employment benefits payable to an executive under the Severance Plan include the value of the Company’s matches to the executive’s 401(k) Plan and Employee Stock Purchase plan accounts;

[0000866706-15-000012:8k_body:39]
·

[0000866706-15-000012:8k_body:40]
Include in the payments to which the executive is entitled during his or her employment following a Change of Control an annual amount equal to the value of the executive’s last Incentive Plan Awards granted prior to the Change of Control, and this amount may be provided in the acquiring party’s stock if it is publicly traded; and

[0000866706-15-000012:8k_body:41]
·

[0000866706-15-000012:8k_body:42]
Simplify the calculation of the executive’s performance bonus amount to be included in the annual benefits payable to the executive during employment after a Change of Control; and include this annual amount in calculating the lump-sum payment to be made to the executive in the event of termination after the Change of Control.
