# ESE MD&A — 0001104659-20-012461


## mdna

[0001104659-20-012461:mdna:1]
[same as prior period, unchanged from 0001144204-19-038765:mdna:1]

[0001104659-20-012461:mdna:2]
[same as prior period, unchanged from 0001144204-19-038765:mdna:2]

[0001104659-20-012461:mdna:3]
References to the first quarters of 2020 and 2019 represent the three-month periods ended December 31, 2019 and 2018, respectively.

[0001104659-20-012461:mdna:4]
[same as prior period, unchanged from 0001144204-19-038765:mdna:4]

[0001104659-20-012461:mdna:5]
In the first quarter of 2020, sales, net earnings and diluted earnings per share from continuing operations were $171.7 million, $10.8 million and $0.41 per share, respectively, compared to $163.4 million, $17.4 million and $0.66 per share, respectively, in the first quarter of 2019. The decrease in net earnings and diluted earnings per share in the first quarter of 2020 as compared to the first quarter of 2019 was mainly due the gain of approximately $8 million on the sale of the Doble Watertown property in the first quarter of 2019.

[0001104659-20-012461:mdna:6]
[same as prior period, unchanged from 0001144204-19-038765:mdna:6]

[0001104659-20-012461:mdna:7]
Net sales increased $8.4 million, or 5.1%, to $171.7 million in the first quarter of 2020 from $163.4 million in the first quarter of 2019. The increase in net sales in the first quarter of 2020 as compared to the first quarter of 2019 was due to an $11.3 million increase in the Aerospace & Defense segment, a $0.1 million increase in the Test segment, partially offset by a $3.0 million decrease in the USG segment.

[0001104659-20-012461:mdna:8]
-Aerospace & Defense (A&D)

[0001104659-20-012461:mdna:9]
In the first quarter of 2020, net sales of $77.5 million were $11.3 million, or 17.1%, higher than the $66.2 million in the first quarter of 2019. The sales increase in the first quarter of 2020 compared to the first quarter of 2019 was mainly due to the addition of $8.8 million in net sales from Globe, a $1.6 million increase in net sales at VACCO due to higher shipments of space products, a $1.4 million increase in net sales at PTI due to higher aerospace assembly shipments, an $0.8 million increase in net sales at Crissair due to higher aerospace shipments, partially offset by a $1.3 million decrease in net sales at Westland due to timing of revenue on government programs.

[0001104659-20-012461:mdna:10]
[same as prior period, unchanged from 0001144204-19-038765:mdna:10]

[0001104659-20-012461:mdna:11]
In the first quarter of 2020, net sales of $41.4 million were $0.1 million, or 0.2%, higher than the $41.3 million in the first quarter of 2019. The increase in the first quarter of 2020 compared to the first quarter of 2019 was primarily due to higher sales from the segment’s U.S. operations due to the timing of test and measurement chamber projects.

[0001104659-20-012461:mdna:12]
-USG

[0001104659-20-012461:mdna:13]
In the first quarter of 2020, net sales of $52.8 million were $3.0 million, or 5.4% lower than the $55.8 million in the first quarter of 2019. The decrease in the first quarter of 2020 compared to the first quarter of 2019 was mainly due to lower product sales at Doble.

[0001104659-20-012461:mdna:14]
[same as prior period, unchanged from 0001144204-19-038765:mdna:16]

[0001104659-20-012461:mdna:15]
Backlog from continuing operations was $500.3 million at December 31, 2019 compared with $451.6 million at September 30, 2019. The Company received new orders totaling $220.4 million in the first quarter of 2020 compared to $181.1 million in the first quarter of 2019. Of the new orders received in the first quarter of 2020, $129.0 million related to Aerospace & Defense products, $38.5 million related to Test products, and $52.9 million related to USG products. Of the new orders received in the first quarter of 2019, $83.7 million related to Aerospace & Defense products, $45.4 million related to Test products, and $52.0 million related to USG products.

[0001104659-20-012461:mdna:16]
[same as prior period, unchanged from 0001144204-19-038765:mdna:19]

[0001104659-20-012461:mdna:17]
Selling, general and administrative (SG&A) expenses from continuing operations for the first quarter of 2020 were $42.1 million (24.5% of net sales), compared with $38.5 million (23.6% of net sales) for the first quarter of 2019. The increase in SG&A in the first quarter of 2020 compared to the first quarter of 2019 was mainly due to higher spending on R&D / new product development, higher sales commissions and the addition of Globe.

[0001104659-20-012461:mdna:18]
[same as prior period, unchanged from 0001144204-19-038765:mdna:21]

[0001104659-20-012461:mdna:19]
Amortization of intangible assets from continuing operations was $5.8 million and $4.4 million for the first quarter of 2020 and 2019, respectively. Amortization expenses consist of amortization of acquired intangible assets from acquisitions and other identifiable intangible assets (primarily software). The increase in amortization expense in the first quarter of 2020 compared to the first quarter of 2019 was mainly due to an increase in amortization of intangible assets related to the Globe acquisition and an increase in amortization of capitalized software at Doble.

[0001104659-20-012461:mdna:20]
OTHER (INCOME) EXPENSES, NET

[0001104659-20-012461:mdna:21]
Other expenses, net, was $0.3 million in the first quarter of 2020 compared to other income, net, of $7.4 million in the first quarter of 2019. There were no individually significant items in other expenses (income), net, in the first quarter of 2020. The principal component in other income, net, in the first quarter of 2019 was a gain of approximately $8 million on the sale of the Doble Watertown, Massachusetts building and land.

[0001104659-20-012461:mdna:22]
[same as prior period, unchanged from 0001144204-19-038765:mdna:27]

[0001104659-20-012461:mdna:23]
The Company evaluates the performance of its operating segments based on EBIT, and provides EBIT on a consolidated basis, which is a non-GAAP financial measure. Please refer to the discussion of non-GAAP financial measures in Note 8 to the Consolidated Financial Statements, above. EBIT was $16.8 million (9.8% of net sales) for the first quarter of 2020 compared to $25.4 million (15.5% of net sales) for the first quarter of 2019.

[0001104659-20-012461:mdna:24]
The following table presents a reconciliation of EBIT to net earnings from continuing operations.

[0001104659-20-012461:mdna:25]
| ​ | ​ | Three Months Ended |
| ​ | ​ | December 31, |
| (In thousands) |  | 2019 |  | 2018 |
| Consolidated EBIT | ​ | $ | 16,791 | ​ | ​ | 25,350 |
| Less: Interest expense, net | ​ |  | (2,421) |  | ​ | (1,855) |
| Less: Income tax expense | ​ |  | (3,606) |  |  | (6,145) |
| Net earnings from continuing operations | ​ | $ | 10,764 |  | ​ | 17,350 |

[0001104659-20-012461:mdna:26]
-Aerospace & Defense

[0001104659-20-012461:mdna:27]
EBIT in the first quarter of 2020 was $12.5 million (16.1% of net sales) compared to $10.6 million (16.0% of net sales) in the first quarter of 2019. The increase in EBIT in the first quarter of 2020 compared to the first quarter of 2019 was mainly due to the contribution from Globe and an increase at PTI and Crissair due to higher sales volumes partially offset by a decrease in EBIT at VACCO and Westland due to change in product mix and the lower sales volumes at Westland mentioned above.

[0001104659-20-012461:mdna:28]
[same as prior period, unchanged from 0001144204-19-038765:mdna:33]

[0001104659-20-012461:mdna:29]
EBIT in the first quarter of 2020 was $4.7 million (11.3% of net sales) compared to $3.3 million (8.0% of net sales) in the first quarter of 2019. The increase in EBIT in the first quarter of 2020 compared to the first quarter of 2019 was primarily due to product mix and higher margins on projects mainly from the segment’s U.S. operations.

[0001104659-20-012461:mdna:30]
-USG

[0001104659-20-012461:mdna:31]
EBIT in the first quarter of 2020 was $9.3 million (17.6% of net sales) compared to $21.5 million (38.6% of net sales) in the first quarter of 2019. The decrease in EBIT in the first quarter of 2020 compared to the first quarter of 2019 was mainly due to the gain on sale of the Doble Watertown facility of approximately $8 million in the first quarter of 2019 as well as a decrease in EBIT from Doble due to lower sales volumes in the first quarter of 2020. In addition, EBIT in the first quarter of 2020 was negatively impacted by approximately $0.6 million of facility move costs at Doble.

[0001104659-20-012461:mdna:32]
[same as prior period, unchanged from 0001144204-19-038765:mdna:40]

[0001104659-20-012461:mdna:33]
Corporate costs included in EBIT were $9.7 million and $10.1 million in the first quarter of 2020 and 2019, respectively. The decrease in Corporate costs in the first quarter of 2020 compared to the first quarter of 2019 was mainly due to losses on derivative instruments recorded in the first quarter of 2019.

[0001104659-20-012461:mdna:34]
[same as prior period, unchanged from 0001144204-19-038765:mdna:42]

[0001104659-20-012461:mdna:35]
Interest expense was $2.4 million and $1.9 million in the first quarter of 2020 and 2019, respectively. The increase in interest expense in the first quarter of 2020 as compared to the first quarter of 2019 was mainly due to higher average outstanding borrowings ($279 million compared to $212 million) at relatively consistent average interest rates of 3.2%.

[0001104659-20-012461:mdna:36]
[same as prior period, unchanged from 0001144204-19-038765:mdna:44]

[0001104659-20-012461:mdna:37]
The first quarter 2020 effective income tax rate from continuing operations was 25.1% compared to 26.2% in the first quarter of 2019. The income tax expense in the first quarter of 2019 was unfavorably impacted by return to provision true-ups increasing the first quarter 2019 effective tax rate by 1.1%.

[0001104659-20-012461:mdna:38]
[same as prior period, unchanged from 0001144204-19-038765:mdna:50]

[0001104659-20-012461:mdna:39]
The Company’s overall financial position and liquidity remains strong. Working capital from continuing operations (current assets less current liabilities) increased to $246.3 million at December 31, 2019 from $229.8 million at September 30, 2019. Inventories increased by $9.0 million during this period mainly due to a $6.4 million increase within the Aerospace & Defense segment resulting primarily from the timing of receipt of raw materials to meet increased sales volumes. Accrued other expenses increased $32.8 million mainly due to a $26 million increase in the current income taxes payable related to the gain on the sale of the Technical Packaging business.

[0001104659-20-012461:mdna:40]
Net cash provided by operating activities from continuing operations was $3.3 million and $4.5 million in the first quarters of 2020 and 2019, respectively. The decrease in net cash provided by operating activities from continuing operations in the first quarter of 2020 as compared to the first quarter of 2019 was driven by higher working capital requirements.

[0001104659-20-012461:mdna:41]
Capital expenditures from continuing operations were $12.6 million and $4.8 million in the first quarters of 2020 and 2019, respectively. The increase in the first quarter of 2020 was mainly due to the building improvement additions at the new Doble headquarters facility of approximately $6 million. In addition, the Company incurred expenditures for capitalized software of approximately $2.0 million in both of the first quarters of 2020 and 2019, respectively.

[0001104659-20-012461:mdna:42]
Credit Facility

[0001104659-20-012461:mdna:43]
At December 31, 2019, the Company had approximately $341 million available to borrow under its bank credit facility, a $250 million increase option subject to lender approval, and $96.7 million cash on hand. At December 31, 2019, the Company had $150 million of outstanding borrowings under the credit facility in addition to outstanding letters of credit of $8.5 million. Cash flow from operations and borrowings under the Company’s credit facility are expected to meet the Company’s capital requirements and operational needs for the foreseeable future. The Company’s ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.

[0001104659-20-012461:mdna:44]
[same as prior period, unchanged from 0001144204-19-038765:mdna:64]

[0001104659-20-012461:mdna:45]
A dividend of $0.08 per share, totaling $2.1 million, was paid on October 17, 2019 to stockholders of record as of October 3, 2019. Subsequent to December 31, 2019, a quarterly dividend of $0.08 per share, totaling $2.1 million, was paid on January 17, 2020 to stockholders of record as of January 2, 2020.

[0001104659-20-012461:mdna:46]
[same as prior period, unchanged from 0001144204-19-038765:mdna:66]

[0001104659-20-012461:mdna:47]
Management’s current expectations for 2020 remain consistent with the details outlined in the Business Outlook presented in the November 19, 2019 press release. Management expects 2020 Adjusted EPS to be in the range of $3.20 to $3.30 per share. Management expects the 2020 second quarter Adjusted EPS to be in the range of $0.70 to $0.75.

[0001104659-20-012461:mdna:48]
[same as prior period, unchanged from 0001144204-19-038765:mdna:68]

[0001104659-20-012461:mdna:49]
Management has evaluated the accounting policies used in the preparation of the Company’s financial statements and related notes and believes those policies to be reasonable and appropriate. Certain of these accounting policies require the application of significant judgment by Management in selecting appropriate assumptions for calculating financial estimates. By their nature, these judgments are subject to an inherent degree of uncertainty. These judgments are based on historical experience, trends in the industry, information provided by customers and information available from other outside sources, as appropriate. The most significant areas involving Management judgments and estimates may be found in the Critical Accounting Policies section of Management’s Discussion and Analysis and in Note 1 to the Consolidated Financial Statements contained in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2019.

[0001104659-20-012461:mdna:50]
[same as prior period, unchanged from 0001144204-19-038765:mdna:71]

[0001104659-20-012461:mdna:51]
Contingencies

[0001104659-20-012461:mdna:52]
As a normal incident of the business in which the Company is engaged, various claims, charges and litigation are asserted or commenced against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. In the opinion of Management, the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company, are adequately reserved, are covered by insurance, or would not have a material adverse effect on the Company’s results from operations, capital expenditures, or competitive position.

[0001104659-20-012461:mdna:53]
[same as prior period, unchanged from 0001144204-19-038765:mdna:74]

[0001104659-20-012461:mdna:54]
Investors are cautioned that such statements are only predictions and speak only as of the date of this Form 10-Q, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment, including but not limited to those described in Item 1A, “Risk Factors,” of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2019, and the following: the impacts of natural disasters on the Company’s operations and those of the Company’s customers and suppliers; the timing and content of future contract awards or customer orders; the appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer contracts or orders; financial exposure in connection with Company guarantees of certain Aclara contracts; weakening of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties; the availability of selected acquisitions; delivery delays or defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability of certain raw materials; labor disputes; changes in U.S. tax laws and regulations; other changes in laws and regulations including but not limited to changes in accounting standards and foreign taxation; changes in interest rates; costs relating to environmental matters arising from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the integration of recently acquired businesses.
