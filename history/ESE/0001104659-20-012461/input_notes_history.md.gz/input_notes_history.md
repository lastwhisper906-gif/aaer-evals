# ESE note change history — 0001144204-19-038765 → 0001104659-20-012461


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-02-07):
[0001104659-20-012461:note_history:1]
The accompanying consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP). For further information, refer to the consolidated financial statements and related notes included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2019. Certain 2019 amounts have been reclassified to conform with the 2020 presentation.
  (was, 2019-08-09, similarity 0.9472):
[0001144204-19-038765:note_history:1]
The accompanying consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP). For further information, refer to the consolidated financial statements and related notes included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2018.

- changed (2020-02-07):
[0001104659-20-012461:note_history:2]
The Company’s results for the three-month period ended December 31, 2019 are not necessarily indicative of the results for the entire 2020 fiscal year. References to the first quarters of 2020 and 2019 represent the fiscal quarters ended December 31, 2019 and 2018, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.
  (was, 2019-08-09, similarity 0.6146):
[0001144204-19-038765:note_history:2]
The Company’s results for the three and nine-month periods ended June 30, 2019 are not necessarily indicative of the results for the entire 2019 fiscal year. References to the third quarters of 2019 and 2018 represent the fiscal quarters ended June 30, 2019 and 2018, respectively.

- added (2020-02-07):
[0001104659-20-012461:note_history:3]
Beginning in the first quarter of 2020, Management has renamed the Filtration / Fluid Flow (Filtration) segment as Aerospace & Defense (A&D) to better reflect the composition of the segment’s products, end markets and customer characteristics. The A&D’s segment’s individual legal and operating entities, historical financial results, and management structure are unchanged from what was formerly presented as Filtration.

- removed (2020-02-07):
[0001144204-19-038765:note_history:4]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: no_current_note, score: 0.0

- removed (2020-02-07):
[0001144204-19-038765:note_history:5]
2.    SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES UPDATE

- removed (2020-02-07):
[0001144204-19-038765:note_history:6]
Our significant accounting policies are included in Note 1 of our Annual Report on Form 10-K for the year ended September 30, 2018. On October 1, 2018, we adopted ASU No. 2014-09, Revenue from Contracts with Customers (ASC 606). Significant changes to our policies resulting from the adoption are provided below. We adopted ASC 606 using the modified retrospective transition method applied to contracts that were not substantially complete at the end of fiscal year 2018. We recorded a $4.2 million adjustment to increase retained earnings to reflect the cumulative impact of adopting this standard at the beginning of fiscal year 2019, primarily related to certain long-term contracts our Filtration and Technical Packaging segments have that converted to the cost-to-cost method for revenue recognition. The comparative information has not been restated and is reported under the accounting standards in effect for those periods. A reconciliation of the financial statement line items impacted for the three and nine months ended June 30, 2019 under ASC 606 to the prior accounting standards is provided in Note 14.

- removed (2020-02-07):
[0001144204-19-038765:note_history:7]
Revenue Recognition

- removed (2020-02-07):
[0001144204-19-038765:note_history:8]
Revenue is recognized when control of the goods or services promised under the contract is transferred to the customer either at a point in time (e.g., upon delivery) or over time (e.g., as we perform under the contract). We account for a contract when it has approval and commitment from both parties, the rights and payment terms of the parties are identified, the contract has commercial substance and collectability of consideration is probable. Contracts are reviewed to determine whether there is one or multiple performance obligations. A performance obligation is a promise to transfer a distinct good or service to a customer and represents the unit of accounting for revenue recognition. For contracts with multiple performance obligations, the expected consideration, or the transaction price, is allocated to each performance obligation identified in the contract based on the relative standalone selling price of each performance obligation. Revenue is then recognized for the transaction price allocated to the performance obligation when control of the promised goods or services underlying the performance obligation is transferred.

- removed (2020-02-07):
[0001144204-19-038765:note_history:9]
Payment terms with customers vary by the type and location of the customer and the products or services offered. The Company does not adjust the promised amount of consideration for the effects of significant financing components based on the expectation that the period between when the Company transfers a promised good or service to a customer and when the customer pays for that good or service will be one year or less. Arrangements with customers that include payment terms extending beyond one year are not significant.

- removed (2020-02-07):
[0001144204-19-038765:note_history:10]
Filtration: Within the Filtration segment, approximately 48% of revenues (approximately 18% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial and military customers and have a single performance obligation as there is only one good promised or the promise to transfer the goods or services is not distinct or separately identifiable from other promises in the contract. The transaction price for these contracts reflects our estimate of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

- removed (2020-02-07):
[0001144204-19-038765:note_history:11]
Approximately 52% of the segment’s revenues (approximately 19% of consolidated revenues) are accounted for over time as the product does not have an alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin or the inventory is owned by the customer. The related contracts are primarily cost-plus or fixed price contracts related to the design, development and manufacture of complex fluid control products, quiet valves, manifolds, shock and vibration dampening, thermal insulation and systems primarily for the commercial aerospace and military (U.S. Government) markets. The contracts may contain multiple products, which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. Our contracts are frequently modified for changes in contract specifications and requirements. Most of our contract modifications are for products that are not distinct from the existing contract and are accounted for as part of that existing contract.

- removed (2020-02-07):
[0001144204-19-038765:note_history:12]
Contracts with the U.S. Government generally contain clauses that provide lien rights to work-in-process along with clauses that allow the customer to unilaterally terminate the contract for convenience, pay us for costs incurred plus a reasonable profit and take control of any work-in-process. Due to the continuous transfer of control to the U.S. Government, we recognize revenue over the time that we perform under the contract.

- removed (2020-02-07):
[0001144204-19-038765:note_history:13]
Selecting the method to measure progress towards completion for the commercial and military contracts requires judgment and is based on the nature of the products or service to be provided. We generally use the cost-to-cost method to measure progress for our Filtration segment contracts the rate at which costs are incurred to fulfill a contract best depicts the transfer of control to the customer. Under this measure, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and revenue is recorded proportionally as costs are incurred based on an estimated profit margin.

- removed (2020-02-07):
[0001144204-19-038765:note_history:14]
The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Certain of our long-term contracts contain incentive fees that can increase the transaction price. These variable amounts generally are awarded upon achievement of certain performance metrics, program milestones or cost targets and can be based upon customer discretion. We include estimated amounts in the transaction price to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimates of variable consideration and determination of whether to include estimated amounts in the transaction price are based largely on an assessment of our anticipated performance and all other information that is reasonably available to us.

- removed (2020-02-07):
[0001144204-19-038765:note_history:15]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to one or more years, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

- removed (2020-02-07):
[0001144204-19-038765:note_history:16]
Under the typical payment terms of our long term fixed price contracts, the customer pays us either performance-based or progress payments. Performance-based payments represent interim payments based on quantifiable measures of performance or on the achievement of specified events or milestones. Progress payments are interim payments of costs incurred as the work progresses. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred, which we present as contract assets and contract liabilities, respectively, in the Consolidated Balance Sheets. Amounts billed and due from our customers are classified in Accounts receivable, net. For short term fixed price and cost-type contracts, we are generally paid within a short period of time.

- removed (2020-02-07):
[0001144204-19-038765:note_history:17]
For contracts where revenue is recognized over time, we generally recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. Anticipated losses on contracts are recognized in full in the period in which the losses become probable and estimable.

- removed (2020-02-07):
[0001144204-19-038765:note_history:18]
Test: Within the Test segment, approximately 25% of revenues (approximately 6% of consolidated revenues) are recognized at a point in time when products such as, antennas and probes are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

- removed (2020-02-07):
[0001144204-19-038765:note_history:19]
Approximately 75% of the segment’s revenues (approximately 17% of consolidated revenues) are recorded over time as the product does not have an alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin. Products accounted for under this guidance include the construction and installation of test chambers to a buyer’s specifications that provide its customers with the ability to measure and contain magnetic, electromagnetic and acoustic energy. The goods and services related to each installed test chamber are not distinct due to the significant amount of integration provided and each installed chamber is accounted for as a single performance obligation. Selecting the method to measure progress towards completion for these contracts requires judgment and is based on the nature of the products and service to be provided. We use milestones to measure progress for our Test segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. For arrangements that are accounted for under this guidance, the Company estimates profit as the difference between total revenue and total estimated cost of a contract and recognizes these revenues and costs based primarily on contract milestones. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable.

- removed (2020-02-07):
[0001144204-19-038765:note_history:20]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to a year, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

- removed (2020-02-07):
[0001144204-19-038765:note_history:21]
Under the typical payment terms of our fixed price contracts, the customer pays us either performance-based or progress payments. Performance-based payments represent interim payments based on quantifiable measures of performance or on the achievement of specified events or milestones. Progress payments are interim payments of costs incurred as the work progresses. Because of the timing difference of revenue recognition and customer billing, these contracts result in revenue recognized in excess of billings and billings in excess of costs incurred, which we present as contract assets and contract liabilities, respectively, in the Consolidated Balance Sheets. Amounts billed and due from our customers are classified in Accounts receivable, net.

- removed (2020-02-07):
[0001144204-19-038765:note_history:22]
For contracts where revenue is recognized over time, we generally recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. Anticipated losses on contracts are recognized in full in the period in which the losses become probable and estimable.

- removed (2020-02-07):
[0001144204-19-038765:note_history:23]
USG: Within the USG segment, approximately 80% of revenues (approximately 24% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

- removed (2020-02-07):
[0001144204-19-038765:note_history:24]
Approximately 20% of the segment’s revenues (approximately 6% of consolidated revenues) are recognized over time as services are performed. The services accounted for under this method include an obligation to provide testing services using hardware and embedded software, software maintenance, training, lab testing, and consulting services. The related contracts contain a bundle of goods and services that are integrated in the context of the contract. Therefore, the goods and services are not distinct and the Company has a single performance obligation. Selecting the method to measure progress towards completion for these contracts requires judgment and is based on the nature of the products and service to be provided. We will recognize revenue as a series of distinct services based on each day of providing services (straight-line over the contract term) for our USG segment contracts. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Under the typical payment terms of our service contracts, the customer pays us in advance of when services are performed. Because of the timing difference of revenue recognition and customer payment, which is typically received upon commencement of the contract, these contracts result in deferred revenue, which we present as contract liabilities, in the Consolidated Balance Sheets.

- removed (2020-02-07):
[0001144204-19-038765:note_history:25]
Included in this category, approximately 8% of the segment’s revenues (approximately 2% of consolidated revenues) are recognized based on the terms of the software contract. For contracts that transfer a software license to the customer, revenue will be recognized at a point in time. These type of software contracts represent a right to use the software, or a functional license, in which revenue should be recognized upon transfer of the license. For contracts in software as a service (SaaS) arrangements, revenue will be recognized over time. The customer receives and consumes the benefits of the SaaS arrangement through access to the system which is for a stated period. We will recognize revenue based on each day of providing access (straight-line over the contract term). The transaction price for our contracts represent our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Under the typical payment terms of our software contracts, the customer pays us in advance of when services are performed. Because of the timing difference of revenue recognition and customer payment, these contracts result in deferred revenue, which we present as contract liabilities, in the Consolidated Balance Sheets.

- removed (2020-02-07):
[0001144204-19-038765:note_history:26]
Technical Packaging: Within the Technical Packaging segment, 100% of the revenues (approximately 10% of consolidated revenues) are recognized over time as the product does not have an alternative use and the Company has an enforceable right to payment. Selecting the method to measure progress towards completion for the contracts requires judgment and is based on the nature of the products to be provided. We use the cost-to-cost method to measure progress for our Technical Packaging segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. Under this measure, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and revenue is recorded proportionally as costs are incurred. The transaction price for our contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant.

- removed (2020-02-07):
[0001144204-19-038765:note_history:27]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of weeks, minimizing the amount of judgment in developing the cost estimate. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

- removed (2020-02-07):
[0001144204-19-038765:note_history:28]
Under the typical payment terms of our contracts, the customer is billed upon shipment of product. Amounts billed and due from our customers are classified in Accounts receivable, net. Because of the timing difference of revenue recognition and customer billing, these contracts result in revenue recognized in excess of billings, which we present as contract assets in the Consolidated Balance Sheets.

- removed (2020-02-07):
[0001144204-19-038765:note_history:29]
For contracts where revenue is recognized over time, we generally recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. Anticipated losses on contracts are recognized in full in the period in which the losses become probable and estimable.

- removed (2020-02-07):
[0001144204-19-038765:note_history:30]
Contract Assets and Liabilities

- removed (2020-02-07):
[0001144204-19-038765:note_history:31]
Contract assets arise from contracts when revenue is recognized over time and the amount of revenue recognized, including our estimate of variable consideration that has been included in the transaction price, exceeds the amount billed to the customer. These amounts are included in contract assets until the right to payment is no longer conditional on events other than the passage of time. These contract assets are reclassified to receivables when the right to consideration becomes unconditional. Contract liabilities include deposits, deferred revenue, upfront payments and billings in excess of revenue recognized. Liabilities for customer rebates and discounts are included in other current liabilities in the accompanying balance sheet.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2020-02-07):
[0001104659-20-012461:note_history:32]
| ​ | ​ | December 31, | ​ | September 30, |
| (In thousands) |  | 2019 |  | 2019 |
| Total borrowings | ​ | $ | 150,000 |  | ​ | 285,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 130,000 |  | ​ | 265,000 |

- changed (2020-02-07):
[0001104659-20-012461:note_history:33]
On September 27, 2019, the Company entered into a new five-year credit facility (“the Credit Facility”), modifying its previous credit facility which would have matured December 21, 2020. The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024.
  (was, 2019-08-09, similarity 0.8105):
[0001144204-19-038765:note_history:33]
The Company’s existing credit facility (“the Credit Facility”) matures December 21, 2020. The Credit Facility includes a $450 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of nine banks led by JPMorgan Chase Bank, N.A., as Administrative Agent.

- added (2020-02-07):
[0001104659-20-012461:note_history:34]
At December 31, 2019, the Company had approximately $341 million available to borrow under the Credit Facility, plus the $250 million increase option, in addition to $96.7 million cash on hand. The Company classified $20.0 million as the current portion of long-term debt as of December 31, 2019, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $8.5 million at December 31, 2019.

- added (2020-02-07):
[0001104659-20-012461:note_history:35]
Interest on borrowings under the Credit Facility is calculated at a spread over either the London Interbank Offered Rate (LIBOR ), the New York Federal Reserve Bank Rate or the prime rate, depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The Credit Facility is secured by the unlimited guaranty of the Company’s direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of its direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 3.18% and 3.25% for the three-month periods ending December 31, 2019 and 2018, respectively. As of December 31, 2019, the Company was in compliance with all covenants.

- removed (2020-02-07):
[0001144204-19-038765:note_history:36]
| ​ | ​ | June 30, | ​ | September 30, |
| (In thousands) |  | 2019 |  | 2018 |
| Total borrowings | ​ | $ | 217,921 |  | 220,000 |
| Short-term borrowings and current portion of long-term debt | ​ |  | (20,921) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 197,000 |  | 200,000 |

- removed (2020-02-07):
[0001144204-19-038765:note_history:37]
At June 30, 2019, the Company had approximately $225 million available to borrow under the Credit Facility, and a $250 million increase option, in addition to $39.0 million cash on hand. At June 30, 2019, the Company had $217.0 million of outstanding borrowings under the Credit Facility, and $0.9 million of short-term borrowing in addition to outstanding letters of credit of $7.2 million. The Company classified $20.9 million as the current portion of long-term debt as of June 30, 2019, as the Company intends to repay this amount within the next twelve month period; however, the Company has no contractual obligation to repay such amount during the next twelve month period.

- removed (2020-02-07):
[0001144204-19-038765:note_history:38]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from 12.5 to 27.5 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a 65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 3.21% and 3.22% for the three and nine-month periods ending June 30, 2019, respectively, and 3.17% and 2.97% for the corresponding periods of 2018. At June 30, 2019, the Company was in compliance with all debt covenants.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2020-02-07):
[0001104659-20-012461:note_history:39]
| ​ | ​ | December 31, | ​ | September 30, |
| (In thousands) |  | 2019 |  | 2019 |
| Total borrowings | ​ | $ | 150,000 |  | ​ | 285,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 130,000 |  | ​ | 265,000 |

- removed (2020-02-07):
[0001144204-19-038765:note_history:40]
The Company’s debt is summarized as follows:

- removed (2020-02-07):
[0001144204-19-038765:note_history:41]
| ​ | ​ | June 30, | ​ | September 30, |
| (In thousands) |  | 2019 |  | 2018 |
| Total borrowings | ​ | $ | 217,921 |  | 220,000 |
| Short-term borrowings and current portion of long-term debt | ​ |  | (20,921) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 197,000 |  | 200,000 |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-02-07):
[0001104659-20-012461:note_history:42]
| ​ |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | Test | ​ | USG | ​ | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 41,907 | ​ | $ | 35,249 | ​ | $ | 52,235 | ​ | $ | 129,391 |
| U.S. Government | ​ |  | 35,604 | ​ |  | 6,134 | ​ |  | 599 | ​ |  | 42,337 |
| Total revenues | ​ | $ | 77,511 | ​ | $ | 41,383 | ​ | $ | 52,834 | ​ | $ | 171,728 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 64,706 | ​ | $ | 24,837 | ​ | $ | 34,651 | ​ | $ | 124,194 |
| International | ​ |  | 12,805 | ​ |  | 16,546 | ​ |  | 18,183 | ​ |  | 47,534 |
| Total revenues | ​ | $ | 77,511 | ​ | $ | 41,383 | ​ | $ | 52,834 | ​ | $ | 171,728 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 35,761 | ​ | $ | 7,611 | ​ | $ | 40,315 | ​ | $ | 83,687 |
| Over time | ​ |  | 41,750 | ​ |  | 33,772 | ​ |  | 12,519 | ​ |  | 88,041 |
| Total revenues | ​ | $ | 77,511 | ​ | $ | 41,383 | ​ | $ | 52,834 | ​ | $ | 171,728 |
  (was, 2019-08-09, similarity 0.787):
[0001144204-19-038765:note_history:42]
| Three Months Ended June 30, 2019 |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | Technical |  | ​ | ​ |
| (In thousands) | ​ | Filtration | ​ | Test | ​ | USG | ​ | Packaging | ​ | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 47,482 | ​ | $ | 37,980 | ​ | $ | 52,065 | ​ | $ | 21,507 | ​ | $ | 159,034 |
| Government | ​ |  | 35,585 | ​ |  | 4,318 | ​ |  | 829 | ​ |  | — | ​ |  | 40,732 |
| Total revenues | ​ | $ | 83,067 | ​ | $ | 42,298 | ​ | $ | 52,894 | ​ | $ | 21,507 | ​ | $ | 199,766 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 69,872 | ​ | $ | 26,923 | ​ | $ | 38,414 | ​ | $ | 11,559 | ​ | $ | 146,268 |
| International | ​ |  | 13,195 | ​ |  | 15,375 | ​ |  | 14,480 | ​ |  | 9,948 | ​ |  | 53,498 |
| Total revenues | ​ | $ | 83,067 | ​ | $ | 42,298 | ​ | $ | 52,894 | ​ | $ | 21,507 | ​ | $ | 199,766 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 41,633 | ​ | $ | 6,485 | ​ | $ | 40,968 | ​ | $ | — | ​ | $ | 89,092 |
| Over time | ​ |  | 41,434 | ​ |  | 35,813 | ​ |  | 11,926 | ​ |  | 21,507 | ​ |  | 110,674 |
| Total revenues | ​ | $ | 83,067 | ​ | $ | 42,298 | ​ | $ | 52,894 | ​ | $ | 21,507 | ​ | $ | 199,766 |

- removed (2020-02-07):
[0001144204-19-038765:note_history:43]
| Nine Months Ended June 30, 2019 |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | Technical |  | ​ | ​ |
| (In thousands) | ​ | Filtration | ​ | Test | ​ | USG | ​ | Packaging | ​ | Total |
| Customer type: |  | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |  |
| Commercial | ​ | $ | 131,112 | ​ | $ | 111,577 | ​ | $ | 154,240 | ​ | $ | 63,251 | ​ | $ | 460,180 |
| Government | ​ |  | 97,657 | ​ |  | 14,882 | ​ |  | 3,399 | ​ |  | 194 | ​ |  | 116,132 |
| Total revenues | ​ | $ | 228,769 | ​ | $ | 126,459 | ​ | $ | 157,639 | ​ | $ | 63,445 | ​ | $ | 576,312 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 190,701 | ​ | $ | 82,072 | ​ | $ | 112,289 | ​ | $ | 32,865 | ​ | $ | 417,927 |
| International | ​ |  | 38,068 | ​ |  | 44,387 | ​ |  | 45,350 | ​ |  | 30,580 | ​ |  | 158,385 |

- removed (2020-02-07):
[0001144204-19-038765:note_history:44]
| Total revenues | ​ | $ | 228,769 | ​ | $ | 126,459 | ​ | $ | 157,639 | ​ | $ | 63,445 | ​ | $ | 576,312 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 115,852 | ​ | $ | 29,092 | ​ | $ | 122,075 | ​ | $ | - | ​ | $ | 267,021 |
| Over time | ​ |  | 112,917 | ​ |  | 97,367 | ​ |  | 35,564 | ​ |  | 63,445 | ​ |  | 309,291 |
| Total revenues | ​ | $ | 228,769 | ​ | $ | 126,459 | ​ | $ | 157,639 | ​ | $ | 63,445 | ​ | $ | 576,312 |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2020-02-07):
[0001144204-19-038765:note_history:45]
Revenue Recognition

- removed (2020-02-07):
[0001144204-19-038765:note_history:46]
Revenue is recognized when control of the goods or services promised under the contract is transferred to the customer either at a point in time (e.g., upon delivery) or over time (e.g., as we perform under the contract). We account for a contract when it has approval and commitment from both parties, the rights and payment terms of the parties are identified, the contract has commercial substance and collectability of consideration is probable. Contracts are reviewed to determine whether there is one or multiple performance obligations. A performance obligation is a promise to transfer a distinct good or service to a customer and represents the unit of accounting for revenue recognition. For contracts with multiple performance obligations, the expected consideration, or the transaction price, is allocated to each performance obligation identified in the contract based on the relative standalone selling price of each performance obligation. Revenue is then recognized for the transaction price allocated to the performance obligation when control of the promised goods or services underlying the performance obligation is transferred.

- removed (2020-02-07):
[0001144204-19-038765:note_history:47]
Payment terms with customers vary by the type and location of the customer and the products or services offered. The Company does not adjust the promised amount of consideration for the effects of significant financing components based on the expectation that the period between when the Company transfers a promised good or service to a customer and when the customer pays for that good or service will be one year or less. Arrangements with customers that include payment terms extending beyond one year are not significant.

- removed (2020-02-07):
[0001144204-19-038765:note_history:48]
Filtration: Within the Filtration segment, approximately 48% of revenues (approximately 18% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial and military customers and have a single performance obligation as there is only one good promised or the promise to transfer the goods or services is not distinct or separately identifiable from other promises in the contract. The transaction price for these contracts reflects our estimate of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

- removed (2020-02-07):
[0001144204-19-038765:note_history:49]
Approximately 52% of the segment’s revenues (approximately 19% of consolidated revenues) are accounted for over time as the product does not have an alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin or the inventory is owned by the customer. The related contracts are primarily cost-plus or fixed price contracts related to the design, development and manufacture of complex fluid control products, quiet valves, manifolds, shock and vibration dampening, thermal insulation and systems primarily for the commercial aerospace and military (U.S. Government) markets. The contracts may contain multiple products, which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. Our contracts are frequently modified for changes in contract specifications and requirements. Most of our contract modifications are for products that are not distinct from the existing contract and are accounted for as part of that existing contract.

- removed (2020-02-07):
[0001144204-19-038765:note_history:50]
Contracts with the U.S. Government generally contain clauses that provide lien rights to work-in-process along with clauses that allow the customer to unilaterally terminate the contract for convenience, pay us for costs incurred plus a reasonable profit and take control of any work-in-process. Due to the continuous transfer of control to the U.S. Government, we recognize revenue over the time that we perform under the contract.

- removed (2020-02-07):
[0001144204-19-038765:note_history:51]
Selecting the method to measure progress towards completion for the commercial and military contracts requires judgment and is based on the nature of the products or service to be provided. We generally use the cost-to-cost method to measure progress for our Filtration segment contracts the rate at which costs are incurred to fulfill a contract best depicts the transfer of control to the customer. Under this measure, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and revenue is recorded proportionally as costs are incurred based on an estimated profit margin.

- removed (2020-02-07):
[0001144204-19-038765:note_history:52]
The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Certain of our long-term contracts contain incentive fees that can increase the transaction price. These variable amounts generally are awarded upon achievement of certain performance metrics, program milestones or cost targets and can be based upon customer discretion. We include estimated amounts in the transaction price to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimates of variable consideration and determination of whether to include estimated amounts in the transaction price are based largely on an assessment of our anticipated performance and all other information that is reasonably available to us.

- removed (2020-02-07):
[0001144204-19-038765:note_history:53]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to one or more years, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

- removed (2020-02-07):
[0001144204-19-038765:note_history:54]
Under the typical payment terms of our long term fixed price contracts, the customer pays us either performance-based or progress payments. Performance-based payments represent interim payments based on quantifiable measures of performance or on the achievement of specified events or milestones. Progress payments are interim payments of costs incurred as the work progresses. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred, which we present as contract assets and contract liabilities, respectively, in the Consolidated Balance Sheets. Amounts billed and due from our customers are classified in Accounts receivable, net. For short term fixed price and cost-type contracts, we are generally paid within a short period of time.

- removed (2020-02-07):
[0001144204-19-038765:note_history:55]
For contracts where revenue is recognized over time, we generally recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. Anticipated losses on contracts are recognized in full in the period in which the losses become probable and estimable.

- removed (2020-02-07):
[0001144204-19-038765:note_history:56]
Test: Within the Test segment, approximately 25% of revenues (approximately 6% of consolidated revenues) are recognized at a point in time when products such as, antennas and probes are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

- removed (2020-02-07):
[0001144204-19-038765:note_history:57]
Approximately 75% of the segment’s revenues (approximately 17% of consolidated revenues) are recorded over time as the product does not have an alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin. Products accounted for under this guidance include the construction and installation of test chambers to a buyer’s specifications that provide its customers with the ability to measure and contain magnetic, electromagnetic and acoustic energy. The goods and services related to each installed test chamber are not distinct due to the significant amount of integration provided and each installed chamber is accounted for as a single performance obligation. Selecting the method to measure progress towards completion for these contracts requires judgment and is based on the nature of the products and service to be provided. We use milestones to measure progress for our Test segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. For arrangements that are accounted for under this guidance, the Company estimates profit as the difference between total revenue and total estimated cost of a contract and recognizes these revenues and costs based primarily on contract milestones. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable.

- removed (2020-02-07):
[0001144204-19-038765:note_history:58]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to a year, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

- removed (2020-02-07):
[0001144204-19-038765:note_history:59]
Under the typical payment terms of our fixed price contracts, the customer pays us either performance-based or progress payments. Performance-based payments represent interim payments based on quantifiable measures of performance or on the achievement of specified events or milestones. Progress payments are interim payments of costs incurred as the work progresses. Because of the timing difference of revenue recognition and customer billing, these contracts result in revenue recognized in excess of billings and billings in excess of costs incurred, which we present as contract assets and contract liabilities, respectively, in the Consolidated Balance Sheets. Amounts billed and due from our customers are classified in Accounts receivable, net.

- removed (2020-02-07):
[0001144204-19-038765:note_history:60]
For contracts where revenue is recognized over time, we generally recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. Anticipated losses on contracts are recognized in full in the period in which the losses become probable and estimable.

- removed (2020-02-07):
[0001144204-19-038765:note_history:61]
USG: Within the USG segment, approximately 80% of revenues (approximately 24% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

- removed (2020-02-07):
[0001144204-19-038765:note_history:62]
Approximately 20% of the segment’s revenues (approximately 6% of consolidated revenues) are recognized over time as services are performed. The services accounted for under this method include an obligation to provide testing services using hardware and embedded software, software maintenance, training, lab testing, and consulting services. The related contracts contain a bundle of goods and services that are integrated in the context of the contract. Therefore, the goods and services are not distinct and the Company has a single performance obligation. Selecting the method to measure progress towards completion for these contracts requires judgment and is based on the nature of the products and service to be provided. We will recognize revenue as a series of distinct services based on each day of providing services (straight-line over the contract term) for our USG segment contracts. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Under the typical payment terms of our service contracts, the customer pays us in advance of when services are performed. Because of the timing difference of revenue recognition and customer payment, which is typically received upon commencement of the contract, these contracts result in deferred revenue, which we present as contract liabilities, in the Consolidated Balance Sheets.

- removed (2020-02-07):
[0001144204-19-038765:note_history:63]
Included in this category, approximately 8% of the segment’s revenues (approximately 2% of consolidated revenues) are recognized based on the terms of the software contract. For contracts that transfer a software license to the customer, revenue will be recognized at a point in time. These type of software contracts represent a right to use the software, or a functional license, in which revenue should be recognized upon transfer of the license. For contracts in software as a service (SaaS) arrangements, revenue will be recognized over time. The customer receives and consumes the benefits of the SaaS arrangement through access to the system which is for a stated period. We will recognize revenue based on each day of providing access (straight-line over the contract term). The transaction price for our contracts represent our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Under the typical payment terms of our software contracts, the customer pays us in advance of when services are performed. Because of the timing difference of revenue recognition and customer payment, these contracts result in deferred revenue, which we present as contract liabilities, in the Consolidated Balance Sheets.

- removed (2020-02-07):
[0001144204-19-038765:note_history:64]
Technical Packaging: Within the Technical Packaging segment, 100% of the revenues (approximately 10% of consolidated revenues) are recognized over time as the product does not have an alternative use and the Company has an enforceable right to payment. Selecting the method to measure progress towards completion for the contracts requires judgment and is based on the nature of the products to be provided. We use the cost-to-cost method to measure progress for our Technical Packaging segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. Under this measure, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and revenue is recorded proportionally as costs are incurred. The transaction price for our contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant.

- removed (2020-02-07):
[0001144204-19-038765:note_history:65]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of weeks, minimizing the amount of judgment in developing the cost estimate. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

- removed (2020-02-07):
[0001144204-19-038765:note_history:66]
Under the typical payment terms of our contracts, the customer is billed upon shipment of product. Amounts billed and due from our customers are classified in Accounts receivable, net. Because of the timing difference of revenue recognition and customer billing, these contracts result in revenue recognized in excess of billings, which we present as contract assets in the Consolidated Balance Sheets.

- removed (2020-02-07):
[0001144204-19-038765:note_history:67]
For contracts where revenue is recognized over time, we generally recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. Anticipated losses on contracts are recognized in full in the period in which the losses become probable and estimable.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-02-07):
[0001104659-20-012461:note_history:68]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2019 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within each reportable segment on a continuing operations basis.
  (was, 2019-08-09, similarity 0.8647):
[0001144204-19-038765:note_history:68]
Our revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2019 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within our reportable segments.

- changed (2020-02-07):
[0001104659-20-012461:note_history:69]
| ​ |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | Test | ​ | USG | ​ | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 41,907 | ​ | $ | 35,249 | ​ | $ | 52,235 | ​ | $ | 129,391 |
| U.S. Government | ​ |  | 35,604 | ​ |  | 6,134 | ​ |  | 599 | ​ |  | 42,337 |
| Total revenues | ​ | $ | 77,511 | ​ | $ | 41,383 | ​ | $ | 52,834 | ​ | $ | 171,728 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 64,706 | ​ | $ | 24,837 | ​ | $ | 34,651 | ​ | $ | 124,194 |
| International | ​ |  | 12,805 | ​ |  | 16,546 | ​ |  | 18,183 | ​ |  | 47,534 |
| Total revenues | ​ | $ | 77,511 | ​ | $ | 41,383 | ​ | $ | 52,834 | ​ | $ | 171,728 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 35,761 | ​ | $ | 7,611 | ​ | $ | 40,315 | ​ | $ | 83,687 |
| Over time | ​ |  | 41,750 | ​ |  | 33,772 | ​ |  | 12,519 | ​ |  | 88,041 |
| Total revenues | ​ | $ | 77,511 | ​ | $ | 41,383 | ​ | $ | 52,834 | ​ | $ | 171,728 |
  (was, 2019-08-09, similarity 0.787):
[0001144204-19-038765:note_history:69]
| Three Months Ended June 30, 2019 |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | Technical |  | ​ | ​ |
| (In thousands) | ​ | Filtration | ​ | Test | ​ | USG | ​ | Packaging | ​ | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 47,482 | ​ | $ | 37,980 | ​ | $ | 52,065 | ​ | $ | 21,507 | ​ | $ | 159,034 |
| Government | ​ |  | 35,585 | ​ |  | 4,318 | ​ |  | 829 | ​ |  | — | ​ |  | 40,732 |
| Total revenues | ​ | $ | 83,067 | ​ | $ | 42,298 | ​ | $ | 52,894 | ​ | $ | 21,507 | ​ | $ | 199,766 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 69,872 | ​ | $ | 26,923 | ​ | $ | 38,414 | ​ | $ | 11,559 | ​ | $ | 146,268 |
| International | ​ |  | 13,195 | ​ |  | 15,375 | ​ |  | 14,480 | ​ |  | 9,948 | ​ |  | 53,498 |
| Total revenues | ​ | $ | 83,067 | ​ | $ | 42,298 | ​ | $ | 52,894 | ​ | $ | 21,507 | ​ | $ | 199,766 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 41,633 | ​ | $ | 6,485 | ​ | $ | 40,968 | ​ | $ | — | ​ | $ | 89,092 |
| Over time | ​ |  | 41,434 | ​ |  | 35,813 | ​ |  | 11,926 | ​ |  | 21,507 | ​ |  | 110,674 |
| Total revenues | ​ | $ | 83,067 | ​ | $ | 42,298 | ​ | $ | 52,894 | ​ | $ | 21,507 | ​ | $ | 199,766 |

- changed (2020-02-07):
[0001104659-20-012461:note_history:70]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At December 31, 2019, the Company had $500 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 76% in the next twelve months.
  (was, 2019-08-09, similarity 0.8976):
[0001144204-19-038765:note_history:70]
Our remaining performance obligations, which is the equivalent of our backlog, represent the expected transaction price allocated to our contracts that we expect to recognize as revenue in future periods when we perform under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At June 30, 2019, we had $432.5 million in remaining performance obligations of which we expect to recognize revenues of 83% in the next twelve months.

- changed (2020-02-07):
[0001104659-20-012461:note_history:71]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At December 31, 2019, contract assets and liabilities totaled $93.5 million and $84.8 million, respectively.  During the first quarter of 2020, the Company recognized approximately $26 million in revenues that were included in the contract liabilities balance at the adoption date.
  (was, 2019-08-09, similarity 0.7383):
[0001144204-19-038765:note_history:71]
Assets and liabilities related to our contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At June 30, 2019, contract assets and liabilities totaled $99.5 million and $53.8 million, respectively. Upon adoption of ASC 606 on October 1, 2018, contract assets and liabilities related to our contracts with customers were $87 million and $51 million, respectively. During the first nine months of 2019, we recognized approximately $35 million in revenues that were included in the contract liabilities balance at the adoption date.

- removed (2020-02-07):
[0001144204-19-038765:note_history:72]
| Nine Months Ended June 30, 2019 |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | Technical |  | ​ | ​ |
| (In thousands) | ​ | Filtration | ​ | Test | ​ | USG | ​ | Packaging | ​ | Total |
| Customer type: |  | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |  |
| Commercial | ​ | $ | 131,112 | ​ | $ | 111,577 | ​ | $ | 154,240 | ​ | $ | 63,251 | ​ | $ | 460,180 |
| Government | ​ |  | 97,657 | ​ |  | 14,882 | ​ |  | 3,399 | ​ |  | 194 | ​ |  | 116,132 |
| Total revenues | ​ | $ | 228,769 | ​ | $ | 126,459 | ​ | $ | 157,639 | ​ | $ | 63,445 | ​ | $ | 576,312 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 190,701 | ​ | $ | 82,072 | ​ | $ | 112,289 | ​ | $ | 32,865 | ​ | $ | 417,927 |
| International | ​ |  | 38,068 | ​ |  | 44,387 | ​ |  | 45,350 | ​ |  | 30,580 | ​ |  | 158,385 |

- removed (2020-02-07):
[0001144204-19-038765:note_history:73]
| Total revenues | ​ | $ | 228,769 | ​ | $ | 126,459 | ​ | $ | 157,639 | ​ | $ | 63,445 | ​ | $ | 576,312 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 115,852 | ​ | $ | 29,092 | ​ | $ | 122,075 | ​ | $ | - | ​ | $ | 267,021 |
| Over time | ​ |  | 112,917 | ​ |  | 97,367 | ​ |  | 35,564 | ​ |  | 63,445 | ​ |  | 309,291 |
| Total revenues | ​ | $ | 228,769 | ​ | $ | 126,459 | ​ | $ | 157,639 | ​ | $ | 63,445 | ​ | $ | 576,312 |

- removed (2020-02-07):
[0001144204-19-038765:note_history:74]
Reconciliation of ASC 606 to Prior Accounting Standards

- removed (2020-02-07):
[0001144204-19-038765:note_history:75]
The amount by which each financial statement line item is affected in 2019 as a result of applying the new accounting standard as discussed in Note 2 is presented below:

- removed (2020-02-07):
[0001144204-19-038765:note_history:76]
| ​ | ​ | June 30, 2019 |
| ​ |  | ​ | ​ |  | Effect of the |  | ​ | ​ |
| ​ | ​ | ​ | ​ |  | adoption of |  | Under Prior |
| (In thousands) | ​ | As Reported |  | ASC 606 | ​ | Accounting |
| Consolidated Balance Sheets |  | ​ |  |  | ​ |  |  | ​ |  |
| Contract assets (1) | ​ | $ | 99,499 | ​ | $ | (43,576) | ​ | $ | 55,923 |
| Inventories | ​ |  | 126,816 | ​ |  | 36,089 | ​ |  | 162,905 |
| Total current assets | ​ |  | 450,206 | ​ |  | (7,487) | ​ |  | 442,719 |
| Total assets | ​ |  | 1,326,095 | ​ |  | (7,487) | ​ |  | 1,318,608 |
| Contract liabilities (2) | ​ |  | 53,758 | ​ |  | 4,549 | ​ |  | 58,307 |
| Total current liabilities | ​ |  | 199,736 | ​ |  | 4,549 | ​ |  | 204,285 |
| Deferred tax liabilities | ​ |  | 66,286 | ​ |  | (1,678) | ​ |  | 64,608 |
| Total liabilities | ​ |  | 514,288 | ​ |  | 2,871 | ​ |  | 517,159 |
| Retained earnings | ​ |  | 661,003 | ​ |  | (10,358) | ​ |  | 650,645 |
| Total shareholders’ equity | ​ |  | 811,807 | ​ |  | (10,358) | ​ |  | 801,449 |
| Total liabilities and shareholders’ equity | ​ | $ | 1,326,095 | ​ |  | (7,487) | ​ |  | 1,318,608 |

- removed (2020-02-07):
[0001144204-19-038765:note_history:77]
|  | (1) | Previously “cost and estimated earnings on long-term contracts” |

- removed (2020-02-07):
[0001144204-19-038765:note_history:78]
|  | (2) | Previously “advance payments on long-term contracts” and “current portion of deferred revenue” |

- removed (2020-02-07):
[0001144204-19-038765:note_history:79]
| ​ | ​ | Three Months Ended |
| ​ | ​ | June 30, 2019 |
| ​ |  | ​ | ​ |  | Effect of the |  | ​ | ​ |
| ​ | ​ | ​ | ​ |  | adoption of |  | Under Prior |
| (In thousands, except per share amounts) | ​ | As Reported |  | ASC 606 | ​ | Accounting |
| Consolidated Statements of Operations | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net sales | ​ | $ | 199,766 | ​ | $ | (4,008) | ​ | $ | 195,758 |
| Cost of sales | ​ |  | 122,172 | ​ |  | (1,380) | ​ |  | 120,792 |
| Total costs and expenses | ​ |  | 174,874 | ​ |  | (1,380) | ​ |  | 173,494 |
| Earnings before income tax | ​ |  | 24,892 | ​ |  | (2,628) | ​ |  | 22,264 |
| Income tax expense (benefit) | ​ |  | 4,825 | ​ |  | (399) | ​ |  | 4,426 |
| Net earnings | ​ | ​ | 20,067 | ​ | ​ | (2,229) | ​ | ​ | 17,838 |
| Earnings per share: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Basic: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net earnings | ​ | $ | 0.77 | ​ | $ | (0.08) | ​ | $ | 0.69 |
| Diluted: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net earnings | ​ | $ | 0.77 | ​ | $ | (0.08) | ​ | $ | 0.69 |
| Consolidated Statements of Comprehensive Income | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net earnings | ​ | $ | 20,067 | ​ | $ | (2,229) | ​ | $ | 17,838 |
| Comprehensive income | ​ |  | 21,899 | ​ |  | (2,229) | ​ |  | 19,670 |

- removed (2020-02-07):
[0001144204-19-038765:note_history:80]
| ​ | ​ | Nine Months Ended |
| ​ | ​ | June 30, 2019 |
| ​ |  | ​ | ​ |  | Effect of the |  | ​ | ​ |
| ​ | ​ | ​ | ​ |  | adoption of |  | Under Prior |
| (In thousands, except per share amounts) | ​ | As Reported |  | ASC 606 | ​ | Accounting |
| Consolidated Statements of Operations | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net sales | ​ | $ | 576,312 | ​ | $ | (9,787) | ​ | $ | 566,525 |
| Cost of sales | ​ |  | 363,026 | ​ |  | (8,360) | ​ |  | 354,666 |
| Total costs and expenses | ​ |  | 506,808 | ​ |  | (8,360) | ​ |  | 498,448 |
| Earnings before income tax | ​ |  | 69,504 | ​ |  | (1,427) | ​ |  | 68,077 |
| Income tax expense (benefit) | ​ |  | 13,323 | ​ |  | (171) | ​ |  | 13,152 |
| Net earnings | ​ |  | 56,181 | ​ |  | (1,256) | ​ |  | 54,925 |
| Earnings per share: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Basic: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net earnings | ​ | $ | 2.17 | ​ | $ | (0.05) | ​ | $ | 2.12 |
| Diluted: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net earnings | ​ | $ | 2.15 | ​ | $ | (0.04) | ​ | $ | 2.11 |
| Consolidated Statements of Comprehensive Income | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net earnings | ​ | $ | 56,181 | ​ | $ | (1,256) | ​ | $ | 54,925 |
| Comprehensive income | ​ |  | 54,262 | ​ |  | (1,256) | ​ |  | 53,006 |
| Consolidated Statements of Cash flows | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net earnings | ​ | $ | 56,181 | ​ | $ | (1,256) | ​ | $ | 54,925 |
| Adjustments to reconcile net earnings to net cash provided by operating activities: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Change in assets and liabilities | ​ | $ | (41,851) | ​ | ​ | 1,256 | ​ | $ | (40,595) |
| Net cash provided by operating activities | ​ |  | 37,041 | ​ |  | — | ​ |  | 37,041 |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2020-02-07):
[0001144204-19-038765:note_history:81]
16.  SUBSEQUENT EVENT

- removed (2020-02-07):
[0001144204-19-038765:note_history:82]
On July 2, 2019, the Company acquired Globe Composite Solutions, LLC (Globe), a supplier of mission-critical composite-based products and solutions for navy, defense, and industrial customers. Globe’s operating results from date of acquisition will be included in the Company’s Filtration segment.
