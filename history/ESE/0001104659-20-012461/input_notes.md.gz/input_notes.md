# ESE notes — 0001104659-20-012461


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001104659-20-012461:notes:1]
[same as prior period, unchanged from 0001144204-19-038765:notes:1]

[0001104659-20-012461:notes:2]
The accompanying consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP). For further information, refer to the consolidated financial statements and related notes included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2019. Certain 2019 amounts have been reclassified to conform with the 2020 presentation.

[0001104659-20-012461:notes:3]
The Company’s results for the three-month period ended December 31, 2019 are not necessarily indicative of the results for the entire 2020 fiscal year. References to the first quarters of 2020 and 2019 represent the fiscal quarters ended December 31, 2019 and 2018, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.

[0001104659-20-012461:notes:4]
Beginning in the first quarter of 2020, Management has renamed the Filtration / Fluid Flow (Filtration) segment as Aerospace & Defense (A&D) to better reflect the composition of the segment’s products, end markets and customer characteristics. The A&D’s segment’s individual legal and operating entities, historical financial results, and management structure are unchanged from what was formerly presented as Filtration.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001104659-20-012461:notes:5]
2.    TECHNICAL PACKAGING DIVESTITURE

[0001104659-20-012461:notes:6]
On December 31, 2019, the Company completed the sale of its Technical Packaging business segment, consisting of the Company's wholly-owned subsidiaries Thermoform Engineered Quality LLC, Plastique Ltd. and Plastique sp. z o.o. (the "Technical Packaging Business"), to Sonoco Plastics, Inc. and Sonoco Holdings, Inc. ("Buyers"), two wholly-owned subsidiaries of Sonoco Products Company, pursuant to the Equity Purchase Agreement entered into on November 15, 2019. The companies within this segment provide innovative solutions to the medical and commercial markets for thermoformed packages and specialty products using a wide variety of thin gauge plastics and pulp. Results of operations, financial position and cash flows for the Technical Packaging business is reflected as discontinued operations in the consolidated financial statements and related notes for all periods presented.

[0001104659-20-012461:notes:7]
The pretax loss recorded in discontinued operations related to the Technical Packaging business was $0.3 million and $0.1 million for the three-month periods ended December 31, 2019 and 2018, respectively. Net sales from the Technical Packaging business were $16.5 million and $19.2 million for the three-month periods ended December 31, 2019 and 2018, respectively. The Company received net proceeds from the sale of approximately $184 million and recorded a $76.6 million after-tax gain on the sale in the first quarter of 2020.

[0001104659-20-012461:notes:8]
The major classes of assets and liabilities of the Technical Packaging business included in the Consolidated Balance Sheet at September 30, 2019 are shown below (in millions).

[0001104659-20-012461:notes:9]
| ​ |  | September 30, 2019 |
| Assets: | ​ |  |  |
| Accounts receivable, net |  | $ | 15.7 |
| Contract assets, net | ​ |  | 5.1 |
| Inventories | ​ |  | 3.9 |
| Other current assets | ​ |  | 0.6 |
| Current assets | ​ |  | 25.3 |
| Property, plant & equipment, net | ​ |  | 33.6 |
| Intangible assets, net | ​ |  | 11.4 |
| Goodwill | ​ |  | 19.0 |
| Other assets | ​ |  | 3.4 |
| Total assets |  | $ | 92.7 |
| Liabilities: | ​ |  |  |
| Accounts payable |  | $ | 7.6 |
| Accrued expenses and other current liabilities | ​ |  | 3.9 |
| Current liabilities | ​ |  | 11.5 |
| Other liabilities | ​ |  | 4.0 |
| Total liabilities |  | $ | 15.5 |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001104659-20-012461:notes:10]
3.    ACCOUNTING STANDARDS UPDATE

[0001104659-20-012461:notes:11]
In February 2016, the FASB issued ASU No. 2016-062, "Leases" (ASU 2016-062) which supersedes ASC 840, "Leases" and creates a new topic, ASC 842, "Leases." Subsequent to the issuance of ASU 2016-062, ASC 842 was amended by various updates that amend and clarify the impact and implementation of the aforementioned update. Effective October 1, 2019, the Company adopted these updates using the optional transition method. These updates require lessees to recognize a lease liability and a lease asset for all leases, including operating leases, with a term greater than 12 months on its balance sheet. Upon initial application, the provisions of these updates are required to be applied using the modified retrospective method, which requires retrospective adoption to each prior reporting period presented with the cumulative effect of adoption recorded to the earliest reporting period presented. An optional transition method can be utilized which requires retrospective adoption beginning on the date of adoption with the cumulative effect of initially applying these updates recognized at the date of initial adoption. The standard also provided several optional practical expedients for use in transition. The Company elected to use what the FASB has deemed the “package of practical expedients,” which allowed the Company not to reassess previous conclusions about lease identification, lease classification and the accounting treatment for initial direct costs. These updates also expand the required quantitative and qualitative disclosures surrounding leases. The adoption resulted in the addition of "right of use" assets and lease liabilities of approximately $20 million in the consolidated balance sheet, with no significant change to the Company’s consolidated statements of operations or cash flows. Refer to Note 16 for further discussion.


## us-gaap:EarningsPerShareTextBlock

[0001104659-20-012461:notes:12]
4.    EARNINGS PER SHARE (EPS)

[0001104659-20-012461:notes:13]
[same as prior period, unchanged from 0001144204-19-038765:notes:33]

[0001104659-20-012461:notes:14]
| ​ | ​ | Three Months |
| ​ | ​ | Ended December 31, |
| ​ |  | 2019 |  | 2018 |
| Weighted Average Shares Outstanding - Basic | ​ | 25,981 | ​ | 25,911 |
| Dilutive Options and Restricted Shares |  | 187 |  | 209 |
| Adjusted Shares - Diluted |  | 26,168 |  | 26,120 |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001104659-20-012461:notes:15]
5.    SHARE-BASED COMPENSATION

[0001104659-20-012461:notes:16]
[same as prior period, unchanged from 0001144204-19-038765:notes:36]

[0001104659-20-012461:notes:17]
[same as prior period, unchanged from 0001144204-19-038765:notes:37]

[0001104659-20-012461:notes:18]
Compensation expense related to the restricted share awards was $1.1 million and $1.1 million for the three-month periods ended December 31, 2019 and 2018, respectively. There were 264,399 non-vested shares outstanding as of December 31, 2019.

[0001104659-20-012461:notes:19]
[same as prior period, unchanged from 0001144204-19-038765:notes:39]

[0001104659-20-012461:notes:20]
Compensation expense related to the non-employee director grants was $0.3 million and $0.3 million for the three-month periods ended December 31, 2019 and 2018, respectively.

[0001104659-20-012461:notes:21]
The total share-based compensation cost that has been recognized in the results of operations and included within selling, general and administrative expenses (SG&A) was $1.4 million and $1.4 million for the three-month periods ended December 31, 2019 and 2018, respectively. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $0.3 million and $0.3 million for the three-month periods ended December 31, 2019 and 2018, respectively. As of December 31, 2019, there was $7.9 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a remaining weighted-average period of 1.8 years.


## us-gaap:InventoryDisclosureTextBlock

[0001104659-20-012461:notes:22]
6.    INVENTORIES

[0001104659-20-012461:notes:23]
Inventories, net, from continuing operations consist of the following:

[0001104659-20-012461:notes:24]
| ​ | ​ | December 31, | ​ | September 30, |
| (In thousands) |  | 2019 |  | 2019 |
| Finished goods | ​ | $ | 22,472 |  | ​ | 23,550 |
| Work in process | ​ |  | 33,417 |  | ​ | 26,407 |
| Raw materials | ​ |  | 78,088 |  |  | 74,999 |
| Total inventories | ​ | $ | 133,977 |  | ​ | 124,956 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001104659-20-012461:notes:25]
7.    GOODWILL AND OTHER INTANGIBLE ASSETS

[0001104659-20-012461:notes:26]
Included on the Company’s Consolidated Balance Sheets at December 31, 2019 and September 30, 2019 are the following intangible assets gross carrying amounts and accumulated amortization from continuing operations:

[0001104659-20-012461:notes:27]
| ​ | ​ | December 31, | ​ | September 30, |
| (Dollars in thousands) |  | 2019 |  | 2019 |
| Goodwill | ​ | $ | 390,383 |  | ​ | 390,256 |
| Intangible assets with determinable lives: | ​ |  | ​ |  | ​ |  |
| Patents | ​ |  | ​ |  | ​ |  |
| Gross carrying amount | ​ | $ | 2,007 |  | ​ | 1,945 |
| Less: accumulated amortization | ​ |  | 775 |  |  | 748 |
| Net | ​ | $ | 1,232 |  | ​ | 1,197 |
| Capitalized software | ​ |  | ​ |  | ​ |  |
| Gross carrying amount | ​ | $ | 80,886 |  | ​ | 78,962 |
| Less: accumulated amortization | ​ |  | 51,075 |  |  | 48,530 |
| Net | ​ | $ | 29,811 |  | ​ | 30,432 |
| Customer relationships | ​ |  | ​ |  | ​ |  |
| Gross carrying amount | ​ | $ | 227,296 |  | ​ | 227,225 |
| Less: accumulated amortization | ​ |  | 58,408 |  |  | 55,326 |
| Net | ​ | $ | 168,888 |  | ​ | 171,899 |
| Other | ​ |  | ​ |  | ​ |  |
| Gross carrying amount | ​ | $ | 5,195 |  | ​ | 5,441 |
| Less: accumulated amortization | ​ |  | 2,800 |  |  | 2,645 |
| Net | ​ | $ | 2,395 |  | ​ | 2,796 |
| Intangible assets with indefinite lives: | ​ |  | ​ |  | ​ |  |
| Trade names | ​ | $ | 175,922 |  | ​ | 175,281 |

[0001104659-20-012461:notes:28]
The changes in the carrying amount of goodwill attributable to each business segment for the three months ended December 31, 2019 is as follows on a continuing operations basis:

[0001104659-20-012461:notes:29]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | Aerospace | ​ | ​ | ​ |
| (Dollars in millions) |  | USG |  | Test |  | & Defense |  | Total |
| Balance as of September 30, 2019 |  | ​ | 254.0 |  | ​ | 34.1 |  | ​ | 102.2 |  | ​ | 390.3 |
| Foreign currency translation |  | ​ | 0.1 |  | ​ | — |  | ​ | — |  | ​ | 0.1 |
| Balance as of December 31, 2019 | ​ | $ | 254.1 |  | ​ | 34.1 |  | ​ | 102.2 |  | ​ | 390.4 |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001104659-20-012461:notes:30]
8.    BUSINESS SEGMENT INFORMATION

[0001104659-20-012461:notes:31]
The Company is organized based on the products and services that it offers, and classifies its continuing business operations in three reportable segments for financial reporting purposes: Aerospace & Defense (formerly called Filtration/Fluid Flow), RF Shielding and Test (Test), and Utility Solutions Group (USG). The Aerospace & Defense segment’s operations consist of PTI Technologies Inc. (PTI), VACCO Industries (VACCO), Crissair, Inc. (Crissair), Westland Technologies Inc. (Westland), Mayday Manufacturing Co. and its affiliate Hi-Tech Metals, Inc. (collectively referred to as Mayday) and Globe Composite Solutions, LLC (Globe). The companies within this segment primarily design and manufacture specialty filtration and naval products, including hydraulic filter elements and fluid control devices used in commercial aerospace applications; unique filter mechanisms used in micro-propulsion devices for satellites and custom designed filters for manned aircraft and submarines; products and systems to reduce vibration and/or acoustic signatures and otherwise reduce or obscure a vessel’s signature, and other communications, sealing, surface control and hydrodynamic related applications to enhance U.S. Navy maritime survivability; precision-tolerance machined components for the aerospace and defense industry; and metal processing services. The Test segment’s operations consist primarily of ETS-Lindgren Inc. (ETS-Lindgren). ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy. ETS-Lindgren also manufactures radio frequency shielding products and components used by manufacturers of medical equipment, communications systems, electronic products, and shielded rooms for high-security data processing and secure communication. The USG segment’s operations consist primarily of Doble Engineering Company (Doble), Morgan Schaffer Inc. (Morgan Schaffer), and NRG Systems, Inc. (NRG). Doble provides high-end, intelligent, diagnostic test and data management solutions for the electric power delivery industry and is a leading supplier of partial discharge testing instruments used to assess the integrity of high voltage power delivery equipment. Morgan Schaffer provides an integrated offering of dissolved gas analysis, oil testing, and data management solutions for the electric power industry. NRG designs and manufactures decision support tools for the renewable energy industry, primarily wind.

[0001104659-20-012461:notes:32]
Management evaluates and measures the performance of its reportable segments based on “Net Sales” and “EBIT”, which are detailed in the table below. EBIT is defined as earnings from continuing operations before interest and taxes. The table below is presented on the basis of continuing operations and excludes discontinued operations.

[0001104659-20-012461:notes:33]
| ​ | ​ | Three Months |
| ​ | ​ | Ended December 31, |
| (In thousands) |  | 2019 |  | 2018 |
| NET SALES |  | ​ |  |  | ​ |  |
| Aerospace & Defense | ​ | $ | 77,511 |  | ​ | 66,224 |
| Test | ​ |  | 41,383 |  | ​ | 41,286 |
| USG | ​ |  | 52,834 |  | ​ | 55,855 |
| Consolidated totals | ​ | $ | 171,728 |  | ​ | 163,365 |
| EBIT | ​ |  | ​ |  | ​ |  |
| Aerospace & Defense | ​ | $ | 12,513 |  | ​ | 10,610 |
| Test | ​ |  | 4,656 |  | ​ | 3,310 |
| USG | ​ |  | 9,288 |  | ​ | 21,546 |
| Corporate (loss) | ​ |  | (9,666) |  |  | (10,116) |
| Consolidated EBIT | ​ |  | 16,791 |  | ​ | 25,350 |
| Less: Interest expense | ​ |  | (2,421) |  |  | (1,855) |
| Earnings before income taxes from continuing operations | ​ | $ | 14,370 |  | ​ | 23,495 |

[0001104659-20-012461:notes:34]
[same as prior period, unchanged from 0001144204-19-038765:notes:55]

[0001104659-20-012461:notes:35]
The financial measure “EBIT” is presented in the above table and elsewhere in this Report. EBIT on a consolidated basis is a non-GAAP financial measure. Management believes that EBIT is useful in assessing the operational profitability of the Company’s business segments because it excludes interest and taxes, which are generally accounted for across the entire Company on a consolidated basis. EBIT is also one of the measures used by management in determining resource allocations within the Company as well as incentive compensation. A reconciliation of EBIT to net earnings from continuing operations is set forth in Item 2, Management’s Discussion and Analysis of Financial Condition and Results of Operations – EBIT.

[0001104659-20-012461:notes:36]
[same as prior period, unchanged from 0001144204-19-038765:notes:58]


## us-gaap:DebtDisclosureTextBlock

[0001104659-20-012461:notes:37]
9.    DEBT

[0001104659-20-012461:notes:38]
The Company’s debt is summarized as follows:

[0001104659-20-012461:notes:39]
| ​ | ​ | December 31, | ​ | September 30, |
| (In thousands) |  | 2019 |  | 2019 |
| Total borrowings | ​ | $ | 150,000 |  | ​ | 285,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 130,000 |  | ​ | 265,000 |

[0001104659-20-012461:notes:40]
On September 27, 2019, the Company entered into a new five-year credit facility (“the Credit Facility”), modifying its previous credit facility which would have matured December 21, 2020. The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024.

[0001104659-20-012461:notes:41]
At December 31, 2019, the Company had approximately $341 million available to borrow under the Credit Facility, plus the $250 million increase option, in addition to $96.7 million cash on hand. The Company classified $20.0 million as the current portion of long-term debt as of December 31, 2019, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $8.5 million at December 31, 2019.

[0001104659-20-012461:notes:42]
Interest on borrowings under the Credit Facility is calculated at a spread over either the London Interbank Offered Rate (LIBOR ), the New York Federal Reserve Bank Rate or the prime rate, depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The Credit Facility is secured by the unlimited guaranty of the Company’s direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of its direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 3.18% and 3.25% for the three-month periods ending December 31, 2019 and 2018, respectively. As of December 31, 2019, the Company was in compliance with all covenants.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001104659-20-012461:notes:43]
10.  INCOME TAX EXPENSE

[0001104659-20-012461:notes:44]
The first quarter 2020 effective income tax rate from continuing operations was 25.1% compared to 26.2% in the first quarter of 2019. The income tax expense in the first quarter of 2019 was unfavorably impacted by return to provision true-ups increasing the first quarter 2019 effective tax rate by 1.1%.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001104659-20-012461:notes:45]
11.  SHAREHOLDERS’ EQUITY

[0001104659-20-012461:notes:46]
The change in shareholders’ equity for the first three months of 2020 and 2019 is shown below (in thousands):

[0001104659-20-012461:notes:47]
| ​ | ​ | Three Months Ended December 31, |
| ​ |  | 2019 |  | 2018 |
| Common stock | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 306 | ​ | 305 |
| Stock plans | ​ | — | ​ | — |
| Ending balance | ​ | 306 | ​ | 305 |
| Additional paid-in-capital | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 292,408 | ​ | 291,190 |
| Stock plans | ​ | (648) | ​ | 1,103 |
| Ending balance | ​ | 293,056 | ​ | 292,293 |
| Retained earnings | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 684,741 | ​ | 606,837 |
| Net earnings common stockholders | ​ | 86,777 | ​ | 17,317 |
| Dividends paid | ​ | (2,079) | ​ | (2,073) |
| Adoption of accounting standards updates | ​ | — | ​ | 5,589 |
| Ending balance | ​ | 769,439 | ​ | 627,670 |
| Accumulated other comprehensive income (loss) | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | (43,974) | ​ | (31,528) |
| Foreign currency translation | ​ | 3,923 | ​ | (4,529) |
| Forward exchange contracts | ​ | — | ​ | (25) |
| Ending balance | ​ | (40,051) | ​ | (36,082) |
| Treasury stock | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | (107,259) | ​ | (107,394) |
| Issued under stock plans | ​ | — | ​ | — |
| Ending balance | ​ | (107,259) | ​ | (107,394) |
| Total equity | ​ | 915,491 | ​ | 776,792 |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001104659-20-012461:notes:48]
12.  RETIREMENT PLANS

[0001104659-20-012461:notes:49]
A summary of net periodic benefit expense for the Company’s defined benefit plans for the three-month periods ended December 31, 2019 and 2018 is shown in the following table. Net periodic benefit cost for each period presented is comprised of the following:

[0001104659-20-012461:notes:50]
| ​ | ​ | Three Months |
| ​ | ​ | Ended December 31, |
| (In thousands) |  | 2019 |  | 2018 |
| Defined benefit plans | ​ | ​ |  | ​ | ​ |  |
| Interest cost | ​ | $ | 824 |  | ​ | 875 |
| Expected return on assets | ​ |  | (1,041) |  | ​ | (1,086) |
| Amortization of: | ​ |  | ​ |  | ​ |  |
| Prior service cost | ​ |  | — |  | ​ | — |
| Actuarial loss | ​ |  | 543 |  |  | 487 |
| Net periodic benefit cost | ​ | $ | 326 |  | ​ | 276 |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001104659-20-012461:notes:51]
13.  DERIVATIVE FINANCIAL INSTRUMENTS

[0001104659-20-012461:notes:52]
Market risks relating to the Company’s operations result primarily from changes in interest rates and changes in foreign currency exchange rates. The Company is exposed to market risk related to changes in interest rates and selectively uses derivative financial instruments, including forward contracts and swaps, to manage these risks. In 2018, the Company entered into three interest rate swaps with a notional amount of $150 million to hedge some of its exposure to variability in future LIBOR-based interest payments on variable rate debt, of which one swap is outstanding as of December 31, 2019. In addition, the Company’s Canadian subsidiary Morgan Schaffer enters into foreign exchange contracts to manage foreign currency risk as a portion of their revenue is denominated in U.S. dollars. The Company expects hedging gains or losses to be essentially offset by losses or gains on the related underlying exposures. The amounts ultimately recognized may differ for open positions, which remain subject to ongoing market price fluctuations until settlement. All derivative instruments are reported in either accrued expenses or other assets on the balance sheet at fair value. For derivative instruments designated as cash flow hedges, the gain or loss on the derivative is deferred in accumulated other comprehensive income until recognized in earnings with the underlying hedged item. The interest rate swaps entered into during 2018 were not designated as cash flow hedges and, therefore, the gain or loss on the derivative is reflected in earnings each period.

[0001104659-20-012461:notes:53]
The following is a summary of the notional transaction amounts and fair values for the Company’s outstanding derivative financial instruments by risk category and instrument type as of December 31, 2019:

[0001104659-20-012461:notes:54]
| ​ | ​ | ​ | ​ | Fair | ​ | ​ | ​ |
| ​ | ​ | Notional | ​ | Value | ​ | Fix | ​ |
| (In thousands) |  | amount |  | (US$) |  | Rate |  |
| Forward contracts |  | 5,500 |  | USD |  | 80 |  |  |  |
| Interest rate swap |  | 150,000 |  | USD |  | (918) |  | 2.24 | % |


## us-gaap:FairValueDisclosuresTextBlock

[0001104659-20-012461:notes:55]
14.  FAIR VALUE MEASUREMENTS

[0001104659-20-012461:notes:56]
[same as prior period, unchanged from 0001144204-19-038765:notes:84]

[0001104659-20-012461:notes:57]
[same as prior period, unchanged from 0001144204-19-038765:notes:85]

[0001104659-20-012461:notes:58]
[same as prior period, unchanged from 0001144204-19-038765:notes:86]

[0001104659-20-012461:notes:59]
[same as prior period, unchanged from 0001144204-19-038765:notes:87]

[0001104659-20-012461:notes:60]
[same as prior period, unchanged from 0001144204-19-038765:notes:88]

[0001104659-20-012461:notes:61]
The Company has estimated the fair value of its financial instruments as of December 31, 2019 and September 30, 2019 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, debt and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001104659-20-012461:notes:62]
[same as prior period, unchanged from 0001144204-19-038765:notes:90]

[0001104659-20-012461:notes:63]
The Company’s forward contracts and interest rate swaps are classified within Level 2 of the valuation hierarchy in accordance with FASB Accounting Standards Codification (ASC) 825, as presented below as of December 31, 2019:

[0001104659-20-012461:notes:64]
| (In thousands) |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets (Liabilities): |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Forward contracts and interest rate swaps | ​ | $ | — |  | ​ | (838) | ​ | $ | — |  | ​ | (838) |

[0001104659-20-012461:notes:65]
[same as prior period, unchanged from 0001144204-19-038765:notes:93]

[0001104659-20-012461:notes:66]
[same as prior period, unchanged from 0001144204-19-038765:notes:94]

[0001104659-20-012461:notes:67]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during the three-month period ended December 31, 2019.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001104659-20-012461:notes:68]
15.  REVENUES

[0001104659-20-012461:notes:69]
[same as prior period, unchanged from 0001144204-19-038765:notes:97]

[0001104659-20-012461:notes:70]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2019 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within each reportable segment on a continuing operations basis.

[0001104659-20-012461:notes:71]
| ​ |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | Test | ​ | USG | ​ | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 41,907 | ​ | $ | 35,249 | ​ | $ | 52,235 | ​ | $ | 129,391 |
| U.S. Government | ​ |  | 35,604 | ​ |  | 6,134 | ​ |  | 599 | ​ |  | 42,337 |
| Total revenues | ​ | $ | 77,511 | ​ | $ | 41,383 | ​ | $ | 52,834 | ​ | $ | 171,728 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 64,706 | ​ | $ | 24,837 | ​ | $ | 34,651 | ​ | $ | 124,194 |
| International | ​ |  | 12,805 | ​ |  | 16,546 | ​ |  | 18,183 | ​ |  | 47,534 |
| Total revenues | ​ | $ | 77,511 | ​ | $ | 41,383 | ​ | $ | 52,834 | ​ | $ | 171,728 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 35,761 | ​ | $ | 7,611 | ​ | $ | 40,315 | ​ | $ | 83,687 |
| Over time | ​ |  | 41,750 | ​ |  | 33,772 | ​ |  | 12,519 | ​ |  | 88,041 |
| Total revenues | ​ | $ | 77,511 | ​ | $ | 41,383 | ​ | $ | 52,834 | ​ | $ | 171,728 |

[0001104659-20-012461:notes:72]
[same as prior period, unchanged from 0001144204-19-038765:notes:102]

[0001104659-20-012461:notes:73]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At December 31, 2019, the Company had $500 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 76% in the next twelve months.

[0001104659-20-012461:notes:74]
[same as prior period, unchanged from 0001144204-19-038765:notes:104]

[0001104659-20-012461:notes:75]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At December 31, 2019, contract assets and liabilities totaled $93.5 million and $84.8 million, respectively.  During the first quarter of 2020, the Company recognized approximately $26 million in revenues that were included in the contract liabilities balance at the adoption date.


## us-gaap:LeasesOfLesseeDisclosureTextBlock

[0001104659-20-012461:notes:76]
16.  LEASES

[0001104659-20-012461:notes:77]
As described in Note 3, effective October 1, 2019, the Company adopted ASC 842, Leases. The Company determines at lease inception whether an arrangement that provides control over the use of an asset is a lease. The Company recognizes at lease commencement a right-of-use (ROU) asset and lease liability based on the present value of the future lease payments over the lease term. The Company has elected not to recognize a ROU asset and lease liability for leases with terms of 12 months or less. Certain of the Company’s leases include options to extend the term of the lease for up to 20 years. When it is reasonably certain that the Company will exercise the option, Management includes the impact of the option in the lease term for purposes of determining total future lease payments. As most of the Company’s lease agreements do not explicitly state the discount rate implicit in the lease, Management uses the Company’s incremental borrowing rate on the commencement date to calculate the present value of future payments based on the tenor of each arrangement.

[0001104659-20-012461:notes:78]
The Company’s leases for real estate commonly include escalating payments. These variable lease payments are included in the calculation of the ROU asset and lease liability. In addition to the present value of the future lease payments, the calculation of the ROU asset also includes any deferred rent, lease pre-payments and initial direct costs of obtaining the lease.

[0001104659-20-012461:notes:79]
In addition to the base rent, real estate leases typically contain provisions for common-area maintenance and other similar services, which are considered non-lease components for accounting purposes. Non-lease components are excluded from our ROU assets and lease liabilities and expensed as incurred.

[0001104659-20-012461:notes:80]
The Company’s leases are for office space, manufacturing facilities, and machinery and equipment.

[0001104659-20-012461:notes:81]
The components of lease costs are shown below:

[0001104659-20-012461:notes:82]
| ​ |  | Three Months |
| ​ | ​ | Ended |
| ​ | ​ | December 31, |
| (Dollars in thousands) |  | 2019 |
| Finance lease cost |  | ​ |  |
| Amortization of right-of-use assets | ​ | $ | 622 |
| Interest on lease liabilities | ​ |  | 328 |
| Operating lease cost | ​ |  | 1,419 |
| Total lease costs | ​ | $ | 2,369 |

[0001104659-20-012461:notes:83]
Additional information related to leases are shown below:

[0001104659-20-012461:notes:84]
| ​ |  | Three Months |  |
| ​ | ​ | Ended |  |
| ​ | ​ | December 31, |  |
| (Dollars in thousands) |  | 2019 |  |
| Cash paid for amounts included in the measurement of lease liabilities |  | ​ |  | ​ |
| Operating cash flows from operating leases | ​ | $ | 1,408 | ​ |
| Operating cash flows from finance leases | ​ |  | 138 | ​ |
| Financing cash flows from finance leases | ​ |  | 351 | ​ |
| Right-of-use assets obtained in exchange for lease liabilities | ​ |  |  | ​ |
| Operating leases | ​ | $ | 22,014 | ​ |
| Weighted-average remaining lease term | ​ |  |  | ​ |
| Operating leases | ​ |  | 6.51 years | ​ |
| Finance leases | ​ |  | 13.16 years | ​ |
| Weighted-average discount rate | ​ |  |  | ​ |
| Operating leases | ​ |  | 3.14 | % |
| Finance leases | ​ |  | 4.28 | % |

[0001104659-20-012461:notes:85]
The following is a reconciliation of future undiscounted cash flows to the operating and finance lease liabilities, and the related ROU assets, presented on our Consolidated Balance Sheet on December 31, 2019:

[0001104659-20-012461:notes:86]
| (Dollars in thousands) | ​ |  | Operating |  | Finance |
| Years Ending September 30: |  | Leases |  | Leases |
| 2020 (excluding the three months ended December 31, 2019) | ​ | $ | 3,887 |  | ​ | 2,029 |
| 2021 | ​ |  | 4,451 |  | ​ | 2,930 |
| 2022 | ​ |  | 3,787 |  | ​ | 3,011 |
| 2023 | ​ |  | 2,968 |  | ​ | 3,094 |
| 2024 and thereafter | ​ |  | 7,808 |  | ​ | 31,481 |
| Total minimum lease payments | ​ |  | 22,901 |  | ​ | 42,545 |
| Less: amounts representing interest | ​ |  | 2,321 |  |  | 11,144 |
| Present value of net minimum lease payments | ​ | $ | 20,580 |  | ​ | 31,401 |
| Less: current portion of lease obligations | ​ |  | 4,571 |  | ​ | 1,866 |
| Non-current portion of lease obligations | ​ |  | 16,009 |  | ​ | 29,535 |
| ROU assets | ​ | $ | 20,209 |  | ​ | 28,619 |

[0001104659-20-012461:notes:87]
Operating lease liabilities are included in the Consolidated Balance Sheet in accrued other expenses and operating lease liabilities. Finance lease liabilities are included in accrued other expenses and other liabilities. Operating lease ROU assets are included as a caption on the Consolidated Balance Sheet and finance lease ROU assets are included in Property, plant and equipment on the Consolidated Balance sheets.

[0001104659-20-012461:notes:88]
As the Company has not restated prior-year information for the adoption of ASC 842, the following presents the Company’s future minimum lease payments for operating and capital leases under ASC 840 for continuing operations as of September 30, 2019:

[0001104659-20-012461:notes:89]
| (Dollars in thousands) |  | Operating |  | Finance |
| Years Ending September 30: |  | Leases |  | Leases |
| 2020 | ​ | $ | 5,574 |  | ​ | 2,518 |
| 2021 | ​ |  | 4,558 |  | ​ | 2,930 |
| 2022 | ​ |  | 3,950 |  | ​ | 3,012 |
| 2023 | ​ |  | 3,270 |  | ​ | 3,094 |
| 2024 and thereafter | ​ |  | 8,443 |  | ​ | 31,499 |
| Total minimum lease payments | ​ | $ | 25,795 |  | ​ | 43,053 |
| Less: amounts representing interest | ​ |  | * |  | ​ | 11,241 |
| Present value of net minimum lease payments | ​ |  | * |  | ​ | 31,812 |
| Less: Current portion of lease obligations | ​ |  | * |  | ​ | 1,832 |
| Non-current portion of lease obligations | ​ |  | * |  | ​ | 29,980 |

[0001104659-20-012461:notes:90]
* Not applicable for operating leases
