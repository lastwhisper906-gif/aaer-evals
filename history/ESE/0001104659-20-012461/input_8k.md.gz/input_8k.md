# ESE 8-K — 0001104659-20-010640 filed 2020-02-04

## item codes, every 8-K on or before 2020-02-07

- 2020-02-04 0001104659-20-010640 — 2.02, 5.07, 7.01, 9.01
- 2020-01-07 0001104659-20-001789 — 2.01, 9.01
- 2019-11-19 0001104659-19-065437 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2019-11-18 0001104659-19-065096 — 1.01, 2.02, 7.01, 9.01
- 2019-09-30 0001144204-19-046523 — 1.01, 1.02, 2.03, 9.01
- 2019-08-08 0001144204-19-038567 — 2.02, 7.01, 9.01
- 2019-05-07 0001144204-19-024241 — 2.02, 5.02, 7.01, 9.01
- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2020-02-07

- none on or before 2020-02-07

## item 2.02 — earnings release, exhibit 99.1

[0001104659-20-010640:8k_2_02:1]
EX-99.1
2
tm206611d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-20-010640:8k_2_02:2]
EXHIBIT 99.1

[0001104659-20-010640:8k_2_02:3]
| NEWS FROM |  |

[0001104659-20-010640:8k_2_02:4]
For more information contact:

[0001104659-20-010640:8k_2_02:5]
Kate Lowrey

[0001104659-20-010640:8k_2_02:6]
Director, Investor Relations

[0001104659-20-010640:8k_2_02:7]
ESCO Technologies Inc.

[0001104659-20-010640:8k_2_02:8]
(314)
213-7277

[0001104659-20-010640:8k_2_02:9]
ESCO
ANNOUNCES FIRST QUARTER FISCAL 2020 RESULTS

[0001104659-20-010640:8k_2_02:10]
- GAAP
EPS $3.32 (Includes Technical Packaging Gain on Sale) -

[0001104659-20-010640:8k_2_02:11]
- Adjusted
EPS $0.43 (Tops Guidance and Consensus) -

[0001104659-20-010640:8k_2_02:12]
ST.
LOUIS, February 4, 2020 – ESCO Technologies Inc. (NYSE: ESE) (ESCO, or the Company)
today reported its operating results for the first quarter ended December 31, 2019 (Q1 2020) compared to the first quarter ended
December 31, 2018 (Q1 2019).

[0001104659-20-010640:8k_2_02:13]
On January
2, 2020, the Company announced that it had completed the sale of its Technical Packaging segment effective December 31, 2019 which
resulted in gross cash proceeds of $191 million ($187 million purchase price plus working capital surplus) and a $77 million,
or $2.93 per share net gain on the sale.

[0001104659-20-010640:8k_2_02:14]
The Technical
Packaging segment’s operating results and the gain on the sale are presented as Discontinued Operations in the attached
tables, and are excluded from the following discussion of the Company’s results from Continuing Operations for the comparable
periods.

[0001104659-20-010640:8k_2_02:15]
The
financial results presented include certain non-GAAP financial measures such as EBIT, EBITDA,
Adjusted EBITDA and Adjusted EPS, as defined within the “Non-GAAP Financial Measures” described below. Any non-GAAP
financial measures presented are reconciled to their respective GAAP equivalents.

[0001104659-20-010640:8k_2_02:16]
Management
believes these non-GAAP financial measures are useful in assessing the ongoing operational
profitability of the Company’s business segments, and therefore, allow shareholders better visibility into the Company’s
underlying operations. See “Non-GAAP Financial Measures” described below.

[0001104659-20-010640:8k_2_02:17]
Filtration
/ Fluid Flow Segment Renamed

[0001104659-20-010640:8k_2_02:18]
With the
addition of Globe Composite LLC (Globe) in Q4 2019, and in conjunction with the divestiture of the Technical Packaging segment,
beginning in Q1 2020, Management has renamed the Filtration / Fluid Flow (Filtration) segment as Aerospace & Defense (A&D)
to better reflect the composition of the segment’s products, end markets and customer characteristics.

[0001104659-20-010640:8k_2_02:19]
The A&D
segment’s individual legal and operating entities, historical financial results, and management structure are unchanged
from what was formerly presented as Filtration.

[0001104659-20-010640:8k_2_02:20]
Earnings
Summary

[0001104659-20-010640:8k_2_02:21]
Q1 2020 GAAP
EPS of $3.32 per share included $0.41 per share from continuing operations and $2.91 per share from discontinued operations ($2.93
per share gain on the sale offset by a ($0.02) per share operating loss). Additionally, Q1 2020 GAAP EPS from continuing operations
included $0.02 per share of charges related to discrete cost reduction actions (primarily Doble facility move costs) which were
excluded when determining Q1 2020 Adjusted EPS of $0.43 per share. Q1 2020 GAAP net earnings were $87 million.

[0001104659-20-010640:8k_2_02:22]
Q1 2019 GAAP
EPS of $0.66 per share included $0.20 per share of discrete items resulting from the gain on the sale of the Doble headquarters
building, partially offset by discrete cost reduction actions described in prior releases. The net effect of excluding the $0.20
per share of discrete items resulted in Q1 2019 Adjusted EPS of $0.46 per share. Q1 2019 GAAP net earnings were $17 million.

[0001104659-20-010640:8k_2_02:23]
Q1 2020 Adjusted
EPS of $0.43 exceeded Management’s previously communicated guidance of $0.35 to $0.40 per share, driven by better than expected
operating performance in the Test and A&D segments.

[0001104659-20-010640:8k_2_02:24]
Q1 2020 Adjusted
EBITDA was $28.0 million, an increase of 5 percent over Q1 2019 Adjusted EBITDA of $26.7 million, led by Test and A&D which
increased 30 percent and 18 percent, respectively.

[0001104659-20-010640:8k_2_02:25]
Operating
Highlights

[0001104659-20-010640:8k_2_02:26]
|  | · | Net sales increased 5 percent to $172 million in Q1 2020 compared to $163 million in Q1 2019. |

[0001104659-20-010640:8k_2_02:27]
|  | · | On a segment basis, Q1 2020 A&D sales increased 17 percent from Q1 2019, including $9 million in sales from the Globe acquisition together with strong contributions from PTI, Crissair, and Vacco. Test sales increased nominally as a result of the quarterly timing on large project milestones, and USG sales decreased $3 million as a result of the timing of product deliveries. |

[0001104659-20-010640:8k_2_02:28]
|  | · | SG&A expenses increased in Q1 2020 as a result of higher spending on R&D / new product development, additional sales commissions, normal cost of living adjustments, and the addition of Globe. |

[0001104659-20-010640:8k_2_02:29]
|  | · | Entered orders were $220 million in Q1 2020 (book-to-bill of 1.28x), an increase of 23 percent over Q1 2019 orders of $179 million, resulting in an ending backlog of $500 million at December 31, 2019, an increase of $48 million, or 11 percent, from September 30, 2019. |

[0001104659-20-010640:8k_2_02:30]
|  | · | The effective income tax rate from continuing operations (GAAP and Adjusted) was 25 percent in Q1 2020. Management estimates future cash tax payments related to the sale of the Technical Packaging segment to be approximately $26 million. |

[0001104659-20-010640:8k_2_02:31]
|  | · | Q1 2020 net cash provided by operating activities from Continuing Operations of $3 million, coupled with the cash proceeds from the sale of the Technical Packaging segment, resulted in $53 million of net debt outstanding (total borrowings, less cash on hand) at December 31 2019 with a 0.92x leverage ratio. Operating cash flow for Q1 2020 was negatively impacted by the timing of cash receipts between December 2019 and January 2020. |

[0001104659-20-010640:8k_2_02:32]
Chairman’s
Commentary – Q1 2020

[0001104659-20-010640:8k_2_02:33]
Vic
Richey, Chairman and Chief Executive Officer, commented, “The clear highlight of Q1
2020 is that we completed the sale of our Technical Packaging segment at the end of December and received approximately $190 million
while recording a large gain on the sale, all while delivering operating results 3 cents above the top end of our guidance for
Adjusted EPS.

[0001104659-20-010640:8k_2_02:34]
“We
received the cash from the divestiture on the last day of the Quarter, and the proceeds were used to pay down a substantial portion
of our outstanding debt and to reduce our leverage ratio. We plan to use this additional liquidity and our substantial debt capacity
to fund future acquisitions and grow our business as we continue to evaluate a robust pipeline of M&A opportunities and expect
to add to our current portfolio during 2020.

[0001104659-20-010640:8k_2_02:35]
“On
the operational side, we delivered solid results during the Quarter as we exceeded our sales, Adjusted EBITDA, and Adjusted EPS
targets set at the start of the year. Our Test and A&D businesses contributed to our enhanced performance as both segments’
results exceeded their targets, and more than offset the timing-related sales and Adjusted EBITDA shortfall noted in USG.

[0001104659-20-010640:8k_2_02:36]
“Globe
continues to deliver results above expectations and its outlook appears to be gaining momentum such that we now believe this business
may provide future contributions greater than our forecast at the time of acquisition. Recent new wins for additional content
on navy submarines, both Virginia and Columbia Class, give me confidence that Globe’s growth prospects may materialize sooner
than expected.

[0001104659-20-010640:8k_2_02:37]
“We
improved our consolidated Q1 2020 Adjusted EBITDA by 5 percent and maintained our margins above 16 percent despite the lower contribution
from our highest margin segment. Our entered orders were strong as we booked $220 million of new business and grew our backlog
from the start of the year by 11 percent to $500 million, which sets us up nicely for our projected growth over the remainder
of the year.

[0001104659-20-010640:8k_2_02:38]
“The
Doble headquarters relocation was completed in November and I’m thrilled with the feedback from our staff as to how smooth
the integration went and how energized everyone is to be in the new location. I’m certain this move will further enhance
our operational efficiency and effectiveness.

[0001104659-20-010640:8k_2_02:39]
“The
recent news surrounding the suspended production of the 737MAX creates some headwind for us over the next few months until production
resumes, but given that our OEM sales content on that platform is relatively modest, we believe we can absorb the earnings impact
over the remainder of the year as we have well-defined opportunities across the A&D segment to mitigate this shortfall.

[0001104659-20-010640:8k_2_02:40]
“We
plan to build on the successes of Q1 and expect to continue benefitting from our disciplined operating culture throughout 2020.
By narrowing our focus and simplifying the business with the recent divestiture, coupled with our solid market positions and tangible
growth opportunities across the Company, I have a favorable view of the future with our goal remaining unchanged – to increase
long-term shareholder value.”

[0001104659-20-010640:8k_2_02:41]
Dividend
Payment

[0001104659-20-010640:8k_2_02:42]
The
next quarterly cash dividend of $0.08 per share will be paid on April 17, 2020 to stockholders of record on April 2, 2020.

[0001104659-20-010640:8k_2_02:43]
Business
Outlook – 2020 Adjusted Basis

[0001104659-20-010640:8k_2_02:44]
The Technical
Packaging business segment’s results of operations, gain on sale, balance sheet and cash flows are reported as Discontinued
Operations, and therefore, are excluded from the following discussion.

[0001104659-20-010640:8k_2_02:45]
As previously
described, Management plans to use a portion of the net proceeds during 2020 to fully fund, terminate, and annuitize the defined
benefit pension plan currently maintained by the Company. Annuitizing this non-strategic liability through an insurance company
will eliminate both equity market risk and interest rate volatility, thereby reducing our costs and eliminating future cash payments.
The defined benefit plan was frozen in 2003 and no additional benefits have been accrued since that date. The accounting impact
of terminating and annuitizing the pension will also be excluded from the calculation of Adjusted EBITDA and Adjusted EPS.

[0001104659-20-010640:8k_2_02:46]
Management
continues to see meaningful net sales and Adjusted EBITDA growth across each of the Company’s business segments and anticipates
growth rates in 2020 and beyond that will generally exceed the broader industrial market. The growth described below is expected
to be enhanced by additional M&A contributions during the year.

[0001104659-20-010640:8k_2_02:47]
Management’s
expectations for growth in 2020 compared to 2019 are consistent with the details outlined in the November 19, 2019 release. The
highlights are summarized here:

[0001104659-20-010640:8k_2_02:48]
|  | · | Management continues to expect 2020 Adjusted EPS to be in the range of $3.20 to $3.30 per share (compared to 2019 Adjusted EPS of $2.95 per share from Continuing Operations). |

[0001104659-20-010640:8k_2_02:49]
|  | · | This increase reflects meaningful sales and Adjusted EBITDA growth, partially offset by the additional depreciation and amortization charges and incremental tax expense described previously. |

[0001104659-20-010640:8k_2_02:50]
On
a quarterly basis and consistent with prior years, Management expects 2020 revenues and Adjusted EPS to be more back half weighted
resulting in the second half of the year being stronger than the first half.

[0001104659-20-010640:8k_2_02:51]
Management
expects Q2 2020 Adjusted EPS to be in the range of $0.70 to $0.75 per share, compared to Q2 2019 Adjusted EPS from Continuing
Operations of $0.71 per share. The timing of quarterly sales and earnings throughout the year, coupled with the discrete charges
incurred within the respective quarters will impact quarterly comparability.

[0001104659-20-010640:8k_2_02:52]
Conference
Call

[0001104659-20-010640:8k_2_02:53]
The Company
will host a conference call today, February 4, at 4:00 p.m. Central Time, to discuss the Company’s Q1 2020 results. A live
audio webcast will be available on the Company’s website at www.escotechnologies.com. Please access the website at
least 15 minutes prior to the call to register, download and install any necessary audio software. A replay of the conference
call will be available on the Company’s website noted above or by phone (dial 1-855-859-2056 and enter the pass code 2159900).

[0001104659-20-010640:8k_2_02:54]
Forward-Looking
Statements

[0001104659-20-010640:8k_2_02:55]
Statements
in this press release regarding the timing and amounts of the Company’s expected quarterly,
2020 full year and beyond results, revenue and sales growth, sales, EPS, Adjusted EPS, EPS growth, cash, EBIT, Adjusted EBITDA
margins, Adjusted EBITDA, interest expense, income tax expense, effective tax rate, non-cash depreciation and amortization of
intangible assets, liquidity, actions in regard to the Company’s frozen defined benefit plan, the realization of operational
efficiencies, the Company’s competitiveness , the Company’s ability to increase operating margins, realize financial
goals and increase shareholder value, the success of acquisition efforts, the use of proceeds from the recent divestiture, the
long-term success of the Company, and any other statements which are not strictly historical are “forward-looking”
statements within the meaning of the safe harbor provisions of the federal securities laws.

[0001104659-20-010640:8k_2_02:56]
Investors
are cautioned that such statements are only predictions and speak only as of the date of this release, and the Company undertakes
no duty to update them except as may be required by applicable laws or regulations. The Company’s actual results in the
future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist
in the Company’s operations and business environment including but not limited to those described in Item 1A, “Risk
Factors”, of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2019,
and the following: weakening of economic conditions in served markets; changes in customer demands or customer insolvencies; competition;
intellectual property rights; technical difficulties; delivery delays or defaults by customers; material changes in the costs
and availability of certain raw materials; the appropriation, allocation and availability of Government funds; the termination
for convenience of Government and other customer contracts; the timing and content of future contract awards or customer orders;
performance issues with key customers, suppliers and subcontractors; labor disputes; the impacts of natural disasters on the Company’s
operations and those of the Company’s customers and suppliers; changes in laws and regulations, including but not limited
to changes in accounting standards, taxation requirements, and new or modified tariffs; changes in interest rates; costs relating
to environmental matters arising from current or former facilities; financial exposure in connection with Company guarantees of
certain Aclara contracts; the availability of select acquisitions; and the uncertainty regarding the ultimate resolution of current
disputes, claims, litigation or arbitration.

[0001104659-20-010640:8k_2_02:57]
Non-GAAP
Financial Measures

[0001104659-20-010640:8k_2_02:58]
The
financial measures EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS are presented in this press
release. The Company defines “EBIT” as earnings before interest and taxes, “EBITDA” as earnings before
interest, taxes, depreciation and amortization, “Adjusted EBITDA” as EBITDA excluding certain defined charges, and
 “Adjusted EPS” as GAAP earnings per share (EPS) excluding the net impact of the items described above which were $0.02
per share in Q1 2020.

[0001104659-20-010640:8k_2_02:59]
EBIT,
EBITDA, Adjusted EBITDA and Adjusted EPS are not recognized in accordance with U.S. generally
accepted accounting principles (GAAP). However, Management believes that EBIT, EBITDA and Adjusted EBITDA are useful in assessing
the operational profitability of the Company’s business segments because they exclude interest, taxes, depreciation and
amortization, which are generally accounted for across the entire Company on a consolidated basis. EBIT is also one of the measures
used by Management in determining resource allocations within the Company as well as incentive compensation. The presentation
of EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS provides important supplemental information to investors by facilitating comparisons
with other companies, many of which use similar non-GAAP financial measures to supplement their GAAP results. The use of non-GAAP
financial measures is not intended to replace any measures of performance determined in accordance with GAAP.

[0001104659-20-010640:8k_2_02:60]
ESCO, headquartered
in St. Louis, Missouri: Manufactures highly-engineered filtration and fluid control products for the aviation, navy, space and
process markets worldwide, as well as composite-based products and solutions for navy, defense and industrial customers; is the
industry leader in RF shielding and EMC test products; and provides diagnostic instruments, software and services for the benefit
of industrial power users and the electric utility and renewable energy industries. Further information regarding ESCO and its
subsidiaries is available on the Company’s website at www.escotechnologies.com.

[0001104659-20-010640:8k_2_02:61]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-20-010640:8k_2_02:62]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-20-010640:8k_2_02:63]
(Dollars in thousands, except per share amounts)

[0001104659-20-010640:8k_2_02:64]
|  |  | Three Months Ended December 31, 2019 |  |  | Three Months Ended December 31, 2018 |  |
| Net Sales |  | $ | 171,728 |  |  |  | 163,365 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 106,727 |  |  |  | 102,454 |  |
| Selling, general and administrative expenses |  |  | 42,105 |  |  |  | 38,540 |  |
| Amortization of intangible assets |  |  | 5,810 |  |  |  | 4,400 |  |
| Interest expense |  |  | 2,421 |  |  |  | 1,855 |  |
| Other expenses (income), net |  |  | 295 |  |  |  | (7,379 | ) |
| Total costs and expenses |  |  | 157,358 |  |  |  | 139,870 |  |
| Earnings before income taxes |  |  | 14,370 |  |  |  | 23,495 |  |
| Income tax expense |  |  | 3,606 |  |  |  | 6,145 |  |
| Earnings from continuing operations |  |  | 10,764 |  |  |  | 17,350 |  |
| Loss from discontinued operations, net of tax expense (benefit) of $269 and $(205) |  |  | (601 | ) |  |  | (33 | ) |
| Gain on sale of discontinued operations, net of tax expense of $23,734 |  |  | 76,614 |  |  |  | 0 |  |
| Earnings (loss) from discontinued operations |  |  | 76,013 |  |  |  | (33 | ) |
| Net earnings |  | $ | 86,777 |  |  |  | 17,317 |  |
| Diluted EPS: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.41 |  |  |  | 0.66 |  |
| Discontinued operations |  |  | 2.91 |  |  |  | 0.00 |  |
| Net earnings |  | $ | 3.32 |  |  |  | 0.66 |  |
| Diluted - As Adjusted Basis |  |  |  |  |  |  |  |  |
| Continuing operations |  |  | $0.43 | (1) |  |  | 0.46 | (2) |
| Diluted average common shares O/S: |  |  | 26,168 |  |  |  | 26,120 |  |

[0001104659-20-010640:8k_2_02:65]
| (1) | Q1 2020 Adjusted EPS excludes $0.02 per share of after-tax charges primarily related to the move of the Doble headquarters facility. |
| (2) | Q1 2019 Adjusted EPS excludes $0.20 per share of after-tax income mainly resulting from the gain on the sale of the Doble Watertown property partially offset by certain restructuring charges primarily at Doble. |

[0001104659-20-010640:8k_2_02:66]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-20-010640:8k_2_02:67]
Condensed Business Segment Information (Unaudited)

[0001104659-20-010640:8k_2_02:68]
(Dollars in thousands)

[0001104659-20-010640:8k_2_02:69]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | Q1 2020 |  |  | Q1 2019 |  |  | Q1 2020 |  |  | Q1 2019 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 77,511 |  |  |  | 66,224 |  |  |  | 77,511 |  |  |  | 66,224 |  |
| Test |  |  | 41,383 |  |  |  | 41,286 |  |  |  | 41,383 |  |  |  | 41,286 |  |
| USG |  |  | 52,834 |  |  |  | 55,855 |  |  |  | 52,834 |  |  |  | 55,855 |  |
| Totals |  | $ | 171,728 |  |  |  | 163,365 |  |  |  | 171,728 |  |  |  | 163,365 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 12,513 |  |  |  | 10,610 |  |  |  | 12,583 |  |  |  | 10,707 |  |
| Test |  |  | 4,656 |  |  |  | 3,310 |  |  |  | 4,656 |  |  |  | 3,310 |  |
| USG |  |  | 9,288 |  |  |  | 21,546 |  |  |  | 9,908 |  |  |  | 13,859 |  |
| Corporate |  |  | (9,666 | ) |  |  | (10,116 | ) |  |  | (9,666 | ) |  |  | (9,751 | ) |
| Consolidated EBIT |  |  | 16,791 |  |  |  | 25,350 |  |  |  | 17,481 |  |  |  | 18,125 |  |
| Less: Interest expense |  |  | (2,421 | ) |  |  | (1,855 | ) |  |  | (2,421 | ) |  |  | (1,855 | ) |
| Less: Income tax expense |  |  | (3,606 | ) |  |  | (6,145 | ) |  |  | (3,772 | ) |  |  | (4,200 | ) |
| Net earnings from continuing ops |  | $ | 10,764 |  |  |  | 17,350 |  |  |  | 11,288 |  |  |  | 12,070 |  |

[0001104659-20-010640:8k_2_02:70]
Note 1: The tables on this page are presented on a continuing operations basis.

[0001104659-20-010640:8k_2_02:71]
Note 2: Adjusted net earnings were $11.3 million in Q1 20 which excluded $0.02 per share of after-tax charges primarily related to the facility move costs at Doble.

[0001104659-20-010640:8k_2_02:72]
Note 3: Adjusted net earnings were $12.1 million in Q1 19 which excluded $0.20 per share of after-tax income primarily related to the Q1 19 gain on the sale of the Doble Watertown facility partially offset by charges related to other restructuring actions.

[0001104659-20-010640:8k_2_02:73]
EBITDA
    Reconciliation to Net earnings:

[0001104659-20-010640:8k_2_02:74]
|  |  |  |  |  | Q1 2020 |  |  |  |  |  | Q1 2019 |  |
|  |  | Q1 2020 |  |  | - As Adj |  |  | Q1 2019 |  |  | - As Adj |  |
| Consolidated EBITDA |  | $ | 27,331 |  |  |  | 28,021 |  |  |  | 33,904 |  |  |  | 26,679 |  |
| Less: Depr & Amort |  |  | (10,540 | ) |  |  | (10,540 | ) |  |  | (8,554 | ) |  |  | (8,554 | ) |
| Consolidated EBIT |  |  | 16,791 |  |  |  | 17,481 |  |  |  | 25,350 |  |  |  | 18,125 |  |
| Less: Interest expense |  |  | (2,421 | ) |  |  | (2,421 | ) |  |  | (1,855 | ) |  |  | (1,855 | ) |
| Less: Income tax expense |  |  | (3,606 | ) |  |  | (3,772 | ) |  |  | (6,145 | ) |  |  | (4,200 | ) |
| Net earnings |  | $ | 10,764 |  |  |  | 11,288 |  |  |  | 17,350 |  |  |  | 12,070 |  |

[0001104659-20-010640:8k_2_02:75]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-20-010640:8k_2_02:76]
Condensed Consolidated Balance Sheets (Unaudited)

[0001104659-20-010640:8k_2_02:77]
(Dollars in thousands)

[0001104659-20-010640:8k_2_02:78]
|  |  | December 31, 2019 |  |  | September 30, 2019 |  |
| Assets |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 96,692 |  |  |  | 61,808 |  |
| Accounts receivable, net |  |  | 160,714 |  |  |  | 158,715 |  |
| Contract assets |  |  | 93,498 |  |  |  | 110,211 |  |
| Inventories |  |  | 133,977 |  |  |  | 124,956 |  |
| Other current assets |  |  | 13,417 |  |  |  | 14,190 |  |
| Assets of discontinued operations-current |  |  | - |  |  |  | 25,314 |  |
| Total current assets |  |  | 498,298 |  |  |  | 495,194 |  |
| Property, plant and equipment, net |  |  | 135,576 |  |  |  | 127,843 |  |
| Intangible assets, net |  |  | 378,248 |  |  |  | 381,605 |  |
| Goodwill |  |  | 390,383 |  |  |  | 390,256 |  |
| Operating lease assets |  |  | 20,209 |  |  |  | - |  |
| Other assets |  |  | 8,855 |  |  |  | 4,445 |  |
| Assets of discontinued operations-other |  |  | - |  |  |  | 67,377 |  |
|  |  | $ | 1,431,569 |  |  |  | 1,466,720 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt |  | $ | 20,000 |  |  |  | 20,000 |  |
| Accounts payable |  |  | 53,056 |  |  |  | 63,800 |  |
| Contract liabilities |  |  | 84,813 |  |  |  | 81,177 |  |
| Other current liabilities |  |  | 94,161 |  |  |  | 75,141 |  |
| Liabilities of discontinued operations-current |  |  | - |  |  |  | 11,517 |  |
| Total current liabilities |  |  | 252,030 |  |  |  | 251,635 |  |
| Deferred tax liabilities |  |  | 60,486 |  |  |  | 60,856 |  |
| Non-current operating lease liabilities |  |  | 16,009 |  |  |  | - |  |
| Other liabilities |  |  | 57,553 |  |  |  | 59,008 |  |
| Long-term debt |  |  | 130,000 |  |  |  | 265,000 |  |
| Liabilities of discontinued operations-other |  |  | - |  |  |  | 3,999 |  |
| Shareholders' equity |  |  | 915,491 |  |  |  | 826,222 |  |
|  |  | $ | 1,431,569 |  |  |  | 1,466,720 |  |

[0001104659-20-010640:8k_2_02:79]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-20-010640:8k_2_02:80]
Consolidated Statements of Cash Flows (Unaudited)

[0001104659-20-010640:8k_2_02:81]
(Dollars in thousands)

[0001104659-20-010640:8k_2_02:82]
|  |  | Three Months Ended December 31, 2019 |  |
| Cash flows from operating activities: |  |  |  |  |
| Net earnings |  | $ | 86,777 |  |
| Earnings from discontinued operations |  |  | (76,013 | ) |
| Adjustments to reconcile net earnings to net cash provided by operating activities: |  |  |  |  |
| Depreciation and amortization |  |  | 10,540 |  |
| Stock compensation expense |  |  | 1,446 |  |
| Changes in assets and liabilities |  |  | (19,051 | ) |
| Effect of deferred taxes |  |  | (370 | ) |
| Net cash provided by operating activities - continuing operations |  |  | 3,329 |  |
| Net cash used by operating activities -discontinued operations |  |  | (622 | ) |
| Net cash provided by operating activities |  |  | 2,707 |  |
| Cash flows from investing activities: |  |  |  |  |
| Capital expenditures |  |  | (12,647 | ) |
| Additions to capitalized software |  |  | (1,923 | ) |
| Net cash used by investing activities - continuing operations |  |  | (14,570 | ) |
| Proceeds from sale of discontinued operations |  |  | 183,997 |  |
| Capital expenditures - discontinued operations |  |  | (1,728 | ) |
| Net cash provided by investing activities - discontinued operations |  |  | 182,269 |  |
| Net cash provided by investing activities |  |  | 167,699 |  |
| Cash flows from financing activities: |  |  |  |  |
| Proceeds from long-term debt |  |  | 10,000 |  |
| Principal payments on long-term debt |  |  | (145,000 | ) |
| Dividends paid |  |  | (2,079 | ) |
| Net cash used by financing activities - continuing operations |  |  | (137,079 | ) |
| Net cash used by financing activities - discontinued operations |  |  | (2,140 | ) |
| Net cash used by financing activities |  |  | (139,219 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 3,697 |  |
| Net increase in cash and cash equivalents |  |  | 34,884 |  |
| Cash and cash equivalents, beginning of period |  |  | 61,808 |  |
| Cash and cash equivalents, end of period |  | $ | 96,692 |  |

[0001104659-20-010640:8k_2_02:83]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-20-010640:8k_2_02:84]
Other Selected Financial Data (Unaudited)  -- Continuing Operations Basis

[0001104659-20-010640:8k_2_02:85]
(Dollars in thousands)

[0001104659-20-010640:8k_2_02:86]
| Backlog And Entered Orders - Q1 FY 2020 |  | Aerospace & Defense |  |  | Test |  |  | USG |  |  | Total |  |
| Beginning Backlog - 10/1/19 |  | $ | 276,273 |  |  |  | 133,571 |  |  |  | 41,715 |  |  |  | 451,559 |  |
| Entered Orders |  |  | 129,022 |  |  |  | 38,513 |  |  |  | 52,904 |  |  |  | 220,439 |  |
| Sales |  |  | (77,511 | ) |  |  | (41,383 | ) |  |  | (52,834 | ) |  |  | (171,728 | ) |
| Ending Backlog - 12/31/19 |  | $ | 327,784 |  |  |  | 130,701 |  |  |  | 41,785 |  |  |  | 500,270 |  |

[0001104659-20-010640:8k_2_02:87]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-20-010640:8k_2_02:88]
Reconciliation of Non-GAAP Financial Measures (Unaudited)

[0001104659-20-010640:8k_2_02:89]
| EPS – Adjusted Basis Reconciliation – Q1 FY 2020 |  |  |  |  |
| EPS from Continuing Ops – GAAP Basis – Q1 2020 |  | $ | 0.41 |  |
| Adjustments (defined below) |  |  | 0.02 |  |
| EPS from Continuing Ops – As Adjusted Basis – Q1 2020 |  | $ | 0.43 |  |

[0001104659-20-010640:8k_2_02:90]
Adjustments exclude $0.02 per share consisting of move costs associated
with the  Doble facility consolidation in the first quarter of 2020.

[0001104659-20-010640:8k_2_02:91]
(The
$0.02 of EPS adjustments per share consists of $690K of pre-tax charges offset by $166K of tax benefit for net impact of $524K.)

[0001104659-20-010640:8k_2_02:92]
| EPS – Adjusted Basis Reconciliation – Q1 FY 2019 |  |  |  |
| EPS from Continuing Ops – GAAP Basis – Q1 FY 2019 |  | $ | 0.66 |  |
| Adjustments (defined below) |  |  | (0.20 | ) |
| EPS from Continuing Ops – As Adjusted Basis – Q1 FY 2019 |  | $ | 0.46 |  |

[0001104659-20-010640:8k_2_02:93]
Adjustments
exclude $0.20 per share consisting of income related to the gain on sale of the Doble Watertown property partially offset by
certain restructuring charges primarily at Doble in the first quarter of 2019.

[0001104659-20-010640:8k_2_02:94]
(The $0.20 of EPS adjustments per share consists of $7.2 million of pre-tax
 income offset by $1.9 million of tax expense for net impact of $5.3 million.)

[0001104659-20-010640:8k_2_02:95]
| EPS – Adjusted Basis Reconciliation – Q2 FY 2019 |  |  |  |
| EPS from Continuing Ops – GAAP Basis – Q2 FY 2019 |  | $ | 0.68 |  |
| Adjustments (defined below) |  |  | 0.03 |  |
| EPS from Continuing Ops – As Adjusted Basis – Q2 FY 2019 |  | $ | 0.71 |  |

[0001104659-20-010640:8k_2_02:96]
Adjustments
exclude $0.03 per share consisting of restructuring charges  related to Doble, PTI & VACCO during the second
quarter of 2019.

[0001104659-20-010640:8k_2_02:97]
(The
$0.03 of EPS adjustments per share consists of $946K of pre-tax charges offset by $215K of tax benefit for net impact of $731K.)
