# ESE MD&A — 0001410578-24-001264


## mdna

[0001410578-24-001264:mdna:1]
[same as prior period, unchanged from 0001410578-24-000723:mdna:1]

[0001410578-24-001264:mdna:2]
[same as prior period, unchanged from 0001410578-24-000723:mdna:2]

[0001410578-24-001264:mdna:3]
References to the third quarters of 2024 and 2023 represent the three-month periods ended June 30, 2024 and 2023, respectively.

[0001410578-24-001264:mdna:4]
[same as prior period, unchanged from 0001410578-24-000723:mdna:4]

[0001410578-24-001264:mdna:5]
In the third quarter of 2024, sales, net earnings and diluted earnings per share were $260.8 million, $29.2 million and $1.13 per share, respectively, compared to $248.7 million, $27.9 million and $1.08 per share, respectively, in the third quarter of 2023. In the first nine months of 2024, sales, net earnings and diluted earnings per share were $728.2 million, $67.6 million and $2.62 per share, respectively, compared to $683.4 million, $60.5 million and $2.34 per share, respectively, in the first nine months of 2023.

[0001410578-24-001264:mdna:6]
[same as prior period, unchanged from 0001410578-24-000723:mdna:6]

[0001410578-24-001264:mdna:7]
In the third quarter of 2024, net sales of $260.8 million were $12.1 million, or 4.8%, higher than the $248.7 million in the third quarter of 2023. In the first nine months of 2024, net sales of $728.2 million were $44.8 million, or 6.6%, higher than the $683.4 million in the first nine months of 2023. The increase in net sales in the third quarter of 2024 as compared to the third quarter of 2023 was due to an $11.0 million increase in the A&D segment, a $0.8 million increase in the Test segment, and a $0.3 million increase in the USG segment. The increase in net sales in the first nine months of 2024 as compared to the first nine months of 2023 was due to a $38.5 million increase in the A&D segment, and a $20.4 million increase in the USG segment, partially offset by a $14.0 million decrease in the Test segment.

[0001410578-24-001264:mdna:8]
[same as prior period, unchanged from 0001410578-24-000723:mdna:8]

[0001410578-24-001264:mdna:9]
In the third quarter of 2024, net sales of $114.5 million were $11.0 million, or 10.6%, higher than the $103.5 million in the third quarter of 2023. In the first nine months of 2024, net sales of $323.9 million were $38.5 million, or 13.5%, higher than the $285.4 million in the first nine months of 2023. The sales increase in the third quarter of 2024 compared to the third quarter of 2023 was mainly due to a $2.3 million increase in commercial aerospace shipments, a $2.1 million increase in defense aerospace shipments and an $8.1 million increase in navy revenues, partially offset by a $1.5 million decrease in industrial revenues. The sales increase in the first nine months of 2024 compared to the first nine months of 2023 was mainly due to a $10.0 million increase in commercial aerospace shipments, an $8.0 million increase in defense aerospace shipments, an $18.1 million increase in navy revenues and a $1.8 million increase in space revenues.

[0001410578-24-001264:mdna:10]
[same as prior period, unchanged from 0001410578-24-000723:mdna:10]

[0001410578-24-001264:mdna:11]
In the third quarter of 2024, net sales of $90.3 million were $0.3 million, or 0.3%, higher than the $90.0 million in the third quarter of 2023. In the first nine months of 2024, net sales of $260.6 million were $20.4 million, or 8.5%, higher than the $240.2 million in the first nine months of 2023. The sales increase in the third quarter of 2024 as compared to the third quarter of 2023 was driven by higher service revenue at Doble partially offset by lower protection testing revenue. The sales increase in the first nine months of 2024 compared to the corresponding period of 2023 was mainly due to an increase in Doble’s service revenue, cybersecurity/compliance (DUCe) revenue and offline test revenue and an increase in net sales at NRG driven by continued strength in the renewables end-market, partially offset by a decrease in protection testing revenue at Doble.

[0001410578-24-001264:mdna:12]
[same as prior period, unchanged from 0001410578-24-000723:mdna:12]

[0001410578-24-001264:mdna:13]
In the third quarter of 2024, net sales of $56.1 million were $0.8 million, or 1.3%, higher than the $55.3 million in the third quarter of 2023. In the first nine months of 2024, net sales of $143.8 million were $14.0 million, or 8.9%, lower than the $157.8 million in the first nine months of 2023. The increase in the third quarter of 2024 as compared to the third quarter of 2023 was primarily due to a $4.4 million increase in sales from the segment’s European operations driven by the MPE acquisition partially offset by a $3.6 million decrease in sales from the Company’s U.S. and Asian operations due to lower wireless, filters and acoustic volumes. The decrease in the first nine months of 2024 compared to the first nine months of 2023 was due to a $13.7 million decrease in sales from the Company’s U.S. operations, and a $1.9 million decrease in sales from the Company’s Asian operations due to lower wireless, filters and acoustic volumes and timing of test and measurement chamber projects partially offset by a $1.6 million increase in sales from the segment’s European operations.

[0001410578-24-001264:mdna:14]
[same as prior period, unchanged from 0001410578-24-000723:mdna:14]

[0001410578-24-001264:mdna:15]
Backlog was $888.7 million at June 30, 2024 compared with $772.4 million at September 30, 2023. The Company received new orders totaling $311.7 million in the third quarter of 2024 compared to $213.3 million in the third quarter of 2023. Of the new orders received in the third quarter of 2024, $146.9 million related to Aerospace & Defense products, $100.0 million related to USG products, and $64.8 million related to Test products. Of the new orders received in the third quarter of 2023, $81.9 million related to Aerospace & Defense products, $85.5 million related to USG products, and $45.9 million related to Test products.

[0001410578-24-001264:mdna:16]
The Company received new orders totaling $844.5 million in the first nine months of 2024 compared to $693.8 million in the first nine months of 2023. Of the new orders received in the first nine months of 2024, $434.5 million related to Aerospace & Defense products, $256.0 million related to USG products, and $154.0 million related to Test products. Of the new orders received in the first nine months of 2023, $290.9 million related to Aerospace & Defense products, $250.3 million related to USG products, and $152.6 million related to Test products.

[0001410578-24-001264:mdna:17]
[same as prior period, unchanged from 0001410578-24-000723:mdna:18]

[0001410578-24-001264:mdna:18]
Selling, general and administrative (SG&A) expenses for the third quarter of 2024 were $55.0 million (21.1% of net sales), compared with $55.4 million (22.3% of net sales) for the third quarter of 2023. For the first nine months of 2024, SG&A expenses were $164.0 million (22.5% of net sales) compared to $160.6 million (23.5% of net sales) for the first nine months of 2023. The increase in SG&A in the first nine months of 2024 compared to the corresponding period of 2023 was mainly due to an increase within the USG and A&D segments due to higher sales, inflationary impacts and MPE acquisition impacts.

[0001410578-24-001264:mdna:19]
[same as prior period, unchanged from 0001410578-24-000723:mdna:20]

[0001410578-24-001264:mdna:20]
Amortization of intangible assets was $8.1 million and $24.6 million for the third quarter and first nine months of 2024, respectively, compared to $7.1 million and $21.0 million for the corresponding periods of 2023. Amortization expenses consist of amortization of acquired intangible assets from acquisitions and other identifiable intangible assets (primarily software). The increase in amortization expense in the third quarter and first nine months of 2024 compared to the corresponding periods of 2023 was mainly due to an increase in amortization of capitalized software and amortization of intangible assets related to the MPE and CMT acquisitions.

[0001410578-24-001264:mdna:21]
[same as prior period, unchanged from 0001410578-24-000723:mdna:22]

[0001410578-24-001264:mdna:22]
Other expenses (income), net, was ($0.3) million in the third quarter of 2024 compared to $1.0 million of expenses in the third quarter of 2023. Other expenses, net, was $0.6 million in the first nine months of 2024 compared to $1.7 million of expenses in the first nine months of 2023. The principal component of other expenses, net, in the first nine months of 2024 was approximately $0.9 million of restructuring charges (primarily severance) within all three segments. The principal items included in other expenses, net, in the third quarter and first nine months of 2023 included a bad debt write-off of $0.5 million due to a customer bankruptcy within the A&D segment and approximately $0.5 million of restructuring costs (mainly severance) in the first nine months of 2023.

[0001410578-24-001264:mdna:23]
[same as prior period, unchanged from 0001410578-24-000723:mdna:24]

[0001410578-24-001264:mdna:24]
The Company evaluates the performance of its operating segments based on EBIT, and provides EBIT on a consolidated basis. EBIT is a non-GAAP financial measure. Please refer to the discussion of non-GAAP financial measures in Note 7 to the Consolidated Financial Statements, above. EBIT was $40.5 million (15.5% of net sales) for the third quarter of 2024 compared to $38.0 million (15.3% of net sales) for the third quarter of 2023. For the first nine months of 2024, EBIT was $95.1 million (13.1% of net sales) compared to $84.2 million (12.3% of net sales) for the first nine months of 2023.

[0001410578-24-001264:mdna:25]
[same as prior period, unchanged from 0001410578-24-000723:mdna:26]

[0001410578-24-001264:mdna:26]
| ​ | ​ | Three Months Ended | ​ | Nine Months Ended |
| ​ | ​ | June 30, | ​ | June 30, |
| (In thousands) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net earnings | ​ | $ | 29,230 | ​ | ​ | 27,943 | ​ | 67,618 | ​ | 60,548 |
| Plus: Interest expense, net | ​ | ​ | 3,335 | ​ | ​ | 2,495 | ​ | 9,228 | ​ | 6,422 |
| Plus: Income tax expense | ​ | ​ | 7,942 | ​ | ​ | 7,563 | ​ | 18,229 | ​ | 17,207 |
| Consolidated EBIT | ​ | $ | 40,507 | ​ | ​ | 38,001 | ​ | 95,075 | ​ | 84,177 |

[0001410578-24-001264:mdna:27]
[same as prior period, unchanged from 0001410578-24-000723:mdna:28]

[0001410578-24-001264:mdna:28]
EBIT in the third quarter of 2024 was $21.4 million (18.7% of net sales) compared to $21.7 million (20.9% of net sales) in the third quarter of 2023. EBIT in the first nine months of 2024 was $61.4 million (19.0% of net sales) compared to $53.0 million (18.6% of net sales) in the first nine months of 2023. EBIT in the third quarter of 2024 was negatively impacted by margin erosion on space development programs at VACCO, revenue mix, and inflationary pressures, partially offset by leverage on higher sales volumes and price increases. The increase in EBIT in the first nine months of 2024 compared to the corresponding period of 2023 was mainly driven by leverage on higher sales volumes and price increases, partially offset by inflationary pressures and mix. EBIT was negatively impacted by $0.4 million of restructuring charges (primarily severance) in the third quarter and first nine months of 2024. EBIT in the first nine months of 2023 was negatively impacted by a $0.6 million inventory step-up charge related to the CMT acquisition.

[0001410578-24-001264:mdna:29]
[same as prior period, unchanged from 0001410578-24-000723:mdna:31]

[0001410578-24-001264:mdna:30]
EBIT in the third quarter of 2024 was $22.2 million (24.5% of net sales) compared to $20.4 million (22.6% of net sales) in the third quarter of 2023. EBIT in the first nine months of 2024 was $57.4 million (22.0% of net sales) compared to $50.5 million (21.0% of net sales) in the first nine months of 2023. The increase in EBIT in the third quarter and first nine months of 2024 compared to the corresponding periods of 2023 was mainly due to leverage on higher sales volumes at Doble and NRG, price increases and mix, partially offset by inflationary pressures. EBIT was negatively impacted by $0.2 million of restructuring charges (primarily severance) in the first nine months of 2024.

[0001410578-24-001264:mdna:31]
[same as prior period, unchanged from 0001410578-24-000723:mdna:33]

[0001410578-24-001264:mdna:32]
EBIT in the third quarter of 2024 was $9.3 million (16.6% of net sales) compared to $8.6 million (15.6% of net sales) in the third quarter of 2023. EBIT in the first nine months of 2024 was $16.6 million (11.6% of net sales) compared to $21.3 million (13.5% of net sales) in the first nine months of 2023. The increase in EBIT in the third quarter of 2024 as compared to the corresponding period of 2023 was mainly due to higher sales volumes from the segment’s European operations driven by the MPE acquisition. The decrease in EBIT in the first nine months of 2024 compared to the corresponding period of 2023 was primarily due to lower sales volumes mainly from the segment’s U.S and Asian operations and inflationary pressures partially offset by price increases and cost reduction actions. In the first nine months of 2024, EBIT was negatively impacted by $0.3 million of inventory step-up charges related to the MPE acquisition and $0.2 million of restructuring charges.

[0001410578-24-001264:mdna:33]
[same as prior period, unchanged from 0001410578-24-000723:mdna:35]

[0001410578-24-001264:mdna:34]
Corporate costs included in EBIT were $12.3 million and $40.3 million in the third quarter and first nine months of 2024, respectively, compared to $12.7 million and $40.6 million in the corresponding periods of 2023. The decrease in Corporate costs in the third quarter and first nine months of 2024 as compared to the corresponding prior year periods was mainly due to executive management transition costs that were incurred in the prior year period.

[0001410578-24-001264:mdna:35]
[same as prior period, unchanged from 0001410578-24-000723:mdna:37]

[0001410578-24-001264:mdna:36]
Interest expense was $3.3 million and $9.2 million in the third quarter and first nine months of 2024, respectively, and $2.5 million and $6.4 million in the corresponding periods of 2023. The increase in interest expense in the third quarter and first nine months of 2024 compared to the corresponding periods of 2023 was mainly due to higher average interest rates and higher average outstanding borrowings. The weighted average interest rates were 6.71% and 6.75% for the three and nine-month periods ending June 30, 2024, respectively, and 6.05% and 5.57% for the three and nine-month periods ending June 30, 2023.

[0001410578-24-001264:mdna:37]
[same as prior period, unchanged from 0001410578-24-000723:mdna:39]

[0001410578-24-001264:mdna:38]
The third quarter 2024 effective income tax rate was 21.4% compared to 21.3% in the third quarter of 2023. The effective income tax rate in the first nine months of 2024 was 21.2% compared to 22.1% for the first nine months of 2023. Income tax expense in the first nine months of 2024 was favorably impacted by discrete events that occurred during the second quarter of 2024 including the release of a foreign valuation allowance and excess tax benefit related to the vesting of share-based director compensation.

[0001410578-24-001264:mdna:39]
[same as prior period, unchanged from 0001410578-24-000723:mdna:41]

[0001410578-24-001264:mdna:40]
The Company’s overall financial position and liquidity remains strong. Working capital (current assets less current liabilities) increased to $341.7 million at June 30, 2024 from $266.4 million at September 30, 2023. Inventories increased by $35.2 million during this period due to a $16.0 million increase within the A&D segment, a $14.6 million increase within the USG segment and a $4.6 million increase within the Test segment resulting primarily from the timing of receipt of raw materials to meet anticipated demand and an increase in work in process and finished goods inventories due to timing of manufacturing existing orders. Accounts receivable increased by $15.0 million during this period mainly due to an approximately $9.0 million increase within the Test segment and an approximately $6.0 million increase within the A&D segment driven by timing of sales and collections.

[0001410578-24-001264:mdna:41]
Net cash provided by operating activities was $55.5 million and $29.2 million in the first nine months of 2024 and 2023, respectively. The increase in net cash provided by operating activities in the first nine months of 2024 as compared to the first nine months of 2023 was mainly driven by an increase in accounts receivable collections and higher earnings.

[0001410578-24-001264:mdna:42]
Capital expenditures were $24.9 million and $17.0 million in the first nine months of 2024 and 2023, respectively. The increase in the first nine months of 2024 compared to the prior year period was mainly due to an increase in building improvements and machinery & equipment within the A&D segment. In addition, the Company incurred expenditures for capitalized software of $8.6 million and $9.3 million in the first nine months of 2024 and 2023, respectively.

[0001410578-24-001264:mdna:43]
Subsequent Event

[0001410578-24-001264:mdna:44]
On July 8, 2024, the Company announced that it has agreed to acquire the Signature Management & Power (or the “Business”) business of Ultra Maritime for a purchase price of approximately $550 million.  The transaction will be funded through cash on hand and incremental debt, with committed financing in place. Signature Management & Power is a provider of mission-critical signature and power management solutions for submarines and surface ships for the U.S. and UK naval defense markets.  The Business is headquartered in Long Island, New York, operates out of four facilities based in the U.S. and the UK, and has approximately 410 employees.  Signature Management & Power will become part of ESCO’s Aerospace & Defense segment and is expected to have approximately $175 million of revenue in calendar year 2024.  The closing of the transaction is subject to certain conditions, including the (i) expiration or termination of the applicable waiting period under the Hart-Scott-Rodino Antitrust Improvements Act of 1976 in the U.S. and (ii) receipt of clearance under the UK National Security and Investment Act of 2021.

[0001410578-24-001264:mdna:45]
Pursuant to a Commitment Letter entered into on July 8, 2024 between the Company and JPMorgan Chase Bank, N.A., on August 5, 2024 the Registrant and certain of its subsidiaries entered into Amendment No. 1 (the “Amendment”) to its Amended and Restated Credit Agreement dated August 30, 2023 (the “2023 Credit Agreement”) among the Company and certain of its subsidiaries, JPMorgan Chase Bank, N.A., as administrative agent thereunder, the initial lenders party thereto and Citibank, N.A. The Amendment, among other things, (i) implements a senior incremental delayed draw term loan credit facility in an aggregate principal amount of up to $375 million (the “Incremental Facility”), and (ii) permits the direct or indirect acquisition by the Registrant or certain of its subsidiaries of all of the issued and outstanding shares of Ultra PMES Limited, Measurement Systems, Inc., EMS Development Corporation, and DNE Technologies, Inc. (the “Transaction”), pursuant to and in accordance with the terms and conditions of that certain Sale and Purchase Agreement, dated July 8, 2024, among Ultra Electronics Holdings Limited, as parent seller, the Registrant, as guarantor, and certain of the Registrant’s subsidiaries as buyers. The proceeds of the loans drawn under the Incremental Facility will be applied to pay a portion of the cash consideration for the Transaction and other customary fees, premiums, expenses and costs incurred in connection with the Transaction. See further discussion of the transaction and financing arrangements in the Company’s Form 8-K’s filed on July 8, 2024 and August 7, 2024.

[0001410578-24-001264:mdna:46]
[same as prior period, unchanged from 0001410578-24-000723:mdna:45]

[0001410578-24-001264:mdna:47]
On November 9, 2023, the Company acquired MPE Limited (MPE), based in the United Kingdom, for a purchase price of approximately $56.2 million, net of cash acquired. MPE is a leading global manufacturer of high-performance EMC/EMP filters and capacitor products for military, utility, telecommunication, and other critical infrastructure applications. Since the date of acquisition, the operating results for the MPE business have been included as part of ETS-Lindgren in the Test segment. The Company paid a $0.2 million working capital settlement in the third quarter of fiscal 2024.

[0001410578-24-001264:mdna:48]
Credit Facility

[0001410578-24-001264:mdna:49]
At June 30, 2024, the Company had approximately $321 million available to borrow under its bank credit facility, a $250 million increase option, and $63.0 million cash on hand. At June 30, 2024, the Company had $173 million of outstanding borrowings under the credit facility in addition to outstanding letters of credit of $5.5 million. Cash flow from operations and borrowings under the Company’s credit facility are expected to meet the Company’s capital requirements and operational needs for the foreseeable future. The Company’s ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.

[0001410578-24-001264:mdna:50]
[same as prior period, unchanged from 0001410578-24-000723:mdna:49]

[0001410578-24-001264:mdna:51]
During the first nine months of 2024, the Company repurchased approximately 80,000 shares for approximately $8.0 million. For further information on the share repurchases during the third quarter of 2024, see Part II, Item 2 of this Report.

[0001410578-24-001264:mdna:52]
[same as prior period, unchanged from 0001410578-24-000723:mdna:51]

[0001410578-24-001264:mdna:53]
A dividend of $0.08 per share, totaling $2.1 million, was paid on October 17, 2023 to stockholders of record as of October 3, 2023. A dividend of $0.08 per share, totaling $2.1 million, was paid on January 19, 2024 to stockholders of record as of January 4, 2024. A dividend of $0.08 per share, totaling $2.1 million, was paid on April 16, 2024 to stockholders of record as of April 1, 2024. Subsequent to June 30, 2024, a dividend of $0.08 per share, totaling $2.1 million, was paid on July 19, 2024 to stockholders of record as of July 3, 2024.

[0001410578-24-001264:mdna:54]
[same as prior period, unchanged from 0001410578-24-000723:mdna:53]

[0001410578-24-001264:mdna:55]
[same as prior period, unchanged from 0001410578-24-000723:mdna:54]

[0001410578-24-001264:mdna:56]
[same as prior period, unchanged from 0001410578-24-000723:mdna:55]

[0001410578-24-001264:mdna:57]
Contingencies

[0001410578-24-001264:mdna:58]
As a normal incident of the business in which the Company is engaged, various claims, charges and litigation are asserted or commenced against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. In the opinion of Management, the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company, are adequately reserved, are covered by insurance, or would not have a material adverse effect on the Company’s results from operations, capital expenditures, or competitive position.

[0001410578-24-001264:mdna:59]
[same as prior period, unchanged from 0001410578-24-000723:mdna:58]

[0001410578-24-001264:mdna:60]
Investors are cautioned that such statements are only predictions and speak only as of the date of this Form 10-Q, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment, including but not limited to those described in Item 1A, “Risk Factors,” of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2023, and the following: the impacts of climate change and related regulation of greenhouse gases; the impacts of labor disputes, civil disorder, wars, elections, political changes, tariffs and trade disputes, terrorist activities, cyberattacks or natural disasters on the Company’s operations and those of the Company’s customers and suppliers; disruptions in manufacturing or delivery arrangements due to shortages or unavailability of materials or components; or supply chain disruptions; inability to access work sites; the timing and content of future contract awards or customer orders; the timely appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer contracts or orders; weakening of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties or data breaches; the availability of selected acquisitions; delivery delays or defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability of certain raw materials; material changes in the cost of credit; changes in laws and regulations including but not limited to changes in accounting standards and taxation; changes in interest, inflation and employment rates; costs relating to environmental matters arising from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the integration and performance of recently acquired businesses.
