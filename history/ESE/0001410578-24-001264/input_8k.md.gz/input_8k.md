# ESE 8-K — 0001104659-24-086768 filed 2024-08-07

## item codes, every 8-K on or before 2024-08-09

- 2024-08-07 0001104659-24-086768 — 1.01, 2.02, 5.02, 7.01, 9.01
- 2024-07-08 0001104659-24-078312 — 1.01, 7.01, 9.01
- 2024-05-09 0001104659-24-059341 — 2.02, 7.01, 9.01
- 2024-02-08 0001104659-24-012294 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2023-11-20 0001104659-23-119761 — 5.02, 9.01
- 2023-11-16 0001104659-23-119126 — 2.02, 7.01, 9.01
- 2023-10-03 0001104659-23-106090 — 5.02, 9.01
- 2023-09-06 0001104659-23-098463 — 1.01, 2.03, 9.01
- 2023-08-08 0001104659-23-088847 — 2.02, 7.01, 9.01
- 2023-07-06 0001104659-23-078571 — 5.02, 8.01, 9.01
- 2023-05-09 0001104659-23-057736 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2023-05-05 0001104659-23-056387 — 5.02, 9.01
- 2023-02-08 0001104659-23-014539 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2023-01-06 0001104659-23-001859 — 5.02, 9.01
- 2022-11-22 0001104659-22-121229 — 5.02, 5.03, 8.01, 9.01
- 2022-11-17 0001104659-22-119898 — 2.02, 7.01, 9.01
- 2022-09-12 0001104659-22-099248 — 5.02, 7.01, 9.01
- 2022-08-08 0001104659-22-087247 — 2.02, 5.02, 7.01, 9.01
- 2022-05-09 0001104659-22-057524 — 2.02, 5.02, 7.01, 9.01
- 2022-02-08 0001104659-22-013878 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2021-12-03 0001104659-21-146361 — 4.01, 9.01 — amendment, the index does not say of what
- 2021-11-24 0001104659-21-143568 — 4.01, 9.01
- 2021-11-23 0001104659-21-142871 — 5.02, 8.01
- 2021-11-18 0001104659-21-141206 — 2.02, 7.01, 9.01
- 2021-08-09 0001104659-21-102150 — 2.02, 7.01, 9.01
- 2021-05-04 0001104659-21-060985 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2021-04-05 0001104659-21-046581 — 5.02, 9.01
- 2021-02-08 0001104659-21-013712 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2020-12-09 0001104659-20-133674 — 5.02, 9.01
- 2020-12-07 0001104659-20-132861 — 5.02, 7.01, 9.01
- 2020-11-19 0001104659-20-127352 — 2.02, 5.02, 7.01, 9.01
- 2020-08-10 0001104659-20-092734 — 2.02, 7.01, 9.01
- 2020-05-06 0001104659-20-057442 — 2.02, 7.01, 8.01, 9.01
- 2020-02-04 0001104659-20-010640 — 2.02, 5.07, 7.01, 9.01
- 2020-01-07 0001104659-20-001789 — 2.01, 9.01
- 2019-11-19 0001104659-19-065437 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2019-11-18 0001104659-19-065096 — 1.01, 2.02, 7.01, 9.01
- 2019-09-30 0001144204-19-046523 — 1.01, 1.02, 2.03, 9.01
- 2019-08-08 0001144204-19-038567 — 2.02, 7.01, 9.01
- 2019-05-07 0001144204-19-024241 — 2.02, 5.02, 7.01, 9.01
- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2024-08-09

- none on or before 2024-08-09

## item 2.02 — earnings release, exhibit 99.1

[0001104659-24-086768:8k_2_02:1]
EX-99.1
2
tm2421020d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-24-086768:8k_2_02:2]
Exhibit 99.1

[0001104659-24-086768:8k_2_02:3]
| NEWS FROM |  |

[0001104659-24-086768:8k_2_02:4]
For more information contact:

[0001104659-24-086768:8k_2_02:5]
Kate Lowrey
- VP of Investor Relations

[0001104659-24-086768:8k_2_02:6]
(314) 213-7277
/ klowrey@escotechnologies.com

[0001104659-24-086768:8k_2_02:7]
ESCO
REPORTS THIRD QUARTER FISCAL 2024 RESULTS

[0001104659-24-086768:8k_2_02:8]
- Q3 Orders increase 46% to $312 million
/ Book-to-Bill of 1.20x –

[0001104659-24-086768:8k_2_02:9]
- Q3 Sales increase 5% to $261 million -

[0001104659-24-086768:8k_2_02:10]
- Q3 GAAP EPS increases 5% to $1.13 -

[0001104659-24-086768:8k_2_02:11]
- Q3 Adjusted EPS increases 6% to $1.16 -

[0001104659-24-086768:8k_2_02:12]
ST. LOUIS, August 7, 2024 – ESCO Technologies Inc. (NYSE:
ESE) (ESCO, or the Company) today reported its operating results for the third quarter ended June 30, 2024 (Q3 2024).

[0001104659-24-086768:8k_2_02:13]
Operating
Highlights

[0001104659-24-086768:8k_2_02:14]
|  | ● | Q3 2024 Sales increased $12.1 million (5 percent) to $260.8 million compared to $248.7 million in Q3 2023. Q3 organic sales increased $8.7 million (4 percent) and the MPE acquisition contributed $3.4 million (1 percent) of revenue in the quarter. |

[0001104659-24-086768:8k_2_02:15]
|  | ● | Q3 2024 GAAP EPS increased 5 percent to $1.13 per share compared to $1.08 per share in Q3 2023. Q3 2024 Adjusted EPS increased 6 percent to $1.16 per share compared to $1.09 per share in Q3 2023. |

[0001104659-24-086768:8k_2_02:16]
|  | ● | Q3 2024 Entered Orders increased $98.4 million (46 percent) compared to the prior year period to $311.7 million (book-to-bill of 1.20x), resulting in record ending backlog of $889 million. |

[0001104659-24-086768:8k_2_02:17]
|  | ● | Net cash provided by operating activities was $55 million YTD, an increase of $26 million compared to the prior year period. |

[0001104659-24-086768:8k_2_02:18]
|  | ● | Net debt (total borrowings less cash on hand) was $110 million, resulting in a 0.73x leverage ratio and $571 million in liquidity as of June 30, 2024. |

[0001104659-24-086768:8k_2_02:19]
Bryan Sayler,
Chief Executive Officer and President, commented, “Q3 was highlighted by over $300 million in orders, with strength across all three
segments. The increase was driven by large Navy orders, continuing strength in aerospace and electric utility orders, and importantly
a rebound in both Test and renewables orders. Revenue grew 5 percent in the quarter and Adjusted EBITDA margin expanded by 60 basis points,
driving a 6 percent increase in Adjusted EPS compared to the prior year quarter. Overall, it was a solid quarter as we continue to see
favorable momentum across our aerospace, Navy and utility end markets.”

[0001104659-24-086768:8k_2_02:20]
Segment Performance

[0001104659-24-086768:8k_2_02:21]
Aerospace & Defense (A&D)

[0001104659-24-086768:8k_2_02:22]
|  | ● | Sales increased $11.0 million (10.6 percent) to $114.5 million in Q3 2024 from $103.5 million in Q3 2023. Sales growth was driven by strength across Navy, commercial aerospace, and defense aerospace programs. |

[0001104659-24-086768:8k_2_02:23]
|  | ● | Q3 2024 EBIT decreased $0.3 million to $21.4 million from $21.7 million in Q3 2023. Adjusted EBIT decreased $0.2 million in Q3 2024 to $21.5 million (18.7 percent margin) from $21.7 million (20.9 percent margin) in Q3 2023. Profitability in the quarter was negatively impacted by margin erosion on space development programs at VACCO. Additionally, unfavorable revenue mix and inflationary pressures were offset by leverage on higher volume and price increases. |

[0001104659-24-086768:8k_2_02:24]
|  | ● | Entered Orders increased $65 million (79 percent) to $147 million in Q3 2024 compared to $82 million in Q3 2023. The increase was primarily driven by strength in Navy (Virginia Class Block V QARMS and Ejection System development), and a strong quarter for commercial and defense aerospace aftermarket orders. The orders in the quarter resulted in a segment book-to-bill of 1.28x and record ending backlog of $595 million. |

[0001104659-24-086768:8k_2_02:25]
Utility Solutions Group (USG)

[0001104659-24-086768:8k_2_02:26]
|  | ● | Sales increased $0.3 million (0.3 percent) to $90.3 million in Q3 2024 from $90.0 million in Q3 2023. As expected, USG revenue growth moderated in Q3 after 13 percent growth in the first half of the year. Revenue grew sequentially and is up 8 percent Q3 YTD, which remains in line with our expectations for the year. Doble’s Q3 2024 sales increased by $0.4 million (0.5 percent), driven by higher services revenue offset by lower protection testing sales. NRG sales were flat compared to strong results in the prior year period. |

[0001104659-24-086768:8k_2_02:27]
|  | ● | EBIT increased $1.8 million (9 percent) in Q3 2024 to $22.2 million from $20.4 million in Q3 2023. Adjusted EBIT increased $1.7 million in Q3 2024 to $22.2 million (24.6 percent margin) from $20.5 million (22.8 percent margin) in Q3 2023. Margin improvement was driven by mix related to increased services revenue and price increases, partially offset by inflationary pressures. |

[0001104659-24-086768:8k_2_02:28]
|  | ● | Entered Orders increased $15 million (17 percent) to $100 million in Q3 2024. Doble orders increased $19 million (30 percent) on continuing strength in services and our lease pool business as utilities focus on keeping substations operational while coping with long lead times on new transformers. NRG’S orders were $19 million in the quarter. While down $4 million compared to the record prior year quarter, this represents the second highest orders quarter in NRG history and was in line with our expectations for a rebound in renewables orders as the market moves beyond last year’s elevated activity related to the initial Inflation Reduction Act spending. The segment book-to-bill was 1.11x in the quarter, resulting in ending backlog of $129 million. |

[0001104659-24-086768:8k_2_02:29]
RF Test & Measurement (Test)

[0001104659-24-086768:8k_2_02:30]
|  | ● | Sales increased $0.8 million (1.3 percent) to $56.1 million in Q3 2024 from $55.3 million in Q3 2023. Organic sales decreased $2.6 million primarily related to lower wireless and US filters volume. This was more than offset by $3.4 million of revenue related to the MPE acquisition which was completed in Q1 2024. While Test’s revenues continue to be somewhat soft, they delivered significant sequential revenue growth of 19 percent in the quarter. |

[0001104659-24-086768:8k_2_02:31]
|  | ● | EBIT and Adjusted EBIT both increased $0.7 million in Q3 2024 to $9.3 million (16.6 percent margin) from $8.6 million (15.6 percent margin) in Q3 2023. Margin improvement was driven by higher margin MPE content, cost reduction actions and price increases, partially offset by inflationary pressures and mix related to lower wireless and US filters volume. |

[0001104659-24-086768:8k_2_02:32]
|  | ● | Entered Orders increased $19 million (41 percent) to $65 million in Q3 2024. The rebound in Test orders was primarily driven by the booking of a large industrial project and a strong quarter for US T&M orders. The segment book-to-bill was 1.16x in the quarter, resulting in ending backlog of $165 million. |

[0001104659-24-086768:8k_2_02:33]
SM&P Acquisition

[0001104659-24-086768:8k_2_02:34]
As announced on July 8, 2024, ESCO has agreed to acquire the Signature
Management & Power (SM&P) business of Ultra Maritime for a purchase price of $550 million. The required filings have been
submitted and we are awaiting regulatory approval, with an anticipation of a Q1 fiscal 2025 closing. SM&P’s sole source product
offerings will add significant scale to the ESCO Navy business, providing increased content on domestic Navy submarine and surface ship
programs and expansion into vital UK and AUKUS navy platforms.

[0001104659-24-086768:8k_2_02:35]
Business
Outlook – 2024

[0001104659-24-086768:8k_2_02:36]
Management’s expectation is for Q4 Adjusted EPS in the range
of $1.38 to $1.48 (10 to 18 percent growth). This results in full year guidance in the range of $4.10 to $4.20 (11 to 14 percent growth),
which represents ESCO’s third consecutive year of double-digit earnings growth. This outlook is based on sales in the range of $1.02
to $1.03 billion (7 to 8 percent annual growth) and excludes further profitability erosion on Space programs at VACCO, which could range
from $5 to $7 million ($0.15 - $0.21) in Q4 2024.

[0001104659-24-086768:8k_2_02:37]
VACCO Space Business Strategic Review

[0001104659-24-086768:8k_2_02:38]
The Company is undertaking a process to review strategic alternatives
for the Space business at VACCO. These alternatives could include, among others, possible joint ventures, strategic partnerships, or a
sale of the business. The intent is to optimize ESCO’s portfolio of businesses and create value for ESCO shareholders. This decision
was made as part of our continual strategic portfolio analysis, which is focused on positioning the Company to serve high-growth markets
that have high margin potential. As we undertake this review, the Company remains committed to executing on our current Space programs
and serving the needs of our customers.

[0001104659-24-086768:8k_2_02:39]
There is no deadline or definitive timetable for completion of the
strategic alternatives review process and there can be no assurance that this process will result in the Company pursuing a transaction
or any other strategic outcome. ESCO does not intend to make any further public comment regarding the review of strategic alternatives
for the Space business at VACCO until it has been completed or the Company determines that a disclosure is required or otherwise deemed
appropriate.

[0001104659-24-086768:8k_2_02:40]
Share Repurchase Program

[0001104659-24-086768:8k_2_02:41]
During Q3 2024, the Company repurchased approximately 8,000 shares
for $0.8 million.

[0001104659-24-086768:8k_2_02:42]
Dividend
Payment

[0001104659-24-086768:8k_2_02:43]
The next quarterly
cash dividend of $0.08 per share will be paid on October 16, 2024 to stockholders of record on October 2, 2024.

[0001104659-24-086768:8k_2_02:44]
Board of Directors

[0001104659-24-086768:8k_2_02:45]
Effective
August 1, 2024, the Company’s Board of Directors approved the addition of two independent directors, Penelope M. Conner and
David A. Campbell, which shall become effective upon the requisite approval by the Federal Energy Regulatory Commission of such
positions and satisfaction of any and all other regulatory requirements.

[0001104659-24-086768:8k_2_02:46]
Ms. Conner
was named to the Nominating and Corporate Governance Committee and Mr. Campbell was named to the Audit and Finance Committee of
the Board of Directors, subject to and effective upon the commencement of their respective terms as directors.

[0001104659-24-086768:8k_2_02:47]
Penelope M. Conner

[0001104659-24-086768:8k_2_02:48]
With 38 years of experience in the electric and gas utility sector,
since 2002 Ms. Conner has held executive positions with Eversource Energy (NYSE: ES), a utility holding company based in Medfield,
Massachusetts, most recently (since 2021) as Eversource’s Executive Vice President, Customer Experience and Energy Strategy. She
is currently responsible for ensuring that Eversource’s 4 million electric and gas customers experience high-quality customer service
while driving Eversource’s energy strategy development and capital allocation throughout the enterprise. Prior to joining Eversource,
Ms. Conner held positions of increasing responsibility from 1986 to 2002 at Tampa Electric Company and then Duke Energy Corporation,
culminating in a position as Duke Energy’s General Manager for Process Integration.

[0001104659-24-086768:8k_2_02:49]
Ms. Conner graduated from North Carolina State University in
1986 with a Bachelor of Science degree in Industrial Engineering, summa cum laude. She is a registered professional engineer in North
and South Carolina.

[0001104659-24-086768:8k_2_02:50]
David A. Campbell

[0001104659-24-086768:8k_2_02:51]
Since 2021
Mr. Campbell has been the President and Chief Executive Officer and a Board Member of Evergy, Inc. (NASDAQ: EVRG), a public
utility holding company incorporated in 2017 and headquartered in Kansas City, Missouri. He previously held executive positions
at a number of electric and integrated energy companies in Texas as well as at an independent energy resource and investment company,
following nine years (four as a partner) in the Dallas office of McKinsey & Company, a leading global management consulting firm
providing strategic and operational counsel to top management of diverse global corporations and institutions.

[0001104659-24-086768:8k_2_02:52]
Mr. Campbell holds degrees from Harvard Law School (J.D. degree
magna cum laude, 1995), Oxford University (M.Phil. International Relations, 1992), and Yale University (B.A. summa cum laude with
Distinction in History, 1990).

[0001104659-24-086768:8k_2_02:53]
Conference Call

[0001104659-24-086768:8k_2_02:54]
The Company
will host a conference call today, August 7, at 4:00 p.m. Central Time, to discuss the Company’s Q3 2024 results. A live
audio webcast and an accompanying slide presentation will be available in the Investor Center of ESCO’s website.
For those unable to participate, a webcast replay will be available after the call in the Investor Center of ESCO’s website.

[0001104659-24-086768:8k_2_02:55]
Forward-Looking Statements

[0001104659-24-086768:8k_2_02:56]
Investors
are cautioned that such statements are only predictions and speak only as of the date of this release, and the Company undertakes no duty
to update them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ
materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations
and business environment including but not limited to those described in Item 1A, “Risk Factors”, of the Company’s Annual
Report on Form 10-K for the fiscal year ended September 30, 2023 and the following: the timing and outcome, if any, of
the Company’s strategic alternatives review for the Space business at VACCO; the impacts of climate change and related regulation
of greenhouse gases; the impacts of labor disputes, civil disorder, wars, elections, political changes, tariffs and trade disputes, terrorist
activities, cyberattacks or natural disasters on the Company’s operations and those of the Company’s customers and suppliers;
disruptions in manufacturing or delivery arrangements due to shortages or unavailability of materials or components or supply chain disruptions;
inability to access work sites; the timing and content of future contract awards or customer orders; the timely appropriation, allocation
and availability of Government funds; the termination for convenience of Government and other customer contracts or orders; weakening
of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies;
competition; intellectual property rights; technical difficulties or data breaches; the availability of acquisitions; delivery delays
or defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability
of certain raw materials; material changes in the cost of credit; changes in laws and regulations including but not limited to changes
in accounting standards and taxation; changes in interest, inflation and employment rates; costs relating to environmental matters arising
from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration;
and the integration and performance of acquired businesses.

[0001104659-24-086768:8k_2_02:57]
Non-GAAP Financial Measures

[0001104659-24-086768:8k_2_02:58]
The financial measures EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA,
and Adjusted EPS are presented in this press release. The Company defines “EBIT” as earnings before interest and taxes, “EBITDA”
as earnings before interest, taxes, depreciation and amortization, “Adjusted EBIT” and “Adjusted EBITDA” as excluding
the net impact of the items described in the attached Reconciliation of Non-GAAP Financial Measures, and “Adjusted EPS” as
GAAP earnings per share excluding the net impact of the items described and reconciled in the attached Reconciliation of Non-GAAP Financial
Measures.

[0001104659-24-086768:8k_2_02:59]
EBIT, Adjusted
EBIT, EBITDA, Adjusted EBITDA, and Adjusted EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP).
However, Management believes EBIT, Adjusted EBIT, EBITDA, and Adjusted EBITDA are useful in assessing the operational profitability of
the Company’s business segments because they exclude interest, taxes, depreciation, and amortization, which are generally accounted
for across the entire Company on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations
within the Company as well as incentive compensation. The presentation of EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA, and Adjusted EPS
provides important supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP
financial measures to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures
of performance determined in accordance with GAAP.

[0001104659-24-086768:8k_2_02:60]
ESCO is a
global provider of highly engineered products and solutions serving diverse end-markets. It manufactures filtration and fluid control
products for the aviation, Navy, space, and process markets worldwide and composite-based products and solutions for Navy, defense, and
industrial customers. ESCO is an industry leader in designing and manufacturing RF test and measurement products and systems; and provides
diagnostic instruments, software and services to industrial power users and the electric utility and renewable energy industries. Headquartered
in St. Louis, Missouri, ESCO and its subsidiaries have offices and manufacturing facilities worldwide. For more information on ESCO and
its subsidiaries, visit the Company’s website at www.escotechnologies.com.

[0001104659-24-086768:8k_2_02:61]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-086768:8k_2_02:62]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-24-086768:8k_2_02:63]
(Dollars
in thousands, except per share amounts)

[0001104659-24-086768:8k_2_02:64]
|  |  | Three Months Ended June 30, 2024 |  |  | Three Months Ended June 30, 2023 |  |
| Net Sales |  | $ | 260,783 |  |  |  | 248,749 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 157,435 |  |  |  | 147,274 |  |
| Selling, general and administrative expenses |  |  | 54,955 |  |  |  | 55,376 |  |
| Amortization of intangible assets |  |  | 8,145 |  |  |  | 7,132 |  |
| Interest expense |  |  | 3,335 |  |  |  | 2,495 |  |
| Other expenses (income), net |  |  | (259 | ) |  |  | 966 |  |
| Total costs and expenses |  |  | 223,611 |  |  |  | 213,243 |  |
| Earnings before income taxes |  |  | 37,172 |  |  |  | 35,506 |  |
| Income tax expense |  |  | 7,942 |  |  |  | 7,563 |  |
| Net earnings |  | $ | 29,230 |  |  |  | 27,943 |  |
| Earnings Per Share (EPS) |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 1.13 |  |  |  | 1.08 |  |
| Diluted - As Adjusted Basis |  | $ | 1.16 | (1) |  |  | 1.09 | (2) |
| Diluted average common shares O/S: |  |  | 25,840 |  |  |  | 25,827 |  |

[0001104659-24-086768:8k_2_02:65]
|  | (1) | Q3 2024 Adjusted EPS excludes $0.03 per share of after-tax charges consisting mainly of: $0.02 of Corporate acquisition related costs and $0.01 of restructuring charges (primarily severance) within the A&D and USG segments. |

[0001104659-24-086768:8k_2_02:66]
|  | (2) | Q3 2023 Adjusted EPS excludes $0.01 per share of after-tax charges consisting mainly of Corporate acquisition related costs. |

[0001104659-24-086768:8k_2_02:67]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-086768:8k_2_02:68]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-24-086768:8k_2_02:69]
(Dollars
in thousands, except per share amounts)

[0001104659-24-086768:8k_2_02:70]
|  |  | Nine Months Ended June 30, 2024 |  |  | Nine Months Ended June 30, 2023 |  |
| Net Sales |  | $ | 728,226 |  |  |  | 683,386 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 443,933 |  |  |  | 415,953 |  |
| Selling, general and administrative expenses |  |  | 164,020 |  |  |  | 160,555 |  |
| Amortization of intangible assets |  |  | 24,585 |  |  |  | 21,023 |  |
| Interest expense |  |  | 9,228 |  |  |  | 6,422 |  |
| Other expenses (income), net |  |  | 613 |  |  |  | 1,678 |  |
| Total costs and expenses |  |  | 642,379 |  |  |  | 605,631 |  |
| Earnings before income taxes |  |  | 85,847 |  |  |  | 77,755 |  |
| Income tax expense |  |  | 18,229 |  |  |  | 17,207 |  |
| Net earnings |  | $ | 67,618 |  |  |  | 60,548 |  |
| Earnings Per Share (EPS) |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 2.62 |  |  |  | 2.34 |  |
| Diluted - As Adjusted Basis |  | $ | 2.72 | (1) |  |  | 2.45 | (2) |
| Diluted average common shares O/S: |  |  | 25,844 |  |  |  | 25,890 |  |

[0001104659-24-086768:8k_2_02:71]
|  | (1) | YTD Q3 2024 Adjusted EPS excludes $0.10 per share of after-tax charges consisting of: $0.04 of MPE acquisition backlog and inventory step-up charges, $0.03 of restructuring charges (primarily severance) within the Test, A&D and USG segments, and $0.03 of Corporate acquisition related costs. |

[0001104659-24-086768:8k_2_02:72]
|  | (2) | YTD Q3 2023 Adjusted EPS excludes $0.11 per share of after-tax charges consisting of: $0.06 of executive management transition costs at Corporate, $0.02 of CMT acquisition inventory step-up charges, $0.02 of restructuring charges within the A&D segment, and $0.01 of Corporate acquisition related costs. |

[0001104659-24-086768:8k_2_02:73]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-086768:8k_2_02:74]
Condensed Business Segment Information (Unaudited)

[0001104659-24-086768:8k_2_02:75]
(Dollars
in thousands)

[0001104659-24-086768:8k_2_02:76]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | Q3 2024 |  |  | Q3 2023 |  |  | Q3 2024 |  |  | Q3 2023 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 114,450 |  |  |  | 103,469 |  |  |  | 114,450 |  |  |  | 103,469 |  |
| USG |  |  | 90,277 |  |  |  | 89,966 |  |  |  | 90,277 |  |  |  | 89,966 |  |
| Test |  |  | 56,056 |  |  |  | 55,314 |  |  |  | 56,056 |  |  |  | 55,314 |  |
| Totals |  | $ | 260,783 |  |  |  | 248,749 |  |  |  | 260,783 |  |  |  | 248,749 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 21,356 |  |  |  | 21,665 |  |  |  | 21,444 |  |  |  | 21,665 |  |
| USG |  |  | 22,155 |  |  |  | 20,351 |  |  |  | 22,230 |  |  |  | 20,481 |  |
| Test |  |  | 9,292 |  |  |  | 8,643 |  |  |  | 9,297 |  |  |  | 8,643 |  |
| Corporate |  |  | (12,296 | ) |  |  | (12,658 | ) |  |  | (11,566 | ) |  |  | (12,438 | ) |
| Consolidated EBIT |  |  | 40,507 |  |  |  | 38,001 |  |  |  | 41,405 |  |  |  | 38,351 |  |
| Less: Interest expense |  |  | (3,335 | ) |  |  | (2,495 | ) |  |  | (3,335 | ) |  |  | (2,495 | ) |
| Less: Income tax expense |  |  | (7,942 | ) |  |  | (7,563 | ) |  |  | (8,149 | ) |  |  | (7,643 | ) |
| Net earnings |  | $ | 29,230 |  |  |  | 27,943 |  |  |  | 29,921 |  |  |  | 28,213 |  |

[0001104659-24-086768:8k_2_02:77]
Note
1: Adjusted net earnings were $29.9 million in Q3 2024 which excludes $0.03 per share of after-tax charges consisting mainly of $0.02
of Corporate acquisition related costs and $0.01 of restructuring charges (primarily severance) within the A&D and USG segments.

[0001104659-24-086768:8k_2_02:78]
Note 2: Adjusted net earnings were $28.2 million in Q3 2023 which excludes $0.01 per share of after-tax charges consisting mainly of Corporate acquisition related costs.

[0001104659-24-086768:8k_2_02:79]
EBITDA Reconciliation to Net earnings:

[0001104659-24-086768:8k_2_02:80]
|  |  |  |  |  |  |  |  | Q3 2024 - |  |  | Q3 2023 - |  |
|  |  | Q3 2024 |  |  | Q3 2023 |  |  | As Adjusted |  |  | As Adjusted |  |
| Consolidated EBITDA |  | $ | 54,310 |  |  |  | 50,790 |  |  |  | 55,208 |  |  |  | 51,140 |  |
| Less: Depr & Amort |  |  | (13,803 | ) |  |  | (12,789 | ) |  |  | (13,803 | ) |  |  | (12,789 | ) |
| Consolidated EBIT |  |  | 40,507 |  |  |  | 38,001 |  |  |  | 41,405 |  |  |  | 38,351 |  |
| Less: Interest expense |  |  | (3,335 | ) |  |  | (2,495 | ) |  |  | (3,335 | ) |  |  | (2,495 | ) |
| Less: Income tax expense |  |  | (7,942 | ) |  |  | (7,563 | ) |  |  | (8,149 | ) |  |  | (7,643 | ) |
| Net earnings |  | $ | 29,230 |  |  |  | 27,943 |  |  |  | 29,921 |  |  |  | 28,213 |  |

[0001104659-24-086768:8k_2_02:81]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-086768:8k_2_02:82]
Condensed Business Segment Information (Unaudited)

[0001104659-24-086768:8k_2_02:83]
(Dollars
in thousands)

[0001104659-24-086768:8k_2_02:84]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | YTD |  |  | YTD |  |  | YTD |  |  | YTD |  |
|  |  | Q3 2024 |  |  | Q3 2023 |  |  | Q3 2024 |  |  | Q3 2023 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 323,884 |  |  |  | 285,434 |  |  |  | 323,884 |  |  |  | 285,434 |  |
| USG |  |  | 260,570 |  |  |  | 240,172 |  |  |  | 260,570 |  |  |  | 240,172 |  |
| Test |  |  | 143,772 |  |  |  | 157,780 |  |  |  | 143,772 |  |  |  | 157,780 |  |
| Totals |  | $ | 728,226 |  |  |  | 683,386 |  |  |  | 728,226 |  |  |  | 683,386 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 61,396 |  |  |  | 52,996 |  |  |  | 61,747 |  |  |  | 53,995 |  |
| USG |  |  | 57,355 |  |  |  | 50,543 |  |  |  | 57,550 |  |  |  | 50,673 |  |
| Test |  |  | 16,614 |  |  |  | 21,280 |  |  |  | 17,095 |  |  |  | 21,280 |  |
| Corporate |  |  | (40,290 | ) |  |  | (40,642 | ) |  |  | (38,124 | ) |  |  | (38,129 | ) |
| Consolidated EBIT |  |  | 95,075 |  |  |  | 84,177 |  |  |  | 98,268 |  |  |  | 87,819 |  |
| Less: Interest expense |  |  | (9,228 | ) |  |  | (6,422 | ) |  |  | (9,228 | ) |  |  | (6,422 | ) |
| Less: Income tax expense |  |  | (18,229 | ) |  |  | (17,207 | ) |  |  | (18,963 | ) |  |  | (18,045 | ) |
| Net earnings |  | $ | 67,618 |  |  |  | 60,548 |  |  |  | 70,077 |  |  |  | 63,352 |  |

[0001104659-24-086768:8k_2_02:85]
Note
1: Adjusted net earnings were $70.1 million in YTD Q3 2024 which excludes $0.10 per share of after-tax charges consisting of $0.04 of
MPE acquisition backlog and inventory step-up charges, $0.03 of restructuring charges (primarily severance) within the Test, A&D
and USG segments, and $0.03 of Corporate acquisition related costs.

[0001104659-24-086768:8k_2_02:86]
Note
2: Adjusted net earnings were $63.4 million in YTD Q3 2023 which excludes $0.11 per share of after-tax charges consisting of $0.06 of
executive management transition costs at Corporate, $0.02 of CMT acquisition inventory step-up charges, $0.02 of restructuring charges
within the A&D segment, and $0.01 of Corporate acquisition related costs.

[0001104659-24-086768:8k_2_02:87]
EBITDA Reconciliation to Net earnings:

[0001104659-24-086768:8k_2_02:88]
|  |  |  |  |  |  |  |  | YTD |  |  | YTD |  |
|  |  | YTD |  |  | YTD |  |  | Q3 2024 - |  |  | Q3 2023 - |  |
|  |  | Q3 2024 |  |  | Q3 2023 |  |  | As Adjusted |  |  | As Adjusted |  |
| Consolidated EBITDA |  | $ | 136,433 |  |  |  | 121,876 |  |  |  | 138,790 |  |  |  | 125,518 |  |
| Less: Depr & Amort |  |  | (41,358 | ) |  |  | (37,699 | ) |  |  | (40,522 | ) |  |  | (37,699 | ) |
| Consolidated EBIT |  |  | 95,075 |  |  |  | 84,177 |  |  |  | 98,268 |  |  |  | 87,819 |  |
| Less: Interest expense |  |  | (9,228 | ) |  |  | (6,422 | ) |  |  | (9,228 | ) |  |  | (6,422 | ) |
| Less: Income tax expense |  |  | (18,229 | ) |  |  | (17,207 | ) |  |  | (18,963 | ) |  |  | (18,045 | ) |
| Net earnings |  | $ | 67,618 |  |  |  | 60,548 |  |  |  | 70,077 |  |  |  | 63,352 |  |

[0001104659-24-086768:8k_2_02:89]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-086768:8k_2_02:90]
Condensed Consolidated Balance Sheets (Unaudited)

[0001104659-24-086768:8k_2_02:91]
(Dollars
in thousands)

[0001104659-24-086768:8k_2_02:92]
|  |  | June 30, 2024 |  |  | September 30, 2023 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 63,042 |  |  |  | 41,866 |  |
| Accounts receivable, net |  |  | 213,592 |  |  |  | 198,557 |  |
| Contract assets |  |  | 134,637 |  |  |  | 138,633 |  |
| Inventories |  |  | 219,312 |  |  |  | 184,067 |  |
| Other current assets |  |  | 22,312 |  |  |  | 17,972 |  |
| Total current assets |  |  | 652,895 |  |  |  | 581,095 |  |
| Property, plant and equipment, net |  |  | 164,749 |  |  |  | 155,484 |  |
| Intangible assets, net |  |  | 408,981 |  |  |  | 392,124 |  |
| Goodwill |  |  | 535,372 |  |  |  | 503,177 |  |
| Operating lease assets |  |  | 37,716 |  |  |  | 39,839 |  |
| Other assets |  |  | 11,342 |  |  |  | 11,495 |  |
|  |  | $ | 1,811,055 |  |  |  | 1,683,214 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt |  | $ | 20,000 |  |  |  | 20,000 |  |
| Accounts payable |  |  | 83,411 |  |  |  | 86,973 |  |
| Contract liabilities |  |  | 113,653 |  |  |  | 112,277 |  |
| Other current liabilities |  |  | 94,143 |  |  |  | 95,401 |  |
| Total current liabilities |  |  | 311,207 |  |  |  | 314,651 |  |
| Deferred tax liabilities |  |  | 77,570 |  |  |  | 75,531 |  |
| Non-current operating lease liabilities |  |  | 35,148 |  |  |  | 36,554 |  |
| Other liabilities |  |  | 40,444 |  |  |  | 43,336 |  |
| Long-term debt |  |  | 153,000 |  |  |  | 82,000 |  |
| Shareholders' equity |  |  | 1,193,686 |  |  |  | 1,131,142 |  |
|  |  | $ | 1,811,055 |  |  |  | 1,683,214 |  |

[0001104659-24-086768:8k_2_02:93]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-086768:8k_2_02:94]
Consolidated Statements of Cash Flows (Unaudited)

[0001104659-24-086768:8k_2_02:95]
(Dollars
in thousands)

[0001104659-24-086768:8k_2_02:96]
|  |  | Nine Months Ended June 30, 2024 |  |  | Nine Months Ended June 30, 2023 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 67,618 |  |  |  | 60,548 |  |
| Adjustments to reconcile net earnings to net cash provided (used) by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 41,358 |  |  |  | 37,699 |  |
| Stock compensation expense |  |  | 6,369 |  |  |  | 7,007 |  |
| Changes in assets and liabilities |  |  | (53,839 | ) |  |  | (72,346 | ) |
| Effect of deferred taxes |  |  | (6,052 | ) |  |  | (3,706 | ) |
| Net cash provided by operating activities |  |  | 55,454 |  |  |  | 29,202 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Acquisition of business, net of cash acquired |  |  | (56,383 | ) |  |  | (17,694 | ) |
| Capital expenditures |  |  | (24,949 | ) |  |  | (16,993 | ) |
| Additions to capitalized software |  |  | (8,556 | ) |  |  | (9,263 | ) |
| Net cash used by investing activities |  |  | (89,888 | ) |  |  | (43,950 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from long-term debt |  |  | 193,000 |  |  |  | 88,000 |  |
| Principal payments on long-term debt and short-term borrowings |  |  | (122,000 | ) |  |  | (93,000 | ) |
| Dividends paid |  |  | (6,185 | ) |  |  | (6,189 | ) |
| Purchases of common stock into treasury |  |  | (7,998 | ) |  |  | (12,401 | ) |
| Other |  |  | (1,516 | ) |  |  | (2,557 | ) |
| Net cash provided (used) by financing activities |  |  | 55,301 |  |  |  | (26,147 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 309 |  |  |  | (777 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 21,176 |  |  |  | (41,672 | ) |
| Cash and cash equivalents, beginning of period |  |  | 41,866 |  |  |  | 97,724 |  |
| Cash and cash equivalents, end of period |  | $ | 63,042 |  |  |  | 56,052 |  |

[0001104659-24-086768:8k_2_02:97]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-086768:8k_2_02:98]
Other Selected Financial Data (Unaudited)

[0001104659-24-086768:8k_2_02:99]
(Dollars
in thousands)

[0001104659-24-086768:8k_2_02:100]
| Backlog And Entered Orders - Q3 2024 |  | A&D |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 4/1/24 |  | $ | 562,302 |  |  |  | 119,155 |  |  |  | 156,254 |  |  |  | 837,711 |  |
| Entered Orders |  |  | 146,890 |  |  |  | 100,012 |  |  |  | 64,829 |  |  |  | 311,731 |  |
| Sales |  |  | (114,450 | ) |  |  | (90,277 | ) |  |  | (56,056 | ) |  |  | (260,783 | ) |
| Ending Backlog - 6/30/24 |  | $ | 594,742 |  |  |  | 128,890 |  |  |  | 165,027 |  |  |  | 888,659 |  |
| Backlog And Entered Orders - YTD Q3 2024 |  | A&D |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 10/1/23 |  | $ | 484,069 |  |  |  | 133,459 |  |  |  | 154,834 |  |  |  | 772,362 |  |
| Entered Orders |  |  | 434,557 |  |  |  | 256,001 |  |  |  | 153,965 |  |  |  | 844,523 |  |
| Sales |  |  | (323,884 | ) |  |  | (260,570 | ) |  |  | (143,772 | ) |  |  | (728,226 | ) |
| Ending Backlog - 6/30/24 |  | $ | 594,742 |  |  |  | 128,890 |  |  |  | 165,027 |  |  |  | 888,659 |  |

[0001104659-24-086768:8k_2_02:101]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-086768:8k_2_02:102]
Reconciliation
of Non-GAAP Financial Measures (Unaudited)

[0001104659-24-086768:8k_2_02:103]
| EPS – Adjusted Basis Reconciliation – Q3 2024 |  |  |  |
| EPS – GAAP Basis – Q3 2024 |  | $ | 1.13 |  |
| Adjustments (defined below) |  |  | 0.03 |  |
| EPS – As Adjusted Basis – Q3 2024 |  | $ | 1.16 |  |

[0001104659-24-086768:8k_2_02:104]
Adjustments
exclude $0.03 per share consisting mainly of Corporate acquisition related costs  and restructuring charges (primarily severance)
in the third quarter of 2024.

[0001104659-24-086768:8k_2_02:105]
The
$0.03 of EPS adjustments per share consists of $898K of pre-tax charges offset by $207K of tax benefit for net impact of $691K.

[0001104659-24-086768:8k_2_02:106]
| EPS – Adjusted Basis Reconciliation – YTD Q3 2024 |  |  |  |
| EPS – GAAP Basis – YTD Q3 2024 |  | $ | 2.62 |  |
| Adjustments (defined below) |  |  | 0.10 |  |
| EPS – As Adjusted Basis – YTD Q3 2024 |  | $ | 2.72 |  |

[0001104659-24-086768:8k_2_02:107]
Adjustments
exclude $0.10 per share consisting of MPE acquisition backlog and inventory step-up charges, restructuring charges (primarily severance)
within the Test, A&D and USG segments, and Corporate acquisition related costs.

[0001104659-24-086768:8k_2_02:108]
The
$0.10 of EPS adjustments per share consists of $3,193K of pre-tax charges offset by $734K of tax benefit for net impact of $2,459K.

[0001104659-24-086768:8k_2_02:109]
| EPS – Adjusted Basis Reconciliation – Q3 2023 |  |  |  |
| EPS – GAAP Basis – Q3 2023 |  | $ | 1.08 |  |
| Adjustments (defined below) |  |  | 0.01 |  |
| EPS – As Adjusted Basis – Q3 2023 |  | $ | 1.09 |  |

[0001104659-24-086768:8k_2_02:110]
Adjustments
exclude $0.01 per share consisting mainly of Corporate acquisition related costs in the third quarter of 2023.

[0001104659-24-086768:8k_2_02:111]
The
$0.01 of EPS adjustments per share consists of $350K of pre-tax charges offset by $80K of tax benefit for net impact of $270K.

[0001104659-24-086768:8k_2_02:112]
| EPS – Adjusted Basis Reconciliation – YTD Q3 2023 |  |  |  |
| EPS – GAAP Basis – YTD Q3 2023 |  | $ | 2.34 |  |
| Adjustments (defined below) |  |  | 0.11 |  |
| EPS – As Adjusted Basis – YTD Q3 2023 |  | $ | 2.45 |  |

[0001104659-24-086768:8k_2_02:113]
Adjustments
exclude $0.11 per share consisting of executive management transition costs at Corporate, CMT acquisition inventory step-up charges and
restructuring charges within the A&D segment, and Corporate acquisition costs in the first nine months of 2023.

[0001104659-24-086768:8k_2_02:114]
The $0.11 of EPS adjustments per share consists of $3,642K of pre-tax charges offset by $838K of tax benefit for net impact of $2,804K.

## item 1.01 — body, verbatim

[0001104659-24-086768:8k_body:1]
Item 1.01

[0001104659-24-086768:8k_body:2]
Entry into a Material Definitive Agreement

[0001104659-24-086768:8k_body:3]
Pursuant to a Commitment Letter entered into on July 8, 2024 between
the Company and JPMorgan Chase Bank, N.A., on August 5, 2024, the Registrant and certain of its subsidiaries entered into Amendment No.
1 (the “Amendment”) to its Amended and Restated Credit Agreement dated August 30, 2023 (the “2023 Credit Agreement”)
among the Company and certain of its subsidiaries, JPMorgan Chase Bank, N.A. as administrative agent thereunder, the initial lenders party
thereto and Citibank, N.A. The Amendment, among other things, (i) implements a senior incremental delayed draw term loan credit facility
in an aggregate principal amount of up to $375 million (the “Incremental Facility”), and (ii) permits the direct or indirect
acquisition by the Registrant or certain of its subsidiaries of all of the issued and outstanding shares of Ultra PMES Limited, Measurement
Systems, Inc., EMS Development Corporation, and DNE Technologies, Inc. (the “Transaction”), pursuant to and in accordance
with the terms and conditions of that certain Sale and Purchase Agreement, dated July 8, 2024, among Ultra Electronics Holdings Limited,
as parent seller, the Registrant, as guarantor, and certain of the Registrant’s subsidiaries as buyers. The proceeds of the loans
drawn under the Incremental Facility will be applied to pay a portion of the cash consideration for the Transaction and other customary
fees, premiums, expenses and costs incurred in connection with the Transaction.

[0001104659-24-086768:8k_body:4]
A description of the 2023 Credit Agreement is incorporated by reference
to Note 6 to the Consolidated Financial Statements included in the Registrant’s Form 10-K for its fiscal year ended September 30,
2023, filed with the Commission on November 29, 2023, and a copy of the 2023 Credit Agreement is attached as Exhibit 4.2 to the Registrant’s
Form 10-Q filed with the Commission on May 10, 2023. Descriptions of the July 8, 2024 Commitment Letter and the July 8, 2024 Sale and
Purchase Agreement are incorporated by reference to the Registrant’s Form 8-K filed on July 8, 2024.

## item 5.02 — body, verbatim

[0001104659-24-086768:8k_body:5]
Item 5.02

[0001104659-24-086768:8k_body:6]
Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements
of Certain Officers

[0001104659-24-086768:8k_body:7]
Election of New Directors

[0001104659-24-086768:8k_body:8]
I Penelope M. Conner

[0001104659-24-086768:8k_body:9]
On August 1, 2024, pursuant to the recommendation of the Nominating
and Corporate Governance Committee, the Company’s Board of Directors, by unanimous written consent pursuant to Section 3.1 of its
Bylaws, increased the authorized size of Class II of the Board of Directors from two to three members and elected Penelope M. Conner,
age 60, as a director to fill the vacancy thereby created, to serve for a term ending at the 2025 annual meeting of shareholders;
provided that such increase and election are hereby made expressly subject to, and shall become effective only upon, the requisite prior
approval by the Federal Energy Regulatory Commission of such position and satisfaction of any and all other regulatory requirements. Ms.
Conner was also named to the Nominating and Corporate Governance Committee of the Board of Directors, subject to and effective upon the
commencement of her term as a director.

[0001104659-24-086768:8k_body:10]
With 38 years of experience in the electric and gas utility sector,
since 2002 Ms. Conner has held executive positions with Eversource Energy (NYSE: ES), an $11.9 billion utility holding company based in
New England serving Connecticut, Massachusetts and New Hampshire, most recently (since 2021) as Eversource’s Executive Vice President,
Customer Experience and Energy Strategy. She is currently responsible for ensuring that Eversource’s 4 million electric and gas
customers experience high-quality customer service while driving Eversource’s energy strategy development and capital allocation
throughout the enterprise. Prior to joining Eversource, Ms. Conner held positions of increasing responsibility from 1986 to 1998 at Duke
Energy Corporation, culminating as General Manager for Process Integration, and then from 1998 to 2002 at Tampa Electric Company as its
Director of Customer Service.

[0001104659-24-086768:8k_body:11]
Ms. Conner graduated from North Carolina State University in 1986 with
a Bachelor of Science degree in Industrial Engineering, summa cum laude. She is a registered professional engineer in North and South
Carolina.

[0001104659-24-086768:8k_body:12]
Since at least the beginning of the Company’s last fiscal year
Ms. Conner has had no reportable transactions with related persons or affiliates of the Company, and she meets all of the qualifications
of an independent director under the rules and regulations of the Securities and Exchange Commission and the New York Stock Exchange.

[0001104659-24-086768:8k_body:13]
Ms. Conner will receive compensation for her service on the Board of
Directors and its Committees pursuant to the Company’s Sub-Plan for the Compensation Plan for Non-Employee Directors adopted under
its 2018 Omnibus Incentive Plan (the “Directors Compensation Plan”), on the same basis as the Company’s other directors;
provided that as compensation for her service during the remainder of calendar 2024 she will receive, subject to and concurrently with
the commencement of her term as a director, (i) cash compensation of $25,000 plus (ii) an award of restricted share units valued at $90,000
divided by the NYSE closing price of the Company’s common stock on the effective grant date, with a one-year vesting requirement.
Under the Plan, Ms. Conner will have up to 30 days from the effective date of her election to elect whether or not to receive all or part
of her compensation on a deferred basis as provided in the Plan.

[0001104659-24-086768:8k_body:14]
II David A. Campbell

[0001104659-24-086768:8k_body:15]
On August 1, 2024, pursuant to the recommendation of the Nominating
and Corporate Governance Committee, the Company’s Board of Directors, by unanimous written consent pursuant to Section 3.1 of its
Bylaws, increased the authorized size of Class I of the Board of Directors from two to three members and elected David A. Campbell, age 55,
as a director to fill the vacancy thereby created, to serve for a term ending at the 2027 annual meeting of shareholders; provided that
such increase and election are hereby made expressly subject to, and shall become effective only upon, the requisite prior approval by
the Federal Energy Regulatory Commission of such position and satisfaction of any and all other regulatory requirements. Mr. Campbell
was also named to the Audit and Finance Committee of the Board of Directors, subject to and effective upon the commencement of his term
as a director.

[0001104659-24-086768:8k_body:16]
Since 2021 Mr. Campbell has been the President and Chief Executive
Officer and a Board Member of Evergy, Inc. (NASDAQ: EVRG), a $5.5 billion public utility holding company incorporated in 2017 and headquartered
in Kansas City, Missouri. He previously held executive positions at a number of electric and integrated energy companies in Texas as well
as at an independent energy resource and investment company, following nine years (four as a partner) in the Dallas office of McKinsey
& Company, a leading global management consulting firm providing strategic and operational counsel to top management of diverse global
corporations and institutions.

[0001104659-24-086768:8k_body:17]
Mr. Campbell holds degrees from Harvard Law School (J.D. degree magna
cum laude, 1995), Oxford University (M.Phil. International Relations, 1992), and Yale University (B.A. summa cum laude with Distinction
in History, 1990). He currently serves or has served on a number of boards including the Edison Electric Institute, the Electric Power
Research Institute, and the Leadership Council of the Yale School of the Environment.

[0001104659-24-086768:8k_body:18]
Since at least the beginning of the Company’s last fiscal year
Mr. Campbell has had no reportable transactions with related persons or affiliates of the Company, and he meets all of the qualifications
of an independent director and member of the Audit and Finance Committee under the rules and regulations of the Securities and Exchange
Commission and the New York Stock Exchange.

[0001104659-24-086768:8k_body:19]
Mr. Campbell will receive compensation for his service on the Board
of Directors and its Committees pursuant to the Directors Compensation Plan, on the same basis as the Company’s other directors;
provided that as compensation for his service during the remainder of calendar 2024 he will receive, subject to and concurrently with
the commencement of his term as a director, (i) cash compensation of $25,000 plus (ii) an award of restricted share units valued at $90,000
divided by the NYSE closing price of the Company’s common stock on the effective grant date, with a one-year vesting requirement.
Under the Plan, Mr. Campbell will have up to 30 days from the effective date of his election to elect whether or not to receive all or
part of his compensation on a deferred basis as provided in the Plan.
