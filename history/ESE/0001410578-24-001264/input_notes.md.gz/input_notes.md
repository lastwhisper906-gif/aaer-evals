# ESE notes — 0001410578-24-001264


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001410578-24-001264:notes:1]
[same as prior period, unchanged from 0001410578-24-000723:notes:1]

[0001410578-24-001264:notes:2]
The accompanying unaudited condensed consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The unaudited condensed consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP) and should be read in conjunction with the audited consolidated financial statements and notes thereto contained in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2023, as filed with the SEC on November 29, 2023.

[0001410578-24-001264:notes:3]
The Company’s results for the three-month period ended June 30, 2024 are not necessarily indicative of the results for the entire 2024 fiscal year. References to the third quarters of 2024 and 2023 represent the fiscal quarters ended June 30, 2024 and 2023, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates. Certain prior period amounts have been reclassified to conform to the current period presentation.


## us-gaap:EarningsPerShareTextBlock

[0001410578-24-001264:notes:4]
[same as prior period, unchanged from 0001410578-24-000723:notes:4]

[0001410578-24-001264:notes:5]
Basic EPS is calculated using the weighted average number of common shares outstanding during the period. Diluted EPS is calculated using the weighted average number of common shares outstanding during the period plus shares issuable upon the assumed exercise of dilutive common share options and vesting of restricted and performance shares by using the treasury stock method. The number of shares used in the calculation of earnings per share for each period presented is as follows (in thousands):

[0001410578-24-001264:notes:6]
| ​ |  | Three Months | ​ | Nine Months |
| ​ | ​ | Ended June 30, | ​ | Ended June 30, |
| ​ |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Weighted Average Shares Outstanding — Basic |  | 25,753 | ​ | 25,757 | ​ | 25,781 | ​ | 25,808 |
| Dilutive Restricted and Performance Shares | ​ | 87 | ​ | 70 | ​ | 63 | ​ | 82 |
| Adjusted Shares — Diluted |  | 25,840 | ​ | 25,827 | ​ | 25,844 | ​ | 25,890 |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001410578-24-001264:notes:7]
[same as prior period, unchanged from 0001410578-24-000723:notes:7]

[0001410578-24-001264:notes:8]
On November 9, 2023, the Company acquired MPE Limited (MPE), based in the United Kingdom, for a purchase price of approximately $56.2 million, net of cash acquired. MPE is a leading global manufacturer of high-performance EMC/EMP filters and capacitor products for military, utility, telecommunication, and other critical infrastructure applications. Since the date of acquisition, the operating results for the MPE business have been included as part of ETS-Lindgren in the Test segment. The acquisition date fair value of the assets acquired and liabilities assumed primarily were as follows: approximately $0.4 million of accounts receivable, $1.1 million of inventory, $1.7 million of property, plant and equipment, $0.7 million of accounts payable and accrued expenses, $7.8 million of deferred tax liabilities, and $31.1 million of identifiable intangible assets, mainly consisting of customer relationships totaling $29.1 million. The acquired goodwill of $30.3 million related to excess value associated with opportunities to expand the services and products that the Company can offer to its customers. The Company does not anticipate that the goodwill will be deductible for tax purposes. The Company paid a $0.2 million working capital settlement in the third quarter of fiscal 2024.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001410578-24-001264:notes:9]
[same as prior period, unchanged from 0001410578-24-000723:notes:9]

[0001410578-24-001264:notes:10]
[same as prior period, unchanged from 0001410578-24-000723:notes:10]

[0001410578-24-001264:notes:11]
[same as prior period, unchanged from 0001410578-24-000723:notes:11]

[0001410578-24-001264:notes:12]
Compensation expense related to these awards was $2.0 million and $5.5 million for the three and nine-month periods ended June 30, 2024, respectively, and $1.4 million and $6.0 million for the corresponding periods in 2023. As of June 30, 2024, there were 221,595 unvested stock units outstanding.

[0001410578-24-001264:notes:13]
[same as prior period, unchanged from 0001410578-24-000723:notes:13]

[0001410578-24-001264:notes:14]
Compensation expense related to the non-employee director grants was $0.3 million and $0.9 million for the three and nine-month periods ended June 30, 2024, respectively, and $0.3 million and $1.0 million for the corresponding periods in 2023.

[0001410578-24-001264:notes:15]
The total share-based compensation cost that has been recognized in the results of operations and included within selling, general and administrative expenses (SG&A) was $2.2 million and $6.4 million for the three and nine-month periods ended June 30, 2024, respectively, and $1.7 million and $7.0 million for the corresponding periods in 2023. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $0.5 million and $1.4 million for the three and nine-month periods ended June 30, 2024, respectively, and $0.2 million and $0.9 million for the corresponding periods in 2023. As of June 30, 2024, there was $11.0 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a remaining weighted-average period of 1.5 years.


## us-gaap:InventoryDisclosureTextBlock

[0001410578-24-001264:notes:16]
[same as prior period, unchanged from 0001410578-24-000723:notes:16]

[0001410578-24-001264:notes:17]
[same as prior period, unchanged from 0001410578-24-000723:notes:17]

[0001410578-24-001264:notes:18]
| ​ | ​ | June 30, | ​ | September 30, |
| (In thousands) |  | 2024 |  | 2023 |
| Finished goods | ​ | $ | 41,955 | ​ | 34,577 |
| Work in process | ​ | ​ | 59,837 | ​ | 42,178 |
| Raw materials | ​ | ​ | 117,520 | ​ | 107,312 |
| Total inventories | ​ | $ | 219,312 | ​ | 184,067 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001410578-24-001264:notes:19]
[same as prior period, unchanged from 0001410578-24-000723:notes:19]

[0001410578-24-001264:notes:20]
Included on the Company’s Consolidated Balance Sheets at June 30, 2024 and September 30, 2023 are the following intangible assets gross carrying amounts and accumulated amortization:

[0001410578-24-001264:notes:21]
| ​ |  | June 30, |  | September 30, |
| (Dollars in thousands) |  | 2024 |  | 2023 |
| Goodwill | ​ | $ | 535,372 | ​ | 503,177 |
| Intangible assets with determinable lives: | ​ |  | ​ | ​ | ​ |
| Patents | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 2,551 | ​ | 2,516 |
| Less: accumulated amortization | ​ |  | 1,322 | ​ | 1,218 |
| Net | ​ | $ | 1,229 | ​ | 1,298 |
| Capitalized software | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 130,648 | ​ | 121,883 |
| Less: accumulated amortization | ​ |  | 89,737 | ​ | 80,774 |
| Net | ​ | $ | 40,911 | ​ | 41,109 |
| Customer relationships | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 327,537 | ​ | 296,927 |
| Less: accumulated amortization | ​ |  | 127,322 | ​ | 113,311 |
| Net | ​ | $ | 200,215 | ​ | 183,616 |
| Other | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 15,122 | ​ | 14,232 |
| Less: accumulated amortization | ​ |  | 11,085 | ​ | 9,578 |
| Net | ​ | $ | 4,037 | ​ | 4,654 |
| Intangible assets with indefinite lives: | ​ |  | ​ | ​ | ​ |
| Trade names | ​ | $ | 162,589 | ​ | 161,447 |

[0001410578-24-001264:notes:22]
The changes in the carrying amount of goodwill attributable to each business segment for the nine months ended June 30, 2024 is as follows:

[0001410578-24-001264:notes:23]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | Aerospace | ​ | ​ |
| (Dollars in millions) |  | USG |  | Test |  | & Defense |  | Total |
| Balance as of September 30, 2023 | ​ | $ | 353.6 |  | ​ | 34.0 |  | 115.6 |  | 503.2 |
| Acquisition activity | ​ | ​ | — | ​ | ​ | 30.5 | ​ | — | ​ | 30.5 |
| Foreign currency translation | ​ | ​ | 0.9 | ​ | ​ | 0.8 | ​ | — | ​ | 1.7 |
| Balance as of June 30, 2024 | ​ | $ | 354.5 | ​ | ​ | 65.3 | ​ | 115.6 | ​ | 535.4 |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001410578-24-001264:notes:24]
[same as prior period, unchanged from 0001410578-24-000723:notes:24]

[0001410578-24-001264:notes:25]
[same as prior period, unchanged from 0001410578-24-000723:notes:25]

[0001410578-24-001264:notes:26]
[same as prior period, unchanged from 0001410578-24-000723:notes:26]

[0001410578-24-001264:notes:27]
The USG segment’s operations consist primarily of Doble Engineering Company and related subsidiaries including Morgan Schaffer and Altanova (collectively, Doble), and NRG Systems, Inc. (NRG). Doble is an industry leader in the development, manufacture and delivery of diagnostic testing solutions that enable electric power grid operators to assess the integrity of high voltage power delivery equipment. It combines three core elements for customers – diagnostic test and condition monitoring instruments, expert consulting, and testing services – and provides access to its large reserve of related empirical knowledge.

[0001410578-24-001264:notes:28]
NRG is a global market leader in the design and manufacture of decision support tools for the renewable energy industry, primarily wind and solar.

[0001410578-24-001264:notes:29]
[same as prior period, unchanged from 0001410578-24-000723:notes:28]

[0001410578-24-001264:notes:30]
[same as prior period, unchanged from 0001410578-24-000723:notes:29]

[0001410578-24-001264:notes:31]
| ​ | ​ | Three Months | ​ | Nine Months |
| ​ | ​ | Ended June 30, | ​ | Ended June 30, |
| (In thousands) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| NET SALES | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |  |
| Aerospace & Defense | ​ | $ | 114,450 | ​ | 103,469 | ​ | 323,884 | ​ | 285,434 |
| USG | ​ | ​ | 90,277 | ​ | 89,966 | ​ | 260,570 | ​ | 240,172 |
| Test | ​ | ​ | 56,056 | ​ | 55,314 | ​ | 143,772 | ​ | 157,780 |
| Consolidated totals | ​ | $ | 260,783 | ​ | 248,749 | ​ | 728,226 | ​ | 683,386 |
| EBIT | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Aerospace & Defense | ​ | $ | 21,356 | ​ | 21,665 | ​ | 61,396 | ​ | 52,996 |
| USG | ​ | ​ | 22,155 | ​ | 20,351 | ​ | 57,355 | ​ | 50,543 |
| Test | ​ | ​ | 9,292 | ​ | 8,643 | ​ | 16,614 | ​ | 21,280 |
| Corporate (loss) | ​ | ​ | (12,296) | ​ | (12,658) | ​ | (40,290) | ​ | (40,642) |
| Consolidated EBIT | ​ | ​ | 40,507 | ​ | 38,001 | ​ | 95,075 | ​ | 84,177 |
| Less: Interest expense | ​ | ​ | (3,335) | ​ | (2,495) | ​ | (9,228) | ​ | (6,422) |
| Earnings before income taxes | ​ | $ | 37,172 | ​ | 35,506 | ​ | 85,847 | ​ | 77,755 |

[0001410578-24-001264:notes:32]
[same as prior period, unchanged from 0001410578-24-000723:notes:31]

[0001410578-24-001264:notes:33]
[same as prior period, unchanged from 0001410578-24-000723:notes:32]

[0001410578-24-001264:notes:34]
[same as prior period, unchanged from 0001410578-24-000723:notes:33]


## us-gaap:DebtDisclosureTextBlock

[0001410578-24-001264:notes:35]
8.    DEBT

[0001410578-24-001264:notes:36]
The Company’s debt is summarized as follows:

[0001410578-24-001264:notes:37]
| ​ |  | June 30, | ​ | September 30, |
| (In thousands) |  | 2024 |  | 2023 |
| Total borrowings | ​ | $ | 173,000 | ​ | 102,000 |
| Current portion of long-term debt | ​ | ​ | (20,000) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 153,000 | ​ | 82,000 |

[0001410578-24-001264:notes:38]
The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of seven banks led by JP Morgan Chase Bank, N.A., as administrative agent, Bank of America, N.A., as syndication agent, and Commerce Bank and TD Bank, N.A. as co-documentation agents. The Credit Facility matures August 30, 2028, with balance due by this date.

[0001410578-24-001264:notes:39]
At June 30, 2024, the Company had approximately $321 million available to borrow under the Credit Facility, plus the $250 million increase option subject to the lenders’ consent, in addition to $63.0 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of June 30, 2024, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $5.5 million at June 30, 2024.

[0001410578-24-001264:notes:40]
Interest on borrowings under the Credit Facility is calculated at a spread over either an Adjusted Term SOFR Rate, Adjusted EURIBOR Rate, Adjusted CDOR Rate, Alternate Base Rate or Daily Simple RFR, at the Company’s election. The Credit Facility also requires a facility fee ranging from 12.5 to 25 basis points per annum on the unused portion. The interest rate spreads and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio. The weighted average interest rates were 6.7% and 6.8% for the three and nine-month periods ending June 30, 2024, respectively, and 6.05% and 5.57% for the three and nine-month periods ending June 30, 2023. As of June 30, 2024, the Company was in compliance with all covenants.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001410578-24-001264:notes:41]
[same as prior period, unchanged from 0001410578-24-000723:notes:40]

[0001410578-24-001264:notes:42]
The third quarter 2024 effective income tax rate was 21.4% compared to 21.3% in the third quarter of 2023. The effective income tax rate in the first nine months of 2024 was 21.2% compared to 22.1% for the first nine months of 2023. Income tax expense in the first nine months of 2024 was favorably impacted by discrete events that occurred during the second quarter of 2024 including the release of a foreign valuation allowance and excess tax benefit related to the vesting of share-based director compensation.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001410578-24-001264:notes:43]
[same as prior period, unchanged from 0001410578-24-000723:notes:42]

[0001410578-24-001264:notes:44]
The change in shareholders’ equity for the first three and nine months of 2024 and 2023 is shown below (in thousands):

[0001410578-24-001264:notes:45]
| ​ | ​ | Three Months Ended June 30, | ​ | Nine Months Ended June 30, |
| ​ |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Common stock | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 308 | ​ | 308 | ​ | 308 | ​ | 307 |
| Stock plans | ​ | — | ​ | — | ​ | — | ​ | 1 |
| Ending balance | ​ | 308 | ​ | 308 | ​ | 308 | ​ | 308 |
| Additional paid-in-capital | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 308,065 | ​ | 304,184 | ​ | 304,850 | ​ | 301,553 |
| Stock plans | ​ | 1,917 | ​ | 1,371 | ​ | 5,132 | ​ | 4,002 |
| Ending balance | ​ | 309,982 | ​ | 305,555 | ​ | 309,982 | ​ | 305,555 |
| Retained earnings | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 1,023,578 | ​ | 933,499 | ​ | 989,315 | ​ | 905,022 |
| Net earnings common stockholders | ​ | 29,230 | ​ | 27,943 | ​ | 67,618 | ​ | 60,548 |
| Dividends paid | ​ | (2,060) | ​ | (2,061) | ​ | (6,185) | ​ | (6,189) |
| Ending balance | ​ | 1,050,748 | ​ | 959,381 | ​ | 1,050,748 | ​ | 959,381 |
| Accumulated other comprehensive income (loss) | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | (19,300) | ​ | (18,018) | ​ | (23,969) | ​ | (31,764) |
| Foreign currency translation | ​ | (1,001) | ​ | (821) | ​ | 3,668 | ​ | 12,925 |
| Ending balance | ​ | (20,301) | ​ | (18,839) | ​ | (20,301) | ​ | (18,839) |
| Treasury stock | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | (146,241) | ​ | (139,178) | ​ | (139,362) | ​ | (126,961) |
| Share repurchases, net | ​ | (810) | ​ | (184) | ​ | (7,689) | ​ | (12,401) |
| Ending balance | ​ | (147,051) | ​ | (139,362) | ​ | (147,051) | ​ | (139,362) |
| Total equity | ​ | 1,193,686 | ​ | 1,107,043 | ​ | 1,193,686 | ​ | 1,107,043 |


## us-gaap:FairValueDisclosuresTextBlock

[0001410578-24-001264:notes:46]
[same as prior period, unchanged from 0001410578-24-000723:notes:45]

[0001410578-24-001264:notes:47]
[same as prior period, unchanged from 0001410578-24-000723:notes:46]

[0001410578-24-001264:notes:48]
[same as prior period, unchanged from 0001410578-24-000723:notes:47]

[0001410578-24-001264:notes:49]
[same as prior period, unchanged from 0001410578-24-000723:notes:48]

[0001410578-24-001264:notes:50]
[same as prior period, unchanged from 0001410578-24-000723:notes:49]

[0001410578-24-001264:notes:51]
[same as prior period, unchanged from 0001410578-24-000723:notes:50]

[0001410578-24-001264:notes:52]
The Company has estimated the fair value of its financial instruments as of June 30, 2024 and September 30, 2023 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001410578-24-001264:notes:53]
[same as prior period, unchanged from 0001410578-24-000723:notes:52]

[0001410578-24-001264:notes:54]
[same as prior period, unchanged from 0001410578-24-000723:notes:53]

[0001410578-24-001264:notes:55]
[same as prior period, unchanged from 0001410578-24-000723:notes:54]

[0001410578-24-001264:notes:56]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however, they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during the three and nine-month periods ended June 30, 2024.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001410578-24-001264:notes:57]
[same as prior period, unchanged from 0001410578-24-000723:notes:56]

[0001410578-24-001264:notes:58]
[same as prior period, unchanged from 0001410578-24-000723:notes:57]

[0001410578-24-001264:notes:59]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2024 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue within each reportable segment.

[0001410578-24-001264:notes:60]
| Three months ended June 30, 2024 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 45,404 | ​ | $ | 88,076 | ​ | $ | 42,327 | ​ | $ | 175,807 |
| Government | ​ | ​ | 69,046 | ​ | ​ | 2,201 | ​ | ​ | 13,729 | ​ | ​ | 84,976 |
| Total revenues | ​ | $ | 114,450 | ​ | $ | 90,277 | ​ | $ | 56,056 | ​ | $ | 260,783 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 95,265 | ​ | $ | 54,063 | ​ | $ | 32,575 | ​ | $ | 181,903 |
| International | ​ | ​ | 19,185 | ​ | ​ | 36,214 | ​ | ​ | 23,481 | ​ | ​ | 78,880 |
| Total revenues | ​ | $ | 114,450 | ​ | $ | 90,277 | ​ | $ | 56,056 | ​ | $ | 260,783 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 53,148 | ​ | $ | 72,985 | ​ | $ | 11,426 | ​ | $ | 137,559 |
| Over time | ​ | ​ | 61,302 | ​ | ​ | 17,292 | ​ | ​ | 44,630 | ​ | ​ | 123,224 |
| Total revenues | ​ | $ | 114,450 | ​ | $ | 90,277 | ​ | $ | 56,056 | ​ | $ | 260,783 |

[0001410578-24-001264:notes:61]
| Nine months ended June 30, 2024 |  | Aerospace |  |  | ​ |  |  | ​ |  |  | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 131,993 | ​ | $ | 254,765 | ​ | $ | 111,951 | ​ | $ | 498,709 |
| Government | ​ |  | 191,891 | ​ |  | 5,805 | ​ |  | 31,821 | ​ |  | 229,517 |
| Total revenues | ​ | $ | 323,884 | ​ | $ | 260,570 | ​ | $ | 143,772 | ​ | $ | 728,226 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 267,325 | ​ | $ | 165,789 | ​ | $ | 82,370 | ​ | $ | 515,484 |
| International | ​ |  | 56,559 | ​ |  | 94,781 | ​ |  | 61,402 | ​ |  | 212,742 |
| Total revenues | ​ | $ | 323,884 | ​ | $ | 260,570 | ​ | $ | 143,772 | ​ | $ | 728,226 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 146,076 | ​ | $ | 209,973 | ​ | $ | 29,706 | ​ | $ | 385,755 |
| Over time | ​ |  | 177,808 | ​ |  | 50,597 | ​ |  | 114,066 | ​ |  | 342,471 |
| Total revenues | ​ | $ | 323,884 | ​ | $ | 260,570 | ​ | $ | 143,772 | ​ | $ | 728,226 |

[0001410578-24-001264:notes:62]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2023 are presented in the tables below.

[0001410578-24-001264:notes:63]
| Three months ended June 30, 2023 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 45,574 | ​ | $ | 88,442 | ​ | $ | 48,407 | ​ | $ | 182,423 |
| Government | ​ | ​ | 57,895 | ​ | ​ | 1,524 | ​ | ​ | 6,907 | ​ | ​ | 66,326 |
| Total revenues | ​ | $ | 103,469 | ​ | $ | 89,966 | ​ | $ | 55,314 | ​ | $ | 248,749 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 86,031 | ​ | $ | 55,011 | ​ | $ | 32,246 | ​ | $ | 173,288 |
| International | ​ | ​ | 17,438 | ​ | ​ | 34,955 | ​ | ​ | 23,068 | ​ | ​ | 75,461 |
| Total revenues | ​ | $ | 103,469 | ​ | $ | 89,966 | ​ | $ | 55,314 | ​ | $ | 248,749 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 48,496 | ​ | $ | 74,128 | ​ | $ | 11,496 | ​ | $ | 134,120 |
| Over time | ​ | ​ | 54,973 | ​ | ​ | 15,838 | ​ | ​ | 43,818 | ​ | ​ | 114,629 |
| Total revenues | ​ | $ | 103,469 | ​ | $ | 89,966 | ​ | $ | 55,314 | ​ | $ | 248,749 |

[0001410578-24-001264:notes:64]
| Nine months ended June 30, 2023 |  | Aerospace |  |  | ​ |  |  | ​ |  |  | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 128,016 | ​ | $ | 236,715 | ​ | $ | 137,587 | ​ | $ | 502,318 |
| Government | ​ |  | 157,418 | ​ |  | 3,457 | ​ |  | 20,193 | ​ |  | 181,068 |
| Total revenues | ​ | $ | 285,434 | ​ | $ | 240,172 | ​ | $ | 157,780 | ​ | $ | 683,386 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 237,481 | ​ | $ | 154,410 | ​ | $ | 87,253 | ​ | $ | 479,144 |
| International | ​ |  | 47,953 | ​ |  | 85,762 | ​ |  | 70,527 | ​ |  | 204,242 |
| Total revenues | ​ | $ | 285,434 | ​ | $ | 240,172 | ​ | $ | 157,780 | ​ | $ | 683,386 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 129,355 | ​ | $ | 194,240 | ​ | $ | 32,565 | ​ | $ | 356,160 |
| Over time | ​ |  | 156,079 | ​ |  | 45,932 | ​ |  | 125,215 | ​ |  | 327,226 |
| Total revenues | ​ | $ | 285,434 | ​ | $ | 240,172 | ​ | $ | 157,780 | ​ | $ | 683,386 |

[0001410578-24-001264:notes:65]
[same as prior period, unchanged from 0001410578-24-000723:notes:64]

[0001410578-24-001264:notes:66]
Payment terms with our customers vary by the type and location of the customer and the products or services offered. Arrangements with customers that include payment terms extending beyond one year are not significant. The transaction price for these contracts reflects our estimate of returns and discounts, which are based on historical, current and forecasted information to determine the expected amount to which we will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation. Under the typical payment terms of our long term fixed price contracts, the customer pays us either performance-based or progress payments. Performance-based payments represent interim payments based on quantifiable measures of performance or on the achievement of specified events or milestones. Progress payments are interim payments of costs incurred as the work progresses.

[0001410578-24-001264:notes:67]
[same as prior period, unchanged from 0001410578-24-000723:notes:67]

[0001410578-24-001264:notes:68]
[same as prior period, unchanged from 0001410578-24-000723:notes:68]

[0001410578-24-001264:notes:69]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At June 30, 2024, the Company had $888.7 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 68% in the next twelve months.

[0001410578-24-001264:notes:70]
[same as prior period, unchanged from 0001410578-24-000723:notes:70]

[0001410578-24-001264:notes:71]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At June 30, 2024, contract assets, contract liabilities and accounts receivable totaled $134.6 million, $123.5 million and $213.6 million, respectively. During the first nine months of 2024, the Company recognized approximately $54 million in revenues that were included in the contract liabilities balance at September 30, 2023. At September 30, 2023, contract assets, contract liabilities and accounts receivable totaled $138.6 million, $123.1 million and $198.6 million, respectively.


## ese:OperatingAndFinancingLeasesOfLesseeDisclosureTextBlock

[0001410578-24-001264:notes:72]
[same as prior period, unchanged from 0001410578-24-000723:notes:72]

[0001410578-24-001264:notes:73]
[same as prior period, unchanged from 0001410578-24-000723:notes:73]

[0001410578-24-001264:notes:74]
[same as prior period, unchanged from 0001410578-24-000723:notes:74]

[0001410578-24-001264:notes:75]
[same as prior period, unchanged from 0001410578-24-000723:notes:75]

[0001410578-24-001264:notes:76]
[same as prior period, unchanged from 0001410578-24-000723:notes:76]

[0001410578-24-001264:notes:77]
[same as prior period, unchanged from 0001410578-24-000723:notes:77]

[0001410578-24-001264:notes:78]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended |
| ​ | ​ | June 30, | ​ | June 30, |
| (Dollars in thousands) |  | 2024 |  | 2023 |
| Finance lease cost | ​ | ​ | ​ | ​ | ​ | ​ |
| Amortization of right-of-use assets | ​ | $ | 372 | ​ | $ | 393 |
| Interest on lease liabilities | ​ | ​ | 213 | ​ | ​ | 230 |
| Operating lease cost | ​ | ​ | 1,937 | ​ | ​ | 1,858 |
| Total lease costs | ​ | $ | 2,522 | ​ | $ | 2,481 |

[0001410578-24-001264:notes:79]
| ​ | ​ | Nine Months Ended | ​ | Nine Months Ended |
| ​ | ​ | June 30, | ​ | June 30, |
| (Dollars in thousands) |  | 2024 |  | 2023 |
| Finance lease cost | ​ | ​ | ​ | ​ | ​ | ​ |
| Amortization of right-of-use assets | ​ | $ | 1,137 | ​ | $ | 1,179 |
| Interest on lease liabilities | ​ |  | 652 | ​ | ​ | 698 |
| Operating lease cost | ​ |  | 5,675 | ​ | ​ | 5,356 |
| Total lease costs | ​ | $ | 7,464 | ​ | $ | 7,233 |

[0001410578-24-001264:notes:80]
[same as prior period, unchanged from 0001410578-24-000723:notes:80]

[0001410578-24-001264:notes:81]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended |
| ​ | ​ | June 30, | ​ | June 30, |
| (Dollars in thousands) |  | 2024 |  | 2023 |
| Cash paid for amounts included in the measurement of lease liabilities | ​ | ​ | ​ | ​ | ​ | ​ |
| Operating cash flows from operating leases | ​ | $ | 1,867 | ​ | $ | 1,792 |
| Operating cash flows from finance leases | ​ | ​ | 213 | ​ | ​ | 230 |
| Financing cash flows from finance leases | ​ | ​ | 331 | ​ | ​ | 334 |
| Right-of-use assets obtained in exchange for operating lease liabilities | ​ | ​ | 515 | ​ | ​ | 402 |

[0001410578-24-001264:notes:82]
| ​ |  | Nine Months Ended |  | Nine Months Ended |
| ​ | ​ | June 30, | ​ | June 30, |
| (Dollars in thousands) | ​ | 2024 | ​ | 2023 |
| Cash paid for amounts included in the measurement of lease liabilities |  | ​ |  |  | ​ |  |
| Operating cash flows from operating leases | ​ | $ | 5,510 | ​ | $ | 5,172 |
| Operating cash flows from finance leases | ​ |  | 652 | ​ |  | 698 |
| Financing cash flows from finance leases | ​ |  | 1,013 | ​ |  | 991 |
| Right-of-use assets obtained in exchange for operating lease liabilities | ​ |  | 2,194 | ​ |  | 14,984 |

[0001410578-24-001264:notes:83]
| ​ |  | June 30, 2024 |  | June 30, 2023 | ​ |
| Weighted-average remaining lease term | ​ |  | ​ |  | ​ |
| Operating leases |  | 10.8 | years | 11.4 | years |
| Finance leases |  | 11.1 | years | 11.3 | years |
| Weighted-average discount rate |  |  |  |  |  |
| Operating leases |  | 4.56 | % | 4.42 | % |
| Finance leases |  | 4.69 | % | 4.62 | % |

[0001410578-24-001264:notes:84]
The following is a reconciliation of future undiscounted cash flows to the operating and finance lease liabilities, and the related ROU assets, presented on our condensed Consolidated Balance Sheet on June 30, 2024:

[0001410578-24-001264:notes:85]
| (Dollars in thousands) | ​ | Operating |  | Finance |
| Years Ending September 30: |  | Leases |  | Leases |
| 2024 (excluding the nine months ended June 30, 2024) | ​ | $ | 1,569 | ​ | 547 |
| 2025 | ​ | ​ | 6,108 | ​ | 2,233 |
| 2026 | ​ | ​ | 4,865 | ​ | 2,297 |
| 2027 | ​ | ​ | 4,620 | ​ | 2,357 |
| 2028 and thereafter | ​ | ​ | 33,915 | ​ | 16,470 |
| Total minimum lease payments | ​ | ​ | 51,077 | ​ | 23,904 |
| Less: amounts representing interest | ​ | ​ | 11,334 | ​ | 5,582 |
| Present value of net minimum lease payments | ​ | $ | 39,743 | ​ | 18,322 |
| Less: current portion of lease obligations | ​ | ​ | 4,595 | ​ | 1,403 |
| Non-current portion of lease obligations | ​ | ​ | 35,148 | ​ | 16,919 |
| ROU assets | ​ | $ | 37,716 | ​ | 14,055 |

[0001410578-24-001264:notes:86]
Operating lease liabilities are included in the condensed Consolidated Balance Sheet in accrued other expenses (current portion) and as a caption on the condensed Consolidated Balance Sheet (long-term portion). Finance lease liabilities are included on the condensed Consolidated Balance Sheet in accrued other expenses (current portion) and other liabilities (long-term portion). Operating lease ROU assets are included as a caption on the condensed Consolidated Balance Sheet and finance lease ROU assets are included in Property, plant and equipment on the condensed Consolidated Balance sheet.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001410578-24-001264:notes:87]
14.  NEW ACCOUNTING PRONOUNCEMENTS

[0001410578-24-001264:notes:88]
In November 2023, the FASB issued ASU 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures,” which expands annual and interim disclosure requirements for reportable segments, primarily through enhanced disclosures about significant expenses. The new segment disclosures are effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024. Management will review the extent of new disclosures necessary in the coming quarters, prior to implementation in our fiscal year 2025. Other than additional disclosure, we do not expect a change to our consolidated statements of operations, financial position, or cash flows.

[0001410578-24-001264:notes:89]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures,” which provides qualitative and quantitative updates to the rate reconciliation and income taxes paid disclosures. This ASU will be effective for fiscal years beginning after December 15, 2024. Management will review the extent of new disclosures necessary in the coming quarters, prior to implementation in our fiscal year 2026. Other than additional disclosure, we do not expect a change to our consolidated statements of operations, financial position, or cash flows.


## us-gaap:SubsequentEventsTextBlock

[0001410578-24-001264:notes:90]
15.  SUBSEQUENT EVENT

[0001410578-24-001264:notes:91]
On July 8, 2024, the Company announced that it has agreed to acquire the Signature Management & Power (or the “Business”) business of Ultra Maritime for a purchase price of approximately $550 million. The transaction will be funded through cash on hand and incremental debt, with committed financing in place. Signature Management & Power is a provider of mission-critical signature and power management solutions for submarines and surface ships for the U.S. and UK naval defense markets.  The Business is headquartered in Long Island, New York, operates out of four facilities based in the U.S. and the UK, and has approximately 410 employees.  Signature Management & Power will become part of ESCO’s Aerospace & Defense segment and is expected to have approximately $175 million of revenue in calendar year 2024.  The closing of the transaction is subject to certain conditions, including the (i) expiration or termination of the applicable waiting period under the Hart-Scott-Rodino Antitrust Improvements Act of 1976 in the U.S. and (ii) receipt of clearance under the UK National Security and Investment Act of 2021.

[0001410578-24-001264:notes:92]
Pursuant to a Commitment Letter entered into on July 8, 2024 between the Company and JPMorgan Chase Bank, N.A., on August 5, 2024 the Registrant and certain of its subsidiaries entered into Amendment No. 1 (the “Amendment”) to its Amended and Restated Credit Agreement dated August 30, 2023 (the “2023 Credit Agreement”) among the Company and certain of its subsidiaries, JPMorgan Chase Bank, N.A., as administrative agent thereunder, the initial lenders party thereto and Citibank, N.A. The Amendment, among other things, (i) implements a senior incremental delayed draw term loan credit facility in an aggregate principal amount of up to $375 million (the “Incremental Facility”), and (ii) permits the direct or indirect acquisition by the

[0001410578-24-001264:notes:93]
Registrant or certain of its subsidiaries of all of the issued and outstanding shares of Ultra PMES Limited, Measurement Systems, Inc., EMS Development Corporation, and DNE Technologies, Inc. (the “Transaction”), pursuant to and in accordance with the terms and conditions of that certain Sale and Purchase Agreement, dated July 8, 2024, among Ultra Electronics Holdings Limited, as parent seller, the Registrant, as guarantor, and certain of the Registrant’s subsidiaries as buyers. The proceeds of the loans drawn under the Incremental Facility will be applied to pay a portion of the cash consideration for the Transaction and other customary fees, premiums, expenses and costs incurred in connection with the Transaction. See further discussion of the transaction and financing arrangements in the Company’s Form 8-K’s filed on July 8, 2024 and August 7, 2024.
