# ESE MD&A — 0001104659-21-102250


## mdna

[0001104659-21-102250:mdna:1]
[same as prior period, unchanged from 0001104659-21-062898:mdna:1]

[0001104659-21-102250:mdna:2]
[same as prior period, unchanged from 0001104659-21-062898:mdna:2]

[0001104659-21-102250:mdna:3]
The COVID-19 global pandemic has continued to create significant and unprecedented challenges, and during these highly uncertain times, our top priority remains the health and safety of our employees, customers and suppliers, thereby securing the financial well-being of the Company and supporting business continuity. To date, our global supply chains have not been materially affected by the pandemic. Given our diverse portfolio of strong, durable businesses serving non-discretionary end-markets, the strength and resilience of our business model positions us to continue our long-term outlook. A portion of our workforce has worked from home at times due to COVID-19, however we have not had to redesign or design new internal controls over financial reporting at this time. Depending on the duration of COVID-19, it may become necessary for us to redesign or design new internal controls over financial reporting in a future period. We do not believe such an event will have a material impact on our business.

[0001104659-21-102250:mdna:4]
The economic uncertainty, changes in the propensity for the general public to travel by air, and reductions in demand for commercial aircraft as a result of the COVID-19 pandemic have adversely impacted net sales and operating results in certain of our Aerospace and Defense reporting units. In addition, our Westland facility had a partial shutdown of its facility for several weeks during the first quarter of 2021 due to COVID-19. We are monitoring the impacts of COVID-19 on the fair value of assets. We determined that there was no impairment for the three and nine months ended June 30, 2021 and the fair value of each reporting unit substantially exceeded carrying value, with the exception of Mayday and Westland where fair value exceeded carrying value by less than 10%. At June 30, 2021, we had $30 million and $18 million of goodwill recorded for Mayday and Westland, respectively. The valuation methodology we use involves estimates of discounted cash flows, which are subject to change, and if they change negatively it could result in the need to write down those assets to fair value. We will continue to monitor the impacts of COVID-19 on the fair value of assets. For further discussion, refer to Management’s Discussion and Analysis contained in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2020.

[0001104659-21-102250:mdna:5]
[same as prior period, unchanged from 0001104659-21-062898:mdna:6]

[0001104659-21-102250:mdna:6]
References to the third quarters of 2021 and 2020 represent the three-month periods ended June 30, 2021 and 2020, respectively.

[0001104659-21-102250:mdna:7]
[same as prior period, unchanged from 0001104659-21-062898:mdna:8]

[0001104659-21-102250:mdna:8]
In the third quarter of 2021, sales, net earnings and diluted earnings per share were $181.4 million, $14.9 million and $0.57 per share, respectively, compared to $172.7 million, $18.7 million and $0.72 per share, respectively, in the third quarter of 2020. In the first nine months of 2021, sales, net earnings and diluted earnings per share from continuing operations were $510.0 million, $43.1 million and $1.65 per share, respectively, compared to $524.9 million, $47.3 million and $1.81 per share, respectively, in the first nine months of 2020. See footnote 13, Quarterly Financial Information, for further discussion about the impact to the first and second quarters of 2021 and the fourth quarter of 2020.

[0001104659-21-102250:mdna:9]
[same as prior period, unchanged from 0001104659-21-062898:mdna:10]

[0001104659-21-102250:mdna:10]
In the third quarter of 2021, net sales of $181.4 million were $8.7 million, or 5.0%, higher than the $172.7 million in the third quarter of 2020. In the first nine months of 2021, net sales of $510.0 million were $14.9 million, or 2.8%, lower than the $524.9 million in the first nine months of 2020. The increase in net sales in the third quarter of 2021 as compared to the third quarter of 2020 was due to a $5.1 million increase in the USG segment, a $2.1 million increase in the Test segment, and a $1.5 million increase in the Aerospace & Defense segment. The decrease in net sales in the first nine months of 2021 as compared to the first nine months of 2020 was due to a $21.9 million decrease in the Aerospace & Defense segment, partially offset by a $4.5 million increase in the Test segment and a $2.5 million increase in the USG segment.

[0001104659-21-102250:mdna:11]
[same as prior period, unchanged from 0001104659-21-062898:mdna:12]

[0001104659-21-102250:mdna:12]
In the third quarter of 2021, net sales of $85.6 million were $1.5 million, or 1.8%, higher than the $84.1 million in the third quarter of 2020. In the first nine months of 2021, net sales of $234.7 million were $22.0 million, or 8.6%, lower than the $256.7 million in the first nine months of 2020. The sales increase in the third quarter of 2021 compared to the third quarter of 2020 was mainly due to a $2.4 million increase in net sales at Globe, a $1.7 million increase in net sales at VACCO and a $1.1 million increase in net sales at PTI, partially offset by a $3.4 million decrease in net sales at Mayday driven by the impact of the COVID-19 pandemic. The sales decrease in the first nine months of 2021 compared to the first nine months of 2020 was mainly due to an $14.9 million decrease in net sales at Mayday, a $9.4 million decrease in net sales at Crissair, an $8.2 million decrease in net sales at PTI, and a $2.9 million

[0001104659-21-102250:mdna:13]
decrease in net sales at Westland  primarily driven by the impact of the COVID-19 pandemic; partially offset by a $9.5 million increase in net sales at VACCO and a $3.9 million increase in net sales at Globe driven by an increase in navy defense.

[0001104659-21-102250:mdna:14]
[same as prior period, unchanged from 0001104659-21-062898:mdna:15]

[0001104659-21-102250:mdna:15]
In the third quarter of 2021, net sales of $47.7 million were $5.1 million, or 12.0%, higher than the $42.6 million in the third quarter of 2020. In the first nine months of 2021, net sales of $141.8 million were $2.6 million, or 1.9%, higher than the $139.2 million in the first nine months of 2020. The increase in the third quarter of 2021 compared to the third quarter of 2020 was mainly due to higher service and product revenue at Doble and an increase in product sales at NRG.   The increase in the first nine months of 2021 compared to the first nine months of 2020 was mainly due to an increase in product sales at NRG, partially offset by lower events and service revenue at Doble primarily driven by the impact of COVID-19.

[0001104659-21-102250:mdna:16]
[same as prior period, unchanged from 0001104659-21-062898:mdna:17]

[0001104659-21-102250:mdna:17]
In the third quarter of 2021, net sales of $48.1 million were $2.1 million, or 4.6%, higher than the $46.0 million in the third quarter of 2020. In the first nine months of 2021, net sales of $133.4 million were $4.4 million, or 3.4%, higher than the $129.0 million in the first nine months of 2020. The increase in the third quarter of 2021 as compared to the third quarter of 2020 was primarily due to higher sales from the Company’s U.S. and European operations totaling $7.4 million partially offset by a $5.3 million decrease in sales from the segment’s Asian operations due to the timing of test and measurement chamber projects. The increase in the first nine months of 2021 compared to the first nine months of 2020 was due to higher sales from the Company’s European operations totaling $6.1 million partially offset by a $1.7 million decrease in sales from the segment’s Asian and U.S. operations due to the timing of test and measurement chamber projects.

[0001104659-21-102250:mdna:18]
[same as prior period, unchanged from 0001104659-21-062898:mdna:19]

[0001104659-21-102250:mdna:19]
Backlog was $539.0 million at June 30, 2021 compared with $539.0 million at September 30, 2020. The Company received new orders totaling $203.8 million in the third quarter of 2021 compared to $157.8 million in the third quarter of 2020. Of the new orders received in the third quarter of 2021, $95.1 million related to Aerospace & Defense products, $53.2 million related to Test products, and $55.5 million related to USG products. Of the new orders received in the third quarter of 2020, $65.9 million related to Aerospace & Defense products, $41.5 million related to Test products, and $50.4 million related to USG products.

[0001104659-21-102250:mdna:20]
The Company received new orders totaling $537.7 million in the first nine months of 2021 compared to $623.9 million in the first nine months of 2020. Of the new orders received in the first nine months of 2021, $248.8 million related to Aerospace & Defense products, $141.1 million related to Test products, and $147.8 million related to USG products. Of the new orders received in the first nine months of 2020, $350.9 million related to Aerospace & Defense products, $121.8 million related to Test products, and $151.2 million related to USG products.

[0001104659-21-102250:mdna:21]
[same as prior period, unchanged from 0001104659-21-062898:mdna:22]

[0001104659-21-102250:mdna:22]
Selling, general and administrative (SG&A) expenses for the third quarter of 2021 were $42.9 million (23.6% of net sales), compared with $36.9 million (21.4% of net sales) for the third quarter of 2020. For the first nine months of 2021, SG&A expenses from continuing operations were $122.6 million (24.0% of net sales) compared to $119.0 million (22.7% of net sales) for the first nine months of 2020. The increase in SG&A in the third quarter and first nine months of 2021 compared to the corresponding periods of 2021 was mainly due to a $2.0 million increase at Corporate for compensation expenses due to the transition of key executives and a $1.0 million increase at Corporate due to acquisition costs.

[0001104659-21-102250:mdna:23]
[same as prior period, unchanged from 0001104659-21-062898:mdna:24]

[0001104659-21-102250:mdna:24]
Amortization of intangible assets from continuing operations was $4.9 million and $14.7 million for the third quarter and first nine months of 2021, respectively, compared to $5.5 million and $16.6 million for the corresponding periods of 2020. Amortization expenses consist of amortization of acquired intangible assets from acquisitions and other identifiable intangible assets (primarily software). The decrease in amortization expense in the third quarter and first nine months of 2021 compared to the corresponding periods of 2020 was mainly due to a decrease in amortization of capitalized software.

[0001104659-21-102250:mdna:25]
OTHER EXPENSES (INCOME), NET

[0001104659-21-102250:mdna:26]
Other expenses (income), net, was $0.6 million in the third quarter of 2021 compared to other expenses (income), net, of $(0.8) million in the third quarter of 2020. The principal component of other expenses, net, in the third quarter of 2021 was $0.5 million of facility consolidation charges for the Doble Morgan Schaffer facility. The principal component of other income, net, in the third quarter of 2020 was a gain on derivative instruments of $0.5 million.

[0001104659-21-102250:mdna:27]
Other (income) expenses, net, was $(1.3) million of income in the first nine months of 2021 compared to other expenses, net, of $0.2 million in the first nine months of 2020. The principal component of other (income), expenses, net, in the first nine months of 2021 was a gain of approximately $2 million for the final settlement on the sale of the Doble Watertown, MA building, partially offset by facility consolidation charges for the Doble Manta and Morgan Schaffer facilities. There were no individually significant items in other expenses, net, in the first nine months of 2020.

[0001104659-21-102250:mdna:28]
[same as prior period, unchanged from 0001104659-21-062898:mdna:30]

[0001104659-21-102250:mdna:29]
The Company evaluates the performance of its operating segments based on EBIT, and provides EBIT on a consolidated basis, which is a non-GAAP financial measure. Please refer to the discussion of non-GAAP financial measures in Note 6 to the Consolidated Financial Statements, above. EBIT was $19.4 million (10.7% of net sales) for the third quarter of 2021 compared to $23.3 million (13.5% of net sales) for the third quarter of 2020. For the first nine months of 2021, EBIT was $57.1 million (11.2% of net sales) compared to $61.5 million (11.7% of net sales) for the first nine months of 2020.

[0001104659-21-102250:mdna:30]
[same as prior period, unchanged from 0001104659-21-062898:mdna:32]

[0001104659-21-102250:mdna:31]
| ​ | ​ | Three Months Ended | ​ | Nine Months Ended |
| ​ | ​ | June 30, | ​ | June 30, |
| (In thousands) |  | 2021 | ​ | 2020 | ​ | 2021 |  | 2020 |
| Consolidated EBIT | ​ | $ | 19,423 | ​ | ​ | 23,332 | ​ | 57,085 | ​ | 61,468 |
| Less: Interest expense, net | ​ |  | (480) |  | ​ | (1,523) |  | (1,453) |  | (5,264) |
| Less: Income tax | ​ |  | (4,034) |  |  | (3,122) |  | (12,501) |  | (8,931) |
| Net earnings from continuing operations | ​ | $ | 14,909 |  | ​ | 18,687 |  | 43,131 |  | 47,273 |

[0001104659-21-102250:mdna:32]
[same as prior period, unchanged from 0001104659-21-062898:mdna:34]

[0001104659-21-102250:mdna:33]
EBIT in the third quarter of 2021 was $16.7 million (19.5% of net sales) compared to $17.4 million (20.7% of net sales) in the third quarter of 2020. EBIT in the first nine months of 2021 was $42.0 million (17.9% of net sales) compared to $51.7 million (20.1% of net sales) in the first nine months of 2020. The decrease in EBIT in the third quarter of 2021 compared to the third quarter of 2020 was mainly due to $2.1 million of pretax charges at Westland driven by new product development challenges, increased production costs, and product quality issues; lower sales volumes at Mayday; partially offset by an increase in EBIT at VACCO and Globe due to the higher sales volumes as mentioned above. The decrease in EBIT in the first nine months of 2021 compared to the first nine months of 2020 was mainly due to $4.4 million of pretax charges at Westland driven by new product development challenges, increased production costs, and product quality issues; lower sales volumes at Mayday, Crissair and PTI; partially offset by an increase in EBIT at VACCO and Globe due to the higher sales volumes as mentioned above. In addition, EBIT in the first quarter of 2021 was negatively impacted by a $0.3 million inventory step-up charge related to the acquisition of Advanced Technology Machining, Inc. and TECC Grinding, Inc. (ATM).

[0001104659-21-102250:mdna:34]
[same as prior period, unchanged from 0001104659-21-062898:mdna:36]

[0001104659-21-102250:mdna:35]
EBIT in the third quarter of 2021 was $8.2 million (17.2% of net sales) compared to $6.2 million (14.5% of net sales) in the third quarter of 2020. EBIT in the first nine months of 2021 was $27.7 million (19.5% of net sales) compared to $20.3 million (14.6% of net sales) in the first nine months of 2020. The increase in EBIT in the third quarter of 2021 compared to the third quarter of 2020 was mainly due higher sales volumes partially offset by $0.5 million of facility consolidation charges at its Doble Morgan Schaffer facility, and an increase in EBIT at NRG due to higher sales volumes as mentioned above.  The increase in EBIT in the first nine months of 2021 compared to the first nine months of 2020 was mainly due to higher EBIT at Doble driven by favorable product mix, $2 million final settlement received on the sale of the Doble Watertown facility, partially offset by $1.8 million of facility consolidation charges at its Doble Manta and Morgan Schaffer facilities, and an increase in EBIT at NRG due to higher sales volumes.

[0001104659-21-102250:mdna:36]
[same as prior period, unchanged from 0001104659-21-062898:mdna:38]

[0001104659-21-102250:mdna:37]
EBIT in the third quarter of 2021 was $6.8 million (14.0% of net sales) compared to $7.2 million (15.6% of net sales) in the third quarter of 2020. EBIT in the first nine months of 2021 was $17.8 million (13.3% of net sales) compared to $17.5 million (13.5% of net sales) in the first nine months of 2020. The increase in EBIT in the first nine months of 2021 compared to the first nine months of 2020 was primarily due to product mix and higher margins on projects mainly from the segment’s Asian operations.

[0001104659-21-102250:mdna:38]
[same as prior period, unchanged from 0001104659-21-062898:mdna:40]

[0001104659-21-102250:mdna:39]
Corporate costs included in EBIT were $12.3 million and $30.4 million in the third quarter and first nine months of 2021, respectively, compared to $7.4 million and $28.0 million in the corresponding periods of 2020. The increase in Corporate costs in the third quarter and first nine months of 2021 compared to the corresponding periods of 2020 was mainly due to an increase in compensation costs related to the transition of key executives and acquisition costs.

[0001104659-21-102250:mdna:40]
[same as prior period, unchanged from 0001104659-21-062898:mdna:42]

[0001104659-21-102250:mdna:41]
Interest expense was $0.5 million and $1.5 million in the third quarter and first nine months of 2021, respectively, and $1.5 million and $5.3 million in the corresponding periods of 2020. The decrease in interest expense in the third quarter and first nine months of 2021 compared to the corresponding periods of 2020 was mainly due to lower average outstanding borrowings and lower average interest rates. Average outstanding borrowings were $39 million and $44 million in the third quarter and first nine months of 2021, respectively, and $151 million and $193 million in the corresponding periods of 2020.

[0001104659-21-102250:mdna:42]
[same as prior period, unchanged from 0001104659-21-062898:mdna:44]

[0001104659-21-102250:mdna:43]
The third quarter 2021 effective income tax rate was 21.3% compared to 14.3% in the third quarter of 2020. The effective income tax rate from continuing operations in the first nine months of 2021 was 22.5% compared to 15.9% in the first nine months of 2020. The income tax expense in the third quarter and first nine months of 2021 was favorably impacted by a tax return to provision true-up to foreign derived intangible income and other 2020 true-ups decreasing the third quarter and year-to-date effective tax rate by 3.9% and 1.2%, respectively.

[0001104659-21-102250:mdna:44]
The income tax expense in the third quarter and first nine months of 2020 was favorably impacted mainly by the following items: 1) an increase in the available 2019 foreign tax credit which was attributable to new information and tax planning strategies reducing the third quarter effective tax rate and year-to-date effective tax rate by 3.3% and 1.3%; and 2) new information and tax planning strategies resulted in an increase in the 2020 foreign tax credit and the catch-up of the benefit which reduced the 2020 third quarter effective tax rate by 2.5%. The year-to-date 2020 effective tax rate was favorably impacted by the release of a valuation allowance of $2.8 million for foreign net operating losses decreasing the year-to-date 2020 effective tax rate by 5.1%.

[0001104659-21-102250:mdna:45]
[same as prior period, unchanged from 0001104659-21-062898:mdna:46]

[0001104659-21-102250:mdna:46]
The Company’s overall financial position and liquidity remains strong. The effects of COVID-19 have not materially affected liquidity. Working capital from continuing operations (current assets less current liabilities) increased to $217.5 million at June 30, 2021 from $187.3 million at September 30, 2020. Accounts receivable decreased by $8.7 million during this period primarily due to a $12.6 million decrease within the Test segment due to increased focus on collections during the period and timing of payments; partially offset by a $4.8 million increase within the USG segment due to the timing of payments.

[0001104659-21-102250:mdna:47]
Net cash provided by operating activities from continuing operations was $75.4 million and $53.8 million in the first nine months of 2021 and 2020, respectively. The increase in net cash provided by operating activities from continuing operations in the first nine months of 2021 as compared to the first nine months of 2020 was mainly driven by lower working capital requirements.

[0001104659-21-102250:mdna:48]
Capital expenditures from continuing operations were $17.9 million and $28.3 million in the first nine months of 2021 and 2020, respectively. The decrease in the first nine months of 2021 compared to the prior year period was mainly due to the building improvement additions in 2020 at the new Doble headquarters facility. In addition, the Company incurred expenditures for capitalized software of $6.5 million and $6.6 million in the first nine months of 2021 and 2020, respectively.

[0001104659-21-102250:mdna:49]
Credit Facility

[0001104659-21-102250:mdna:50]
At June 30, 2021, the Company had approximately $444 million available to borrow under its bank credit facility, a $250 million increase option subject to lender approval, and $78.4 million cash on hand. At June 30, 2021, the Company had $48 million of outstanding borrowings under the credit facility in addition to outstanding letters of credit of $8.4 million. Cash flow from operations and borrowings under the Company’s credit facility are expected to meet the Company’s capital requirements and operational needs for the foreseeable future. The Company’s ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.

[0001104659-21-102250:mdna:51]
Subsequent Events

[0001104659-21-102250:mdna:52]
On May 20, 2021, the Company announced it had entered into an agreement to acquire I.S.A. Altanova Group S.R.L. (Altanova), a supplier in the field of advanced condition assessment technologies including partial discharge measurement and analysis, as well as test instruments for electrical apparatus. Altanova, which will become part of the USG operating segment, had annual sales of approximately $30 million in 2020. As of June 30, 2021, the Company had 30 million Euros held in an escrow account related to this transaction which will be used to partially fund the acquisition. The transaction was subject to Italian regulatory approval, which was obtained and the transaction closed on July 29, 2021.

[0001104659-21-102250:mdna:53]
On August 9, 2021, the Company announced it had acquired the assets of Phenix Technologies, Inc. (Phenix), a manufacturer of stationary and portable high voltage, high current, high power test systems, components and solutions supporting the electric utility industry. Phenix, which will become part of the USG operating segment, had annual sales of approximately $25 million in 2020.

[0001104659-21-102250:mdna:54]
[same as prior period, unchanged from 0001104659-21-062898:mdna:53]

[0001104659-21-102250:mdna:55]
A quarterly dividend of $0.08 per share, totaling $2.1 million, was paid on October 15, 2020 to stockholders of record as of October 1, 2020. A quarterly dividend of $0.08 per share, totaling $2.1 million, was paid on January 19, 2021 to stockholders of record as of January 4, 2021. A quarterly dividend of $0.08 per share, totaling $2.1 million, was paid on April 16, 2021 to stockholders of record as of April 1, 2021. Subsequent to June 30, 2021, a quarterly dividend of $0.08 per share, totaling $2.1 million, was paid on July 16, 2021 to stockholders of record as of July 1, 2021.

[0001104659-21-102250:mdna:56]
New Share Repurchase Program

[0001104659-21-102250:mdna:57]
On August 5, 2021, the Company’s Board of Directors adopted a new stock repurchase program, replacing the previous program which was adopted in 2012 and was scheduled to expire September 30, 2021. Under the new program, which is similar to the previous one, Management may repurchase shares of its outstanding stock in the open market and otherwise throughout the period ending September 30, 2024. The total value authorized is the lesser of $200 million or the dollar limitation imposed by the Company’s Credit Agreement. The repurchase program does not obligate the Company to repurchase any particular amount of stock, and it may be modified, extended, suspended or discontinued at any time. The timing and amount of repurchases are determined by Management based on a variety of factors such as the market price of our common stock, our corporate requirements, and overall market conditions. Purchases of our common stock may be made in open market transactions effected through a broker-dealer at prevailing market prices, in block trades, or in privately negotiated transactions. In addition, we may repurchase common stock through private or other transactions outside of the repurchase program.

[0001104659-21-102250:mdna:58]
[same as prior period, unchanged from 0001104659-21-062898:mdna:58]

[0001104659-21-102250:mdna:59]
[same as prior period, unchanged from 0001104659-21-062898:mdna:59]

[0001104659-21-102250:mdna:60]
[same as prior period, unchanged from 0001104659-21-062898:mdna:60]

[0001104659-21-102250:mdna:61]
Contingencies

[0001104659-21-102250:mdna:62]
As a normal incident of the business in which the Company is engaged, various claims, charges and litigation are asserted or commenced against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. In the opinion of Management, the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company, are adequately reserved, are covered by insurance, or would not have a material adverse effect on the Company’s results from operations, capital expenditures, or competitive position.

[0001104659-21-102250:mdna:63]
[same as prior period, unchanged from 0001104659-21-062898:mdna:63]

[0001104659-21-102250:mdna:64]
Investors are cautioned that such statements are only predictions and speak only as of the date of this Form 10-Q, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment, including but not limited to those described in Item 1A, “Risk Factors,” of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2020 and the following: the success and timing of COVID-19 vaccines in ending the pandemic and the effects of known or unknown COVID-19 variants; the continuing impact of the COVID-19 pandemic including labor shortages, facility closures, shelter in place policies or quarantines, material shortages, transportation delays, termination or delays of Company contracts and the inability of our suppliers or customers to perform, the impacts of natural disasters on the Company’s operations and those of the Company’s customers and suppliers; the timing and content of future contract awards or customer orders; the appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer contracts or orders; weakening of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties; the availability of selected acquisitions; delivery delays or defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability of certain raw materials; labor disputes; changes in U.S. tax laws and regulations; other changes in laws and regulations including but not limited to changes in accounting standards and foreign taxation; changes in interest rates; costs relating to environmental matters arising from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the integration of recently acquired businesses.
