# ESE 8-K — 0001104659-21-102150 filed 2021-08-09

## item codes, every 8-K on or before 2021-08-09

- 2021-08-09 0001104659-21-102150 — 2.02, 7.01, 9.01
- 2021-05-04 0001104659-21-060985 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2021-04-05 0001104659-21-046581 — 5.02, 9.01
- 2021-02-08 0001104659-21-013712 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2020-12-09 0001104659-20-133674 — 5.02, 9.01
- 2020-12-07 0001104659-20-132861 — 5.02, 7.01, 9.01
- 2020-11-19 0001104659-20-127352 — 2.02, 5.02, 7.01, 9.01
- 2020-08-10 0001104659-20-092734 — 2.02, 7.01, 9.01
- 2020-05-06 0001104659-20-057442 — 2.02, 7.01, 8.01, 9.01
- 2020-02-04 0001104659-20-010640 — 2.02, 5.07, 7.01, 9.01
- 2020-01-07 0001104659-20-001789 — 2.01, 9.01
- 2019-11-19 0001104659-19-065437 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2019-11-18 0001104659-19-065096 — 1.01, 2.02, 7.01, 9.01
- 2019-09-30 0001144204-19-046523 — 1.01, 1.02, 2.03, 9.01
- 2019-08-08 0001144204-19-038567 — 2.02, 7.01, 9.01
- 2019-05-07 0001144204-19-024241 — 2.02, 5.02, 7.01, 9.01
- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2021-08-09

- none on or before 2021-08-09

## item 2.02 — earnings release, exhibit 99.1

[0001104659-21-102150:8k_2_02:1]
EX-99.1
2
tm2124297d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-21-102150:8k_2_02:2]
Exhibit 99.1

[0001104659-21-102150:8k_2_02:3]
| NEWS FROM |  |

[0001104659-21-102150:8k_2_02:4]
For more information contact:

[0001104659-21-102150:8k_2_02:5]
Kate Lowrey

[0001104659-21-102150:8k_2_02:6]
Director, Investor Relations

[0001104659-21-102150:8k_2_02:7]
ESCO Technologies Inc.

[0001104659-21-102150:8k_2_02:8]
(314) 213-7277

[0001104659-21-102150:8k_2_02:9]
ESCO ANNOUNCES THIRD QUARTER FISCAL 2021
RESULTS

[0001104659-21-102150:8k_2_02:10]
- Q3 GAAP EPS $0.57 and Adjusted EPS $0.67
-

[0001104659-21-102150:8k_2_02:11]
- YTD 2021 GAAP EPS $1.65 and Adjusted EPS
$1.75 (versus $1.87 YTD 2020) -

[0001104659-21-102150:8k_2_02:12]
- $75 Million YTD Cash Flow from Operations
 –

[0001104659-21-102150:8k_2_02:13]
- Q3 Orders Over $200 Million - Book-to-bill
of 1.12 -

[0001104659-21-102150:8k_2_02:14]
ST. LOUIS, August 9, 2021 – ESCO Technologies
Inc. (NYSE: ESE) (ESCO, or the Company) today reported its operating results for the third quarter and nine months ended June 30, 2021
(Q3 2021 and YTD 2021) compared to the third quarter and nine months ended June 30, 2020 (Q3 2020 and YTD 2020).

[0001104659-21-102150:8k_2_02:15]
Vic Richey, Chairman and Chief Executive Officer,
commented, “Our dedicated team continues to successfully manage through the impacts of the COVID-19 global pandemic. Our liquidity
and end-market diversity have helped provide stability in our operating results as we have navigated through this challenging time. Our
commitment to improving working capital management, cost reduction activities, and new product development has us well-positioned for
profitable growth as our end-markets continue to recover.”

[0001104659-21-102150:8k_2_02:16]
“At the beginning of this fiscal year, we stated
that with the strength of the first half of fiscal 2020 (pre-COVID), we projected the first half of fiscal 2021 to be slightly lower in
comparison to 2020, and that we expected the second half of 2021 to be a favorable comparison to the prior year given our expectation
of tangible elements of recovery. Due to our focus on effective cost management and program execution, our first half Adjusted EPS and
Adjusted EBITDA exceeded the prior year on lower revenue (as presented in our May 4, 2021 earnings release for Q2 and the first half of
2021). In Q3, we began to see positive signs of the start of longer term recovery across our end-markets most affected by COVID. Q3 entered
orders were up $46 million (29 percent) over the prior year Q3 to over $200 million, with growth in commercial and military aerospace,
Navy, space, electric utility and renewable energy. Sales increased 5 percent over the prior year with all three business segments posting
higher sales for the quarter. We will continue our focus on optimizing our cost structure, driving working capital improvement, and investing
in the business to deliver profitable growth going forward.”

[0001104659-21-102150:8k_2_02:17]
Discrete Items

[0001104659-21-102150:8k_2_02:18]
During Q3 2021, the Company incurred $2.7 million
($0.10 per share) consisting of after-tax charges at Corporate due to one-time compensation costs related to management transition and
acquisition costs ($0.09 per share), and charges related to the USG (Morgan Schaffer) facility move ($0.01 per share). These costs are
excluded from the calculation of Q3 2021 Adjusted EBITDA and Adjusted EPS.

[0001104659-21-102150:8k_2_02:19]
YTD 2021, the Company has incurred $2.8 million ($0.10
per share) consisting of after-tax charges at Corporate due to one-time compensation and acquisition costs ($0.10 per share), an ATM acquisition
inventory step-up charge ($.01 per share), and charges related to USG (Manta and Morgan Schaffer) facility consolidations ($0.05 per share),
partially offset by the final settlement from the sale of the Doble Watertown facility ($0.06 gain per share). These costs are excluded
from the calculation of Q3 2021 YTD Adjusted EBITDA and Adjusted EPS.

[0001104659-21-102150:8k_2_02:20]
During Q3 2020, the Company incurred $0.9 million
($0.04 per share) of after-tax charges primarily related to incremental costs associated with COVID-19. These costs are excluded from
the calculation of Q3 2020 Adjusted EBITDA and Adjusted EPS.

[0001104659-21-102150:8k_2_02:21]
In the first nine months of 2020, the Company incurred
$1.5 million ($0.06 per share) of after-tax charges primarily related to incremental costs associated with COVID-19 ($0.04 per share)
and charges related to the move of the Doble headquarters facility ($.02 per share). In addition, during Q1 2020, the company completed
the sale of its Technical Packaging segment which resulted in gross cash proceeds of $191 million and a net gain on the sale of $77 million,
or $2.91 per share, which is recorded as discontinued operations.

[0001104659-21-102150:8k_2_02:22]
The financial results presented include certain non-GAAP
financial measures such as Adjusted SG&A, EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS, as defined within the “Non-GAAP
Financial Measures” described below. Any non-GAAP financial measures presented are reconciled to their respective GAAP equivalents.
Management believes these non-GAAP financial measures are useful in assessing the ongoing operational profitability of the Company’s
business segments, and therefore, allow shareholders better visibility into the Company’s underlying operations. See “Non-GAAP
Financial Measures” described below.

[0001104659-21-102150:8k_2_02:23]
Earnings Summary

[0001104659-21-102150:8k_2_02:24]
Q3 2021 GAAP EPS was $0.57 per share (GAAP net earnings of $14.9 million)
and included the net earnings impact of the Q3 2021 Discrete Items described above. Excluding the net earnings impact of the Discrete
Items, Q3 2021 Adjusted EPS was $0.67 per share. In the third quarter, the Company’s P&L was negatively impacted by approximately
$2.1 million driven by new product development challenges, increased production costs, and product quality issues at our Westland Technologies
subsidiary, within our A&D segment. We have already taken a number of steps to correct production issues and reduce costs throughout
the operation. Westland will continue to be an important part of the overall A&D group and we are actively exploring additional opportunities
for synergies with our Globe operating unit.

[0001104659-21-102150:8k_2_02:25]
YTD 2021 GAAP EPS was $1.65 per share (GAAP net earnings
of $43.1 million) and included the net earnings impact of the YTD 2021 Discrete Items described above. Excluding the net earnings impact
of the Discrete Items, YTD 2021 Adjusted EPS was $1.75 per share. During the third quarter of 2021, the Company identified $2.3 million
out of period pretax adjustments to our previously reported YTD P&L related to the Westland operating issues described above. Of this
amount, $1.1 million and $1.2 million related to the first and second quarters of 2021, respectively. We have restated our discussion
of GAAP and As Adjusted results for YTD 2021 to reflect the correction of these items in the proper periods. On a prospective basis, interim
period consolidated financial statements will be updated to reflect these corrections and we have provided disclosures for these items
in our interim financial statements.

[0001104659-21-102150:8k_2_02:26]
Q3 2020 GAAP EPS was $0.72 per share (GAAP net earnings
of $18.7 million) and included $0.04 per share from the Discrete Items noted above. Excluding the net earnings impact of the Discrete
Items, Q3 2020 Adjusted EPS was $0.76 per share.

[0001104659-21-102150:8k_2_02:27]
YTD 2020 GAAP EPS from Continuing Operations was
$1.81 per share (GAAP net earnings from Continuing Operations of $47.3 million) and included $0.06 per share from the Discrete Items noted
above. Excluding the net earnings impact of the Discrete Items, YTD 2020 Adjusted EPS from Continuing Operations was $1.87 per share.

[0001104659-21-102150:8k_2_02:28]
Operating Highlights – Q3 & YTD

[0001104659-21-102150:8k_2_02:29]
|  | · | Sales increased $8 million (5 percent) to $181 million in Q3 2021, compared to $173 million in Q3 2020. YTD 2021 sales decreased $15 million (3 percent) to $510 million, compared to $525 million YTD 2020. |

[0001104659-21-102150:8k_2_02:30]
|  | · | Gross margin percentage decreased to 37.4 percent in Q3 2021 from 37.6 percent in Q3 2020, due to the previously discussed issues at Westland, largely offset by the implementation of cost reduction actions across the company. YTD 2021 gross margin percentage increased to 37.9 percent from 37.6 percent in YTD 2020. |

[0001104659-21-102150:8k_2_02:31]
|  | · | Adjusted SG&A expenses increased by $4.2 million in Q3 2021 compared to Q3 2020 due to overall lower operating expenses in the prior year related to COVID and the moderate return of travel and other expenses in 2021. Adjusted YTD 2021 SG&A expenses increased by $1.5 million compared to YTD 2020 due to the above, partially offset by lower spending (headcount, travel and pension) in the first half of the year. |

[0001104659-21-102150:8k_2_02:32]
|  | · | Interest expense decreased $1.0 million in Q3 2021 and $3.8 million YTD 2021 compared to the prior year due to lower debt outstanding and lower average interest rates. |

[0001104659-21-102150:8k_2_02:33]
|  | · | The effective income tax rate increased to 21.3 percent in Q3 2021 from 14.3 percent in Q3 2020. The significantly lower tax rate in Q3 2020 reflected the favorable impact ($0.06 per share) of certain one-time tax strategies implemented in the prior year which were not repeated. |

[0001104659-21-102150:8k_2_02:34]
|  | · | Q3 2021 Entered orders were $204 million (book-to-bill of 1.12x). YTD entered orders are $538 million (book-to-bill of 1.05x), and backlog has increased in all three business segments year-to-date. |

[0001104659-21-102150:8k_2_02:35]
|  | · | YTD 2021 net cash provided by operating activities was $75 million, resulting in a net cash position (total cash on hand, less total borrowings) of $30 million and a 0.43x leverage ratio at June 30, 2021. |

[0001104659-21-102150:8k_2_02:36]
Segment Performance

[0001104659-21-102150:8k_2_02:37]
A&D

[0001104659-21-102150:8k_2_02:38]
|  | · | Sales increased $2 million (2 percent) to $86 million in Q3 2021 from $84 million in Q3 2020, due to higher Navy sales partially offset by lower commercial aerospace sales. While commercial aerospace weakness is continuing, increased U.S domestic passenger boardings and recent orders for new planes by major airlines are encouraging signs for 2022. |

[0001104659-21-102150:8k_2_02:39]
|  | · | Adjusted EBIT decreased $1.5 million in Q3 2021 to $16.7 million from $18.2 million in Q3 2020, with a 20 percent Adjusted EBIT margin, as the Westland issues and continued softness in the commercial aerospace market were partially offset by higher contribution from Navy programs. |

[0001104659-21-102150:8k_2_02:40]
|  | · | Entered Orders were $95 million in Q3 2021 (book-to-bill of 1.11) compared to $66 million in Q3 2020. With continued strength in Navy and space, and solid order growth in commercial aerospace, overall A&D orders increased $29 million (44 percent) in Q3. |

[0001104659-21-102150:8k_2_02:41]
USG

[0001104659-21-102150:8k_2_02:42]
|  | · | Sales increased $5 million (12 percent) to $48 million in Q3 2021 from $43 million in Q3 2020. Doble sales increased $3 million (8 percent), driven by growth from utility customers, although overall demand has not returned to pre-COVID levels. NRG sales increased $2 million (37 percent) with significant momentum in both wind and solar. |

[0001104659-21-102150:8k_2_02:43]
|  | · | Adjusted EBIT increased $2.4 million in Q3 2021 to $8.7 million from $6.3 million in Q3 2020, with an 18 percent EBIT margin versus 15 percent in the prior year. The profitability increase was driven by leverage on sales growth and favorable impacts from prior cost reductions. |

[0001104659-21-102150:8k_2_02:44]
|  | · | Entered Orders were $55 million in Q3 2021 (book-to-bill of 1.16) compared to $50 million in Q3 2020. Despite some continued deferrals of maintenance and test equipment purchases, electric utility orders were up $2 million (5 percent) and renewables orders were up $3 million (49 percent) over the prior year with significant growth in both solar and wind. |

[0001104659-21-102150:8k_2_02:45]
Test

[0001104659-21-102150:8k_2_02:46]
|  | · | Sales increased $2 million (5 percent) to $48 million in Q3 2021 from $46 million in Q3 2020, due to strength in the Americas and Europe partially offset by lower sales in Asia. |

[0001104659-21-102150:8k_2_02:47]
|  | · | EBIT decreased $0.4 million in Q3 2021 to $6.8 million (compared to $7.2 million in Q3 2020), with a 14 percent EBIT margin. A strong quarter of sales with favorable mix in Asia drove the higher margin in the prior year. |

[0001104659-21-102150:8k_2_02:48]
|  | · | Entered Orders were $53 million in Q3 2021 (book-to-bill of 1.11) compared to $41 million in Q3 2020. The $12 million (28 percent) increase was primarily driven by strength in Asia and sets a strong backlog for Q4 and fiscal 2022. |

[0001104659-21-102150:8k_2_02:49]
Summary Commentary

[0001104659-21-102150:8k_2_02:50]
Despite the continuing COVID related challenges, our Q3 sales and entered
orders increased both sequentially and year-over-year across all three business segments. From a margin perspective, Q3 Adjusted EBITDA
margin decreased to 18.2 percent from 20.3 percent in the prior year, primarily related to the Westland issues in the quarter, the return
of travel and other spending in 2021, and lower operating expenses in 2020 related to COVID. Due to our persistent focus on cost management,
YTD Adjusted EBITDA margins are in line with both 2020 and pre-COVID 2019 levels, giving us confidence in our ability to drive margin
improvement as long-term revenue growth returns in our more challenged end-markets.

[0001104659-21-102150:8k_2_02:51]
Driven by our continuing focus on working capital
management and cash conversion, our cash flow from operations is up $22 million YTD over the prior year. With a leverage ratio of .43x
and almost $700 million in liquidity, we remain well-positioned to fund capital investments, new product development, and the pursuit
of acquisition opportunities. We continue to evaluate a solid pipeline of M&A opportunities with the intent to further expand our
product portfolio by adding complimentary businesses that increase shareholder value.

[0001104659-21-102150:8k_2_02:52]
Vic Richey, Chairman and Chief Executive Officer,
commented, “I want to thank our entire team for their continuing commitment and efforts during the unprecedented challenges of 2020
and 2021. Despite the challenges of the quarter and the lingering effects of COVID in the aerospace and electric utility markets, we delivered
revenue growth and solid profitability and cash flow in the quarter. I am confident that we have positioned the company for profitable
growth as our end-markets return to a more normal operating environment moving into 2022.”

[0001104659-21-102150:8k_2_02:53]
New Share Repurchase Program

[0001104659-21-102150:8k_2_02:54]
On August 5, 2021, the Company’s Board of Directors adopted a new stock repurchase program, replacing the previous program
which was adopted in 2012 and was scheduled to expire September 30, 2021.  Under the new program, which is similar to the previous
one, Management may repurchase shares of its outstanding stock in the open market and otherwise throughout the period ending September
30, 2024. The total value authorized is $200 million.

[0001104659-21-102150:8k_2_02:55]
Dividend Payment

[0001104659-21-102150:8k_2_02:56]
The next quarterly cash dividend
of $0.08 per share will be paid on October 15, 2021 to stockholders of record on October 1, 2021.

[0001104659-21-102150:8k_2_02:57]
Business Outlook – 2021

[0001104659-21-102150:8k_2_02:58]
Throughout the first nine months of 2021, our Navy,
defense aerospace, space and Test segment end-markets have remained solid and now we are beginning to see recovery in our core markets
most affected by the pandemic. We are encouraged by the growing strength of our entered orders across the commercial aerospace, electric
utility and renewable energy end-markets and our Q3 revenue growth in all three business segments. While there is still uncertainty as
to the timing and pace of the recovery in the commercial aerospace and electric utility markets, we believe we now have a clearer picture
of the near term and will resume issuing quarterly guidance.

[0001104659-21-102150:8k_2_02:59]
While we did see good order input and sales growth
for all three segments in Q3, the level of activity is somewhat lower than anticipated in the commercial aerospace and utility markets.
Backlog is building to support significant improvement in fiscal 2022. Our expectation is for solid Q4 growth in sales, Adjusted EBITDA,
and Adjusted EPS as compared to Q3 2021. However, with the recovery of commercial aerospace still in the early stages, we do not anticipate
the level of revenue strength we typically see in our fourth quarter. Our expectation is for Q4 Adjusted EPS to be in the range of $0.73
to $0.78 per share. This outlook excludes the impact from acquisitions that have closed in Q4. Please see the separate press release issued
today for information regarding two acquisitions that were closed in the USG business segment. These acquisitions are expected to provide
an additional boost to core growth in 2022.

[0001104659-21-102150:8k_2_02:60]
Conference Call

[0001104659-21-102150:8k_2_02:61]
The Company will host a conference call today, August 9, at 4:00 p.m.
Central Time, to discuss the Company’s Q3 2021 results. A live audio webcast will be available on the Company’s website at
www.escotechnologies.com. Please access the website at least 15 minutes prior to the call to register, download and install any necessary
audio software. A replay of the conference call will be available on the Company’s website noted above or by phone (dial 1-855-859-2056
and enter the pass code 2782855).

[0001104659-21-102150:8k_2_02:62]
Forward-Looking Statements

[0001104659-21-102150:8k_2_02:63]
Statements in this press release regarding the timing
and magnitude of recovery in the Company’s end markets, the continuing impacts of COVID-19 on the Company’s results, sales,
Adjusted SG&A, Adjusted EBIT, Adjusted EBITDA, Adjusted EPS, cash flow, results of cost reduction efforts, margins, growth, the financial
success of the Company, the strength of its end markets, the outlook for the A&D, Test and USG segments, the ability to increase shareholder
value, the timing and success of acquisition efforts, internal investments in new products and solutions, the correction of production
issues, the effect of certain changes in the Company’s internal controls or in other factors on the effectiveness of its internal
controls, the long-term success of the Company, and any other statements which are not strictly historical are “forward-looking”
statements within the meaning of the safe harbor provisions of the federal securities laws.

[0001104659-21-102150:8k_2_02:64]
Investors are cautioned that such statements are
only predictions and speak only as of the date of this release, and the Company undertakes no duty to update them except as may be required
by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the
forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment including
but not limited to those described in Item 1A, “Risk Factors”, of the Company’s Annual Report on Form 10-K for the fiscal
year ended September 30, 2020; the availability and acceptance of viable COVID-19 vaccines by enough of the U.S. and world’s population
to curtail the pandemic; the continuing impact of the COVID-19 pandemic and the effects of known or unknown COVID-19 variants including
labor shortages, facility closures, shelter in place policies or quarantines, material shortages, transportation delays, termination or
delays of Company contracts, and the inability of our suppliers or customers to perform; the impacts of natural disasters on the Company’s
operations and those of the Company’s customers and suppliers; the timing and content of future contract awards or customer orders;
the appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer contracts
or orders; weakening of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands
or customer insolvencies; competition; intellectual property rights; technical difficulties; the success of the Company’s acquisition
efforts; delivery delays or defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes
in the costs and availability of certain raw materials; labor disputes; changes in U.S. tax laws and regulations; other changes in laws
and regulations including but not limited to changes in accounting standards and foreign taxation; changes in interest rates; costs relating
to environmental matters arising from current or former facilities; uncertainty regarding the ultimate resolution of current disputes,
claims, litigation or arbitration; and the integration of recently acquired businesses.

[0001104659-21-102150:8k_2_02:65]
Non-GAAP Financial Measures

[0001104659-21-102150:8k_2_02:66]
The financial measures Adjusted SG&A, EBIT, Adjusted EBIT, EBITDA,
Adjusted EBITDA and Adjusted EPS are presented in this press release. The Company defines “Adjusted SG&A” as the corresponding
GAAP amounts excluding the net impact of the items described above in Discrete Items and reconciled in the attached Reconciliation of
Non-GAAP Financial Measures, “EBIT” as earnings before interest and taxes, “EBITDA” as earnings before interest,
taxes, depreciation and amortization, “Adjusted EBIT” and “Adjusted EBITDA” as excluding the net impact of the
items described above in Discrete Items, and “Adjusted EPS” as GAAP earnings per share (EPS) excluding the net impact of the
items described above which were ($0.10) per share in Q3 2021.

[0001104659-21-102150:8k_2_02:67]
Adjusted SG&A, EBIT, Adjusted EBIT, EBITDA, Adjusted
EBITDA and Adjusted EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management
believes that Adjusted SG&A is useful in assessing the operational profitability of the Company as it excludes certain one-time charges.
Management believes EBIT, Adjusted EBIT, EBITDA and Adjusted EBITDA are useful in assessing the operational profitability of the Company’s
business segments because they exclude interest, taxes, depreciation and amortization, which are generally accounted for across the entire
Company on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company
as well as incentive compensation. The presentation of Adjusted SG&A, EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS
provides important supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP
financial measures to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of
performance determined in accordance with GAAP.

[0001104659-21-102150:8k_2_02:68]
ESCO, headquartered in St. Louis, Missouri: Manufactures
highly-engineered filtration and fluid control products for the aviation, Navy, space and process markets worldwide, as well as composite-based
products and solutions for Navy, defense and industrial customers; is the industry leader in RF shielding and EMC test products; and
provides diagnostic instruments, software and services for the benefit of industrial power users and the electric utility and renewable
energy industries. Further information regarding ESCO and its subsidiaries is available on the Company’s website at www.escotechnologies.com.

[0001104659-21-102150:8k_2_02:69]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Condensed Consolidated Statements of Operations (Unaudited) |
| (Dollars in thousands, except per share amounts) |

[0001104659-21-102150:8k_2_02:70]
|  |  | Three Months Ended June 30, 2021 |  |  |  | Three Months Ended June 30, 2020 |  |  |
| Net Sales |  | $ | 181,394 |  |  |  |  | 172,665 |  |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 113,610 |  |  |  |  | 107,686 |  |  |
| Selling, general and administrative expenses |  |  | 42,882 |  |  |  |  | 36,936 |  |  |
| Amortization of intangible assets |  |  | 4,864 |  |  |  |  | 5,535 |  |  |
| Interest expense |  |  | 480 |  |  |  |  | 1,523 |  |  |
| Other (income) expenses, net |  |  | 615 |  |  |  |  | (824 | ) |  |
| Total costs and expenses |  |  | 162,451 |  |  |  |  | 150,856 |  |  |
| Earnings before income taxes |  |  | 18,943 |  |  |  |  | 21,809 |  |  |
| Income tax expense |  |  | 4,034 |  |  |  |  | 3,122 |  |  |
| Net earnings |  | $ | 14,909 |  |  |  |  | 18,687 |  |  |
| Diluted EPS: |  |  |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  |  |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 0.57 |  |  |  |  | 0.72 |  |  |
| Diluted - As Adjusted Basis |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.67 |  | (1) |  |  | 0.76 |  | (2) |
| Diluted average common shares O/S: |  |  | 26,214 |  |  |  |  | 26,134 |  |  |

[0001104659-21-102150:8k_2_02:71]
|  | (1) | Q3 2021 Adjusted EPS excludes $0.10 per share consisting of after-tax charges incurred at Corporate due to one-time compensation costs related to management transition and acquisition costs, and charges related to the USG (Morgan Schaffer) facility move. |

[0001104659-21-102150:8k_2_02:72]
|  | (2) | Q3 2020 Adjusted EPS excludes $0.04 per share of after-tax charges primarily related to incremental costs associated with COVID-19. |

[0001104659-21-102150:8k_2_02:73]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Condensed Consolidated Statements of Operations (Unaudited) |
| (Dollars in thousands, except per share amounts) |  |

[0001104659-21-102150:8k_2_02:74]
|  |  | Nine Months Ended June 30, 2021 |  |  |  | Nine Months Ended June 30, 2020 |  |  |
| Net Sales |  | $ | 509,962 |  |  |  |  | 524,885 |  |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 316,785 |  |  |  |  | 327,655 |  |  |
| Selling, general and administrative expenses |  |  | 122,628 |  |  |  |  | 119,023 |  |  |
| Amortization of intangible assets |  |  | 14,729 |  |  |  |  | 16,565 |  |  |
| Interest expense |  |  | 1,453 |  |  |  |  | 5,264 |  |  |
| Other (income) expenses, net |  |  | (1,265 | ) |  |  |  | 174 |  |  |
| Total costs and expenses |  |  | 454,330 |  |  |  |  | 468,681 |  |  |
| Earnings before income taxes |  |  | 55,632 |  |  |  |  | 56,204 |  |  |
| Income tax expense |  |  | 12,501 |  |  |  |  | 8,931 |  |  |
| Earnings from continuing operations |  |  | 43,131 |  |  |  |  | 47,273 |  |  |
| (Loss) earnings from discontinued operations, net of tax |  |  |  |  |  |  |  |  |  |  |
| expense of $269 |  |  | - |  |  |  |  | (601 | ) |  |
| Gain on sale of discontinued operations, net of |  |  |  |  |  |  |  |  |  |  |
| tax expense of $23,734 |  |  | - |  |  |  |  | 76,614 |  |  |
| Earnings from discontinued operations |  |  | - |  |  |  |  | 76,013 |  |  |
| Net earnings |  | $ | 43,131 |  |  |  |  | 123,286 |  |  |
| Diluted EPS: |  |  |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 1.65 |  |  |  |  | 1.81 |  |  |
| Discontinued operations |  |  | 0.00 |  |  |  |  | 2.91 |  |  |
| Net earnings |  | $ | 1.65 |  |  |  |  | 4.72 |  |  |
| Diluted - As Adjusted Basis |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 1.75 |  | (1) |  |  | 1.87 |  | (2) |
| Diluted average common shares O/S: |  |  | 26,199 |  |  |  |  | 26,130 |  |  |

[0001104659-21-102150:8k_2_02:75]
|  | (1) | YTD Q3 2021 Adjusted EPS excludes $0.10 per share consisting of after-tax charges incurred at Corporate due to one-time compensation costs related to management transition and acquisition costs, an ATM acquisition inventory step-up charge, and charges related to the USG (Doble Manta & Morgan Schaffer) facility consolidations, partially offset by the final settlement from the sale of the Doble Watertown facility. |

[0001104659-21-102150:8k_2_02:76]
|  | (2) | YTD Q3 2020 Adjusted EPS excludes $0.06 per share of after-tax charges primarily related to incremental costs associated with COVID-19 and charges related to the move of the Doble headquarters facility. |

[0001104659-21-102150:8k_2_02:77]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Condensed Business Segment Information (Unaudited) |
| (Dollars in thousands) |

[0001104659-21-102150:8k_2_02:78]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | Q3 2021 |  |  | Q3 2020 |  |  | Q3 2021 |  |  | Q3 2020 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 85,576 |  |  |  | 84,072 |  |  |  | 85,576 |  |  |  | 84,072 |  |
| USG |  |  | 47,704 |  |  |  | 42,577 |  |  |  | 47,704 |  |  |  | 42,577 |  |
| Test |  |  | 48,114 |  |  |  | 46,016 |  |  |  | 48,114 |  |  |  | 46,016 |  |
| Totals |  | $ | 181,394 |  |  |  | 172,665 |  |  |  | 181,394 |  |  |  | 172,665 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 16,714 |  |  |  | 17,409 |  |  |  | 16,739 |  |  |  | 18,224 |  |
| USG |  |  | 8,227 |  |  |  | 6,156 |  |  |  | 8,710 |  |  |  | 6,316 |  |
| Test |  |  | 6,751 |  |  |  | 7,177 |  |  |  | 6,751 |  |  |  | 7,246 |  |
| Corporate |  |  | (12,269 | ) |  |  | (7,410 | ) |  |  | (9,246 | ) |  |  | (7,219 | ) |
| Consolidated EBIT |  |  | 19,423 |  |  |  | 23,332 |  |  |  | 22,954 |  |  |  | 24,567 |  |
| Less: Interest expense |  |  | (480 | ) |  |  | (1,523 | ) |  |  | (480 | ) |  |  | (1,523 | ) |
| Less: Income tax expense |  |  | (4,034 | ) |  |  | (3,122 | ) |  |  | (4,846 | ) |  |  | (3,418 | ) |
| Net earnings from cont ops |  | $ | 14,909 |  |  |  | 18,687 |  |  |  | 17,628 |  |  |  | 19,626 |  |

[0001104659-21-102150:8k_2_02:79]
Note 1: Adjusted net earnings were $17.6 million in Q3 2021 which excluded $0.10 per share consisting of after-tax charges incurred at Corporate due to one-time compensation costs related to management transition and acquisition costs, and charges related to the USG (Morgan Schaffer) facility move.

[0001104659-21-102150:8k_2_02:80]
Note 2: Adjusted net earnings were $19.6 million in Q3 2020 which excluded $0.04 per share primarily related to incremental costs associated with COVID-19.

[0001104659-21-102150:8k_2_02:81]
EBITDA Reconciliation to Net earnings from continuing operations:

[0001104659-21-102150:8k_2_02:82]
|  |  |  |  |  |  |  |  | Adjusted |  |  | Adjusted |  |
|  |  | Q3 2021 |  |  | Q3 2020 |  |  | Q3 2021 |  |  | Q3 2020 |  |
| Consolidated EBITDA |  | $ | 29,567 |  |  |  | 33,815 |  |  |  | 33,098 |  |  |  | 35,050 |  |
| Less: Depr & Amort |  |  | (10,144 | ) |  |  | (10,483 | ) |  |  | (10,144 | ) |  |  | (10,483 | ) |
| Consolidated EBIT |  |  | 19,423 |  |  |  | 23,332 |  |  |  | 22,954 |  |  |  | 24,567 |  |
| Less: Interest expense |  |  | (480 | ) |  |  | (1,523 | ) |  |  | (480 | ) |  |  | (1,523 | ) |
| Less: Income tax expense |  |  | (4,034 | ) |  |  | (3,122 | ) |  |  | (4,846 | ) |  |  | (3,418 | ) |
| Net earnings from cont ops |  | $ | 14,909 |  |  |  | 18,687 |  |  |  | 17,628 |  |  |  | 19,626 |  |

[0001104659-21-102150:8k_2_02:83]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Condensed Business Segment Information (Unaudited) |
| (Dollars in thousands) |

[0001104659-21-102150:8k_2_02:84]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | YTD Q3 |  |  | YTD Q3 |  |  | YTD Q3 |  |  | YTD Q3 |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 234,720 |  |  |  | 256,707 |  |  |  | 234,720 |  |  |  | 256,707 |  |
| USG |  |  | 141,799 |  |  |  | 139,179 |  |  |  | 141,799 |  |  |  | 139,179 |  |
| Test |  |  | 133,443 |  |  |  | 128,999 |  |  |  | 133,443 |  |  |  | 128,999 |  |
| Totals |  | $ | 509,962 |  |  |  | 524,885 |  |  |  | 509,962 |  |  |  | 524,885 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 41,980 |  |  |  | 51,658 |  |  |  | 42,365 |  |  |  | 52,543 |  |
| USG |  |  | 27,683 |  |  |  | 20,310 |  |  |  | 27,552 |  |  |  | 21,090 |  |
| Test |  |  | 17,781 |  |  |  | 17,483 |  |  |  | 17,781 |  |  |  | 17,552 |  |
| Corporate |  |  | (30,359 | ) |  |  | (27,983 | ) |  |  | (26,986 | ) |  |  | (27,792 | ) |
| Consolidated EBIT |  |  | 57,085 |  |  |  | 61,468 |  |  |  | 60,712 |  |  |  | 63,393 |  |
| Less: Interest expense |  |  | (1,453 | ) |  |  | (5,264 | ) |  |  | (1,453 | ) |  |  | (5,264 | ) |
| Less: Income tax |  |  | (12,501 | ) |  |  | (8,931 | ) |  |  | (13,335 | ) |  |  | (9,393 | ) |
| Net earnings from cont ops |  | $ | 43,131 |  |  |  | 47,273 |  |  |  | 45,924 |  |  |  | 48,736 |  |

[0001104659-21-102150:8k_2_02:85]
Note 1: Adjusted net earnings were $45.9 million YTD Q3 2021 which excluded $0.10 per share consisting of after-tax charges incurred at Corporate due to one-time compensation costs related to management transition and acquisition costs, an ATM acquisition inventory step-up charge, and charges related to USG (Manta and Morgan Schaffer) facility consolidations, partially offset by the final settlement from the sale of the Doble Watertown facility.

[0001104659-21-102150:8k_2_02:86]
Note 2: Adjusted net earnings were $48.7 million in YTD Q3 2020 which excluded $0.06 per share primarily related to incremental costs associated with COVID-19 and charges related to the move of the Doble headquarters facility.

[0001104659-21-102150:8k_2_02:87]
EBITDA Reconciliation to Net earnings from continuing operations:

[0001104659-21-102150:8k_2_02:88]
|  |  |  |  |  |  |  |  | Adjusted |  |  | Adjusted |  |
|  |  | YTD Q3 |  |  | YTD Q3 |  |  | YTD Q3 |  |  | YTD Q3 |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Consolidated EBITDA |  | $ | 87,344 |  |  |  | 92,534 |  |  |  | 90,971 |  |  |  | 94,459 |  |
| Less: Depr & Amort |  |  | (30,259 | ) |  |  | (31,066 | ) |  |  | (30,259 | ) |  |  | (31,066 | ) |
| Consolidated EBIT |  |  | 57,085 |  |  |  | 61,468 |  |  |  | 60,712 |  |  |  | 63,393 |  |
| Less: Interest expense |  |  | (1,453 | ) |  |  | (5,264 | ) |  |  | (1,453 | ) |  |  | (5,264 | ) |
| Less: Income tax expense |  |  | (12,501 | ) |  |  | (8,931 | ) |  |  | (13,335 | ) |  |  | (9,393 | ) |
| Net earnings from cont ops |  | $ | 43,131 |  |  |  | 47,273 |  |  |  | 45,924 |  |  |  | 48,736 |  |

[0001104659-21-102150:8k_2_02:89]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Condensed Consolidated Balance Sheets (Unaudited) |
| (Dollars in thousands) |

[0001104659-21-102150:8k_2_02:90]
|  |  | June 30, 2021 |  |  | September 30, 2020 |  |
| Assets |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 78,359 |  |  |  | 52,560 |  |
| Accounts receivable, net |  |  | 135,343 |  |  |  | 144,082 |  |
| Contract assets |  |  | 94,768 |  |  |  | 94,302 |  |
| Inventories |  |  | 141,113 |  |  |  | 135,296 |  |
| Other current assets |  |  | 21,282 |  |  |  | 17,053 |  |
| Total current assets |  |  | 470,865 |  |  |  | 443,293 |  |
| Property, plant and equipment, net |  |  | 141,967 |  |  |  | 139,870 |  |
| Intangible assets, net |  |  | 343,346 |  |  |  | 346,632 |  |
| Goodwill |  |  | 411,732 |  |  |  | 408,063 |  |
| Operating lease assets |  |  | 30,426 |  |  |  | 21,390 |  |
| Other assets |  |  | 10,347 |  |  |  | 10,938 |  |
|  |  | $ | 1,408,683 |  |  |  | 1,370,186 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt & short-term borrowings |  | $ | 20,000 |  |  |  | 22,368 |  |
| Accounts payable |  |  | 50,921 |  |  |  | 50,525 |  |
| Contract liabilities |  |  | 105,822 |  |  |  | 100,551 |  |
| Other current liabilities |  |  | 76,649 |  |  |  | 82,585 |  |
| Total current liabilities |  |  | 253,392 |  |  |  | 256,029 |  |
| Deferred tax liabilities |  |  | 56,992 |  |  |  | 60,170 |  |
| Non-current operating lease liabilities |  |  | 26,458 |  |  |  | 16,785 |  |
| Other liabilities |  |  | 38,987 |  |  |  | 38,176 |  |
| Long-term debt |  |  | 28,000 |  |  |  | 40,000 |  |
| Shareholders' equity |  |  | 1,004,854 |  |  |  | 959,026 |  |
|  |  | $ | 1,408,683 |  |  |  | 1,370,186 |  |

[0001104659-21-102150:8k_2_02:91]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Consolidated Statements of Cash Flows (Unaudited) |
| (Dollars in thousands) |

[0001104659-21-102150:8k_2_02:92]
|  |  | Nine Months Ended June 30, 2021 |  |  | Nine Months Ended June 30, 2020 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 43,131 |  |  |  | 123,286 |  |
| Earnings from discontinued operations |  |  | - |  |  |  | (76,013 | ) |
| Adjustments to reconcile net earnings to net cash |  |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 30,259 |  |  |  | 31,066 |  |
| Stock compensation expense |  |  | 5,386 |  |  |  | 4,184 |  |
| Changes in assets and liabilities |  |  | 2,520 |  |  |  | (20,926 | ) |
| Gain on sale of building and land |  |  | (1,950 | ) |  |  | - |  |
| Effect of deferred taxes |  |  | (3,946 | ) |  |  | 2,155 |  |
| Pension contributions related to terminated pension plan |  |  | - |  |  |  | (10,000 | ) |
| Net cash provided by operating activities - continuing operations |  |  | 75,400 |  |  |  | 53,752 |  |
| Net cash used by operating activities - discontinued operations |  |  | - |  |  |  | (14,737 | ) |
| Net cash provided by operating activities |  |  | 75,400 |  |  |  | 39,015 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Acquisition of business, net of cash acquired |  |  | (6,684 | ) |  |  | - |  |
| Proceeds from sale of building and land |  |  | 1,950 |  |  |  | - |  |
| Capital expenditures |  |  | (17,887 | ) |  |  | (28,291 | ) |
| Additions to capitalized software |  |  | (6,500 | ) |  |  | (6,564 | ) |
| Net cash used by investing activities - continuing operations |  |  | (29,121 | ) |  |  | (34,855 | ) |
| Proceeds from sale of discontinued operations |  |  | - |  |  |  | 183,812 |  |
| Capital expenditures - discontinued operations |  |  | - |  |  |  | (1,728 | ) |
| Net cash provided by investing activities - discontinued operations |  |  | - |  |  |  | 182,084 |  |
| Net cash (used) provided by investing activities |  |  | (29,121 | ) |  |  | 147,229 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from long-term debt and short-term borrowings |  |  | 80,000 |  |  |  | 11,577 |  |
| Principal payments on long-term debt and short-term borrowings |  |  | (94,368 | ) |  |  | (145,000 | ) |
| Dividends paid |  |  | (6,249 | ) |  |  | (6,240 | ) |
| Other |  |  | (1,674 | ) |  |  | (3,127 | ) |
| Net cash used by financing activities - continuing operations |  |  | (22,291 | ) |  |  | (142,790 | ) |
| Net cash used by financing activities - discontinued operations |  |  | - |  |  |  | (2,140 | ) |
| Net cash used by financing activities |  |  | (22,291 | ) |  |  | (144,930 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 1,811 |  |  |  | 1,617 |  |
| Net increase in cash and cash equivalents |  |  | 25,799 |  |  |  | 42,931 |  |
| Cash and cash equivalents, beginning of period |  |  | 52,560 |  |  |  | 61,808 |  |
| Cash and cash equivalents, end of period |  | $ | 78,359 |  |  |  | 104,739 |  |

[0001104659-21-102150:8k_2_02:93]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Other Selected Financial Data (Unaudited) |
| (Dollars in thousands) |
| Backlog And Entered Orders - Q3 2021 |  |  | Aerospace & Defense |  |  |  | USG |  |  |  | Test |  |  |  | Total |  |
| Beginning Backlog - 4/1/21 |  | $ | 349,165 |  |  |  | 48,943 |  |  |  | 118,424 |  |  |  | 516,532 |  |
| Entered Orders |  |  | 95,145 |  |  |  | 55,476 |  |  |  | 53,228 |  |  |  | 203,849 |  |
| Sales |  |  | (85,576 | ) |  |  | (47,704 | ) |  |  | (48,114 | ) |  |  | (181,394 | ) |
| Ending Backlog - 6/30/21 |  | $ | 358,734 |  |  |  | 56,715 |  |  |  | 123,538 |  |  |  | 538,987 |  |

[0001104659-21-102150:8k_2_02:94]
| Backlog And Entered Orders - YTD Q3 2021 |  | Aerospace & Defense |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 10/1/20 |  | $ | 344,661 |  |  |  | 50,688 |  |  |  | 115,854 |  |  |  | 511,203 |  |
| Entered Orders |  |  | 248,793 |  |  |  | 147,826 |  |  |  | 141,127 |  |  |  | 537,746 |  |
| Sales |  |  | (234,720 | ) |  |  | (141,799 | ) |  |  | (133,443 | ) |  |  | (509,962 | ) |
| Ending Backlog - 6/30/21 |  | $ | 358,734 |  |  |  | 56,715 |  |  |  | 123,538 |  |  |  | 538,987 |  |

[0001104659-21-102150:8k_2_02:95]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Reconciliation of Non-GAAP Financial Measures (Unaudited) |

[0001104659-21-102150:8k_2_02:96]
| Adjusted Basis Reconciliation - Q3 2021 |  | SG&A |  |  | EPS |  |
| GAAP Basis |  |  | 42,882 |  |  | $ | 0.57 |  |
| Adjustments |  |  |  |  |  |  |  |  |
| Management Transition & Acquisition Costs |  |  | (3,023 | ) |  | $ | 0.09 |  |
| USG (Morgan Schaffer) Facility Move |  |  | - |  |  | $ | 0.01 |  |
| Total Adjustments |  |  | (3,023 | ) |  | $ | 0.10 |  |
| As Adjusted Basis |  |  | 39,859 |  |  | $ | 0.67 |  |

[0001104659-21-102150:8k_2_02:97]
| The $0.10 of EPS adjustments per share consists of $3.5 million of pre-tax charges offset by $0.8 million of tax benefit for a net impact of $2.7 million. |

[0001104659-21-102150:8k_2_02:98]
| Adjusted Basis Reconciliation – YTD Q3 2021 |  | SG&A |  |  | EPS |  |
| GAAP Basis |  |  | 122,628 |  |  | $ | 1.65 |  |
| Adjustments |  |  |  |  |  |  |  |  |
| Management Transition & Acquisition Costs |  |  | (3,373 | ) |  | $ | 0.10 |  |
| ATM Acquisition Inventory Step-up Charge |  |  |  |  |  | $ | 0.01 |  |
| USG (Manta & Morgan Schaffer) Facility Consol |  |  | - |  |  | $ | 0.05 |  |
| Settlement from Doble Watertown Facility Sale |  |  | - |  |  | $ | (0.06 | ) |
| Total Adjustments |  |  | (3,373 | ) |  | $ | 0.10 |  |
| As Adjusted Basis |  |  | 119,255 |  |  | $ | 1.75 |  |

[0001104659-21-102150:8k_2_02:99]
| The $0.10 of EPS adjustments per share consists of $3.6 million of pre-tax charges offset by $0.8 million of tax benefit for a net impact of $2.8 million. |

[0001104659-21-102150:8k_2_02:100]
| Adjusted Basis Reconciliation – Q3 2020 |  | SG&A |  |  | EPS |  |
| EPS from Continuing Ops – GAAP Basis |  |  | 36,936 |  |  | $ | 0.72 |  |
| Adjustments (defined below) |  |  | (1,235 | ) |  | $ | 0.04 |  |
| EPS from Continuing Ops – As Adjusted Basis |  |  | 35,701 |  |  | $ | 0.76 |  |

[0001104659-21-102150:8k_2_02:101]
| Adjustments exclude $0.04 per share of after-tax charges primarily related to incremental costs associated with COVID-19 in the third quarter of 2020. The $0.04 of EPS adjustments per share consists of $1.2 million of pre-tax charges offset by $.3 million of tax benefit for a net impact of $0.9 million. |

[0001104659-21-102150:8k_2_02:102]
| Adjusted Basis Reconciliation – YTD Q3 2020 |  | SG&A |  |  | EPS |  |
| EPS from Continuing Ops – GAAP Basis |  |  | 119,023 |  |  | $ | 1.81 |  |
| Adjustments (defined below) |  |  | (1,235 | ) |  | $ | 0.06 |  |
| EPS from Continuing Ops – As Adjusted Basis |  |  | 117,788 |  |  | $ | 1.87 |  |

[0001104659-21-102150:8k_2_02:103]
Adjustments exclude $0.06 per share of after-tax charges primarily related to incremental costs associated with COVID-19 and charges related to the move of the Doble headquarters facility in the first nine months of 2020. The $0.06 of EPS adjustments per share consists of $1.9 million of pre-tax charges offset by $.4 million of tax benefit for a net impact of $1.5 million.
