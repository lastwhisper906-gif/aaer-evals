# ESE notes — 0001104659-21-102250


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001104659-21-102250:notes:1]
[same as prior period, unchanged from 0001104659-21-062898:notes:1]

[0001104659-21-102250:notes:2]
[same as prior period, unchanged from 0001104659-21-062898:notes:2]

[0001104659-21-102250:notes:3]
The Company’s results for the three-month and nine-month periods ended June 30, 2021 are not necessarily indicative of the results for the entire 2021 fiscal year. References to the third quarters of 2021 and 2020 represent the fiscal quarters ended June 30, 2021 and 2020, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:EarningsPerShareTextBlock

[0001104659-21-102250:notes:4]
[same as prior period, unchanged from 0001104659-21-062898:notes:4]

[0001104659-21-102250:notes:5]
Basic EPS is calculated using the weighted average number of common shares outstanding during the period. Diluted EPS is calculated using the weighted average number of common shares outstanding during the period plus shares issuable upon the assumed exercise of dilutive common share options and vesting of unvested restricted share units (restricted shares) by using the treasury stock method. The number of shares used in the calculation of earnings per share for each period presented is as follows (in thousands):

[0001104659-21-102250:notes:6]
| ​ |  | Three Months | ​ | Nine Months |
| ​ | ​ | Ended June 30, | ​ | Ended June 30, |
| ​ | ​ | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Weighted Average Shares Outstanding — Basic |  | 26,045 |  | 26,031 |  | 26,040 |  | 26,002 |
| Dilutive Options and Restricted Shares | ​ | 169 | ​ | 103 | ​ | 159 | ​ | 128 |
| Adjusted Shares — Diluted |  | 26,214 |  | 26,134 |  | 26,199 |  | 26,130 |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001104659-21-102250:notes:7]
[same as prior period, unchanged from 0001104659-21-062898:notes:7]

[0001104659-21-102250:notes:8]
[same as prior period, unchanged from 0001104659-21-062898:notes:8]

[0001104659-21-102250:notes:9]
[same as prior period, unchanged from 0001104659-21-062898:notes:9]

[0001104659-21-102250:notes:10]
Compensation expense related to the restricted share awards was $2.5 million and $4.5 million for the three and nine-month periods ended June 30, 2021, respectively, and $1.0 million and $3.2 million for the corresponding periods in 2020. There were 229,602 non-vested shares outstanding as of June 30, 2021.

[0001104659-21-102250:notes:11]
[same as prior period, unchanged from 0001104659-21-062898:notes:11]

[0001104659-21-102250:notes:12]
Compensation expense related to the non-employee director grants was $0.3 million and $1.0 million for the three and nine-month periods ended June 30, 2021, respectively, and $0.3 million and $1.0 million for the corresponding periods in 2020.

[0001104659-21-102250:notes:13]
The total share-based compensation cost that has been recognized in the results of operations and included within selling, general and administrative expenses (SG&A) was $2.8 million and $5.5 million for the three and nine-month periods ended June 30, 2021, respectively, and $1.3 million and $4.2 million for the corresponding periods in 2020. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $0.4 million and $1.1 million for the three

[0001104659-21-102250:notes:14]
and nine-month periods ended June 30, 2021, respectively, and $0.2 million and $0.9 million for the corresponding periods in 2020. As of June 30, 2021, there was $9.2 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a remaining weighted-average period of 1.9 years.


## us-gaap:InventoryDisclosureTextBlock

[0001104659-21-102250:notes:15]
[same as prior period, unchanged from 0001104659-21-062898:notes:15]

[0001104659-21-102250:notes:16]
[same as prior period, unchanged from 0001104659-21-062898:notes:16]

[0001104659-21-102250:notes:17]
| ​ |  | June 30, |  | September 30, |
| (In thousands) |  | 2021 |  | 2020 |
| Finished goods | ​ | $ | 28,732 |  | 28,471 |
| Work in process | ​ |  | 37,874 |  | 30,183 |
| Raw materials | ​ |  | 74,507 |  | 76,642 |
| Total inventories | ​ | $ | 141,113 |  | 135,296 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001104659-21-102250:notes:18]
[same as prior period, unchanged from 0001104659-21-062898:notes:18]

[0001104659-21-102250:notes:19]
Included on the Company’s Consolidated Balance Sheets at June 30, 2021 and September 30, 2020 are the following intangible assets gross carrying amounts and accumulated amortization from continuing operations:

[0001104659-21-102250:notes:20]
| ​ |  | June 30, |  | September 30, |
| (Dollars in thousands) |  | 2021 |  | 2020 |
| Goodwill | ​ | $ | 411,732 |  | 408,063 |
| Intangible assets with determinable lives: | ​ |  | ​ | ​ | ​ |
| Patents | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 2,144 | ​ | 2,092 |
| Less: accumulated amortization | ​ |  | 943 | ​ | 858 |
| Net | ​ | $ | 1,201 | ​ | 1,234 |
| Capitalized software | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 91,388 | ​ | 84,888 |
| Less: accumulated amortization | ​ |  | 62,111 | ​ | 57,302 |
| Net | ​ | $ | 29,277 | ​ | 27,586 |
| Customer relationships | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 229,385 | ​ | 227,178 |
| Less: accumulated amortization | ​ |  | 76,986 | ​ | 67,643 |
| Net | ​ | $ | 152,399 | ​ | 159,535 |
| Other | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 5,358 | ​ | 5,156 |
| Less: accumulated amortization | ​ |  | 3,730 | ​ | 3,260 |
| Net | ​ | $ | 1,628 | ​ | 1,896 |
| Intangible assets with indefinite lives: | ​ |  | ​ | ​ | ​ |
| Trade names | ​ | $ | 158,841 | ​ | 156,381 |

[0001104659-21-102250:notes:21]
The changes in the carrying amount of goodwill attributable to each business segment for the nine months ended June 30, 2021 is as follows on a continuing operations basis:

[0001104659-21-102250:notes:22]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | Aerospace | ​ | ​ |
| (Dollars in millions) |  | USG |  | Test |  | & Defense |  | Total |
| Balance as of September 30, 2020 | ​ | ​ | 271.9 |  | 34.1 |  | 102.1 |  | 408.1 |
| Acquisition activity | ​ | ​ | — | ​ | — | ​ | 2.2 | ​ | 2.2 |
| Foreign currency translation | ​ | ​ | 1.4 | ​ | — | ​ | — | ​ | 1.4 |
| Balance as of June 30, 2021 | ​ | $ | 273.3 | ​ | 34.1 | ​ | 104.3 | ​ | 411.7 |

[0001104659-21-102250:notes:23]
The economic uncertainty, changes in the propensity for the general public to travel by air, and reductions in demand for commercial aircraft as a result of the COVID-19 pandemic have adversely impacted net sales and operating results in certain of the Aerospace and Defense reporting units. There were no impairment charges incurred for the three and nine-month periods ended June 30, 2021, however, the fair value of the Mayday and Westland reporting units, included in the Aerospace and Defense segment, exceeded carrying value by less than 10%. At June 30, 2021, we had $30 million and $18 million of goodwill recorded for Mayday and Westland, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001104659-21-102250:notes:24]
[same as prior period, unchanged from 0001104659-21-062898:notes:24]

[0001104659-21-102250:notes:25]
[same as prior period, unchanged from 0001104659-21-062898:notes:25]

[0001104659-21-102250:notes:26]
[same as prior period, unchanged from 0001104659-21-062898:notes:26]

[0001104659-21-102250:notes:27]
| ​ | ​ | Three Months | ​ | Nine Months |
| ​ | ​ | Ended June 30, | ​ | Ended June 30, |
| (In thousands) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| NET SALES | ​ | ​ |  | ​ |  | ​ |  | ​ |  |
| Aerospace & Defense | ​ | $ | 85,576 | ​ | 84,072 | ​ | 234,720 | ​ | 256,707 |
| USG | ​ | ​ | 47,704 | ​ | 42,577 | ​ | 141,799 | ​ | 139,179 |
| Test | ​ | ​ | 48,114 | ​ | 46,016 | ​ | 133,443 | ​ | 128,999 |
| Consolidated totals | ​ | $ | 181,394 | ​ | 172,665 | ​ | 509,962 | ​ | 524,885 |
| EBIT | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Aerospace & Defense | ​ | $ | 16,714 | ​ | 17,409 | ​ | 41,980 | ​ | 51,658 |
| USG | ​ | ​ | 8,227 | ​ | 6,156 | ​ | 27,683 | ​ | 20,310 |
| Test | ​ | ​ | 6,751 | ​ | 7,177 | ​ | 17,781 | ​ | 17,483 |
| Corporate (loss) | ​ | ​ | (12,269) | ​ | (7,410) | ​ | (30,359) | ​ | (27,983) |
| Consolidated EBIT | ​ | ​ | 19,423 | ​ | 23,332 | ​ | 57,085 | ​ | 61,468 |
| Less: Interest expense | ​ | ​ | (480) | ​ | (1,523) | ​ | (1,453) | ​ | (5,264) |
| Earnings before income taxes | ​ | $ | 18,943 | ​ | 21,809 | ​ | 55,632 | ​ | 56,204 |

[0001104659-21-102250:notes:28]
[same as prior period, unchanged from 0001104659-21-062898:notes:28]

[0001104659-21-102250:notes:29]
The financial measure “EBIT” is presented in the above table and elsewhere in this Report. EBIT on a consolidated basis is a non-GAAP financial measure. Management believes that EBIT is useful in assessing the operational profitability of the Company’s business segments because it excludes interest and taxes, which are generally accounted for across the entire Company on a consolidated basis. EBIT is also one of the measures used by management in determining resource allocations within the Company as well as incentive compensation. A reconciliation of EBIT to net earnings from continuing operations is set forth in Item 2, Management’s Discussion and Analysis of Financial Condition and Results of Operations – EBIT.

[0001104659-21-102250:notes:30]
[same as prior period, unchanged from 0001104659-21-062898:notes:31]


## us-gaap:DebtDisclosureTextBlock

[0001104659-21-102250:notes:31]
7.    DEBT

[0001104659-21-102250:notes:32]
The Company’s debt is summarized as follows:

[0001104659-21-102250:notes:33]
| ​ |  | June 30, | ​ | September 30, |
| (In thousands) |  | 2021 |  | 2020 |
| Total borrowings | ​ | $ | 48,000 |  | 62,368 |
| Current portion of long-term debt and short-term borrowings | ​ |  | (20,000) |  | (22,368) |
| Total long-term debt, less current portion | ​ | $ | 28,000 |  | 40,000 |

[0001104659-21-102250:notes:34]
The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024.

[0001104659-21-102250:notes:35]
At June 30, 2021, the Company had approximately $444 million available to borrow under the Credit Facility, plus the $250 million increase option, subject to lender approval, in addition to $78.4 million cash on hand. The Company classified $20.0 million as the current portion of long-term debt as of June 30, 2021, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $8.4 million at June 30, 2021.

[0001104659-21-102250:notes:36]
Interest on borrowings under the Credit Facility is calculated at a spread over either the London Interbank Offered Rate (LIBOR), the New York Federal Reserve Bank Rate or the prime rate, depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The Credit Facility is secured by the unlimited guaranty of the Company’s direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of its direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 1.16% and 1.33% for the three and nine- month periods ending June 30, 2021, respectively, and 3.24% and 3.22% for the three and nine-month periods ending June 30, 2020. As of June 30, 2021, the Company was in compliance with all covenants.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001104659-21-102250:notes:37]
[same as prior period, unchanged from 0001104659-21-062898:notes:38]

[0001104659-21-102250:notes:38]
The third quarter 2021 effective income tax rate was 21.3% compared to 14.3% in the third quarter of 2020. The effective income tax rate from continuing operations in the first nine months of 2021 was 22.5% compared to 15.9% in the first nine months of 2020. The income tax expense in the third quarter and first nine months of 2021 was favorably impacted by a tax return to provision true-up to foreign derived intangible income and other 2020 true-ups decreasing the third quarter and year-to-date effective tax rate by 3.9% and 1.2%, respectively.

[0001104659-21-102250:notes:39]
The income tax expense in the third quarter and first nine months of 2020 was favorably impacted mainly by the following items: 1) an increase in the available 2019 foreign tax credit which was attributable to new information and tax planning strategies reducing the third quarter effective tax rate and year-to-date effective tax rate by 3.3% and 1.3%; and 2) new information and tax planning strategies resulted in an increase in the 2020 foreign tax credit and the catch-up of the benefit which reduced the 2020 third quarter effective tax rate by 2.5%. The year-to-date 2020 effective tax rate was favorably impacted by the release of a valuation allowance of $2.8 million for foreign net operating losses decreasing the year-to-date 2020 effective tax rate by 5.1%.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001104659-21-102250:notes:40]
[same as prior period, unchanged from 0001104659-21-062898:notes:40]

[0001104659-21-102250:notes:41]
The change in shareholders’ equity for the first three and nine months of 2021 and 2020 is shown below (in thousands):

[0001104659-21-102250:notes:42]
| ​ | ​ | Three Months Ended June 30, | ​ | Nine Months Ended June 30, |
| ​ |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Common stock | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 306 | ​ | 306 | ​ | 306 | ​ | 306 |
| Stock plans | ​ | 1 | ​ | 1 | ​ | 1 | ​ | 1 |
| Ending balance | ​ | 307 | ​ | 307 | ​ | 307 | ​ | 307 |
| Additional paid-in-capital | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 295,796 | ​ | 294,787 | ​ | 293,682 | ​ | 292,408 |
| Stock plans | ​ | 782 | ​ | (2,156) | ​ | 2,896 | ​ | 223 |
| Ending balance | ​ | 296,578 | ​ | 292,631 | ​ | 296,578 | ​ | 292,631 |
| Retained earnings | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 799,884 | ​ | 785,184 | ​ | 775,829 | ​ | 684,741 |
| Net earnings common stockholders | ​ | 14,909 | ​ | 18,687 | ​ | 43,131 | ​ | 123,286 |
| Dividends paid | ​ | (2,084) | ​ | (2,084) | ​ | (6,251) | ​ | (6,240) |
| Ending balance | ​ | 812,709 | ​ | 801,787 | ​ | 812,709 | ​ | 801,787 |
| Accumulated other comprehensive income (loss) | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 1,808 | ​ | (46,936) | ​ | (3,657) | ​ | (43,974) |
| Foreign currency translation | ​ | 535 | ​ | 2,802 | ​ | 6,000 | ​ | (160) |
| Ending balance | ​ | 2,343 | ​ | (44,134) | ​ | 2,343 | ​ | (44,134) |
| Treasury stock | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | (107,134) | ​ | (107,134) | ​ | (107,134) | ​ | (107,259) |
| Issued under stock plans | ​ | 51 | ​ | — | ​ | 51 | ​ | 125 |
| Ending balance | ​ | (107,083) | ​ | (107,134) | ​ | (107,083) | ​ | (107,134) |
| Total equity | ​ | 1,004,854 | ​ | 943,457 | ​ | 1,004,854 | ​ | 943,457 |


## us-gaap:FairValueDisclosuresTextBlock

[0001104659-21-102250:notes:43]
[same as prior period, unchanged from 0001104659-21-062898:notes:43]

[0001104659-21-102250:notes:44]
[same as prior period, unchanged from 0001104659-21-062898:notes:44]

[0001104659-21-102250:notes:45]
[same as prior period, unchanged from 0001104659-21-062898:notes:45]

[0001104659-21-102250:notes:46]
[same as prior period, unchanged from 0001104659-21-062898:notes:46]

[0001104659-21-102250:notes:47]
[same as prior period, unchanged from 0001104659-21-062898:notes:47]

[0001104659-21-102250:notes:48]
[same as prior period, unchanged from 0001104659-21-062898:notes:48]

[0001104659-21-102250:notes:49]
The Company has estimated the fair value of its financial instruments as of June 30, 2021 and September 30, 2020 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, debt and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001104659-21-102250:notes:50]
[same as prior period, unchanged from 0001104659-21-062898:notes:50]

[0001104659-21-102250:notes:51]
The Company’s forward contracts and interest rate swaps are classified within Level 2 of the valuation hierarchy in accordance with FASB Accounting Standards Codification (ASC) 825, as presented below as of June 30, 2021:

[0001104659-21-102250:notes:52]
| (In thousands) |  | Level 1 |  | Level 2 |  | ​ | Level 3 |  | Total |
| Assets (Liabilities): | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Forward contracts | ​ | $ | — |  | (27) |  | $ | — |  | (27) |

[0001104659-21-102250:notes:53]
[same as prior period, unchanged from 0001104659-21-062898:notes:53]

[0001104659-21-102250:notes:54]
[same as prior period, unchanged from 0001104659-21-062898:notes:54]

[0001104659-21-102250:notes:55]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during the three and nine-month periods ended June 30, 2021.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001104659-21-102250:notes:56]
[same as prior period, unchanged from 0001104659-21-062898:notes:56]

[0001104659-21-102250:notes:57]
[same as prior period, unchanged from 0001104659-21-062898:notes:57]

[0001104659-21-102250:notes:58]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2021 are presented in the tables below as the Company believes it best depicts how the nature, amount, timing and

[0001104659-21-102250:notes:59]
uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue within each reportable segment on a continuing operations basis.

[0001104659-21-102250:notes:60]
| Three months ended June 30, 2021 |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total | ​ |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 34,708 | ​ | $ | 46,735 | ​ | $ | 42,063 | ​ | $ | 123,506 | ​ |
| U.S. Government | ​ |  | 50,868 | ​ | ​ | 969 | ​ | ​ | 6,051 | ​ |  | 57,888 | ​ |
| Total revenues | ​ | $ | 85,576 | ​ | $ | 47,704 | ​ | $ | 48,114 | ​ | $ | 181,394 | ​ |
| Geographic location: | ​ |  | ​ | ​ | ​ |  | ​ | ​ |  | ​ |  | ​ | ​ |
| United States | ​ | $ | 75,701 | ​ | $ | 32,111 | ​ | $ | 27,719 | ​ | $ | 135,531 | ​ |
| International | ​ |  | 9,875 | ​ | ​ | 15,593 | ​ | ​ | 20,395 | ​ |  | 45,863 | ​ |
| Total revenues | ​ | $ | 85,576 | ​ | $ | 47,704 | ​ | $ | 48,114 | ​ | $ | 181,394 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ |  | ​ | ​ |  | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 37,513 | ​ | $ | 35,242 | ​ | $ | 9,673 | ​ | $ | 82,428 | ​ |
| Over time | ​ |  | 48,063 | ​ | ​ | 12,462 | ​ | ​ | 38,441 | ​ |  | 98,966 | ​ |
| Total revenues | ​ | $ | 85,576 | ​ | $ | 47,704 | ​ | $ | 48,114 | ​ | $ | 181,394 | ​ |

[0001104659-21-102250:notes:61]
| Nine months ended June 30, 2021 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |  |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 95,712 | ​ | $ | 139,149 | ​ | $ | 118,089 | ​ | $ | 352,950 | ​ |
| U.S. Government | ​ |  | 139,008 | ​ |  | 2,650 | ​ |  | 15,354 | ​ |  | 157,012 | ​ |
| Total revenues | ​ | $ | 234,720 | ​ | $ | 141,799 | ​ | $ | 133,443 | ​ | $ | 509,962 | ​ |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  |  | ​ |  | ​ | ​ |
| United States | ​ | $ | 205,527 | ​ | $ | 96,601 | ​ | $ | 73,950 | ​ | $ | 376,078 | ​ |
| International | ​ |  | 29,193 | ​ |  | 45,198 | ​ |  | 59,493 | ​ |  | 133,884 | ​ |
| Total revenues | ​ | $ | 234,720 | ​ | $ | 141,799 | ​ | $ | 133,443 | ​ | $ | 509,962 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  |  | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 103,492 | ​ | $ | 105,173 | ​ | $ | 27,789 | ​ | $ | 236,454 | ​ |
| Over time | ​ |  | 131,228 | ​ |  | 36,626 | ​ |  | 105,654 | ​ |  | 273,508 | ​ |
| Total revenues | ​ | $ | 234,720 | ​ | $ | 141,799 | ​ | $ | 133,443 | ​ | $ | 509,962 | ​ |

[0001104659-21-102250:notes:62]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2020 are presented in the tables below.

[0001104659-21-102250:notes:63]
| Three months ended June 30, 2020 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 37,485 | ​ | $ | 39,740 | ​ | $ | 38,737 | ​ | $ | 115,962 |
| U.S. Government | ​ |  | 46,587 | ​ |  | 2,837 | ​ |  | 7,279 | ​ |  | 56,703 |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 42,577 | ​ | $ | 46,016 | ​ | $ | 172,665 |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| United States | ​ | $ | 73,476 | ​ | $ | 26,499 | ​ | $ | 19,441 | ​ | $ | 119,416 |
| International | ​ |  | 10,596 | ​ |  | 16,078 | ​ |  | 26,575 | ​ |  | 53,249 |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 42,577 | ​ | $ | 46,016 | ​ | $ | 172,665 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 36,461 | ​ | $ | 27,765 | ​ | $ | 9,138 | ​ | $ | 73,364 |
| Over time | ​ |  | 47,611 | ​ |  | 14,812 | ​ |  | 36,878 | ​ |  | 99,301 |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 42,577 | ​ | $ | 46,016 | ​ | $ | 172,665 |

[0001104659-21-102250:notes:64]
| Nine months ended June 30, 2020 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 130,817 | ​ | $ | 135,711 | ​ | $ | 107,931 | ​ | $ | 374,459 |
| U.S. Government | ​ |  | 125,890 | ​ |  | 3,468 | ​ |  | 21,068 | ​ |  | 150,426 |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 139,179 | ​ | $ | 128,999 | ​ | $ | 524,885 |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| United States | ​ | $ | 219,640 | ​ | $ | 90,155 | ​ | $ | 69,399 | ​ | $ | 379,194 |
| International | ​ |  | 37,067 | ​ |  | 49,024 | ​ |  | 59,600 | ​ |  | 145,691 |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 139,179 | ​ | $ | 128,999 | ​ | $ | 524,885 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 118,660 | ​ | $ | 100,289 | ​ | $ | 26,157 | ​ | $ | 245,106 |
| Over time | ​ |  | 138,047 | ​ |  | 38,890 | ​ |  | 102,842 | ​ |  | 279,779 |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 139,179 | ​ | $ | 128,999 | ​ | $ | 524,885 |

[0001104659-21-102250:notes:65]
[same as prior period, unchanged from 0001104659-21-062898:notes:64]

[0001104659-21-102250:notes:66]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At June 30, 2021, the Company had $539.0 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 70% in the next twelve months.

[0001104659-21-102250:notes:67]
Contract assets and contract liabilities

[0001104659-21-102250:notes:68]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At June 30, 2021, contract assets and contract liabilities totaled $94.8 million and $105.8 million, respectively. Contract assets and contract liabilities are presented as current in the consolidated balance sheets as it is expected all related transaction activity with customers will be substantially completed within twelve months. During the first nine months of 2021, the Company recognized approximately $75 million in revenues that were included in the contract liabilities balance at September 30, 2020.


## us-gaap:LeasesOfLesseeDisclosureTextBlock

[0001104659-21-102250:notes:69]
[same as prior period, unchanged from 0001104659-21-062898:notes:68]

[0001104659-21-102250:notes:70]
[same as prior period, unchanged from 0001104659-21-062898:notes:69]

[0001104659-21-102250:notes:71]
[same as prior period, unchanged from 0001104659-21-062898:notes:70]

[0001104659-21-102250:notes:72]
[same as prior period, unchanged from 0001104659-21-062898:notes:71]

[0001104659-21-102250:notes:73]
[same as prior period, unchanged from 0001104659-21-062898:notes:72]

[0001104659-21-102250:notes:74]
[same as prior period, unchanged from 0001104659-21-062898:notes:73]

[0001104659-21-102250:notes:75]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended |
| ​ | ​ | June 30, | ​ | June 30, |
| (Dollars in thousands) |  | 2021 |  | 2020 |
| Finance lease cost | ​ | ​ |  | ​ | ​ |  |
| Amortization of right-of-use assets | ​ | $ | 492 | ​ | $ | 540 |
| Interest on lease liabilities | ​ |  | 306 | ​ |  | 319 |
| Operating lease cost | ​ |  | 1,471 | ​ |  | 1,474 |
| Total lease costs | ​ | $ | 2,269 | ​ | $ | 2,333 |

[0001104659-21-102250:notes:76]
| ​ |  | Nine Months |  | Nine Months |
| ​ | ​ | Ended | ​ | Ended |
| ​ | ​ | June 30, | ​ | June 30, |
| (Dollars in thousands) |  | 2021 |  | 2020 |
| Finance lease cost | ​ | ​ | ​ | ​ | ​ | ​ |
| Amortization of right-of-use assets | ​ | $ | 1,477 | ​ | $ | 1,622 |
| Interest on lease liabilities | ​ |  | 929 | ​ |  | 970 |
| Operating lease cost | ​ |  | 4,347 | ​ |  | 4,399 |
| Total lease costs | ​ | $ | 6,753 | ​ | $ | 6,991 |

[0001104659-21-102250:notes:77]
[same as prior period, unchanged from 0001104659-21-062898:notes:76]

[0001104659-21-102250:notes:78]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended | ​ |
| ​ | ​ | June 30, | ​ | June 30, | ​ |
| (Dollars in thousands) |  | 2021 |  | 2020 | ​ |
| Cash paid for amounts included in the measurement of lease liabilities | ​ | ​ |  | ​ | ​ |  | ​ |
| Operating cash flows from operating leases | ​ | $ | 1,320 | ​ | $ | 1,452 | ​ |
| Operating cash flows from finance leases | ​ |  | 306 | ​ |  | 319 | ​ |
| Financing cash flows from finance leases | ​ |  | 428 | ​ |  | 418 | ​ |
| Right-of-use assets obtained in exchange for operating lease liabilities | ​ | ​ | 12,780 | ​ | ​ | 53 | ​ |

[0001104659-21-102250:notes:79]
| ​ |  | Nine Months |  | Nine Months |
| ​ | ​ | June 30, | ​ | June 30, |
| (Dollars in thousands) |  | 2021 |  | 2020 |
| Cash paid for amounts included in the measurement of lease liabilities | ​ | ​ | ​ | ​ | ​ | ​ |
| Operating cash flows from operating leases | ​ | $ | 4,102 | ​ | $ | 4,334 |
| Operating cash flows from finance leases | ​ |  | 915 | ​ |  | 655 |
| Financing cash flows from finance leases | ​ |  | 1,261 | ​ |  | 1,145 |
| Right-of-use assets obtained in exchange for operating lease liabilities | ​ | ​ | 12,780 | ​ |  | 22,072 |

[0001104659-21-102250:notes:80]
| Weighted-average remaining lease term |  | June 30, 2021 |  | June 30, 2020 |  |
| Operating leases |  | 10.31 years |  | 6.64 years | ​ |
| Finance leases |  | 11.86 years |  | 12.76 years | ​ |
| Weighted-average discount rate |  |  |  |  | ​ |
| Operating leases |  | 3.12 | % | 3.14 | % |
| Finance leases |  | 4.31 | % | 4.29 | % |

[0001104659-21-102250:notes:81]
The following is a reconciliation of future undiscounted cash flows to the operating and finance lease liabilities, and the related ROU assets, presented on our Consolidated Balance Sheet on June 30, 2021:

[0001104659-21-102250:notes:82]
| (Dollars in thousands) | ​ | Operating |  | Finance |
| Years Ending September 30: |  | Leases |  | Leases |
| 2021 (excluding the nine months ended June 30, 2021) | ​ | $ | 1,378 |  | ​ | 739 |
| 2022 | ​ |  | 5,093 |  | ​ | 3,015 |
| 2023 | ​ |  | 4,324 |  | ​ | 3,098 |
| 2024 | ​ |  | 3,677 |  | ​ | 3,181 |
| 2025 and thereafter | ​ |  | 21,976 |  | ​ | 28,285 |
| Total minimum lease payments | ​ |  | 36,448 |  | ​ | 38,318 |
| Less: amounts representing interest | ​ |  | 5,460 |  |  | 9,320 |
| Present value of net minimum lease payments | ​ | $ | 30,988 |  | ​ | 28,998 |
| Less: current portion of lease obligations | ​ |  | 4,530 |  | ​ | 1,859 |
| Non-current portion of lease obligations | ​ | ​ | 26,458 |  | ​ | 27,139 |
| ROU assets | ​ | $ | 30,426 |  | ​ | 24,689 |

[0001104659-21-102250:notes:83]
[same as prior period, unchanged from 0001104659-21-062898:notes:82]


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001104659-21-102250:notes:84]
13.  ADJUSTED QUARTERLY FINANCIAL INFORMATION

[0001104659-21-102250:notes:85]
During the third quarter of 2021, the Company identified immaterial errors in the historical consolidated financial statements of Westland, within the A&D segment, and are being corrected as an immaterial revision of those financial statements. Specifically, the adjustments include $3.5 million related to net sales being overstated, of which $2.4 million related to the fourth quarter of 2020, $0.3 million related to the first quarter of 2021, and $0.8 million related to the second quarter of 2021. In addition, $2.1 million of the total adjustments resulted from inventory being overstated and cost of goods sold being understated, of which $0.9 million related to the fourth quarter of 2020, $0.8 million related to the first quarter of 2021, and $0.4 million related to the second quarter of 2021. The tax impact of correcting these errors was a reduction in tax expense of $0.8 million, $0.2 million, and $0.3 million in the fourth quarter of 2020, first quarter of 2021, and second quarter of 2021, respectively. This correction also resulted in a reclassification in the Consolidated Statements of Cash Flows between line items of net earnings, changes in assets and liabilities, and effect of deferred taxes totaling $3.3 million in the fourth quarter of 2020, $1.1 million in the first quarter of 2021, and $1.2 million in the second quarter of 2021, with no impact to the total net cash provided by operating activities for any period. The fiscal 2021 and 2020 quarterly results have been adjusted to reflect the correction of these adjustments in the proper periods. The table below shows the impact of all adjustments to the respective periods. Management has determined that all of these adjustments are not material to any prior periods or the current fiscal year.

[0001104659-21-102250:notes:86]
| ​ | ​ | First Quarter | ​ | First Quarter | ​ | Second Quarter | ​ | Second Quarter |
| (Dollars in thousands, except per share amounts) |  | (As Reported) |  | (As Adjusted) |  | (As Reported) |  | (As Adjusted) |
| 2021 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net sales | ​ | $ | 162,949 | ​ | 162,674 | ​ | 166,644 | ​ | 165,894 |
| Cost of sales | ​ | ​ | 98,777 | ​ | 99,622 | ​ | 103,113 | ​ | 103,553 |
| Earnings before income taxes | ​ | ​ | 17,660 | ​ | 16,540 | ​ | 21,339 | ​ | 20,149 |
| Income tax expense | ​ | ​ | 3,974 | ​ | 3,722 | ​ | 5,025 | ​ | 4,745 |
| Net earnings | ​ | ​ | 13,686 | ​ | 12,818 | ​ | 16,314 | ​ | 15,404 |
| Diluted earnings (loss) per share: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net earnings | ​ | $ | 0.52 | ​ | 0.49 | ​ | 0.62 | ​ | 0.59 |

[0001104659-21-102250:notes:87]
| ​ |  | First Quarter |  | First Quarter |  | Second Quarter |  | Second Quarter |
| ​ | ​ | (As Reported) | ​ | (As Adjusted) | ​ | (As Reported) | ​ | (As Adjusted) |
| Contract assets | ​ | $ | 93,762 |  | 91,043 |  | 95,002 |  | 91,533 |
| Inventories | ​ |  | 144,054 |  | 142,316 |  | 145,342 |  | 143,164 |
| Retained earnings | ​ | $ | 790,000 |  | 786,563 |  | 804,231 |  | 799,884 |

[0001104659-21-102250:notes:88]
| ​ |  | Fourth Quarter |  | Fourth Quarter |
| (Dollars in thousands, except per share amounts) | ​ | (As Reported | ​ | (As Adjusted) |
| 2020 | ​ | ​ | ​ | ​ | ​ |
| Net sales | ​ | $ | 208,030 |  | 205,586 |
| Cost of sales | ​ |  | 129,763 |  | 130,656 |
| Loss before income taxes | ​ |  | (16,461) |  | (19,798) |
| Income tax expense | ​ |  | 5,347 |  | 4,579 |
| Net loss | ​ |  | (21,808) |  | (24,377) |
| Diluted earnings (loss) per share: | ​ |  |  |  |  |
| Net loss | ​ | $ | (0.83) |  | (0.93) |

[0001104659-21-102250:notes:89]
| ​ |  | Fourth Quarter |  | Fourth Quarter |
| (Dollars in thousands, except per share amounts) | ​ | (As Reported | ​ | (As Adjusted) |
| September 30, 2020 |  | ​ | ​ |  |  |
| Contract assets | ​ | $ | 96,746 |  | 94,302 |
| Inventories | ​ |  | 136,189 |  | 135,296 |
| Total current assets | ​ |  | 446,630 |  | 443,293 |
| Total assets | ​ |  | 1,373,523 |  | 1,370,186 |
| Total shareholders’ equity | ​ |  | 961,595 |  | 959,026 |
| Total liabilities and shareholders’ equity | ​ |  | 1,373,523 |  | 1,370,186 |


## us-gaap:SubsequentEventsTextBlock

[0001104659-21-102250:notes:90]
14.  SUBSEQUENT EVENTS

[0001104659-21-102250:notes:91]
On May 20, 2021, the Company announced it had entered into an agreement to acquire I.S.A. Altanova Group S.R.L. (Altanova), a supplier in the field of advanced condition assessment technologies including partial discharge measurement and analysis, as well as test instruments for electrical apparatus. Altanova, which will become part of the USG operating segment, had annual sales of approximately $30 million in 2020. As of June 30, 2021, the Company had 30 million Euros held in an escrow account related to this transaction which will be used to partially fund the acquisition. The transaction was subject to Italian regulatory approval, which was obtained and the transaction closed on July 29, 2021.

[0001104659-21-102250:notes:92]
On August 9, 2021, the Company announced it had acquired the assets of Phenix Technologies, Inc. (Phenix), a manufacturer of stationary and portable high voltage, high current, high power test systems, components and solutions supporting the electric utility industry. Phenix, which will become part of the USG operating segment, had annual sales of approximately $25 million in 2020.
