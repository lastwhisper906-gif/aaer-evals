# ESE 10-Q controls and the auditor's report


## item_4_controls

[0001104659-21-102250:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0001104659-21-102250:item_4_controls:2]
The Company carried out an evaluation, under the supervision and with the participation of Management, including the Company’s Chief Executive Officer and Chief Financial Officer, of the effectiveness of the design and operation of the Company’s disclosure controls and procedures as of the end of the period covered by this report. Disclosure controls and procedures are controls and procedures that are designed to ensure that information required to be disclosed in Company reports filed or submitted under the Securities Exchange Act of 1934 (the “Exchange Act”) is recorded, processed, summarized and reported within the time periods specified in the Securities and Exchange Commission’s rules and forms. Based upon that evaluation, the Company’s Chief Executive Officer and Chief Financial Officer concluded that the Company’s disclosure controls and procedures were not effective as of June 30, 2021 as a result of material weaknesses in the Company’s internal control over financial reporting at a reporting unit within the Aerospace & Defense (A&D) segment, related to the ineffective design of certain controls over revenue recognition and the accumulation of inventory costs and determination of inventory carrying value resulting from changes in the business.

[0001104659-21-102250:item_4_controls:3]
Other than identifying the specific deficiencies at a reporting unit within the A&D segment related to the material weaknesses disclosed, there were no changes in the Company’s internal control over financial reporting (as defined in Rule 13a-15(f) under the Exchange Act) during the period covered by this report that has materially affected, or is reasonably likely to materially affect, the Company’s internal control over financial reporting.

[0001104659-21-102250:item_4_controls:4]
The Company is in the process of remediating the material weaknesses and is taking  the following actions: enhancing policies, procedures and controls related to inventory costing and revenue recognition, providing additional training to the segment finance department, and dedicating additional resources to improve the Company’s risk assessment process. The Company believes these measures will remediate the control deficiencies and strengthen internal control over financial reporting. The operating effectiveness of the revised and new controls will be assessed subsequent to full implementation, and the material weaknesses will be considered remediated only after the applicable controls have operated effectively for a sufficient period of time.

[0001104659-21-102250:item_4_controls:5]
26
