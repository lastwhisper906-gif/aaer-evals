# ESE MD&A — 0001104659-25-117276


## mdna

[0001104659-25-117276:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001104659-25-117276:mdna:2]
The following discussion should be read in conjunction with the Consolidated Financial Statements and Notes thereto and refers to our results from continuing operations except where noted.

[0001104659-25-117276:mdna:3]
On May 20, 2025, the Company announced it had entered into a definitive agreement to sell VACCO Industries (VACCO) to RBC Bearings Incorporated (RBC), an international manufacturer and marketer of highly engineered precision bearings and products, headquartered in Oxford, Connecticut. The Company completed this divestiture on July 18, 2025. The Company received net proceeds from the sale of approximately $270 million and recorded a $172.6 million after-tax gain on the sale in the fourth quarter of 2025. The Company used the proceeds from the sale to primarily pay down debt. The VACCO business is reflected as discontinued operations in the Consolidated Financial Statements and related notes for all periods presented, in accordance with accounting principles generally accepted in the United States of America (GAAP). The sale of VACCO represents a strategic shift for the Company to exit the Space business. Net sales from the VACCO business were $102.9 million, $107.6 million and $100.2 million for the period October 1, 2024 through July 18, 2025 and years ending September 30, 2024 and 2023, respectively. Pretax earnings (loss) from the VACCO business were $13.7 million, $(1.1) million and $8.6 million for the years ending September 30, 2025, 2024 and 2023, respectively. See Note 3 to the Consolidated Financial Statements for further discussion.

[0001104659-25-117276:mdna:4]
Selected financial information for each of our business segments is provided in the discussion below and in Note 10 to the Company’s Consolidated Financial Statements.

[0001104659-25-117276:mdna:5]
This section includes comparisons of certain 2025 financial information to the same information for 2024. Year-to-year comparisons of the 2024 financial information to the same information for 2023 are contained in Item 7 of our Form 10-K for 2024 filed with the Securities and Exchange Commission on November 29, 2024 and available through the SEC’s website at https://www.sec.gov/edgar/searchedgar/companysearch.html.

[0001104659-25-117276:mdna:6]
Introduction

[0001104659-25-117276:mdna:7]
We classify our business operations into three segments for financial reporting purposes, although for reporting certain financial information we treat Corporate activities as a separate segment. Our three operating segments during 2025 were Aerospace & Defense (A&D), Utility Solutions Group (USG), and RF Test & Measurement (Test). Our operating segments are comprised of the following primary operating subsidiaries:

[0001104659-25-117276:mdna:8]
|  | ● | A&D: PTI Technologies Inc. (PTI); Crissair, Inc. (Crissair); Globe Composite Solutions, LLC (Globe, which also includes Westland Technologies, Inc.); Mayday Manufacturing Co. (Mayday); and since April 25, 2025, ESCO Maritime Solutions (or Maritime), consisting of ESCO Maritime Solutions, Ltd., DNE Technologies, Inc.(DNE), EMS Development Corporation (EMS), Measurement Systems, Inc. (MSI) and PMES I Limited. |

[0001104659-25-117276:mdna:9]
|  | ● | USG: Doble Engineering Company (Doble), Morgan Schaffer Ltd. (Morgan Schaffer), and I.S.A. – Altanova Group S.r.l. and affiliates (Altanova); and NRG Systems, Inc. (NRG) (except as the context may otherwise indicate, Doble also includes Morgan Schaffer, Altanova and ESCO’s other USG segment subsidiaries other than NRG). |

[0001104659-25-117276:mdna:10]
|  | ● | Test: ETS-Lindgren Inc. (ETS-Lindgren) and MPE Limited (MPE) (except as the context may otherwise indicate, ETS-Lindgren also includes MPE and ESCO’s other Test segment subsidiaries). |

[0001104659-25-117276:mdna:11]
A&D.  PTI and Crissair primarily design and manufacture specialty filtration products, including hydraulic filter elements and fluid control devices used in commercial and defense aerospace applications, and miniature electro-explosive devices for military aircraft ejection seats and missile arming devices. Mayday manufactures mission-critical bushings, pins, sleeves and precision-tolerance machined components for landing gear, rotor heads, engine mounts, flight controls, and actuation systems for the aerospace and defense industries. Globe designs, develops and manufactures elastomeric-based signature reduction solutions for U.S. naval vessels. Maritime is an established, long-standing business providing mission-critical signature and power management solutions for the US and UK naval defense markets.

[0001104659-25-117276:mdna:12]
USG.  Doble develops, manufactures and delivers diagnostic testing solutions that enable electric power grid operators to assess the integrity of high-voltage power delivery equipment. NRG designs and manufactures decision support tools for the renewable energy industry, primarily wind and solar.

[0001104659-25-117276:mdna:13]
Test.  ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and control magnetic and electromagnetic energy.

[0001104659-25-117276:mdna:14]
We continue to operate with meaningful growth prospects in our primary served markets and with considerable financial flexibility. We continue to focus on new products that incorporate proprietary design and process technologies. Our Management is committed to delivering shareholder value through organic growth, ongoing performance improvement initiatives, and acquisitions.

[0001104659-25-117276:mdna:15]
Highlights of 2025

[0001104659-25-117276:mdna:16]
|  | ● | Sales and net earnings from continuing operations in 2025 were $1,095.4 million and $116.3 million, respectively, compared to sales and net earnings from continuing operations in 2024 of $919.1 million and $102.6 million, respectively. |

[0001104659-25-117276:mdna:17]
|  | ● | Diluted EPS – GAAP from continuing operations for 2025 increased 13.1% to $4.49, compared to Diluted EPS – GAAP from continuing operations for 2024 of $3.97. Diluted EPS – GAAP for 2025 was $11.55 compared to Diluted EPS – GAAP for 2024 of $3.94. |

[0001104659-25-117276:mdna:18]
|  | ● | Diluted EPS – As Adjusted for 2025 was $6.03 excluding $52.1 million of pretax charges (or $1.54 per share after tax), consisting of acquisition costs at Corporate and purchase accounting adjustments primarily related to the Maritime acquisition, restructuring charges in the USG and Test segments, and acquisition related amortization. Diluted EPS – As Adjusted for 2024 was $4.77 excluding $26.7 million of pretax charges (or $0.80 per share after tax), consisting of debt financing and acquisition costs at Corporate primarily related to the Maritime acquisition, restructuring charges in the A&D, Test and USG segments, MPE purchase accounting adjustments, and acquisition-related amortization. See “Non-GAAP Financial Measures” below. |

[0001104659-25-117276:mdna:19]
| ​ | ​ | Fiscal year ended |
| (Dollars in millions) |  | 2025 |  | 2024 |
| Diluted EPS – Continuing Operations GAAP | ​ | $ | 4.49 |  | 3.97 |
| Acquisition related costs / debt financing costs | ​ |  | 0.15 |  | 0.15 |
| Purchase accounting adjustments | ​ | ​ | 0.14 |  | 0.04 |
| Restructuring adjustments | ​ | ​ | 0.02 | ​ | 0.02 |
| Acquisition related amortization | ​ | ​ | 1.23 | ​ | 0.59 |
| Diluted EPS – Continuing Operations As Adjusted | ​ | $ | 6.03 | ​ | 4.77 |

[0001104659-25-117276:mdna:20]
|  | ● | At September 30, 2025, cash on hand was $101.4 million and outstanding debt was $186 million, for a net debt position (total debt less cash on hand) of approximately $84.6 million. |

[0001104659-25-117276:mdna:21]
|  | ● | On April 25, 2025, the Company completed the acquisition of the Signature Management & Power business (renamed ESCO Maritime Solutions or Maritime) for a purchase price of approximately $472 million, net of cash acquired. |

[0001104659-25-117276:mdna:22]
|  | ● | Entered orders for 2025 from continuing operations were $1,564.8 million (including $364.2 million of Maritime acquired backlog) resulting in a book-to-bill ratio of 1.43x. Backlog at September 30, 2025 was $1,133.6 million, an increase of $469.4 million, or 70.7%, compared to backlog from continuing operations of $664.2 million at September 30, 2024. |

[0001104659-25-117276:mdna:23]
|  | ● | The Company declared dividends of $0.32 per share during 2025, totaling $8.3 million in dividend payments. |

[0001104659-25-117276:mdna:24]
Results of Continuing Operations

[0001104659-25-117276:mdna:25]
Net Sales

[0001104659-25-117276:mdna:26]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | Change |  |
| ​ | ​ | Fiscal year ended | ​ | 2025 |  |
| (Dollars in millions) |  | 2025 |  | 2024 |  | vs. 2024 |  |
| A&D | ​ | $ | 478.2 |  | 340.5 |  | 40.4 | % |
| USG | ​ |  | 380.0 |  | 369.1 |  | 3.0 | % |
| Test | ​ |  | 237.2 |  | 209.5 |  | 13.2 | % |
| Total | ​ | $ | 1,095.4 |  | 919.1 |  | 19.2 | % |

[0001104659-25-117276:mdna:27]
Net sales increased $176.3 million, or 19.2%, to $1,095.4 million in 2025 from $919.1 million in 2024. The increase in net sales in 2025 as compared to 2024 was mainly due to a $137.7 million increase in the A&D segment, a $10.9 million increase in the USG segment, and a $27.7 million increase in the Test segment.

[0001104659-25-117276:mdna:28]
A&D

[0001104659-25-117276:mdna:29]
The $137.7 million, or 40.4%, increase in net sales in 2025 as compared to 2024 was mainly due to a $94.1 million increase in navy revenues and a $39.8 million increase in commercial aerospace revenues, partially offset by a $5.2 million decrease in defense aerospace revenues. By subsidiary, the $137.7 million increase in net sales in 2025 as compared to 2024 was due to an $8.1 million increase in net sales at PTI, a $13.3 million increase in net sales at Globe, a $19.6 million increase in net sales at Crissair, a $1.5 million increase in net sales at Mayday and a $95.2 million net sales contribution from the current year acquisition of Maritime.

[0001104659-25-117276:mdna:30]
21

[0001104659-25-117276:mdna:31]
USG

[0001104659-25-117276:mdna:32]
The $10.9 million, or 3.0%, increase in net sales in 2025 as compared to 2024 was mainly due to a $17.8 million increase in net sales at Doble mainly due to higher shipments of offline and protection testing products and service revenue, partially offset by a $7.0 million decrease in net sales at NRG driven by lower shipments of solar and wind products due to renewables market weakness.

[0001104659-25-117276:mdna:33]
Test

[0001104659-25-117276:mdna:34]
The $27.7 million, or 13.2%, increase in net sales in 2025 as compared to 2024 was due to a $15.4 million increase in sales from the Company’s U.S. operations, an $8.8 million increase in sales from the Company’s European operations, and a $3.5 million increase in sales from the Company’s Asian operations due to higher test and measurement, industrial shielding, medical services and filters volumes partially offset by lower wireless volumes.

[0001104659-25-117276:mdna:35]
Orders and Backlog

[0001104659-25-117276:mdna:36]
New orders received from continuing operations were $1,564.8 million in 2025 and $999.8 million in 2024. Order backlog was $1,133.6 million at September 30, 2025, compared to order backlog from continuing operations of $664.2 million at September 30, 2024. Orders are entered into backlog as firm purchase order commitments are received.

[0001104659-25-117276:mdna:37]
By operating segment, 2025 orders were $895.6 million related to A&D products (including $364.2 million of Maritime acquired backlog), $403.5 million related to USG products, and $265.7 million related to Test products; and 2024 orders were $430.9 million related to A&D products, $355.6 million related to USG products, and $213.3 million related to Test products.

[0001104659-25-117276:mdna:38]
Selling, General and Administrative Expenses

[0001104659-25-117276:mdna:39]
Selling, general and administrative (SG&A) expenses were $234.6 million, or 21.4% of net sales, in 2025, and $208.2 million, or 22.7% of net sales, in 2024. The $26.4 million increase in SG&A expenses in 2025 as compared to 2024 was mainly due to an increase within the A&D segment (due to the Maritime acquisition) and the Test and USG segments due to higher sales, inflationary impacts, and an increase at Corporate mainly due to acquisition costs.

[0001104659-25-117276:mdna:40]
Amortization of Intangible Assets

[0001104659-25-117276:mdna:41]
Amortization of intangible assets was $53.3 million in 2025 and $32.8 million in 2024, including $41.4 million and $20.7 million of amortization of acquired intangible assets in 2025 and 2024, respectively, related to our acquisitions. The amortization of acquired intangible assets related to acquisitions is included in the Corporate segment’s results. The remaining amortization expenses relate to other identifiable intangible assets (primarily software, patents and licenses), which are included in the respective segment’s operating results. The increase in amortization expense in 2025 as compared to 2024 was mainly due to an increase in amortization of intangible assets related to the Maritime acquisition.

[0001104659-25-117276:mdna:42]
Other Expenses, Net

[0001104659-25-117276:mdna:43]
Other expenses, net, were $2.8 million in 2025, compared to $1.4 million in 2024. The principal component of other expenses, net, in 2025 was approximately $1.0 million of restructuring charges within the USG and Test segments (mainly severance charges) and $1.3 million of UK stamp duty charges due to the Maritime acquisition. The principal component of other expenses, net, in 2024 was approximately $1.0 million of restructuring costs within the USG and Test segments (mainly severance charges).

[0001104659-25-117276:mdna:44]
Non-GAAP Financial Measures

[0001104659-25-117276:mdna:45]
The information reported herein includes the financial measures Diluted EPS As Adjusted, which we define as Diluted EPS excluding the per-share net impact of discrete acquisition related costs at Corporate, purchase accounting charges related to the Maritime acquisition, restructuring charges within the Test and USG segments, and acquisition related amortization in 2025; and discrete debt financing and acquisition related costs at Corporate primarily related to the Maritime acquisition, restructuring charges in the A&D, Test and USG segments (primarily severance), purchase accounting charges related to the MPE acquisition and acquisition related amortization in 2024; EBIT, which we define as earnings before interest and taxes; and EBIT margin, which we define as EBIT expressed as a percentage of net sales. Diluted EPS –As Adjusted, EBIT on a consolidated basis, and EBIT margin on a consolidated basis are not recognized in accordance with GAAP. However, we believe that these measures provide investors and Management with valuable information for assessing our operating results. Management evaluates the performance of our operating segments based on EBIT and believes that EBIT is useful to investors to demonstrate the operational profitability of our business segments by excluding interest and taxes, which are generally accounted for across the entire company on a consolidated basis. EBIT is also one of the measures Management uses to determine resource allocations and incentive compensation. We believe that the presentation of EBIT, EBIT margin and Diluted EPS –As Adjusted provides important supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance determined in accordance with GAAP.

[0001104659-25-117276:mdna:46]
EBIT

[0001104659-25-117276:mdna:47]
The reconciliation of EBIT from continuing operations to a GAAP financial measure is as follows:

[0001104659-25-117276:mdna:48]
| (Dollars in millions) |  | 2025 |  | 2024 |
| Net earnings from continuing operations | ​ | $ | 116.3 | ​ | 102.6 |
| Add: Interest expense, net | ​ |  | 17.5 |  | 15.2 |
| Add: Income tax expense | ​ |  | 36.6 |  | 28.4 |
| EBIT from continuing operations | ​ | $ | 170.4 | ​ | 146.2 |

[0001104659-25-117276:mdna:49]
EBIT by business segment is as follows:

[0001104659-25-117276:mdna:50]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | Change |  |
| ​ | ​ | Fiscal year ended | ​ | 2025 |  |
| (Dollars in millions) |  | 2025 |  | 2024 |  | vs. 2024 |  |
| A&D | ​ | $ | 125.1 |  | 85.8 |  | 45.8 | % |
| % of net sales | ​ |  | 26.2 | % | 25.2 | % | — | ​ |
| USG | ​ |  | 94.7 |  | 85.9 |  | 10.2 | % |
| % of net sales | ​ |  | 24.9 | % | 23.3 | % | — | ​ |
| Test | ​ |  | 34.1 |  | 28.6 |  | 19.2 | % |
| % of net sales | ​ |  | 14.4 | % | 13.7 | % | — | ​ |
| Corporate | ​ |  | (83.5) |  | (54.1) |  | (54.3) | % |
| Total | ​ | $ | 170.4 |  | 146.2 |  | 16.6 | % |
| % of net sales | ​ |  | 15.6 | % | 15.9 | % | — | ​ |

[0001104659-25-117276:mdna:51]
A&D

[0001104659-25-117276:mdna:52]
The $39.3 million, or 45.8%, increase in EBIT in 2025 as compared to 2024 was primarily due to leverage on higher sales volumes and price increases at Mayday, PTI, Crissair and Globe and the contribution from the current year acquisition of Maritime partially offset by a decrease in EBIT due to inflationary pressures. EBIT in 2025 was negatively impacted by $4.5 million primarily consisting of inventory step-up charges and UK stamp duty charges related to the Maritime acquisition.

[0001104659-25-117276:mdna:53]
USG

[0001104659-25-117276:mdna:54]
The $8.8 million, or 10.2%, increase in EBIT in 2025 as compared to 2024 was mainly due to leverage on higher sales volumes at Doble with a favorable product mix and price increases, partially offset by lower sales at NRG and inflationary pressures. EBIT in 2025 was negatively impacted by $0.4 million of restructuring charges (mainly severance).

[0001104659-25-117276:mdna:55]
Test

[0001104659-25-117276:mdna:56]
The $5.5 million, or 19.2%, increase in EBIT in 2025 as compared to 2024 was primarily due to an increase in EBIT from the segment’s U.S. and European operations and price increases, partially offset by a decrease in EBIT from the Company’s Asian operations, inflationary pressures and unfavorable mix. EBIT in 2025 was negatively impacted by $0.5 million of restructuring charges (mainly severance).

[0001104659-25-117276:mdna:57]
Corporate

[0001104659-25-117276:mdna:58]
Corporate costs included in 2025 consolidated EBIT increased to $83.5 million as compared to $54.1 million in 2024. The increase in Corporate costs in 2025 as compared to 2024 was mainly due to a $21.4 million increase in acquisition related amortization expense and $5.5 million of acquisition costs, both primarily due to the Maritime acquisition, as well as an increase in share-based compensation costs.

[0001104659-25-117276:mdna:59]
Interest Expense, Net

[0001104659-25-117276:mdna:60]
Interest expense, net was $17.5 million and $15.2 million in 2025 and 2024, respectively. The increase in interest expense in 2025 was mainly due to higher average outstanding borrowings related to the Maritime acquisition in April 2025. Average outstanding borrowings were $265 million in 2025 compared to $167 million in 2024.

[0001104659-25-117276:mdna:61]
Income Tax Expense

[0001104659-25-117276:mdna:62]
The effective tax rates from continuing operations for 2025 and 2024 were 23.9% and 21.6%, respectively. The increase in the 2025 effective tax rate as compared to 2024 was primarily due to an increase in non-deductible executive compensation, increased non-deductible transaction costs and a reduction in the foreign-derived intangible income deduction.

[0001104659-25-117276:mdna:63]
No provision has been made in 2025 for foreign withholding or any applicable U.S. income taxes on the undistributed earnings of non-U.S. subsidiaries where these earnings are considered indefinitely invested or otherwise retained for continuing international operations. Determination of the amount of taxes that might be paid on these undistributed earnings if eventually remitted is not practicable.

[0001104659-25-117276:mdna:64]
Acquisitions

[0001104659-25-117276:mdna:65]
Information regarding our acquisitions during 2025, 2024 and 2023 is set forth in Note 2 to the Consolidated Financial Statements, which Note is incorporated by reference herein.

[0001104659-25-117276:mdna:66]
All of our acquisitions have been accounted for using the purchase method of accounting, and accordingly, the respective purchase prices were allocated to the assets (including intangible assets) acquired and liabilities assumed based on estimated fair values at the date of acquisition. The financial results from these acquisitions have been included in our financial statements from the date of acquisition.

[0001104659-25-117276:mdna:67]
Divestiture

[0001104659-25-117276:mdna:68]
In July 2025, we completed the sale of our former A&D subsidiary VACCO Industries (VACCO) for net sales proceeds of approximately $270 million. The sale was made as part of our strategic portfolio analysis, which is focused on positioning us to serve high-growth markets that have high margin potential. VACCO is reflected as discontinued operations in the Consolidated Financial Statements and related notes for all periods shown in this Annual Report.

[0001104659-25-117276:mdna:69]
Capital Resources and Liquidity

[0001104659-25-117276:mdna:70]
Our overall financial position and liquidity are strong. Working capital from continuing operations (current assets less current liabilities) decreased to $180.4 million at September 30, 2025 from $283.9 million at September 30, 2024. The main driver of the decrease was an increase in contract liabilities of $135.7 million primarily due to the Maritime acquisition and increases at Globe and Doble. Accounts receivable increased by $31.5 million during 2025 mainly due to an approximately $30.6 million increase within the A&D segment (primarily due to the Maritime acquisition), a $5.8 million increase within the Test segment, partially offset by a $4.9 million decrease within the USG segment. Inventories increased by $22.3 million during 2025 mainly due to a $14.7 million increase within the A&D segment (primarily due to the Maritime acquisition), a $5.7 million increase within the Test segment and a $2.0

[0001104659-25-117276:mdna:71]
million increase within the USG segment resulting primarily from the timing of finished goods and receipt of raw materials to meet anticipated demand and an increase in work in process inventories due to timing of manufacturing existing orders.

[0001104659-25-117276:mdna:72]
Net cash provided by operating activities from continuing operations was $200.4 million in 2025 and $121.6 million in 2024. The increase in net cash provided by operating activities in 2025 as compared to 2024 was mainly driven by higher net earnings and lower working capital requirements.

[0001104659-25-117276:mdna:73]
Net cash used in investing activities from continuing operations was $524.2 million in 2025 and $96.6 million in 2024. The increase in 2025 as compared to 2024 was mainly due to the Maritime acquisition completed on April 25, 2025. Capital expenditures from continuing operations were $36.3 million in 2025 and $28.3 million in 2024. The increase in 2025 as compared to 2024 was mainly due to modest increases across all three business segments. In addition, the Company incurred expenditures for capitalized software and other of $15.8 million in 2025 and $11.9 million in 2024.

[0001104659-25-117276:mdna:74]
There were no commitments outstanding that were considered material for capital expenditures at September 30, 2025.

[0001104659-25-117276:mdna:75]
Net cash provided (used) by financing activities from continuing operations was $49.5 million in 2025 and $(0.8) million in 2024, primarily due to the increase in debt borrowings during 2025.

[0001104659-25-117276:mdna:76]
Bank Credit Facility

[0001104659-25-117276:mdna:77]
A description of our credit facility (the “Credit Facility”) is set forth in Note 7 to the Consolidated Financial Statements, which Note is incorporated by reference herein.

[0001104659-25-117276:mdna:78]
Cash flow from operations and borrowings under the Credit Facility and the Incremental Facility is expected to provide adequate resources to meet our capital requirements and operational needs both for the next 12 months and for the foreseeable future.

[0001104659-25-117276:mdna:79]
Dividends

[0001104659-25-117276:mdna:80]
During both 2025 and 2024 we paid a regular quarterly cash dividend at an annual rate of $0.32 per share, totaling $8.3 million and $8.2 million in 2025 and 2024, respectively.

[0001104659-25-117276:mdna:81]
Off-Balance-Sheet Arrangements

[0001104659-25-117276:mdna:82]
We had no off-balance-sheet arrangements outstanding at September 30, 2025.

[0001104659-25-117276:mdna:83]
Share Repurchases

[0001104659-25-117276:mdna:84]
The Company did not repurchase any shares during 2025. During 2024, the Company repurchased approximately 80,500 shares for approximately $8.0 million.

[0001104659-25-117276:mdna:85]
Critical Accounting Estimates

[0001104659-25-117276:mdna:86]
The preparation of financial statements in conformity with U.S. generally accepted accounting principles (GAAP) requires Management to make estimates and assumptions in certain circumstances that affect amounts reported in the Consolidated Financial Statements. In preparing these financial statements, Management has made its best estimates and judgments of certain amounts included in the Consolidated Financial Statements, giving due consideration to materiality. We do not believe there is a great likelihood that materially different amounts would be reported under different conditions or using different assumptions related to the accounting policies described below. However, application of these accounting policies involves the exercise of judgment and use of assumptions as to future uncertainties and, as a result, actual results could differ from these estimates. Our senior Management discusses the critical accounting policies described below with the Audit and Finance Committee of our Board of Directors on a periodic basis.

[0001104659-25-117276:mdna:87]
The following discussion of critical accounting policies is intended to bring to the attention of readers those accounting policies which Management believes are critical to the Consolidated Financial Statements and other financial disclosure. It is not intended to be a comprehensive list of all significant accounting policies that are more fully described in Note 1 to the Consolidated Financial Statements.

[0001104659-25-117276:mdna:88]
Revenue Recognition

[0001104659-25-117276:mdna:89]
We account for revenue in accordance with ASC Topic 606, Revenue from Contracts with Customers. The unit of account in ASC Topic 606 is a performance obligation. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration, as applicable, which are based on historical, current and forecasted information. The transaction price is allocated to each distinct performance obligation within the contract and recognized as revenue when, or as, the performance obligation is satisfied. Certain of our long-term contracts contain incentive fees that can increase the transaction price. These variable amounts generally are awarded upon achievement of certain performance metrics, program milestones or cost targets and can be based upon customer discretion. We include estimated amounts in the transaction price to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur. The estimated amounts are based on an assessment of our anticipated performance and all other information that is reasonably available to us.

[0001104659-25-117276:mdna:90]
Approximately 48% of the A&D segment’s revenue (21% of consolidated revenue) is recognized over time as the products do not have an alternative use and either we have an enforceable right to payment for costs incurred plus a reasonable margin or the inventory is owned by the customer. Selecting the method to measure progress towards completion for our contracts requires judgment and is based on the nature of the products or services to be provided.

[0001104659-25-117276:mdna:91]
The A&D segment generally uses the cost-to-cost method to measure progress on our contracts, as the rate at which costs are incurred to fulfill a contract best depicts the transfer of control to the customer. Under this method, we measure the extent of progress towards completion based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and we record revenue proportionally as costs are incurred based on an estimated profit margin.

[0001104659-25-117276:mdna:92]
The Test segment generally uses the milestone output method to measure progress on our contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. Under this method, we estimate profit as the difference between total revenue and total estimated costs at completion of a contract and recognize these revenues and costs based on milestones achieved.

[0001104659-25-117276:mdna:93]
Total contract cost estimates are based on current contract specifications and expected engineering requirements and require us to make estimates on expected profit. The estimates on profit are based on judgments we make to project the outcome of future events, and can often span more than one year and include labor productivity and availability, the complexity of the work to be performed, change orders issued by our customers, and other specialized engineering and production related activities. Our cost estimation process is based on historical results of contracts and historical actuals to original estimates, and the application of professional knowledge and experience of engineers and program managers along with finance professionals to these historical results. We review and update our estimates of costs quarterly or more frequently when circumstances significantly change, which can affect the profitability of our contracts.

[0001104659-25-117276:mdna:94]
For contracts where revenue is recognized over time, we recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. We have net revenue recognized in the current year from performance obligations satisfied in the prior year due to changes in our estimated costs to complete the related performance obligations. We recognize anticipated losses on contracts in full in the period in which the losses become known.

[0001104659-25-117276:mdna:95]
The impact of adjustments in contract estimates on our operating earnings can be reflected in either revenue or operating costs and expenses. The aggregate impact of adjustments in contract estimates increased our earnings after income tax from continuing operations and diluted earnings per share by approximately $2.6 million and $0.10 per share, respectively, in 2025.

[0001104659-25-117276:mdna:96]
Income Taxes

[0001104659-25-117276:mdna:97]
We operate in numerous taxing jurisdictions and are subject to examination by various U.S. Federal, state and foreign jurisdictions for various tax periods. Our income tax positions are based on research and interpretations of the income tax laws and rulings in each of the jurisdictions in which we do business. Due to the subjectivity of interpretations of laws and rulings in each jurisdiction, the differences and interplay in tax laws between those jurisdictions, as well as the inherent uncertainty in estimating the final resolution of complex tax audit matters, Management’s estimates of income tax liabilities may differ from actual payments or assessments.

[0001104659-25-117276:mdna:98]
We account for income taxes under the asset and liability method. We recognize deferred tax assets and liabilities for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. We measure deferred tax assets and liabilities using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. We may reduce deferred tax assets by a valuation allowance if it is more likely than not that some portion of the deferred tax assets will not be realized. We recognize the effect on deferred tax assets and liabilities of a change in tax rates in income in the period that includes the enactment date. We regularly review our deferred tax assets for recoverability and establish a valuation allowance when Management believes it is more likely than not such assets will not be recovered, taking into consideration historical operating results, expectations of future earnings, tax planning strategies, and the expected timing of the reversals of existing temporary differences.

[0001104659-25-117276:mdna:99]
Goodwill and Other Long-Lived Assets

[0001104659-25-117276:mdna:100]
Our Management annually reviews goodwill and other long-lived assets for impairment or whenever events or changes in circumstances indicate the carrying amount may not be recoverable. If we determine that the carrying value of the goodwill and other long-lived assets may not be recoverable, we record a permanent impairment charge for the amount by which the carrying value of the goodwill and other long-lived assets exceeds its fair value. We measure fair value based on a discounted cash flow method using a discount rate determined by Management to be commensurate with the risk inherent in each of our reporting units’ or asset groups’ current business models. Our estimates of cash flows and discount rate are subject to change due to the economic environment, including such factors as interest rates, expected market returns and volatility of markets served. We believe that Management’s estimates of future cash flows and fair value are reasonable; however, changes in estimates could result in impairment charges. At September 30, 2025 we have determined that no goodwill or other long-lived assets were impaired.

[0001104659-25-117276:mdna:101]
We amortize intangible assets with estimable useful lives over their respective estimated useful lives to their estimated residual values, and review them for impairment whenever events or changes in business circumstances indicate the carrying value of the assets may not be recoverable.

[0001104659-25-117276:mdna:102]
Business Combinations

[0001104659-25-117276:mdna:103]
We account for business combinations using the acquisition method of accounting, which requires that once control is obtained, all the assets acquired and liabilities assumed are recorded at their respective fair values at the date of acquisition. The determination of the acquisition date fair values of identifiable assets acquired and liabilities assumed requires estimates and the use of valuation techniques when fair value is not readily available and requires a significant amount of management judgment. For the valuation of intangible assets acquired in a business combination, we typically use an income approach. Specifically, for the Maritime acquisition, we used the multi-period excess earnings method to determine the estimated acquisition date fair values of the customer relationship and backlog intangible assets. The significant assumptions used to estimate the fair values of these intangible assets included forecasted revenues, expected customer attrition rates, and the discount rate applied. Although the Company believes its estimates of acquisition date fair values are reasonable, actual financial results could differ from those estimates due to the inherent uncertainty involved in making such estimates. Changes in assumptions concerning future financial results of other underlying assumptions could have a significant impact on the determination of the fair values of the customer relationship and backlog intangible assets acquired. The excess of the purchase price over fair values of identifiable assets acquired and liabilities assumed is recorded as goodwill. During the measurement period, which is up to one year from the acquisition date, we may record adjustments to the assets acquired and liabilities assumed with the corresponding offset to goodwill due to the use of preliminary information in our initial estimates. Upon conclusion of the measurement period, any subsequent adjustments are recorded to earnings.

[0001104659-25-117276:mdna:104]
Other Matters

[0001104659-25-117276:mdna:105]
Quantitative and Qualitative Disclosures about Market Risk

[0001104659-25-117276:mdna:106]
Market risks relating to our operations result primarily from changes in interest rates and changes in foreign currency exchange rates. We are exposed to market risk related to changes in interest rates, and we selectively use derivative financial instruments, including forward contracts and swaps, to manage these risks. Our Canadian subsidiary Morgan Schaffer has entered into foreign exchange contracts to manage foreign currency risk, because a portion of their revenue is denominated in U.S. dollars. We report all derivative instruments on our balance sheet at fair value. For derivative instruments designated as cash flow hedges, we defer the gain or loss on the derivative in accumulated other comprehensive income until recognized in earnings with the underlying hedged item.
