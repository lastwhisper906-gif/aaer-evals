# ESE note change history — 0001410578-25-001145 → 0001410578-25-001667


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-08-11):
[0001410578-25-001667:note_history:1]
The accompanying condensed consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The condensed consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP). For further information refer to the consolidated financial statements and related notes included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2024.
  (was, 2025-05-09, similarity 0.8348):
[0001410578-25-001145:note_history:1]
The accompanying consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP).

- changed (2025-08-11):
[0001410578-25-001667:note_history:2]
The Company’s results for the three-month period ended June 30, 2025 are not necessarily indicative of the results for the entire 2025 fiscal year. References to the third quarters of 2025 and 2024 represent the fiscal quarters ended June 30, 2025 and 2024, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.
  (was, 2025-05-09, similarity 0.9717):
[0001410578-25-001145:note_history:2]
The Company’s results for the three-month period ended March 31, 2025 are not necessarily indicative of the results for the entire 2025 fiscal year. References to the second quarters of 2025 and 2024 represent the fiscal quarters ended March 31, 2025 and 2024, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-08-11):
[0001410578-25-001667:note_history:3]
| ​ |  | June 30, | ​ | September 30, |
| (In thousands) |  | 2025 |  | 2024 |
| Revolving credit facility | ​ | ​ | 155,000 | ​ | 122,000 |
| Incremental facility (Term loan A) | ​ | ​ | 370,000 | ​ | — |
| Total borrowings | ​ | $ | 525,000 | ​ | 122,000 |
| Current portion of long-term debt | ​ | ​ | (20,000) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 505,000 | ​ | 102,000 |
  (was, 2025-05-09, similarity 0.6862):
[0001410578-25-001145:note_history:3]
| ​ |  | March 31, | ​ | September 30, |
| (In thousands) |  | 2025 |  | 2024 |
| Total borrowings | ​ | $ | 88,000 | ​ | 122,000 |
| Current portion of long-term debt | ​ | ​ | (20,000) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 68,000 | ​ | 102,000 |

- changed (2025-08-11):
[0001410578-25-001667:note_history:4]
On August 5, 2024, the Company and certain of its subsidiaries entered into Amendment No. 1 to the Credit Facility which, among other things, (i) implements a senior incremental delayed draw term loan credit facility in an aggregate principal amount of up to $375 million (the “Incremental Facility”), and (ii) permits the direct or indirect acquisition by the Registrant or certain of its subsidiaries of all the issued and outstanding shares of Ultra PMES Limited, Measurement Systems, Inc., EMS Development
  (was, 2025-05-09, similarity 0.6255):
[0001410578-25-001145:note_history:4]
On August 5, 2024, the Company and certain of its subsidiaries entered into Amendment No. 1 (the “Amendment”) to the Credit Facility which, among other things, (i) implements a senior incremental delayed draw term loan credit facility in an aggregate principal amount of up to $375 million (the “Incremental Facility”), and (ii) permits the direct or indirect acquisition by the Registrant or certain of its subsidiaries of all the issued and outstanding shares of Ultra PMES Limited, Measurement Systems, Inc., EMS Development Corporation, and DNE Technologies, Inc. (the “SM&P Acquisition), pursuant to and in accordance with the terms and conditions of that certain Sale and Purchase Agreement, dated July 8, 2024, among Ultra Electronics Holdings Limited, as parent seller, the Registrant, as guarantor, and certain of the Registrant’s subsidiaries as buyers. The proceeds of the loans drawn under the Incremental Facility will be applied to pay a portion of the cash consideration for the SM&P Acquisition and other customary fees, premiums, expenses and costs incurred in connection with the SM&P Acquisition.

- added (2025-08-11):
[0001410578-25-001667:note_history:5]
Corporation, and DNE Technologies, Inc. (the “SM&P Acquisition), pursuant to and in accordance with the terms and conditions of that certain Sale and Purchase Agreement, dated July 8, 2024. During the third quarter of 2025, the proceeds of the loans drawn under the Incremental Facility were applied to pay a portion of the cash consideration for the Maritime Acquisition and other customary fees, premiums, expenses and costs incurred in connection with the acquisition. The Incremental Facility matures August 30, 2028, with balance due by this date.

- added (2025-08-11):
[0001410578-25-001667:note_history:6]
At June 30, 2025, the Company had approximately $338 million available to borrow under the Credit Facility, plus the $250 million increase option subject to the lenders’ consent, in addition to $78.7 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of June 30, 2025, as the Company intends to repay this amount as obligated by the repayment terms of the Incremental Facility within the next twelve months. The Company is obligated to repay the Incremental Facility Loan on the last day of each fiscal quarter, commencing on September 30, 2025 (the first full quarter ending after the Funding Date), in an amount equal to (a) 1.25% of the original aggregate principal amount of the Loans for each of the first twelve fiscal quarters ending after the Funding date, and (b) 1.875% of the original aggregate principal amount of the Loans for each fiscal quarter thereafter until the Maturity Date. The letters of credit issued and outstanding under the Credit Facility totaled $7.2 million at June 30, 2025.

- changed (2025-08-11):
[0001410578-25-001667:note_history:7]
Interest on borrowings under the Credit Facility and the Incremental Facility is calculated at a spread ranging from 0.25% to 2.25% over either an Adjusted Term SOFR Rate, Adjusted EURIBOR Rate, Adjusted CDOR Rate, Alternate Base Rate or Daily Simple RFR, at the Company’s election. The Credit Facility also requires a facility fee ranging from 12.5 to 25 basis points per annum on the unused portion. The interest rate spreads and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio. The weighted average interest rates under the Credit Facility were 6.03% and 5.99% for the three and nine-month periods ending June 30, 2025, respectively, and 6.71% and 6.75% for the three and nine-month periods ending June 30, 2024. The weighted average interest rate under the Incremental Facility was 6.42% for the three-month period ending June 30, 2025. As of June 30, 2025, the Company was in compliance with all covenants.
  (was, 2025-05-09, similarity 0.7577):
[0001410578-25-001145:note_history:7]
Interest on borrowings under the Credit Facility is calculated at a spread over either an Adjusted Term SOFR Rate, Adjusted EURIBOR Rate, Adjusted CDOR Rate, Alternate Base Rate or Daily Simple RFR, at the Company’s election. The Credit Facility also requires a facility fee ranging from 12.5 to 25 basis points per annum on the unused portion. The interest rate spreads and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio. The weighted average interest rates were 5.8% and 6.0% for the three and six-month periods ending March 31, 2025, respectively, and 6.8% and 6.8% for the three and six-month periods ending March 31, 2024. As of March 31, 2025, the Company was in compliance with all covenants.

- removed (2025-08-11):
[0001410578-25-001145:note_history:8]
At March 31, 2025, the Company had approximately $407 million available to borrow under the Credit Facility, excluding the Incremental Facility, plus the $250 million increase option subject to the lenders’ consent, in addition to $57.4 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of March 31, 2025, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $5.1 million at March 31, 2025.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-08-11):
[0001410578-25-001667:note_history:9]
| ​ |  | June 30, | ​ | September 30, |
| (In thousands) |  | 2025 |  | 2024 |
| Revolving credit facility | ​ | ​ | 155,000 | ​ | 122,000 |
| Incremental facility (Term loan A) | ​ | ​ | 370,000 | ​ | — |
| Total borrowings | ​ | $ | 525,000 | ​ | 122,000 |
| Current portion of long-term debt | ​ | ​ | (20,000) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 505,000 | ​ | 102,000 |
  (was, 2025-05-09, similarity 0.6862):
[0001410578-25-001145:note_history:9]
| ​ |  | March 31, | ​ | September 30, |
| (In thousands) |  | 2025 |  | 2024 |
| Total borrowings | ​ | $ | 88,000 | ​ | 122,000 |
| Current portion of long-term debt | ​ | ​ | (20,000) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 68,000 | ​ | 102,000 |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-08-11):
[0001410578-25-001667:note_history:10]
| Three months ended June 30, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 57,297 | ​ | $ | 87,653 | ​ | $ | 50,591 | ​ | $ | 195,541 |
| Government | ​ | ​ | 79,027 | ​ | ​ | 4,704 | ​ | ​ | 17,072 | ​ | ​ | 100,803 |
| Total revenues | ​ | $ | 136,324 | ​ | $ | 92,357 | ​ | $ | 67,663 | ​ | $ | 296,344 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 94,518 | ​ | $ | 63,062 | ​ | $ | 36,188 | ​ | $ | 193,768 |
| International | ​ | ​ | 41,806 | ​ | ​ | 29,295 | ​ | ​ | 31,475 | ​ | ​ | 102,576 |
| Total revenues | ​ | $ | 136,324 | ​ | $ | 92,357 | ​ | $ | 67,663 | ​ | $ | 296,344 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 66,833 | ​ | $ | 74,143 | ​ | $ | 11,123 | ​ | $ | 152,099 |
| Over time | ​ | ​ | 69,491 | ​ | ​ | 18,214 | ​ | ​ | 56,540 | ​ | ​ | 144,245 |
| Total revenues | ​ | $ | 136,324 | ​ | $ | 92,357 | ​ | $ | 67,663 | ​ | $ | 296,344 |
  (was, 2025-05-09, similarity 0.9951):
[0001410578-25-001145:note_history:10]
| Three months ended March 31, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 50,788 | ​ | $ | 89,649 | ​ | $ | 37,891 | ​ | $ | 178,328 |
| Government | ​ | ​ | 72,581 | ​ | ​ | 1,118 | ​ | ​ | 13,492 | ​ | ​ | 87,191 |
| Total revenues | ​ | $ | 123,369 | ​ | $ | 90,767 | ​ | $ | 51,383 | ​ | $ | 265,519 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 98,335 | ​ | $ | 54,944 | ​ | $ | 32,267 | ​ | $ | 185,546 |
| International | ​ | ​ | 25,034 | ​ | ​ | 35,823 | ​ | ​ | 19,116 | ​ | ​ | 79,973 |
| Total revenues | ​ | $ | 123,369 | ​ | $ | 90,767 | ​ | $ | 51,383 | ​ | $ | 265,519 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 56,052 | ​ | $ | 73,002 | ​ | $ | 11,607 | ​ | $ | 140,661 |
| Over time | ​ | ​ | 67,317 | ​ | ​ | 17,765 | ​ | ​ | 39,776 | ​ | ​ | 124,858 |
| Total revenues | ​ | $ | 123,369 | ​ | $ | 90,767 | ​ | $ | 51,383 | ​ | $ | 265,519 |

- changed (2025-08-11):
[0001410578-25-001667:note_history:11]
| Nine months ended June 30, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 151,756 | ​ | $ | 261,581 | ​ | $ | 124,831 | ​ | $ | 538,168 |
| Government | ​ | ​ | 156,063 | ​ | ​ | 8,203 | ​ | ​ | 40,280 | ​ | ​ | 204,546 |
| Total revenues | ​ | $ | 307,819 | ​ | $ | 269,784 | ​ | $ | 165,111 | ​ | $ | 742,714 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 226,444 | ​ | $ | 173,121 | ​ | $ | 97,086 | ​ | $ | 496,651 |
| International | ​ | ​ | 81,375 | ​ | ​ | 96,663 | ​ | ​ | 68,025 | ​ | ​ | 246,063 |
| Total revenues | ​ | $ | 307,819 | ​ | $ | 269,784 | ​ | $ | 165,111 | ​ | $ | 742,714 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 166,191 | ​ | $ | 216,423 | ​ | $ | 32,522 | ​ | $ | 415,136 |
| Over time | ​ | ​ | 141,628 | ​ | ​ | 53,361 | ​ | ​ | 132,589 | ​ | ​ | 327,578 |
| Total revenues | ​ | $ | 307,819 | ​ | $ | 269,784 | ​ | $ | 165,111 | ​ | $ | 742,714 |
  (was, 2025-05-09, similarity 0.9915):
[0001410578-25-001145:note_history:11]
| Six months ended March 31, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 98,288 | ​ | $ | 173,928 | ​ | $ | 74,240 | ​ | $ | 346,456 |
| Government | ​ | ​ | 139,382 | ​ | ​ | 3,499 | ​ | ​ | 23,208 | ​ | ​ | 166,089 |
| Total revenues | ​ | $ | 237,670 | ​ | $ | 177,427 | ​ | $ | 97,448 | ​ | $ | 512,545 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 195,038 | ​ | $ | 114,860 | ​ | $ | 60,897 | ​ | $ | 370,795 |
| International | ​ | ​ | 42,632 | ​ | ​ | 62,567 | ​ | ​ | 36,551 | ​ | ​ | 141,750 |
| Total revenues | ​ | $ | 237,670 | ​ | $ | 177,427 | ​ | $ | 97,448 | ​ | $ | 512,545 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 106,178 | ​ | $ | 142,280 | ​ | $ | 21,398 | ​ | $ | 269,856 |
| Over time | ​ | ​ | 131,492 | ​ | ​ | 35,147 | ​ | ​ | 76,050 | ​ | ​ | 242,689 |
| Total revenues | ​ | $ | 237,670 | ​ | $ | 177,427 | ​ | $ | 97,448 | ​ | $ | 512,545 |

- changed (2025-08-11):
[0001410578-25-001667:note_history:12]
| Three months ended June 30, 2024 | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 43,927 | ​ | $ | 88,076 | ​ | $ | 42,327 | ​ | $ | 174,330 |
| Government | ​ | ​ | 43,308 | ​ | ​ | 2,201 | ​ | ​ | 13,729 | ​ | ​ | 59,238 |
| Total revenues | ​ | $ | 87,235 | ​ | $ | 90,277 | ​ | $ | 56,056 | ​ | $ | 233,568 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 69,228 | ​ | $ | 54,063 | ​ | $ | 32,575 | ​ | $ | 155,866 |
| International | ​ | ​ | 18,007 | ​ | ​ | 36,214 | ​ | ​ | 23,481 | ​ | ​ | 77,702 |
| Total revenues | ​ | $ | 87,235 | ​ | $ | 90,277 | ​ | $ | 56,056 | ​ | $ | 233,568 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 51,234 | ​ | $ | 72,985 | ​ | $ | 11,426 | ​ | $ | 135,645 |
| Over time | ​ | ​ | 36,001 | ​ | ​ | 17,292 | ​ | ​ | 44,630 | ​ | ​ | 97,923 |
| Total revenues | ​ | $ | 87,235 | ​ | $ | 90,277 | ​ | $ | 56,056 | ​ | $ | 233,568 |
  (was, 2025-05-09, similarity 0.9952):
[0001410578-25-001145:note_history:12]
| Three months ended March 31, 2024 | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 49,382 | ​ | $ | 85,220 | ​ | $ | 34,537 | ​ | $ | 169,139 |
| Government | ​ | ​ | 65,319 | ​ | ​ | 2,089 | ​ | ​ | 12,582 | ​ | ​ | 79,990 |
| Total revenues | ​ | $ | 114,701 | ​ | $ | 87,309 | ​ | $ | 47,119 | ​ | $ | 249,129 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 92,161 | ​ | $ | 55,763 | ​ | $ | 27,543 | ​ | $ | 175,467 |
| International | ​ | ​ | 22,540 | ​ | ​ | 31,546 | ​ | ​ | 19,576 | ​ | ​ | 73,662 |
| Total revenues | ​ | $ | 114,701 | ​ | $ | 87,309 | ​ | $ | 47,119 | ​ | $ | 249,129 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 53,463 | ​ | $ | 70,285 | ​ | $ | 10,301 | ​ | $ | 134,049 |
| Over time | ​ | ​ | 61,238 | ​ | ​ | 17,024 | ​ | ​ | 36,818 | ​ | ​ | 115,080 |
| Total revenues | ​ | $ | 114,701 | ​ | $ | 87,309 | ​ | $ | 47,119 | ​ | $ | 249,129 |

- changed (2025-08-11):
[0001410578-25-001667:note_history:13]
| Nine months ended June 30, 2024 | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 126,191 | ​ | $ | 254,765 | ​ | $ | 111,951 | ​ | $ | 492,907 |
| Government | ​ |  | 115,088 | ​ |  | 5,805 | ​ |  | 31,821 | ​ |  | 152,714 |
| Total revenues | ​ | $ | 241,279 | ​ | $ | 260,570 | ​ | $ | 143,772 | ​ | $ | 645,621 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 190,264 | ​ | $ | 165,789 | ​ | $ | 82,370 | ​ | $ | 438,423 |
| International | ​ |  | 51,015 | ​ |  | 94,781 | ​ |  | 61,402 | ​ |  | 207,198 |
| Total revenues | ​ | $ | 241,279 | ​ | $ | 260,570 | ​ | $ | 143,772 | ​ | $ | 645,621 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 137,769 | ​ | $ | 209,973 | ​ | $ | 29,706 | ​ | $ | 377,448 |
| Over time | ​ |  | 103,510 | ​ |  | 50,597 | ​ |  | 114,066 | ​ |  | 268,173 |
| Total revenues | ​ | $ | 241,279 | ​ | $ | 260,570 | ​ | $ | 143,772 | ​ | $ | 645,621 |
  (was, 2025-05-09, similarity 0.9911):
[0001410578-25-001145:note_history:13]
| Six months ended March 31, 2024 | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 86,591 | ​ | $ | 166,689 | ​ | $ | 69,615 | ​ | $ | 322,895 |
| Government | ​ |  | 122,843 | ​ |  | 3,604 | ​ |  | 18,101 | ​ |  | 144,548 |
| Total revenues | ​ | $ | 209,434 | ​ | $ | 170,293 | ​ | $ | 87,716 | ​ | $ | 467,443 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 172,062 | ​ | $ | 111,725 | ​ | $ | 49,795 | ​ | $ | 333,582 |
| International | ​ |  | 37,372 | ​ |  | 58,568 | ​ |  | 37,921 | ​ |  | 133,861 |
| Total revenues | ​ | $ | 209,434 | ​ | $ | 170,293 | ​ | $ | 87,716 | ​ | $ | 467,443 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 92,928 | ​ | $ | 136,989 | ​ | $ | 18,280 | ​ | $ | 248,197 |
| Over time | ​ |  | 116,506 | ​ |  | 33,304 | ​ |  | 69,436 | ​ |  | 219,246 |
| Total revenues | ​ | $ | 209,434 | ​ | $ | 170,293 | ​ | $ | 87,716 | ​ | $ | 467,443 |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-08-11):
[0001410578-25-001667:note_history:14]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2025 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue from continuing operations within each reportable segment.
  (was, 2025-05-09, similarity 0.9502):
[0001410578-25-001145:note_history:14]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2025 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue within each reportable segment.

- changed (2025-08-11):
[0001410578-25-001667:note_history:15]
| Three months ended June 30, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 57,297 | ​ | $ | 87,653 | ​ | $ | 50,591 | ​ | $ | 195,541 |
| Government | ​ | ​ | 79,027 | ​ | ​ | 4,704 | ​ | ​ | 17,072 | ​ | ​ | 100,803 |
| Total revenues | ​ | $ | 136,324 | ​ | $ | 92,357 | ​ | $ | 67,663 | ​ | $ | 296,344 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 94,518 | ​ | $ | 63,062 | ​ | $ | 36,188 | ​ | $ | 193,768 |
| International | ​ | ​ | 41,806 | ​ | ​ | 29,295 | ​ | ​ | 31,475 | ​ | ​ | 102,576 |
| Total revenues | ​ | $ | 136,324 | ​ | $ | 92,357 | ​ | $ | 67,663 | ​ | $ | 296,344 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 66,833 | ​ | $ | 74,143 | ​ | $ | 11,123 | ​ | $ | 152,099 |
| Over time | ​ | ​ | 69,491 | ​ | ​ | 18,214 | ​ | ​ | 56,540 | ​ | ​ | 144,245 |
| Total revenues | ​ | $ | 136,324 | ​ | $ | 92,357 | ​ | $ | 67,663 | ​ | $ | 296,344 |
  (was, 2025-05-09, similarity 0.9951):
[0001410578-25-001145:note_history:15]
| Three months ended March 31, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 50,788 | ​ | $ | 89,649 | ​ | $ | 37,891 | ​ | $ | 178,328 |
| Government | ​ | ​ | 72,581 | ​ | ​ | 1,118 | ​ | ​ | 13,492 | ​ | ​ | 87,191 |
| Total revenues | ​ | $ | 123,369 | ​ | $ | 90,767 | ​ | $ | 51,383 | ​ | $ | 265,519 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 98,335 | ​ | $ | 54,944 | ​ | $ | 32,267 | ​ | $ | 185,546 |
| International | ​ | ​ | 25,034 | ​ | ​ | 35,823 | ​ | ​ | 19,116 | ​ | ​ | 79,973 |
| Total revenues | ​ | $ | 123,369 | ​ | $ | 90,767 | ​ | $ | 51,383 | ​ | $ | 265,519 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 56,052 | ​ | $ | 73,002 | ​ | $ | 11,607 | ​ | $ | 140,661 |
| Over time | ​ | ​ | 67,317 | ​ | ​ | 17,765 | ​ | ​ | 39,776 | ​ | ​ | 124,858 |
| Total revenues | ​ | $ | 123,369 | ​ | $ | 90,767 | ​ | $ | 51,383 | ​ | $ | 265,519 |

- changed (2025-08-11):
[0001410578-25-001667:note_history:16]
| Nine months ended June 30, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 151,756 | ​ | $ | 261,581 | ​ | $ | 124,831 | ​ | $ | 538,168 |
| Government | ​ | ​ | 156,063 | ​ | ​ | 8,203 | ​ | ​ | 40,280 | ​ | ​ | 204,546 |
| Total revenues | ​ | $ | 307,819 | ​ | $ | 269,784 | ​ | $ | 165,111 | ​ | $ | 742,714 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 226,444 | ​ | $ | 173,121 | ​ | $ | 97,086 | ​ | $ | 496,651 |
| International | ​ | ​ | 81,375 | ​ | ​ | 96,663 | ​ | ​ | 68,025 | ​ | ​ | 246,063 |
| Total revenues | ​ | $ | 307,819 | ​ | $ | 269,784 | ​ | $ | 165,111 | ​ | $ | 742,714 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 166,191 | ​ | $ | 216,423 | ​ | $ | 32,522 | ​ | $ | 415,136 |
| Over time | ​ | ​ | 141,628 | ​ | ​ | 53,361 | ​ | ​ | 132,589 | ​ | ​ | 327,578 |
| Total revenues | ​ | $ | 307,819 | ​ | $ | 269,784 | ​ | $ | 165,111 | ​ | $ | 742,714 |
  (was, 2025-05-09, similarity 0.9915):
[0001410578-25-001145:note_history:16]
| Six months ended March 31, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 98,288 | ​ | $ | 173,928 | ​ | $ | 74,240 | ​ | $ | 346,456 |
| Government | ​ | ​ | 139,382 | ​ | ​ | 3,499 | ​ | ​ | 23,208 | ​ | ​ | 166,089 |
| Total revenues | ​ | $ | 237,670 | ​ | $ | 177,427 | ​ | $ | 97,448 | ​ | $ | 512,545 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 195,038 | ​ | $ | 114,860 | ​ | $ | 60,897 | ​ | $ | 370,795 |
| International | ​ | ​ | 42,632 | ​ | ​ | 62,567 | ​ | ​ | 36,551 | ​ | ​ | 141,750 |
| Total revenues | ​ | $ | 237,670 | ​ | $ | 177,427 | ​ | $ | 97,448 | ​ | $ | 512,545 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 106,178 | ​ | $ | 142,280 | ​ | $ | 21,398 | ​ | $ | 269,856 |
| Over time | ​ | ​ | 131,492 | ​ | ​ | 35,147 | ​ | ​ | 76,050 | ​ | ​ | 242,689 |
| Total revenues | ​ | $ | 237,670 | ​ | $ | 177,427 | ​ | $ | 97,448 | ​ | $ | 512,545 |

- changed (2025-08-11):
[0001410578-25-001667:note_history:17]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2024 are presented in the tables below.
  (was, 2025-05-09, similarity 0.9576):
[0001410578-25-001145:note_history:17]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2024 are presented in the tables below.

- changed (2025-08-11):
[0001410578-25-001667:note_history:18]
| Three months ended June 30, 2024 | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 43,927 | ​ | $ | 88,076 | ​ | $ | 42,327 | ​ | $ | 174,330 |
| Government | ​ | ​ | 43,308 | ​ | ​ | 2,201 | ​ | ​ | 13,729 | ​ | ​ | 59,238 |
| Total revenues | ​ | $ | 87,235 | ​ | $ | 90,277 | ​ | $ | 56,056 | ​ | $ | 233,568 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 69,228 | ​ | $ | 54,063 | ​ | $ | 32,575 | ​ | $ | 155,866 |
| International | ​ | ​ | 18,007 | ​ | ​ | 36,214 | ​ | ​ | 23,481 | ​ | ​ | 77,702 |
| Total revenues | ​ | $ | 87,235 | ​ | $ | 90,277 | ​ | $ | 56,056 | ​ | $ | 233,568 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 51,234 | ​ | $ | 72,985 | ​ | $ | 11,426 | ​ | $ | 135,645 |
| Over time | ​ | ​ | 36,001 | ​ | ​ | 17,292 | ​ | ​ | 44,630 | ​ | ​ | 97,923 |
| Total revenues | ​ | $ | 87,235 | ​ | $ | 90,277 | ​ | $ | 56,056 | ​ | $ | 233,568 |
  (was, 2025-05-09, similarity 0.9952):
[0001410578-25-001145:note_history:18]
| Three months ended March 31, 2024 | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 49,382 | ​ | $ | 85,220 | ​ | $ | 34,537 | ​ | $ | 169,139 |
| Government | ​ | ​ | 65,319 | ​ | ​ | 2,089 | ​ | ​ | 12,582 | ​ | ​ | 79,990 |
| Total revenues | ​ | $ | 114,701 | ​ | $ | 87,309 | ​ | $ | 47,119 | ​ | $ | 249,129 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 92,161 | ​ | $ | 55,763 | ​ | $ | 27,543 | ​ | $ | 175,467 |
| International | ​ | ​ | 22,540 | ​ | ​ | 31,546 | ​ | ​ | 19,576 | ​ | ​ | 73,662 |
| Total revenues | ​ | $ | 114,701 | ​ | $ | 87,309 | ​ | $ | 47,119 | ​ | $ | 249,129 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 53,463 | ​ | $ | 70,285 | ​ | $ | 10,301 | ​ | $ | 134,049 |
| Over time | ​ | ​ | 61,238 | ​ | ​ | 17,024 | ​ | ​ | 36,818 | ​ | ​ | 115,080 |
| Total revenues | ​ | $ | 114,701 | ​ | $ | 87,309 | ​ | $ | 47,119 | ​ | $ | 249,129 |

- changed (2025-08-11):
[0001410578-25-001667:note_history:19]
| Nine months ended June 30, 2024 | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 126,191 | ​ | $ | 254,765 | ​ | $ | 111,951 | ​ | $ | 492,907 |
| Government | ​ |  | 115,088 | ​ |  | 5,805 | ​ |  | 31,821 | ​ |  | 152,714 |
| Total revenues | ​ | $ | 241,279 | ​ | $ | 260,570 | ​ | $ | 143,772 | ​ | $ | 645,621 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 190,264 | ​ | $ | 165,789 | ​ | $ | 82,370 | ​ | $ | 438,423 |
| International | ​ |  | 51,015 | ​ |  | 94,781 | ​ |  | 61,402 | ​ |  | 207,198 |
| Total revenues | ​ | $ | 241,279 | ​ | $ | 260,570 | ​ | $ | 143,772 | ​ | $ | 645,621 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 137,769 | ​ | $ | 209,973 | ​ | $ | 29,706 | ​ | $ | 377,448 |
| Over time | ​ |  | 103,510 | ​ |  | 50,597 | ​ |  | 114,066 | ​ |  | 268,173 |
| Total revenues | ​ | $ | 241,279 | ​ | $ | 260,570 | ​ | $ | 143,772 | ​ | $ | 645,621 |
  (was, 2025-05-09, similarity 0.9911):
[0001410578-25-001145:note_history:19]
| Six months ended March 31, 2024 | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 86,591 | ​ | $ | 166,689 | ​ | $ | 69,615 | ​ | $ | 322,895 |
| Government | ​ |  | 122,843 | ​ |  | 3,604 | ​ |  | 18,101 | ​ |  | 144,548 |
| Total revenues | ​ | $ | 209,434 | ​ | $ | 170,293 | ​ | $ | 87,716 | ​ | $ | 467,443 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 172,062 | ​ | $ | 111,725 | ​ | $ | 49,795 | ​ | $ | 333,582 |
| International | ​ |  | 37,372 | ​ |  | 58,568 | ​ |  | 37,921 | ​ |  | 133,861 |
| Total revenues | ​ | $ | 209,434 | ​ | $ | 170,293 | ​ | $ | 87,716 | ​ | $ | 467,443 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 92,928 | ​ | $ | 136,989 | ​ | $ | 18,280 | ​ | $ | 248,197 |
| Over time | ​ |  | 116,506 | ​ |  | 33,304 | ​ |  | 69,436 | ​ |  | 219,246 |
| Total revenues | ​ | $ | 209,434 | ​ | $ | 170,293 | ​ | $ | 87,716 | ​ | $ | 467,443 |

- changed (2025-08-11):
[0001410578-25-001667:note_history:20]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At June 30, 2025, the Company had $1,165.4 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 66% in the next twelve months.
  (was, 2025-05-09, similarity 0.9935):
[0001410578-25-001145:note_history:20]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At March 31, 2025, the Company had $932.3 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 74% in the next twelve months.

- changed (2025-08-11):
[0001410578-25-001667:note_history:21]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At June 30, 2025, contract assets, contract liabilities and accounts receivable from continuing operations totaled $91.7 million, $214.1 million and $238.0 million, respectively. During the first nine months of 2025, the Company recognized approximately $54 million in revenues that were included in the contract liabilities balance at September 30, 2024. At September 30, 2024, contract assets, contract liabilities and accounts receivable from continuing operations totaled $66.7 million, $90.3 million and $222.1 million, respectively.
  (was, 2025-05-09, similarity 0.8586):
[0001410578-25-001145:note_history:21]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At March 31, 2025, contract assets, contract liabilities and accounts receivable totaled $125.3 million, $138.5 million and $218.1 million, respectively. During the first six months of 2025, the Company recognized approximately $56 million in revenues that were included in the contract liabilities balance at September 30, 2024. At September 30, 2024, contract assets, contract liabilities and accounts receivable totaled $130.5 million, $134.3 million and $240.7 million, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2025-08-11):
[0001410578-25-001667:note_history:22]
See subsequent event item noted in footnote 4 related to the Company’s divestiture of VACCO.

- removed (2025-08-11):
[0001410578-25-001145:note_history:23]
On April 25, 2025, the Company completed the acquisition of the Signature Management & Power (SM&P) business of Ultra Maritime for a purchase price of approximately $550 million in cash. SM&P will become part of ESCO’s Aerospace & Defense (A&D) segment and will be known as ESCO Maritime Solutions (Maritime) going forward. Their Signature Management and Power Management product lines are highly complementary to ESCO’s current naval programs. Signature Management offers solutions for surface ships and submarines that provide magnetic and electric field countermeasures to prevent underwater mine and sensor detection. Power Management provides innovative and highly-engineered motors that drive critical ship propulsion systems with an ultra-quiet design ensuring low vibration levels to increase stealth capabilities.
