# ESE notes — 0001104659-25-117276


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001104659-25-117276:notes:1]
Cybersecurity Risk Management and Strategy

[0001104659-25-117276:notes:2]
We maintain a data protection and cybersecurity risk management program based upon the National Institute of Standards and Technology (NIST) Cybersecurity framework and the Cybersecurity Maturity Model Certification (CMMC) program to assess, identify and manage cybersecurity risks. As part of this program, we maintain defensive network perimeter safeguards, internal mitigation and control features, continuous system and network monitoring, and contingency data protection. In the event of an incident, we intend to follow our detailed incident response plan, which provides a step-by-step framework to follow from incident detection to mitigation, recovery and notification, including notifying functional areas (e.g., legal), as well as senior leadership and the Board of Directors, as appropriate.

[0001104659-25-117276:notes:3]
As part of our risk management program, we regularly conduct vulnerability assessments, as well as internal user training and tabletop exercises. We also conduct self and third-party assessments of our cybersecurity risk management program to evaluate effectiveness and alignment with NIST and CMMC standards and industry best practices.

[0001104659-25-117276:notes:4]
Our Company’s business strategy, results of operations and financial condition have not been materially affected, and we believe that they are not reasonably likely to be materially affected, by risks from cybersecurity threats, but we cannot provide assurance that the Company will not be materially affected in the future by such risks or any future material incidents. For more information about the cybersecurity risks we face, see Item 1A, “Risk Factors.”


## cyd:CybersecurityRiskBoardOfDirectorsOversightTextBlock

[0001104659-25-117276:notes:5]
Cybersecurity Governance

[0001104659-25-117276:notes:6]
Our cybersecurity program is managed by a global internal team that addresses potential risks, implements processes to support our cybersecurity program and responds to potential cyber incidents. The team has decades of experience with varied certifications and includes our Senior Director of IT who has over 25 years of experience as an IT professional engaged in network cybersecurity. The internal team is supported by third party providers to expand coverage, expertise and responsiveness.

[0001104659-25-117276:notes:7]
Annual risk assessments are performed and incorporated as part of our overall enterprise risk management process, which is overseen by our Board of Directors. Management regularly provides data protection and cybersecurity reports to the Audit Committee and the Board of Directors, which includes updates on cybersecurity initiatives, cybersecurity metrics and threat landscape.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001104659-25-117276:notes:8]
1.      Summary of Significant Accounting Policies

[0001104659-25-117276:notes:9]
A.      Principles of Consolidation

[0001104659-25-117276:notes:10]
The Consolidated Financial Statements include the accounts of ESCO Technologies Inc. (ESCO) and its wholly owned subsidiaries. Except where the context indicates otherwise, the terms “Company”, “we”, “our” and “us” are used in this report to refer to ESCO together with its subsidiaries through which its businesses are conducted. All significant intercompany transactions and accounts have been eliminated in consolidation.

[0001104659-25-117276:notes:11]
B.      Basis of Presentation

[0001104659-25-117276:notes:12]
Our fiscal year ends on September 30. Throughout the Consolidated Financial Statements, unless the context indicates otherwise, references to a year (for example 2025) refer to fiscal year ending on September 30 of that year.

[0001104659-25-117276:notes:13]
The VACCO business is reflected as discontinued operations in the Consolidated Financial Statements and related notes for all periods presented, in accordance with GAAP. Prior period amounts have been reclassified to conform to the current period presentation. See Note 3 for further discussion.

[0001104659-25-117276:notes:14]
C.      Nature of Operations

[0001104659-25-117276:notes:15]
We are organized based on the products and services we offer and we currently classify our business operations in three segments for financial reporting purposes: Aerospace & Defense (A&D), Utility Solutions Group (USG), and RF Test & Measurement (Test).

[0001104659-25-117276:notes:16]
A&D: The companies within this segment primarily design and manufacture specialty filtration products, including hydraulic filter elements and fluid control devices used in commercial and defense aerospace applications; custom designed filters for manned aircraft and submarines; products and systems to reduce vibration and/or acoustic signatures and otherwise reduce or obscure a vessel’s signature, power management and control equipment, sealing, surface control and hydrodynamic related applications to enhance U.S. and UK Navy maritime survivability; precision-tolerance machined components for the aerospace and defense industry; and metal processing services; and miniature electro-explosive devices utilized in mission-critical defense and aerospace applications.

[0001104659-25-117276:notes:17]
USG: The companies within this segment provide diagnostic testing solutions that enable electric power grid operators to assess the integrity of high-voltage power delivery equipment, as well as decision support tools for the renewable energy industry, primarily wind and solar.

[0001104659-25-117276:notes:18]
Test: The companies within this segment provide their customers with the ability to identify, measure and control magnetic and electromagnetic energy.

[0001104659-25-117276:notes:19]
In addition, for reporting certain financial information we treat Corporate activities as a separate segment.

[0001104659-25-117276:notes:20]
D.      Use of Estimates

[0001104659-25-117276:notes:21]
The preparation of financial statements in conformity with GAAP requires Management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.

[0001104659-25-117276:notes:22]
E.      Revenue Recognition

[0001104659-25-117276:notes:23]
We recognize revenue when control of the goods or services promised under the contract is transferred to the customer either at a point in time (e.g., upon delivery) or over time (e.g., as we perform under the contract). We account for a contract when it has approval and commitment from both parties, the rights and payment terms of the parties are identified, the contract has commercial substance and collectability of consideration is probable. We review contracts to determine whether there are one or multiple performance obligations. A performance obligation is a promise to transfer a distinct good or service to a customer and represents the unit of accounting for revenue recognition. For contracts with multiple performance obligations, we allocate the expected consideration, or the transaction price, to each performance obligation identified in the contract based on the relative standalone selling price of each performance obligation. We then recognize revenue for the transaction price allocated to the performance obligation when control of the promised goods or services underlying the performance obligation is transferred.

[0001104659-25-117276:notes:24]
Payment terms with our customers vary by the type and location of the customer and the products or services offered. We do not adjust the promised amount of consideration for the effects of significant financing components based on the expectation that the period between when we transfer a promised good or service to a customer and when the customer pays for that good or service will be one year or less. Arrangements with customers that include payment terms extending beyond one year are not significant. We account for shipping and handling costs on a gross basis and include them in net sales. We account for taxes collected from customers and remitted to governmental authorities on a net basis and exclude them from net sales.

[0001104659-25-117276:notes:25]
A&D: Within the A&D segment, approximately 52% of revenues (approximately 23% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial and military customers and have a single performance obligation as there is only one good promised or the promise to transfer the goods or services is not distinct or separately identifiable from other promises in the contract. The transaction price for these contracts reflects our estimate of returns and discounts, which are based on historical, current and forecasted information to determine the expected amount to which we will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to the customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in cost of goods sold in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

[0001104659-25-117276:notes:26]
Approximately 48% of the segment’s revenues (approximately 21% of consolidated revenues) are accounted for over time as the product does not have an alternative use and we have an enforceable right to payment for costs incurred plus a reasonable margin or the inventory is owned by the customer. The related contracts are primarily cost-plus or fixed price contracts related to the design, development and manufacture of complex fluid control products, valves, manifolds, shock and vibration dampening, thermal insulation and systems primarily for the commercial aerospace and military markets. The contracts may contain multiple products, which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. Our contracts are frequently modified for changes in contract specifications and requirements. Most of our contract modifications are for products that are not distinct from the existing contract and are accounted for as part of that existing contract.

[0001104659-25-117276:notes:27]
Contracts with the U.S. Government generally contain clauses that provide lien rights to work-in-process along with clauses that allow the customer to unilaterally terminate the contract for convenience, pay us for costs incurred plus a reasonable profit and take control of any work-in-process. Due to the continuous transfer of control to the U.S. Government, we recognize revenue over the time that we perform under the contract.

[0001104659-25-117276:notes:28]
Selecting the method to measure progress towards completion for the commercial and military contracts requires judgment and is based on the nature of the products or service to be provided. We generally use the cost-to-cost method to measure progress for our A&D segment contracts, as the rate at which costs are incurred to fulfill a contract best depicts the transfer of control to the customer. Under this method, we measure the extent of progress towards completion based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and record revenue proportionally as costs are incurred based on an estimated profit margin.

[0001104659-25-117276:notes:29]
The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable.

[0001104659-25-117276:notes:30]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to one or more years, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

[0001104659-25-117276:notes:31]
Under the typical payment terms of our long term fixed price contracts, the customer pays us either performance-based or progress payments. Performance-based payments represent interim payments based on quantifiable measures of performance or on the achievement of specified events or milestones. Progress payments are interim payments of costs incurred as the work progresses. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred, which we present as contract assets and contract liabilities, respectively, in the Consolidated Balance Sheets. We classify amounts billed and due from our customers in Accounts receivable, net. For short term fixed price and cost-type contracts, we are generally paid within a short period of time.

[0001104659-25-117276:notes:32]
For contracts where revenue is recognized over time, we recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. We have net revenue recognized in the current year from performance obligations satisfied in the prior year due to changes in our estimated costs to complete the related performance obligations. We recognize anticipated losses on contracts in full in the period in which the losses become known.

[0001104659-25-117276:notes:33]
USG: Within the USG segment, approximately 81% of revenues (approximately 28% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and is accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which we will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. We generally do not treat them as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in the period they are incurred. We record taxes collected from customers and remitted to government authorities on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

[0001104659-25-117276:notes:34]
Approximately 19% of the segment’s revenues (approximately 7% of consolidated revenues) are recognized over time as services are performed. The services accounted for under this method include an obligation to provide testing services using hardware and embedded software, software maintenance, training, lab testing, and consulting services. Typically, the related contracts contain a bundle of goods and services that are integrated in the context of the contract. Therefore, the goods and services are not distinct and we have a single performance obligation. Selecting the method to measure progress towards completion for these contracts requires judgment and is based on the nature of the products and service to be provided. We recognize revenue as a series of distinct services based on each day of providing services (straight-line over the contract term) for our USG segment contracts. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Under the typical payment terms of our service contracts, the customer pays us in advance of when services are performed. Because of the timing difference of revenue recognition and customer payment, which is typically received upon commencement of the contract, these contracts result in deferred revenue, which we present as contract liabilities, in the Consolidated Balance Sheets.

[0001104659-25-117276:notes:35]
Included in this category, approximately 4% of the segment’s revenues (approximately 2% of consolidated revenues) are recognized based on the terms of the respective software contract. For contracts that transfer a software license to the customer, revenue will be recognized at a point in time. These type of software contracts represent a right to use the software, or a functional license, in which revenue should be recognized upon transfer of the license. For contracts in software as a service (SaaS) arrangements, revenue will be recognized over time. The customer receives and consumes the benefits of the SaaS arrangement through access to the system which is for a stated period. We will recognize revenue based on each day of providing access (straight-line over the contract term). The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Under the typical payment terms of our software contracts, the customer pays us in advance of when services are performed. Because of the timing difference of revenue recognition and customer payment, these contracts result in deferred revenue, which we present as contract liabilities, in the Consolidated Balance Sheets.

[0001104659-25-117276:notes:36]
Test: Within the Test segment, approximately 19% of revenues (approximately 4% of consolidated revenues) are recognized at a point in time when products such as, antennas and probes are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct because the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in the context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which we will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

[0001104659-25-117276:notes:37]
Approximately 81% of the segment’s revenues (approximately 17% of consolidated revenues) are recorded over time as the product does not have an alternative use and we have an enforceable right to payment for costs incurred plus a reasonable margin. Products accounted for under this guidance include the construction and installation of test chambers to a buyer’s specifications that provide its customers with the ability to measure and contain magnetic and electromagnetic energy. The goods and services related to each installed test chamber are not distinct due to the significant amount of integration provided and each installed chamber is accounted for as a single performance obligation. Selecting the method to measure progress towards completion for these contracts requires judgment and is based on the nature of the products and service to be provided. We use milestones to measure progress for our Test segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. For arrangements that are accounted for under this guidance, we estimate profit as the difference between total revenue and total estimated cost of a contract and recognize these revenues and costs based primarily on contract milestones. The transaction price for our contracts is typically fixed price and represents our best estimate of the consideration we will receive.

[0001104659-25-117276:notes:38]
We estimate total contract cost utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to a year, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

[0001104659-25-117276:notes:39]
Under the typical payment terms of our fixed price contracts, the customer pays us either based on progress or based on a fixed billing schedule within the contract. Performance-based payments represent interim payments based on noted progress points as the work progresses. Because of the timing difference of revenue recognition and customer billing, these contracts result in revenue recognized in excess of billings and billings in excess of revenue recognized, which we present as contract assets and contract liabilities, respectively, in the Consolidated Balance Sheets. Amounts billed and due from our customers are classified in Accounts receivable, net.

[0001104659-25-117276:notes:40]
For contracts where revenue is recognized over time, we generally recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. We have net revenue recognized in the current year from performance obligations satisfied in the prior year due to changes in our estimated costs to complete the related performance obligations. We recognize anticipated losses on contracts in full in the period in which the losses become probable and estimable.

[0001104659-25-117276:notes:41]
Contract Assets and Liabilities

[0001104659-25-117276:notes:42]
Contract assets arise from contracts when revenue is recognized over time and the amount of revenue recognized, including our estimate of variable consideration that has been included in the transaction price, exceeds the amount billed to the customer. These amounts are included in contract assets until the right to payment is no longer conditional on events other than the passage of time. These contract assets are reclassified to receivables when the right to consideration becomes unconditional. Contract liabilities include deposits, deferred revenue, upfront payments and billings in excess of revenue recognized. We include liabilities for customer rebates and discounts in other current liabilities in the Consolidated Balance Sheets.

[0001104659-25-117276:notes:43]
See the further discussion of our revenue recognition in Note 13 below.

[0001104659-25-117276:notes:44]
F.      Cash and Cash Equivalents

[0001104659-25-117276:notes:45]
Cash equivalents include temporary investments that are readily convertible into cash, such as money market funds, with original maturities of three months or less. Some of our cash is deposited with financial institutions located throughout the U.S. and at banks in foreign countries where we operate subsidiary offices, and at times may exceed insured limits. Cash and cash equivalents held in foreign bank accounts totaled $97.7 million at September 30, 2025 and we routinely repatriate cash from our foreign subsidiaries.

[0001104659-25-117276:notes:46]
G.      Accounts Receivable

[0001104659-25-117276:notes:47]
We reduce accounts receivable by an allowance for amounts that we estimate are uncollectible in the future. This estimated allowance is based on Management’s evaluation of the financial condition of the customer and historical write-off experience.

[0001104659-25-117276:notes:48]
H.      Inventories

[0001104659-25-117276:notes:49]
We value inventories at the lower of cost (first-in, first-out) or net realizable value. We regularly review inventories for excess quantities and obsolescence based upon historical experience, specific identification of discontinued items, future demand, and market conditions. Inventories under long-term contracts reflect accumulated production costs, factory overhead, initial tooling and other related costs less the portion of such costs charged to cost of sales.

[0001104659-25-117276:notes:50]
I.      Property, Plant and Equipment

[0001104659-25-117276:notes:51]
Property, plant and equipment are recorded at cost. Depreciation and amortization are computed primarily on a straight-line basis over the estimated useful lives of the assets: buildings, 10–40 years; machinery and equipment, 3–10 years; and office furniture and equipment, 3–10 years. Leasehold improvements are amortized over the remaining term of the applicable lease or their estimated useful lives, whichever is shorter. Long-lived tangible assets are reviewed for impairment whenever events or changes in business circumstances indicate the carrying value of the assets may not be recoverable. Impairment losses are recognized based on fair value.

[0001104659-25-117276:notes:52]
J.      Leases

[0001104659-25-117276:notes:53]
Our lease agreements primarily relate to office space, manufacturing facilities, and machinery and equipment. We determine at lease inception whether an arrangement that provides control over the use of an asset is a lease. We recognize at lease commencement a right-of-use (ROU) asset and lease liability based on the present value of the future lease payments over the lease term. We have elected not to recognize a ROU asset and lease liability for leases with terms of 12 months or less. Certain of our leases include options to extend the term of the lease for up to 20 years. When it is reasonably certain that we will exercise the option, Management includes the impact of the option in the lease term for purposes of determining total future lease payments. As most of our lease agreements do not explicitly state the discount rate implicit in the lease, Management uses our incremental borrowing rate on the commencement date to calculate the present value of future payments based on the tenor of each arrangement.

[0001104659-25-117276:notes:54]
K.      Goodwill and Other Long-Lived Intangible Assets

[0001104659-25-117276:notes:55]
Goodwill represents the excess of purchase price over the fair value of net identifiable assets acquired in business acquisitions. Management annually reviews goodwill and other long-lived assets with indefinite useful lives for impairment or whenever events or changes in circumstances indicate the carrying amount may be less than fair value. If we determine that the carrying value of the long-lived asset or reporting unit is less than fair value, we record a permanent impairment charge for the amount by which the carrying value of the long-lived asset exceeds its fair value. We measure the fair value of our reporting units based on a discounted cash flow method using a discount rate determined by Management to be commensurate with the risk inherent in each of our reporting units’ current business models. We determine the fair value of trade names using a generally accepted valuation method based on an income approach called the relief from royalty method. During 2025, Management performed a quantitative impairment analysis, which included a detailed calculation of the fair value of our trade names and reporting units related to certain reporting units within these segments. A Step 0 analysis was performed on the other reporting units for which a quantitative analysis was not performed. The results of these impairment analyses indicated that the fair values of the trade names and reporting units are not less than their carrying values. Our estimates of discounted cash flows to derive the fair value were measured in accordance with ASC 350, Intangibles – Goodwill and Other. We are using estimates of discounted cash flows that may change, and if they change negatively it could result in the need to write down those assets to fair value.

[0001104659-25-117276:notes:56]
Other intangible assets represent costs allocated to identifiable intangible assets, principally customer relationships, capitalized software, patents, trademarks, and technology rights. We amortize intangible assets with estimable useful lives over their respective estimated useful lives to their estimated residual values, and review them for impairment whenever events or changes in business circumstances indicate the carrying value of the assets may not be recoverable.

[0001104659-25-117276:notes:57]
See Note 4 regarding goodwill and other intangible assets activity.

[0001104659-25-117276:notes:58]
L.      Capitalized Software

[0001104659-25-117276:notes:59]
Costs incurred for the development of computer software that will be sold, leased, or otherwise marketed are charged to research and development expense when incurred, until technological feasibility has been established for the product. Technological feasibility is typically established upon completion of a detailed program design. Costs incurred after this point are capitalized on a project-by-project basis. Capitalized costs consist of internal and external development costs. Upon general release of the product to customers, we cease capitalization and begin amortization, which is calculated on a project-by-project basis as the greater of (1) the ratio of current gross revenues for a product to the total of current and anticipated future gross revenues for the product or (2) the straight-line method over the estimated economic life of the product. We generally amortize software development costs over a three-to-seven year period based upon the estimated future economic life of the product. Factors we consider in determining the estimated future economic life of the product include anticipated future revenues, and changes in software and hardware technologies. Management annually reviews the carrying values of capitalized costs for impairment or whenever events or changes in circumstances indicate the carrying amount may not be recoverable. If expected cash flows are insufficient to recover the carrying amount of the asset, then we recognize an impairment loss to state the asset at its net realizable value.

[0001104659-25-117276:notes:60]
M.      Income Taxes

[0001104659-25-117276:notes:61]
We account for income taxes under the asset and liability method. We recognize deferred tax assets and liabilities for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. We measure deferred tax assets and liabilities using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. We may reduce deferred tax assets by a valuation allowance if it is more likely than not that some portion or all of the deferred tax assets will not be realized. We recognize the effect on deferred tax assets and liabilities of a change in tax rates in income in the period that includes the enactment date. We regularly review our deferred tax assets for recoverability and establish a valuation allowance when Management believes it is more likely than not such assets will not be recovered, taking into consideration historical operating results, expectations of future earnings, tax planning strategies, and the expected timing of the reversals of existing temporary differences. Our policy is to include interest related to unrecognized tax benefits in income tax expense and penalties in operating expense.

[0001104659-25-117276:notes:62]
N.      Research and Development Costs

[0001104659-25-117276:notes:63]
Company-sponsored research and development costs include research and development and bid and proposal efforts related to our products and services. We charge Company-sponsored product development costs to expense when incurred. Customer-sponsored research and development costs refer to certain situations whereby customers provide funding to support specific contractually defined research and development costs. We account for customer-sponsored research and development costs incurred pursuant to contracts similarly to other program costs. Total Company and customer-sponsored research and development expenses from continuing operations were approximately $23.0 million, $12.0 million and $13.0 million for 2025, 2024 and 2023, respectively.

[0001104659-25-117276:notes:64]
O.      Foreign Currency Translation

[0001104659-25-117276:notes:65]
We translate the financial statements of our foreign operations into U.S. dollars in accordance with FASB ASC Topic 830, Foreign Currency Matters. We record the resulting translation adjustments as a separate component of accumulated other comprehensive income.

[0001104659-25-117276:notes:66]
P.      Earnings Per Share

[0001104659-25-117276:notes:67]
We calculate basic earnings per share using the weighted average number of common shares outstanding during the period. We calculate diluted earnings per share using the weighted average number of common shares outstanding during the period plus shares issuable upon the assumed exercise of dilutive vesting of unvested performance-based share awards and time–vested restricted shares by using the treasury stock method. There are no anti-dilutive shares.

[0001104659-25-117276:notes:68]
The number of shares used in the calculation of earnings per share for each year presented is as follows:

[0001104659-25-117276:notes:69]
| (in thousands) |  | 2025 |  | 2024 |  | 2023 |
| Weighted Average Shares Outstanding — Basic |  | 25,811 |  | 25,774 |  | 25,802 |
| Dilutive Shares | ​ | 99 | ​ | 98 | ​ | 77 |
| Adjusted Shares — Diluted |  | 25,910 |  | 25,872 |  | 25,879 |

[0001104659-25-117276:notes:70]
Q.      Share-Based Compensation

[0001104659-25-117276:notes:71]
We provide compensation benefits to certain key employees under several share-based plans providing for a combination of performance-based share unit (PSU) awards and time-vested restricted share units (RSU) awards, and to non-employee directors under a separate compensation plan for non-employee directors. We measure share-based payment expense at the grant date based on the fair value of the award and recognize it on a straight-line basis over the requisite service period (generally the vesting period of the award) and/or if the performance criteria are deemed probable.

[0001104659-25-117276:notes:72]
R.      Accumulated Other Comprehensive Loss

[0001104659-25-117276:notes:73]
Accumulated other comprehensive loss of $(2.5) million at September 30, 2025 and $(10.8) million at September 30, 2024 consisted of currency translation adjustments.

[0001104659-25-117276:notes:74]
S.      Fair Value Measurements

[0001104659-25-117276:notes:75]
Fair value is defined as the price at which an asset could be exchanged in a current transaction between knowledgeable, willing parties or the amount that would be paid to transfer a liability to a new obligor, not the amount that would be paid to settle the liability with the creditor. Where available, we base fair value on observable market prices or parameters or derived from such prices or parameters. Where observable prices or inputs are not available, we apply valuation models. These valuation techniques involve some level of Management estimation and judgment, the degree of which is dependent on the price transparency for the instruments or market and the instruments’ complexity.

[0001104659-25-117276:notes:76]
The accounting guidance establishes a three-level hierarchy for disclosure of fair value measurements, based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date, as follows:

[0001104659-25-117276:notes:77]
Level 1 – Inputs to the valuation methodology are quoted prices (unadjusted) for identical assets or liabilities in active markets.

[0001104659-25-117276:notes:78]
Level 2 – Inputs to the valuation methodology include quoted prices for similar assets and liabilities in active markets, and inputs that are observable for the asset or liability, either directly or indirectly, for substantially the full term of the financial instrument.

[0001104659-25-117276:notes:79]
Level 3 – Inputs to the valuation methodology are unobservable and significant to the fair value measurement.

[0001104659-25-117276:notes:80]
Financial Assets and Liabilities

[0001104659-25-117276:notes:81]
We have estimated the fair value of our financial instruments as of September 30, 2025 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, payables and other current assets and liabilities approximate fair value because of the short maturity of those instruments. The carrying amounts due under the revolving credit facility approximate fair value as the interest on outstanding borrowings is calculated at a spread over either an Adjusted Term SOFR Rate, Adjusted EURIBOR Rate, Adjusted CDOR Rate, Alternate Base Rate or Daily Simple RFR, at the Company’s election.

[0001104659-25-117276:notes:82]
Nonfinancial Assets and Liabilities

[0001104659-25-117276:notes:83]
Our nonfinancial assets such as property, plant and equipment, inventories, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during 2025.

[0001104659-25-117276:notes:84]
T.      New Accounting Pronouncements

[0001104659-25-117276:notes:85]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures,” which provides qualitative and quantitative updates to the rate reconciliation and income taxes paid disclosures. This ASU will be effective for fiscal years beginning after December 15, 2024. Other than additional disclosure, we do not expect a change to our consolidated statements of operations, financial position, or cash flows.

[0001104659-25-117276:notes:86]
In November 2024, the FASB issued ASU 2024-03, “Disaggregation of Income Statement Expenses,” which requires disaggregated disclosure of income statement expenses for public business entities. The ASU does not change the expense captions an entity presents on the face of the income statement; rather, it requires disaggregation of certain expense captions into specified categories in disclosures within the footnotes to the financial statements. This ASU will be effective for fiscal years beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027. Other than additional disclosure, we do not expect a change to our consolidated statements of operations, financial position, or cash flows.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001104659-25-117276:notes:87]
2.     Acquisitions

[0001104659-25-117276:notes:88]
2025

[0001104659-25-117276:notes:89]
On April 25, 2025, the Company completed the acquisition of the Signature Management & Power (SM&P) business of Ultra Maritime, since renamed as ESCO Maritime Solutions (Maritime), for a cash purchase price of approximately $472 million, net of cash acquired. Maritime is part of ESCO’s Aerospace & Defense (A&D) segment, and its Signature Management and Power Management product lines are highly complementary to ESCO’s current naval programs: Signature Management offers solutions for surface ships and submarines that provide magnetic and electric field countermeasures to prevent underwater mine and sensor detection, and Power Management provides innovative and highly-engineered motors that drive critical ship propulsion systems with an ultra-quiet design ensuring low vibration levels to increase stealth capabilities. Maritime contributed $95.2 million in revenue in 2025 since the date of acquisition.

[0001104659-25-117276:notes:90]
Since the date of acquisition, the operating results for the Maritime business have been included as part of the A&D segment. The acquisition date fair values of the assets acquired and liabilities assumed were primarily as follows: $72.2 million of cash, $22.9 million of accounts receivable, $16.2 million of inventory, $15.1 million of contract assets, $1.6 million of prepaid assets, $12.2 million of property, plant and equipment, $5.0 million of other assets, $9.7 million of accounts payable, $18.2 million of accrued expenses and other current liabilities, $104.5 million of contract liabilities, $3.5 million of other liabilities, $45.5 million of deferred tax liabilities, $290.5 million of customer relationships and $61.3 million of backlog. The customer relationships were determined to have a useful life of fifteen years and the backlog was determined to have a useful life of two years. The acquired goodwill of $226.5 million relates to the excess value associated with opportunities to expand the services and products that we can offer to our customers as well as access to new markets. We expect that approximately $100 million of this goodwill will be deductible for tax purposes.

[0001104659-25-117276:notes:91]
Pro Forma Results

[0001104659-25-117276:notes:92]
The following pro forma financial information for the years ended September 30, 2025 and 2024 presents the combined results of operations of ESCO and Maritime as if the acquisition had occurred on October 1, 2023. The pro forma financial information for the periods presented excludes the VACCO business which was sold in July 2025. The combined results of operations have been adjusted for the impact of certain acquisition-related items, including additional amortization of identifiable intangible assets, additional financing expenses and other direct costs. The impact of pro forma adjustments are tax-effected at the expected consolidated corporate tax rate. The unaudited pro forma financial information is not intended to represent, or be indicative of, the Company’s consolidated results of operations or financial condition that would have been reported had the acquisition been completed as of the beginning of each of the periods presented. This information is provided for illustrative purposes only and is not necessarily indicative of the Company’s future consolidated results of operations or financial condition.

[0001104659-25-117276:notes:93]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ |
| (Unaudited) | ​ | ​ | ​ | ​ | ​ |
| Pro Forma Results |  | FY 2025 |  | FY 2024 |
| Net sales | ​ | $ | 1,198.2 | ​ | 1,097.3 |
| Net earnings from continuing operations | ​ | $ | 111.1 |  | 61.2 |

[0001104659-25-117276:notes:94]
2024

[0001104659-25-117276:notes:95]
On November 9, 2023, we acquired MPE for a purchase price of approximately $56.2 million, net of cash acquired. MPE is a leading global manufacturer of high-performance EMC/EMP filters and capacitor products for military, utility, telecommunication, and other critical infrastructure applications. Since the date of acquisition, the operating results for the MPE business have been included as part of ETS-Lindgren in the Test segment. MPE contributed $10 million in revenue in 2024 since the date of acquisition. The acquisition date fair value of the assets acquired and liabilities assumed primarily were as follows: approximately $0.4 million of accounts receivable, $1.1 million of inventory, $1.7 million of property, plant and equipment, $0.7 million of accounts payable and accrued expenses, $8.1 million of deferred tax liabilities, and $31.1 million of identifiable intangible assets, mainly consisting of customer relationships totaling $29.1 million. The acquired goodwill of $30.6 million related to excess value associated with opportunities to expand the services and products that we can offer to our customers. We do not anticipate that the goodwill will be deductible for tax purposes. We paid a $0.2 million working capital settlement in the third quarter of 2024.

[0001104659-25-117276:notes:96]
2023

[0001104659-25-117276:notes:97]
On February 1, 2023, we acquired CMT Materials, LLC and its affiliate Engineered Syntactic Systems, LLC (together, CMT) for a purchase price of approximately $18 million, net of cash acquired. CMT, based in Attleboro, Massachusetts, is a supplier of syntactic materials for buoyancy and specialty applications. Since the date of acquisition, the operating results for the CMT business have been included as part of Globe in the A&D segment. The acquisition date fair value of the assets acquired and liabilities assumed primarily were as follows: approximately $1.7 million of accounts receivable, $3.0 million of inventory, $1.3 million of property, plant and equipment, $1.2 million of accounts payable and accrued expenses, and $7.3 million of identifiable intangible assets mainly consisting of customer relationships totaling $6.2 million. The acquired goodwill of $5.6 million related to excess value associated with opportunities to expand the services and products that we can offer to our customers. The full amount of acquired goodwill is deductible for tax purposes. We received a $0.2 million working capital settlement during the third quarter of 2023.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001104659-25-117276:notes:98]
3.      VACCO Divestiture

[0001104659-25-117276:notes:99]
On July 18, 2025, the Company completed the divestiture of VACCO Industries (VACCO) to RBC Bearings Incorporated (RBC), an international manufacturer and marketer of highly engineered precision bearings and products, headquartered in Oxford, Connecticut. Results of operations, financial position and cash flows for the VACCO business are reflected as discontinued operations in the Condensed Consolidated Financial Statements and related notes for all periods presented. The sale of VACCO represents a strategic shift for the Company to exit the Space business.

[0001104659-25-117276:notes:100]
Net sales from the VACCO business were $102.9 million, $107.6 million and $100.2 million for the years ending September 30, 2025, 2024 and 2023, respectively. Pretax earnings (loss) from the VACCO business were $13.7 million, $(1.1) million and $8.6 million for the years ending September 30, 2025, 2024 and 2023, respectively. The net proceeds from the sale of approximately $270 million and the related after-tax gain on sale of $172.6 million were recorded in the fourth quarter of 2025. The Company anticipates a tax payment of approximately $59 million to be paid during fiscal 2026 related to the gain on sale.

[0001104659-25-117276:notes:101]
The major classes of VACCO’s assets and liabilities included in the Condensed Consolidated Balance Sheet at September 30, 2024 are shown below (in thousands).

[0001104659-25-117276:notes:102]
| ​ |  | September 30, |
| ​ | ​ | 2024 |
| Assets: | ​ |  |
| Accounts receivable, net |  | 18,579 |
| Contract assets |  | 63,822 |
| Inventories |  | 13,699 |
| Other current assets |  | 1,281 |
| Current assets |  | 97,381 |
| Property, plant and equipment, net |  | 21,345 |
| Intangible assets, net |  | 4,078 |
| Goodwill |  | 9,964 |
| Other assets |  | 607 |
| Total assets |  | 133,375 |
| Liabilities: |  |  |
| Accounts payable |  | 9,435 |
| Contract liabilities |  | 44,001 |
| Accrued expenses and other current liabilities |  | 9,063 |
| Current liabilities |  | 62,499 |
| Other liabilities |  | 2,710 |
| Total liabilities |  | 65,209 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001104659-25-117276:notes:103]
4.      Goodwill and Other Intangible Assets

[0001104659-25-117276:notes:104]
Included on the Consolidated Balance Sheets at September 30, 2025 and 2024 are the following intangible assets gross carrying amounts and accumulated amortization from continuing operations:

[0001104659-25-117276:notes:105]
| (Dollars in thousands) |  | 2025 |  | 2024 |
| Goodwill | ​ | $ | 761,931 | ​ | 529,935 |
| Intangible assets with determinable lives: | ​ |  | ​ | ​ | ​ |
| Patents | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 7,607 | ​ | 2,638 |
| Less: accumulated amortization | ​ |  | 1,775 | ​ | 1,415 |
| Net | ​ | $ | 5,832 | ​ | 1,223 |
| Capitalized software | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 138,144 | ​ | 126,721 |
| Less: accumulated amortization | ​ |  | 100,818 | ​ | 89,558 |
| Net | ​ | $ | 37,326 | ​ | 37,163 |
| Customer Relationships | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 625,535 | ​ | 330,328 |
| Less: accumulated amortization | ​ |  | 159,543 | ​ | 132,135 |
| Net | ​ | $ | 465,992 | ​ | 198,193 |
| Other | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 76,991 | ​ | 15,182 |
| Less: accumulated amortization | ​ |  | 24,829 | ​ | 11,173 |
| Net | ​ | $ | 52,162 | ​ | 4,009 |
| Intangible assets with indefinite lives: | ​ |  | ​ | ​ | ​ |
| Trade names | ​ | $ | 162,661 | ​ | 162,936 |

[0001104659-25-117276:notes:106]
We performed our annual evaluation of goodwill and intangible assets for impairment during the fourth quarter of 2025 and concluded that no impairment existed at September 30, 2025. There were no accumulated impairment losses as of September 30, 2025.

[0001104659-25-117276:notes:107]
The changes in the carrying amount of goodwill attributable to each business segment from continuing operations for 2025 and 2024 are as follows:

[0001104659-25-117276:notes:108]
| (Dollars in millions) |  | A&D |  | Test |  | USG |  | Total |
| Balance as of September 30, 2023 | ​ | $ | 105.6 | ​ | ​ | 34.0 | ​ | 353.6 | ​ | 493.2 |
| Acquisition activity | ​ | ​ | — | ​ | ​ | 30.9 | ​ | — | ​ | 30.9 |
| Foreign currency translation and other | ​ | ​ | — | ​ | ​ | 2.5 | ​ | 3.3 | ​ | 5.8 |
| Balance as of September 30, 2024 | ​ | $ | 105.6 | ​ | ​ | 67.4 | ​ | 356.9 | ​ | 529.9 |
| Acquisition activity | ​ | ​ | 226.5 | ​ | ​ | — | ​ | — | ​ | 226.5 |
| Foreign currency translation and other | ​ | ​ | 1.9 | ​ | ​ | 0.4 | ​ | 3.2 | ​ | 5.5 |
| Balance as of September 30, 2025 | ​ | $ | 334.0 | ​ | ​ | 67.8 | ​ | 360.1 | ​ | 761.9 |

[0001104659-25-117276:notes:109]
Amortization expense related to intangible assets with determinable lives was $53.3 million, $32.8 million and $29.0 million in 2025, 2024 and 2023, respectively. Patents are amortized over the life of the patents, generally ten to twenty years. Capitalized software is amortized over the estimated useful life of the software, generally three to seven years. Customer relationships are generally amortized over thirteen to twenty years. Intangible asset amortization for fiscal years 2026 through 2030 is estimated as follows: approximately $80 million in 2026, approximately $67 million in 2027, and approximately $46 million in 2028 - 2030. The weighted-average amortization period of the acquired intangible assets subject to amortization is twelve years.


## us-gaap:InventoryDisclosureTextBlock

[0001104659-25-117276:notes:110]
5.      Inventories

[0001104659-25-117276:notes:111]
Inventories from continuing operations consisted of the following at September 30, 2025 and 2024:

[0001104659-25-117276:notes:112]
| (Dollars in thousands) |  | 2025 |  | 2024 |
| Finished goods | ​ | $ | 52,644 |  | 46,586 |
| Work in process | ​ |  | 46,825 |  | 40,606 |
| Raw materials | ​ |  | 118,338 |  | 108,273 |
| Total | ​ | $ | 217,807 |  | 195,465 |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001104659-25-117276:notes:113]
6.      Income Tax Expense

[0001104659-25-117276:notes:114]
Total income tax expense (benefit) for the years ended September 30, 2025, 2024, and 2023 was allocated to income tax expense as follows:

[0001104659-25-117276:notes:115]
| (Dollars in thousands) |  | 2025 |  | 2024 |  | 2023 |
| Income tax expense from continuing operations | ​ | $ | 36,554 | ​ | 28,325 | ​ | 24,684 |
| Income tax expense (benefit) from discontinued operations |  | ​ | 57,464 |  | (317) |  | 1,718 |
| Total income expense | ​ | $ | 94,018 |  | 28,008 |  | 26,402 |

[0001104659-25-117276:notes:116]
The components of income from continuing operations before income taxes for 2025, 2024 and 2023 consisted of the following:

[0001104659-25-117276:notes:117]
| (Dollars in thousands) |  | 2025 |  | 2024 |  | 2023 |
| United States | ​ | $ | 121,169 |  | 101,123 |  | 90,404 |
| Foreign | ​ |  | 31,684 |  | 29,830 |  | 19,964 |
| Total income before income taxes | ​ | $ | 152,853 |  | 130,953 |  | 110,368 |

[0001104659-25-117276:notes:118]
The principal components of income tax expense (benefit) from continuing operations for 2025, 2024 and 2023 consist of:

[0001104659-25-117276:notes:119]
| (Dollars in thousands) |  | 2025 |  | 2024 |  | 2023 |
| Federal: |  | ​ |  |  |  |  |  |
| Current | ​ | $ | 25,007 |  | 25,584 |  | 21,923 |
| Deferred | ​ |  | (1,185) |  | (7,295) |  | (5,095) |
| State and local: | ​ |  | ​ |  | ​ |  | ​ |
| Current | ​ |  | 3,935 |  | 3,212 |  | 3,304 |
| Deferred | ​ |  | (228) |  | 17 |  | (950) |
| Foreign: | ​ |  | ​ |  | ​ |  | ​ |
| Current | ​ |  | 13,109 |  | 8,602 |  | 5,694 |
| Deferred | ​ |  | (4,084) |  | (1,795) |  | (192) |
| Total | ​ | $ | 36,554 |  | 28,325 |  | 24,684 |

[0001104659-25-117276:notes:120]
The actual income tax expense from continuing operations for 2025, 2024 and 2023 differs from the expected tax expense for those years (computed by applying the U.S. Federal corporate statutory rate) as follows:

[0001104659-25-117276:notes:121]
| ​ |  | 2025 |  | 2024 |  | 2023 |  |
| Federal corporate statutory rate |  | 21.0 | % | 21.0 | % | 21.0 | % |
| State and local, net of Federal benefits | ​ | 2.3 |  | 2.5 |  | 2.1 | ​ |
| Impact of foreign operations | ​ | 1.1 | ​ | 0.4 | ​ | 0.3 | ​ |
| Federal research credit | ​ | (1.1) | ​ | (0.8) | ​ | (0.9) | ​ |
| Executive compensation | ​ | 0.9 |  | 0.2 |  | 1.1 | ​ |
| Valuation allowance | ​ | (0.1) |  | (0.3) |  | 0.3 | ​ |
| U.S. tax on GILTI | ​ | 2.5 | ​ | 2.4 | ​ | 1.3 | ​ |
| GILTI foreign tax credits | ​ | (1.8) | ​ | (2.0) | ​ | (1.0) | ​ |
| FDII deduction | ​ | (1.1) | ​ | (1.7) | ​ | (1.7) | ​ |
| Other, net | ​ | 0.2 |  | (0.1) |  | (0.1) | ​ |
| Effective income tax rate | ​ | 23.9 | % | 21.6 | % | 22.4 | % |

[0001104659-25-117276:notes:122]
The tax effects of temporary differences that give rise to significant portions of the deferred tax assets and liabilities at September 30, 2025 and 2024 are presented below:

[0001104659-25-117276:notes:123]
| (Dollars in thousands) |  | 2025 |  | 2024 |
| Deferred tax assets: |  | ​ |  |  |  |
| Inventories | ​ | $ | 5,589 |  | 4,663 |
| Pension and other postretirement benefits | ​ |  | 417 |  | 460 |
| Capitalized research and development expenditures | ​ | ​ | 14,648 | ​ | 9,726 |
| Lease liabilities | ​ | ​ | 8,571 | ​ | 7,183 |
| Net operating and capital loss carryforwards — domestic | ​ |  | 473 |  | 544 |
| Net operating loss carryforward — foreign | ​ |  | 3,855 |  | 3,855 |
| Other compensation-related costs and other cost accruals | ​ |  | 9,904 |  | 9,289 |
| State credit carryforward | ​ |  | 1,016 |  | 1,601 |
| Total deferred tax assets | ​ |  | 44,473 |  | 37,321 |
| Deferred tax liabilities: | ​ |  | ​ |  | ​ |
| ROU assets | ​ | ​ | (8,906) | ​ | (6,627) |
| Goodwill | ​ |  | (15,904) |  | (13,353) |
| Acquisition intangible assets | ​ |  | (107,190) |  | (66,986) |
| Depreciation, software amortization | ​ |  | (20,359) |  | (17,079) |
| Net deferred tax liabilities before valuation allowance | ​ |  | (107,886) |  | (66,724) |
| Less valuation allowance | ​ |  | (1,347) |  | (1,513) |
| Net deferred tax liabilities | ​ | $ | (109,233) |  | (68,237) |

[0001104659-25-117276:notes:124]
We had a foreign net operating loss (NOL) carryforward of $13.9 million at September 30, 2025, which reflects tax loss carryforwards in Germany, Canada, Japan, and the United Kingdom. Approximately $12.1 million of the tax loss carryforwards have no expiration date while the remaining $1.8 million will expire between 2031 and 2042.We had deferred tax assets related to state NOL carryforwards of $0.5 million at September 30, 2025 which expire between 2031 and 2045. We also had state research and other credit carryforwards of $1.0 million of which $0.1 million expires between 2035 and 2045. The remaining $0.9 million does not have an expiration date.

[0001104659-25-117276:notes:125]
The valuation allowance for deferred tax assets as of September 30, 2025 and 2024 was $1.3 million and $1.5 million, respectively. The net change in the total valuation allowance for each of the years ended September 30, 2025 and 2024 was a decrease of $0.2 million and $0.3 million, respectively. In addition, we maintained a valuation allowance against state NOL carryforwards that are not expected to be realized in future periods of $0.4 million at September 30, 2025 and $0.5 million at September 30, 2024. Lastly, we released a valuation allowance against foreign deferred tax assets of $0.1 million in the year ended September 30, 2025, which resulted in a valuation allowance against foreign deferred assets which may not be realized in future periods of $0.9 million and $1.0 million at September 30, 2025 and 2024, respectively.

[0001104659-25-117276:notes:126]
As of September 30, 2025, the Company does not have any material unrecognized tax benefits.


## us-gaap:DebtDisclosureTextBlock

[0001104659-25-117276:notes:127]
7.      Debt

[0001104659-25-117276:notes:128]
Debt consists of the following at September 30, 2025 and 2024:

[0001104659-25-117276:notes:129]
| (Dollars in thousands) |  | 2025 |  | 2024 |
| Revolving credit facility | ​ | $ | 25,000 | ​ | 122,000 |
| Incremental facility (Term loan A) | ​ | ​ | 161,000 | ​ | — |
| Total borrowings | ​ | ​ | 186,000 |  | 122,000 |
| Current portion of long-term debt and short-term borrowings | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 166,000 |  | 102,000 |

[0001104659-25-117276:notes:130]
The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of seven banks led by JP Morgan Chase Bank, N.A., as administrative agent, Bank of America, N.A., as syndication agent, and Commerce Bank and TD Bank, N.A. as co-documentation agents. The Credit Facility matures August 30, 2028, with balance due by this date. The Credit Facility is secured by the unlimited guaranty of our direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of our direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. As of September 30, 2025, we were in compliance with all covenants.

[0001104659-25-117276:notes:131]
On August 5, 2024, the Company and certain of its subsidiaries entered into Amendment No. 1 (the “Amendment”) to the Credit Facility which, among other things, (i) implements a senior incremental delayed draw term loan credit facility in an aggregate principal amount of up to $375 million (the “Incremental Facility”), and (ii) permits the direct or indirect acquisition by the Registrant or certain of its subsidiaries of all of the issued and outstanding shares of PMES I Limited, Measurement Systems, Inc., EMS Development Corporation, and DNE Technologies, Inc. (the “Maritime Acquisition”), pursuant to and in accordance with the terms and conditions of the Sale and Purchase Agreement dated July 8, 2024 among Ultra Electronics Holdings Limited, as parent seller, the Registrant, as guarantor, and certain of the Registrant’s subsidiaries as buyers. During the third quarter of 2025, the proceeds of the loans drawn under the Incremental Facility were applied to pay a portion of the cash consideration for the Maritime Acquisition and other customary fees, premiums, expenses and costs incurred in connection with the acquisition. The Incremental Facility matures August 30, 2028, with the balance due by that date.

[0001104659-25-117276:notes:132]
Interest on borrowings under the Credit Facility and the Incremental Facility is calculated at a spread ranging from 0.25% to 2.25% over either an Adjusted Term SOFR Rate, Adjusted EURIBOR Rate, Adjusted CDOR Rate, Alternate Base Rate or Daily Simple RFR, at the Company’s election. The Credit Facility also requires a facility fee ranging from 12.5 to 25 basis points per annum. The interest rate spreads and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio.

[0001104659-25-117276:notes:133]
At September 30, 2025, we had approximately $465 million available to borrow under the Credit Facility, plus the $250 million increase option subject to the lenders’ consent, in addition to $101.4 million cash on hand. We classified $20 million as the current portion of long-term debt as of September 30, 2025, as we intend to repay at least this amount within the next twelve months; however, we have no contractual obligation to repay such amount during the next twelve months.

[0001104659-25-117276:notes:134]
During 2025 and 2024, our maximum aggregate short-term borrowings at any month-end were $637 million and $191 million, respectively, and the average aggregate short-term borrowings outstanding based on month-end balances were $264.9 million and $166.6 million, respectively. The weighted average interest rates under the Credit Facility were 5.99% and 6.72% for 2025 and 2024, respectively. The weighted average interest rate under the Incremental Facility was 6.38% for 2025. As of September 30, 2025, the interest rate on our debt was 6.50%. The letters of credit issued and outstanding under the Credit Facility totaled $10.1 million and $5.0 million at September 30, 2025 and 2024, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001104659-25-117276:notes:135]
8.      Capital Stock

[0001104659-25-117276:notes:136]
The 30,886,024 and 30,809,483 common shares as presented in the accompanying Consolidated Balance Sheets at September 30, 2025 and 2024 represent the actual number of shares issued at the respective dates. We held 5,056,771 common shares in treasury at both September 30, 2025 and 2024.

[0001104659-25-117276:notes:137]
In August 2024, our Board of Directors approved a common stock repurchase program authorizing us to repurchase shares of our stock from time to time in Management’s discretion, in the open market or otherwise, up to a maximum total repurchase amount of $200 million or the maximum amount permitted under our bank credit agreements, if less, over a three-year period expiring September 30, 2027. We did not repurchase any shares in 2025 and we repurchased approximately 80,500 shares in 2024.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001104659-25-117276:notes:138]
9.      Share-Based Compensation

[0001104659-25-117276:notes:139]
We provide compensation benefits to certain key employees under several share-based plans providing for a combination of performance-based share unit (PSU) awards and time-vested restricted share unit (RSU) awards and to non-employee directors under a separate compensation plan. As of September 30, 2025, our equity compensation plans had a total of 808,103 shares authorized and available for future issuance.

[0001104659-25-117276:notes:140]
Performance Share Unit (PSU) Awards and Time-Vested Restricted Stock Unit (RSU) Awards

[0001104659-25-117276:notes:141]
The Company grants PSU awards with a three-year vesting period, with each PSU representing the right to receive one share of Company common stock if certain performance targets are achieved over a corresponding three-year performance period. Beginning in fiscal 2023, the targets were based on achieving certain EBITDA and Return on Invested Capital (ROIC) metrics and utilizing an rTSR modifier.

[0001104659-25-117276:notes:142]
RSU awards represent the right to receive a specified number of shares of Company common stock if and when the award vests. Each RSU represents the right to receive one share of Company common stock if the recipient remains continuously employed by the Company until the award vests. RSU awards granted prior to fiscal 2023 were normally granted in the spring with full vesting approximately 3 ½ years after the effective award date, while RSU awards granted in fiscal 2023 were normally granted in the spring with vesting one-third at the end of each November beginning approximately 18 months after the award date, and RSU awards granted in fiscal 2024 and fiscal 2025 were normally granted in the fall with vesting one-third at the end of each November beginning approximately 12 months after the award date. The RSU award grants were valued at the stock price on the date of grant.

[0001104659-25-117276:notes:143]
Pretax compensation expense related to the above awards was $9.3 million, $7.5 million and $7.6 million for 2025, 2024 and 2023, respectively.

[0001104659-25-117276:notes:144]
The following summary presents information regarding outstanding share-based compensation awards as of the specified dates, and changes during the specified periods:

[0001104659-25-117276:notes:145]
| ​ | ​ | FY 2025 | ​ | FY 2024 | ​ | FY 2023 |
| ​ |  | ​ |  | Estimated |  | ​ |  | Estimated |  | ​ |  | Estimated |
| ​ | ​ | ​ | ​ | Weighted | ​ | ​ | ​ | Weighted | ​ | ​ | ​ | Weighted |
| ​ | ​ | Shares | ​ | Avg. Price | ​ | Shares | ​ | Avg. Price | ​ | Shares | ​ | Avg. Price |
| Nonvested at October 1, |  | 220,758 | ​ | $ | 102.40 |  | 189,725 | ​ | $ | 94.91 |  | 265,367 | ​ | $ | 84.29 |
| Granted |  | 104,353 | ​ |  | 145.39 |  | 78,016 | ​ |  | 108.16 |  | 84,880 | ​ |  | 93.64 |
| Vested |  | (98,574) | ​ |  | 138.40 |  | (34,753) | ​ |  | 96.52 |  | (119,811) | ​ |  | 82.28 |
| Cancelled |  | (19,259) | ​ |  | 94.24 |  | (12,230) | ​ |  | 94.91 |  | (40,711) | ​ |  | 85.00 |
| Nonvested at September 30, |  | 207,278 | ​ | $ | 114.68 |  | 220,758 | ​ | $ | 102.40 |  | 189,725 | ​ | $ | 94.91 |

[0001104659-25-117276:notes:146]
Compensation Plan for Non-Employee Directors

[0001104659-25-117276:notes:147]
In addition to an annual cash retainer, we provide each non-employee director with an annual equity award having a grant date market value of $180,000, based on the NYSE closing price of the Company’s stock on the date of grant. The award is in the form of Restricted Stock Units, each of which represents the right to receive one share of Company stock at the end of a one-year vesting period. At the end of the vesting period, each award will be converted into the right to receive the same number of actual shares of common stock, plus additional shares representing the value of the quarterly dividends which would have accrued on the underlying shares during the vesting period. Compensation expense related to the non-employee director grants was $1.4 million, $1.1 million and $1.3 million for 2025, 2024 and 2023, respectively.

[0001104659-25-117276:notes:148]
Total Share-Based Compensation

[0001104659-25-117276:notes:149]
The total share-based compensation cost that has been recognized in results of operations and included within SG&A was $10.7 million, $8.6 million and $8.9 million for 2025, 2024 and 2023, respectively. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $2.1 million, $1.9 million and $1.3 million for 2025, 2024 and 2023, respectively. As of September 30, 2025, there was $11.8 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a weighted-average period of 1.4 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001104659-25-117276:notes:150]
10.      Business Segment Information

[0001104659-25-117276:notes:151]
The below disclosure reflects our adoption of ASU 2023-07 Segment Reporting. We are organized based on the products and services we offer, and we classify our business operations in three reportable segments for financial reporting purposes: Aerospace & Defense (A&D), Utility Solutions Group (USG) and RF Test & Measurement (Test). Corporate is not a reportable segment, but it is included for reconciliation purposes.

[0001104659-25-117276:notes:152]
The A&D segment’s operations consist of PTI, Crissair, Globe, Mayday, and Maritime. Previously, A&D also included VACCO Industries which is now being reported in discontinued operations. The companies within this segment primarily design and manufacture specialty filtration, fluid control and naval products, including hydraulic filter elements and fluid control devices used in aerospace and defense applications; custom designed filters for manned aircraft and submarines; products and systems to reduce vibration and/or acoustic signatures and otherwise reduce or obscure a vessel’s signature, power management and control equipment; sealing, surface control and hydrodynamic related applications to enhance U.S. and UK Navy maritime survivability; precision-tolerance machined components for the aerospace and defense industry; metal processing services; and miniature electro-explosive devices utilized in mission-critical defense and aerospace applications.

[0001104659-25-117276:notes:153]
The USG segment’s operations consist of Doble Engineering Company and related subsidiaries including Morgan Schaffer and Altanova/ISA (collectively, Doble), and NRG. Doble is an industry leader in the development, manufacture and delivery of diagnostic testing and data management solutions that enable electric power grid operators to assess the integrity of high-voltage power delivery equipment, and Altanova/ISA’s strong market presence in Europe and Asia provides Doble with a significant international platform. Doble combines three core elements for customers – diagnostic test and condition monitoring instruments, expert consulting, and testing services – and provides access to its large reserve of related empirical knowledge. NRG is a global market leader in the design and manufacture of decision support tools for the renewable energy industry, primarily wind and solar.

[0001104659-25-117276:notes:154]
The Test segment’s operations consist of ETS-Lindgren Inc., including its related subsidiaries, and MPE Limited (collectively, ETS - Lindgren). ETS-Lindgren is an industry leader in designing and manufacturing products and systems to measure and control RF energy. It serves the medical, health and safety, electronics, wireless communications, automotive and defense markets, supplying a broad range of turnkey systems, including RF test facilities and measurement systems, RF and magnetically shielded rooms and secure communication facilities, and providing the design, program management, installation and integration services required to successfully complete these types of facilities. It also supplies a broad range of components including RF absorptive materials, filters, antennas, field probes, test cells, proprietary measurement software and other test accessories required to perform a variety of tests and measurements, and offers a variety of services including calibration and product tests.

[0001104659-25-117276:notes:155]
Accounting policies of the segments are the same as those described in the summary of significant accounting policies in Note 1 to the Consolidated Financial Statements. The operating units within each reporting segment have been aggregated because of similar economic characteristics and meet the other aggregation criteria of FASB ASC 280.

[0001104659-25-117276:notes:156]
Measurement of Segment Results

[0001104659-25-117276:notes:157]
Our CODM, who is our Chief Executive Officer, evaluates each segment’s performance and allocates resources based on segment EBIT, which is defined as earnings before interest and taxes. EBIT on a consolidated basis is a non-GAAP financial measure and is reconciled to consolidated earnings before income taxes below for continuing operations. Intersegment sales and transfers are not significant. Segment assets consist primarily of customer receivables, inventories, capitalized software and fixed assets directly associated with the production processes of the segment. Segment depreciation and amortization is based upon the direct assets listed above. Corporate assets consist primarily of acquired intangible assets including goodwill, deferred taxes and cash balances. The tables below are presented on the basis of continuing operations and exclude discontinued operations.

[0001104659-25-117276:notes:158]
| Year Ended September 30, 2025 |  | ​ | ​ |  | ​ |  | ​ | ​ | Segment | ​ | ​ | ​ | ​ |  | ​ |
| (In thousands) | ​ | A&D | ​ | USG | ​ | Test |  | Total |  | Corporate | ​ | Total |
| Sales | ​ | $ | 478,192 |  | 379,995 |  | 237,201 | ​ | 1,095,388 | ​ | ​ | — | ​ |  | 1,095,388 |
| Cost of sales | ​ |  | 296,688 |  | 176,976 |  | 160,639 | ​ | 634,303 | ​ | ​ | — | ​ |  | 634,303 |
| SG&A expense | ​ |  | 53,050 |  | 99,520 |  | 38,987 | ​ | 191,557 | ​ | ​ | 43,081 | ​ | ​ | 234,638 |
| Amortization of intangible assets | ​ |  | 1,465 |  | 8,563 |  | 1,978 | ​ | 12,006 | ​ | ​ | 41,311 | ​ |  | 53,317 |
| Other expense (income), net | ​ |  | 1,850 |  | 195 |  | 1,486 | ​ | 3,531 | ​ | ​ | (756) | ​ |  | 2,775 |
| Segment profit (loss) | ​ | $ | 125,139 |  | 94,741 |  | 34,111 | ​ | 253,991 | ​ | ​ | (83,636) | ​ |  | 170,355 |
| Interest expense | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | $ | 17,502 | ​ |  | 17,502 |
| Earnings before income taxes | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | $ | 152,853 |
| Depreciation and amortization | ​ | $ | 11,714 |  | 16,119 |  | 5,744 | ​ | 33,577 | ​ | ​ | 41,444 | ​ |  | 75,021 |
| Segment assets | ​ |  | 409,789 | ​ | 289,505 | ​ | 206,944 | ​ | 906,238 | ​ | ​ | 1,504,150 | ​ | ​ | 2,410,388 |
| Capital expenditures | ​ | $ | 18,758 |  | 9,478 |  | 5,048 | ​ | 33,284 | ​ | ​ | 3,038 | ​ |  | 36,322 |

[0001104659-25-117276:notes:159]
| Year Ended September 30, 2024 |  | ​ | ​ |  | ​ |  | ​ |  | Segment | ​ |  | ​ | ​ |  | ​ |
| (In thousands) | ​ | A&D | ​ | USG | ​ | Test | ​ | Total |  | Corporate |  | Total |
| Sales | ​ | $ | 340,543 |  | 369,061 |  | 209,523 | ​ | 919,127 | ​ | ​ | — | ​ |  | 919,127 |
| Cost of sales | ​ |  | 211,112 |  | 176,803 |  | 142,640 | ​ | 530,555 | ​ | ​ | — | ​ | ​ | 530,555 |
| SG&A expense | ​ |  | 42,231 |  | 97,396 |  | 35,351 | ​ | 174,978 | ​ | ​ | 33,225 | ​ |  | 208,203 |
| Amortization of intangible assets | ​ |  | 1,876 |  | 8,414 |  | 1,816 | ​ | 12,106 | ​ | ​ | 20,698 | ​ |  | 32,804 |
| Other expense (income), net | ​ |  | (487) |  | 530 |  | 1,088 | ​ | 1,131 | ​ | ​ | 234 | ​ |  | 1,365 |
| Segment profit (loss) | ​ | $ | 85,811 |  | 85,918 |  | 28,628 | ​ | 200,357 | ​ | ​ | (54,157) | ​ |  | 146,200 |
| Interest expense | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | $ | 15,247 | ​ |  | 15,247 |
| Earnings before income taxes | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | $ | 130,953 |
| Depreciation and amortization | ​ | $ | 10,384 |  | 15,608 |  | 5,349 | ​ | 31,341 | ​ | ​ | 20,814 | ​ |  | 52,155 |
| Segment assets | ​ |  | 267,775 |  | 294,494 |  | 188,663 | ​ | 750,932 | ​ | ​ | 954,313 | ​ |  | 1,705,245 |
| Capital expenditures | ​ | $ | 15,926 |  | 8,751 |  | 3,529 | ​ | 28,206 | ​ | ​ | 69 | ​ |  | 28,275 |

[0001104659-25-117276:notes:160]
| Year Ended September 30, 2023 |  | ​ | ​ |  | ​ |  | ​ |  | Segment | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) | ​ | A&D | ​ | USG | ​ | Test | ​ | total |  | Corporate |  | Total |
| Sales | ​ | $ | 292,203 |  | 342,320 |  | 221,270 | ​ | 855,793 | ​ |  | — | ​ |  | 855,793 |
| Cost of sales | ​ |  | 187,192 |  | 164,094 |  | 151,397 | ​ | 502,683 | ​ |  | — | ​ |  | 502,683 |
| SG&A expense | ​ |  | 39,919 |  | 94,168 |  | 35,211 | ​ | 169,298 | ​ |  | 34,161 | ​ |  | 203,459 |
| Amortization of intangible assets | ​ |  | 1,224 |  | 7,227 |  | 1,864 | ​ | 10,315 | ​ |  | 18,638 | ​ |  | 28,953 |
| Other expense (income), net | ​ |  | 803 |  | 185 |  | 402 | ​ | 1,390 | ​ |  | 171 | ​ |  | 1,561 |
| Segment profit (loss) | ​ | $ | 63,065 |  | 76,646 |  | 32,396 | ​ | 172,107 | ​ | ​ | (52,970) | ​ |  | 119,137 |
| Interest expense | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | $ | 8,769 | ​ |  | 8,769 |
| Earnings before income taxes | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | $ | 110,368 |
| Depreciation and amortization | ​ | $ | 9,770 |  | 13,964 |  | 5,268 | ​ | 29,002 | ​ |  | 18,707 | ​ |  | 47,709 |
| Capital expenditures | ​ | $ | 10,138 |  | 4,856 |  | 4,515 | ​ | 19,509 | ​ |  | 150 | ​ |  | 19,659 |

[0001104659-25-117276:notes:161]
No customer exceeded 10% of consolidated sales in 2025, 2024 or 2023.

[0001104659-25-117276:notes:162]
Geographic Information

[0001104659-25-117276:notes:163]
Net Sales

[0001104659-25-117276:notes:164]
| (Dollars in thousands) | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2025 |  | 2024 |  | 2023 |
| United States | ​ | $ | 727,267 |  | 632,836 |  | 576,639 |
| Asia | ​ |  | 111,844 |  | 108,423 |  | 114,698 |
| Europe | ​ |  | 156,404 |  | 91,762 |  | 80,691 |
| Canada | ​ |  | 56,693 |  | 50,728 |  | 46,822 |
| Other | ​ |  | 43,180 |  | 35,378 |  | 36,943 |
| Consolidated totals | ​ | $ | 1,095,388 |  | 919,127 |  | 855,793 |

[0001104659-25-117276:notes:165]
Long-Lived Assets

[0001104659-25-117276:notes:166]
| (Dollars in thousands) | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2025 |  | 2024 |
| United States | ​ | $ | 142,341 |  | 130,947 |
| United Kingdom | ​ | ​ | 13,659 | ​ | 2,900 |
| Other | ​ |  | 16,493 |  | 15,404 |
| Consolidated totals | ​ | $ | 172,493 |  | 149,251 |

[0001104659-25-117276:notes:167]
We attribute net sales to countries based on the location of the customer. We attribute long-lived assets to countries based on the location of the asset.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001104659-25-117276:notes:168]
11.      Commitments and Contingencies

[0001104659-25-117276:notes:169]
At September 30, 2025, we had $10.1 million in letters of credit outstanding as guarantees of contract performance and cash amounts that exceeded federally insured amounts. As a normal incident of the businesses in which we are engaged, various claims, charges and litigation are asserted or commenced from time to time against us. Additionally, we are currently involved in various stages of investigation and remediation relating to environmental matters. It is the opinion of Management that the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against us are adequately accrued, are covered by insurance or are not likely to have a material adverse effect on our financial results as the estimated exposure to loss is not material.


## ese:OperatingAndFinancingLeasesOfLesseeDisclosureTextBlock

[0001104659-25-117276:notes:170]
12.      Leases

[0001104659-25-117276:notes:171]
We record our leases in accordance with ASC 842, Leases. We determine at lease inception whether an arrangement that provides control over the use of an asset is a lease. We recognize at lease commencement a right-of-use (ROU) asset and lease liability based on the present value of the future lease payments over the lease term (including anticipated renewals). We have elected not to recognize a ROU asset and lease liability for leases with terms of 12 months or less. Certain of our leases include options to extend the term of the lease for up to 20 years. When it is reasonably certain that we will exercise the option, Management includes the impact of the option in the lease term for purposes of determining total future lease payments. As most of our lease agreements do not explicitly state the discount rate implicit in the lease, Management uses our incremental borrowing rate on the commencement date to calculate the present value of future payments based on the tenor of each arrangement.

[0001104659-25-117276:notes:172]
Our leases for real estate commonly include escalating payments. We include these variable lease payments in the calculation of our ROU asset and lease liability. In addition to the present value of the future lease payments, the calculation of the ROU asset also includes any deferred rent, lease pre-payments and initial direct costs of obtaining the lease.

[0001104659-25-117276:notes:173]
In addition to the base rent, real estate leases typically contain provisions for common-area maintenance and other similar services, which are considered non-lease components for accounting purposes. Non-lease components are excluded from our ROU assets and lease liabilities and expensed as incurred.

[0001104659-25-117276:notes:174]
Our leases are for office space, manufacturing facilities, and machinery and equipment.

[0001104659-25-117276:notes:175]
The components of lease costs are shown below:

[0001104659-25-117276:notes:176]
| ​ | ​ | Year Ended |  | Year Ended |
| ​ | ​ | September 30, | ​ | September 30, |
| (Dollars in thousands) |  | 2025 |  | 2024 |
| Finance lease cost: |  | ​ |  | ​ | ​ | ​ |
| Amortization | ​ | $ | 1,489 | ​ | ​ | 1,510 |
| Interest on lease liabilities | ​ |  | 802 | ​ | ​ | 861 |
| Operating lease cost | ​ |  | 7,810 | ​ | ​ | 6,582 |
| Total lease cost | ​ | $ | 10,101 | ​ | ​ | 8,953 |

[0001104659-25-117276:notes:177]
Additional information related to leases is shown below:

[0001104659-25-117276:notes:178]
| ​ |  | Year Ended |  | Year Ended |  |
| ​ | ​ | September 30, | ​ | September 30, | ​ |
| (Dollars in thousands) | ​ | 2025 | ​ | 2024 | ​ |
| Cash paid for amounts included in the measurement of lease liabilities: | ​ | ​ | ​ |  | ​ |  |  |
| Operating cash flows from operating leases | ​ | $ | 7,318 | ​ | ​ | 6,349 |  |
| Operating cash flows from finance leases | ​ | ​ | 802 | ​ | ​ | 861 |  |
| Financing cash flows from finance leases | ​ | ​ | 1,430 | ​ | ​ | 1,351 |  |
| Right-of-use assets obtained in exchange for operating lease liabilities | ​ | $ | 16,426 | ​ | ​ | 3,028 |  |
| Weighted-average remaining lease term: | ​ | ​ | ​ | ​ |  | ​ |  |
| Operating leases | ​ | ​ | 9.3 | yrs |  | 10.5 | yrs |
| Finance leases | ​ | ​ | 9.7 | yrs |  | 10.4 | yrs |
| Weighted-average discount rate: | ​ | ​ | ​ | ​ |  | ​ |  |
| Operating leases | ​ | ​ | 4.8 | % |  | 4.6 | % |
| Finance leases | ​ | ​ | 4.7 | % |  | 4.7 | % |

[0001104659-25-117276:notes:179]
The table below is a reconciliation of future undiscounted cash flows to the operating and finance lease liabilities, and the related ROU assets, presented on our Consolidated Balance Sheet on September 30, 2025:

[0001104659-25-117276:notes:180]
| (Dollars in thousands) | ​ | Operating | ​ | Finance |
| Years Ending September 30: |  | Leases |  | Leases |
| 2026 | ​ | $ | 7,951 | ​ | ​ | 2,297 |
| 2027 | ​ |  | 7,709 | ​ | ​ | 2,357 |
| 2028 | ​ |  | 7,574 | ​ | ​ | 2,417 |
| 2029 | ​ | ​ | 6,134 | ​ | ​ | 2,478 |
| 2030 and thereafter | ​ |  | 33,540 | ​ | ​ | 11,575 |
| Total minimum lease payments | ​ | ​ | 62,908 | ​ | ​ | 21,124 |
| Less: amounts representing interest | ​ |  | 12,611 | ​ | ​ | 4,571 |
| Present value of net minimum lease payments | ​ | $ | 50,297 | ​ | ​ | 16,553 |
| Less: current portion of lease obligations | ​ |  | 5,894 | ​ | ​ | 1,554 |
| Non-current portion of lease obligations | ​ | ​ | 44,403 | ​ | ​ | 14,999 |
| ROU assets | ​ | $ | 47,707 | ​ | ​ | 12,194 |

[0001104659-25-117276:notes:181]
The table below is a reconciliation of future undiscounted cash flows to the operating and finance lease liabilities, and the related ROU assets, presented on our Consolidated Balance Sheet on September 30, 2024:

[0001104659-25-117276:notes:182]
| (Dollars in thousands) |  | Operating |  | Finance |
| Years Ending September 30: | ​ | Leases | ​ | Leases |
| 2025 | ​ | $ | 6,394 |  | 2,233 |
| 2026 | ​ |  | 5,118 |  | 2,297 |
| 2027 | ​ |  | 4,813 |  | 2,357 |
| 2028 | ​ |  | 4,517 |  | 2,417 |
| 2029 and thereafter | ​ |  | 29,765 |  | 14,053 |
| Total minimum lease payments | ​ | ​ | 50,607 |  | 23,357 |
| Less: amounts representing interest | ​ |  | 11,026 |  | 5,373 |
| Present value of net minimum lease payments | ​ | $ | 39,581 |  | 17,984 |
| Less: current portion of lease obligations | ​ |  | 4,771 |  | 1,431 |
| Non-current portion of lease obligations | ​ |  | 34,810 |  | 16,553 |
| ROU assets | ​ | $ | 37,476 | ​ | 13,683 |

[0001104659-25-117276:notes:183]
We include operating and finance lease liabilities in the Consolidated Balance Sheet in accrued other expenses (current portion) and other liabilities (long-term portion). We include operating lease ROU assets as a caption on the Consolidated Balance Sheet and include finance lease ROU assets in Property, plant and equipment on the Consolidated Balance Sheet.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001104659-25-117276:notes:184]
13.     Revenues

[0001104659-25-117276:notes:185]
| (a) | Disaggregation of Revenues |

[0001104659-25-117276:notes:186]
The tables below present our revenues from continuing operations by customer type, geographic location, and revenue recognition method for the years ended September 30, 2025 and 2024, as we believe this presentation best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables also include a reconciliation of the disaggregated revenue within our reportable segments.

[0001104659-25-117276:notes:187]
| Year Ended September 30, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 201,664 | ​ |  | 369,291 | ​ |  | 177,952 | ​ |  | 748,907 |
| Government | ​ | ​ | 276,528 | ​ | ​ | 10,704 | ​ | ​ | 59,249 | ​ | ​ | 346,481 |
| Total revenues | ​ | $ | 478,192 | ​ | ​ | 379,995 | ​ | ​ | 237,201 | ​ | ​ | 1,095,388 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 345,308 | ​ |  | 241,233 | ​ |  | 140,726 | ​ |  | 727,267 |
| International | ​ | ​ | 132,884 | ​ | ​ | 138,762 | ​ | ​ | 96,475 | ​ | ​ | 368,121 |
| Total revenues | ​ | $ | 478,192 | ​ | ​ | 379,995 | ​ | ​ | 237,201 | ​ | ​ | 1,095,388 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 246,923 | ​ |  | 308,754 | ​ |  | 44,784 | ​ |  | 600,461 |
| Over time | ​ | ​ | 231,269 | ​ | ​ | 71,241 | ​ | ​ | 192,417 | ​ | ​ | 494,927 |
| Total revenues | ​ | $ | 478,192 | ​ | ​ | 379,995 | ​ | ​ | 237,201 | ​ | ​ | 1,095,388 |

[0001104659-25-117276:notes:188]
| Year Ended September 30, 2024 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 178,954 | ​ |  | 361,478 | ​ |  | 164,321 | ​ |  | 704,753 |
| Government | ​ |  | 161,589 | ​ | ​ | 7,583 | ​ | ​ | 45,202 | ​ | ​ | 214,374 |
| Total revenues | ​ | $ | 340,543 | ​ | ​ | 369,061 | ​ | ​ | 209,523 | ​ | ​ | 919,127 |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 272,183 | ​ |  | 240,153 | ​ |  | 120,500 | ​ |  | 632,836 |
| International | ​ |  | 68,360 | ​ | ​ | 128,908 | ​ | ​ | 89,023 | ​ | ​ | 286,291 |
| Total revenues | ​ | $ | 340,543 | ​ | ​ | 369,061 | ​ | ​ | 209,523 | ​ | ​ | 919,127 |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 200,693 | ​ |  | 301,200 | ​ |  | 43,150 | ​ |  | 545,043 |
| Over time | ​ |  | 139,850 | ​ | ​ | 67,861 | ​ | ​ | 166,373 | ​ | ​ | 374,084 |
| Total revenues | ​ | $ | 340,543 | ​ | ​ | 369,061 | ​ | ​ | 209,523 | ​ | ​ | 919,127 |

[0001104659-25-117276:notes:189]
| (b) | Remaining Performance Obligations |

[0001104659-25-117276:notes:190]
Our remaining performance obligations, which is the equivalent of our backlog, represent the expected transaction price allocated to our performance obligations that we expect to recognize as revenue in future periods when we perform under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery or Indefinite Quantity contracts. At September 30, 2025, we had $1,133.6 million in remaining performance obligations of which we expect to recognize to revenues approximately 64% in the next twelve months. We expect to recognize to revenues approximately 92% in the next three years.

[0001104659-25-117276:notes:191]
| (c) | Contract assets, contract liabilities and accounts receivable from continuing operations |

[0001104659-25-117276:notes:192]
We report assets and liabilities related to our contracts with customers on a contract-by-contract basis at the end of each reporting period. At September 30, 2025, our contract assets, contract liabilities and accounts receivable totaled $90.7 million, $224.7 million and $253.6 million, respectively. At September 30, 2024, our contract assets, contract liabilities and accounts receivable totaled $66.7 million, $90.3 million and $222.1 million, respectively. At September 30, 2023, our contract assets, contract liabilities and accounts receivable totaled $68.8 million, $83.8 million and $189.3 million, respectively. During 2025, we recognized approximately $60 million in revenues that were included in the contract liabilities balance at September 30, 2024.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001104659-25-117276:notes:193]
14.     Related Parties

[0001104659-25-117276:notes:194]
Two of the Company’s directors are officers at two customers of the Company’s Doble subsidiary. Doble sells products, leases equipment and provides testing services in the ordinary course of Doble’s business. The total amount of these sales was approximately $4.7 million during fiscal 2025. All transactions between Doble and the two customers are intended to be and have been consistent with Doble’s normal commercial terms offered to its customers, and the Company’s Board of Directors has determined that the relationships between the Company and the customers are not material and did not impair either the Company’s or the directors’ independence.
