# ESE 8-K — 0001104659-25-114614 filed 2025-11-20

## item codes, every 8-K on or before 2025-12-01

- 2025-11-20 0001104659-25-114614 — 2.02, 5.02, 7.01, 9.01
- 2025-08-07 0001104659-25-075202 — 2.02, 7.01, 9.01
- 2025-05-07 0001104659-25-045548 — 2.02, 7.01, 9.01
- 2025-04-28 0001104659-25-039819 — 2.01, 7.01, 9.01
- 2025-02-06 0001104659-25-010118 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2024-11-14 0001104659-24-118951 — 2.02, 5.02, 7.01, 9.01
- 2024-10-18 0001104659-24-109788 — 5.02
- 2024-10-01 0001104659-24-104776 — 5.02
- 2024-08-07 0001104659-24-086768 — 1.01, 2.02, 5.02, 7.01, 9.01
- 2024-07-08 0001104659-24-078312 — 1.01, 7.01, 9.01
- 2024-05-09 0001104659-24-059341 — 2.02, 7.01, 9.01
- 2024-02-08 0001104659-24-012294 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2023-11-20 0001104659-23-119761 — 5.02, 9.01
- 2023-11-16 0001104659-23-119126 — 2.02, 7.01, 9.01
- 2023-10-03 0001104659-23-106090 — 5.02, 9.01
- 2023-09-06 0001104659-23-098463 — 1.01, 2.03, 9.01
- 2023-08-08 0001104659-23-088847 — 2.02, 7.01, 9.01
- 2023-07-06 0001104659-23-078571 — 5.02, 8.01, 9.01
- 2023-05-09 0001104659-23-057736 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2023-05-05 0001104659-23-056387 — 5.02, 9.01
- 2023-02-08 0001104659-23-014539 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2023-01-06 0001104659-23-001859 — 5.02, 9.01
- 2022-11-22 0001104659-22-121229 — 5.02, 5.03, 8.01, 9.01
- 2022-11-17 0001104659-22-119898 — 2.02, 7.01, 9.01
- 2022-09-12 0001104659-22-099248 — 5.02, 7.01, 9.01
- 2022-08-08 0001104659-22-087247 — 2.02, 5.02, 7.01, 9.01
- 2022-05-09 0001104659-22-057524 — 2.02, 5.02, 7.01, 9.01
- 2022-02-08 0001104659-22-013878 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2021-12-03 0001104659-21-146361 — 4.01, 9.01 — amendment, the index does not say of what
- 2021-11-24 0001104659-21-143568 — 4.01, 9.01
- 2021-11-23 0001104659-21-142871 — 5.02, 8.01
- 2021-11-18 0001104659-21-141206 — 2.02, 7.01, 9.01
- 2021-08-09 0001104659-21-102150 — 2.02, 7.01, 9.01
- 2021-05-04 0001104659-21-060985 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2021-04-05 0001104659-21-046581 — 5.02, 9.01
- 2021-02-08 0001104659-21-013712 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2020-12-09 0001104659-20-133674 — 5.02, 9.01
- 2020-12-07 0001104659-20-132861 — 5.02, 7.01, 9.01
- 2020-11-19 0001104659-20-127352 — 2.02, 5.02, 7.01, 9.01
- 2020-08-10 0001104659-20-092734 — 2.02, 7.01, 9.01
- 2020-05-06 0001104659-20-057442 — 2.02, 7.01, 8.01, 9.01
- 2020-02-04 0001104659-20-010640 — 2.02, 5.07, 7.01, 9.01
- 2020-01-07 0001104659-20-001789 — 2.01, 9.01
- 2019-11-19 0001104659-19-065437 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2019-11-18 0001104659-19-065096 — 1.01, 2.02, 7.01, 9.01
- 2019-09-30 0001144204-19-046523 — 1.01, 1.02, 2.03, 9.01
- 2019-08-08 0001144204-19-038567 — 2.02, 7.01, 9.01
- 2019-05-07 0001144204-19-024241 — 2.02, 5.02, 7.01, 9.01
- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2025-12-01

- none on or before 2025-12-01

## item 2.02 — earnings release, exhibit 99.1

[0001104659-25-114614:8k_2_02:1]
EX-99.1
2
tm2531749d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-25-114614:8k_2_02:2]
Exhibit 99.1

[0001104659-25-114614:8k_2_02:3]
| NEWS FROM |  |

[0001104659-25-114614:8k_2_02:4]
For more information contact:

[0001104659-25-114614:8k_2_02:5]
Kate Lowrey - VP of
Investor Relations

[0001104659-25-114614:8k_2_02:6]
(314) 213-7277 / klowrey@escotechnologies.com

[0001104659-25-114614:8k_2_02:7]
ESCO REPORTS
FOURTH QUARTER AND FISCAL 2025 RESULTS

[0001104659-25-114614:8k_2_02:8]
- Q4 Sales increase 29% to $353 Million

[0001104659-25-114614:8k_2_02:9]
- Q4 Entered Orders increase 30% to $321
Million

[0001104659-25-114614:8k_2_02:10]
- Q4 GAAP EPS from Continuing Operations
increases 14% to $1.73 -

[0001104659-25-114614:8k_2_02:11]
- Q4 Adjusted EPS from Continuing Operations
increases 30% to $2.32 -

[0001104659-25-114614:8k_2_02:12]
- FY 2025 Sales increase 19% to $1.1 Billion
-

[0001104659-25-114614:8k_2_02:13]
- FY 2025 Entered Orders increase 57% to
$1.6 Billion -

[0001104659-25-114614:8k_2_02:14]
- FY 2025 GAAP EPS from Continuing Operations
increases 13% to $4.49 -

[0001104659-25-114614:8k_2_02:15]
- FY 2025 Adjusted EPS from Continuing Operations
increases 26% to $6.03 -

[0001104659-25-114614:8k_2_02:16]
ST. LOUIS, November 20, 2025 –
ESCO Technologies Inc. (NYSE: ESE) (ESCO, or the Company) today reported its operating results for the fourth quarter and fiscal
year ended September 30, 2025 (Q4 2025 and FY 2025, respectively). During Q4 2025, the Company completed the sale of VACCO Industries.
The VACCO operating results are presented as Discontinued Operations in the attached tables and are excluded from the following discussion
of the Company’s results from Continuing Operations for the comparable periods.

[0001104659-25-114614:8k_2_02:17]
Operating Highlights

[0001104659-25-114614:8k_2_02:18]
|  | · | Q4 2025 Sales increased $79 million (28.9 percent) to $353 million compared to $274 million in Q4 2024. Q4 organic sales increased $21 million (7.7 percent) and the Maritime acquisition contributed $58 million (21.2 percent) of revenue growth in the quarter. |

[0001104659-25-114614:8k_2_02:19]
|  | · | FY 2025 Sales increased $176 million (19.2 percent) to $1.1 billion compared to $919 million in FY 2024. Organic sales increased $81 million (8.8 percent) and the Maritime acquisition added $95 million (10.4 percent) of revenue growth for the full year. |

[0001104659-25-114614:8k_2_02:20]
|  | · | Q4 2025 GAAP EPS from Continuing Operations increased 13.8 percent to $1.73 per share compared to $1.52 per share in Q4 2024. Q4 2025 Adjusted EPS from Continuing Operations increased 29.6 percent to $2.32 per share compared to $1.79 per share in Q4 2024. |

[0001104659-25-114614:8k_2_02:21]
|  | · | FY 2025 GAAP EPS from Continuing Operations increased 13.1 percent to $4.49 per share compared to $3.97 per share in FY 2024. FY 2025 Adjusted EPS from Continuing Operations increased 26.4 percent to $6.03 per share compared to $4.77 per share in FY 2024. |

[0001104659-25-114614:8k_2_02:22]
|  | · | Q4 2025 Entered Orders increased $73 million (29.7 percent) to $321 million (book-to-bill of 0.91x). |

[0001104659-25-114614:8k_2_02:23]
|  | · | FY 2025 Entered Orders increased $565 million (56.5 percent) to $1.6 billion (book-to-bill of 1.43x), resulting in record year-end backlog of $1.1 billion. Excluding $364 million of acquired backlog at Maritime, FY 2025 orders increased $201 million (20.1 percent) over the prior year. |

[0001104659-25-114614:8k_2_02:24]
|  | · | Net Cash provided by Operating Activities from Continuing Operations was $112 million in Q4 2025 and $200 million for FY 2025 (an increase of $79 million compared to FY 2024). |

[0001104659-25-114614:8k_2_02:25]
Bryan Sayler, Chief Executive Officer and President, commented, “We
finished the year strong with another great quarter highlighted by 29 percent sales growth, 100 basis points of Adjusted EBIT margin improvement,
and a 30 percent increase in Adjusted EPS from Continuing Operations.

[0001104659-25-114614:8k_2_02:26]
“For the year, strong end-market demand, disciplined execution,
and the acquisition of Maritime drove record sales, orders, backlog and Adjusted EPS. These results underscore the strength of our strategic
positioning and our ability to create sustainable value in attractive markets.

[0001104659-25-114614:8k_2_02:27]
“It was a truly historic year for ESCO as we continued to build
on our solid foundation, delivering value across the enterprise while enhancing our portfolio by completing two consequential transactions.
These accomplishments were the result of a lot of hard work and I would like to extend my appreciation to our entire team for their energy,
focus, and dedication. Our collective efforts helped drive significant improvement in operating performance while taking a meaningful
step forward in the evolution of the company.”

[0001104659-25-114614:8k_2_02:28]
Segment Performance

[0001104659-25-114614:8k_2_02:29]
Aerospace & Defense (A&D)

[0001104659-25-114614:8k_2_02:30]
|  | · | Q4 2025 sales increased $71 million (71.6 percent) to $170 million from $99 million in Q4 2024. Organic sales increased $13 million (13.1 percent) and Maritime added $58 million (58.5 percent) of revenue growth in the quarter. FY 2025 sales increased $137 million (40.4 percent) to $478 million from $341 million in FY 2024. Organic sales increased $42 million (12.5 percent) and Maritime added $95 million (27.9 percent) of revenue growth for the year. Sales growth in both the quarter and the year was driven by strength in Navy and commercial aerospace. |

[0001104659-25-114614:8k_2_02:31]
|  | · | Q4 2025 EBIT increased $17.0 million to $46.9 million from $29.9 million in Q4 2024. Adjusted EBIT increased $18.8 million in Q4 2025 to $48.7 million (28.6 percent margin) from $29.9 million (30.1 percent margin) in Q4 2024. The 63 percent increase in Adjusted EBIT was driven by the Maritime acquisition as well as leverage on higher volume, price increases, and mix. FY 2025 EBIT increased $39.3 million to $125.1 million from $85.8 million in FY 2024. FY 2025 Adjusted EBIT increased $43.7 million to $129.7 million (27.1 percent margin) from $86.0 million (25.2 percent margin) in FY 2024. Leverage on higher volume, price increases, mix, and the impact of Maritime more than offset inflationary pressures for the year. |

[0001104659-25-114614:8k_2_02:32]
|  | · | Q4 2025 entered orders increased $53 million (60.1 percent) to $141.9 million (book-to-bill of 0.83). Q4 orders growth was driven by strong commercial and defense aerospace orders at PTI and $43 million of Maritime orders. FY 2025 entered orders increased $465 million (108 percent) to $896 million (book-to-bill of 1.87) resulting in record year-end backlog of $803 million. FY 2025 included $364 million of acquired backlog at Maritime. Without this impact, A&D orders increased $101 million (23 percent) primarily driven by higher Navy orders at Globe and the addition of Maritime. |

[0001104659-25-114614:8k_2_02:33]
Utility Solutions Group (USG)

[0001104659-25-114614:8k_2_02:34]
|  | · | Q4 2025 sales increased $2 million (1.6 percent) to $110 million from $108 million in Q4 2024. Doble sales increased by $6 million (6.8 percent) and NRG sales decreased by $4 million (19.7 percent). FY 2025 sales increased $11 million (3.0 percent) to $380 million from $369 million in FY 2024. Doble sales increased $18 million (6.0 percent) and NRG sales decreased $7 million (9.6 percent) for the year. Sales growth in both the quarter and the year was driven by higher offline test equipment, protection testing, and services, partially offset by lower condition monitoring sales at Doble and lower renewables revenue at NRG. |

[0001104659-25-114614:8k_2_02:35]
|  | · | Q4 2025 EBIT increased $3.3 million to $31.9 million from $28.6 million in Q4 2024. Adjusted EBIT increased $3.4 million in Q4 2025 to $32.0 million (29.1 percent margin) from $28.6 million (26.4 percent margin) in Q4 2024. FY 2025 EBIT increased $8.8 million to $94.7 million from $85.9 million in FY 2024. FY 2025 Adjusted EBIT increased $9.1 million to $95.2 million (25.0 percent margin) from $86.1 million (23.3 percent margin) in FY 2024. Adjusted EBIT increases for the quarter and year were largely driven by price increases and mix, partially offset by inflationary pressures. |

[0001104659-25-114614:8k_2_02:36]
|  | · | Q4 2025 entered orders increased $17 million (16.8 percent) to $116 million (book-to-bill of 1.05). Record quarterly orders at Doble increased $21 million (25.7 percent) to $101 million and NRG orders decreased $4 million (21.2 percent) to $15 million compared to Q4 2024. FY 2025 entered orders increased $48 million (13.5 percent) to $404 million (book-to-bill of 1.06) resulting in year-end backlog of $143 million. For the year, Doble orders increased $47 million (16.2 percent) related to increased electric utility spending to maintain and expand the grid. NRG orders increased $1 million (1.4 percent) as renewables project developers focused on completing current projects as tax credits sunset under new U.S. tax legislation approved during the year. |

[0001104659-25-114614:8k_2_02:37]
RF Test & Measurement (Test)

[0001104659-25-114614:8k_2_02:38]
|  | · | Q4 2025 sales increased $6 million (9.6 percent) to $72 million from $66 million in Q4 2024. FY 2025 sales increased $27 million (13.2 percent) to $237 million from $210 million in FY 2024. Sales growth in both the quarter and the year was largely driven by higher Test & Measurement (EMC) and industrial shielding sales, partially offset by lower wireless sales. |

[0001104659-25-114614:8k_2_02:39]
|  | · | Q4 2025 EBIT and Adjusted EBIT both increased $0.6 million to $12.6 million (17.5 percent margin) from $12.0 million (18.3 percent margin) in Q4 2024. The Adjusted EBIT margin was lower than the record margin of 18.3 percent in Q4 2024 as leverage on higher volume and price increases were offset by inflationary pressures. FY 2025 EBIT increased $5.5 million to $34.1 million from $28.6 million in FY 2024. FY 2025 Adjusted EBIT also increased $5.5 million to $34.6 million (14.6 percent margin) from $29.1 million (13.9 percent margin) in FY 2024. Leverage on higher volume and price increases in FY 2025 were partially offset by inflationary pressures and unfavorable mix. |

[0001104659-25-114614:8k_2_02:40]
|  | · | Q4 2025 entered orders increased $3.4 million (5.8 percent) to $63 million. Higher Test orders were highlighted by a $5.5 million defense project booked in the quarter. FY 2025 entered orders increased $53 million (24.6 percent) to a record $266 million (book-to-bill of 1.12) resulting in year-end backlog of $187 million. With the exception of the wireless market, Test experienced a broad rebound in orders across other served markets in FY 2025. |

[0001104659-25-114614:8k_2_02:41]
Discontinued Operations - VACCO Industries Divestiture

[0001104659-25-114614:8k_2_02:42]
As previously announced, the Company closed the divestiture of VACCO
Industries on July 18, 2025. During the fourth quarter, the Company recognized an after-tax gain of $173 million related to the sale
and $1.1 million in earnings related to discontinued operations. An accrued tax expense of $59 million was recorded in the quarter, with
the anticipation of making the tax payment related to the gain on the sale in the first half of FY 2026.

[0001104659-25-114614:8k_2_02:43]
Business Outlook
– FY 2026

[0001104659-25-114614:8k_2_02:44]
Management expects double-digit sales, Adjusted EBIT, Adjusted EBITDA,
and Adjusted EPS growth in FY 2026.

[0001104659-25-114614:8k_2_02:45]
Expectations for growth in FY 2026 compared to FY 2025:

[0001104659-25-114614:8k_2_02:46]
|  | · | Net sales are expected to grow 16 to 20 percent to a range of $1.27 to $1.31 billion on a consolidated basis, with A&D growing 33 to 38 percent (6 to 8 percent organic growth plus Maritime revenue of $230 to $245 million), USG growing 4 to 6 percent, and Test growing 3 to 5 percent. |

[0001104659-25-114614:8k_2_02:47]
|  | · | Adjusted EBIT is expected to increase approximately 21 to 25 percent with Adjusted EBIT margins increasing to 20.9 to 21.5 percent of sales. |

[0001104659-25-114614:8k_2_02:48]
|  | · | Adjusted EBITDA is expected to increase approximately 20 to 24 percent with Adjusted EBITDA margins increasing to 23.8 to 24.6 percent of sales. |

[0001104659-25-114614:8k_2_02:49]
|  | · | The effective income tax rate is expected to be in the range of 23.7 to 24.1 percent in 2026. |

[0001104659-25-114614:8k_2_02:50]
|  | · | FY 2026 Adjusted EPS is expected to increase 24 to 29 percent to a range of $7.50 to $7.80 per share. |

[0001104659-25-114614:8k_2_02:51]
|  | · | Q1 2026 Adjusted EPS is expected to increase 32 to 42 percent compared to the prior year first quarter and be in the range of $1.25 - $1.35 per share. |

[0001104659-25-114614:8k_2_02:52]
|  | · | Consistent with prior years, revenues and Adjusted EPS are expected to grow sequentially throughout the year. |

[0001104659-25-114614:8k_2_02:53]
Dividend Payment

[0001104659-25-114614:8k_2_02:54]
The next quarterly cash dividend of $0.08
per share will be paid on January 16, 2026 to stockholders of record on January 2, 2026.

[0001104659-25-114614:8k_2_02:55]
2026 Annual Meeting

[0001104659-25-114614:8k_2_02:56]
The 2026 Annual Meeting of the Company’s shareholders will be
held on January 30, 2026.

[0001104659-25-114614:8k_2_02:57]
Conference Call

[0001104659-25-114614:8k_2_02:58]
The Company will host a conference call
today, November 20, at 4:00 p.m. Central Time, to discuss the Company’s Q4 2025 results. A live audio webcast and an
accompanying slide presentation will be available in the Investor Center of ESCO’s website. Participants may also
access the webcast using this registration link. For those unable to participate, a webcast replay will be available after the
call in the Investor Center of ESCO’s website.

[0001104659-25-114614:8k_2_02:59]
Forward-Looking Statements

[0001104659-25-114614:8k_2_02:60]
Investors are cautioned that such statements
are only predictions and speak only as of the date of this release, and the Company undertakes no duty to update them except as may be
required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected
in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment
including but not limited to those described in Item 1A, “Risk Factors”, of the Company’s Annual Report on Form 10-K
for the fiscal year ended September 30, 2024 and the following: the impacts of climate change and related regulation of greenhouse
gases; the impacts of labor disputes, civil disorder, wars, elections, political changes, tariffs and trade disputes, terrorist activities,
cyberattacks or natural disasters on the Company’s operations and those of the Company’s customers and suppliers; disruptions
in manufacturing or delivery arrangements due to shortages or unavailability of materials or components or supply chain disruptions; inability
to access work sites; the timing and content of future contract awards or customer orders; the timely appropriation, allocation and availability
of Government funds; the termination for convenience of Government and other customer contracts or orders; weakening of economic conditions
in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies; competition;
intellectual property rights; technical difficulties or data breaches; the availability of acquisitions; delivery delays or defaults by
customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability of certain
raw materials; material changes in the cost of credit; changes in laws and regulations including but not limited to changes in accounting
standards and taxation; changes in interest, inflation and employment rates; costs relating to environmental matters arising from current
or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the integration
and performance of acquired businesses.

[0001104659-25-114614:8k_2_02:61]
Non-GAAP Financial Measures

[0001104659-25-114614:8k_2_02:62]
The financial measures EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA,
and Adjusted EPS are presented in this press release. The Company defines “EBIT” as earnings before interest and taxes, “EBITDA”
as earnings before interest, taxes, depreciation and amortization, “Adjusted EBIT” and “Adjusted EBITDA” as excluding
the net impact of the items described in the attached Reconciliation of Non-GAAP Financial Measures, and “Adjusted EPS” as
GAAP earnings per share excluding the net impact of the items described and reconciled in the attached Reconciliation of Non-GAAP Financial
Measures.

[0001104659-25-114614:8k_2_02:63]
EBIT, Adjusted EBIT, EBITDA, Adjusted
EBITDA, and Adjusted EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management
believes EBIT, Adjusted EBIT, EBITDA, and Adjusted EBITDA are useful in assessing the operational profitability of the Company’s
business segments because they exclude interest, taxes, depreciation, and amortization, which are generally accounted for across the entire
Company on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company
as well as incentive compensation. The presentation of EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA, and Adjusted EPS provides important
supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures
to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance
determined in accordance with GAAP.

[0001104659-25-114614:8k_2_02:64]
About ESCO

[0001104659-25-114614:8k_2_02:65]
ESCO Technologies is a global provider
of highly engineered products and solutions serving diverse end-markets. It manufactures filtration and fluid control products, advanced
composites, as well as signature and power management solutions for aviation, Navy, and industrial customers. ESCO is an industry leader
in designing and manufacturing RF test and measurement products and systems; and provides diagnostic instruments, software and services
to industrial power users and the electric utility and renewable energy industries. Headquartered in St. Louis, Missouri, ESCO and its
subsidiaries have offices and manufacturing facilities worldwide. For more information on ESCO and its subsidiaries, visit ESCO’s
website at www.escotechnologies.com.

[0001104659-25-114614:8k_2_02:66]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-25-114614:8k_2_02:67]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-25-114614:8k_2_02:68]
(Dollars in thousands, except per share amounts)

[0001104659-25-114614:8k_2_02:69]
|  |  | Three Months Ended September 30, 2025 |  |  | Three Months Ended September 30, 2024 |  |
| Net Sales |  | $ | 352,674 |  |  |  | 273,506 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 203,235 |  |  |  | 152,129 |  |
| Selling, general and administrative expenses |  |  | 63,333 |  |  |  | 55,596 |  |
| Amortization of intangible assets |  |  | 20,582 |  |  |  | 8,219 |  |
| Interest expense |  |  | 5,129 |  |  |  | 6,019 |  |
| Other (income) expenses, net |  |  | 828 |  |  |  | 960 |  |
| Total costs and expenses |  |  | 293,107 |  |  |  | 222,923 |  |
| Earnings before income taxes |  |  | 59,567 |  |  |  | 50,583 |  |
| Income tax expense |  |  | 14,713 |  |  |  | 11,285 |  |
| Net earnings from continuing operations |  |  | 44,854 |  |  |  | 39,298 |  |
| Earnings (loss) from discontinued operations, net of tax expense (benefit) of $458 and $(1,506) |  |  | 1,156 |  |  |  | (5,035 | ) |
| Gain on sale of discontinued operations, net of tax expense of $54,000 |  |  | 172,642 |  |  |  | - |  |
| Net earnings from discontinued operations |  |  | 173,798 |  |  |  | (5,035 | ) |
| Net earnings |  | $ | 218,652 |  |  |  | 34,263 |  |
| Diluted - GAAP |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 1.73 |  |  |  | 1.52 |  |
| Discontinued operations |  |  | 6.70 |  |  |  | (0.19 | ) |
| Net earnings |  | $ | 8.43 |  |  |  | 1.33 |  |
| Diluted - As Adjusted Basis |  |  |  |  |  |  |  |  |
| Continuing Operations |  | $ | 2.32 | (1) |  |  | 1.79 | (2) |
| Diluted average common shares O/S: |  |  | 25,928 |  |  |  | 25,854 |  |

[0001104659-25-114614:8k_2_02:70]
| (1) | Q4 2025 Adjusted EPS from continuing operations excludes $0.59 per share of after-tax charges consisting of: $0.05 of Maritime inventory step-up charges, $0.01 of restructuring charges (primarily severance) within the USG segment, and $0.53 of acquisition related amortization. |
| (2) | Q4 2024 Adjusted EPS from continuing operations excludes $0.27 per share of after-tax charges consisting of: $0.09 of debt financing and $0.03 of acquisition costs at Corporate, and $0.15 of acquisition related amortization. |

[0001104659-25-114614:8k_2_02:71]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-25-114614:8k_2_02:72]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-25-114614:8k_2_02:73]
(Dollars in thousands, except per share amounts)

[0001104659-25-114614:8k_2_02:74]
|  |  | Year Ended September 30, 2025 |  |  | Year Ended September 30, 2024 |  |
| Net Sales |  | $ | 1,095,388 |  |  |  | 919,127 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 634,303 |  |  |  | 530,555 |  |
| Selling, general and administrative expenses |  |  | 234,638 |  |  |  | 208,203 |  |
| Amortization of intangible assets |  |  | 53,317 |  |  |  | 32,804 |  |
| Interest expense |  |  | 17,502 |  |  |  | 15,247 |  |
| Other expenses (income), net |  |  | 2,775 |  |  |  | 1,365 |  |
| Total costs and expenses |  |  | 942,535 |  |  |  | 788,174 |  |
| Earnings before income taxes |  |  | 152,853 |  |  |  | 130,953 |  |
| Income tax expense |  |  | 36,554 |  |  |  | 28,325 |  |
| Net earnings from continuing operations |  |  | 116,299 |  |  |  | 102,628 |  |
| Earnings (loss) from discontinued operations, net of tax expense (benefit) of $3,464 and $(317) |  |  | 10,282 |  |  |  | (747 | ) |
| Gain on sale of discontinued operations, net of tax expense of $54,000 |  |  | 172,642 |  |  |  | - |  |
| Net earnings (loss) from discontinued operations |  |  | 182,924 |  |  |  | (747 | ) |
| Net earnings |  | $ | 299,223 |  |  |  | 101,881 |  |
| Diluted - GAAP |  |  |  |  |  |  |  |  |
| Continuing operations |  |  | 4.49 |  |  |  | 3.97 |  |
| Discontinued operations |  |  | 7.06 |  |  |  | (0.03 | ) |
| Net earnings |  | $ | 11.55 |  |  |  | 3.94 |  |
| Diluted - As Adjusted Basis |  |  |  |  |  |  |  |  |
| Continuing Operations |  | $ | 6.03 | (1) |  |  | 4.77 | (2) |
| Diluted average common shares O/S: |  |  | 25,910 |  |  |  | 25,872 |  |

[0001104659-25-114614:8k_2_02:75]
| (1) | FY 2025 Adjusted EPS from continuing operations excludes $1.54 per share of after-tax charges consisting of: $0.15 of Corporate acquisition costs, $0.14 of Maritime inventory step-up charges and stamp duties, $0.02 of restructuring charges within the Test and USG segments, and $1.23 of acquisition related amortization. |

[0001104659-25-114614:8k_2_02:76]
| (2) | FY 2024 Adjusted EPS from continuing operations excludes $0.80 per share of after-tax charges consisting of: $0.09 of debt financing and $0.06 of acquisition costs at Corporate, $0.04 of MPE acquisition backlog and inventory step-up charges, $0.02 of restructuring charges (primarily severance) within the A&D, Test, and USG segments, and $0.59 of acquisition related amortization. |

[0001104659-25-114614:8k_2_02:77]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-25-114614:8k_2_02:78]
Condensed Business Segment Information (Unaudited) - Continuing Operations basis

[0001104659-25-114614:8k_2_02:79]
(Dollars in thousands)

[0001104659-25-114614:8k_2_02:80]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | Q4 2025 |  |  | Q4 2024 |  |  | Q4 2025 |  |  | Q4 2024 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 170,373 |  |  |  | 99,264 |  |  |  | 170,373 |  |  |  | 99,264 |  |
| USG |  |  | 110,211 |  |  |  | 108,491 |  |  |  | 110,211 |  |  |  | 108,491 |  |
| Test |  |  | 72,090 |  |  |  | 65,751 |  |  |  | 72,090 |  |  |  | 65,751 |  |
| Totals |  | $ | 352,674 |  |  |  | 273,506 |  |  |  | 352,674 |  |  |  | 273,506 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 46,893 |  |  |  | 29,892 |  |  |  | 48,660 |  |  |  | 29,922 |  |
| USG |  |  | 31,933 |  |  |  | 28,563 |  |  |  | 32,019 |  |  |  | 28,593 |  |
| Test |  |  | 12,588 |  |  |  | 12,015 |  |  |  | 12,588 |  |  |  | 12,015 |  |
| Corporate |  |  | (26,718 | ) |  |  | (13,868 | ) |  |  | (8,852 | ) |  |  | (7,912 | ) |
| Consolidated EBIT |  |  | 64,696 |  |  |  | 56,602 |  |  |  | 84,415 |  |  |  | 62,618 |  |
| Less: Interest expense |  |  | (5,129 | ) |  |  | (6,019 | ) |  |  | (5,129 | ) |  |  | (2,969 | ) |
| Less: Income tax expense |  |  | (14,713 | ) |  |  | (11,285 | ) |  |  | (19,248 | ) |  |  | (13,370 | ) |
| Net earnings |  | $ | 44,854 |  |  |  | 39,298 |  |  |  | 60,038 |  |  |  | 46,279 |  |

[0001104659-25-114614:8k_2_02:81]
Note 1: Adjusted net earnings of $60.0 million in Q4 2025 exclude $15.2 million (or $0.59 per share) of after-tax charges consisting of: $0.05 of Maritime inventory step-up charges, $0.01 of restructuring charges (primarily severance) within the USG segment, and $0.53 of acquisition related amortization.

[0001104659-25-114614:8k_2_02:82]
Note 2: Adjusted net earnings of $46.3 million in Q4 2024 exclude $7.0 million (or $0.27 per share) of after-tax charges consisting of: $0.09 of debt financing and $0.03 of acquisition costs at Corporate, and $0.15 of acquisition related amortization.

[0001104659-25-114614:8k_2_02:83]
EBITDA Reconciliation to Net earnings:

[0001104659-25-114614:8k_2_02:84]
|  |  |  |  |  |  |  |  | Q4 2025 - |  |  | Q4 2024 - |  |
|  |  | Q4 2025 |  |  | Q4 2024 |  |  | As Adj |  |  | As Adj |  |
| Consolidated EBITDA |  | $ | 91,316 |  |  |  | 69,785 |  |  |  | 93,328 |  |  |  | 70,758 |  |
| Less: Depr & Amort |  |  | (26,620 | ) |  |  | (13,183 | ) |  |  | (8,913 | ) |  |  | (8,140 | ) |
| Consolidated EBIT |  |  | 64,696 |  |  |  | 56,602 |  |  |  | 84,415 |  |  |  | 62,618 |  |
| Less: Interest expense |  |  | (5,129 | ) |  |  | (6,019 | ) |  |  | (5,129 | ) |  |  | (2,969 | ) |
| Less: Income tax expense |  |  | (14,713 | ) |  |  | (11,285 | ) |  |  | (19,248 | ) |  |  | (13,370 | ) |
| Net earnings |  | $ | 44,854 |  |  |  | 39,298 |  |  |  | 60,038 |  |  |  | 46,279 |  |

[0001104659-25-114614:8k_2_02:85]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-25-114614:8k_2_02:86]
Condensed Business Segment Information (Unaudited) - Continuing Operations basis

[0001104659-25-114614:8k_2_02:87]
(Dollars in thousands)

[0001104659-25-114614:8k_2_02:88]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | FY 25 |  |  | FY 24 |  |  | FY 25 |  |  | FY 24 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 478,192 |  |  |  | 340,543 |  |  |  | 478,192 |  |  |  | 340,543 |  |
| USG |  |  | 379,995 |  |  |  | 369,061 |  |  |  | 379,995 |  |  |  | 369,061 |  |
| Test |  |  | 237,201 |  |  |  | 209,523 |  |  |  | 237,201 |  |  |  | 209,523 |  |
| Totals |  | $ | 1,095,388 |  |  |  | 919,127 |  |  |  | 1,095,388 |  |  |  | 919,127 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 125,139 |  |  |  | 85,811 |  |  |  | 129,676 |  |  |  | 85,983 |  |
| USG |  |  | 94,741 |  |  |  | 85,918 |  |  |  | 95,159 |  |  |  | 86,143 |  |
| Test |  |  | 34,111 |  |  |  | 28,628 |  |  |  | 34,576 |  |  |  | 29,109 |  |
| Corporate |  |  | (83,636 | ) |  |  | (54,157 | ) |  |  | (36,994 | ) |  |  | (31,338 | ) |
| Consolidated EBIT |  |  | 170,355 |  |  |  | 146,200 |  |  |  | 222,417 |  |  |  | 169,897 |  |
| Less: Interest expense |  |  | (17,502 | ) |  |  | (15,247 | ) |  |  | (17,502 | ) |  |  | (12,197 | ) |
| Less: Income tax |  |  | (36,554 | ) |  |  | (28,325 | ) |  |  | (48,527 | ) |  |  | (34,476 | ) |
| Net earnings |  | $ | 116,299 |  |  |  | 102,628 |  |  |  | 156,388 |  |  |  | 123,224 |  |

[0001104659-25-114614:8k_2_02:89]
Note 1: Adjusted net earnings of $156.4 million in FY 2025 exclude $40.1 million (or $1.54 per share) of after-tax charges consisting of: $0.15 of Corporate acquisition costs, $0.14 of Maritime inventory step-up charges and stamp duties, $0.02 of restructuring charges within the Test and USG segments, and $1.23 of acquisition related amortization.

[0001104659-25-114614:8k_2_02:90]
Note 2: Adjusted net earnings of $123.2 million in FY 2024 exclude $20.6 million (or $0.80 per share) of after-tax charges consisting of: $0.09 of debt financing and $0.06 of acquisition costs at Corporate, $0.04 of MPE acquisition backlog and inventory step-up charges, $0.02 of restructuring charges (primarily severance) in the A&D, Test, and USG segments, and $0.59 of acquisition related amortization.

[0001104659-25-114614:8k_2_02:91]
EBITDA Reconciliation to Net earnings:

[0001104659-25-114614:8k_2_02:92]
|  |  |  |  |  |  |  |  | FY 2025 - |  |  | FY 2024 - |  |
|  |  | FY 25 |  |  | FY 24 |  |  | As Adj |  |  | As Adj |  |
| Consolidated EBITDA |  | $ | 245,376 |  |  |  | 198,355 |  |  |  | 256,303 |  |  |  | 201,476 |  |
| Less: Depr & Amort |  |  | (75,021 | ) |  |  | (52,155 | ) |  |  | (33,886 | ) |  |  | (31,579 | ) |
| Consolidated EBIT |  |  | 170,355 |  |  |  | 146,200 |  |  |  | 222,417 |  |  |  | 169,897 |  |
| Less: Interest expense |  |  | (17,502 | ) |  |  | (15,247 | ) |  |  | (17,502 | ) |  |  | (12,197 | ) |
| Less: Income tax expense |  |  | (36,554 | ) |  |  | (28,325 | ) |  |  | (48,527 | ) |  |  | (34,476 | ) |
| Net earnings |  | $ | 116,299 |  |  |  | 102,628 |  |  |  | 156,388 |  |  |  | 123,224 |  |

[0001104659-25-114614:8k_2_02:93]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-25-114614:8k_2_02:94]
Condensed Consolidated Balance Sheets (Unaudited)

[0001104659-25-114614:8k_2_02:95]
(Dollars in thousands)

[0001104659-25-114614:8k_2_02:96]
|  |  | September 30, 2025 |  |  | September 30, 2024 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 101,350 |  |  |  | 65,963 |  |
| Accounts receivable, net |  |  | 253,554 |  |  |  | 222,101 |  |
| Contract assets |  |  | 90,730 |  |  |  | 66,712 |  |
| Inventories |  |  | 217,807 |  |  |  | 195,465 |  |
| Other current assets |  |  | 25,065 |  |  |  | 21,027 |  |
| Assets from discontinued operations - current |  |  | - |  |  |  | 97,381 |  |
| Total current assets |  |  | 688,506 |  |  |  | 668,649 |  |
| Property, plant and equipment, net |  |  | 172,493 |  |  |  | 149,251 |  |
| Intangible assets, net |  |  | 723,973 |  |  |  | 403,524 |  |
| Goodwill |  |  | 761,931 |  |  |  | 529,935 |  |
| Operating lease assets |  |  | 47,707 |  |  |  | 37,476 |  |
| Other assets |  |  | 15,778 |  |  |  | 13,791 |  |
| Assets from discontinued operations - other |  |  | - |  |  |  | 35,994 |  |
|  |  | $ | 2,410,388 |  |  |  | 1,838,620 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt |  | $ | 20,000 |  |  |  | 20,000 |  |
| Accounts payable |  |  | 96,534 |  |  |  | 88,936 |  |
| Contract liabilities |  |  | 216,590 |  |  |  | 80,844 |  |
| Current income tax payable |  |  | 62,007 |  |  |  | 6,251 |  |
| Other current liabilities |  |  | 113,017 |  |  |  | 91,324 |  |
| Liabilities from discontinued operations - current |  |  | - |  |  |  | 62,499 |  |
| Total current liabilities |  |  | 508,148 |  |  |  | 349,854 |  |
| Deferred tax liabilities |  |  | 112,390 |  |  |  | 72,623 |  |
| Non-current operating lease liabilities |  |  | 44,403 |  |  |  | 34,810 |  |
| Other liabilities |  |  | 38,576 |  |  |  | 39,273 |  |
| Long-term debt |  |  | 166,000 |  |  |  | 102,000 |  |
| Liabilities from discontinued operations - other |  |  | - |  |  |  | 2,710 |  |
| Shareholders' equity |  |  | 1,540,871 |  |  |  | 1,237,350 |  |
|  |  | $ | 2,410,388 |  |  |  | 1,838,620 |  |

[0001104659-25-114614:8k_2_02:97]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-25-114614:8k_2_02:98]
Consolidated Statements of Cash Flows (Unaudited)

[0001104659-25-114614:8k_2_02:99]
(Dollars in thousands)

[0001104659-25-114614:8k_2_02:100]
|  |  | Year Ended September 30, 2025 |  |  | Year Ended September 30, 2024 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 299,223 |  |  |  | 101,881 |  |
| (Earnings) loss from discontinued operations |  |  | (182,924 | ) |  |  | 747 |  |
| Adjustments to reconcile net earnings to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 75,021 |  |  |  | 52,155 |  |
| Stock compensation expense |  |  | 10,671 |  |  |  | 8,599 |  |
| Changes in assets and liabilities |  |  | 9,381 |  |  |  | (33,406 | ) |
| Effect of deferred taxes |  |  | (10,976 | ) |  |  | (8,394 | ) |
| Net cash provided by operating activities - continuing operations |  |  | 200,396 |  |  |  | 121,582 |  |
| Net cash provided by operating activities - discontinued operations |  |  | 41,543 |  |  |  | 5,960 |  |
| Net cash provided by operating activities |  |  | 241,939 |  |  |  | 127,542 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Acquisition of business, net of cash acquired |  |  | (472,006 | ) |  |  | (56,383 | ) |
| Capital expenditures |  |  | (36,322 | ) |  |  | (28,275 | ) |
| Additions to capitalized software and other |  |  | (15,844 | ) |  |  | (11,903 | ) |
| Net cash used by investing activities - continuing operations |  |  | (524,172 | ) |  |  | (96,561 | ) |
| Net cash provided (used) by investing activities - discontinued operations |  |  | 268,383 |  |  |  | (8,078 | ) |
| Net cash used by investing activities |  |  | (255,789 | ) |  |  | (104,639 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from long-term debt |  |  | 661,000 |  |  |  | 217,000 |  |
| Principal payments on long-term debt and short-term borrowings |  |  | (597,000 | ) |  |  | (197,000 | ) |
| Dividends paid |  |  | (8,262 | ) |  |  | (8,246 | ) |
| Purchases of common stock into treasury |  |  | - |  |  |  | (7,998 | ) |
| Debt issuance costs |  |  | - |  |  |  | (2,988 | ) |
| Other |  |  | (6,197 | ) |  |  | (1,541 | ) |
| Net cash provided by financing activities - continuing operations |  |  | 49,541 |  |  |  | (773 | ) |
| Net cash used by financing activities - discontinued operations |  |  | - |  |  |  | - |  |
| Net cash provided by financing activities |  |  | 49,541 |  |  |  | (773 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (304 | ) |  |  | 1,967 |  |
| Net increase in cash and cash equivalents |  |  | 35,387 |  |  |  | 24,097 |  |
| Cash and cash equivalents, beginning of period |  |  | 65,963 |  |  |  | 41,866 |  |
| Cash and cash equivalents, end of period |  | $ | 101,350 |  |  |  | 65,963 |  |

[0001104659-25-114614:8k_2_02:101]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-25-114614:8k_2_02:102]
Other Selected Financial Data (Unaudited) - Continuing Operations Basis

[0001104659-25-114614:8k_2_02:103]
(Dollars in thousands)

[0001104659-25-114614:8k_2_02:104]
| Backlog And Entered Orders - Q4 2025 |  | A&D |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 7/1/25 |  | $ | 831,521 |  |  |  | 137,441 |  |  |  | 196,460 |  |  |  | 1,165,422 |  |
| Entered Orders |  |  | 141,854 |  |  |  | 116,230 |  |  |  | 62,805 |  |  |  | 320,889 |  |
| Sales |  |  | (170,373 | ) |  |  | (110,211 | ) |  |  | (72,090 | ) |  |  | (352,674 | ) |
| Ending Backlog - 9/30/25 |  | $ | 803,002 |  |  |  | 143,460 |  |  |  | 187,175 |  |  |  | 1,133,637 |  |

[0001104659-25-114614:8k_2_02:105]
| Backlog And Entered Orders - FY 2025 |  | A&D |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 10/1/24 |  | $ | 385,601 |  |  |  | 119,943 |  |  |  | 158,644 |  |  |  | 664,188 |  |
| Entered Orders |  |  | 895,593 |  |  |  | 403,512 |  |  |  | 265,732 |  |  |  | 1,564,837 |  |
| Sales |  |  | (478,192 | ) |  |  | (379,995 | ) |  |  | (237,201 | ) |  |  | (1,095,388 | ) |
| Ending Backlog - 9/30/25 |  | $ | 803,002 |  |  |  | 143,460 |  |  |  | 187,175 |  |  |  | 1,133,637 |  |

[0001104659-25-114614:8k_2_02:106]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-25-114614:8k_2_02:107]
Reconciliation of Non-GAAP Financial Measures (Unaudited)

[0001104659-25-114614:8k_2_02:108]
| EPS – Adjusted Basis Reconciliation – Q4 2025 |  |  |  |
| EPS Continuing Operations– GAAP Basis – Q4 2025 |  | $ | 1.73 |  |
| Adjustments (defined below) |  |  | 0.59 |  |
| EPS Continuing Operations– As Adjusted Basis – Q4 2025 |  | $ | 2.32 |  |
| Adjustments exclude $0.59 per share consisting primarily of: $0.05 of Maritime inventory step-up charges. $0.01 of restructuring charges within the USG segment and $0.53 of acquisition related amortization. |  |  |  |  |
| EPS – Adjusted Basis Reconciliation – Q4 2024 |  |  |  |  |
| EPS Continuing Operations– GAAP Basis – Q4 2024 |  | $ | 1.52 |  |
| Adjustments (defined below) |  |  | 0.27 |  |
| EPS Continuing Operations– As Adjusted Basis – Q4 2024 |  | $ | 1.79 |  |
| Adjustments exclude $0.27 per share consisting primarily of: $0.09 of debt financing and $0.03 of acquisition costs at Corporate, and $0.15 of acquisition related amortization. |  |  |  |  |
| EPS – Adjusted Basis Reconciliation – FY 2025 |  |  |  |  |
| EPS Continuing Operations– GAAP Basis – FY 2025 |  | $ | 4.49 |  |
| Adjustments (defined below) |  |  | 1.54 |  |
| EPS Continuing Operations – As Adjusted Basis – FY 2025 |  | $ | 6.03 |  |
| Adjustments exclude $1.54 per share consisting primarily of: $0.15 of Corporate acquisition costs, $0.14 of Maritime inventory step-up charges and stamp duties, $0.02 of restructuring charges within the Test and USG segments, and $1.23 of acquisition related amortization. |  |  |  |  |
| EPS – Adjusted Basis Reconciliation – FY 2024 |  |  |  |  |
| EPS Continuing Operations – GAAP Basis – FY 2024 |  | $ | 3.97 |  |
| Adjustments (defined below) |  |  | 0.80 |  |
| EPS Continuing Operations – As Adjusted Basis – FY 2024 |  | $ | 4.77 |  |
| Adjustments exclude $0.80 per share consisting primarily of: $0.09 of debt financing and $0.06 of acquisition costs at Corporate, $0.04 of MPE acquisition backlog and inventory step-up charges, $0.02 of restructuring charges within the Test, A&D and USG segments and $0.59 of acquisition related amortization. |  |  |  |  |

## item 5.02 — body, verbatim

[0001104659-25-114614:8k_body:1]
Item 5.02  Departure of Directors
or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers

[0001104659-25-114614:8k_body:2]
Executive Officers – Long-Term Equity
Incentive Awards

[0001104659-25-114614:8k_body:3]
On November 17, 2025, the Human Resources and Compensation Committee
of the Company’s Board of Directors approved the fiscal 2026 awards of time-based Restricted Share Units (RSUs) and Performance
Share Units (PSUs) to the Company’s three executive officers and the other participants in the Company’s LTI program, effective
November 17, 2025.

[0001104659-25-114614:8k_body:4]
Other than the share amounts, the terms of the fiscal 2026 RSUs (and
future RSUs except to the extent hereafter amended by the HRCC) are substantially similar to those awarded for fiscal 2025, vesting over
a period of approximately three years, in three equal portions approximately 12, 24 and 36 months after the grant date; for the fiscal
2026 awards, vesting will occur on the last NYSE trading days in November 2026, 2027 and 2028.

[0001104659-25-114614:8k_body:5]
The terms of the fiscal 2026 PSUs (and future PSUs except to the extent
hereafter amended by the HRCC) are substantially similar to those awarded for fiscal 2025 other than the specific share amounts and performance
goals. The fiscal 2026 PSUs will vest after a three-year performance period beginning October 1, 2025 and ending on September 30, 2028,
on the last trading day of the month in which the HRCC approves and certifies the extent to which the applicable performance goals have
been achieved. Upon vesting, the awards will be converted into a currently undeterminable number of shares of Company common stock, which
may be less than or greater than the number of PSUs awarded, within certain specified threshold and maximum limits, depending on the degree
to which the Company has achieved one or more specified performance goals. If the performance is less than the threshold goal for a particular
performance measure, there will be no payout of that portion of the PSUs dependent on that measure.

[0001104659-25-114614:8k_body:6]
The performance goals for the fiscal 2026 PSUs are specified Committee-approved
targets for EBITDA (60%) and Return on Invested Capital (40%), with the resulting number of shares potentially subject to increase or
decrease based on the Company’s Total Shareholder Return (TSR) over the performance period compared to the TSR of the companies
in a peer group based on the S&P Small-Cap 600 Industrials Index (rTSR). If the Company’s rTSR is below the 25th
percentile or above the 75th percentile, the resulting number of shares will be decreased by 20% or increased by 20%, respectively;
if the Company’s rTSR is from the 25th percentile to the 75th percentile, no adjustment will be made.

[0001104659-25-114614:8k_body:7]
The target number of shares in each RSU and PSU award equals the Committee-approved
target values divided by the 15-day average trading price of the Company’s stock. The actual payout of the RSUs and PSUs will be
in shares, whose value at the time of payout may be greater or less than the target values.

[0001104659-25-114614:8k_body:8]
For the executive officers, the numbers of RSUs granted and the PSU
threshold, target and maximum numbers of shares payable according to the performance criteria, were as follows:

[0001104659-25-114614:8k_body:9]
PSU Payout Potential (Shares)

[0001104659-25-114614:8k_body:10]
Name and Title

[0001104659-25-114614:8k_body:11]
RSU

[0001104659-25-114614:8k_body:12]
Target Values

[0001104659-25-114614:8k_body:13]
as of

[0001104659-25-114614:8k_body:14]
Grant Date

[0001104659-25-114614:8k_body:15]
Number

[0001104659-25-114614:8k_body:16]
of RSUs

[0001104659-25-114614:8k_body:17]
Granted

[0001104659-25-114614:8k_body:18]
PSU

[0001104659-25-114614:8k_body:19]
Target Values

[0001104659-25-114614:8k_body:20]
as of

[0001104659-25-114614:8k_body:21]
Grant Date

[0001104659-25-114614:8k_body:22]
At Threshold

[0001104659-25-114614:8k_body:23]
Performance

[0001104659-25-114614:8k_body:24]
(50% of

[0001104659-25-114614:8k_body:25]
Target)

[0001104659-25-114614:8k_body:26]
At Target

[0001104659-25-114614:8k_body:27]
Performance

[0001104659-25-114614:8k_body:28]
At

[0001104659-25-114614:8k_body:29]
Maximum

[0001104659-25-114614:8k_body:30]
Performance

[0001104659-25-114614:8k_body:31]
(200% of

[0001104659-25-114614:8k_body:32]
Target)

[0001104659-25-114614:8k_body:33]
Bryan H. Sayler
 Chief Executive Officer & President

[0001104659-25-114614:8k_body:34]
$

[0001104659-25-114614:8k_body:35]
1,050,000

[0001104659-25-114614:8k_body:36]
4,786

[0001104659-25-114614:8k_body:37]
$

[0001104659-25-114614:8k_body:38]
2,450,000

[0001104659-25-114614:8k_body:39]
5,583

[0001104659-25-114614:8k_body:40]
11,166

[0001104659-25-114614:8k_body:41]
22,332

[0001104659-25-114614:8k_body:42]
Christopher L. Tucker
 Senior Vice President 
 & Chief Financial Officer

[0001104659-25-114614:8k_body:43]
$

[0001104659-25-114614:8k_body:44]
288,240

[0001104659-25-114614:8k_body:45]
1,314

[0001104659-25-114614:8k_body:46]
$

[0001104659-25-114614:8k_body:47]
672,560

[0001104659-25-114614:8k_body:48]
1,533

[0001104659-25-114614:8k_body:49]
3,065

[0001104659-25-114614:8k_body:50]
6,130

[0001104659-25-114614:8k_body:51]
David M. Schatz
 Senior Vice President, 
 General Counsel & Secretary

[0001104659-25-114614:8k_body:52]
$

[0001104659-25-114614:8k_body:53]
166,980

[0001104659-25-114614:8k_body:54]
761

[0001104659-25-114614:8k_body:55]
$

[0001104659-25-114614:8k_body:56]
389,620

[0001104659-25-114614:8k_body:57]
888

[0001104659-25-114614:8k_body:58]
1,776

[0001104659-25-114614:8k_body:59]
3,552

[0001104659-25-114614:8k_body:60]
Item
7.01  Regulation FD Disclosure

[0001104659-25-114614:8k_body:61]
Today, November 20, 2025, the Company is issuing a press release (attached
as Exhibit 99.1) announcing its financial and operating results for the fourth quarter and fiscal year ended September 30, 2025. The
Company will conduct a related Webcast conference call today at 4:00 p.m. Central Time. The press release will be posted on the Company’s
web site located at http://www.escotechnologies.com. It can be viewed through the “Investor News” page of the web
site under the “Investor Center” tab, although the Company reserves the right to discontinue that availability at any time.

[0001104659-25-114614:8k_body:62]
Item
9.01  Financial Statements and Exhibits

[0001104659-25-114614:8k_body:63]
(d)           Exhibits

[0001104659-25-114614:8k_body:64]
Exhibit No.

[0001104659-25-114614:8k_body:65]
Description
                                            of Exhibit

[0001104659-25-114614:8k_body:66]
99.1

[0001104659-25-114614:8k_body:67]
Press Release issued November 20, 2025

[0001104659-25-114614:8k_body:68]
104

[0001104659-25-114614:8k_body:69]
Cover Page Inline
Interactive Data File

[0001104659-25-114614:8k_body:70]
Other Matters

[0001104659-25-114614:8k_body:71]
The information in this report furnished pursuant to Item 2.02 and Item 7.01, including Exhibit 99.1, shall not be deemed to be “filed”
for purposes of Section 18 of the Securities Exchange Act of 1934 as amended (“Exchange Act”) or otherwise subject to the
liabilities of that section, unless the Company incorporates it by reference into a filing under the Securities Act of 1933 as amended
or the Exchange Act.

[0001104659-25-114614:8k_body:72]
Any references to the Company’s web site address included in this Form 8-K and the press release are intended
only as inactive textual references and not as active links to its web site. Information contained on the Company’s web site does
not constitute part of this Form 8-K or the press release.
