# ESE 8-K — 0001104659-20-057442 filed 2020-05-06

## item codes, every 8-K on or before 2020-05-08

- 2020-05-06 0001104659-20-057442 — 2.02, 7.01, 8.01, 9.01
- 2020-02-04 0001104659-20-010640 — 2.02, 5.07, 7.01, 9.01
- 2020-01-07 0001104659-20-001789 — 2.01, 9.01
- 2019-11-19 0001104659-19-065437 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2019-11-18 0001104659-19-065096 — 1.01, 2.02, 7.01, 9.01
- 2019-09-30 0001144204-19-046523 — 1.01, 1.02, 2.03, 9.01
- 2019-08-08 0001144204-19-038567 — 2.02, 7.01, 9.01
- 2019-05-07 0001144204-19-024241 — 2.02, 5.02, 7.01, 9.01
- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2020-05-08

- none on or before 2020-05-08

## item 2.02 — earnings release, exhibit 99.1

[0001104659-20-057442:8k_2_02:1]
EX-99.1
2
tm2018661d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-20-057442:8k_2_02:2]
Exhibit 99.1

[0001104659-20-057442:8k_2_02:3]
| NEWS FROM |  |

[0001104659-20-057442:8k_2_02:4]
For more information contact:

[0001104659-20-057442:8k_2_02:5]
Kate Lowrey

[0001104659-20-057442:8k_2_02:6]
Director, Investor Relations

[0001104659-20-057442:8k_2_02:7]
ESCO Technologies Inc.

[0001104659-20-057442:8k_2_02:8]
(314)
213-7277

[0001104659-20-057442:8k_2_02:9]
ESCO ANNOUNCES SECOND QUARTER FISCAL
2020 RESULTS

[0001104659-20-057442:8k_2_02:10]
AND PROVIDES COVID-19 BUSINESS
UPDATE

[0001104659-20-057442:8k_2_02:11]
- Net Sales Increased 5 Percent in
Q2 and YTD 2020 -

[0001104659-20-057442:8k_2_02:12]
- Q2 2020 GAAP and Adjusted EPS $0.68
 –

[0001104659-20-057442:8k_2_02:13]
- Net Debt of $50 Million, Leverage
Ratio 0.92x, Liquidity of $700 Million -

[0001104659-20-057442:8k_2_02:14]
ST. LOUIS, May 6, 2020 – ESCO Technologies
Inc. (NYSE: ESE) (ESCO, or the Company) today reported its operating results for the second quarter ended March 31, 2020 (Q2 2020)
compared to the second quarter ended March 31, 2019 (Q2 2019), and provided a COVID-19 update.

[0001104659-20-057442:8k_2_02:15]
COVID-19 Update

[0001104659-20-057442:8k_2_02:16]
Vic Richey, Chairman and Chief Executive
Officer, commented, “The COVID-19 global pandemic has created significant and unprecedented challenges, and during these
highly uncertain times, our top priority remains the health and safety of our employees, customers and suppliers, thereby securing
the financial well-being of the Company and supporting business continuity.

[0001104659-20-057442:8k_2_02:17]
“Over the past few months, we have
implemented significant actions in an effort to ensure our employees around the world have the necessary personal safety and protection
measures in place to allow our businesses to continue operating with as little disruption as possible. Our businesses have been
deemed essential and remain operational, supplying our customers with vital and necessary products.

[0001104659-20-057442:8k_2_02:18]
“We are fortunate to have a deep and
experienced leadership team that has managed through multiple downturns in the past. Coupled with our strong balance sheet and
significant financial liquidity, I’m confident that we can effectively manage through this pandemic. ESCO has faced and overcome
many challenges in our 30-year history and our goal is to emerge from this extraordinary challenge as an even stronger company.

[0001104659-20-057442:8k_2_02:19]
“Given our diverse portfolio of strong,
durable businesses serving non-discretionary end-markets, the strength and resilience of our business model positions us to continue
to support our long-term outlook.

[0001104659-20-057442:8k_2_02:20]
“We have taken decisive actions to
enhance our strong financial condition, while continuing to execute our long-term strategy for profitable growth. Some of the actions
we’ve taken to address expected business pressures over the balance of the year, include: deferring a portion of executive
compensation; reducing discretionary spending; prioritizing / minimizing capital spending; implementing hiring and salary freezes;
and, increasing our focus on optimizing free cash flow.

[0001104659-20-057442:8k_2_02:21]
“These operational measures are prudent
steps to maintain our solid liquidity and will support our financial flexibility as we work through near-term volatility. As of
March 31, 2020, we had nearly $700 million of liquidity, with $100 million in cash, net debt of approximately $50 million, and
a very conservative leverage ratio of 0.92x. Additionally, we have no debt maturities nor repayment obligations coming due and
payable until September 2024.

[0001104659-20-057442:8k_2_02:22]
“While we are pleased with the operating
performance, cash flow, entered orders and backlog of our businesses year-to-date through March 31, 2020, given the extent of the
uncertainty presented by this pandemic, we are withdrawing our full-year 2020 financial guidance.

[0001104659-20-057442:8k_2_02:23]
“Everyone at ESCO, including our dedicated
employees, Board of Directors, and executive leadership team have displayed an amazing amount of resilience and personal commitment
to serve our customers through this difficult time. I want to thank everyone for the hard work, dedication, and sacrifice they
have demonstrated while working through this fight to position ESCO for the future and to drive continued success.”

[0001104659-20-057442:8k_2_02:24]
Q2 2020 Earnings Report

[0001104659-20-057442:8k_2_02:25]
On January 2, 2020, the Company announced
that it had completed the sale of its Technical Packaging segment effective December 31, 2019 which resulted in gross cash proceeds
of $191 million ($187 million purchase price plus working capital surplus) and a $77 million, or $2.93 per share net gain on the
sale in Q1 2020.

[0001104659-20-057442:8k_2_02:26]
The financial results presented include
certain non-GAAP financial measures such as EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS, as defined within the “Non-GAAP
Financial Measures” described below. Any non-GAAP financial measures presented are reconciled to their respective GAAP equivalents.

[0001104659-20-057442:8k_2_02:27]
Management believes these non-GAAP financial
measures are useful in assessing the ongoing operational profitability of the Company’s business segments, and therefore,
allow shareholders better visibility into the Company’s underlying operations. See “Non-GAAP Financial Measures”
described below.

[0001104659-20-057442:8k_2_02:28]
Q2 2020 GAAP and As Adjusted EPS was $0.68
per share, with net earnings of $18 million.

[0001104659-20-057442:8k_2_02:29]
Q2 2019 GAAP EPS of $0.68 per share included
$0.03 per share of cost reduction charges described in prior releases. The net effect of excluding the $0.03 per share of discrete
items resulted in Q2 2019 Adjusted EPS of $0.71 per share, with GAAP net earnings from continuing operations of $18 million.

[0001104659-20-057442:8k_2_02:30]
Q2 2020 Adjusted EBITDA was $31.4 million,
compared to Q2 2019 Adjusted EBITDA of $31.2 million.

[0001104659-20-057442:8k_2_02:31]
Operating Highlights

[0001104659-20-057442:8k_2_02:32]
|  | · | Net sales increased 5 percent to $180 million in Q2 2020 compared to $171 million in Q2 2019. |

[0001104659-20-057442:8k_2_02:33]
|  | · | Aerospace & Defense (A&D) segment sales increased $16 million, or 20 percent from Q2 2019, including $9 million in sales from the Globe acquisition together with strong aerospace contributions from PTI and Crissair, and higher space sales at Vacco. |

[0001104659-20-057442:8k_2_02:34]
|  | · | Test sales decreased $1 million in Q2 2020 as a result of a three-week COVID-19 shutdown of its Chinese manufacturing facility in February 2020, coupled with timing delays on certain installation projects due to COVID-19 related customer closure mandates and on-site personnel restrictions at customer locations, offset by strong domestic chamber project sales. |

[0001104659-20-057442:8k_2_02:35]
|  | · | USG sales decreased $5 million in Q2 2020 due to the timing of various project deliverables, and several utility customers re-aligning their short-term maintenance and spending protocols to focus on uninterrupted power delivery due to short-term electricity demand / mix changes between industrial, commercial and residential customers due to COVID-19. |

[0001104659-20-057442:8k_2_02:36]
|  | · | SG&A expenses as a percent of sales decreased to 22 percent in Q2 2020, from 23 percent in Q2 2019, despite additional spending on R&D / new product development, additional sales commissions, normal cost of living adjustments, and the addition of Globe. |

[0001104659-20-057442:8k_2_02:37]
|  | · | Q2 2020 amortization of intangible assets increased $1 million, or 20 percent compared to Q2 2019 as a result of the Globe acquisition being included in the Q2 2020 amounts. |

[0001104659-20-057442:8k_2_02:38]
|  | · | Interest expense decreased in Q2 2020 due to the lower net debt outstanding and favorable interest rates. |

[0001104659-20-057442:8k_2_02:39]
|  | · | The effective income tax rate from continuing operations (GAAP and Adjusted) was approximately 11 percent in both Q2 2020 and Q2 2019. The Q2 2020 quarterly rate was included in management’s previous guidance. Both quarterly periods were favorably impacted by various one-time tax strategies. |

[0001104659-20-057442:8k_2_02:40]
|  | · | Entered orders were $246 million in Q2 2020 (book-to-bill of 1.36x), and were $466 million YTD 2020 (book-to-bill of 1.32x), resulting in an ending backlog of $565 million at March 31, 2020, an increase of $113 million, or 25 percent, from September 30, 2019. |

[0001104659-20-057442:8k_2_02:41]
|  | · | Q2 2020 net cash provided by operating activities from Continuing Operations of $34 million, coupled with the cash proceeds from the sale of the Technical Packaging segment, resulted in $50 million of net debt outstanding (total borrowings, less cash on hand) at March 31 2020 and a 0.92x leverage ratio. |

[0001104659-20-057442:8k_2_02:42]
Chairman’s Commentary

[0001104659-20-057442:8k_2_02:43]
Vic Richey, Chairman and Chief Executive
Officer, commented, “The clear highlight of Q2 2020 was the strength of our A&D segment where sales increased 20 percent
over prior year, with an EBIT margin of nearly 23 percent. PTI and Crissair delivered strong performance on the aerospace side
and both Globe and Westland outperformed expectations on their navy / submarine platforms. A&D’s entered orders were
another bright spot coming in at $156 million with a book-to-bill of 1.64x led by exceptionally strong Block V orders for the
Virginia Class submarines.

[0001104659-20-057442:8k_2_02:44]
“We expect to see a slowdown in commercial
aerospace deliveries over the balance of the year, but it is too early in the cycle to determine the sales and EBIT impact from
the current industry downturn as it relates to future build rates and airline passenger miles.

[0001104659-20-057442:8k_2_02:45]
“The defense portion of A&D, both
military aerospace and navy products, is expected to remain strong given its backlog coupled with the urgency of expected platform
deliveries.

[0001104659-20-057442:8k_2_02:46]
“Test reported another solid Quarter
delivering a better than expected EBIT margin of 13.6 percent, despite lower sales resulting from the China facility’s temporary
shutdown and delayed timing of installation projects caused by access limitations to customer sites due to COVID-19.

[0001104659-20-057442:8k_2_02:47]
“We expect Test to remain relatively
solid over the remainder of the year given the strength of its backlog and its served markets, primarily related to new communications
technologies such as 5G and our medical shielding business.

[0001104659-20-057442:8k_2_02:48]
“USG came in lower than expected in
Q2 2020 as several utility customers deferred purchase orders and maintenance-related project deliveries so they could divert resources
to more important issues such as critical power delivery given their concerns around COVID-19. Additionally, Doble’s service
business is largely on hold. The order pipeline of new business remains robust, especially as it relates to cyber security solutions,
and I’m pleased to report that several new products and solutions introduced at the recent Doble Conference in March have
been enthusiastically received.

[0001104659-20-057442:8k_2_02:49]
“We expect USG’s customer spending
softness to continue for the next few months and once the utilities come out of their “summer testing protocols,” we
expect the USG business to return to a more normal state.

[0001104659-20-057442:8k_2_02:50]
“We improved our consolidated Q2 2020
Adjusted EBITDA and delivered a 17.4 percent EBITDA margin despite the lower contribution from our highest margin segment. Our
Q2 2020 entered orders were strong as we booked $246 million of new business and grew our backlog from the start of the year by
25 percent to $565 million, which helps protect against some downside risks over the remainder of the year.

[0001104659-20-057442:8k_2_02:51]
“From a liquidity perspective, we
are in a really solid position given our significant cash balance and our low debt level. The divestiture of the packaging business
proved to be a very timely event given that we used the proceeds to pay down a substantial portion of our outstanding debt and
to reduce our leverage ratio.

[0001104659-20-057442:8k_2_02:52]
“When the time is right, we plan to
use a portion of this additional liquidity and substantial debt capacity to fund future acquisitions and grow our business as we
continue to evaluate a robust pipeline of M&A opportunities. We are taking a prudent approach to our existing, near-term M&A
opportunities, and once things settle down a bit in our targeted end-markets, we would be comfortable adding to our current portfolio
during 2020.

[0001104659-20-057442:8k_2_02:53]
“Despite the significant economic
challenges we, and everyone else, are facing today, we plan to use the successes of the first half of 2020 and the benefit of our
disciplined operating culture to attempt to minimize our risks throughout the remainder of the year. I continue to have a favorable
view of our longer-term future with our goal remaining unchanged – to increase long-term shareholder value.”

[0001104659-20-057442:8k_2_02:54]
Dividend Payment

[0001104659-20-057442:8k_2_02:55]
Given its strong liquidity position, the
Company is not changing its dividend payment plan. The next quarterly cash dividend of $0.08 per share will be paid on July 16,
2020 to stockholders of record on July 2, 2020.

[0001104659-20-057442:8k_2_02:56]
Business Outlook – Including COVID-19
Impact

[0001104659-20-057442:8k_2_02:57]
During Q2 2020, business disruptions related
to the pandemic started to affect the Company’s operations. Given the considerable uncertainty around the extent and duration
of these economic circumstances, it is difficult to predict how our future operations will be affected using our normal forecasting
methodologies, therefore, the Company is suspending its previously issued fiscal year 2020 guidance.

[0001104659-20-057442:8k_2_02:58]
For 2020 financial reporting, the Technical
Packaging business segment’s results of operations, gain on sale, balance sheet and cash flows are reported as Discontinued
Operations.

[0001104659-20-057442:8k_2_02:59]
Pension Plan Termination Update

[0001104659-20-057442:8k_2_02:60]
As previously announced, Management will
be using a portion of the Technical Packaging divestiture proceeds to fully fund, terminate, and annuitize the defined benefit
pension plan (the Plan) currently maintained by the Company. The termination is expected to be completed before the end of fiscal
year 2020.

[0001104659-20-057442:8k_2_02:61]
By initiating this process in November 2019,
the Company was able to convert the majority of the Plan assets (equities and bonds) to Cash in January and February prior to the
recent, and extraordinary market volatility, thereby avoiding a major loss in Plan asset value which would have resulted in a larger
under-funding situation.

[0001104659-20-057442:8k_2_02:62]
Management commented in previous releases
that by annuitizing this non-strategic liability through an insurance company it could eliminate both equity market risk and interest
rate volatility, thereby reducing ongoing costs and eliminating future cash payments.

[0001104659-20-057442:8k_2_02:63]
The Plan was frozen in 2003 and no additional
benefits have been accrued since that date.

[0001104659-20-057442:8k_2_02:64]
The accounting impact of terminating and
annuitizing the pension will be excluded from the calculation of Adjusted EBITDA and Adjusted EPS when terminated.

[0001104659-20-057442:8k_2_02:65]
Conference Call

[0001104659-20-057442:8k_2_02:66]
The Company will host a conference call
today, May 6, at 4:00 p.m. Central Time, to discuss the Company’s Q2 2020 results. A live audio webcast will be available
on the Company’s website at www.escotechnologies.com. Please access the website at least 15 minutes prior to the call to
register, download and install any necessary audio software. A replay of the conference call will be available on the Company’s
website noted above or by phone (dial 1-855-859-2056 and enter the pass code 9211249).

[0001104659-20-057442:8k_2_02:67]
Forward-Looking Statements

[0001104659-20-057442:8k_2_02:68]
Statements in this press release regarding
the future impacts of COVID-19 on the Company’s results, the financial success of the Company, the strength of its end markets,
including without limitation the anticipated slowdown in commercial aerospace, actions in regard to the Company’s frozen
defined benefit plan, the ability to increase shareholder value, the success of acquisition efforts, the use of proceeds from the
recent divestiture, the long-term success of the Company, and any other statements which are not strictly historical are “forward-looking”
statements within the meaning of the safe harbor provisions of the federal securities laws.

[0001104659-20-057442:8k_2_02:69]
Investors are cautioned that such statements
are only predictions and speak only as of the date of this release, and the Company undertakes no duty to update them except as
may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from
those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and
business environment including but not limited to those described in Item 1A, “Risk Factors”, of the Company’s
Annual Report on Form 10-K for the fiscal year ended September 30, 2019, in Item 8.01 of the Company’s Form 8-K filed May
6, 2020, and the following: impacts arising from COVID-19 including without limitation labor shortages due to illness, shelter
in place policies or quarantines, material shortages, transportation delays, delays or termination of Company contracts, the inability
of our suppliers to perform, weakening of economic conditions in served markets; changes in customer demands or customer insolvencies;
competition; intellectual property rights; technical difficulties; delivery delays or defaults by customers; material changes in
the costs and availability of certain raw materials; the appropriation, allocation and availability of Government funds; the termination
for convenience of Government and other customer contracts; the timing and content of future contract awards or customer orders;
performance issues with key customers, suppliers and subcontractors; labor disputes; the impacts of natural disasters on the Company’s
operations and those of the Company’s customers and suppliers; changes in laws and regulations, including but not limited
to changes in accounting standards, taxation requirements, and new or modified tariffs; changes in interest rates; costs relating
to environmental matters arising from current or former facilities; financial exposure in connection with the Company’s guarantee
of a former Aclara lease; the availability of select acquisitions; and the uncertainty regarding the ultimate resolution of current
disputes, claims, litigation or arbitration.

[0001104659-20-057442:8k_2_02:70]
Non-GAAP Financial Measures

[0001104659-20-057442:8k_2_02:71]
The financial measures EBIT, EBITDA, Adjusted
EBITDA and Adjusted EPS are presented in this press release. The Company defines “EBIT” as earnings before interest
and taxes, “EBITDA” as earnings before interest, taxes, depreciation and amortization, “Adjusted EBITDA”
as EBITDA excluding certain defined charges, and “Adjusted EPS” as GAAP earnings per share (EPS) excluding the net
impact of the items described above which were $0.02 per share in YTD 2020.

[0001104659-20-057442:8k_2_02:72]
EBIT, EBITDA, Adjusted EBITDA and Adjusted
EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management believes that
EBIT, EBITDA and Adjusted EBITDA are useful in assessing the operational profitability of the Company’s business segments
because they exclude interest, taxes, depreciation and amortization, which are generally accounted for across the entire Company
on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company
as well as incentive compensation. The presentation of EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS provides important supplemental
information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures
to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance
determined in accordance with GAAP.

[0001104659-20-057442:8k_2_02:73]
ESCO, headquartered in St. Louis, Missouri:
Manufactures highly-engineered filtration and fluid control products for the aviation, navy, space and process markets worldwide,
as well as composite-based products and solutions for navy, defense and industrial customers; is the industry leader in RF shielding
and EMC test products; and provides diagnostic instruments, software and services for the benefit of industrial power users and
the electric utility and renewable energy industries. Further information regarding ESCO and its subsidiaries is available on the
Company’s website at www.escotechnologies.com.

[0001104659-20-057442:8k_2_02:74]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-20-057442:8k_2_02:75]
Condensed Consolidated Statements
of Operations (Unaudited)

[0001104659-20-057442:8k_2_02:76]
(Dollars in thousands, except
per share amounts)

[0001104659-20-057442:8k_2_02:77]
|  |  | Three Months Ended March 31, 2020 |  |  | Three Months Ended March 31, 2019 |  |
| Net Sales |  | $ | 180,492 |  |  |  | 171,243 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 113,242 |  |  |  | 103,547 |  |
| Selling, general and administrative expenses |  |  | 39,982 |  |  |  | 39,327 |  |
| Amortization of intangible assets |  |  | 5,220 |  |  |  | 4,371 |  |
| Interest expense |  |  | 1,320 |  |  |  | 1,853 |  |
| Other expenses (income), net |  |  | 703 |  |  |  | 2,022 |  |
| Total costs and expenses |  |  | 160,467 |  |  |  | 151,120 |  |
| Earnings before income taxes |  |  | 20,025 |  |  |  | 20,123 |  |
| Income tax expense |  |  | 2,203 |  |  |  | 2,301 |  |
| Earnings from continuing operations |  |  | 17,822 |  |  |  | 17,822 |  |
| Earnings from discontinued operations, net of tax expense of $257 |  |  | - |  |  |  | 975 |  |
| Gain on sale of discontinued operations |  |  | - |  |  |  | - |  |
| Earnings from discontinued operations |  |  | - |  |  |  | 975 |  |
| Net earnings |  | $ | 17,822 |  |  |  | 18,797 |  |
| Diluted EPS: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.68 |  |  |  | 0.68 |  |
| Discontinued operations |  |  | 0.00 |  |  |  | 0.04 |  |
| Net earnings |  | $ | 0.68 |  |  |  | 0.72 |  |
| Diluted - As Adjusted Basis Continuing operations |  | $ | 0.68 |  |  |  | 0.71 | (1) |
| Diluted average common shares O/S: |  |  | 26,088 |  |  |  | 26,036 |  |

[0001104659-20-057442:8k_2_02:78]
|  | (1) | Q2 FY 19 Adjusted EPS excludes $0.03 per share of after-tax charges incurred primarily at Doble, PTI and VACCO during the second quarter of fiscal 2019. |

[0001104659-20-057442:8k_2_02:79]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-20-057442:8k_2_02:80]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-20-057442:8k_2_02:81]
(Dollars in thousands, except per share amounts)

[0001104659-20-057442:8k_2_02:82]
|  |  | Six Months Ended March 31, 2020 |  |  | Six Months Ended March 31, 2019 |  |
| Net Sales |  | $ | 352,220 |  |  |  | 334,608 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 219,969 |  |  |  | 206,001 |  |
| Selling, general and administrative expenses |  |  | 82,087 |  |  |  | 77,867 |  |
| Amortization of intangible assets |  |  | 11,030 |  |  |  | 8,771 |  |
| Interest expense |  |  | 3,741 |  |  |  | 3,708 |  |
| Other expenses (income), net |  |  | 998 |  |  |  | (5,357 | ) |
| Total costs and expenses |  |  | 317,825 |  |  |  | 290,990 |  |
| Earnings before income taxes |  |  | 34,395 |  |  |  | 43,618 |  |
| Income tax expense |  |  | 5,809 |  |  |  | 8,446 |  |
| Earnings from continuing operations |  |  | 28,586 |  |  |  | 35,172 |  |
| (Loss) earnings from discontinued operations, net of tax expense of $269 and $52 |  |  | (601 | ) |  |  | 942 |  |
| Gain on sale of discontinued operations, net of tax expense of $23,734 |  |  | 76,614 |  |  |  | - |  |
| Earnings from discontinued operations |  |  | 76,013 |  |  |  | 942 |  |
| Net earnings |  | $ | 104,599 |  |  |  | 36,114 |  |
| Diluted EPS: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 1.09 |  |  |  | 1.34 |  |
| Discontinued operations |  |  | 2.91 |  |  |  | 0.04 |  |
| Net earnings |  | $ | 4.00 |  |  |  | 1.38 |  |
| Diluted - As Adjusted Basis Continuing operations |  | $ | 1.11 | (1) |  |  | 1.17 | (2) |
| Diluted average common shares O/S: |  |  | 26,126 |  |  |  | 26,078 |  |

[0001104659-20-057442:8k_2_02:83]
|  | (1) | YTD Q2 FY 20 Adjusted EPS excludes $0.02 per share of after-tax charges primarily related to the move of the Doble headquarters facility. |

[0001104659-20-057442:8k_2_02:84]
|  | (2) | YTD Q2 FY 19 Adjusted EPS excludes $0.17 per share of after-tax income mainly resulting from the gain on the sale of the Doble Watertown property partially offset by certain restructuring charges primarily at Doble, PTI and VACCO. |

[0001104659-20-057442:8k_2_02:85]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-20-057442:8k_2_02:86]
Condensed Business Segment Information (Unaudited)

[0001104659-20-057442:8k_2_02:87]
(Dollars in thousands)

[0001104659-20-057442:8k_2_02:88]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | Q2 2020 |  |  | Q2 2019 |  |  | Q2 2020 |  |  | Q2 2019 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 95,124 |  |  |  | 79,478 |  |  |  | 95,124 |  |  |  | 79,478 |  |
| Test |  |  | 41,600 |  |  |  | 42,875 |  |  |  | 41,600 |  |  |  | 42,875 |  |
| USG |  |  | 43,768 |  |  |  | 48,890 |  |  |  | 43,768 |  |  |  | 48,890 |  |
| Totals |  | $ | 180,492 |  |  |  | 171,243 |  |  |  | 180,492 |  |  |  | 171,243 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 21,736 |  |  |  | 17,443 |  |  |  | 21,736 |  |  |  | 17,806 |  |
| Test |  |  | 5,651 |  |  |  | 5,554 |  |  |  | 5,651 |  |  |  | 5,554 |  |
| USG |  |  | 4,866 |  |  |  | 8,767 |  |  |  | 4,866 |  |  |  | 9,241 |  |
| Corporate |  |  | (10,908 | ) |  |  | (9,788 | ) |  |  | (10,908 | ) |  |  | (9,679 | ) |
| Consolidated EBIT |  |  | 21,345 |  |  |  | 21,976 |  |  |  | 21,345 |  |  |  | 22,922 |  |
| Less: Interest expense |  |  | (1,320 | ) |  |  | (1,853 | ) |  |  | (1,320 | ) |  |  | (1,853 | ) |
| Less: Income tax expense |  |  | (2,203 | ) |  |  | (2,301 | ) |  |  | (2,203 | ) |  |  | (2,516 | ) |
| Net earnings from cont ops |  | $ | 17,822 |  |  |  | 17,822 |  |  |  | 17,822 |  |  |  | 18,553 |  |

[0001104659-20-057442:8k_2_02:89]
Note 1: Adjusted net earnings were $18.5 million in Q2 FY
19 which excluded $0.03 per share of after-tax charges related to the restructuring charges incurred at Doble, PTI and VACCO
during the second quarter of 2019.

[0001104659-20-057442:8k_2_02:90]
EBITDA Reconciliation to Net earnings from continuing operations:

[0001104659-20-057442:8k_2_02:91]
|  |  |  |  |  |  |  |  | Adjusted |  |  | Adjusted |  |
|  |  | Q2 2020 |  |  | Q2 2019 |  |  | Q2 2020 |  |  | Q2 2019 |  |
| Consolidated EBITDA |  | $ | 31,388 |  |  |  | 30,259 |  |  |  | 31,388 |  |  |  | 31,205 |  |
| Less: Depr & Amort |  |  | (10,043 | ) |  |  | (8,283 | ) |  |  | (10,043 | ) |  |  | (8,283 | ) |
| Consolidated EBIT |  |  | 21,345 |  |  |  | 21,976 |  |  |  | 21,345 |  |  |  | 22,922 |  |
| Less: Interest expense |  |  | (1,320 | ) |  |  | (1,853 | ) |  |  | (1,320 | ) |  |  | (1,853 | ) |
| Less: Income tax expense |  |  | (2,203 | ) |  |  | (2,301 | ) |  |  | (2,203 | ) |  |  | (2,516 | ) |
| Net earnings from cont opsd |  | $ | 17,822 |  |  |  | 17,822 |  |  |  | 17,822 |  |  |  | 18,553 |  |

[0001104659-20-057442:8k_2_02:92]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-20-057442:8k_2_02:93]
Condensed Business Segment Information (Unaudited)

[0001104659-20-057442:8k_2_02:94]
(Dollars in thousands)

[0001104659-20-057442:8k_2_02:95]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | YTD Q2 |  |  | YTD Q2 |  |  | YTD Q2 |  |  | YTD Q2 |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 172,635 |  |  |  | 145,702 |  |  |  | 172,635 |  |  |  | 145,702 |  |
| Test |  |  | 82,983 |  |  |  | 84,161 |  |  |  | 82,983 |  |  |  | 84,161 |  |
| USG |  |  | 96,602 |  |  |  | 104,745 |  |  |  | 96,602 |  |  |  | 104,745 |  |
| Totals |  | $ | 352,220 |  |  |  | 334,608 |  |  |  | 352,220 |  |  |  | 334,608 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 34,249 |  |  |  | 28,053 |  |  |  | 34,319 |  |  |  | 28,513 |  |
| Test |  |  | 10,307 |  |  |  | 8,864 |  |  |  | 10,307 |  |  |  | 8,864 |  |
| USG |  |  | 14,153 |  |  |  | 30,313 |  |  |  | 14,773 |  |  |  | 23,100 |  |
| Corporate |  |  | (20,573 | ) |  |  | (19,904 | ) |  |  | (20,573 | ) |  |  | (19,430 | ) |
| Consolidated EBIT |  |  | 38,136 |  |  |  | 47,326 |  |  |  | 38,826 |  |  |  | 41,047 |  |
| Less: Interest expense |  |  | (3,741 | ) |  |  | (3,708 | ) |  |  | (3,741 | ) |  |  | (3,708 | ) |
| Less: Income tax |  |  | (5,809 | ) |  |  | (8,446 | ) |  |  | (5,975 | ) |  |  | (6,716 | ) |
| Net earnings from cont ops |  | $ | 28,586 |  |  |  | 35,172 |  |  |  | 29,110 |  |  |  | 30,623 |  |

[0001104659-20-057442:8k_2_02:96]
Note 1: Adjusted net earnings were $29.1 million in YTD Q2 FY 20 which excluded $0.02 per share of after-tax charges related primarily to the facility move at Doble.

[0001104659-20-057442:8k_2_02:97]
Note 2: Adjusted net earnings were
$30.6 million in YTD Q2 FY 19 which excluded $0.17 per share of after-tax income primarily related to the Q1 FY 19 gain on
the sale of the Doble Watertown facility partially offset by charges related to other restructuring actions at Doble, PTI and
VACCO.

[0001104659-20-057442:8k_2_02:98]
EBITDA Reconciliation to Net earnings from continuing operations:

[0001104659-20-057442:8k_2_02:99]
|  |  |  |  |  |  |  |  | Adjusted |  |  | Adjusted |  |
|  |  | YTD Q2 |  |  | YTD Q2 |  |  | YTD Q2 |  |  | YTD Q2 |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Consolidated EBITDA |  | $ | 58,719 |  |  |  | 64,163 |  |  |  | 59,409 |  |  |  | 57,884 |  |
| Less: Depr & Amort |  |  | (20,583 | ) |  |  | (16,837 | ) |  |  | (20,583 | ) |  |  | (16,837 | ) |
| Consolidated EBIT |  |  | 38,136 |  |  |  | 47,326 |  |  |  | 38,826 |  |  |  | 41,047 |  |
| Less: Interest expense |  |  | (3,741 | ) |  |  | (3,708 | ) |  |  | (3,741 | ) |  |  | (3,708 | ) |
| Less: Income tax expense |  |  | (5,809 | ) |  |  | (8,446 | ) |  |  | (5,975 | ) |  |  | (6,716 | ) |
| Net earnings from cont ops |  | $ | 28,586 |  |  |  | 35,172 |  |  |  | 29,110 |  |  |  | 30,623 |  |

[0001104659-20-057442:8k_2_02:100]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-20-057442:8k_2_02:101]
Condensed Consolidated Balance Sheets (Unaudited)

[0001104659-20-057442:8k_2_02:102]
(Dollars in thousands)

[0001104659-20-057442:8k_2_02:103]
|  |  | March 31, 2020 |  |  | September 30, 2019 |  |
| Assets |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 100,195 |  |  |  | 61,808 |  |
| Accounts receivable, net |  |  | 157,050 |  |  |  | 158,715 |  |
| Contract assets |  |  | 96,100 |  |  |  | 110,211 |  |
| Inventories |  |  | 141,027 |  |  |  | 124,956 |  |
| Other current assets |  |  | 17,228 |  |  |  | 14,190 |  |
| Assets of discontinued operations-current |  |  | - |  |  |  | 25,314 |  |
| Total current assets |  |  | 511,600 |  |  |  | 495,194 |  |
| Property, plant and equipment, net |  |  | 139,248 |  |  |  | 127,843 |  |
| Intangible assets, net |  |  | 371,779 |  |  |  | 381,605 |  |
| Goodwill |  |  | 389,630 |  |  |  | 390,256 |  |
| Operating lease assets |  |  | 18,901 |  |  |  | - |  |
| Other assets |  |  | 10,421 |  |  |  | 4,445 |  |
| Assets of discontinued operations-other |  |  | - |  |  |  | 67,377 |  |
|  |  | $ | 1,441,579 |  |  |  | 1,466,720 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt |  | $ | 20,000 |  |  |  | 20,000 |  |
| Accounts payable |  |  | 53,617 |  |  |  | 63,800 |  |
| Contract liabilities |  |  | 95,382 |  |  |  | 81,177 |  |
| Other current liabilities |  |  | 82,030 |  |  |  | 75,141 |  |
| Liabilities of discontinued operations-current |  |  | - |  |  |  | 11,517 |  |
| Total current liabilities |  |  | 251,029 |  |  |  | 251,635 |  |
| Deferred tax liabilities |  |  | 61,690 |  |  |  | 60,856 |  |
| Non-current operating lease liabilities |  |  | 15,010 |  |  |  | - |  |
| Other liabilities |  |  | 57,643 |  |  |  | 59,008 |  |
| Long-term debt |  |  | 130,000 |  |  |  | 265,000 |  |
| Liabilities of discontinued operations-other |  |  | - |  |  |  | 3,999 |  |
| Shareholders' equity |  |  | 926,207 |  |  |  | 826,222 |  |
|  |  | $ | 1,441,579 |  |  |  | 1,466,720 |  |

[0001104659-20-057442:8k_2_02:104]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-20-057442:8k_2_02:105]
Consolidated Statements of Cash Flows (Unaudited)

[0001104659-20-057442:8k_2_02:106]
(Dollars in thousands)

[0001104659-20-057442:8k_2_02:107]
|  |  | Six Months Ended March 31, 2020 |  |
| Cash flows from operating activities: |  |  |  |
| Net earnings |  | $ | 104,599 |  |
| Earnings from discontinued operations |  |  | (76,013 | ) |
| Adjustments to reconcile net earnings to net cash provided by operating activities: |  |  |  |  |
| Depreciation and amortization |  |  | 20,583 |  |
| Stock compensation expense |  |  | 2,896 |  |
| Changes in assets and liabilities |  |  | (16,247 | ) |
| Effect of deferred taxes |  |  | 834 |  |
| Net cash provided by continuing operations |  |  | 36,652 |  |
| Net cash used by discontinued operations |  |  | (14,622 | ) |
| Cash flows from investing activities: |  |  |  |  |
| Capital expenditures |  |  | (21,211 | ) |
| Additions to capitalized software |  |  | (4,280 | ) |
| Net cash used by investing activities - continuing operations |  |  | (25,491 | ) |
| Proceeds from sale of discontinued operations |  |  | 183,997 |  |
| Capital expenditures - discontinued operations |  |  | (1,728 | ) |
| Net cash provided by investing activities - discontinued operations |  |  | 182,269 |  |
| Net cash provided by investing activities |  |  | 156,778 |  |
| Cash flows from financing activities: |  |  |  |  |
| Proceeds from long-term debt |  |  | 10,000 |  |
| Principal payments on long-term debt |  |  | (145,000 | ) |
| Dividends paid |  |  | (4,156 | ) |
| Net cash used by financing activities - continuing operations |  |  | (139,156 | ) |
| Net cash used by financing activities - discontinued operations |  |  | (2,140 | ) |
| Net cash used by financing activities |  |  | (141,296 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 875 |  |
| Net increase in cash and cash equivalents |  |  | 38,387 |  |
| Cash and cash equivalents, beginning of period |  |  | 61,808 |  |
| Cash and cash equivalents, end of period |  | $ | 100,195 |  |

[0001104659-20-057442:8k_2_02:108]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-20-057442:8k_2_02:109]
Other Selected Financial Data (Unaudited)  -- Continuing Operations Basis

[0001104659-20-057442:8k_2_02:110]
(Dollars in thousands)

[0001104659-20-057442:8k_2_02:111]
| Backlog And Entered Orders - Q2 FY 2020 |  | Aerospace & Defense |  |  | Test |  |  | USG |  |  | Total |  |
| Beginning Backlog - 1/1/20 |  | $ | 327,784 |  |  |  | 130,701 |  |  |  | 41,785 |  |  |  | 500,270 |  |
| Entered Orders |  |  | 155,984 |  |  |  | 41,787 |  |  |  | 47,845 |  |  |  | 245,616 |  |
| Sales |  |  | (95,124 | ) |  |  | (41,600 | ) |  |  | (43,768 | ) |  |  | (180,492 | ) |
| Ending Backlog - 3/31/20 |  | $ | 388,644 |  |  |  | 130,888 |  |  |  | 45,862 |  |  |  | 565,394 |  |

[0001104659-20-057442:8k_2_02:112]
| Backlog And Entered Orders - YTD Q2 FY 2020 |  | Aerospace & Defense |  |  | Test |  |  | USG |  |  | Total |  |
| Beginning Backlog - 10/1/19 |  | $ | 276,273 |  |  |  | 133,571 |  |  |  | 41,715 |  |  |  | 451,559 |  |
| Entered Orders |  |  | 285,006 |  |  |  | 80,300 |  |  |  | 100,749 |  |  |  | 466,055 |  |
| Sales |  |  | (172,635 | ) |  |  | (82,983 | ) |  |  | (96,602 | ) |  |  | (352,220 | ) |
| Ending Backlog - 3/31/20 |  | $ | 388,644 |  |  |  | 130,888 |  |  |  | 45,862 |  |  |  | 565,394 |  |

[0001104659-20-057442:8k_2_02:113]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-20-057442:8k_2_02:114]
Reconciliation of Non-GAAP Financial Measures (Unaudited)

[0001104659-20-057442:8k_2_02:115]
| EPS – Adjusted Basis Reconciliation – YTD Q2 FY 20 |  |  |  |
| EPS from Continuing Ops – GAAP Basis – YTD Q2 FY 20 |  | $ | 1.09 |  |
| Adjustments (defined below) |  |  | 0.02 |  |
| EPS from Continuing Ops – As Adjusted Basis – YTD Q2 FY 20 |  | $ | 1.11 |  |

[0001104659-20-057442:8k_2_02:116]
| Adjustments exclude $0.02 per share consisting of move costs associated with the Doble facility consolidation in the first six months of 2020. |  |  |  |  |
| (The $0.02 of EPS adjustments per share consists of $690K of pre-tax charges offset by $166K of tax benefit for net impact of $524K.) |  |  |  |  |

[0001104659-20-057442:8k_2_02:117]
| EPS – Adjusted Basis Reconciliation – Q2 FY 19 |  |  |  |  |
| EPS from Continuing Ops – GAAP Basis – Q2 FY 19 |  | $ | 0.68 |  |
| Adjustments (defined below) |  |  | 0.03 |  |
| EPS from Continuing Ops – As Adjusted Basis – Q2 FY 19 |  | $ | 0.71 |  |

[0001104659-20-057442:8k_2_02:118]
| Adjustments exclude $0.03 per share consisting of restructuring charges related to Doble, PTI & VACCO during the second quarter of 2019. |  |  |  |  |
| (The $0.03 of EPS adjustments per share consists of $946K of pre-tax charges offset by $215K of tax benefit for net impact of $731K.) |  |  |  |  |

[0001104659-20-057442:8k_2_02:119]
| EPS – Adjusted Basis Reconciliation – YTD Q2 FY 19 |  |  |  |  |
| EPS from Continuing Ops – GAAP Basis – YTD Q2 FY 19 |  | $ | 1.34 |  |
| Adjustments (defined below) |  |  | (0.17 | ) |
| EPS from Continuing Ops – As Adjusted Basis – YTD Q2 FY 19 |  | $ | 1.17 |  |

[0001104659-20-057442:8k_2_02:120]
| Adjustments exclude $0.17 per share consisting of income related to the gain on sale of the Doble Watertown property partially offset |  |  |  |  |
| by certain restructuring charges at Doble, PTI & VACCO in the first six months of 2019. (The $0.17 of EPS adjustments per share |  |  |  |  |
| consists of $6.3 million of pre-tax income offset by $1.7 million of tax expense for net impact of $4.6 million.) |  |  |  |  |
