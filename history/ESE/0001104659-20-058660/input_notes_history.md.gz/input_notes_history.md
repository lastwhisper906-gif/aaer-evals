# ESE note change history — 0001104659-20-012461 → 0001104659-20-058660


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-05-08):
[0001104659-20-058660:note_history:1]
The Company’s results for the three-month period ended March 31, 2020 are not necessarily indicative of the results for the entire 2020 fiscal year. References to the second quarters of 2020 and 2019 represent the fiscal quarters ended March 31, 2020 and 2019, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.
  (was, 2020-02-07, similarity 0.9616):
[0001104659-20-012461:note_history:1]
The Company’s results for the three-month period ended December 31, 2019 are not necessarily indicative of the results for the entire 2020 fiscal year. References to the first quarters of 2020 and 2019 represent the fiscal quarters ended December 31, 2019 and 2018, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-08):
[0001104659-20-058660:note_history:2]
| ​ | ​ | March 31, | ​ | September 30, |
| (In thousands) |  | 2020 |  | 2019 |
| Total borrowings | ​ | $ | 150,000 |  | ​ | 285,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 130,000 |  | ​ | 265,000 |
  (was, 2020-02-07, similarity 0.9772):
[0001104659-20-012461:note_history:2]
| ​ | ​ | December 31, | ​ | September 30, |
| (In thousands) |  | 2019 |  | 2019 |
| Total borrowings | ​ | $ | 150,000 |  | ​ | 285,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 130,000 |  | ​ | 265,000 |

- changed (2020-05-08):
[0001104659-20-058660:note_history:3]
At March 31, 2020, the Company had approximately $341 million available to borrow under the Credit Facility, plus the $250 million increase option, subject to lender approval, in addition to $100.2 million cash on hand. The Company classified $20.0 million as the current portion of long-term debt as of March 31, 2020, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $9.8 million at March 31, 2020.
  (was, 2020-02-07, similarity 0.9339):
[0001104659-20-012461:note_history:3]
At December 31, 2019, the Company had approximately $341 million available to borrow under the Credit Facility, plus the $250 million increase option, in addition to $96.7 million cash on hand. The Company classified $20.0 million as the current portion of long-term debt as of December 31, 2019, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $8.5 million at December 31, 2019.

- changed (2020-05-08):
[0001104659-20-058660:note_history:4]
Interest on borrowings under the Credit Facility is calculated at a spread over either the London Interbank Offered Rate (LIBOR ), the New York Federal Reserve Bank Rate or the prime rate, depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The Credit Facility is secured by the unlimited guaranty of the Company’s direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of its direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 3.24% and 3.21% for the three and  six-month periods ending March 31, 2020, respectively , and 3.20% and 3.23% for the three and six-month periods ending March 31, 2019. As of March 31, 2020, the Company was in compliance with all covenants.
  (was, 2020-02-07, similarity 0.9274):
[0001104659-20-012461:note_history:4]
Interest on borrowings under the Credit Facility is calculated at a spread over either the London Interbank Offered Rate (LIBOR ), the New York Federal Reserve Bank Rate or the prime rate, depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The Credit Facility is secured by the unlimited guaranty of the Company’s direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of its direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 3.18% and 3.25% for the three-month periods ending December 31, 2019 and 2018, respectively. As of December 31, 2019, the Company was in compliance with all covenants.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-08):
[0001104659-20-058660:note_history:5]
| ​ | ​ | March 31, | ​ | September 30, |
| (In thousands) |  | 2020 |  | 2019 |
| Total borrowings | ​ | $ | 150,000 |  | ​ | 285,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 130,000 |  | ​ | 265,000 |
  (was, 2020-02-07, similarity 0.9772):
[0001104659-20-012461:note_history:5]
| ​ | ​ | December 31, | ​ | September 30, |
| (In thousands) |  | 2019 |  | 2019 |
| Total borrowings | ​ | $ | 150,000 |  | ​ | 285,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 130,000 |  | ​ | 265,000 |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-08):
[0001104659-20-058660:note_history:6]
| Three months ended March 31, 2020 |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | Test | ​ | USG | ​ | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 51,550 | ​ | $ | 33,952 | ​ | $ | 43,736 | ​ | $ | 129,238 |
| U.S. Government | ​ |  | 43,574 | ​ | ​ | 7,648 | ​ | ​ | 32 | ​ |  | 51,254 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 41,600 | ​ | $ | 43,768 | ​ | $ | 180,492 |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |
| United States | ​ | $ | 81,458 | ​ | $ | 25,121 | ​ | $ | 28,706 | ​ | $ | 135,285 |
| International | ​ |  | 13,666 | ​ | ​ | 16,479 | ​ | ​ | 15,062 | ​ |  | 45,207 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 41,600 | ​ | $ | 43,768 | ​ | $ | 180,492 |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 46,610 | ​ | $ | 8,009 | ​ | $ | 32,209 | ​ | $ | 86,828 |
| Over time | ​ |  | 48,514 | ​ | ​ | 33,591 | ​ | ​ | 11,559 | ​ |  | 93,664 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 41,600 | ​ | $ | 43,768 | ​ | $ | 180,492 |
  (was, 2020-02-07, similarity 0.902):
[0001104659-20-012461:note_history:6]
| ​ |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | Test | ​ | USG | ​ | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 41,907 | ​ | $ | 35,249 | ​ | $ | 52,235 | ​ | $ | 129,391 |
| U.S. Government | ​ |  | 35,604 | ​ |  | 6,134 | ​ |  | 599 | ​ |  | 42,337 |
| Total revenues | ​ | $ | 77,511 | ​ | $ | 41,383 | ​ | $ | 52,834 | ​ | $ | 171,728 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 64,706 | ​ | $ | 24,837 | ​ | $ | 34,651 | ​ | $ | 124,194 |
| International | ​ |  | 12,805 | ​ |  | 16,546 | ​ |  | 18,183 | ​ |  | 47,534 |
| Total revenues | ​ | $ | 77,511 | ​ | $ | 41,383 | ​ | $ | 52,834 | ​ | $ | 171,728 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 35,761 | ​ | $ | 7,611 | ​ | $ | 40,315 | ​ | $ | 83,687 |
| Over time | ​ |  | 41,750 | ​ |  | 33,772 | ​ |  | 12,519 | ​ |  | 88,041 |
| Total revenues | ​ | $ | 77,511 | ​ | $ | 41,383 | ​ | $ | 52,834 | ​ | $ | 171,728 |

- added (2020-05-08):
[0001104659-20-058660:note_history:7]
| Six months ended March 31, 2020 |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | Test | ​ | USG | ​ | Total |
| Customer type: |  | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| Commercial | ​ | $ | 93,417 | ​ | $ | 69,194 | ​ | $ | 95,971 | ​ | $ | 258,582 |
| U.S. Government | ​ |  | 79,218 | ​ | ​ | 13,789 | ​ | ​ | 631 | ​ |  | 93,638 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 82,983 | ​ | $ | 96,602 | ​ | $ | 352,220 |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |
| United States | ​ | $ | 146,164 | ​ | $ | 49,959 | ​ | $ | 63,665 | ​ | $ | 259,788 |
| International | ​ |  | 26,471 | ​ | ​ | 33,024 | ​ | ​ | 32,937 | ​ |  | 92,432 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 82,983 | ​ | $ | 96,602 | ​ | $ | 352,220 |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 82,897 | ​ | $ | 17,019 | ​ | $ | 72,524 | ​ | $ | 172,440 |
| Over time | ​ |  | 89,738 | ​ | ​ | 65,964 | ​ | ​ | 24,078 | ​ |  | 179,780 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 82,983 | ​ | $ | 96,602 | ​ | $ | 352,220 |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-08):
[0001104659-20-058660:note_history:8]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2020 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also include a reconciliation of the disaggregated revenue within each reportable segment on a continuing operations basis.
  (was, 2020-02-07, similarity 0.9575):
[0001104659-20-012461:note_history:8]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2019 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within each reportable segment on a continuing operations basis.

- changed (2020-05-08):
[0001104659-20-058660:note_history:9]
| Three months ended March 31, 2020 |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | Test | ​ | USG | ​ | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 51,550 | ​ | $ | 33,952 | ​ | $ | 43,736 | ​ | $ | 129,238 |
| U.S. Government | ​ |  | 43,574 | ​ | ​ | 7,648 | ​ | ​ | 32 | ​ |  | 51,254 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 41,600 | ​ | $ | 43,768 | ​ | $ | 180,492 |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |
| United States | ​ | $ | 81,458 | ​ | $ | 25,121 | ​ | $ | 28,706 | ​ | $ | 135,285 |
| International | ​ |  | 13,666 | ​ | ​ | 16,479 | ​ | ​ | 15,062 | ​ |  | 45,207 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 41,600 | ​ | $ | 43,768 | ​ | $ | 180,492 |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 46,610 | ​ | $ | 8,009 | ​ | $ | 32,209 | ​ | $ | 86,828 |
| Over time | ​ |  | 48,514 | ​ | ​ | 33,591 | ​ | ​ | 11,559 | ​ |  | 93,664 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 41,600 | ​ | $ | 43,768 | ​ | $ | 180,492 |
  (was, 2020-02-07, similarity 0.902):
[0001104659-20-012461:note_history:9]
| ​ |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | Test | ​ | USG | ​ | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 41,907 | ​ | $ | 35,249 | ​ | $ | 52,235 | ​ | $ | 129,391 |
| U.S. Government | ​ |  | 35,604 | ​ |  | 6,134 | ​ |  | 599 | ​ |  | 42,337 |
| Total revenues | ​ | $ | 77,511 | ​ | $ | 41,383 | ​ | $ | 52,834 | ​ | $ | 171,728 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 64,706 | ​ | $ | 24,837 | ​ | $ | 34,651 | ​ | $ | 124,194 |
| International | ​ |  | 12,805 | ​ |  | 16,546 | ​ |  | 18,183 | ​ |  | 47,534 |
| Total revenues | ​ | $ | 77,511 | ​ | $ | 41,383 | ​ | $ | 52,834 | ​ | $ | 171,728 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 35,761 | ​ | $ | 7,611 | ​ | $ | 40,315 | ​ | $ | 83,687 |
| Over time | ​ |  | 41,750 | ​ |  | 33,772 | ​ |  | 12,519 | ​ |  | 88,041 |
| Total revenues | ​ | $ | 77,511 | ​ | $ | 41,383 | ​ | $ | 52,834 | ​ | $ | 171,728 |

- added (2020-05-08):
[0001104659-20-058660:note_history:10]
| Six months ended March 31, 2020 |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | Test | ​ | USG | ​ | Total |
| Customer type: |  | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| Commercial | ​ | $ | 93,417 | ​ | $ | 69,194 | ​ | $ | 95,971 | ​ | $ | 258,582 |
| U.S. Government | ​ |  | 79,218 | ​ | ​ | 13,789 | ​ | ​ | 631 | ​ |  | 93,638 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 82,983 | ​ | $ | 96,602 | ​ | $ | 352,220 |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |
| United States | ​ | $ | 146,164 | ​ | $ | 49,959 | ​ | $ | 63,665 | ​ | $ | 259,788 |
| International | ​ |  | 26,471 | ​ | ​ | 33,024 | ​ | ​ | 32,937 | ​ |  | 92,432 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 82,983 | ​ | $ | 96,602 | ​ | $ | 352,220 |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 82,897 | ​ | $ | 17,019 | ​ | $ | 72,524 | ​ | $ | 172,440 |
| Over time | ​ |  | 89,738 | ​ | ​ | 65,964 | ​ | ​ | 24,078 | ​ |  | 179,780 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 82,983 | ​ | $ | 96,602 | ​ | $ | 352,220 |

- changed (2020-05-08):
[0001104659-20-058660:note_history:11]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At March 31, 2020, the Company had $565 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 68% in the next twelve months.
  (was, 2020-02-07, similarity 0.9907):
[0001104659-20-012461:note_history:11]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At December 31, 2019, the Company had $500 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 76% in the next twelve months.

- changed (2020-05-08):
[0001104659-20-058660:note_history:12]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At March 31, 2020, contract assets and liabilities totaled $96.1 million and $95.4 million, respectively.  During the first six months of 2020, the Company recognized approximately $36.4 million in revenues that were included in the contract liabilities balance at the adoption date.
  (was, 2020-02-07, similarity 0.8639):
[0001104659-20-012461:note_history:12]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At December 31, 2019, contract assets and liabilities totaled $93.5 million and $84.8 million, respectively.  During the first quarter of 2020, the Company recognized approximately $26 million in revenues that were included in the contract liabilities balance at the adoption date.
