# ESE MD&A — 0001104659-20-058660


## mdna

[0001104659-20-058660:mdna:1]
[same as prior period, unchanged from 0001104659-20-012461:mdna:1]

[0001104659-20-058660:mdna:2]
COVID-19 TRENDS AND UNCERTAINTIES

[0001104659-20-058660:mdna:3]
The COVID-19 global pandemic has created significant and unprecedented challenges, and during these highly uncertain times, our top priority remains the health and safety of our employees, customers and suppliers, thereby securing the financial well-being of the Company and supporting business continuity. Our businesses have been deemed essential and are currently operational, supplying our customers with vital and necessary products. To date our global supply chains have not been materially affected by the global pandemic. Given our diverse portfolio of strong, durable businesses serving non-discretionary end-markets, the strength and resilience of our business model positions us to continue to support our long-term outlook.

[0001104659-20-058660:mdna:4]
Recognizing the uncertainty presented by this global pandemic, we are suspending our full-year 2020 financial guidance. Our businesses are facing varying levels of pressure depending on the markets they serve as outlined below and the impact on our business cannot be reasonably estimated at this time. In response to COVID-19, we have taken decisive actions to enhance our financial condition, while continuing to execute our long-term strategy for profitable growth. Some of the actions we have taken include: deferring a portion of executive compensation, reducing discretionary spending, minimizing capital spending, implementing hiring and salary freezes, and increasing our focus on optimizing free cash flow. These operational measures are prudent steps to maintain our liquidity and will help manage our financial flexibility as we work through near-term volatility. As of March 31, 2020, we had nearly $700 million of liquidity, with $100 million in cash, net debt of approximately $50 million. Additionally, we have no debt maturities nor repayment obligations coming due and payable until September 2024. The Company has made no changes to its dividend plan. We are also monitoring the impacts of COVID-19 on the fair value of assets. We do not currently anticipate any material impairments on assets as a result of COVID-19. A portion of our workforce has worked from home at times due to COVID-19, however we have not had to redesign or design new internal controls over financial reporting at this time. Depending on the duration of COVID-19, it may become necessary for us to redesign or design new internal controls over financial reporting in a future period. We do not believe such an event will have a material impact on our business. Further details by operating segment are outlined below.

[0001104659-20-058660:mdna:5]
In our A&D segment, we expect to see a slowdown in commercial aerospace deliveries and revenues over the remainder of the year but it is too early in the cycle to determine the impact from the current industry downturn as it relates to future build rates and airline passenger miles. The defense portion of A&D, both military aerospace and navy products is expected to remain in-line with current forecasts given its backlog coupled with the timing of expected platform deliveries. We had a temporary two-week shutdown in April of our Globe manufacturing facility due to a confirmed COVID-19 case but we are fully operational as of the current date.

[0001104659-20-058660:mdna:6]
In our Test segment, our second quarter revenues were negatively impacted by a decrease of approximately $2 million due to the China facility’s temporary three-week shutdown in February, and delayed timing of installation projects caused by access limitations to customer sites due to COVID-19. We expect the Test segment to remain in-line with current forecasts over the remainder of the year given the strength of its backlog and its served markets, primarily related to new communications technologies such as 5G.

[0001104659-20-058660:mdna:7]
In our USG segment, our second quarter revenues were negatively impacted by approximately $5 million as several utility customers deferred purchase orders and maintenance-related project deliveries so they could divert resources to other issues such as critical power delivery given their concerns around COVID-19. Additionally, Doble’s service business is largely on hold during the pandemic. We expect USG’s customer spending softness to continue for the next few months before the utilities return to a more normal state of business in the later part of this fiscal year.

[0001104659-20-058660:mdna:8]
See the “Outlook” and “Part II – Other Information, Item 1A, Risk Factors” sections below for additional details.

[0001104659-20-058660:mdna:9]
[same as prior period, unchanged from 0001104659-20-012461:mdna:2]

[0001104659-20-058660:mdna:10]
References to the second quarters of 2020 and 2019 represent the three-month periods ended March 31, 2020 and 2019, respectively.

[0001104659-20-058660:mdna:11]
[same as prior period, unchanged from 0001104659-20-012461:mdna:4]

[0001104659-20-058660:mdna:12]
In the second quarter of 2020, sales, net earnings and diluted earnings per share from continuing operations were $180.5 million, $17.8 million and $0.68 per share, respectively, compared to $171.2 million, $17.8 million and $0.68 per share, respectively, in the second quarter of 2019. In the first six months of 2020, sales, net earnings and diluted earnings per share were $352.2 million, $28.6 million and $1.09, respectively, compared to $334.6 million, $35.2 million and $1.34 per share, respectively, in the first six months of 2019. The decrease in net earnings and diluted earnings per share in the first six months of 2020 as compared to the first six months of 2019 was mainly due the gain of approximately $8 million on the sale of the Doble Watertown property in the first quarter of 2019.

[0001104659-20-058660:mdna:13]
[same as prior period, unchanged from 0001104659-20-012461:mdna:6]

[0001104659-20-058660:mdna:14]
In the second quarter of 2020, net sales of $180.5 million were $9.3 million, or 5.4%, higher than the $171.2 million in the second quarter of 2019. In the first six months of 2020, net sales of $352.2 million were $17.6 million, or 5.3%, higher than the $334.6 million in the first six months of 2019. The increase in net sales in the second quarter of 2020 as compared to the second quarter of 2019 was due to a $15.6 million increase in the Aerospace & Defense segment, partially offset by a $1.2 million decrease in the Test segment and a $5.1 million decrease in the USG segment. The increase in net sales in the first six months of 2020 as compared to the first six months of 2019 was due to a $26.9 million increase in the Aerospace & Defense segment, partially offset by a $1.1 million decrease in the Test segment and an $8.2 million decrease in the USG segment.

[0001104659-20-058660:mdna:15]
[same as prior period, unchanged from 0001104659-20-012461:mdna:8]

[0001104659-20-058660:mdna:16]
In the second quarter of 2020, net sales of $95.1 million were $15.6 million, or 19.6%, higher than the $79.5 million in the second quarter of 2019. In the first six months of 2020, net sales of $172.6 million were $26.9 million, or 18.5%, higher than the $145.7 million in the first six months of 2019. The sales increase in the second quarter of 2020 compared to the second quarter of 2019 was mainly due to the addition of $9.0 million in net sales from Globe, a $3.8 million increase in net sales at VACCO due to increased revenue from space products, a $2.6 million increase in net sales at PTI due to higher aerospace assembly shipments, a $0.5 million increase in net sales at Mayday, and a $0.4 million increase in net sales at Crissair, partially offset by a $0.7 million decrease in net sales at Westland due to timing of revenue on government programs. The sales increase in the first six months of 2020 compared to the first six months of 2019 was due to the addition of $17.8 million in net sales from Globe, a $5.3 million increase in net sales at VACCO due to increased revenue from space products, a $4.0 million increase in net sales at PTI due to higher aerospace assembly shipments, a $0.6 million increase in net sales at Mayday, and a $1.2 million increase in net sales at Crissair, partially offset by a $2.0 million decrease in net sales at Westland due to timing of revenue on government programs.

[0001104659-20-058660:mdna:17]
[same as prior period, unchanged from 0001104659-20-012461:mdna:10]

[0001104659-20-058660:mdna:18]
In the second quarter of 2020, net sales of $41.6 million were $1.3 million, or 3.0%, lower than the $42.9 million in the second quarter of 2019. In the first six months of 2020, net sales of $83.0 million were $1.2 million, or 1.4%, lower than the $84.2 million in the first six months of 2019. The decrease in the second quarter and first six months of 2020 compared to the corresponding periods of 2019 was primarily due to lower sales from the segment’s Asian operations due to the temporary three-week shutdown of the China facility due to COVID-19 and the timing of test and measurement chamber projects.

[0001104659-20-058660:mdna:19]
[same as prior period, unchanged from 0001104659-20-012461:mdna:12]

[0001104659-20-058660:mdna:20]
In the second quarter of 2020, net sales of $43.8 million were $5.1 million, or 10.4% lower than the $48.9 million in the second quarter of 2019. In the first six months of 2020, net sales of $96.6 million were $8.1 million, or 7.7%, lower than the $104.7 million in the first six months of 2019. The decrease in the second quarter and first six months of 2020 compared to the corresponding periods of 2019 was mainly due to lower product and software sales at Doble primarily driven by the impact of COVID-19 as customers delayed orders and on-site testing.

[0001104659-20-058660:mdna:21]
[same as prior period, unchanged from 0001104659-20-012461:mdna:14]

[0001104659-20-058660:mdna:22]
Backlog from continuing operations was $565.4 million at March 31, 2020 compared with $451.6 million at September 30, 2019. The Company received new orders totaling $245.6 million in the second quarter of 2020 compared to $209.4 million in the second quarter of 2019. Of the new orders received in the second quarter of 2020, $156.0 million related to Aerospace & Defense products, $41.8 million related to Test products, and $47.8 million related to USG products. Of the new orders received in the second quarter of 2019, $100.8 million related to Aerospace & Defense products, $57.6 million related to Test products, and $51.0 million related to USG products.

[0001104659-20-058660:mdna:23]
The Company received new orders totaling $466.1 million in the first six months of 2020 compared to $390.5 million in the first six months of 2019. Of the new orders received in the first six months of 2020, $285.0 million related to Aerospace & Defense products, $80.3 million related to Test products, and $100.8 million related to USG products. Of the new orders received in the first six months of 2019, $184.5 million related to Aerospace & Defense products, $103.0 million related to Test products, and $103.0 million related to USG products.

[0001104659-20-058660:mdna:24]
[same as prior period, unchanged from 0001104659-20-012461:mdna:16]

[0001104659-20-058660:mdna:25]
Selling, general and administrative (SG&A) expenses from continuing operations for the second quarter of 2020 were $40.0 million (22.2% of net sales), compared with $39.3 million (23.0% of net sales) for the second quarter of 2019. For the first six months of 2020, SG&A expenses were $82.1 million (23.3% of net sales) compared to $77.9 million (23.3% of net sales) for the first six months of 2019. The increase in SG&A in the second quarter and first six months of 2020 compared to the corresponding periods of 2019 was mainly due to the addition of Globe and higher spending on R&D / new product development.

[0001104659-20-058660:mdna:26]
[same as prior period, unchanged from 0001104659-20-012461:mdna:18]

[0001104659-20-058660:mdna:27]
Amortization of intangible assets from continuing operations was $5.2 million and $11.0 million for the second quarter and first six months of 2020, respectively, compared to $4.4 million and $8.8 million for the corresponding periods of 2019. Amortization expenses consist of amortization of acquired intangible assets from acquisitions and other identifiable intangible assets (primarily software). The increase in amortization expense in the second quarter and first six months of 2020 compared to the corresponding periods of 2019 was mainly due to an increase in amortization of intangible assets related to the Globe acquisition and an increase in amortization of capitalized software at Doble.

[0001104659-20-058660:mdna:28]
OTHER EXPENSES (INCOME), NET

[0001104659-20-058660:mdna:29]
Other expenses, net, was $0.7 million in the second quarter of 2020 compared to other expenses, net, of $2.0 million in the second quarter of 2019. There were no individually significant items in other expenses (income), net, in the second quarter of 2020. The principal component of other expenses, net, in the second quarter of 2019 was $0.9 million of restructuring charges related to the consolidation of VACCO’s aircraft/aerospace business into PTI’s aerospace facility in Oxnard, California and the completion of other restructuring activities begun in 2018; and losses on derivative instruments.

[0001104659-20-058660:mdna:30]
Other expenses, net, was $1.0 million in the first six months of 2020 compared to other income, net, of $5.4 million in the first six months of 2019. The principal component of other expenses, net, in the first six months of 2020 were losses on derivative instruments of $0.8 million. The principal component of other income, net, in the first six months of 2019 was a gain of approximately $8 million on the sale of the Doble Watertown, MA building and land, partially offset by certain restructuring activities at Doble, PTI and VACCO and losses on derivative instruments.

[0001104659-20-058660:mdna:31]
[same as prior period, unchanged from 0001104659-20-012461:mdna:22]

[0001104659-20-058660:mdna:32]
The Company evaluates the performance of its operating segments based on EBIT, and provides EBIT on a consolidated basis, which is a non-GAAP financial measure. Please refer to the discussion of non-GAAP financial measures in Note 8 to the Consolidated Financial Statements, above. EBIT was $21.3 million (11.8% of net sales) for the second quarter of 2020 compared to $22.0 million (12.8% of net sales) for the second quarter of 2019. For the first six months of 2020, EBIT was $38.1 million (10.8% of net sales) compared to $47.3 million (14.1% of net sales) for the first six months of 2019.

[0001104659-20-058660:mdna:33]
[same as prior period, unchanged from 0001104659-20-012461:mdna:24]

[0001104659-20-058660:mdna:34]
| ​ | ​ | Three Months Ended | ​ | Six Months Ended |
| ​ | ​ | March 31, | ​ | March 31, |
| (In thousands) |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Consolidated EBIT | ​ | $ | 21,345 | ​ | ​ | 21,976 | ​ | 38,136 | ​ | 47,326 |
| Less: Interest expense, net | ​ |  | (1,320) |  | ​ | (1,853) |  | (3,741) |  | (3,708) |
| Less: Income tax | ​ |  | (2,203) |  |  | (2,301) |  | (5,809) |  | (8,446) |
| Net earnings from continuing operations | ​ | $ | 17,822 |  | ​ | 17,822 |  | 28,586 |  | 35,172 |

[0001104659-20-058660:mdna:35]
[same as prior period, unchanged from 0001104659-20-012461:mdna:26]

[0001104659-20-058660:mdna:36]
EBIT in the second quarter of 2020 was $21.7 million (22.8% of net sales) compared to $17.4 million (21.9% of net sales) in the second quarter of 2019. EBIT in the first six months of 2020 was $34.2 million (19.8% of net sales) compared to $28.1 million (19.3% of net sales) in the first six months of 2019.  The increase in EBIT in the second quarter of 2020 compared to the second quarter of 2019 was mainly due to the $2.4 million contribution from Globe, and a $1.0 million increase at PTI and a $0.7 million increase at VACCO both due to higher sales volumes. The increase in EBIT in the first six months of 2020 compared to the first six months of 2019 was mainly due to the $4.6 million contribution from Globe and a $1.6 million increase at PTI due to higher sales volumes.

[0001104659-20-058660:mdna:37]
[same as prior period, unchanged from 0001104659-20-012461:mdna:28]

[0001104659-20-058660:mdna:38]
EBIT in the second quarter of 2020 was $5.7 million (13.6% of net sales) compared to $5.6 million (13.0% of net sales) in the second quarter of 2019. EBIT in the first six months of 2020 was $10.3 million (12.4% of net sales) compared to $8.9 million (10.6% of net sales) in the first six months of 2019. The increase in EBIT in the second quarter and first six months of 2020 compared to the corresponding periods of 2019 was primarily due to product mix and higher margins on projects mainly from the segment’s U.S. operations.

[0001104659-20-058660:mdna:39]
[same as prior period, unchanged from 0001104659-20-012461:mdna:30]

[0001104659-20-058660:mdna:40]
EBIT in the second quarter of 2020 was $4.9 million (11.1% of net sales) compared to $8.8 million (17.9% of net sales) in the second quarter of 2019. EBIT in the first six months of 2020 was $14.2 million (14.7% of net sales) compared to $30.3 million (28.9% of net sales) in the first six months of 2019. The decrease in EBIT in the second quarter of 2020 compared to the second quarter of 2019 was mainly due to a decrease in EBIT from Doble due to lower sales volumes of higher margin products and software mentioned above and the timing of their annual Client conference (second quarter of 2020 versus third quarter of 2019).   The decrease in EBIT in the first six months of 2020 as compared to the first six months of 2019 was mainly due to the gain on sale of the Doble Watertown facility of approximately $8 million in the first quarter of 2019 as well as a decrease in EBIT from Doble due to lower sales volumes in the first six months of 2020. In addition, EBIT in the first quarter of 2020 was negatively impacted by approximately $0.6 million of facility move costs at Doble.

[0001104659-20-058660:mdna:41]
[same as prior period, unchanged from 0001104659-20-012461:mdna:32]

[0001104659-20-058660:mdna:42]
Corporate costs included in EBIT were $10.9 million and $20.6 million in the second quarter and first six months of 2020, respectively, compared to $9.8 million and $19.9 million in the corresponding periods of 2019. The increase in Corporate costs in the second quarter and first six months of 2020 compared to the corresponding periods of 2019 was mainly due to losses on derivative instruments of $0.8 million recorded in the first six months of 2020.

[0001104659-20-058660:mdna:43]
[same as prior period, unchanged from 0001104659-20-012461:mdna:34]

[0001104659-20-058660:mdna:44]
Interest expense was $1.3 million and $3.7 million in the second quarter and first six months of 2020, respectively, and $1.9 million and $3.7 million in the corresponding periods of 2019. The decrease in interest expense in the second quarter of 2020 as compared to the second quarter of 2019 was mainly due to lower average outstanding borrowings ($150 million compared to $217 million) at relatively consistent average interest rates of 3.2%.

[0001104659-20-058660:mdna:45]
[same as prior period, unchanged from 0001104659-20-012461:mdna:36]

[0001104659-20-058660:mdna:46]
The second quarter 2020 effective income tax rate from continuing operations was 11.0% compared to 11.4% in the second quarter of 2019. The effective income tax rate in the first six months of 2020 was 16.9% compared to 19.4% for the first six months of 2019. The income tax expense in the second quarter of 2020 was favorably impacted by the release of a valuation allowance of $2.8 million for foreign net operating losses decreasing the second quarter and year-to-date effective tax rate by 14.3% and 8.2%, respectively. The income tax expense in the second quarter and first six months of 2019 was favorably impacted by tax planning strategies to increase the foreign tax credits claimed retrospectively. The Company reduced the valuation allowance for excess foreign tax credits by $2.3 million and recorded an amended return receivable of $0.2 million, which favorably impacted the 2019 second quarter and year-to-date effective tax rate by 12.9% and 5.9%, respectively.

[0001104659-20-058660:mdna:47]
[same as prior period, unchanged from 0001104659-20-012461:mdna:38]

[0001104659-20-058660:mdna:48]
The Company’s overall financial position and liquidity remains strong. The effects of COVID-19 have not materially affected liquidity. Working capital from continuing operations (current assets less current liabilities) increased to $260.6 million at March 31, 2020 from $229.8 million at September 30, 2019. Inventories increased by $16.1 million during this period due to a $10.0 million increase within the Aerospace & Defense segment, a $3.2 million increase within the Test segment and a $2.9 million increase within the USG segment, resulting primarily from the timing of receipt of raw materials and work-in-process due to timing of projects.

[0001104659-20-058660:mdna:49]
Net cash provided by operating activities from continuing operations was $36.7 million and $10.5 million in the first six months of 2020 and 2019, respectively. The increase in net cash provided by operating activities from continuing operations in the first six months of 2020 as compared to the first six months of 2019 was driven by lower working capital requirements.

[0001104659-20-058660:mdna:50]
Capital expenditures from continuing operations were $21.2 million and $10.1 million in the first six months of 2020 and 2019, respectively. The increase in the first six months of 2020 was mainly due to the building improvement additions at the new Doble headquarters facility of approximately $7 million and a $2.7 million increase in capital expenditures at VACCO primarily for construction of a new parking lot and certain machinery and equipment. In addition, the Company incurred expenditures for capitalized software of $4.3 million and $4.5 million in the first six months of 2020 and 2019, respectively.

[0001104659-20-058660:mdna:51]
Credit Facility

[0001104659-20-058660:mdna:52]
At March 31, 2020, the Company had approximately $341 million available to borrow under its bank credit facility, a $250 million increase option subject to lender approval, and $100.2 million cash on hand. At March 31, 2020, the Company had $150 million of outstanding borrowings under the credit facility in addition to outstanding letters of credit of $9.8 million. Cash flow from operations and borrowings under the Company’s credit facility are expected to meet the Company’s capital requirements and operational needs for the foreseeable future. The Company’s ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.

[0001104659-20-058660:mdna:53]
[same as prior period, unchanged from 0001104659-20-012461:mdna:44]

[0001104659-20-058660:mdna:54]
A dividend of $0.08 per share, totaling $2.1 million, was paid on January 17, 2020 to stockholders of record as of January 2, 2020. Subsequent to March 31, 2020, a quarterly dividend of $0.08 per share, totaling $2.1 million, was paid on April 17, 2020 to stockholders of record as of April 2, 2020.

[0001104659-20-058660:mdna:55]
[same as prior period, unchanged from 0001104659-20-012461:mdna:46]

[0001104659-20-058660:mdna:56]
During the second quarter of 2020, business disruptions related to the COVID-19 pandemic began to affect the Company’s operations. Given the considerable uncertainty around the extent and duration of these economic circumstances, it is difficult to predict how our future operations will be affected using our normal forecasting methodologies, therefore, the Company is suspending its previously issued fiscal year 2020 guidance.

[0001104659-20-058660:mdna:57]
[same as prior period, unchanged from 0001104659-20-012461:mdna:48]

[0001104659-20-058660:mdna:58]
[same as prior period, unchanged from 0001104659-20-012461:mdna:49]

[0001104659-20-058660:mdna:59]
[same as prior period, unchanged from 0001104659-20-012461:mdna:50]

[0001104659-20-058660:mdna:60]
Contingencies

[0001104659-20-058660:mdna:61]
As a normal incident of the business in which the Company is engaged, various claims, charges and litigation are asserted or commenced against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. In the opinion of Management, the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company, are adequately reserved, are covered by insurance, or would not have a material adverse effect on the Company’s results from operations, capital expenditures, or competitive position.

[0001104659-20-058660:mdna:62]
[same as prior period, unchanged from 0001104659-20-012461:mdna:53]

[0001104659-20-058660:mdna:63]
Investors are cautioned that such statements are only predictions and speak only as of the date of this Form 10-Q, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment, including but not limited to those described in Item 1A, “Risk Factors,” of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2019 and this Quarterly Report on Form 10-Q, and the following: the impact of the COVID-19 pandemic including labor shortages, facility closures, material shortages, transportation delays, termination or delays of Company contracts, the inability of our suppliers or customers to perform, and weakening of economic conditions in served markets; the impacts of natural disasters on the Company’s operations and those of the Company’s customers and suppliers; the timing and content of future contract awards or customer orders; the appropriation, allocation and availability of Government funds; the termination of Government and other customer contracts or orders; financial exposure in connection with the Company’s guarantee of a certain Aclara lease; weakening of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties; the availability of selected acquisitions; delivery delays or defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability of certain raw materials; labor disputes; changes in U.S. tax laws and regulations; other changes in laws and regulations including but not limited to changes in accounting standards and foreign taxation; changes in interest rates; costs relating to environmental matters arising from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the integration of recently acquired businesses.
