# ESE notes — 0001104659-20-058660


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001104659-20-058660:notes:1]
[same as prior period, unchanged from 0001104659-20-012461:notes:1]

[0001104659-20-058660:notes:2]
The accompanying consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP). For further information, refer to the consolidated financial statements and related notes included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2019. Certain 2019 amounts have been reclassified to conform with the 2020 presentation.

[0001104659-20-058660:notes:3]
The Company’s results for the three-month period ended March 31, 2020 are not necessarily indicative of the results for the entire 2020 fiscal year. References to the second quarters of 2020 and 2019 represent the fiscal quarters ended March 31, 2020 and 2019, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.

[0001104659-20-058660:notes:4]
[same as prior period, unchanged from 0001104659-20-012461:notes:4]


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001104659-20-058660:notes:5]
[same as prior period, unchanged from 0001104659-20-012461:notes:5]

[0001104659-20-058660:notes:6]
[same as prior period, unchanged from 0001104659-20-012461:notes:6]

[0001104659-20-058660:notes:7]
Net sales from the Technical Packaging business were zero and $16.5 million in the second quarter and first six months of 2020, respectively, compared to $22.7 million and $41.9 million in the corresponding periods of 2019. The Company received net proceeds from the sale of approximately $184 million and recorded a $76.6 million after-tax gain on the sale in the first quarter of 2020. The Company expects to finalize the working capital adjustment during the third quarter of 2020.

[0001104659-20-058660:notes:8]
[same as prior period, unchanged from 0001104659-20-012461:notes:8]

[0001104659-20-058660:notes:9]
| ​ |  | September 30, 2019 |
| Assets: | ​ |  |  |
| Accounts receivable, net |  | $ | 15.7 |
| Contract assets, net | ​ |  | 5.1 |
| Inventories | ​ |  | 3.9 |
| Other current assets | ​ |  | 0.6 |
| Current assets | ​ |  | 25.3 |
| Property, plant & equipment, net | ​ |  | 33.6 |
| Intangible assets, net | ​ |  | 11.4 |
| Goodwill | ​ |  | 19.0 |
| Other assets | ​ |  | 3.4 |
| Total assets |  | $ | 92.7 |
| Liabilities: | ​ |  | ​ |
| Accounts payable |  | $ | 7.6 |
| Accrued expenses and other current liabilities | ​ |  | 3.9 |
| Current liabilities | ​ |  | 11.5 |
| Other liabilities | ​ |  | 4.0 |
| Total liabilities |  | $ | 15.5 |


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001104659-20-058660:notes:10]
3.    ACCOUNTING STANDARDS UPDATE

[0001104659-20-058660:notes:11]
In February 2016, the FASB issued ASU No. 2016-062, "Leases" (ASU 2016-062) which supersedes ASC 840, "Leases" and creates a new topic, ASC 842, "Leases." Subsequent to the issuance of ASU 2016-062, ASC 842 was amended by various updates that amend and clarify the impact and implementation of the aforementioned update. Effective October 1, 2019, the Company adopted these updates using the optional transition method. These updates require lessees to recognize a lease liability and a lease asset for all leases, including operating leases, with a term greater than 12 months on its balance sheet. Upon initial application, the provisions of these updates are required to be applied using the modified retrospective method, which requires retrospective adoption to each prior reporting period presented with the cumulative effect of adoption recorded to the earliest reporting period presented. An optional transition method can be utilized which requires retrospective adoption beginning on the date of adoption with the cumulative effect of initially applying these updates recognized at the date of initial adoption. The standard also provided several optional practical expedients for use in transition. The Company elected to use what the FASB has deemed the “package of practical expedients,” which allowed the Company not to reassess previous conclusions regarding lease identification, lease classification and the accounting treatment for initial direct costs. These updates also expand the required quantitative and qualitative disclosures surrounding leases. The adoption resulted in the addition of "right of use" assets and lease liabilities of approximately $20 million in the consolidated balance sheet, with no significant change to the Company’s consolidated statements of operations or cash flows. Refer to Note 16 for further discussion.


## us-gaap:EarningsPerShareTextBlock

[0001104659-20-058660:notes:12]
[same as prior period, unchanged from 0001104659-20-012461:notes:12]

[0001104659-20-058660:notes:13]
[same as prior period, unchanged from 0001104659-20-012461:notes:13]

[0001104659-20-058660:notes:14]
| ​ | ​ | Three Months | ​ | Six Months |
| ​ | ​ | Ended March 31, | ​ | Ended March 31, |
| ​ |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Weighted Average Shares Outstanding - Basic | ​ | 25,988 | ​ | 25,918 | ​ | 25,985 | ​ | 25,915 |
| Dilutive Options and Restricted Shares |  | 100 |  | 118 |  | 141 |  | 163 |
| Adjusted Shares - Diluted |  | 26,088 |  | 26,036 |  | 26,126 |  | 26,078 |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001104659-20-058660:notes:15]
[same as prior period, unchanged from 0001104659-20-012461:notes:15]

[0001104659-20-058660:notes:16]
[same as prior period, unchanged from 0001104659-20-012461:notes:16]

[0001104659-20-058660:notes:17]
[same as prior period, unchanged from 0001104659-20-012461:notes:17]

[0001104659-20-058660:notes:18]
Compensation expense related to the restricted share awards was $1.1 million and $2.3 million for the three and six-month periods ended March 31, 2020, respectively, and $0.9 million and $2.0 million for the corresponding periods in 2019. There were 175,577 non-vested shares outstanding as of March 31, 2020.

[0001104659-20-058660:notes:19]
[same as prior period, unchanged from 0001104659-20-012461:notes:19]

[0001104659-20-058660:notes:20]
Compensation expense related to the non-employee director grants was $0.3 million and $0.6 million for the three and six-month periods ended March 31, 2020, respectively, and $0.3 million and $0.5 million for the corresponding periods in 2019.

[0001104659-20-058660:notes:21]
The total share-based compensation cost that has been recognized in the results of operations and included within selling, general and administrative expenses (SG&A) was $1.5 million and $2.9 million for the three and six-month periods ended March 31, 2020, respectively, and $1.2 million and $2.6 million for the corresponding periods in 2019. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $0.3 million and $0.7 million for the three and six-month periods ended March 31, 2020, respectively, and $0.3 million and $0.6 million for the corresponding periods in 2019. As of March 31, 2020, there was $6.8 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a remaining weighted-average period of 2.1 years.


## us-gaap:InventoryDisclosureTextBlock

[0001104659-20-058660:notes:22]
[same as prior period, unchanged from 0001104659-20-012461:notes:22]

[0001104659-20-058660:notes:23]
[same as prior period, unchanged from 0001104659-20-012461:notes:23]

[0001104659-20-058660:notes:24]
| ​ | ​ | March 31, | ​ | September 30, |
| (In thousands) |  | 2020 |  | 2019 |
| Finished goods | ​ | $ | 23,898 | ​ | ​ | 23,550 |
| Work in process | ​ |  | 39,768 | ​ | ​ | 26,407 |
| Raw materials | ​ |  | 77,361 | ​ | ​ | 74,999 |
| Total inventories | ​ | $ | 141,027 | ​ | ​ | 124,956 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001104659-20-058660:notes:25]
[same as prior period, unchanged from 0001104659-20-012461:notes:25]

[0001104659-20-058660:notes:26]
Included on the Company’s Consolidated Balance Sheets at March 31, 2020 and September 30, 2019 are the following intangible assets gross carrying amounts and accumulated amortization from continuing operations:

[0001104659-20-058660:notes:27]
| ​ | ​ | March 31, | ​ | September 30, |
| (Dollars in thousands) |  | 2020 |  | 2019 |
| Goodwill | ​ | $ | 389,630 | ​ | ​ | 390,256 |
| Intangible assets with determinable lives: | ​ |  | ​ | ​ | ​ | ​ |
| Patents | ​ |  | ​ | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 2,067 | ​ | ​ | 1,945 |
| Less: accumulated amortization | ​ |  | 806 | ​ | ​ | 748 |
| Net | ​ | $ | 1,261 | ​ | ​ | 1,197 |
| Capitalized software | ​ |  | ​ | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 83,243 | ​ | ​ | 78,962 |
| Less: accumulated amortization | ​ |  | 53,034 | ​ | ​ | 48,530 |
| Net | ​ | $ | 30,209 | ​ | ​ | 30,432 |
| Customer relationships | ​ |  | ​ | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 226,946 | ​ | ​ | 227,225 |
| Less: accumulated amortization | ​ |  | 61,486 | ​ | ​ | 55,326 |
| Net | ​ | $ | 165,460 | ​ | ​ | 171,899 |
| Other | ​ |  | ​ | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 5,081 | ​ | ​ | 5,441 |
| Less: accumulated amortization | ​ |  | 2,953 | ​ | ​ | 2,645 |
| Net | ​ | $ | 2,128 | ​ | ​ | 2,796 |
| Intangible assets with indefinite lives: | ​ |  | ​ | ​ | ​ | ​ |
| Trade names | ​ | $ | 172,721 | ​ | ​ | 175,281 |

[0001104659-20-058660:notes:28]
The changes in the carrying amount of goodwill attributable to each business segment for the six months ended March 31, 2020 is as follows on a continuing operations basis:

[0001104659-20-058660:notes:29]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | Aerospace | ​ | ​ | ​ |
| (Dollars in millions) |  | USG |  | Test |  | & Defense |  | Total |
| Balance as of September 30, 2019 |  | ​ | 254.0 |  | ​ | 34.1 |  | ​ | 102.2 |  | ​ | 390.3 |
| Foreign currency translation |  | ​ | (0.6) | ​ | ​ | (0.1) | ​ | ​ | — | ​ | ​ | (0.7) |
| Balance as of March 31, 2020 | ​ | $ | 253.4 | ​ | ​ | 34.0 | ​ | ​ | 102.2 | ​ | ​ | 389.6 |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001104659-20-058660:notes:30]
[same as prior period, unchanged from 0001104659-20-012461:notes:30]

[0001104659-20-058660:notes:31]
[same as prior period, unchanged from 0001104659-20-012461:notes:31]

[0001104659-20-058660:notes:32]
[same as prior period, unchanged from 0001104659-20-012461:notes:32]

[0001104659-20-058660:notes:33]
| ​ | ​ | Three Months | ​ | Six Months |
| ​ | ​ | Ended March 31, | ​ | Ended September 30, |
| (In thousands) |  | 2020 |  | 2019 |  | 2020 | 2019 |
| NET SALES |  | ​ |  |  | ​ |  |  |  |  |  |
| Aerospace & Defense | ​ | $ | 95,124 |  | ​ | 79,478 |  | 172,635 |  | 145,702 |
| Test | ​ |  | 41,600 |  | ​ | 42,875 |  | 82,983 |  | 84,161 |
| USG | ​ |  | 43,768 |  | ​ | 48,890 |  | 96,602 |  | 104,745 |
| Consolidated totals | ​ | $ | 180,492 |  | ​ | 171,243 |  | 352,220 |  | 334,608 |
| EBIT | ​ |  | ​ |  | ​ | ​ |  | ​ |  | ​ |
| Aerospace & Defense | ​ | $ | 21,736 |  | ​ | 17,443 |  | 34,249 |  | 28,053 |
| Test | ​ |  | 5,651 |  | ​ | 5,554 |  | 10,307 |  | 8,864 |
| USG | ​ |  | 4,866 |  | ​ | 8,767 |  | 14,153 |  | 30,313 |
| Corporate (loss) | ​ |  | (10,908) |  |  | (9,788) |  | (20,573) |  | (19,904) |
| Consolidated EBIT | ​ |  | 21,345 |  | ​ | 21,976 |  | 38,136 |  | 47,326 |
| Less: Interest expense | ​ |  | (1,320) |  |  | (1,853) |  | (3,741) |  | (3,708) |
| Earnings before income taxes | ​ | $ | 20,025 |  | ​ | 20,123 |  | 34,395 |  | 43,618 |

[0001104659-20-058660:notes:34]
[same as prior period, unchanged from 0001104659-20-012461:notes:34]

[0001104659-20-058660:notes:35]
[same as prior period, unchanged from 0001104659-20-012461:notes:35]

[0001104659-20-058660:notes:36]
[same as prior period, unchanged from 0001104659-20-012461:notes:36]


## us-gaap:DebtDisclosureTextBlock

[0001104659-20-058660:notes:37]
9.    DEBT

[0001104659-20-058660:notes:38]
The Company’s debt is summarized as follows:

[0001104659-20-058660:notes:39]
| ​ | ​ | March 31, | ​ | September 30, |
| (In thousands) |  | 2020 |  | 2019 |
| Total borrowings | ​ | $ | 150,000 |  | ​ | 285,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 130,000 |  | ​ | 265,000 |

[0001104659-20-058660:notes:40]
On September 27, 2019, the Company entered into a new five-year credit facility (“the Credit Facility”), modifying its previous credit facility which would have matured December 21, 2020. The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024.

[0001104659-20-058660:notes:41]
At March 31, 2020, the Company had approximately $341 million available to borrow under the Credit Facility, plus the $250 million increase option, subject to lender approval, in addition to $100.2 million cash on hand. The Company classified $20.0 million as the current portion of long-term debt as of March 31, 2020, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $9.8 million at March 31, 2020.

[0001104659-20-058660:notes:42]
Interest on borrowings under the Credit Facility is calculated at a spread over either the London Interbank Offered Rate (LIBOR ), the New York Federal Reserve Bank Rate or the prime rate, depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The Credit Facility is secured by the unlimited guaranty of the Company’s direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of its direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 3.24% and 3.21% for the three and  six-month periods ending March 31, 2020, respectively , and 3.20% and 3.23% for the three and six-month periods ending March 31, 2019. As of March 31, 2020, the Company was in compliance with all covenants.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001104659-20-058660:notes:43]
[same as prior period, unchanged from 0001104659-20-012461:notes:43]

[0001104659-20-058660:notes:44]
The second quarter 2020 effective income tax rate from continuing operations was 11.0% compared to 11.4% in the second quarter of 2019. The effective income tax rate in the first six months of 2020 was 16.9% compared to 19.4% for the first six months of 2019. The income tax expense in the second quarter of 2020 was favorably impacted by the release of a valuation allowance of $2.8 million for foreign net operating losses decreasing the second quarter and year-to-date effective tax rate by 14.3% and 8.2%, respectively. The income tax expense in the second quarter and first six months of 2019 was favorably impacted by tax planning strategies to increase the foreign tax credits claimed retrospectively. The Company reduced the valuation allowance for excess foreign tax credits by $2.3 million and recorded an amended return receivable of $0.2 million, which favorably impacted the 2019 second quarter and year-to-date effective tax rate by 12.9% and 5.9%, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001104659-20-058660:notes:45]
11.  SHAREHOLDERS’ EQUITY

[0001104659-20-058660:notes:46]
The change in shareholders’ equity for the first three and six months of 2020 and 2019 is shown below (in thousands):

[0001104659-20-058660:notes:47]
| ​ | ​ | Three Months Ended March 31, | ​ | Six Months Ended March 31, |
| ​ |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Common stock | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 306 | ​ | 305 | ​ | 306 | ​ | 305 |
| Stock plans | ​ | — | ​ | — | ​ | — | ​ | — |
| Ending balance | ​ | 306 | ​ | 305 | ​ | 306 | ​ | 305 |
| Additional paid-in-capital | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 293,056 | ​ | 292,293 | ​ | 292,408 | ​ | 291,190 |
| Stock plans | ​ | 1,731 | ​ | 1,319 | ​ | 2,379 | ​ | 2,422 |
| Ending balance | ​ | 294,787 | ​ | 293,612 | ​ | 294,787 | ​ | 293,612 |
| Retained earnings | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 769,439 | ​ | 627,670 | ​ | 684,741 | ​ | 606,837 |
| Net earnings common stockholders | ​ | 17,822 | ​ | 18,797 | ​ | 104,599 | ​ | 36,114 |
| Dividends paid | ​ | (2,077) | ​ | (2,074) | ​ | (4,156) | ​ | (4,147) |
| Adoption of accounting standards updates | ​ | — | ​ | (1,375) | ​ | — | ​ | 4,214 |
| Ending balance | ​ | 785,184 | ​ | 643,018 | ​ | 785,184 | ​ | 643,018 |
| Accumulated other comprehensive income (loss) | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | (40,051) | ​ | (36,083) | ​ | (43,974) | ​ | (31,528) |
| Foreign currency translation | ​ | (6,885) | ​ | 677 | ​ | (2,962) | ​ | (3,853) |
| Pension | ​ | — | ​ | — | ​ | — | ​ | — |
| Forward exchange contracts | ​ | — | ​ | 126 | ​ | — | ​ | 101 |
| Ending balance | ​ | (46,936) | ​ | (35,280) | ​ | (46,936) | ​ | (35,280) |
| Treasury stock | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | (107,259) | ​ | (107,394) | ​ | (107,259) | ​ | (107,394) |
| Issued under stock plans | ​ | 125 | ​ | 135 | ​ | 125 | ​ | 135 |
| Ending balance | ​ | (107,134) | ​ | (107,259) | ​ | (107,134) | ​ | (107,259) |
| Total equity | ​ | 926,207 | ​ | 794,396 | ​ | 926,207 | ​ | 794,396 |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001104659-20-058660:notes:48]
[same as prior period, unchanged from 0001104659-20-012461:notes:48]

[0001104659-20-058660:notes:49]
A summary of net periodic benefit expense for the Company’s defined benefit plans for the three and six-month periods ended March 31, 2020 and 2019 is shown in the following table. Net periodic benefit cost for each period presented is comprised of the following:

[0001104659-20-058660:notes:50]
| ​ | ​ | Three Months | ​ | Six Months |
| ​ | ​ | Ended March 31, | ​ | Ended March 31, |
| (In thousands) |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Defined benefit plans | ​ | ​ |  | ​ | ​ |  | ​ |  | ​ |  |
| Interest cost | ​ | $ | 824 |  | ​ | 875 |  | 1,648 |  | 1,750 |
| Expected return on assets | ​ |  | (1,041) |  | ​ | (1,086) |  | (2,082) |  | (2,172) |
| Amortization of: | ​ |  | ​ |  | ​ | ​ |  | ​ |  | ​ |
| Prior service cost | ​ |  | — |  | ​ | — |  | — |  | — |
| Actuarial loss | ​ |  | 543 |  |  | 487 |  | 1,087 |  | 974 |
| Net periodic benefit cost | ​ | $ | 326 |  | ​ | 276 |  | 653 |  | 552 |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001104659-20-058660:notes:51]
[same as prior period, unchanged from 0001104659-20-012461:notes:51]

[0001104659-20-058660:notes:52]
Market risks relating to the Company’s operations result primarily from changes in interest rates and changes in foreign currency exchange rates. The Company is exposed to market risk related to changes in interest rates and selectively uses derivative financial instruments, including forward contracts and swaps, to manage these risks. In 2018, the Company entered into three interest rate swaps with a notional amount of $150 million to hedge some of its exposure to variability in future LIBOR-based interest payments on variable rate debt, of which one swap is outstanding as of March 31, 2020. In addition, the Company’s Canadian subsidiary Morgan Schaffer enters into foreign exchange contracts to manage foreign currency risk as a portion of their revenue is denominated in U.S. dollars. The Company expects hedging gains or losses to be essentially offset by losses or gains on the related underlying exposures. The amounts ultimately recognized may differ for open positions, which remain subject to ongoing market price fluctuations until settlement. All derivative instruments are reported in either accrued expenses or other assets on the balance sheet at fair value. For derivative instruments designated as cash flow hedges, the gain or loss on the derivative is deferred in accumulated other comprehensive income until recognized in earnings with the underlying hedged item. The interest rate swaps entered into during 2018 were not designated as cash flow hedges and, therefore, the gain or loss on the derivative is reflected in earnings each period.

[0001104659-20-058660:notes:53]
The following is a summary of the notional transaction amounts and fair values for the Company’s outstanding derivative financial instruments by risk category and instrument type as of March 31, 2020:

[0001104659-20-058660:notes:54]
| ​ | ​ | ​ | ​ | Fair | ​ | ​ | ​ |
| ​ | ​ | Notional | ​ | Value | ​ | Fix | ​ |
| (In thousands) |  | amount |  | (US$) |  | Rate |  |
| Forward contracts |  | 6,250 |  | USD |  | (381) |  |  |  |
| Interest rate swap |  | 150,000 |  | USD |  | (1,997) |  | 2.24 | % |


## us-gaap:FairValueDisclosuresTextBlock

[0001104659-20-058660:notes:55]
[same as prior period, unchanged from 0001104659-20-012461:notes:55]

[0001104659-20-058660:notes:56]
[same as prior period, unchanged from 0001104659-20-012461:notes:56]

[0001104659-20-058660:notes:57]
[same as prior period, unchanged from 0001104659-20-012461:notes:57]

[0001104659-20-058660:notes:58]
[same as prior period, unchanged from 0001104659-20-012461:notes:58]

[0001104659-20-058660:notes:59]
[same as prior period, unchanged from 0001104659-20-012461:notes:59]

[0001104659-20-058660:notes:60]
[same as prior period, unchanged from 0001104659-20-012461:notes:60]

[0001104659-20-058660:notes:61]
The Company has estimated the fair value of its financial instruments as of March 31, 2020 and September 30, 2019 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, debt and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001104659-20-058660:notes:62]
[same as prior period, unchanged from 0001104659-20-012461:notes:62]

[0001104659-20-058660:notes:63]
The Company’s forward contracts and interest rate swaps are classified within Level 2 of the valuation hierarchy in accordance with FASB Accounting Standards Codification (ASC) 825, as presented below as of March 31, 2020:

[0001104659-20-058660:notes:64]
| (In thousands) |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets (Liabilities): |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Forward contracts and interest rate swaps | ​ | $ | — |  | ​ | (2,378) | ​ | $ | — |  | ​ | (2,378) |

[0001104659-20-058660:notes:65]
[same as prior period, unchanged from 0001104659-20-012461:notes:65]

[0001104659-20-058660:notes:66]
[same as prior period, unchanged from 0001104659-20-012461:notes:66]

[0001104659-20-058660:notes:67]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during the three and six-month periods ended March 31, 2020.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001104659-20-058660:notes:68]
[same as prior period, unchanged from 0001104659-20-012461:notes:68]

[0001104659-20-058660:notes:69]
[same as prior period, unchanged from 0001104659-20-012461:notes:69]

[0001104659-20-058660:notes:70]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2020 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also include a reconciliation of the disaggregated revenue within each reportable segment on a continuing operations basis.

[0001104659-20-058660:notes:71]
| Three months ended March 31, 2020 |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | Test | ​ | USG | ​ | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 51,550 | ​ | $ | 33,952 | ​ | $ | 43,736 | ​ | $ | 129,238 |
| U.S. Government | ​ |  | 43,574 | ​ | ​ | 7,648 | ​ | ​ | 32 | ​ |  | 51,254 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 41,600 | ​ | $ | 43,768 | ​ | $ | 180,492 |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |
| United States | ​ | $ | 81,458 | ​ | $ | 25,121 | ​ | $ | 28,706 | ​ | $ | 135,285 |
| International | ​ |  | 13,666 | ​ | ​ | 16,479 | ​ | ​ | 15,062 | ​ |  | 45,207 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 41,600 | ​ | $ | 43,768 | ​ | $ | 180,492 |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 46,610 | ​ | $ | 8,009 | ​ | $ | 32,209 | ​ | $ | 86,828 |
| Over time | ​ |  | 48,514 | ​ | ​ | 33,591 | ​ | ​ | 11,559 | ​ |  | 93,664 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 41,600 | ​ | $ | 43,768 | ​ | $ | 180,492 |

[0001104659-20-058660:notes:72]
| Six months ended March 31, 2020 |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | Test | ​ | USG | ​ | Total |
| Customer type: |  | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| Commercial | ​ | $ | 93,417 | ​ | $ | 69,194 | ​ | $ | 95,971 | ​ | $ | 258,582 |
| U.S. Government | ​ |  | 79,218 | ​ | ​ | 13,789 | ​ | ​ | 631 | ​ |  | 93,638 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 82,983 | ​ | $ | 96,602 | ​ | $ | 352,220 |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |
| United States | ​ | $ | 146,164 | ​ | $ | 49,959 | ​ | $ | 63,665 | ​ | $ | 259,788 |
| International | ​ |  | 26,471 | ​ | ​ | 33,024 | ​ | ​ | 32,937 | ​ |  | 92,432 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 82,983 | ​ | $ | 96,602 | ​ | $ | 352,220 |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 82,897 | ​ | $ | 17,019 | ​ | $ | 72,524 | ​ | $ | 172,440 |
| Over time | ​ |  | 89,738 | ​ | ​ | 65,964 | ​ | ​ | 24,078 | ​ |  | 179,780 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 82,983 | ​ | $ | 96,602 | ​ | $ | 352,220 |

[0001104659-20-058660:notes:73]
[same as prior period, unchanged from 0001104659-20-012461:notes:72]

[0001104659-20-058660:notes:74]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At March 31, 2020, the Company had $565 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 68% in the next twelve months.

[0001104659-20-058660:notes:75]
[same as prior period, unchanged from 0001104659-20-012461:notes:74]

[0001104659-20-058660:notes:76]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At March 31, 2020, contract assets and liabilities totaled $96.1 million and $95.4 million, respectively.  During the first six months of 2020, the Company recognized approximately $36.4 million in revenues that were included in the contract liabilities balance at the adoption date.


## us-gaap:LeasesOfLesseeDisclosureTextBlock

[0001104659-20-058660:notes:77]
[same as prior period, unchanged from 0001104659-20-012461:notes:76]

[0001104659-20-058660:notes:78]
[same as prior period, unchanged from 0001104659-20-012461:notes:77]

[0001104659-20-058660:notes:79]
[same as prior period, unchanged from 0001104659-20-012461:notes:78]

[0001104659-20-058660:notes:80]
[same as prior period, unchanged from 0001104659-20-012461:notes:79]

[0001104659-20-058660:notes:81]
[same as prior period, unchanged from 0001104659-20-012461:notes:80]

[0001104659-20-058660:notes:82]
[same as prior period, unchanged from 0001104659-20-012461:notes:81]

[0001104659-20-058660:notes:83]
| ​ | ​ | Three Months | ​ | Six Months |
| ​ | ​ | Ended | ​ | Ended |
| ​ | ​ | March 31, | ​ | March 31, |
| (Dollars in thousands) |  | 2020 |  | 2020 |
| Finance lease cost |  | ​ | ​ | ​ | ​ |  |
| Amortization of right-of-use assets | ​ | $ | 622 | ​ | $ | 1,245 |
| Interest on lease liabilities | ​ |  | 323 | ​ |  | 651 |
| Operating lease cost | ​ |  | 1,402 | ​ |  | 2,750 |
| Total lease costs | ​ | $ | 2,347 | ​ | $ | 4,646 |

[0001104659-20-058660:notes:84]
[same as prior period, unchanged from 0001104659-20-012461:notes:83]

[0001104659-20-058660:notes:85]
| ​ | ​ | Three Months | ​ | Six Months | ​ |
| ​ | ​ | Ended | ​ | Ended | ​ |
| ​ | ​ | March 31, | ​ | September 30, | ​ |
| (Dollars in thousands) |  | 2020 |  | 2020 | ​ |
| Cash paid for amounts included in the measurement of lease liabilities |  | ​ | ​ | ​ | ​ |  | ​ |
| Operating cash flows from operating leases | ​ | $ | 1,380 | ​ | $ | 2,717 | ​ |
| Operating cash flows from finance leases | ​ |  | 198 | ​ |  | 335 | ​ |
| Financing cash flows from finance leases | ​ |  | 376 | ​ |  | 727 | ​ |
| Right-of-use assets obtained in exchange for lease liabilities | ​ |  | ​ | ​ |  | ​ | ​ |
| Operating leases | ​ | $ | 1,566 | ​ | $ | 22,268 | ​ |
| Weighted-average remaining lease term | ​ | ​ | ​ | ​ |  | ​ | ​ |
| Operating leases | ​ | ​ | ​ | ​ |  | 6.37 | years |
| Finance leases | ​ | ​ | ​ | ​ |  | 12.97 | years |
| Weighted-average discount rate | ​ | ​ | ​ | ​ |  | ​ | ​ |
| Operating leases | ​ | ​ | ​ | ​ |  | 3.14 | % |
| Finance leases | ​ | ​ | ​ | ​ |  | 4.29 | % |

[0001104659-20-058660:notes:86]
The following is a reconciliation of future undiscounted cash flows to the operating and finance lease liabilities, and the related ROU assets, presented on our Consolidated Balance Sheet on March 31, 2020:

[0001104659-20-058660:notes:87]
| (Dollars in thousands) | ​ |  | Operating |  | Finance |
| Years Ending September 30: |  | Leases |  | Leases |
| 2020 (excluding the six months ended March 31, 2020) | ​ | $ | 2,667 |  | ​ | 1,455 |
| 2021 | ​ |  | 4,696 |  | ​ | 2,930 |
| 2022 | ​ |  | 4,036 |  | ​ | 3,011 |
| 2023 | ​ |  | 3,090 |  | ​ | 3,094 |
| 2024 and thereafter | ​ |  | 6,931 |  | ​ | 31,481 |
| Total minimum lease payments | ​ |  | 21,420 |  | ​ | 41,971 |
| Less: amounts representing interest | ​ |  | 2,202 |  |  | 10,821 |
| Present value of net minimum lease payments | ​ | $ | 19,218 |  | ​ | 31,150 |
| Less: current portion of lease obligations | ​ |  | 4,208 |  | ​ | 1,902 |
| Non-current portion of lease obligations | ​ |  | 15,010 |  | ​ | 29,248 |
| ROU assets | ​ | $ | 18,901 |  | ​ | 28,072 |

[0001104659-20-058660:notes:88]
[same as prior period, unchanged from 0001104659-20-012461:notes:87]

[0001104659-20-058660:notes:89]
[same as prior period, unchanged from 0001104659-20-012461:notes:88]

[0001104659-20-058660:notes:90]
[same as prior period, unchanged from 0001104659-20-012461:notes:89]

[0001104659-20-058660:notes:91]
*    Not applicable for operating leases
