# ESE note change history — 0001104659-20-092836 → 0001104659-21-016643


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-02-09):
[0001104659-21-016643:note_history:1]
The accompanying consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP). As a result of the pension plan termination referenced in the fourth quarter of 2020, certain prior year amounts have been reclassified to conform with the current year presentation. For further information, refer to the consolidated financial statements and related notes included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2020.
  (was, 2020-08-10, similarity 0.8435):
[0001104659-20-092836:note_history:1]
The accompanying consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP). For further information, refer to the consolidated financial statements and related notes included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2019. Certain 2019 amounts have been reclassified to conform with the 2020 presentation.

- changed (2021-02-09):
[0001104659-21-016643:note_history:2]
The Company’s results for the three-month period ended December 31, 2020 are not necessarily indicative of the results for the entire 2021 fiscal year. References to the first quarters of 2021 and 2020 represent the fiscal quarters ended December 31, 2020 and 2019, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.
  (was, 2020-08-10, similarity 0.9646):
[0001104659-20-092836:note_history:2]
The Company’s results for the three-month period ended June 30, 2020 are not necessarily indicative of the results for the entire 2020 fiscal year. References to the third quarters of 2020 and 2019 represent the fiscal quarters ended June 30, 2020 and 2019, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.

- removed (2021-02-09):
[0001104659-20-092836:note_history:3]
Beginning in the first quarter of 2020, Management has renamed the Filtration / Fluid Flow (Filtration) segment as Aerospace & Defense (A&D) to better reflect the composition of the segment’s products, end markets and customer characteristics. The A&D segment’s individual legal and operating entities, historical financial results, and management structure are unchanged from what was formerly presented as Filtration.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-02-09):
[0001104659-21-016643:note_history:4]
| ​ |  | December 31, | ​ | September 30, |
| (In thousands) |  | 2020 |  | 2020 |
| Total borrowings | ​ | $ | 55,842 |  | 62,368 |
| Current portion of long-term debt and short-term borrowings | ​ |  | (21,842) |  | (22,368) |
| Total long-term debt, less current portion | ​ | $ | 34,000 |  | 40,000 |

- changed (2021-02-09):
[0001104659-21-016643:note_history:5]
The Credit Facility includes a $500 million revolving line of credit, as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024.
  (was, 2020-08-10, similarity 0.8288):
[0001104659-20-092836:note_history:5]
On September 27, 2019, the Company entered into a new five-year credit facility (“the Credit Facility”), modifying its previous credit facility which would have matured December 21, 2020. The Credit Facility includes a $500 million revolving line of credit, as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024.

- added (2021-02-09):
[0001104659-21-016643:note_history:6]
At December 31, 2020, the Company had approximately $434 million available to borrow under the Credit Facility, plus the $250 million increase option, in addition to $57.4 million cash on hand. The Company classified $20.0 million as the current portion of long-term debt as of December 31, 2020, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $9.9 million at December 31, 2020.

- changed (2021-02-09):
[0001104659-21-016643:note_history:7]
Interest on borrowings under the Credit Facility is calculated at a spread over either the London Interbank Offered Rate (LIBOR ), the New York Federal Reserve Bank Rate or the prime rate, depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The Credit Facility is secured by the unlimited guaranty of the Company’s direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of its direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 1.45% and 3.18% for the three-month periods ending December 31, 2020 and 2019, respectively. As of December 31, 2020, the Company was in compliance with all covenants.
  (was, 2020-08-10, similarity 0.8677):
[0001104659-20-092836:note_history:7]
Interest on borrowings under the Credit Facility is calculated at a spread over either the London Interbank Offered Rate (LIBOR ), the New York Federal Reserve Bank Rate or the prime rate, depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The Credit Facility is secured by the unlimited guaranty of the Company’s direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of its direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 3.24% and 3.22% for the three and  nine-month periods ending June 30, 2020, respectively , and 3.21% and 3.22% for the three and nine-month periods ending June 30, 2019. As of June 30, 2020, the Company was in compliance with all covenants.

- removed (2021-02-09):
[0001104659-20-092836:note_history:8]
| ​ |  | June 30, | ​ | September 30, |
| (In thousands) | ​ | 2020 |  | 2019 |
| Total borrowings | ​ | $ | 151,577 |  | 285,000 |
| Current portion of long-term debt and short-term borrowings | ​ |  | (21,577) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 130,000 |  | 265,000 |

- removed (2021-02-09):
[0001104659-20-092836:note_history:9]
At June 30, 2020, the Company had approximately $340 million available to borrow under the Credit Facility, plus the $250 million increase option, subject to lender approval, in addition to $104.7 million cash on hand. The Company classified $20.0 million as the current portion of long-term debt as of June 30, 2020, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $9.9 million at June 30, 2020.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-02-09):
[0001104659-21-016643:note_history:10]
| ​ |  | December 31, | ​ | September 30, |
| (In thousands) |  | 2020 |  | 2020 |
| Total borrowings | ​ | $ | 55,842 |  | 62,368 |
| Current portion of long-term debt and short-term borrowings | ​ |  | (21,842) |  | (22,368) |
| Total long-term debt, less current portion | ​ | $ | 34,000 |  | 40,000 |

- removed (2021-02-09):
[0001104659-20-092836:note_history:11]
| ​ |  | June 30, | ​ | September 30, |
| (In thousands) | ​ | 2020 |  | 2019 |
| Total borrowings | ​ | $ | 151,577 |  | 285,000 |
| Current portion of long-term debt and short-term borrowings | ​ |  | (21,577) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 130,000 |  | 265,000 |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-02-09):
[0001104659-21-016643:note_history:12]
| ​ |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total | ​ |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 27,879 | ​ | $ | 53,864 | ​ | $ | 36,722 | ​ | $ | 118,465 | ​ |
| U.S. Government | ​ |  | 39,012 | ​ | ​ | 676 | ​ | ​ | 4,796 | ​ |  | 44,484 | ​ |
| Total revenues | ​ | $ | 66,891 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,949 | ​ |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| United States | ​ | $ | 57,813 | ​ | $ | 37,045 | ​ | $ | 23,266 | ​ | $ | 118,124 | ​ |
| International | ​ |  | 9,078 | ​ | ​ | 17,495 | ​ | ​ | 18,252 | ​ |  | 44,825 | ​ |
| Total revenues | ​ | $ | 66,891 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,949 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 26,946 | ​ | $ | 42,367 | ​ | $ | 8,868 | ​ | $ | 78,181 | ​ |
| Over time | ​ |  | 39,945 | ​ | ​ | 12,173 | ​ | ​ | 32,650 | ​ |  | 84,768 | ​ |
| Total revenues | ​ | $ | 66,891 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,949 | ​ |
  (was, 2020-08-10, similarity 0.974):
[0001104659-20-092836:note_history:12]
| Three Months Ended June 30, 2020 |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | Test | ​ | USG | ​ | Total | ​ |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 37,485 | ​ | $ | 38,737 | ​ | $ | 39,740 | ​ | $ | 115,962 | ​ |
| U.S. Government | ​ |  | 46,587 | ​ | ​ | 7,279 | ​ | ​ | 2,837 | ​ |  | 56,703 | ​ |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 46,016 | ​ | $ | 42,577 | ​ | $ | 172,665 | ​ |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| United States | ​ | $ | 73,476 | ​ | $ | 19,441 | ​ | $ | 26,499 | ​ | $ | 119,416 | ​ |
| International | ​ |  | 10,596 | ​ | ​ | 26,575 | ​ | ​ | 16,078 | ​ |  | 53,249 | ​ |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 46,016 | ​ | $ | 42,577 | ​ | $ | 172,665 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 36,461 | ​ | $ | 9,138 | ​ | $ | 27,765 | ​ | $ | 73,364 | ​ |
| Over time | ​ |  | 47,611 | ​ | ​ | 36,878 | ​ | ​ | 14,812 | ​ |  | 99,301 | ​ |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 46,016 | ​ | $ | 42,577 | ​ | $ | 172,665 | ​ |

- removed (2021-02-09):
[0001104659-20-092836:note_history:13]
| Nine Months Ended June 30, 2020 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | Test |  | USG |  | Total | ​ |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 130,817 | ​ | $ | 107,931 | ​ | $ | 135,711 | ​ | $ | 374,459 | ​ |
| U.S. Government | ​ |  | 125,890 | ​ |  | 21,068 | ​ |  | 3,468 | ​ |  | 150,426 | ​ |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 128,999 | ​ | $ | 139,179 | ​ | $ | 524,885 | ​ |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |
| United States | ​ | $ | 219,640 | ​ | $ | 69,399 | ​ | $ | 90,155 | ​ | $ | 379,194 | ​ |
| International | ​ |  | 37,067 | ​ |  | 59,600 | ​ |  | 49,024 | ​ |  | 145,691 | ​ |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 128,999 | ​ | $ | 139,179 | ​ | $ | 524,885 | ​ |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |
| Point in time | ​ | $ | 118,660 | ​ | $ | 26,157 | ​ | $ | 100,289 | ​ | $ | 245,106 | ​ |
| Over time | ​ |  | 138,047 | ​ |  | 102,842 | ​ |  | 38,890 | ​ |  | 279,779 | ​ |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 128,999 | ​ | $ | 139,179 | ​ | $ | 524,885 | ​ |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-02-09):
[0001104659-21-016643:note_history:14]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2020 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net
  (was, 2020-08-10, similarity 0.6676):
[0001104659-20-092836:note_history:14]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2020 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also include a reconciliation of the disaggregated revenue within each reportable segment on a continuing operations basis.

- added (2021-02-09):
[0001104659-21-016643:note_history:15]
sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within each reportable segment on a continuing operations basis.

- changed (2021-02-09):
[0001104659-21-016643:note_history:16]
| ​ |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total | ​ |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 27,879 | ​ | $ | 53,864 | ​ | $ | 36,722 | ​ | $ | 118,465 | ​ |
| U.S. Government | ​ |  | 39,012 | ​ | ​ | 676 | ​ | ​ | 4,796 | ​ |  | 44,484 | ​ |
| Total revenues | ​ | $ | 66,891 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,949 | ​ |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| United States | ​ | $ | 57,813 | ​ | $ | 37,045 | ​ | $ | 23,266 | ​ | $ | 118,124 | ​ |
| International | ​ |  | 9,078 | ​ | ​ | 17,495 | ​ | ​ | 18,252 | ​ |  | 44,825 | ​ |
| Total revenues | ​ | $ | 66,891 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,949 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 26,946 | ​ | $ | 42,367 | ​ | $ | 8,868 | ​ | $ | 78,181 | ​ |
| Over time | ​ |  | 39,945 | ​ | ​ | 12,173 | ​ | ​ | 32,650 | ​ |  | 84,768 | ​ |
| Total revenues | ​ | $ | 66,891 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,949 | ​ |
  (was, 2020-08-10, similarity 0.974):
[0001104659-20-092836:note_history:16]
| Three Months Ended June 30, 2020 |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | Test | ​ | USG | ​ | Total | ​ |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 37,485 | ​ | $ | 38,737 | ​ | $ | 39,740 | ​ | $ | 115,962 | ​ |
| U.S. Government | ​ |  | 46,587 | ​ | ​ | 7,279 | ​ | ​ | 2,837 | ​ |  | 56,703 | ​ |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 46,016 | ​ | $ | 42,577 | ​ | $ | 172,665 | ​ |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| United States | ​ | $ | 73,476 | ​ | $ | 19,441 | ​ | $ | 26,499 | ​ | $ | 119,416 | ​ |
| International | ​ |  | 10,596 | ​ | ​ | 26,575 | ​ | ​ | 16,078 | ​ |  | 53,249 | ​ |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 46,016 | ​ | $ | 42,577 | ​ | $ | 172,665 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 36,461 | ​ | $ | 9,138 | ​ | $ | 27,765 | ​ | $ | 73,364 | ​ |
| Over time | ​ |  | 47,611 | ​ | ​ | 36,878 | ​ | ​ | 14,812 | ​ |  | 99,301 | ​ |
| Total revenues | ​ | $ | 84,072 | ​ | $ | 46,016 | ​ | $ | 42,577 | ​ | $ | 172,665 | ​ |

- changed (2021-02-09):
[0001104659-21-016643:note_history:17]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At December 31, 2020, the Company had $512.1 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 72% in the next twelve months.
  (was, 2020-08-10, similarity 0.9914):
[0001104659-20-092836:note_history:17]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At June 30, 2020, the Company had $550.5 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 72% in the next twelve months.

- changed (2021-02-09):
[0001104659-21-016643:note_history:18]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At December 31, 2020, contract assets and liabilities totaled $93.8 million and $112.3 million, respectively.  During the first quarter of 2021, the Company recognized approximately $30 million in revenues that were included in the contract liabilities balance at the adoption date.
  (was, 2020-08-10, similarity 0.7673):
[0001104659-20-092836:note_history:18]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At June 30, 2020, contract assets and liabilities totaled $101.5 million and $87.4 million, respectively.  During the first nine months of 2020, the Company recognized approximately $47.1 million in revenues that were included in the contract liabilities balance at the adoption date.

- removed (2021-02-09):
[0001104659-20-092836:note_history:19]
| Nine Months Ended June 30, 2020 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | Test |  | USG |  | Total | ​ |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 130,817 | ​ | $ | 107,931 | ​ | $ | 135,711 | ​ | $ | 374,459 | ​ |
| U.S. Government | ​ |  | 125,890 | ​ |  | 21,068 | ​ |  | 3,468 | ​ |  | 150,426 | ​ |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 128,999 | ​ | $ | 139,179 | ​ | $ | 524,885 | ​ |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |
| United States | ​ | $ | 219,640 | ​ | $ | 69,399 | ​ | $ | 90,155 | ​ | $ | 379,194 | ​ |
| International | ​ |  | 37,067 | ​ |  | 59,600 | ​ |  | 49,024 | ​ |  | 145,691 | ​ |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 128,999 | ​ | $ | 139,179 | ​ | $ | 524,885 | ​ |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |
| Point in time | ​ | $ | 118,660 | ​ | $ | 26,157 | ​ | $ | 100,289 | ​ | $ | 245,106 | ​ |
| Over time | ​ |  | 138,047 | ​ |  | 102,842 | ​ |  | 38,890 | ​ |  | 279,779 | ​ |
| Total revenues | ​ | $ | 256,707 | ​ | $ | 128,999 | ​ | $ | 139,179 | ​ | $ | 524,885 | ​ |
