# ESE MD&A — 0001104659-21-016643


## mdna

[0001104659-21-016643:mdna:1]
[same as prior period, unchanged from 0001104659-20-092836:mdna:1]

[0001104659-21-016643:mdna:2]
[same as prior period, unchanged from 0001104659-20-092836:mdna:9]

[0001104659-21-016643:mdna:3]
References to the first quarters of 2021 and 2020 represent the three-month periods ended December 31, 2020 and 2019, respectively.

[0001104659-21-016643:mdna:4]
[same as prior period, unchanged from 0001104659-20-092836:mdna:2]

[0001104659-21-016643:mdna:5]
The COVID-19 global pandemic has created significant and unprecedented challenges, and during these highly uncertain times, our top priority remains the health and safety of our employees, customers and suppliers, thereby securing the financial well-being of the Company and supporting business continuity. Our businesses have been deemed essential and are currently operational, supplying our customers with vital and necessary products. To date, our global supply chains have not been materially affected by the pandemic. Given our diverse portfolio of strong, durable businesses serving non-discretionary end-markets, the strength and resilience of our business model positions us to continue our long-term outlook. Recognizing the uncertainty presented by this global pandemic, we are continuing to suspend our practice of providing full-year financial guidance. Our businesses continue to face varying levels of pressure depending on the markets they serve and the impact on the Company cannot be reasonably estimated at this time. A portion of our workforce has worked from home at times due to COVID-19, however we have not had to redesign or design new internal controls over financial reporting at this time. Depending on the duration of COVID-19, it may become necessary for us to redesign or design new internal controls over financial reporting in a future period. We do not believe such an event will have a material impact on our business.

[0001104659-21-016643:mdna:6]
The economic uncertainty, changes in the propensity for the general public to travel by air, and reductions in demand for commercial aircraft as a result of the COVID-19 pandemic have adversely impacted net sales and operating results in certain of our Aerospace and Defense reporting units. In addition, our Westland facility had a partial shutdown of its facility for several weeks during the first quarter of 2021 due to COVID-19. We are also monitoring the impacts of COVID-19 on the fair value of assets. We do not currently anticipate any material impairments on assets as a result of COVID-19. We determined that there was no impairment for the three months ended December 31, 2020 and the fair value of each reporting unit reviewed substantially exceeded carrying value, with the exception of Mayday where fair value exceeded carrying value by slightly less than 10%. At December 31, 2020, we had $30 million of goodwill recorded for Mayday. The valuation methodology we use involves estimates of discounted cash flows, which are subject to change, and if they change negatively it could result in the need to write down those assets to fair value. We will continue to monitor the impacts of COVID-19 on the fair value of assets. For further discussion, refer to Management’s Discussion and Analysis contained in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2020.

[0001104659-21-016643:mdna:7]
[same as prior period, unchanged from 0001104659-20-092836:mdna:11]

[0001104659-21-016643:mdna:8]
Sales, net earnings and diluted earnings per share from continuing operations were $162.9 million, $13.7 million and $0.52 per share, respectively, in the first quarter of 2021 compared to $171.7 million, $10.8 million and $0.41 per share, respectively, in the first quarter of 2020.

[0001104659-21-016643:mdna:9]
[same as prior period, unchanged from 0001104659-20-092836:mdna:13]

[0001104659-21-016643:mdna:10]
Net sales decreased $8.8 million, or 5.1%, to $162.9 million in the first quarter of 2021 from $171.7 million in the first quarter of 2020. The decrease in net sales in the first quarter of 2021 as compared to the first quarter of 2020 was due to a $10.6 million decrease in the Aerospace & Defense segment, partially offset by a $1.7 million increase in the USG segment and a $0.1 million increase in the Test segment.

[0001104659-21-016643:mdna:11]
– Aerospace & Defense (A&D)

[0001104659-21-016643:mdna:12]
Net sales of $66.9 million in the first quarter of 2021 were $10.6 million, or 13.7%, lower than the $77.5 million in the first quarter of 2020. The sales decrease in the first quarter of 2021 compared to the first quarter of 2020 was mainly due to an approximately $14 million decrease in commercial aerospace sales at PTI, Crissair and Mayday driven by the COVID-19 pandemic, partially offset by a $4 million increase in navy and space sales from VACCO and Globe.

[0001104659-21-016643:mdna:13]
– USG

[0001104659-21-016643:mdna:14]
Net sales of $54.5 million in the first quarter of 2021 were $1.7 million, or 3.2% higher than the $52.8 million in the first quarter of 2020. The increase in the first quarter of 2021 compared to the first quarter of 2020 was mainly due to higher product sales at NRG and Doble.

[0001104659-21-016643:mdna:15]
– Test

[0001104659-21-016643:mdna:16]
Net sales of $41.5 million in the first quarter of 2021 were $0.1 million, or 0.2%, higher than the $41.4 million in the first quarter of 2020. The increase in the first quarter of 2021 compared to the first quarter of 2020 was primarily due to $3.6 million of higher sales from the segment’s European and Asian operations partially offset by $3.5 million of lower sales from the segment’s U.S. operations, both due to the timing of test and measurement chamber projects.

[0001104659-21-016643:mdna:17]
[same as prior period, unchanged from 0001104659-20-092836:mdna:21]

[0001104659-21-016643:mdna:18]
Backlog was $512.1 million at December 31, 2020 compared with $517.4 million at September 30, 2020. The Company received new orders totaling $157.6 million in the first quarter of 2021 compared to $220.4 million in the first quarter of 2020. Of the new orders received in the first quarter of 2021, $65.4 million related to Aerospace & Defense products, $43.5 million related to Test products, and $48.7 million related to USG products. Of the new orders received in the first quarter of 2020, $129.0 million related to Aerospace & Defense products, $38.5 million related to Test products, and $52.9 million related to USG products.

[0001104659-21-016643:mdna:19]
[same as prior period, unchanged from 0001104659-20-092836:mdna:24]

[0001104659-21-016643:mdna:20]
Selling, general and administrative (SG&A) expenses from continuing operations were $41.0 million (25.1% of net sales) for the first quarter of 2021, compared with $42.1 million (24.5% of net sales) for the first quarter of 2020. The decrease in SG&A in the first quarter of 2021 compared to the first quarter of 2020 was mainly due to lower discretionary spending related to travel and other discretionary expenses due to the COVID-19 pandemic.

[0001104659-21-016643:mdna:21]
[same as prior period, unchanged from 0001104659-20-092836:mdna:26]

[0001104659-21-016643:mdna:22]
Amortization of intangible assets from continuing operations was $4.9 million and $5.8 million for the first quarter of 2021 and 2020, respectively. Amortization expenses consist of amortization of acquired intangible assets from acquisitions and other identifiable intangible assets (primarily software). The decrease in amortization expense in the first quarter of 2021 compared to the first quarter of 2020 was mainly due to a decrease in amortization of capitalized software.

[0001104659-21-016643:mdna:23]
OTHER EXPENSES, NET

[0001104659-21-016643:mdna:24]
Other expenses, net, were $0.1 million in the first quarter of 2021 compared to other expenses, net, of $0.3 million in the first quarter of 2020. The principal component of other expenses, net, in the first quarter of 2021 included approximately $0.7 million of facility consolidation charges for the Doble Manta facility, including employee severance and lease termination charges. There were no individually significant items in other expenses (income), net, in the first quarter of 2020.

[0001104659-21-016643:mdna:25]
[same as prior period, unchanged from 0001104659-20-092836:mdna:31]

[0001104659-21-016643:mdna:26]
The Company evaluates the performance of its operating segments based on EBIT, and provides EBIT on a consolidated basis, which is a non-GAAP financial measure. Please refer to the discussion of non-GAAP financial measures in Note 6 to the Consolidated Financial Statements, above. EBIT was $18.2 million (11.2% of net sales) for the first quarter of 2021 compared to $16.8 million (9.8% of net sales) for the first quarter of 2020.

[0001104659-21-016643:mdna:27]
[same as prior period, unchanged from 0001104659-20-092836:mdna:33]

[0001104659-21-016643:mdna:28]
| ​ | ​ | Three Months Ended |
| ​ | ​ | December 31, |
| (In thousands) |  | 2020 |  | 2019 |
| Consolidated EBIT | ​ | $ | 18,201 | ​ | 16,791 |
| Less: Interest expense, net | ​ |  | (541) |  | (2,421) |
| Less: Income tax expense | ​ |  | (3,974) |  | (3,606) |
| Net earnings from continuing operations | ​ | $ | 13,686 |  | 10,764 |

[0001104659-21-016643:mdna:29]
– Aerospace & Defense

[0001104659-21-016643:mdna:30]
EBIT was $9.4 million (14.0% of net sales) in the first quarter of 2021 compared to $12.5 million (16.1% of net sales) in the first quarter of 2020. The decrease in EBIT in the first quarter of 2021 compared to the first quarter of 2020 was mainly due to lower sales volumes at Mayday, PTI and Crissair partially offset by an increase in EBIT at VACCO and Globe due to favorable product mix and the higher sales volumes mentioned above. In addition, EBIT in the first quarter of 2021 was negatively impacted by a $0.3 million inventory step-up charge related to the ATM acquisition.

[0001104659-21-016643:mdna:31]
– USG

[0001104659-21-016643:mdna:32]
EBIT was $12.7 million (23.3% of net sales) in the first quarter of 2021 compared to $9.3 million (17.6% of net sales) in the first quarter of 2020. The increase in EBIT in the first quarter of 2021 compared to the first quarter of 2020 was mainly due to the higher sales volumes in the first quarter of 2021 and favorable product mix. In addition, EBIT in the first quarter of 2021 was negatively impacted by approximately $0.7 million of facility consolidation charges at its Doble Manta facility.

[0001104659-21-016643:mdna:33]
– Test

[0001104659-21-016643:mdna:34]
EBIT was $5.3 million (12.9% of net sales) in the first quarter of 2021 compared to $4.7 million (11.3% of net sales) in the first quarter of 2020. The increase in EBIT in the first quarter of 2021 compared to the first quarter of 2020 was primarily due to favorable product mix and higher sales volumes from the segment’s European and Asian operations.

[0001104659-21-016643:mdna:35]
– Corporate

[0001104659-21-016643:mdna:36]
Corporate costs included in EBIT were $9.3 million and $9.7 million in the first quarter of 2021 and 2020, respectively. The decrease in Corporate costs in the first quarter of 2021 compared to the first quarter of 2020 was mainly due to the decrease in pension expense as a result of the defined benefit pension plan termination in the fourth quarter of 2020.

[0001104659-21-016643:mdna:37]
[same as prior period, unchanged from 0001104659-20-092836:mdna:43]

[0001104659-21-016643:mdna:38]
Interest expense was $0.5 million and $2.4 million in the first quarter of 2021 and 2020, respectively. The decrease in interest expense in the first quarter of 2021 as compared to the first quarter of 2020 was mainly due to lower average outstanding borrowings ($70 million compared to $279 million) and lower average interest rates.

[0001104659-21-016643:mdna:39]
[same as prior period, unchanged from 0001104659-20-092836:mdna:45]

[0001104659-21-016643:mdna:40]
The effective income tax rate from continuing operations was 22.5% in the first quarter of 2021 compared to 25.1% in the first quarter of 2020. There were no significant or unusual items impacting the effective income tax rate in the first quarter of 2021.

[0001104659-21-016643:mdna:41]
[same as prior period, unchanged from 0001104659-20-092836:mdna:48]

[0001104659-21-016643:mdna:42]
The Company’s overall financial position and liquidity remain strong. Working capital from continuing operations (current assets less current liabilities) increased to $197.6 million at December 31, 2020 from $190.6 million at September 30, 2020. Inventories increased by $7.9 million during this period mainly due to a $4.7 million increase within the Aerospace & Defense segment and a $3.0 million increase within the Test segment resulting primarily from the timing of receipt of raw materials to meet anticipated demand and timing of manufacturing existing orders.

[0001104659-21-016643:mdna:43]
Net cash provided by operating activities from continuing operations was $24.8 million and $3.3 million in the first quarters of 2021 and 2020, respectively. The increase in net cash provided by operating activities from continuing operations in the first quarter of 2021 as compared to the first quarter of 2020 was driven by lower working capital requirements.

[0001104659-21-016643:mdna:44]
Capital expenditures from continuing operations were $6.0 million and $12.6 million in the first quarters of 2021 and 2020, respectively. The decrease in the first quarter of 2021 was mainly due to the building improvement additions at the new Doble headquarters facility of approximately $6 million in the first quarter of 2020. In addition, the Company incurred expenditures for capitalized software of approximately $1.6 million and $1.9 million in the first quarters of 2021 and 2020, respectively.

[0001104659-21-016643:mdna:45]
Acquisition

[0001104659-21-016643:mdna:46]
On October 22, 2020, the Company acquired the equity of Advanced Technology Machining, Inc. and its affiliate TECC Grinding, Inc. (referred to together as “ATM”), small privately held manufacturers of precision machined metal parts serving the aerospace, defense and space industries for a purchase price of approximately $6.5 million in cash, net of cash acquired. Located in Valencia, California near Crissair’s facility, ATM supplies custom-designed parts widely used on defense and commercial aircraft, as well as missile and tank programs, and has annual revenues of approximately $7 million. Since the date of acquisition, the operating results for ATM have been included as a product line of Crissair within the Company’s A&D segment.

[0001104659-21-016643:mdna:47]
Credit Facility

[0001104659-21-016643:mdna:48]
At December 31, 2020, the Company had approximately $434 million available to borrow under its bank credit facility, a $250 million increase option subject to lender approval, and $57.4 million cash on hand. At December 31, 2020, the Company had $55.8 million of outstanding borrowings under the credit facility and short-term borrowings in addition to outstanding letters of credit of $9.9 million. Cash flow from operations and borrowings under the Company’s credit facility are expected to meet the Company’s capital requirements and operational needs for the foreseeable future. The Company’s ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.

[0001104659-21-016643:mdna:49]
[same as prior period, unchanged from 0001104659-20-092836:mdna:56]

[0001104659-21-016643:mdna:50]
A dividend of $0.08 per share, totaling $2.1 million, was paid on October 15, 2020 to stockholders of record as of October 1, 2020. Subsequent to December 31, 2020, a quarterly dividend of $0.08 per share, totaling $2.1 million, was paid on January 19, 2021 to stockholders of record as of January 4, 2021.

[0001104659-21-016643:mdna:51]
[same as prior period, unchanged from 0001104659-20-092836:mdna:58]

[0001104659-21-016643:mdna:52]
Management’s current expectations for 2021 remain consistent with the details outlined in the Business Outlook section presented in the November 19, 2020 press release. In mid-year 2020, business disruptions related to the COVID-19 pandemic began to affect the Company’s operations and continued throughout the balance of the year. During 2021, the commercial aerospace and utility end-markets have seen some degree of customer stabilization, as well as notable pockets of recovery; however there is still uncertainty as to the timing and pace of the recovery in these areas. The wide distribution of viable COVID-19 vaccines is anticipated to benefit and accelerate the recovery of commercial air travel and utility spending with customers resuming normal testing protocols and equipment purchases, but Management has determined that it is advisable to wait at least another 90 days before resuming specific guidance. Given this uncertainty, it is difficult to predict how the balance of 2021 will be affected using normal forecasting methodologies; therefore, the Company will continue its suspension of forward-looking guidance.

[0001104659-21-016643:mdna:53]
To assist shareholders and analysts, Management will continue offering “directional” guidance for 2021, by stating that the Company is seeing tangible signs of recovery in the second half of fiscal 2021 that point to a solid outlook for the back half of the year. Given the strength of the first half of 2020 pre-COVID, it is projected that the first half of 2021 will be slightly lower compared to 2020’s first half, but the outlook for the second half of 2021 is expected to compare favorably to the second half of 2020 given the anticipated elements of recovery. Management’s current expectations for 2021 show growth in Sales, Adjusted EBITDA, and Adjusted EPS compared to 2020, with Adjusted EBITDA and Adjusted EPS reasonably consistent with 2019.

[0001104659-21-016643:mdna:54]
[same as prior period, unchanged from 0001104659-20-092836:mdna:60]

[0001104659-21-016643:mdna:55]
Management has evaluated the accounting policies used in the preparation of the Company’s financial statements and related notes and believes those policies to be reasonable and appropriate. Certain of these accounting policies require the application of significant

[0001104659-21-016643:mdna:56]
judgment by Management in selecting appropriate assumptions for calculating financial estimates. By their nature, these judgments are subject to an inherent degree of uncertainty. These judgments are based on historical experience, trends in the industry, information provided by customers and information available from other outside sources, as appropriate. The most significant areas involving Management judgments and estimates may be found in the Critical Accounting Policies section of Management’s Discussion and Analysis and in Note 1 to the Consolidated Financial Statements contained in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2020.

[0001104659-21-016643:mdna:57]
[same as prior period, unchanged from 0001104659-20-092836:mdna:62]

[0001104659-21-016643:mdna:58]
Contingencies

[0001104659-21-016643:mdna:59]
As a normal incident of the business in which the Company is engaged, various claims, charges and litigation are asserted or commenced against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. In the opinion of Management, the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company, are adequately reserved, are covered by insurance, or would not have a material adverse effect on the Company’s results from operations, capital expenditures, or competitive position.

[0001104659-21-016643:mdna:60]
[same as prior period, unchanged from 0001104659-20-092836:mdna:65]

[0001104659-21-016643:mdna:61]
Investors are cautioned that such statements are only predictions and speak only as of the date of this Form 10-Q, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment, including but not limited to those described in Item 1A, “Risk Factors,” of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2020 and in this Quarterly Report on Form 10-Q, and the following: the continuing impact of the COVID-19 pandemic including labor shortages, facility closures, shelter in place policies or quarantines, material shortages, transportation delays, termination or delays of Company contracts and the inability of our suppliers or customers to perform, the impacts of natural disasters on the Company’s operations and those of the Company’s customers and suppliers; the timing and content of future contract awards or customer orders; the appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer contracts or orders; weakening of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties; the availability of selected acquisitions; delivery delays or defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability of certain raw materials; labor disputes; changes in U.S. tax laws and regulations; other changes in laws and regulations including but not limited to changes in accounting standards and foreign taxation; changes in interest rates; costs relating to environmental matters arising from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the integration of recently acquired businesses.
