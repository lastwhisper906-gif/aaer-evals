# ESE notes — 0001104659-21-016643


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001104659-21-016643:notes:1]
[same as prior period, unchanged from 0001104659-20-092836:notes:1]

[0001104659-21-016643:notes:2]
The accompanying consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP). As a result of the pension plan termination referenced in the fourth quarter of 2020, certain prior year amounts have been reclassified to conform with the current year presentation. For further information, refer to the consolidated financial statements and related notes included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2020.

[0001104659-21-016643:notes:3]
The Company’s results for the three-month period ended December 31, 2020 are not necessarily indicative of the results for the entire 2021 fiscal year. References to the first quarters of 2021 and 2020 represent the fiscal quarters ended December 31, 2020 and 2019, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:EarningsPerShareTextBlock

[0001104659-21-016643:notes:4]
2.    EARNINGS PER SHARE (EPS)

[0001104659-21-016643:notes:5]
[same as prior period, unchanged from 0001104659-20-092836:notes:13]

[0001104659-21-016643:notes:6]
| ​ | ​ | Three Months Ended |
| ​ | ​ | December 31, |
| ​ |  | 2020 |  | 2019 |
| Weighted Average Shares Outstanding — Basic |  | 26,038 |  | 25,981 |
| Dilutive Options and Restricted Shares | ​ | 144 | ​ | 187 |
| Adjusted Shares — Diluted |  | 26,182 |  | 26,168 |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001104659-21-016643:notes:7]
3.    SHARE-BASED COMPENSATION

[0001104659-21-016643:notes:8]
[same as prior period, unchanged from 0001104659-20-092836:notes:16]

[0001104659-21-016643:notes:9]
[same as prior period, unchanged from 0001104659-20-092836:notes:17]

[0001104659-21-016643:notes:10]
Compensation expense related to the restricted share awards was $1.1 million and $1.1 million for the three-month periods ended December 31, 2020 and 2019, respectively. There were 220,300 non-vested shares outstanding as of December 31, 2020.

[0001104659-21-016643:notes:11]
[same as prior period, unchanged from 0001104659-20-092836:notes:19]

[0001104659-21-016643:notes:12]
Compensation expense related to the non-employee director grants was $0.3 million and $0.3 million for the three-month periods ended December 31, 2020 and 2019, respectively.

[0001104659-21-016643:notes:13]
The total share-based compensation cost that has been recognized in the results of operations and included within selling, general and administrative expenses (SG&A) was $1.4 million for each of the three-month periods ended December 31, 2020 and 2019. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $0.3 million for each of the three-month periods ended December 31, 2020 and 2019. As of December 31, 2020, there was $7.1 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a remaining weighted-average period of 1.7 years.


## us-gaap:InventoryDisclosureTextBlock

[0001104659-21-016643:notes:14]
4.    INVENTORIES

[0001104659-21-016643:notes:15]
[same as prior period, unchanged from 0001104659-20-092836:notes:23]

[0001104659-21-016643:notes:16]
| ​ |  | December 31, |  | September 30, |
| (In thousands) |  | 2020 |  | 2020 |
| Finished goods | ​ | $ | 28,365 |  | 28,471 |
| Work in process | ​ |  | 37,290 |  | 30,183 |
| Raw materials | ​ |  | 78,399 |  | 77,535 |
| Total inventories | ​ | $ | 144,054 |  | 136,189 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001104659-21-016643:notes:17]
5.    GOODWILL AND OTHER INTANGIBLE ASSETS

[0001104659-21-016643:notes:18]
Included on the Company’s Consolidated Balance Sheets at December 31, 2020 and September 30, 2020 are the following intangible assets gross carrying amounts and accumulated amortization from continuing operations:

[0001104659-21-016643:notes:19]
| ​ |  | December 31, |  | September 30, |
| (Dollars in thousands) |  | 2020 |  | 2020 |
| Goodwill | ​ | $ | 411,161 |  | 408,063 |
| Intangible assets with determinable lives: | ​ |  | ​ | ​ | ​ |
| Patents | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 2,120 | ​ | 2,092 |
| Less: accumulated amortization | ​ |  | 887 | ​ | 858 |
| Net | ​ | $ | 1,233 | ​ | 1,234 |
| Capitalized software | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 86,442 | ​ | 84,888 |
| Less: accumulated amortization | ​ |  | 58,957 | ​ | 57,302 |
| Net | ​ | $ | 27,485 | ​ | 27,586 |
| Customer relationships | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 229,275 | ​ | 227,178 |
| Less: accumulated amortization | ​ |  | 70,746 | ​ | 67,643 |
| Net | ​ | $ | 158,529 | ​ | 159,535 |
| Other | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 5,342 | ​ | 5,156 |
| Less: accumulated amortization | ​ |  | 3,415 | ​ | 3,260 |
| Net | ​ | $ | 1,927 | ​ | 1,896 |
| Intangible assets with indefinite lives: | ​ |  | ​ | ​ | ​ |
| Trade names | ​ | $ | 158,263 | ​ | 156,381 |

[0001104659-21-016643:notes:20]
The changes in the carrying amount of goodwill attributable to each business segment for the three months ended December 31, 2020 is as follows:

[0001104659-21-016643:notes:21]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | Aerospace | ​ | ​ |
| (Dollars in millions) |  | USG |  | Test |  | & Defense |  | Total |
| Balance as of September 30, 2020 | ​ | ​ | 271.9 |  | 34.1 |  | 102.1 |  | 408.1 |
| Acquisition activity | ​ | ​ | — | ​ | — | ​ | 2.3 | ​ | 2.3 |
| Foreign currency translation | ​ | ​ | 0.8 | ​ | — | ​ | — | ​ | 0.8 |
| Balance as of December 31, 2020 | ​ | $ | 272.7 | ​ | 34.1 | ​ | 104.4 | ​ | 411.2 |

[0001104659-21-016643:notes:22]
The economic uncertainty, changes in the propensity for the general public to travel by air, and reductions in demand for commercial aircraft as a result of the COVID-19 pandemic have adversely impacted net sales and operating results in certain of

[0001104659-21-016643:notes:23]
the Aerospace and Defense reporting units. There were no impairment charges incurred for the three months ended December 31, 2020, however, the fair value of the Mayday reporting unit exceeded carrying value by slightly less than 10%. At December 31, 2020, we had $30 million of goodwill recorded for Mayday.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001104659-21-016643:notes:24]
6.    BUSINESS SEGMENT INFORMATION

[0001104659-21-016643:notes:25]
The Company is organized based on the products and services that it offers and classifies its continuing business operations in three reportable segments for financial reporting purposes: Aerospace & Defense (formerly called Filtration/Fluid Flow), RF Shielding and Test (Test), and Utility Solutions Group (USG). The Aerospace & Defense segment’s operations consist of PTI Technologies Inc. (PTI), VACCO Industries (VACCO), Crissair, Inc. (Crissair), Westland Technologies Inc. (Westland), Mayday Manufacturing Co. and its affiliate Hi-Tech Metals, Inc. (collectively referred to as Mayday) and Globe Composite Solutions, LLC (Globe). The companies within this segment primarily design and manufacture specialty filtration, fluid control and naval products, including hydraulic filter elements and fluid control devices used in aerospace and defense applications; unique filter mechanisms used in micro-propulsion devices for satellites and custom designed filters for manned aircraft and submarines; products and systems to reduce vibration and/or acoustic signatures and otherwise reduce or obscure a vessel’s signature, and other communications, sealing, surface control and hydrodynamic related applications to enhance U.S. Navy maritime survivability; precision-tolerance machined components for the aerospace and defense industry; and metal processing services. The Test segment’s operations consist primarily of ETS-Lindgren Inc. (ETS-Lindgren). ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy. ETS-Lindgren also manufactures radio frequency shielding products and components used by manufacturers of medical equipment, communications systems, electronic products, and shielded rooms for high-security data processing and secure communication. The USG segment’s operations consist primarily of Doble Engineering Company and Morgan Schaffer Inc. (together Doble), and NRG Systems, Inc. (NRG). Doble is an industry leader in the development, manufacture and delivery of diagnostic testing solutions that enable electric power grid operators to assess the integrity of high voltage power delivery equipment. NRG designs and manufactures decision support tools for the renewable energy industry, primarily wind and solar.

[0001104659-21-016643:notes:26]
[same as prior period, unchanged from 0001104659-20-092836:notes:35]

[0001104659-21-016643:notes:27]
| ​ | ​ | Three Months Ended |
| ​ | ​ | December 31, |
| (In thousands) |  | 2020 |  | 2019 |
| NET SALES | ​ | ​ |  | ​ |  |
| Aerospace & Defense | ​ | $ | 66,891 | ​ | 77,511 |
| USG | ​ | ​ | 54,540 | ​ | 52,834 |
| Test | ​ | ​ | 41,518 | ​ | 41,383 |
| Consolidated totals | ​ | $ | 162,949 | ​ | 171,728 |
| EBIT | ​ | ​ | ​ | ​ | ​ |
| Aerospace & Defense | ​ | $ | 9,380 | ​ | 12,513 |
| USG | ​ | ​ | 12,731 | ​ | 9,288 |
| Test | ​ | ​ | 5,342 | ​ | 4,656 |
| Corporate (loss) | ​ | ​ | (9,252) | ​ | (9,666) |
| Consolidated EBIT | ​ | ​ | 18,201 | ​ | 16,791 |
| Less: Interest expense | ​ | ​ | (541) | ​ | (2,421) |
| Earnings before income taxes from continuing operations | ​ | $ | 17,660 | ​ | 14,370 |

[0001104659-21-016643:notes:28]
[same as prior period, unchanged from 0001104659-20-092836:notes:37]

[0001104659-21-016643:notes:29]
[same as prior period, unchanged from 0001104659-20-092836:notes:38]

[0001104659-21-016643:notes:30]
[same as prior period, unchanged from 0001104659-20-092836:notes:39]


## us-gaap:DebtDisclosureTextBlock

[0001104659-21-016643:notes:31]
7.    DEBT

[0001104659-21-016643:notes:32]
The Company’s debt is summarized as follows:

[0001104659-21-016643:notes:33]
| ​ |  | December 31, | ​ | September 30, |
| (In thousands) |  | 2020 |  | 2020 |
| Total borrowings | ​ | $ | 55,842 |  | 62,368 |
| Current portion of long-term debt and short-term borrowings | ​ |  | (21,842) |  | (22,368) |
| Total long-term debt, less current portion | ​ | $ | 34,000 |  | 40,000 |

[0001104659-21-016643:notes:34]
The Credit Facility includes a $500 million revolving line of credit, as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024.

[0001104659-21-016643:notes:35]
At December 31, 2020, the Company had approximately $434 million available to borrow under the Credit Facility, plus the $250 million increase option, in addition to $57.4 million cash on hand. The Company classified $20.0 million as the current portion of long-term debt as of December 31, 2020, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $9.9 million at December 31, 2020.

[0001104659-21-016643:notes:36]
Interest on borrowings under the Credit Facility is calculated at a spread over either the London Interbank Offered Rate (LIBOR ), the New York Federal Reserve Bank Rate or the prime rate, depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The Credit Facility is secured by the unlimited guaranty of the Company’s direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of its direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 1.45% and 3.18% for the three-month periods ending December 31, 2020 and 2019, respectively. As of December 31, 2020, the Company was in compliance with all covenants.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001104659-21-016643:notes:37]
8.  INCOME TAX EXPENSE

[0001104659-21-016643:notes:38]
The first quarter 2021 effective income tax rate from continuing operations was 22.5% compared to 25.1% in the first quarter of 2020. There were no significant or unusual items impacting the effective income tax rate in the first quarter of 2021.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001104659-21-016643:notes:39]
9.  SHAREHOLDERS’ EQUITY

[0001104659-21-016643:notes:40]
The change in shareholders’ equity for the first three months of 2021 and 2020 is shown below (in thousands):

[0001104659-21-016643:notes:41]
| ​ | ​ | Three Months Ended December 31, |
| ​ |  | 2020 |  | 2019 |
| Common stock | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 306 | ​ | 306 |
| Stock plans | ​ | — | ​ | — |
| Ending balance | ​ | 306 | ​ | 306 |
| Additional paid-in-capital | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 293,682 | ​ | 292,408 |
| Stock plans | ​ | 1,053 | ​ | 648 |
| Ending balance | ​ | 294,735 | ​ | 293,056 |
| Retained earnings | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 778,398 | ​ | 684,741 |
| Net earnings common stockholders | ​ | 13,686 | ​ | 86,777 |
| Dividends paid | ​ | (2,084) | ​ | (2,079) |
| Ending balance | ​ | 790,000 | ​ | 769,439 |
| Accumulated other comprehensive income (loss) | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | (3,657) | ​ | (43,974) |
| Foreign currency translation | ​ | 5,349 | ​ | 3,923 |
| Forward exchange contracts | ​ | — | ​ | — |
| Ending balance | ​ | 1,692 | ​ | (40,051) |
| Treasury stock | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | (107,134) | ​ | (107,259) |
| Issued under stock plans | ​ | — | ​ | — |
| Ending balance | ​ | (107,134) | ​ | (107,259) |
| Total equity | ​ | 979,599 | ​ | 915,491 |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001104659-21-016643:notes:42]
10.  DERIVATIVE FINANCIAL INSTRUMENTS

[0001104659-21-016643:notes:43]
Market risks relating to the Company’s operations result primarily from changes in interest rates and changes in foreign currency exchange rates. The Company is exposed to market risk related to changes in interest rates and selectively uses derivative financial instruments, including forward contracts and swaps, to manage these risks. In 2018, the Company entered into three interest rate swaps with a notional amount of $150 million to hedge some of its exposure to variability in future LIBOR-based interest payments on variable rate debt. The final interest rate swap was settled during September 2020; therefore, there are no outstanding interest rate swaps as of December 31, 2020.

[0001104659-21-016643:notes:44]
The Company’s Canadian subsidiary Morgan Schaffer enters into foreign exchange contracts to manage foreign currency risk as a portion of their revenue is denominated in U.S. dollars. The Company expects hedging gains or losses to be essentially offset by losses or gains on the related underlying exposures. The amounts ultimately recognized may differ for open positions, which remain subject to ongoing market price fluctuations until settlement. All derivative instruments are reported in either accrued expenses or other assets on the balance sheet at fair value. For derivative instruments designated as cash flow hedges, the gain or loss on the derivative is deferred in accumulated other comprehensive income until recognized in earnings with the underlying hedged item.

[0001104659-21-016643:notes:45]
The following is a summary of the notional transaction amounts and fair values for the Company’s outstanding derivative financial instruments by risk category and instrument type as of December 31, 2020:

[0001104659-21-016643:notes:46]
| ​ | ​ | Notional | ​ | Fair Value |  |
| (In thousands) |  | amount |  | (US$) |  |
| Forward contracts |  | 3,500 | USD | 167 | ​ |


## us-gaap:FairValueDisclosuresTextBlock

[0001104659-21-016643:notes:47]
11.  FAIR VALUE MEASUREMENTS

[0001104659-21-016643:notes:48]
[same as prior period, unchanged from 0001104659-20-092836:notes:60]

[0001104659-21-016643:notes:49]
[same as prior period, unchanged from 0001104659-20-092836:notes:61]

[0001104659-21-016643:notes:50]
[same as prior period, unchanged from 0001104659-20-092836:notes:62]

[0001104659-21-016643:notes:51]
[same as prior period, unchanged from 0001104659-20-092836:notes:63]

[0001104659-21-016643:notes:52]
[same as prior period, unchanged from 0001104659-20-092836:notes:64]

[0001104659-21-016643:notes:53]
The Company has estimated the fair value of its financial instruments as of December 31, 2020 and September 30, 2020 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, debt and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001104659-21-016643:notes:54]
[same as prior period, unchanged from 0001104659-20-092836:notes:66]

[0001104659-21-016643:notes:55]
The Company’s forward contracts and interest rate swaps are classified within Level 2 of the valuation hierarchy in accordance with FASB Accounting Standards Codification (ASC) 825, as presented below as of December 31, 2020:

[0001104659-21-016643:notes:56]
| (In thousands) |  | Level 1 |  | Level 2 |  | ​ | Level 3 |  | Total |
| Assets (Liabilities): | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Forward contracts and interest rate swaps | ​ | $ | — |  | 167 |  | $ | — |  | 167 |

[0001104659-21-016643:notes:57]
[same as prior period, unchanged from 0001104659-20-092836:notes:69]

[0001104659-21-016643:notes:58]
[same as prior period, unchanged from 0001104659-20-092836:notes:70]

[0001104659-21-016643:notes:59]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during the three-month period ended December 31, 2020.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001104659-21-016643:notes:60]
12.  REVENUES

[0001104659-21-016643:notes:61]
[same as prior period, unchanged from 0001104659-20-092836:notes:73]

[0001104659-21-016643:notes:62]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2020 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net

[0001104659-21-016643:notes:63]
sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within each reportable segment on a continuing operations basis.

[0001104659-21-016643:notes:64]
| ​ |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total | ​ |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 27,879 | ​ | $ | 53,864 | ​ | $ | 36,722 | ​ | $ | 118,465 | ​ |
| U.S. Government | ​ |  | 39,012 | ​ | ​ | 676 | ​ | ​ | 4,796 | ​ |  | 44,484 | ​ |
| Total revenues | ​ | $ | 66,891 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,949 | ​ |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| United States | ​ | $ | 57,813 | ​ | $ | 37,045 | ​ | $ | 23,266 | ​ | $ | 118,124 | ​ |
| International | ​ |  | 9,078 | ​ | ​ | 17,495 | ​ | ​ | 18,252 | ​ |  | 44,825 | ​ |
| Total revenues | ​ | $ | 66,891 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,949 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 26,946 | ​ | $ | 42,367 | ​ | $ | 8,868 | ​ | $ | 78,181 | ​ |
| Over time | ​ |  | 39,945 | ​ | ​ | 12,173 | ​ | ​ | 32,650 | ​ |  | 84,768 | ​ |
| Total revenues | ​ | $ | 66,891 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,949 | ​ |

[0001104659-21-016643:notes:65]
[same as prior period, unchanged from 0001104659-20-092836:notes:77]

[0001104659-21-016643:notes:66]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At December 31, 2020, the Company had $512.1 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 72% in the next twelve months.

[0001104659-21-016643:notes:67]
[same as prior period, unchanged from 0001104659-20-092836:notes:79]

[0001104659-21-016643:notes:68]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At December 31, 2020, contract assets and liabilities totaled $93.8 million and $112.3 million, respectively.  During the first quarter of 2021, the Company recognized approximately $30 million in revenues that were included in the contract liabilities balance at the adoption date.


## us-gaap:LeasesOfLesseeDisclosureTextBlock

[0001104659-21-016643:notes:69]
13.  LEASES

[0001104659-21-016643:notes:70]
The Company determines at lease inception whether an arrangement that provides control over the use of an asset is a lease. The Company recognizes at lease commencement a right-of-use (ROU) asset and lease liability based on the present value of the future lease payments over the lease term. The Company has elected not to recognize a ROU asset and lease liability for leases with terms of 12 months or less. Certain of the Company’s leases include options to extend the term of the lease for up to 20 years. When it is reasonably certain that the Company will exercise the option, Management includes the impact of the option in the lease term for purposes of determining total future lease payments. As most of the Company’s lease agreements do not explicitly state the discount rate implicit in the lease, Management uses the Company’s incremental borrowing rate on the commencement date to calculate the present value of future payments based on the tenor of each arrangement.

[0001104659-21-016643:notes:71]
[same as prior period, unchanged from 0001104659-20-092836:notes:83]

[0001104659-21-016643:notes:72]
In addition to the base rent, real estate leases typically contain provisions for common-area maintenance and other similar services, which are considered non-lease components for accounting purposes. Non-lease components are excluded from ROU assets and lease liabilities and expensed as incurred.

[0001104659-21-016643:notes:73]
[same as prior period, unchanged from 0001104659-20-092836:notes:85]

[0001104659-21-016643:notes:74]
[same as prior period, unchanged from 0001104659-20-092836:notes:86]

[0001104659-21-016643:notes:75]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended |
| ​ | ​ | December 31, | ​ | December 31, |
| (Dollars in thousands) |  | 2020 |  | 2019 |
| Finance lease cost | ​ | ​ |  | ​ | ​ |  |
| Amortization of right-of-use assets | ​ | $ | 492 | ​ | ​ | 622 |
| Interest on lease liabilities | ​ |  | 313 | ​ |  | 328 |
| Operating lease cost | ​ |  | 1,452 | ​ |  | 1,419 |
| Total lease costs | ​ | $ | 2,257 | ​ | ​ | 2,369 |

[0001104659-21-016643:notes:76]
[same as prior period, unchanged from 0001104659-20-092836:notes:88]

[0001104659-21-016643:notes:77]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended | ​ |
| ​ | ​ | December 31, | ​ | December 31, | ​ |
| (Dollars in thousands) |  | 2020 |  | 2019 | ​ |
| Cash paid for amounts included in the measurement of lease liabilities | ​ | ​ |  | ​ | ​ |  | ​ |
| Operating cash flows from operating leases | ​ | $ | 1,425 | ​ | ​ | 1,408 | ​ |
| Operating cash flows from finance leases | ​ |  | 313 | ​ |  | 138 | ​ |
| Financing cash flows from finance leases | ​ |  | 417 | ​ |  | 351 | ​ |
| Right-of-use assets obtained in exchange for lease liabilities | ​ |  | ​ | ​ |  | ​ | ​ |
| Operating leases | ​ | $ | — | ​ | ​ | 22,014 | ​ |
| Weighted-average remaining lease term | ​ |  | ​ | ​ |  | ​ | ​ |
| Operating leases | ​ |  | 5.9 | years |  | 6.5 | years |
| Finance leases | ​ |  | 12.3 | years |  | 13.2 | years |
| Weighted-average discount rate | ​ |  | ​ | ​ |  | ​ | ​ |
| Operating leases | ​ |  | 3.10 | % |  | 3.14 | % |
| Finance leases | ​ |  | 4.30 | % |  | 4.28 | % |

[0001104659-21-016643:notes:78]
The following is a reconciliation of future undiscounted cash flows to the operating and finance lease liabilities, and the related ROU assets, presented on the Consolidated Balance Sheet on December 31, 2020:

[0001104659-21-016643:notes:79]
| (Dollars in thousands) | ​ | Operating |  | Finance |
| Years Ending September 30: |  | Leases |  | Leases |
| 2021 (excluding the three months ended December 31, 2020) | ​ | $ | 4,182 |  | ​ | 2,204 |
| 2022 | ​ |  | 4,980 |  | ​ | 3,016 |
| 2023 | ​ |  | 3,984 |  | ​ | 3,098 |
| 2024 | ​ |  | 2,438 |  | ​ | 3,181 |
| 2025 and thereafter | ​ |  | 7,208 |  | ​ | 28,285 |
| Total minimum lease payments | ​ |  | 22,792 |  | ​ | 39,784 |
| Less: amounts representing interest | ​ |  | 2,047 |  |  | 9,935 |
| Present value of net minimum lease payments | ​ | $ | 20,745 |  | ​ | 29,849 |
| Less: current portion of lease obligations | ​ |  | 4,999 |  | ​ | 1,972 |
| Non-current portion of lease obligations | ​ | $ | 15,746 |  | ​ | 27,877 |
| ROU assets | ​ | $ | 20,315 |  | ​ | 25,674 |

[0001104659-21-016643:notes:80]
Operating lease liabilities are included on the Consolidated Balance Sheet in accrued other expenses (current portion) and as a caption on the Consolidated Balance Sheet (long-term portion). Finance lease liabilities are included on the Consolidated Balance Sheet in accrued other expenses (current portion) and other liabilities (long-term portion). Operating lease ROU assets are included as a caption on the Consolidated Balance Sheet and finance lease ROU assets are included in Property, plant and equipment on the Consolidated Balance sheet.
