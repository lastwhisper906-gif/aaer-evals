# ESE 8-K — 0001104659-21-013712 filed 2021-02-08

## item codes, every 8-K on or before 2021-02-09

- 2021-02-08 0001104659-21-013712 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2020-12-09 0001104659-20-133674 — 5.02, 9.01
- 2020-12-07 0001104659-20-132861 — 5.02, 7.01, 9.01
- 2020-11-19 0001104659-20-127352 — 2.02, 5.02, 7.01, 9.01
- 2020-08-10 0001104659-20-092734 — 2.02, 7.01, 9.01
- 2020-05-06 0001104659-20-057442 — 2.02, 7.01, 8.01, 9.01
- 2020-02-04 0001104659-20-010640 — 2.02, 5.07, 7.01, 9.01
- 2020-01-07 0001104659-20-001789 — 2.01, 9.01
- 2019-11-19 0001104659-19-065437 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2019-11-18 0001104659-19-065096 — 1.01, 2.02, 7.01, 9.01
- 2019-09-30 0001144204-19-046523 — 1.01, 1.02, 2.03, 9.01
- 2019-08-08 0001144204-19-038567 — 2.02, 7.01, 9.01
- 2019-05-07 0001144204-19-024241 — 2.02, 5.02, 7.01, 9.01
- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2021-02-09

- none on or before 2021-02-09

## item 2.02 — earnings release, exhibit 99.1

[0001104659-21-013712:8k_2_02:1]
EX-99.1
2
tm215610d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-21-013712:8k_2_02:2]
Exhibit 99.1

[0001104659-21-013712:8k_2_02:3]
| NEWS FROM |  |

[0001104659-21-013712:8k_2_02:4]
For more information contact:

[0001104659-21-013712:8k_2_02:5]
Kate Lowrey

[0001104659-21-013712:8k_2_02:6]
Director, Investor Relations

[0001104659-21-013712:8k_2_02:7]
ESCO Technologies Inc.

[0001104659-21-013712:8k_2_02:8]
(314)
213-7277

[0001104659-21-013712:8k_2_02:9]
ESCO ANNOUNCES FIRST QUARTER FISCAL
2021 RESULTS

[0001104659-21-013712:8k_2_02:10]
- GAAP EPS $0.52 and Adjusted EPS
$0.55 (Tops Consensus Estimate) -

[0001104659-21-013712:8k_2_02:11]
- Record Q1 Cash Flow from Operations,
Leverage Ratio 0.38x, Liquidity of $740 Million -

[0001104659-21-013712:8k_2_02:12]
ST. LOUIS, February 8, 2021 – ESCO
Technologies Inc. (NYSE: ESE) (ESCO, or the Company) today reported its operating results for the first quarter ended December
31, 2020 (Q1 2021) compared to the first quarter ended December 31, 2019 (Q1 2020).

[0001104659-21-013712:8k_2_02:13]
COVID-19 Update

[0001104659-21-013712:8k_2_02:14]
Vic Richey, Chairman and Chief Executive
Officer, commented, “While we continue managing through the COVID-19 global pandemic, our primary focus remains the health
and safety of our employees, customers and suppliers, thereby securing the financial well-being of the Company.

[0001104659-21-013712:8k_2_02:15]
“Our Q1 2021 results reflect the importance
of maintaining diversity across our end-markets, as this diversity, coupled with our strong balance sheet and substantial liquidity
will continue to support our long-term growth. Our multi-segment platform, enabled us to substantially mitigate COVID-19’s
impact on sales and earnings, while generating record cash flow during Q1 which allowed us to further reduce our debt and lower
our leverage ratio to 0.38x at December 31st. Our continued focus on operating execution and effective cost management resulted
in a strong start to the year.

[0001104659-21-013712:8k_2_02:16]
“I’m confident that our well-tested
operating model and our recent cost reduction actions will position us for solid earnings growth as our end-markets recover. The
fundamentals of our portfolio remain strong and our goal remains the same – to create long-term shareholder value.”

[0001104659-21-013712:8k_2_02:17]
Q1 2021 Acquisition

[0001104659-21-013712:8k_2_02:18]
As announced previously, on October 22,
2020, the Company acquired Advanced Technology Machining, Inc. and its affiliate TECC Grinding, Inc. (collectively referred to
as “ATM”), a small, privately-held manufacturer of precision machined metal parts serving the aerospace, defense, and
space industries. Located in Valencia, California near Crissair’s facility, ATM has a solid customer base supplying custom-designed
parts widely used on defense and commercial aircraft, as well as missile and tank programs. The results of ATM are included in
the Q1 2021 A&D operating segment since the date of acquisition.

[0001104659-21-013712:8k_2_02:19]
Discrete Items

[0001104659-21-013712:8k_2_02:20]
During Q1 2021, the Company incurred $1
million, or $0.03 per share, of one-time purchase accounting charges related to the ATM acquisition, and facility shut-down costs
in the USG segment related to the closure of a former manufacturing facility in Toronto (described in the November 2020 earnings
release). These costs are excluded from the calculation of Adjusted EBITDA and Adjusted EPS in Q1 2021.

[0001104659-21-013712:8k_2_02:21]
During Q1 2020, the company incurred $0.7
million, or $0.02 per share, of cost reduction actions primarily related to the move of Doble’s headquarters facility from
Watertown to Marlborough, Massachusetts. These costs are excluded from the calculation of Adjusted EBITDA and Adjusted EPS in Q1
2020.

[0001104659-21-013712:8k_2_02:22]
Also during Q1 2020, the company completed
the sale of its Technical Packaging segment which resulted in gross cash proceeds of $191 million and a $77 million, or $2.93 per
share net gain on the sale which is recorded as discontinued operations. The impact of discontinued operations is excluded from
the calculation of Adjusted EBITDA and Adjusted EPS in Q1 2020.

[0001104659-21-013712:8k_2_02:23]
The financial results presented include
certain non-GAAP financial measures such as EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS, as defined within the “Non-GAAP
Financial Measures” described below. Any non-GAAP financial measures presented are reconciled to their respective GAAP equivalents.

[0001104659-21-013712:8k_2_02:24]
Management believes these non-GAAP financial
measures are useful in assessing the ongoing operational profitability of the Company’s business segments, and therefore,
allow shareholders better visibility into the Company’s underlying operations. See “Non-GAAP Financial Measures”
described below.

[0001104659-21-013712:8k_2_02:25]
Earnings Summary

[0001104659-21-013712:8k_2_02:26]
Q1 2021 GAAP EPS was $0.52 per share (GAAP
net earnings of $14 million) and included the net earnings’ impact of the Q1 2021 Discrete Items described above. Excluding
the net earnings impact of the Discrete Items, Q1 2021 Adjusted EPS was $0.55 per share.

[0001104659-21-013712:8k_2_02:27]
Q1 2020 GAAP EPS was $3.32 per share (GAAP
net earnings of $87 million) and included $2.91 per share from discontinued operations and $0.02 per share from the Discrete Items
noted above. Excluding discontinued operations and the net earnings impact of the Discrete Items, Q1 2020 Adjusted EPS was $0.43
per share.

[0001104659-21-013712:8k_2_02:28]
Q1 2021 Adjusted EBITDA increased 4.4 percent
to $29.2 million, compared to Q1 2020 Adjusted EBITDA of $28 million.

[0001104659-21-013712:8k_2_02:29]
Operating Highlights – Q1

[0001104659-21-013712:8k_2_02:30]
|  | · | Net sales were $163 million in Q1 2021, compared to $172 million in Q1 2020. |

[0001104659-21-013712:8k_2_02:31]
|  | · | A&D segment sales decreased $11 million in Q1 2021, resulting from lower commercial aerospace sales due to COVID-19, partially offset by a $4 million increase in navy and space sales. |

[0001104659-21-013712:8k_2_02:32]
|  | · | Driven by steady chamber project deliveries, Test sales increased to $42 million in Q1 2021 from $41 million in Q1 2020. |

[0001104659-21-013712:8k_2_02:33]
|  | · | USG sales increased to $55 million in Q1 2021 compared to $53 million in Q1 2020. The sales increase resulted from an easing of pent-up demand as several utility customers released calendar year-end spending for equipment and software requirements. This partial spending recovery continues to be impacted by the timing of certain project deliverables and maintenance deferrals as utility customers continue to manage around COVID-19’s impact restricting on-site personnel at substations, large transformers and other customer locations. |

[0001104659-21-013712:8k_2_02:34]
|  | · | Gross margin percentage increased to 39.4 percent in Q1 2021 from 37.9 percent in Q1 2020 driven by higher sales in USG coupled with manufacturing cost reduction actions implemented across the company. |

[0001104659-21-013712:8k_2_02:35]
|  | · | SG&A expenses decreased $1 million in Q1 2021 compared to Q1 2020 as a result of lower spending on discretionary expenses, including travel, to help offset the negative sales impact from COVID-19. |

[0001104659-21-013712:8k_2_02:36]
|  | · | Non-cash amortization of intangible assets decreased $1 million in Q1 2021 compared to Q1 2020 resulting from lower software amortization. |

[0001104659-21-013712:8k_2_02:37]
|  | · | Interest expense decreased $2 million in Q1 2021 compared to Q1 2020 due to the lower amount of debt outstanding. |

[0001104659-21-013712:8k_2_02:38]
|  | · | The effective income tax rate used for determining Adjusted EPS was approximately 23 percent in Q1 2021 and 25 percent in Q1 2020. |

[0001104659-21-013712:8k_2_02:39]
|  | · | Entered orders were $158 million in Q1 2021 (book-to-bill of 0.97x) resulting in an ending backlog of $512 million at December 31, 2020. |

[0001104659-21-013712:8k_2_02:40]
|  | · | Q1 2021 net cash provided by operating activities was $25 million, resulting in a net cash position (total cash on hand, less total borrowings) of $2 million at December 31, 2020 reflecting a 0.38x leverage ratio. |

[0001104659-21-013712:8k_2_02:41]
Chairman’s Commentary

[0001104659-21-013712:8k_2_02:42]
Vic Richey, Chairman and Chief Executive
Officer, commented, “While we are still being impacted by COVID-19 within our commercial aerospace and utility businesses,
I’m really pleased with our Q1 results as we had numerous highlights across the company which offset the obvious headwinds.

[0001104659-21-013712:8k_2_02:43]
“Driven by our increased focus on
working capital management, the clear highlight in Q1 was the strength of our cash generation which increased our liquidity. Our
strong liquidity position will benefit us during 2021 as we continue our pursuit of acquisitions and expand our internal investments
in new product development across the company.

[0001104659-21-013712:8k_2_02:44]
“From an operations perspective, USG
clearly drove our Q1 2021 success by substantially exceeding our internal expectations on both sales and earnings, as the segment
reported an Adjusted EBIT margin of nearly 25 percent, compared to Q1 2020’s Adjusted EBIT margin of 19 percent. USG delivered
higher than expected sales as several customers resumed their calendar year-end budget spending which provided additional product
and software sales, and resulted in a favorable sales mix.

[0001104659-21-013712:8k_2_02:45]
“While we expect to see some continued
deferrals of test equipment purchases and maintenance-related projects for the next few months, our positive outlook for the second
half of the year remains the same. Our cost reduction actions implemented in 2020 are also having an impact as shown by USG’s
improved operating margins.

[0001104659-21-013712:8k_2_02:46]
“Continuing on the positive side,
I’m pleased to see the enthusiasm being generated in the market surrounding several new products and solutions recently introduced
at Doble, and we continue to see NRG’s end markets recovering as investments in renewable energy have been increasing in
both wind and solar. Our recently introduced solar products have been growing far better than anticipated and we expect that growth
to continue.

[0001104659-21-013712:8k_2_02:47]
“The performance of the Test segment
remained solid as we increased our EBIT margin to 12.9 percent in Q1 2021, up from 11.3 percent in Q1 2020 on slightly higher sales.
While not immune from COVID’s impact, our Test business continues to demonstrate its resilience by delivering consistently
solid operating results with increasing margins. We expect Test’s outlook to remain positive given the strength of its served
markets, primarily related to new communications technologies such as 5G and our growing shielding business. Our view of 5G’s
future is favorable given the size of the investments being made by numerous large, global companies leading its development.

[0001104659-21-013712:8k_2_02:48]
Our A&D segment’s results were
generally consistent with our previous sales and EBIT expectations. We anticipated a meaningful decrease in our commercial aerospace
businesses resulting from COVID to be partially offset by solid performance from our navy, defense and space businesses. Despite
the decline in commercial aerospace sales, A&D’s Adjusted EBIT margin was 15 percent, only slightly down from the 16
percent Adjusted EBIT margin reported in Q1 2020. Maintaining a reasonable operating margin during COVID’s impact reflects
the strength of our program, product and end-market diversity, as the navy and defense markets remained strong which partially
offset the decline in commercial aerospace. A&D’s operating margins are expected to improve significantly as the commercial
aerospace market recovers over time coupled with our resized operating cost structure implemented during 2020’s downturn.

[0001104659-21-013712:8k_2_02:49]
“The defense portion of A&D, both
military aerospace and navy products, is expected to remain strong for the foreseeable future given its sizeable backlog coupled
with the timing of expected platform deliveries.

[0001104659-21-013712:8k_2_02:50]
“Wrapping up, I’m pleased that
we were able to generate substantial cash from operations and increase our Adjusted EBITDA margin to 18 percent, from 16 percent
in Q1 2020, despite the lower contribution from our commercial aerospace business.

[0001104659-21-013712:8k_2_02:51]
“Given our strong financial condition,
we expect to fund future acquisitions and to organically grow our business through continued investment in new products and solutions.
We are currently evaluating a solid pipeline of M&A opportunities as we continue to take a prudent and deliberate approach
while evaluating our near-term targets. As end-markets continue to settle down and more clarity appears in our targeted areas,
we are confident that we will add to our current portfolio.

[0001104659-21-013712:8k_2_02:52]
“We have positioned ourselves favorably
from a cost structure standpoint and we anticipate a gradual return to a more normal operating environment in the second half of
2021. I continue to have a strong, favorable view of our future.”

[0001104659-21-013712:8k_2_02:53]
Dividend Payment

[0001104659-21-013712:8k_2_02:54]
The next quarterly cash dividend of $0.08
per share will be paid on April 16, 2021 to stockholders of record on April 1, 2021.

[0001104659-21-013712:8k_2_02:55]
Planned Retirement of General Counsel – 2021

[0001104659-21-013712:8k_2_02:56]
Alyson Barclay, Senior Vice President, Secretary
& General Counsel has announced her plans to retire in Q3 2021 after 33 successful years with the Company, with the past 21
years serving as General Counsel. Upon her retirement, Ms. Barclay will be succeeded by David (Dave) Schatz, currently serving
as ESCO’s Vice President, Intellectual Property Counsel & Assistant Secretary.

[0001104659-21-013712:8k_2_02:57]
Mr. Schatz has been an integral part of
the Company’s legal team since 1998 with a 22 year history of assuming positions with increasing responsibility, including
nearly a decade of direct operating unit experience. Mr. Schatz has extensive knowledge of the company’s operations, technologies,
intellectual property, regulatory matters, M&A and other complex legal matters.

[0001104659-21-013712:8k_2_02:58]
Vic Richey commented, “On behalf of
the Board of Directors and the entire organization, I want to thank Alyson for her exceptional legal counsel and leadership over
the past three decades. She has been a valued and trusted advisor to our management team and the Board and has been a significant
contributor to ESCO’s success as a long-term ally supporting me as CEO.”

[0001104659-21-013712:8k_2_02:59]
Ms. Barclay commented, “It has been
my honor and privilege to have spent my career working at such a great company with so many talented people.”

[0001104659-21-013712:8k_2_02:60]
Business Outlook – 2021 (COVID
Uncertainty)

[0001104659-21-013712:8k_2_02:61]
Our current Business Outlook for 2021 is
consistent with the commentary included in the Company’s previous earnings release dated November 19, 2020, and is updated
and repeated here.

[0001104659-21-013712:8k_2_02:62]
In mid-year 2020, business disruptions related
to the pandemic began to affect the Company’s operations and continued throughout the balance of the year. During 2021, the
commercial aerospace and utility end-markets have seen some degree of customer stabilization, as well as notable pockets of recovery;
however, there is still uncertainty as to the timing and pace of the recovery in these areas.

[0001104659-21-013712:8k_2_02:63]
The wide distribution of viable COVID-19
vaccines is anticipated to benefit and accelerate the recovery of commercial air travel and utility spending with customers resuming
normal testing protocols and equipment purchases, but Management has determined that it is advisable to wait at least another 90
days before resuming specific guidance.

[0001104659-21-013712:8k_2_02:64]
Given this uncertainty, it is difficult
to predict how the balance of 2021 will be affected using normal forecasting methodologies, therefore, the Company will continue
its suspension of forward-looking guidance.

[0001104659-21-013712:8k_2_02:65]
To assist shareholders and analysts, Management
will continue offering “directional” guidance for 2021, by stating that the Company is seeing tangible signs of recovery
in the second half of fiscal 2021 that point to a solid outlook for the back half of the year.

[0001104659-21-013712:8k_2_02:66]
Given the strength of the first half of
2020 pre-COVID, it is projected that the first half of 2021 will be a slightly lower comparison to 2020’s first half, but
the outlook for the second half of 2021 is expected to compare favorably to the second half of 2020 given the anticipated elements
of recovery.

[0001104659-21-013712:8k_2_02:67]
Management’s current expectations
for 2021 show growth in Sales, Adjusted EBITDA, and Adjusted EPS compared to 2020, with Adjusted EBITDA and Adjusted EPS reasonably
consistent with 2019.

[0001104659-21-013712:8k_2_02:68]
Conference Call

[0001104659-21-013712:8k_2_02:69]
The Company will host a conference call
today, February 8, at 4:00 p.m. Central Time, to discuss the Company’s Q1 2021 results. A live audio webcast will be available
on the Company’s website at www.escotechnologies.com. Please access the website at least 15 minutes prior to the call to
register, download and install any necessary audio software. A replay of the conference call will be available on the Company’s
website noted above or by phone (dial 1-855-859-2056 and enter the pass code 3478248).

[0001104659-21-013712:8k_2_02:70]
Forward-Looking Statements

[0001104659-21-013712:8k_2_02:71]
Statements in this press release regarding
the future impacts of COVID-19, including the impact of COVID-19 vaccines on the Company’s results, cost reduction efforts,
margins, growth, the financial success of the Company, the strength of its end markets, including without limitation, the timing
of expected recovery in selected end markets, growth in the Company’s solar business, delays in test equipment purchases
and maintenance-related projects by USG customers, the outlook for the A&D, Test and USG segments, the ability to increase
shareholder value, the success of acquisition efforts, internal investments in new products, the long-term success of the Company,
and any other statements which are not strictly historical are “forward-looking” statements within the meaning of the
safe harbor provisions of the federal securities laws.

[0001104659-21-013712:8k_2_02:72]
Investors are cautioned that such statements
are only predictions and speak only as of the date of this release, and the Company undertakes no duty to update them except as
may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from
those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and
business environment including but not limited to those described in Item 1A, “Risk Factors”, of the Company’s
Annual Report on Form 10-K for the fiscal year ended September 30, 2020, the continuing impact of the COVID-19 pandemic including
labor shortages, facility closures, shelter in place policies or quarantines, material shortages, transportation delays, termination
or delays of Company contracts, and the inability of our suppliers or customers to perform; the impacts of natural disasters on
the Company’s operations and those of the Company’s customers and suppliers; the timing and content of future contract
awards or customer orders; the appropriation, allocation and availability of Government funds; the termination for convenience
of Government and other customer contracts or orders; weakening of economic conditions in served markets; the success of the Company’s
competitors; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties;
the availability of selected acquisitions; delivery delays or defaults by customers; performance issues with key customers, suppliers
and subcontractors; material changes in the costs and availability of certain raw materials; labor disputes; changes in U.S. tax
laws and regulations; other changes in laws and regulations including but not limited to changes in accounting standards and foreign
taxation; changes in interest rates; costs relating to environmental matters arising from current or former facilities; uncertainty
regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the integration of recently acquired
businesses.

[0001104659-21-013712:8k_2_02:73]
Non-GAAP Financial Measures

[0001104659-21-013712:8k_2_02:74]
The financial measures EBIT, EBITDA, Adjusted
EBITDA and Adjusted EPS are presented in this press release. The Company defines “EBIT” as earnings before interest
and taxes, “EBITDA” as earnings before interest, taxes, depreciation and amortization, “Adjusted EBITDA”
as EBITDA excluding certain defined charges, and “Adjusted EPS” as GAAP earnings per share (EPS) excluding the net
impact of the items described above which were $0.03 per share in Q1 2021.

[0001104659-21-013712:8k_2_02:75]
EBIT, EBITDA, Adjusted EBITDA and Adjusted
EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management believes that
EBIT, EBITDA and Adjusted EBITDA are useful in assessing the operational profitability of the Company’s business segments
because they exclude interest, taxes, depreciation and amortization, which are generally accounted for across the entire Company
on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company
as well as incentive compensation. The presentation of EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS provides important supplemental
information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures
to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance
determined in accordance with GAAP.

[0001104659-21-013712:8k_2_02:76]
ESCO, headquartered in St. Louis, Missouri:
Manufactures highly-engineered filtration and fluid control products for the aviation, navy, space and process markets worldwide,
as well as composite-based products and solutions for navy, defense and industrial customers; is the industry leader in RF shielding
and EMC test products; and provides diagnostic instruments, software and services for the benefit of industrial power users and
the electric utility and renewable energy industries. Further information regarding ESCO and its subsidiaries is available on
the Company’s website at www.escotechnologies.com.

[0001104659-21-013712:8k_2_02:77]
ESCO TECHNOLOGIES
INC. AND SUBSIDIARIES

[0001104659-21-013712:8k_2_02:78]
Condensed Consolidated
Statements of Operations (Unaudited)

[0001104659-21-013712:8k_2_02:79]
(Dollars in
thousands, except per share amounts)

[0001104659-21-013712:8k_2_02:80]
|  |  | Three Months Ended December 31, 2020 |  |  | Three Months Ended December 31, 2019 |  |
| Net Sales |  | $ | 162,949 |  |  |  | 171,728 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 98,777 |  |  |  | 106,727 |  |
| Selling, general and administrative expenses |  |  | 41,000 |  |  |  | 42,105 |  |
| Amortization of intangible assets |  |  | 4,948 |  |  |  | 5,810 |  |
| Interest expense |  |  | 541 |  |  |  | 2,421 |  |
| Other expenses, net |  |  | 23 |  |  |  | 295 |  |
| Total costs and expenses |  |  | 145,289 |  |  |  | 157,358 |  |
| Earnings before income taxes |  |  | 17,660 |  |  |  | 14,370 |  |
| Income tax expense |  |  | 3,974 |  |  |  | 3,606 |  |
| Earnings from continuing operations |  |  | 13,686 |  |  |  | 10,764 |  |
| Loss from discontinued operations, net of tax expense (benefit) of $269 |  |  | - |  |  |  | (601 | ) |
| Gain on sale of discontinued operations, net of tax expense of $23,734 |  |  | - |  |  |  | 76,614 |  |
| Earnings from discontinued operations |  |  | - |  |  |  | 76,013 |  |
| Net earnings |  | $ | 13,686 |  |  |  | 86,777 |  |
| Diluted EPS: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.52 |  |  |  | 0.41 |  |
| Discontinued operations |  |  | 0.00 |  |  |  | 2.91 |  |
| Net earnings |  | $ | 0.52 |  |  |  | 3.32 |  |
| Diluted - As Adjusted Basis |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.55 | (1) |  |  | 0.43 | (2) |
| Diluted average common shares O/S: |  |  | 26,182 |  |  |  | 26,168 |  |

[0001104659-21-013712:8k_2_02:81]
|  | (1) | Q1 2021 Adjusted EPS excludes $0.03 per share of after-tax charges associated with the Doble Manta facility consolidation and ATM acquisition inventory step-up. |

[0001104659-21-013712:8k_2_02:82]
|  | (2) | Q1 2020 Adjusted EPS excludes $0.02 per share of after-tax charges associated with the move of the Doble headquarters facility. |

[0001104659-21-013712:8k_2_02:83]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-21-013712:8k_2_02:84]
Condensed Business Segment Information (Unaudited)

[0001104659-21-013712:8k_2_02:85]
(Dollars in thousands)

[0001104659-21-013712:8k_2_02:86]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | Q1 2021 |  |  | Q1 2020 |  |  | Q1 2021 |  |  | Q1 2020 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 66,891 |  |  |  | 77,511 |  |  |  | 66,891 |  |  |  | 77,511 |  |
| Test |  |  | 41,518 |  |  |  | 41,383 |  |  |  | 41,518 |  |  |  | 41,383 |  |
| USG |  |  | 54,540 |  |  |  | 52,834 |  |  |  | 54,540 |  |  |  | 52,834 |  |
| Totals |  | $ | 162,949 |  |  |  | 171,728 |  |  |  | 162,949 |  |  |  | 171,728 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 9,380 |  |  |  | 12,513 |  |  |  | 9,700 |  |  |  | 12,583 |  |
| Test |  |  | 5,342 |  |  |  | 4,656 |  |  |  | 5,342 |  |  |  | 4,656 |  |
| USG |  |  | 12,731 |  |  |  | 9,288 |  |  |  | 13,381 |  |  |  | 9,908 |  |
| Corporate |  |  | (9,252 | ) |  |  | (9,666 | ) |  |  | (9,192 | ) |  |  | (9,666 | ) |
| Consolidated EBIT |  |  | 18,201 |  |  |  | 16,791 |  |  |  | 19,231 |  |  |  | 17,481 |  |
| Less: Interest expense |  |  | (541 | ) |  |  | (2,421 | ) |  |  | (541 | ) |  |  | (2,421 | ) |
| Less: Income tax expense |  |  | (3,974 | ) |  |  | (3,606 | ) |  |  | (4,211 | ) |  |  | (3,772 | ) |
| Net earnings from continuing ops |  | $ | 13,686 |  |  |  | 10,764 |  |  |  | 14,479 |  |  |  | 11,288 |  |

[0001104659-21-013712:8k_2_02:87]
Note 1: The tables on this page are presented on a continuing operations basis.

[0001104659-21-013712:8k_2_02:88]
Note 2: Adjusted net
earnings were $14.5 million in Q1 2021 which excludes $0.03 per share of after-tax charges associated with the Doble Manta facility
consolidation and ATM acquisition inventory step-up.

[0001104659-21-013712:8k_2_02:89]
Note 3: Adjusted net earnings were $11.3 million in Q1 2020 which excludes
$0.02 per share of after-tax charges associated with the move of the Doble headquarters facility.

[0001104659-21-013712:8k_2_02:90]
| EBITDA Reconciliation to Net earnings: |  |  |  |  | Q1 2021 |  |  |  |  |  | Q1 2020 |  |
|  |  | Q1 2021 |  |  | - As Adj |  |  | Q1 2020 |  |  | - As Adj |  |
| Consolidated EBITDA |  | $ | 28,213 |  |  |  | 29,243 |  |  |  | 27,331 |  |  |  | 28,021 |  |
| Less: Depr & Amort |  |  | (10,012 | ) |  |  | (10,012 | ) |  |  | (10,540 | ) |  |  | (10,540 | ) |
| Consolidated EBIT |  |  | 18,201 |  |  |  | 19,231 |  |  |  | 16,791 |  |  |  | 17,481 |  |
| Less: Interest expense |  |  | (541 | ) |  |  | (541 | ) |  |  | (2,421 | ) |  |  | (2,421 | ) |
| Less: Income tax expense |  |  | (3,974 | ) |  |  | (4,211 | ) |  |  | (3,606 | ) |  |  | (3,772 | ) |
| Net earnings |  | $ | 13,686 |  |  |  | 14,479 |  |  |  | 10,764 |  |  |  | 11,288 |  |

[0001104659-21-013712:8k_2_02:91]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-21-013712:8k_2_02:92]
Condensed Consolidated Balance Sheets (Unaudited)

[0001104659-21-013712:8k_2_02:93]
(Dollars in thousands)

[0001104659-21-013712:8k_2_02:94]
|  |  | December 31, 2020 |  |  | September 30, 2020 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 57,362 |  |  |  | 52,560 |  |
| Accounts receivable, net |  |  | 143,675 |  |  |  | 144,082 |  |
| Contract assets |  |  | 93,762 |  |  |  | 96,746 |  |
| Inventories |  |  | 144,054 |  |  |  | 136,189 |  |
| Other current assets |  |  | 13,392 |  |  |  | 17,053 |  |
| Total current assets |  |  | 452,245 |  |  |  | 446,630 |  |
| Property, plant and equipment, net |  |  | 141,538 |  |  |  | 139,870 |  |
| Intangible assets, net |  |  | 347,437 |  |  |  | 346,632 |  |
| Goodwill |  |  | 411,161 |  |  |  | 408,063 |  |
| Operating lease assets |  |  | 20,315 |  |  |  | 21,390 |  |
| Other assets |  |  | 10,879 |  |  |  | 10,938 |  |
|  |  | $ | 1,383,575 |  |  |  | 1,373,523 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt & short-term borrowings |  | $ | 21,842 |  |  |  | 22,368 |  |
| Accounts payable |  |  | 44,198 |  |  |  | 50,525 |  |
| Contract liabilities |  |  | 112,286 |  |  |  | 100,551 |  |
| Other current liabilities |  |  | 76,297 |  |  |  | 82,585 |  |
| Total current liabilities |  |  | 254,623 |  |  |  | 256,029 |  |
| Deferred tax liabilities |  |  | 60,400 |  |  |  | 60,938 |  |
| Non-current operating lease liabilities |  |  | 15,746 |  |  |  | 16,785 |  |
| Other liabilities |  |  | 39,207 |  |  |  | 38,176 |  |
| Long-term debt |  |  | 34,000 |  |  |  | 40,000 |  |
| Shareholders' equity |  |  | 979,599 |  |  |  | 961,595 |  |
|  |  | $ | 1,383,575 |  |  |  | 1,373,523 |  |

[0001104659-21-013712:8k_2_02:95]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-21-013712:8k_2_02:96]
Consolidated Statements of Cash Flows (Unaudited)

[0001104659-21-013712:8k_2_02:97]
(Dollars in thousands)

[0001104659-21-013712:8k_2_02:98]
|  |  | Quarter Ended December 31, 2020 |  |
| Cash flows from operating activities: |  |  |  |  |
| Net earnings |  | $ | 13,686 |  |
| Adjustments to reconcile net earnings to net cash provided by operating activities: |  |  |  |  |
| Depreciation and amortization |  |  | 10,012 |  |
| Stock compensation expense |  |  | 1,368 |  |
| Changes in assets and liabilities |  |  | 264 |  |
| Effect of deferred taxes |  |  | (538 | ) |
| Net cash provided by operating activities |  |  | 24,792 |  |
| Cash flows from investing activities: |  |  |  |  |
| Acquisition of business, net of cash acquired |  |  | (6,508 | ) |
| Capital expenditures |  |  | (5,973 | ) |
| Additions to capitalized software |  |  | (1,554 | ) |
| Net cash used by investing activities |  |  | (14,035 | ) |
| Cash flows from financing activities: |  |  |  |  |
| Proceeds from long-term debt |  |  | 30,000 |  |
| Principal payments on long-term debt and short-term borrowings |  |  | (36,526 | ) |
| Dividends paid |  |  | (2,083 | ) |
| Net cash used by financing activities |  |  | (8,609 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 2,654 |  |
| Net increase in cash and cash equivalents |  |  | 4,802 |  |
| Cash and cash equivalents, beginning of period |  |  | 52,560 |  |
| Cash and cash equivalents, end of period |  | $ | 57,362 |  |

[0001104659-21-013712:8k_2_02:99]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-21-013712:8k_2_02:100]
Other Selected Financial Data (Unaudited)

[0001104659-21-013712:8k_2_02:101]
(Dollars in thousands)

[0001104659-21-013712:8k_2_02:102]
| Backlog And Entered Orders - Q1 2021 |  | Aerospace & Defense |  |  | Test |  |  | USG |  |  | Total |  |
| Beginning Backlog - 10/1/20 |  | $ | 344,661 |  |  |  | 122,032 |  |  |  | 50,688 |  |  |  | 517,381 |  |
| Entered Orders |  |  | 65,442 |  |  |  | 43,496 |  |  |  | 48,711 |  |  |  | 157,649 |  |
| Sales |  |  | (66,891 | ) |  |  | (41,518 | ) |  |  | (54,540 | ) |  |  | (162,949 | ) |
| Ending Backlog - 12/31/20 |  | $ | 343,212 |  |  |  | 124,010 |  |  |  | 44,859 |  |  |  | 512,081 |  |

[0001104659-21-013712:8k_2_02:103]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-21-013712:8k_2_02:104]
Reconciliation of
Non-GAAP Financial Measures (Unaudited)

[0001104659-21-013712:8k_2_02:105]
| EPS – Adjusted Basis Reconciliation – Q1 2021 |  |  |  |  |
| EPS from Continuing Ops – GAAP Basis – Q1 2021 |  | $ | 0.52 |  |
| Adjustments (defined below) |  |  | 0.03 |  |
| EPS from Continuing Ops – As Adjusted Basis – Q1 2021 |  | $ | 0.55 |  |
| Adjustments exclude $0.03 per share consisting of move costs associated with the Doble Manta facility consolidation and ATM acquisition inventory step-up in the first quarter of 2021. |  |
| (The $0.03 of EPS adjustments per share consists of $1,030K of pre-tax charges offset by $237K of tax benefit for net impact of $793K.) |  |
| EPS – Adjusted Basis Reconciliation – Q1 2020 |  |  |  |  |
| EPS from Continuing Ops – GAAP Basis – Q1 2020 |  | $ | 0.41 |  |
| Adjustments (defined below) |  |  | 0.02 |  |
| EPS from Continuing Ops – As Adjusted Basis – Q1 2020 |  | $ | 0.43 |  |
| Adjustments exclude $0.02 per share consisting of costs associated with the Move of the Doble headquarters facility in the first quarter of 2020. |  |
| (The $0.02 of EPS adjustments per share consists of $690K of pre-tax charges offset by $166K of tax benefit for net impact of $524K.) |  |

## item 5.02 — body, verbatim

[0001104659-21-013712:8k_body:1]
Item 5.02

[0001104659-21-013712:8k_body:2]
Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements
of Certain Officers

[0001104659-21-013712:8k_body:3]
As stated in the
Press Release attached hereto as Exhibit 99.1, Alyson Barclay, the Company’s Senior Vice President, Secretary and
General Counsel has announced her plans to retire in the third quarter of fiscal 2021. Upon her retirement she will be
succeeded by David (Dave) Schatz, who is currently the Company’s Vice President, Intellectual Property Counsel and
Assistant Secretary.
