# ESE MD&A — 0001104659-19-068679


## mdna

[0001104659-19-068679:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001104659-19-068679:mdna:2]
The following discussion should be read in conjunction with the Consolidated Financial Statements and Notes thereto and refers to the Company’s results from continuing operations, except where noted.

[0001104659-19-068679:mdna:3]
This section includes comparisons of certain 2019 financial information to the same information for 2018. Year-to-year comparisons of the 2018 financial information to the same information for 2017 are contained in Item 7 of the Company’s Form 10-K for 2018 filed with the Securities and Exchange Commission on November 29, 2018 and available through the SEC’s website at https://www.sec.gov/edgar/searchedgar/companysearch.html.

[0001104659-19-068679:mdna:4]
Introduction

[0001104659-19-068679:mdna:5]
ESCO Technologies Inc. and its wholly owned subsidiaries (the Company) are organized into four reportable operating segments for financial reporting purposes: Filtration/Fluid Flow (Filtration), RF Shielding and Test (Test), Utility Solutions Group (USG), and Technical Packaging. The Company’s business segments are comprised of the following primary operating entities:

[0001104659-19-068679:mdna:6]
|  | ● | Filtration: PTI Technologies Inc. (PTI); VACCO Industries (VACCO); Crissair, Inc. (Crissair); Westland Technologies, Inc. (Westland); Mayday Manufacturing Co. (Mayday), Hi-Tech Metals, Inc. (Hi-Tech); and Globe Composite Solutions, LLC (Globe). |

[0001104659-19-068679:mdna:7]
|  | ● | USG: Doble Engineering Company (Doble); Morgan Schaffer Ltd. (Morgan Schaffer); and NRG Systems, Inc. (NRG). |

[0001104659-19-068679:mdna:8]
|  | ● | Test: ETS-Lindgren Inc. (ETS-Lindgren). |

[0001104659-19-068679:mdna:9]
|  | ● | Technical Packaging: Thermoform Engineered Quality LLC (TEQ); Plastique Limited and Plastique Sp. z o.o. (together, Plastique). In November 2019 the Company entered into an agreement to sell the businesses comprising this segment. See “Subsequent Event” on page 7. |

[0001104659-19-068679:mdna:10]
Filtration. PTI, VACCO and Crissair primarily design and manufacture specialty filtration products, including hydraulic filter elements and fluid control devices used in commercial aerospace applications, unique filter mechanisms used in micro-propulsion devices for satellites and custom designed filters for manned aircraft and submarines. Westland designs, develops and manufactures elastomeric-based signature reduction solutions for U.S. naval vessels. Mayday designs and manufactures mission-critical bushings, pins, sleeves and precision-tolerance machined components for landing gear, rotor heads, engine mounts, flight controls, and actuation systems for the aerospace and defense industries. Hi-Tech is a full-service metal processor serving aerospace suppliers. Globe is a vertically integrated supplier of composite-based products and solutions for acoustic, signature-reduction, communications, sealing, vibration-reducing, surface control, and hydrodynamic-related applications.

[0001104659-19-068679:mdna:11]
USG. Doble provides high-end, intelligent diagnostic test solutions for the electric power delivery industry and is a leading supplier of power factor and partial discharge testing instruments used to assess the integrity of high-voltage power delivery equipment. Morgan Schaffer provides an integrated offering of dissolved gas analysis, oil testing, and data management solutions which enhance the ability of electric utilities to accurately monitor the health of critical power transformers. NRG designs and manufactures decision support tools for the renewable energy industry, primarily wind.

[0001104659-19-068679:mdna:12]
Test. ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy.

[0001104659-19-068679:mdna:13]
Technical Packaging. The companies within this segment provide innovative solutions to the medical and commercial markets for thermoformed and precision molded pulp fiber packages and specialty products using a wide variety of thin gauge plastics and pulp.

[0001104659-19-068679:mdna:14]
Selected financial information for each of the Company’s business segments is provided in the discussion below and in Note 13 to the Company’s Consolidated Financial Statements.

[0001104659-19-068679:mdna:15]
The Company continues to operate with meaningful growth prospects in its primary served markets and with considerable financial flexibility. The Company continues to focus on new products that incorporate proprietary design and process technologies. Management is committed to delivering shareholder value through organic growth, ongoing performance improvement initiatives, and acquisitions.

[0001104659-19-068679:mdna:16]
Highlights of 2019 Operations

[0001104659-19-068679:mdna:17]
|  | ● | Sales, net earnings and diluted earnings per share in 2019 were $813.0 million, $81.0 million and $3.10 per share, respectively, compared to sales, net earnings and diluted earnings per share in 2018 of $771.6 million, $92.1 million and $3.54 per share, respectively. |

[0001104659-19-068679:mdna:18]
|  | ● | Diluted EPS – As Adjusted for 2019 was $3.13 and excludes $0.6 million of pretax charges (or $0.03 per share after tax) consisting primarily of purchase accounting charges related to the Globe acquisition and certain restructuring charges related to facility consolidations at Doble, Plastique, PTI and VACCO partially offset by the gain on the Doble Watertown building sale. Diluted EPS – As Adjusted for 2018 was $2.77 and excludes $4.8 million of pretax charges (or $0.17 per share after tax) consisting primarily of charges related to closing the Doble offices in Norway, China, Dubai and Mexico, consisting of employee severance and compensation benefits, professional fees, and asset impairment charges; and restructuring charges at PTI related to the exit of the low margin industrial/automotive market. Also excluded for 2018 was a $24.4 million (or $0.94 per share) of net tax benefit recorded resulting from the implementation of U.S. Tax Reform. |

[0001104659-19-068679:mdna:19]
|  | ● | Net cash provided by operating activities was approximately $105.1 million in 2019 compared to $93.3 million in 2018. |

[0001104659-19-068679:mdna:20]
|  | ● | At September 30, 2019, cash on hand was $61.8 million and outstanding debt was $286.3 million, for a net debt position (total debt less net cash) of approximately $224.5 million. |

[0001104659-19-068679:mdna:21]
|  | ● | Entered orders for 2019 were $905.3 million resulting in a book-to-bill ratio of 1.11x. Backlog at September 30, 2019 was $475.1 million compared to $382.8 million at September 30, 2018. |

[0001104659-19-068679:mdna:22]
|  | ● | In July 2019, the Company acquired Globe for a purchase price of approximately $95 million, net of cash acquired. Since the date of acquisition, the operating results for Globe have been included within the Company’s Filtration segment. |

[0001104659-19-068679:mdna:23]
|  | ● | The Company declared dividends of $0.32 per share during 2019, totaling $8.3 million in dividend payments. |

[0001104659-19-068679:mdna:24]
Results of Operations

[0001104659-19-068679:mdna:25]
Net Sales

[0001104659-19-068679:mdna:26]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | Change |  |
| ​ | ​ | Fiscal year ended | ​ | 2019 |  |
| (Dollars in millions) |  | 2019 |  | 2018 |  | vs. 2018 |  |
| Filtration | ​ | $ | 325.8 |  | 286.8 |  | 13.6 | % |
| USG | ​ |  | 211.9 |  | 214.0 |  | (1.0) | % |
| Test | ​ |  | 188.4 |  | 182.9 |  | 3.0 | % |
| Technical Packaging | ​ |  | 86.9 |  | 87.9 |  | (1.1) | % |
| Total | ​ | $ | 813.0 |  | 771.6 |  | 5.4 | % |

[0001104659-19-068679:mdna:27]
Net sales increased $41.4 million, or 5.4%, to $813.0 million in 2019 from $771.6 million in 2018. The increase in net sales in 2019 as compared to 2018 was due to a $39.0 million increase in the Filtration segment and a $5.5 million increase in the Test segment, partially offset by a $2.1 million decrease in the USG segment and a $1.0 million decrease in the Technical Packaging segment.

[0001104659-19-068679:mdna:28]
Filtration.

[0001104659-19-068679:mdna:29]
The $39.0 million, or 13.6%, increase in net sales in 2019 as compared to 2018 was mainly due to a $14.3 million increase in net sales at PTI due to higher aerospace and assembly element shipments, a $11.1 million increase in net sales at Crissair due to higher aerospace shipments, an $8.9 million sales contribution from Globe (acquired in July 2019), a $6.8 million increase in net sales at Mayday due to higher aerospace shipments, and a $1.1 million increase in net sales at Westland, partially offset by a $3.2 million decrease in net sales at VACCO due to lower shipments of defense spares.

[0001104659-19-068679:mdna:30]
USG.

[0001104659-19-068679:mdna:31]
The $2.1 million, or 1.0%, decrease in net sales in 2019 as compared to 2018 was mainly due to a $9.5 million decrease in net sales at NRG due to continued softness in the renewable energy market, partially offset by a $7.4 million increase in net sales at Doble driven by a full year of Manta’s sales and higher F series product shipments.

[0001104659-19-068679:mdna:32]
Test.

[0001104659-19-068679:mdna:33]
The $5.5 million, or 3.0%, increase in net sales in 2019 as compared to 2018 was mainly due to a $7.7 million increase in net sales from the segment’s U.S. and Asian operations partially offset by a $2.2 million decrease in net sales from the segment’s European operations, both due to the timing of test and measurement chamber projects.

[0001104659-19-068679:mdna:34]
Technical Packaging.

[0001104659-19-068679:mdna:35]
The $1.0 million, or 1.1%, decrease in net sales in 2019 as compared to 2018 was mainly due to a $5.5 million decrease in net sales from Plastique due to lower shipments to commercial customers partially offset by a $4.5 million increase in net sales at TEQ.

[0001104659-19-068679:mdna:36]
Orders and Backlog

[0001104659-19-068679:mdna:37]
New orders received in 2019 were $905.3 million as compared to $777.2 million in 2018, resulting in order backlog of $475.1 million at September 30, 2019 as compared to order backlog of $382.8 million at September 30, 2018. Orders are entered into backlog as firm purchase order commitments are received.

[0001104659-19-068679:mdna:38]
In 2019, the Company recorded orders of $409.9 million related to Filtration products, $212.9 million related to USG products, $199.6 million related to Test products and $82.9 million related to Technical Packaging products. In 2018, the Company recorded orders of $287.9 million related to Filtration products, $219.1 million related to USG products, $190.4 million related to Test products and $79.8 million related to Technical Packaging products.

[0001104659-19-068679:mdna:39]
Selling, General and Administrative Expenses

[0001104659-19-068679:mdna:40]
Selling, general and administrative (SG&A) expenses were $172.1million, or 21.2% of net sales, in 2019, and $162.4 million, or 21.0% of net sales, in 2018.

[0001104659-19-068679:mdna:41]
The increase in SG&A expenses in 2019 as compared to 2018 was mainly due to an increase in the USG segment due to higher sales commissions including additional sales and marketing expenses to support future revenue growth.

[0001104659-19-068679:mdna:42]
Amortization of Intangible Assets

[0001104659-19-068679:mdna:43]
Amortization of intangible assets was $19.5 million in 2019 and $18.3 million in 2018. Amortization of intangible assets included $11.8 million and $10.9 million of amortization of acquired intangible assets in 2019 and 2018, respectively, related to the Company’s acquisitions. The amortization of acquired intangible assets related to the Company’s acquisitions is included in the Corporate operating segment’s results. The remaining amortization expenses relate to other identifiable intangible assets (primarily software, patents and licenses), which are included in the respective segment’s operating results. The increase in amortization expense in 2019 as compared to 2018 was mainly due to an increase in amortization of intangible assets related to the Company’s recent acquisitions.

[0001104659-19-068679:mdna:44]
Other Expenses or Income, Net

[0001104659-19-068679:mdna:45]
Other expenses, net, were $2.2 million in 2019, compared to other expenses, net, of $3.7 million in 2018. The principal components of other expenses, net, in 2019 included $3 million of purchase accounting charges related to the Globe acquisition; $1.4 million of restructuring charges incurred related to the Plastique facility consolidation in 2019 consisting primarily of severance and compensation benefits and asset impairment charges; $0.9 million of restructuring charges related to the consolidation of VACCO’s aircraft/aerospace business into PTI’s aerospace facility in Oxnard, California; approximately $1 million of charges at Doble related to facility consolidations begun in 2018; and approximately $3 million of losses on derivative instruments; partially offset by a net gain of approximately $8 million on the sale of the Doble Watertown, MA building and land. The principal components of other expenses, net, in 2018 included $3 million of charges related to the USG segment restructuring activities, including the Doble facility consolidations in Norway, China, Dubai and Mexico; and $0.8 million of charges within the Filtration segment due to the exit of the low margin industrial/automotive market. There were no other individually significant items included in other expenses, net, in 2019 or 2018.

[0001104659-19-068679:mdna:46]
Non-GAAP Financial Measures

[0001104659-19-068679:mdna:47]
The information reported herein includes the financial measures EPS – As Adjusted, which the Company defines as EPS excluding the per-share net impact of the purchase accounting charges related to the Globe acquisition and the restructuring charges incurred at Doble, Plastique, PTI and VACCO during fiscal 2019, partially offset by the gain on the Doble Watertown, MA property sale; and restructuring charges related to the Company’s restructuring actions in 2018 and the net recorded per-share tax benefit resulting from the implementation of U.S. Tax Reform in 2018; EBIT, which the Company defines as earnings before interest and taxes; and EBIT margin, which the Company defines as EBIT expressed as a percentage of net sales. EPS – As Adjusted, EBIT on a consolidated basis, and EBIT margin on a consolidated basis are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, the Company believes that EBIT and EBIT margin provide investors and Management with valuable information for assessing the Company’s operating results. Management evaluates the performance of its operating segments based on EBIT and believes that EBIT is useful to investors to demonstrate the operational profitability of the Company’s business segments by excluding interest and taxes, which are generally accounted for across the entire company on a consolidated basis. EBIT is also one of the measures Management uses to determine resource allocations and incentive compensation. The Company believes that the presentation of EBIT, EBIT margin and EPS – As Adjusted provides important supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance determined in accordance with GAAP.

[0001104659-19-068679:mdna:48]
EBIT

[0001104659-19-068679:mdna:49]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | Change |  |
| ​ | ​ | Fiscal year ended | ​ | 2019 |  |
| (Dollars in millions) |  | 2019 |  | 2018 |  | vs. 2018 |  |
| Filtration | ​ | $ | 70.1 |  | 58.7 |  | 19.4 | % |
| % of net sales | ​ |  | 21.5 | % | 20.5 | % |  | ​ |
| USG | ​ |  | 52.2 |  | 43.2 |  | 20.8 | % |
| % of net sales | ​ |  | 24.6 | % | 20.2 | % |  | ​ |
| Test | ​ |  | 25.6 |  | 23.8 |  | 7.6 | % |
| % of net sales | ​ |  | 13.6 | % | 13.0 | % |  | ​ |
| Technical Packaging | ​ |  | 5.9 |  | 8.1 |  | (27.2) | % |
| % of net sales | ​ |  | 6.8 | % | 9.2 | % |  | ​ |
| Corporate | ​ |  | (43.2) |  | (37.0) |  | 16.8 | % |
| Total | ​ | $ | 110.6 |  | 96.8 |  | 14.3 | % |
| % of net sales | ​ |  | 13.6 | % | 12.5 | % |  | ​ |

[0001104659-19-068679:mdna:50]
21

[0001104659-19-068679:mdna:51]
The reconciliation of EBIT to a GAAP financial measure is as follows:

[0001104659-19-068679:mdna:52]
| (Dollars in millions) |  | 2019 |  | 2018 |
| Net earnings | ​ | $ | 81.0 |  | 92.1 |
| Add: Interest expense | ​ |  | 8.4 |  | 8.8 |
| Add (less): Income taxes | ​ |  | 21.2 |  | (4.1) |
| EBIT | ​ | $ | 110.6 |  | 96.8 |

[0001104659-19-068679:mdna:53]
Filtration

[0001104659-19-068679:mdna:54]
The $11.4 million increase in EBIT in 2019 as compared to 2018 was primarily due to the EBIT contribution from higher sales volumes at PTI, Crissair, Mayday and Westland and Globe (acquired July 2019). EBIT in 2019 was negatively impacted by $0.9 million of restructuring charges related to the consolidation of VACCO’s aircraft/aerospace business into PTI’s aerospace facility in Oxnard, California and $0.3 million of purchase accounting charges at Globe related to the inventory step-up charge.

[0001104659-19-068679:mdna:55]
USG

[0001104659-19-068679:mdna:56]
The $9.0 million increase in EBIT in 2019 as compared to 2018 was primarily due to a $12.0 million increase in EBIT at Doble (which included a net gain on the sale of the Doble Watertown facility of approximately $8.0 million partially offset by certain charges to close the Doble facilities in Dubai and Mexico), and also due to higher sales volumes at Doble; partially offset by a $3.0 million decrease in EBIT from NRG due to softness in the renewable energy market.

[0001104659-19-068679:mdna:57]
Test

[0001104659-19-068679:mdna:58]
The $1.8 million increase in EBIT in 2019 as compared to 2018 was primarily due to the increased sales volumes from the segment’s U.S. and Asian operations.

[0001104659-19-068679:mdna:59]
Technical Packaging

[0001104659-19-068679:mdna:60]
The $2.2 million decrease in EBIT in 2019 as compared to 2018 was primarily due to the $1.4 million of restructuring charges incurred related to the Plastique facility consolidation in 2019. These charges consisted primarily of severance and compensation benefits and asset impairment charges.

[0001104659-19-068679:mdna:61]
Corporate

[0001104659-19-068679:mdna:62]
Corporate operating charges included in 2019 consolidated EBIT increased to $43.2 million as compared to $37.0 million in 2018 due to purchase accounting charges related to the Globe acquisition, higher professional fees and acquisition costs.

[0001104659-19-068679:mdna:63]
The “Reconciliation to Consolidated Totals (Corporate)” in Note 13 to the Consolidated Financial Statements represents Corporate office operating charges.

[0001104659-19-068679:mdna:64]
Interest Expense, Net

[0001104659-19-068679:mdna:65]
Interest expense was $8.4 million in 2019 compared to $8.8 million in 2018, due to lower average outstanding borrowings ($236.4 million compared to $258.8 million) partially offset by higher average interest rates (3.2% vs. 3.0%) as a result of the additional borrowings to fund the Company’s recent acquisitions.

[0001104659-19-068679:mdna:66]
Income Tax Expense

[0001104659-19-068679:mdna:67]
On December 22, 2017, President Trump signed into law new tax legislation commonly referred to as the Tax Cut and Jobs Act (the “TCJA”). Provisions under the TCJA affecting the Company include a further reduction in the U.S. statutory rate to 21%, a new minimum tax on global intangible low-taxed income (“GILTI”), the benefit of the deduction for foreign-derived intangible income (“FDII”), and changes to IRC Section 162(m) related to the deductibility of executive compensation.

[0001104659-19-068679:mdna:68]
The effective tax rates for 2019, 2018 and 2017 were 20.7%, (4.7)% and 33.0%, respectively. The increase in the 2019 effective tax rate as compared to 2018 was primarily due to the enactment of the TCJA. The specific impacts of the TCJA in 2018 were primarily as follows:

[0001104659-19-068679:mdna:69]
|  | ● | The Company’s 2018 federal statutory rate decreased from 35.0% to 24.5%, which required an adjustment to the value of its deferred tax assets and liabilities. This adjustment of $30.6 million (complete as of September 30, 2018) favorably impacted the 2018 effective tax rate by 34.8%. |

[0001104659-19-068679:mdna:70]
|  | ● | The TCJA subjected the Company’s cumulative foreign earnings to $3.7 million (complete as of December 31, 2018) of federal income tax which unfavorably impacted the 2018 effective tax rate by 4.2%. In addition to the impacts from the TCJA, the Company recorded $2.4 million (complete as of September 30, 2018) for the income tax effects of the current and future repatriation of the cumulative earnings of its foreign subsidiaries which unfavorably impacted the 2018 effective tax rate by 2.8%. |

[0001104659-19-068679:mdna:71]
|  | ● | The Company approved an additional $7.5 million pension contribution for the 2017 plan year during the second quarter of 2018 resulting in a favorable adjustment to the 2018 effective tax rate of 0.9%. |

[0001104659-19-068679:mdna:72]
|  | ● | An accounting method change was filed with the 2017 tax return which resulted in a favorable adjustment to the 2018 effective tax rate of 0.7%. |

[0001104659-19-068679:mdna:73]
The 2019 effective tax rate was favorably impacted by tax planning strategies to increase foreign tax credits claimed retrospectively. The Company reduced the valuation allowance for excess foreign tax credits by $2.4 million and recorded an amended return benefit of $0.3 million, which favorably impacted the 2019 effective tax rate by 2.8%.

[0001104659-19-068679:mdna:74]
The TJCA made comprehensive changes to U.S. federal income tax laws by moving from a global to a modified territorial tax regime. As a result, cash repatriated to the U.S. is generally no longer subject to U.S. federal income tax. No provision is made for foreign withholding any applicable U.S. income taxes on the undistributed earnings of non-U.S. subsidiaries where these earnings are considered indefinitely invested or otherwise retained for continuing international operations. Determination of the amount of taxes that might be paid on these undistributed earnings if eventually remitted is not practicable.

[0001104659-19-068679:mdna:75]
Acquisitions and Dispositions

[0001104659-19-068679:mdna:76]
Information regarding the Company’s acquisitions during 2019, 2018 and 2017 is set forth in Note 2 to the Company’s Consolidated Financial Statements, which Note is incorporated by reference herein.

[0001104659-19-068679:mdna:77]
All of the Company’s acquisitions have been accounted for using the purchase method of accounting, and accordingly, the respective purchase prices were allocated to the assets (including intangible assets) acquired and liabilities assumed based on estimated fair values at the date of acquisition. The financial results from these acquisitions have been included in the Company’s financial statements from the date of acquisition.

[0001104659-19-068679:mdna:78]
Subsequent to the end of fiscal 2019 the Company entered into an agreement to sell the business comprising its Technical Packaging segment. See “Subsequent Event” on page 7.

[0001104659-19-068679:mdna:79]
Capital Resources and Liquidity

[0001104659-19-068679:mdna:80]
The Company’s overall financial position and liquidity are strong. Working capital (current assets less current liabilities) increased to $243.6 million at September 30, 2019 from $195.5 million at September 30, 2018. Contract assets increased $62.3 million in 2019 mainly within the Filtration segment due to the adoption of ASU No. 2014-09, Revenue from Contracts with Customers (ASC 606). Inventories decreased by $6.6 million during 2019 mainly due to a 9.5 million decrease within the Filtration segment resulting primarily from the adoption of ASC 606. The $8.3 million increase in accounts payable at September 30, 2019 was mainly due to a $4.9 million increase within the Test segment and a $4.0 million increase within the Technical Packaging segment both due to the timing of payments.

[0001104659-19-068679:mdna:81]
Net cash provided by operating activities was $105.1 million and $93.3 million in 2019 and 2018, respectively.

[0001104659-19-068679:mdna:82]
Net cash used in investing activities was $125.1 million and $41.6 million in 2019 and 2018, respectively. The increase in net cash used in investing activities in 2019 as compared to 2018 was due to the Globe acquisition and higher capital expenditures. Capital expenditures were $37.2 million and $20.6 million in 2019 and 2018, respectively. The increase in capital expenditures in 2019 as compared to 2018 was mainly due to the facility expansion at TEQ in 2019. There were no commitments outstanding that were considered material for capital expenditures at September 30, 2019. In addition, the Company incurred expenditures for capitalized software of $8.4 million and $9.6 million in 2019 and 2018, respectively.

[0001104659-19-068679:mdna:83]
The Company made pension contributions of $2.5 million and $10.0 million in 2019 and 2018, respectively.

[0001104659-19-068679:mdna:84]
Net cash provided by financing activities was $53.5 million in 2019, compared to net cash used by financing activities of $66.4 million in 2018. The change in 2019 as compared to 2018 was primarily due to additional borrowings in 2019 related to the Globe acquisition.

[0001104659-19-068679:mdna:85]
Bank Credit Facility

[0001104659-19-068679:mdna:86]
A description of the Company’s credit facility (the “Credit Facility”) is set forth in Note 8 to the Company’s Consolidated Financial Statements, which Note is incorporated by reference herein.

[0001104659-19-068679:mdna:87]
Cash flow from operations and borrowings under the Credit Facility is expected to provide adequate resources to meet the Company’s capital requirements and operational needs for the foreseeable future.

[0001104659-19-068679:mdna:88]
Dividends

[0001104659-19-068679:mdna:89]
Since 2010, the Company has paid a regular quarterly cash dividend at an annual rate of $0.32 per share. The Company paid dividends of $8.3 million and $8.3 million in 2019 and 2018, respectively.

[0001104659-19-068679:mdna:90]
Contractual Obligations

[0001104659-19-068679:mdna:91]
The following table shows the Company’s contractual obligations as of September 30, 2019:

[0001104659-19-068679:mdna:92]
| ​ | ​ | Payments due by period |
| ​ | ​ | ​ | ​ | ​ | Less than | ​ | 1 to 3 | ​ | 3 to 5 | ​ | More than |
| (Dollars in millions) |  | Total |  | 1 year |  | years |  | years |  | 5 years |
| Long-Term Debt Obligation | ​ | $ | 286.3 |  | 1.3 |  | — |  | 285.0 |  | — |
| Estimated Interest Payments (1) | ​ |  | 25.1 |  | 9.6 |  | 12.9 |  | 2.6 |  | — |
| Operating Lease Obligations | ​ |  | 30.0 |  | 6.4 |  | 9.9 |  | 5.7 |  | 8.0 |
| Purchase Obligations (2) | ​ |  | 18.2 |  | 18.2 |  | — |  | — |  | — |
| Total | ​ | $ | 359.6 |  | 35.5 |  | 22.8 |  | 293.3 |  | 8.0 |

[0001104659-19-068679:mdna:93]
|  | (1) | Estimated interest payments for the Company’s debt obligations were calculated based on Management’s determination of the estimated applicable interest rates and payment dates. |

[0001104659-19-068679:mdna:94]
|  | (2) | A purchase obligation is defined as a legally binding and enforceable agreement to purchase goods and services that specifies all significant terms. Since the majority of the Company’s purchase orders can be cancelled, they are not included in the table above. |

[0001104659-19-068679:mdna:95]
The Company had no off-balance-sheet arrangements outstanding at September 30, 2019.

[0001104659-19-068679:mdna:96]
Share Repurchases

[0001104659-19-068679:mdna:97]
Information about the Company’s common stock repurchases is provided in Note 9 to the Consolidated Financial Statements.

[0001104659-19-068679:mdna:98]
Pension Funding Requirements

[0001104659-19-068679:mdna:99]
The minimum cash funding requirements related to the Company’s defined benefit pension plans are estimated to be approximately $0 in 2020, $0 in 2021, and $1.4 million in 2022. Additional information about the Company’s pension plans is provided in Note 11 to the Consolidated Financial Statements.

[0001104659-19-068679:mdna:100]
Other

[0001104659-19-068679:mdna:101]
As a normal incident of the business in which the Company is engaged, various claims, charges and litigation are asserted or commenced from time to time against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. It is the opinion of Management that the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company are adequately reserved for, are covered by insurance or are not likely to have a material adverse effect on the Company’s results of operations, capital expenditures or competitive position.

[0001104659-19-068679:mdna:102]
Outlook

[0001104659-19-068679:mdna:103]
Management continues to see meaningful organic sales, Adjusted EBIT and Adjusted EBITDA growth across each of the Company’s business segments, and anticipates that growth rates in 2020 and beyond will generally exceed the broader industrial market. Given the pending sale of the Technical Packaging business expected to be completed in the first half of 2020 (see “Subsequent Event” on page 7), this business will be reported as discontinued operations in 2020 and is excluded from the Outlook section and comparisons to 2019 described below. The details of Management’s growth expectations for 2020 compared to 2019 are as follows:

[0001104659-19-068679:mdna:104]
|  | ● | Sales from continuing operations are expected to increase 9 to 10 percent on a consolidated basis, with Filtration growing 13.5 to 14.5 percent, USG growing 7 to 8 percent and Test growing 4 to 5 percent; |

[0001104659-19-068679:mdna:105]
|  | ● | Interest expense is expected to be lower than 2019, and will be impacted by the timing of the final after-tax cash proceeds received on the sale of the Technical Packaging business; |

[0001104659-19-068679:mdna:106]
|  | ● | Non-cash depreciation and amortization of intangible assets is expected to increase approximately $5 million, or $0.15 per share after-tax, related to previous acquisitions and capital spending; |

[0001104659-19-068679:mdna:107]
|  | ● | Income tax expense is expected to increase as Management is expecting a 23 to 24 percent effective tax rate calculated on higher pretax earnings; |

[0001104659-19-068679:mdna:108]
|  | ● | In summary, excluding Technical Packaging and the accounting impact of terminating and annuitizing the Company’s defined benefit pension plan, Management projects 2020 Adjusted EPS to be in the range of $3.20 to $3.30 per share (compared to 2019 Adjusted EPS of $2.95 per share, excluding the 2019 results of Technical Packaging). |

[0001104659-19-068679:mdna:109]
On a quarterly basis and consistent with prior years, Management expects 2020 revenues and Adjusted EPS to be more second-half weighted. Management expects Q1 2020 Adjusted EPS to be in the range of $0.35 to $0.40 per share.

[0001104659-19-068679:mdna:110]
Market Risk Exposure

[0001104659-19-068679:mdna:111]
Market risks relating to the Company’s operations result primarily from changes in interest rates and changes in foreign currency exchange rates. The Company is exposed to market risk related to changes in interest rates and selectively uses derivative financial instruments, including forward contracts and swaps, to manage these risks. In 2018, the Company entered into three interest rate swaps with a notional amount of $150 million to hedge some of its exposure to variability in future LIBOR-based interest payments on variable rate debt. In addition, the Company’s Canadian subsidiary Morgan Schaffer entered into foreign exchange contracts to manage foreign currency risk, as a portion of their revenue is denominated in U.S. dollars. All derivative instruments are reported on the balance sheet at fair value. For derivative instruments designated as cash flow hedges, the gain or loss on the derivative is deferred in accumulated other comprehensive income until recognized in earnings with the underlying hedged item. The interest rate swaps entered into during 2018 were not designated as cash flow hedges and therefore the gain or loss on the derivative is reflected in earnings each period.

[0001104659-19-068679:mdna:112]
The Company is also subject to foreign currency exchange rate risk inherent in its sales commitments, anticipated sales, anticipated purchases and assets and liabilities denominated in currencies other than the U.S. dollar. The foreign currencies most significant to the Company’s operations are the Canadian Dollar and the Euro. The Company occasionally hedges certain foreign currency commitments by purchasing foreign currency forward contracts. The Company does not have material foreign currency market risk; net foreign currency transaction gain/loss was less than 2% of net earnings for 2019 and 2018.

[0001104659-19-068679:mdna:113]
The Company has determined that the market risk related to interest rates with respect to its variable debt is not material. The Company estimates that if market interest rates averaged one percentage point higher, the effect would have been less than 3% of net earnings for the year ended September 30, 2019.

[0001104659-19-068679:mdna:114]
For more information about the Company’s derivative financial instruments, see Note 12 to the Company’s Consolidated Financial Statements included herein.

[0001104659-19-068679:mdna:115]
Critical Accounting Policies

[0001104659-19-068679:mdna:116]
The preparation of financial statements in conformity with U.S. generally accepted accounting principles (GAAP) requires Management to make estimates and assumptions in certain circumstances that affect amounts reported in the Consolidated Financial Statements. In preparing these financial statements, Management has made its best estimates and judgments of certain amounts included in the Consolidated Financial Statements, giving due consideration to materiality. The Company does not believe there is a great likelihood that materially different amounts would be reported under different conditions or using different assumptions related to the accounting policies described below. However, application of these accounting policies involves the exercise of judgment and use of assumptions as to future uncertainties and, as a result, actual results could differ from these estimates. The Company’s senior Management discusses the critical accounting policies described below with the Audit and Finance Committee of the Company’s Board of Directors on a periodic basis.

[0001104659-19-068679:mdna:117]
The following discussion of critical accounting policies is intended to bring to the attention of readers those accounting policies which Management believes are critical to the Consolidated Financial Statements and other financial disclosure. It is not intended to be a comprehensive list of all significant accounting policies that are more fully described in Note 1 to the Consolidated Financial Statements.

[0001104659-19-068679:mdna:118]
Revenue Recognition

[0001104659-19-068679:mdna:119]
Information regarding the recognition of revenue by the entities in each of the Company’s business segments is set forth in Note 1.E to the Company’s Consolidated Financial Statements.

[0001104659-19-068679:mdna:120]
Income Taxes

[0001104659-19-068679:mdna:121]
The Company operates in numerous taxing jurisdictions and is subject to examination by various U.S. Federal, state and foreign jurisdictions for various tax periods. The Company’s income tax positions are based on research and interpretations of the income tax laws and rulings in each of the jurisdictions in which the Company does business. Due to the subjectivity of interpretations of laws and rulings in each jurisdiction, the differences and interplay in tax laws between those jurisdictions, as well as the inherent uncertainty in estimating the final resolution of complex tax audit matters, Management’s estimates of income tax liabilities may differ from actual payments or assessments.

[0001104659-19-068679:mdna:122]
On December 22, 2017, the U.S. government enacted the TCJA, which, among other things, lowered the U.S. corporate statutory income tax rate and established a modified territorial system requiring a mandatory deemed repatriation on undistributed earnings of foreign subsidiaries. The Company completed its analysis of the impact of the TCJA during the first quarter of 2019.

[0001104659-19-068679:mdna:123]
Income taxes are accounted for under the asset and liability method. Deferred tax assets and liabilities are recognized for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. Deferred tax assets may be reduced by a valuation allowance if it is more likely than not that some portion of the deferred tax assets will not be realized. The effect on deferred tax assets and liabilities of a change in tax rates is recognized in income in the period that includes the enactment date. The Company regularly reviews its deferred tax assets for recoverability and establishes a valuation allowance when Management believes it is more likely than not such assets will not be recovered, taking into consideration historical operating results, expectations of future earnings, tax planning strategies, and the expected timing of the reversals of existing temporary differences.

[0001104659-19-068679:mdna:124]
Goodwill and Other Long-Lived Assets

[0001104659-19-068679:mdna:125]
Management annually reviews goodwill and other long-lived assets with indefinite useful lives for impairment or whenever events or changes in circumstances indicate the carrying amount may not be recoverable. If the Company determines that the carrying value of the long-lived asset may not be recoverable, a permanent impairment charge is recorded for the amount by which the carrying value of the long-lived asset exceeds its fair value. Fair value is measured based on a discounted cash flow method using a discount rate determined by Management to be commensurate with the risk inherent in each of our reporting units’ current business models. The estimates of cash flows and discount rate are subject to change due to the economic environment, including such factors as interest rates, expected market returns and volatility of markets served. Management believes that the estimates of future cash flows and fair value are reasonable; however, changes in estimates could result in impairment charges. At September 30, 2019, the Company has determined that no reporting units are at risk of goodwill impairment as the fair value of each reporting unit exceeded its carrying value.

[0001104659-19-068679:mdna:126]
Intangible assets with estimable useful lives are amortized over their respective estimated useful lives to their estimated residual values, and are reviewed for impairment whenever events or changes in business circumstances indicate the carrying value of the assets may not be recoverable.

[0001104659-19-068679:mdna:127]
Other Matters

[0001104659-19-068679:mdna:128]
Contingencies

[0001104659-19-068679:mdna:129]
As a normal incident of the businesses in which the Company is engaged, various claims, charges and litigation are asserted or commenced from time to time against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. It is the opinion of Management that the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company are adequately accrued, are covered by insurance or are not likely to have a material adverse effect on the Company’s results from continuing operations, capital expenditures, or competitive position.

[0001104659-19-068679:mdna:130]
Quantitative and Qualitative Disclosures about Market Risk

[0001104659-19-068679:mdna:131]
Market risks relating to the Company’s operations result primarily from changes in interest rates and changes in foreign currency exchange rates. The Company is exposed to market risk related to changes in interest rates and selectively uses derivative financial instruments, including forward contracts and swaps, to manage these risks. In 2018, the Company entered into three interest rate swaps with a notional amount of $150 million to hedge some of its exposure to variability in future LIBOR-based interest payments on variable rate debt. In addition, the Company’s Canadian subsidiary Morgan Schaffer has entered into foreign exchange contracts to manage foreign currency risk as a portion of their revenue is denominated in U.S. dollars. All derivative instruments are reported on the balance sheet at fair value. For derivative instruments designated as cash flow hedges, the gain or loss on the derivative is deferred in accumulated other comprehensive income until recognized in earnings with the underlying hedged item. See further discussion regarding the Company’s market risks in “Market Risk Analysis,” above.

[0001104659-19-068679:mdna:132]
Controls and Procedures

[0001104659-19-068679:mdna:133]
For a description of the Company’s evaluation of its disclosure controls and procedures, see Item 9A, “Controls and Procedures.”

[0001104659-19-068679:mdna:134]
New Accounting Pronouncements

[0001104659-19-068679:mdna:135]
Information regarding new and updated accounting standards which affect the content and/or presentation of the Company’s financial information is set forth in Note 1.V to the Company’s Consolidated Financial Statements included herein.
