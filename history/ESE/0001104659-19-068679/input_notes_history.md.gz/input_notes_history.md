# ESE note change history — 0001144204-19-024737 → 0001144204-19-038765


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-08-09):
[0001144204-19-038765:note_history:1]
1.    BASIS OF PRESENTATION
  (was, 2019-05-09, similarity 0.8519):
[0001144204-19-024737:note_history:1]
|  | 1. | BASIS OF PRESENTATION |

- changed (2019-08-09):
[0001144204-19-038765:note_history:2]
The Company’s results for the three and nine-month periods ended June 30, 2019 are not necessarily indicative of the results for the entire 2019 fiscal year. References to the third quarters of 2019 and 2018 represent the fiscal quarters ended June 30, 2019 and 2018, respectively.
  (was, 2019-05-09, similarity 0.9344):
[0001144204-19-024737:note_history:2]
The Company’s results for the three and six-month periods ended March 31, 2019 are not necessarily indicative of the results for the entire 2019 fiscal year. References to the second quarters of 2019 and 2018 represent the fiscal quarters ended March 31, 2019 and 2018, respectively.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-08-09):
[0001144204-19-038765:note_history:3]
2.    SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES UPDATE
  (was, 2019-05-09, similarity 0.9273):
[0001144204-19-024737:note_history:3]
|  | 2. | SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES UPDATE |

- changed (2019-08-09):
[0001144204-19-038765:note_history:4]
Our significant accounting policies are included in Note 1 of our Annual Report on Form 10-K for the year ended September 30, 2018. On October 1, 2018, we adopted ASU No. 2014-09, Revenue from Contracts with Customers (ASC 606). Significant changes to our policies resulting from the adoption are provided below. We adopted ASC 606 using the modified retrospective transition method applied to contracts that were not substantially complete at the end of fiscal year 2018. We recorded a $4.2 million adjustment to increase retained earnings to reflect the cumulative impact of adopting this standard at the beginning of fiscal year 2019, primarily related to certain long-term contracts our Filtration and Technical Packaging segments have that converted to the cost-to-cost method for revenue recognition. The comparative information has not been restated and is reported under the accounting standards in effect for those periods. A reconciliation of the financial statement line items impacted for the three and nine months ended June 30, 2019 under ASC 606 to the prior accounting standards is provided in Note 14.
  (was, 2019-05-09, similarity 0.8706):
[0001144204-19-024737:note_history:4]
. Significant changes to our policies resulting from the adoption are provided below. We adopted ASC 606 using the modified retrospective transition method applied to contracts that were not substantially complete at the end of fiscal year 2018. We recorded a $4.2 million adjustment to increase retained earnings to reflect the cumulative impact of adopting this standard at the beginning of fiscal year 2019, primarily related to certain long-term contracts our Filtration and Technical Packaging segments have that converted to the cost-to-cost method for revenue recognition. The comparative information has not been restated and is reported under the accounting standards in effect for those periods. A reconciliation of the financial statement line items impacted for the three and six months ended March 31, 2019 under ASC 606 to the prior accounting standards is provided in Note 14.

- changed (2019-08-09):
[0001144204-19-038765:note_history:5]
Filtration: Within the Filtration segment, approximately 48% of revenues (approximately 18% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial and military customers and have a single performance obligation as there is only one good promised or the promise to transfer the goods or services is not distinct or separately identifiable from other promises in the contract. The transaction price for these contracts reflects our estimate of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.
  (was, 2019-05-09, similarity 0.9966):
[0001144204-19-024737:note_history:5]
Within the Filtration segment, approximately 48% of revenues (approximately 18% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial and military customers and have a single performance obligation as there is only one good promised or the promise to transfer the goods or services is not distinct or separately identifiable from other promises in the contract. The transaction price for these contracts reflects our estimate of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

- changed (2019-08-09):
[0001144204-19-038765:note_history:6]
Approximately 52% of the segment’s revenues (approximately 19% of consolidated revenues) are accounted for over time as the product does not have an alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin or the inventory is owned by the customer. The related contracts are primarily cost-plus or fixed price contracts related to the design, development and manufacture of complex fluid control products, quiet valves, manifolds, shock and vibration dampening, thermal insulation and systems primarily for the commercial aerospace and military (U.S. Government) markets. The contracts may contain multiple products, which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. Our contracts are frequently modified for changes in contract specifications and requirements. Most of our contract modifications are for products that are not distinct from the existing contract and are accounted for as part of that existing contract.
  (was, 2019-05-09, similarity 0.9647):
[0001144204-19-024737:note_history:6]
are accounted for over time as the product does not have an alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin or the inventory is owned by the customer. The related contracts are primarily cost-plus or fixed price contracts related to the design, development and manufacture of complex fluid control products, quiet valves, manifolds, shock and vibration dampening, thermal insulation and systems primarily for the commercial aerospace and military (U.S. Government) markets. The contracts may contain multiple products, which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. Our contracts are frequently modified for changes in contract specifications and requirements. Most of our contract modifications are for products that are not distinct from the existing contract and are accounted for as part of that existing contract.

- changed (2019-08-09):
[0001144204-19-038765:note_history:7]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to one or more years, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.
  (was, 2019-05-09, similarity 0.9887):
[0001144204-19-024737:note_history:7]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to one or more years, and the estimation of these costs requires substantial judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

- changed (2019-08-09):
[0001144204-19-038765:note_history:8]
Test: Within the Test segment, approximately 25% of revenues (approximately 6% of consolidated revenues) are recognized at a point in time when products such as, antennas and probes are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.
  (was, 2019-05-09, similarity 0.9985):
[0001144204-19-024737:note_history:8]
Within the Test segment, approximately 25% of revenues (approximately 6% of consolidated revenues) are recognized at a point in time when products such as, antennas and probes are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

- changed (2019-08-09):
[0001144204-19-038765:note_history:9]
Approximately 75% of the segment’s revenues (approximately 17% of consolidated revenues) are recorded over time as the product does not have an alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin. Products accounted for under this guidance include the construction and installation of test chambers to a buyer’s specifications that provide its customers with the ability to measure and contain magnetic, electromagnetic and acoustic energy. The goods and services related to each installed test chamber are not distinct due to the significant amount of integration provided and each installed chamber is accounted for as a single performance obligation. Selecting the method to measure progress towards completion for these contracts requires judgment and is based on the nature of the products and service to be provided. We use milestones to measure progress for our Test segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. For arrangements that are accounted for under this guidance, the Company estimates profit as the difference between total revenue and total estimated cost of a contract and recognizes these revenues and costs based primarily on contract milestones. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable.
  (was, 2019-05-09, similarity 0.9973):
[0001144204-19-024737:note_history:9]
Approximately 75% of the segment’s revenues (approximately 17% of consolidated revenues) are recorded over time as the product does not have an alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin. Products accounted for under this guidance include the construction and installation of complex test chambers to a buyer’s specifications that provide its customers with the ability to measure and contain magnetic, electromagnetic and acoustic energy. The goods and services related to each installed test chamber are not distinct due to the significant amount of integration provided and each installed chamber is accounted for as a single performance obligation. Selecting the method to measure progress towards completion for these contracts requires judgment and is based on the nature of the products and service to be provided. We use milestones to measure progress for our Test segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. For arrangements that are accounted for under this guidance, the Company estimates profit as the difference between total revenue and total estimated cost of a contract and recognizes these revenues and costs based primarily on contract milestones. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable.

- changed (2019-08-09):
[0001144204-19-038765:note_history:10]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to a year, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.
  (was, 2019-05-09, similarity 0.9884):
[0001144204-19-024737:note_history:10]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to a year, and the estimation of these costs requires substantial judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

- changed (2019-08-09):
[0001144204-19-038765:note_history:11]
USG: Within the USG segment, approximately 80% of revenues (approximately 24% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.
  (was, 2019-05-09, similarity 0.9987):
[0001144204-19-024737:note_history:11]
Within the USG segment, approximately 80% of revenues (approximately 24% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

- changed (2019-08-09):
[0001144204-19-038765:note_history:12]
Technical Packaging: Within the Technical Packaging segment, 100% of the revenues (approximately 10% of consolidated revenues) are recognized over time as the product does not have an alternative use and the Company has an enforceable right to payment. Selecting the method to measure progress towards completion for the contracts requires judgment and is based on the nature of the products to be provided. We use the cost-to-cost method to measure progress for our Technical Packaging segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. Under this measure, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and revenue is recorded proportionally as costs are incurred. The transaction price for our contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant.
  (was, 2019-05-09, similarity 0.9923):
[0001144204-19-024737:note_history:12]
Within the Technical Packaging segment, 100% of the revenues (approximately 10% of consolidated revenues) are recognized over time as the product does not have an alternative use and the Company has an enforceable right to payment. Selecting the method to measure progress towards completion for the contracts requires judgment and is based on the nature of the products to be provided. We use the cost-to-cost method to measure progress for our Technical Packaging segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. Under this measure, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and revenue is recorded proportionally as costs are incurred. The transaction price for our contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant.

- removed (2019-08-09):
[0001144204-19-024737:note_history:13]
Our significant accounting policies are included in Note 1 of our Annual Report on Form 10-K for the year ended September 30, 2018. On October 1, 2018, we adopted ASU No. 2014-09,

- removed (2019-08-09):
[0001144204-19-024737:note_history:14]
Revenue from Contracts with Customers (ASC 606)

- removed (2019-08-09):
[0001144204-19-024737:note_history:15]
Filtration:

- removed (2019-08-09):
[0001144204-19-024737:note_history:16]
Approximately

- removed (2019-08-09):
[0001144204-19-024737:note_history:17]
52

- removed (2019-08-09):
[0001144204-19-024737:note_history:18]
% of the segment’s revenues (approximately

- removed (2019-08-09):
[0001144204-19-024737:note_history:19]
19

- removed (2019-08-09):
[0001144204-19-024737:note_history:20]
% of consolidated revenues)

- removed (2019-08-09):
[0001144204-19-024737:note_history:21]
Test:

- removed (2019-08-09):
[0001144204-19-024737:note_history:22]
USG

- removed (2019-08-09):
[0001144204-19-024737:note_history:23]
:

- removed (2019-08-09):
[0001144204-19-024737:note_history:24]
Technical Packaging:


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-08-09):
[0001144204-19-038765:note_history:25]
8.    DEBT
  (was, 2019-05-09, similarity 0.6):
[0001144204-19-024737:note_history:25]
|  | 8. | DEBT |

- changed (2019-08-09):
[0001144204-19-038765:note_history:26]
| ​ | ​ | June 30, | ​ | September 30, |
| (In thousands) |  | 2019 |  | 2018 |
| Total borrowings | ​ | $ | 217,921 |  | 220,000 |
| Short-term borrowings and current portion of long-term debt | ​ |  | (20,921) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 197,000 |  | 200,000 |
  (was, 2019-05-09, similarity 0.778):
[0001144204-19-024737:note_history:26]
| (In thousands) |  | March 31,2019 |  |  | September 30, 2018 |  |
| Total borrowings |  | $ | 217,000 |  |  |  | 220,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000 | ) |  |  | (20,000 | ) |
| Total long-term debt, less current portion |  | $ | 197,000 |  |  |  | 200,000 |  |

- changed (2019-08-09):
[0001144204-19-038765:note_history:27]
At June 30, 2019, the Company had approximately $225 million available to borrow under the Credit Facility, and a $250 million increase option, in addition to $39.0 million cash on hand. At June 30, 2019, the Company had $217.0 million of outstanding borrowings under the Credit Facility, and $0.9 million of short-term borrowing in addition to outstanding letters of credit of $7.2 million. The Company classified $20.9 million as the current portion of long-term debt as of June 30, 2019, as the Company intends to repay this amount within the next twelve month period; however, the Company has no contractual obligation to repay such amount during the next twelve month period.
  (was, 2019-05-09, similarity 0.9464):
[0001144204-19-024737:note_history:27]
At March 31, 2019, the Company had approximately $207.0 million available to borrow under the Credit Facility, and a $250 million increase option, in addition to $35.0 million cash on hand. At March 31, 2019, the Company had $217.0 million of outstanding borrowings under the Credit Facility in addition to outstanding letters of credit of $8.3 million. The Company classified $20.0 million as the current portion of long-term debt as of March 31, 2019, as the Company intends to repay this amount within the next twelve month period; however, the Company has no contractual obligation to repay such amount during the next twelve month period.

- changed (2019-08-09):
[0001144204-19-038765:note_history:28]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from 12.5 to 27.5 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a 65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 3.21% and 3.22% for the three and nine-month periods ending June 30, 2019, respectively, and 3.17% and 2.97% for the corresponding periods of 2018. At June 30, 2019, the Company was in compliance with all debt covenants.
  (was, 2019-05-09, similarity 0.9853):
[0001144204-19-024737:note_history:28]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from 12.5 to 27.5 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a 65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 3.20% and 3.23% for the three and six-month periods ending March 31, 2019, respectively, and 2.99% and 2.87% for the corresponding periods of 2018. At March 31, 2019, the Company was in compliance with all debt covenants.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-08-09):
[0001144204-19-038765:note_history:29]
| ​ | ​ | June 30, | ​ | September 30, |
| (In thousands) |  | 2019 |  | 2018 |
| Total borrowings | ​ | $ | 217,921 |  | 220,000 |
| Short-term borrowings and current portion of long-term debt | ​ |  | (20,921) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 197,000 |  | 200,000 |
  (was, 2019-05-09, similarity 0.778):
[0001144204-19-024737:note_history:29]
| (In thousands) |  | March 31,2019 |  |  | September 30, 2018 |  |
| Total borrowings |  | $ | 217,000 |  |  |  | 220,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000 | ) |  |  | (20,000 | ) |
| Total long-term debt, less current portion |  | $ | 197,000 |  |  |  | 200,000 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2019-08-09):
[0001144204-19-038765:note_history:30]
| Three Months Ended June 30, 2019 |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | Technical |  | ​ | ​ |
| (In thousands) | ​ | Filtration | ​ | Test | ​ | USG | ​ | Packaging | ​ | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 47,482 | ​ | $ | 37,980 | ​ | $ | 52,065 | ​ | $ | 21,507 | ​ | $ | 159,034 |
| Government | ​ |  | 35,585 | ​ |  | 4,318 | ​ |  | 829 | ​ |  | — | ​ |  | 40,732 |
| Total revenues | ​ | $ | 83,067 | ​ | $ | 42,298 | ​ | $ | 52,894 | ​ | $ | 21,507 | ​ | $ | 199,766 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 69,872 | ​ | $ | 26,923 | ​ | $ | 38,414 | ​ | $ | 11,559 | ​ | $ | 146,268 |
| International | ​ |  | 13,195 | ​ |  | 15,375 | ​ |  | 14,480 | ​ |  | 9,948 | ​ |  | 53,498 |
| Total revenues | ​ | $ | 83,067 | ​ | $ | 42,298 | ​ | $ | 52,894 | ​ | $ | 21,507 | ​ | $ | 199,766 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 41,633 | ​ | $ | 6,485 | ​ | $ | 40,968 | ​ | $ | — | ​ | $ | 89,092 |
| Over time | ​ |  | 41,434 | ​ |  | 35,813 | ​ |  | 11,926 | ​ |  | 21,507 | ​ |  | 110,674 |
| Total revenues | ​ | $ | 83,067 | ​ | $ | 42,298 | ​ | $ | 52,894 | ​ | $ | 21,507 | ​ | $ | 199,766 |

- added (2019-08-09):
[0001144204-19-038765:note_history:31]
| Nine Months Ended June 30, 2019 |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | Technical |  | ​ | ​ |
| (In thousands) | ​ | Filtration | ​ | Test | ​ | USG | ​ | Packaging | ​ | Total |
| Customer type: |  | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |  |
| Commercial | ​ | $ | 131,112 | ​ | $ | 111,577 | ​ | $ | 154,240 | ​ | $ | 63,251 | ​ | $ | 460,180 |
| Government | ​ |  | 97,657 | ​ |  | 14,882 | ​ |  | 3,399 | ​ |  | 194 | ​ |  | 116,132 |
| Total revenues | ​ | $ | 228,769 | ​ | $ | 126,459 | ​ | $ | 157,639 | ​ | $ | 63,445 | ​ | $ | 576,312 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 190,701 | ​ | $ | 82,072 | ​ | $ | 112,289 | ​ | $ | 32,865 | ​ | $ | 417,927 |
| International | ​ |  | 38,068 | ​ |  | 44,387 | ​ |  | 45,350 | ​ |  | 30,580 | ​ |  | 158,385 |

- added (2019-08-09):
[0001144204-19-038765:note_history:32]
| Total revenues | ​ | $ | 228,769 | ​ | $ | 126,459 | ​ | $ | 157,639 | ​ | $ | 63,445 | ​ | $ | 576,312 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 115,852 | ​ | $ | 29,092 | ​ | $ | 122,075 | ​ | $ | - | ​ | $ | 267,021 |
| Over time | ​ |  | 112,917 | ​ |  | 97,367 | ​ |  | 35,564 | ​ |  | 63,445 | ​ |  | 309,291 |
| Total revenues | ​ | $ | 228,769 | ​ | $ | 126,459 | ​ | $ | 157,639 | ​ | $ | 63,445 | ​ | $ | 576,312 |

- removed (2019-08-09):
[0001144204-19-024737:note_history:33]
Our revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2019 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within our reportable segments.

- removed (2019-08-09):
[0001144204-19-024737:note_history:34]
| Three Months Ended March 31, 2019(In thousands) |  | Filtration |  |  | Test |  |  | USG |  |  | Technical Packaging |  |  | Total |  |
| Customer type: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial |  | $ | 46,325 |  |  | $ | 37,451 |  |  | $ | 47,551 |  |  | $ | 22,630 |  |  | $ | 153,957 |  |
| Government |  |  | 33,153 |  |  |  | 5,424 |  |  |  | 1,339 |  |  |  | 76 |  |  |  | 39,992 |  |
| Total revenues |  | $ | 79,478 |  |  | $ | 42,875 |  |  | $ | 48,890 |  |  | $ | 22,706 |  |  | $ | 193,949 |  |
| Geographic location: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 66,068 |  |  | $ | 26,694 |  |  | $ | 33,798 |  |  | $ | 11,457 |  |  | $ | 138,017 |  |
| International |  |  | 13,410 |  |  |  | 16,181 |  |  |  | 15,092 |  |  |  | 11,249 |  |  |  | 55,932 |  |
| Total revenues |  | $ | 79,478 |  |  | $ | 42,875 |  |  | $ | 48,890 |  |  | $ | 22,706 |  |  | $ | 193,949 |  |
| Revenue recognition method: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Point in time |  | $ | 42,400 |  |  | $ | 12,166 |  |  | $ | 36,874 |  |  | $ | - |  |  | $ | 91,440 |  |
| Over time |  |  | 37,078 |  |  |  | 30,709 |  |  |  | 12,016 |  |  |  | 22,706 |  |  |  | 102,509 |  |
| Total revenues |  | $ | 79,478 |  |  | $ | 42,875 |  |  | $ | 48,890 |  |  | $ | 22,706 |  |  | $ | 193,949 |  |

- removed (2019-08-09):
[0001144204-19-024737:note_history:35]
| Six Months Ended March 31, 2019(In thousands) |  | Filtration |  |  | Test |  |  | USG |  |  | Technical Packaging |  |  | Total |  |
| Customer type: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial |  | $ | 83,546 |  |  | $ | 73,688 |  |  | $ | 102,206 |  |  | $ | 41,744 |  |  | $ | 301,184 |  |
| Government |  |  | 62,156 |  |  |  | 10,473 |  |  |  | 2,539 |  |  |  | 194 |  |  |  | 75,362 |  |
| Total revenues |  | $ | 145,702 |  |  | $ | 84,161 |  |  | $ | 104,745 |  |  | $ | 41,938 |  |  | $ | 376,546 |  |
| Geographic location: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 120,833 |  |  | $ | 55,148 |  |  | $ | 73,879 |  |  | $ | 21,306 |  |  | $ | 271,166 |  |
| International |  |  | 24,869 |  |  |  | 29,013 |  |  |  | 30,866 |  |  |  | 20,632 |  |  |  | 105,380 |  |
| Total revenues |  | $ | 145,702 |  |  | $ | 84,161 |  |  | $ | 104,745 |  |  | $ | 41,938 |  |  | $ | 376,546 |  |
| Revenue recognition method: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Point in time |  | $ | 74,214 |  |  | $ | 22,608 |  |  | $ | 81,107 |  |  | $ | - |  |  | $ | 177,929 |  |
| Over time |  |  | 71,488 |  |  |  | 61,553 |  |  |  | 23,638 |  |  |  | 41,938 |  |  |  | 198,617 |  |
| Total revenues |  | $ | 145,702 |  |  | $ | 84,161 |  |  | $ | 104,745 |  |  | $ | 41,938 |  |  | $ | 376,546 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: title_similarity, score: 1.0

- changed (2019-08-09):
[0001144204-19-038765:note_history:36]
Filtration: Within the Filtration segment, approximately 48% of revenues (approximately 18% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial and military customers and have a single performance obligation as there is only one good promised or the promise to transfer the goods or services is not distinct or separately identifiable from other promises in the contract. The transaction price for these contracts reflects our estimate of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.
  (was, 2019-05-09, similarity 0.9966):
[0001144204-19-024737:note_history:36]
Within the Filtration segment, approximately 48% of revenues (approximately 18% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial and military customers and have a single performance obligation as there is only one good promised or the promise to transfer the goods or services is not distinct or separately identifiable from other promises in the contract. The transaction price for these contracts reflects our estimate of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

- changed (2019-08-09):
[0001144204-19-038765:note_history:37]
Approximately 52% of the segment’s revenues (approximately 19% of consolidated revenues) are accounted for over time as the product does not have an alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin or the inventory is owned by the customer. The related contracts are primarily cost-plus or fixed price contracts related to the design, development and manufacture of complex fluid control products, quiet valves, manifolds, shock and vibration dampening, thermal insulation and systems primarily for the commercial aerospace and military (U.S. Government) markets. The contracts may contain multiple products, which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. Our contracts are frequently modified for changes in contract specifications and requirements. Most of our contract modifications are for products that are not distinct from the existing contract and are accounted for as part of that existing contract.
  (was, 2019-05-09, similarity 0.9647):
[0001144204-19-024737:note_history:37]
are accounted for over time as the product does not have an alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin or the inventory is owned by the customer. The related contracts are primarily cost-plus or fixed price contracts related to the design, development and manufacture of complex fluid control products, quiet valves, manifolds, shock and vibration dampening, thermal insulation and systems primarily for the commercial aerospace and military (U.S. Government) markets. The contracts may contain multiple products, which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. Our contracts are frequently modified for changes in contract specifications and requirements. Most of our contract modifications are for products that are not distinct from the existing contract and are accounted for as part of that existing contract.

- changed (2019-08-09):
[0001144204-19-038765:note_history:38]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to one or more years, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.
  (was, 2019-05-09, similarity 0.9887):
[0001144204-19-024737:note_history:38]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to one or more years, and the estimation of these costs requires substantial judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

- changed (2019-08-09):
[0001144204-19-038765:note_history:39]
Test: Within the Test segment, approximately 25% of revenues (approximately 6% of consolidated revenues) are recognized at a point in time when products such as, antennas and probes are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.
  (was, 2019-05-09, similarity 0.9985):
[0001144204-19-024737:note_history:39]
Within the Test segment, approximately 25% of revenues (approximately 6% of consolidated revenues) are recognized at a point in time when products such as, antennas and probes are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

- changed (2019-08-09):
[0001144204-19-038765:note_history:40]
Approximately 75% of the segment’s revenues (approximately 17% of consolidated revenues) are recorded over time as the product does not have an alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin. Products accounted for under this guidance include the construction and installation of test chambers to a buyer’s specifications that provide its customers with the ability to measure and contain magnetic, electromagnetic and acoustic energy. The goods and services related to each installed test chamber are not distinct due to the significant amount of integration provided and each installed chamber is accounted for as a single performance obligation. Selecting the method to measure progress towards completion for these contracts requires judgment and is based on the nature of the products and service to be provided. We use milestones to measure progress for our Test segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. For arrangements that are accounted for under this guidance, the Company estimates profit as the difference between total revenue and total estimated cost of a contract and recognizes these revenues and costs based primarily on contract milestones. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable.
  (was, 2019-05-09, similarity 0.9973):
[0001144204-19-024737:note_history:40]
Approximately 75% of the segment’s revenues (approximately 17% of consolidated revenues) are recorded over time as the product does not have an alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin. Products accounted for under this guidance include the construction and installation of complex test chambers to a buyer’s specifications that provide its customers with the ability to measure and contain magnetic, electromagnetic and acoustic energy. The goods and services related to each installed test chamber are not distinct due to the significant amount of integration provided and each installed chamber is accounted for as a single performance obligation. Selecting the method to measure progress towards completion for these contracts requires judgment and is based on the nature of the products and service to be provided. We use milestones to measure progress for our Test segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. For arrangements that are accounted for under this guidance, the Company estimates profit as the difference between total revenue and total estimated cost of a contract and recognizes these revenues and costs based primarily on contract milestones. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable.

- changed (2019-08-09):
[0001144204-19-038765:note_history:41]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to a year, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.
  (was, 2019-05-09, similarity 0.9884):
[0001144204-19-024737:note_history:41]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to a year, and the estimation of these costs requires substantial judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

- changed (2019-08-09):
[0001144204-19-038765:note_history:42]
USG: Within the USG segment, approximately 80% of revenues (approximately 24% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.
  (was, 2019-05-09, similarity 0.9987):
[0001144204-19-024737:note_history:42]
Within the USG segment, approximately 80% of revenues (approximately 24% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

- changed (2019-08-09):
[0001144204-19-038765:note_history:43]
Technical Packaging: Within the Technical Packaging segment, 100% of the revenues (approximately 10% of consolidated revenues) are recognized over time as the product does not have an alternative use and the Company has an enforceable right to payment. Selecting the method to measure progress towards completion for the contracts requires judgment and is based on the nature of the products to be provided. We use the cost-to-cost method to measure progress for our Technical Packaging segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. Under this measure, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and revenue is recorded proportionally as costs are incurred. The transaction price for our contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant.
  (was, 2019-05-09, similarity 0.9923):
[0001144204-19-024737:note_history:43]
Within the Technical Packaging segment, 100% of the revenues (approximately 10% of consolidated revenues) are recognized over time as the product does not have an alternative use and the Company has an enforceable right to payment. Selecting the method to measure progress towards completion for the contracts requires judgment and is based on the nature of the products to be provided. We use the cost-to-cost method to measure progress for our Technical Packaging segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. Under this measure, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and revenue is recorded proportionally as costs are incurred. The transaction price for our contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant.

- removed (2019-08-09):
[0001144204-19-024737:note_history:44]
Filtration:

- removed (2019-08-09):
[0001144204-19-024737:note_history:45]
Approximately

- removed (2019-08-09):
[0001144204-19-024737:note_history:46]
52

- removed (2019-08-09):
[0001144204-19-024737:note_history:47]
% of the segment’s revenues (approximately

- removed (2019-08-09):
[0001144204-19-024737:note_history:48]
19

- removed (2019-08-09):
[0001144204-19-024737:note_history:49]
% of consolidated revenues)

- removed (2019-08-09):
[0001144204-19-024737:note_history:50]
Test:

- removed (2019-08-09):
[0001144204-19-024737:note_history:51]
USG

- removed (2019-08-09):
[0001144204-19-024737:note_history:52]
:

- removed (2019-08-09):
[0001144204-19-024737:note_history:53]
Technical Packaging:


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2019-08-09):
[0001144204-19-038765:note_history:54]
14.  REVENUES

- added (2019-08-09):
[0001144204-19-038765:note_history:55]
Disaggregation of Revenues

- added (2019-08-09):
[0001144204-19-038765:note_history:56]
Our revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2019 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within our reportable segments.

- added (2019-08-09):
[0001144204-19-038765:note_history:57]
| Three Months Ended June 30, 2019 |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | Technical |  | ​ | ​ |
| (In thousands) | ​ | Filtration | ​ | Test | ​ | USG | ​ | Packaging | ​ | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 47,482 | ​ | $ | 37,980 | ​ | $ | 52,065 | ​ | $ | 21,507 | ​ | $ | 159,034 |
| Government | ​ |  | 35,585 | ​ |  | 4,318 | ​ |  | 829 | ​ |  | — | ​ |  | 40,732 |
| Total revenues | ​ | $ | 83,067 | ​ | $ | 42,298 | ​ | $ | 52,894 | ​ | $ | 21,507 | ​ | $ | 199,766 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 69,872 | ​ | $ | 26,923 | ​ | $ | 38,414 | ​ | $ | 11,559 | ​ | $ | 146,268 |
| International | ​ |  | 13,195 | ​ |  | 15,375 | ​ |  | 14,480 | ​ |  | 9,948 | ​ |  | 53,498 |
| Total revenues | ​ | $ | 83,067 | ​ | $ | 42,298 | ​ | $ | 52,894 | ​ | $ | 21,507 | ​ | $ | 199,766 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 41,633 | ​ | $ | 6,485 | ​ | $ | 40,968 | ​ | $ | — | ​ | $ | 89,092 |
| Over time | ​ |  | 41,434 | ​ |  | 35,813 | ​ |  | 11,926 | ​ |  | 21,507 | ​ |  | 110,674 |
| Total revenues | ​ | $ | 83,067 | ​ | $ | 42,298 | ​ | $ | 52,894 | ​ | $ | 21,507 | ​ | $ | 199,766 |

- added (2019-08-09):
[0001144204-19-038765:note_history:58]
| Nine Months Ended June 30, 2019 |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | Technical |  | ​ | ​ |
| (In thousands) | ​ | Filtration | ​ | Test | ​ | USG | ​ | Packaging | ​ | Total |
| Customer type: |  | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |  |
| Commercial | ​ | $ | 131,112 | ​ | $ | 111,577 | ​ | $ | 154,240 | ​ | $ | 63,251 | ​ | $ | 460,180 |
| Government | ​ |  | 97,657 | ​ |  | 14,882 | ​ |  | 3,399 | ​ |  | 194 | ​ |  | 116,132 |
| Total revenues | ​ | $ | 228,769 | ​ | $ | 126,459 | ​ | $ | 157,639 | ​ | $ | 63,445 | ​ | $ | 576,312 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 190,701 | ​ | $ | 82,072 | ​ | $ | 112,289 | ​ | $ | 32,865 | ​ | $ | 417,927 |
| International | ​ |  | 38,068 | ​ |  | 44,387 | ​ |  | 45,350 | ​ |  | 30,580 | ​ |  | 158,385 |

- added (2019-08-09):
[0001144204-19-038765:note_history:59]
| Total revenues | ​ | $ | 228,769 | ​ | $ | 126,459 | ​ | $ | 157,639 | ​ | $ | 63,445 | ​ | $ | 576,312 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 115,852 | ​ | $ | 29,092 | ​ | $ | 122,075 | ​ | $ | - | ​ | $ | 267,021 |
| Over time | ​ |  | 112,917 | ​ |  | 97,367 | ​ |  | 35,564 | ​ |  | 63,445 | ​ |  | 309,291 |
| Total revenues | ​ | $ | 228,769 | ​ | $ | 126,459 | ​ | $ | 157,639 | ​ | $ | 63,445 | ​ | $ | 576,312 |

- added (2019-08-09):
[0001144204-19-038765:note_history:60]
Remaining Performance Obligations

- added (2019-08-09):
[0001144204-19-038765:note_history:61]
Our remaining performance obligations, which is the equivalent of our backlog, represent the expected transaction price allocated to our contracts that we expect to recognize as revenue in future periods when we perform under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At June 30, 2019, we had $432.5 million in remaining performance obligations of which we expect to recognize revenues of 83% in the next twelve months.

- added (2019-08-09):
[0001144204-19-038765:note_history:62]
Contract assets and liabilities

- added (2019-08-09):
[0001144204-19-038765:note_history:63]
Assets and liabilities related to our contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At June 30, 2019, contract assets and liabilities totaled $99.5 million and $53.8 million, respectively. Upon adoption of ASC 606 on October 1, 2018, contract assets and liabilities related to our contracts with customers were $87 million and $51 million, respectively. During the first nine months of 2019, we recognized approximately $35 million in revenues that were included in the contract liabilities balance at the adoption date.

- added (2019-08-09):
[0001144204-19-038765:note_history:64]
Reconciliation of ASC 606 to Prior Accounting Standards

- added (2019-08-09):
[0001144204-19-038765:note_history:65]
The amount by which each financial statement line item is affected in 2019 as a result of applying the new accounting standard as discussed in Note 2 is presented below:

- added (2019-08-09):
[0001144204-19-038765:note_history:66]
| ​ | ​ | June 30, 2019 |
| ​ |  | ​ | ​ |  | Effect of the |  | ​ | ​ |
| ​ | ​ | ​ | ​ |  | adoption of |  | Under Prior |
| (In thousands) | ​ | As Reported |  | ASC 606 | ​ | Accounting |
| Consolidated Balance Sheets |  | ​ |  |  | ​ |  |  | ​ |  |
| Contract assets (1) | ​ | $ | 99,499 | ​ | $ | (43,576) | ​ | $ | 55,923 |
| Inventories | ​ |  | 126,816 | ​ |  | 36,089 | ​ |  | 162,905 |
| Total current assets | ​ |  | 450,206 | ​ |  | (7,487) | ​ |  | 442,719 |
| Total assets | ​ |  | 1,326,095 | ​ |  | (7,487) | ​ |  | 1,318,608 |
| Contract liabilities (2) | ​ |  | 53,758 | ​ |  | 4,549 | ​ |  | 58,307 |
| Total current liabilities | ​ |  | 199,736 | ​ |  | 4,549 | ​ |  | 204,285 |
| Deferred tax liabilities | ​ |  | 66,286 | ​ |  | (1,678) | ​ |  | 64,608 |
| Total liabilities | ​ |  | 514,288 | ​ |  | 2,871 | ​ |  | 517,159 |
| Retained earnings | ​ |  | 661,003 | ​ |  | (10,358) | ​ |  | 650,645 |
| Total shareholders’ equity | ​ |  | 811,807 | ​ |  | (10,358) | ​ |  | 801,449 |
| Total liabilities and shareholders’ equity | ​ | $ | 1,326,095 | ​ |  | (7,487) | ​ |  | 1,318,608 |

- added (2019-08-09):
[0001144204-19-038765:note_history:67]
|  | (1) | Previously “cost and estimated earnings on long-term contracts” |

- added (2019-08-09):
[0001144204-19-038765:note_history:68]
|  | (2) | Previously “advance payments on long-term contracts” and “current portion of deferred revenue” |

- added (2019-08-09):
[0001144204-19-038765:note_history:69]
| ​ | ​ | Three Months Ended |
| ​ | ​ | June 30, 2019 |
| ​ |  | ​ | ​ |  | Effect of the |  | ​ | ​ |
| ​ | ​ | ​ | ​ |  | adoption of |  | Under Prior |
| (In thousands, except per share amounts) | ​ | As Reported |  | ASC 606 | ​ | Accounting |
| Consolidated Statements of Operations | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net sales | ​ | $ | 199,766 | ​ | $ | (4,008) | ​ | $ | 195,758 |
| Cost of sales | ​ |  | 122,172 | ​ |  | (1,380) | ​ |  | 120,792 |
| Total costs and expenses | ​ |  | 174,874 | ​ |  | (1,380) | ​ |  | 173,494 |
| Earnings before income tax | ​ |  | 24,892 | ​ |  | (2,628) | ​ |  | 22,264 |
| Income tax expense (benefit) | ​ |  | 4,825 | ​ |  | (399) | ​ |  | 4,426 |
| Net earnings | ​ | ​ | 20,067 | ​ | ​ | (2,229) | ​ | ​ | 17,838 |
| Earnings per share: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Basic: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net earnings | ​ | $ | 0.77 | ​ | $ | (0.08) | ​ | $ | 0.69 |
| Diluted: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net earnings | ​ | $ | 0.77 | ​ | $ | (0.08) | ​ | $ | 0.69 |
| Consolidated Statements of Comprehensive Income | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net earnings | ​ | $ | 20,067 | ​ | $ | (2,229) | ​ | $ | 17,838 |
| Comprehensive income | ​ |  | 21,899 | ​ |  | (2,229) | ​ |  | 19,670 |

- added (2019-08-09):
[0001144204-19-038765:note_history:70]
| ​ | ​ | Nine Months Ended |
| ​ | ​ | June 30, 2019 |
| ​ |  | ​ | ​ |  | Effect of the |  | ​ | ​ |
| ​ | ​ | ​ | ​ |  | adoption of |  | Under Prior |
| (In thousands, except per share amounts) | ​ | As Reported |  | ASC 606 | ​ | Accounting |
| Consolidated Statements of Operations | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net sales | ​ | $ | 576,312 | ​ | $ | (9,787) | ​ | $ | 566,525 |
| Cost of sales | ​ |  | 363,026 | ​ |  | (8,360) | ​ |  | 354,666 |
| Total costs and expenses | ​ |  | 506,808 | ​ |  | (8,360) | ​ |  | 498,448 |
| Earnings before income tax | ​ |  | 69,504 | ​ |  | (1,427) | ​ |  | 68,077 |
| Income tax expense (benefit) | ​ |  | 13,323 | ​ |  | (171) | ​ |  | 13,152 |
| Net earnings | ​ |  | 56,181 | ​ |  | (1,256) | ​ |  | 54,925 |
| Earnings per share: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Basic: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net earnings | ​ | $ | 2.17 | ​ | $ | (0.05) | ​ | $ | 2.12 |
| Diluted: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net earnings | ​ | $ | 2.15 | ​ | $ | (0.04) | ​ | $ | 2.11 |
| Consolidated Statements of Comprehensive Income | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net earnings | ​ | $ | 56,181 | ​ | $ | (1,256) | ​ | $ | 54,925 |
| Comprehensive income | ​ |  | 54,262 | ​ |  | (1,256) | ​ |  | 53,006 |
| Consolidated Statements of Cash flows | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net earnings | ​ | $ | 56,181 | ​ | $ | (1,256) | ​ | $ | 54,925 |
| Adjustments to reconcile net earnings to net cash provided by operating activities: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Change in assets and liabilities | ​ | $ | (41,851) | ​ | ​ | 1,256 | ​ | $ | (40,595) |
| Net cash provided by operating activities | ​ |  | 37,041 | ​ |  | — | ​ |  | 37,041 |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2019-08-09):
[0001144204-19-038765:note_history:71]
16.  SUBSEQUENT EVENT

- added (2019-08-09):
[0001144204-19-038765:note_history:72]
On July 2, 2019, the Company acquired Globe Composite Solutions, LLC (Globe), a supplier of mission-critical composite-based products and solutions for navy, defense, and industrial customers. Globe’s operating results from date of acquisition will be included in the Company’s Filtration segment.
