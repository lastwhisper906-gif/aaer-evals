# ESE 8-K — 0001104659-19-065437 filed 2019-11-19

## item codes, every 8-K on or before 2019-11-29

- 2019-11-19 0001104659-19-065437 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2019-11-18 0001104659-19-065096 — 1.01, 2.02, 7.01, 9.01
- 2019-09-30 0001144204-19-046523 — 1.01, 1.02, 2.03, 9.01
- 2019-08-08 0001144204-19-038567 — 2.02, 7.01, 9.01
- 2019-05-07 0001144204-19-024241 — 2.02, 5.02, 7.01, 9.01
- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2019-11-29

- none on or before 2019-11-29

## item 2.02 — earnings release, exhibit 99.1

[0001104659-19-065437:8k_2_02:1]
EX-99.1
5
tm1923262d2_ex99-1.htm
EXHIBIT 99.1

[0001104659-19-065437:8k_2_02:2]
EXHIBIT 99.1

[0001104659-19-065437:8k_2_02:3]
| NEWS FROM |  |

[0001104659-19-065437:8k_2_02:4]
For more information contact:

[0001104659-19-065437:8k_2_02:5]
Kate Lowrey

[0001104659-19-065437:8k_2_02:6]
Director, Investor Relations

[0001104659-19-065437:8k_2_02:7]
ESCO Technologies Inc.

[0001104659-19-065437:8k_2_02:8]
(314)
213-7277

[0001104659-19-065437:8k_2_02:9]
ESCO ANNOUNCES FISCAL 2019 RESULTS

[0001104659-19-065437:8k_2_02:10]
- GAAP EPS $3.10 (Includes Doble
Building Gain, net of Defined Charges) -

[0001104659-19-065437:8k_2_02:11]
- Adjusted EPS $3.13 (Tops Guidance
and Consensus / 13 Percent above 2018) –

[0001104659-19-065437:8k_2_02:12]
ST. LOUIS, November 19, 2019 – ESCO
Technologies Inc. (NYSE: ESE) (ESCO, or the Company) today reported its operating results for the fourth quarter (Q4 2019) and
fiscal year ended September 30, 2019 (2019).

[0001104659-19-065437:8k_2_02:13]
On November 18, 2019, the Company announced
the divestiture of its Technical Packaging segment under a separate release, where it expects to receive $187 million in gross
cash proceeds and finalize the transaction as soon as customary regulatory items are completed.

[0001104659-19-065437:8k_2_02:14]
The financial results presented include
certain non-GAAP financial measures such as EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS, as defined within the “Non-GAAP
Financial Measures” described below. Any non-GAAP financial measures presented are reconciled to their respective GAAP equivalents.

[0001104659-19-065437:8k_2_02:15]
Management believes these non-GAAP financial
measures are useful in assessing the ongoing operational profitability of the Company’s business segments, and therefore,
allow shareholders better visibility into the Company’s underlying operations. See “Non-GAAP Financial Measures”
described below.

[0001104659-19-065437:8k_2_02:16]
Earnings Summary – Full Year

[0001104659-19-065437:8k_2_02:17]
2019 GAAP EPS of $3.10 per share included
$0.19 per share from a gain on the sale of Doble’s headquarters building in Watertown, Massachusetts, offset by $0.22 per
share of charges related to cost reduction actions taken in Technical Packaging and at Doble, costs incurred to move the aircraft
/ aerospace business from VACCO to PTI, and one-time purchase accounting charges related to the July 2019 acquisition of Globe
Composite Solutions, LLC (Globe). The $0.03 per share of net discrete items was excluded when determining 2019 Adjusted EPS of
$3.13 per share. 2019 GAAP net earnings were $81 million.

[0001104659-19-065437:8k_2_02:18]
2018 GAAP EPS of $3.54 per share reflected
the favorable net impact of the December 2017 “Tax Cuts and Jobs Act” (U.S. Tax Reform) which resulted in a tax benefit
of $0.94 per share, partially offset by $0.17 per share of cost reduction / restructuring and move costs. The net effect of excluding
the $0.77 per share of discrete items resulted in 2018 Adjusted EPS of $2.77 per share. 2018 GAAP net earnings were $92 million.

[0001104659-19-065437:8k_2_02:19]
2019 Adjusted EPS topped Management expectations
and increased 13 percent over 2018 Adjusted EPS.

[0001104659-19-065437:8k_2_02:20]
2019 Adjusted EBITDA was $151 million, an
increase of 9 percent over 2018 Adjusted EBITDA of $139 million, led by Filtration and Test which increased 18 percent and 8 percent,
respectively.

[0001104659-19-065437:8k_2_02:21]
Earnings Summary – Q4

[0001104659-19-065437:8k_2_02:22]
Q4 2019 GAAP EPS was $0.95 per share and
Q4 2019 Adjusted EPS was $1.09 per share, excluding the $0.14 per share of one-time purchase accounting charges related to the
Globe acquisition and the Q4 portion of the cost reduction actions described above.

[0001104659-19-065437:8k_2_02:23]
Q4 2018 GAAP EPS was $1.09 per share and
Q4 2018 Adjusted EPS was $1.22 per share, excluding $0.13 per share of charges related to the prior year’s cost reduction
actions, and the true-up of income tax expense resulting from the implementation of U.S. Tax Reform.

[0001104659-19-065437:8k_2_02:24]
Q4 2019 Adjusted EBITDA was $51 million
compared to $52 million in Q4 2018.

[0001104659-19-065437:8k_2_02:25]
Operating Highlights

[0001104659-19-065437:8k_2_02:26]
|  | · | Net sales increased $41 million (5.4 percent) to $813 million in 2019 compared to $772 million in 2018. |

[0001104659-19-065437:8k_2_02:27]
|  | · | On a segment basis, 2019 Filtration sales increased 14 percent from 2018 (10.5 percent excluding Globe). Aerospace sales (PTI, Crissair, and Mayday) increased $32 million (19 percent) in 2019 driven by higher OEM build rates and strong after-market demand, partially offset by lower navy sales at VACCO due to revenue recognition timing on several large programs. Test sales increased $6 million (3 percent) in 2019 resulting from strong orders throughout 2019 and the completion of several large projects. USG sales from Doble increased $8 million (6 percent), while NRG’s sales to renewable energy customers decreased nearly $10 million, resulting in a net decrease in USG sales. Technical Packaging sales decreased nominally resulting from solid growth in domestic medical / pharm sales, offset by delayed new product introductions in Europe. |

[0001104659-19-065437:8k_2_02:28]
|  | · | SG&A expenses increased in 2019 as a result of higher spending on R&D / new product development, additional sales commissions, normal cost of living adjustments, and the addition of Globe. Both periods’ SG&A spending represents approximately 21 percent of net sales. |

[0001104659-19-065437:8k_2_02:29]
|  | · | Entered orders were $905 million in 2019 (book-to-bill of 1.11x) and were $279 million during Q4 2019 (book-to-bill of 1.18x) which resulted in an ending backlog of $475 million at September 30, 2019, an increase of $92 million, or 24 percent, from September 30, 2018. |

[0001104659-19-065437:8k_2_02:30]
|  | · | The effective income tax rate (GAAP and Adjusted) was 21 percent in 2019 and was favorably impacted by certain tax strategies implemented during 2019. |

[0001104659-19-065437:8k_2_02:31]
|  | · | 2019 net cash provided by operating activities was $105 million resulting in $224 million of net debt outstanding (total borrowings, less cash on hand) at September 30, 2019 with a 1.68x leverage ratio. Q4 2019 net cash provided by operating activities was $68 million resulting from strong earnings and favorable working capital management. |

[0001104659-19-065437:8k_2_02:32]
Chairman’s Commentary –
2019

[0001104659-19-065437:8k_2_02:33]
Vic Richey, Chairman and Chief Executive
Officer, commented, “I’m pleased with how we ended the year as our results once again came in above expectations and
we delivered 13 percent Adjusted EPS growth over prior year. We had solid operational performance across the Company as we exceeded
our sales, Adjusted EBIT, and Adjusted EPS commitments set at the beginning of the year. Our Filtration business was the clear
winner in 2019 as the segment, when excluding Globe, exceeded profit expectations by 9 percent, with Test and Doble also beating
profit expectations and delivering strong results.

[0001104659-19-065437:8k_2_02:34]
“We improved our 2019 Adjusted EBITDA
by 9 percent and increased our margins from 2018, while generating record cash flow from operations. Our entered orders were another
bright spot as we booked over $900 million of new business during the year and grew our backlog by 24 percent, which sets us up
nicely for growth in 2020.

[0001104659-19-065437:8k_2_02:35]
“The Globe acquisition announced in
early July is off to a great start as they performed better than we projected. I’m very happy with the early stages of the
integration, and I’m looking forward to Globe’s continuing growth as part of ESCO. The strong leadership team, dedicated
employees, and great products are an excellent addition to our portfolio and enable us to create additional avenues for meaningful
sales growth across our shared customer base.

[0001104659-19-065437:8k_2_02:36]
“On the M&A front we continue
to evaluate a robust pipeline of opportunities and continue to work these aggressively, and I remain hopeful that we will be able
to add to our portfolio. Consistent with our history, we will remain prudent and committed to our disciplined approach of balancing
ROIC and protecting our balance sheet.

[0001104659-19-065437:8k_2_02:37]
“The Doble headquarters relocation
from Watertown to Marlborough is nearly complete and we expect to be moved in and fully operational in the next few weeks. The
Doble team is looking forward to having all of its Boston area staff co-located in a single, customer-friendly facility as this
will further enhance our operational efficiency and effectiveness, while lowering our facility operating costs.

[0001104659-19-065437:8k_2_02:38]
“I’m pleased with the way we
wrapped up 2019, and we plan to build on the successes we achieved this year and expect to continue benefitting from our disciplined
operating culture heading into 2020. Our solid market positions and tangible growth opportunities across the Company provide us
with a favorable view of the future with our goal remaining unchanged – to increase long-term shareholder value.”

[0001104659-19-065437:8k_2_02:39]
Dividend Payment

[0001104659-19-065437:8k_2_02:40]
The next
quarterly cash dividend of $0.08 per share will be paid on January 17, 2020 to stockholders of record on January 2, 2020.

[0001104659-19-065437:8k_2_02:41]
Board of Directors

[0001104659-19-065437:8k_2_02:42]
Effective
November 13, 2019, the Company added an additional independent director, Gloria L. Valdez to the Company’s Board of Directors.

[0001104659-19-065437:8k_2_02:43]
Ms. Valdez
retired in 2018 after 32 years of civilian service with the Department of the Navy and the Department of Homeland Security. Prior
to her retirement she served as Deputy Assistant Secretary of the Navy for Ships within the Office of the Assistant Secretary of
the Navy for Research, Development and Acquisition. In this capacity, Ms. Valdez was responsible for executive oversight of all
naval shipbuilding programs, major ship conversions, and the maintenance, modernization and disposal of in-service ships.

[0001104659-19-065437:8k_2_02:44]
Ms. Valdez
holds a Master of Science degree in Management from Florida Institute of Technology as well as a Bachelor of Science in Mechanical
Engineering from the University of New Mexico, and was selected to serve on the Company’s Board due to her extensive management
experience in the navy and defense markets, which will allow her to assist the board in guiding strategy from the highest level.

[0001104659-19-065437:8k_2_02:45]
Adding
a new director further enhances Corporate Governance, facilitates board refreshment, and adds new and relevant experience supplementing
existing independent director oversight.

[0001104659-19-065437:8k_2_02:46]
Business Outlook – 2020 Adjusted
Basis

[0001104659-19-065437:8k_2_02:47]
Given the pending sale of the Technical
Packaging business, beginning with the Q1 2020 results of operations, the segment’s operating results, balance sheet and
cash flows will be reported as Discontinued Operations, and therefore, will be excluded from the Business Outlook comparisons to
2019 described below.

[0001104659-19-065437:8k_2_02:48]
The Discontinued Operations impact, as well
as the expected after-tax gain on the sale of Technical Packaging will be excluded from the calculation of Adjusted EBIT, Adjusted
EBITDA and Adjusted EPS in the reporting of the 2020 and 2019 results.

[0001104659-19-065437:8k_2_02:49]
The net proceeds from the sale will be used
to pay down debt, thereby significantly increasing liquidity and enhancing the Company’s ability to complete future acquisitions.

[0001104659-19-065437:8k_2_02:50]
Additionally, later in 2020, Management
plans to use a portion of the net proceeds to fully fund, terminate, and annuitize the defined benefit pension plan currently maintained
by the Company. Annuitizing this non-strategic liability through an insurance company will eliminate both equity market risk and
interest rate volatility, thereby reducing our costs and eliminating future cash payments. The defined benefit plan was frozen
in 2003 and no additional benefits have been accrued since that date. The accounting impact of terminating and annuitizing the
pension will also be excluded from the calculation of Adjusted EBITDA and Adjusted EPS.

[0001104659-19-065437:8k_2_02:51]
Management continues to see meaningful net
sales, Adjusted EBIT, and Adjusted EBITDA growth across each of the Company’s business segments and anticipates growth rates
in 2020 and beyond that will generally exceed the broader industrial market. The growth described below is expected to be enhanced
by additional M&A contributions throughout the year.

[0001104659-19-065437:8k_2_02:52]
Management’s expectations for growth
in 2020 compared to 2019, excluding the results of Technical Packaging in both periods, are as follows:

[0001104659-19-065437:8k_2_02:53]
|  | · | Net sales from continuing operations are expected to increase 9 to 10 percent on a consolidated basis, with Filtration growing 13.5 to 14.5 percent, USG growing 7 to 8 percent and Test growing 4 to 5 percent; |

[0001104659-19-065437:8k_2_02:54]
|  | · | Adjusted EBIT is expected to increase approximately 11 to 12 percent with Adjusted EBIT margins at 14 to 15 percent of sales; |

[0001104659-19-065437:8k_2_02:55]
|  | · | Adjusted EBITDA is expected to increase approximately 12 to 13 percent with Adjusted EBITDA margins increasing nearly a full point; |

[0001104659-19-065437:8k_2_02:56]
|  | · | Interest expense is expected to be lower than 2019, and will be impacted by the timing (date) of closing and the amount of the final after-tax cash proceeds received on the sale of Technical Packaging; |

[0001104659-19-065437:8k_2_02:57]
|  | · | Non-cash depreciation and amortization of intangible assets is expected to increase approximately $5 million, or $0.15 per share after-tax, related to previous acquisitions and capital spending; |

[0001104659-19-065437:8k_2_02:58]
|  | · | Income tax expense is expected to increase in 2020 as Management is projecting a 23 to 24 percent effective tax rate calculated on higher pretax earnings, compared to the 20.3 percent effective tax rate used in calculating 2019 Adjusted EPS (excluding Technical Packaging). The higher effective tax rate negatively impacts 2020 Adjusted EPS by approximately ($0.10) per share; |

[0001104659-19-065437:8k_2_02:59]
|  | · | In summary, and excluding Technical Packaging, Management projects 2020 Adjusted EPS to be in the range of $3.20 to $3.30 per share (compared to 2019 Adjusted EPS of $2.95 per share, excluding the 2019 results of Technical Packaging). This increase reflects meaningful sales, Adjusted EBITDA and Adjusted EPS growth, partially offset by the additional depreciation and amortization charges and incremental tax expense as noted above. |

[0001104659-19-065437:8k_2_02:60]
On a quarterly basis and consistent
with prior years, Management expects 2020 revenues and Adjusted EPS to be more back half weighted resulting in the second half
of the year being stronger than the first half.

[0001104659-19-065437:8k_2_02:61]
Management expects Q1 2020 Adjusted
EPS to be in the range of $0.35 to $0.40 per share. The timing of quarterly sales and earnings throughout the year, coupled with
the discrete charges incurred within the respective quarters will impact quarterly comparability.

[0001104659-19-065437:8k_2_02:62]
Conference Call

[0001104659-19-065437:8k_2_02:63]
The Company will host a conference call
today, November 19, at 4:00 p.m. Central Time, to discuss the Company’s 2019 results and the packaging segment divestiture.
A live audio webcast will be available on the Company’s website at www.escotechnologies.com. Please access the website
at least 15 minutes prior to the call to register, download and install any necessary audio software. A replay of the conference
call will be available on the Company’s website noted above or by phone (dial 1-855-859-2056 and enter the pass code 2935058).

[0001104659-19-065437:8k_2_02:64]
Forward-Looking Statements

[0001104659-19-065437:8k_2_02:65]
Statements in this press release
regarding the timing and amounts of the Company’s expected quarterly, 2020 full year and beyond results, revenue and
sales growth, sales, EPS, Adjusted EPS, EPS growth, cash, EBIT, Adjusted EBIT, Adjusted EBIT margins, Adjusted EBITDA
margins, Adjusted EBITDA, interest expense, income tax expense, effective tax rate, non-cash depreciation and amortization of
intangible assets, liquidity, actions in regard to the Company’s frozen defined benefit plan, the realization of
operational efficiencies, the Company’s competitiveness , the Company’s ability to increase operating margins,
realize financial goals and increase shareholder value, the success of acquisition efforts, the sale of and expected proceeds
from the pending divestiture and use of those proceeds, the long-term success of the Company, and any other statements which
are not strictly historical are “forward-looking” statements within the meaning of the safe harbor provisions of
the federal securities laws.

[0001104659-19-065437:8k_2_02:66]
Investors are cautioned that such statements
are only predictions and speak only as of the date of this release, and the Company undertakes no duty to update them except as
may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from
those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and
business environment including but not limited to those described in Item 1A, “Risk Factors”, of the Company’s
Annual Report on Form 10-K for the fiscal year ended September 30, 2018, and the following: to the failure to obtain regulatory
approval of the Company’s sale of the Technical Packaging business, contractual disputes with the buyer of the Company’s
Technical Packaging business; the success of the Company’s competitors; weakening of economic conditions in served markets;
changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties; delivery
delays or defaults by customers; material changes in the costs and availability of certain raw materials; the appropriation, allocation
and availability of Government funds; the termination for convenience of Government and other customer contracts; the timing and
content of future contract awards or customer orders; performance issues with key customers, suppliers and subcontractors; labor
disputes; the impacts of natural disasters on the Company’s operations and those of the Company’s customers and suppliers;
changes in laws and regulations, including but not limited to changes in accounting standards, taxation requirements, and new or
modified tariffs; changes in interest rates; costs relating to environmental matters arising from current or former facilities;
financial exposure in connection with Company guarantees of certain Aclara contracts; the availability of select acquisitions;
and the uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration.

[0001104659-19-065437:8k_2_02:67]
Non-GAAP Financial Measures

[0001104659-19-065437:8k_2_02:68]
The financial measures EBIT, EBITDA, Adjusted
EBITDA and Adjusted EPS are presented in this press release. The Company defines “EBIT” as earnings before interest
and taxes, “EBITDA” as earnings before interest, taxes, depreciation and amortization, “Adjusted EBITDA”
as EBITDA excluding certain defined charges, and “Adjusted EPS” as GAAP earnings per share (EPS) excluding the net
impact of the items described above which were $0.03 per share in 2019.

[0001104659-19-065437:8k_2_02:69]
EBIT, EBITDA, Adjusted EBITDA and
Adjusted EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management
believes that EBIT, EBITDA and Adjusted EBITDA are useful in assessing the operational profitability of the Company’s
business segments because they exclude interest, taxes, depreciation and amortization, which are generally accounted for
across the entire Company on a consolidated basis. EBIT is also one of the measures used by Management in determining
resource allocations within the Company as well as incentive compensation. The presentation of EBIT, EBITDA, Adjusted EBITDA
and Adjusted EPS provides important supplemental information to investors by facilitating comparisons with other companies,
many of which use similar non-GAAP financial measures to supplement their GAAP results. The use of non-GAAP financial
measures is not intended to replace any measures of performance determined in accordance with GAAP.

[0001104659-19-065437:8k_2_02:70]
ESCO, headquartered in St. Louis, Missouri:
Manufactures highly-engineered filtration and fluid control products for the aviation, navy, space and process markets worldwide,
as well as composite-based products and solutions for navy, defense and industrial customers; is the industry leader in RF shielding
and EMC test products; provides diagnostic instruments, software and services for the benefit of industrial power users and the
electric utility and renewable energy industries; and, produces custom thermoformed packaging, pulp-based packaging, and specialty
products for medical and commercial markets. Further information regarding ESCO and its subsidiaries is available on the Company’s
website at www.escotechnologies.com.

[0001104659-19-065437:8k_2_02:71]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-19-065437:8k_2_02:72]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-19-065437:8k_2_02:73]
(Dollars in thousands, except per share amounts)

[0001104659-19-065437:8k_2_02:74]
|  |  | Three Months Ended September 30, 2019 |  |  | Three Months Ended September 30, 2018 |  |
| Net Sales |  | $ | 236,658 |  |  |  | 231,086 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 145,495 |  |  |  | 143,486 |  |
| Selling, general and administrative expenses |  |  | 46,043 |  |  |  | 39,618 |  |
| Amortization of intangible assets |  |  | 5,523 |  |  |  | 4,713 |  |
| Interest expense |  |  | 2,608 |  |  |  | 2,284 |  |
| Other expenses (income), net |  |  | 4,277 |  |  |  | 2,663 |  |
| Total costs and expenses |  |  | 203,946 |  |  |  | 192,764 |  |
| Earnings before income taxes |  |  | 32,712 |  |  |  | 38,322 |  |
| Income taxes |  |  | 7,854 |  |  |  | 9,870 |  |
| Net earnings |  | $ | 24,858 |  |  |  | 28,452 |  |
| Diluted EPS - GAAP |  | $ | 0.95 |  |  |  | 1.09 |  |
| Diluted EPS - As Adjusted |  | $ | 1.09 | (1) |  |  | 1.22 | (2) |
| Diluted average common shares O/S: |  |  | 26,146 |  |  |  | 26,103 |  |

[0001104659-19-065437:8k_2_02:75]
| (1) | Q4 2019 Adjusted EPS excluded $0.14 per share net impact of purchase accounting charges related to the Globe acquisition and restructuring charges incurred primarily at Plastique, Doble and PTI/VACCO during the fourth quarter of 2019. |

[0001104659-19-065437:8k_2_02:76]
| (2) | Q4 2018 Adjusted EPS excluded $0.13 per share of after-tax charges incurred related to the Q4 2018 restructuring actions and the true-up of tax expense recorded resulting from the implementation of U.S. Tax Reform. |

[0001104659-19-065437:8k_2_02:77]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-19-065437:8k_2_02:78]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-19-065437:8k_2_02:79]
(Dollars in thousands, except per share amounts)

[0001104659-19-065437:8k_2_02:80]
|  |  | Year Ended September 30, 2019 |  |  | Year Ended September 30, 2018 |  |
| Net Sales |  | $ | 812,970 |  |  |  | 771,582 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 508,521 |  |  |  | 490,397 |  |
| Selling, general and administrative expenses |  |  | 172,109 |  |  |  | 162,431 |  |
| Amortization of intangible assets |  |  | 19,488 |  |  |  | 18,328 |  |
| Interest expense |  |  | 8,396 |  |  |  | 8,748 |  |
| Other expenses (income), net |  |  | 2,240 |  |  |  | 3,655 |  |
| Total costs and expenses |  |  | 710,754 |  |  |  | 683,559 |  |
| Earnings before income taxes |  |  | 102,216 |  |  |  | 88,023 |  |
| Income taxes |  |  | 21,177 |  |  |  | (4,113 | ) |
| Net earnings |  | $ | 81,039 |  |  |  | 92,136 |  |
| Diluted EPS - GAAP |  | $ | 3.10 |  |  |  | 3.54 |  |
| Diluted EPS - As Adjusted |  | $ | 3.13 | (1) |  |  | 2.77 | (2) |
| Diluted average common shares O/S: |  |  | 26,097 |  |  |  | 26,058 |  |

[0001104659-19-065437:8k_2_02:81]
| (1) | 2019 Adjusted EPS excluded $0.03 per share net impact mainly from the purchase accounting charges related to the Globe acquisition and restructuring charges primarily at Plastique, PTI/VACCO & Doble partially offset by the gain on the sale of the Doble Watertown property. |

[0001104659-19-065437:8k_2_02:82]
| (2) | 2018 Adjusted EPS excluded $0.17 per share of after-tax charges incurred related to the 2018 restructuring actions, and excluded a $0.94 net tax benefit recorded resulting from the implementation of U.S. Tax Reform. |

[0001104659-19-065437:8k_2_02:83]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-19-065437:8k_2_02:84]
Condensed Business Segment Information (Unaudited)

[0001104659-19-065437:8k_2_02:85]
(Dollars in thousands)

[0001104659-19-065437:8k_2_02:86]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | Q4 2019 |  |  | Q4 2018 |  |  | Q4 2019 |  |  | Q4 2018 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 96,966 |  |  |  | 91,274 |  |  |  | 96,966 |  |  |  | 91,274 |  |
| USG |  |  | 54,276 |  |  |  | 56,013 |  |  |  | 54,276 |  |  |  | 56,013 |  |
| Test |  |  | 61,935 |  |  |  | 59,523 |  |  |  | 61,935 |  |  |  | 59,523 |  |
| Technical Packaging |  |  | 23,481 |  |  |  | 24,276 |  |  |  | 23,481 |  |  |  | 24,276 |  |
| Totals |  | $ | 236,658 |  |  |  | 231,086 |  |  |  | 236,658 |  |  |  | 231,086 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 23,050 |  |  |  | 23,615 |  |  |  | 23,459 |  |  |  | 23,961 |  |
| USG |  |  | 11,708 |  |  |  | 15,364 |  |  |  | 12,715 |  |  |  | 16,399 |  |
| Test |  |  | 10,849 |  |  |  | 10,029 |  |  |  | 10,849 |  |  |  | 10,029 |  |
| Technical Packaging |  |  | 2,532 |  |  |  | 2,721 |  |  |  | 2,635 |  |  |  | 2,721 |  |
| Corporate |  |  | (12,819 | ) |  |  | (11,123 | ) |  |  | (9,659 | ) |  |  | (10,252 | ) |
| Consolidated EBIT |  |  | 35,320 |  |  |  | 40,606 |  |  |  | 39,999 |  |  |  | 42,858 |  |
| Less: Interest expense |  |  | (2,608 | ) |  |  | (2,284 | ) |  |  | (2,608 | ) |  |  | (2,284 | ) |
| Less: Income tax expense |  |  | (7,854 | ) |  |  | (9,870 | ) |  |  | (8,941 | ) |  |  | (8,582 | ) |
| Net earnings |  | $ | 24,858 |  |  |  | 28,452 |  |  |  | 28,450 |  |  |  | 31,992 |  |

[0001104659-19-065437:8k_2_02:87]
Note 1: Adjusted net earnings were $28.5 million in Q4 2019 which excluded the $0.14 per share net impact of the purchase accounting charges related to the Globe acquisition and the restructuring charges incurred at Doble, Plastique, PTI and VACCO during Q4 2019.

[0001104659-19-065437:8k_2_02:88]
Note 2: Adjusted net earnings were $32.0 million in Q4 2018 which excluded the $0.13 per share of after-tax charges incurred related to the Q4 2018 restructuring actions, and the true-up of tax expense recorded resulting from the implementation of U.S. Tax Reform.

[0001104659-19-065437:8k_2_02:89]
EBITDA Reconciliation to Net earnings:

[0001104659-19-065437:8k_2_02:90]
|  |  |  |  |  |  |  |  | Adjusted |  |  | Adjusted |  |
|  |  | Q4 2019 |  |  | Q4 2018 |  |  | Q4 2019 |  |  | Q4 2018 |  |
| Consolidated EBITDA |  | $ | 46,607 |  |  |  | 50,011 |  |  |  | 51,286 |  |  |  | 52,263 |  |
| Less: Depr & Amort |  |  | (11,287 | ) |  |  | (9,405 | ) |  |  | (11,287 | ) |  |  | (9,405 | ) |
| Consolidated EBIT |  |  | 35,320 |  |  |  | 40,606 |  |  |  | 39,999 |  |  |  | 42,858 |  |
| Less: Interest expense |  |  | (2,608 | ) |  |  | (2,284 | ) |  |  | (2,608 | ) |  |  | (2,284 | ) |
| Less: Income tax expense |  |  | (7,854 | ) |  |  | (9,870 | ) |  |  | (8,941 | ) |  |  | (8,582 | ) |
| Net earnings |  | $ | 24,858 |  |  |  | 28,452 |  |  |  | 28,450 |  |  |  | 31,992 |  |

[0001104659-19-065437:8k_2_02:91]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-19-065437:8k_2_02:92]
Condensed Business Segment Information (Unaudited)

[0001104659-19-065437:8k_2_02:93]
(Dollars in thousands)

[0001104659-19-065437:8k_2_02:94]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | FY 2019 |  |  | FY 2018 |  |  | FY 2019 |  |  | FY 2018 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 325,735 |  |  |  | 286,805 |  |  |  | 325,735 |  |  |  | 286,805 |  |
| USG |  |  | 211,915 |  |  |  | 213,953 |  |  |  | 211,915 |  |  |  | 213,953 |  |
| Test |  |  | 188,394 |  |  |  | 182,892 |  |  |  | 188,394 |  |  |  | 182,892 |  |
| Technical Packaging |  |  | 86,926 |  |  |  | 87,932 |  |  |  | 86,926 |  |  |  | 87,932 |  |
| Totals |  | $ | 812,970 |  |  |  | 771,582 |  |  |  | 812,970 |  |  |  | 771,582 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 70,142 |  |  |  | 58,670 |  |  |  | 71,316 |  |  |  | 59,464 |  |
| USG |  |  | 52,169 |  |  |  | 43,169 |  |  |  | 46,282 |  |  |  | 46,121 |  |
| Test |  |  | 25,640 |  |  |  | 23,826 |  |  |  | 25,640 |  |  |  | 23,826 |  |
| Technical Packaging |  |  | 5,865 |  |  |  | 8,075 |  |  |  | 7,299 |  |  |  | 8,075 |  |
| Corporate |  |  | (43,204 | ) |  |  | (36,969 | ) |  |  | (39,375 | ) |  |  | (35,875 | ) |
| Consolidated EBIT |  |  | 110,612 |  |  |  | 96,771 |  |  |  | 111,162 |  |  |  | 101,611 |  |
| Less: Interest expense |  |  | (8,396 | ) |  |  | (8,748 | ) |  |  | (8,396 | ) |  |  | (8,748 | ) |
| Less: Income tax |  |  | (21,177 | ) |  |  | 4,113 |  |  |  | (20,965 | ) |  |  | (20,665 | ) |
| Net earnings |  | $ | 81,039 |  |  |  | 92,136 |  |  |  | 81,801 |  |  |  | 72,198 |  |

[0001104659-19-065437:8k_2_02:95]
Note 1: Adjusted net earnings were $81.8 million in 2019 which excluded the $0.03 per share net impact of the purchase accounting charges related to the Globe acquisition and the restructuring charges incurred at Doble, Plastique, PTI and VACCO during 2019, partially offset by the gain on the sale of the Doble Watertown property.

[0001104659-19-065437:8k_2_02:96]
Note 2: Adjusted net earnings were $72.2 million in 2018 which excluded $0.17 per share of after-tax charges incurred related to the 2018 restructuring actions, and excluded a $0.94 net tax benefit recorded resulting from the implementation of U.S. Tax Reform.

[0001104659-19-065437:8k_2_02:97]
EBITDA Reconciliation to Net earnings:

[0001104659-19-065437:8k_2_02:98]
|  |  |  |  |  |  |  |  | Adjusted |  |  | Adjusted |  |
|  |  | FY 2019 |  |  | FY 2018 |  |  | FY 2019 |  |  | FY 2018 |  |
| Consolidated EBITDA |  | $ | 150,662 |  |  |  | 134,526 |  |  |  | 151,212 |  |  |  | 139,366 |  |
| Less: Depr & Amort |  |  | (40,050 | ) |  |  | (37,755 | ) |  |  | (40,050 | ) |  |  | (37,755 | ) |
| Consolidated EBIT |  |  | 110,612 |  |  |  | 96,771 |  |  |  | 111,162 |  |  |  | 101,611 |  |
| Less: Interest expense |  |  | (8,396 | ) |  |  | (8,748 | ) |  |  | (8,396 | ) |  |  | (8,748 | ) |
| (Less) Plus: Income tax |  |  | (21,177 | ) |  |  | 4,113 |  |  |  | (20,965 | ) |  |  | (20,665 | ) |
| Net earnings |  | $ | 81,039 |  |  |  | 92,136 |  |  |  | 81,801 |  |  |  | 72,198 |  |

[0001104659-19-065437:8k_2_02:99]
ESCO
TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-19-065437:8k_2_02:100]
Condensed Consolidated Balance Sheets (Unaudited)

[0001104659-19-065437:8k_2_02:101]
(Dollars in thousands)

[0001104659-19-065437:8k_2_02:102]
|  |  | September 30, 2019 |  |  | September 30, 2018 |
| Assets |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 61,808 |  |  | 30,477 |
| Accounts receivable, net |  |  | 174,427 |  |  | 163,740 |
| Contract assets |  |  | 115,310 |  |  | 53,034 |
| Inventories |  |  | 128,825 |  |  | 135,416 |
| Other current assets |  |  | 14,824 |  |  | 13,356 |
| Total current assets |  |  | 495,194 |  |  | 396,023 |
| Property, plant and equipment, net |  |  | 161,470 |  |  | 134,954 |
| Intangible assets, net |  |  | 393,047 |  |  | 345,353 |
| Goodwill |  |  | 409,215 |  |  | 381,652 |
| Other assets |  |  | 7,794 |  |  | 7,140 |
|  |  | $ | 1,466,720 |  |  | 1,265,122 |
| Liabilities and Shareholders' Equity |  |  |  |  |
| Short-term borrowings and current maturities of long-term debt |  | $ | 21,261 |  |  | 20,000 |
| Accounts payable |  |  | 71,370 |  |  | 63,033 |
| Contract liabilities |  |  | 81,177 |  |  | 49,035 |
| Other current liabilities |  |  | 77,827 |  |  | 68,462 |
| Total current liabilities |  |  | 251,635 |  |  | 200,530 |
| Deferred tax liabilities |  |  | 64,855 |  |  | 64,794 |
| Other liabilities |  |  | 59,008 |  |  | 40,388 |
| Long-term debt |  |  | 265,000 |  |  | 200,000 |
| Shareholders' equity |  |  | 826,222 |  |  | 759,410 |
|  |  | $ | 1,466,720 |  |  | 1,265,122 |

[0001104659-19-065437:8k_2_02:103]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-19-065437:8k_2_02:104]
Consolidated Statements of Cash Flows (Unaudited)

[0001104659-19-065437:8k_2_02:105]
(Dollars in thousands)

[0001104659-19-065437:8k_2_02:106]
|  |  | Year Ended September 30, 2019 |  |
| Cash flows from operating activities: |  |  |  |  |
| Net earnings |  | $ | 81,039 |  |
| Adjustments to reconcile net earnings to net cash provided by operating activities: |  |  |  |  |
| Depreciation and amortization |  |  | 40,050 |  |
| Stock compensation expense |  |  | 5,353 |  |
| Changes in assets and liabilities |  |  | (9,944 | ) |
| Change in PP&E from gain on building sale |  |  | (8,922 | ) |
| Pension contributions |  |  | (2,500 | ) |
| Effect of deferred taxes |  |  | 61 |  |
| Net cash provided by operating activities |  |  | 105,137 |  |
| Cash flows from investing activities: |  |  |  |  |
| Acquisition of businesses, net of cash acquired |  |  | (96,777 | ) |
| Capital expenditures |  |  | (37,183 | ) |
| Additions to capitalized software |  |  | (8,386 | ) |
| Proceeds from sale of building and land |  |  | 17,201 |  |
| Net cash used by investing activities |  |  | (125,145 | ) |
| Cash flows from financing activities: |  |  |  |  |
| Proceeds from long-term debt and short-term borrowings |  |  | 131,261 |  |
| Principal payments on long-term debt |  |  | (65,000 | ) |
| Dividends paid |  |  | (8,302 | ) |
| Debt issuance costs |  |  | (1,071 | ) |
| Other |  |  | (3,371 | ) |
| Net cash provided by financing activities |  |  | 53,517 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (2,178 | ) |
| Net increase in cash and cash equivalents |  |  | 31,331 |  |
| Cash and cash equivalents, beginning of period |  |  | 30,477 |  |
| Cash and cash equivalents, end of period |  | $ | 61,808 |  |

[0001104659-19-065437:8k_2_02:107]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-19-065437:8k_2_02:108]
Other Selected Financial Data (Unaudited)

[0001104659-19-065437:8k_2_02:109]
(Dollars in thousands)

[0001104659-19-065437:8k_2_02:110]
| Backlog And Entered Orders - Q4 FY 2019 |  | Filtration |  |  | USG |  |  | Test |  |  | Technical Packaging |  |  | Total |  |
| Beginning Backlog - 7/1/19 |  | $ | 231,150 |  |  |  | 41,529 |  |  |  | 143,035 |  |  |  | 16,737 |  |  |  | 432,451 |  |
| Entered Orders |  |  | 154,256 |  |  |  | 54,461 |  |  |  | 52,477 |  |  |  | 18,146 |  |  |  | 279,340 |  |
| Sales |  |  | (96,966 | ) |  |  | (54,276 | ) |  |  | (61,935 | ) |  |  | (23,481 | ) |  |  | (236,658 | ) |
| Ending Backlog - 9/30/19 |  | $ | 288,440 |  |  |  | 41,714 |  |  |  | 133,577 |  |  |  | 11,402 |  |  |  | 475,133 |  |

[0001104659-19-065437:8k_2_02:111]
| Backlog And Entered Orders - YTD Q4 FY 2019 |  | Filtration |  |  | USG |  |  | Test |  |  | Technical Packaging |  |  | Total |  |
| Beginning Backlog - 10/1/18 |  | $ | 204,227 |  |  |  | 40,727 |  |  |  | 122,350 |  |  |  | 15,467 |  |  |  | 382,771 |  |
| Entered Orders |  |  | 409,948 |  |  |  | 212,902 |  |  |  | 199,621 |  |  |  | 82,861 |  |  |  | 905,332 |  |
| Sales |  |  | (325,735 | ) |  |  | (211,915 | ) |  |  | (188,394 | ) |  |  | (86,926 | ) |  |  | (812,970 | ) |
| Ending Backlog - 9/30/19 |  | $ | 288,440 |  |  |  | 41,714 |  |  |  | 133,577 |  |  |  | 11,402 |  |  |  | 475,133 |  |

## item 5.02 — body, verbatim

[0001104659-19-065437:8k_body:1]
Item 5.02

[0001104659-19-065437:8k_body:2]
Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers

[0001104659-19-065437:8k_body:3]
Election of New Director and Reclassification
of Directors

[0001104659-19-065437:8k_body:4]
On November 13, 2019 the Company’s Board of Directors,
by unanimous written consent pursuant to Section 3.1 of its Bylaws, increased the authorized size of the Board of Directors
from eight to nine members and elected Gloria L. Valdez, age 57, as a director to fill the vacancy thereby created.

[0001104659-19-065437:8k_body:5]
Ms. Valdez retired in April 2018 after 32 years of civilian
service with the Department of the Navy and the Department of Homeland Security. Prior to her retirement, she served as the Deputy
Assistant Secretary of the Navy within the Office of the Assistant Secretary of the Navy (ASN) for Research, Development and Acquisition.
In this capacity, she was responsible for executive oversight of all naval shipbuilding programs, major ship conversions, and the
maintenance, modernization and disposal of in-service ships. She previously served as the Executive Director for the Program Executive
Office for submarines, responsible for civilian management, and design, acquisition and construction for submarine platform and
undersea systems, and as the Director of the Investment and Development division within the Office of ASN for Financial Management
and Comptroller.

[0001104659-19-065437:8k_body:6]
Ms. Valdez holds a Master of Science degree in Management from
Florida Institute of Technology as well as a Bachelor of Science degree in Mechanical Engineering from the University of New Mexico.
She has received the Department of the Navy’s Distinguished, Superior and Meritorious Civilian Service Awards, and in 2014
she was awarded the Pioneer award from Great Minds in STEM.

[0001104659-19-065437:8k_body:7]
Ms Valdez was selected to serve the Company on the basis of
her extensive strategic and operational experience in the defense markets as well as her management and financial experience, which
will allow her to assist the board in guiding strategy at the highest level.

[0001104659-19-065437:8k_body:8]
Ms. Valdez will receive compensation for her service on the
Board of Directors and its Committees pursuant to the Company’s Compensation Plan for Non-Employee Directors, as amended
(the “Directors Compensation Plan”), on the same basis as the Company’s other directors; provided that as compensation
for her service during the remainder of calendar 2019 she will receive compensation prorated at 25% of a full year’s compensation,
consisting of cash fees of $12,500, plus an award of shares of Company common stock valued at $45,000 on the issue date, Under
the Directors Compensation Plan, Ms. Valdez has 30 days from the date of her election to elect whether or not to receive the common
stock award, or both the cash fees and common stock award, or neither of them, in common stock equivalents priced at the closing
price of the common stock on the issue/payment date and issuable at the termination of the director’s service in stock and/or
cash, all on the terms and conditions provided in the Directors Compensation Plan.

[0001104659-19-065437:8k_body:9]
Ms. Valdez was designated as a Class II Director, to serve for
a term ending at the 2022 annual meeting of shareholders. She will also serve on the Nominating and Corporate Governance Committee
of the Board of Directors. In order to retain equality of size among the three director classes as nearly as practicable, as required
by the Company’s Bylaws, director Victor L. Richey, previously a Class II director, agreed to be reclassified as a Class
I Director to serve for a shortened term ending at the 2021 annual meeting of shareholders.

[0001104659-19-065437:8k_body:10]
Compensation of Executive Officers

[0001104659-19-065437:8k_body:11]
On November 14, 2019, the Human Resources and Compensation Committee
(the “Committee”) of the Company’s Board of Directors approved the following base salaries and target cash incentive
compensation opportunities for its executive officers for the Company’s 2020 fiscal year ending September 30, 2020. The Committee
determined that increases in total cash compensation of 4.5%, 4.2% and 4.2% were warranted for Mr. Richey, Mr. Muenster and Ms.
Barclay, respectively, and (as it had done for fiscal 2019) it provided each of the executive officers with the discretion to allocate
their increase prospectively between their base salaries and their cash incentive targets. Mr. Richey and Ms. Barclay elected to
allocate the entire dollar amount of their increases to their cash incentive targets, and Mr. Muenster elected to allocate his
increase between his base salary and his cash incentive target, resulting in fiscal 2020 base salaries of $824,500, $600,000 and
$350,600 and cash incentive targets of $927,965, $480,000 and $241,400 for Mr. Richey, Mr. Muenster and Ms. Barclay, respectively.

[0001104659-19-065437:8k_body:12]
For fiscal 2020 the Committee allocated 100% of the executive
officers’ cash incentive compensation opportunity to the Company’s Performance Compensation Plan (“PCP”).
The Committee also approved the fiscal 2020 performance criteria for determining the percentage of such target incentive compensation
opportunity that will actually be earned by the executive officers, depending on actual fiscal 2020 results compared to the criteria.
The Committee established two performance criteria for fiscal 2020:

[0001104659-19-065437:8k_body:13]
·

[0001104659-19-065437:8k_body:14]
Earnings per share adjusted for certain defined non-recurring gains and charges (“Adjusted EPS”), weighted at 70% of the total target opportunity; and

[0001104659-19-065437:8k_body:15]
·

[0001104659-19-065437:8k_body:16]
Cash generated from operations at the subsidiary level, including corporate cash activity related to debt and interest payments, tax payments, pension contributions and corporate general administrative expenses, and excluding corporate cash activity related to acquisitions, dividends and share repurchases (“Cash Flow”), weighted at 30% of the total target opportunity.

[0001104659-19-065437:8k_body:17]
The actual cash incentive compensation payable under the PCP
for fiscal 2020 will range from 0.2 to 2.0 times the target opportunity for both Adjusted EPS and Cash Flow, depending on actual
2020 performance, based on a separate matrix for each of the measures.

[0001104659-19-065437:8k_body:18]
On February 4, 2019 the Compensation and Human Resources Committee
of the Company’s Board of Directors had prospectively amended and restated the PCP effective beginning with the November
2019 awards described above (and other awards granted concurrently therewith). The last previous amendment to the PCP was on November
9, 2017. The 2019 amendments did not increase the amounts or change the forms of compensation which may be paid to the eligible
officers or managers; the principal changes were (i) to update the references in the PCP to refer to the Company’s 2018 Omnibus
Incentive Plan, (ii) to delete references to now-repealed Section 162(m) of the Internal Revenue Code and the qualification of
awards thereunder, and (iii) to clarify the events constituting “Misconduct” for which a recipient’s awards may
be cancelled and other penalties imposed. A copy of the PCP as restated to incorporate the amendments is attached to this report
as Exhibit 10.1, and a copy of the restated PCP marked to indicate the substantive changes since November 2017 is attached
as Exhibit 10.2.
