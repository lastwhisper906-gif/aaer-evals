# ESE notes — 0001104659-19-068679


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001104659-19-068679:notes:1]
1.      Summary of Significant Accounting Policies

[0001104659-19-068679:notes:2]
A.      Principles of Consolidation

[0001104659-19-068679:notes:3]
The Consolidated Financial Statements include the accounts of ESCO Technologies Inc. (ESCO) and its wholly owned subsidiaries (the Company). All significant intercompany transactions and accounts have been eliminated in consolidation.

[0001104659-19-068679:notes:4]
B.      Basis of Presentation

[0001104659-19-068679:notes:5]
The Company’s fiscal year ends on September 30. Throughout the Consolidated Financial Statements, unless the context indicates otherwise, references to a year (for example 2019) refer to the Company’s fiscal year ending on September 30 of that year.

[0001104659-19-068679:notes:6]
The Company accounts for shipping and handling costs on a gross basis and they are included in net sales. The Company accounts for taxes collected from customers and remitted to governmental authorities on a net basis and they are excluded from net sales.

[0001104659-19-068679:notes:7]
C.      Nature of Operations

[0001104659-19-068679:notes:8]
The Company is organized based on the products and services it offers, and classifies its business operations in segments for financial reporting purposes. Under the current organization structure, the Company has four segments for financial reporting purposes: Filtration/Fluid Flow (Filtration), RF Shielding and Test (Test), Utility Solutions Group (USG) and Technical Packaging.

[0001104659-19-068679:notes:9]
Filtration: The companies within this segment primarily design and manufacture specialty filtration products, including hydraulic filter elements and fluid control devices used in commercial aerospace applications; unique filter mechanisms used in micro-propulsion devices for satellites; custom designed filters for manned aircraft and submarines; products and systems to reduce vibration and/or acoustic signatures and otherwise reduce or obscure a vessel’s signature, and other communications, sealing, surface control and hydrodynamic related applications to enhance U.S. Navy maritime survivability; precision-tolerance machined components for the aerospace and defense industry; and metal processing services.

[0001104659-19-068679:notes:10]
USG: The companies within this segment provide high-end, intelligent, diagnostic test and data management solutions for the electric power delivery industry, and decision support tools for the renewable energy industry, primarily wind.

[0001104659-19-068679:notes:11]
Test: ETS-Lindgren Inc. provides its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy.

[0001104659-19-068679:notes:12]
Technical Packaging: The companies within this segment provide innovative solutions to the medical and commercial markets for thermoformed and precision molded pulp fiber packages and specialty products using a wide variety of thin gauge plastics and pulp.

[0001104659-19-068679:notes:13]
D.      Use of Estimates

[0001104659-19-068679:notes:14]
The preparation of financial statements in conformity with GAAP requires Management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.

[0001104659-19-068679:notes:15]
E.      Revenue Recognition

[0001104659-19-068679:notes:16]
On October 1, 2018, we adopted ASU No. 2014-09, Revenue from Contracts with Customers (ASC 606). Significant changes to our policies resulting from the adoption are provided below. We adopted ASC 606 using the modified retrospective transition method applied to contracts that were not substantially complete at the end of fiscal year 2018. We recorded a $5.2 million adjustment to increase retained earnings to reflect the cumulative impact of adopting this standard at the beginning of fiscal year 2019, primarily related to certain long-term contracts in our Filtration and Technical Packaging segments that converted to the cost-to-cost method for revenue recognition. The comparative information has not been restated and is reported under the accounting standards in effect for those periods. A reconciliation of the financial statement line items impacted for the year ended September 30, 2019 under ASC 606 to the prior accounting standards is provided in Note 16.

[0001104659-19-068679:notes:17]
Revenue Recognition

[0001104659-19-068679:notes:18]
Revenue is recognized when control of the goods or services promised under the contract is transferred to the customer either at a point in time (e.g., upon delivery) or over time (e.g., as we perform under the contract). We account for a contract when it has approval and commitment from both parties, the rights and payment terms of the parties are identified, the contract has commercial substance and collectability of consideration is probable. Contracts are reviewed to determine whether there is one or multiple performance obligations. A performance obligation is a promise to transfer a distinct good or service to a customer and represents the unit of accounting for revenue recognition. For contracts with multiple performance obligations, the expected consideration, or the transaction price, is allocated to each performance obligation identified in the contract based on the relative standalone selling price of each performance obligation. Revenue is then recognized for the transaction price allocated to the performance obligation when control of the promised goods or services underlying the performance obligation is transferred.

[0001104659-19-068679:notes:19]
Payment terms with customers vary by the type and location of the customer and the products or services offered. The Company does not adjust the promised amount of consideration for the effects of significant financing components based on the expectation that the period between when the Company transfers a promised good or service to a customer and when the customer pays for that good or service will be one year or less. Arrangements with customers that include payment terms extending beyond one year are not significant.

[0001104659-19-068679:notes:20]
Filtration: Within the Filtration segment, approximately 50% of revenues (approximately 20% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial and military customers and have a single performance obligation as there is only one good promised or the promise to transfer the goods or services is not distinct or separately identifiable from other promises in the contract. The transaction price for these contracts reflects our estimate of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

[0001104659-19-068679:notes:21]
Approximately 50% of the segment’s revenues (approximately 20% of consolidated revenues) are accounted for over time as the product does not have an alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin or the inventory is owned by the customer. The related contracts are primarily cost-plus or fixed price contracts related to the design, development and manufacture of complex fluid control products, quiet valves, manifolds, shock and vibration dampening, thermal insulation and systems primarily for the commercial aerospace and military (U.S. Government) markets. The contracts may contain multiple products, which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. Our contracts are frequently modified for changes in contract specifications and requirements. Most of our contract modifications are for products that are not distinct from the existing contract and are accounted for as part of that existing contract.

[0001104659-19-068679:notes:22]
Contracts with the U.S. Government generally contain clauses that provide lien rights to work-in-process along with clauses that allow the customer to unilaterally terminate the contract for convenience, pay us for costs incurred plus a reasonable profit and take control of any work-in-process. Due to the continuous transfer of control to the U.S. Government, we recognize revenue over the time that we perform under the contract.

[0001104659-19-068679:notes:23]
Selecting the method to measure progress towards completion for the commercial and military contracts requires judgment and is based on the nature of the products or service to be provided. We generally use the cost-to-cost method to measure progress for our Filtration segment contracts, as the rate at which costs are incurred to fulfill a contract best depicts the transfer of control to the customer. Under this measure, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and revenue is recorded proportionally as costs are incurred based on an estimated profit margin.

[0001104659-19-068679:notes:24]
The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Certain of our long-term contracts contain incentive fees that can increase the transaction price. These variable amounts generally are awarded upon achievement of certain performance metrics, program milestones or cost targets and can be based upon customer discretion. We include estimated amounts in the transaction price to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimates of variable consideration and determination of whether to include estimated amounts in the transaction price are based largely on an assessment of our anticipated performance and all other information that is reasonably available to us.

[0001104659-19-068679:notes:25]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to one or more years, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

[0001104659-19-068679:notes:26]
Under the typical payment terms of our long term fixed price contracts, the customer pays us either performance-based or progress payments. Performance-based payments represent interim payments based on quantifiable measures of performance or on the achievement of specified events or milestones. Progress payments are interim payments of costs incurred as the work progresses. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred, which we present as contract assets and contract liabilities, respectively, in the Consolidated Balance Sheets. Amounts billed and due from our customers are classified in Accounts receivable, net. For short term fixed price and cost-type contracts, we are generally paid within a short period of time.

[0001104659-19-068679:notes:27]
For contracts where revenue is recognized over time, we generally recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. We have net revenue recognized in the current year from performance obligations satisfied in the prior year due to changes in our estimated costs to complete the related performance obligations. Anticipated losses on contracts are recognized in full in the period in which the losses become probable and estimable.

[0001104659-19-068679:notes:28]
USG: Within the USG segment, approximately 75% of revenues (approximately 19% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and is accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

[0001104659-19-068679:notes:29]
Approximately 25% of the segment’s revenues (approximately 7% of consolidated revenues) are recognized over time as services are performed. The services accounted for under this method include an obligation to provide testing services using hardware and embedded software, software maintenance, training, lab testing, and consulting services. The related contracts contain a bundle of goods and services that are integrated in the context of the contract. Therefore, the goods and services are not distinct and the Company has a single performance obligation. Selecting the method to measure progress towards completion for these contracts requires judgment and is based on the nature of the products and service to be provided. We will recognize revenue as a series of distinct services based on each day of providing services (straight-line over the contract term) for our USG segment contracts. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Under the typical payment terms of our service contracts, the customer pays us in advance of when services are performed. Because of the timing difference of revenue recognition and customer payment, which is typically received upon commencement of the contract, these contracts result in deferred revenue, which we present as contract liabilities, in the Consolidated Balance Sheets.

[0001104659-19-068679:notes:30]
Included in this category, approximately 10% of the segment’s revenues (approximately 2% of consolidated revenues) are recognized based on the terms of the software contract. For contracts that transfer a software license to the customer, revenue will be recognized at a point in time. These type of software contracts represent a right to use the software, or a functional license, in which revenue should be recognized upon transfer of the license. For contracts in software as a service (SaaS) arrangements, revenue will be recognized over time. The customer receives and consumes the benefits of the SaaS arrangement through access to the system which is for a stated period. We will recognize revenue based on each day of providing access (straight-line over the contract term). The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Under the typical payment terms of our software contracts, the customer pays us in advance of when services are performed. Because of the timing difference of revenue recognition and customer payment, these contracts result in deferred revenue, which we present as contract liabilities, in the Consolidated Balance Sheets.

[0001104659-19-068679:notes:31]
Test: Within the Test segment, approximately 20% of revenues (approximately 4% of consolidated revenues) are recognized at a point in time when products such as, antennas and probes are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

[0001104659-19-068679:notes:32]
Approximately 80% of the segment’s revenues (approximately 19% of consolidated revenues) are recorded over time as the product does not have an alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin. Products accounted for under this guidance include the construction and installation of test chambers to a buyer’s specifications that provide its customers with the ability to measure and contain magnetic, electromagnetic and acoustic energy. The goods and services related to each installed test chamber are not distinct due to the significant amount of integration provided and each installed chamber is accounted for as a single performance obligation. Selecting the method to measure progress towards completion for these contracts requires judgment and is based on the nature of the products and service to be provided. We use milestones to measure progress for our Test segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. For arrangements that are accounted for under this guidance, the Company estimates profit as the difference between total revenue and total estimated cost of a contract and recognizes these revenues and costs based primarily on contract milestones. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable.

[0001104659-19-068679:notes:33]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to a year, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

[0001104659-19-068679:notes:34]
Under the typical payment terms of our fixed price contracts, the customer pays us either performance-based or progress payments. Performance-based payments represent interim payments based on quantifiable measures of performance or on the achievement of specified events or milestones. Progress payments are interim payments of costs incurred as the work progresses. Because of the timing difference of revenue recognition and customer billing, these contracts result in revenue recognized in excess of billings and billings in excess of costs incurred, which we present as contract assets and contract liabilities, respectively, in the Consolidated Balance Sheets. Amounts billed and due from our customers are classified in Accounts receivable, net.

[0001104659-19-068679:notes:35]
For contracts where revenue is recognized over time, we generally recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. We have net revenue recognized in the current year from performance obligations satisfied in the prior year due to changes in our estimated costs to complete the related

[0001104659-19-068679:notes:36]
performance obligations. Anticipated losses on contracts are recognized in full in the period in which the losses become probable and estimable.

[0001104659-19-068679:notes:37]
Technical Packaging: Within the Technical Packaging segment, 100% of the revenues (approximately 11% of consolidated revenues) are recognized over time as the product does not have an alternative use and the Company has an enforceable right to payment. Selecting the method to measure progress towards completion for the contracts requires judgment and is based on the nature of the products to be provided. We use the cost-to-cost method to measure progress for our Technical Packaging segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. Under this measure, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and revenue is recorded proportionally as costs are incurred. The transaction price for our contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant.

[0001104659-19-068679:notes:38]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of weeks, minimizing the amount of judgment in developing the cost estimate. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

[0001104659-19-068679:notes:39]
Under the typical payment terms of our contracts, the customer is billed upon shipment of product. Amounts billed and due from our customers are classified in Accounts receivable, net. Because of the timing difference of revenue recognition and customer billing, these contracts result in revenue recognized in excess of billings, which we present as contract assets in the Consolidated Balance Sheets.

[0001104659-19-068679:notes:40]
For contracts where revenue is recognized over time, we generally recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. Anticipated losses on contracts are recognized in full in the period in which the losses become probable and estimable.

[0001104659-19-068679:notes:41]
Contract Assets and Liabilities

[0001104659-19-068679:notes:42]
Contract assets arise from contracts when revenue is recognized over time and the amount of revenue recognized, including our estimate of variable consideration that has been included in the transaction price, exceeds the amount billed to the customer. These amounts are included in contract assets until the right to payment is no longer conditional on events other than the passage of time. These contract assets are reclassified to receivables when the right to consideration becomes unconditional. Contract liabilities include deposits, deferred revenue, upfront payments and billings in excess of revenue recognized. Liabilities for customer rebates and discounts are included in other current liabilities in the accompanying balance sheet.

[0001104659-19-068679:notes:43]
See the further discussion of the Company’s revenue recognition in Note 16 below.

[0001104659-19-068679:notes:44]
Prior to Adoption of ASC 606

[0001104659-19-068679:notes:45]
Prior to October 1, 2018, Management recognized revenue consistent with ASC 605. The Filtration and Technical Packaging segments were most impacted by the change in the timing of revenue recognition. Under ASC 605, the Filtration segment recognized 85% and 86% of revenues upon delivery of products (when title and risk of ownership transfers) and when the other general conditions to revenue recognition (collectability of revenues is probable, there is evidence of an arrangement, fees are fixed and determinable) are met, and 15% and 14% of revenues under percentage-of-completion in 2018 and 2017, respectively. Under ASC 605, the Technical Packaging segment recognized 100% of revenues upon delivery of products (when title and risk of ownership transfers) in 2018 and 2017. The change to recording more revenue over time as costs are incurred at both segments is the result of the products not having an alternative use and the Company having an enforceable right to payment for costs incurred plus a reasonable margin or the inventory is owned by the customer.

[0001104659-19-068679:notes:46]
The timing of revenue recognition under ASC 605 and ASC 606 was similar for the USG and Test segments. Within the USG segment, 25% and 22% of revenues were recognized under percentage-of-completion and 75% and 78% of revenues were recognized when products were delivered or services performed (when title and risk of ownership transfers) and when the other general conditions to revenue recognition (collectability of revenues is probable, there is evidence of an arrangement, fees are fixed and

[0001104659-19-068679:notes:47]
determinable) are met) in 2018 and 2017, respectively. Within the Test segment, 75% and 70% of revenues were recognized under percentage-of-completion and 25% and 30% of revenues were recognized when products were delivered or services performed (when title and risk of ownership transfers) in 2018 and 2017, respectively.

[0001104659-19-068679:notes:48]
F.      Cash and Cash Equivalents

[0001104659-19-068679:notes:49]
Cash equivalents include temporary investments that are readily convertible into cash, such as money market funds, with original maturities of three months or less.

[0001104659-19-068679:notes:50]
G.      Accounts Receivable

[0001104659-19-068679:notes:51]
Accounts receivable have been reduced by an allowance for amounts that the Company estimates are uncollectible in the future. This estimated allowance is based on Management’s evaluation of the financial condition of the customer and historical write-off experience.

[0001104659-19-068679:notes:52]
H.      Inventories

[0001104659-19-068679:notes:53]
Inventories are valued at the lower of cost (first-in, first-out) or market value. Inventories are regularly reviewed for excess quantities and obsolescence based upon historical experience, specific identification of discontinued items, future demand, and market conditions. Inventories under long-term contracts reflect accumulated production costs, factory overhead, initial tooling and other related costs less the portion of such costs charged to cost of sales.

[0001104659-19-068679:notes:54]
I.      Property, Plant and Equipment

[0001104659-19-068679:notes:55]
Property, plant and equipment are recorded at cost. Depreciation and amortization are computed primarily on a straight-line basis over the estimated useful lives of the assets: buildings, 10-40 years; machinery and equipment, 3-10 years; and office furniture and equipment, 3-10 years. Leasehold improvements are amortized over the remaining term of the applicable lease or their estimated useful lives, whichever is shorter. Long-lived tangible assets are reviewed for impairment whenever events or changes in business circumstances indicate the carrying value of the assets may not be recoverable. Impairment losses are recognized based on fair value.

[0001104659-19-068679:notes:56]
J.      Leases

[0001104659-19-068679:notes:57]
Lease agreements are evaluated to determine whether they are capital or operating leases in accordance with ASC 840, Leases (ASC 840). When any one of the four test criteria in ASC 840 is met, the lease then qualifies as a capital lease. Capital leases are capitalized at the lower of the net present value of the total amount payable under the leasing agreement (excluding finance charges) or the fair market value of the leased asset. Capital lease assets are depreciated on a straight-line basis, over a period consistent with the Company’s normal depreciation policy for tangible fixed assets. The Company allocates each lease payment between a reduction of the lease obligation and interest expense using the effective interest method. Rent expense for operating leases, which may include free rent or fixed escalation amounts in addition to minimum lease payments, is recognized on a straight-line basis over the duration of the lease term. Capital lease obligations are included within other long-term liabilities (long-term portion) and accrued other expenses (current portion).

[0001104659-19-068679:notes:58]
K.      Goodwill and Other Long-Lived Assets

[0001104659-19-068679:notes:59]
Goodwill represents the excess of purchase price over the fair value of net identifiable assets acquired in business acquisitions. Management annually reviews goodwill and other long-lived assets with indefinite useful lives for impairment or whenever events or changes in circumstances indicate the carrying amount may not be recoverable. If the Company determines that the carrying value of the long-lived asset may not be recoverable, a permanent impairment charge is recorded for the amount by which the carrying value of the long-lived asset exceeds its fair value. Fair value is measured based on a discounted cash flow method using a discount rate determined by Management to be commensurate with the risk inherent in each of our reporting units' current business models. During 2019, the revenue softness in the Company’s renewable energy subsidiary NRG led management to perform a more comprehensive impairment analysis, which included a detailed calculation surrounding the carrying value of its $8 million of goodwill and $8 million of tradename related to that reporting unit. The results of these additional analyses indicated that our estimates of discounted cash flows for assets measured in accordance with ASC 350, Intangibles – Goodwill and Other would allow the carrying amounts to be recovered. Since we are using estimates of discounted cash flows, these may change, and if they change negatively it could result in the need to write down those assets to fair value.

[0001104659-19-068679:notes:60]
Other intangible assets represent costs allocated to identifiable intangible assets, principally customer relationships, capitalized software, patents, trademarks, and technology rights. Intangible assets with estimable useful lives are amortized over their respective estimated useful lives to their estimated residual values, and are reviewed for impairment whenever events or changes in business circumstances indicate the carrying value of the assets may not be recoverable. See Note 3 regarding goodwill and other intangible assets activity.

[0001104659-19-068679:notes:61]
L.      Capitalized Software

[0001104659-19-068679:notes:62]
The costs incurred for the development of computer software that will be sold, leased, or otherwise marketed are charged to expense when incurred as research and development until technological feasibility has been established for the product. Technological feasibility is typically established upon completion of a detailed program design. Costs incurred after this point are capitalized on a project-by-project basis. Capitalized costs consist of internal and external development costs. Upon general release of the product to customers, the Company ceases capitalization and begins amortization, which is calculated on a project-by-project basis as the greater of (1) the ratio of current gross revenues for a product to the total of current and anticipated future gross revenues for the product or (2) the straight-line method over the estimated economic life of the product. The Company generally amortizes the software development costs over a three-to-seven year period based upon the estimated future economic life of the product. Factors considered in determining the estimated future economic life of the product include anticipated future revenues, and changes in software and hardware technologies. Management annually reviews the carrying values of capitalized costs for impairment or whenever events or changes in circumstances indicate the carrying amount may not be recoverable. If expected cash flows are insufficient to recover the carrying amount of the asset, then an impairment loss is recognized to state the asset at its net realizable value.

[0001104659-19-068679:notes:63]
M.      Income Taxes

[0001104659-19-068679:notes:64]
Income taxes are accounted for under the asset and liability method. Deferred tax assets and liabilities are recognized for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. Deferred tax assets may be reduced by a valuation allowance if it is more likely than not that some portion or all of the deferred tax assets will not be realized. The effect on deferred tax assets and liabilities of a change in tax rates is recognized in income in the period that includes the enactment date. The Company regularly reviews its deferred tax assets for recoverability and establishes a valuation allowance when Management believes it is more likely than not such assets will not be recovered, taking into consideration historical operating results, expectations of future earnings, tax planning strategies, and the expected timing of the reversals of existing temporary differences.

[0001104659-19-068679:notes:65]
N.      Research and Development Costs

[0001104659-19-068679:notes:66]
Company-sponsored research and development costs include research and development and bid and proposal efforts related to the Company’s products and services. Company-sponsored product development costs are charged to expense when incurred. Customer-sponsored research and development costs incurred pursuant to contracts are accounted for similarly to other program costs. Customer-sponsored research and development costs refer to certain situations whereby customers provide funding to support specific contractually defined research and development costs. Total Company and customer-sponsored research and development expenses were approximately $14.5 million, $13.1 million and $14.0 million for 2019, 2018 and 2017, respectively. These expense amounts exclude certain engineering costs primarily associated with product line extensions, modifications and maintenance, which amounted to approximately $15.8 million, $13.1 million and $10.4 million for 2019, 2018 and 2017, respectively.

[0001104659-19-068679:notes:67]
O.      Foreign Currency Translation

[0001104659-19-068679:notes:68]
The financial statements of the Company’s foreign operations are translated into U.S. dollars in accordance with FASB ASC Topic 830, Foreign Currency Matters. The resulting translation adjustments are recorded as a separate component of accumulated other comprehensive income.

[0001104659-19-068679:notes:69]
P.      Earnings Per Share

[0001104659-19-068679:notes:70]
Basic earnings per share is calculated using the weighted average number of common shares outstanding during the period. Diluted earnings per share is calculated using the weighted average number of common shares outstanding during the period plus shares issuable upon the assumed exercise of dilutive common share options and vesting of performance-accelerated restricted shares using the treasury stock method. There are no anti-dilutive shares.

[0001104659-19-068679:notes:71]
The number of shares used in the calculation of earnings per share for each year presented is as follows:

[0001104659-19-068679:notes:72]
| (in thousands) |  | 2019 |  | 2018 |  | 2017 |
| Weighted Average Shares Outstanding — Basic |  | 25,946 |  | 25,874 |  | 25,774 |
| Performance- Accelerated Restricted Stock |  | 151 |  | 184 |  | 221 |
| Shares — Diluted |  | 26,097 |  | 26,058 |  | 25,995 |

[0001104659-19-068679:notes:73]
Q.      Share-Based Compensation

[0001104659-19-068679:notes:74]
The Company provides compensation benefits to certain key employees under several share-based plans providing for employee stock options and/or performance-accelerated restricted shares (restricted shares), and to non-employee directors under a non-employee directors compensation plan. Share-based payment expense is measured at the grant date based on the fair value of the award and is recognized on a straight-line basis over the requisite service period (generally the vesting period of the award).

[0001104659-19-068679:notes:75]
R.      Accumulated Other Comprehensive Loss

[0001104659-19-068679:notes:76]
Accumulated other comprehensive loss of $(44.0) million at September 30, 2019 consisted of $(37.0) million related to the pension actuarial loss; and $(7.0) million related to currency translation adjustments. Accumulated other comprehensive loss of $(31.5) million at September 30, 2018 consisted of $(30.9) million related to the pension net actuarial loss; $(0.5) million related to currency translation adjustments; and $(0.1) million related to forward exchange contracts.

[0001104659-19-068679:notes:77]
S.      Deferred Revenue and Costs

[0001104659-19-068679:notes:78]
Deferred revenue and costs are recorded when products or services have been provided or cash has been received but the criteria for revenue recognition have not been met. If there is a customer acceptance provision or there is uncertainty about customer acceptance, revenue and costs are deferred until the customer has accepted the product or service.

[0001104659-19-068679:notes:79]
T.      Derivative Financial Instruments

[0001104659-19-068679:notes:80]
All derivative financial instruments are reported on the balance sheet at fair value. The accounting for changes in fair value of a derivative instrument depends on whether it has been designated and qualifies as a hedge and on the type of hedge. For each derivative instrument designated as a cash flow hedge, the effective portion of the gain or loss on the derivative is deferred in accumulated other comprehensive income until recognized in earnings with the underlying hedged item. For each derivative instrument designated as a fair value hedge, the gain or loss on the derivative and the offsetting gain or loss on the hedged item are recognized immediately in earnings. Regardless of type, a fully effective hedge will result in no net earnings impact while the derivative is outstanding. To the extent that any hedge is ineffective at offsetting cash flow or fair value changes in the underlying hedged item, there could be a net earnings impact.

[0001104659-19-068679:notes:81]
U.      Fair Value Measurements

[0001104659-19-068679:notes:82]
Fair value is defined as the price at which an asset could be exchanged in a current transaction between knowledgeable, willing parties or the amount that would be paid to transfer a liability to a new obligor, not the amount that would be paid to settle the liability with the creditor. Where available, fair value is based on observable market prices or parameters or derived from such prices or parameters. Where observable prices or inputs are not available, valuation models are applied. These valuation techniques involve some level of Management estimation and judgment, the degree of which is dependent on the price transparency for the instruments or market and the instruments’ complexity.

[0001104659-19-068679:notes:83]
The accounting guidance establishes a three-level hierarchy for disclosure of fair value measurements, based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date, as follows:

[0001104659-19-068679:notes:84]
Level 1 – Inputs to the valuation methodology are quoted prices (unadjusted) for identical assets or liabilities in active markets.

[0001104659-19-068679:notes:85]
Level 2 –Inputs to the valuation methodology include quoted prices for similar assets and liabilities in active markets, and inputs that are observable for the asset or liability, either directly or indirectly, for substantially the full term of the financial instrument.

[0001104659-19-068679:notes:86]
Level 3 – Inputs to the valuation methodology are unobservable and significant to the fair value measurement.

[0001104659-19-068679:notes:87]
Financial Assets and Liabilities

[0001104659-19-068679:notes:88]
The Company has estimated the fair value of its financial instruments as of September 30, 2019 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables and other current assets and liabilities approximate fair value because of the short maturity of those instruments. The carrying amounts due under the revolving credit facility approximate fair value as the interest on outstanding borrowings is calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election.

[0001104659-19-068679:notes:89]
Nonfinancial Assets and Liabilities

[0001104659-19-068679:notes:90]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during 2019.

[0001104659-19-068679:notes:91]
V.      New Accounting Standards

[0001104659-19-068679:notes:92]
Leases

[0001104659-19-068679:notes:93]
In February 2016, the FASB issued ASU No. 2016-062, "Leases" (ASU 2016-02) which supersedes ASC 840, "Leases" and creates a new topic, ASC 842, "Leases." Subsequent to the issuance of ASU 2016-02, ASC 842 was amended by various updates that amend and clarify the impact and implementation of the aforementioned update. These updates require lessees to recognize a lease liability and a lease asset for all leases, including operating leases, with a term greater than 12 months on its balance sheet. Upon initial application, the provisions of these updates are required to be applied using the modified retrospective method which requires retrospective adoption to each prior reporting period presented with the cumulative effect of adoption recorded to the earliest reporting period presented. An optional transition method can be utilized which requires retrospective adoption beginning on the date of adoption with the cumulative effect of initially applying these updates recognized at the date of initial adoption. These updates also expand the required quantitative and qualitative disclosures surrounding leases. These updates are effective for fiscal years beginning after December 15, 2018 and interim periods within those fiscal years, with earlier application permitted. We adopted these updates on October 1, 2019 using the optional transition method. The adoption resulted in the addition of "right of use" assets and lease liabilities of approximately $25 million to our consolidated balance sheet, with no significant change to our consolidated statements of operations or cash flows. The updates will also have an impact on our accounting policies, internal controls and disclosures related to leases.

[0001104659-19-068679:notes:94]
Other Standards

[0001104659-19-068679:notes:95]
In January 2018, the FASB issued ASU No. 2018-02, Income Statement – Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which gives entities the option to reclassify to retained earnings the tax effects resulting from the Act related to items in accumulated other comprehensive income (loss) (AOCI) that the FASB refers to as having been stranded in AOCI. This new standard is effective for annual periods beginning after December 15, 2018. The Company adopted this ASU in the fourth quarter of 2018 and, as a result of adopting this standard, it reclassified $6.3 million from AOCI to retained earnings.

[0001104659-19-068679:notes:96]
In January 2017, the FASB issued Accounting Standards Update (ASU) No. 2017-04, Simplifying the Test for Goodwill Impairment (ASU 2017-04), which eliminates Step 2 from the goodwill impairment test. Under the amendments in this update, an entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value; however, the loss recognized should not exceed the total amount of goodwill allocated to that reporting unit. The new standard is effective for fiscal years beginning after December 15, 2019. Early adoption is permitted for interim or annual goodwill impairment test performed on testing dates after January 1, 2017. The Company adopted this standard in the fourth quarter of 2017 with its annual goodwill impairment tests. The adoption of ASU 2017-04 did not have an impact on the Company’s consolidated financial statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001104659-19-068679:notes:97]
2.      Acquisitions

[0001104659-19-068679:notes:98]
2019

[0001104659-19-068679:notes:99]
On July 2, 2019 the Company acquired Globe Composite Solutions, LLC, for a purchase price of approximately $95 million, net of cash acquired. Globe, based in Stoughton, Massachusetts, is a well-established, vertically integrated supplier of mission-critical composite-based products and solutions for navy, defense, and industrial customers, Globe has annualized sales of approximately $37

[0001104659-19-068679:notes:100]
million. Since the date of acquisition, the operating results for Globe have been included in the Company’s Filtration segment. Based on the preliminary purchase price allocation, the Company recorded approximately $3.5 million of accounts receivable, $3.5 million of inventory, $6.3 million of property, plant and equipment, $10.5 million of accounts payable, accrued expenses and advance payments, $28.5 million of goodwill, $3.7 million of tradenames and $59.7 million of amortizable intangible assets consisting mainly of $56.7 million of customer relationships with a weighted average life of 20 years and $2.8 million of customer contract assets. The final working capital adjustment is due in January 2020. The acquired goodwill relates to excess value associated with the opportunities to expand the services and markets that the Company can offer to its customers. The Company estimates approximately $25 million of the goodwill will be deductible for tax purposes.

[0001104659-19-068679:notes:101]
2018

[0001104659-19-068679:notes:102]
On March 14, 2018, the Company acquired the assets of Manta Test Systems Inc. (Manta), a North American utility solutions provider located in Mississauga, Ontario, Canada, for a purchase price of $9.5 million in cash. Since the date of acquisition, the operating results for Manta have been included as a product line of Doble within the Company’s USG segment. Based on the purchase price allocation, the Company recorded approximately $0.4 million of accounts receivable, $1.1 million of inventory, $0.2 million of property, plant and equipment, $0.4 million of accounts payable and accrued expenses, $3.5 million of goodwill, $1.2 million of tradenames and $3.5 million of amortizable intangible assets consisting of customer relationships with a weighted average life of 13 years.

[0001104659-19-068679:notes:103]
2017

[0001104659-19-068679:notes:104]
On August 30, 2017, the Company acquired the assets of Vanguard Instruments Company (Vanguard Instruments), a test equipment provider serving the global electric utility market, located in Ontario, California, for a purchase price of $36.0 million in cash. Since the date of acquisition, the operating results for Vanguard Instruments have been included as a product line of Doble within the Company’s USG segment. Based on the purchase price allocation, the Company recorded approximately $1.8 million of accounts receivable, $2.1 million of inventory, $0.3 million of property, plant and equipment, $0.2 million of accounts payable and accrued expenses, $10.7 million of goodwill, $3.2 million of tradenames and $18.0 million of amortizable intangible assets consisting of customer relationships with a weighted average life of 15 years.

[0001104659-19-068679:notes:105]
On May 25, 2017, the Company acquired the assets of Morgan Schaffer Inc. (Morgan Schaffer), a global utilities provider located in Montreal, Quebec, Canada, for a purchase price of $48.8 million in cash. Since the date of acquisition, the operating results for Morgan Schaffer have been included in the Company’s USG segment. Based on the purchase price allocation, the Company recorded approximately $2.5 million of accounts receivable, $5.2 million of inventory, $1.7 million of property, plant and equipment, $0.4 million of other assets, $4.9 million of accounts payable and accrued expenses, $4.8 million of goodwill, $35.6 million of trade names and $3.6 million of amortizable intangible assets consisting of customer relationships and developed technology with a weighted average life of approximately 10 years.

[0001104659-19-068679:notes:106]
On May 8, 2017, the Company acquired NRG Systems, Inc. (NRG), located in Hinesburg, Vermont, for a purchase price of $38.6 million in cash (net of cash acquired). NRG is a global market leader in the design and manufacture of decision support tools for the renewable energy industry, primarily wind. Since the date of acquisition, the operating results for NRG have been included in the Company’s USG segment. Based on the purchase price allocation, the Company recorded approximately $1.5 million of cash, $4.1 million of accounts receivable, $5.1 million of inventory, $0.4 million of other assets, $9.4 million of property, plant and equipment (including a capital lease), $4.3 million of accounts payable and accrued expenses, $8.9 million of long-term lease liability, $7.5 million of goodwill, $8.1 million of trade names and $17.2 million of amortizable intangible assets consisting of customer relationships with a weighted average life of approximately 14 years.

[0001104659-19-068679:notes:107]
On November 7, 2016, the Company acquired aerospace suppliers Mayday Manufacturing Co. (Mayday) and its affiliate, Hi-Tech Metals, Inc. (Hi-Tech), which share a state-of-the-art, expandable 130,000 square foot facility in Denton, Texas, for a purchase price of approximately $75 million in cash. Since the date of acquisition, the consolidated operating results for Mayday and Hi-Tech have been included in the Company’s Filtration segment. Based on the purchase price allocation, the Company recorded approximately $7.4 million of accounts receivable, $11.0 million of inventory, $0.3 million of other assets, $16.6 million of property, plant and equipment (including a capital lease), $2.8 million of accounts payable and accrued expenses, $9.5 million of long-term lease liability, $15.7 million of deferred tax liabilities, $30.1 million of goodwill, $4.8 million of trade names and $32.8 million of amortizable identifiable intangible assets consisting primarily of customer relationships with a weighted-average life of approximately 20 years.

[0001104659-19-068679:notes:108]
All of the Company’s acquisitions have been accounted for using the purchase method of accounting, and accordingly, the respective purchase prices were allocated to the assets (including intangible assets) acquired and liabilities assumed based on estimated fair

[0001104659-19-068679:notes:109]
values at the date of acquisition. The financial results from these acquisitions have been included in the Company’s financial statements from the date of acquisition.

[0001104659-19-068679:notes:110]
The goodwill recorded for the Mayday acquisition mentioned above is not expected to be deductible for U.S. Federal or state income tax purposes. The goodwill recorded for the Globe, Vanguard Instruments and NRG acquisitions mentioned above is expected to be deductible for U.S. Federal and state income tax purposes. The goodwill recorded for the Manta and Morgan Schaffer acquisitions is expected to be deductible for Canadian income tax purposes.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001104659-19-068679:notes:111]
3.      Goodwill and Other Intangible Assets

[0001104659-19-068679:notes:112]
Included on the Company’s Consolidated Balance Sheets at September 30, 2019 and 2018 are the following intangible assets gross carrying amounts and accumulated amortization:

[0001104659-19-068679:notes:113]
| (Dollars in millions) |  | 2019 |  | 2018 |
| Goodwill | ​ | $ | 409.2 |  | 381.7 |
| Intangible assets with determinable lives: | ​ |  | ​ | ​ |  |
| Patents | ​ |  | ​ | ​ |  |
| Gross carrying amount | ​ | $ | 2.1 | ​ | 1.8 |
| Less: accumulated amortization | ​ |  | 0.9 | ​ | 0.8 |
| Net | ​ | $ | 1.2 | ​ | 1.0 |
| Capitalized software | ​ |  | ​ | ​ |  |
| Gross carrying amount | ​ | $ | 79.7 | ​ | 71.3 |
| Less: accumulated amortization | ​ |  | 49.2 | ​ | 41.6 |
| Net | ​ | $ | 30.5 | ​ | 29.7 |
| Customer Relationships | ​ |  | ​ | ​ |  |
| Gross carrying amount | ​ | $ | 241.3 | ​ | 185.3 |
| Less: accumulated amortization | ​ |  | 59.0 | ​ | 47.8 |
| Net | ​ | $ | 182.3 | ​ | 137.5 |
| Other | ​ |  | ​ | ​ |  |
| Gross carrying amount | ​ | $ | 5.3 | ​ | 5.5 |
| Less: accumulated amortization | ​ |  | 2.6 | ​ | 2.0 |
| Net | ​ | $ | 2.7 | ​ | 3.5 |
| Intangible assets with indefinite lives: | ​ |  | ​ | ​ |  |
| Trade names | ​ | $ | 176.3 | ​ | 173.7 |

[0001104659-19-068679:notes:114]
The Company performed its annual evaluation of goodwill and intangible assets for impairment during the fourth quarter of 2019 and concluded no impairment existed at September 30, 2019 and there are no accumulated impairment losses as of September 30, 2019.

[0001104659-19-068679:notes:115]
The changes in the carrying amount of goodwill attributable to each business segment for 2019 and 2018 are as follows:

[0001104659-19-068679:notes:116]
| (Dollars in millions) |  | Filtration |  | Test |  | USG |  | Technical Packaging |  | Total |
| Balance as of September 30, 2017 | ​ | $ | 73.7 |  | 34.1 |  | 250.2 |  | 19.9 |  | 377.9 |
| Acquisition activity | ​ |  | — |  | — |  | 3.9 |  | — |  | 3.9 |
| Foreign currency translation and other | ​ |  | — |  | — |  | — |  | (0.1) |  | (0.1) |
| Balance as of September 30, 2018 | ​ | ​ | 73.7 |  | 34.1 |  | 254.1 |  | 19.8 |  | 381.7 |
| Acquisition activity | ​ | ​ | 28.5 | ​ | — | ​ | — | ​ | — | ​ | 28.5 |
| Foreign currency translation and other | ​ | ​ | — | ​ | — | ​ | (0.1) | ​ | (0.9) | ​ | (1.0) |
| Balance as of September 30, 2019 | ​ | $ | 102.2 | ​ | 34.1 | ​ | 254.0 | ​ | 18.9 | ​ | 409.2 |

[0001104659-19-068679:notes:117]
Amortization expense related to intangible assets with determinable lives was $19.5 million, $18.3 million and $16.3 million in 2019, 2018 and 2017, respectively. Patents are amortized over the life of the patents, generally 17 years. Capitalized software is amortized over the estimated useful life of the software, generally three to seven years. Customer relationships are generally amortized over

[0001104659-19-068679:notes:118]
fifteen to twenty years. Intangible asset amortization for fiscal years 2020 through 2024 is estimated at approximately $22 million per year.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001104659-19-068679:notes:119]
4.      Accounts Receivable

[0001104659-19-068679:notes:120]
Accounts receivable, net of the allowance for doubtful accounts, consist of the following at September 30, 2019 and 2018:

[0001104659-19-068679:notes:121]
| (Dollars in thousands) |  | 2019 |  | 2018 |
| Commercial | ​ | $ | 153,265 |  | 146,049 |
| U.S. Government and prime contractors | ​ |  | 21,162 |  | 17,691 |
| Total | ​ | $ | 174,427 |  | 163,740 |


## us-gaap:InventoryDisclosureTextBlock

[0001104659-19-068679:notes:122]
5.      Inventories, Net

[0001104659-19-068679:notes:123]
Inventories consist of the following at September 30, 2019 and 2018:

[0001104659-19-068679:notes:124]
| (Dollars in thousands) |  | 2019 |  | 2018 |
| Finished goods | ​ | $ | 23,550 |  | 26,678 |
| Work in process | ​ |  | 26,407 |  | 47,765 |
| Raw materials | ​ |  | 78,868 |  | 60,973 |
| Total | ​ | $ | 128,825 |  | 135,416 |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001104659-19-068679:notes:125]
6.      Related Parties

[0001104659-19-068679:notes:126]
One of the Company’s directors is an officer at a customer of the Company’s subsidiary Doble. Doble sells products, rents equipment and provides testing services to the customer in the ordinary course of Doble’s business. The total amount of these sales were approximately $3.3 million, $2.1 million and $3.6 million during fiscal 2019, 2018 and 2017, respectively. All transactions between Doble and the customer are intended to be and have been consistent with Doble’s normal commercial terms offered to its customers, and the Company’s Board of Directors has determined that the relationship between the Company and the customer is not material and did not impair either the Company’s or the director’s independence.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001104659-19-068679:notes:127]
7.      Income Tax Expense

[0001104659-19-068679:notes:128]
The components of income before income taxes for 2019, 2018 and 2017 consisted of the following:

[0001104659-19-068679:notes:129]
| (Dollars in thousands) |  | 2019 |  | 2018 |  | 2017 |
| United States | ​ | $ | 93,654 |  | 80,994 |  | 72,353 |
| Foreign | ​ |  | 8,562 |  | 7,029 |  | 7,800 |
| Total income before income taxes | ​ | $ | 102,216 |  | 88,023 |  | 80,153 |

[0001104659-19-068679:notes:130]
The principal components of income tax expense (benefit) for 2019, 2018 and 2017 consist of:

[0001104659-19-068679:notes:131]
| (Dollars in thousands) |  | 2019 |  | 2018 |  | 2017 |
| Federal: |  | ​ |  |  |  |  |  |
| Current | ​ | $ | 14,097 |  | 9,174 |  | 21,448 |
| Deferred | ​ |  | 1,020 |  | (22,943) |  | 628 |
| State and local: | ​ |  | ​ |  |  |  |  |
| Current | ​ |  | 3,189 |  | 2,121 |  | 1,795 |
| Deferred | ​ |  | 204 |  | 2,972 |  | (49) |
| Foreign: | ​ |  | ​ |  |  |  |  |
| Current | ​ |  | 2,493 |  | 2,233 |  | 4,450 |
| Deferred | ​ |  | 174 |  | 2,330 |  | (1,822) |
| Total | ​ | $ | 21,177 |  | (4,113) |  | 26,450 |

[0001104659-19-068679:notes:132]
The actual income tax expense (benefit) for 2019, 2018 and 2017 differs from the expected tax expense for those years (computed by applying the U.S. Federal corporate statutory rate) as follows:

[0001104659-19-068679:notes:133]
| ​ |  | 2019 |  | 2018 |  | 2017 |  |
| Federal corporate statutory rate |  | 21.0 | % | 24.5 | % | 35.0 | % |
| State and local, net of Federal benefits | ​ | 3.3 |  | 3.0 |  | 2.4 | ​ |
| Foreign | ​ | 0.7 |  | 0.6 |  | (0.1) | ​ |
| Research credit | ​ | (0.9) |  | (1.6) |  | (1.1) | ​ |
| Domestic production deduction | ​ | — |  | (1.1) |  | (2.7) | ​ |
| Change in uncertain tax positions | ​ | (0.1) |  | (0.1) |  | — | ​ |
| Executive compensation | ​ | 0.3 |  | (0.1) |  | (0.1) | ​ |
| Valuation allowance | ​ | (2.4) |  | 3.0 |  | (0.3) | ​ |
| GILTI and FDII | ​ | (0.8) | ​ | — | ​ | — | ​ |
| Tax reform – impact on U.S. deferred tax assets and liabilities | ​ | (0.3) |  | (37.2) |  | — | ​ |
| Tax reform – transition tax | ​ | (0.1) |  | 1.5 |  | — | ​ |
| Tax reform – taxes related to foreign unremitted earnings | ​ | — |  | 2.8 |  | — | ​ |
| Other, net | ​ | — |  | — |  | (0.1) | ​ |
| Effective income tax rate | ​ | 20.7 | % | (4.7) | % | 33.0 | % |

[0001104659-19-068679:notes:134]
On December 22, 2017, President Trump signed into law new tax legislation commonly referred to as the Tax Cut and Jobs Act (the “TCJA”). Provisions under the TCJA that became effective for the Company in the current fiscal year include a further reduction in the U.S. statutory rate to 21%, a new minimum tax on global intangible low-taxed income (“GILTI”), the benefit of the deduction for foreign-derived intangible income ("FDII"), and changes to IRC Section 162(m) related to the deductibility of executive compensation.

[0001104659-19-068679:notes:135]
The tax effects of temporary differences that give rise to significant portions of the deferred tax assets and liabilities at September 30, 2019 and 2018 are presented below:

[0001104659-19-068679:notes:136]
| (Dollars in thousands) |  | 2019 |  | 2018 |
| Deferred tax assets: |  | ​ |  |  |  |
| Inventories | ​ | $ | 5,089 |  | 5,834 |
| Pension and other postretirement benefits | ​ |  | 5,533 |  | 3,969 |
| Net operating and capital loss carryforwards — domestic | ​ |  | 617 |  | 639 |
| Net operating loss carryforward — foreign | ​ |  | 3,766 |  | 4,603 |
| Foreign tax credit carryforward | ​ |  | — |  | 2,377 |
| Other compensation-related costs and other cost accruals | ​ |  | 7,952 |  | 7,048 |
| State credit carryforward | ​ |  | 1,914 |  | 2,103 |
| Total deferred tax assets | ​ |  | 24,871 |  | 26,573 |
| Deferred tax liabilities: | ​ |  | ​ |  |  |
| Timing differences related to revenue recognition | ​ | ​ | (1,508) | ​ | — |
| Goodwill | ​ |  | (2,673) |  | (969) |
| Acquisition assets | ​ |  | (60,224) |  | (62,841) |
| Depreciation, software amortization | ​ |  | (20,161) |  | (19,584) |
| Net deferred tax liabilities before valuation allowance | ​ |  | (59,695) |  | (56,821) |
| Less valuation allowance | ​ |  | (4,520) |  | (7,144) |
| Net deferred tax liabilities | ​ | $ | (64,215) |  | (63,965) |

[0001104659-19-068679:notes:137]
The Company has a foreign net operating loss (NOL) carryforward of $16.6 million at September 30, 2019, which reflects tax loss carryforwards in Germany, Finland, South Africa, Japan, Canada, Norway and the United Kingdom. Approximately $16.0 million of the tax loss carryforwards have no expiration date while the remaining $0.6 million will expire between 2027 and 2039. The Company has deferred tax assets related to state NOL carryforwards of $0.6 million at September 30, 2019 which expire between 2027 and 2039. The Company also has net state research and other credit carryforwards of $1.9 million of which $1.4 million expires between 2025 and 2037. The remaining $0.5 million does not have an expiration date.

[0001104659-19-068679:notes:138]
The valuation allowance for deferred tax assets as of September 30, 2019 and 2018 was $4.5 million and $7.1 million, respectively. The net change in the total valuation allowance for each of the years ended September 30, 2019 and 2018 was a decrease of $2.6 million and an increase of $2.7 million, respectively. The Company has established a valuation allowance for excess foreign tax credits that are not expected to be utilized in future periods of $0 and $2.4 million at September 30, 2019 and 2018, respectively. The Company has established a valuation allowance against state credit carryforwards of $0.4 million at both September 30, 2019 and 2018. In addition, the Company has established a valuation allowance against state NOL carryforwards that are not expected to be realized in future periods of $0.6 million at both September 30, 2019 and 2018. Lastly, the Company has established a valuation allowance against certain NOL carryforwards in foreign jurisdictions which may not be realized in future periods of $3.6 million and $3.8 million at September 30, 2019 and 2018, respectively.

[0001104659-19-068679:notes:139]
On December 22, 2017, the U.S. government enacted the Tax Cuts and Jobs Act, which made comprehensive changes to U.S. federal income tax laws by moving from a global to a modified territorial tax regime. As a result, cash repatriated to the U.S. is generally no longer subject to U.S. federal income tax. No provision is made for foreign withholding any applicable U.S. income taxes on the undistributed earnings of non-U.S. where these earnings are considered indefinitely invested or otherwise retained for continuing international operations. Determination of the amount of taxes that might be paid on these undistributed earnings if eventually remitted is not practicable.

[0001104659-19-068679:notes:140]
The Company had $0 and $0.1 million of unrecognized tax benefits as of September 30, 2019 and 2018, respectively, which, if recognized, would affect the Company’s effective tax rate. The Company’s policy is to include interest related to unrecognized tax benefits in income tax expense and penalties in operating expense. As of September 30, 2019, 2018 and 2017, the Company had zero accrued interest related to uncertain tax positions on its Consolidated Balance Sheets. No penalties have been accrued.

[0001104659-19-068679:notes:141]
The principal jurisdictions for which the Company files income tax returns are U.S. Federal and the various city, state, and international locations where the Company has operations. The U.S. Federal tax years for the periods ended September 30, 2016 and forward remain subject to income tax examination. Various state tax years for the periods ended September 30, 2015 and forward remain subject to income tax examinations. The Company is subject to income tax in many jurisdictions outside the United States, none of which is individually significant.


## us-gaap:DebtDisclosureTextBlock

[0001104659-19-068679:notes:142]
8.      Debt

[0001104659-19-068679:notes:143]
Debt consists of the following at September 30, 2019 and 2018:

[0001104659-19-068679:notes:144]
| (Dollars in thousands) |  | 2019 |  | 2018 |
| Revolving credit facility, including current portion | ​ | $ | 286,261 |  | 220,000 |
| Current portion of long-term debt | ​ |  | (21,261) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 265,000 |  | 200,000 |

[0001104659-19-068679:notes:145]
On September 27, 2019, the Company entered into a new five-year credit facility (“the Credit Facility"), modifying its previous credit facility which would have matured December 21, 2020. The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024.

[0001104659-19-068679:notes:146]
Interest on borrowings under the Credit Facility is calculated at a spread over either the London Interbank Offered Rate (LIBOR), the New York Federal Reserve Bank Rate or the prime rate, depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The interest rate spreads and the facility fee are subject to increase or decrease depending on the Company's leverage ratio.

[0001104659-19-068679:notes:147]
The Credit Facility is secured by the unlimited guaranty of the Company's direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of its direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. As of September 30, 2019, the Company was in compliance with all covenants.

[0001104659-19-068679:notes:148]
At September 30, 2019, the Company had approximately $207 million available to borrow under the Credit Facility, plus the $250 million increase option, in addition to $61.8 million cash on hand. The Company classified $21.3 million as the current portion of long-term debt as of September 30, 2019, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months.

[0001104659-19-068679:notes:149]
During 2019 and 2018, the maximum aggregate short-term borrowings at any month-end were $308 million and $271 million, respectively, and the average aggregate short-term borrowings outstanding based on month-end balances were $236.4 million and $258.8 million, respectively. The weighted average interest rates were 3.21%, 3.03% and 2.09% for 2019, 2018 and 2017, respectively. The letters of credit issued and outstanding under the Credit Facility totaled $8.2 million and $7.8 million at September 30, 2019 and 2018, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001104659-19-068679:notes:150]
9.      Capital Stock

[0001104659-19-068679:notes:151]
The 30,596,940 and 30,534,786 common shares as presented in the accompanying Consolidated Balance Sheets at September 30, 2019 and 2018 represent the actual number of shares issued at the respective dates. The Company held 4,615,627 and 4,623,958 common shares in treasury at September 30, 2019 and 2018, respectively.

[0001104659-19-068679:notes:152]
In August 2012, the Company’s Board of Directors authorized a common stock repurchase program under which the Company may repurchase shares of its stock from time to time in its discretion, in the open market or otherwise, up to a maximum total repurchase amount of $100 million (or such lesser amount as may be permitted under the Company’s bank credit agreements). This program has been repeatedly extended by the Company’s Board of Directors and is currently scheduled to expire September 30, 2021. There were no share repurchases in 2019, 2018 or 2017. At September 30, 2019, approximately $50.4 million remained available for repurchases under the program.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001104659-19-068679:notes:153]
10.      Share-Based Compensation

[0001104659-19-068679:notes:154]
The Company provides compensation benefits to certain key employees under several share-based plans providing for performance-accelerated restricted share unit (PARS) awards, and to non-employee directors under a non-employee directors compensation plan. The Company has no stock options currently outstanding. As of September 30, 2019, the Company's equity compensation plans had a total of 844,029 shares authorized and available for future issuance.

[0001104659-19-068679:notes:155]
Performance-Accelerated Restricted Share Unit (PARS) Awards

[0001104659-19-068679:notes:156]
A PARS award represents the right to receive a specified number of shares of Company common stock if and when the award vests. A PARS award is not stock and does not give the recipient any rights as a shareholder until it vests and is paid out in shares of stock. PARS awards currently outstanding have a five-year vesting period, with accelerated vesting if certain targets based on market conditions are achieved. In these cases, if it is probable that the performance condition will be met, the Company recognizes compensation cost on a straight-line basis over the shorter performance period; otherwise, it will recognize compensation cost over the longer service period. Compensation cost for the outstanding PARS awards is being recognized over the shorter performance period, as it is probable the performance condition will be met. The PARS award grants were valued at the stock price on the date of grant. Pretax compensation expense related to the PARS awards for continuing operations was $4.3 million, $4.1 million and $4.4 million for 2019, 2018 and 2017, respectively.

[0001104659-19-068679:notes:157]
The following summary presents information regarding outstanding PARS awards as of the specified dates, and changes during the specified periods:

[0001104659-19-068679:notes:158]
| ​ | ​ | FY 2019 | ​ | FY 2018 | ​ | FY 2017 |
| ​ |  | ​ |  | Estimated |  | ​ |  | Estimated |  | ​ |  | Estimated |
| ​ | ​ | ​ | ​ | Weighted | ​ | ​ | ​ | Weighted | ​ | ​ | ​ | Weighted |
| ​ | ​ | Shares | ​ | Avg. Price | ​ | Shares | ​ | Avg. Price | ​ | Shares | ​ | Avg. Price |
| Nonvested at October 1, |  | 315,544 | ​ | $ | 47.23 |  | 335,825 | ​ | $ | 40.35 |  | 427,438 | ​ | $ | 35.40 |
| Granted |  | 84,862 | ​ |  | 74.77 |  | 104,320 | ​ |  | 56.06 |  | 110,422 | ​ |  | 51.16 |
| Vested |  | (113,402) | ​ |  | 37.00 |  | (121,301) | ​ |  | 35.59 |  | (202,035) | ​ |  | 35.78 |
| Cancelled |  | (6,000) | ​ |  | 45.20 |  | (3,300) | ​ |  | 53.86 |  | — | ​ |  | — |
| Nonvested at September 30, |  | 281,004 | ​ | $ | 59.72 |  | 315,544 | ​ | $ | 47.23 |  | 335,825 | ​ | $ | 40.35 |

[0001104659-19-068679:notes:159]
Compensation Plan for Non-Employee Directors

[0001104659-19-068679:notes:160]
Through the first quarter of 2018 the Company's Compensation Plan for Non-Employee Directors provided to each non-employee director a retainer of 900 common shares per quarter. Beginning in the second quarter of 2018, the quarterly retainer was replaced by an annual retainer of Company stock having a grant date market value of $180,000. Non-employee director grants were valued at the NYSE closing price of the Company’s stock on the date of grant and were issued from the Company’s treasury stock. Compensation expense related to the non-employee director grants was $1.1 million, $1.1 million and $1.0 million for 2019, 2018 and 2017, respectively.

[0001104659-19-068679:notes:161]
Total Share-Based Compensation

[0001104659-19-068679:notes:162]
The total share-based compensation cost that has been recognized in results of operations and included within SG&A from continuing operations was $5.4 million, $5.2 million and $5.4 million for 2019, 2018 and 2017, respectively. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $1.1 million, $1.3 million and $1.8 million for 2019, 2018 and 2017, respectively. As of September 30, 2019, there was $9.6 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a weighted-average period of 2.0 years.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001104659-19-068679:notes:163]
11.      Retirement and Other Benefit Plans

[0001104659-19-068679:notes:164]
Formerly, substantially all domestic employees were covered by a defined benefit pension plan maintained by the Company. Effective December 31, 2003, the Company’s defined benefit plan was frozen and no additional benefits have been accrued after that date. As a result, the accumulated benefit obligation and projected benefit obligation are equal. These frozen retirement income benefits are provided to employees under defined benefit pay-related and flat-dollar plans, which are noncontributory. The annual contributions to the defined benefit retirement plan equal or exceed the minimum funding requirements of the Employee Retirement Income Security Act. Subsequent to September 30, 2019, the Company announced that it plans to terminate and annuitize the defined benefit pension plan during fiscal 2020. In addition to providing retirement income benefits, the Company provides unfunded postretirement health and life insurance benefits to certain retirees. To qualify, an employee must retire at age 55 or later and the employee’s age plus service must equal or exceed 75. Retiree contributions are defined as a percentage of medical premiums. Consequently, retiree contributions increase with increases in the medical premiums. The life insurance plans are noncontributory and provide coverage of a flat dollar amount for qualifying retired employees. Effective December 31, 2004, no new retirees were eligible for life insurance benefits. In addition, substantially all domestic employees are covered by a defined contribution plan maintained by the Company.

[0001104659-19-068679:notes:165]
The Company uses a measurement date of September 30 for its pension and other postretirement benefit plans. The Company has an accrued benefit liability of $0.6 million and $0.5 million at September 30, 2019 and 2018, respectively, related to its other postretirement benefit obligations. All other information related to its postretirement benefit plans is not considered material to the Company’s results of operations or financial condition.

[0001104659-19-068679:notes:166]
The following tables provide a reconciliation of the changes in the pension plans and fair value of assets over the two-year period ended September 30, 2019, and a statement of the funded status as of September 30, 2019 and 2018:

[0001104659-19-068679:notes:167]
| (Dollars in millions) | ​ | ​ | ​ | ​ |  |
| Reconciliation of benefit obligation |  | 2019 |  | 2018 |
| Net benefit obligation at beginning of year | ​ | $ | 89.8 |  | 95.3 |
| Interest cost | ​ |  | 3.7 |  | 3.4 |
| Actuarial loss (gain) | ​ |  | 11.3 |  | (4.3) |
| Gross benefits paid | ​ |  | (4.7) |  | (4.6) |
| Settlements | ​ |  | — |  | — |
| Net benefit obligation at end of year | ​ | $ | 100.1 |  | 89.8 |

[0001104659-19-068679:notes:168]
| (Dollars in millions) |  |  | ​ |  |  |
| Reconciliation of fair value of plan assets | ​ | 2019 | ​ | 2018 |
| Fair value of plan assets at beginning of year | ​ | $ | 73.3 |  | 65.0 |
| Actual return on plan assets | ​ |  | 5.9 |  | 2.7 |
| Employer contributions | ​ |  | 2.7 |  | 10.2 |
| Gross benefits paid | ​ |  | (4.7) |  | (4.6) |
| Settlements | ​ |  | — |  | — |
| Fair value of plan assets at end of year | ​ | $ | 77.2 |  | 73.3 |

[0001104659-19-068679:notes:169]
| (Dollars in millions) |  |  | ​ |  |  |
| Funded Status | ​ | 2019 | ​ | 2018 |
| Funded status at end of year | ​ | $ | (22.9) |  | (16.5) |
| Accrued benefit cost | ​ |  | (22.9) |  | (16.5) |
| Amounts recognized in the Balance Sheet consist of: | ​ |  | ​ |  |  |
| Current liability | ​ |  | (0.2) |  | (0.2) |
| Noncurrent liability | ​ |  | (22.7) |  | (16.3) |
| Accumulated other comprehensive (income)/loss (before tax effect) | ​ |  | 49.6 |  | 41.9 |
| Amounts recognized in accumulated other comprehensive (income)/loss consist of: | ​ |  | ​ |  |  |
| Net actuarial loss | ​ |  | 49.6 |  | 41.9 |
| Accumulated other comprehensive (income)/loss (before tax effect) | ​ | $ | 49.6 |  | 41.9 |

[0001104659-19-068679:notes:170]
The estimated amount that will be amortized from accumulated other comprehensive (income) loss into net periodic benefit cost (income) in 2020 is $2.7 million.

[0001104659-19-068679:notes:171]
The following table provides the components of net periodic benefit cost for the plans for 2019, 2018 and 2017:

[0001104659-19-068679:notes:172]
| (Dollars in millions) |  | 2019 |  | 2018 |  | 2017 |
| Service cost | ​ | $ | — |  | — |  | — |
| Interest cost | ​ |  | 3.7 |  | 3.4 |  | 3.2 |
| Expected return on plan assets | ​ |  | (4.4) |  | (3.8) |  | (3.9) |
| Net actuarial loss | ​ |  | 2.1 |  | 2.3 |  | 2.6 |
| Net periodic benefit cost | ​ |  | 1.4 |  | 1.9 |  | 1.9 |
| Defined contribution plans | ​ |  | 7.3 |  | 7.1 |  | 6.3 |
| Total | ​ | $ | 8.7 |  | 9.0 |  | 8.2 |

[0001104659-19-068679:notes:173]
The discount rate used in measuring the Company’s pension obligations was developed by matching yields of actual high-quality corporate bonds to expected future pension plan cash flows (benefit payments). Over 400 Aa-rated, non-callable bonds with a wide range of maturities were used in the analysis. After using the bond yields to determine the present value of the plan cash flows, a single representative rate that resulted in the same present value was developed. The expected long-term rate of return on plan assets assumption was determined by reviewing the actual investment return of the plans since inception and evaluating those returns in relation to expectations of various investment organizations to determine whether long-term future returns are expected to differ significantly from the past.

[0001104659-19-068679:notes:174]
The following weighted-average assumptions were used to determine the net periodic benefit cost for the pension plans:

[0001104659-19-068679:notes:175]
| ​ |  | 2019 |  | 2018 |  | 2017 |  |
| Discount rate |  | 4.15 | % | 3.65 | % | 3.25 | % |
| Rate of increase in compensation levels |  | N/A |  | N/A |  | N/A | ​ |
| Expected long-term rate of return on assets |  | 6.00 | % | 6.00 | % | 6.25 | % |

[0001104659-19-068679:notes:176]
The following weighted-average assumptions were used to determine the net periodic benefit obligations for the pension plans:

[0001104659-19-068679:notes:177]
| ​ |  | 2019 |  | 2018 |  |
| Discount rate |  | 3.05 | % | 4.15 | % |
| Rate of increase in compensation levels |  | N/A |  | N/A | ​ |

[0001104659-19-068679:notes:178]
The assumed rate of increase in compensation levels is not applicable in 2019, 2018 and 2017 as the plan was frozen in earlier years.

[0001104659-19-068679:notes:179]
The asset allocation for the Company’s pension plans at the end of 2019 and 2018, and the Company’s acceptable range and the target allocation for 2020, by asset category, are as follows:

[0001104659-19-068679:notes:180]
| ​ |  | Target |  | ​ |  | Percentage of Plan Assets at |  |
| ​ | ​ | Allocation | ​ | Acceptable | ​ | Year-end |  |
| Asset Category | ​ | 2020 | ​ | Range | ​ | 2019 | ​ | 2018 |  |
| Return seeking |  | 53 | % | 48%-58 | % | 41 | % | 44 | % |
| Liability hedging |  | 47 | % | 42%-52 | % | 56 | % | 54 | % |
| Cash/cash equivalents |  | 0 | % | 0%-10 | % | 3 | % | 2 | % |

[0001104659-19-068679:notes:181]
The Company’s pension plan assets are managed by outside investment managers and assets are rebalanced when the target ranges are exceeded. Pension plan assets consist principally of funds which invest in marketable securities including common stocks, bonds, and interest-bearing deposits. The Company’s investment strategy with respect to pension assets is to achieve a total rate of return (income and capital appreciation) that is sufficient to accomplish the purpose of providing retirement benefits to all eligible and future retirees of the pension plan. The Company regularly monitors performance and compliance with investment guidelines.

[0001104659-19-068679:notes:182]
Fair Value of Financial Measurements

[0001104659-19-068679:notes:183]
The fair values of the Company’s defined benefit plan investments as of September 30, 2019 and 2018, by asset category, were as follows:

[0001104659-19-068679:notes:184]
| (Dollars in millions) |  | 2019 |  | 2018 |
| Investments at fair value: |  | ​ |  |  |  |
| Cash and cash equivalents | ​ | $ | 2.1 |  | 2.1 |
| Common and preferred stock funds: | ​ |  |  |  |  |
| Domestic large capitalization | ​ |  | 8.8 |  | 8.7 |
| Domestic small-/mid-capitalization | ​ |  | 2.4 |  | 2.7 |
| International funds | ​ |  | 10.6 |  | 10.8 |
| Fixed income funds | ​ |  | 49.7 |  | 45.6 |
| Real estate investment funds | ​ |  | 3.6 |  | 3.4 |
| Total investments at fair value | ​ | $ | 77.2 |  | 73.3 |

[0001104659-19-068679:notes:185]
The following methods were used to estimate the fair value of each class of financial instrument:

[0001104659-19-068679:notes:186]
Cash and cash equivalents: The carrying value of cash represents fair value as it consists of actual currency.

[0001104659-19-068679:notes:187]
Investment Funds: The fair value of the investment funds, which offer daily redemptions, is determined based on the published net asset value of the funds as a practical expedient for fair value.

[0001104659-19-068679:notes:188]
As of September 30, 2019, the fair values of the investments were classified within the valuation hierarchy under ASC 825 as follows: $44.9 million within Level 0, $13.0 million within Level 1 and $19.3 million within Level 2.

[0001104659-19-068679:notes:189]
Expected Cash Flows

[0001104659-19-068679:notes:190]
Information about the expected cash flows for the pension and other postretirement benefit plans follows:

[0001104659-19-068679:notes:191]
| ​ |  | Pension |  | Other |
| (Dollars in millions) | ​ | Benefits | ​ | Benefits |
| Expected Employer Contributions — 2020 | ​ | $ | 0.7 |  | 0.1 |
| Expected Benefit Payments: | ​ |  |  |  |  |
| 2020 | ​ |  | 5.8 |  | 0.1 |
| 2021 | ​ |  | 5.5 |  | 0.1 |
| 2022 | ​ |  | 5.7 |  | 0.1 |
| 2023 | ​ |  | 5.8 |  | 0.1 |
| 2024 | ​ | ​ | 5.9 | ​ | 0.1 |
| 2025‑2029 | ​ | $ | 30.2 |  | 0.2 |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001104659-19-068679:notes:192]
12.      Derivative Financial Instruments

[0001104659-19-068679:notes:193]
Market risks relating to the Company’s operations result primarily from changes in interest rates and changes in foreign currency exchange rates. The Company is exposed to market risk related to changes in interest rates and selectively uses derivative financial instruments, including forward contracts and swaps, to manage these risks. In 2018, the Company entered into three interest rate swaps with a notional amount of $150 million to hedge its exposure to variability in future LIBOR-based interest payments on variable rate debt. In addition, the Company’s Canadian subsidiary Morgan Schaffer enters into foreign exchange contracts to manage foreign currency risk as a portion of their revenue is denominated in U.S. dollars. The Company expects hedging gains or losses to be essentially offset by losses or gains on the related underlying exposures. The amounts ultimately recognized may differ for open positions, which remain subject to ongoing market price fluctuations until settlement. All derivative instruments are reported in either accrued expenses or other assets on the balance sheet at fair value. For derivative instruments designated as cash flow hedges, the gain or loss on the derivative is deferred in accumulated other comprehensive income until recognized in earnings with the underlying hedged item. The interest rate swaps entered into during 2018 were not designated as cash flow hedges and, therefore, the gain or loss on the derivative is reflected in earnings each period. The following is a summary of the notional transaction amounts and fair values for the Company’s outstanding derivative financial instruments as of September 30, 2019.

[0001104659-19-068679:notes:194]
| ​ | ​ | Notional Amount | ​ | Fair Value | ​ | ​ |  |
| (In thousands) |  | (Currency) |  | (US$) |  | Fix Rate |  |
| Forward contracts |  | 5,750 | USD | (35) |  |  | ​ |
| Interest rate swap |  | 150,000 | USD | (19) |  | 2.09 | % |
| Interest rate swap * |  | 150,000 | USD | (1,143) |  | 2.24 | % |

[0001104659-19-068679:notes:195]
*      This swap represents a forward contract and will be effective in November 2019.

[0001104659-19-068679:notes:196]
Fair Value of Financial Instruments

[0001104659-19-068679:notes:197]
The Company’s forward contracts are classified within Level 2 of the valuation hierarchy in accordance with ASC 825, as presented below as of September 30, 2019:

[0001104659-19-068679:notes:198]
| (In thousands) |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Asset: |  | ​ |  |  |  |  |  |  |  |
| Forward contracts | ​ | $ | — |  | (1,197) |  | — |  | (1,197) |

[0001104659-19-068679:notes:199]
Valuation was based on third party evidence of similarly priced derivative instruments. There are no master netting arrangements with financial parties.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001104659-19-068679:notes:200]
13.      Business Segment Information

[0001104659-19-068679:notes:201]
The Company is organized based on the products and services it offers, and classifies its business operations in four reportable segments for financial reporting purposes: Filtration/Fluid Flow (Filtration), Utility Solutions Group (USG), RF Shielding and Test (Test) and Technical Packaging.

[0001104659-19-068679:notes:202]
The Filtration segment’s operations consist of PTI Technologies Inc. (PTI), VACCO Industries (VACCO), Crissair, Inc. (Crissair), Mayday Manufacturing Co. (Mayday), Hi-Tech Metals, Inc. (Hi-Tech), Westland Technologies, Inc. (Westland), and Globe Composite Solutions, LLC (Globe). PTI, VACCO and Crissair design and manufacture specialty filtration products, including hydraulic filter elements and fluid control devices used in commercial aerospace applications, unique filter mechanisms used in micro-propulsion devices for satellites and custom designed filters for manned aircraft and submarines. Mayday designs and manufactures mission-critical bushings, pins, sleeves and precision-tolerance machined components for landing gear, rotor heads, engine mounts, flight controls, and actuation systems for the aerospace and defense industries. Hi-Tech is a full-service metal processor offering aerospace OEM’s and Tier 1 suppliers, a large portfolio of processing services including anodizing, cadmium and zinc-nickel plating, organic coatings, non-destructive testing, and heat treatment. Westland designs, develops and manufactures elastomeric-based signature reduction solutions for U.S. naval vessels.

[0001104659-19-068679:notes:203]
Globe supplies navy, defense, and industrial customers with mission-critical composite-based products and solutions for acoustic, signature-reduction, communications, sealing, vibration-reducing, surface control, and hydrodynamic-related applications.

[0001104659-19-068679:notes:204]
The USG segment’s operations consist of Doble Engineering Company and related subsidiaries (Doble), Morgan Schaffer Ltd. (Morgan Schaffer), and NRG Systems, Inc. (NRG). Doble provides high-end, intelligent diagnostic test solutions for the electric power delivery industry and is a leading supplier of power factor and partial discharge testing instruments used to assess the integrity of high-voltage power delivery equipment. Morgan Schaffer provides an integrated offering of dissolved gas analysis, oil testing, and data management solutions which enhance the ability of electric utilities to accurately monitor the health of critical power transformers. NRG designs and manufactures decision support tools for the renewable energy industry, primarily wind.

[0001104659-19-068679:notes:205]
The Test segment's operations consist of ETS-Lindgren Inc. and related subsidiaries (ETS-Lindgren). ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy. ETS-Lindgren also manufactures radio frequency shielding products and components used by manufacturers of medical equipment, communications systems, electronic products, and shielded rooms for high-security data processing and secure communication.

[0001104659-19-068679:notes:206]
The Technical Packaging segment’s operations consist of Thermoform Engineered Quality LLC (TEQ), Plastique Limited and Plastique sp. z o.o. The companies within this segment provide innovative solutions to the medical and commercial markets for thermoformed and precision molded pulp fiber packages and specialty products using a wide variety of thin gauge plastics and pulp.

[0001104659-19-068679:notes:207]
Accounting policies of the segments are the same as those described in the summary of significant accounting policies in Note 1 to the Consolidated Financial Statements. The operating units within each reporting segment have been aggregated because of similar economic characteristics and meet the other aggregation criteria of FASB ASC 280.

[0001104659-19-068679:notes:208]
The Company evaluates the performance of its operating units based on EBIT, which is defined as earnings before interest and taxes. EBIT on a consolidated basis is a non-GAAP financial measure; see “Non-GAAP Financial Measures” in Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations.” Intersegment sales and transfers are not significant. Segment assets consist primarily of customer receivables, inventories, capitalized software and fixed assets directly associated with the production processes of the segment. Segment depreciation and amortization is based upon the direct assets listed above.

[0001104659-19-068679:notes:209]
Net Sales

[0001104659-19-068679:notes:210]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2019 |  | 2018 |  | 2017 |
| Filtration | ​ | $ | 325.8 |  | 286.8 |  | 279.5 |
| USG | ​ | ​ | 211.9 | ​ | 214.0 | ​ | 162.4 |
| Test | ​ |  | 188.4 |  | 182.9 |  | 160.9 |
| USG | ​ |  | — |  | ​ | ​ | ​ |
| Technical Packaging | ​ |  | 86.9 |  | 87.9 |  | 82.9 |
| Consolidated totals | ​ | $ | 813.0 |  | 771.6 |  | 685.7 |

[0001104659-19-068679:notes:211]
No customer exceeded 10% of sales in 2019 or 2018.

[0001104659-19-068679:notes:212]
EBIT

[0001104659-19-068679:notes:213]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2019 |  | 2018 |  | 2017 |
| Filtration | ​ | $ | 70.1 |  | 58.7 |  | 52.2 |
| USG | ​ | ​ | 52.2 | ​ | 43.2 | ​ | 36.6 |
| Test | ​ |  | 25.6 |  | 23.8 |  | 19.5 |
| USG | ​ |  | — |  | ​ | ​ | ​ |
| Technical Packaging | ​ |  | 5.9 |  | 8.1 |  | 8.5 |
| Reconciliation to consolidated totals (Corporate) | ​ |  | (43.2) |  | (37.0) |  | (32.1) |
| Consolidated EBIT | ​ |  | 110.6 |  | 96.8 |  | 84.7 |
| Less: interest expense | ​ |  | (8.4) |  | (8.8) |  | (4.6) |
| Earnings before income tax | ​ | $ | 102.2 |  | 88.0 |  | 80.1 |

[0001104659-19-068679:notes:214]
Identifiable Assets

[0001104659-19-068679:notes:215]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ |  | ​ |
| Year ended September 30, |  | 2019 |  | 2018 | ​ | ​ |
| Filtration | ​ | $ | 260.3 |  | 204.7 | ​ | ​ |
| USG | ​ | ​ | 190.0 | ​ | 176.9 | ​ | ​ |
| Test | ​ |  | 154.2 |  | 138.3 | ​ | ​ |
| USG | ​ |  | — |  | ​ | ​ | ​ |
| Technical Packaging | ​ |  | 59.1 |  | 50.9 | ​ | ​ |
| Corporate – Goodwill | ​ |  | 409.2 |  | 381.7 | ​ | ​ |
| Corporate – Other assets | ​ |  | 393.9 |  | 312.6 | ​ | ​ |
| Consolidated totals | ​ | $ | 1,466.7 |  | 1,265.1 | ​ | ​ |

[0001104659-19-068679:notes:216]
Corporate assets consist primarily of goodwill, deferred taxes, acquired intangible assets and cash balances.

[0001104659-19-068679:notes:217]
Capital Expenditures

[0001104659-19-068679:notes:218]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2019 |  | 2018 |  | 2017 |
| Filtration | ​ | $ | 11.7 |  | 7.0 |  | 10.2 |
| USG | ​ | ​ | 8.5 | ​ | 5.2 | ​ | 7.6 |
| Test | ​ |  | 4.0 |  | 3.0 |  | 4.5 |
| USG | ​ |  | — |  | ​ | ​ | ​ |
| Technical Packaging | ​ |  | 13.0 |  | 5.4 |  | 7.4 |
| Corporate | ​ |  | — |  | — |  | — |
| Consolidated totals | ​ | $ | 37.2 |  | 20.6 |  | 29.7 |

[0001104659-19-068679:notes:219]
In addition to the above amounts, the Company incurred expenditures for capitalized software of $8.4 million, $9.5 million and $9.0 million in 2019, 2018 and 2017, respectively.

[0001104659-19-068679:notes:220]
Depreciation and Amortization

[0001104659-19-068679:notes:221]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2019 |  | 2018 |  | 2017 |
| Filtration | ​ | $ | 8.3 |  | 7.6 |  | 6.6 |
| USG | ​ | ​ | 11.3 | ​ | 11.0 | ​ | 9.8 |
| Test | ​ |  | 5.1 |  | 4.5 |  | 3.6 |
| USG | ​ |  | — |  | ​ |  | ​ |
| Technical Packaging | ​ |  | 4.1 |  | 4.1 |  | 3.5 |
| Corporate | ​ |  | 11.3 |  | 10.6 |  | 8.7 |
| Consolidated totals | ​ | $ | 40.1 |  | 37.8 |  | 32.2 |

[0001104659-19-068679:notes:222]
Depreciation expense of property, plant and equipment was $20.6 million, $19.4 million and $15.9 million for 2019, 2018 and 2017, respectively.

[0001104659-19-068679:notes:223]
Geographic Information

[0001104659-19-068679:notes:224]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2019 |  | 2018 |  | 2017 |
| United States | ​ | $ | 583.0 |  | 536.7 |  | 503.1 |
| Asia | ​ |  | 88.3 |  | 94.5 |  | 69.8 |
| Europe | ​ |  | 82.8 |  | 85.0 |  | 75.4 |
| Canada | ​ |  | 33.2 |  | 30.3 |  | 22.2 |
| India | ​ |  | 11.7 |  | 9.4 |  | 4.8 |
| Other | ​ |  | 14.0 |  | 15.7 |  | 10.4 |
| Consolidated totals | ​ | $ | 813.0 |  | 771.6 |  | 685.7 |

[0001104659-19-068679:notes:225]
Long-Lived Assets

[0001104659-19-068679:notes:226]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ |  | ​ |
| Year ended September 30, |  | 2019 |  | 2018 |  | ​ |
| United States | ​ | $ | 140.0 |  | 113.2 | ​ | ​ |
| Europe | ​ |  | 16.6 |  | 17.1 | ​ | ​ |
| Other | ​ |  | 4.9 |  | 4.7 | ​ | ​ |
| Consolidated totals | ​ | $ | 161.5 |  | 135.0 | ​ | ​ |

[0001104659-19-068679:notes:227]
Net sales are attributed to countries based on location of customer. Long-lived assets are attributed to countries based on location of the asset.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001104659-19-068679:notes:228]
14.      Commitments and Contingencies

[0001104659-19-068679:notes:229]
The Company leases certain real property, equipment and machinery under non-cancelable operating leases. Rental expense under these operating leases was $6.4 million, $6.9 million and $6.8 million for 2019, 2018 and 2017, respectively. Future aggregate minimum lease payments under operating leases that have initial or remaining non-cancelable lease terms in excess of one year as of September 30, 2019, are:

[0001104659-19-068679:notes:230]
| (Dollars in thousands) | ​ | ​ | ​ |
| Years ending September 30: |  |  | ​ |
| 2020 | ​ | $ | 6,405 |
| 2021 | ​ |  | 5,279 |
| 2022 | ​ |  | 4,592 |
| 2023 | ​ |  | 3,567 |
| 2024 and thereafter | ​ |  | 10,197 |
| Total | ​ | $ | 30,040 |

[0001104659-19-068679:notes:231]
At September 30, 2019, the Company had $8.2 million in letters of credit outstanding as guarantees of contract performance. As a normal incident of the businesses in which the Company is engaged, various claims, charges and litigation are asserted or commenced from time to time against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. It is the opinion of Management that the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company are adequately accrued, are covered by insurance or are not likely to have a material adverse effect on the Company’s results from continuing operations, capital expenditures or competitive position.


## us-gaap:CapitalLeasesInFinancialStatementsOfLesseeDisclosureTextBlock

[0001104659-19-068679:notes:232]
15.      Capital Leases

[0001104659-19-068679:notes:233]
The Company leases certain real property, equipment and machinery under capital leases, primarily associated with the new Doble building in Marlborough, Massachusetts and the 2017 acquisitions of NRG and Mayday. The Doble facility lease expires in 2036, the NRG and Mayday facility leases expire in 2029, and the machinery leases expire in 2020. As of September 30, 2019, the net carrying value and accumulated depreciation of the assets under capital leases recorded by the Company were $28.4 million and $3.5 million, respectively. Capital lease obligations are included within other long-term liabilities (long-term portion) and accrued other expenses (current portion). Remaining payments due on the Company’s capital lease obligations as of September 30, 2019, are:

[0001104659-19-068679:notes:234]
| (Dollars in thousands) | ​ | ​ | ​ |
| Years ending September 30: |  |  | ​ |
| 2020 | ​ | $ | 2,518 |
| 2021 | ​ |  | 2,930 |
| 2022 | ​ |  | 3,012 |
| 2023 | ​ |  | 3,094 |
| 2024 and thereafter | ​ |  | 31,499 |
| Total minimum lease payments | ​ |  | 43,053 |
| Less: amounts representing interest | ​ |  | 11,241 |
| Present value of net minimum lease payments | ​ |  | 31,812 |
| Current portion of capital lease obligations | ​ |  | 1,832 |
| Non-current portion of capital lease obligations | ​ | $ | 29,980 |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001104659-19-068679:notes:235]
16.     Revenues

[0001104659-19-068679:notes:236]
| (a) | Disaggregation of Revenues |

[0001104659-19-068679:notes:237]
Our revenues by customer type, geographic location, and revenue recognition method for the year ended September 30, 2019 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within our reportable segments.

[0001104659-19-068679:notes:238]
| Year Ended September 30, 2019 | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ | Technical | ​ |  |
| (In thousands) |  | Filtration |  | USG |  | Test |  | Packaging |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 180,356 | ​ | $ | 207,666 | ​ | $ | 168,201 | ​ | $ | 86,599 | ​ | $ | 642,822 |
| Government | ​ |  | 145,379 | ​ |  | 4,249 | ​ |  | 20,193 | ​ |  | 327 | ​ |  | 170,148 |
| Total revenues | ​ | $ | 325,735 | ​ | $ | 211,915 | ​ | $ | 188,394 | ​ | $ | 86,926 | ​ | $ | 812,970 |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| United States | ​ | $ | 274,446 | ​ | $ | 150,381 | ​ | $ | 112,358 | ​ | $ | 45,787 | ​ | $ | 582,972 |
| International | ​ |  | 51,289 | ​ |  | 61,534 | ​ |  | 76,036 | ​ |  | 41,139 | ​ |  | 229,998 |
| Total revenues | ​ | $ | 325,735 | ​ | $ | 211,915 | ​ | $ | 188,394 | ​ | $ | 86,926 | ​ | $ | 812,970 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 164,224 | ​ | $ | 164,126 | ​ | $ | 36,787 | ​ | $ | — | ​ | $ | 365,137 |
| Over time | ​ |  | 161,511 | ​ |  | 47,789 | ​ |  | 151,607 | ​ |  | 86,926 | ​ |  | 447,833 |
| Total revenues | ​ | $ | 325,735 | ​ | $ | 211,915 | ​ | $ | 188,394 | ​ | $ | 86,926 | ​ | $ | 812,970 |

[0001104659-19-068679:notes:239]
| (b) | Remaining Performance Obligations |

[0001104659-19-068679:notes:240]
Our remaining performance obligations, which is the equivalent of our backlog, represent the expected transaction price allocated to our contracts that we expect to recognize as revenue in future periods when we perform under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At September 30, 2019, we had $475 million in remaining performance obligations of which we expect to recognize revenues of 90% in the next twelve months.

[0001104659-19-068679:notes:241]
| (c) | Contract assets and liabilities |

[0001104659-19-068679:notes:242]
Assets and liabilities related to our contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At September 30, 2019, contract assets and liabilities totaled $115.3 million and $81.2 million, respectively. Upon adoption of ASC 606 on October 1, 2018, contract assets and liabilities related to our contracts with customers were $87 million and $51 million, respectively. During 2019, we recognized approximately $40 million in revenues that were included in the contract liabilities balance at the adoption date.

[0001104659-19-068679:notes:243]
| (d) | Reconciliation of ASC 606 to Prior Accounting Standards |

[0001104659-19-068679:notes:244]
The amount by which each financial statement line item is affected in 2019 as a result of applying the new accounting standard as discussed in Note 2 is presented below:

[0001104659-19-068679:notes:245]
| ​ | ​ | September 30, 2019 |
| ​ | ​ | ​ | ​ | ​ | Effect of the | ​ | ​ | ​ |
| ​ | ​ | ​ | ​ | ​ | adoption of | ​ | Under Prior |
| (In thousands) |  | As Reported |  | ASC 606 |  | Accounting |
| Consolidated Balance Sheets |  | ​ |  |  | ​ |  |  | ​ |  |
| Contract assets (1) | ​ | $ | 115,310 | ​ | $ | (39,055) | ​ | $ | 76,255 |
| Inventories | ​ |  | 128,825 | ​ |  | 34,065 | ​ |  | 162,890 |
| Total current assets | ​ |  | 495,194 | ​ |  | (4,990) | ​ |  | 490,204 |
| Total assets | ​ |  | 1,466,720 | ​ |  | (4,990) | ​ |  | 1,461,730 |
| Contract liabilities (2) | ​ |  | 81,177 | ​ |  | 2,870 | ​ |  | 84,047 |
| Total current liabilities | ​ |  | 251,635 | ​ |  | 2,870 | ​ |  | 254,505 |
| Deferred tax liabilities | ​ |  | 64,855 | ​ |  | (658) | ​ |  | 64,197 |
| Total liabilities | ​ |  | 640,498 | ​ |  | 2,212 | ​ |  | 642,710 |
| Retained earnings | ​ |  | 684,741 | ​ |  | (7,202) | ​ |  | 677,539 |
| Total shareholders’ equity | ​ |  | 826,222 | ​ |  | (7,202) | ​ |  | 819,020 |
| Total liabilities and shareholders’ equity | ​ | $ | 1,466,720 | ​ |  | (4,990) | ​ |  | 1,461,730 |

[0001104659-19-068679:notes:246]
|  | (1) | Previously “cost and estimated earnings on long-term contracts” |

[0001104659-19-068679:notes:247]
|  | (2) | Previously “advance payments on long-term contracts” and “current portion of deferred revenue” |

[0001104659-19-068679:notes:248]
| ​ | ​ | Year ended |
| ​ | ​ | September 30, 2019 |
| ​ | ​ | ​ | ​ | ​ | Effect of the | ​ | ​ | ​ |
| ​ | ​ | ​ | ​ | ​ | adoption of | ​ | Under Prior |
| (In thousands, except per share amounts) |  | As Reported |  | ASC 606 |  | Accounting |
| Consolidated Statements of Operations |  | ​ |  |  | ​ |  |  | ​ |  |
| Net sales | ​ | $ | 812,970 | ​ | $ | (5,598) | ​ | $ | 807,372 |
| Cost of sales | ​ |  | 508,521 | ​ |  | (6,658) | ​ |  | 501,863 |
| Total costs and expenses | ​ |  | 710,754 | ​ |  | (6,658) | ​ |  | 704,096 |
| Earnings before income tax | ​ |  | 102,216 | ​ |  | 1,060 | ​ |  | 103,276 |
| Income tax expense | ​ |  | 21,177 | ​ |  | 255 | ​ |  | 21,432 |
| Net earnings | ​ |  | 81,039 | ​ |  | 805 | ​ |  | 81,844 |
| Earnings per share: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Basic: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Net earnings | ​ | $ | 3.12 | ​ | $ | 0.03 | ​ | $ | 3.15 |
| Diluted: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Net earnings | ​ | $ | 3.10 | ​ | $ | 0.03 | ​ | $ | 3.13 |
| Consolidated Statements of Comprehensive Income | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net earnings | ​ | $ | 81,039 | ​ | $ | 805 | ​ | $ | 81,844 |
| Comprehensive income | ​ | ​ | 68,593 | ​ | ​ | 805 | ​ | ​ | 69,398 |
| Consolidated Statements of Cash flows | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net earnings | ​ | $ | 81,039 | ​ | $ | 805 | ​ | $ | 81,844 |
| Adjustments to reconcile net earnings to net cash provided by operating activities: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Change in assets and liabilities | ​ | $ | (9,944) | ​ | ​ | (805) | ​ | $ | (10,749) |
| Net cash provided by operating activities | ​ | ​ | 105,137 | ​ | ​ | — | ​ | ​ | 105,137 |


## us-gaap:SubsequentEventsTextBlock

[0001104659-19-068679:notes:249]
17.     Subsequent Event

[0001104659-19-068679:notes:250]
On November 15, 2019 the Company, through its wholly owned subsidiaries ESCO Technologies Holding LLC and ESCO UK Holding Company I Ltd., entered into an agreement to sell its Technical Packaging business segment, consisting of Thermoform Engineered Quality LLC, Plastique Ltd. and Plastique sp. z o.o., to subsidiaries of Sonoco Products Company (NYSE: SON) for a cash purchase price of $187 million, plus or minus certain customary adjustments based on working capital and other typical post-closing adjustments specified in the sale agreement. Closing of the transaction is subject to specified representations, warranties, covenants and conditions customary in agreements of this kind and scope. The buyers have agreed to waive any post-closing claims against the sellers for indemnity under the representations and warranties in the sale agreement (except in the event of fraud) and intend to obtain a Representation and Warranty Insurance policy to provide coverage in the event of a breach by the sellers.

[0001104659-19-068679:notes:251]
The Company expects to finalize the sale upon receipt of regulatory clearance under the Hart-Scott-Rodino Antitrust Improvements Act of 1976 and similar foreign regulations, and upon satisfaction or waiver of the conditions to Closing specified in the Agreement. The Company expects the Closing to occur in late 2019 or early 2020.

[0001104659-19-068679:notes:252]
The Technical Packaging business segment will be reported as discontinued operations in 2020.

[0001104659-19-068679:notes:253]
The Company intends to use the proceeds from the sale to pay down debt and for other corporate purposes, including funding, terminating and annuitizing the Company’s defined benefit pension plan, which has been frozen since 2003, during fiscal 2020.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001104659-19-068679:notes:254]
18.     Quarterly Financial Information (Unaudited)

[0001104659-19-068679:notes:255]
| ​ | ​ | First | ​ | Second | ​ | Third | ​ | Fourth |
| (Dollars in thousands, except per share amounts) |  | Quarter |  | Quarter |  | Quarter |  | Quarter |
| 2019 |  | ​ |  |  |  |  |  |  |  |
| Net sales | ​ | $ | 182,597 |  | 193,949 |  | 199,766 |  | 236,658 |
| Net earnings | ​ |  | 17,317 |  | 18,797 |  | 20,067 |  | 24,858 |
| Earnings per share: | ​ |  |  |  |  |  |  |  |  |
| Basic | ​ | $ | 0.67 |  | 0.73 |  | 0.77 |  | 0.96 |
| Diluted | ​ |  | 0.66 |  | 0.72 |  | 0.77 |  | 0.95 |
| Dividends declared per common share | ​ | $ | 0.08 |  | 0.08 |  | 0.08 |  | 0.08 |
| Common stock price per share: | ​ |  |  |  |  |  |  |  |  |
| High | ​ | $ | 71.47 |  | 71.29 |  | 82.70 |  | 85.86 |
| Low | ​ |  | 59.00 |  | 62.91 |  | 67.43 |  | 73.04 |
| 2018 | ​ |  |  |  |  |  |  |  |  |
| Net sales | ​ | $ | 173,495 |  | 174,778 |  | 192,223 |  | 231,086 |
| Net earnings | ​ |  | 34,671 |  | 9,994 |  | 19,019 |  | 28,452 |
| Earnings per share: | ​ |  |  |  |  |  |  |  |  |
| Basic | ​ | $ | 1.34 |  | 0.39 |  | 0.73 |  | 1.10 |
| Diluted | ​ |  | 1.33 |  | 0.38 |  | 0.73 |  | 1.09 |
| Dividends declared per common share | ​ | $ | 0.08 |  | 0.08 |  | 0.08 |  | 0.08 |
| Common stock price per share: | ​ |  |  |  |  |  |  |  |  |
| High | ​ | $ | 65.95 |  | 66.80 |  | 60.25 |  | 70.20 |
| Low | ​ |  | 51.55 |  | 57.15 |  | 54.35 |  | 57.00 |
