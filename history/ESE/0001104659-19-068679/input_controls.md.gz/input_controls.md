# ESE 10-K controls and the auditor's report


## auditors_report

[0001104659-19-068679:auditors_report:1]
F-1

[0001104659-19-068679:auditors_report:2]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001104659-19-068679:auditors_report:3]
To the Shareholders and Board of Directors

[0001104659-19-068679:auditors_report:4]
ESCO Technologies Inc.:

[0001104659-19-068679:auditors_report:5]
Opinion on the Consolidated Financial Statements

[0001104659-19-068679:auditors_report:6]
We have audited the accompanying consolidated balance sheets of ESCO Technologies Inc. and subsidiaries (the Company) as of September 30, 2019 and 2018, the related consolidated statements of operations, comprehensive income (loss), shareholders’ equity, and cash flows for each of the years in the three-year period ended September 30, 2019, and the related notes (collectively, the consolidated financial statements). In our opinion, the consolidated financial statements present fairly, in all material respects, the financial position of the Company as of September 30, 2019 and 2018, and the results of its operations and its cash flows for each of the years in the three-year period ended September 30, 2019, in conformity with U.S. generally accepted accounting principles.

[0001104659-19-068679:auditors_report:7]
We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the Company’s internal control over financial reporting as of September 30, 2019, based on criteria established in Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission, and our report dated November 29, 2019 expressed an unqualified opinion on the effectiveness of the Company’s internal control over financial reporting.

[0001104659-19-068679:auditors_report:8]
Change in Accounting Principle

[0001104659-19-068679:auditors_report:9]
As discussed in Note 2 to the consolidated financial statements, the Company has changed its method of accounting for revenue from contracts with customers as of October 1, 2018 due to the adoption of ASU No. 2014-09, Revenue from Contracts with Customers (ASC Topic 606).

[0001104659-19-068679:auditors_report:10]
Basis for Opinion

[0001104659-19-068679:auditors_report:11]
These consolidated financial statements are the responsibility of the Company’s management. Our responsibility is to express an opinion on these consolidated financial statements based on our audits. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001104659-19-068679:auditors_report:12]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0001104659-19-068679:auditors_report:13]
Critical Audit Matters

[0001104659-19-068679:auditors_report:14]
The critical audit matters communicated below are matters arising from the current period audit of the consolidated financial statements that were communicated or required to be communicated to the audit committee and that: (1) relate to accounts or disclosures that are material to the consolidated financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0001104659-19-068679:auditors_report:15]
F-2

[0001104659-19-068679:auditors_report:16]
Assessment of the estimation of total contract costs at completion for contracts in the Filtration segment for which revenue is recognized over time using a cost-to-cost model

[0001104659-19-068679:auditors_report:17]
As discussed in Notes 2 and 14 to the consolidated financial statements, the Company’s Filtration segment enters into certain long-term fixed price contracts with aerospace and defense customers to produce various products. These products do not have an alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin. Revenue for these contracts is recognized over time using a cost-to-cost model. Under such model, the Company measures the extent of progress towards completion of these contracts based on the ratio of contract costs incurred to date to the estimate of total contract costs at completion. The estimation of these costs requires judgment by the Company given the unique product specifications and requirements for contracts related to the design, development, and manufacture of complex products.

[0001104659-19-068679:auditors_report:18]
We identified the assessment of the estimation of total contract costs at completion for contracts in the Filtration segment for which revenue is recognized over time using a cost-to-cost model as a critical audit matter. Complex auditor judgment was required in evaluating expected engineering and production requirements of the contracts and the associated cost estimates for labor hours and materials.

[0001104659-19-068679:auditors_report:19]
The primary procedures we performed to address this critical audit matter included the following. We tested certain internal controls over the Company’s revenue recognition process, including controls over the accumulation and estimation of labor hours and costs of materials. We compared the Company’s historical estimated costs and profit margin to the actual costs and profit margin for completed contracts to assess the Company’s ability to accurately estimate costs. We challenged the Company’s assumptions for labor hours and materials to be incurred for a sample of contracts by:

[0001104659-19-068679:auditors_report:20]
| ● | Reading the underlying contract documents to obtain an understanding of the contractual requirements and deliverables; |

[0001104659-19-068679:auditors_report:21]
| ● | Comparing the costs incurred to date, as a percentage of the estimated costs at completion, to the Company’s physical production to date under the contract; |

[0001104659-19-068679:auditors_report:22]
| ● | Comparing actual incurred and remaining estimated material costs to the original estimated amount of material costs at the beginning of the project plus incremental material costs due to modifications; |

[0001104659-19-068679:auditors_report:23]
| ● | Comparing actual incurred and remaining estimated labor hours to the original estimate of labor hours at the beginning of the project plus incremental labor hours due to modification; |

[0001104659-19-068679:auditors_report:24]
| ● | Comparing the estimated costs at completion, which includes costs incurred to date plus estimated costs to complete, to actual costs incurred for similar products previously developed and produced, if applicable; and |

[0001104659-19-068679:auditors_report:25]
| ● | Inspecting correspondence between the Company and the customer regarding actual and expected contract performance to date and comparing to the estimate to complete. |

[0001104659-19-068679:auditors_report:26]
Evaluation of the sufficiency of audit evidence obtained over net sales

[0001104659-19-068679:auditors_report:27]
As discussed in Notes 1 and 16 to the consolidated financial statements, and disclosed in the consolidated statements of operations, the Company recorded $813.0 million of net sales in 2019. Net sales are recognized primarily from the sale of highly engineered products and systems across various industries and through multiple Company divisions and locations around the world.

[0001104659-19-068679:auditors_report:28]
We identified the evaluation of the sufficiency of audit evidence obtained over net sales as a critical audit matter. Evaluating the sufficiency of audit evidence obtained over net sales required especially subjective auditor judgment because of the disaggregated nature of the Company’s operations, including revenue recognition accounting policies and procedures that differ among the various divisions and locations. This included determining the Company divisions and locations at which procedures were performed.

[0001104659-19-068679:auditors_report:29]
The primary procedures we performed to address this critical audit matter included the following. We applied auditor judgment to determine the nature and extent of procedures to be performed over net sales, including the determination of the Company divisions and locations at which those procedures were to be performed. At each Company division and location where procedures were performed, we:

[0001104659-19-068679:auditors_report:30]
| ● | Tested certain internal controls over the Company’s net sales process at the applicable division and location; and |

[0001104659-19-068679:auditors_report:31]
| ● | Assessed the recorded net sales by selecting a sample of transactions and compared the amount recognized for consistency with underlying documentation, including contracts with customers and shipping documentation, if applicable, and the Company’s revenue recognition policies. |

[0001104659-19-068679:auditors_report:32]
F-3

[0001104659-19-068679:auditors_report:33]
After completion of these procedures, we evaluated the overall sufficiency of audit evidence obtained over net sales.

[0001104659-19-068679:auditors_report:34]
Evaluation of initial measurement of customer relationship and trade name intangible assets acquired in the Globe Composite Solutions, LLC business combination

[0001104659-19-068679:auditors_report:35]
As discussed in Note 2 to the consolidated financial statements, the Company acquired Globe Composite Solutions, LLC (Globe) on July 2, 2019. As a result of the transaction, the Company acquired a customer relationship intangible asset associated with the generation of future income from Globe’s existing customers and a trade name intangible asset associated with the Globe Composite Solutions trade name (collectively, the intangible assets).

[0001104659-19-068679:auditors_report:36]
We identified the evaluation of the initial measurement of these intangible assets acquired in the Globe business combination as a critical audit matter. There was a high degree of subjectivity in evaluating the discounted cash flow model used to calculate the acquisition-date fair value of the intangible assets. In addition, auditor judgment was required to evaluate the following assumptions used by the Company in valuing the intangible assets:

[0001104659-19-068679:auditors_report:37]
| ● | Forecasted revenues and revenue growth rates; |

[0001104659-19-068679:auditors_report:38]
| ● | Forecasted revenues from existing customer contracts, inclusive of attrition; |

[0001104659-19-068679:auditors_report:39]
| ● | Forecasted earnings before interest, taxes, depreciation, and amortization (EBITDA); |

[0001104659-19-068679:auditors_report:40]
| ● | Royalty rate; and |

[0001104659-19-068679:auditors_report:41]
| ● | Estimated discount rate. |

[0001104659-19-068679:auditors_report:42]
The primary procedures we performed to address this critical audit matter included the following. We tested certain internal controls over the Company’s acquisition-date valuation process, including controls related to the development of the relevant assumptions, as listed above. We compared the Company’s estimates of forecasted revenues and EBITDA to Globe’s historical results. We evaluated the Company’s forecasted revenues from existing customers, exclusive of attrition, and forecasted EBITDA by comparing forecasted revenue growth and EBITDA assumptions to those of the Company’s peers and trends in the industry. We tested the Company’s determination of the weighted average cost of capital (WACC) by comparing it to the WACCs of comparable peer companies. In addition, we involved valuation professionals with specialized skills and knowledge, who assisted in:

[0001104659-19-068679:auditors_report:43]
| ● | Comparing the valuation approaches used by the Company to calculate the fair value of the intangible assets to standard valuation approaches for comparable types of assets; |

[0001104659-19-068679:auditors_report:44]
| ● | Comparing customer attrition to an independent estimate developed based on historical attrition rates for Globe and certain qualitative market factors; |

[0001104659-19-068679:auditors_report:45]
| ● | Evaluating the Company’s royalty rate, by comparing it to royalty rates used for similar assets in the same industry; |

[0001104659-19-068679:auditors_report:46]
| ● | Evaluating the Company’s discount rate, by comparing it against a discount rate range that was independently developed using publicly available market data for comparable peers; |

[0001104659-19-068679:auditors_report:47]
| ● | Developing an estimate of the fair value of the customer relationship intangible asset using the Company’s cash flow forecast and an independently developed discount rate; and |

[0001104659-19-068679:auditors_report:48]
| ● | Developing an estimate of the fair value of the trade name intangible asset using the Company’s forecasted revenues and estimated royalty rate and an independently developed discount rate. |

[0001104659-19-068679:auditors_report:49]
| /s/ KPMG LLP | ​ |

[0001104659-19-068679:auditors_report:50]
We have served as the Company’s auditor since 1990.

[0001104659-19-068679:auditors_report:51]
St. Louis, Missouri

[0001104659-19-068679:auditors_report:52]
November 29, 2019

[0001104659-19-068679:auditors_report:53]
F-4


## item_9a

[0001104659-19-068679:item_9a:1]
Item 9A. Controls and Procedures

[0001104659-19-068679:item_9a:2]
For 2019, the Company carried out an evaluation of the effectiveness of the design and operation of the Company’s disclosure controls and procedures, as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the Exchange Act). The evaluation was conducted under the supervision and with the participation of the Company’s Management, including the Company’s Chief Executive Officer and Chief Financial Officer, using the Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). Disclosure controls and procedures are designed to ensure that information required to be disclosed by the Company in reports filed or submitted under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the Securities and Exchange Commission’s rules and forms. Based upon that evaluation, the Company’s Chief Executive Officer and Chief Financial Officer concluded that the Company’s disclosure controls and procedures were effective as of September 30, 2019.

[0001104659-19-068679:item_9a:3]
As disclosed in Item 9A, Controls and Procedures, in our Annual Report on Form 10-K for the fiscal year ended September 30, 2018, during the fourth quarter of 2018 we identified a material weakness in internal control related to the ineffective design and operation of controls impacting the deferred revenue general ledger account. During 2019, Management implemented our previously disclosed remediation plan that included: enhancing our policies and procedures related to the deferred revenue reconciliation and review and providing additional training to certain personnel in our finance department. During the fourth quarter of 2019, we completed our testing of the operating effectiveness of the implemented controls and found them to be effective. As a result we have concluded the material weakness has been remediated as of September 30, 2019.

[0001104659-19-068679:item_9a:4]
Except for the changes in connection with our implementation of the remediation plan discussed above, there have been no other changes in the Company’s internal control over financial reporting (as defined in Rule 13a-15(f) under the Exchange Act) during the fiscal quarter ended September 30, 2019 that have materially affected, or are reasonably likely to materially affect, the Company’s internal control over financial reporting.

[0001104659-19-068679:item_9a:5]
For the remainder of the information required by this item, see “Management’s Report on Internal Control over Financial Reporting” and the related “Report of Independent Registered Public Accounting Firm” of KPMG LLP, in the Financial Information section beginning on page F-1 of this Annual Report, which are incorporated into this Item by reference.
