# ESE notes — 0001410578-23-002596


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001410578-23-002596:notes:1]
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS

[0001410578-23-002596:notes:2]
1.      Summary of Significant Accounting Policies

[0001410578-23-002596:notes:3]
A.      Principles of Consolidation

[0001410578-23-002596:notes:4]
The Consolidated Financial Statements include the accounts of ESCO Technologies Inc. (ESCO) and its wholly owned subsidiaries. Except where the context indicates otherwise, the terms “Company”, “we”, “our” and “us” are used in this report to refer to ESCO together with its subsidiaries through which its businesses are conducted. All significant intercompany transactions and accounts have been eliminated in consolidation.

[0001410578-23-002596:notes:5]
B.      Basis of Presentation

[0001410578-23-002596:notes:6]
Our fiscal year ends on September 30. Throughout the Consolidated Financial Statements, unless the context indicates otherwise, references to a year (for example 2023) refer to fiscal year ending on September 30 of that year. Certain items have been reclassified in the prior year financial statements to conform to the presentation and classifications used in the current year. These reclassifications have no effect on the Company’s consolidated results, financial position or cash flows.

[0001410578-23-002596:notes:7]
C.      Nature of Operations

[0001410578-23-002596:notes:8]
We are organized based on the products and services we offer and we currently classify our business operations in three segments for financial reporting purposes: Aerospace & Defense (A&D), Utility Solutions Group (USG), and RF Test & Measurement, formerly called RF Shielding and Test (Test).

[0001410578-23-002596:notes:9]
A&D: The companies within this segment primarily design and manufacture specialty filtration products, including hydraulic filter elements and fluid control devices used in commercial aerospace applications; unique filter mechanisms used in micro-propulsion devices for satellites; custom designed filters for manned aircraft and submarines; products and systems to reduce vibration and/or acoustic signatures and otherwise reduce or obscure a vessel’s signature, and other communications, sealing, surface control and hydrodynamic related applications to enhance U.S. Navy maritime survivability; precision-tolerance machined components for the aerospace and defense industry; and metal processing services; and miniature electro-explosive devices for military aircraft ejection seats and missile arming devices.

[0001410578-23-002596:notes:10]
USG: The companies within this segment provide diagnostic testing solutions that enable electric power grid operators to assess the integrity of high-voltage power delivery equipment, as well as decision support tools for the renewable energy industry, primarily wind and solar.

[0001410578-23-002596:notes:11]
Test: The companies within this segment provide their customers with the ability to identify, measure and control magnetic, electromagnetic and acoustic energy.

[0001410578-23-002596:notes:12]
In addition, for reporting certain financial information we treat Corporate activities as a separate segment.

[0001410578-23-002596:notes:13]
D.      Use of Estimates

[0001410578-23-002596:notes:14]
The preparation of financial statements in conformity with GAAP requires Management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.

[0001410578-23-002596:notes:15]
E.      Revenue Recognition

[0001410578-23-002596:notes:16]
We recognize revenue when control of the goods or services promised under the contract is transferred to the customer either at a point in time (e.g., upon delivery) or over time (e.g., as we perform under the contract). We account for a contract when it has approval and commitment from both parties, the rights and payment terms of the parties are identified, the contract has commercial substance and collectability of consideration is probable. We review contracts to determine whether there are one or multiple performance obligations. A performance obligation is a promise to transfer a distinct good or service to a customer and represents the unit of accounting for revenue recognition. For contracts with multiple performance obligations, we allocate the expected consideration, or the transaction price, to each performance obligation identified in the contract based on the relative standalone

[0001410578-23-002596:notes:17]
selling price of each performance obligation. We then recognize revenue for the transaction price allocated to the performance obligation when control of the promised goods or services underlying the performance obligation is transferred.

[0001410578-23-002596:notes:18]
Payment terms with our customers vary by the type and location of the customer and the products or services offered. We do not adjust the promised amount of consideration for the effects of significant financing components based on the expectation that the period between when we transfer a promised good or service to a customer and when the customer pays for that good or service will be one year or less. Arrangements with customers that include payment terms extending beyond one year are not significant. We account for shipping and handling costs on a gross basis and include them in net sales. We account for taxes collected from customers and remitted to governmental authorities on a net basis and exclude them from net sales.

[0001410578-23-002596:notes:19]
A&D: Within the A&D segment, approximately 45% of revenues (approximately 19% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial and military customers and have a single performance obligation as there is only one good promised or the promise to transfer the goods or services is not distinct or separately identifiable from other promises in the contract. The transaction price for these contracts reflects our estimate of returns and discounts, which are based on historical, current and forecasted information to determine the expected amount to which we will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to the customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in cost of goods sold in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

[0001410578-23-002596:notes:20]
Approximately 55% of the segment’s revenues (approximately 22% of consolidated revenues) are accounted for over time as the product does not have an alternative use and we have an enforceable right to payment for costs incurred plus a reasonable margin or the inventory is owned by the customer. The related contracts are primarily cost-plus or fixed price contracts related to the design, development and manufacture of complex fluid control products, quiet valves, manifolds, shock and vibration dampening, thermal insulation and systems primarily for the commercial aerospace and military (U.S. Government) markets. The contracts may contain multiple products, which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. Our contracts are frequently modified for changes in contract specifications and requirements. Most of our contract modifications are for products that are not distinct from the existing contract and are accounted for as part of that existing contract.

[0001410578-23-002596:notes:21]
Contracts with the U.S. Government generally contain clauses that provide lien rights to work-in-process along with clauses that allow the customer to unilaterally terminate the contract for convenience, pay us for costs incurred plus a reasonable profit and take control of any work-in-process. Due to the continuous transfer of control to the U.S. Government, we recognize revenue over the time that we perform under the contract.

[0001410578-23-002596:notes:22]
Selecting the method to measure progress towards completion for the commercial and military contracts requires judgment and is based on the nature of the products or service to be provided. We generally use the cost-to-cost method to measure progress for our Aerospace & Defense segment contracts, as the rate at which costs are incurred to fulfill a contract best depicts the transfer of control to the customer. Under this method, we measure the extent of progress towards completion based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and record revenue proportionally as costs are incurred based on an estimated profit margin.

[0001410578-23-002596:notes:23]
The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable.

[0001410578-23-002596:notes:24]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to one or more years, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

[0001410578-23-002596:notes:25]
Under the typical payment terms of our long term fixed price contracts, the customer pays us either performance-based or progress payments. Performance-based payments represent interim payments based on quantifiable measures of performance or on the achievement of specified events or milestones. Progress payments are interim payments of costs incurred as the work progresses. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred, which we present as contract assets and contract liabilities, respectively, in the Consolidated Balance Sheets. We classify amounts billed and due from our customers in Accounts receivable, net. For short term fixed price and cost-type contracts, we are generally paid within a short period of time.

[0001410578-23-002596:notes:26]
For contracts where revenue is recognized over time, we recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. We have net revenue recognized in the current year from performance obligations satisfied in the prior year due to changes in our estimated costs to complete the related performance obligations. We recognize anticipated losses on contracts in full in the period in which the losses become known.

[0001410578-23-002596:notes:27]
USG: Within the USG segment, approximately 82% of revenues (approximately 29% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and is accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which we will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. We generally do not treat them as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in the period they are incurred. We record taxes collected from customers and remitted to government authorities on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

[0001410578-23-002596:notes:28]
Approximately 18% of the segment’s revenues (approximately 6% of consolidated revenues) are recognized over time as services are performed. The services accounted for under this method include an obligation to provide testing services using hardware and embedded software, software maintenance, training, lab testing, and consulting services. Typically, the related contracts contain a bundle of goods and services that are integrated in the context of the contract. Therefore, the goods and services are not distinct and we have a single performance obligation. Selecting the method to measure progress towards completion for these contracts requires judgment and is based on the nature of the products and service to be provided. We will recognize revenue as a series of distinct services based on each day of providing services (straight-line over the contract term) for our USG segment contracts. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Under the typical payment terms of our service contracts, the customer pays us in advance of when services are performed. Because of the timing difference of revenue recognition and customer payment, which is typically received upon commencement of the contract, these contracts result in deferred revenue, which we present as contract liabilities, in the Consolidated Balance Sheets.

[0001410578-23-002596:notes:29]
Included in this category, approximately 5% of the segment’s revenues (approximately 2% of consolidated revenues) are recognized based on the terms of the software contract. For contracts that transfer a software license to the customer, revenue will be recognized at a point in time. These type of software contracts represent a right to use the software, or a functional license, in which revenue should be recognized upon transfer of the license. For contracts in software as a service (SaaS) arrangements, revenue will be recognized over time. The customer receives and consumes the benefits of the SaaS arrangement through access to the system which is for a stated period. We will recognize revenue based on each day of providing access (straight-line over the contract term). The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Under the typical payment terms of our software contracts, the customer pays us in advance of when services are performed. Because of the timing difference of revenue recognition and customer payment, these contracts result in deferred revenue, which we present as contract liabilities, in the Consolidated Balance Sheets.

[0001410578-23-002596:notes:30]
Test: Within the Test segment, approximately 20% of revenues (approximately 5% of consolidated revenues) are recognized at a point in time when products such as, antennas and probes are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct because the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in the context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which we will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

[0001410578-23-002596:notes:31]
Approximately 80% of the segment’s revenues (approximately 19% of consolidated revenues) are recorded over time as the product does not have an alternative use and we have an enforceable right to payment for costs incurred plus a reasonable margin. Products accounted for under this guidance include the construction and installation of test chambers to a buyer’s specifications that provide its customers with the ability to measure and contain magnetic, electromagnetic and acoustic energy. The goods and services related to each installed test chamber are not distinct due to the significant amount of integration provided and each installed chamber is accounted for as a single performance obligation. Selecting the method to measure progress towards completion for these contracts requires judgment and is based on the nature of the products and service to be provided. We use milestones to measure progress for our Test segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. For arrangements that are accounted for under this guidance, we estimate profit as the difference between total revenue and total estimated cost of a contract and recognize these revenues and costs based primarily on contract milestones. The transaction price for our contracts is typically fixed price and represents our best estimate of the consideration we will receive.

[0001410578-23-002596:notes:32]
We estimate total contract cost utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to a year, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

[0001410578-23-002596:notes:33]
Under the typical payment terms of our fixed price contracts, the customer pays us either based on progress or based on a fixed billing schedule within the contract. Performance-based payments represent interim payments based on noted progress points as the work progresses. Because of the timing difference of revenue recognition and customer billing, these contracts result in revenue recognized in excess of billings and billings in excess of revenue recognized, which we present as contract assets and contract liabilities, respectively, in the Consolidated Balance Sheets. Amounts billed and due from our customers are classified in Accounts receivable, net.

[0001410578-23-002596:notes:34]
For contracts where revenue is recognized over time, we generally recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. We have net revenue recognized in the current year from performance obligations satisfied in the prior year due to changes in our estimated costs to complete the related performance obligations. We recognize anticipated losses on contracts in full in the period in which the losses become probable and estimable.

[0001410578-23-002596:notes:35]
Contract Assets and Liabilities

[0001410578-23-002596:notes:36]
Contract assets arise from contracts when revenue is recognized over time and the amount of revenue recognized, including our estimate of variable consideration that has been included in the transaction price, exceeds the amount billed to the customer. These amounts are included in contract assets until the right to payment is no longer conditional on events other than the passage of time. These contract assets are reclassified to receivables when the right to consideration becomes unconditional. Contract liabilities include deposits, deferred revenue, upfront payments and billings in excess of revenue recognized. We include liabilities for customer rebates and discounts in other current liabilities in the Consolidated Balance Sheets.

[0001410578-23-002596:notes:37]
See the further discussion of our revenue recognition in Note 12 below.

[0001410578-23-002596:notes:38]
F.      Cash and Cash Equivalents

[0001410578-23-002596:notes:39]
Cash equivalents include temporary investments that are readily convertible into cash, such as money market funds, with original maturities of three months or less. Some of our cash is deposited with financial institutions located throughout the U.S. and at banks in foreign countries where we operate subsidiary offices, and at times may exceed insured limits. Cash and cash equivalents held in foreign bank accounts totaled $35.2 million at September 30, 2023 and we routinely repatriate cash from our foreign subsidiaries.

[0001410578-23-002596:notes:40]
G.      Accounts Receivable

[0001410578-23-002596:notes:41]
We reduce accounts receivable by an allowance for amounts that we estimate are uncollectible in the future. This estimated allowance is based on Management’s evaluation of the financial condition of the customer and historical write-off experience.

[0001410578-23-002596:notes:42]
H.      Inventories

[0001410578-23-002596:notes:43]
We value inventories at the lower of cost (first-in, first-out) or net realizable value. We regularly review inventories for excess quantities and obsolescence based upon historical experience, specific identification of discontinued items, future demand, and market conditions. Inventories under long-term contracts reflect accumulated production costs, factory overhead, initial tooling and other related costs less the portion of such costs charged to cost of sales.

[0001410578-23-002596:notes:44]
I.      Property, Plant and Equipment

[0001410578-23-002596:notes:45]
Property, plant and equipment are recorded at cost. Depreciation and amortization are computed primarily on a straight-line basis over the estimated useful lives of the assets: buildings, 10-40 years; machinery and equipment, 3-10 years; and office furniture and equipment, 3-10 years. Leasehold improvements are amortized over the remaining term of the applicable lease or their estimated useful lives, whichever is shorter. Long-lived tangible assets are reviewed for impairment whenever events or changes in business circumstances indicate the carrying value of the assets may not be recoverable. Impairment losses are recognized based on fair value.

[0001410578-23-002596:notes:46]
J.      Leases

[0001410578-23-002596:notes:47]
Our lease agreements primarily relate to office space, manufacturing facilities, and machinery and equipment. We determine at lease inception whether an arrangement that provides control over the use of an asset is a lease. We recognize at lease commencement a right-of-use (ROU) asset and lease liability based on the present value of the future lease payments over the lease term. We have elected not to recognize a ROU asset and lease liability for leases with terms of 12 months or less. Certain of our leases include options to extend the term of the lease for up to 20 years. When it is reasonably certain that we will exercise the option, Management includes the impact of the option in the lease term for purposes of determining total future lease payments. As most of our lease agreements do not explicitly state the discount rate implicit in the lease, Management uses our incremental borrowing rate on the commencement date to calculate the present value of future payments based on the tenor of each arrangement.

[0001410578-23-002596:notes:48]
K.      Goodwill and Other Long-Lived Intangible Assets

[0001410578-23-002596:notes:49]
Goodwill represents the excess of purchase price over the fair value of net identifiable assets acquired in business acquisitions. Management annually reviews goodwill and other long-lived assets with indefinite useful lives for impairment or whenever events or changes in circumstances indicate the carrying amount may be less than fair value. If we determine that the carrying value of the long-lived asset or reporting unit is less than fair value, we record a permanent impairment charge for the amount by which the carrying

[0001410578-23-002596:notes:50]
value of the long-lived asset exceeds its fair value. We measure the fair value of our reporting units based on a discounted cash flow method using a discount rate determined by Management to be commensurate with the risk inherent in each of our reporting units’ current business models. We determine the fair value of trade names using a generally accepted valuation method based on an income approach called the relief from royalty method. During 2023, Management performed a quantitative impairment analysis, which included a detailed calculation of the fair value of our trade names and reporting units related to certain reporting units within these segments. A Step 0 analysis was performed on the other reporting units for which a quantitative analysis was not performed. The results of these impairment analyses indicated that the fair values of the trade names and reporting units are not less than their carrying values. Our estimates of discounted cash flows to derive the fair value were measured in accordance with ASC 350, Intangibles – Goodwill and Other. We are using estimates of discounted cash flows that may change, and if they change negatively it could result in the need to write down those assets to fair value.

[0001410578-23-002596:notes:51]
Other intangible assets represent costs allocated to identifiable intangible assets, principally customer relationships, capitalized software, patents, trademarks, and technology rights. We amortize intangible assets with estimable useful lives over their respective estimated useful lives to their estimated residual values, and review them for impairment whenever events or changes in business circumstances indicate the carrying value of the assets may not be recoverable.

[0001410578-23-002596:notes:52]
See Note 3 regarding goodwill and other intangible assets activity.

[0001410578-23-002596:notes:53]
L.      Capitalized Software

[0001410578-23-002596:notes:54]
Costs incurred for the development of computer software that will be sold, leased, or otherwise marketed are charged to research and development expense when incurred, until technological feasibility has been established for the product. Technological feasibility is typically established upon completion of a detailed program design. Costs incurred after this point are capitalized on a project-by-project basis. Capitalized costs consist of internal and external development costs. Upon general release of the product to customers, we cease capitalization and begin amortization, which is calculated on a project-by-project basis as the greater of (1) the ratio of current gross revenues for a product to the total of current and anticipated future gross revenues for the product or (2) the straight-line method over the estimated economic life of the product. We generally amortize software development costs over a three-to-seven year period based upon the estimated future economic life of the product. Factors we consider in determining the estimated future economic life of the product include anticipated future revenues, and changes in software and hardware technologies. Management annually reviews the carrying values of capitalized costs for impairment or whenever events or changes in circumstances indicate the carrying amount may not be recoverable. If expected cash flows are insufficient to recover the carrying amount of the asset, then we recognize an impairment loss to state the asset at its net realizable value.

[0001410578-23-002596:notes:55]
M.      Income Taxes

[0001410578-23-002596:notes:56]
We account for income taxes under the asset and liability method. We recognize deferred tax assets and liabilities for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. We measure deferred tax assets and liabilities using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. We may reduce deferred tax assets by a valuation allowance if it is more likely than not that some portion or all of the deferred tax assets will not be realized. We recognize the effect on deferred tax assets and liabilities of a change in tax rates in income in the period that includes the enactment date. We regularly review our deferred tax assets for recoverability and establish a valuation allowance when Management believes it is more likely than not such assets will not be recovered, taking into consideration historical operating results, expectations of future earnings, tax planning strategies, and the expected timing of the reversals of existing temporary differences. Our policy is to include interest related to unrecognized tax benefits in income tax expense and penalties in operating expense.

[0001410578-23-002596:notes:57]
N.      Research and Development Costs

[0001410578-23-002596:notes:58]
Company-sponsored research and development costs include research and development and bid and proposal efforts related to our products and services. We charge Company-sponsored product development costs to expense when incurred. Customer-sponsored research and development costs refer to certain situations whereby customers provide funding to support specific contractually defined research and development costs. We account for customer-sponsored research and development costs incurred pursuant to contracts similarly to other program costs. Total Company and customer-sponsored research and development expenses were approximately $13.0 million, $12.3 million and $15.4 million for 2023, 2022 and 2021, respectively.

[0001410578-23-002596:notes:59]
O.      Foreign Currency Translation

[0001410578-23-002596:notes:60]
We translate the financial statements of our foreign operations into U.S. dollars in accordance with FASB ASC Topic 830, Foreign Currency Matters. We record the resulting translation adjustments as a separate component of accumulated other comprehensive income.

[0001410578-23-002596:notes:61]
P.      Earnings Per Share

[0001410578-23-002596:notes:62]
We calculate basic earnings per share using the weighted average number of common shares outstanding during the period. We calculate diluted earnings per share using the weighted average number of common shares outstanding during the period plus shares issuable upon the assumed exercise of dilutive vesting of unvested restricted units (restricted shares) using the treasury stock method. There are no anti-dilutive shares.

[0001410578-23-002596:notes:63]
The number of shares used in the calculation of earnings per share for each year presented is as follows:

[0001410578-23-002596:notes:64]
| (in thousands) |  | 2023 |  | 2022 |  | 2021 |
| Weighted Average Shares Outstanding — Basic |  | 25,802 |  | 25,933 |  | 26,046 |
| Dilutive Restricted Shares | ​ | 77 | ​ | 134 | ​ | 179 |
| Shares — Diluted |  | 25,879 |  | 26,067 |  | 26,225 |

[0001410578-23-002596:notes:65]
Q.      Share-Based Compensation

[0001410578-23-002596:notes:66]
We provide compensation benefits to certain key employees under several share-based plans providing for performance-accelerated, performance-based and/or time-vested restricted stock unit awards, and to non-employee directors under a separate compensation plan for non-employee directors. We measure share-based payment expense at the grant date based on the fair value of the award and recognize it on a straight-line basis over the requisite service period (generally the vesting period of the award) and/or if the performance criteria are deemed probable.

[0001410578-23-002596:notes:67]
R.      Accumulated Other Comprehensive Loss

[0001410578-23-002596:notes:68]
Accumulated other comprehensive loss of $(24.0) million at September 30, 2023 consisted of currency translation adjustments.

[0001410578-23-002596:notes:69]
S.      Fair Value Measurements

[0001410578-23-002596:notes:70]
Fair value is defined as the price at which an asset could be exchanged in a current transaction between knowledgeable, willing parties or the amount that would be paid to transfer a liability to a new obligor, not the amount that would be paid to settle the liability with the creditor. Where available, we base fair value on observable market prices or parameters or derived from such prices or parameters. Where observable prices or inputs are not available, we apply valuation models. These valuation techniques involve some level of Management estimation and judgment, the degree of which is dependent on the price transparency for the instruments or market and the instruments’ complexity.

[0001410578-23-002596:notes:71]
The accounting guidance establishes a three-level hierarchy for disclosure of fair value measurements, based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date, as follows:

[0001410578-23-002596:notes:72]
Level 1 – Inputs to the valuation methodology are quoted prices (unadjusted) for identical assets or liabilities in active markets.

[0001410578-23-002596:notes:73]
Level 2 – Inputs to the valuation methodology include quoted prices for similar assets and liabilities in active markets, and inputs that are observable for the asset or liability, either directly or indirectly, for substantially the full term of the financial instrument.

[0001410578-23-002596:notes:74]
Level 3 – Inputs to the valuation methodology are unobservable and significant to the fair value measurement.

[0001410578-23-002596:notes:75]
Financial Assets and Liabilities

[0001410578-23-002596:notes:76]
We have estimated the fair value of our financial instruments as of September 30, 2023 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, payables and other current assets and liabilities approximate fair value because of the short maturity of those instruments. The carrying amounts due under the revolving credit facility approximate fair value as the interest on outstanding borrowings is calculated at a spread over either an Adjusted Term SOFR Rate, Adjusted EURIBOR Rate, Adjusted CDOR Rate, Alternate Base Rate or Daily Simple RFR, at the Company’s election.

[0001410578-23-002596:notes:77]
Nonfinancial Assets and Liabilities

[0001410578-23-002596:notes:78]
Our nonfinancial assets such as property, plant and equipment, inventories, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during 2023.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001410578-23-002596:notes:79]
2.     Acquisitions

[0001410578-23-002596:notes:80]
2023

[0001410578-23-002596:notes:81]
On February 1, 2023, we acquired CMT Materials, LLC and its affiliate Engineered Syntactic Systems, LLC (together, CMT) for a purchase price of approximately $18 million, net of cash acquired. CMT, based in Attleboro, Massachusetts, is a supplier of syntactic materials for buoyancy and specialty applications. Since the date of acquisition, the operating results for the CMT business have been included as part of Globe in the A&D segment. The acquisition date fair value of the assets acquired and liabilities assumed primarily were as follows: approximately $1.7 million of accounts receivable, $3.0 million of inventory, $1.3 million of property, plant and equipment, $1.2 million of accounts payable and accrued expenses, and $7.3 million of identifiable intangible assets mainly consisting of customer relationships totaling $6.2 million. The acquired goodwill of $5.6 million related to excess value associated with opportunities to expand the services and products that we can offer to our customers. We anticipate that the goodwill will be deductible for tax purposes. We received a $0.2 million working capital settlement during the third quarter of 2023.

[0001410578-23-002596:notes:82]
2022

[0001410578-23-002596:notes:83]
On November 4, 2021, we acquired Networks Electronic Company, LLC (NEco) for a purchase price of approximately $15.4 million, net of cash acquired. NEco, based in Chatsworth, California, provides miniature electro-explosive devices utilized in mission-critical defense and aerospace applications. Since the date of acquisition, the operating results for the NEco business have been included as part of PTI in the A&D segment. The acquisition date fair value of the assets acquired and liabilities assumed primarily were as follows: approximately $0.6 million of accounts receivable, $1.5 million of inventory, $0.2 million of property, plant and equipment, $0.7 million of accounts payable and accrued expenses, $8.1 million of identifiable intangible assets, mainly consisting of customer relationships totaling $6.3 million. The acquired goodwill of $5.7 million related to excess value associated with opportunities to expand the services and products that we can offer to our customers. We anticipate that the goodwill will be deductible for tax purposes.

[0001410578-23-002596:notes:84]
2021

[0001410578-23-002596:notes:85]
On August 9, 2021 we acquired the assets of Phenix Technologies, Inc. (Phenix), for a purchase price of approximately $47.2 million in cash. Phenix, based in Accident, Maryland, is a leading designer and manufacturer of high voltage, high current, high power test systems and components and solutions supporting the electric utility industry, high voltage test laboratories, and field service organizations worldwide. Since the date of acquisition, the operating results for the Phenix business have been included as part of the USG segment. The acquisition date fair value of the assets acquired and liabilities assumed were as follows: approximately $2.6 million of accounts receivable, $5.8 million of inventory, $8.0 million of property, plant and equipment, $6.2 million of accounts payable and accrued expenses, $3.7 million for tradenames, $9.6 million of customer relationships and $0.5 million of miscellaneous items. The tradename was determined to have an indefinite useful life and the customer relationships were determined to have a useful life of 13 years. The acquired goodwill of $18.7 million relates to excess value associated with opportunities to expand the services and products that we can offer to our customers, with approximately $15 million of goodwill deductible for tax purposes. During the fourth quarter of 2022, we received $4.6 million upon finalization of the working capital adjustment.

[0001410578-23-002596:notes:86]
On July 29, 2021 we acquired I.S.A. – Altanova Group S.r.l., (Altanova), headquartered in Taino, Italy, for a purchase price of approximately $115 million, net of cash acquired. Altanova is a supplier of diagnostic products, monitoring systems and services related to power generation, transmission and distribution networks, renewable energy and storage, and process industries to customers in more than 100 countries. Since the date of acquisition, the operating results for the Altanova business have been included as part of the USG segment. The acquisition date fair value of the assets acquired and liabilities assumed were as follows: $9.7 million of accounts receivable, $5.6 million of inventory, $1.2 million of property, plant and equipment, $9.0 million of other assets, $12.8 million of accounts payable and accrued expenses, $6.9 million of other liabilities, $16.7 million of deferred tax liabilities, $50.5 million of customer relationships and $4.3 million of tradenames. The tradename was determined to have a useful life of ten years and the customer relationships were determined to have a useful life of twenty years. The acquired goodwill of $71.1 million relates to the excess value associated with opportunities to expand the services and products that we can offer to our customers, access to new markets, and synergies anticipated by combining Altanova with existing USG businesses. The goodwill is not deductible for tax purposes.

[0001410578-23-002596:notes:87]
We accounted for these acquisitions using the purchase method of accounting, and accordingly, we allocated the respective purchase prices to the assets (including intangible assets) acquired and liabilities assumed based on estimated fair values at the date of acquisition. We have included the financial results from these acquisitions in our financial statements from the date of acquisition.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001410578-23-002596:notes:88]
3.      Goodwill and Other Intangible Assets

[0001410578-23-002596:notes:89]
Included on the Consolidated Balance Sheets at September 30, 2023 and 2022 are the following intangible assets gross carrying amounts and accumulated amortization:

[0001410578-23-002596:notes:90]
| (Dollars in thousands) |  | 2023 |  | 2022 |
| Goodwill | ​ | $ | 503,177 | ​ | 492,709 |
| Intangible assets with determinable lives: | ​ |  | ​ | ​ | ​ |
| Patents | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 2,516 | ​ | 2,353 |
| Less: accumulated amortization | ​ |  | 1,218 | ​ | 1,091 |
| Net | ​ | $ | 1,298 | ​ | 1,262 |
| Capitalized software | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 121,883 | ​ | 106,583 |
| Less: accumulated amortization | ​ |  | 80,774 | ​ | 70,476 |
| Net | ​ | $ | 41,109 | ​ | 36,107 |
| Customer Relationships | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 296,927 | ​ | 287,447 |
| Less: accumulated amortization | ​ |  | 113,311 | ​ | 96,921 |
| Net | ​ | $ | 183,616 | ​ | 190,526 |
| Other | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 14,232 | ​ | 13,985 |
| Less: accumulated amortization | ​ |  | 9,578 | ​ | 7,440 |
| Net | ​ | $ | 4,654 | ​ | 6,545 |
| Intangible assets with indefinite lives: | ​ |  | ​ | ​ | ​ |
| Trade names | ​ | $ | 161,447 | ​ | 160,024 |

[0001410578-23-002596:notes:91]
We performed our annual evaluation of goodwill and intangible assets for impairment during the fourth quarter of 2023 and concluded that no impairment existed at September 30, 2023. There were no accumulated impairment losses as of September 30, 2023.

[0001410578-23-002596:notes:92]
The changes in the carrying amount of goodwill attributable to each business segment for 2023 and 2022 are as follows:

[0001410578-23-002596:notes:93]
| (Dollars in millions) |  | A&D |  | Test |  | USG |  | Total |
| Balance as of September 30, 2021 | ​ | $ | 104.3 | ​ | ​ | 34.1 | ​ | 366.5 | ​ | 504.9 |
| Acquisition activity | ​ | ​ | 5.7 | ​ | ​ | — | ​ | (4.7) | ​ | 1.0 |
| Foreign currency translation and other | ​ | ​ | — | ​ | ​ | (0.1) | ​ | (13.1) | ​ | (13.2) |
| Balance as of September 30, 2022 | ​ | $ | 110.0 | ​ | ​ | 34.0 | ​ | 348.7 | ​ | 492.7 |
| Acquisition activity | ​ | ​ | 5.6 | ​ | ​ | — | ​ | — | ​ | 5.6 |
| Foreign currency translation and other | ​ | ​ | — | ​ | ​ | — | ​ | 4.9 | ​ | 4.9 |
| Balance as of September 30, 2023 | ​ | $ | 115.6 | ​ | ​ | 34.0 | ​ | 353.6 | ​ | 503.2 |

[0001410578-23-002596:notes:94]
Amortization expense related to intangible assets with determinable lives was $29.0 million, $25.9 million and $20.8 million in 2023, 2022 and 2021, respectively. Patents are amortized over the life of the patents, generally ten to twenty years. Capitalized software is amortized over the estimated useful life of the software, generally three to seven years. Customer relationships are generally amortized over thirteen to twenty years. Intangible asset amortization for fiscal years 2024 through 2027 is estimated at approximately $17 million per year, and approximately $14.5 million in 2028.


## us-gaap:InventoryDisclosureTextBlock

[0001410578-23-002596:notes:95]
4.      Inventories

[0001410578-23-002596:notes:96]
Inventories consisted of the following at September 30, 2023 and 2022:

[0001410578-23-002596:notes:97]
| (Dollars in thousands) |  | 2023 |  | 2022 |
| Finished goods | ​ | $ | 34,577 |  | 32,471 |
| Work in process | ​ |  | 42,178 |  | 38,492 |
| Raw materials | ​ |  | 107,312 |  | 91,440 |
| Total | ​ | $ | 184,067 |  | 162,403 |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001410578-23-002596:notes:98]
5.      Income Tax Expense

[0001410578-23-002596:notes:99]
The components of income before income taxes for 2023, 2022 and 2021 consisted of the following:

[0001410578-23-002596:notes:100]
| (Dollars in thousands) |  | 2023 |  | 2022 |  | 2021 |
| United States | ​ | $ | 98,983 |  | 90,674 |  | 70,214 |
| Foreign | ​ |  | 19,964 |  | 15,761 |  | 10,457 |
| Total income before income taxes | ​ | $ | 118,947 |  | 106,435 |  | 80,671 |

[0001410578-23-002596:notes:101]
The principal components of income tax expense (benefit) for 2023, 2022 and 2021 consist of:

[0001410578-23-002596:notes:102]
| (Dollars in thousands) |  | 2023 |  | 2022 |  | 2021 |
| Federal: |  | ​ |  |  |  |  |  |
| Current | ​ | $ | 24,192 |  | 7,248 |  | 14,807 |
| Deferred | ​ |  | (5,816) |  | 9,752 |  | (1,598) |
| State and local: | ​ |  | ​ |  | ​ |  | ​ |
| Current | ​ |  | 3,563 |  | 1,635 |  | 2,257 |
| Deferred | ​ |  | (1,038) |  | 1,774 |  | (786) |
| Foreign: | ​ |  | ​ |  | ​ |  | ​ |
| Current | ​ |  | 5,694 |  | 4,645 |  | 2,922 |
| Deferred | ​ |  | (193) |  | (939) |  | (427) |
| Total | ​ | $ | 26,402 |  | 24,115 |  | 17,175 |

[0001410578-23-002596:notes:103]
The actual income tax expense for 2023, 2022 and 2021 differs from the expected tax expense for those years (computed by applying the U.S. Federal corporate statutory rate) as follows:

[0001410578-23-002596:notes:104]
| ​ |  | 2023 |  | 2022 |  | 2021 |  |
| Federal corporate statutory rate |  | 21.0 | % | 21.0 | % | 21.0 | % |
| State and local, net of Federal benefits | ​ | 2.1 |  | 2.9 |  | 1.9 | ​ |
| Impact of foreign operations | ​ | 0.3 | ​ | (0.3) | ​ | (0.4) | ​ |
| Federal research credit | ​ | (1.1) | ​ | (0.3) | ​ | (0.9) | ​ |
| Executive compensation | ​ | 0.9 |  | 0.5 |  | 0.9 | ​ |
| Valuation allowance | ​ | 0.3 |  | (0.3) |  | — | ​ |
| U.S. tax on GILTI | ​ | 1.2 | ​ | 1.8 | ​ | 1.0 | ​ |
| GILTI foreign tax credits | ​ | (0.9) | ​ | (1.5) | ​ | (0.6) | ​ |
| FDII deduction | ​ | (1.6) | ​ | (0.9) | ​ | (1.7) | ​ |
| Other, net | ​ | — |  | (0.2) |  | 0.1 | ​ |
| Effective income tax rate | ​ | 22.2 | % | 22.7 | % | 21.3 | % |

[0001410578-23-002596:notes:105]
The tax effects of temporary differences that give rise to significant portions of the deferred tax assets and liabilities at September 30, 2023 and 2022 are presented below:

[0001410578-23-002596:notes:106]
| (Dollars in thousands) |  | 2023 |  | 2022 |
| Deferred tax assets: |  | ​ |  |  |  |
| Inventories | ​ | $ | 5,457 |  | 4,990 |
| Pension and other postretirement benefits | ​ |  | 658 |  | 664 |
| Capitalized research and development expenditures | ​ | ​ | 4,114 | ​ | — |
| Lease liabilities | ​ | ​ | 9,822 | ​ | 7,073 |
| Net operating and capital loss carryforwards — domestic | ​ |  | 553 |  | 575 |
| Net operating loss carryforward — foreign | ​ |  | 3,714 |  | 3,396 |
| Other compensation-related costs and other cost accruals | ​ |  | 8,691 |  | 9,093 |
| State credit carryforward | ​ |  | 2,249 |  | 1,676 |
| Foreign credit carryforward | ​ | ​ | — | ​ | 203 |
| Total deferred tax assets | ​ |  | 35,258 |  | 27,670 |
| Deferred tax liabilities: | ​ |  | ​ |  | ​ |
| ROU assets | ​ | ​ | (9,822) | ​ | (7,073) |
| Goodwill | ​ |  | (13,313) |  | (11,691) |
| Acquisition intangible assets | ​ |  | (61,187) |  | (62,051) |
| Depreciation, software amortization | ​ |  | (21,772) |  | (24,503) |
| Net deferred tax liabilities before valuation allowance | ​ |  | (70,836) |  | (77,648) |
| Less valuation allowance | ​ |  | (1,772) |  | (1,208) |
| Net deferred tax liabilities | ​ | $ | (72,608) |  | (78,856) |

[0001410578-23-002596:notes:107]
We had a foreign net operating loss (NOL) carryforward of $13.2 million at September 30, 2023, which reflects tax loss carryforwards in Germany, South Africa, Canada, Japan, India and the United Kingdom. Approximately $11.1 million of the tax loss carryforwards have no expiration date while the remaining $2.1 million will expire between 2030 and 2042.We had deferred tax assets related to state NOL carryforwards of $0.6 million at September 30, 2023 which expire between 2025 and 2043. We also had state research and other credit carryforwards of $2.2 million of which $0.8 million expires between 2036 and 2038. The remaining $1.4 million does not have an expiration date.

[0001410578-23-002596:notes:108]
The valuation allowance for deferred tax assets as of September 30, 2023 and 2022 was $1.8 million and $1.2 million, respectively. The net change in the total valuation allowance for each of the years ended September 30, 2023 and 2022 was an increase of $0.6 million and a decrease of $0.8 million, respectively. In addition, we maintained a valuation allowance against state NOL carryforwards that are not expected to be realized in future periods of $0.5 million at September 30 of both 2023 and 2022. Lastly, we recorded a valuation allowance against foreign deferred tax assets of $0.6 million in the year ended September 30, 2023, which resulted in a valuation allowance against foreign deferred assets which may not be realized in future periods of $1.3 million and $0.7 million at September 30, 2023 and 2022, respectively.

[0001410578-23-002596:notes:109]
As of September 30, 2023, the Company does not have any material unrecognized tax benefits.


## us-gaap:DebtDisclosureTextBlock

[0001410578-23-002596:notes:110]
6.      Debt

[0001410578-23-002596:notes:111]
Debt consists of the following at September 30, 2023 and 2022:

[0001410578-23-002596:notes:112]
| (Dollars in thousands) |  | 2023 |  | 2022 |
| Total borrowings | ​ | $ | 102,000 |  | 153,000 |
| Current portion of long-term debt and short-term borrowings | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 82,000 |  | 133,000 |

[0001410578-23-002596:notes:113]
On August 30, 2023, the Company entered into a new five-year credit facility (“the Credit Facility"), replacing its previous credit facility which would have matured September 27, 2024. The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of seven banks led by JP Morgan Chase Bank, N.A., as administrative agent, Bank of America, N.A., as syndication agent, and Commerce Bank and TD Bank, N.A. as co-documentation agents. The Credit Facility matures August 30, 2028, with balance due by this date.

[0001410578-23-002596:notes:114]
Interest on borrowings under the Credit Facility is calculated at a spread over either an Adjusted Term SOFR Rate, Adjusted EURIBOR Rate, Adjusted CDOR Rate, Alternate Base Rate or Daily Simple RFR, at the Company’s election. The Credit Facility also requires a facility fee ranging from 12.5 to 25 basis points per annum on the unused portion. The interest rate spreads and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio.

[0001410578-23-002596:notes:115]
The Credit Facility is secured by the unlimited guaranty of our direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of our direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. As of September 30, 2023, we were in compliance with all covenants.

[0001410578-23-002596:notes:116]
At September 30, 2023, we had approximately $390 million available to borrow under the Credit Facility, plus the $250 million increase option subject to the lenders’ consent, in addition to $41.9 million cash on hand. We classified $20 million as the current portion of long-term debt as of September 30, 2023, as we intend to repay this amount within the next twelve months; however, we have no contractual obligation to repay such amount during the next twelve months.

[0001410578-23-002596:notes:117]
During 2023 and 2022, our maximum aggregate short-term borrowings at any month-end were $161 million and $208 million, respectively, and the average aggregate short-term borrowings outstanding based on month-end balances were $140.3 million and $189.8 million, respectively. The weighted average interest rates were 5.82% and 2.11% for 2023 and 2022, respectively. As of September 30, 2023, the interest rate on our debt was 6.81%. The letters of credit issued and outstanding under the Credit Facility totaled $8.3 million and $8.0 million at September 30, 2023 and 2022, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001410578-23-002596:notes:118]
7.      Capital Stock

[0001410578-23-002596:notes:119]
The 30,781,699 and 30,707,748 common shares as presented in the accompanying Consolidated Balance Sheets at September 30, 2023 and 2022 represent the actual number of shares issued at the respective dates. We held 4,995,414 and 4,854,997 common shares in treasury at September 30, 2023 and 2022, respectively.

[0001410578-23-002596:notes:120]
In August 2021, our Board of Directors approved a new common stock repurchase program authorizing us to repurchase shares of our stock from time to time in Management’s discretion, in the open market or otherwise, up to a maximum total repurchase amount of $200 million (or the maximum amount permitted under our bank credit agreements, if less). This program is scheduled to expire September 30, 2024. Under this program we repurchased approximately 140,000 shares in 2023 at an aggregate cost of $12.4 million and approximately 257,500 shares in 2022 at an aggregate cost of $20.0 million. We did not repurchase any shares in 2021.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001410578-23-002596:notes:121]
8.      Share-Based Compensation

[0001410578-23-002596:notes:122]
We provide compensation benefits to certain key employees under several share-based plans providing for performance-accelerated and/or time-vested restricted stock unit awards, and to non-employee directors under a separate compensation plan for non-employee directors. As of September 30, 2023, our equity compensation plans had a total of 1,033,413 shares authorized and available for future issuance.

[0001410578-23-002596:notes:123]
Performance-Accelerated Restricted Stock Unit (PARS) Awards, Time-Vested Restricted Stock Unit (RSU) Awards, and Performance Share Unit (PSU) Awards

[0001410578-23-002596:notes:124]
A PARS award represents the right to receive a specified number of shares of Company common stock if and when the award vests. A PARS award is not stock and does not give the recipient any rights as a shareholder until it vests and is paid out in shares of stock. PARS awards currently outstanding have a five-year vesting period, with accelerated vesting if certain targets based on market conditions are achieved. In these cases, if it is probable that the performance condition will be met, the Company recognizes compensation cost on a straight-line basis over the shorter performance period; otherwise, it will recognize compensation cost over the longer service period. Compensation cost for the outstanding PARS awards is being recognized over the shorter performance period, as it is probable the performance condition will be met. The PARS award grants were valued at the stock price on the date of grant.

[0001410578-23-002596:notes:125]
The terms of the RSU awards are similar to those of the PARS awards, but without any provision for acceleration of the vesting date. Each RSU represents the right to receive one share of Company common stock if the recipient remains continuously employed by the Company until the award vests, normally 3 ½ years after the effective award date. The RSU award grants were valued at the stock price on the date of grant.

[0001410578-23-002596:notes:126]
Beginning in fiscal 2022, the Company granted PSU awards with a three-year vesting period, with each PSU representing the right to receive one share of Company common stock if certain performance targets are achieved. The targets are based on achieving certain EBITDA metrics and a Total Shareholder return (rTSR) metric over a three-year period. In fiscal 2023, the Company granted PSU awards with a three-year vesting period, with performance targets based on achieving certain EBITDA and Return on Invested Capital (ROIC) metrics and utilizing a rTSR modifier.

[0001410578-23-002596:notes:127]
Pretax compensation expense related to the above awards was $7.6 million, $6.1 million and $5.6 million for 2023, 2022 and 2021, respectively.

[0001410578-23-002596:notes:128]
The following summary presents information regarding outstanding share-based compensation awards as of the specified dates, and changes during the specified periods:

[0001410578-23-002596:notes:129]
| ​ | ​ | FY 2023 | ​ | FY 2022 | ​ | FY 2021 |
| ​ |  | ​ |  | Estimated |  | ​ |  | Estimated |  | ​ |  | Estimated |
| ​ | ​ | ​ | ​ | Weighted | ​ | ​ | ​ | Weighted | ​ | ​ | ​ | Weighted |
| ​ | ​ | Shares | ​ | Avg. Price | ​ | Shares | ​ | Avg. Price | ​ | Shares | ​ | Avg. Price |
| Nonvested at October 1, |  | 265,367 | ​ | $ | 84.29 |  | 226,705 | ​ | $ | 76.15 |  | 220,300 | ​ | $ | 66.55 |
| Granted |  | 84,880 | ​ |  | 93.64 |  | 117,045 | ​ |  | 82.54 |  | 51,476 | ​ |  | 108.05 |
| Vested |  | (119,811) | ​ |  | 82.28 |  | (75,327) | ​ |  | 56.87 |  | (35,753) | ​ |  | 64.40 |
| Cancelled |  | (40,711) | ​ |  | 85.00 |  | (3,056) | ​ |  | 89.51 |  | (9,318) | ​ |  | 70.50 |
| Nonvested at September 30, |  | 189,725 | ​ | $ | 94.91 |  | 265,367 | ​ | $ | 84.29 |  | 226,705 | ​ | $ | 76.15 |

[0001410578-23-002596:notes:130]
Compensation Plan for Non-Employee Directors

[0001410578-23-002596:notes:131]
In addition to an annual cash retainer, we provide each non-employee director with an annual equity award having a grant date market value of $180,000, based on the NYSE closing price of the Company’s stock on the date of grant. The award is in the form of Restricted Stock Units, each of which represents the right to receive one share of Company stock at the end of a one-year vesting period. At the end of the vesting period, each award will be converted into the right to receive the same number of actual shares of common stock, plus additional shares representing the value of the quarterly dividends which would have accrued on the underlying shares during the vesting period. Compensation expense related to the non-employee director grants was $1.3 million, $1.2 million and $1.3 million for 2023, 2022 and 2021, respectively.

[0001410578-23-002596:notes:132]
Total Share-Based Compensation

[0001410578-23-002596:notes:133]
The total share-based compensation cost that has been recognized in results of operations and included within SG&A was $8.9 million, $7.3 million and $6.9 million for 2023, 2022 and 2021, respectively. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $1.3 million, $1.5 million and $1.4 million for 2023, 2022 and 2021, respectively. As of September 30, 2023, there was $9.0 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a weighted-average period of 1.5 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001410578-23-002596:notes:134]
9.      Business Segment Information

[0001410578-23-002596:notes:135]
We are organized based on the products and services we offer, and we classify our continuing business operations in three reportable segments for financial reporting purposes:  Aerospace & Defense (A&D), Utility Solutions Group (USG) and RF Test & Measurement, formerly called RF Shielding and Test (Test). In addition, for reporting certain financial information we treat Corporate activities as a separate segment.

[0001410578-23-002596:notes:136]
The A&D segment’s operations consist of PTI Technologies Inc. (PTI), VACCO Industries (VACCO), Crissair, Inc. (Crissair), Globe Composite Solutions, LLC (Globe), Westland Technologies, Inc. (Westland), and Mayday Manufacturing Co. (Mayday). The companies within this segment primarily design and manufacture specialty filtration, fluid control and naval products, including hydraulic filter elements and fluid control devices used in aerospace and defense applications, unique filter mechanisms used in micro-propulsion devices for satellites, custom designed filters for manned aircraft and submarines, products and systems to reduce vibration and/or acoustic signatures and otherwise reduce or obscure a vessel’s signature, and other communications, sealing, surface control and hydrodynamic related applications to enhance U.S. Navy maritime survivability; precision-tolerance machined components for the aerospace and defense industry; metal processing services; and miniature electro-explosive devices utilized in mission-critical defense and aerospace applications.

[0001410578-23-002596:notes:137]
The USG segment’s operations consist of Doble Engineering Company and related subsidiaries including Morgan Schaffer and Altanova (collectively, Doble), and NRG Systems, Inc. (NRG). Doble is an industry leader in the development, manufacture and delivery of diagnostic testing and data management solutions that enable electric power grid operators to assess the integrity of high-voltage power delivery equipment. It combines three core elements for customers – diagnostic test and condition monitoring instruments, expert consulting, and testing services – and provides access to its large reserve of related empirical knowledge. NRG is a global market leader in the design and manufacture of decision support tools for the renewable energy industry, primarily wind and solar. The acquisition of Altanova not only complements our existing products and services but its strong market presence in Europe and Asia provides a significant international platform for our USG segment.

[0001410578-23-002596:notes:138]
The Test segment’s operations consist of ETS-Lindgren Inc. and related subsidiaries (ETS-Lindgren). ETS-Lindgren is an industry leader in designing and manufacturing products and systems to measure and control RF and acoustic energy. It serves the acoustics, medical, health and safety, electronics, wireless communications, automotive and defense markets, supplying a broad range of turnkey systems, including RF test facilities and measurement systems, acoustic test enclosures, RF and magnetically shielded rooms, and secure communication facilities, and providing the design, program management, installation and integration services required to successfully complete these types of facilities. It also supplies a broad range of components including RF absorptive materials, filters, antennas, field probes, test cells, proprietary measurement software and other test accessories required to perform a variety of tests and measurements, and offers a variety of services including calibration and product tests.

[0001410578-23-002596:notes:139]
Accounting policies of the segments are the same as those described in the summary of significant accounting policies in Note 1 to the Consolidated Financial Statements. The operating units within each reporting segment have been aggregated because of similar economic characteristics and meet the other aggregation criteria of FASB ASC 280.

[0001410578-23-002596:notes:140]
We evaluate the performance of our operating units based on EBIT, which is defined as earnings before interest and taxes. EBIT on a consolidated basis is a non-GAAP financial measure. Intersegment sales and transfers are not significant. Segment assets consist primarily of customer receivables, inventories, capitalized software and fixed assets directly associated with the production processes of the segment. Segment depreciation and amortization is based upon the direct assets listed above.

[0001410578-23-002596:notes:141]
Net Sales

[0001410578-23-002596:notes:142]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2023 |  | 2022 |  | 2021 |
| A&D | ​ | $ | 392.4 |  | 351.4 |  | 314.8 |
| USG | ​ | ​ | 342.3 | ​ | 278.4 | ​ | 202.9 |
| Test | ​ |  | 221.3 |  | 227.7 |  | 197.7 |
| Consolidated totals | ​ | $ | 956.0 |  | 857.5 |  | 715.4 |

[0001410578-23-002596:notes:143]
No customer exceeded 10% of consolidated sales in 2023, 2022 or 2021.

[0001410578-23-002596:notes:144]
EBIT

[0001410578-23-002596:notes:145]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2023 |  | 2022 |  | 2021 |
| A&D | ​ | $ | 71.6 |  | 68.4 |  | 56.5 |
| USG | ​ | ​ | 76.7 | ​ | 57.6 | ​ | 40.9 |
| Test | ​ |  | 32.4 |  | 32.6 |  | 27.6 |
| Reconciliation to consolidated totals (Corporate) | ​ |  | (53.0) |  | (47.3) |  | (42.1) |
| Consolidated EBIT | ​ |  | 127.7 |  | 111.3 |  | 82.9 |
| Less: interest expense | ​ |  | (8.8) |  | (4.9) |  | (2.2) |
| Earnings before income tax | ​ | $ | 118.9 |  | 106.4 |  | 80.7 |

[0001410578-23-002596:notes:146]
Identifiable Assets

[0001410578-23-002596:notes:147]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2023 |  | 2022 |
| A&D | ​ | $ | 354.7 |  | 295.2 |
| USG | ​ | ​ | 254.9 | ​ | 220.0 |
| Test | ​ |  | 167.6 |  | 174.6 |
| Corporate | ​ |  | 906.0 |  | 964.7 |
| Consolidated totals | ​ | $ | 1,683.2 |  | 1,654.5 |

[0001410578-23-002596:notes:148]
Corporate consists primarily of deferred taxes, acquired intangible assets including goodwill and cash balances.

[0001410578-23-002596:notes:149]
Capital Expenditures

[0001410578-23-002596:notes:150]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2023 |  | 2022 |  | 2021 |
| A&D | ​ | $ | 12.9 |  | 9.4 |  | 10.4 |
| USG | ​ | ​ | 4.9 | ​ | 14.4 | ​ | 11.6 |
| Test | ​ |  | 4.5 |  | 8.3 |  | 4.7 |
| Corporate | ​ |  | 0.1 |  | — |  | — |
| Consolidated totals | ​ | $ | 22.4 |  | 32.1 |  | 26.7 |

[0001410578-23-002596:notes:151]
In addition to the above amounts, we incurred expenditures for capitalized software of $12.4 million, $12.9 million and $8.8 million in 2023, 2022 and 2021, respectively.

[0001410578-23-002596:notes:152]
Depreciation and Amortization

[0001410578-23-002596:notes:153]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2023 |  | 2022 |  | 2021 |
| A&D | ​ | $ | 12.6 |  | 11.1 |  | 10.4 |
| USG | ​ | ​ | 14.0 | ​ | 12.6 | ​ | 13.5 |
| Test | ​ |  | 5.3 |  | 5.4 |  | 5.2 |
| Corporate | ​ |  | 18.6 |  | 19.2 |  | 12.9 |
| Consolidated totals | ​ | $ | 50.5 |  | 48.3 |  | 42.0 |

[0001410578-23-002596:notes:154]
Depreciation expense of property, plant and equipment was $21.6 million, $22.4 million and $21.2 million for 2023, 2022 and 2021, respectively.

[0001410578-23-002596:notes:155]
Geographic Information

[0001410578-23-002596:notes:156]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2023 |  | 2022 |  | 2021 |
| United States | ​ | $ | 665.4 |  | 603.2 |  | 517.0 |
| Asia | ​ |  | 116.3 |  | 132.7 |  | 104.7 |
| Europe | ​ |  | 90.4 |  | 72.4 |  | 53.5 |
| Canada | ​ |  | 46.8 |  | 31.2 |  | 27.0 |
| Other | ​ |  | 37.1 |  | 18.0 |  | 13.2 |
| Consolidated totals | ​ | $ | 956.0 |  | 857.5 |  | 715.4 |

[0001410578-23-002596:notes:157]
Long-Lived Assets

[0001410578-23-002596:notes:158]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2023 |  | 2022 |
| United States | ​ | $ | 141.9 |  | 141.5 |
| Canada | ​ | ​ | 4.3 | ​ | 4.9 |
| Mexico | ​ |  | 2.4 |  | 5.8 |
| Other | ​ |  | 6.9 |  | 3.8 |
| Consolidated totals | ​ | $ | 155.5 |  | 156.0 |

[0001410578-23-002596:notes:159]
We attribute net sales to countries based on the location of the customer. We attribute long-lived assets to countries based on the location of the asset.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001410578-23-002596:notes:160]
10.      Commitments and Contingencies

[0001410578-23-002596:notes:161]
At September 30, 2023, we had $8.3 million in letters of credit outstanding as guarantees of contract performance and cash amounts that exceeded federally insured amounts. As a normal incident of the businesses in which we are engaged, various claims, charges and litigation are asserted or commenced from time to time against us. Additionally, we are currently involved in various stages of investigation and remediation relating to environmental matters. It is the opinion of Management that the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against us are adequately accrued, are covered by insurance or are not likely to have a material adverse effect on our financial results as the estimated exposure to loss is not material.


## ese:OperatingAndFinancingLeasesOfLesseeDisclosureTextBlock

[0001410578-23-002596:notes:162]
11.      Leases

[0001410578-23-002596:notes:163]
We record our leases in accordance with ASC 842, Leases. We determine at lease inception whether an arrangement that provides control over the use of an asset is a lease. We recognize at lease commencement a right-of-use (ROU) asset and lease liability based on the present value of the future lease payments over the lease term (including anticipated renewals). We have elected not to recognize a ROU asset and lease liability for leases with terms of 12 months or less. Certain of our leases include options to extend the term of the lease for up to 20 years. When it is reasonably certain that we will exercise the option, Management includes the impact of

[0001410578-23-002596:notes:164]
the option in the lease term for purposes of determining total future lease payments. As most of our lease agreements do not explicitly state the discount rate implicit in the lease, Management uses our incremental borrowing rate on the commencement date to calculate the present value of future payments based on the tenor of each arrangement.

[0001410578-23-002596:notes:165]
Our leases for real estate commonly include escalating payments. We include these variable lease payments in the calculation of our ROU asset and lease liability. In addition to the present value of the future lease payments, the calculation of the ROU asset also includes any deferred rent, lease pre-payments and initial direct costs of obtaining the lease.

[0001410578-23-002596:notes:166]
In addition to the base rent, real estate leases typically contain provisions for common-area maintenance and other similar services, which are considered non-lease components for accounting purposes. Non-lease components are excluded from our ROU assets and lease liabilities and expensed as incurred.

[0001410578-23-002596:notes:167]
Our leases are for office space, manufacturing facilities, and machinery and equipment.

[0001410578-23-002596:notes:168]
The components of lease costs are shown below:

[0001410578-23-002596:notes:169]
| ​ | ​ | Year Ended |  | Year Ended |
| ​ | ​ | September 30, | ​ | September 30, |
| (Dollars in thousands) |  | 2023 |  | 2022 |
| Finance lease cost: |  | ​ |  | ​ | ​ | ​ |
| Amortization | ​ | $ | 1,572 | ​ | ​ | 1,572 |
| Interest on lease liabilities | ​ |  | 925 | ​ | ​ | 973 |
| Operating lease cost | ​ |  | 7,224 | ​ | ​ | 6,347 |
| Total lease cost | ​ | $ | 9,721 | ​ | ​ | 8,892 |

[0001410578-23-002596:notes:170]
Additional information related to leases is shown below:

[0001410578-23-002596:notes:171]
| ​ |  | Year Ended |  | Year Ended |  |
| ​ | ​ | September 30, | ​ | September 30, | ​ |
| (Dollars in thousands) | ​ | 2023 | ​ | 2022 | ​ |
| Cash paid for amounts included in the measurement of lease liabilities: | ​ | ​ | ​ |  | ​ |  |  |
| Operating cash flows from operating leases | ​ | $ | 6,964 | ​ | ​ | 6,101 |  |
| Operating cash flows from finance leases | ​ | ​ | 925 | ​ | ​ | 973 |  |
| Financing cash flows from finance leases | ​ | ​ | 1,331 | ​ | ​ | 1,224 |  |
| Right-of-use assets obtained in exchange for operating lease liabilities | ​ | $ | 16,243 | ​ | ​ | 4,160 |  |
| Weighted-average remaining lease term: | ​ | ​ | ​ | ​ |  | ​ |  |
| Operating leases | ​ | ​ | 11.1 | yrs |  | 9.3 | yrs |
| Finance leases | ​ | ​ | 11.1 | yrs |  | 12.0 | yrs |
| Weighted-average discount rate: | ​ | ​ | ​ | ​ |  | ​ |  |
| Operating leases | ​ | ​ | 4.5 | % |  | 3.2 | % |
| Finance leases | ​ | ​ | 4.6 | % |  | 4.6 | % |

[0001410578-23-002596:notes:172]
The table below is a reconciliation of future undiscounted cash flows to the operating and finance lease liabilities, and the related ROU assets, presented on our Consolidated Balance Sheet on September 30, 2023:

[0001410578-23-002596:notes:173]
| (Dollars in thousands) | ​ | Operating | ​ | Finance |
| Years Ending September 30: |  | Leases |  | Leases |
| 2024 | ​ | $ | 6,826 | ​ | ​ | 2,315 |
| 2025 | ​ |  | 5,645 | ​ | ​ | 2,370 |
| 2026 | ​ |  | 4,436 | ​ | ​ | 2,434 |
| 2027 | ​ |  | 4,229 | ​ | ​ | 2,494 |
| 2028 and thereafter | ​ |  | 32,806 | ​ | ​ | 16,503 |
| Total minimum lease payments | ​ | ​ | 53,942 | ​ | ​ | 26,116 |
| Less: amounts representing interest | ​ |  | 12,262 | ​ | ​ | 6,265 |
| Present value of net minimum lease payments | ​ | $ | 41,680 | ​ | ​ | 19,851 |
| Less: current portion of lease obligations | ​ |  | 5,126 | ​ | ​ | 1,444 |
| Non-current portion of lease obligations | ​ | ​ | 36,554 | ​ | ​ | 18,407 |
| ROU assets | ​ | $ | 39,839 | ​ | ​ | 15,771 |

[0001410578-23-002596:notes:174]
The table below is a reconciliation of future undiscounted cash flows to the operating and finance lease liabilities, and the related ROU assets, presented on our Consolidated Balance Sheet on September 30, 2022:

[0001410578-23-002596:notes:175]
| (Dollars in thousands) |  | Operating |  | Finance |
| Years Ending September 30: | ​ | Leases | ​ | Leases |
| 2023 | ​ | $ | 5,953 |  | 2,256 |
| 2024 | ​ |  | 5,132 |  | 2,315 |
| 2025 | ​ |  | 3,790 |  | 2,370 |
| 2026 | ​ |  | 2,881 |  | 2,434 |
| 2027 and thereafter | ​ |  | 17,029 |  | 18,997 |
| Total minimum lease payments | ​ | ​ | 34,785 |  | 28,372 |
| Less: amounts representing interest | ​ |  | 4,760 |  | 7,189 |
| Present value of net minimum lease payments | ​ | $ | 30,025 |  | 21,183 |
| Less: current portion of lease obligations | ​ |  | 5,172 |  | 1,331 |
| Non-current portion of lease obligations | ​ |  | 24,853 |  | 19,852 |
| ROU assets | ​ | $ | 29,150 | ​ | 17,343 |

[0001410578-23-002596:notes:176]
We include operating and finance lease liabilities in the Consolidated Balance Sheet in accrued other expenses (current portion) and other liabilities (long-term portion). We include operating lease ROU assets as a caption on the Consolidated Balance Sheet and include finance lease ROU assets in Property, plant and equipment on the Consolidated Balance Sheet.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001410578-23-002596:notes:177]
12.     Revenues

[0001410578-23-002596:notes:178]
| (a) | Disaggregation of Revenues |

[0001410578-23-002596:notes:179]
The tables below present our revenues by customer type, geographic location, and revenue recognition method for the years ended September 30, 2023 and 2022, as we believe this presentation best depicts how the nature, amount, timing and uncertainty of net sales

[0001410578-23-002596:notes:180]
and cash flows are affected by economic factors. The tables also include a reconciliation of the disaggregated revenue within our reportable segments.

[0001410578-23-002596:notes:181]
| Year Ended September 30, 2023 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 178,447 | ​ |  | 331,836 | ​ |  | 193,744 | ​ |  | 704,027 |
| Government | ​ | ​ | 213,996 | ​ | ​ | 10,484 | ​ | ​ | 27,526 | ​ | ​ | 252,006 |
| Total revenues | ​ | $ | 392,443 | ​ | ​ | 342,320 | ​ | ​ | 221,270 | ​ | ​ | 956,033 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 326,566 | ​ |  | 220,536 | ​ |  | 118,289 | ​ |  | 665,391 |
| International | ​ | ​ | 65,877 | ​ | ​ | 121,784 | ​ | ​ | 102,981 | ​ | ​ | 290,642 |
| Total revenues | ​ | $ | 392,443 | ​ | ​ | 342,320 | ​ | ​ | 221,270 | ​ | ​ | 956,033 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 178,222 | ​ |  | 281,977 | ​ |  | 44,042 | ​ |  | 504,241 |
| Over time | ​ | ​ | 214,221 | ​ | ​ | 60,343 | ​ | ​ | 177,228 | ​ | ​ | 451,792 |
| Total revenues | ​ | $ | 392,443 | ​ | ​ | 342,320 | ​ | ​ | 221,270 | ​ | ​ | 956,033 |

[0001410578-23-002596:notes:182]
| Year Ended September 30, 2022 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 144,305 | ​ | ​ | 272,432 | ​ | ​ | 209,016 | ​ | ​ | 625,753 |
| Government | ​ |  | 207,108 | ​ |  | 5,935 | ​ |  | 18,706 | ​ |  | 231,749 |
| Total revenues | ​ | $ | 351,413 | ​ | ​ | 278,367 | ​ | ​ | 227,722 | ​ | ​ | 857,502 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 299,158 | ​ | ​ | 180,586 | ​ | ​ | 123,428 | ​ | ​ | 603,172 |
| International | ​ |  | 52,255 | ​ |  | 97,781 | ​ |  | 104,294 | ​ |  | 254,330 |
| Total revenues | ​ | $ | 351,413 | ​ | ​ | 278,367 | ​ | ​ | 227,722 | ​ | ​ | 857,502 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 144,039 | ​ | ​ | 226,418 | ​ | ​ | 58,522 | ​ | ​ | 428,979 |
| Over time | ​ |  | 207,374 | ​ |  | 51,949 | ​ |  | 169,200 | ​ |  | 428,523 |
| Total revenues | ​ | $ | 351,413 | ​ | ​ | 278,367 | ​ | ​ | 227,722 | ​ | ​ | 857,502 |

[0001410578-23-002596:notes:183]
| (b) | Remaining Performance Obligations |

[0001410578-23-002596:notes:184]
Remaining performance obligations represent the aggregate transaction price allocated to performance obligations which are fully or partially unsatisfied at the end of the period. Remaining performance obligations include noncancelable purchase orders and other long-term contracts. At September 30, 2023, we had approximately $360 million in remaining performance obligations for contracts with an original duration of greater than one year which we expect approximately 80% to be recognized as revenues in the next twenty-four months and approximately 20% thereafter.

[0001410578-23-002596:notes:185]
| (c) | Contract assets, contract liabilities and accounts receivable |

[0001410578-23-002596:notes:186]
We report assets and liabilities related to our contracts with customers on a contract-by-contract basis at the end of each reporting period. At September 30, 2023, our contract assets, contract liabilities and accounts receivable totaled $138.6 million, $123.1 million and $198.6 million, respectively. At September 30, 2022, our contract assets, contract liabilities and accounts receivable totaled $125.2 million, $137.6 million and $164.6 million, respectively. At September 30, 2021, our contract assets, contract liabilities and accounts receivable totaled $93.8 million, $108.8 million and $146.3 million, respectively. During 2023, we recognized approximately $80 million in revenues that were included in the contract liabilities balance at September 30, 2022.


## us-gaap:SubsequentEventsTextBlock

[0001410578-23-002596:notes:187]
13.     Subsequent Event

[0001410578-23-002596:notes:188]
On November 9, 2023, the Company acquired MPE Limited (MPE), based in the United Kingdom, for a purchase price of approximately $57 million. MPE is a leading global manufacturer of high-performance EMC/EMP filters and capacitor products for military, utility, telecommunication, and other critical infrastructure applications. The business will become part of our Test segment. Given the timing of the acquisition, the preliminary estimate of the purchase price indicates that the majority of the purchase price will be allocated to customer relationships and goodwill.
