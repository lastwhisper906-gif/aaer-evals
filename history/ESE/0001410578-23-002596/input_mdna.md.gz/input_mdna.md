# ESE MD&A — 0001410578-23-002596


## mdna

[0001410578-23-002596:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001410578-23-002596:mdna:2]
The following discussion should be read in conjunction with the Consolidated Financial Statements and Notes thereto and refers to our results from continuing operations except where noted.

[0001410578-23-002596:mdna:3]
Selected financial information for each of our business segments is provided in the discussion below and in Note 9 to the Company’s Consolidated Financial Statements.

[0001410578-23-002596:mdna:4]
This section includes comparisons of certain 2023 financial information to the same information for 2022. Year-to-year comparisons of the 2022 financial information to the same information for 2021 are contained in Item 7 of our Form 10-K for 2022 filed with the Securities and Exchange Commission on November 29, 2022 and available through the SEC’s website at https://www.sec.gov/edgar/searchedgar/companysearch.html.

[0001410578-23-002596:mdna:5]
Introduction

[0001410578-23-002596:mdna:6]
We classify our business operations into three segments for financial reporting purposes, although for reporting certain financial information we treat Corporate activities as a separate segment. Our three operating segments during 2023 were Aerospace & Defense (A&D), Utility Solutions Group (USG), and RF Test & Measurement, formerly called RF Shielding and Test (Test). Our operating segments are comprised of the following primary operating subsidiaries:

[0001410578-23-002596:mdna:7]
|  | ● | A&D: PTI Technologies Inc. (PTI); VACCO Industries (VACCO); Crissair, Inc. (Crissair); Globe Composite Solutions, LLC (Globe); Westland Technologies, Inc. (Westland); and Mayday Manufacturing Co. (Mayday);. |

[0001410578-23-002596:mdna:8]
|  | ● | USG: Doble Engineering Company; I.S.A. – Altanova Group S.r.l. and affiliates (Altanova); Morgan Schaffer Ltd. and Phenix Technologies (Phenix) (collectively, Doble); and NRG Systems, Inc. (NRG). |

[0001410578-23-002596:mdna:9]
|  | ● | Test: ETS-Lindgren Inc. (ETS-Lindgren). |

[0001410578-23-002596:mdna:10]
A&D. PTI, VACCO and Crissair primarily design and manufacture specialty filtration products, including hydraulic filter elements and fluid control devices used in commercial and defense aerospace applications, unique filter mechanisms used in micro-propulsion devices for satellites and custom designed filters for manned aircraft and submarines. Globe and Westland design, develop and manufacture elastomeric-based signature reduction solutions for U.S. naval vessels. Mayday designs and manufactures mission-critical bushings, pins, sleeves and precision-tolerance machined components for landing gear, rotor heads, engine mounts, flight controls, and actuation systems for the aerospace and defense industries.

[0001410578-23-002596:mdna:11]
USG.  Doble develops, manufactures and delivers diagnostic testing solutions that enable electric power grid operators to assess the integrity of high-voltage power delivery equipment. NRG designs and manufactures decision support tools for the renewable energy industry, primarily wind and solar.

[0001410578-23-002596:mdna:12]
Test.  ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and control magnetic, electromagnetic and acoustic energy.

[0001410578-23-002596:mdna:13]
We continue to operate with meaningful growth prospects in our primary served markets and with considerable financial flexibility. We continue to focus on new products that incorporate proprietary design and process technologies. Our Management is committed to delivering shareholder value through organic growth, ongoing performance improvement initiatives, and acquisitions.

[0001410578-23-002596:mdna:14]
Highlights of 2023

[0001410578-23-002596:mdna:15]
|  | ● | Sales, net earnings and diluted earnings per share in 2023 were $956.0 million, $92.5 million and $3.58 per share, respectively, compared to sales, net earnings and diluted earnings per share in 2022 of $857.5 million, $82.3 million and $3.16 per share, respectively. |

[0001410578-23-002596:mdna:16]
|  | ● | Diluted EPS – GAAP for 2023 increased 13.3% to $3.58, compared to Diluted EPS – GAAP for 2022 of $3.16. |

[0001410578-23-002596:mdna:17]
|  | ● | Diluted EPS – As Adjusted for 2023 was $3.70 excluding $4.1 million of pretax charges (or $0.12 per share after tax), consisting of executive management transition costs and acquisition related costs at Corporate, CMT purchase accounting adjustments, and restructuring charges primarily within the A&D segment. Diluted EPS – As Adjusted for 2022 was $3.21 excluding $1.3 million of pretax charges (or $0.05 per share after tax), consisting of Altanova and NEco purchase accounting adjustments, severance charges primarily at VACCO and NRG, and acquisition and management transition costs at Corporate. See “Non-GAAP Financial Measures” below. |

[0001410578-23-002596:mdna:18]
| ​ | ​ | Fiscal year ended |
| (Dollars in millions) |  | 2023 |  | 2022 |
| Diluted EPS – GAAP | ​ | $ | 3.58 |  | 3.16 |
| Executive management transition costs & acquisition related costs | ​ |  | 0.07 |  | 0.02 |
| Restructuring adjustments | ​ |  | 0.03 |  | 0.01 |
| Purchase accounting adjustments | ​ | ​ | 0.02 |  | 0.02 |
| Diluted EPS – As Adjusted | ​ | $ | 3.70 | ​ | 3.21 |

[0001410578-23-002596:mdna:19]
|  | ● | At September 30, 2023, cash on hand was $41.9 million and outstanding debt was $102.0 million, for a net debt position (total debt less cash on hand) of approximately $60.1 million. |

[0001410578-23-002596:mdna:20]
|  | ● | Entered orders for 2023 were $1,033 million resulting in a book-to-bill ratio of 1.08x. Backlog at September 30, 2023 was $772.4 million, an increase of $77.4 million, or 11.1%, compared to backlog of $695.0 million at September 30, 2022. |

[0001410578-23-002596:mdna:21]
|  | ● | The Company declared dividends of $0.32 per share during 2023, totaling $8.3 million in dividend payments. |

[0001410578-23-002596:mdna:22]
Results of Operations

[0001410578-23-002596:mdna:23]
Net Sales

[0001410578-23-002596:mdna:24]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | Change |  |
| ​ | ​ | Fiscal year ended | ​ | 2023 |  |
| (Dollars in millions) |  | 2023 |  | 2022 |  | vs. 2022 |  |
| A&D | ​ | $ | 392.4 |  | 351.4 |  | 11.7 | % |
| USG | ​ |  | 342.3 |  | 278.4 |  | 23.0 | % |
| Test | ​ |  | 221.3 |  | 227.7 |  | (2.8) | % |
| Total | ​ | $ | 956.0 |  | 857.5 |  | 11.5 | % |

[0001410578-23-002596:mdna:25]
Net sales increased $98.5 million, or 11.5%, to $956.0 million in 2023 from $857.5 million in 2022, with the CMT acquisition adding approximately $10 million of revenue in 2023. The increase in net sales in 2023 as compared to 2022 was mainly due to a $63.9 million increase in the USG segment and a $41.0 million increase in the A&D segment, partially offset by a $6.4 million decrease in the Test segment.

[0001410578-23-002596:mdna:26]
A&D.

[0001410578-23-002596:mdna:27]
The $41 million, or 11.7%, increase in net sales in 2023 as compared to 2022 was mainly due to a $21.8 million increase in net sales at Mayday, a $12.5 million increase in net sales at Crissair and an $11.2 million increase in net sales at PTI, all primarily due to an increase in commercial aerospace sales driven by the rebound from the COVID-19 pandemic; a $6.5 million increase in net sales at Globe/Westland combined, partially offset by an $11.0 million decrease in net sales at VACCO driven mainly by margin erosion on certain space development contracts.

[0001410578-23-002596:mdna:28]
USG.

[0001410578-23-002596:mdna:29]
The $63.9 million, or 23.0%, increase in net sales in 2023 as compared to 2022 was mainly due to a $41.8 million increase in net sales at Doble mainly due to higher shipments of condition monitoring and protection testing products and service revenue, and a $22.1 million increase in net sales at NRG driven by higher shipments of wind energy assessment towers and sensors, and solar products.

[0001410578-23-002596:mdna:30]
Test.

[0001410578-23-002596:mdna:31]
The $6.4 million, or (2.8)%, decrease in net sales in 2023 as compared to 2022 was due to a $15.3 million decrease in net sales from the Company’s Asian operations due to COVID-19 disruptions in China and a $2.0 million decrease in net sales from the Company’s U.S. operations, partially offset by a $10.9 million increase in net sales from the segment’s European operations due to timing of test and measurement chamber projects.

[0001410578-23-002596:mdna:32]
Orders and Backlog

[0001410578-23-002596:mdna:33]
New orders received were $1,033 million in 2023 and $960.5 million in 2022. Order backlog was $772.4 million at September 30, 2023, compared to order backlog of $695.0 million at September 30, 2022. Orders are entered into backlog as firm purchase order commitments are received.

[0001410578-23-002596:mdna:34]
By operating segment, 2023 orders were $468.2 million related to A&D products (including $7.0 million of acquired backlog), $347.6 million related to USG products, and $217.5 million related to Test products and 2022 orders were $392.5 million related to A&D products, $314.9 million related to USG products, and $253.1 million related to Test products.

[0001410578-23-002596:mdna:35]
Selling, General and Administrative Expenses

[0001410578-23-002596:mdna:36]
Selling, general and administrative (SG&A) expenses were $217.1 million, or 22.7% of net sales, in 2023, and $195.1 million, or 22.7% of net sales, in 2022. The increase in SG&A expenses in 2023 as compared to 2022 was mainly due to higher expenses within the USG segment as a result of increased engineering and commission expenses and wage and material inflation and higher expenses at Corporate due to executive management transition costs and professional fees.

[0001410578-23-002596:mdna:37]
Amortization of Intangible Assets

[0001410578-23-002596:mdna:38]
Amortization of intangible assets was $29.0 million in 2023 and $25.9 million in 2022, including $18.5 million and $19.3 million of amortization of acquired intangible assets in 2023 and 2022, respectively, related to our acquisitions. The amortization of acquired intangible assets related to acquisitions is included in the Corporate segment’s results. The remaining amortization expenses relate to other identifiable intangible assets (primarily software, patents and licenses), which are included in the respective segment’s operating results. The increase in amortization expense in 2023 as compared to 2022 was mainly due to an increase in amortization of capitalized software.

[0001410578-23-002596:mdna:39]
Other Income or Expenses, Net

[0001410578-23-002596:mdna:40]
Other expenses, net, was $1.9 million in 2023, compared to other income, net, of $(0.3) million in 2022. The principal component of other expenses, net, in 2023 included approximately $1.0 million of restructuring costs within the A&D segment and USG segment (mainly severance charges).  There were no individually significant items in other income, net in 2022.

[0001410578-23-002596:mdna:41]
Non-GAAP Financial Measures

[0001410578-23-002596:mdna:42]
The information reported herein includes the financial measures Diluted EPS As Adjusted, which we define as Diluted EPS excluding the per-share net impact of discrete compensation and acquisition related costs at Corporate, purchase accounting charges related to the CMT acquisition, and restructuring charges primarily within the A&D segment (primarily severance) in 2023; the per-share net impact of discrete compensation and acquisition related costs, severance charges primarily within the A&D segment, and purchase accounting charges related to the Company’s acquisitions (Altanova and NEco) in 2022; and the per-share net impact of discrete compensation and acquisition related costs, facility consolidation charges within the USG segment, and purchase accounting charges related to the Company’s acquisitions of Altanova and Phenix in 2021, partially offset by a gain on the final installment of the Doble Watertown, MA property sale; EBIT, which we define as earnings before interest and taxes; and EBIT margin, which we define as EBIT expressed as a percentage of net sales. Diluted EPS –As Adjusted, EBIT on a consolidated basis, and EBIT margin on a consolidated basis are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, we believe that EBIT and EBIT margin provide investors and Management with valuable information for assessing our operating results. Management evaluates the performance of our operating segments based on EBIT and believes that EBIT is useful to investors to demonstrate the operational profitability of our business segments by excluding interest and taxes, which are generally accounted for across the entire company on a consolidated basis. EBIT is also one of the measures Management uses to determine resource

[0001410578-23-002596:mdna:43]
allocations and incentive compensation. We believe that the presentation of EBIT, EBIT margin and Diluted EPS –As Adjusted provides important supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance determined in accordance with GAAP.

[0001410578-23-002596:mdna:44]
EBIT

[0001410578-23-002596:mdna:45]
The reconciliation of EBIT to a GAAP financial measure is as follows:

[0001410578-23-002596:mdna:46]
| (Dollars in millions) |  | 2023 |  | 2022 |
| EBIT | ​ | $ | 127.7 | ​ | 111.3 |
| Less: Interest expense, net | ​ |  | (8.8) |  | (4.9) |
| Less: Income tax expense | ​ |  | (26.4) |  | (24.1) |
| Net earnings | ​ | $ | 92.5 | ​ | 82.3 |

[0001410578-23-002596:mdna:47]
EBIT by business segment is as follows:

[0001410578-23-002596:mdna:48]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | Change |  |
| ​ | ​ | Fiscal year ended | ​ | 2023 |  |
| (Dollars in millions) |  | 2023 |  | 2022 |  | vs. 2022 |  |
| A&D | ​ | $ | 71.6 |  | 68.4 |  | 4.7 | % |
| % of net sales | ​ |  | 18.2 | % | 19.5 | % | ​ | ​ |
| USG | ​ |  | 76.7 |  | 57.6 |  | 33.2 | % |
| % of net sales | ​ |  | 22.4 | % | 20.7 | % | ​ | ​ |
| Test | ​ |  | 32.4 |  | 32.6 |  | (0.6) | % |
| % of net sales | ​ |  | 14.6 | % | 14.3 | % | ​ | ​ |
| Corporate | ​ |  | (53.0) |  | (47.3) |  | (12.1) | % |
| Total | ​ | $ | 127.7 |  | 111.3 |  | 14.7 | % |
| % of net sales | ​ |  | 13.4 | % | 13.0 | % |  | ​ |

[0001410578-23-002596:mdna:49]
A&D

[0001410578-23-002596:mdna:50]
The $3.2 million, or 4.7%, increase in EBIT in 2023 as compared to 2022 was primarily due to higher sales volumes at Mayday, PTI, Crissair and Globe partially offset by a decrease in EBIT at VACCO due to lower sales volumes as mentioned above and margin erosion on certain space development contracts. EBIT in 2023 was negatively impacted by a $0.6 million inventory step-up charge related to the CMT acquisition and $0.8 million in restructuring charges (mainly severance).

[0001410578-23-002596:mdna:51]
USG

[0001410578-23-002596:mdna:52]
The $19.1 million, or 33.2%, increase in EBIT in 2023 as compared to 2022 was mainly due to higher sales volumes at Doble and NRG with a favorable product mix and price increases, partially offset by the impacts of wage and material cost inflation and higher commissions related to increased sales.

[0001410578-23-002596:mdna:53]
Test

[0001410578-23-002596:mdna:54]
The $(0.2) million, or (0.6)%, decrease in EBIT in 2023 as compared to 2022 was primarily due to a decrease in EBIT from the segment’s Asian operations due to COVID disruptions in China, partially offset by leverage on higher sales volumes from the segment’s European operations and price increases from the segment’s U.S. operations.

[0001410578-23-002596:mdna:55]
Corporate

[0001410578-23-002596:mdna:56]
Corporate operating charges included in 2023 consolidated EBIT increased to $53.0 million as compared to $47.3 million in 2022 mainly due to an increase in executive management transition costs and professional fees and amortization expense of acquired intangible assets related to the Company’s recent acquisition of CMT Materials.

[0001410578-23-002596:mdna:57]
The “Reconciliation to Consolidated Totals (Corporate)” in Note 9 to the Consolidated Financial Statements represents Corporate office operating charges.

[0001410578-23-002596:mdna:58]
Interest Expense, Net

[0001410578-23-002596:mdna:59]
Interest expense, net was $8.8 million and $4.9 million in 2023 and 2022, respectively. The increase in interest expense in 2023 was mainly due to higher average interest rates. The weighted average interest rates were 5.82% in 2023 compared to 2.11% in 2022. Average outstanding borrowings were $140 million in 2023 compared to $190 million in 2022.

[0001410578-23-002596:mdna:60]
Income Tax Expense

[0001410578-23-002596:mdna:61]
The effective tax rates for 2023 and 2022 were 22.2% and 22.7%, respectively. The decrease in the 2023 effective tax rate as compared to 2022 was primarily due to a decrease in state income tax expense and an increase in research credit benefits partially offset by the impact of foreign operations.

[0001410578-23-002596:mdna:62]
No provision has been made in 2023 for foreign withholding of any applicable U.S. income taxes on the undistributed earnings of non-U.S. subsidiaries where these earnings are considered indefinitely invested or otherwise retained for continuing international operations. Determination of the amount of taxes that might be paid on these undistributed earnings if eventually remitted is not practicable.

[0001410578-23-002596:mdna:63]
Acquisitions

[0001410578-23-002596:mdna:64]
Information regarding our acquisitions during 2023, 2022 and 2021 is set forth in Note 2 to the Consolidated Financial Statements, which Note is incorporated by reference herein.

[0001410578-23-002596:mdna:65]
All of our acquisitions have been accounted for using the purchase method of accounting, and accordingly, the respective purchase prices were allocated to the assets (including intangible assets) acquired and liabilities assumed based on estimated fair values at the date of acquisition. The financial results from these acquisitions have been included in our financial statements from the date of acquisition.

[0001410578-23-002596:mdna:66]
Capital Resources and Liquidity

[0001410578-23-002596:mdna:67]
Our overall financial position and liquidity are strong. Working capital (current assets less current liabilities) increased to $266.4 million at September 30, 2023 from $254.5 million at September 30, 2022. Accounts receivable increased by $33.9 million during 2023 mainly due to a $24.0 million increase within the USG segment and a $9.6 million increase within the A&D segment, driven by timing and higher sales volumes in the current year. Inventories increased by $21.7 million during 2023 mainly due to a $13.2 million increase within the USG segment and a $12.7 million increase within the A&D segment resulting primarily from the timing of receipt of raw materials to meet anticipated demand and an increase in work in process inventories due to timing of manufacturing existing orders partially offset by a $4.2 million decrease within the Test segment. Accounts payable increased by $8.2 million during 2023 mainly due to a $6.2 million increase within the USG segment and a $4.2 million increase within the A&D segment partially offset by a $2.2 million increase within the Test segment, due to the timing of payments.

[0001410578-23-002596:mdna:68]
Net cash provided by operating activities was $76.9 million in 2023 and $135.3 million in 2022. The decrease in net cash provided by operating activities in 2023 as compared to 2022 was mainly driven by higher working capital requirements, including an increase in inventories and accounts receivable, and higher tax and interest payments.

[0001410578-23-002596:mdna:69]
Net cash used in investing activities was $52.5 million in 2023 and $55.9 million in 2022. Capital expenditures were $22.4 million in 2023 and $32.1 million in 2022. The decrease in 2023 as compared to 2022 was mainly due to the purchase of the NRG building of approximately $10 million in 2022. In addition, the Company incurred expenditures for capitalized software of $12.4 million in 2023 and $12.9 million in 2022.

[0001410578-23-002596:mdna:70]
There were no commitments outstanding that were considered material for capital expenditures at September 30, 2023.

[0001410578-23-002596:mdna:71]
Net cash used by financing activities was $78 million in 2023 compared to net cash used by financing activities of $32 million in 2022, primarily due to the increase in debt paydown during 2023.

[0001410578-23-002596:mdna:72]
Bank Credit Facility

[0001410578-23-002596:mdna:73]
A description of our credit facility (the “Credit Facility”) is set forth in Note 6 to the Consolidated Financial Statements, which Note is incorporated by reference herein.

[0001410578-23-002596:mdna:74]
Cash flow from operations and borrowings under the Credit Facility is expected to provide adequate resources to meet our capital requirements and operational needs both for the next 12 months and for the foreseeable future.

[0001410578-23-002596:mdna:75]
Dividends

[0001410578-23-002596:mdna:76]
During both 2023 and 2022 we paid a regular quarterly cash dividend at an annual rate of $0.32 per share, totaling $8.3 million in both 2023 and 2022.

[0001410578-23-002596:mdna:77]
Off-Balance-Sheet Arrangements

[0001410578-23-002596:mdna:78]
We had no off-balance-sheet arrangements outstanding at September 30, 2023.

[0001410578-23-002596:mdna:79]
Share Repurchases

[0001410578-23-002596:mdna:80]
During 2023, the Company repurchased approximately 140,000 shares for approximately $12.4 million. During 2022, the Company repurchased approximately 257,500 shares for approximately $20.0 million.

[0001410578-23-002596:mdna:81]
Critical Accounting Estimates

[0001410578-23-002596:mdna:82]
The preparation of financial statements in conformity with U.S. generally accepted accounting principles (GAAP) requires Management to make estimates and assumptions in certain circumstances that affect amounts reported in the Consolidated Financial Statements. In preparing these financial statements, Management has made its best estimates and judgments of certain amounts included in the Consolidated Financial Statements, giving due consideration to materiality. We do not believe there is a great likelihood that materially different amounts would be reported under different conditions or using different assumptions related to the accounting policies described below. However, application of these accounting policies involves the exercise of judgment and use of assumptions as to future uncertainties and, as a result, actual results could differ from these estimates. Our senior Management discusses the critical accounting policies described below with the Audit and Finance Committee of our Board of Directors on a periodic basis.

[0001410578-23-002596:mdna:83]
The following discussion of critical accounting policies is intended to bring to the attention of readers those accounting policies which Management believes are critical to the Consolidated Financial Statements and other financial disclosure. It is not intended to be a comprehensive list of all significant accounting policies that are more fully described in Note 1 to the Consolidated Financial Statements.

[0001410578-23-002596:mdna:84]
Revenue Recognition

[0001410578-23-002596:mdna:85]
We account for revenue in accordance with ASC Topic 606, Revenue from Contracts with Customers. The unit of account in ASC Topic 606 is a performance obligation. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration, as applicable, which are based on historical, current and forecasted information. The transaction price is allocated to each distinct performance obligation within the contract and recognized as revenue when, or as, the performance obligation is satisfied. Certain of our long-term contracts contain incentive fees that can increase the transaction price. These variable amounts generally are awarded upon achievement of certain performance metrics, program milestones or cost targets and can be based upon customer discretion. We include estimated amounts in the transaction price to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur. The estimated amounts are based on an assessment of our anticipated performance and all other information that is reasonably available to us.

[0001410578-23-002596:mdna:86]
Approximately 55% of the A&D segment’s revenue (22% of consolidated revenue) is recognized over time as the products do not have an alternative use and either we have an enforceable right to payment for costs incurred plus a reasonable margin or the inventory is owned by the customer. Selecting the method to measure progress towards completion for our contracts requires judgment and is based on the nature of the products or services to be provided.

[0001410578-23-002596:mdna:87]
The A&D segment generally uses the cost-to-cost method to measure progress on our contracts, as the rate at which costs are incurred to fulfill a contract best depicts the transfer of control to the customer. Under this method, we measure the extent of progress towards completion based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and we record revenue proportionally as costs are incurred based on an estimated profit margin.

[0001410578-23-002596:mdna:88]
The Test segment generally uses the milestone output method to measure progress on our contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. Under this method, we estimate profit as the difference between total revenue and total estimated costs at completion of a contract and recognize these revenues and costs based on milestones achieved.

[0001410578-23-002596:mdna:89]
Total contract cost estimates are based on current contract specifications and expected engineering requirements and require us to make estimates on expected profit. The estimates on profit are based on judgments we make to project the outcome of future events, and can often span more than one year and include labor productivity and availability, the complexity of the work to be performed, change orders issued by our customers, and other specialized engineering and production related activities. Our cost estimation process is based on historical results of contracts and historical actuals to original estimates, and the application of professional knowledge and experience of engineers and program managers along with finance professionals to these historical results. We review and update our estimates of costs quarterly or more frequently when circumstances significantly change, which can affect the profitability of our contracts.

[0001410578-23-002596:mdna:90]
For contracts where revenue is recognized over time, we recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. We have net revenue recognized in the current year from performance obligations satisfied in the prior year due to changes in our estimated costs to complete the related performance obligations. We recognize anticipated losses on contracts in full in the period in which the losses become known.

[0001410578-23-002596:mdna:91]
The impact of adjustments in contract estimates on our operating earnings can be reflected in either revenue or operating costs and expenses. The aggregate impact of adjustments in contract estimates decreased our earnings before income tax and diluted earnings per share by approximately $14.0 million and $0.43 per share, respectively, in 2023.

[0001410578-23-002596:mdna:92]
Income Taxes

[0001410578-23-002596:mdna:93]
We operate in numerous taxing jurisdictions and are subject to examination by various U.S. Federal, state and foreign jurisdictions for various tax periods. Our income tax positions are based on research and interpretations of the income tax laws and rulings in each of the jurisdictions in which we do business. Due to the subjectivity of interpretations of laws and rulings in each jurisdiction, the differences and interplay in tax laws between those jurisdictions, as well as the inherent uncertainty in estimating the final resolution of complex tax audit matters, Management’s estimates of income tax liabilities may differ from actual payments or assessments.

[0001410578-23-002596:mdna:94]
We account for income taxes under the asset and liability method. We recognize deferred tax assets and liabilities for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. We measure deferred tax assets and liabilities using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. We may reduce deferred tax assets by a valuation allowance if it is more likely than not that some portion of the deferred tax assets will not be realized. We recognize the effect on deferred tax assets and liabilities of a change in tax rates in income in the period that includes the enactment date. We regularly review our deferred tax assets for recoverability and establish a valuation allowance when Management believes it is more likely than not such assets will not be recovered, taking into consideration historical operating results, expectations of future earnings, tax planning strategies, and the expected timing of the reversals of existing temporary differences.

[0001410578-23-002596:mdna:95]
Goodwill and Other Long-Lived Assets

[0001410578-23-002596:mdna:96]
Our Management annually reviews goodwill and other long-lived assets for impairment or whenever events or changes in circumstances indicate the carrying amount may not be recoverable. If we determine that the carrying value of the goodwill and other long-lived assets may not be recoverable, we record a permanent impairment charge for the amount by which the carrying value of the goodwill and other long-lived assets exceeds its fair value. We measure fair value based on a discounted cash flow method using a discount rate determined by Management to be commensurate with the risk inherent in each of our reporting units’ or asset groups’ current business models. Our estimates of cash flows and discount rate are subject to change due to the economic environment,

[0001410578-23-002596:mdna:97]
including such factors as interest rates, expected market returns and volatility of markets served. We believe that Management’s estimates of future cash flows and fair value are reasonable; however, changes in estimates could result in impairment charges. At September 30, 2023 we have determined that no goodwill or other long-lived assets were impaired.

[0001410578-23-002596:mdna:98]
We amortize intangible assets with estimable useful lives over their respective estimated useful lives to their estimated residual values, and review them for impairment whenever events or changes in business circumstances indicate the carrying value of the assets may not be recoverable.

[0001410578-23-002596:mdna:99]
Other Matters

[0001410578-23-002596:mdna:100]
Quantitative and Qualitative Disclosures about Market Risk

[0001410578-23-002596:mdna:101]
Market risks relating to our operations result primarily from changes in interest rates and changes in foreign currency exchange rates. We are exposed to market risk related to changes in interest rates, and we selectively use derivative financial instruments, including forward contracts and swaps, to manage these risks. Our Canadian subsidiary Morgan Schaffer has entered into foreign exchange contracts to manage foreign currency risk, because a portion of their revenue is denominated in U.S. dollars. We report all derivative instruments on our balance sheet at fair value. For derivative instruments designated as cash flow hedges, we defer the gain or loss on the derivative in accumulated other comprehensive income until recognized in earnings with the underlying hedged item.
