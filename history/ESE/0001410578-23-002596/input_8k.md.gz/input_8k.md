# ESE 8-K — 0001104659-23-119126 filed 2023-11-16

## item codes, every 8-K on or before 2023-11-29

- 2023-11-20 0001104659-23-119761 — 5.02, 9.01
- 2023-11-16 0001104659-23-119126 — 2.02, 7.01, 9.01
- 2023-10-03 0001104659-23-106090 — 5.02, 9.01
- 2023-09-06 0001104659-23-098463 — 1.01, 2.03, 9.01
- 2023-08-08 0001104659-23-088847 — 2.02, 7.01, 9.01
- 2023-07-06 0001104659-23-078571 — 5.02, 8.01, 9.01
- 2023-05-09 0001104659-23-057736 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2023-05-05 0001104659-23-056387 — 5.02, 9.01
- 2023-02-08 0001104659-23-014539 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2023-01-06 0001104659-23-001859 — 5.02, 9.01
- 2022-11-22 0001104659-22-121229 — 5.02, 5.03, 8.01, 9.01
- 2022-11-17 0001104659-22-119898 — 2.02, 7.01, 9.01
- 2022-09-12 0001104659-22-099248 — 5.02, 7.01, 9.01
- 2022-08-08 0001104659-22-087247 — 2.02, 5.02, 7.01, 9.01
- 2022-05-09 0001104659-22-057524 — 2.02, 5.02, 7.01, 9.01
- 2022-02-08 0001104659-22-013878 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2021-12-03 0001104659-21-146361 — 4.01, 9.01 — amendment, the index does not say of what
- 2021-11-24 0001104659-21-143568 — 4.01, 9.01
- 2021-11-23 0001104659-21-142871 — 5.02, 8.01
- 2021-11-18 0001104659-21-141206 — 2.02, 7.01, 9.01
- 2021-08-09 0001104659-21-102150 — 2.02, 7.01, 9.01
- 2021-05-04 0001104659-21-060985 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2021-04-05 0001104659-21-046581 — 5.02, 9.01
- 2021-02-08 0001104659-21-013712 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2020-12-09 0001104659-20-133674 — 5.02, 9.01
- 2020-12-07 0001104659-20-132861 — 5.02, 7.01, 9.01
- 2020-11-19 0001104659-20-127352 — 2.02, 5.02, 7.01, 9.01
- 2020-08-10 0001104659-20-092734 — 2.02, 7.01, 9.01
- 2020-05-06 0001104659-20-057442 — 2.02, 7.01, 8.01, 9.01
- 2020-02-04 0001104659-20-010640 — 2.02, 5.07, 7.01, 9.01
- 2020-01-07 0001104659-20-001789 — 2.01, 9.01
- 2019-11-19 0001104659-19-065437 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2019-11-18 0001104659-19-065096 — 1.01, 2.02, 7.01, 9.01
- 2019-09-30 0001144204-19-046523 — 1.01, 1.02, 2.03, 9.01
- 2019-08-08 0001144204-19-038567 — 2.02, 7.01, 9.01
- 2019-05-07 0001144204-19-024241 — 2.02, 5.02, 7.01, 9.01
- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2023-11-29

- none on or before 2023-11-29

## item 2.02 — earnings release, exhibit 99.1

[0001104659-23-119126:8k_2_02:1]
EX-99.1
2
tm2330893d1_ex99-1.htm
EXHIBT 99.1

[0001104659-23-119126:8k_2_02:2]
Exhibit 99.1

[0001104659-23-119126:8k_2_02:3]
| NEWS FROM |  |

[0001104659-23-119126:8k_2_02:4]
For more information contact:

[0001104659-23-119126:8k_2_02:5]
Kate Lowrey - VP of Investor Relations

[0001104659-23-119126:8k_2_02:6]
(314) 213-7277
/ klowrey@escotechnologies.com

[0001104659-23-119126:8k_2_02:7]
ESCO ANNOUNCES RECORD FOURTH QUARTER AND FISCAL
2023 RESULTS

[0001104659-23-119126:8k_2_02:8]
- FY 2023 Sales increase 11% to $956 Million
-

[0001104659-23-119126:8k_2_02:9]
- FY 2023 Entered Orders surpass $1 Billion
-

[0001104659-23-119126:8k_2_02:10]
- Q4 GAAP EPS $1.24 / Adjusted EPS $1.25
 –

[0001104659-23-119126:8k_2_02:11]
ST. LOUIS, November 16, 2023 – ESCO Technologies
Inc. (NYSE: ESE) (ESCO, or the Company) today reported its operating results for the fourth quarter (Q4 2023) and fiscal year (FY 2023)
ended September 30, 2023.

[0001104659-23-119126:8k_2_02:12]
Operating Highlights

[0001104659-23-119126:8k_2_02:13]
|  | · | Q4 2023 sales increased $16 million (6 percent) to $273 million compared to $257 million in Q4 2022. Organic sales increased $13 million (5 percent) and the CMT acquisition added $3 million (1 percent) of revenue growth in the quarter. |
|  | · | FY 2023 sales increased $99 million (11 percent) to $956 million. Organic sales increased $89 million (10 percent) and the CMT acquisition added $10 million (1 percent) of revenue growth for the full year. |
|  | · | Q4 2023 entered orders increased $95 million (39 percent) compared to the prior year period to $340 million (book-to-bill of 1.25x). Full year 2023 entered orders increased $73 million (8 percent) to $1.0 billion (book-to-bill of 1.08x) and resulted in record year-end backlog of $772 million. |
|  | · | Q4 2023 GAAP EPS increased $0.05 per share (4 percent) to $1.24 per share compared to $1.19 per share in Q4 2022. Q4 2023 Adjusted EPS increased $0.04 per share (3 percent) to $1.25 per share compared to $1.21 per share in Q4 2022. |
|  | · | FY 2023 GAAP EPS increased $0.42 per share (13 percent) to $3.58 per share compared to $3.16 per share in FY 2022. FY 2023 Adjusted EPS increased $0.49 per share (15 percent) to $3.70 per share compared to $3.21 per share in FY 2022. |
|  | · | Net cash provided by operating activities was $48 million in Q4 and $77 million for the full year, resulting in a decrease of $58 million compared to the prior year. Cash flow improved significantly in Q4 but was negatively impacted during the year by higher working capital requirements, along with higher interest and tax payments compared to the prior year. |

[0001104659-23-119126:8k_2_02:14]
|  | · | Net debt (total borrowings less cash on hand) was $60 million, resulting in a leverage ratio of 0.54x and $640 million in available liquidity on September 30, 2023. |

[0001104659-23-119126:8k_2_02:15]
Bryan Sayler, Chief Executive Officer and President,
commented, “ESCO had a great year, as we delivered record sales, Adjusted EBIT, Adjusted EPS, entered orders, and year-end backlog.
We are well positioned in a number of end-markets with excellent growth characteristics, and we continue to see orders and sales momentum
across our portfolio. In the quarter, all three business segments reported solid orders growth that resulted in an overall book-to-bill
of 1.25x. A highlight in the quarter was booking over $90 million in Navy orders, which included significant content for machining of
Block V hull treatments on Virginia Class submarines, hypersonic ejection valves, and Navy spares. Record quarterly orders of $340 million
capped off a year in which we surpassed $1 billion dollars in orders for the first time.

[0001104659-23-119126:8k_2_02:16]
“This was a particularly strong quarter for
our USG segment as the need to update and maintain the aging U.S. electric grid, while at the same time expanding it to support the clean
energy transition, is driving investments in utility infrastructure. USG sales increased 22 percent in the quarter, and we leveraged that
growth to drive 2 points of margin expansion.

[0001104659-23-119126:8k_2_02:17]
“I would like to thank our team for all their
hard work during the year. The dedication of our employees is a key factor in being able to deliver record results once again. Across
the company there is a lot to be excited about, both in our FY’23 results and in our opportunities to drive growth going forward.”

[0001104659-23-119126:8k_2_02:18]
Segment Performance

[0001104659-23-119126:8k_2_02:19]
Aerospace & Defense (A&D)

[0001104659-23-119126:8k_2_02:20]
|  | · | Q4 2023 sales increased $3 million (3 percent) to $107 million from $104 million in Q4 2022. Q4 organic sales were flat compared to the prior year as commercial and defense aerospace sales growth was offset by lower space revenue. The CMT acquisition contributed $3 million (3 percent) in the quarter. FY 2023 sales increased $41 million (12 percent) to $392 million. Organic sales increased $31 million (9 percent), driven by commercial aerospace which increased $24 million and defense aerospace which increased $17 million, partially offset by space which decreased $10 million. The CMT acquisition added $10 million (3 percent) revenue growth in FY 2023. |
|  | · | Q4 2023 EBIT decreased $4.7 million to $18.6 million from $23.3 million in Q4 2022. Adjusted EBIT decreased $4.5 million in Q4 2023 to $19.1 million (17.8 percent margin) from $23.6 million (22.7 percent margin) in Q4 2022. FY 2023 EBIT increased $3.2 million to $71.6 million from $68.4 million in FY 2022. FY 2023 Adjusted EBIT increased $4.1 million to $73.1 million (18.6 percent margin) from $69.0 million (19.6 percent margin) in FY 2022. Margin erosion on certain space development contracts offset leverage on aerospace growth in both the quarter and the year. |

[0001104659-23-119126:8k_2_02:21]
|  | · | Entered orders increased $80 million (82 percent) to $177 million in Q4 2023 (book-to-bill of 1.66). For the full year entered orders increased $76 million (19 percent) to $468 million (book-to-bill of 1.19). Growth in the quarter and the year was driven by defense and commercial aerospace and large Navy orders and resulted in record year-end backlog of $484 million. |

[0001104659-23-119126:8k_2_02:22]
Utility Solutions Group (USG)

[0001104659-23-119126:8k_2_02:23]
|  | · | Q4 2023 sales increased $19 million (22 percent) to $102 million from $83 million in Q4 2022. Doble sales increased $11 million (15 percent), primarily driven by a strong quarter for protection testing hardware and software. NRG sales increased $8 million (69 percent) in the quarter as a result of continued robust demand across all product lines. FY 2023 sales increased $64 million (23 percent) to $342 million from $278 million in FY 2022. Doble sales increased $42 million (18 percent) and NRG sales increased $22 million (52 percent) for the year. The sales growth was driven by condition monitoring and protection testing sales at Doble and strong demand across our renewables product lines at NRG. |
|  | · | Q4 2023 EBIT and Adjusted EBIT both increased $6.4 million in Q4 2023 to $26.2 million (25.7 percent margin) from $19.8 million (23.7 percent margin) in Q4 2022. FY 2023 EBIT increased $19.1 million to $76.7 million from $57.6 million in FY 2022. FY 2023 Adjusted EBIT increased $18.8 million to $76.9 million (22.5 percent margin) from $58.1 million (20.9 percent margin) in FY 2022. Adjusted EBIT increases for the quarter and year were largely driven by higher volumes and price increases, partially offset by inflationary pressures, and higher commissions related to increased sales. |
|  | · | Entered Orders increased $10 million to $97 million in Q4 2023 as Doble orders increased $14 million and NRG orders decreased $4 million compared to the prior year quarter. For the full year entered orders increased $33 million to $348 million (book-to-bill of 1.02) and resulted in year-end backlog of $133 million. For the year, Doble orders increased $18 million (7 percent) on increased electric utility spending and NRG orders increased $15 million (28 percent) due to continued growth in the demand for renewables and the initial impact of the Inflation Reduction Act. |

[0001104659-23-119126:8k_2_02:24]
RF Test & Measurement (Test)

[0001104659-23-119126:8k_2_02:25]
|  | · | Q4 2023 sales decreased $6 million (8 percent) to $63 million from $69 million in Q4 2022. FY 2023 sales decreased $6 million (3 percent) to $221 million. The primary drivers in both the quarter and year were lower domestic filter sales and test and measurement volume in China, partially offset by increased domestic service revenue and test and measurement activity in EMEA. |
|  | · | Q4 2023 EBIT decreased $0.7 million to $11.1 million (17.5 percent margin) from $11.8 million (17.0 percent margin) in Q4 2022. FY 2023 EBIT decreased $0.2 million to $32.4 million (14.6 percent margin) from $32.6 million (14.3 percent margin) in FY 2022. The Q4 and full year margin percentage improvement was driven by price increases and cost reduction efforts, which more than offset the impact of lower volume and wage and material cost inflation. |

[0001104659-23-119126:8k_2_02:26]
|  | · | Entered orders increased $5 million to $65 million in Q4 2023. Q4 was the highest orders quarter of the year for Test and included bookings for large utility shielding and anechoic chamber projects. For the full year entered orders decreased $36 million to $218 million (book-to-bill of 0.98). The decrease in orders for the year was primarily driven by lower domestic power filter orders and test and measurement projects in China and resulted in year-end backlog of $155 million. |

[0001104659-23-119126:8k_2_02:27]
Share Repurchase Program

[0001104659-23-119126:8k_2_02:28]
The Company did not repurchase any shares of stock
during Q4 2023. During FY 2023 the Company repurchased approximately 140,000 shares for $12 million.

[0001104659-23-119126:8k_2_02:29]
Dividend Payment

[0001104659-23-119126:8k_2_02:30]
The next quarterly cash dividend
of $0.08 per share will be paid on January 19, 2024 to stockholders of record on January 4, 2024.

[0001104659-23-119126:8k_2_02:31]
2024 Annual Meeting

[0001104659-23-119126:8k_2_02:32]
The 2024 Annual Meeting of the Company’s
Shareholders will be held on February 7, 2024.

[0001104659-23-119126:8k_2_02:33]
Acquisition Update

[0001104659-23-119126:8k_2_02:34]
On November 9, 2023, the Company acquired MPE Limited (MPE), based
in the United Kingdom. MPE is a leading global manufacturer of high-performance EMC/EMP filters and capacitor products for military, utility,
telecommunication, and other critical infrastructure applications. MPE’s facility and component filter product offerings are highly
complementary to ETS-Lindgren’s powerline filter business and will broaden our end-markets served and expand our reach internationally.
The business is expected to have annualized sales in the range of $12 to $14 million and will become part of our RF Test & Measurement
segment. We expect MPE to be accretive to the sales growth and EBITDA margin profile of our existing Test segment.

[0001104659-23-119126:8k_2_02:35]
Business Outlook – FY 2024

[0001104659-23-119126:8k_2_02:36]
Management expects growth in sales, Adjusted EBIT, and Adjusted EBITDA
across each of the Company’s business segments in 2024.

[0001104659-23-119126:8k_2_02:37]
Management’s expectations for growth in 2024 compared to 2023:

[0001104659-23-119126:8k_2_02:38]
|  | · | Net sales are expected to grow 7 to 9 percent and be in the range of $1.02 to $1.04 billion on a consolidated basis, with A&D growing 8 to 10 percent, USG growing 6 to 8 percent, and Test growing 8 to 10 percent (including the MPE acquisition). |
|  | · | Adjusted EBIT is expected to increase approximately 12 to 15 percent with Adjusted EBIT margins increasing to 14.3 to 14.7 percent of sales. |
|  | · | Adjusted EBITDA is expected to increase approximately 10 to 12 percent with Adjusted EBITDA margins increasing to 19.4 to 19.8 percent of sales. |

[0001104659-23-119126:8k_2_02:39]
|  | · | The effective income tax rate is expected to be in the range of 22.5 to 23.5 percent in 2024. |
|  | · | Adjusted EPS to expected to increase 11 to 16 percent and be in the range of $4.10 to $4.30 per share. |
|  | · | Management expects Q1 2024 Adjusted EPS to increase 7 to 17 percent compared to the prior year first quarter and to be in the range of $0.64 - $0.70 per share. Consistent with prior years, revenues and Adjusted EPS are expected to grow sequentially throughout the year. |

[0001104659-23-119126:8k_2_02:40]
Conference Call

[0001104659-23-119126:8k_2_02:41]
The Company will host a conference call today, November 16, at 4:00
p.m. Central Time, to discuss the Company’s Q4 and full year 2023 results. A live audio webcast and an accompanying slide presentation
will be available on ESCO’s investor website at https://investor.escotechnologies.com. For those unable to participate, a webcast
replay will be available after the call on ESCO’s investor website.

[0001104659-23-119126:8k_2_02:42]
Forward-Looking Statements

[0001104659-23-119126:8k_2_02:43]
Statements in this press release regarding expectations
for future results, sales and sales growth, EPS, Adjusted EBIT, Adjusted EBITDA, Adjusted EPS, cash flow, results of cost reduction efforts,
margins, income tax rates, the financial success of the Company, the strength of its end markets, the outlook for the A&D, Test and
USG segments, the ability to increase shareholder value, the results of acquisitions and international expansion efforts, internal investments
in new products and solutions, the impacts of inflation, the long-term success of the Company, and any other statements which are not
strictly historical are “forward-looking” statements within the meaning of the safe harbor provisions of the federal securities
laws.

[0001104659-23-119126:8k_2_02:44]
Investors are cautioned that such statements are
only predictions and speak only as of the date of this release, and the Company undertakes no duty to update them except as may be required
by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the
forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment including
but not limited to those described in Item 1A, “Risk Factors”, of the Company’s Annual Report on Form 10-K for the fiscal
year ended September 30, 2022; the impacts of natural disasters on the Company’s operations and those of the Company’s customers
and suppliers; the timing and content of future contract awards or customer orders; future impacts of the Inflation Reduction Act and
other existing and future laws and regulations, future levels of utility infrastructure spending and demand for renewables products; the
appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer contracts
or orders; changing economic conditions in served markets; changes in customer demands or customer insolvencies; competition; intellectual
property rights; technical difficulties; the success of the Company’s acquisition and cost reduction efforts; delivery delays or
defaults by customers; performance issues with key customers, suppliers and subcontractors; changes in the costs and availability of certain
raw materials; labor disputes; changes in U.S. tax laws and regulations; other changes in laws and regulations including but not limited
to changes in accounting standards and foreign taxation; changes in interest rates; costs relating to environmental matters arising from
current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and
the integration of recently acquired businesses.

[0001104659-23-119126:8k_2_02:45]
Non-GAAP Financial Measures

[0001104659-23-119126:8k_2_02:46]
The financial measures EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA,
and Adjusted EPS are presented in this press release. The Company defines “EBIT” as earnings before interest and taxes, “EBITDA”
as earnings before interest, taxes, depreciation and amortization, “Adjusted EBIT” and “Adjusted EBITDA” as excluding
the net impact of the items described in the attached Reconciliation of Non-GAAP Financial Measures, and “Adjusted EPS” as
GAAP earnings per share excluding the net impact of the items described and reconciled in the attached Reconciliation of Non-GAAP Financial
Measures.

[0001104659-23-119126:8k_2_02:47]
EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA, and
Adjusted EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management believes
EBIT, Adjusted EBIT, EBITDA, and Adjusted EBITDA are useful in assessing the operational profitability of the Company’s business
segments because they exclude interest, taxes, depreciation, and amortization, which are generally accounted for across the entire Company
on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company as
well as incentive compensation. The presentation of EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA, and Adjusted EPS provides important
supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures
to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance determined
in accordance with GAAP.

[0001104659-23-119126:8k_2_02:48]
ESCO is a global provider of highly engineered products and solutions
serving diverse end-markets. It manufactures filtration and fluid control products for the aviation, Navy, space, and process markets
worldwide and composite-based products and solutions for Navy, defense, and industrial customers. ESCO is an industry leader in designing
and manufacturing RF test and measurement products and systems; and provides diagnostic instruments, software and services to industrial
power users and the electric utility and renewable energy industries. Headquartered in St. Louis, Missouri, ESCO and its subsidiaries
have offices and manufacturing facilities worldwide. For more information on ESCO and its subsidiaries, visit the Company’s website
at www.escotechnologies.com.

[0001104659-23-119126:8k_2_02:49]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-23-119126:8k_2_02:50]
Condensed
Consolidated Statements of Operations (Unaudited)

[0001104659-23-119126:8k_2_02:51]
(Dollars in thousands, except per share amounts)

[0001104659-23-119126:8k_2_02:52]
|  |  | Three Months Ended September 30, 2023 |  |  | Three Months Ended September 30, 2022 |  |
| Net Sales |  | $ | 272,647 |  |  |  | 256,498 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 164,424 |  |  |  | 154,323 |  |
| Selling, general and administrative expenses |  |  | 56,555 |  |  |  | 53,054 |  |
| Amortization of intangible assets |  |  | 7,930 |  |  |  | 6,553 |  |
| Interest expense |  |  | 2,347 |  |  |  | 1,767 |  |
| Other expenses (income), net |  |  | 199 |  |  |  | 373 |  |
| Total costs and expenses |  |  | 231,455 |  |  |  | 216,070 |  |
| Earnings before income taxes |  |  | 41,192 |  |  |  | 40,428 |  |
| Income tax expense |  |  | 9,195 |  |  |  | 9,388 |  |
| Net earnings |  | $ | 31,997 |  |  |  | 31,040 |  |
| Earnings Per Share (EPS) |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 1.24 |  |  |  | 1.19 |  |
| Diluted - As Adjusted Basis |  | $ | 1.25 | (1) |  |  | 1.21 | (2) |
| Diluted average common shares O/S: |  |  | 25,862 |  |  |  | 25,990 |  |

[0001104659-23-119126:8k_2_02:53]
| (1) | Q4 2023 Adjusted EPS excludes $0.01 per share of after-tax restructuring charges primarily at Westland (severance and asset write-off). |
| (2) | Q4 2022 Adjusted EPS excludes $0.02 per share of after-tax severance charges at VACCO and NRG, and Corporate management transition costs. |

[0001104659-23-119126:8k_2_02:54]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-23-119126:8k_2_02:55]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-23-119126:8k_2_02:56]
(Dollars
in thousands, except per share amounts)

[0001104659-23-119126:8k_2_02:57]
|  |  | Year Ended September 30, 2023 |  |  | Year Ended September 30, 2022 |  |
| Net Sales |  | $ | 956,033 |  |  |  | 857,502 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 580,377 |  |  |  | 525,457 |  |
| Selling, general and administrative expenses |  |  | 217,110 |  |  |  | 195,127 |  |
| Amortization of intangible assets |  |  | 28,953 |  |  |  | 25,936 |  |
| Interest expense |  |  | 8,769 |  |  |  | 4,851 |  |
| Other expenses (income), net |  |  | 1,877 |  |  |  | (304 | ) |
| Total costs and expenses |  |  | 837,086 |  |  |  | 751,067 |  |
| Earnings before income taxes |  |  | 118,947 |  |  |  | 106,435 |  |
| Income tax expense |  |  | 26,402 |  |  |  | 24,115 |  |
| Net earnings |  | $ | 92,545 |  |  |  | 82,320 |  |
| Earnings Per Share (EPS) |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 3.58 |  |  |  | 3.16 |  |
| Diluted - As Adjusted Basis |  | $ | 3.70 | (1) |  |  | 3.21 | (2) |
| Diluted average common shares O/S: |  |  | 25,879 |  |  |  | 26,067 |  |

[0001104659-23-119126:8k_2_02:58]
| (1) | FY 2023 Adjusted EPS excludes $0.12 per share of after-tax charges consisting of $0.06 of executive management transition costs at Corporate, $0.02 of CMT acquisition inventory step-up charges, $0.03 of restructuring charges within the A&D segment, and $0.01 of Corporate acquisition related costs. |
| (2) | FY 2022 Adjusted EPS excludes $0.05 per share of after-tax charges associated with the Altanova & NEco acquisition inventory step-up charges, severance charges at VACCO and NRG, and Corporate acquisition and management transition costs. |

[0001104659-23-119126:8k_2_02:59]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-23-119126:8k_2_02:60]
Condensed Business Segment Information (Unaudited)

[0001104659-23-119126:8k_2_02:61]
(Dollars in thousands)

[0001104659-23-119126:8k_2_02:62]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | Q4 2023 |  |  | Q4 2022 |  |  | Q4 2023 |  |  | Q4 2022 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 107,009 |  |  |  | 103,742 |  |  |  | 107,009 |  |  |  | 103,742 |  |
| USG |  |  | 102,148 |  |  |  | 83,490 |  |  |  | 102,148 |  |  |  | 83,490 |  |
| Test |  |  | 63,490 |  |  |  | 69,266 |  |  |  | 63,490 |  |  |  | 69,266 |  |
| Totals |  | $ | 272,647 |  |  |  | 256,498 |  |  |  | 272,647 |  |  |  | 256,498 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 18,647 |  |  |  | 23,310 |  |  |  | 19,075 |  |  |  | 23,590 |  |
| USG |  |  | 26,179 |  |  |  | 19,764 |  |  |  | 26,242 |  |  |  | 19,813 |  |
| Test |  |  | 11,115 |  |  |  | 11,779 |  |  |  | 11,115 |  |  |  | 11,779 |  |
| Corporate |  |  | (12,402 | ) |  |  | (12,658 | ) |  |  | (12,402 | ) |  |  | (12,428 | ) |
| Consolidated EBIT |  |  | 43,539 |  |  |  | 42,195 |  |  |  | 44,030 |  |  |  | 42,754 |  |
| Less: Interest expense |  |  | (2,347 | ) |  |  | (1,767 | ) |  |  | (2,347 | ) |  |  | (1,767 | ) |
| Less: Income tax expense |  |  | (9,195 | ) |  |  | (9,388 | ) |  |  | (9,308 | ) |  |  | (9,517 | ) |
| Net earnings |  | $ | 31,997 |  |  |  | 31,040 |  |  |  | 32,375 |  |  |  | 31,470 |  |

[0001104659-23-119126:8k_2_02:63]
Note 1: Adjusted net earnings of $32.4 million in Q4 2023 exclude $0.4
million (or $0.01 per share) of after-tax restructuring charges primarily at Westland (severance and asset write-off).

[0001104659-23-119126:8k_2_02:64]
Note 2: Adjusted net earnings of $31.5 million in Q4 2022 exclude $0.4
million (or $0.02 per share) of after-tax severance charges at VACCO and NRG, and Corporate management transition costs.

[0001104659-23-119126:8k_2_02:65]
| EBITDA Reconciliation to Net earnings: |  |  |  |  | Q4 2023 - |  |  | Q4 2022 - |  |
|  |  | Q4 2023 |  |  | Q4 2022 |  |  | As Adjusted |  |  | As Adjusted |  |
| Consolidated EBITDA |  | $ | 56,363 |  |  |  | 54,291 |  |  |  | 56,854 |  |  |  | 54,850 |  |
| Less: Depr & Amort |  |  | (12,824 | ) |  |  | (12,096 | ) |  |  | (12,824 | ) |  |  | (12,096 | ) |
| Consolidated EBIT |  |  | 43,539 |  |  |  | 42,195 |  |  |  | 44,030 |  |  |  | 42,754 |  |
| Less: Interest expense |  |  | (2,347 | ) |  |  | (1,767 | ) |  |  | (2,347 | ) |  |  | (1,767 | ) |
| Less: Income tax expense |  |  | (9,195 | ) |  |  | (9,388 | ) |  |  | (9,308 | ) |  |  | (9,517 | ) |
| Net earnings |  | $ | 31,997 |  |  |  | 31,040 |  |  |  | 32,375 |  |  |  | 31,470 |  |

[0001104659-23-119126:8k_2_02:66]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-23-119126:8k_2_02:67]
Condensed Business Segment Information (Unaudited)

[0001104659-23-119126:8k_2_02:68]
(Dollars in thousands)

[0001104659-23-119126:8k_2_02:69]
|  |  | GAAP |  | As Adjusted |  |
|  |  | FY 2023 |  |  | FY 2022 |  |  | FY 2023 |  |  | FY 2022 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 392,443 |  |  |  | 351,413 |  |  |  | 392,443 |  |  |  | 351,413 |  |
| USG |  |  | 342,320 |  |  |  | 278,367 |  |  |  | 342,320 |  |  |  | 278,367 |  |
| Test |  |  | 221,270 |  |  |  | 227,722 |  |  |  | 221,270 |  |  |  | 227,722 |  |
| Totals |  | $ | 956,033 |  |  |  | 857,502 |  |  |  | 956,033 |  |  |  | 857,502 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 71,643 |  |  |  | 68,352 |  |  |  | 73,070 |  |  |  | 68,967 |  |
| USG |  |  | 76,722 |  |  |  | 57,604 |  |  |  | 76,915 |  |  |  | 58,120 |  |
| Test |  |  | 32,395 |  |  |  | 32,592 |  |  |  | 32,395 |  |  |  | 32,592 |  |
| Corporate |  |  | (53,044 | ) |  |  | (47,262 | ) |  |  | (50,531 | ) |  |  | (46,727 | ) |
| Consolidated EBIT |  |  | 127,716 |  |  |  | 111,286 |  |  |  | 131,849 |  |  |  | 112,952 |  |
| Less: Interest expense |  |  | (8,769 | ) |  |  | (4,851 | ) |  |  | (8,769 | ) |  |  | (4,851 | ) |
| Less: Income tax |  |  | (26,402 | ) |  |  | (24,115 | ) |  |  | (27,353 | ) |  |  | (24,499 | ) |
| Net earnings |  | $ | 92,545 |  |  |  | 82,320 |  |  |  | 95,727 |  |  |  | 83,602 |  |

[0001104659-23-119126:8k_2_02:70]
Note 1: Adjusted net earnings of $95.7 million in FY 2023 exclude $3.2
million (or $0.12 per share) of after-tax charges consisting of $0.06 of executive management transition costs at Corporate, $0.02 of
CMT acquisition inventory step-up charges, $0.03 of restructuring charges within the A&D segment, and $0.01 of Corporate acquisition
related costs.

[0001104659-23-119126:8k_2_02:71]
Note 2: Adjusted net earnings of $83.6 million in FY 2022 exclude $1.3
million (or $0.05 per share) of after-tax charges associated with the Altanova & NEco acquisition inventory step-up charges, severance
charges at VACCO and NRG, and Corporate acquisition and management transition costs.

[0001104659-23-119126:8k_2_02:72]
| EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |  | FY 2023 |  |  | FY 2022 |  |
|  |  | FY 2023 |  |  | FY 2022 |  |  | As Adjusted |  |  | As Adjusted |  |
| Consolidated EBITDA |  | $ | 178,239 |  |  |  | 159,629 |  |  |  | 182,372 |  |  |  | 161,295 |  |
| Less: Depr & Amort |  |  | (50,523 | ) |  |  | (48,343 | ) |  |  | (50,523 | ) |  |  | (48,343 | ) |
| Consolidated EBIT |  |  | 127,716 |  |  |  | 111,286 |  |  |  | 131,849 |  |  |  | 112,952 |  |
| Less: Interest expense |  |  | (8,769 | ) |  |  | (4,851 | ) |  |  | (8,769 | ) |  |  | (4,851 | ) |
| Less: Income tax expense |  |  | (26,402 | ) |  |  | (24,115 | ) |  |  | (27,353 | ) |  |  | (24,499 | ) |
| Net earnings |  | $ | 92,545 |  |  |  | 82,320 |  |  |  | 95,727 |  |  |  | 83,602 |  |

[0001104659-23-119126:8k_2_02:73]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-23-119126:8k_2_02:74]
Condensed Consolidated Balance Sheets (Unaudited)

[0001104659-23-119126:8k_2_02:75]
(Dollars in thousands)

[0001104659-23-119126:8k_2_02:76]
|  |  | September 30, 2023 |  |  | September 30, 2022 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 41,866 |  |  |  | 97,724 |  |
| Accounts receivable, net |  |  | 198,557 |  |  |  | 164,645 |  |
| Contract assets |  |  | 138,633 |  |  |  | 125,154 |  |
| Inventories |  |  | 184,067 |  |  |  | 162,403 |  |
| Other current assets |  |  | 17,972 |  |  |  | 22,696 |  |
| Total current assets |  |  | 581,095 |  |  |  | 572,622 |  |
| Property, plant and equipment, net |  |  | 155,484 |  |  |  | 155,973 |  |
| Intangible assets, net |  |  | 392,124 |  |  |  | 394,464 |  |
| Goodwill |  |  | 503,177 |  |  |  | 492,709 |  |
| Operating lease assets |  |  | 39,839 |  |  |  | 29,150 |  |
| Other assets |  |  | 11,495 |  |  |  | 9,538 |  |
|  |  | $ | 1,683,214 |  |  |  | 1,654,456 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt |  | $ | 20,000 |  |  |  | 20,000 |  |
| Accounts payable |  |  | 86,973 |  |  |  | 78,746 |  |
| Contract liabilities |  |  | 112,277 |  |  |  | 125,009 |  |
| Other current liabilities |  |  | 95,401 |  |  |  | 94,374 |  |
| Total current liabilities |  |  | 314,651 |  |  |  | 318,129 |  |
| Deferred tax liabilities |  |  | 75,531 |  |  |  | 82,023 |  |
| Non-current operating lease liabilities |  |  | 36,554 |  |  |  | 24,853 |  |
| Other liabilities |  |  | 43,336 |  |  |  | 48,294 |  |
| Long-term debt |  |  | 82,000 |  |  |  | 133,000 |  |
| Shareholders' equity |  |  | 1,131,142 |  |  |  | 1,048,157 |  |
|  |  | $ | 1,683,214 |  |  |  | 1,654,456 |  |

[0001104659-23-119126:8k_2_02:77]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-23-119126:8k_2_02:78]
Consolidated Statements of Cash Flows

[0001104659-23-119126:8k_2_02:79]
(Dollars in thousands)

[0001104659-23-119126:8k_2_02:80]
|  |  | Year Ended September 30, 2023 |  |  | Year Ended September 30, 2022 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 92,545 |  |  |  | 82,320 |  |
| Adjustments to reconcile net earnings to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 50,523 |  |  |  | 48,343 |  |
| Stock compensation expense |  |  | 8,910 |  |  |  | 7,320 |  |
| Changes in assets and liabilities |  |  | (68,821 | ) |  |  | (11,654 | ) |
| Effect of deferred taxes |  |  | (6,267 | ) |  |  | 8,946 |  |
| Net cash provided by operating activities |  |  | 76,890 |  |  |  | 135,275 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Acquisition of business, net of cash acquired |  |  | (17,694 | ) |  |  | (10,906 | ) |
| Capital expenditures |  |  | (22,377 | ) |  |  | (32,101 | ) |
| Additions to capitalized software |  |  | (12,397 | ) |  |  | (12,912 | ) |
| Net cash used by investing activities |  |  | (52,468 | ) |  |  | (55,919 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from long-term debt |  |  | 103,000 |  |  |  | 100,000 |  |
| Principal payments on long-term debt & short-term borrowings |  |  | (154,000 | ) |  |  | (101,000 | ) |
| Dividends paid |  |  | (8,252 | ) |  |  | (8,268 | ) |
| Purchases of common stock into treasury |  |  | (12,401 | ) |  |  | (19,878 | ) |
| Debt issuance costs |  |  | (1,826 | ) |  |  | 0 |  |
| Other |  |  | (4,851 | ) |  |  | (2,976 | ) |
| Net cash used by financing activities |  |  | (78,330 | ) |  |  | (32,122 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (1,950 | ) |  |  | (5,742 | ) |
| Net (decrease) increase in cash and cash equivalents |  |  | (55,858 | ) |  |  | 41,492 |  |
| Cash and cash equivalents, beginning of period |  |  | 97,724 |  |  |  | 56,232 |  |
| Cash and cash equivalents, end of period |  | $ | 41,866 |  |  |  | 97,724 |  |

[0001104659-23-119126:8k_2_02:81]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-23-119126:8k_2_02:82]
Other Selected Financial Data (Unaudited)

[0001104659-23-119126:8k_2_02:83]
(Dollars in thousands)

[0001104659-23-119126:8k_2_02:84]
| Backlog And Entered Orders - Q4 2023 |  | Aerospace & Defense |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 7/1/23 |  | $ | 413,713 |  |  |  | 138,240 |  |  |  | 153,456 |  |  |  | 705,409 |  |
| Entered Orders |  |  | 177,365 |  |  |  | 97,367 |  |  |  | 64,868 |  |  |  | 339,600 |  |
| Sales |  |  | (107,009 | ) |  |  | (102,148 | ) |  |  | (63,490 | ) |  |  | (272,647 | ) |
| Ending Backlog - 9/30/23 |  | $ | 484,069 |  |  |  | 133,459 |  |  |  | 154,834 |  |  |  | 772,362 |  |

[0001104659-23-119126:8k_2_02:85]
| Backlog And Entered Orders - FY 2023 |  | Aerospace & Defense |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 10/1/22 |  | $ | 408,269 |  |  |  | 128,156 |  |  |  | 158,597 |  |  |  | 695,022 |  |
| Entered Orders |  |  | 468,243 |  |  |  | 347,623 |  |  |  | 217,507 |  |  |  | 1,033,373 |  |
| Sales |  |  | (392,443 | ) |  |  | (342,320 | ) |  |  | (221,270 | ) |  |  | (956,033 | ) |
| Ending Backlog - 9/30/23 |  | $ | 484,069 |  |  |  | 133,459 |  |  |  | 154,834 |  |  |  | 772,362 |  |

[0001104659-23-119126:8k_2_02:86]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-23-119126:8k_2_02:87]
Reconciliation of Non-GAAP Financial Measures (Unaudited)

[0001104659-23-119126:8k_2_02:88]
| EPS – Adjusted Basis Reconciliation – Q4 2023 |  |  |  |
| EPS – GAAP Basis – Q4 2022 |  | $ | 1.24 |  |
| Adjustments (defined below) |  |  | 0.01 |  |
| EPS – As Adjusted Basis – Q4 2023 |  | $ | 1.25 |  |
| Adjustments exclude $0.01 per share consisting of after-tax restructuring charges primarily at Westland (severance and asset write-off). |  |  |  |  |
| The $0.01 of EPS adjustments per share consists of $0.5 million of pre-tax charges offset by $0.1 million of tax benefit for net impact of $0.4 million. |  |  |  |  |
| EPS – Adjusted Basis Reconciliation – FY 2023 |  |  |  |  |
| EPS – GAAP Basis – FY 2023 |  | $ | 3.58 |  |
| Adjustments (defined below) |  |  | 0.12 |  |
| EPS – As Adjusted Basis – FY 2023 |  | $ | 3.70 |  |
| Adjustments exclude $0.12 per share of after-tax charges consisting of executive management transition costs at Corporate, CMT acquisition inventory step-up charges, restructuring charges within the A&D segment and Corporate acquisition related costs. |  |  |  |  |
| The $0.12 of EPS adjustments per share consists of $4.1 million of pre-tax charges offset by $0.9 million of tax benefit for net impact of $3.2 million |  |  |  |  |
| EPS – Adjusted Basis Reconciliation – Q4 2022 |  |  |  |  |
| EPS – GAAP Basis – Q4 2022 |  | $ | 1.19 |  |
| Adjustments (defined below) |  |  | 0.02 |  |
| EPS – As Adjusted Basis – Q4 2022 |  | $ | 1.21 |  |
| Adjustments exclude $0.02 per share consisting of after-tax severance charges at VACCO and NRG and Corporate management transition costs. |  |  |  |  |
| The $0.02 of EPS adjustments per share consists of $0.6 million of pre-tax charges offset by $0.2 million of tax benefit for net impact of $0.4 million. |  |  |  |  |
| EPS – Adjusted Basis Reconciliation – FY 2022 |  |  |  |  |
| EPS – GAAP Basis – FY 2022 |  | $ | 3.16 |  |
| Adjustments (defined below) |  |  | 0.05 |  |
| EPS – As Adjusted Basis – FY 2022 |  | $ | 3.21 |  |
| Adjustments exclude $0.05 per share consisting of Altanova & Neco acquisition inventory step-up charges, severance charges at VACCO and NRG, Corporate acquisition costs and management transition costs. |  |  |  |  |
| The $0.05 of EPS adjustments per share consists of $1.7 million of pre-tax charges offset by $0.4 million of tax benefit for net impact of $1.3 million |  |  |  |  |
