# ESE MD&A — 0001104659-20-130486


## mdna

[0001104659-20-130486:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001104659-20-130486:mdna:2]
The following discussion should be read in conjunction with the Consolidated Financial Statements and Notes thereto and refers to the Company’s results from continuing operations except where noted.

[0001104659-20-130486:mdna:3]
In December 2019, the Company sold the businesses comprising its former Technical Packaging segment. The Company received net proceeds from the sale of approximately $184 million and recorded a $76.5 million after-tax gain on the sale in 2020. The Company used the proceeds from the sale to pay down debt and for other corporate purposes including the termination of the Company’s defined benefit pension plan. The Technical Packaging segment is reflected as discontinued operations in the Consolidated Financial Statements and related notes for all periods presented, in accordance with accounting principles generally accepted in the United States of America (GAAP). See Note 2 to the Consolidated Financial Statements for further discussion.

[0001104659-20-130486:mdna:4]
Selected financial information for each of the Company’s business segments is provided in the discussion below and in Note 14 to the Company’s Consolidated Financial Statements.

[0001104659-20-130486:mdna:5]
This section includes comparisons of certain 2020 financial information to the same information for 2019. Year-to-year comparisons of the 2019 financial information to the same information for 2018 are contained in Item 7 of the Company’s Form 10-K for 2019 filed with the Securities and Exchange Commission on November 29, 2019 and available through the SEC’s website at https://www.sec.gov/edgar/searchedgar/companysearch.html.

[0001104659-20-130486:mdna:6]
Introduction

[0001104659-20-130486:mdna:7]
ESCO Technologies Inc. and its wholly owned subsidiaries (the Company) are organized into three reportable operating segments for financial reporting purposes: Aerospace & Defense (formerly Filtration/Fluid Flow), Utility Solutions Group (USG), RF Shielding and Test (Test). The Company’s business segments are comprised of the following primary operating entities:

[0001104659-20-130486:mdna:8]
|  | ● | Aerospace & Defense: PTI Technologies Inc. (PTI); VACCO Industries (VACCO); Crissair, Inc. (Crissair); Westland Technologies, Inc. (Westland); Mayday Manufacturing Co. (Mayday), Hi-Tech Metals, Inc. (Hi-Tech); and Globe Composite Solutions, LLC (Globe). |

[0001104659-20-130486:mdna:9]
|  | ● | USG: Doble Engineering Company and Morgan Schaffer (together, Doble); and NRG Systems, Inc. (NRG). |

[0001104659-20-130486:mdna:10]
|  | ● | Test: ETS-Lindgren Inc. (ETS-Lindgren). |

[0001104659-20-130486:mdna:11]
Aerospace & Defense.  PTI, VACCO and Crissair primarily design and manufacture specialty filtration products, including hydraulic filter elements and fluid control devices used in commercial aerospace applications, unique filter mechanisms used in micro-propulsion devices for satellites and custom designed filters for manned aircraft and submarines. Westland designs, develops and manufactures elastomeric-based signature reduction solutions for U.S. naval vessels. Mayday designs and manufactures mission-critical bushings, pins, sleeves and precision-tolerance machined components for landing gear, rotor heads, engine mounts, flight controls, and actuation systems for the aerospace and defense industries. Hi-Tech is a full-service metal processor serving aerospace suppliers. Globe is a vertically integrated supplier of composite-based products and solutions for acoustic, signature-reduction, communications, sealing, vibration-reducing, surface control, and hydrodynamic-related applications.

[0001104659-20-130486:mdna:12]
USG.  Doble develops, manufactures and delivers diagnostic testing solutions that enable electric power grid operators to assess the integrity of high-voltage power delivery equipment. NRG designs and manufactures decision support tools for the renewable energy industry, primarily wind and solar.

[0001104659-20-130486:mdna:13]
Test.  ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy.

[0001104659-20-130486:mdna:14]
The Company continues to operate with meaningful growth prospects in its primary served markets and with considerable financial flexibility. The Company continues to focus on new products that incorporate proprietary design and process technologies. Management is committed to delivering shareholder value through organic growth, ongoing performance improvement initiatives, and acquisitions.

[0001104659-20-130486:mdna:15]
COVID-19 Trends and Uncertainties

[0001104659-20-130486:mdna:16]
The COVID-19 global pandemic has created significant and unprecedented challenges, and during these highly uncertain times, our top priority remains the health and safety of our employees, customers and suppliers, thereby securing the financial well-being of the Company and supporting business continuity. Our businesses have been deemed essential and are currently operational, supplying our customers with vital and necessary products. To date, our global supply chains have not been materially affected by the pandemic. Given our diverse portfolio of strong, durable businesses serving non-discretionary end-markets, the strength and resilience of our business model positions us to continue to support our long-term outlook.

[0001104659-20-130486:mdna:17]
Recognizing the uncertainty presented by this global pandemic, we are suspending our practice of providing full-year financial guidance. Our businesses are facing varying levels of pressure depending on the markets they serve as outlined below and the impact on our business cannot be reasonably estimated at this time. In response to COVID-19, we have taken actions to enhance our financial condition, while continuing to execute our long-term strategy for profitable growth. Some of the actions we have taken include: reducing a portion of executive compensation, reducing discretionary spending, minimizing capital spending, implementing hiring and salary freezes, and increasing our focus on optimizing free cash flow. These operational measures are prudent steps to maintain our liquidity and will increase our financial flexibility as we work through near-term volatility. As of September 30, 2020, we had approximately $725 million of liquidity (amount available to borrow under credit facility plus $250 million increase option and $52.6 million in cash) and net debt (debt outstanding less cash on hand) of approximately $9.8 million. Additionally, we have no debt maturities nor repayment obligations due and payable until September 2024 on our revolving credit facility. The Company has made no changes to its dividend plan. We are also monitoring the impacts of COVID-19 on the fair value of assets. We do not currently

[0001104659-20-130486:mdna:18]
anticipate any material impairments on assets as a result of COVID-19. A portion of our workforce has worked from home at times due to COVID-19, however we have not had to redesign or design new internal controls over financial reporting at this time. Depending on the duration of COVID-19, it may become necessary for us to redesign or design new internal controls over financial reporting in a future period. We do not believe such an event will have a material impact on our business. Further details by operating segment are outlined below.

[0001104659-20-130486:mdna:19]
In our Aerospace & Defense segment, our fiscal 2020 revenues were negatively impacted by a decrease of approximately $20 million related to the COVID-19 pandemic and we anticipate the slowdown in commercial aerospace deliveries and revenues continuing into fiscal 2021. For the year ended September 30, 2020, the economic uncertainty, changes in the propensity for the general public to travel by air, and reductions in demand for commercial aircraft as a result of the COVID-19 pandemic have adversely impacted net sales and operating results in certain of our Aerospace & Defense reporting units and was determined to be an event and change in circumstances that required a quantitative review of our intangible assets, long-lived assets and goodwill for impairment. We determined that there was no impairment as of and for the year ended September 30, 2020 and the fair value of each reporting unit reviewed substantially exceeded carrying value, with the exception of Mayday where fair value exceeded carrying value by 10%. At September 30, 2020, we had $30 million of goodwill recorded for Mayday. The valuation methodology we use involves estimates of discounted cash flows, which are subject to change, and if they change negatively it could result in the need to write down those assets to fair value. We will continue to monitor the impacts of COVID-19 on the fair value of assets. The defense portion of Aerospace & Defense, both military aerospace and navy products, is expected to remain at approximately historical business levels given its backlog coupled with the timing of expected platform deliveries.

[0001104659-20-130486:mdna:20]
In our Test segment, our fiscal 2020 revenues were negatively impacted by the COVID-19 pandemic due to the China facility’s three-week shutdown in February and delayed timing of installation projects caused by access limitations to customer sites. We expect the Test segment to remain at relatively normal business levels into fiscal 2021 given the strength of its backlog and its served markets, primarily related to new communications technologies such as 5G.

[0001104659-20-130486:mdna:21]
In our USG segment, our fiscal 2020 revenues were negatively impacted by approximately $20 million related to the COVID-19 pandemic as several utility customers deferred purchase orders and maintenance-related project deliveries so they could divert resources to other issues such as critical power delivery given their concerns around COVID-19. Additionally, Doble’s service business was largely on hold during the pandemic. We expect USG’s customer spending softness to continue for the next few quarters before returning to normal levels. Goodwill for Doble and NRG was $246 million and $8 million, respectively, as of September 30, 2020. We reviewed the intangible assets, long-lived assets and goodwill of our Doble and NRG businesses for impairment. The quantitative reviews determined that there was no impairment as of September 30, 2020 as the fair value of Doble substantially exceeded carrying value and the fair value of NRG exceeded carrying value by 15%. The valuation methodology we use involves estimates of discounted cash flows, which are subject to change, and if they change negatively it could result in the need to write down those assets to fair value. We will continue to monitor the impacts of COVID-19 on the fair value of assets.

[0001104659-20-130486:mdna:22]
See also Item 1A, “Risk Factors” in Part I above, and “Outlook” below for additional information.

[0001104659-20-130486:mdna:23]
Highlights of 2020

[0001104659-20-130486:mdna:24]
|  | ● | Diluted EPS – GAAP for 2020 was $3.90, consisting of $0.97 per share from continuing operations and $2.93 from discontinued operations as compared to Diluted EPS – GAAP for 2019 of $3.10, consisting of $2.97 per share from continuing operations and $0.13 per share from discontinued operations. |

[0001104659-20-130486:mdna:25]
|  | ● | Sales, net earnings and diluted earnings per share from continuing operations in 2020 were $732.9 million, $25.5 million and $0.97 per share, respectively, compared to sales, net earnings and diluted earnings per share from continuing operations in 2019 of $726.0 million, $77.5 million and $2.97 per share, respectively. |

[0001104659-20-130486:mdna:26]
|  | ● | Diluted EPS – Continuing Operations As Adjusted for 2020 was $2.76 and excludes the pension plan termination charge of $40.6 million (or $1.55 per share after tax) and $8.3 million of pretax charges (or $0.24 per share after tax) consisting primarily of facility consolidation charges for the Doble Manta facility (including employee severance and compensation benefits), asset impairment charges and the incremental costs associated with the COVID-19 pandemic. Diluted EPS – Continuing Operations As Adjusted for 2019 was $2.95 and excludes $0.4 million of income (or $0.02 per share after tax) consisting primarily of the gain on the Doble Watertown building sale partially offset by purchase accounting charges related |

[0001104659-20-130486:mdna:27]
|  |  | to the Globe acquisition and certain restructuring charges related to facility consolidations at Doble, PTI and VACCO. See “Non-GAAP Financial Measures” below. |

[0001104659-20-130486:mdna:28]
| ​ |  | Fiscal year ended |
| (Dollars in millions) |  | 2020 |  | 2019 |
| Diluted EPS – Continuing Operations GAAP | ​ | $ | 0.97 |  | 2.97 |
| Pension termination adjustment | ​ |  | 1.55 |  | — |
| Restructuring adjustments | ​ |  | 0.24 |  | (0.02) |
| Diluted EPS – Continuing Operations As Adjusted | ​ | $ | 2.76 |  | 2.95 |

[0001104659-20-130486:mdna:29]
|  | ● | Net cash provided by operating activities from continuing operations was approximately $108.5 million in 2020 compared to $100.6 million in 2019. |

[0001104659-20-130486:mdna:30]
|  | ● | At September 30, 2020, cash on hand was $52.6 million and outstanding debt was $62.4 million, for a net debt position (total debt less cash on hand) of approximately $9.8 million. |

[0001104659-20-130486:mdna:31]
|  | ● | Entered orders for 2020 from continuing operations were $798.7 million resulting in a book-to-bill ratio of 1.09x. Backlog at September 30, 2020 was $517.4 million compared to $451.6 million at September 30, 2019. |

[0001104659-20-130486:mdna:32]
|  | ● | The Company declared dividends of $0.32 per share during 2020, totaling $8.3 million in dividend payments. |

[0001104659-20-130486:mdna:33]
Results of Continuing Operations

[0001104659-20-130486:mdna:34]
Net Sales

[0001104659-20-130486:mdna:35]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | Change |  |
| ​ | ​ | Fiscal year ended | ​ | 2020 |  |
| (Dollars in millions) |  | 2020 |  | 2019 |  | vs. 2019 |  |
| Aerospace & Defense | ​ | $ | 354.3 |  | 325.7 |  | 8.8 | % |
| USG | ​ |  | 191.7 |  | 211.9 |  | (9.5) | % |
| Test | ​ |  | 186.9 |  | 188.4 |  | (0.8) | % |
| Total | ​ | $ | 732.9 |  | 726.0 |  | 1.0 | % |

[0001104659-20-130486:mdna:36]
Net sales increased $6.9 million, or 1.0%, to $732.9 million in 2020 from $726.0 million in 2019. The increase in net sales in 2020 as compared to 2019 was due to a $28.6 million increase in the Aerospace & Defense segment, partially offset by a $20.2 million decrease in the USG segment and a $1.5 million decrease in the Test segment.

[0001104659-20-130486:mdna:37]
Aerospace & Defense.

[0001104659-20-130486:mdna:38]
The $28.6 million, or 8.8%, increase in net sales in 2020 as compared to 2019 was mainly due to a $27.6 million increase in net sales from Globe (acquired in July 2019), a $13.5 million increase in net sales at VACCO due to higher shipments of space products, partially offset by a $6.1 million decrease in net sales at Mayday, a $3.7 million decrease in net sales at Crissair and a $3.0 million decrease in net sales at PTI all driven by the COVID-19 pandemic in the current year.

[0001104659-20-130486:mdna:39]
USG.

[0001104659-20-130486:mdna:40]
The $20.2 million, or 9.5%, decrease in net sales in 2020 as compared to 2019 was mainly due to a $19.1 million decrease in net sales at Doble and a $1.1 million decrease in net sales at NRG, both mainly driven by the COVID-19 pandemic in the current year as customers delayed orders and on-site testing.

[0001104659-20-130486:mdna:41]
Test.

[0001104659-20-130486:mdna:42]
The $1.5 million, or 0.8%, decrease in net sales in 2020 as compared to 2019 was mainly due to a $16.0 million decrease in net sales from the segment’s U.S. operations due to timing of test and measurement chamber projects and the COVID-19 pandemic, partially

[0001104659-20-130486:mdna:43]
offset by a $7.5 million increase in net sales from the segment’s European operations and a $7.0 million increase in net sales from the segment’s Asian operations due to timing of projects.

[0001104659-20-130486:mdna:44]
Orders and Backlog

[0001104659-20-130486:mdna:45]
New orders received in 2020 from continuing operations were $798.7 million as compared to $822.5 million in 2019. Order backlog was $517.4 million at September 30, 2020, compared to order backlog of $451.6 million at September 30, 2019. Orders are entered into backlog as firm purchase order commitments are received.

[0001104659-20-130486:mdna:46]
In 2020, the Company recorded orders of $422.7 million related to Aerospace & Defense products, $200.7 million related to USG products, and $175.3 million related to Test products. In 2019, the Company recorded orders of $409.9 million related to Aerospace & Defense products, $212.9 million related to USG products, and $199.6 million related to Test products.

[0001104659-20-130486:mdna:47]
Selling, General and Administrative Expenses

[0001104659-20-130486:mdna:48]
Selling, general and administrative (SG&A) expenses were $159.5 million, or 21.8% of net sales, in 2020, and $162.7 million, or 22.4% of net sales, in 2019.

[0001104659-20-130486:mdna:49]
The decrease in SG&A expenses in 2020 as compared to 2019 was mainly due to lower discretionary spending related to travel and other discretionary expenses due to the COVID-19 pandemic, partially offset by the addition of Globe.

[0001104659-20-130486:mdna:50]
Amortization of Intangible Assets

[0001104659-20-130486:mdna:51]
Amortization of intangible assets was $21.8 million in 2020 and $18.5 million in 2019. Amortization of intangible assets included $13.0 million and $10.8 million of amortization of acquired intangible assets in 2020 and 2019, respectively, related to the Company’s acquisitions. The amortization of acquired intangible assets related to the Company’s acquisitions is included in the Corporate operating segment’s results. The remaining amortization expenses relate to other identifiable intangible assets (primarily software, patents and licenses), which are included in the respective segment’s operating results. The increase in amortization expense in 2020 as compared to 2019 was mainly due to the acquisition of Globe in 2019.

[0001104659-20-130486:mdna:52]
Other Expenses or Income, Net

[0001104659-20-130486:mdna:53]
Other expenses, net, were $7.1 million in 2020, compared to other expenses, net, of $0.9 million in 2019. The principal components of other expenses, net, in 2020 included approximately $8 million of pretax charges consisting primarily of facility consolidation charges for the Doble Manta facility, including employee severance and compensation benefits, and asset impairment charges. The principal components of other expenses, net, in 2019 included $3 million of purchase accounting charges related to the Globe acquisition; $0.9 million of restructuring charges related to the consolidation of VACCO’s aircraft/aerospace business into PTI’s aerospace facility in Oxnard, California; approximately $1 million of charges at Doble related to facility consolidations begun in 2018; and approximately $3 million of losses on derivative instruments; partially offset by a net gain of approximately $8 million on the sale of the Doble Watertown, MA building and land. There were no other individually significant items included in other expenses, net, in 2020 or 2019.

[0001104659-20-130486:mdna:54]
Non-GAAP Financial Measures

[0001104659-20-130486:mdna:55]
The information reported herein includes the financial measures Diluted EPS – Continuing Operations As Adjusted, which the Company defines as EPS excluding the per-share net impact of the pension plan termination charge and restructuring charges related to the Company’s facility consolidation restructuring plans in 2020 and the gain on the Doble Watertown property sale in 2019 partially offset by purchase accounting charges related to the Globe acquisition and the restructuring charges incurred at Doble, PTI and VACCO during 2019; EBIT, which the Company defines as earnings before interest and taxes; and EBIT margin, which the Company defines as EBIT expressed as a percentage of net sales. Diluted EPS – Continuing Operations As Adjusted, EBIT on a consolidated basis, and EBIT margin on a consolidated basis are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, the Company believes that EBIT and EBIT margin provide investors and Management with valuable information for assessing the Company’s operating results. Management evaluates the performance of its operating segments based on EBIT and believes that EBIT is useful to investors to demonstrate the operational profitability of the Company’s business segments by excluding interest and taxes, which are generally accounted for across the entire company on a consolidated basis. EBIT

[0001104659-20-130486:mdna:56]
is also one of the measures Management uses to determine resource allocations and incentive compensation. The Company believes that the presentation of EBIT, EBIT margin and Diluted EPS – Continuing Operations As Adjusted provides important supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance determined in accordance with GAAP.

[0001104659-20-130486:mdna:57]
EBIT

[0001104659-20-130486:mdna:58]
The reconciliation of EBIT to a GAAP financial measure is as follows:

[0001104659-20-130486:mdna:59]
| (Dollars in millions) |  | 2020 |  | 2019 |
| EBIT | ​ | $ | 46.5 |  | 106.0 |
| Less: Income tax expense | ​ |  | 14.3 |  | 20.4 |
| Less: Interest expense | ​ |  | 6.7 |  | 8.1 |
| Net earnings from continuing operations | ​ | $ | 25.5 |  | 77.5 |

[0001104659-20-130486:mdna:60]
EBIT by business segment is as follows:

[0001104659-20-130486:mdna:61]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | Change |  |
| ​ | ​ | Fiscal year ended | ​ | 2020 |  |
| (Dollars in millions) |  | 2020 |  | 2019 |  | vs. 2019 |  |
| Aerospace & Defense | ​ | $ | 73.2 |  | 70.1 |  | 4.4 | % |
| % of net sales | ​ |  | 20.7 | % | 21.5 | % | ​ | ​ |
| USG | ​ |  | 24.4 |  | 52.2 |  | (53.3) | % |
| % of net sales | ​ |  | 12.7 | % | 24.6 | % | ​ | ​ |
| Test | ​ |  | 27.2 |  | 25.6 |  | 6.2 | % |
| % of net sales | ​ |  | 14.6 | % | 13.6 | % | ​ | ​ |
| Corporate | ​ |  | (78.3) |  | (41.9) |  | (86.9) | % |
| Total | ​ | $ | 46.5 |  | 106.0 |  | (56.1) | % |
| % of net sales | ​ |  | 6.3 | % | 14.6 | % |  | ​ |

[0001104659-20-130486:mdna:62]
Aerospace & Defense

[0001104659-20-130486:mdna:63]
The $3.1 million increase in EBIT in 2020 as compared to 2019 was primarily due to the $7.3 million EBIT contribution from Globe; partially offset by a $2.9 million decrease at Crissair and a $1.6 million decrease at Mayday both driven by the lower sales volumes in the current year. In addition, EBIT in 2020 was negatively impacted by $0.5 million of restructuring charges related to the consolidation of VACCO’s aircraft/aerospace business into PTI’s aerospace facility in Oxnard, California and severance charges at Crissair and $0.9 million of incremental costs associated with the COVID-19 pandemic.

[0001104659-20-130486:mdna:64]
USG

[0001104659-20-130486:mdna:65]
The $27.8 million decrease in EBIT in 2020 as compared to 2019 was mainly due to a decrease in EBIT from Doble due to the lower sales volumes in 2020 and the gain on the sale of the Doble Watertown facility of approximately $8 million in 2019. In addition, EBIT in 2020 was negatively impacted by approximately $6.6 million of restructuring charges consisting primarily of facility consolidation charges related to the Manta facility including severance and compensation benefits and asset impairment charges.

[0001104659-20-130486:mdna:66]
Test

[0001104659-20-130486:mdna:67]
The $1.6 million increase in EBIT in 2020 as compared to 2019 was primarily due to the increased sales volumes from the segment’s Asian operations partially offset by the decrease in sales volumes from the segment’s U.S. operations.

[0001104659-20-130486:mdna:68]
Corporate

[0001104659-20-130486:mdna:69]
Corporate operating charges included in 2020 consolidated EBIT increased to $78.3 million as compared to $41.9 million in 2019 mainly due to a $40.6 million pension plan termination charge as a result of the decision to terminate and annuitize the Company’s defined benefit pension plan in 2020. See Note 12 to the Consolidated Financial Statements for further discussion.

[0001104659-20-130486:mdna:70]
The “Reconciliation to Consolidated Totals (Corporate)” in Note 14 to the Consolidated Financial Statements represents Corporate office operating charges.

[0001104659-20-130486:mdna:71]
Interest Expense, Net

[0001104659-20-130486:mdna:72]
Interest expense was $6.7 million in 2020 compared to $8.1 million in 2019, primarily due to lower average outstanding borrowings ($175.6 million compared to $236.4 million) at relatively consistent average interest rates of 3.2%.

[0001104659-20-130486:mdna:73]
Income Tax Expense

[0001104659-20-130486:mdna:74]
The effective tax rates from continuing operations for 2020, 2019 and 2018 were 35.9%, 20.8% and (6.4%), respectively. The 2020 effective tax rate was unfavorably impacted by a pension plan termination charge of $40.6 million which is not deductible for tax purposes increasing the effective tax rate by 21.4%. The 2020 effective tax rate was favorably impacted by the following:  (1) an increase in the available 2019 foreign tax credit which was attributable to new information and tax planning strategies reducing the 2020 effective tax rate by 1.8%; (2) the release of a valuation allowance of $2.8 million for foreign net operating losses decreasing the effective tax rate by 7.2%; and (3) favorable 2019 state tax return to provision true-ups decreasing the effective tax rate by 1.6%.

[0001104659-20-130486:mdna:75]
The 2019 effective tax rate was favorably impacted by tax planning strategies to increase foreign tax credits claimed retrospectively. The Company reduced the valuation allowance for excess foreign tax credits by $2.4 million and recorded an amended return benefit of $0.3 million, which favorably impacted the 2019 effective tax rate by 3.0%.

[0001104659-20-130486:mdna:76]
The 2017 Tax Cut and Jobs Act (TCJA) made comprehensive changes to U.S. federal income tax laws by moving from a global to a modified territorial tax regime. As a result, cash repatriated to the U.S. is generally no longer subject to U.S. federal income tax. No provision is made for foreign withholding any applicable U.S. income taxes on the undistributed earnings of non-U.S. subsidiaries where these earnings are considered indefinitely invested or otherwise retained for continuing international operations. Determination of the amount of taxes that might be paid on these undistributed earnings if eventually remitted is not practicable.

[0001104659-20-130486:mdna:77]
Divestiture and Acquisitions

[0001104659-20-130486:mdna:78]
Information regarding the Company’s divestiture and acquisitions during 2020, 2019 and 2018 is set forth in Notes 2 and 3 to the Company’s Consolidated Financial Statements, which Notes are incorporated by reference herein.

[0001104659-20-130486:mdna:79]
All of the Company’s acquisitions have been accounted for using the purchase method of accounting, and accordingly, the respective purchase prices were allocated to the assets (including intangible assets) acquired and liabilities assumed based on estimated fair values at the date of acquisition. The financial results from these acquisitions have been included in the Company’s financial statements from the date of acquisition.

[0001104659-20-130486:mdna:80]
Pension Plan Termination

[0001104659-20-130486:mdna:81]
On November 14, 2019, the Company’s Board of Directors approved a resolution to terminate the Company’s defined benefit pension plan (the Plan), effective as of February 29, 2020. In connection with the termination, the Company contributed $25.7 million to the Plan during the fourth quarter of 2020, settled approximately $32.4 million of Plan liabilities during the fourth quarter of 2020 through lump-sum payments from existing plan assets to eligible participants who elected to receive them; and recorded approximately $40.6 million of non-cash charges associated with these settlements. During 2020, the Company settled approximately $69.1 million of Plan liabilities by entering into an agreement to purchase annuities from Massachusetts Mutual Life Insurance Company (MassMutual). This agreement covered approximately 825 active and former employees and their beneficiaries, with MassMutual assuming the future annuity payments for these individuals. Additionally, the Company settled approximately $0.1 million of Plan liabilities through a combination of annuities and direct funding to the Pension Benefit Guaranty Corporation for the remaining approximately 14 former employees and their beneficiaries. Refer to Note 12 of the Consolidated Financial Statements for more information.

[0001104659-20-130486:mdna:82]
Capital Resources and Liquidity

[0001104659-20-130486:mdna:83]
The Company’s overall financial position and liquidity are strong. Working capital from continuing operations (current assets less current liabilities) decreased to $190.6 million at September 30, 2020 from $229.8 million at September 30, 2019. Accounts receivable decreased $14.6 million during 2020 mainly due to a $12 million decrease within the USG segment and a $7.9 million decrease within the Aerospace & Defense segment, driven by timing and lower sales volumes in the current year; partially offset by an increase of approximately $4 million within the Test segment due to timing of projects. Inventories increased by $11.2 million during 2020 mainly due to a $5.4 million increase within the Aerospace & Defense segment, a $4.8 million increase within the USG segment and a $1.0 million increase within the Test segment, resulting primarily from the timing of receipt of raw materials and work-in-progress due to timing of projects. The $13.3 million decrease in accounts payable at September 30, 2020 was mainly due to a $9.8 million decrease within the Test segment and a $2.4 million decrease within the Aerospace & Defense segment due to the timing of payments.

[0001104659-20-130486:mdna:84]
Net cash provided by operating activities from continuing operations was $108.5 million and $100.6 million in 2020 and 2019, respectively.

[0001104659-20-130486:mdna:85]
Net cash used in investing activities from continuing operations was $41.1 million and $111.2 million in 2020 and 2019, respectively. The decrease in net cash used in investing activities in 2020 as compared to 2019 was due to the acquisition of Globe in 2019. Capital expenditures from continuing operations were $32.1 million and $24.2 million in 2020 and 2019, respectively. The increase in 2020 as compared to 2019 was mainly due to building improvements at the new Doble headquarters facility and an increase at VACCO primarily for construction of a new parking lot and certain machinery and equipment. There were no commitments outstanding that were considered material for capital expenditures at September 30, 2020. In addition, the Company incurred expenditures for capitalized software of $9.0 million and $8.4 million in 2020 and 2019, respectively.

[0001104659-20-130486:mdna:86]
Net cash (used) provided by financing activities from continuing operations was $(234.1) million in 2020, compared to $52.3 million in 2019. The change in 2020 as compared to 2019 was primarily due to the repayment of debt in the current year from the proceeds on the sale of the Technical Packaging business.

[0001104659-20-130486:mdna:87]
Bank Credit Facility

[0001104659-20-130486:mdna:88]
A description of the Company’s credit facility (the “Credit Facility”) is set forth in Note 9 to the Company’s Consolidated Financial Statements, which Note is incorporated by reference herein.

[0001104659-20-130486:mdna:89]
Cash flow from operations and borrowings under the Credit Facility is expected to provide adequate resources to meet the Company’s capital requirements and operational needs for the foreseeable future.

[0001104659-20-130486:mdna:90]
Dividends

[0001104659-20-130486:mdna:91]
Since 2010, the Company has paid a regular quarterly cash dividend at an annual rate of $0.32 per share. The Company paid dividends of $8.3 million in both 2020 and 2019.

[0001104659-20-130486:mdna:92]
Contractual Obligations

[0001104659-20-130486:mdna:93]
The following table shows the Company’s contractual obligations as of September 30, 2020:

[0001104659-20-130486:mdna:94]
| ​ | ​ | Payments due by period |
| ​ | ​ | ​ | ​ | ​ | Less than | ​ | 1 to 3 | ​ | 3 to 5 | ​ | More than |
| (Dollars in millions) |  | Total |  | 1 year |  | years |  | years |  | 5 years |
| Long-Term Debt Obligations | ​ | $ | 62.4 |  | 2.4 |  | — |  | 60.0 |  | — |
| Estimated Interest Payments (1) | ​ |  | 3.5 |  | 2.2 |  | 1.3 |  | — |  | — |
| Operating Lease Obligations | ​ |  | 24.0 |  | 5.6 |  | 9.0 |  | 2.4 |  | 7.0 |
| Finance Lease Obligations | ​ | ​ | 40.5 | ​ | 2.9 | ​ | 6.1 | ​ | 3.2 | ​ | 28.3 |
| Purchase Obligations (2) | ​ |  | 23.4 |  | 21.5 |  | 1.9 |  | — |  | — |
| Total | ​ | $ | 153.8 |  | 34.6 |  | 18.3 |  | 65.6 |  | 35.3 |

[0001104659-20-130486:mdna:95]
|  | (1) | Estimated interest payments for the Company’s debt obligations were calculated based on Management’s determination of the estimated applicable interest rates and payment dates. |

[0001104659-20-130486:mdna:96]
|  | (2) | A purchase obligation is defined as a legally binding and enforceable agreement to purchase goods and services that specifies all significant terms. Since the majority of the Company’s purchase orders can be cancelled, they are not included in the table above. |

[0001104659-20-130486:mdna:97]
The Company had no off-balance-sheet arrangements outstanding at September 30, 2020.

[0001104659-20-130486:mdna:98]
Share Repurchases

[0001104659-20-130486:mdna:99]
Information about the Company’s common stock repurchases is provided in Note 10 to the Consolidated Financial Statements.

[0001104659-20-130486:mdna:100]
Subsequent Event

[0001104659-20-130486:mdna:101]
On October 22, 2020, the Company acquired the equity of Advanced Technology Machining, Inc. and its affiliate TECC Grinding, Inc. (collectively TECC and ATM referred to as “ATM”), small privately held manufacturers of precision machined metal parts serving the aerospace, defense and space industries. Located in Valencia, California near Crissair’s facility, ATM has a solid customer base supplying custom-designed parts widely used on defense and commercial aircraft, as well as missile and tank programs. ATM will become part of Crissair in the Aerospace & Defense segment and has annual sales of approximately $7 million.

[0001104659-20-130486:mdna:102]
Outlook

[0001104659-20-130486:mdna:103]
In mid-year 2020, business disruptions related to the COVID-19 pandemic began to affect the Company’s operations and continued throughout the balance of the year. Entering 2021, the commercial aerospace and utility end-markets are seeing customer stabilization, as well as some notable pockets of recovery, but there is still some uncertainty as to the timing and pace of the recovery in these areas. The prospect of a viable COVID-19 vaccine will no doubt benefit and accelerate the anticipated recovery of commercial air travel and utility spending, with customers resuming normal testing protocols and equipment purchases, but Management has determined that it is advisable to wait at least another 90 days before resuming specific and finite guidance. Given this uncertainty, it is difficult to predict how 2021 will be affected using normal forecasting methodologies; therefore, the Company will continue its suspension of forward-looking guidance.

[0001104659-20-130486:mdna:104]
To assist shareholders and analysts, however, Management is offering “directional” guidance for 2021, seeing tangible signs of recovery in the second half of fiscal 2021 that point to a solid outlook for the back half of the year. Given the strength of the first half of 2020 pre-COVID, it is projected that the first half of 2021 will be slightly lower compared to 2020’s first half, but the outlook for the second half of 2021 is expected to compare favorably to the second half of 2020 given the anticipated elements of recovery. Management’s current expectations for 2021 are for growth in Sales, Adjusted EBITDA, and Adjusted EPS compared to 2020, with Adjusted EBITDA and Adjusted EPS reasonably consistent with 2019.

[0001104659-20-130486:mdna:105]
Market Risk Exposure

[0001104659-20-130486:mdna:106]
Market risks relating to the Company’s operations result primarily from changes in interest rates and changes in foreign currency exchange rates. The Company is exposed to market risk related to changes in interest rates and selectively uses derivative financial instruments, including forward contracts and swaps, to manage these risks. In 2018, the Company entered into three interest rate swaps with a notional amount of $150 million to hedge some of its exposure to variability interest payments on variable rate debt. The interest rate swaps entered into during 2018 were not designated as cash flow hedges and therefore the gain or loss on the derivative is reflected in earnings each period. The final interest rate swap was settled during September 2020, therefore, there are no outstanding interest rate swaps as of September 30, 2020.

[0001104659-20-130486:mdna:107]
The Company’s Canadian subsidiary Morgan Schaffer entered into foreign exchange contracts to manage foreign currency risk, as a portion of their revenue is denominated in U.S. dollars. All derivative instruments are reported on the balance sheet at fair value. For derivative instruments designated as cash flow hedges, the gain or loss on the derivative is deferred in accumulated other comprehensive income until recognized in earnings with the underlying hedged item.

[0001104659-20-130486:mdna:108]
The Company is also subject to foreign currency exchange rate risk inherent in its sales commitments, anticipated sales, anticipated purchases and assets and liabilities denominated in currencies other than the U.S. dollar. The foreign currencies most significant to the Company’s operations are the Canadian Dollar and the Euro. The Company occasionally hedges certain foreign currency commitments by purchasing foreign currency forward contracts. The Company does not have material foreign currency market risk; net foreign currency transaction gain/loss was less than 2% of net earnings for 2020 and 2019.

[0001104659-20-130486:mdna:109]
The Company has determined that the market risk related to interest rates with respect to its variable debt is not material. The Company estimates that if market interest rates averaged one percentage point higher, the effect would have been less than 2% of net earnings for the year ended September 30, 2020.

[0001104659-20-130486:mdna:110]
For more information about the Company’s derivative financial instruments, see Note 13 to the Company’s Consolidated Financial Statements included herein.

[0001104659-20-130486:mdna:111]
Critical Accounting Policies

[0001104659-20-130486:mdna:112]
The preparation of financial statements in conformity with U.S. generally accepted accounting principles (GAAP) requires Management to make estimates and assumptions in certain circumstances that affect amounts reported in the Consolidated Financial Statements. In preparing these financial statements, Management has made its best estimates and judgments of certain amounts included in the Consolidated Financial Statements, giving due consideration to materiality. The Company does not believe there is a great likelihood that materially different amounts would be reported under different conditions or using different assumptions related to the accounting policies described below. However, application of these accounting policies involves the exercise of judgment and use of assumptions as to future uncertainties and, as a result, actual results could differ from these estimates. The Company’s senior Management discusses the critical accounting policies described below with the Audit and Finance Committee of the Company’s Board of Directors on a periodic basis.

[0001104659-20-130486:mdna:113]
The following discussion of critical accounting policies is intended to bring to the attention of readers those accounting policies which Management believes are critical to the Consolidated Financial Statements and other financial disclosure. It is not intended to be a comprehensive list of all significant accounting policies that are more fully described in Note 1 to the Consolidated Financial Statements.

[0001104659-20-130486:mdna:114]
Revenue Recognition

[0001104659-20-130486:mdna:115]
The Company accounts for revenue in accordance with ASC Topic 606, Revenue from Contracts with Customers. The unit of account in ASC Topic 606 is a performance obligation. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration, as applicable, which are based on historical, current and forecasted information. The transaction price is allocated to each distinct performance obligation within the contract and recognized as revenue when, or as, the performance obligation is satisfied. Certain of our long-term contracts contain incentive fees that can increase the transaction price. These variable amounts generally are awarded upon achievement of certain performance metrics, program milestones or cost targets and can be based upon customer discretion. We include estimated amounts in the transaction price to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur. The estimated amounts are based on an assessment of our anticipated performance and all other information that is reasonably available to us.

[0001104659-20-130486:mdna:116]
Approximately 55% of the Company’s Aerospace & Defense segment’s revenue (26% of consolidated revenue) is recognized over time as the products do not have an alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin or the inventory is owned by the customer. Selecting the method to measure progress towards completion for our contracts requires judgment and is based on the nature of the products or services to be provided.

[0001104659-20-130486:mdna:117]
The Aerospace & Defense segment generally uses the cost-to-cost method to measure progress on our contracts, as the rate at which costs are incurred to fulfill a contract best depicts the transfer of control to the customer. Under this method, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and revenue is recorded proportionally as costs are incurred based on an estimated profit margin.

[0001104659-20-130486:mdna:118]
The Test segment generally used the milestone output method to measure progress on our contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. Under this method, the Company estimates profit as the

[0001104659-20-130486:mdna:119]
difference between total revenue and total estimated costs at completion of a contract and recognizes these revenues and costs based on milestones achieved.

[0001104659-20-130486:mdna:120]
Total contract cost estimates are based on current contract specifications and expected engineering requirements and require us to make estimates on expected profit. The estimates on profit are based on judgments we make to project the outcome of future events can often span more than one year and include labor productivity and availability, the complexity of the work to be performed, change orders issued by our customers, and other specialized engineering and production related activities. Our cost estimation process is based on historical results of contracts and historical actuals to original estimates, and the application of professional knowledge and experience of engineers and program managers along with finance professionals to these historical results. We review and update our estimates of costs quarterly or more frequently when circumstances significantly change, which can affect the profitability of our contracts.

[0001104659-20-130486:mdna:121]
For contracts where revenue is recognized over time, we generally recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. We have net revenue recognized in the current year from performance obligations satisfied in the prior year due to changes in our estimated costs to complete the related performance obligations. Anticipated losses on contracts are recognized in full in the period in which the losses become probable and estimable.

[0001104659-20-130486:mdna:122]
The impact of adjustments in contract estimates on our operating earnings can be reflected in either revenue or operating costs and expenses. The aggregate impact of adjustments in contract estimates decreased our earnings before income tax and diluted earnings per share by $2.2 million and $0.06 per share, respectively, in the current year.

[0001104659-20-130486:mdna:123]
Income Taxes

[0001104659-20-130486:mdna:124]
The Company operates in numerous taxing jurisdictions and is subject to examination by various U.S. Federal, state and foreign jurisdictions for various tax periods. The Company’s income tax positions are based on research and interpretations of the income tax laws and rulings in each of the jurisdictions in which the Company does business. Due to the subjectivity of interpretations of laws and rulings in each jurisdiction, the differences and interplay in tax laws between those jurisdictions, as well as the inherent uncertainty in estimating the final resolution of complex tax audit matters, Management’s estimates of income tax liabilities may differ from actual payments or assessments.

[0001104659-20-130486:mdna:125]
On December 22, 2017, the U.S. government enacted the TCJA, which, among other things, lowered the U.S. corporate statutory income tax rate and established a modified territorial system requiring a mandatory deemed repatriation on undistributed earnings of foreign subsidiaries. The Company completed its analysis of the impact of the TCJA during the first quarter of 2019.

[0001104659-20-130486:mdna:126]
Income taxes are accounted for under the asset and liability method. Deferred tax assets and liabilities are recognized for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. Deferred tax assets may be reduced by a valuation allowance if it is more likely than not that some portion of the deferred tax assets will not be realized. The effect on deferred tax assets and liabilities of a change in tax rates is recognized in income in the period that includes the enactment date. The Company regularly reviews its deferred tax assets for recoverability and establishes a valuation allowance when Management believes it is more likely than not such assets will not be recovered, taking into consideration historical operating results, expectations of future earnings, tax planning strategies, and the expected timing of the reversals of existing temporary differences.

[0001104659-20-130486:mdna:127]
The Company’s policy is to include interest related to unrecognized tax benefits in income tax expense and penalties in operating expense.

[0001104659-20-130486:mdna:128]
Goodwill and Other Long-Lived Assets

[0001104659-20-130486:mdna:129]
Management annually reviews goodwill and other long-lived assets with indefinite useful lives for impairment or whenever events or changes in circumstances indicate the carrying amount may not be recoverable. If the Company determines that the carrying value of the long-lived asset may not be recoverable, a permanent impairment charge is recorded for the amount by which the carrying value of the long-lived asset exceeds its fair value. Fair value is measured based on a discounted cash flow method using a discount rate

[0001104659-20-130486:mdna:130]
determined by Management to be commensurate with the risk inherent in each of our reporting units’ current business models. The estimates of cash flows and discount rate are subject to change due to the economic environment, including such factors as interest rates, expected market returns and volatility of markets served. Management believes that the estimates of future cash flows and fair value are reasonable; however, changes in estimates could result in impairment charges. At September 30, 2020, the Company has determined that no reporting units are at risk of goodwill impairment as the fair value of each reporting unit exceeded its carrying value.

[0001104659-20-130486:mdna:131]
Intangible assets with estimable useful lives are amortized over their respective estimated useful lives to their estimated residual values, and are reviewed for impairment whenever events or changes in business circumstances indicate the carrying value of the assets may not be recoverable.

[0001104659-20-130486:mdna:132]
For the year ended September 30, 2020, the economic uncertainty, changes in the propensity for the general public to travel by air, and reductions in demand for commercial aircraft as a result of the COVID-19 pandemic have adversely impacted net sales and operating results in certain of our Aerospace & Defense reporting units and was determined to be an event and change in circumstances that required a quantitative review of our intangible assets, long-lived assets and goodwill for impairment. We determined that there was no impairment as of and for the year ended September 30, 2020 and the fair value of each reporting unit reviewed substantially exceeded carrying value, with the exception of Mayday where fair value exceeded carrying value by 10%. At September 30, 2020, we had $30 million of goodwill recorded for Mayday. The valuation methodology we use involves estimates of discounted cash flows, which are subject to change, and if they change negatively it could result in the need to write down those assets to fair value.

[0001104659-20-130486:mdna:133]
In our USG segment, our fiscal 2020 revenues were negatively impacted by the COVID-19 pandemic as several utility customers deferred purchase orders and maintenance-related project deliveries so they could divert resources to other issues such as critical power delivery given their concerns around COVID-19. Additionally, Doble’s service business was largely on hold during the pandemic. We expect USG’s customer spending softness to continue for the next few quarters before returning to normal levels. Goodwill for Doble and NRG were $246 million and $8 million, respectively, as of September 30, 2020. We reviewed the intangible assets, long-lived assets and goodwill, of our Doble and NRG businesses for impairment. The quantitative reviews determined that there was no impairment as of September 30, 2020 as the fair value of Doble substantially exceeded carrying value and the fair value of NRG exceeded carrying value by 15%. The valuation methodology we use involves estimates of discounted cash flows, which are subject to change, and if they change negatively it could result in the need to write down those assets to fair value.

[0001104659-20-130486:mdna:134]
Other Matters

[0001104659-20-130486:mdna:135]
Contingencies

[0001104659-20-130486:mdna:136]
As a normal incident of the businesses in which the Company is engaged, various claims, charges and litigation are asserted or commenced from time to time against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. It is the opinion of Management that the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company are adequately reserved for, are covered by insurance or are not likely to have a material adverse effect on the Company’s results from continuing operations, capital expenditures, or competitive position.

[0001104659-20-130486:mdna:137]
Quantitative and Qualitative Disclosures about Market Risk

[0001104659-20-130486:mdna:138]
Market risks relating to the Company’s operations result primarily from changes in interest rates and changes in foreign currency exchange rates. The Company is exposed to market risk related to changes in interest rates and selectively uses derivative financial instruments, including forward contracts and swaps, to manage these risks. In 2018, the Company entered into three interest rate swaps with a notional amount of $150 million to hedge some of its exposure to variability in future interest payments on variable rate debt. The final interest rate swap was settled during September 2020, therefore, there are no outstanding interest rate swaps as of September 30, 2020. In addition, the Company’s Canadian subsidiary Morgan Schaffer has entered into foreign exchange contracts to manage foreign currency risk as a portion of their revenue is denominated in U.S. dollars. All derivative instruments are reported on the balance sheet at fair value. For derivative instruments designated as cash flow hedges, the gain or loss on the derivative is deferred in accumulated other comprehensive income until recognized in earnings with the underlying hedged item. See further discussion regarding the Company’s market risks in “Market Risk Analysis,” above.

[0001104659-20-130486:mdna:139]
Controls and Procedures

[0001104659-20-130486:mdna:140]
For a description of the Company’s evaluation of its disclosure controls and procedures, see Item 9A, “Controls and Procedures.”

[0001104659-20-130486:mdna:141]
New Accounting Pronouncements

[0001104659-20-130486:mdna:142]
Information regarding new and updated accounting standards which affect the content and/or presentation of the Company’s financial information is set forth in Note 1.U to the Consolidated Financial Statements.
