# ESE 8-K — 0001104659-20-127352 filed 2020-11-19

## item codes, every 8-K on or before 2020-11-30

- 2020-11-19 0001104659-20-127352 — 2.02, 5.02, 7.01, 9.01
- 2020-08-10 0001104659-20-092734 — 2.02, 7.01, 9.01
- 2020-05-06 0001104659-20-057442 — 2.02, 7.01, 8.01, 9.01
- 2020-02-04 0001104659-20-010640 — 2.02, 5.07, 7.01, 9.01
- 2020-01-07 0001104659-20-001789 — 2.01, 9.01
- 2019-11-19 0001104659-19-065437 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2019-11-18 0001104659-19-065096 — 1.01, 2.02, 7.01, 9.01
- 2019-09-30 0001144204-19-046523 — 1.01, 1.02, 2.03, 9.01
- 2019-08-08 0001144204-19-038567 — 2.02, 7.01, 9.01
- 2019-05-07 0001144204-19-024241 — 2.02, 5.02, 7.01, 9.01
- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2020-11-30

- none on or before 2020-11-30

## item 2.02 — earnings release, exhibit 99.1

[0001104659-20-127352:8k_2_02:1]
EX-99.1
5
tm2036170d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-20-127352:8k_2_02:2]
EXHIBIT 99.1

[0001104659-20-127352:8k_2_02:3]
| NEWS FROM |  |

[0001104659-20-127352:8k_2_02:4]
For more information contact:

[0001104659-20-127352:8k_2_02:5]
Kate Lowrey

[0001104659-20-127352:8k_2_02:6]
Director, Investor Relations

[0001104659-20-127352:8k_2_02:7]
ESCO Technologies Inc.

[0001104659-20-127352:8k_2_02:8]
(314) 213-7277

[0001104659-20-127352:8k_2_02:9]
ESCO ANNOUNCES FISCAL 2020 RESULTS

[0001104659-20-127352:8k_2_02:10]
- GAAP EPS $3.90 (Includes Technical
Packaging Gain and Pension Termination Charge) –

[0001104659-20-127352:8k_2_02:11]
- Adjusted EPS $2.76 (Tops Consensus
Estimate)

[0001104659-20-127352:8k_2_02:12]
- Net Debt of $10 Million, Leverage
Ratio 0.47x, Liquidity of $725 Million -

[0001104659-20-127352:8k_2_02:13]
ST. LOUIS, November 19, 2020 –
ESCO Technologies Inc. (NYSE: ESE) (ESCO, or the Company) today reported its operating results for the fourth quarter (Q4 2020)
and fiscal year (2020) ended September 30, 2020.

[0001104659-20-127352:8k_2_02:14]
COVID-19 Update

[0001104659-20-127352:8k_2_02:15]
Vic Richey, Chairman and Chief Executive
Officer, commented, “As we continue to manage through the COVID-19 global pandemic, we remain focused on the health and safety
of our employees, customers and suppliers, thereby securing the financial well-being of the Company.

[0001104659-20-127352:8k_2_02:16]
“Our 2020 results reflect the
importance of maintaining diversity across our end-markets, as this diversity, coupled with our strong balance sheet and
substantial liquidity will support our long-term growth. Because of our multi-segment platform, we were able to
partially mitigate COVID-19’s impact on sales and earnings as we reported 2020 sales of $733 million with an Adjusted
EBITDA of $137 million and Adjusted EPS of $2.76 per share. Additionally, we generated record cash flow in 2020 and paid down
our net debt to $10 million resulting in a 0.47 leverage ratio at September 30th. Driven by effective cost management,
solid operating execution, and acquisition contributions, we delivered solid performance in a challenging year.

[0001104659-20-127352:8k_2_02:17]
“I’m confident that our
well-tested operating model and our track record of taking action to reduce spending and resize the business will position us
for solid earnings growth as our end-markets return to normal.

[0001104659-20-127352:8k_2_02:18]
“Our deep and experienced leadership
team has us well-positioned for the future and we continue to invest in growth initiatives both organically and through acquisition.
The fundamentals of our portfolio remain strong and our goal remains the same – to create long-term shareholder
value.”

[0001104659-20-127352:8k_2_02:19]
2020 Discrete Items

[0001104659-20-127352:8k_2_02:20]
On January 2, 2020, the Company announced
that it had completed the sale of its Technical Packaging segment effective December 31, 2019 which resulted in $191 million
of gross cash proceeds and $77 million, or $2.93 per share of net earnings from discontinued operations. Earnings from discontinued
operations are excluded from Adjusted EBITDA and Adjusted EPS.

[0001104659-20-127352:8k_2_02:21]
In Q4 2020, the Company completed its previously
announced “Pension Plan Termination” and fully funded, terminated, and annuitized its defined benefit pension plan.
Annuitizing this non-strategic liability through an insurance company removes equity market risk and interest rate volatility,
reduces ongoing costs, and eliminates future cash payments. The termination resulted in a $41 million, or $1.55 per share non-cash charge, which is excluded from the calculation of Adjusted EBITDA and Adjusted EPS.

[0001104659-20-127352:8k_2_02:22]
Additionally, the Company took cost reduction
actions in Q4 2020 to lower its Aerospace & Defense (A&D) and Utility Solutions Group (USG) segments’ operating
costs by reducing headcount, eliminating certain under-performing product lines, and reducing the footprint at a less-efficient
manufacturing operation. As a result, the Company recognized $6 million, or $0.18 per share of discrete charges in Q4 2020 (total
of $8 million, or $0.24 for the full year) which are excluded from the calculation of Adjusted EBITDA and Adjusted EPS in their
respective periods. Certain additional period costs related to these items will be recognized in 2021.

[0001104659-20-127352:8k_2_02:23]
Discontinued operations, the pension termination,
and the cost reduction actions are collectively referred to as the “2020 Discrete Items” in the following discussion.

[0001104659-20-127352:8k_2_02:24]
The financial results presented include
certain non-GAAP financial measures such as EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS, as defined within the “Non-GAAP
Financial Measures” described below. Any non-GAAP financial measures presented are reconciled to their respective GAAP equivalents.

[0001104659-20-127352:8k_2_02:25]
Management believes these non-GAAP financial
measures are useful in assessing the ongoing operational profitability of the Company’s business segments, and therefore,
allow shareholders better visibility into the Company’s underlying operations. See “Non-GAAP Financial Measures”
described below.

[0001104659-20-127352:8k_2_02:26]
Subsequent Event – Acquisition

[0001104659-20-127352:8k_2_02:27]
On October 22, 2020, the Company acquired
Advanced Technology Machining, Inc. and its affiliate TECC Grinding, Inc. (collectively TECC and ATM referred to as “ATM”),
small, privately held manufacturers of precision machined metal parts serving the aerospace, defense, and space industries. Located
in Valencia, California near Crissair’s facility, ATM has a solid customer base supplying custom-designed parts widely used
on defense and commercial aircraft, as well as missile and tank programs.

[0001104659-20-127352:8k_2_02:28]
ATM will become part of Crissair in the
A&D operating segment and has annual sales of approximately $7 million with EBITDA margin percentages in
the high teens.

[0001104659-20-127352:8k_2_02:29]
Vic Richey ESCO’s Chairman and
CEO, commented, “ATM is a great addition to the Crissair portfolio of products, and I welcome the ATM team to ESCO, and
look forward to growing their sales of high-quality products which serve the same end users in A&D that we serve
today.”

[0001104659-20-127352:8k_2_02:30]
Earnings Summary – Full Year

[0001104659-20-127352:8k_2_02:31]
2020 GAAP EPS was $3.90 per share (GAAP
net earnings of $102 million) and included the net earnings impact of the 2020 Discrete Items described above. Excluding the net
earnings impact of the 2020 Discrete Items, 2020 Adjusted EPS was $2.76 per share.

[0001104659-20-127352:8k_2_02:32]
2019 GAAP EPS was $3.10 per share (GAAP
net earnings of $81 million) and included $0.15 per share from discontinued operations and other non-operating items described
in prior releases. Excluding discontinued operations and other non-operating items, 2019 Adjusted EPS was $2.95 per share.

[0001104659-20-127352:8k_2_02:33]
2020 Adjusted EBITDA was $137 million, compared
to 2019 Adjusted EBITDA of $141 million.

[0001104659-20-127352:8k_2_02:34]
Earnings Summary – Q4

[0001104659-20-127352:8k_2_02:35]
Q4 2020 GAAP EPS was ($0.81) per share (GAAP
net loss of $21 million) and included the quarterly impact of the 2020 Discrete Items. Excluding the net earnings impact of the
2020 Discrete Items, Q4 2020 Adjusted EPS was $0.90 per share.

[0001104659-20-127352:8k_2_02:36]
Q4 2019 GAAP EPS was $0.95 per share (GAAP
net earnings of $25 million) and included $0.07 per share from discontinued operations and other non-operating items described
in prior releases. Excluding discontinued operations and other non-operating items, Q4 2019 Adjusted EPS was $1.02 per share.

[0001104659-20-127352:8k_2_02:37]
Q4 2020 Adjusted EBITDA was $42 million,
compared to Q4 2019 Adjusted EBITDA of $48 million.

[0001104659-20-127352:8k_2_02:38]
Operating Highlights

[0001104659-20-127352:8k_2_02:39]
|  | · | Net sales increased $7 million in 2020 to $733 million, compared to $726 million in 2019. |

[0001104659-20-127352:8k_2_02:40]
|  | · | A&D segment sales increased $29 million (9 percent) from 2019, including a $41 million increase in navy and space sales from Globe (full year contribution), Westland, and Vacco, partially offset by lower commercial aerospace sales due to COVID-19. |

[0001104659-20-127352:8k_2_02:41]
|  | · | Test sales were $187 million in 2020 compared to $188 million in 2019, driven by strong chamber project sales, offset by timing delays on certain installation projects due to COVID-19 related customer closure mandates and on-site personnel restrictions at customer locations. |

[0001104659-20-127352:8k_2_02:42]
|  | · | USG sales decreased $20 million in 2020 due to deferrals of various project deliverables as utility customers re-aligned their short-term maintenance and spending protocols to focus on uninterrupted power delivery due to COVID-19. Maintenance deferrals also reflect various mandates restricting on-site personnel at substations, large transformers and other customer locations. Q4 2020 sales were only down $2 million from Q4 2019 as USG began seeing some recovery in customer spending. |

[0001104659-20-127352:8k_2_02:43]
|  | · | SG&A expenses decreased $3 million in 2020 driven by cost mitigation programs implemented to help offset the negative sales impact from COVID-19, despite continued spending on R&D and new product development to enhance future growth. |

[0001104659-20-127352:8k_2_02:44]
|  | · | 2020 non-cash amortization of intangible assets increased $3 million, or 18 percent, compared to 2019 as a result of the Globe acquisition. |

[0001104659-20-127352:8k_2_02:45]
|  | · | Interest expense decreased in 2020 due to the lower net debt outstanding. |

[0001104659-20-127352:8k_2_02:46]
|  | · | The effective income tax rate used for determining Adjusted EPS was approximately 18 percent in 2020 and 20 percent in 2019 as both periods were favorably impacted by tax reduction initiatives. |

[0001104659-20-127352:8k_2_02:47]
|  | · | Entered orders were $799 million in 2020 (book-to-bill of 1.09x) resulting in an ending backlog of $517 million at September 30, 2020, an increase of $66 million, or 15 percent, from September 30, 2019. |

[0001104659-20-127352:8k_2_02:48]
|  | · | 2020 net cash provided by operating activities from continuing operations was $109 million, and included a $26 million cash payment to fund the pension plan termination completed in Q4 2020. Net debt (total borrowings, less cash on hand) was $10 million at September 30, 2020 reflecting a 0.47x leverage ratio. |

[0001104659-20-127352:8k_2_02:49]
Chairman’s Commentary

[0001104659-20-127352:8k_2_02:50]
Vic Richey, Chairman and Chief Executive
Officer, commented, “While 2020 was a clearly a challenging year, there are several highlights to touch on in
this unprecedented period.

[0001104659-20-127352:8k_2_02:51]
“The key highlight of 2020 was the
strength of our cash generation, which was driven by the sale of our packaging business and our increased focus on working capital
management to improve and increase our liquidity. We believe we will benefit from this strong liquidity position during 2021 as
we continue our pursuit of acquisitions and expand our internal investments in new product development across the company.

[0001104659-20-127352:8k_2_02:52]
“The performance of the Test
segment in 2020 was also noteworthy as we increased our EBIT margin to 14.6 percent, up from 13.6 percent in 2019 despite
flat sales. Our A&D segment demonstrated its resilience by delivering an EBIT margin of 21.1 percent despite a decrease
in high-margin commercial aerospace sales. A&D’s solid margin was driven by its program, product and end-market
diversity, as the navy and defense markets remained strong which offset the decline in commercial aerospace. PTI, Crissair
and Mayday’s sales decline reflected the reduction in both OEM build rates and air traffic, while Globe, Vacco and
Westland outperformed on their navy / submarine platforms.

[0001104659-20-127352:8k_2_02:53]
“While we expect the softness in commercial
aerospace deliveries to continue for the next few quarters, the commercial aerospace industry continues to see signs of a
recovery emerging as several airlines are bringing more of their idled fleets back into service and daily aircraft passenger boarding
has been increasing.

[0001104659-20-127352:8k_2_02:54]
“The defense portion of A&D, both
military aerospace and navy products, is expected to remain strong for the foreseeable future given its sizeable backlog coupled
with the timing of expected platform deliveries.

[0001104659-20-127352:8k_2_02:55]
“We expect Test to remain relatively
solid given the strength of its served markets, primarily related to new communications technologies such as 5G and our growing
shielding business. Our view of 5G’s future is favorable given the size of the investments being made by numerous large,
global companies leading the development of this technology.

[0001104659-20-127352:8k_2_02:56]
“USG sales remained soft over the
second half of 2020 as utility customers continued deferring test equipment purchases and maintenance-related projects to focus
their resources on issues such as critical power delivery. Given their ongoing travel and site access restrictions, Doble’s
service business was largely on hold in the second half of the year while utilities tried to reduce personal safety risks.

[0001104659-20-127352:8k_2_02:57]
“On the positive side, USG’s
order pipeline was solid in 2020 with over $200 million in new orders received. A significant number of the orders at Doble related
to cyber security solutions such as the DUCe, and I’m pleased to see the enthusiasm being generated in the market surrounding
several new products and solutions recently introduced. We continue to see NRG’s end markets recovering as investments in
renewable energy have been increasing in both wind and solar. Our new products supporting solar have been growing far better than
anticipated and we expect that growth to continue.

[0001104659-20-127352:8k_2_02:58]
“We expect Doble’s customer
spending softness to continue for the next few quarters before returning to normal levels. We take comfort knowing that COVID-19
does not change the fundamentals of the global utility market as society needs reliable, safe and secure electricity. While customers
can defer testing and maintenance for a period of time, they cannot do it indefinitely without significantly increasing the risk
of catastrophic failure.

[0001104659-20-127352:8k_2_02:59]
“Doble is using this temporary pause
in the market to accelerate development of several new products and software solutions that we expect to introduce over the next
several quarters.

[0001104659-20-127352:8k_2_02:60]
“Wrapping up 2020, I’m
pleased that we were able to generate substantial cash from operations and maintain our Adjusted EBITDA margin at 19 percent despite
the lower contribution from our highest margin businesses.

[0001104659-20-127352:8k_2_02:61]
“Given our solid financial condition,
we plan to use a portion of our liquidity and debt capacity to fund future acquisitions and grow our business. We continue to evaluate
a robust pipeline of M&A opportunities, but we are taking a particularly prudent and deliberate approach evaluating our near-term
targets. As end-markets continue to settle down and more clarity appears in our targeted areas, we are comfortable adding to our
current portfolio and capitalizing on today’s slightly lower valuations.

[0001104659-20-127352:8k_2_02:62]
“Despite the recent economic
challenges, we plan to continue our history of proven cost management and believe that we will benefit from our disciplined
operating culture to minimize our risks going forward. We have positioned ourselves favorably from a cost structure
standpoint entering 2021, and we anticipate a gradual return to a more normal operating environment. I continue to have a
strong, favorable view of our future.”

[0001104659-20-127352:8k_2_02:63]
Dividend Payment

[0001104659-20-127352:8k_2_02:64]
The next quarterly cash dividend of $0.08
per share will be paid on January 19, 2021 to stockholders of record on January 4, 2021.

[0001104659-20-127352:8k_2_02:65]
2021 Annual Meeting

[0001104659-20-127352:8k_2_02:66]
The 2021 Annual Meeting of the Company’s
Shareholders will be held on February 5, 2021.

[0001104659-20-127352:8k_2_02:67]
Business Outlook – 2021 (COVID Uncertainty)

[0001104659-20-127352:8k_2_02:68]
In mid-year 2020, business disruptions
related to the pandemic started to affect the Company’s operations and continued throughout the balance of the year.
Entering 2021, the commercial aerospace and utility end-markets are seeing some degree of customer stabilization, as well as
 notable pockets of recovery.  However, there is still some uncertainty as to the timing and pace of the recovery in these
areas.

[0001104659-20-127352:8k_2_02:69]
The prospect of a viable COVID-19 vaccine
will certainly benefit and accelerate the anticipated recovery of commercial air travel and utility spending with customers resuming
normal testing protocols and equipment purchases, but Management determined it is best to take a “wait and see” approach
for at least the next 90 days before resuming specific and finite guidance.

[0001104659-20-127352:8k_2_02:70]
Given this uncertainty, it is difficult
to predict how 2021 will be affected using our normal forecasting methodologies, therefore, the Company will continue the suspension
of forward-looking guidance.

[0001104659-20-127352:8k_2_02:71]
To assist shareholders and analysts, Management
will offer “directional” guidance for 2021, by stating we are seeing tangible signs of recovery in the second half
of fiscal 2021 that point to a solid outlook for the back half of the year.

[0001104659-20-127352:8k_2_02:72]
Given the strength of the first half of
2020 pre-COVID, it is projected that the first half of 2021 will be a slightly lower comparison to 2020’s first half.
The outlook for the second half of 2021 is expected to be a favorable comparison to the second half of 2020 given the tangible
elements of recovery we are anticipating.

[0001104659-20-127352:8k_2_02:73]
Management’s current expectations
for the 2021 outlook show growth in Sales, Adjusted EBITDA, and Adjusted EPS compared to 2020, with Adjusted EBITDA and Adjusted
EPS reasonably consistent with 2019.

[0001104659-20-127352:8k_2_02:74]
Conference Call

[0001104659-20-127352:8k_2_02:75]
The Company will host a conference call
today, November 19th, at 4:00 p.m. Central Time, to discuss the Company’s 2020 results. A live audio webcast will
be available on the Company’s website at www.escotechnologies.com. Please access the website at least 15 minutes
prior to the call to register, download and install any necessary audio software. A replay of the conference call will be available
on the Company’s website noted above or by phone (dial 1-855-859-2056 and enter the pass code 2765908).

[0001104659-20-127352:8k_2_02:76]
Forward-Looking Statements

[0001104659-20-127352:8k_2_02:77]
Statements in this press release regarding
the future impacts of COVID-19, including the impact of a viable COVID-19 vaccine on the Company’s results, the financial
success of the Company, the strength of its end markets, including without limitation, the  slowdown in commercial aerospace
and the timing of expected recovery, growth in the Company’s solar business, the outlook for the A&D, Test and USG segments,
the ability to increase shareholder value, the success of acquisition efforts, internal investments in new products, the long-term
success of the Company, and any other statements which are not strictly historical are “forward-looking” statements
within the meaning of the safe harbor provisions of the federal securities laws.

[0001104659-20-127352:8k_2_02:78]
Investors are cautioned that such statements
are only predictions and speak only as of the date of this release, and the Company undertakes no duty to update them except as
may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from
those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and
business environment including but not limited to those described in Item 1A, “Risk Factors”, of the Company’s
Annual Report on Form 10-K for the fiscal year ended September 30, 2019, in Item 8.01 of the Company’s Form 8-K
filed May 6, 2020, and the following: impacts arising from COVID-19 including without limitation labor shortages due to illness,
shelter in place policies or quarantines, material shortages, transportation delays, delays or termination of Company contracts,
the inability of our suppliers to perform, weakening of economic conditions in served markets; changes in customer demands or customer
insolvencies; inability to access work sites; competition; intellectual property rights; technical difficulties; delivery delays
or defaults by customers; material changes in the costs and availability of certain raw materials; the appropriation, allocation
and availability of Government funds; the termination for convenience of Government and other customer contracts; the timing and
content of future contract awards or customer orders; performance issues with key customers, suppliers and subcontractors; labor
disputes; the impacts of natural disasters on the Company’s operations and those of the Company’s customers and suppliers;
changes in laws and regulations, including but not limited to changes in accounting standards, taxation requirements, and new or
modified tariffs; changes in interest rates; costs relating to environmental matters arising from current or former facilities;
the availability of select acquisitions; and the uncertainty regarding the ultimate resolution of current disputes, claims, litigation
or arbitration.

[0001104659-20-127352:8k_2_02:79]
Non-GAAP Financial Measures

[0001104659-20-127352:8k_2_02:80]
The financial measures EBIT, EBITDA, Adjusted
EBITDA and Adjusted EPS are presented in this press release. The Company defines “EBIT” as earnings before interest
and taxes, “EBITDA” as earnings before interest, taxes, depreciation and amortization, “Adjusted EBITDA”
as EBITDA excluding certain defined charges, and “Adjusted EPS” as GAAP earnings per share (EPS) excluding the net
impact of the items described above which were $1.73 per share in Q4 2020 and $1.79 per share in 2020.

[0001104659-20-127352:8k_2_02:81]
EBIT, EBITDA, Adjusted EBITDA and Adjusted
EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management believes that
EBIT, EBITDA and Adjusted EBITDA are useful in assessing the operational profitability of the Company’s business segments
because they exclude interest, taxes, depreciation and amortization, which are generally accounted for across the entire Company
on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company
as well as incentive compensation. The presentation of EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS provides important supplemental
information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures
to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance
determined in accordance with GAAP.

[0001104659-20-127352:8k_2_02:82]
ESCO, headquartered in St. Louis, Missouri:
Manufactures highly-engineered filtration and fluid control products for the aviation, navy, space and process markets worldwide,
as well as composite-based products and solutions for navy, defense and industrial customers; is the industry leader in RF shielding
and EMC test products; and provides diagnostic instruments, software and services for the benefit of industrial power users and
the electric utility and renewable energy industries. Further information regarding ESCO and its subsidiaries is available on the
Company’s website at www.escotechnologies.com.

[0001104659-20-127352:8k_2_02:83]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-20-127352:8k_2_02:84]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-20-127352:8k_2_02:85]
(Dollars
in thousands, except per share amounts)

[0001104659-20-127352:8k_2_02:86]
|  |  | Three Months Ended September 30, 2020 |  |  | Three Months Ended September 30, 2019 |  |
| Net Sales |  | $ | 208,030 |  |  |  | 213,177 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 129,763 |  |  |  | 126,961 |  |
| Selling, general and administrative expenses |  |  | 40,467 |  |  |  | 43,641 |  |
| Amortization of intangible assets |  |  | 5,247 |  |  |  | 5,276 |  |
| Interest expense |  |  | 1,466 |  |  |  | 2,506 |  |
| Pension plan termination charge |  |  | 40,600 |  |  |  | - |  |
| Other expenses, net |  |  | 6,948 |  |  |  | 4,201 |  |
| Total costs and expenses |  |  | 224,491 |  |  |  | 182,585 |  |
| (Loss) earnings before income taxes |  |  | (16,461 | ) |  |  | 30,592 |  |
| Income tax expense |  |  | 5,347 |  |  |  | 7,319 |  |
| (Loss) earnings from continuing operations |  |  | (21,808 | ) |  |  | 23,273 |  |
| Earnings from discontinued operations, net of tax (benefit) |  |  |  |  |  |  |  |  |
| expense of $(502) and $535, respectively |  |  | 502 |  |  |  | 1,585 |  |
| Net earnings |  | $ | (21,306 | ) |  |  | 24,858 |  |
| Diluted EPS: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | (0.83 | ) |  |  | 0.89 |  |
| Discontinued operations |  |  | 0.02 |  |  |  | 0.06 |  |
| Net earnings |  | $ | (0.81 | ) |  |  | 0.95 |  |
| Diluted - As Adjusted Basis |  |  |  |  |  |  |  |  |
| Continuing operations |  |  | $0.90 | (1) |  |  | 1.02 | (2) |
| Diluted average common shares O/S: |  |  | 26,163 |  |  |  | 26,146 |  |

[0001104659-20-127352:8k_2_02:87]
| (1) | Q4 FY 20 Adjusted EPS excludes $1.55 per share of charges related to the pension plan termination and $0.18 per share of charges incurred within the USG and A&D segments due to facility consolidation, asset impairment and severance charges in the fourth quarter of FY 20. |
| (2) | Q4 FY 19 Adjusted EPS excludes $0.13 per share net impact of purchase accounting charges related to the Globe acquisition and restructuring charges incurred primarily at Doble, PTI and VACCO during the fourth quarter of FY 19. |

[0001104659-20-127352:8k_2_02:88]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-20-127352:8k_2_02:89]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-20-127352:8k_2_02:90]
(Dollars in thousands, except per share amounts)

[0001104659-20-127352:8k_2_02:91]
|  |  | Year Ended September 30, 2020 |  |  | Year Ended September 30, 2019 |  |
| Net Sales |  | $ | 732,915 |  |  |  | 726,044 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 457,418 |  |  |  | 437,998 |  |
| Selling, general and administrative expenses |  |  | 159,490 |  |  |  | 162,734 |  |
| Amortization of intangible assets |  |  | 21,812 |  |  |  | 18,492 |  |
| Interest expense |  |  | 6,730 |  |  |  | 8,092 |  |
| Pension plan termination charge |  |  | 40,600 |  |  |  | - |  |
| Other expenses, net |  |  | 7,122 |  |  |  | 851 |  |
| Total costs and expenses |  |  | 693,172 |  |  |  | 628,167 |  |
| Earnings before income taxes |  |  | 39,743 |  |  |  | 97,877 |  |
| Income tax expense |  |  | 14,278 |  |  |  | 20,388 |  |
| Earnings from continuing operations |  |  | 25,465 |  |  |  | 77,489 |  |
| (Loss) earnings from discontinued operations, net |  |  |  |  |  |  |  |  |
| of tax expense of $269 and $789 |  |  | (601 | ) |  |  | 3,550 |  |
| Gain on sale of discontinued operations, net of tax |  |  |  |  |  |  |  |  |
| expense of $23,232 |  |  | 77,116 |  |  |  | - |  |
| Earnings from discontinued operations |  |  | 76,515 |  |  |  | 3,550 |  |
| Net earnings |  | $ | 101,980 |  |  |  | 81,039 |  |
| Diluted EPS: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.97 |  |  |  | 2.97 |  |
| Discontinued operations |  |  | 2.93 |  |  |  | 0.13 |  |
| Net earnings |  | $ | 3.90 |  |  |  | 3.10 |  |
| Diluted - As Adjusted Basis |  |  |  |  |  |  |  |  |
| Continuing operations |  |  | $2.76 | (1) |  |  | 2.95 | (2) |
| Diluted average common shares O/S: |  |  | 26,135 |  |  |  | 26,097 |  |

[0001104659-20-127352:8k_2_02:92]
| (1) | FY20 Adjusted EPS excludes $1.55 per share of charges related to the pension plan termination and $0.24 per share of charges within the USG and A&D segments related to facility consolidation, asset impairment, severance charges, and the incremental costs associated with COVID-19. |
| (2) | FY 19 Adjusted EPS excludes $0.02 per share of after-tax income mainly resulting from the gain on the sale of the Doble Watertown property partially offset by certain restructuring charges primarily at Doble, PTI & VACCO. |

[0001104659-20-127352:8k_2_02:93]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-20-127352:8k_2_02:94]
Condensed Business Segment Information (Unaudited)

[0001104659-20-127352:8k_2_02:95]
(Dollars in thousands)

[0001104659-20-127352:8k_2_02:96]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | Q4 2020 |  |  | Q4 2019 |  |  | Q4 2020 |  |  | Q4 2019 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 97,613 |  |  |  | 96,966 |  |  |  | 97,613 |  |  |  | 96,966 |  |
| USG |  |  | 52,524 |  |  |  | 54,276 |  |  |  | 52,524 |  |  |  | 54,276 |  |
| Test |  |  | 57,893 |  |  |  | 61,935 |  |  |  | 57,893 |  |  |  | 61,935 |  |
| Totals |  | $ | 208,030 |  |  |  | 213,177 |  |  |  | 208,030 |  |  |  | 213,177 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 21,555 |  |  |  | 23,050 |  |  |  | 22,075 |  |  |  | 23,459 |  |
| USG |  |  | 4,058 |  |  |  | 11,708 |  |  |  | 9,884 |  |  |  | 12,715 |  |
| Test |  |  | 9,718 |  |  |  | 10,849 |  |  |  | 9,718 |  |  |  | 10,849 |  |
| Corporate |  |  | (50,326 | ) |  |  | (12,509 | ) |  |  | (9,718 | ) |  |  | (9,349 | ) |
| Consolidated EBIT |  |  | (14,995 | ) |  |  | 33,098 |  |  |  | 31,959 |  |  |  | 37,674 |  |
| Less: Interest expense |  |  | (1,466 | ) |  |  | (2,506 | ) |  |  | (1,466 | ) |  |  | (2,506 | ) |
| Less: Income tax expense |  |  | (5,347 | ) |  |  | (7,319 | ) |  |  | (6,872 | ) |  |  | (8,386 | ) |
| Net (loss) earnings from cont ops |  | $ | (21,808 | ) |  |  | 23,273 |  |  |  | 23,621 |  |  |  | 26,782 |  |

[0001104659-20-127352:8k_2_02:97]
| Note 1: Adjusted net earnings were $23.6 million in Q4 20 which excluded $40.6 million (or $1.55 per share) net impact related to the pension plan termination and $6.3 million (or $0.18 per share) of pretax charges incurred within the USG and A&D segments due to facility consolidation, asset impairment and severance charges in the fourth quarter of FY 20. |
| Note 2: Adjusted net earnings were $26.8 million in Q4 19 which excluded $3.5 million (or $0.13 per share) net impact of the purchase accounting charges related to the Globe acquisition and the restructuring charges incurred at Doble, PTI and VACCO during the fourth quarter of FY 19. |

[0001104659-20-127352:8k_2_02:98]
| EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |  | Adjusted |  |  | Adjusted |  |
|  |  | Q4 2020 |  |  | Q4 2019 |  |  | Q4 2020 |  |  | Q4 2019 |  |
| Consolidated EBITDA |  | $ | (4,723 | ) |  |  | 43,291 |  |  |  | 42,231 |  |  |  | 47,867 |  |
| Less: Depr & Amort |  |  | (10,272 | ) |  |  | (10,193 | ) |  |  | (10,272 | ) |  |  | (10,193 | ) |
| Consolidated EBIT |  |  | (14,995 | ) |  |  | 33,098 |  |  |  | 31,959 |  |  |  | 37,674 |  |
| Less: Interest expense |  |  | (1,466 | ) |  |  | (2,506 | ) |  |  | (1,466 | ) |  |  | (2,506 | ) |
| Less: Income tax expense |  |  | (5,347 | ) |  |  | (7,319 | ) |  |  | (6,872 | ) |  |  | (8,386 | ) |
| Net (loss) earnings from cont ops |  | $ | (21,808 | ) |  |  | 23,273 |  |  |  | 23,621 |  |  |  | 26,782 |  |

[0001104659-20-127352:8k_2_02:99]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-20-127352:8k_2_02:100]
Condensed Business Segment Information (Unaudited)

[0001104659-20-127352:8k_2_02:101]
(Dollars in thousands)

[0001104659-20-127352:8k_2_02:102]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | FY 2020 |  |  | FY 2019 |  |  | FY 2020 |  |  | FY 2019 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 354,320 |  |  |  | 325,735 |  |  |  | 354,320 |  |  |  | 325,735 |  |
| USG |  |  | 191,703 |  |  |  | 211,915 |  |  |  | 191,703 |  |  |  | 211,915 |  |
| Test |  |  | 186,892 |  |  |  | 188,394 |  |  |  | 186,892 |  |  |  | 188,394 |  |
| Totals |  | $ | 732,915 |  |  |  | 726,044 |  |  |  | 732,915 |  |  |  | 726,044 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 73,213 |  |  |  | 70,142 |  |  |  | 74,618 |  |  |  | 71,316 |  |
| USG |  |  | 24,368 |  |  |  | 52,169 |  |  |  | 30,974 |  |  |  | 46,282 |  |
| Test |  |  | 27,201 |  |  |  | 25,640 |  |  |  | 27,270 |  |  |  | 25,640 |  |
| Corporate |  |  | (78,309 | ) |  |  | (41,982 | ) |  |  | (37,510 | ) |  |  | (38,153 | ) |
| Consolidated EBIT |  |  | 46,473 |  |  |  | 105,969 |  |  |  | 95,352 |  |  |  | 105,085 |  |
| Less: Interest expense |  |  | (6,730 | ) |  |  | (8,092 | ) |  |  | (6,730 | ) |  |  | (8,092 | ) |
| Less: Income tax expense |  |  | (14,278 | ) |  |  | (20,388 | ) |  |  | (16,265 | ) |  |  | (19,903 | ) |
| Net earnings from cont ops |  | $ | 25,465 |  |  |  | 77,489 |  |  |  | 72,357 |  |  |  | 77,090 |  |

[0001104659-20-127352:8k_2_02:103]
| Note 1: Adjusted net earnings were $72.4 million in FY 20 which excluded $40.6 million (or $1.55 per share) net impact related to the pension plan termination and $8.3 million (or $0.24 per share) of pretax charges within the USG and A&D segments related to facility consolidation, asset impairment, severance charges, and the incremental costs associated with COVID-19. |
| Note 2: Adjusted net earnings were $77.1 million in FY 19 which excluded $0.4 million (or $0.02 per share) of after-tax income mainly resulting from the gain on the sale of the Doble Watertown property partially offset by certain restructuring charges at Doble, PTI & VACCO. |

[0001104659-20-127352:8k_2_02:104]
| EBITDA Reconciliation to Net earnings: |  |  |  |  | Adjusted |  |  | Adjusted |  |
|  |  | FY 2020 |  |  | FY 2019 |  |  | FY 2020 |  |  | FY 2019 |  |
| Consolidated EBITDA |  | $ | 87,811 |  |  |  | 141,964 |  |  |  | 136,690 |  |  |  | 141,080 |  |
| Less: Depr & Amort |  |  | (41,338 | ) |  |  | (35,995 | ) |  |  | (41,338 | ) |  |  | (35,995 | ) |
| Consolidated EBIT |  |  | 46,473 |  |  |  | 105,969 |  |  |  | 95,352 |  |  |  | 105,085 |  |
| Less: Interest expense |  |  | (6,730 | ) |  |  | (8,092 | ) |  |  | (6,730 | ) |  |  | (8,092 | ) |
| Less: Income tax expense |  |  | (14,278 | ) |  |  | (20,388 | ) |  |  | (16,265 | ) |  |  | (19,903 | ) |
| Net earnings from cont ops |  | $ | 25,465 |  |  |  | 77,489 |  |  |  | 72,357 |  |  |  | 77,090 |  |

[0001104659-20-127352:8k_2_02:105]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Condensed Consolidated Balance Sheets (Unaudited) |
| (Dollars in thousands) |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 52,560 |  |  |  | 61,808 |  |
| Accounts receivable, net |  |  | 144,082 |  |  |  | 158,715 |  |
| Contract assets |  |  | 96,746 |  |  |  | 110,211 |  |
| Inventories |  |  | 136,189 |  |  |  | 124,956 |  |
| Other current assets |  |  | 17,053 |  |  |  | 14,190 |  |
| Assets of discontinued operations-current |  |  | - |  |  |  | 25,314 |  |
| Total current assets |  |  | 446,630 |  |  |  | 495,194 |  |
| Property, plant and equipment, net |  |  | 139,870 |  |  |  | 127,843 |  |
| Intangible assets, net |  |  | 346,632 |  |  |  | 381,605 |  |
| Goodwill |  |  | 408,063 |  |  |  | 390,256 |  |
| Operating lease assets |  |  | 21,390 |  |  |  | - |  |
| Other assets |  |  | 10,938 |  |  |  | 4,445 |  |
| Assets of discontinued operations-other |  |  | - |  |  |  | 67,377 |  |
|  |  | $ | 1,373,523 |  |  |  | 1,466,720 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt & short-term borrowings |  | $ | 22,368 |  |  |  | 20,000 |  |
| Accounts payable |  |  | 50,525 |  |  |  | 63,800 |  |
| Contract liabilities |  |  | 100,551 |  |  |  | 81,177 |  |
| Other current liabilities |  |  | 82,585 |  |  |  | 75,141 |  |
| Liabilities of discontinued operations-current |  |  | - |  |  |  | 11,517 |  |
| Total current liabilities |  |  | 256,029 |  |  |  | 251,635 |  |
| Deferred tax liabilities |  |  | 60,938 |  |  |  | 60,856 |  |
| Non-current operating lease liabilities |  |  | 16,785 |  |  |  | - |  |
| Other liabilities |  |  | 38,176 |  |  |  | 59,008 |  |
| Long-term debt |  |  | 40,000 |  |  |  | 265,000 |  |
| Liabilities of discontinued operations-other |  |  | - |  |  |  | 3,999 |  |
| Shareholders' equity |  |  | 961,595 |  |  |  | 826,222 |  |
|  |  | $ | 1,373,523 |  |  |  | 1,466,720 |  |

[0001104659-20-127352:8k_2_02:106]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Consolidated Statements of Cash Flows (Unaudited) |
| (Dollars in thousands) |
|  |  | Year Ended September 30, 2020 |  |
| Cash flows from operating activities: |  |  |  |  |
| Net earnings |  | $ | 101,980 |  |
| Earnings from discontinued operations |  |  | (76,515 | ) |
| Adjustments to reconcile net earnings to net cash |  |  |  |  |
| provided by operating activities: |  |  |  |  |
| Depreciation and amortization |  |  | 41,338 |  |
| Stock compensation expense |  |  | 5,550 |  |
| Changes in assets and liabilities |  |  | 23,793 |  |
| Effect of deferred taxes |  |  | (2,562 | ) |
| Pension contributions related to terminated pension plan |  |  | (25,650 | ) |
| Pension plan termination charge |  |  | 40,600 |  |
| Net cash provided by operating activities - continuing operations |  |  | 108,534 |  |
| Net cash used by operating activities - discontinued operations |  |  | (26,254 | ) |
| Net cash provided by operating activities |  |  | 82,280 |  |
| Cash flows from investing activities: |  |  |  |  |
| Capital expenditures |  |  | (32,108 | ) |
| Additions to capitalized software |  |  | (9,023 | ) |
| Net cash used by investing activities - continuing operations |  |  | (41,131 | ) |
| Proceeds from sale of discontinued operations |  |  | 183,812 |  |
| Capital expenditures - discontinued operations |  |  | (1,728 | ) |
| Net cash provided by investing activities - discontinued operations |  |  | 182,084 |  |
| Net cash provided by investing activities |  |  | 140,953 |  |
| Cash flows from financing activities: |  |  |  |  |
| Proceeds from long-term debt and short-term borrowings |  |  | 12,368 |  |
| Principal payments on long-term debt |  |  | (235,000 | ) |
| Dividends paid |  |  | (8,323 | ) |
| Other |  |  | (3,125 | ) |
| Net cash used by financing activities - continuing operations |  |  | (234,080 | ) |
| Net cash used by financing activities - discontinued operations |  |  | (2,140 | ) |
| Net cash used by financing activities |  |  | (236,220 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 3,739 |  |
| Net decrease in cash and cash equivalents |  |  | (9,248 | ) |
| Cash and cash equivalents, beginning of period |  |  | 61,808 |  |
| Cash and cash equivalents, end of period |  | $ | 52,560 |  |

[0001104659-20-127352:8k_2_02:107]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Other Selected Financial Data (Unaudited) -- Continuing Operations Basis |
| (Dollars in thousands) |
| Backlog And Entered Orders - Q4 FY 2020 |  | Aerospace & Defense |  |  | Test |  |  | USG |  |  | Total |  |
| Beginning Backlog - 7/1/20 |  | $ | 370,429 |  |  |  | 126,410 |  |  |  | 53,709 |  |  |  | 550,548 |  |
| Entered Orders |  |  | 71,845 |  |  |  | 53,515 |  |  |  | 49,503 |  |  |  | 174,863 |  |
| Sales |  |  | (97,613 | ) |  |  | (57,893 | ) |  |  | (52,524 | ) |  |  | (208,030 | ) |
| Ending Backlog - 9/30/20 |  | $ | 344,661 |  |  |  | 122,032 |  |  |  | 50,688 |  |  |  | 517,381 |  |

[0001104659-20-127352:8k_2_02:108]
| Backlog And Entered Orders - FY 2020 |  | Aerospace & Defense |  |  | Test |  |  | USG |  |  | Total |  |
| Beginning Backlog - 10/1/19 |  | $ | 276,273 |  |  |  | 133,571 |  |  |  | 41,715 |  |  |  | 451,559 |  |
| Entered Orders |  |  | 422,708 |  |  |  | 175,353 |  |  |  | 200,676 |  |  |  | 798,737 |  |
| Sales |  |  | (354,320 | ) |  |  | (186,892 | ) |  |  | (191,703 | ) |  |  | (732,915 | ) |
| Ending Backlog - 9/30/20 |  | $ | 344,661 |  |  |  | 122,032 |  |  |  | 50,688 |  |  |  | 517,381 |  |

[0001104659-20-127352:8k_2_02:109]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Reconciliation of Non-GAAP Financial Measures (Unaudited) |
| EPS – Adjusted Basis Reconciliation – Q4 FY 20 |  |  |  |  |
| EPS from Continuing Ops – GAAP Basis – Q4 FY 20 |  | $ | (0.83 | ) |
| Adjustments (defined below) |  |  | 1.73 |  |
| EPS from Continuing Ops – As Adjusted Basis – Q4 FY 20 |  | $ | 0.90 |  |
| Adjustments consist of $1.55 per share related to the pension plan termination and $0.18 per share of restructuring charges within the USG and A&D segments due to facility consolidation, asset impairment and severance charges in Q4 FY 20. |  |  |  |  |
| (The $1.73 per share of EPS adjustments consists of $46.9 million of pre-tax charges offset by $1.5 million of tax benefit for net impact of $45.4 million.) |  |  |  |  |
| EPS – Adjusted Basis Reconciliation – FY 20 |  |  |  |  |
| EPS from Continuing Ops – GAAP Basis – FY 20 |  | $ | 0.97 |  |
| Adjustments (defined below) |  |  | 1.79 |  |
| EPS from Continuing Ops – As Adjusted Basis – FY 20 |  | $ | 2.76 |  |
| Adjustments consist of $1.55 per share related to the pension plan termination and $0.24 per share of restructuring charges within the USG and A&D segments due to facility consolidation, asset impairment, severance and incremental costs associated with COVID-19 in FY 20. |  |  |  |  |
| (The $1.79 per share of EPS adjustments consists of $48.9 million of pre-tax charges offset by $2 million of tax benefit for net impact of $46.9 million.) |  |  |  |  |
| EPS – Adjusted Basis Reconciliation – Q4 FY 19 |  |  |  |  |
| EPS from Continuing Ops – GAAP Basis – Q4 FY 19 |  | $ | 0.89 |  |
| Adjustments (defined below) |  |  | 0.13 |  |
| EPS from Continuing Ops – As Adjusted Basis – Q4 FY 19 |  | $ | 1.02 |  |
| Adjustments consist of $0.13 per share net impact of the purchase accounting charges related to the Globe acquisition and the restructuring charges related to Doble, PTI, & VACCO during Q4 FY 19. |  |  |  |  |
| (The $0.13 per share of EPS adjustments consists of $4.6 million of pre-tax charges offset by $1.1 million of tax benefit for net impact of $3.5 million.) |  |  |  |  |
| EPS – Adjusted Basis Reconciliation – FY 19 |  |  |  |  |
| EPS from Continuing Ops – GAAP Basis – FY 19 |  | $ | 2.97 |  |
| Adjustments (defined below) |  |  | (0.02 | ) |
| EPS from Continuing Ops – As Adjusted Basis – FY 19 |  | $ | 2.95 |  |
| Adjustments consist of $0.02 per share net impact of income related to the gain on sale of the Doble Watertown property partially offset by certain restructuring charges at Doble, PTI & VACCO in FY 19. |  |  |  |  |
| (The $0.02 per share of EPS adjustments consists of $0.9 million of pre-tax income offset by $0.5 million of tax expense for net impact of $0.4 million.) |  |  |  |  |

## item 5.02 — body, verbatim

[0001104659-20-127352:8k_body:1]
Item 5.02

[0001104659-20-127352:8k_body:2]
Departure
                                         of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers;
                                         Compensatory Arrangements of Certain Officers

[0001104659-20-127352:8k_body:3]
Compensation of Executive Officers

[0001104659-20-127352:8k_body:4]
On November 17 and 18, 2020, the Human
Resources and Compensation Committee (the “Committee”) of the Company’s Board of Directors approved the following
base salaries and target cash incentive compensation opportunities for its executive officers for the Company’s 2021 fiscal
year ending September 30, 2021.

[0001104659-20-127352:8k_body:5]
The Committee determined that increases in
target total cash compensation (base salary plus cash incentive target) of 2.8%, 5.2% and 6.2% were warranted for Mr. Richey,
Mr. Muenster and Ms. Barclay, respectively. As it had done for fiscal 2020 the Committee provided Mr. Muenster and Ms. Barclay
with the discretion to allocate their increase prospectively between their base salaries and their cash incentive targets. A portion
of the base salary increase was provided to offset the elimination of the tax gross-up on perquisites effective in January 2021.
For Mr. Richey, the entire dollar amount of his increase was allocated to his base salary. Mr. Muenster and Ms. Barclay elected
to allocate their increases between their base salaries and their cash incentive targets, resulting in fiscal 2021 base salaries
of $874,000, $637,100 and $377,500 and cash incentive targets of $927,965, $499,200 and $251,000 for Mr. Richey, Mr. Muenster
and Ms. Barclay, respectively.

[0001104659-20-127352:8k_body:6]
For fiscal 2021 the Committee allocated 100% of the executive officers’ cash incentive compensation
opportunity to the Company’s Performance Compensation Plan (“PCP”). The Committee also approved the fiscal 2021
performance criteria for determining the percentage of such target incentive compensation opportunity that will actually be earned
by the executive officers, depending on actual fiscal 2021 results compared to the criteria. The Committee established two performance
criteria for fiscal 2021:

[0001104659-20-127352:8k_body:7]
·

[0001104659-20-127352:8k_body:8]
Earnings
                                         per share adjusted for certain defined non-recurring gains and charges (“Adjusted
                                         EPS”), weighted at 70% of the total target opportunity; and

[0001104659-20-127352:8k_body:9]
·

[0001104659-20-127352:8k_body:10]
Cash
                                         generated from operations at the subsidiary level, including corporate cash activity
                                         related to debt and interest payments, tax payments, and corporate
                                         general administrative expenses, and excluding corporate cash activity related to acquisitions,
                                         dividends and share repurchases (“Cash Flow”), weighted at 30% of the total
                                         target opportunity.

[0001104659-20-127352:8k_body:11]
The actual cash incentive compensation payable
under the PCP for fiscal 2021 will range from 0.2 to 2.0 times the target opportunity for both Adjusted EPS and Cash Flow, depending
on actual 2021 performance, based on a separate matrix for each of the measures.

[0001104659-20-127352:8k_body:12]
Modifications to 2018 and 2019 Long-Term
Incentive Compensation Awards

[0001104659-20-127352:8k_body:13]
On November 17,
2020, the Committee approved amendments to the April 30, 2018 and May 1, 2019 Performance-Accelerated Restricted Stock
(PARS) Award Agreements for its Named Executive Officers, Mr. Richey, Mr. Muenster and Ms. Barclay, each of whom
has agreed to the amendments. The 2018 and 2019 PARS Awards are the only ones outstanding for the Named Executive Officers.

[0001104659-20-127352:8k_body:14]
The purpose of the
amendments is to provide a “double trigger” for acceleration of the PARS awards upon a Change of Control (as defined
in the Agreements) of the Company. Vesting of the PARS Award will not accelerate if the acquirer or successor company is willing
and able to substitute a replacement award agreement, substituting for the Company common stock underlying the Award an equivalent
total value of the acquirer’s common stock which is widely held and publicly traded on the NYSE or NASDAQ, as described
in the ESCO Technologies Inc. Fourth Amended and Restated Severance Plan dated November 17, 2020 (the “Severance Plan”),
described in the section below

[0001104659-20-127352:8k_body:15]
If the substitution
is made, then vesting of the PARS Award will not occur if the executive’s employment terminates prior to the end of the
PARS vesting period by the acquirer for Cause or by the executive without Good Reason, as those terms are defined in the PARS
Award Agreements. In the event of the executive’s retirement prior to the end of the PARS vesting period the executive may
be entitled to partial vesting, as under the original PARS Awards. Vesting of the PARS Award will occur if the executive’s
employment terminates during the Severance Coverage Period Without Cause or with Good Reason, as those terms are defined in the
PARS Award Agreements.

[0001104659-20-127352:8k_body:16]
However, if the acquirer
or successor company is unwilling or unable to make the above substitution, then the executive will be entitled, subject to certain
conditions, to receive cash in an amount equal to the value of the underlying shares of Company common stock based on the average
NYSE closing price of the stock on the last ten trading days prior to the Change of Control.

[0001104659-20-127352:8k_body:17]
The form of amendment,
which is identical for all three Named Executive Officers, is included herein as Exhibit 10.1. The original forms
of the 2018 and 2019 PARS Award Agreements were filed as Exhibit 10.6(f) to the Company’s Form 10-K for
the fiscal year ended September 30, 2018 and Exhibit 10.1 to the Company’s Form 8-K filed May 7,
2019, respectively.

[0001104659-20-127352:8k_body:18]
Amendment and Restatement of Severance
Plan for Executive Officers

[0001104659-20-127352:8k_body:19]
On November 17,
2020, the Committee approved the Fourth Amended and Restated Severance Plan for the Company’s executive officers (the “Severance
Plan”).The amendments to the Severance Plan expand and broaden the “double trigger” requirement under the Severance
Plan in a similar manner to the above-described changes to the 2018 and 2019 PARS Awards, by providing that upon a Change of Control
of the Company, the executive will not be entitled to acceleration of unvested equity awards if the acquirer or successor company
is willing and able to substitute for the Company common stock underlying the awards an equivalent total value of the acquirer’s
common stock which is widely held and publicly traded on the NYSE or NASDAQ. However, if the acquirer or successor company is
unwilling or unable to make the above substitution, then the executive’s equity awards will vest immediately prior to the
Change of Control and be distributed in accordance with the terms of the award agreements. The 2018 and 2019 PARS Awards are the
only currently outstanding equity awards held by the Company’s executive officers. The amendments also make certain other
changes in the calculation of the amount due in certain cases and increase the interest rate applicable in case of the Company’s
failure to make payments when due.

[0001104659-20-127352:8k_body:20]
A copy of the Fourth
Amended and Restated Severance Plan is included herein as Exhibit 10.2, marked to show the substantive changes from
the previous version of the Severance Plan, which was filed as Exhibit 10.1 to the Company’s Form 8-K/A filed
November 30, 2015.

[0001104659-20-127352:8k_body:21]
Amendments to 2018 Omnibus Incentive
Plan

[0001104659-20-127352:8k_body:22]
On
November 17, 2020, the Committee approved an amendment and restatement of the Company’s 2018 Omnibus Incentive
Plan (the “Omnibus Plan”). The amendments deleted obsolete language relating to the former exclusion under
Section 162(m) of the Internal Revenue Code from the $1 million cap on deductibility for U.S. corporate income tax
purposes of certain performance-based executive compensation; this exclusion was repealed for tax years beginning after
December 31, 2017. The amendments also made certain minor changes in terminology and to clarify certain provisions, and
relocated the language regarding service requirements so that it would apply to all awards under the Plan rather than only to
PARS awards. The amendments do not change the compensation of the Company’s executive officers or increase the number
of shares available under the Plan. The Company does not consider the amendments to be individually or collectively
material.

[0001104659-20-127352:8k_body:23]
A copy of the Omnibus
Plan as amended and restated is included herein as Exhibit 10.3, marked to show the substantive changes from the Omnibus
Plan as originally adopted, which was filed as Exhibit 10.1 to the Company’s Form 8-K filed February 6,
2018.

[0001104659-20-127352:8k_body:24]
Changes to Terms of Future Compensation
of Non-Employee Directors

[0001104659-20-127352:8k_body:25]
On November 17,
2020, the Committee decided to implement a one-year vesting requirement on future awards of Company Common Stock to the Company’s
Non-Employee Directors. The vesting requirement will be effective beginning with the share-based component of the directors’
annual retainer currently scheduled to be awarded in January 2021.
