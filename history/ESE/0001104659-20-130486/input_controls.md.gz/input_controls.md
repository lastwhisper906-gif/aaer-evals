# ESE 10-K controls and the auditor's report


## auditors_report

[0001104659-20-130486:auditors_report:1]
F-1

[0001104659-20-130486:auditors_report:2]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001104659-20-130486:auditors_report:3]
To the Shareholders and Board of Directors

[0001104659-20-130486:auditors_report:4]
ESCO Technologies Inc.:

[0001104659-20-130486:auditors_report:5]
Opinion on the Consolidated Financial Statements

[0001104659-20-130486:auditors_report:6]
We have audited the accompanying consolidated balance sheets of ESCO Technologies Inc. and subsidiaries (the Company) as of September 30, 2020 and 2019, the related consolidated statements of operations, comprehensive income, shareholders’ equity, and cash flows for each of the years in the three-year period ended September 30, 2020, and the related notes (collectively, the consolidated financial statements). In our opinion, the consolidated financial statements present fairly, in all material respects, the financial position of the Company as of September 30, 2020 and 2019, and the results of its operations and its cash flows for each of the years in the three-year period ended September 30, 2020, in conformity with U.S. generally accepted accounting principles.

[0001104659-20-130486:auditors_report:7]
We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the Company’s internal control over financial reporting as of September 30, 2020, based on criteria established in Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission, and our report dated November 30, 2020 expressed an unqualified opinion on the effectiveness of the Company’s internal control over financial reporting.

[0001104659-20-130486:auditors_report:8]
Basis for Opinion

[0001104659-20-130486:auditors_report:9]
These consolidated financial statements are the responsibility of the Company’s management. Our responsibility is to express an opinion on these consolidated financial statements based on our audits. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001104659-20-130486:auditors_report:10]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0001104659-20-130486:auditors_report:11]
Change in Accounting Principles

[0001104659-20-130486:auditors_report:12]
As discussed in Note 1 of the consolidated financial statements, the Company has changed its method of accounting for leases as of October 1, 2019 due to the adoption of ASU No. 2016-062, Leases (ASC Topic 842) and method of accounting for revenue contracts with customers as of October 1, 2018 due to the adoption of ASU No. 2014-09, Revenue with Contracts with Customers (ASC Topic 606).

[0001104659-20-130486:auditors_report:13]
Critical Audit Matters

[0001104659-20-130486:auditors_report:14]
The critical audit matters communicated below are matters arising from the current period audit of the consolidated financial statements that were communicated or required to be communicated to the audit committee and that: (1) relate to accounts or disclosures that are material to the consolidated financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0001104659-20-130486:auditors_report:15]
Revenue recognition — Estimate of contract costs at completion

[0001104659-20-130486:auditors_report:16]
As discussed in Notes 1 and 17 to the consolidated financial statements, the Company’s Aerospace & Defense segment enters into certain long-term fixed price contracts with aerospace and defense customers to produce various products. These products do not have an alternative use and the Company has an enforceable right to payment for costs incurred plus a

[0001104659-20-130486:auditors_report:17]
F-2

[0001104659-20-130486:auditors_report:18]
reasonable margin. Revenue for these contracts is recognized over time generally using a cost-to-cost model. Under such model, the Company measures the extent of progress towards completion of these contracts based on the ratio of contract costs incurred to date to the estimate of total contract costs at completion. The estimation of these costs requires judgment by the Company given the unique product specifications and requirements for contracts related to the design, development, and manufacture of complex products.

[0001104659-20-130486:auditors_report:19]
We identified the assessment of the estimate of total contract costs at completion for certain contracts in the Aerospace & Defense segment for which revenue is recognized over time using a cost-to-cost model as a critical audit matter. Complex auditor judgment was required in evaluating expected engineering and production requirements of the contracts and the associated cost estimates for labor hours and materials, which represent assumptions with a high level of estimation uncertainty and that are also susceptible to potential management bias. Changes to these estimates may have a significant impact on the net sales and earnings recorded during the fiscal year.

[0001104659-20-130486:auditors_report:20]
The following are the primary procedures we performed to address this critical audit matter. We evaluated the design and tested the operating effectiveness of certain internal controls related to the Company’s revenue recognition process. This included controls over the accumulation and estimation of costs to complete for labor hours and materials for the contracts described above. For a selection of contracts, we compared the Company’s historical estimated costs and profit margin to the actual costs and profit margin for completed contracts to assess the Company’s ability to accurately estimate costs. We challenged the Company’s assumptions for labor hours and materials to be incurred for a selection of contracts by:

[0001104659-20-130486:auditors_report:21]
|  | ● | reading the underlying contract documents, including applicable amendments, to obtain an understanding of the contractual requirements and deliverables |

[0001104659-20-130486:auditors_report:22]
|  | ● | inquiring of financial and operational personnel of the Company to identify factors that should be considered within the cost to complete estimates |

[0001104659-20-130486:auditors_report:23]
|  | ● | comparing the costs incurred to date, as a percentage of the estimated costs at completion, to the Company’s physical production to date under the contract, including consideration of remaining contract performance risks |

[0001104659-20-130486:auditors_report:24]
|  | ● | comparing actual incurred and remaining estimated material costs to the original estimated amount of material costs at the beginning of the project plus incremental material costs due to contract modification |

[0001104659-20-130486:auditors_report:25]
|  | ● | comparing actual incurred and remaining estimated labor hours to the original estimate of labor hours at the beginning of the project plus incremental labor hours due to contract modification |

[0001104659-20-130486:auditors_report:26]
|  | ● | comparing the estimated costs at completion, which includes costs incurred to date plus estimated costs to complete, to actual costs incurred for similar products previously developed and produced, if applicable |

[0001104659-20-130486:auditors_report:27]
|  | ● | inspecting correspondence, if applicable, between the Company and the customer regarding actual and expected contract performance to date and comparing to the estimate to complete |

[0001104659-20-130486:auditors_report:28]
|  | ● | assessing the estimates for indicators of management bias by evaluating the audit evidence obtained through the procedures described above. |

[0001104659-20-130486:auditors_report:29]
Sufficiency of audit evidence obtained over net sales

[0001104659-20-130486:auditors_report:30]
As discussed in Notes 1 and 17 to the consolidated financial statements, sales are recognized primarily from the sale of products across various industries and through multiple Company subsidiaries and locations around the world. The Company recorded $732.9 million of net sales for the year ended September 30, 2020.

[0001104659-20-130486:auditors_report:31]
We identified the evaluation of the sufficiency of audit evidence obtained over net sales as a critical audit matter. Evaluating the sufficiency of audit evidence obtained over net sales required especially subjective auditor judgment because of the disaggregated nature of the Company’s operations, including revenue recognition accounting policies and procedures that differ among the various subsidiaries and locations. This included determining the Company subsidiaries and locations at which procedures were performed.

[0001104659-20-130486:auditors_report:32]
The following are the primary procedures we performed to address this critical audit matter. We applied auditor judgment to determine the nature and extent of procedures to be performed over net sales, including the determination of the Company

[0001104659-20-130486:auditors_report:33]
F-3

[0001104659-20-130486:auditors_report:34]
subsidiaries and locations at which those procedures were to be performed. At each Company subsidiary and location where procedures were performed, we:

[0001104659-20-130486:auditors_report:35]
|  | ● | evaluated the design and tested the operating effectiveness of certain internal controls related to the Company’s revenue recognition process at the applicable subsidiaries and locations; and |

[0001104659-20-130486:auditors_report:36]
|  | ● | assessed the recorded net sales for a selection of transactions by comparing the amount recognized for consistency with underlying documentation, including contracts with customers and shipping documentation, if applicable, and the Company’s revenue recognition policies. |

[0001104659-20-130486:auditors_report:37]
We evaluated the sufficiency of audit evidence obtained by assessing the results of procedures performed.

[0001104659-20-130486:auditors_report:38]
Assessing the carrying value of goodwill and indefinite-lived intangible assets of certain reporting units in the Utility Solutions Group and Aerospace & Defense segments

[0001104659-20-130486:auditors_report:39]
As discussed in Notes 1 and 4 to the consolidated financial statements, the Company reviews goodwill and other – indefinite-lived intangible assets for impairment annually and whenever events or changes in circumstances indicate it is more likely than not that the fair value of  a reporting unit or an indefinite-lived intangible asset is less than its carrying value. The Company uses a discounted cash flow method, using a discount rate determined to be commensurate with the risk inherent in each reporting unit’s business model when estimating fair value. The Company uses a relief from royalty method to estimate the fair value of indefinite-lived intangible assets.

[0001104659-20-130486:auditors_report:40]
We identified the assessment of the carrying value of goodwill and indefinite-lived intangible assets of certain reporting units in the Utility Solutions Group and Aerospace & Defense segments as a critical audit matter. The valuation of each reporting unit and the related indefinite-lived intangible assets involved estimation uncertainty in the projection of future cash flows, resulting in an increased level of subjective auditor judgment. Specifically, subjective and challenging auditor judgment was required to evaluate the forecasted revenue growth rates, gross margins, and discount rates used in the discounted cash flows to derive the fair value of the reporting unit. Additionally, subjective auditor judgment was required to assess the forecasted revenue growth rates, discount rate, and royalty rate assumptions used in the valuation of indefinite-lived intangible assets. Evaluation of the forecasted revenue growth rates and gross margins was challenging as they represented subjective determinations of future market and economic conditions that were sensitive to variation. Specialized skills and knowledge were required to evaluate the Company’s discount rate and royalty rate assumptions.

[0001104659-20-130486:auditors_report:41]
The following were the primary procedures we performed to address this critical audit matter. We evaluated the design and tested the operating effectiveness of certain internal controls over the Company’s goodwill and indefinite-lived intangible asset impairment assessment process. This included controls related to the determination of the fair value of the reporting units and indefinite-lived intangible assets and the development of forecasted revenue growth rates, gross margins, discount rates, and royalty rate assumptions. We evaluated the Company’s forecasted revenue growth rates by comparing to industry and peer company forecasted revenue growth rates. We also assessed the Company’s forecasted revenue growth rates and gross margins by comparing them to historical experience and to underlying business strategies and growth plans available for market participants for each reporting unit. We compared historical forecasted revenue growth rates and gross margins to actual results in order to assess the Company’s ability to forecast. We involved valuation professionals with specialized skills and knowledge, who assisted in:

[0001104659-20-130486:auditors_report:42]
|  | ● | evaluating the royalty rate assumptions by comparing them to royalty rate ranges developed using publicly available market data for comparable company intangible assets and affordability analyses based on profitability of the reporting unit to which the indefinite-lived intangible assets relate |

[0001104659-20-130486:auditors_report:43]
|  | ● | evaluating the discount rates by comparing them to discount rate ranges that were independently developed using publicly available market data for comparable entities. |

[0001104659-20-130486:auditors_report:44]
| /s/ KPMG LLP | ​ |

[0001104659-20-130486:auditors_report:45]
We have served as the Company’s auditor since 1990.

[0001104659-20-130486:auditors_report:46]
St. Louis, Missouri

[0001104659-20-130486:auditors_report:47]
November 30, 2020

[0001104659-20-130486:auditors_report:48]
F-4


## item_9a

[0001104659-20-130486:item_9a:1]
Item 9A. Controls and Procedures

[0001104659-20-130486:item_9a:2]
For 2020, the Company carried out an evaluation of the effectiveness of the design and operation of the Company’s disclosure controls and procedures, as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the Exchange Act). The evaluation was conducted under the supervision and with the participation of the Company’s Management, including the Company’s Chief Executive Officer and Chief Financial Officer, using the Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). Disclosure controls and procedures are designed to ensure that information required to be disclosed by the Company in reports filed or submitted under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the Securities and Exchange Commission’s rules and forms. Based upon that evaluation, the Company’s Chief Executive Officer and Chief Financial Officer concluded that the Company’s disclosure controls and procedures were effective as of September 30, 2020.

[0001104659-20-130486:item_9a:3]
There have been no changes in the Company’s internal control over financial reporting (as defined in Rule 13a-15(f) under the Exchange Act) during the fiscal quarter ended September 30, 2020 that have materially affected, or are reasonably likely to materially affect, the Company’s internal control over financial reporting. For the remainder of the information required by this item, see “Management’s Report on Internal Control over Financial Reporting” and the related “Report of Independent Registered Public Accounting Firm” of KPMG LLP, in the Financial Information section beginning on page F-1 of this Annual Report, which are incorporated into this Item by reference.
