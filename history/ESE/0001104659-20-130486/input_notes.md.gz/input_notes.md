# ESE notes — 0001104659-20-130486


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001104659-20-130486:notes:1]
1.      Summary of Significant Accounting Policies

[0001104659-20-130486:notes:2]
A.      Principles of Consolidation

[0001104659-20-130486:notes:3]
The Consolidated Financial Statements include the accounts of ESCO Technologies Inc. (ESCO) and its wholly owned subsidiaries (the Company). All significant intercompany transactions and accounts have been eliminated in consolidation.

[0001104659-20-130486:notes:4]
B.      Basis of Presentation

[0001104659-20-130486:notes:5]
The Company’s fiscal year ends on September 30. Throughout the Consolidated Financial Statements, unless the context indicates otherwise, references to a year (for example 2020) refer to the Company’s fiscal year ending on September 30 of that year.

[0001104659-20-130486:notes:6]
The Company's former Technical Packaging segment is reflected as discontinued operations in the Consolidated Financial Statements and related notes for all periods presented, in accordance with accounting principles generally accepted in the United States of America (GAAP). Prior period amounts have been reclassified to conform to the current period presentation. See Note 2.

[0001104659-20-130486:notes:7]
The Company accounts for shipping and handling costs on a gross basis and they are included in net sales. The Company accounts for taxes collected from customers and remitted to governmental authorities on a net basis and they are excluded from net sales.

[0001104659-20-130486:notes:8]
C.      Nature of Operations

[0001104659-20-130486:notes:9]
The Company is organized based on the products and services it offers and classifies its business operations in segments for financial reporting purposes. Under the current organization structure, the Company has three segments for financial reporting purposes:  Aerospace & Defense, Utility Solutions Group (USG), and RF Shielding and Test (Test).

[0001104659-20-130486:notes:10]
Aerospace & Defense:  The companies within this segment primarily design and manufacture specialty filtration products, including hydraulic filter elements and fluid control devices used in commercial aerospace applications; unique filter mechanisms used in micro-propulsion devices for satellites; custom designed filters for manned aircraft and submarines; products and systems to reduce vibration and/or acoustic signatures and otherwise reduce or obscure a vessel’s signature, and other communications, sealing, surface control and hydrodynamic related applications to enhance U.S. Navy maritime survivability; precision-tolerance machined components for the aerospace and defense industry; and metal processing services.

[0001104659-20-130486:notes:11]
USG:  The companies within this segment provide diagnostic testing solutions that enable electric power grid operators to assess the integrity of high-voltage power delivery equipment, as well as decision support tools for the renewable energy industry, primarily wind and solar.

[0001104659-20-130486:notes:12]
Test:  ETS-Lindgren Inc. provides its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy.

[0001104659-20-130486:notes:13]
D.      Use of Estimates

[0001104659-20-130486:notes:14]
The preparation of financial statements in conformity with GAAP requires Management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.

[0001104659-20-130486:notes:15]
E.      Revenue Recognition

[0001104659-20-130486:notes:16]
On October 1, 2018, we adopted ASU No. 2014-09, Revenue from Contracts with Customers (ASC 606). Significant changes to our policies resulting from the adoption are provided below. We adopted ASC 606 using the modified retrospective transition method applied to contracts that were not substantially complete at the end of fiscal year 2018. We recorded a $5.2 million adjustment to increase retained earnings to reflect the cumulative impact of adopting this standard at the beginning of fiscal year 2019, primarily related to certain long-term contracts in our Aerospace & Defense and Technical Packaging segments that converted to the cost-to-cost method for revenue recognition. The comparative information has not been restated and is reported under the accounting standards in effect for those periods.

[0001104659-20-130486:notes:17]
Revenue Recognition

[0001104659-20-130486:notes:18]
Revenue is recognized when control of the goods or services promised under the contract is transferred to the customer either at a point in time (e.g., upon delivery) or over time (e.g., as we perform under the contract). We account for a contract when it has approval and commitment from both parties, the rights and payment terms of the parties are identified, the contract has commercial substance and collectability of consideration is probable. Contracts are reviewed to determine whether there is one or multiple performance obligations. A performance obligation is a promise to transfer a distinct good or service to a customer and represents the unit of accounting for revenue recognition. For contracts with multiple performance obligations, the expected consideration, or the transaction price, is allocated to each performance obligation identified in the contract based on the relative standalone selling price of each performance obligation. Revenue is then recognized for the transaction price allocated to the performance obligation when control of the promised goods or services underlying the performance obligation is transferred.

[0001104659-20-130486:notes:19]
Payment terms with customers vary by the type and location of the customer and the products or services offered. The Company does not adjust the promised amount of consideration for the effects of significant financing components based on the expectation that the period between when the Company transfers a promised good or service to a customer and when the customer pays for that good or service will be one year or less. Arrangements with customers that include payment terms extending beyond one year are not significant.

[0001104659-20-130486:notes:20]
Aerospace & Defense: Within the Aerospace & Defense segment, approximately 45% of revenues (approximately 22% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial and military customers and have a single performance obligation as there is only one good promised or the promise to transfer the goods or services is not distinct or separately identifiable from other promises in the contract. The transaction price for these contracts reflects our estimate of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

[0001104659-20-130486:notes:21]
Approximately 55% of the segment’s revenues (approximately 26% of consolidated revenues) are accounted for over time as the product does not have an alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin or the inventory is owned by the customer. The related contracts are primarily cost-plus or fixed price contracts related to the design, development and manufacture of complex fluid control products, quiet valves, manifolds, shock and vibration dampening, thermal insulation and systems primarily for the commercial aerospace and military (U.S. Government) markets. The contracts may contain multiple products, which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. Our contracts are frequently modified for changes in contract specifications and requirements. Most of our contract modifications are for products that are not distinct from the existing contract and are accounted for as part of that existing contract.

[0001104659-20-130486:notes:22]
Contracts with the U.S. Government generally contain clauses that provide lien rights to work-in-process along with clauses that allow the customer to unilaterally terminate the contract for convenience, pay us for costs incurred plus a reasonable profit and take control of any work-in-process. Due to the continuous transfer of control to the U.S. Government, we recognize revenue over the time that we perform under the contract.

[0001104659-20-130486:notes:23]
Selecting the method to measure progress towards completion for the commercial and military contracts requires judgment and is based on the nature of the products or service to be provided. We generally use the cost-to-cost method to measure progress for our Aerospace & Defense segment contracts, as the rate at which costs are incurred to fulfill a contract best depicts the transfer of control to the customer. Under this measure, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and revenue is recorded proportionally as costs are incurred based on an estimated profit margin.

[0001104659-20-130486:notes:24]
The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Certain of our long-term contracts contain incentive fees that can increase the transaction price. These variable amounts generally are awarded upon achievement of certain performance metrics, program milestones or cost targets and can be based upon customer discretion. We include estimated amounts in the transaction price to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimates of variable consideration and determination of whether to include estimated amounts in the transaction price are based largely on an assessment of our anticipated performance and all other information that is reasonably available to us.

[0001104659-20-130486:notes:25]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to one or more years, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

[0001104659-20-130486:notes:26]
Under the typical payment terms of our long term fixed price contracts, the customer pays us either performance-based or progress payments. Performance-based payments represent interim payments based on quantifiable measures of performance or on the achievement of specified events or milestones. Progress payments are interim payments of costs incurred as the work progresses. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred, which we present as contract assets and contract liabilities, respectively, in the Consolidated Balance Sheets. Amounts billed and due from our customers are classified in Accounts receivable, net. For short term fixed price and cost-type contracts, we are generally paid within a short period of time.

[0001104659-20-130486:notes:27]
For contracts where revenue is recognized over time, we generally recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. We have net revenue recognized in the current year from performance obligations satisfied in the prior year due to changes in our estimated costs to complete the related performance obligations. Anticipated losses on contracts are recognized in full in the period in which the losses become probable and estimable.

[0001104659-20-130486:notes:28]
USG: Within the USG segment, approximately 75% of revenues (approximately 20% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and is accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

[0001104659-20-130486:notes:29]
Approximately 25% of the segment’s revenues (approximately 7% of consolidated revenues) are recognized over time as services are performed. The services accounted for under this method include an obligation to provide testing services using hardware and embedded software, software maintenance, training, lab testing, and consulting services. The related contracts contain a bundle of goods and services that are integrated in the context of the contract. Therefore, the goods and services are not distinct and the Company has a single performance obligation. Selecting the method to measure progress towards completion for these contracts requires judgment and is based on the nature of the products and service to be provided. We will recognize revenue as a series of distinct services based on each day of providing services (straight-line over the contract term) for our USG segment contracts. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Under the typical payment terms of our service contracts, the customer pays us in advance of when services are performed. Because of the timing difference of revenue recognition and customer payment, which is typically

[0001104659-20-130486:notes:30]
received upon commencement of the contract, these contracts result in deferred revenue, which we present as contract liabilities, in the Consolidated Balance Sheets.

[0001104659-20-130486:notes:31]
Included in this category, approximately 10% of the segment’s revenues (approximately 2% of consolidated revenues) are recognized based on the terms of the software contract. For contracts that transfer a software license to the customer, revenue will be recognized at a point in time. These type of software contracts represent a right to use the software, or a functional license, in which revenue should be recognized upon transfer of the license. For contracts in software as a service (SaaS) arrangements, revenue will be recognized over time. The customer receives and consumes the benefits of the SaaS arrangement through access to the system which is for a stated period. We will recognize revenue based on each day of providing access (straight-line over the contract term). The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Under the typical payment terms of our software contracts, the customer pays us in advance of when services are performed. Because of the timing difference of revenue recognition and customer payment, these contracts result in deferred revenue, which we present as contract liabilities, in the Consolidated Balance Sheets.

[0001104659-20-130486:notes:32]
Test: Within the Test segment, approximately 18% of revenues (approximately 5% of consolidated revenues) are recognized at a point in time when products such as, antennas and probes are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

[0001104659-20-130486:notes:33]
Approximately 82% of the segment’s revenues (approximately 20% of consolidated revenues) are recorded over time as the product does not have an alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin. Products accounted for under this guidance include the construction and installation of test chambers to a buyer’s specifications that provide its customers with the ability to measure and contain magnetic, electromagnetic and acoustic energy. The goods and services related to each installed test chamber are not distinct due to the significant amount of integration provided and each installed chamber is accounted for as a single performance obligation. Selecting the method to measure progress towards completion for these contracts requires judgment and is based on the nature of the products and service to be provided. We use milestones to measure progress for our Test segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. For arrangements that are accounted for under this guidance, the Company estimates profit as the difference between total revenue and total estimated cost of a contract and recognizes these revenues and costs based primarily on contract milestones. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable.

[0001104659-20-130486:notes:34]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to a year, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

[0001104659-20-130486:notes:35]
Under the typical payment terms of our fixed price contracts, the customer pays us either performance-based or progress payments. Performance-based payments represent interim payments based on quantifiable measures of performance or on the achievement of specified events or milestones. Progress payments are interim payments of costs incurred as the work progresses. Because of the timing difference of revenue recognition and customer billing, these contracts result in revenue recognized in excess of billings and billings in excess of costs incurred, which we present as contract assets and contract liabilities, respectively, in the Consolidated Balance Sheets. Amounts billed and due from our customers are classified in Accounts receivable, net.

[0001104659-20-130486:notes:36]
Contract Assets and Liabilities

[0001104659-20-130486:notes:37]
Contract assets arise from contracts when revenue is recognized over time and the amount of revenue recognized, including our estimate of variable consideration that has been included in the transaction price, exceeds the amount billed to the customer. These amounts are included in contract assets until the right to payment is no longer conditional on events other than the passage of time. These contract assets are reclassified to receivables when the right to consideration becomes unconditional. Contract liabilities include deposits, deferred revenue, upfront payments and billings in excess of revenue recognized. Liabilities for customer rebates and discounts are included in other current liabilities in the accompanying balance sheet.

[0001104659-20-130486:notes:38]
See the further discussion of the Company’s revenue recognition in Note 17 below.

[0001104659-20-130486:notes:39]
Prior to Adoption of ASC 606

[0001104659-20-130486:notes:40]
Prior to October 1, 2018, Management recognized revenue consistent with ASC 605. The Aerospace & Defense segment was most impacted by the change in the timing of revenue recognition. Under ASC 605, in 2018 the Aerospace & Defense segment recognized 85% of revenues upon delivery of products (when title and risk of ownership transfers) and when the other general conditions to revenue recognition (collectability of revenues is probable, there is evidence of an arrangement, fees are fixed and determinable) were met, and 15% of revenues under percentage-of-completion. The change to recording more revenue over time as costs are incurred at the Aerospace & Defense segment is the result of the products not having an alternative use and the Company having an enforceable right to payment for costs incurred plus a reasonable margin or the inventory is owned by the customer.

[0001104659-20-130486:notes:41]
The timing of revenue recognition under ASC 605 and ASC 606 was similar for the USG and Test segments. In 2018, the USG segment recognized 25% of revenues under percentage-of-completion and 75% of revenues when products were delivered or services performed (when title and risk of ownership transfers) and when the other general conditions to revenue recognition (collectability of revenues is probable, there is evidence of an arrangement, fees are fixed and determinable) were met. In 2018, the Test segment recognized 75% of revenues under percentage-of-completion and 25% of revenues when products were delivered or services performed (when title and risk of ownership transfers).

[0001104659-20-130486:notes:42]
F.      Cash and Cash Equivalents

[0001104659-20-130486:notes:43]
Cash equivalents include temporary investments that are readily convertible into cash, such as money market funds, with original maturities of three months or less.

[0001104659-20-130486:notes:44]
G.      Accounts Receivable

[0001104659-20-130486:notes:45]
Accounts receivable have been reduced by an allowance for amounts that the Company estimates are uncollectible in the future. This estimated allowance is based on Management’s evaluation of the financial condition of the customer and historical write-off experience.

[0001104659-20-130486:notes:46]
H.      Inventories

[0001104659-20-130486:notes:47]
Inventories are valued at the lower of cost (first-in, first-out) or market value. Inventories are regularly reviewed for excess quantities and obsolescence based upon historical experience, specific identification of discontinued items, future demand, and market conditions. Inventories under long-term contracts reflect accumulated production costs, factory overhead, initial tooling and other related costs less the portion of such costs charged to cost of sales.

[0001104659-20-130486:notes:48]
I.      Property, Plant and Equipment

[0001104659-20-130486:notes:49]
Property, plant and equipment are recorded at cost. Depreciation and amortization are computed primarily on a straight-line basis over the estimated useful lives of the assets: buildings, 10-40 years; machinery and equipment, 3-10 years; and office furniture and equipment, 3-10 years. Leasehold improvements are amortized over the remaining term of the applicable lease or their estimated useful lives, whichever is shorter. Long-lived tangible assets are reviewed for impairment whenever events or changes in business circumstances indicate the carrying value of the assets may not be recoverable. Impairment losses are recognized based on fair value.

[0001104659-20-130486:notes:50]
J.      Leases

[0001104659-20-130486:notes:51]
The Company’s lease agreements primarily relate to office space, manufacturing facilities, and machinery and equipment. The Company determines at lease inception whether an arrangement that provides control over the use of an asset is a lease. The Company recognizes at lease commencement a right-of-use (ROU) asset and lease liability based on the present value of the future lease payments over the lease term. The Company has elected not to recognize a ROU asset and lease liability for leases with terms of 12 months or less. Certain of the Company’s leases include options to extend the term of the lease for up to 20 years. When it is reasonably certain that the Company will exercise the option, Management includes the impact of the option in the lease term for purposes of determining total future lease payments. As most of the Company’s lease agreements do not explicitly state the discount rate implicit in the lease, Management uses the Company’s incremental borrowing rate on the commencement date to calculate the present value of future payments based on the tenor of each arrangement.

[0001104659-20-130486:notes:52]
K.      Goodwill and Other Long-Lived Intangible Assets

[0001104659-20-130486:notes:53]
Goodwill represents the excess of purchase price over the fair value of net identifiable assets acquired in business acquisitions. Management annually reviews goodwill and other long-lived assets with indefinite useful lives for impairment or whenever events or changes in circumstances indicate the carrying amount may be less than fair value. If the Company determines that the carrying value of the long-lived asset or reporting unit is less than fair value, a permanent impairment charge is recorded for the amount by which the carrying value of the long-lived asset exceeds its fair value. Fair value of the Company’s reporting units is measured based on a discounted cash flow method using a discount rate determined by Management to be commensurate with the risk inherent in each of our reporting units’ current business models. Fair value for trade names is determined using a generally accepted valuation method based on an income approach called the relief from royalty method. During 2020, the revenue softness in the Company’s Aerospace & Defense segment as well as its USG segment due to the COVID-19 pandemic led management to perform a quantitative impairment analysis, which included a detailed calculation of the fair value of its trade names and reporting units related to certain reporting units within these segments. The results of these impairment analyses indicated that the fair values of the trade names and reporting units are not less than their carrying values. The Company’s estimates of discounted cash flows to derive the fair value were measured in accordance with ASC 350, Intangibles – Goodwill and Other. The Company is using estimates of discounted cash flows that may change, and if they change negatively it could result in the need to write down those assets to fair value.

[0001104659-20-130486:notes:54]
Other intangible assets represent costs allocated to identifiable intangible assets, principally customer relationships, capitalized software, patents, trademarks, and technology rights. Intangible assets with estimable useful lives are amortized over their respective estimated useful lives to their estimated residual values, and are reviewed for impairment whenever events or changes in business circumstances indicate the carrying value of the assets may not be recoverable.

[0001104659-20-130486:notes:55]
See Note 4 regarding goodwill and other intangible assets activity.

[0001104659-20-130486:notes:56]
L.      Capitalized Software

[0001104659-20-130486:notes:57]
The costs incurred for the development of computer software that will be sold, leased, or otherwise marketed are charged to expense when incurred as research and development until technological feasibility has been established for the product. Technological feasibility is typically established upon completion of a detailed program design. Costs incurred after this point are capitalized on a project-by-project basis. Capitalized costs consist of internal and external development costs. Upon general release of the product to customers, the Company ceases capitalization and begins amortization, which is calculated on a project-by-project basis as the greater of (1) the ratio of current gross revenues for a product to the total of current and anticipated future gross revenues for the product or (2) the straight-line method over the estimated economic life of the product. The Company generally amortizes the software development costs over a three-to-seven year period based upon the estimated future economic life of the product. Factors considered in determining the estimated future economic life of the product include anticipated future revenues, and changes in software and hardware technologies. Management annually reviews the carrying values of capitalized costs for impairment or whenever events or changes in circumstances indicate the carrying amount may not be recoverable. If expected cash flows are insufficient to recover the carrying amount of the asset, then an impairment loss is recognized to state the asset at its net realizable value.

[0001104659-20-130486:notes:58]
M.      Income Taxes

[0001104659-20-130486:notes:59]
Income taxes are accounted for under the asset and liability method. Deferred tax assets and liabilities are recognized for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. Deferred tax assets may be reduced by a valuation allowance if it is more likely than not that some portion or all of the deferred tax assets will not be realized. The effect on deferred tax assets and liabilities of a change in tax rates is recognized in income in the period that includes the enactment date. The Company regularly reviews its deferred tax assets for recoverability and establishes a valuation allowance when Management believes it is more likely than not such assets will not be recovered, taking into consideration historical operating results, expectations of future earnings, tax planning strategies, and the expected timing of the reversals of existing temporary differences.

[0001104659-20-130486:notes:60]
N.      Research and Development Costs

[0001104659-20-130486:notes:61]
Company-sponsored research and development costs include research and development and bid and proposal efforts related to the Company’s products and services. Company-sponsored product development costs are charged to expense when incurred. Customer-sponsored research and development costs incurred pursuant to contracts are accounted for similarly to other program costs. Customer-sponsored research and development costs refer to certain situations whereby customers provide funding to support specific contractually defined research and development costs. Total Company and customer-sponsored research and development expenses were approximately $13.3 million, $12.1 million and $10.9 million for 2020, 2019 and 2018, respectively. These expense amounts exclude certain engineering costs primarily associated with product line extensions, modifications and maintenance, which amounted to approximately $16.1 million, $15.8 million and $13.1 million for 2020, 2019 and 2018, respectively.

[0001104659-20-130486:notes:62]
O.      Foreign Currency Translation

[0001104659-20-130486:notes:63]
The financial statements of the Company’s foreign operations are translated into U.S. dollars in accordance with FASB ASC Topic 830, Foreign Currency Matters. The resulting translation adjustments are recorded as a separate component of accumulated other comprehensive income.

[0001104659-20-130486:notes:64]
P.      Earnings Per Share

[0001104659-20-130486:notes:65]
Basic earnings per share is calculated using the weighted average number of common shares outstanding during the period. Diluted earnings per share is calculated using the weighted average number of common shares outstanding during the period plus shares

[0001104659-20-130486:notes:66]
issuable upon the assumed exercise of dilutive common share options and vesting of performance-accelerated restricted shares using the treasury stock method. There are no anti-dilutive shares.

[0001104659-20-130486:notes:67]
The number of shares used in the calculation of earnings per share for each year presented is as follows:

[0001104659-20-130486:notes:68]
| (in thousands) |  | 2020 |  | 2019 |  | 2018 |
| Weighted Average Shares Outstanding - Basic |  | 26,010 |  | 25,946 |  | 25,874 |
| Performance-Accelerated Restricted Stock |  | 125 |  | 151 |  | 184 |
| Shares - Diluted |  | 26,135 |  | 26,097 |  | 26,058 |

[0001104659-20-130486:notes:69]
Q.      Share-Based Compensation

[0001104659-20-130486:notes:70]
The Company provides compensation benefits to certain key employees under several share-based plans providing for employee stock options and/or performance-accelerated restricted shares (restricted shares), and to non-employee directors under a non-employee directors compensation plan. Share-based payment expense is measured at the grant date based on the fair value of the award and is recognized on a straight-line basis over the requisite service period (generally the vesting period of the award).

[0001104659-20-130486:notes:71]
R.      Accumulated Other Comprehensive Loss

[0001104659-20-130486:notes:72]
Accumulated other comprehensive loss of $(3.7) million at September 30, 2020 consisted of currency translation adjustments. Accumulated other comprehensive loss of $(44.0) million at September 30, 2019 consisted of $(37.0) million related to the pension net actuarial loss; and $(7.0) million related to currency translation adjustments.

[0001104659-20-130486:notes:73]
S.      Derivative Financial Instruments

[0001104659-20-130486:notes:74]
All derivative financial instruments are reported on the balance sheet at fair value. The accounting for changes in fair value of a derivative instrument depends on whether it has been designated and qualifies as a hedge and on the type of hedge. For each derivative instrument designated as a cash flow hedge, the effective portion of the gain or loss on the derivative is deferred in accumulated other comprehensive income until recognized in earnings with the underlying hedged item. For each derivative instrument designated as a fair value hedge, the gain or loss on the derivative and the offsetting gain or loss on the hedged item are recognized immediately in earnings. Regardless of type, a fully effective hedge will result in no net earnings impact while the derivative is outstanding. To the extent that any hedge is ineffective at offsetting cash flow or fair value changes in the underlying hedged item, there could be a net earnings impact.

[0001104659-20-130486:notes:75]
T.      Fair Value Measurements

[0001104659-20-130486:notes:76]
Fair value is defined as the price at which an asset could be exchanged in a current transaction between knowledgeable, willing parties or the amount that would be paid to transfer a liability to a new obligor, not the amount that would be paid to settle the liability with the creditor. Where available, fair value is based on observable market prices or parameters or derived from such prices or parameters. Where observable prices or inputs are not available, valuation models are applied. These valuation techniques involve some level of Management estimation and judgment, the degree of which is dependent on the price transparency for the instruments or market and the instruments’ complexity.

[0001104659-20-130486:notes:77]
The accounting guidance establishes a three-level hierarchy for disclosure of fair value measurements, based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date, as follows:

[0001104659-20-130486:notes:78]
Level 1 – Inputs to the valuation methodology are quoted prices (unadjusted) for identical assets or liabilities in active markets.

[0001104659-20-130486:notes:79]
Level 2 –Inputs to the valuation methodology include quoted prices for similar assets and liabilities in active markets, and inputs that are observable for the asset or liability, either directly or indirectly, for substantially the full term of the financial instrument.

[0001104659-20-130486:notes:80]
Level 3 – Inputs to the valuation methodology are unobservable and significant to the fair value measurement.

[0001104659-20-130486:notes:81]
Financial Assets and Liabilities

[0001104659-20-130486:notes:82]
The Company has estimated the fair value of its financial instruments as of September 30, 2020 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables and other current assets and liabilities approximate fair value because of the short maturity of those instruments. The carrying amounts due under the revolving credit facility approximate fair value as the interest on outstanding borrowings is calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election.

[0001104659-20-130486:notes:83]
Nonfinancial Assets and Liabilities

[0001104659-20-130486:notes:84]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during 2020.

[0001104659-20-130486:notes:85]
U.      New Accounting Standards

[0001104659-20-130486:notes:86]
In February 2016, the FASB issued ASU No. 2016-062, “Leases” (ASU 2016-02) which supersedes ASC 840, “Leases” and creates a new topic, ASC 842, “Leases.” Subsequent to the issuance of ASU 2016-02, ASC 842 was amended by various updates that amend and clarify the impact and implementation of the aforementioned update. Effective October 1, 2019, the Company adopted these updates using the optional transition method. These updates require lessees to recognize a lease liability and a lease asset for all leases, including operating leases, with a term greater than 12 months on its balance sheet. Upon initial application, the provisions of these updates are required to be applied using the modified retrospective method which requires retrospective adoption to each prior reporting period presented with the cumulative effect of adoption recorded to the earliest reporting period presented. An optional transition method can be utilized which requires retrospective adoption beginning on the date of adoption with the cumulative effect of initially applying these updates recognized at the date of initial adoption. The standard also provided several optional practical expedients for use in transition. The Company elected to use what the FASB has deemed the “package of practical expedients,” which allowed the Company not to reassess previous conclusions regarding lease identification, lease classification and the accounting treatment for initial direct costs. These updates also expand the required quantitative and qualitative disclosures surrounding leases. The adoption resulted in the addition of “right of use” assets of approximately $20 million and lease liabilities of approximately $23 million in the Consolidated Balance Sheet, with no significant change to the Consolidated Statements of Operations or Cash Flows. Refer to Note 16 for further discussion.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001104659-20-130486:notes:87]
2.      Technical Packaging Divestiture

[0001104659-20-130486:notes:88]
On December 31, 2019, pursuant to an Equity Purchase Agreement entered into on November 15, 2019, the Company completed the sale of its Technical Packaging business segment, consisting of the Company's wholly-owned subsidiaries Thermoform Engineered Quality LLC, Plastique Ltd. and Plastique sp. z o.o. (the "Technical Packaging Business"), to Sonoco Plastics, Inc. and Sonoco Holdings, Inc. ("Buyers"), two wholly-owned subsidiaries of Sonoco Products Company (NYSE:SON). The companies within this segment provide innovative solutions to the medical and commercial markets for thermoformed packages and specialty products using a wide variety of thin gauge plastics and pulp. Results of operations, financial position and cash flows for the Technical Packaging business are reflected as discontinued operations in the Consolidated Financial Statements and related notes for all periods presented.

[0001104659-20-130486:notes:89]
Net sales from the Technical Packaging business were $16.5 million, $86.9 million and $87.9 million in 2020, 2019 and 2018, respectively. Pretax (loss) earnings from the Technical Packaging business was $(0.3) million, $4.3 million and $6.9 million in 2020, 2019 and 2018, respectively. The Company received net proceeds from the sale of approximately $184 million and recorded a $76.5 million after-tax gain on the sale in 2020. The Company finalized the working capital adjustment and paid $0.2 million to the buyer during the third quarter of 2020.

[0001104659-20-130486:notes:90]
The major classes of assets and liabilities of the Technical Packaging business included in the Consolidated Balance Sheet at September 30, 2019 are shown below (in millions).

[0001104659-20-130486:notes:91]
| ​ |  | September 30, 2019 |
| Assets: | ​ |  |  |
| Accounts receivable, net |  | $ | 15.7 |
| Contract assets, net | ​ |  | 5.1 |
| Inventories | ​ |  | 3.9 |
| Other current assets | ​ |  | 0.6 |
| Current assets | ​ |  | 25.3 |
| Property, plant & equipment, net | ​ |  | 33.6 |
| Intangible assets, net | ​ |  | 11.4 |
| Goodwill | ​ |  | 19.0 |
| Other assets | ​ |  | 3.4 |
| Total assets |  | $ | 92.7 |
| Liabilities: | ​ |  | ​ |
| Accounts payable |  | $ | 7.6 |
| Accrued expenses and other current liabilities | ​ |  | 3.9 |
| Current liabilities | ​ |  | 11.5 |
| Other liabilities | ​ |  | 4.0 |
| Total liabilities |  | $ | 15.5 |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001104659-20-130486:notes:92]
3.      Acquisitions

[0001104659-20-130486:notes:93]
2019

[0001104659-20-130486:notes:94]
On July 2, 2019 the Company acquired Globe Composite Solutions, LLC, for a purchase price of approximately $95 million, net of cash acquired. Globe, based in Stoughton, Massachusetts, is a well-established, vertically integrated supplier of mission-critical composite-based products and solutions for navy, defense, and industrial customers, Globe has annualized sales of approximately $37 million. Since the date of acquisition, the operating results for Globe have been included in the Company’s Aerospace & Defense segment. Based on the purchase price allocation, the Company recorded approximately $3.5 million of accounts receivable, $3.5 million of inventory, $6.3 million of property, plant and equipment, $10.5 million of accounts payable, accrued expenses and advance payments, $28.5 million of goodwill, $3.7 million of tradenames and $59.7 million of amortizable intangible assets consisting mainly of $56.7 million of customer relationships with a weighted average life of 20 years and $2.8 million of customer contract assets. The acquired goodwill relates to excess value associated with the opportunities to expand the services and markets that the Company can offer to its customers. The Company estimates approximately $25 million of the goodwill will be deductible for tax purposes.

[0001104659-20-130486:notes:95]
2018

[0001104659-20-130486:notes:96]
On March 14, 2018, the Company acquired the assets of Manta Test Systems Inc. (Manta), a North American utility solutions provider located in Mississauga, Ontario, Canada, for a purchase price of $9.5 million in cash. Since the date of acquisition, the operating results for Manta have been included as a product line of Doble within the Company’s USG segment. Based on the purchase price allocation, the Company recorded approximately $0.4 million of accounts receivable, $1.1 million of inventory, $0.2 million of property, plant and equipment, $0.4 million of accounts payable and accrued expenses, $3.5 million of goodwill, $1.2 million of tradenames and $3.5 million of amortizable intangible assets consisting of customer relationships with a weighted average life of 13 years.

[0001104659-20-130486:notes:97]
All of the Company’s acquisitions have been accounted for using the purchase method of accounting, and accordingly, the respective purchase prices were allocated to the assets (including intangible assets) acquired and liabilities assumed based on estimated fair values at the date of acquisition. The financial results from these acquisitions have been included in the Company’s financial statements from the date of acquisition.

[0001104659-20-130486:notes:98]
The goodwill recorded for the Globe acquisition mentioned above is deductible for U.S. Federal and state income tax purposes. The goodwill recorded for the Manta acquisition is deductible for Canadian income tax purposes.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001104659-20-130486:notes:99]
4.      Goodwill and Other Intangible Assets

[0001104659-20-130486:notes:100]
Included on the Company’s Consolidated Balance Sheets at September 30, 2020 and 2019 are the following intangible assets gross carrying amounts and accumulated amortization:

[0001104659-20-130486:notes:101]
| (Dollars in thousands) |  | 2020 |  | 2019 |
| Goodwill | ​ | $ | 408,063 |  | 390,256 |
| Intangible assets with determinable lives: | ​ |  | ​ | ​ | ​ |
| Patents | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 2,092 | ​ | 1,945 |
| Less: accumulated amortization | ​ |  | 858 | ​ | 748 |
| Net | ​ | $ | 1,234 | ​ | 1,197 |
| Capitalized software | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 84,888 | ​ | 78,962 |
| Less: accumulated amortization | ​ |  | 57,302 | ​ | 48,530 |
| Net | ​ | $ | 27,586 | ​ | 30,432 |
| Customer Relationships | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 227,178 | ​ | 227,225 |
| Less: accumulated amortization | ​ |  | 67,643 | ​ | 55,326 |
| Net | ​ | $ | 159,535 | ​ | 171,899 |
| Other | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 5,156 | ​ | 5,441 |
| Less: accumulated amortization | ​ |  | 3,260 | ​ | 2,645 |
| Net | ​ | $ | 1,896 | ​ | 2,796 |
| Intangible assets with indefinite lives: | ​ |  | ​ | ​ | ​ |
| Trade names | ​ | $ | 156,381 | ​ | 175,281 |

[0001104659-20-130486:notes:102]
The Company performed its annual evaluation of goodwill and intangible assets for impairment during the fourth quarter of 2020 and concluded no impairment existed at September 30, 2020 and there are no accumulated impairment losses as of September 30, 2020.

[0001104659-20-130486:notes:103]
The changes in the carrying amount of goodwill attributable to each business segment for 2020 and 2019 are as follows:

[0001104659-20-130486:notes:104]
| ​ | ​ | Aerospace & | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (Dollars in millions) |  | Defense |  | Test |  | USG |  | Total |
| Balance as of September 30, 2018 | ​ | ​ | 73.7 |  | ​ | 34.1 |  | 254.1 |  | 361.9 |
| Acquisition activity and other | ​ |  | 28.5 |  | ​ | — |  | (0.1) |  | 28.4 |
| Balance as of September 30, 2019 | ​ | ​ | 102.2 |  | ​ | 34.1 |  | 254.0 |  | 390.3 |
| Out-of-period adjustment | ​ | ​ | — | ​ | ​ | — | ​ | 18.0 | ​ | 18.0 |
| Foreign currency translation and other | ​ | ​ | (0.1) | ​ | ​ | — | ​ | (0.1) | ​ | (0.2) |
| Balance as of September 30, 2020 | ​ | $ | 102.1 | ​ | ​ | 34.1 | ​ | 271.9 | ​ | 408.1 |

[0001104659-20-130486:notes:105]
As of September 30, 2020, the Company reclassified $18.0 million from Morgan Schaffer’s tradename to goodwill to correct a misclassification that originated in the original accounting for the acquisition in fiscal 2017. Management has determined that the effect of this misclassification was not material to the current or any prior periods and it had no impact on the Company’s total assets, results of operations or cash flows for any period.

[0001104659-20-130486:notes:106]
Amortization expense related to intangible assets with determinable lives was $21.8 million, $18.5 million and $17.3 million in 2020, 2019 and 2018, respectively. Patents are amortized over the life of the patents, generally 17 years. Capitalized software is amortized over the estimated useful life of the software, generally three to seven years. Customer relationships are generally amortized over

[0001104659-20-130486:notes:107]
fifteen to twenty years. Intangible asset amortization for fiscal years 2021 through 2025 is estimated at approximately $21 million per year.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001104659-20-130486:notes:108]
5.      Accounts Receivable

[0001104659-20-130486:notes:109]
Accounts receivable, net of the allowance for doubtful accounts, from continuing operations consist of the following at September 30, 2020 and 2019:

[0001104659-20-130486:notes:110]
| (Dollars in thousands) |  | 2020 |  | 2019 |
| Commercial | ​ | $ | 121,924 |  | 137,553 |
| U.S. Government and prime contractors | ​ |  | 22,158 |  | 21,162 |
| Total | ​ | $ | 144,082 |  | 158,715 |


## us-gaap:InventoryDisclosureTextBlock

[0001104659-20-130486:notes:111]
6.      Inventories, Net

[0001104659-20-130486:notes:112]
Inventories, net, from continuing operations consist of the following at September 30, 2020 and 2019:

[0001104659-20-130486:notes:113]
| (Dollars in thousands) |  | 2020 |  | 2019 |
| Finished goods | ​ | $ | 28,471 |  | 23,550 |
| Work in process | ​ |  | 30,183 |  | 26,407 |
| Raw materials | ​ |  | 77,535 |  | 74,999 |
| Total | ​ | $ | 136,189 |  | 124,956 |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001104659-20-130486:notes:114]
7.      Related Parties

[0001104659-20-130486:notes:115]
One of the Company’s directors is a former officer at a customer of the Company’s subsidiary Doble. Doble sells products, rents equipment and provides testing services to the customer in the ordinary course of Doble’s business. The total amount of these sales were approximately $2.8 million, $3.3 million and $2.1 million during fiscal 2020, 2019 and 2018, respectively. All transactions between Doble and the customer are intended to be and have been consistent with Doble’s normal commercial terms offered to its customers, and the Company’s Board of Directors has determined that the relationship between the Company and the customer is not material and did not impair either the Company’s or the director’s independence.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001104659-20-130486:notes:116]
8.      Income Tax Expense

[0001104659-20-130486:notes:117]
Total income tax expense (benefit) for the years ended September 30, 2020, 2019 and 2018 was allocated to income tax expense as follows:

[0001104659-20-130486:notes:118]
| (Dollars in thousands) |  | 2020 |  | 2019 |  | 2018 |
| Income tax expense (benefit) from continuing operations | ​ | $ | 14,278 |  | 20,388 |  | (5,170) |
| Income tax expense from discontinued operations | ​ |  | 23,501 |  | 789 |  | 1,060 |
| Total income tax expense (benefit) | ​ | $ | 37,779 |  | 21,177 |  | (4,110) |

[0001104659-20-130486:notes:119]
The components of income from continuing operations before income taxes for 2020, 2019 and 2018 consisted of the following:

[0001104659-20-130486:notes:120]
| (Dollars in thousands) |  | 2020 |  | 2019 |  | 2018 |
| United States | ​ | $ | 27,288 |  | 87,150 |  | 74,028 |
| Foreign | ​ |  | 12,455 |  | 10,727 |  | 7,063 |
| Total income before income taxes | ​ | $ | 39,743 |  | 97,877 |  | 81,091 |

[0001104659-20-130486:notes:121]
The principal components of income tax expense (benefit) from continuing operations for 2020, 2019 and 2018 consist of:

[0001104659-20-130486:notes:122]
| (Dollars in thousands) |  | 2020 |  | 2019 |  | 2018 |
| Federal: |  | ​ |  |  |  |  |  |
| Current | ​ | $ | 10,982 |  | 13,888 |  | 7,663 |
| Deferred | ​ |  | 1,507 |  | 250 |  | (22,329) |
| State and local: | ​ |  | ​ |  | ​ |  | ​ |
| Current | ​ |  | 2,042 |  | 3,039 |  | 1,885 |
| Deferred | ​ |  | (905) |  | 98 |  | 2,899 |
| Foreign: | ​ |  | ​ |  | ​ |  | ​ |
| Current | ​ |  | 2,875 |  | 2,439 |  | 2,208 |
| Deferred | ​ |  | (2,223) |  | 674 |  | 2,504 |
| Total | ​ | $ | 14,278 |  | 20,388 |  | (5,170) |

[0001104659-20-130486:notes:123]
The actual income tax expense (benefit) from continuing operations for 2020, 2019 and 2018 differs from the expected tax expense for those years (computed by applying the U.S. Federal corporate statutory rate) as follows:

[0001104659-20-130486:notes:124]
| ​ |  | 2020 |  | 2019 |  | 2018 |  |
| Federal corporate statutory rate |  | 21.0 | % | 21.0 | % | 24.5 | % |
| State and local, net of Federal benefits | ​ | 2.3 |  | 3.2 |  | 2.9 | ​ |
| Foreign | ​ | (1.1) |  | 0.6 |  | 0.8 | ​ |
| Research credit | ​ | (3.4) |  | (0.8) |  | (1.6) | ​ |
| Domestic production deduction | ​ | — |  | — |  | (1.1) | ​ |
| Change in uncertain tax positions | ​ | — |  | (0.1) |  | (0.1) | ​ |
| Executive compensation | ​ | 1.5 |  | 0.3 |  | (0.1) | ​ |
| Valuation allowance | ​ | (6.3) |  | (2.4) |  | 3.0 | ​ |
| GILTI and FDII | ​ | 0.4 | ​ | (0.6) | ​ | — | ​ |
| Tax reform – impact on U.S. deferred tax assets and liabilities | ​ | — |  | (0.3) |  | (39.3) | ​ |
| Tax reform – transition tax | ​ | — |  | (0.1) |  | 1.6 | ​ |
| Tax reform – taxes related to foreign unremitted earnings | ​ | — |  | — |  | 3.0 | ​ |
| Pension plan termination charge | ​ | 21.4 | ​ | — | ​ | — | ​ |
| Other, net | ​ | 0.1 |  | — |  | — | ​ |
| Effective income tax rate | ​ | 35.9 | % | 20.8 | % | (6.4) | % |

[0001104659-20-130486:notes:125]
The tax effects of temporary differences that give rise to significant portions of the deferred tax assets and liabilities at September 30, 2020 and 2019 are presented below:

[0001104659-20-130486:notes:126]
| (Dollars in thousands) |  | 2020 |  | 2019 |
| Deferred tax assets: |  | ​ |  |  |  |
| Inventories | ​ | $ | 4,998 |  | 4,800 |
| Pension and other postretirement benefits | ​ |  | 842 |  | 5,533 |
| Timing differences related to revenue recognition | ​ | ​ | 4,722 | ​ | — |
| Lease liabilities | ​ | ​ | 5,220 | ​ | — |
| Net operating and capital loss carryforwards — domestic | ​ |  | 563 |  | 602 |
| Net operating loss carryforward — foreign | ​ |  | 3,678 |  | 3,766 |
| Other compensation-related costs and other cost accruals | ​ |  | 8,953 |  | 7,764 |
| State credit carryforward | ​ |  | 2,366 |  | 1,914 |
| Total deferred tax assets | ​ |  | 31,342 |  | 24,379 |
| Deferred tax liabilities: | ​ |  | ​ |  | ​ |
| Timing differences related to revenue recognition | ​ | ​ | — | ​ | (1,805) |
| ROU assets | ​ | ​ | (5,220) | ​ | — |
| Goodwill | ​ |  | (7,878) |  | (1,450) |
| Acquisition assets | ​ |  | (52,682) |  | (58,547) |
| Depreciation, software amortization | ​ |  | (21,283) |  | (18,288) |
| Net deferred tax liabilities before valuation allowance | ​ |  | (55,721) |  | (55,711) |
| Less valuation allowance | ​ |  | (1,932) |  | (4,504) |
| Net deferred tax liabilities | ​ | $ | (57,653) |  | (60,215) |

[0001104659-20-130486:notes:127]
The Company has a foreign net operating loss (NOL) carryforward of $14.0 million at September 30, 2020, which reflects tax loss carryforwards in Germany, South Africa, Canada, India and the United Kingdom. Approximately $13.8 million of the tax loss carryforwards have no expiration date while the remaining $0.2 million will expire between 2028 and 2038. The Company has deferred tax assets related to state NOL carryforwards of $0.6 million at September 30, 2020 which expire between 2025 and 2040. The Company also has net state research and other credit carryforwards of $2.4 million of which $1.7 million expires between 2023 and 2035. The remaining $0.7 million does not have an expiration date.

[0001104659-20-130486:notes:128]
The valuation allowance for deferred tax assets as of September 30, 2020 and 2019 was $1.9 million and $4.5 million, respectively. The net change in the total valuation allowance for each of the years ended September 30, 2020 and 2019 was a decrease of $2.6 million and a decrease of $2.6 million, respectively.The Company has established a valuation allowance against state credit carryforwards of $0.6 million and $0.4 million at September 30, 2020 and 2019, respectively. In addition, the Company has established a valuation allowance against state NOL carryforwards that are not expected to be realized in future periods of $0.5 million and $0.6 million  at September 30, 2020 and 2019, respectively. Lastly, the Company has established a valuation allowance against certain NOL carryforwards in foreign jurisdictions which may not be realized in future periods of $0.8 million and $3.6 million at September 30, 2020 and 2019, respectively.

[0001104659-20-130486:notes:129]
On December 22, 2017, the U.S. government enacted the Tax Cuts and Jobs Act, which made comprehensive changes to U.S. federal income tax laws by moving from a global to a modified territorial tax regime. As a result, cash repatriated to the U.S. is generally no longer subject to U.S. federal income tax. No provision is made for foreign withholding or any applicable U.S. income taxes on the undistributed earnings of non-U.S. subsidiaries where these earnings are considered indefinitely invested or otherwise retained for continuing international operations. Determination of the amount of taxes that might be paid on these undistributed earnings if eventually remitted is not practicable.


## us-gaap:DebtDisclosureTextBlock

[0001104659-20-130486:notes:130]
9.      Debt

[0001104659-20-130486:notes:131]
Debt consists of the following at September 30, 2020 and 2019:

[0001104659-20-130486:notes:132]
| (Dollars in thousands) |  | 2020 |  | 2019 |
| Revolving credit facility, including current portion | ​ | $ | 62,368 |  | 285,000 |
| Current portion of long-term debt and short-term borrowings | ​ |  | (22,368) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 40,000 |  | 265,000 |

[0001104659-20-130486:notes:133]
The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for an increase of the commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024.

[0001104659-20-130486:notes:134]
Interest on borrowings under the Credit Facility is calculated at a spread over either the London Interbank Offered Rate (LIBOR), the New York Federal Reserve Bank Rate or the prime rate, depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The interest rate spreads and the facility fee are subject to increase or decrease depending on the Company's leverage ratio.

[0001104659-20-130486:notes:135]
The Credit Facility is secured by the unlimited guaranty of the Company's direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of its direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. As of September 30, 2020, the Company was in compliance with all covenants.

[0001104659-20-130486:notes:136]
At September 30, 2020, the Company had approximately $430 million available to borrow under the Credit Facility, plus the $250 million increase option subject to the lenders’ consent, in addition to $52.6 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of September 30, 2020, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. In addition, the Company had $2.4 million of short-term borrowings at its foreign locations outstanding as of September 30, 2020.

[0001104659-20-130486:notes:137]
During 2020 and 2019, the maximum aggregate short-term borrowings at any month-end were $281 million and $308 million, respectively, and the average aggregate short-term borrowings outstanding based on month-end balances were $175.6 million and $236.4 million, respectively. The weighted average interest rates were 3.20%, 3.21% and 3.03% for 2020, 2019 and 2018, respectively. As of September 30, 2020, the interest rate on the Company's debt was 1.09%. The letters of credit issued and outstanding under the Credit Facility totaled $9.9 million and $8.2 million at September 30, 2020 and 2019, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001104659-20-130486:notes:138]
10.      Capital Stock

[0001104659-20-130486:notes:139]
The 30,645,625 and 30,596,940 common shares as presented in the accompanying Consolidated Balance Sheets at September 30, 2020 and 2019 represent the actual number of shares issued at the respective dates. The Company held 4,607,911 and 4,615,627 common shares in treasury at September 30, 2020 and 2019, respectively.

[0001104659-20-130486:notes:140]
In August 2012, the Company’s Board of Directors authorized a common stock repurchase program under which the Company may repurchase shares of its stock from time to time in its discretion, in the open market or otherwise, up to a maximum total repurchase amount of $100 million (or such lesser amount as may be permitted under the Company’s bank credit agreements). This program has been repeatedly extended by the Company’s Board of Directors and is currently scheduled to expire September 30, 2021. There were no share repurchases in 2020, 2019 or 2018. At September 30, 2020, approximately $50.4 million remained available for repurchases under the program.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001104659-20-130486:notes:141]
11.      Share-Based Compensation

[0001104659-20-130486:notes:142]
The Company provides compensation benefits to certain key employees under several share-based plans providing for performance-accelerated restricted share unit (PARS) awards, and to non-employee directors under a non-employee directors compensation plan. The Company has no stock options currently outstanding. As of September 30, 2020, the Company's equity compensation plans had a total of 782,412 shares authorized and available for future issuance.

[0001104659-20-130486:notes:143]
Performance-Accelerated Restricted Share Unit (PARS) Awards

[0001104659-20-130486:notes:144]
A PARS award represents the right to receive a specified number of shares of Company common stock if and when the award vests. A PARS award is not stock and does not give the recipient any rights as a shareholder until it vests and is paid out in shares of stock. PARS awards currently outstanding have a five-year vesting period, with accelerated vesting if certain targets based on market conditions are achieved. In these cases, if it is probable that the performance condition will be met, the Company recognizes compensation cost on a straight-line basis over the shorter performance period; otherwise, it will recognize compensation cost over the longer service period. Compensation cost for the outstanding PARS awards is being recognized over the shorter performance period, as it is probable the performance condition will be met. The PARS award grants were valued at the stock price on the date of grant. Pretax compensation expense related to the PARS awards for continuing operations was $4.3 million, $4.0 million and $3.9 million for 2020, 2019 and 2018, respectively.

[0001104659-20-130486:notes:145]
The following summary presents information regarding outstanding PARS awards as of the specified dates, and changes during the specified periods:

[0001104659-20-130486:notes:146]
| ​ | ​ | FY 2020 | ​ | FY 2019 | ​ | FY 2018 |
| ​ |  | ​ |  | Estimated |  | ​ |  | Estimated |  | ​ |  | Estimated |
| ​ | ​ | ​ | ​ | Weighted | ​ | ​ | ​ | Weighted | ​ | ​ | ​ | Weighted |
| ​ | ​ | Shares | ​ | Avg. Price | ​ | Shares | ​ | Avg. Price | ​ | Shares | ​ | Avg. Price |
| Nonvested at October 1, |  | 281,004 | ​ | $ | 59.72 |  | 315,544 | ​ | $ | 47.23 |  | 335,825 | ​ | $ | 40.35 |
| Granted |  | 45,723 | ​ |  | 74.80 |  | 84,862 | ​ |  | 74.77 |  | 104,320 | ​ |  | 56.06 |
| Vested |  | (89,822) | ​ |  | 50.51 |  | (113,402) | ​ |  | 37.00 |  | (121,301) | ​ |  | 35.59 |
| Cancelled |  | (16,605) | ​ |  | 60.48 |  | (6,000) | ​ |  | 45.20 |  | (3,300) | ​ |  | 53.86 |
| Nonvested at September 30, |  | 220,300 | ​ | $ | 66.55 |  | 281,004 | ​ | $ | 59.72 |  | 315,544 | ​ | $ | 47.23 |

[0001104659-20-130486:notes:147]
Compensation Plan for Non-Employee Directors

[0001104659-20-130486:notes:148]
Through the first quarter of 2018, the Company's Compensation Plan for Non-Employee Directors provided to each non-employee director a retainer of 900 common shares per quarter. Beginning in the second quarter of 2018, the quarterly retainer was replaced by an annual retainer of Company stock having a grant date market value of $180,000. Non-employee director grants were valued at the NYSE closing price of the Company’s stock on the date of grant and were issued from the Company’s treasury stock. Compensation expense related to the non-employee director grants was $1.3 million, $1.1 million and $1.1 million for 2020, 2019 and 2018, respectively.

[0001104659-20-130486:notes:149]
Total Share-Based Compensation

[0001104659-20-130486:notes:150]
The total share-based compensation cost that has been recognized in results of operations and included within SG&A from continuing operations was $5.6 million, $5.1 million and $5.0 million for 2020, 2019 and 2018, respectively. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $1.2 million, $1.1 million and $1.3 million for 2020, 2019 and 2018, respectively. As of September 30, 2020, there was $8.2 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a weighted-average period of 2.0 years.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001104659-20-130486:notes:151]
12.      Retirement and Other Benefit Plans

[0001104659-20-130486:notes:152]
Formerly, substantially all domestic employees were covered by a defined benefit pension plan (the Plan) maintained by the Company. The Plan was frozen in 2003 and no additional benefits have been accrued since that date. On November 14, 2019, the Company’s Board of Directors approved a resolution to terminate the Plan effective as of February 29, 2020. In connection with the termination, the Company contributed $25.7 million of cash to the Plan during the fourth quarter of 2020, settled approximately $32.4 million of Plan liabilities during the fourth quarter of 2020 through lump-sum payments from existing plan assets to eligible participants who elected to receive them; and recorded approximately $40.6 million of charges associated with these settlements. During 2020, the Company settled approximately $69.1 million of Plan liabilities by entering into an agreement to purchase annuities from Massachusetts Mutual Life Insurance Company (MassMutual). This agreement covered active and former employees and their beneficiaries, with MassMutual assuming the future annuity payments for these individuals.

[0001104659-20-130486:notes:153]
Substantially all domestic employees are covered by a defined contribution plan maintained by the Company. In addition, the Company offers unfunded post-retirement pre-Medicare health insurance benefits to a small number of eligible retirees and employees. The Company formerly provided unfunded post-retirement life insurance to qualifying retired employees who retired before 2005, but ceased providing this coverage on July 31, 2020.  The Company currently provides unfunded Medicare supplement coverage to a small number of retired employees, but will cease providing this coverage on December 31, 2020.

[0001104659-20-130486:notes:154]
The Company used a measurement date of September 30 for its pension and other postretirement benefit plans. The Company had an accrued benefit liability of $0.2 million and $0.6 million at September 30, 2020 and 2019, respectively, related to its other postretirement benefit obligations. All other information related to its postretirement benefit plans is not considered material to the Company’s results of operations or financial condition.

[0001104659-20-130486:notes:155]
The following tables provide a reconciliation of the changes in the pension plans and fair value of assets over the two-year period ended September 30, 2020, and a statement of the funded status as of September 30, 2020 and 2019:

[0001104659-20-130486:notes:156]
| (Dollars in millions) | ​ | ​ | ​ | ​ |  |
| Reconciliation of benefit obligation |  | 2020 |  | 2019 |
| Net benefit obligation at beginning of year | ​ | $ | 100.1 |  | 89.8 |
| Interest cost | ​ |  | 3.0 |  | 3.7 |
| Actuarial loss | ​ |  | 6.9 |  | 11.3 |
| Gross benefits paid | ​ |  | (4.8) |  | (4.7) |
| Settlements | ​ |  | (102.4) |  | — |
| Net benefit obligation at end of year | ​ | $ | 2.8 |  | 100.1 |

[0001104659-20-130486:notes:157]
| (Dollars in millions) |  |  | ​ |  |  |
| Reconciliation of fair value of plan assets | ​ | 2020 | ​ | 2019 |
| Fair value of plan assets at beginning of year | ​ | $ | 77.2 |  | 73.3 |
| Actual return on plan assets | ​ |  | 3.6 |  | 5.9 |
| Employer contributions | ​ |  | 26.4 |  | 2.7 |
| Gross benefits paid | ​ |  | (4.8) |  | (4.7) |
| Settlements | ​ |  | (102.4) |  | — |
| Fair value of plan assets at end of year | ​ | $ | — |  | 77.2 |

[0001104659-20-130486:notes:158]
| (Dollars in millions) |  |  | ​ |  |  |
| Funded Status | ​ | 2020 | ​ | 2019 |
| Funded status at end of year | ​ | $ | (2.8) |  | (22.9) |
| Accrued benefit cost | ​ |  | (2.8) |  | (22.9) |
| Amounts recognized in the Balance Sheet consist of: | ​ |  | ​ |  | ​ |
| Current liability | ​ |  | (0.3) |  | (0.2) |
| Noncurrent liability | ​ |  | (2.5) |  | (22.7) |
| Accumulated other comprehensive loss (before tax effect) | ​ |  | 0.7 |  | 49.6 |
| Amounts recognized in accumulated other comprehensive loss consist of: | ​ |  | ​ |  | ​ |
| Net actuarial loss | ​ |  | 0.7 |  | 49.6 |
| Accumulated other comprehensive loss (before tax effect) | ​ | $ | 0.7 |  | 49.6 |

[0001104659-20-130486:notes:159]
The following table provides the components of net periodic benefit cost for the plans for 2020, 2019 and 2018:

[0001104659-20-130486:notes:160]
| (Dollars in millions) |  | 2020 |  | 2019 |  | 2018 |
| Service cost | ​ | $ | — |  | — |  | — |
| Interest cost | ​ |  | 3.0 |  | 3.7 |  | 3.4 |
| Expected return on plan assets | ​ |  | (4.2) |  | (4.4) |  | (3.8) |
| Settlements | ​ | ​ | 53.6 | ​ | — | ​ | — |
| Net actuarial loss | ​ |  | 2.8 |  | 2.1 |  | 2.3 |
| Net periodic benefit cost | ​ |  | 55.2 |  | 1.4 |  | 1.9 |
| Defined contribution plans | ​ |  | 7.4 |  | 6.8 |  | 6.6 |
| Total | ​ | $ | 62.6 |  | 8.2 |  | 8.5 |

[0001104659-20-130486:notes:161]
The discount rate used in measuring the Company’s pension obligations was developed by matching yields of actual high-quality corporate bonds to expected future pension plan cash flows (benefit payments). Over 400 Aa-rated, non-callable bonds with a wide range of maturities were used in the analysis. After using the bond yields to determine the present value of the plan cash flows, a single representative rate that resulted in the same present value was developed. The expected long-term rate of return on plan assets assumption was determined by reviewing the actual investment return of the plans since inception and evaluating those returns in relation to expectations of various investment organizations to determine whether long-term future returns are expected to differ significantly from the past.

[0001104659-20-130486:notes:162]
Expected Cash Flows

[0001104659-20-130486:notes:163]
Information about the expected cash flows for the other postretirement benefit plans follows:

[0001104659-20-130486:notes:164]
| ​ |  | Other |
| (Dollars in millions) | ​ | Benefits |
| Expected Benefit Payments: | ​ |  |  |
| 2021 | ​ | $ | 0.2 |
| 2022 | ​ |  | 0.2 |
| 2023 | ​ |  | 0.3 |
| 2024 | ​ |  | 0.2 |
| 2025 | ​ | ​ | 0.2 |
| 2026‑2030 | ​ | $ | 0.9 |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001104659-20-130486:notes:165]
13.      Derivative Financial Instruments

[0001104659-20-130486:notes:166]
Market risks relating to the Company’s operations result primarily from changes in interest rates and changes in foreign currency exchange rates. The Company is exposed to market risk related to changes in interest rates and selectively uses derivative financial instruments, including forward contracts and swaps, to manage these risks. In 2018, the Company entered into three interest rate swaps with a notional amount of $150 million to hedge its exposure to variability in future LIBOR-based interest payments on variable rate debt. The interest rate swaps entered into during 2018 were not designated as cash flow hedges and therefore the gain or loss on the derivative is reflected in earnings each period. The final interest rate swap was settled during September 2020; therefore there are no outstanding interest rate swaps as of September 30, 2020.

[0001104659-20-130486:notes:167]
The Company’s Canadian subsidiary Morgan Schaffer enters into foreign exchange contracts to manage foreign currency risk as a portion of their revenue is denominated in U.S. dollars. The Company expects hedging gains or losses to be essentially offset by losses or gains on the related underlying exposures. The amounts ultimately recognized may differ for open positions, which remain subject to ongoing market price fluctuations until settlement. All derivative instruments are reported in either accrued expenses or other assets on the balance sheet at fair value. For derivative instruments designated as cash flow hedges, the gain or loss on the derivative is deferred in accumulated other comprehensive income until recognized in earnings with the underlying hedged item.

[0001104659-20-130486:notes:168]
The following is a summary of the notional transaction amounts and fair values for the Company’s outstanding derivative financial instruments as of September 30, 2020.

[0001104659-20-130486:notes:169]
| ​ | ​ | Notional Amount | ​ | Fair Value | ​ |
| (In thousands) |  | (Currency) |  | (US$) |  |
| Forward contracts |  | 4,250 | USD | (6) | ​ |

[0001104659-20-130486:notes:170]
Fair Value of Financial Instruments

[0001104659-20-130486:notes:171]
The Company’s forward contracts are classified within Level 2 of the valuation hierarchy in accordance with ASC 825, as presented below as of September 30, 2020:

[0001104659-20-130486:notes:172]
| (In thousands) |  | Level 1 |  | Level 2 |  | ​ | Level 3 |  | Total |
| Asset: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Forward contracts | ​ | $ | — |  | (6) |  | ​ | — |  | (6) |

[0001104659-20-130486:notes:173]
Valuation was based on third party evidence of similarly priced derivative instruments. There are no master netting arrangements with financial parties.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001104659-20-130486:notes:174]
14.      Business Segment Information

[0001104659-20-130486:notes:175]
The Company is organized based on the products and services it offers and classifies its continuing business operations in three reportable segments for financial reporting purposes: Aerospace & Defense (formerly called Filtration/Fluid Flow), Utility Solutions Group (USG) and RF Shielding and Test (Test). The former Technical Packaging segment was divested in December 2019 and has been reflected as discontinued operations for 2020.

[0001104659-20-130486:notes:176]
The Aerospace & Defense segment’s operations consist of PTI Technologies Inc. (PTI), VACCO Industries (VACCO), Crissair, Inc. (Crissair), Mayday Manufacturing Co. (Mayday), Hi-Tech Metals, Inc. (Hi-Tech), Westland Technologies, Inc. (Westland), and Globe Composite Solutions, LLC (Globe).The companies within this segment primarily design and manufacture specialty filtration and naval products, including hydraulic filter elements and fluid control devices used in aerospace and defense applications, unique filter mechanisms used in micro-propulsion devices for satellites and custom designed filters for manned aircraft and submarines, products and systems to reduce vibration and/or acoustic signatures and otherwise reduce or obscure a vessel’s signature, and other communications, sealing, surface control and hydrodynamic related applications to enhance U.S. Navy maritime survivability; precision-tolerance machined components for the aerospace and defense industry; and metal processing services.

[0001104659-20-130486:notes:177]
The USG segment’s operations consist of Doble Engineering Company and related subsidiaries including Morgan Schaffer (collectively, Doble), and NRG Systems, Inc. (NRG). Doble is an industry leader in the development, manufacture and delivery of diagnostic testing and data management solutions that enable electric power grid operators to assess the integrity of high-voltage power delivery equipment. NRG designs and manufactures decision support tools for the renewable energy industry, primarily wind and solar.

[0001104659-20-130486:notes:178]
The Test segment's operations consist of ETS-Lindgren Inc. and related subsidiaries (ETS-Lindgren). ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy. ETS-Lindgren also manufactures radio frequency shielding products and components used by manufacturers of medical equipment, communications systems, electronic products, and shielded rooms for high-security data processing and secure communication.

[0001104659-20-130486:notes:179]
Accounting policies of the segments are the same as those described in the summary of significant accounting policies in Note 1 to the Consolidated Financial Statements. The operating units within each reporting segment have been aggregated because of similar economic characteristics and meet the other aggregation criteria of FASB ASC 280.

[0001104659-20-130486:notes:180]
The Company evaluates the performance of its operating units based on EBIT, which is defined as earnings before interest and taxes. EBIT on a consolidated basis is a non-GAAP financial measure; see “Non-GAAP Financial Measures” in Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations.” Intersegment sales and transfers are not significant. Segment assets consist primarily of customer receivables, inventories, capitalized software and fixed assets directly associated with

[0001104659-20-130486:notes:181]
the production processes of the segment. Segment depreciation and amortization is based upon the direct assets listed above. The tables below are presented on the basis of continuing operations and exclude discontinued operations.

[0001104659-20-130486:notes:182]
Net Sales

[0001104659-20-130486:notes:183]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2020 |  | 2019 |  | 2018 |
| Aerospace & Defense | ​ | $ | 354.3 |  | 325.7 |  | 286.8 |
| USG | ​ | ​ | 191.7 | ​ | 211.9 | ​ | 214.0 |
| Test | ​ |  | 186.9 |  | 188.4 |  | 182.9 |
| Consolidated totals | ​ | $ | 732.9 |  | 726.0 |  | 683.7 |

[0001104659-20-130486:notes:184]
One customer exceeded 10% of sales in 2020 and no customer exceeded 10% of sales in 2019.

[0001104659-20-130486:notes:185]
EBIT

[0001104659-20-130486:notes:186]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2020 |  | 2019 |  | 2018 |
| Aerospace & Defense | ​ | $ | 73.2 |  | 70.1 |  | 58.7 |
| USG | ​ | ​ | 24.4 | ​ | 52.2 | ​ | 43.2 |
| Test | ​ |  | 27.2 |  | 25.6 |  | 23.8 |
| Reconciliation to consolidated totals (Corporate) | ​ |  | (78.3) |  | (41.9) |  | (35.8) |
| Consolidated EBIT | ​ |  | 46.5 |  | 106.0 |  | 89.9 |
| Less: interest expense | ​ |  | (6.7) |  | (8.1) |  | (8.8) |
| Earnings before income tax | ​ | $ | 39.8 |  | 97.9 |  | 81.1 |

[0001104659-20-130486:notes:187]
Identifiable Assets

[0001104659-20-130486:notes:188]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2020 |  | 2019 |
| Aerospace & Defense | ​ | $ | 279.5 |  | 260.3 |
| USG | ​ | ​ | 144.8 | ​ | 146.3 |
| Test | ​ |  | 153.0 |  | 154.2 |
| Corporate – goodwill | ​ |  | 408.1 |  | 390.3 |
| Corporate – other assets | ​ |  | 388.1 |  | 422.9 |
| Assets from discontinued operations | ​ | ​ | – | ​ | 92.7 |
| Consolidated totals | ​ | $ | 1,373.5 |  | 1,466.7 |

[0001104659-20-130486:notes:189]
Corporate other assets consist primarily of deferred taxes, acquired intangible assets and cash balances.

[0001104659-20-130486:notes:190]
Capital Expenditures

[0001104659-20-130486:notes:191]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2020 |  | 2019 |  | 2018 |
| Aerospace & Defense | ​ | $ | 15.9 |  | 11.7 |  | 7.0 |
| USG | ​ | ​ | 12.4 | ​ | 8.5 | ​ | 5.2 |
| Test | ​ |  | 3.6 |  | 4.0 |  | 3.0 |
| Corporate | ​ |  | 0.2 |  | — |  | — |
| Consolidated totals | ​ | $ | 32.1 |  | 24.2 |  | 15.2 |

[0001104659-20-130486:notes:192]
In addition to the above amounts, the Company incurred expenditures for capitalized software of $9.0 million, $8.4 million and $9.5 million in 2020, 2019 and 2018, respectively.

[0001104659-20-130486:notes:193]
Depreciation and Amortization

[0001104659-20-130486:notes:194]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2020 |  | 2019 |  | 2018 |
| Aerospace & Defense | ​ | $ | 9.4 |  | 8.3 |  | 7.6 |
| USG | ​ | ​ | 14.4 | ​ | 11.3 | ​ | 11.0 |
| Test | ​ |  | 5.0 |  | 5.1 |  | 4.5 |
| Corporate | ​ |  | 12.5 |  | 11.3 |  | 10.6 |
| Consolidated totals | ​ | $ | 41.3 |  | 36.0 |  | 33.7 |

[0001104659-20-130486:notes:195]
Depreciation expense of property, plant and equipment was $19.5 million, $16.5 million and $15.4 million for 2020, 2019 and 2018, respectively.

[0001104659-20-130486:notes:196]
Geographic Information

[0001104659-20-130486:notes:197]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2020 |  | 2019 |  | 2018 |
| United States | ​ | $ | 531.9 |  | 537.2 |  | 495.8 |
| Asia | ​ |  | 96.3 |  | 86.2 |  | 92.6 |
| Europe | ​ |  | 51.3 |  | 45.0 |  | 41.3 |
| Canada | ​ |  | 31.7 |  | 33.0 |  | 30.2 |
| India | ​ |  | 10.3 |  | 11.7 |  | 9.4 |
| Other | ​ |  | 11.4 |  | 12.9 |  | 14.4 |
| Consolidated totals | ​ | $ | 732.9 |  | 726.0 |  | 683.7 |

[0001104659-20-130486:notes:198]
Long-Lived Assets

[0001104659-20-130486:notes:199]
| (Dollars in millions) | ​ | ​ | ​ | ​ | ​ |
| Year ended September 30, |  | 2020 |  | 2019 |
| United States | ​ | $ | 131.5 |  | 120.7 |
| Mexico | ​ |  | 3.1 |  | 1.8 |
| Other | ​ |  | 5.3 |  | 5.3 |
| Consolidated totals | ​ | $ | 139.9 |  | 127.8 |

[0001104659-20-130486:notes:200]
Net sales are attributed to countries based on location of customer. Long-lived assets are attributed to countries based on location of the asset.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001104659-20-130486:notes:201]
15.      Commitments and Contingencies

[0001104659-20-130486:notes:202]
At September 30, 2020, the Company had $9.9 million in letters of credit outstanding as guarantees of contract performance. As a normal incident of the businesses in which the Company is engaged, various claims, charges and litigation are asserted or commenced from time to time against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. It is the opinion of Management that the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company are adequately accrued, are covered by insurance or are not likely to have a material adverse effect on the Company’s results from continuing operations, capital expenditures or competitive position.


## us-gaap:LeasesOfLesseeDisclosureTextBlock

[0001104659-20-130486:notes:203]
16.      Leases

[0001104659-20-130486:notes:204]
As described in Note 3, effective October 1, 2019, the Company adopted ASC 842, Leases. The Company determines at lease inception whether an arrangement that provides control over the use of an asset is a lease. The Company recognizes at lease commencement a right-of-use (ROU) asset and lease liability based on the present value of the future lease payments over the lease term. The Company has elected not to recognize a ROU asset and lease liability for leases with terms of 12 months or less. Certain of

[0001104659-20-130486:notes:205]
the Company’s leases include options to extend the term of the lease for up to 20 years. When it is reasonably certain that the Company will exercise the option, Management includes the impact of the option in the lease term for purposes of determining total future lease payments. As most of the Company’s lease agreements do not explicitly state the discount rate implicit in the lease, Management uses the Company’s incremental borrowing rate on the commencement date to calculate the present value of future payments based on the tenor of each arrangement.

[0001104659-20-130486:notes:206]
The Company’s leases for real estate commonly include escalating payments. These variable lease payments are included in the calculation of the ROU asset and lease liability. In addition to the present value of the future lease payments, the calculation of the ROU asset also includes any deferred rent, lease pre-payments and initial direct costs of obtaining the lease.

[0001104659-20-130486:notes:207]
In addition to the base rent, real estate leases typically contain provisions for common-area maintenance and other similar services, which are considered non-lease components for accounting purposes. Non-lease components are excluded from our ROU assets and lease liabilities and expensed as incurred.

[0001104659-20-130486:notes:208]
The Company’s leases are for office space, manufacturing facilities, and machinery and equipment.

[0001104659-20-130486:notes:209]
The components of lease costs are shown below:

[0001104659-20-130486:notes:210]
| ​ |  | Year Ended |
| (Dollars in thousands) | ​ | September 30, 2020 |
| Finance lease cost: |  | ​ |  |
| Amortization of right-of-use assets | ​ | $ | 2,056 |
| Interest on lease liabilities | ​ |  | 971 |
| Operating lease cost | ​ |  | 5,284 |
| Total lease cost | ​ | $ | 8,311 |

[0001104659-20-130486:notes:211]
Additional information related to leases is shown below:

[0001104659-20-130486:notes:212]
| ​ |  | ​ |  | Year Ended |  |
| ​ | ​ | ​ | ​ | September 30, | ​ |
| (Dollars in thousands) | ​ | ​ | ​ | 2020 | ​ |
| Cash paid for amounts included in the measurement of lease liabilities: | ​ | ​ |  | ​ |  |  |
| Operating cash flows from operating leases | ​ | ​ | ​ | $ | 5,223 |  |
| Operating cash flows from finance leases | ​ | ​ | ​ |  | 971 |  |
| Financing cash flows from finance leases | ​ | ​ | ​ |  | 1,547 |  |
| Right-of-use assets obtained in exchange for operating lease liabilities | ​ | ​ | ​ | $ | 26,244 |  |
| Weighted-average remaining lease term: | ​ | ​ | ​ |  |  |  |
| Operating leases | ​ | ​ | ​ |  | 6.00 | years |
| Finance leases | ​ | ​ | ​ |  | 12.53 | years |
| Weighted-average discount rate: | ​ | ​ | ​ |  |  |  |
| Operating leases | ​ | ​ | ​ |  | 3.09 | % |
| Finance leases | ​ | ​ | ​ |  | 4.30 | % |

[0001104659-20-130486:notes:213]
The following is a reconciliation of future undiscounted cash flows to the operating and finance lease liabilities, and the related ROU assets, presented on our Consolidated Balance Sheet on September 30, 2020:

[0001104659-20-130486:notes:214]
| (Dollars in thousands) | ​ | Operating | ​ | Finance | ​ |
| Years Ending September 30: |  | Leases |  | Leases |  |
| 2021 | ​ | $ | 5,614 | ​ | ​ | 2,930 | ​ |
| 2022 | ​ |  | 4,985 | ​ | ​ | 3,011 | ​ |
| 2023 | ​ |  | 3,984 | ​ | ​ | 3,094 | ​ |
| 2024 | ​ |  | 2,438 | ​ | ​ | 3,177 | ​ |
| 2025 and thereafter | ​ |  | 6,984 | ​ | ​ | 28,323 | ​ |
| Total minimum lease payments | ​ | ​ | 24,005 | ​ | ​ | 40,535 | ​ |
| Less: amounts representing interest | ​ |  | 2,211 | ​ | ​ | 10,270 | ​ |
| Present value of net minimum lease payments | ​ | $ | 21,794 | ​ | ​ | 30,265 | ​ |
| Less: current portion of lease obligations | ​ |  | 5,009 | ​ | ​ | 1,937 | ​ |
| Non-current portion of lease obligations | ​ | ​ | 16,785 | ​ | ​ | 28,328 | ​ |
| ROU assets | ​ | $ | 21,390 | ​ | ​ | 26,164 | ​ |

[0001104659-20-130486:notes:215]
Operating and finance lease liabilities are included in the Consolidated Balance Sheet in accrued other expenses (current portion) and other liabilities (long-term portion). Operating lease ROU assets are included as a caption on the Consolidated Balance Sheet and finance lease ROU assets are included in Property, plant and equipment on the Consolidated Balance sheets.

[0001104659-20-130486:notes:216]
As the Company has not restated prior-year information for the adoption of ASC 842, the following presents the Company's future minimum lease payments for operating and capital leases under ASC 840 for continuing operations as of September 30, 2019:

[0001104659-20-130486:notes:217]
| (Dollars in thousands) |  | Operating |  | Finance |
| Years Ending September 30: | ​ | Leases | ​ | Leases |
| 2020 | ​ | $ | 5,574 |  | 2,518 |
| 2021 | ​ |  | 4,558 |  | 2,930 |
| 2022 | ​ |  | 3,950 |  | 3,012 |
| 2023 | ​ |  | 3,270 |  | 3,094 |
| 2024 and thereafter | ​ |  | 8,443 |  | 31,499 |
| Total minimum lease payments | ​ | $ | 25,795 |  | 43,053 |
| Less: amounts representing interest | ​ |  | * |  | 11,241 |
| Present value of net minimum lease payments | ​ |  | * |  | 31,812 |
| Less: Current portion of lease obligations | ​ |  | * |  | 1,832 |
| Non-current portion of lease obligations | ​ |  | * |  | 29,980 |

[0001104659-20-130486:notes:218]
*    Not applicable for operating leases


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001104659-20-130486:notes:219]
17.     Revenues

[0001104659-20-130486:notes:220]
| (a) | Disaggregation of Revenues |

[0001104659-20-130486:notes:221]
Our revenues by customer type, geographic location, and revenue recognition method for the year ended September 30, 2020 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within our reportable segments.

[0001104659-20-130486:notes:222]
| Year Ended September 30, 2020 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 169,484 | ​ | $ | 184,906 | ​ | $ | 158,420 | ​ | $ | 512,810 |
| Government | ​ |  | 184,836 | ​ |  | 6,797 | ​ |  | 28,472 | ​ |  | 220,105 |
| Total revenues | ​ | $ | 354,320 | ​ | $ | 191,703 | ​ | $ | 186,892 | ​ | $ | 732,915 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  |  |
| United States | ​ | $ | 305,155 | ​ | $ | 134,601 | ​ | $ | 92,105 | ​ | $ | 531,861 |
| International | ​ |  | 49,165 | ​ |  | 57,102 | ​ |  | 94,787 | ​ |  | 201,054 |
| Total revenues | ​ | $ | 354,320 | ​ | $ | 191,703 | ​ | $ | 186,892 | ​ | $ | 732,915 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  |  |
| Point in time | ​ | $ | 160,402 | ​ | $ | 144,192 | ​ | $ | 33,482 | ​ | $ | 338,076 |
| Over time | ​ |  | 193,918 | ​ |  | 47,511 | ​ |  | 153,410 | ​ |  | 394,839 |
| Total revenues | ​ | $ | 354,320 | ​ | $ | 191,703 | ​ | $ | 186,892 | ​ | $ | 732,915 |

[0001104659-20-130486:notes:223]
| (b) | Remaining Performance Obligations |

[0001104659-20-130486:notes:224]
Our remaining performance obligations, which is the equivalent of our backlog, represent the expected transaction price allocated to our contracts that we expect to recognize as revenue in future periods when we perform under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At September 30, 2020, we had $517.4 million in remaining performance obligations of which we expect to recognize revenues of 73% in the next twelve months.

[0001104659-20-130486:notes:225]
| (c) | Contract assets and liabilities |

[0001104659-20-130486:notes:226]
Assets and liabilities related to our contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At September 30, 2020, contract assets and liabilities totaled $96.7 million and $100.6 million, respectively. Upon adoption of ASC 606 on October 1, 2018, contract assets and liabilities related to our contracts with customers were $87 million and $51 million, respectively. During 2020, we recognized approximately $54 million in revenues that were included in the contract liabilities balance at the adoption date.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001104659-20-130486:notes:227]
18.     Quarterly Financial Information (Unaudited)

[0001104659-20-130486:notes:228]
| ​ | ​ | First | ​ | Second | ​ | Third | ​ | Fourth |
| (Dollars in thousands, except per share amounts) |  | Quarter |  | Quarter |  | Quarter |  | Quarter |
| 2020 |  | ​ |  |  |  |  |  |  |  |
| Net sales | ​ | $ | 171,728 |  | 180,492 |  | 172,665 |  | 208,030 |
| Net earnings (loss) from continuing operations | ​ | ​ | 10,764 | ​ | 17,822 | ​ | 18,687 | ​ | (21,808) |
| Net earnings from discontinued operations | ​ | ​ | 76,013 | ​ | — | ​ | — | ​ | 502 |
| Net earnings (loss) | ​ |  | 86,777 |  | 17,822 |  | 18,687 |  | (21,306) |
| Basic earnings per share: | ​ |  | ​ |  | ​ |  | ​ |  | ​ |
| Net earnings (loss) from continuing operations | ​ | $ | 0.41 |  | 0.69 |  | 0.72 |  | (0.84) |
| Net earnings from discontinued operations | ​ | ​ | 2.93 | ​ | — | ​ | — | ​ | 0.02 |
| Net earnings (loss) | ​ |  | 3.34 |  | 0.69 |  | 0.72 |  | (0.82) |
| Diluted earnings per share: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net earnings (loss) from continuing operations | ​ | $ | 0.41 | ​ | 0.68 | ​ | 0.72 | ​ | (0.83) |
| Net earnings from discontinued operations | ​ | ​ | 2.91 | ​ | — | ​ | — | ​ | 0.02 |
| Net earnings (loss) | ​ | $ | 3.32 | ​ | 0.68 | ​ | 0.72 | ​ | (0.81) |
| Dividends declared per common share | ​ | $ | 0.08 |  | 0.08 |  | 0.08 |  | 0.08 |
| Common stock price per share: | ​ |  | ​ |  | ​ |  | ​ |  | ​ |
| High | ​ | $ | 93.21 |  | 107.10 |  | 94.24 |  | 95.60 |
| Low | ​ |  | 74.16 |  | 62.64 |  | 68.09 |  | 78.30 |
| 2019 | ​ |  | ​ |  | ​ |  | ​ |  | ​ |
| Net sales | ​ | $ | 163,365 |  | 171,243 |  | 178,259 |  | 213,177 |
| Net earnings from continuing operations | ​ | ​ | 17,350 | ​ | 17,822 | ​ | 19,045 | ​ | 23,272 |
| Net (loss) earnings from discontinued operations | ​ | ​ | (33) | ​ | 975 | ​ | 1,022 | ​ | 1,586 |
| Net earnings | ​ |  | 17,317 |  | 18,797 |  | 20,067 |  | 24,858 |
| Basic earnings per share: | ​ |  | ​ |  | ​ |  | ​ |  | ​ |
| Net earnings from continuing operations | ​ | ​ | 0.67 |  | 0.69 |  | 0.73 |  | 0.90 |
| Net earnings from discontinued operations | ​ | ​ | — | ​ | 0.04 | ​ | 0.04 | ​ | 0.06 |
| Net earnings | ​ | $ | 0.67 |  | 0.73 |  | 0.77 |  | 0.96 |
| Diluted earnings per share: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Net earnings from continuing operations | ​ | ​ | 0.66 | ​ | 0.68 | ​ | 0.73 | ​ | 0.89 |
| Net earnings from discontinued operations | ​ | ​ | — | ​ | 0.04 | ​ | 0.04 | ​ | 0.06 |
| Net earnings | ​ | $ | 0.66 | ​ | 0.72 | ​ | 0.77 | ​ | 0.95 |
| Dividends declared per common share | ​ | $ | 0.08 |  | 0.08 |  | 0.08 |  | 0.08 |
| Common stock price per share: | ​ |  | ​ |  | ​ |  | ​ |  | ​ |
| High | ​ | $ | 71.47 |  | 71.29 |  | 82.70 |  | 85.86 |
| Low | ​ |  | 59.00 |  | 62.91 |  | 67.43 |  | 73.04 |

[0001104659-20-130486:notes:229]
See Note 2 for discussion of divestiture activity.
