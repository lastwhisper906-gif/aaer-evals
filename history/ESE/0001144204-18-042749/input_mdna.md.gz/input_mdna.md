# ESE MD&A — 0001144204-18-042749


## mdna

[0001144204-18-042749:mdna:1]
[same as prior period, unchanged from 0001144204-18-026388:mdna:1]

[0001144204-18-042749:mdna:2]
[same as prior period, unchanged from 0001144204-18-026388:mdna:2]

[0001144204-18-042749:mdna:3]
References to the third quarters of 2018 and 2017 represent
the three-month periods ended June 30, 2018 and 2017, respectively.

[0001144204-18-042749:mdna:4]
[same as prior period, unchanged from 0001144204-18-026388:mdna:4]

[0001144204-18-042749:mdna:5]
In the third quarter of 2018, sales, net earnings and diluted
earnings per share were $192.2 million, $19.0 million and $0.73 per share, respectively, compared to $171.2 million, $12.6 million
and $0.49 per share, respectively, in the third quarter of 2017. In the first nine months of 2018, sales, net earnings and diluted
earnings per share were $540.5 million, $63.7 million and $2.45, respectively, compared to $478.7 million, $34.5 million and $1.33
per share, respectively, in the first nine months of 2017.

[0001144204-18-042749:mdna:6]
[same as prior period, unchanged from 0001144204-18-026388:mdna:8]

[0001144204-18-042749:mdna:7]
Net sales increased $21.0 million, or 12.3%, to $192.2 million
in the third quarter of 2018 from $171.2 million in the third quarter of 2017. Net sales increased $61.8 million, or 12.9%, to
$540.5 million in the first nine months of 2018 from $478.7 million in the first nine months of 2017. The increase in net sales
in the third quarter of 2018 as compared to the third quarter of 2017 was due to a $13.4 million increase in the USG segment, a
$7.5 million increase in the Test segment and a $1.6 million increase in the Technical Packaging segment, partially offset by a
$1.5 million decrease in the Filtration segment. The increase in net sales in the first nine months of 2018 as compared to the
corresponding prior year period was due to a $47.7 million increase in the USG segment, a $13.6 million increase in the Test segment
and a $3.8 million increase in the Technical Packaging segment, partially offset by a $3.3 million decrease in the Filtration segment.

[0001144204-18-042749:mdna:8]
[same as prior period, unchanged from 0001144204-18-026388:mdna:10]

[0001144204-18-042749:mdna:9]
In the third quarter of 2018, net sales of $69.7 million were
$1.5 million, or 2.0%, lower than the $71.2 million in the third quarter of 2017. Net sales decreased $3.3 million, or 1.7%, to
$195.5 million in the first nine months of 2018 from $198.9 million in the first nine months of 2017. The sales decrease in the
third quarter of 2018 compared to the third quarter of 2017 was mainly due to a $4.7 million decrease in net sales at VACCO due
to lower shipments of its defense spares products and a $1.6 million decrease in net sales at PTI due to lower aerospace assembly
and industrial/automotive shipments, partially offset by a $2.2 million increase in net sales at Mayday due to higher aerospace
shipments, $1.8 million increase in net sales at Crissair due to higher aerospace shipments and $0.9 million increase in net sales
at Westland. The sales decrease in the first nine months of 2018 compared to the first nine months of 2017 was primarily due to
a $6.2 million decrease in net sales at PTI due to lower aerospace assembly and industrial/automotive shipments, a $6.0 million
decrease in net sales at VACCO due to lower shipments of its defense spares products and a $3.8 million decrease in net sales at
Westland due to timing of shipments on government programs, partially offset by an $12.9 million increase in net sales at Mayday
and Crissair due to higher aerospace shipments.

[0001144204-18-042749:mdna:10]
[same as prior period, unchanged from 0001144204-18-026388:mdna:12]

[0001144204-18-042749:mdna:11]
In the third quarter of 2018, net sales of $45.0 million were
$7.5 million, or 19.9%, higher than the $37.5 million recorded in the third quarter of 2017. Net sales increased $13.6 million,
or 12.4%, to $123.4 million in the first nine months of 2018 from $109.7 million in the first nine months of 2017. The increase
in the third quarter and first nine months of 2018 compared to the corresponding periods of 2017 was primarily due to higher sales
from the segment’s U.S. operations due to the timing of test and measurement chamber projects.

[0001144204-18-042749:mdna:12]
[same as prior period, unchanged from 0001144204-18-026388:mdna:14]

[0001144204-18-042749:mdna:13]
Net sales increased $13.4 million, or 31.9%, to $55.5 million
in the third quarter of 2018 from $42.1 million in the third quarter of 2017. Net sales increased $47.7 million, or 43.2%, to $157.9
million in the first nine months of 2018 from $110.3 million in the first nine months of 2017. The increase in the third quarter
of 2018 compared to the third quarter of 2017 was mainly due to the sales contributions from the NRG, Morgan Schaffer and Vanguard
Instruments acquisitions. The increase in the first nine months of 2018 compared to the first nine months of 2017 was mainly due
to the sales contributions from NRG, Morgan Schaffer and Vanguard Instruments and new products and software solutions at Doble.

[0001144204-18-042749:mdna:14]
[same as prior period, unchanged from 0001144204-18-026388:mdna:16]

[0001144204-18-042749:mdna:15]
In the third quarter of 2018, net sales of $22.0 million were
$1.6 million, or 7.7%, higher than the $20.4 million in the third quarter of 2017. Net sales increased $3.8 million, or 6.4%,
to $63.7 million in the first nine months of 2018 from $59.8 million in the first nine months of 2017. The increase in the third
quarter and first nine months of 2018 compared to the corresponding periods of 2017 was primarily due to the increase in net sales
from Plastique driven by fluctuations in currency ($2.5 million for the first nine months of 2018) and increased shipments to
new customers.

[0001144204-18-042749:mdna:16]
[same as prior period, unchanged from 0001144204-18-026388:mdna:18]

[0001144204-18-042749:mdna:17]
Backlog was $425.5 million at June 30, 2018 compared with $377.1
million at September 30, 2017. The Company received new orders totaling $201.1 million in the third quarter of 2018 compared to
$182.2 million in the third quarter of 2017. Of the new orders received in the third quarter of 2018, $85.9 million related to
Filtration products, $37.9 million related to Test products, $57.8 million related to USG products, and $19.5 million related to
Technical Packaging products. Of the new orders received in the third quarter of 2017, $77.6 million related to Filtration products,
$38.0 million related to Test products, $46.3 million related to USG products, and $20.3 million related to Technical Packaging
products.

[0001144204-18-042749:mdna:18]
The Company received new orders totaling $588.9 million in the
first nine months of 2018 compared to $532.0 million in the first nine months of 2017. Of the new orders received in the first
nine months of 2018, $219.1 million related to Filtration products, $144.2 million related to Test products, $

[0001144204-18-042749:mdna:19]
[same as prior period, unchanged from 0001144204-18-026388:mdna:6]

[0001144204-18-042749:mdna:20]
8.0 million related
to USG products, and $57.6 million related to Technical Packaging products. Of the new orders received in the first nine months
of 2017, $207.1 million related to Filtration products, $138.3 million related to Test products, $118.9 million related to USG
products, and $67.7 million related to Technical Packaging products.

[0001144204-18-042749:mdna:21]
[same as prior period, unchanged from 0001144204-18-026388:mdna:21]

[0001144204-18-042749:mdna:22]
Selling, general and administrative (SG&A) expenses for
the third quarter of 2018 were $39.9 million (20.8% of net sales), compared with $38.5 million (22.5% of net sales) for the third
quarter of 2017. For the first nine months of 2018, SG&A expenses were $122.8 million (22.7% of net sales) compared to $107.1
million (22.4% of net sales) for the first nine months of 2017. The increase in SG&A in the third quarter and first nine months
of 2018 compared to the corresponding periods of 2017 was mainly due to an increase in the USG segment due to the Company’s
recent acquisitions (NRG, Morgan Schaffer and Vanguard Instruments) and additional sales and marketing expenses to support future
revenue growth, and at Corporate (higher professional fees including acquisition expenses).

[0001144204-18-042749:mdna:23]
[same as prior period, unchanged from 0001144204-18-026388:mdna:23]

[0001144204-18-042749:mdna:24]
[same as prior period, unchanged from 0001144204-18-026388:mdna:24]

[0001144204-18-042749:mdna:25]
Amortization of intangible assets was $4.6 million and $13.6
million for the third quarter and first nine months of 2018, respectively, compared to $4.1 million and $11.5 million for the corresponding
periods of 2017. Amortization expenses consist of amortization of acquired intangible assets from acquisitions and other identifiable
intangible assets (primarily software). The increase in amortization expense in the third quarter and first nine months of 2018
compared to the corresponding periods of 2017 was mainly due to an increase in amortization of intangibles related to the Morgan
Schaffer, NRG and Mayday acquisitions.

[0001144204-18-042749:mdna:26]
[same as prior period, unchanged from 0001144204-18-026388:mdna:26]

[0001144204-18-042749:mdna:27]
Other income, net, was $0.7 million in the third quarter of
2018 compared to other expenses, net, of $1.2 million in the third quarter of 2017. The principal component in other income, net,
in the third quarter of 2018 was a gain on derivative instruments of $0.5 million. There were no individually significant items
in other (income) expenses, net, in the third quarter of 2017.

[0001144204-18-042749:mdna:28]
Other expenses, net, was $1.0 million in the first nine months
of 2018 compared to other income, net, of $0.2 million in the first nine months of 2017. The principal components in other expenses,
net, in the first nine months of 2018 were $2.1 million of charges primarily related to the USG segment restructuring activities,
including the Doble facility consolidations, partially offset by gains on derivative instruments. The restructuring charges mainly
related to severance and compensation benefits, professional fees and asset impairment charges related to abandoned assets. The
principal component in other income, net, in the first nine months of 2017 was $0.4 million of income related to death benefit
insurance proceeds from a former subsidiary.

[0001144204-18-042749:mdna:29]
[same as prior period, unchanged from 0001144204-18-026388:mdna:29]

[0001144204-18-042749:mdna:30]
The Company evaluates the performance of its operating segments
based on EBIT, and provides EBIT on a consolidated basis, which is a non-GAAP financial measure. Please refer to the discussion
of non-GAAP financial measures in Note 7 to the Consolidated Financial Statements, above. EBIT was $25.6 million (13.3% of net
sales) for the third quarter of 2018 compared to $18.6 million (10.9% of net sales) for the third quarter of 2017. For the first
nine months of 2018, EBIT was $56.2 million (10.4% of net sales) compared to $53.1 million (11.1% of net sales) for the first nine
months of 2017.

[0001144204-18-042749:mdna:31]
[same as prior period, unchanged from 0001144204-18-026388:mdna:31]

[0001144204-18-042749:mdna:32]
| (In thousands) |  | Three Months Ended June 30, |  |  | Nine Months Ended June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Consolidated EBIT |  | $ | 25,559 |  |  |  | 18,635 |  |  |  | 56,165 |  |  |  | 53,118 |  |
| Less: Interest expense, net |  |  | (2,243 | ) |  |  | (1,213 | ) |  |  | (6,464 | ) |  |  | (2,752 | ) |
| Plus (Less): Income tax |  |  | (4,297 | ) |  |  | (4,777 | ) |  |  | 13,983 |  |  |  | (15,837 | ) |
| Net earnings |  | $ | 19,019 |  |  |  | 12,645 |  |  |  | 63,684 |  |  |  | 34,529 |  |

[0001144204-18-042749:mdna:33]
[same as prior period, unchanged from 0001144204-18-026388:mdna:33]

[0001144204-18-042749:mdna:34]
EBIT in the third quarter of 2018 was $14.3 million (20.5% of
net sales) compared to $11.9 million (16.8% of net sales) in the third quarter of 20

[0001144204-18-042749:mdna:35]
[same as prior period, unchanged from 0001144204-18-026388:mdna:35]

[0001144204-18-042749:mdna:36]
. EBIT in the first nine months of 20

[0001144204-18-042749:mdna:37]
[same as prior period, unchanged from 0001144204-18-026388:mdna:37]

[0001144204-18-042749:mdna:38]
was
$35.1 million (17.9% of net sales) compared to $34.3 million (17.2% of net sales) in the first nine months of 2017. The increase
in EBIT in the third quarter compared to the third quarter of 2017 was mainly due to an increase at Crissair, Mayday and Westland
due to higher sales volumes partially offset by a decrease in EBIT at VACCO and PTI due to the lower sales volumes mentioned above.
The increase in EBIT in the first nine months of 2018 compared to the first nine months of 2017 was mainly due to an increase at
Mayday and Crissair due to higher sales volumes partially offset by a decrease in EBIT at Westland, PTI and VACCO due to lower
sales volumes as mentioned above. In addition, EBIT in the first nine months of 2018 included $0.5 million of restructuring charges
at PTI related to the exit of the low margin industrial/automotive market, which were recorded in the second quarter of 2018. These
charges consisted primarily of severance and compensation benefits and asset impairment charges.

[0001144204-18-042749:mdna:39]
[same as prior period, unchanged from 0001144204-18-026388:mdna:39]

[0001144204-18-042749:mdna:40]
EBIT in the third quarter of 2018 was $5.9 million (13.1% of
net sales) compared to $4.9 million (13.0% of net sales) in the third quarter of 2017. EBIT in the first nine months of 2018 was
$13.8 million (11.2% of net sales) compared to $11.1 million (10.1% of net sales) in the first nine months of 2017. The increase
in EBIT in the third quarter and first nine months of 2018 compared to the corresponding prior year periods was primarily due to
the increased sales volumes mainly from the segment’s U.S. operations.

[0001144204-18-042749:mdna:41]
[same as prior period, unchanged from 0001144204-18-026388:mdna:41]

[0001144204-18-042749:mdna:42]
[same as prior period, unchanged from 0001144204-18-026388:mdna:42]

[0001144204-18-042749:mdna:43]
EBIT in the third quarter of 2018 was $11.5 million (20.8%
of net sales) compared to $8.5 million (20.2% of net sales) in the third quarter of 2017. EBIT in the first nine months of 2018
was $27.8 million (17.6% of net sales) compared to EBIT of $25.6 million (23.2% of net sales) in the first nine months of 2017.
The increase in EBIT in the third quarter and first nine months of 2018 compared to the corresponding periods of 2017 was mainly
due to the higher sales volumes as well as the EBIT contribution from the recent acquisitions of NRG, Morgan Schaffer and Vanguard
Instruments. In addition, EBIT in the first nine months of 2018 was negatively impacted by $1.9 million of charges recorded in
the second quarter of 2018 related to closing the Doble facilities in Norway and China consisting mainly of employee severance
and compensation benefits, professional fees, and asset impairment charges.

[0001144204-18-042749:mdna:44]
[same as prior period, unchanged from 0001144204-18-026388:mdna:44]

[0001144204-18-042749:mdna:45]
EBIT in the third quarter of 2018 was $2.5 million (11.4% of
net sales) compared to $2.4 million (11.9% of net sales) in the third quarter of 2017. EBIT in the first nine months of 2018 was
$5.4 million (8.4% of net sales) compared to $5.7 million (9.5% of net sales) in the first nine months of 2017. The decrease in
EBIT as a percent of net sales in the third quarter of 2018 and the decrease in EBIT in the first nine months of 2018 compared
to the corresponding periods of 2017 was mainly due to product mix at Plastique including lower margin projects.

[0001144204-18-042749:mdna:46]
[same as prior period, unchanged from 0001144204-18-026388:mdna:46]

[0001144204-18-042749:mdna:47]
Corporate costs included in EBIT were $8.7 million and $25.8
million in the third quarter and first nine months of 2018, respectively, compared to $9.1 million and $23.5 million in the corresponding
periods of 2017. The decrease in Corporate costs in the third quarter of 2018 compared to the third quarter of 2017 was mainly
due to the $0.5 million of gains on derivative instruments recorded in the third quarter of 2018. The increase in Corporate costs
in the first nine months of 2018 compared to the corresponding periods of 2017 was primarily due to higher professional fees and
an increase in amortization of intangible assets related to recent acquisitions.

[0001144204-18-042749:mdna:48]
[same as prior period, unchanged from 0001144204-18-026388:mdna:48]

[0001144204-18-042749:mdna:49]
Interest expense was $2.2 million and $6.5 million in the third
quarter and first nine months of 2018, respectively, and $1.2 million and $2.8 million in the corresponding periods of 2017. The
increase in interest expense in the first nine months of 2018 compared to the corresponding period of 2017 was mainly due to higher
average outstanding borrowings ($263 million compared to $189 million) and higher average interest rates (2.97% vs. 1.90%) as a
result of the additional borrowings to fund the Company’s recent acquisitions.

[0001144204-18-042749:mdna:50]
[same as prior period, unchanged from 0001144204-18-026388:mdna:50]

[0001144204-18-042749:mdna:51]
The third quarter 2018 effective income tax rate was 18.4% compared
to 27.4% in the third quarter of 2017. The income tax benefit for the first nine months of 2018 was $14.0 million compared to income
tax expense of $15.8 million for the first nine months of 2017. The effective income tax rate for the first nine months of 2018
was (28.1%) compared to 31.4% for the first nine months of 2017. H.R. 1, Tax Cuts and Jobs Act (“TCJA”), was
signed into law on December 22, 2017. The total impact of the TCJA in the third quarter and first nine months of 2018 was a net
expense of $0.1 million and a net benefit of $24.3 million, respectively. The impacts were as follows: First, the Company’s
2018 federal statutory rate decreased from 35.0% to 24.5% which required an adjustment to the value of its deferred tax assets
and liabilities. This adjustment ($30.3 million provisional amount recorded in the first quarter of 2018 and $0.4 million provisional
amount in the third quarter of 2018) favorably impacted the third quarter and year-to-date effective tax rate by 1.5% and 61.7%,
respectively. Second, the TCJA subjected the Company’s cumulative foreign earnings to federal income tax ($4.1 million provisional
amount of which $2.9 million was recorded in the first quarter of 2018, $0.7 million was recorded in the second quarter of 2018,
and $0.5 million in the third quarter of 2018) which unfavorably impacted the third quarter and year-to-date effective tax rate
by 2.1% and 8.2%, respectively.

[0001144204-18-042749:mdna:52]
In the first quarter of 2018, the Company recorded a $2.3 million
provisional estimate of the income tax effects of the future repatriation of the cumulative earnings of its foreign subsidiaries
which unfavorably impacted the year-to-date effective tax rate by 4.7%. An additional $7.5 million pension contribution for
the 2017 plan year was approved during the second quarter of 2018 increasing the value of the deferred tax liability by $1.0 million
(provisional amount). This favorable adjustment, net of the $0.3 million unfavorable impact to the 2017 Domestic Production Deduction,
favorably impacted the year-to-date effective tax rate by 1.6%. An accounting method change was filed with the 2017 tax return
which resulted in an additional deferred tax liability to be adjusted as a result of the TCJA. A favorable adjustment, net of the
$0.3 million unfavorable impact to the 2017 Domestic Production deduction, favorably impacted the third quarter and year-to-date
effective tax rate by 2.9% and 1.4%, respectively. The income tax expense in the third quarter and first nine months of 2018 was
favorably impacted by return to provision true-ups decreasing the third quarter and year-to-date effective tax rate by 1.4% and
0.7%, respectively. In 2017, the Company elected to adopt Accounting Standards Update No. 2016-09, Improvements to Employee
Share-Based Payment Accounting, resulting in income tax expense in the third quarter and nine months of 2017 being favorably
impacted by additional tax benefits on share-based compensation that vested during the quarter decreasing the effective tax rate
by 5.2% and 1.8%, respectively. Income tax expense in the third quarter and nine months of 2018 was also favorably impacted by
additional tax benefits on share-based compensation that vested during the quarter decreasing the effective tax rate by 1.9% and
0.9%, respectively.

[0001144204-18-042749:mdna:53]
Staff Accounting Bulletin No. 118 (SAB 118) was issued by the
SEC effective December 22, 2017. SAB 118 allows registrants to record provisional amounts of the income tax effects of the TCJA
where the information necessary to complete the accounting under ASC Topic 740 is not available but the amounts are based on reasonable
estimates. SAB 118 permits registrants to record adjustments to its provisional amounts during the measurement period (which cannot
exceed one year).

[0001144204-18-042749:mdna:54]
[same as prior period, unchanged from 0001144204-18-026388:mdna:58]

[0001144204-18-042749:mdna:55]
In the first and second quarter of 2018, the Company recorded
reasonable provisional estimates of the TCJA income tax effects. During the third quarter of 2018, the Company collected and analyzed
additional information needed to compute the Company’s deferred tax assets and liabilities. However, these amounts remain
provisional as the Company needs more time to collect and analyze information primarily related to the federal impact on the value
of state deferred tax assets and liabilities. The income tax effects of subjecting the Company’s cumulative foreign earnings
to federal income tax also remains provisional as the Company needs more time to collect and analyze the cumulative balance of
earnings subject to the tax and the amount of foreign tax credit that is available to offset the tax.

[0001144204-18-042749:mdna:56]
[same as prior period, unchanged from 0001144204-18-026388:mdna:54]

[0001144204-18-042749:mdna:57]
[same as prior period, unchanged from 0001144204-18-026388:mdna:55]

[0001144204-18-042749:mdna:58]
TCJA moved the U.S. to a federal tax system that will no longer
tax dividends from foreign corporations to U.S. corporations. The cost of transitioning to this new tax system is a deemed repatriation
of cumulative foreign earnings, the “Foreign Earnings Toll Charge”, the estimated tax cost of which was recorded in
the first quarter and trued up during the second and third quarters of 2018. The actual repatriation of foreign earnings triggers
foreign dividend withholding taxes and U.S. state taxes, the estimated cost of which was recorded in the first quarter and trued
up during the second and third quarters of 2018.

[0001144204-18-042749:mdna:59]
During the three-month period ended June 30, 2018, there were
no material changes in the unrecognized tax benefits. The Company does not anticipate a material change in the amount of unrecognized
tax benefits in the next twelve months.

[0001144204-18-042749:mdna:60]
[same as prior period, unchanged from 0001144204-18-026388:mdna:61]

[0001144204-18-042749:mdna:61]
[same as prior period, unchanged from 0001144204-18-026388:mdna:59]

[0001144204-18-042749:mdna:62]
The Company’s overall financial position and liquidity
remains strong. Working capital (current assets less current liabilities) increased to $210.0 million at June 30,

[0001144204-18-042749:mdna:63]
[same as prior period, unchanged from 0001144204-18-026388:mdna:63]

[0001144204-18-042749:mdna:64]
18 from $197.8
million at September 30, 2017. Inventories increased by $

[0001144204-18-042749:mdna:65]
| 21 |

[0001144204-18-042749:mdna:66]
.1 million during this period mainly due to a $10.7 million increase
within the Filtration segment primarily to support new aerospace platforms, a $4.3 million increase within the Test segment and
a $4.2 million increase within the USG segment to support revenue growth in the fourth quarter of 2018. Costs and estimated earnings
in excess of billings on long-term contracts decreased $8.1 million in the first nine months of 2018 mainly due to ETS-Lindgren
($7.3 million) related to timing of projects.

[0001144204-18-042749:mdna:67]
Net cash provided by operating activities was $53.9 million
and $33.5 million in the first nine months of 2018 and 2017, respectively. The increase in net cash provided by operating activities
in the first nine months of 2018 as compared to the first nine months of 2017 was driven by higher earnings and lower working
capital requirements.

[0001144204-18-042749:mdna:68]
Capital expenditures were $15.5 million and $23.1 million in
the first nine months of 2018 and 2017, respectively. The decrease in the first nine months of 2018 was mainly due to a decrease
in machinery and equipment at Plastique ($3.6 million) and VACCO ($1.8 million). In addition, the Company incurred expenditures
for capitalized software of $7.1 million and $6.2 million in the first nine months of 2018 and 2017, respectively.

[0001144204-18-042749:mdna:69]
Credit Facility

[0001144204-18-042749:mdna:70]
At June 30, 2018, the Company had approximately $180 million
available to borrow under its bank credit facility, a $250 million increase option subject to lender approval, and $43.3 million
cash on hand. At June 30, 2018, the Company had $262 million of outstanding borrowings under the credit facility in addition to
outstanding letters of credit of $8.3 million. Cash flow from operations and borrowings under the Company’s credit facility
are expected to meet the Company’s capital requirements and operational needs for the foreseeable future. The Company’s
ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating
or other outside banks.

[0001144204-18-042749:mdna:71]
[same as prior period, unchanged from 0001144204-18-026388:mdna:69]

[0001144204-18-042749:mdna:72]
In March 2017, the FASB issued ASU 2017-07, Improving the
Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost, which updates ASC 715, Compensation
– Retirement Benefits. This update permits only the service cost component of net periodic pension and postretirement
expense to be reported with other compensation costs, while all other components are required to be reported separately in other
deductions, outside any subtotal of operating income. These updates are effective for fiscal years beginning after December 15,
2017, with early adoption permitted, and must be adopted on a retrospective basis. The updates change presentation only and will
not impact the Company’s results of operations.

[0001144204-18-042749:mdna:73]
In August 2017, the FASB issued ASU 2017-12, Targeted Improvements
to Accounting for Hedge Activities, which updates ASC 815, Derivatives and Hedging. This update is intended to amend
the hedge accounting model to enable entities to better align the economics of risk management activities and financial reporting.
The updates eliminate the requirement to separately measure and report hedge ineffectiveness and simplify hedge documentation and
effectiveness assessment requirements. These updates are effective for fiscal years beginning after December 15, 2018, with early
adoption permitted, and must be adopted using a modified retrospective approach. These updates are not expected to materially impact
the Company’s results of operations.

[0001144204-18-042749:mdna:74]
In February 2016, the FASB issued ASU No. 2016-062, Leases
(Topic 842), which, among other things, requires an entity to recognize lease assets and lease liabilities on the balance sheet
and disclose key information about leasing arrangements. This standard will increase an entities’ reported assets and liabilities.
The standard is effective for fiscal years beginning after December 15, 2018 and mandates a modified retrospective transition period
for all entities. The Company is currently assessing the impact of this standard on its consolidated financial statements and related
disclosures.

[0001144204-18-042749:mdna:75]
In May 2014, the FASB issued ASU No. 2014-09, Revenue from
Contracts with Customers, (ASU 2014-09) which requires an entity to recognize the amount of revenue to which it expects to
be entitled for the transfer of promised goods or services to customers. This guidance has been further clarified and amended.
The new standard will be effective for annual reporting periods beginning after December 15, 2017, and interim periods within
those annual periods. The standard permits the use of either the retrospective or cumulative effect transition method. The Company
has selected the cumulative effect method of transition to the new standard. Because the new standard impacts the Company’s
business processes, systems and controls, we developed a project plan to guide the implementation. This project plan included
analyzing the standard’s impact on our contract portfolio, comparing our historical accounting policies and practices to
the requirements of the new standard, and identifying differences from applying the requirements of the new standard to our contracts.
We developed internal controls to ensure that we adequately evaluated our portfolio of contracts under the five-step model to
ensure proper assessment of our operating results under ASU 2014-09. We reported on the progress of the implementation to the
Audit Committee and the Board of Directors on a regular basis during the project’s duration. The adoption of ASU 2014-09
will have one primary impact on our portfolio of contracts and our Consolidated Financial Statements which is that more of our
contracts within our Filtration and Technical Packaging segments will recognize revenue and earnings over time as the work progresses
versus at a single point of time. This standard will not change the total revenue or operating earnings recognized, only the timing
of when those amounts are recognized. The Company is currently in the process of finalizing the effect that ASU 2014-09 will have
on its consolidated financial statements and related disclosures.

[0001144204-18-042749:mdna:76]
[same as prior period, unchanged from 0001144204-18-026388:mdna:74]

[0001144204-18-042749:mdna:77]
[same as prior period, unchanged from 0001144204-18-026388:mdna:75]

[0001144204-18-042749:mdna:78]
[same as prior period, unchanged from 0001144204-18-026388:mdna:76]

[0001144204-18-042749:mdna:79]
[same as prior period, unchanged from 0001144204-18-026388:mdna:77]

[0001144204-18-042749:mdna:80]
A dividend of $0.08 per share, totaling $2.1 million, was paid
on April 18, 2018 to stockholders of record as of April 3, 2018. Subsequent to June 30, 2018, a quarterly dividend of $0.08 per
share, totaling $2.1 million, was paid on July 19, 2018 to stockholders of record as of July 5, 2018.

[0001144204-18-042749:mdna:81]
[same as prior period, unchanged from 0001144204-18-026388:mdna:79]

[0001144204-18-042749:mdna:82]
Management’s current expectations for 2018 remain consistent
with the details outlined in the Business Outlook presented in previous releases. Management expects 2018 GAAP EPS in the range
of $3.55 to $3.65 per share and Adjusted EPS in the range of $2.65 to $2.75 per share, adjusting for the 2018 incremental net tax
benefits resulting from U.S. Tax Reform and the 2018 cost reduction charges in the USG and Filtration segments.

[0001144204-18-042749:mdna:83]
20

[0001144204-18-042749:mdna:84]
[same as prior period, unchanged from 0001144204-18-026388:mdna:83]

[0001144204-18-042749:mdna:85]
[same as prior period, unchanged from 0001144204-18-026388:mdna:84]

[0001144204-18-042749:mdna:86]
[same as prior period, unchanged from 0001144204-18-026388:mdna:85]

[0001144204-18-042749:mdna:87]
Contingencies

[0001144204-18-042749:mdna:88]
As a normal incident of the business in which the Company is
engaged, various claims, charges and litigation are asserted or commenced against the Company. Additionally, the Company is currently
involved in various stages of investigation and remediation relating to environmental matters. In the opinion of Management, the
aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company,
are adequately reserved, are covered by insurance, or would not have a material adverse effect on the Company’s results from
operations, capital expenditures, or competitive position.

[0001144204-18-042749:mdna:89]
[same as prior period, unchanged from 0001144204-18-026388:mdna:88]

[0001144204-18-042749:mdna:90]
Investors are cautioned that such statements are only predictions
and speak only as of the date of this Form 10-Q, and the Company undertakes no duty to update them except as may be required by
applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in
the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment,
including but not limited to those described in Item 1A, “Risk Factors,” of the Company’s Annual Report on Form
10-K for the fiscal year ended September 30, 2017, and the following: the impacts of natural disasters on the Company’s operations
and those of the Company’s customers and suppliers; the timing and content of future contract awards or customer orders;
the appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer
contracts or orders; financial exposure in connection with Company guarantees of certain Aclara contracts; weakening of economic
conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies;
competition; intellectual property rights; technical difficulties; the availability of selected acquisitions; delivery delays or
defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability
of certain raw materials; labor disputes; final analysis of the impacts of the TCJA; changes in U.S. tax laws and regulations;
other changes in laws and regulations including but not limited to changes in accounting standards and foreign taxation; changes
in interest rates; costs relating to environmental matters arising from current or former facilities; uncertainty regarding the
ultimate resolution of current disputes, claims, litigation or arbitration; and the integration of recently acquired businesses.
