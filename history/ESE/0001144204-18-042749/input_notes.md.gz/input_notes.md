# ESE notes — 0001144204-18-042749


## us-gaap:ScheduleOfDebtTableTextBlock

[0001144204-18-042749:notes:1]
The Company’s debt is summarized as follows:

[0001144204-18-042749:notes:2]
| (In thousands) |  | June 30,2018 |  |  | September 30, 2017 |  |
| Total borrowings |  | $ | 262,000 |  |  |  | 275,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000 | ) |  |  | (20,000 | ) |
| Total long-term debt, less current portion |  | $ | 242,000 |  |  |  | 255,000 |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0001144204-18-042749:notes:3]
The change in shareholders’ equity for the first nine months of 2018 is shown below (in thousands):

[0001144204-18-042749:notes:4]
| Balance at September 30, 2017 |  | $ | 671,918 |  |
| Net earnings |  |  | 63,684 |  |
| Other comprehensive (loss) |  |  | (2,647 | ) |
| Cash dividends |  |  | (6,205 | ) |
| Stock compensation plans |  |  | 504 |  |
| Balance at June 30, 2018 |  | $ | 727,254 |  |


## us-gaap:ScheduleOfChangesInProjectedBenefitObligationsTableTextBlock

[0001144204-18-042749:notes:5]
A summary of net periodic benefit expense for the Company’s defined benefit plans for the three and six-month periods ended March 31, 2018 and 2017 is shown in the following table. Net periodic benefit cost for each period presented is comprised of the following:

[0001144204-18-042749:notes:6]
|  |  | Three MonthsEnded June 30, |  |  | Nine MonthsEnded June 30, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Defined benefit plans |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest cost |  | $ | 821 |  |  |  | 737 |  |  |  | 2,461 |  |  |  | 2,438 |  |
| Expected return on assets |  |  | (975 | ) |  |  | (942 | ) |  |  | (2,924 | ) |  |  | (2,978 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior service cost |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 3 |  |
| Actuarial loss |  |  | 548 |  |  |  | 683 |  |  |  | 1,644 |  |  |  | 1,871 |  |
| Net periodic benefit cost |  | $ | 394 |  |  |  | 478 |  |  |  | 1,181 |  |  |  | 1,334 |  |


## us-gaap:ScheduleOfNotionalAmountsOfOutstandingDerivativePositionsTableTextBlock

[0001144204-18-042749:notes:7]
The following is a summary of the notional transaction amounts and fair values for the Company’s outstanding derivative financial instruments by risk category and instrument type as of June 30, 2018:

[0001144204-18-042749:notes:8]
| (In thousands) |  | Notionalamount |  |  | FairValue(US$) |  |  | FloatRate |  |  | FixRate |  |
| Forward contracts |  |  | 700 |  |  | GBP | (80 | ) |  |  |  |  |  |  |  |  |
| Forward contracts |  |  | 9,250 |  |  | USD | (199 | ) |  |  |  |  |  |  |  |  |
| Forward contracts |  |  | 600 |  |  | EUR | 10 |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  |  | 150,000 |  |  | USD | 227 |  |  |  | 2.09 | % |  |  | 1.80 | % |
| Interest rate swap * |  |  | 150,000 |  |  | USD | 760 |  |  |  | N/A |  |  |  | 2.09 | % |
| Interest rate swap ** |  |  | 150,000 |  |  | USD | 955 |  |  |  | N/A |  |  |  | 2.24 | % |

[0001144204-18-042749:notes:9]
[same as prior period, unchanged from 0001144204-18-026388:notes:46]

[0001144204-18-042749:notes:10]
[same as prior period, unchanged from 0001144204-18-026388:notes:47]


## us-gaap:ScheduleOfDerivativeLiabilitiesAtFairValueTableTextBlock

[0001144204-18-042749:notes:11]
The Company’s forward contracts and interest rate swaps are classified within Level 2 of the valuation hierarchy in accordance with FASB Accounting Standards Codification (ASC) 825, as presented below as of June 30, 2018:

[0001144204-18-042749:notes:12]
| (In thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets (Liabilities): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Forward contracts and interest rate swaps |  | $ | - |  |  |  | 1,673 |  |  | $ | - |  |  |  | 1,673 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001144204-18-042749:notes:13]
|  | 1. | BASIS OF PRESENTATION |

[0001144204-18-042749:notes:14]
[same as prior period, unchanged from 0001144204-18-026388:notes:2]

[0001144204-18-042749:notes:15]
The Company’s results for the three and nine-month periods ended June 30, 2018 are not necessarily indicative of the results for the entire 2018 fiscal year. References to the third quarters of 2018 and 2017 represent the fiscal quarters ended June 30, 2018 and 2017, respectively.

[0001144204-18-042749:notes:16]
The preparation of financial statements in conformity with GAAP 
requires management 
to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001144204-18-042749:notes:17]
|  | 2. | ACQUISITION |

[0001144204-18-042749:notes:18]
On March 14, 2018, the Company acquired the assets of Manta Test Systems Inc. (Manta), a North American utility solutions provider located in Mississauga, Ontario, Canada, for a purchase price of $9.5 million in cash. Manta has annualized sales of approximately $8 million. 
Since the date of acquisition, the operating results for Manta have been included as a product line of Doble Engineering Company within the Company’s USG segment. Based on the preliminary purchase price allocation, the Company recorded 
approximately $0.4 million of accounts receivable, $1.1 million of inventory, $0.2 million of property, plant and equipment, $0.4 million of accounts payable and accrued expenses, $3.5 million of goodwill, $1.2 million of tradenames and $3.5 million of amortizable intangible assets consisting of customer relationships with a weighted average life of 13 years.


## us-gaap:EarningsPerShareTextBlock

[0001144204-18-042749:notes:19]
|  | 3. | EARNINGS PER SHARE (EPS) |

[0001144204-18-042749:notes:20]
Basic EPS is calculated using the weighted average number of common shares outstanding during the period. Diluted EPS is calculated using the weighted average number of common shares outstanding during the period plus shares issuable upon the assumed exercise of dilutive common share options and vesting of performance-accelerated restricted shares (restricted shares) by using the treasury stock method. The number of shares used in the calculation of earnings per share for each period presented is as follows (in thousands):

[0001144204-18-042749:notes:21]
|  |  | Three MonthsEnded June 30, |  |  | Nine Months Ended June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Weighted Average Shares Outstanding - Basic |  |  | 25,900 |  |  |  | 25,815 |  |  |  | 25,862 |  |  |  | 25,756 |  |
| Dilutive Options and Restricted Shares |  |  | 150 |  |  |  | 210 |  |  |  | 180 |  |  |  | 219 |  |
| Adjusted Shares - Diluted |  |  | 26,050 |  |  |  | 26,025 |  |  |  | 26,042 |  |  |  | 25,975 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001144204-18-042749:notes:22]
[same as prior period, unchanged from 0001144204-18-026388:notes:10]

[0001144204-18-042749:notes:23]
[same as prior period, unchanged from 0001144204-18-026388:notes:11]

[0001144204-18-042749:notes:24]
[same as prior period, unchanged from 0001144204-18-026388:notes:12]

[0001144204-18-042749:notes:25]
Compensation expense related to the restricted share awards was $0.9 million and $3.1 million for the three and nine-month periods ended June 30, 2018, respectively, and $1.0 million and $3.3 million for the corresponding periods of 2017. There were 316,544 non-vested shares outstanding as of June 30, 2018.

[0001144204-18-042749:notes:26]
[same as prior period, unchanged from 0001144204-18-026388:notes:14]

[0001144204-18-042749:notes:27]
Compensation expense related to the non-employee director grants was $0.3 million and $0.8 million for the three and nine-month periods ended June 30, 2018, respectively, and $0.3 million and $0.8 million for the corresponding periods of 2017.

[0001144204-18-042749:notes:28]
The total share-based compensation cost that has been recognized in the results of operations and included within selling, general and administrative expenses (SG&A) was $1.2 million and $3.9 million for the three-and nine-month periods ended June 30, 2018, respectively, and $1.3 million and $4.1 million for the three and nine-month periods ended June 30, 2017. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $0.2 million and $0.9 million for the three and nine-month periods ended June 30, 2018, respectively, and $1.2 million and $2.2 million for the three and nine-month periods ended June 30, 2017, respectively. As of June 30, 2018, there was $8.9 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a remaining weighted-average period of 2.1 years.


## us-gaap:InventoryDisclosureTextBlock

[0001144204-18-042749:notes:29]
|  | 5. | INVENTORIES |

[0001144204-18-042749:notes:30]
[same as prior period, unchanged from 0001144204-18-026388:notes:18]

[0001144204-18-042749:notes:31]
| (In thousands) |  | June 30,2018 |  |  | September 30, 2017 |  |
| Finished goods |  | $ | 30,960 |  |  |  | 28,127 |  |
| Work in process |  |  | 57,155 |  |  |  | 43,750 |  |
| Raw materials |  |  | 57,481 |  |  |  | 52,638 |  |
| Total inventories |  | $ | 145,596 |  |  |  | 124,515 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001144204-18-042749:notes:32]
|  | 6. | GOODWILL AND OTHER INTANGIBLE ASSETS |

[0001144204-18-042749:notes:33]
Included on the Company’s Consolidated Balance Sheets at June 30, 2018 and September 30, 2017 are the following intangible assets gross carrying amounts and accumulated amortization:

[0001144204-18-042749:notes:34]
| (Dollars in thousands) |  | June 302018 |  |  | September 30, 2017 |  |
| Goodwill |  | $ | 381,420 |  |  |  | 377,879 |  |
| Intangible assets with determinable lives: |  |  |  |  |  |  |  |  |
| Patents |  |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 973 |  |  |  | 928 |  |
| Less: accumulated amortization |  |  | 773 |  |  |  | 750 |  |
| Net |  | $ | 200 |  |  |  | 178 |  |
| Capitalized software |  |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 68,876 |  |  |  | 63,007 |  |
| Less: accumulated amortization |  |  | 39,757 |  |  |  | 34,382 |  |
| Net |  | $ | 29,119 |  |  |  | 28,625 |  |
| Customer relationships |  |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 185,055 |  |  |  | 181,891 |  |
| Less: accumulated amortization |  |  | 45,066 |  |  |  | 37,364 |  |
| Net |  | $ | 139,989 |  |  |  | 144,527 |  |
| Other |  |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 5,316 |  |  |  | 5,373 |  |
| Less: accumulated amortization |  |  | 1,899 |  |  |  | 1,383 |  |
| Net |  | $ | 3,417 |  |  |  | 3,990 |  |
| Intangible assets with indefinite lives: |  |  |  |  |  |  |  |  |
| Trade names |  | $ | 173,149 |  |  |  | 173,813 |  |

[0001144204-18-042749:notes:35]
The changes in the carrying amount of goodwill attributable to each business segment for the nine months ended June 30, 2018 is as follows:

[0001144204-18-042749:notes:36]
| (Dollars in millions) |  | USG |  |  | Test |  |  | Filtration |  |  | Packaging |  |  | Total |  |
| Balance as of September 30, 2017 |  |  | 250.2 |  |  |  | 34.1 |  |  |  | 73.7 |  |  |  | 19.9 |  |  |  | 377.9 |  |
| Acquisition activity |  |  | 3.8 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 3.8 |  |
| Foreign currency translation |  |  | (0.1 | ) |  |  | - |  |  |  | - |  |  |  | (0.2 | ) |  |  | (0.3 | ) |
| Balance as of June 30, 2018 |  | $ | 253.9 |  |  |  | 34.1 |  |  |  | 73.7 |  |  |  | 19.7 |  |  |  | 381.4 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001144204-18-042749:notes:37]
Management evaluates and measures the performance of its reportable segments based on “Net Sales” and “EBIT”, which are detailed in the table below. EBIT is defined as earnings before interest and taxes.

[0001144204-18-042749:notes:38]
|  |  | Three MonthsEnded June 30, |  |  | Nine MonthsEnded June 30, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| NET SALES |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 69,721 |  |  |  | 71,179 |  |  |  | 195,531 |  |  |  | 198,869 |  |
| Test |  |  | 45,034 |  |  |  | 37,544 |  |  |  | 123,368 |  |  |  | 109,738 |  |
| USG |  |  | 55,489 |  |  |  | 42,059 |  |  |  | 157,942 |  |  |  | 110,287 |  |
| Technical Packaging |  |  | 21,979 |  |  |  | 20,407 |  |  |  | 63,655 |  |  |  | 59,841 |  |
| Consolidated totals |  | $ | 192,223 |  |  |  | 171,189 |  |  |  | 540,496 |  |  |  | 478,735 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 14,292 |  |  |  | 11,945 |  |  |  | 35,056 |  |  |  | 34,296 |  |
| Test |  |  | 5,902 |  |  |  | 4,885 |  |  |  | 13,797 |  |  |  | 11,076 |  |
| USG |  |  | 11,528 |  |  |  | 8,477 |  |  |  | 27,805 |  |  |  | 25,585 |  |
| Technical Packaging |  |  | 2,505 |  |  |  | 2,433 |  |  |  | 5,355 |  |  |  | 5,660 |  |
| Corporate (loss) |  |  | (8,668 | ) |  |  | (9,105 | ) |  |  | (25,848 | ) |  |  | (23,499 | ) |
| Consolidated EBIT |  |  | 25,559 |  |  |  | 18,635 |  |  |  | 56,165 |  |  |  | 53,118 |  |
| Less: Interest expense |  |  | (2,243 | ) |  |  | (1,213 | ) |  |  | (6,464 | ) |  |  | (2,752 | ) |
| Earnings before income taxes |  | $ | 23,316 |  |  |  | 17,422 |  |  |  | 49,701 |  |  |  | 50,366 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001144204-18-042749:notes:39]
|  | 7. | BUSINESS SEGMENT INFORMATION |

[0001144204-18-042749:notes:40]
The Company is organized based on the products and services that it offers, and classifies its business operations in four reportable segments for financial reporting purposes: Filtration/Fluid Flow (Filtration), RF Shielding and Test (Test), Utility Solutions Group (USG) and Technical Packaging. The Filtration segment’s operations consist of PTI Technologies Inc. (PTI), VACCO Industries (VACCO), Crissair, Inc. (Crissair), Westland Technologies Inc. (Westland), Mayday Manufacturing Co. and its affiliate Hi-Tech Metals, Inc. (collectively referred to as Mayday). The companies within this segment primarily design and manufacture specialty filtration products, including hydraulic filter elements used in commercial aerospace applications, unique filter mechanisms used in micro-propulsion devices for satellites and custom designed filters for manned and unmanned aircraft; manufacture elastomeric-based signature reduction solutions for the U.S. Navy; and manufacture landing gear components for the aerospace and defense industry. The Test segment’s operations consist primarily of ETS-Lindgren Inc. (ETS-Lindgren). ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy. The USG segment’s operations consist primarily of Doble Engineering Company (Doble), Morgan Schaffer Inc. (Morgan Schaffer), and NRG Systems, Inc. (NRG). Doble provides high-end, intelligent diagnostic test solutions for the electric power delivery industry and is a leading supplier of partial discharge testing instruments used to assess the integrity of high voltage power delivery equipment. Morgan Schaffer provides an integrated offering of dissolved gas analysis, oil testing, and data management solutions for the electric power industry. NRG designs and manufactures decision support tools for the renewable energy industry, primarily wind. The Technical Packaging segment’s operations consist of Thermoform Engineered Quality LLC (TEQ) and Plastique Limited and Plastique Sp. z o.o. (together, Plastique). The companies within this segment provide innovative solutions to the medical and commercial markets for thermoformed packages and specialty products using a wide variety of thin gauge plastics and pulp.

[0001144204-18-042749:notes:41]
[same as prior period, unchanged from 0001144204-18-026388:notes:29]

[0001144204-18-042749:notes:42]
[same as prior period, unchanged from 0001144204-18-026388:notes:30]

[0001144204-18-042749:notes:43]
[same as prior period, unchanged from 0001144204-18-026388:notes:31]


## us-gaap:DebtDisclosureTextBlock

[0001144204-18-042749:notes:44]
|  | 8. | DEBT |

[0001144204-18-042749:notes:45]
The Company’s existing credit facility (“the Credit Facility”) matures December 21, 2020. The Credit Facility includes a $450 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of nine banks led by JPMorgan Chase Bank, N.A., as Administrative Agent.

[0001144204-18-042749:notes:46]
At June 30, 2018, the Company had approximately $180 million available to borrow under the Credit Facility, and a $250 million increase option 
subject to lender approval
, in addition to $43.3 million cash on hand. At June 30, 2018, the Company had $262 million of outstanding borrowings under the Credit Facility in addition to outstanding letters of credit of $8.3 million. The Company classified $20.0 million as the current portion of long-term debt as of June 30, 2018, as the Company intends to repay this amount within the next twelve month period; however, the Company has no contractual obligation to repay such amount during the next twelve month period.

[0001144204-18-042749:notes:47]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from 12.5 to 27.5 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a 65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 3.17% and 2.97% for the three and nine-month periods ending June 30, 2018, respectively, and 2.11% and 1.90% for the corresponding periods of 2017. At June 30, 2018, the Company was in compliance with all debt covenants.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001144204-18-042749:notes:48]
|  | 9. | INCOME TAX EXPENSE |

[0001144204-18-042749:notes:49]
The third quarter 2018 effective income tax rate was 18.4% compared to 27.4% in the third quarter of 2017. The income tax benefit for the first nine months of 2018 was $14.0 million compared to income tax expense of $15.8 million for the first nine months of 2017. The effective income tax rate for the first nine months of 2018 was (28.1%) compared to 31.4% for the first nine months of 2017. H.R. 1, 
Tax Cuts and Jobs Act
 (“TCJA”), was signed into law on December 22, 2017. The total impact of the TCJA in the third quarter and first nine months of 2018 was a net expense of $0.1 million and a net benefit of $24.3 million, respectively. The impacts were as follows: First, the Company’s 2018 federal statutory rate decreased from 35.0% to 24.5% which required an adjustment to the value of its deferred tax assets and liabilities. This adjustment ($30.3 million provisional amount recorded in the first quarter of 2018 and $0.4 million 
provisional amount 
in the third quarter of 2018) favorably impacted the third quarter and year-to-date effective tax rate by 1.5% and 61.7%, respectively. Second, the TCJA subjected the Company’s cumulative foreign earnings to federal income tax ($4.1 million provisional amount of which $2.9 million was recorded in the first quarter of 2018, $0.7 million was recorded in the second quarter of 2018, and $0.5 million in the third quarter of 2018) which unfavorably impacted the third quarter and year-to-date effective tax rate by 2.1% and 8.2%, respectively.

[0001144204-18-042749:notes:50]
In the first quarter of 2018, the Company recorded a $2.3 million provisional estimate of the income tax effects of the future repatriation of the cumulative earnings of its foreign subsidiaries which unfavorably impacted the year-to-date effective tax rate by 4.7%. An additional $7.5 million pension contribution for the 2017 plan year was approved during the second quarter of 2018 increasing the value of the deferred tax liability by $1.0 million (provisional amount). This favorable adjustment, net of the $0.3 million unfavorable impact to the 2017 Domestic Production Deduction, favorably impacted the year-to-date effective tax rate by 1.6%. An accounting method change was filed with the 2017 tax return which resulted in an additional deferred tax liability to be adjusted as a result of the TCJA. A favorable adjustment, net of the $0.3 million unfavorable impact to the 2017 Domestic Production deduction, favorably impacted the third quarter and year-to-date effective tax rate by 2.9% and 1.4%, respectively. The income tax expense in the third quarter and first nine months of 2018 was favorably impacted by return to provision true-ups decreasing the third quarter and year-to-date effective tax rate by 1.4% and 0.7%, respectively. In 2017, the Company elected to adopt Accounting Standards Update No. 2016-09, 
Improvements to Employee Share-Based Payment Accounting
, resulting in income tax expense in the third quarter and nine months of 2017 being favorably impacted by additional tax benefits on share-based compensation that vested during the quarter decreasing the effective tax rate by 5.2% and 1.8%, respectively. Income tax expense in the third quarter and nine months of 2018 was also favorably impacted by additional tax benefits on share-based compensation that vested during the quarter decreasing the effective tax rate by 1.9% and 0.9%, respectively.

[0001144204-18-042749:notes:51]
[same as prior period, unchanged from 0001144204-18-026388:notes:69]

[0001144204-18-042749:notes:52]
In 
the first and second quarter of 2018, the Company recorded reasonable provisional estimates of the TCJA income tax effects. During the third quarter of 2018, the Company collected and analyzed additional information needed to compute the Company’s deferred tax assets and liabilities. However, these amounts remain provisional as the Company needs more time to collect and analyze information primarily related to the federal impact on the value of state deferred tax assets and liabilities. The income tax effects of subjecting the Company’s cumulative foreign earnings to federal income tax also remains provisional as the Company needs more time to collect and analyze the cumulative balance of earnings subject to the tax and the amount of foreign tax credit that is available to offset the tax.

[0001144204-18-042749:notes:53]
[same as prior period, unchanged from 0001144204-18-026388:notes:71]

[0001144204-18-042749:notes:54]
[same as prior period, unchanged from 0001144204-18-026388:notes:72]


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001144204-18-042749:notes:55]
|  | 10. | SHAREHOLDERS’ EQUITY |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001144204-18-042749:notes:56]
|  | 11. | RETIREMENT PLANS |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001144204-18-042749:notes:57]
|  | 12. | DERIVATIVE FINANCIAL INSTRUMENTS |

[0001144204-18-042749:notes:58]
[same as prior period, unchanged from 0001144204-18-026388:notes:65]


## us-gaap:FairValueDisclosuresTextBlock

[0001144204-18-042749:notes:59]
|  | 13. | FAIR VALUE MEASUREMENTS |

[0001144204-18-042749:notes:60]
[same as prior period, unchanged from 0001144204-18-026388:notes:49]

[0001144204-18-042749:notes:61]
[same as prior period, unchanged from 0001144204-18-026388:notes:50]

[0001144204-18-042749:notes:62]
[same as prior period, unchanged from 0001144204-18-026388:notes:51]

[0001144204-18-042749:notes:63]
The Company has estimated the fair value of its financial instruments as of June 30, 2018 and September 30, 2017 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, debt and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001144204-18-042749:notes:64]
[same as prior period, unchanged from 0001144204-18-026388:notes:53]

[0001144204-18-042749:notes:65]
[same as prior period, unchanged from 0001144204-18-026388:notes:56]

[0001144204-18-042749:notes:66]
[same as prior period, unchanged from 0001144204-18-026388:notes:57]

[0001144204-18-042749:notes:67]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during the three and nine-month periods ended June 30, 2018.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001144204-18-042749:notes:68]
|  | 14. | NEW ACCOUNTING STANDARDS |

[0001144204-18-042749:notes:69]
In March 2017, the FASB issued ASU 2017-07, 
Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost,
 which updates ASC 715, 
Compensation – Retirement Benefits
. This update permits only the service cost component of net periodic pension and postretirement expense to be reported with other compensation costs, while all other components are required to be reported separately in other deductions, outside any subtotal of operating income. These updates are effective for fiscal years beginning after December 15, 2017, with early adoption permitted, and must be adopted on a retrospective basis. The updates change presentation only and will not impact the Company’s results of operations.

[0001144204-18-042749:notes:70]
In August 2017, the FASB issued ASU 2017-12, 
Targeted Improvements to Accounting for Hedge Activities,
 which updates ASC 815, 
Derivatives and Hedging
. This update is intended to amend the hedge accounting model to enable entities to better align the economics of risk management activities and financial reporting. The updates eliminate the requirement to separately measure and report hedge ineffectiveness and simplify hedge documentation and effectiveness assessment requirements. These updates are effective for fiscal years beginning after December 15, 2018, with early adoption permitted, and must be adopted using a modified retrospective approach. These updates are not expected to materially impact the Company’s results of operations.

[0001144204-18-042749:notes:71]
In February 2016, the FASB issued ASU No. 2016-062, 
Leases (Topic 842)
, which, among other things, requires an entity to recognize lease assets and lease liabilities on the balance sheet and disclose key information about leasing arrangements. This standard will increase an entities’ reported assets and liabilities. The standard is effective for fiscal years beginning after December 15, 2018 and mandates a modified retrospective transition period for all entities. The Company is currently assessing the impact of this standard on its consolidated financial statements and related disclosures.

[0001144204-18-042749:notes:72]
In May 2014, the FASB issued ASU No. 2014-09, 
Revenue from Contracts with Customers
, (ASU 2014-09) which requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. This guidance has been further clarified and amended. The new standard will be effective for annual reporting periods beginning after December 15, 2017, and interim periods within those annual periods. The standard permits the use of either the retrospective or cumulative effect transition method. 
The Company has selected the cumulative effect method of transition to the new standard. Because the new standard impacts the Company’s business processes, systems and controls, we developed a project plan to guide the implementation. This project plan included analyzing the standard’s impact on our contract portfolio, comparing our historical accounting policies and practices to the requirements of the new standard, and identifying differences from applying the requirements of the new standard to our contracts. We developed internal controls to ensure that we adequately evaluated our portfolio of contracts under the five-step model to ensure proper assessment of our operating results under ASU 2014-09. We reported on the progress of the implementation to the Audit Committee and the Board of Directors on a regular basis during the project’s duration. The adoption of ASU 2014-09 will have one primary impact on our portfolio of contracts and our Consolidated Financial Statements which is that more of our contracts within our Filtration and Technical Packaging segments will recognize revenue and earnings over time as the work progresses versus at a single point of time. This standard will not change the total revenue or operating earnings recognized, only the timing of when those amounts are recognized. The Company is currently in the process of finalizing 
the effect that ASU 2014-09 will have on its consolidated financial statements and related disclosures.
