# ESE note change history — 0001144204-18-026388 → 0001144204-18-042749


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-08-08):
[0001144204-18-042749:note_history:1]
|  | 1. | BASIS OF PRESENTATION |
  (was, 2018-05-09, similarity 0.9667):
[0001144204-18-026388:note_history:1]
| 1. | BASIS OF PRESENTATION |

- changed (2018-08-08):
[0001144204-18-042749:note_history:2]
The Company’s results for the three and nine-month periods ended June 30, 2018 are not necessarily indicative of the results for the entire 2018 fiscal year. References to the third quarters of 2018 and 2017 represent the fiscal quarters ended June 30, 2018 and 2017, respectively.
  (was, 2018-05-09, similarity 0.9344):
[0001144204-18-026388:note_history:2]
The Company’s results for the three and six-month periods ended March 31, 2018 are not necessarily indicative of the results for the entire 2018 fiscal year. References to the second quarters of 2018 and 2017 represent the fiscal quarters ended March 31, 2018 and 2017, respectively.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-08-08):
[0001144204-18-042749:note_history:3]
|  | 8. | DEBT |
  (was, 2018-05-09, similarity 0.9231):
[0001144204-18-026388:note_history:3]
| 8. | DEBT |

- changed (2018-08-08):
[0001144204-18-042749:note_history:4]
| (In thousands) |  | June 30,2018 |  |  | September 30, 2017 |  |
| Total borrowings |  | $ | 262,000 |  |  |  | 275,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000 | ) |  |  | (20,000 | ) |
| Total long-term debt, less current portion |  | $ | 242,000 |  |  |  | 255,000 |  |
  (was, 2018-05-09, similarity 0.9218):
[0001144204-18-026388:note_history:4]
| (In thousands) |  | March 31, 2018 |  | September 30, 2017 |  |
| Total borrowings |  | $ | 265,000 |  |  | 275,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 245,000 |  |  | 255,000 |  |

- changed (2018-08-08):
[0001144204-18-042749:note_history:5]
At June 30, 2018, the Company had approximately $180 million available to borrow under the Credit Facility, and a $250 million increase option 
subject to lender approval
, in addition to $43.3 million cash on hand. At June 30, 2018, the Company had $262 million of outstanding borrowings under the Credit Facility in addition to outstanding letters of credit of $8.3 million. The Company classified $20.0 million as the current portion of long-term debt as of June 30, 2018, as the Company intends to repay this amount within the next twelve month period; however, the Company has no contractual obligation to repay such amount during the next twelve month period.
  (was, 2018-05-09, similarity 0.9556):
[0001144204-18-026388:note_history:5]
At March 31, 2018, the Company had approximately $176 million available to borrow under the Credit Facility, and a $250 million increase option, in addition to $42.9 million cash on hand. At March 31, 2018, the Company had $265 million of outstanding borrowings under the Credit Facility in addition to outstanding letters of credit of $9.1 million. The Company classified $20.0 million as the current portion of long-term debt as of March 31, 2018, as the Company intends to repay this amount within the next twelve month period; however, the Company has no contractual obligation to repay such amount during the next twelve month period.

- changed (2018-08-08):
[0001144204-18-042749:note_history:6]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from 12.5 to 27.5 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a 65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 3.17% and 2.97% for the three and nine-month periods ending June 30, 2018, respectively, and 2.11% and 1.90% for the corresponding periods of 2017. At June 30, 2018, the Company was in compliance with all debt covenants.
  (was, 2018-05-09, similarity 0.9853):
[0001144204-18-026388:note_history:6]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from  12.5 to  27.5 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a  65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were  2.99% and  2.87% for the three and six-month periods ending March 31, 2018, respectively, and  1.89% and  1.76% for the corresponding periods of 2017. At March 31, 2018, the Company was in compliance with all debt covenants.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-08-08):
[0001144204-18-042749:note_history:7]
| (In thousands) |  | June 30,2018 |  |  | September 30, 2017 |  |
| Total borrowings |  | $ | 262,000 |  |  |  | 275,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000 | ) |  |  | (20,000 | ) |
| Total long-term debt, less current portion |  | $ | 242,000 |  |  |  | 255,000 |  |
  (was, 2018-05-09, similarity 0.9218):
[0001144204-18-026388:note_history:7]
| (In thousands) |  | March 31, 2018 |  | September 30, 2017 |  |
| Total borrowings |  | $ | 265,000 |  |  | 275,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 245,000 |  |  | 255,000 |  |
