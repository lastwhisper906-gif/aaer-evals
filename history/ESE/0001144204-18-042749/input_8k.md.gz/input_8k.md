# ESE 8-K — 0000866706-18-000006 filed 2018-08-07

## item codes, every 8-K on or before 2018-08-08

- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2018-08-08

- none on or before 2018-08-08

## item 2.02 — earnings release, exhibit 99.1

[0000866706-18-000006:8k_2_02:1]
EX-99.1
2
escoearningsrelease.htm
ESCO PRESS RELEASE

[0000866706-18-000006:8k_2_02:2]
Exhibit 99.1

[0000866706-18-000006:8k_2_02:3]
NEWS FROM

[0000866706-18-000006:8k_2_02:4]
For more information contact:

[0000866706-18-000006:8k_2_02:5]
Kate Lowrey

[0000866706-18-000006:8k_2_02:6]
Director, Investor Relations

[0000866706-18-000006:8k_2_02:7]
ESCO Technologies Inc.

[0000866706-18-000006:8k_2_02:8]
(314) 213-7277

[0000866706-18-000006:8k_2_02:9]
ESCO ANNOUNCES THIRD QUARTER FISCAL 2018 RESULTS

[0000866706-18-000006:8k_2_02:10]
- Q3 EPS $0.73 at Top of Guidance Range and Beats Consensus -

[0000866706-18-000006:8k_2_02:11]
- EPS Reflects 49 Percent (GAAP) and 43 Percent (Adjusted) Increase -

[0000866706-18-000006:8k_2_02:12]
ST. LOUIS, August 7, 2018 – ESCO Technologies Inc. (NYSE: ESE) (ESCO, or the Company) today reported its operating results for the third quarter (Q3 2018) and nine months year-to-date (YTD 2018) periods ended June 30, 2018.

[0000866706-18-000006:8k_2_02:13]
The financial results presented include certain non-GAAP financial measures such as EBIT, EBITDA (defined as earnings before interest, taxes, depreciation and amortization), Adjusted EBITDA (defined as EBITDA excluding certain defined charges) and Adjusted EPS. Any non-GAAP financial measures presented are reconciled to their respective GAAP equivalents.

[0000866706-18-000006:8k_2_02:14]
Management believes these non-GAAP financial measures are useful in assessing the ongoing operational profitability of the Company's business segments, and therefore, allow shareholders better visibility into the Company's underlying operations. See "Non-GAAP Financial Measures" described below.

[0000866706-18-000006:8k_2_02:15]
Earnings Summary

[0000866706-18-000006:8k_2_02:16]
Q3 2018 EPS (GAAP and Adjusted) was $0.73 per share, which, at the top of Management's previous guidance of $0.68 to $0.73 per share, represents a 49 percent (GAAP) and 43 percent (Adjusted) increase over Q3 2017 GAAP and Adjusted EPS, respectively.

[0000866706-18-000006:8k_2_02:17]
Q3 2017 GAAP EPS was $0.49 per share and Adjusted EPS was $0.51 per share, which excluded the $0.02 per share net impact from the NRG and Morgan Schaffer acquisitions completed in May 2017.

[0000866706-18-000006:8k_2_02:18]
EBITDA was $35.1 million in Q3 2018, reflecting a 27 percent increase over Q3 2017 Adjusted EBITDA of $27.7 million.

[0000866706-18-000006:8k_2_02:19]
Operating Highlights

[0000866706-18-000006:8k_2_02:20]
| · | Q3 2018 sales increased $21 million (12 percent) to $192 million compared to $171 million in Q3 2017; |

[0000866706-18-000006:8k_2_02:21]
| · | On a segment basis, Q3 2018 Filtration sales exceeded expectations by 3 percent, but decreased nominally from Q3 2017. Compared to Q3 2017, commercial aerospace sales increased significantly, offset by lower industrial/automotive sales at PTI as previously communicated, and decreased space sales at VACCO due to the quarterly timing of large project deliveries. Test sales increased 20 percent driven by its strong backlog conversion to sales, and Technical Packaging sales increased 8 percent, primarily in Europe. USG sales increased $13 million, or 32 percent, driven by the recent acquisitions; |

[0000866706-18-000006:8k_2_02:22]
| · | SG&A expenses increased $1 million in Q3 2018 primarily due to the inclusion of the 2017 acquisitions in the current period, partially offset by successful cost reduction actions across the Company; |

[0000866706-18-000006:8k_2_02:23]
| · | Amortization of intangible assets increased $1 million due to the 2017 acquisitions; |

[0000866706-18-000006:8k_2_02:24]
| · | Entered orders were $201 million in Q3 2018 (book-to-bill of 1.05x) reflecting a $14 million (8 percent) sequential increase over Q2 2018 orders of $187 million, which resulted in an ending backlog of $426 million at June 30, 2018; |

[0000866706-18-000006:8k_2_02:25]
| · | Filtration orders were $86 million with a book-to-bill of 1.23x comprised of significantly higher commercial aerospace orders and additional navy products; |

[0000866706-18-000006:8k_2_02:26]
| · | Test orders were $38 million with a book-to-bill of 0.84x which reflects the increased sales conversion from backlog; |

[0000866706-18-000006:8k_2_02:27]
| · | USG orders were $58 million with a book-to-bill of 1.04x resulting from increased orders for new products and solutions across the segment; |

[0000866706-18-000006:8k_2_02:28]
| · | Technical Packaging orders were $19 million with a book-to-bill of 0.89x due primarily to the timing of large project orders and the resulting sales conversion from existing backlog; |

[0000866706-18-000006:8k_2_02:29]
| · | The Q3 2018 income tax rate was 18.4 percent compared to the Q3 2017 income tax rate of 27.4 percent; |

[0000866706-18-000006:8k_2_02:30]
| · | YTD 2018 net cash provided by operating activities was $54 million ($63 million excluding pension funding contributions intended to reduce the operating costs of the previously frozen plan) resulting in $219 million of net debt (outstanding borrowings less cash on hand) at June 30, 2018 and a 2.0x leverage ratio. Management is planning to repatriate a substantial portion of its foreign cash (currently $32 million) to pay down its outstanding debt and for other corporate purposes. |

[0000866706-18-000006:8k_2_02:31]
Chairman's Commentary – Q3 2018

[0000866706-18-000006:8k_2_02:32]
Vic Richey, Chairman and Chief Executive Officer, commented, "I am pleased with our results for the first nine months of the year. We started the year on a positive note as our Q1 operating results were at the high end of our range, the momentum continued in Q2 as we beat our Adjusted EPS expectations by $0.05 per share, and we wrapped up Q3 at the top of our guidance range by delivering $0.73 per share.

[0000866706-18-000006:8k_2_02:33]
"We remain ahead of Plan on cash flow and entered orders at June 30th, and have grown our backlog by $48 million or 13 percent from the start of the year. This provides confidence that we expect to meet our 2018 expectations by achieving our Q4 growth projections, which are meaningfully higher than our first three quarters as we communicated throughout the year. Our original plan anticipated a very large Q4 and given the strength of our orders, backlog, and performance year-to-date, we remain committed to our goals.

[0000866706-18-000006:8k_2_02:34]
"USG's recent acquisitions continue to be a bright spot in 2018 as each has made a meaningful contribution to our YTD performance. The integration has gone better than anticipated and we continue to see additional sales opportunities from rationalizing our distribution channels and maximizing our sales efficiency.

[0000866706-18-000006:8k_2_02:35]
"Q3 sales increased significantly in USG driven by the contributions from our recent acquisitions. Despite the inherently lower margins of the companies we added last year compared to Doble's historical margins, our Q3 2018 EBIT margin increased to nearly 21 percent, up from 20 percent in prior year Q3.

[0000866706-18-000006:8k_2_02:36]
"The clear highlight of Q3 was the performance of our Filtration group where we increased EBIT by $2.3 million on lower sales which resulted in an EBIT margin of 20.5 percent compared to 16.8 percent in Q3 2017 with every operating unit increasing its margin year-over-year.

[0000866706-18-000006:8k_2_02:37]
"The Test business sales increased significantly in Q3 2018 and its EBIT margin was 13.1 percent, exceeding our previous margin expectations.

[0000866706-18-000006:8k_2_02:38]
"Our Packaging business remains on track to meet its commitments and we continue to see opportunities to enhance its operating margins.

[0000866706-18-000006:8k_2_02:39]
"Our strong YTD 2018 cash flow and our cash expectations for the balance of the year enable us to pay down debt while continuing our M&A activities without creating an unfavorable leverage situation. We will continue to balance our acquisition activities with our debt levels and leverage ratios as we are committed to maintaining a prudent balance sheet.

[0000866706-18-000006:8k_2_02:40]
"Consistent with our history, we will continue to focus on cost reduction and margin enhancement opportunities across the company, and will maintain our unrelenting diligence in identifying improved operating efficiencies across all our platforms globally.

[0000866706-18-000006:8k_2_02:41]
"Our market positions and continued growth opportunities across the Company provide me with a favorable view of the future with our goal remaining unchanged – to increase long-term shareholder value."

[0000866706-18-000006:8k_2_02:42]
Dividend Payment

[0000866706-18-000006:8k_2_02:43]
The next quarterly cash dividend of $0.08 per share will be paid on October 17, 2018 to stockholders of record on October 3, 2018.

[0000866706-18-000006:8k_2_02:44]
Business Outlook – 2018

[0000866706-18-000006:8k_2_02:45]
Management continues to see meaningful sales and Adjusted EBITDA growth across each of the Company's business segments and anticipates solid growth over the remainder of 2018.

[0000866706-18-000006:8k_2_02:46]
Management's current expectations for 2018 remain consistent with the details outlined in the Business Outlook presented in previous releases. To recap, Management expects 2018 GAAP EPS in the range of $3.55 to $3.65 per share, and Adjusted EPS in the range of $2.65 to $2.75 per share, adjusting for the incremental net tax benefits resulting from U.S. Tax Reform and the cost reduction charges described previously.

[0000866706-18-000006:8k_2_02:47]
Management's focus on profitable growth, cash flow, and ROIC will remain steadfast in accordance with the belief that these are the key drivers of sustainable share price appreciation.

[0000866706-18-000006:8k_2_02:48]
Conference Call

[0000866706-18-000006:8k_2_02:49]
The Company will host a conference call today, August 7, at 4:00 p.m. Central Time, to discuss the Company's Q3 2018 results. A live audio webcast will be available on the Company's website at www.escotechnologies.com. Please access the website at least 15 minutes prior to the call to register, download and install any necessary audio software. A replay of the conference call will be available for seven days on the Company's website noted above or by phone (dial 1-855-859-2056 and enter the pass code 3190618).

[0000866706-18-000006:8k_2_02:50]
Forward-Looking Statements

[0000866706-18-000006:8k_2_02:51]
Statements in this press release regarding the Company's expected quarterly, 2018 full year and beyond results, revenue and sales growth, EPS, Adjusted EPS, EPS growth, cash, EBIT, EBITDA, Adjusted EBITDA, corporate costs, income tax expense, effective tax rates, cash generation, repatriation of foreign cash and the uses of such cash, margin expansion and savings resulting from cost reduction actions, the Company's ability to increase operating margins, realize financial goals and increase shareholder value, the success of acquisition efforts, the size, number and timing of future sales and growth opportunities, the long-term success of the Company, and any other statements which are not strictly historical are "forward-looking" statements within the meaning of the safe harbor provisions of the federal securities laws.

[0000866706-18-000006:8k_2_02:52]
Investors are cautioned that such statements are only predictions and speak only as of the date of this release, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company's actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company's operations and business environment including, but not limited to those described in Item 1A, "Risk Factors", of the Company's Annual Report on Form 10-K for the fiscal year ended September 30, 2017, and the following: the success of the Company's competitors; weakening of economic conditions in served markets; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties; delivery delays or defaults by customers; material changes in the costs and availability of certain raw materials; the appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer contracts; the timing and content of future contract awards or customer orders; performance issues with key customers, suppliers and subcontractors; labor disputes; the impacts of natural disasters on the Company's operations and those of the Company's customers and suppliers; changes in laws and regulations, including but not limited to changes in accounting standards and taxation requirements; legal and foreign tax requirements impacting the repatriation of cash in foreign locations; changes in interest rates; costs relating to environmental matters arising from current or former facilities; financial exposure in connection with Company guarantees of certain Aclara contracts; the availability of select acquisitions; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the success and integration of recently acquired businesses.

[0000866706-18-000006:8k_2_02:53]
Non-GAAP Financial Measures

[0000866706-18-000006:8k_2_02:54]
The financial measures EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS are presented in this press release. The Company defines "EBIT" as earnings before interest and taxes, "EBITDA" as earnings before interest, taxes, depreciation and amortization, "Adjusted EBITDA" as EBITDA excluding certain defined charges, and "Adjusted EPS" as GAAP earnings per share (EPS) excluding the net impact of the items described above which were $0.90 per share YTD 2018.

[0000866706-18-000006:8k_2_02:55]
EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management believes that EBIT, EBITDA and Adjusted EBITDA are useful in assessing the operational profitability of the Company's business segments because they exclude interest, taxes, depreciation and amortization, which are generally accounted for across the entire Company on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company as well as incentive compensation. The Company believes that the presentation of EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS provides important supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance determined in accordance with GAAP.

[0000866706-18-000006:8k_2_02:56]
ESCO, headquartered in St. Louis: Manufactures highly-engineered filtration and fluid control products for the aviation, space and process markets worldwide; is the industry leader in RF shielding and EMC test products; provides diagnostic instruments, software and services for the benefit of industrial power users and the electric utility and renewable energy industries; and, produces custom thermoformed packaging, pulp-based packaging, and specialty products for medical and commercial markets. Further information regarding ESCO and its subsidiaries is available on the Company's website at www.escotechnologies.com.

[0000866706-18-000006:8k_2_02:57]
-tables attached-

[0000866706-18-000006:8k_2_02:58]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |  |
| Condensed Consolidated Statements of Operations (Unaudited) |  |  |
| (Dollars in thousands, except per share amounts) |  |  |
|  |  | Three Months Ended June 30, 2018 |  |  | Three Months Ended June 30, 2017 |  |  |
| Net Sales |  | $ | 192,223 |  |  |  | 171,189 |  |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 122,805 |  |  |  | 108,856 |  |  |
| Selling, general and administrative expenses |  |  | 39,910 |  |  |  | 38,453 |  |  |
| Amortization of intangible assets |  |  | 4,605 |  |  |  | 4,085 |  |  |
| Interest expense |  |  | 2,243 |  |  |  | 1,213 |  |  |
| Other (income) expenses, net |  |  | (656 | ) |  |  | 1,160 |  |  |
| Total costs and expenses |  |  | 168,907 |  |  |  | 153,767 |  |  |
| Earnings before income taxes |  |  | 23,316 |  |  |  | 17,422 |  |  |
| Income taxes |  |  | 4,297 |  |  |  | 4,777 |  |  |
| Net earnings |  | $ | 19,019 |  |  |  | 12,645 |  |  |
| Diluted EPS - GAAP |  | $ | 0.73 |  |  |  | 0.49 |  |  |
| Diluted EPS - As Adjusted |  | $ | 0.73 |  |  |  | 0.51 | (1) |  |
| Diluted average common shares O/S: |  |  | 26,050 |  |  |  | 26,025 |  |  |

[0000866706-18-000006:8k_2_02:59]
| (1) | Excludes $0.5 million (or $0.02 per share) net impact from the acquisitions of NRG and Morgan Schaffer during the third quarter of 2017. |  |

[0000866706-18-000006:8k_2_02:60]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |  |  |  |
| Condensed Consolidated Statements of Operations (Unaudited) |  |  |  |  |
| (Dollars in thousands, except per share amounts) |  |  |  |  |
|  |  | Nine Months Ended June 30, 2018 |  |  |  |  |  | Nine Months Ended June 30, 2017 |  |  |  |  |
| Net Sales |  | $ | 540,496 |  |  |  |  |  |  | 478,735 |  |  |  |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 346,911 |  |  |  |  |  |  | 307,149 |  |  |  |  |
| Selling, general and administrative expenses |  |  | 122,813 |  |  |  |  |  |  | 107,104 |  |  |  |  |
| Amortization of intangible assets |  |  | 13,615 |  |  |  |  |  |  | 11,548 |  |  |  |  |
| Interest expense |  |  | 6,464 |  |  |  |  |  |  | 2,752 |  |  |  |  |
| Other (income) expenses, net |  |  | 992 |  |  |  |  |  |  | (184 | ) |  |  |  |  |
| Total costs and expenses |  |  | 490,795 |  |  |  |  |  |  | 428,369 |  |  |  |  |  |
| Earnings before income taxes |  |  | 49,701 |  |  |  |  |  |  | 50,366 |  |  |  |  |  |
| Income taxes |  |  | (13,983 | ) |  |  |  |  |  |  | 15,837 |  |  |  |  |  |
| Net earnings |  | $ | 63,684 |  |  |  |  |  |  |  | 34,529 |  |  |  |  |  |
| Diluted EPS - GAAP |  | $ | 2.45 |  |  |  |  |  |  |  | 1.33 |  |  |  |  |  |
| Diluted EPS - As Adjusted |  | $ | 1.55 |  | (1) |  |  |  |  |  | 1.41 |  | (2) |  |  |  |
| Diluted average common shares O/S: |  |  | 26,042 |  |  |  |  |  |  |  | 25,975 |  |  |  |  |  |

[0000866706-18-000006:8k_2_02:61]
| (1) | Excludes $2.7 million net impact of restructuring charges incurred at Doble & PTI during the first nine months of 2018 and the $25 million tax benefit recorded related to U.S. Tax Reform. |  |
| (2) | Excludes $2.0 million (or $0.08 per share) net impact from the acquisitions of Mayday, NRG and Morgan Schaffer during the first nine months of 2017. |  |

[0000866706-18-000006:8k_2_02:62]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Condensed Business Segment Information (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  | GAAP |  |
|  |  |  | Q3 2018 |  |  |  | Q3 2017 |  |
| Net Sales |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 69,721 |  |  |  | 71,179 |  |
| Test |  |  | 45,034 |  |  |  | 37,544 |  |
| USG |  |  | 55,489 |  |  |  | 42,059 |  |
| Technical Packaging |  |  | 21,979 |  |  |  | 20,407 |  |
| Totals |  | $ | 192,223 |  |  |  | 171,189 |  |
| EBIT |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 14,292 |  |  |  | 11,945 |  |
| Test |  |  | 5,902 |  |  |  | 4,885 |  |
| USG |  |  | 11,528 |  |  |  | 8,477 |  |
| Technical Packaging |  |  | 2,505 |  |  |  | 2,433 |  |
| Corporate |  |  | (8,668 | ) |  |  | (9,105 | ) |
| Consolidated EBIT |  |  | 25,559 |  |  |  | 18,635 |  |
| Less: Interest expense |  |  | (2,243 | ) |  |  | (1,213 | ) |
| Less: Income tax expense |  |  | (4,297 | ) |  |  | (4,777 | ) |
| Net earnings |  | $ | 19,019 |  |  |  | 12,645 |  |

[0000866706-18-000006:8k_2_02:63]
| Note 1: Adjusted net earnings were $13.1 million in Q3 '17 which excluded $0.5 million (or $0.02 per share) net impact from the acquisitions of NRG and Morgan Schaffer during the third quarter of 2017. |  |

[0000866706-18-000006:8k_2_02:64]
|  |  | EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  | Adjusted |  |
|  |  |  | Q3 2018 |  |  |  | Q3 2017 |  |  |  | Q3 2017 |  |
| Consolidated EBITDA |  | $ | 35,111 |  |  |  | 26,970 |  |  |  | 27,724 |  |
| Less: Depr & Amort |  |  | (9,552 | ) |  |  | (8,335 | ) |  |  | (8,335 | ) |
| Consolidated EBIT |  |  | 25,559 |  |  |  | 18,635 |  |  |  | 19,389 |  |
| Less: Interest expense |  |  | (2,243 | ) |  |  | (1,213 | ) |  |  | (1,213 | ) |
| Less: Income tax expense |  |  | (4,297 | ) |  |  | (4,777 | ) |  |  | (5,041 | ) |
| Net earnings |  | $ | 19,019 |  |  |  | 12,645 |  |  |  | 13,135 |  |

[0000866706-18-000006:8k_2_02:65]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Condensed Business Segment Information (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | YTD Q3 2018 |  |  | YTD Q3 2017 |  |  | YTD Q3 2018 |  |  | YTD Q3 2017 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 195,531 |  |  |  | 198,869 |  |  |  | 195,531 |  |  |  | 198,869 |  |
| Test |  |  | 123,368 |  |  |  | 109,738 |  |  |  | 123,368 |  |  |  | 109,738 |  |
| USG |  |  | 157,942 |  |  |  | 110,287 |  |  |  | 157,942 |  |  |  | 110,287 |  |
| Technical Packaging |  |  | 63,655 |  |  |  | 59,841 |  |  |  | 63,655 |  |  |  | 59,841 |  |
| Totals |  | $ | 540,496 |  |  |  | 478,735 |  |  |  | 540,496 |  |  |  | 478,735 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 35,056 |  |  |  | 34,296 |  |  |  | 35,504 |  |  |  | 34,296 |  |
| Test |  |  | 13,797 |  |  |  | 11,076 |  |  |  | 13,797 |  |  |  | 11,076 |  |
| USG |  |  | 27,805 |  |  |  | 25,585 |  |  |  | 30,074 |  |  |  | 28,625 |  |
| Technical Packaging |  |  | 5,355 |  |  |  | 5,660 |  |  |  | 5,355 |  |  |  | 5,660 |  |
| Corporate |  |  | (25,848 | ) |  |  | (23,499 | ) |  |  | (25,977 | ) |  |  | (23,499 | ) |
| Consolidated EBIT |  |  | 56,165 |  |  |  | 53,118 |  |  |  | 58,753 |  |  |  | 56,158 |  |
| Less: Interest expense |  |  | (6,464 | ) |  |  | (2,752 | ) |  |  | (6,464 | ) |  |  | (2,752 | ) |
| Plus (Less): Income tax |  |  | 13,983 |  |  |  | (15,837 | ) |  |  | (11,002 | ) |  |  | (16,901 | ) |
| Net earnings |  | $ | 63,684 |  |  |  | 34,529 |  |  |  | 41,287 |  |  |  | 36,505 |  |

[0000866706-18-000006:8k_2_02:66]
| Note 1: Adjusted net earnings were $41.3 million in YTD Q3'18 which excluded $2.7 million (or $0.10 per share) net impact of the restructuring charges incurred at Doble and PTI during the first nine months of 2018, and the $25 million (or $1.00 per share) tax benefit recorded related to U.S. Tax Reform. |  |
| Note 2: Adjusted net earnings were $36.5 million in YTD Q3'17 which excluded $2.0 million (or $0.08 per share) net impact from the acquisitions of Mayday, NRG and Morgan Schaffer during the first nine months of 2017. |  |

[0000866706-18-000006:8k_2_02:67]
|  | EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  | Adjusted |  | Adjusted |  |
|  | YTD Q3 2018 |  | YTD Q3 2017 |  | YTD Q3 2018 |  | YTD Q3 2017 |  |
| Consolidated EBITDA |  | $ | 84,515 |  |  |  | 76,141 |  |  |  | 87,103 |  |  |  | 79,181 |  |
| Less: Depr & Amort |  |  | (28,350 | ) |  |  | (23,023 | ) |  |  | (28,350 | ) |  |  | (23,023 | ) |
| Consolidated EBIT |  |  | 56,165 |  |  |  | 53,118 |  |  |  | 58,753 |  |  |  | 56,158 |  |
| Less: Interest expense |  |  | (6,464 | ) |  |  | (2,752 | ) |  |  | (6,464 | ) |  |  | (2,752 | ) |
| Plus (Less): Income tax |  |  | 13,983 |  |  |  | (15,837 | ) |  |  | (11,002 | ) |  |  | (16,901 | ) |
| Net earnings |  | $ | 63,684 |  |  |  | 34,529 |  |  |  | 41,287 |  |  |  | 36,505 |  |

[0000866706-18-000006:8k_2_02:68]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Condensed Consolidated Balance Sheets (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  | June 30, 2018 |  |  | September 30, 2017 |  |
| Assets |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 43,259 |  |  |  | 45,516 |  |
| Accounts receivable, net |  |  | 164,100 |  |  |  | 160,580 |  |
| Costs and estimated earnings on |  |  |  |  |  |  |  |  |
| long-term contracts |  |  | 39,180 |  |  |  | 47,286 |  |
| Inventories |  |  | 145,596 |  |  |  | 124,515 |  |
| Other current assets |  |  | 17,861 |  |  |  | 14,895 |  |
| Total current assets |  |  | 409,996 |  |  |  | 392,792 |  |
| Property, plant and equipment, net |  |  | 134,704 |  |  |  | 132,748 |  |
| Intangible assets, net |  |  | 345,874 |  |  |  | 351,134 |  |
| Goodwill |  |  | 381,420 |  |  |  | 377,879 |  |
| Other assets |  |  | 6,977 |  |  |  | 5,891 |  |
|  |  | $ | 1,278,971 |  |  |  | 1,260,444 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Short-term borrowings and current |  | $ | 20,000 |  |  |  | 20,000 |  |
| maturities of long-term debt |  |  |  |  |  |  |  |  |
| Accounts payable |  |  | 49,830 |  |  |  | 54,789 |  |
| Current portion of deferred revenue |  |  | 37,082 |  |  |  | 28,583 |  |
| Other current liabilities |  |  | 93,110 |  |  |  | 91,597 |  |
| Total current liabilities |  |  | 200,022 |  |  |  | 194,969 |  |
| Deferred tax liabilities |  |  | 63,292 |  |  |  | 86,378 |  |
| Other liabilities |  |  | 46,403 |  |  |  | 52,179 |  |
| Long-term debt |  |  | 242,000 |  |  |  | 255,000 |  |
| Shareholders' equity |  |  | 727,254 |  |  |  | 671,918 |  |
|  |  | $ | 1,278,971 |  |  |  | 1,260,444 |  |

[0000866706-18-000006:8k_2_02:69]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Consolidated Statements of Cash Flows (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  | Nine Months Ended June 30, 2018 |  |
| Cash flows from operating activities: |  |  |  |
| Net earnings |  | $ | 63,684 |  |
| Adjustments to reconcile net earnings |  |  |  |  |
| to net cash provided by operating activities: |  |  |  |  |
| Depreciation and amortization |  |  | 28,350 |  |
| Stock compensation expense |  |  | 3,864 |  |
| Changes in assets and liabilities |  |  | (18,239 | ) |
| Effect of deferred taxes |  |  | (23,086 | ) |
| Change in deferred revenue and costs, net |  |  | 8,785 |  |
| Pension contributions |  |  | (9,414 | ) |
| Net cash provided by operating activities |  |  | 53,944 |  |
| Cash flows from investing activities: |  |  |  |  |
| Acquisition of businesses, net of cash acquired |  |  | (11,445 | ) |
| Capital expenditures |  |  | (15,539 | ) |
| Additions to capitalized software |  |  | (7,118 | ) |
| Net cash used by investing activities |  |  | (34,102 | ) |
| Cash flows from financing activities: |  |  |  |  |
| Proceeds from long-term debt |  |  | 53,000 |  |
| Principal payments on long-term debt |  |  | (66,000 | ) |
| Dividends paid |  |  | (6,205 | ) |
| Other |  |  | (2,886 | ) |
| Net cash used by financing activities |  |  | (22,091 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (8 | ) |
| Net decrease in cash and cash equivalents |  |  | (2,257 | ) |
| Cash and cash equivalents, beginning of period |  |  | 45,516 |  |
| Cash and cash equivalents, end of period |  | $ | 43,259 |  |

[0000866706-18-000006:8k_2_02:70]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Other Selected Financial Data (Unaudited) |  |
| (Dollars in thousands) |  |
| Backlog And Entered Orders - Q3 FY 2018 | Filtration |  |  | Test |  |  | USG |  |  | Technical Packaging |  |  | Total |  |
| Beginning Backlog - 4/1/18 |  | $ | 210,541 |  |  |  | 142,795 |  |  |  | 43,277 |  |  |  | 20,062 |  |  |  | 416,675 |  |
| Entered Orders |  |  | 85,911 |  |  |  | 37,865 |  |  |  | 57,828 |  |  |  | 19,462 |  |  |  | 201,066 |  |
| Sales |  |  | (69,721 | ) |  |  | (45,034 | ) |  |  | (55,489 | ) |  |  | (21,979 | ) |  |  | (192,223 | ) |
| Ending Backlog - 6/30/18 |  | $ | 226,731 |  |  |  | 135,626 |  |  |  | 45,616 |  |  |  | 17,545 |  |  |  | 425,518 |  |
| Backlog And Entered Orders - YTD Q3 FY 2018 | Filtration |  |  | Test |  |  | USG |  |  | Technical Packaging |  |  | Total |  |
| Beginning Backlog - 10/1/17 |  | $ | 203,120 |  |  |  | 114,792 |  |  |  | 35,581 |  |  |  | 23,614 |  |  |  | 377,107 |  |
| Entered Orders |  |  | 219,142 |  |  |  | 144,202 |  |  |  | 167,977 |  |  |  | 57,586 |  |  |  | 588,907 |  |
| Sales |  |  | (195,531 | ) |  |  | (123,368 | ) |  |  | (157,942 | ) |  |  | (63,655 | ) |  |  | (540,496 | ) |
| Ending Backlog - 6/30/18 |  | $ | 226,731 |  |  |  | 135,626 |  |  |  | 45,616 |  |  |  | 17,545 |  |  |  | 425,518 |  |
