# ESE notes — 0001410578-24-000723


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001410578-24-000723:notes:1]
[same as prior period, unchanged from 0001410578-24-000030:notes:1]

[0001410578-24-000723:notes:2]
[same as prior period, unchanged from 0001410578-24-000030:notes:2]

[0001410578-24-000723:notes:3]
The Company’s results for the three-month period ended March 31, 2024 are not necessarily indicative of the results for the entire 2024 fiscal year. References to the second quarters of 2024 and 2023 represent the fiscal quarters ended March 31, 2024 and 2023, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:EarningsPerShareTextBlock

[0001410578-24-000723:notes:4]
[same as prior period, unchanged from 0001410578-24-000030:notes:4]

[0001410578-24-000723:notes:5]
Basic EPS is calculated using the weighted average number of common shares outstanding during the period. Diluted EPS is calculated using the weighted average number of common shares outstanding during the period plus shares issuable upon the assumed exercise of dilutive common share options and vesting of restricted shares by using the treasury stock method. The number of shares used in the calculation of earnings per share for each period presented is as follows (in thousands):

[0001410578-24-000723:notes:6]
| ​ |  | Three Months | ​ | Six Months |
| ​ | ​ | Ended March 31, | ​ | Ended March 31, |
| ​ |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Weighted Average Shares Outstanding — Basic |  | 25,792 | ​ | 25,800 | ​ | 25,794 | ​ | 25,831 |
| Dilutive Restricted Shares | ​ | 55 | ​ | 95 | ​ | 52 | ​ | 88 |
| Adjusted Shares — Diluted |  | 25,847 | ​ | 25,895 | ​ | 25,846 | ​ | 25,919 |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001410578-24-000723:notes:7]
[same as prior period, unchanged from 0001410578-24-000030:notes:7]

[0001410578-24-000723:notes:8]
[same as prior period, unchanged from 0001410578-24-000030:notes:8]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001410578-24-000723:notes:9]
[same as prior period, unchanged from 0001410578-24-000030:notes:9]

[0001410578-24-000723:notes:10]
[same as prior period, unchanged from 0001410578-24-000030:notes:10]

[0001410578-24-000723:notes:11]
Performance-Accelerated Restricted Stock Unit (PARS) Awards and Time-Vested Restricted Stock Unit (RSU) Awards, and Performance Share Unit (PSU) Awards

[0001410578-24-000723:notes:12]
Compensation expense related to these awards was $1.7 million and $3.5 million for the three and six-month periods ended March 31, 2024, respectively, and $3.1 million and $4.7 million for the corresponding periods in 2023. As of March 31, 2024, there were 226,674 unvested stock units outstanding.

[0001410578-24-000723:notes:13]
[same as prior period, unchanged from 0001410578-24-000030:notes:13]

[0001410578-24-000723:notes:14]
Compensation expense related to the non-employee director grants was $0.3 million and $0.6 million for the three and six-month periods ended March 31, 2024, respectively, and $0.3 million and $0.6 million for the corresponding periods in 2023.

[0001410578-24-000723:notes:15]
The total share-based compensation cost that has been recognized in the results of operations and included within selling, general and administrative expenses (SG&A) was $2.0 million and $4.1 million for the three and six-month periods ended March 31, 2024, respectively, and $3.4 million and $5.3 million for the corresponding periods in 2023. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $0.3 million and $0.5 million for the three and six-month periods ended March 31, 2024, respectively, and $0.3 million and $0.6 million for the corresponding periods in 2023. As of March 31, 2024, there was $13.1 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a remaining weighted-average period of 1.8 years.


## us-gaap:InventoryDisclosureTextBlock

[0001410578-24-000723:notes:16]
[same as prior period, unchanged from 0001410578-24-000030:notes:16]

[0001410578-24-000723:notes:17]
[same as prior period, unchanged from 0001410578-24-000030:notes:17]

[0001410578-24-000723:notes:18]
| ​ | ​ | March 31, | ​ | September 30, |
| (In thousands) |  | 2024 |  | 2023 |
| Finished goods | ​ | $ | 38,857 | ​ | 34,577 |
| Work in process | ​ | ​ | 54,889 | ​ | 42,178 |
| Raw materials | ​ | ​ | 117,592 | ​ | 107,312 |
| Total inventories | ​ | $ | 211,338 | ​ | 184,067 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001410578-24-000723:notes:19]
[same as prior period, unchanged from 0001410578-24-000030:notes:19]

[0001410578-24-000723:notes:20]
Included on the Company’s Consolidated Balance Sheets at March 31, 2024 and September 30, 2023 are the following intangible assets gross carrying amounts and accumulated amortization:

[0001410578-24-000723:notes:21]
| ​ |  | March 31, |  | September 30, |
| (Dollars in thousands) |  | 2024 |  | 2023 |
| Goodwill | ​ | $ | 535,661 | ​ | 503,177 |
| Intangible assets with determinable lives: | ​ |  | ​ | ​ | ​ |
| Patents | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 2,516 | ​ | 2,516 |
| Less: accumulated amortization | ​ |  | 1,287 | ​ | 1,218 |
| Net | ​ | $ | 1,229 | ​ | 1,298 |
| Capitalized software | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 128,042 | ​ | 121,883 |
| Less: accumulated amortization | ​ |  | 86,622 | ​ | 80,774 |
| Net | ​ | $ | 41,420 | ​ | 41,109 |
| Customer relationships | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 327,695 | ​ | 296,927 |
| Less: accumulated amortization | ​ |  | 122,542 | ​ | 113,311 |
| Net | ​ | $ | 205,153 | ​ | 183,616 |
| Other | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 15,144 | ​ | 14,232 |
| Less: accumulated amortization | ​ |  | 10,870 | ​ | 9,578 |
| Net | ​ | $ | 4,274 | ​ | 4,654 |
| Intangible assets with indefinite lives: | ​ |  | ​ | ​ | ​ |
| Trade names | ​ | $ | 162,796 | ​ | 161,447 |

[0001410578-24-000723:notes:22]
The changes in the carrying amount of goodwill attributable to each business segment for the six months ended March 31, 2024 is as follows:

[0001410578-24-000723:notes:23]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | Aerospace | ​ | ​ |
| (Dollars in millions) |  | USG |  | Test |  | & Defense |  | Total |
| Balance as of September 30, 2023 | ​ | $ | 353.6 |  | ​ | 34.0 |  | 115.6 |  | 503.2 |
| Acquisition activity | ​ | ​ | — | ​ | ​ | 30.3 | ​ | — | ​ | 30.3 |
| Foreign currency translation | ​ | ​ | 1.4 | ​ | ​ | 0.8 | ​ | — | ​ | 2.2 |
| Balance as of March 31, 2024 | ​ | $ | 355.0 | ​ | ​ | 65.1 | ​ | 115.6 | ​ | 535.7 |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001410578-24-000723:notes:24]
[same as prior period, unchanged from 0001410578-24-000030:notes:24]

[0001410578-24-000723:notes:25]
The Company is organized based on the products and services that it offers and classifies its continuing business operations in three reportable segments for financial reporting purposes: Aerospace & Defense (A&D), Utility Solutions Group (USG), and RF Test and Measurement (Test).

[0001410578-24-000723:notes:26]
The Aerospace & Defense segment’s operations consist of PTI Technologies Inc. (PTI), VACCO Industries (VACCO), Crissair, Inc. (Crissair), Globe Composite Solutions, LLC (Globe) and Mayday Manufacturing Co. (Mayday). The companies within this segment primarily design and manufacture specialty filtration, fluid control and naval products, including hydraulic filter elements and fluid control devices used in aerospace and defense applications; unique filter mechanisms used in micro-propulsion devices for satellites, custom designed filters for manned aircraft and submarines; products and systems to reduce vibration and/or acoustic signatures and otherwise reduce or obscure a vessel’s signature, and other communications, sealing, surface control and hydrodynamic related applications to enhance U.S. Navy maritime survivability; precision-tolerance machined components for the aerospace and defense industry; metal processing services; and miniature electro-explosive devices utilized in mission-critical defense and aerospace applications.

[0001410578-24-000723:notes:27]
The USG segment’s operations consist primarily of Doble Engineering Company and related subsidiaries including Morgan Schaffer and Altanova (collectively, Doble), and NRG Systems, Inc. (NRG). Doble is an industry leader in the development, manufacture and delivery of diagnostic testing solutions that enable electric power grid operators to assess the integrity of high voltage power delivery equipment. It combines three core elements for customers – diagnostic test and condition monitoring instruments, expert consulting, and testing services – and provides access to its large reserve of related empirical knowledge. NRG is a global market leader in the design and manufacture of decision support tools for the renewable energy industry, primarily wind and solar.

[0001410578-24-000723:notes:28]
[same as prior period, unchanged from 0001410578-24-000030:notes:27]

[0001410578-24-000723:notes:29]
[same as prior period, unchanged from 0001410578-24-000030:notes:28]

[0001410578-24-000723:notes:30]
| ​ | ​ | Three Months | ​ | Six Months |
| ​ | ​ | Ended March 31, | ​ | Ended March 31, |
| (In thousands) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| NET SALES | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |  |
| Aerospace & Defense | ​ | $ | 114,701 | ​ | 98,982 | ​ | 209,434 | ​ | 181,965 |
| USG | ​ | ​ | 87,309 | ​ | 79,161 | ​ | 170,293 | ​ | 150,206 |
| Test | ​ | ​ | 47,119 | ​ | 50,993 | ​ | 87,716 | ​ | 102,466 |
| Consolidated totals | ​ | $ | 249,129 | ​ | 229,136 | ​ | 467,443 | ​ | 434,637 |
| EBIT | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Aerospace & Defense | ​ | $ | 23,377 | ​ | 18,795 | ​ | 40,040 | ​ | 31,331 |
| USG | ​ | ​ | 17,575 | ​ | 14,061 | ​ | 35,200 | ​ | 30,192 |
| Test | ​ | ​ | 5,542 | ​ | 7,226 | ​ | 7,321 | ​ | 12,637 |
| Corporate (loss) | ​ | ​ | (14,047) | ​ | (14,463) | ​ | (27,993) | ​ | (27,984) |
| Consolidated EBIT | ​ | ​ | 32,447 | ​ | 25,619 | ​ | 54,568 | ​ | 46,176 |
| Less: Interest expense | ​ | ​ | (3,226) | ​ | (2,269) | ​ | (5,893) | ​ | (3,927) |
| Earnings before income taxes | ​ | $ | 29,221 | ​ | 23,350 | ​ | 48,675 | ​ | 42,249 |

[0001410578-24-000723:notes:31]
[same as prior period, unchanged from 0001410578-24-000030:notes:30]

[0001410578-24-000723:notes:32]
[same as prior period, unchanged from 0001410578-24-000030:notes:31]

[0001410578-24-000723:notes:33]
[same as prior period, unchanged from 0001410578-24-000030:notes:32]


## us-gaap:DebtDisclosureTextBlock

[0001410578-24-000723:notes:34]
8.    DEBT

[0001410578-24-000723:notes:35]
The Company’s debt is summarized as follows:

[0001410578-24-000723:notes:36]
| ​ |  | March 31, | ​ | September 30, |
| (In thousands) |  | 2024 |  | 2023 |
| Total borrowings | ​ | $ | 191,000 | ​ | 102,000 |
| Current portion of long-term debt | ​ | ​ | (20,000) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 171,000 | ​ | 82,000 |

[0001410578-24-000723:notes:37]
The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of seven banks led by JP Morgan Chase Bank, N.A., as administrative agent, Bank of America, N.A., as syndication agent, and Commerce Bank and TD Bank, N.A. as co-documentation agents. The Credit Facility matures August 30, 2028, with balance due by this date.

[0001410578-24-000723:notes:38]
At March 31, 2024, the Company had approximately $303 million available to borrow under the Credit Facility, plus the $250 million increase option subject to the lenders’ consent, in addition to $59.4 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of March 31, 2024, as the Company intends to repay this amount within the next twelve months; however, the Company no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $5.8 million at March 31, 2024.

[0001410578-24-000723:notes:39]
Interest on borrowings under the Credit Facility is calculated at a spread over either an Adjusted Term SOFR Rate, Adjusted EURIBOR Rate, Adjusted CDOR Rate, Alternate Base Rate or Daily Simple RFR, at the Company’s election. The Credit Facility also requires a facility fee ranging from 12.5 to 25 basis points per annum on the unused portion. The interest rate spreads and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio. The weighted average interest rates were 6.8% and 6.8% for the three and six-month periods ending March 31, 2024, respectively, and 6.0% and 5.3% for the three and six-month periods ending March 31, 2023. As of March 31, 2024, the Company was in compliance with all covenants.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001410578-24-000723:notes:40]
[same as prior period, unchanged from 0001410578-24-000030:notes:39]

[0001410578-24-000723:notes:41]
The second quarter 2024 effective income tax rate was 20.5% compared to 23.4% in the second quarter of 2023. The effective income tax rate in the first six months of 2024 was 21.1% compared to 22.8% for the first six months of 2023. Income tax expense in the second quarter and first six months of 2024 was favorably impacted by discrete events including the release of a foreign valuation allowance and excess tax benefit related to the vesting of share-based director compensation.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001410578-24-000723:notes:42]
[same as prior period, unchanged from 0001410578-24-000030:notes:41]

[0001410578-24-000723:notes:43]
The change in shareholders’ equity for the first three and six months of 2024 and 2023 is shown below (in thousands):

[0001410578-24-000723:notes:44]
| ​ | ​ | Three Months Ended March 31, | ​ | Six Months Ended March 31, |
| ​ |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Common stock | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 308 | ​ | 307 | ​ | 308 | ​ | 307 |
| Stock plans | ​ | — | ​ | 1 | ​ | — | ​ | 1 |
| Ending balance | ​ | 308 | ​ | 308 | ​ | 308 | ​ | 308 |
| Additional paid-in-capital | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 305,283 | ​ | 300,697 | ​ | 304,850 | ​ | 301,553 |
| Stock plans | ​ | 2,782 | ​ | 3,487 | ​ | 3,215 | ​ | 2,631 |
| Ending balance | ​ | 308,065 | ​ | 304,184 | ​ | 308,065 | ​ | 304,184 |
| Retained earnings | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 1,002,420 | ​ | 917,682 | ​ | 989,315 | ​ | 905,022 |
| Net earnings common stockholders | ​ | 23,219 | ​ | 17,878 | ​ | 38,388 | ​ | 32,605 |
| Dividends paid | ​ | (2,061) | ​ | (2,061) | ​ | (4,125) | ​ | (4,128) |
| Ending balance | ​ | 1,023,578 | ​ | 933,499 | ​ | 1,023,578 | ​ | 933,499 |
| Accumulated other comprehensive income (loss) | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | (14,555) | ​ | (20,251) | ​ | (23,969) | ​ | (31,764) |
| Foreign currency translation | ​ | (4,745) | ​ | 2,233 | ​ | 4,669 | ​ | 13,746 |
| Ending balance | ​ | (19,300) | ​ | (18,018) | ​ | (19,300) | ​ | (18,018) |
| Treasury stock | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | (139,362) | ​ | (132,037) | ​ | (139,362) | ​ | (126,961) |
| Share repurchases | ​ | (6,879) | ​ | (7,141) | ​ | (6,879) | ​ | (12,217) |
| Ending balance | ​ | (146,241) | ​ | (139,178) | ​ | (146,241) | ​ | (139,178) |
| Total equity | ​ | 1,166,410 | ​ | 1,080,795 | ​ | 1,166,410 | ​ | 1,080,795 |


## us-gaap:FairValueDisclosuresTextBlock

[0001410578-24-000723:notes:45]
[same as prior period, unchanged from 0001410578-24-000030:notes:44]

[0001410578-24-000723:notes:46]
[same as prior period, unchanged from 0001410578-24-000030:notes:45]

[0001410578-24-000723:notes:47]
[same as prior period, unchanged from 0001410578-24-000030:notes:46]

[0001410578-24-000723:notes:48]
[same as prior period, unchanged from 0001410578-24-000030:notes:47]

[0001410578-24-000723:notes:49]
[same as prior period, unchanged from 0001410578-24-000030:notes:48]

[0001410578-24-000723:notes:50]
[same as prior period, unchanged from 0001410578-24-000030:notes:49]

[0001410578-24-000723:notes:51]
The Company has estimated the fair value of its financial instruments as of March 31, 2024 and September 30, 2023 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001410578-24-000723:notes:52]
[same as prior period, unchanged from 0001410578-24-000030:notes:51]

[0001410578-24-000723:notes:53]
[same as prior period, unchanged from 0001410578-24-000030:notes:52]

[0001410578-24-000723:notes:54]
[same as prior period, unchanged from 0001410578-24-000030:notes:53]

[0001410578-24-000723:notes:55]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however, they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during the three and six-month periods ended March 31, 2024.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001410578-24-000723:notes:56]
[same as prior period, unchanged from 0001410578-24-000030:notes:55]

[0001410578-24-000723:notes:57]
[same as prior period, unchanged from 0001410578-24-000030:notes:56]

[0001410578-24-000723:notes:58]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2024 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue within each reportable segment.

[0001410578-24-000723:notes:59]
| Three months ended March 31, 2024 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 49,382 | ​ | $ | 85,220 | ​ | $ | 34,537 | ​ | $ | 169,139 |
| Government | ​ | ​ | 65,319 | ​ | ​ | 2,089 | ​ | ​ | 12,582 | ​ | ​ | 79,990 |
| Total revenues | ​ | $ | 114,701 | ​ | $ | 87,309 | ​ | $ | 47,119 | ​ | $ | 249,129 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 92,161 | ​ | $ | 55,763 | ​ | $ | 27,543 | ​ | $ | 175,467 |
| International | ​ | ​ | 22,540 | ​ | ​ | 31,546 | ​ | ​ | 19,576 | ​ | ​ | 73,662 |
| Total revenues | ​ | $ | 114,701 | ​ | $ | 87,309 | ​ | $ | 47,119 | ​ | $ | 249,129 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 53,463 | ​ | $ | 70,285 | ​ | $ | 10,301 | ​ | $ | 134,049 |
| Over time | ​ | ​ | 61,238 | ​ | ​ | 17,024 | ​ | ​ | 36,818 | ​ | ​ | 115,080 |
| Total revenues | ​ | $ | 114,701 | ​ | $ | 87,309 | ​ | $ | 47,119 | ​ | $ | 249,129 |

[0001410578-24-000723:notes:60]
| Six months ended March 31, 2024 |  | Aerospace |  |  | ​ |  |  | ​ |  |  | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 86,591 | ​ | $ | 166,689 | ​ | $ | 69,615 | ​ | $ | 322,895 |
| Government | ​ |  | 122,843 | ​ |  | 3,604 | ​ |  | 18,101 | ​ |  | 144,548 |
| Total revenues | ​ | $ | 209,434 | ​ | $ | 170,293 | ​ | $ | 87,716 | ​ | $ | 467,443 |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| United States | ​ | $ | 172,062 | ​ | $ | 111,725 | ​ | $ | 49,795 | ​ | $ | 333,582 |
| International | ​ |  | 37,372 | ​ |  | 58,568 | ​ |  | 37,921 | ​ |  | 133,861 |
| Total revenues | ​ | $ | 209,434 | ​ | $ | 170,293 | ​ | $ | 87,716 | ​ | $ | 467,443 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 92,928 | ​ | $ | 136,989 | ​ | $ | 18,280 | ​ | $ | 248,197 |
| Over time | ​ |  | 116,506 | ​ |  | 33,304 | ​ |  | 69,436 | ​ |  | 219,246 |
| Total revenues | ​ | $ | 209,434 | ​ | $ | 170,293 | ​ | $ | 87,716 | ​ | $ | 467,443 |

[0001410578-24-000723:notes:61]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2023 are presented in the tables below.

[0001410578-24-000723:notes:62]
| Three months ended March 31, 2023 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 48,228 | ​ | $ | 78,110 | ​ | $ | 43,188 | ​ | $ | 169,526 |
| Government | ​ | ​ | 50,754 | ​ | ​ | 1,051 | ​ | ​ | 7,805 | ​ | ​ | 59,610 |
| Total revenues | ​ | $ | 98,982 | ​ | $ | 79,161 | ​ | $ | 50,993 | ​ | $ | 229,136 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 82,516 | ​ | $ | 53,020 | ​ | $ | 27,504 | ​ | $ | 163,040 |
| International | ​ | ​ | 16,466 | ​ | ​ | 26,141 | ​ | ​ | 23,489 | ​ | ​ | 66,096 |
| Total revenues | ​ | $ | 98,982 | ​ | $ | 79,161 | ​ | $ | 50,993 | ​ | $ | 229,136 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 47,255 | ​ | $ | 64,080 | ​ | $ | 11,968 | ​ | $ | 123,303 |
| Over time | ​ | ​ | 51,727 | ​ | ​ | 15,081 | ​ | ​ | 39,025 | ​ | ​ | 105,833 |
| Total revenues | ​ | $ | 98,982 | ​ | $ | 79,161 | ​ | $ | 50,993 | ​ | $ | 229,136 |

[0001410578-24-000723:notes:63]
| Six months ended March 31, 2023 |  | Aerospace |  |  | ​ |  |  | ​ |  |  | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 84,968 | ​ | $ | 148,273 | ​ | $ | 89,180 | ​ | $ | 322,421 |
| Government | ​ |  | 96,997 | ​ |  | 1,933 | ​ |  | 13,286 | ​ |  | 112,216 |
| Total revenues | ​ | $ | 181,965 | ​ | $ | 150,206 | ​ | $ | 102,466 | ​ | $ | 434,637 |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| United States | ​ | $ | 151,450 | ​ | $ | 99,399 | ​ | $ | 55,007 | ​ | $ | 305,856 |
| International | ​ |  | 30,515 | ​ |  | 50,807 | ​ |  | 47,459 | ​ |  | 128,781 |
| Total revenues | ​ | $ | 181,965 | ​ | $ | 150,206 | ​ | $ | 102,466 | ​ | $ | 434,637 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 80,859 | ​ | $ | 120,111 | ​ | $ | 21,069 | ​ | $ | 222,039 |
| Over time | ​ |  | 101,106 | ​ |  | 30,095 | ​ |  | 81,397 | ​ |  | 212,598 |
| Total revenues | ​ | $ | 181,965 | ​ | $ | 150,206 | ​ | $ | 102,466 | ​ | $ | 434,637 |

[0001410578-24-000723:notes:64]
[same as prior period, unchanged from 0001410578-24-000030:notes:61]

[0001410578-24-000723:notes:65]
Payment terms with our customers vary by the type and location of the customer and the products or services offered. Arrangements with customers that include payment terms extending beyond one year are not significant. The transaction price for

[0001410578-24-000723:notes:66]
these contracts reflects our estimate of returns and discounts, which are based on historical, current and forecasted information to determine the expected amount to which we will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation. Under the typical payment terms of our long term fixed price contracts, the customer pays us either performance-based or progress payments. Performance-based payments represent interim payments based on quantifiable measures of performance or on the achievement of specified events or milestones. Progress payments are interim payments of costs incurred as the work progresses.

[0001410578-24-000723:notes:67]
[same as prior period, unchanged from 0001410578-24-000030:notes:63]

[0001410578-24-000723:notes:68]
[same as prior period, unchanged from 0001410578-24-000030:notes:64]

[0001410578-24-000723:notes:69]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At March 31, 2024, the Company had $837.7 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 70% in the next twelve months.

[0001410578-24-000723:notes:70]
[same as prior period, unchanged from 0001410578-24-000030:notes:66]

[0001410578-24-000723:notes:71]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At March 31, 2024, contract assets, contract liabilities and accounts receivable totaled $139.3 million, $117.8 million and $187.5 million, respectively. During the first six months of 2024, the Company recognized approximately $44 million in revenues that were included in the contract liabilities balance at September 30, 2023. At September 30, 2023, contract assets, contract liabilities and accounts receivable totaled $138.6 million, $123.1 million and $198.6 million, respectively.


## ese:OperatingAndFinancingLeasesOfLesseeDisclosureTextBlock

[0001410578-24-000723:notes:72]
[same as prior period, unchanged from 0001410578-24-000030:notes:68]

[0001410578-24-000723:notes:73]
[same as prior period, unchanged from 0001410578-24-000030:notes:69]

[0001410578-24-000723:notes:74]
[same as prior period, unchanged from 0001410578-24-000030:notes:70]

[0001410578-24-000723:notes:75]
In addition to the base rent, real estate leases typically contain provisions for common-area maintenance and other similar services, which are considered non-lease components for accounting purposes. Non-lease components are excluded from our ROU assets and lease liabilities and expensed as incurred.

[0001410578-24-000723:notes:76]
[same as prior period, unchanged from 0001410578-24-000030:notes:72]

[0001410578-24-000723:notes:77]
[same as prior period, unchanged from 0001410578-24-000030:notes:73]

[0001410578-24-000723:notes:78]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended |
| ​ | ​ | March 31, | ​ | March 31, |
| (Dollars in thousands) |  | 2024 |  | 2023 |
| Finance lease cost | ​ | ​ | ​ | ​ | ​ | ​ |
| Amortization of right-of-use assets | ​ | $ | 372 | ​ | $ | 393 |
| Interest on lease liabilities | ​ | ​ | 216 | ​ | ​ | 233 |
| Operating lease cost | ​ | ​ | 1,874 | ​ | ​ | 1,853 |
| Total lease costs | ​ | $ | 2,462 | ​ | $ | 2,479 |

[0001410578-24-000723:notes:79]
| ​ | ​ | Six Months Ended | ​ | Six Months Ended |
| ​ | ​ | March 31, | ​ | ​ | March 31, |
| (Dollars in thousands) |  | 2024 |  | ​ | 2023 |
| Finance lease cost | ​ | ​ | ​ | ​ | ​ | ​ |
| Amortization of right-of-use assets | ​ | $ | 765 | ​ | $ | 786 |
| Interest on lease liabilities | ​ |  | 439 | ​ | ​ | 469 |
| Operating lease cost | ​ |  | 3,738 | ​ | ​ | 3,498 |
| Total lease costs | ​ | $ | 4,942 | ​ | $ | 4,753 |

[0001410578-24-000723:notes:80]
[same as prior period, unchanged from 0001410578-24-000030:notes:75]

[0001410578-24-000723:notes:81]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended |
| ​ | ​ | March 31, | ​ | March 31, |
| (Dollars in thousands) |  | 2024 |  | 2023 |
| Cash paid for amounts included in the measurement of lease liabilities | ​ | ​ | ​ | ​ | ​ | ​ |
| Operating cash flows from operating leases | ​ | $ | 1,824 | ​ | $ | 1,779 |
| Operating cash flows from finance leases | ​ | ​ | 216 | ​ | ​ | 233 |
| Financing cash flows from finance leases | ​ | ​ | 328 | ​ | ​ | 330 |
| Right-of-use assets obtained in exchange for operating lease liabilities | ​ | ​ | 1,679 | ​ | ​ | 618 |

[0001410578-24-000723:notes:82]
| ​ |  | Six Months Ended |  | Six Months Ended |
| ​ | ​ | March 31, | ​ | March 31, |
| (Dollars in thousands) | ​ | 2024 | ​ | 2023 |
| Cash paid for amounts included in the measurement of lease liabilities |  | ​ |  |  | ​ |  |
| Operating cash flows from operating leases | ​ | $ | 3,643 | ​ | $ | 3,380 |
| Operating cash flows from finance leases | ​ |  | 439 | ​ |  | 469 |
| Financing cash flows from finance leases | ​ |  | 683 | ​ |  | 658 |
| Right-of-use assets obtained in exchange for operating lease liabilities | ​ |  | 1,679 | ​ |  | 14,582 |

[0001410578-24-000723:notes:83]
| ​ |  | March 31, 2024 |  | March 31, 2023 | ​ |
| Weighted-average remaining lease term | ​ |  | ​ |  | ​ |
| Operating leases |  | 10.8 | years | 11.5 | years |
| Finance leases |  | 11.1 | years | 11.5 | years |
| Weighted-average discount rate |  |  |  |  |  |
| Operating leases |  | 4.55 | % | 4.40 | % |
| Finance leases |  | 4.68 | % | 4.61 | % |

[0001410578-24-000723:notes:84]
The following is a reconciliation of future undiscounted cash flows to the operating and finance lease liabilities, and the related ROU assets, presented on our Consolidated Balance Sheet on March 31, 2024:

[0001410578-24-000723:notes:85]
| (Dollars in thousands) | ​ | Operating |  | Finance |
| Years Ending September 30: |  | Leases |  | Leases |
| 2024 (excluding the six months ended March 31, 2024) | ​ | $ | 3,389 | ​ | 1,090 |
| 2025 | ​ | ​ | 6,014 | ​ | 2,233 |
| 2026 | ​ | ​ | 4,729 | ​ | 2,297 |
| 2027 | ​ | ​ | 4,479 | ​ | 2,357 |
| 2028 and thereafter | ​ | ​ | 33,206 | ​ | 16,470 |
| Total minimum lease payments | ​ | ​ | 51,817 | ​ | 24,447 |
| Less: amounts representing interest | ​ | ​ | 11,540 | ​ | 5,795 |
| Present value of net minimum lease payments | ​ | $ | 40,277 | ​ | 18,652 |
| Less: current portion of lease obligations | ​ | ​ | 4,833 | ​ | 1,375 |
| Non-current portion of lease obligations | ​ | ​ | 35,444 | ​ | 17,277 |
| ROU assets | ​ | $ | 38,322 | ​ | 14,427 |

[0001410578-24-000723:notes:86]
Operating lease liabilities are included in the Consolidated Balance Sheet in accrued other expenses (current portion) and as a caption on the Consolidated Balance Sheet (long-term portion). Finance lease liabilities are included on the Consolidated Balance Sheet in accrued other expenses (current portion) and other liabilities (long-term portion). Operating lease ROU assets are included as a caption on the Consolidated Balance Sheet and finance lease ROU assets are included in Property, plant and equipment on the Consolidated Balance sheet.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001410578-24-000723:notes:87]
14.  NEW ACCOUNTING PRONOUNCEMENTS

[0001410578-24-000723:notes:88]
In November 2023, the FASB issued ASU 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures,” which expands annual and interim disclosure requirements for reportable segments, primarily through enhanced disclosures about significant expenses. The new segment disclosures are effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024. Management will review the extent of new disclosures necessary in the coming quarters, prior to implementation in our fiscal year 2025. Other than additional disclosure, we do not expect a change to our consolidated statements of operations, financial position, or cash flows.

[0001410578-24-000723:notes:89]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures,” which provides qualitative and quantitative updates to the rate reconciliation and income taxes paid disclosures. This ASU will be effective for fiscal years beginning after December 15, 2024. Management will review the extent of new disclosures necessary in the coming quarters, prior to implementation in our fiscal year 2026. Other than additional disclosure, we do not expect a change to our consolidated statements of operations, financial position, or cash flows.
