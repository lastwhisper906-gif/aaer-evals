# ESE 8-K — 0001104659-24-059341 filed 2024-05-09

## item codes, every 8-K on or before 2024-05-10

- 2024-05-09 0001104659-24-059341 — 2.02, 7.01, 9.01
- 2024-02-08 0001104659-24-012294 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2023-11-20 0001104659-23-119761 — 5.02, 9.01
- 2023-11-16 0001104659-23-119126 — 2.02, 7.01, 9.01
- 2023-10-03 0001104659-23-106090 — 5.02, 9.01
- 2023-09-06 0001104659-23-098463 — 1.01, 2.03, 9.01
- 2023-08-08 0001104659-23-088847 — 2.02, 7.01, 9.01
- 2023-07-06 0001104659-23-078571 — 5.02, 8.01, 9.01
- 2023-05-09 0001104659-23-057736 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2023-05-05 0001104659-23-056387 — 5.02, 9.01
- 2023-02-08 0001104659-23-014539 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2023-01-06 0001104659-23-001859 — 5.02, 9.01
- 2022-11-22 0001104659-22-121229 — 5.02, 5.03, 8.01, 9.01
- 2022-11-17 0001104659-22-119898 — 2.02, 7.01, 9.01
- 2022-09-12 0001104659-22-099248 — 5.02, 7.01, 9.01
- 2022-08-08 0001104659-22-087247 — 2.02, 5.02, 7.01, 9.01
- 2022-05-09 0001104659-22-057524 — 2.02, 5.02, 7.01, 9.01
- 2022-02-08 0001104659-22-013878 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2021-12-03 0001104659-21-146361 — 4.01, 9.01 — amendment, the index does not say of what
- 2021-11-24 0001104659-21-143568 — 4.01, 9.01
- 2021-11-23 0001104659-21-142871 — 5.02, 8.01
- 2021-11-18 0001104659-21-141206 — 2.02, 7.01, 9.01
- 2021-08-09 0001104659-21-102150 — 2.02, 7.01, 9.01
- 2021-05-04 0001104659-21-060985 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2021-04-05 0001104659-21-046581 — 5.02, 9.01
- 2021-02-08 0001104659-21-013712 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2020-12-09 0001104659-20-133674 — 5.02, 9.01
- 2020-12-07 0001104659-20-132861 — 5.02, 7.01, 9.01
- 2020-11-19 0001104659-20-127352 — 2.02, 5.02, 7.01, 9.01
- 2020-08-10 0001104659-20-092734 — 2.02, 7.01, 9.01
- 2020-05-06 0001104659-20-057442 — 2.02, 7.01, 8.01, 9.01
- 2020-02-04 0001104659-20-010640 — 2.02, 5.07, 7.01, 9.01
- 2020-01-07 0001104659-20-001789 — 2.01, 9.01
- 2019-11-19 0001104659-19-065437 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2019-11-18 0001104659-19-065096 — 1.01, 2.02, 7.01, 9.01
- 2019-09-30 0001144204-19-046523 — 1.01, 1.02, 2.03, 9.01
- 2019-08-08 0001144204-19-038567 — 2.02, 7.01, 9.01
- 2019-05-07 0001144204-19-024241 — 2.02, 5.02, 7.01, 9.01
- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2024-05-10

- none on or before 2024-05-10

## item 2.02 — earnings release, exhibit 99.1

[0001104659-24-059341:8k_2_02:1]
EX-99.1
2
tm2413938d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-24-059341:8k_2_02:2]
Exhibit 99.1

[0001104659-24-059341:8k_2_02:3]
| NEWS FROM |  |  |

[0001104659-24-059341:8k_2_02:4]
For more information contact:

[0001104659-24-059341:8k_2_02:5]
Kate Lowrey
- VP of Investor Relations

[0001104659-24-059341:8k_2_02:6]
(314) 213-7277
/ klowrey@escotechnologies.com

[0001104659-24-059341:8k_2_02:7]
ESCO
REPORTS SECOND QUARTER FISCAL 2024 RESULTS

[0001104659-24-059341:8k_2_02:8]
- Q2 Sales increase 9% to $249 Million -

[0001104659-24-059341:8k_2_02:9]
- Q2 GAAP EPS increases 30% to $0.90 -

[0001104659-24-059341:8k_2_02:10]
- Q2 Adjusted EPS increases 24% to $0.94
-

[0001104659-24-059341:8k_2_02:11]
ST. LOUIS, May 9, 2024 – ESCO Technologies Inc. (NYSE: ESE)
(ESCO, or the Company) today reported its operating results for the second quarter ended March 31, 2024 (Q2 2024).

[0001104659-24-059341:8k_2_02:12]
Operating
Highlights

[0001104659-24-059341:8k_2_02:13]
|  | ● | Q2 2024 Sales increased $20.0 million (9 percent) to $249.1 million compared to $229.1 million in Q2 2023. Q2 organic sales increased $17.8 million (8 percent) and the MPE acquisition contributed $2.2 million (1 percent) of revenue in the quarter. |

[0001104659-24-059341:8k_2_02:14]
|  | ● | Q2 2024 GAAP EPS increased 30 percent to $0.90 per share compared to $0.69 per share in Q2 2023. Q2 2024 Adjusted EPS increased 24 percent to $0.94 per share compared to $0.76 per share in Q2 2023. |

[0001104659-24-059341:8k_2_02:15]
|  | ● | Q2 2024 Entered Orders decreased $12.5 million (5 percent) compared to the prior year period to $239.1 million (book-to-bill of 0.96x), resulting in ending backlog of $838 million. |

[0001104659-24-059341:8k_2_02:16]
|  | ● | Net cash provided by operating activities was $19 million YTD, an increase of $25 million compared to the prior year period, as cash flow was positively impacted by lower accounts receivable balances and higher earnings. |

[0001104659-24-059341:8k_2_02:17]
|  | ● | Net debt (total borrowings less cash on hand) was $132 million, resulting in a 0.86x leverage ratio and $553 million in liquidity as of March 31, 2024. |

[0001104659-24-059341:8k_2_02:18]
Bryan Sayler,
Chief Executive Officer and President, commented, “Q2 was a solid quarter highlighted by both top and bottom-line growth. Revenue
grew 9 percent as we continue to see favorable dynamics in our key aerospace, Navy and utility end markets. The sales performance translated
to the bottom line very well as Adjusted EPS increased 24 percent compared to the prior year quarter.”

[0001104659-24-059341:8k_2_02:19]
Segment Performance

[0001104659-24-059341:8k_2_02:20]
Aerospace & Defense (A&D)

[0001104659-24-059341:8k_2_02:21]
|  | ● | Sales increased $15.7 million (16 percent) to $114.7 million in Q2 2024 from $99.0 million in Q2 2023. Sales growth was driven by strength across Navy, commercial aerospace, and defense aerospace programs. |

[0001104659-24-059341:8k_2_02:22]
|  | ● | Q2 2024 EBIT increased $4.6 million to $23.4 million from $18.8 million in Q2 2023. Adjusted EBIT increased $4.0 million in Q2 2024 to $23.6 million (20.6 percent margin) from $19.6 million (19.8 percent margin) in Q2 2023. Margin improvement was driven by leverage on revenue growth and price increases, partially offset by inflationary pressures and mix. |

[0001104659-24-059341:8k_2_02:23]
|  | ● | Entered Orders increased $4 million (4 percent) to $116 million in Q2 2024 compared to $112 million in Q2 2023. The increase in orders was primarily driven by strength in OEM and aftermarket orders for both commercial and defense aerospace. The orders in the quarter resulted in a segment book-to-bill of 1.01x and ending backlog of $562 million. |

[0001104659-24-059341:8k_2_02:24]
Utility Solutions Group (USG)

[0001104659-24-059341:8k_2_02:25]
|  | ● | Sales increased $8.1 million (10 percent) to $87.3 million in Q2 2024 from $79.2 million in Q2 2023. Doble’s sales increased by $6.3 million (10 percent) driven by a strong quarter for services and cybersecurity/compliance (DUCe) solutions. NRG sales increased $1.8 million (13 percent) driven by higher demand for solar products. |

[0001104659-24-059341:8k_2_02:26]
|  | ● | EBIT increased $3.5 million (25 percent) in Q2 2024 to $17.6 million (20.1 percent margin) from $14.1 million (17.8 percent margin) in Q2 2023. There were no adjustments in either period. Margin improvement was driven by mix from increased service business, leverage on revenue growth, and price increases, partially offset by inflationary pressures. |

[0001104659-24-059341:8k_2_02:27]
|  | ● | Entered Orders decreased $6 million (7 percent) to $79 million in Q2 2024. Orders were down slightly at Doble and continued to moderate at NRG. NRG’S orders were extremely strong in FY’23 driven by a unique surge related to large orders at extended lead-times as customers managed supply chain concerns and order activity related to Inflation Reduction Act spending. We expect orders for the renewables business to rebound as the market digests last year’s elevated activity level and new projects are defined and implemented. The segment book-to-bill was 0.91x in the quarter, resulting in ending backlog of $119 million. |

[0001104659-24-059341:8k_2_02:28]
RF Test & Measurement (Test)

[0001104659-24-059341:8k_2_02:29]
|  | ● | Sales decreased $3.9 million (8 percent) to $47.1 million in Q2 2024 from $51.0 million in Q2 2023. Organic sales decreased $6.1 million primarily related to lower wireless, filters and acoustic volume, partially offset by $2.2 million of revenue related to the MPE acquisition which was completed in Q1 2024. |
|  | ● | In line with our prior communication, our Test Segment’s revenue continued to be somewhat soft in Q2. While sales were down compared to the prior year, they increased 16 percent sequentially. |

[0001104659-24-059341:8k_2_02:30]
|  | ● | EBIT decreased $1.7 million in Q2 2024 to $5.5 million from $7.2 million in Q2 2023. Adjusted EBIT decreased $1.5 million in Q2 2024 to $5.7 million (12.2 percent margin) from $7.2 million (14.2 percent margin) in Q2 2023. Margin was impacted by lower volume and inflationary pressures, largely mitigated by price increases and cost reduction actions. |

[0001104659-24-059341:8k_2_02:31]
|  | ● | Entered Orders decreased $11 million (21 percent) to $44 million in Q2 2024. The decrease was primarily related to lower wireless demand and delays on a few large projects, partially offset by higher OTC filter, MPE, and services orders. The segment book-to-bill was 0.93x in the quarter, resulting in ending backlog of $156 million. |

[0001104659-24-059341:8k_2_02:32]
Share Repurchase Program

[0001104659-24-059341:8k_2_02:33]
During Q2 2024, the Company repurchased approximately 72,000 shares
for $7.2 million.

[0001104659-24-059341:8k_2_02:34]
Dividend
Payment

[0001104659-24-059341:8k_2_02:35]
The next quarterly
cash dividend of $0.08 per share will be paid on July 19, 2024 to stockholders of record on July 3, 2024.

[0001104659-24-059341:8k_2_02:36]
Business
Outlook – 2024

[0001104659-24-059341:8k_2_02:37]
Year-to-date performance has tracked to expectations and full year
adjusted earnings per share guidance is being maintained in the range of $4.15 to $4.30 (12 to 16 percent growth). This represents ESCO’s
third year in a row of double-digit earnings growth. This outlook is based on sales in line with our initial guidance range of $1.02 to
$1.04 billion (7 to 9 percent annual growth). Management’s expectation is for Q3 Adjusted EPS in the range of $1.16 to $1.22.

[0001104659-24-059341:8k_2_02:38]
Conference Call

[0001104659-24-059341:8k_2_02:39]
The Company
will host a conference call today, May 9, at 4:00 p.m. Central Time, to discuss the Company’s Q2 2024 results. A live
audio webcast and an accompanying slide presentation will be available on ESCO’s investor website. For those unable to participate,
a webcast replay will be available after the call on ESCO’s investor website.

[0001104659-24-059341:8k_2_02:40]
Forward-Looking Statements

[0001104659-24-059341:8k_2_02:41]
Investors
are cautioned that such statements are only predictions and speak only as of the date of this release, and the Company undertakes no duty
to update them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ
materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations
and business environment including but not limited to those described in Item 1A, “Risk Factors”, of the Company’s Annual
Report on Form 10-K for the fiscal year ended September 30, 2023 and the following: the impacts of climate change and
related regulation of greenhouse gases; the impacts of labor disputes, civil disorder, wars, elections, political changes, tariffs and
trade disputes, terrorist activities, cyberattacks or natural disasters on the Company’s operations and those of the Company’s
customers and suppliers; disruptions in manufacturing or delivery arrangements due to shortages or unavailability of materials or components
or supply chain disruptions; inability to access work sites; the timing and content of future contract awards or customer orders; the
timely appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer
contracts or orders; weakening of economic conditions in served markets; the success of the Company’s competitors; changes in customer
demands or customer insolvencies; competition; intellectual property rights; technical difficulties or data breaches; the availability
of selected acquisitions; delivery delays or defaults by customers; performance issues with key customers, suppliers and subcontractors;
material changes in the costs and availability of certain raw materials; material changes in the cost of credit; changes in laws and regulations
including but not limited to changes in accounting standards and taxation; changes in interest, inflation and employment rates; costs
relating to environmental matters arising from current or former facilities; uncertainty regarding the ultimate resolution of current
disputes, claims, litigation or arbitration; and the integration and performance of recently acquired businesses.

[0001104659-24-059341:8k_2_02:42]
Non-GAAP Financial Measures

[0001104659-24-059341:8k_2_02:43]
The financial measures EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA,
and Adjusted EPS are presented in this press release. The Company defines “EBIT” as earnings before interest and taxes, “EBITDA”
as earnings before interest, taxes, depreciation and amortization, “Adjusted EBIT” and “Adjusted EBITDA” as excluding
the net impact of the items described in the attached Reconciliation of Non-GAAP Financial Measures, and “Adjusted EPS” as
GAAP earnings per share excluding the net impact of the items described and reconciled in the attached Reconciliation of Non-GAAP Financial
Measures.

[0001104659-24-059341:8k_2_02:44]
EBIT, Adjusted
EBIT, EBITDA, Adjusted EBITDA, and Adjusted EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP).
However, Management believes EBIT, Adjusted EBIT, EBITDA, and Adjusted EBITDA are useful in assessing the operational profitability of
the Company’s business segments because they exclude interest, taxes, depreciation, and amortization, which are generally accounted
for across the entire Company on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations
within the Company as well as incentive compensation. The presentation of EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA, and Adjusted EPS
provides important supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP
financial measures to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures
of performance determined in accordance with GAAP.

[0001104659-24-059341:8k_2_02:45]
ESCO is a
global provider of highly engineered products and solutions serving diverse end-markets. It manufactures filtration and fluid control
products for the aviation, Navy, space, and process markets worldwide and composite-based products and solutions for Navy, defense, and
industrial customers. ESCO is an industry leader in designing and manufacturing RF test and measurement products and systems; and provides
diagnostic instruments, software and services to industrial power users and the electric utility and renewable energy industries. Headquartered
in St. Louis, Missouri, ESCO and its subsidiaries have offices and manufacturing facilities worldwide. For more information on ESCO and
its subsidiaries, visit the Company’s website at www.escotechnologies.com.

[0001104659-24-059341:8k_2_02:46]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-059341:8k_2_02:47]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-24-059341:8k_2_02:48]
(Dollars in thousands, except per share amounts)

[0001104659-24-059341:8k_2_02:49]
|  |  | Three Months Ended March 31, 2024 |  |  | Three Months Ended March 31, 2023 |  |
| Net Sales |  | $ | 249,129 |  |  |  | 229,136 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 152,347 |  |  |  | 142,296 |  |
| Selling, general and administrative expenses |  |  | 55,097 |  |  |  | 53,877 |  |
| Amortization of intangible assets |  |  | 8,572 |  |  |  | 7,030 |  |
| Interest expense |  |  | 3,226 |  |  |  | 2,269 |  |
| Other expenses (income), net |  |  | 666 |  |  |  | 314 |  |
| Total costs and expenses |  |  | 219,908 |  |  |  | 205,786 |  |
| Earnings before income taxes |  |  | 29,221 |  |  |  | 23,350 |  |
| Income tax expense |  |  | 6,002 |  |  |  | 5,472 |  |
| Net earnings |  | $ | 23,219 |  |  |  | 17,878 |  |
| Earnings Per Share (EPS) |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.90 |  |  |  | 0.69 |  |
| Diluted - As Adjusted Basis |  | $ | 0.94 | (1) |  |  | 0.76 | (2) |
| Diluted average common shares O/S: |  |  | 25,847 |  |  |  | 25,895 |  |

[0001104659-24-059341:8k_2_02:50]
|  | (1) | Q2 2024 Adjusted EPS excludes $0.04 per share of after-tax charges consisting of: $0.02 of MPE acquisition backlog charges and $0.02 of restructuring charges (primarily severance) within the Test and A&D segments. |
|  | (2) | Q2 2023 Adjusted EPS excludes $0.07 per share of after-tax charges consisting of: $0.04 of executive management transition costs at Corporate, $0.02 of CMT acquisition inventory step-up charges and $0.01 of restructuring charges within the A&D segment. |

[0001104659-24-059341:8k_2_02:51]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-059341:8k_2_02:52]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-24-059341:8k_2_02:53]
(Dollars in thousands, except per share amounts)

[0001104659-24-059341:8k_2_02:54]
|  |  | Six Months Ended March 31, 2024 |  |  | Six Months Ended March 31, 2023 |  |
| Net Sales |  | $ | 467,443 |  |  |  | 434,637 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 286,498 |  |  |  | 268,679 |  |
| Selling, general and administrative expenses |  |  | 109,065 |  |  |  | 105,179 |  |
| Amortization of intangible assets |  |  | 16,440 |  |  |  | 13,891 |  |
| Interest expense |  |  | 5,893 |  |  |  | 3,927 |  |
| Other expenses (income), net |  |  | 872 |  |  |  | 712 |  |
| Total costs and expenses |  |  | 418,768 |  |  |  | 392,388 |  |
| Earnings before income taxes |  |  | 48,675 |  |  |  | 42,249 |  |
| Income tax expense |  |  | 10,287 |  |  |  | 9,644 |  |
| Net earnings |  | $ | 38,388 |  |  |  | 32,605 |  |
| Earnings Per Share (EPS) |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 1.49 |  |  |  | 1.26 |  |
| Diluted - As Adjusted Basis |  | $ | 1.56 | (1) |  |  | 1.36 | (2) |
| Diluted average common shares O/S: |  |  | 25,846 |  |  |  | 25,919 |  |

[0001104659-24-059341:8k_2_02:55]
|  | (1) | YTD Q2 2024 Adjusted EPS excludes $0.07 per share of after-tax charges consisting of: $0.05 of MPE acquisition backlog and inventory step-up charges and acquisition costs and $0.02 of restructuring charges (primarily severance) within the Test and A&D segments. |
|  | (2) | YTD Q2 2023 Adjusted EPS excludes $0.10 per share of after-tax charges consisting of: $0.06 of executive management transition costs at Corporate, $0.02 of CMT acquisition inventory step-up charges and $0.02 of restructuring charges within the A&D segment. |

[0001104659-24-059341:8k_2_02:56]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-059341:8k_2_02:57]
Condensed Business Segment Information (Unaudited)

[0001104659-24-059341:8k_2_02:58]
(Dollars in thousands)

[0001104659-24-059341:8k_2_02:59]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  |  | Q2 2024 |  |  |  | Q2 2023 |  |  |  | Q2 2024 |  |  |  | Q2 2023 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 114,701 |  |  |  | 98,982 |  |  |  | 114,701 |  |  |  | 98,982 |  |
| USG |  |  | 87,309 |  |  |  | 79,161 |  |  |  | 87,309 |  |  |  | 79,161 |  |
| Test |  |  | 47,119 |  |  |  | 50,993 |  |  |  | 47,119 |  |  |  | 50,993 |  |
| Totals |  | $ | 249,129 |  |  |  | 229,136 |  |  |  | 249,129 |  |  |  | 229,136 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 23,377 |  |  |  | 18,795 |  |  |  | 23,640 |  |  |  | 19,595 |  |
| USG |  |  | 17,575 |  |  |  | 14,061 |  |  |  | 17,575 |  |  |  | 14,061 |  |
| Test |  |  | 5,542 |  |  |  | 7,226 |  |  |  | 5,745 |  |  |  | 7,226 |  |
| Corporate |  |  | (14,047 | ) |  |  | (14,463 | ) |  |  | (13,262 | ) |  |  | (12,963 | ) |
| Consolidated EBIT |  |  | 32,447 |  |  |  | 25,619 |  |  |  | 33,698 |  |  |  | 27,919 |  |
| Less: Interest expense |  |  | (3,226 | ) |  |  | (2,269 | ) |  |  | (3,226 | ) |  |  | (2,269 | ) |
| Less: Income tax expense |  |  | (6,002 | ) |  |  | (5,472 | ) |  |  | (6,290 | ) |  |  | (6,001 | ) |
| Net earnings |  | $ | 23,219 |  |  |  | 17,878 |  |  |  | 24,182 |  |  |  | 19,649 |  |

[0001104659-24-059341:8k_2_02:60]
Note
1: Adjusted net earnings of $24.2 million in Q2 2024 exclude $0.04 per share of after-tax charges consisting of: $0.02 of MPE acquisition
backlog charges and $0.02 of restructuring charges (primarily severance) within the Test and A&D segments.

[0001104659-24-059341:8k_2_02:61]
Note 2: Adjusted net earnings of $19.6 million in Q2 2023 exclude $0.07 per share of after-tax charges consisting of: $0.04 of executive management transition costs at Corporate, $0.02 of CMT acquisition inventory step-up charges and $0.01 of restructuring charges within the A&D segment.

[0001104659-24-059341:8k_2_02:62]
| EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |  | Q2 2024 - |  |  | Q2 2023 - |  |
|  |  | Q2 2024 |  |  | Q2 2023 |  |  | As Adjusted |  |  | As Adjusted |  |
| Consolidated EBITDA |  | $ | 46,550 |  |  |  | 38,162 |  |  |  | 47,174 |  |  |  | 40,462 |  |
| Less: Depr & Amort |  |  | (14,103 | ) |  |  | (12,543 | ) |  |  | (13,476 | ) |  |  | (12,543 | ) |
| Consolidated EBIT |  |  | 32,447 |  |  |  | 25,619 |  |  |  | 33,698 |  |  |  | 27,919 |  |
| Less: Interest expense |  |  | (3,226 | ) |  |  | (2,269 | ) |  |  | (3,226 | ) |  |  | (2,269 | ) |
| Less: Income tax expense |  |  | (6,002 | ) |  |  | (5,472 | ) |  |  | (6,290 | ) |  |  | (6,001 | ) |
| Net earnings |  | $ | 23,219 |  |  |  | 17,878 |  |  |  | 24,182 |  |  |  | 19,649 |  |

[0001104659-24-059341:8k_2_02:63]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-059341:8k_2_02:64]
Condensed Business Segment Information (Unaudited)

[0001104659-24-059341:8k_2_02:65]
(Dollars in thousands)

[0001104659-24-059341:8k_2_02:66]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | YTD |  |  | YTD |  |  | YTD |  |  | YTD |  |
|  |  | Q2 2024 |  |  | Q2 2023 |  |  | Q2 2024 |  |  | Q2 2023 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 209,434 |  |  |  | 181,965 |  |  |  | 209,434 |  |  |  | 181,965 |  |
| USG |  |  | 170,293 |  |  |  | 150,206 |  |  |  | 170,293 |  |  |  | 150,206 |  |
| Test |  |  | 87,716 |  |  |  | 102,466 |  |  |  | 87,716 |  |  |  | 102,466 |  |
| Totals |  | $ | 467,443 |  |  |  | 434,637 |  |  |  | 467,443 |  |  |  | 434,637 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 40,040 |  |  |  | 31,331 |  |  |  | 40,303 |  |  |  | 32,330 |  |
| USG |  |  | 35,200 |  |  |  | 30,192 |  |  |  | 35,320 |  |  |  | 30,192 |  |
| Test |  |  | 7,321 |  |  |  | 12,637 |  |  |  | 7,797 |  |  |  | 12,637 |  |
| Corporate |  |  | (27,993 | ) |  |  | (27,984 | ) |  |  | (26,557 | ) |  |  | (25,691 | ) |
| Consolidated EBIT |  |  | 54,568 |  |  |  | 46,176 |  |  |  | 56,863 |  |  |  | 49,468 |  |
| Less: Interest expense |  |  | (5,893 | ) |  |  | (3,927 | ) |  |  | (5,893 | ) |  |  | (3,927 | ) |
| Less: Income tax expense |  |  | (10,287 | ) |  |  | (9,644 | ) |  |  | (10,815 | ) |  |  | (10,401 | ) |
| Net earnings |  | $ | 38,388 |  |  |  | 32,605 |  |  |  | 40,155 |  |  |  | 35,140 |  |

[0001104659-24-059341:8k_2_02:67]
Note
1: Adjusted net earnings of $40.2 million in YTD 2024 exclude $0.07 per share of after-tax charges consisting of: $0.05 of MPE acquisition
backlog and inventory step-up charges and acquisition costs and $0.02 of restructuring costs (primarily severance) within the Test and
A&D segments.

[0001104659-24-059341:8k_2_02:68]
Note 2: Adjusted net earnings of $35.1 million in YTD 2023 exclude $0.10 per share of after-tax charges consisting of: $0.06 of executive management transition costs at Corporate, $0.02 of CMT acquisition inventory step-up charges and $0.02 of restructuring charges within the A&D segment.

[0001104659-24-059341:8k_2_02:69]
| EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |  | YTD |  |  | YTD |  |
|  |  | YTD |  |  | YTD |  |  | Q2 2024 - |  |  | Q2 2023 - |  |
|  |  | Q2 2024 |  |  | Q2 2023 |  |  | As Adj |  |  | As Adj |  |
| Consolidated EBITDA |  | $ | 82,123 |  |  |  | 71,086 |  |  |  | 83,582 |  |  |  | 74,378 |  |
| Less: Depr & Amort |  |  | (27,555 | ) |  |  | (24,910 | ) |  |  | (26,719 | ) |  |  | (24,910 | ) |
| Consolidated EBIT |  |  | 54,568 |  |  |  | 46,176 |  |  |  | 56,863 |  |  |  | 49,468 |  |
| Less: Interest expense |  |  | (5,893 | ) |  |  | (3,927 | ) |  |  | (5,893 | ) |  |  | (3,927 | ) |
| Less: Income tax expense |  |  | (10,287 | ) |  |  | (9,644 | ) |  |  | (10,815 | ) |  |  | (10,401 | ) |
| Net earnings |  | $ | 38,388 |  |  |  | 32,605 |  |  |  | 40,155 |  |  |  | 35,140 |  |

[0001104659-24-059341:8k_2_02:70]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-059341:8k_2_02:71]
Condensed Consolidated Balance Sheets (Unaudited)

[0001104659-24-059341:8k_2_02:72]
(Dollars in thousands)

[0001104659-24-059341:8k_2_02:73]
|  |  | March 31, 2024 |  |  | September 30, 2023 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 59,436 |  |  |  | 41,866 |  |
| Accounts receivable, net |  |  | 187,535 |  |  |  | 198,557 |  |
| Contract assets |  |  | 139,303 |  |  |  | 138,633 |  |
| Inventories |  |  | 211,338 |  |  |  | 184,067 |  |
| Other current assets |  |  | 24,310 |  |  |  | 17,972 |  |
| Total current assets |  |  | 621,922 |  |  |  | 581,095 |  |
| Property, plant and equipment, net |  |  | 161,811 |  |  |  | 155,484 |  |
| Intangible assets, net |  |  | 414,872 |  |  |  | 392,124 |  |
| Goodwill |  |  | 535,661 |  |  |  | 503,177 |  |
| Operating lease assets |  |  | 38,322 |  |  |  | 39,839 |  |
| Other assets |  |  | 11,603 |  |  |  | 11,495 |  |
|  |  | $ | 1,784,191 |  |  |  | 1,683,214 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt |  | $ | 20,000 |  |  |  | 20,000 |  |
| Accounts payable |  |  | 81,961 |  |  |  | 86,973 |  |
| Contract liabilities |  |  | 107,357 |  |  |  | 112,277 |  |
| Other current liabilities |  |  | 79,612 |  |  |  | 95,401 |  |
| Total current liabilities |  |  | 288,930 |  |  |  | 314,651 |  |
| Deferred tax liabilities |  |  | 80,648 |  |  |  | 75,531 |  |
| Non-current operating lease liabilities |  |  | 35,444 |  |  |  | 36,554 |  |
| Other liabilities |  |  | 41,759 |  |  |  | 43,336 |  |
| Long-term debt |  |  | 171,000 |  |  |  | 82,000 |  |
| Shareholders' equity |  |  | 1,166,410 |  |  |  | 1,131,142 |  |
|  |  | $ | 1,784,191 |  |  |  | 1,683,214 |  |

[0001104659-24-059341:8k_2_02:74]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-059341:8k_2_02:75]
Consolidated Statements of Cash Flows (Unaudited)

[0001104659-24-059341:8k_2_02:76]
(Dollars in thousands)

[0001104659-24-059341:8k_2_02:77]
|  |  | Six Months Ended March 31, 2024 |  |  | Six Months Ended March 31, 2023 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 38,388 |  |  |  | 32,605 |  |
| Adjustments to reconcile net earnings to net cash |  |  |  |  |  |  |  |  |
| provided (used) by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 27,555 |  |  |  | 24,910 |  |
| Stock compensation expense |  |  | 4,144 |  |  |  | 5,309 |  |
| Changes in assets and liabilities |  |  | (47,869 | ) |  |  | (67,140 | ) |
| Effect of deferred taxes |  |  | (2,981 | ) |  |  | (1,145 | ) |
| Net cash provided (used) by operating activities |  |  | 19,237 |  |  |  | (5,461 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Acquisition of business, net of cash acquired |  |  | (56,179 | ) |  |  | (17,901 | ) |
| Capital expenditures |  |  | (16,301 | ) |  |  | (10,305 | ) |
| Additions to capitalized software |  |  | (5,912 | ) |  |  | (5,918 | ) |
| Net cash used by investing activities |  |  | (78,392 | ) |  |  | (34,124 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from long-term debt |  |  | 154,000 |  |  |  | 68,000 |  |
| Principal payments on long-term debt and short-term borrowings |  |  | (65,000 | ) |  |  | (60,000 | ) |
| Dividends paid |  |  | (4,125 | ) |  |  | (4,128 | ) |
| Purchases of common stock into treasury |  |  | (7,189 | ) |  |  | (12,217 | ) |
| Other |  |  | (1,432 | ) |  |  | (2,374 | ) |
| Net cash provided (used) by financing activities |  |  | 76,254 |  |  |  | (10,719 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 471 |  |  |  | 801 |  |
| Net increase (decrease) in cash and cash equivalents |  |  | 17,570 |  |  |  | (49,503 | ) |
| Cash and cash equivalents, beginning of period |  |  | 41,866 |  |  |  | 97,724 |  |
| Cash and cash equivalents, end of period |  | $ | 59,436 |  |  |  | 48,221 |  |

[0001104659-24-059341:8k_2_02:78]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-059341:8k_2_02:79]
Other Selected Financial Data (Unaudited)

[0001104659-24-059341:8k_2_02:80]
(Dollars in thousands)

[0001104659-24-059341:8k_2_02:81]
| Backlog And Entered Orders - Q2 2024 |  | A&D |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 1/1/24 |  | $ | 560,893 |  |  |  | 127,439 |  |  |  | 159,436 |  |  |  | 847,768 |  |
| Entered Orders |  |  | 116,110 |  |  |  | 79,025 |  |  |  | 43,937 |  |  |  | 239,072 |  |
| Sales |  |  | (114,701 | ) |  |  | (87,309 | ) |  |  | (47,119 | ) |  |  | (249,129 | ) |
| Ending Backlog - 3/31/24 |  | $ | 562,302 |  |  |  | 119,155 |  |  |  | 156,254 |  |  |  | 837,711 |  |

[0001104659-24-059341:8k_2_02:82]
| Backlog And Entered Orders - YTD Q2 2024 |  | A&D |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 10/1/23 |  | $ | 484,069 |  |  |  | 133,459 |  |  |  | 154,834 |  |  |  | 772,362 |  |
| Entered Orders |  |  | 287,667 |  |  |  | 155,989 |  |  |  | 89,136 |  |  |  | 532,792 |  |
| Sales |  |  | (209,434 | ) |  |  | (170,293 | ) |  |  | (87,716 | ) |  |  | (467,443 | ) |
| Ending Backlog - 3/31/24 |  | $ | 562,302 |  |  |  | 119,155 |  |  |  | 156,254 |  |  |  | 837,711 |  |

[0001104659-24-059341:8k_2_02:83]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-059341:8k_2_02:84]
Reconciliation of Non-GAAP Financial Measures (Unaudited)

[0001104659-24-059341:8k_2_02:85]
| EPS – Adjusted Basis Reconciliation – Q2 2024 |  |  |  |  |
| EPS – GAAP Basis – Q2 2024 |  | $ | 0.90 |  |
| Adjustments (defined below) |  |  | 0.04 |  |
| EPS – As Adjusted Basis – Q2 2024 |  | $ | 0.94 |  |
| Adjustments exclude $0.04 per share consisting of: $0.02 of MPE acquisition backlog charges and $0.02 of restructuring charges (primarily severance) within the Test and A&D segments in the second quarter of 2024. |  |  |  |  |
| The $0.04 of EPS adjustments per share consists of $1,251K of pre-tax charges offset by $288K of tax benefit for net impact of $963K. |  |  |  |  |
| EPS – Adjusted Basis Reconciliation – Q2 2023 |  |  |  |  |
| EPS – GAAP Basis – Q2 2023 |  | $ | 0.69 |  |
| Adjustments (defined below) |  |  | 0.07 |  |
| EPS – As Adjusted Basis – Q2 2023 |  | $ | 0.76 |  |
| Adjustments exclude $0.07 per share consisting of executive management transition costs at Corporate, CMT acquisition inventory step-up charges and restructuring charges within the A&D segment in the second quarter of 2023. |  |  |  |  |
| The $0.07 of EPS adjustments per share consists of $2,300K of pre-tax charges offset by $529K of tax benefit for net impact of $1,771K. |  |  |  |  |
| EPS – Adjusted Basis Reconciliation – YTD Q2 2024 |  |  |  |  |
| EPS – GAAP Basis – YTD Q2 2024 |  | $ | 1.49 |  |
| Adjustments (defined below) |  |  | 0.07 |  |
| EPS – As Adjusted Basis – YTD Q2 2024 |  | $ | 1.56 |  |
| Adjustments exclude $0.07 per share consisting of: $0.05 of MPE acquisition backlog and inventory step-up charges and acquisition costs, and $0.02 of restructuring charges (primarily severance) within the Test and A&D segments in the first six months of 2024. |  |  |  |  |
| The $0.07 of EPS adjustments per share consists of $2,295K of pre-tax charges offset by $528K of tax benefit for net impact of $1,767K. |  |  |  |  |
| EPS – Adjusted Basis Reconciliation – YTD Q2 2023 |  |  |  |  |
| EPS – GAAP Basis – YTD Q2 2023 |  | $ | 1.26 |  |
| Adjustments (defined below) |  |  | 0.10 |  |
| EPS – As Adjusted Basis – YTD Q2 2023 |  | $ | 1.36 |  |
| Adjustments exclude $0.10 per share consisting of executive management transition costs at Corporate, CMT acquisition inventory step-up charges and restructuring charges within the A&D segment in the first six months of 2023. |  |  |  |  |
| The $0.10 of EPS adjustments per share consists of $3,292K of pre-tax charges offset by $757K of tax benefit for net impact of $2,535K. |  |  |  |  |
