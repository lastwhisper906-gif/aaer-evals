# ESE note change history — 0001410578-24-000030 → 0001410578-24-000723


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-05-10):
[0001410578-24-000723:note_history:1]
The Company’s results for the three-month period ended March 31, 2024 are not necessarily indicative of the results for the entire 2024 fiscal year. References to the second quarters of 2024 and 2023 represent the fiscal quarters ended March 31, 2024 and 2023, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.
  (was, 2024-02-09, similarity 0.9616):
[0001410578-24-000030:note_history:1]
The Company’s results for the three-month period ended December 31, 2023 are not necessarily indicative of the results for the entire 2024 fiscal year. References to the first quarters of 2024 and 2023 represent the fiscal quarters ended December 31, 2023 and 2022, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-10):
[0001410578-24-000723:note_history:2]
| ​ |  | March 31, | ​ | September 30, |
| (In thousands) |  | 2024 |  | 2023 |
| Total borrowings | ​ | $ | 191,000 | ​ | 102,000 |
| Current portion of long-term debt | ​ | ​ | (20,000) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 171,000 | ​ | 82,000 |
  (was, 2024-02-09, similarity 0.9768):
[0001410578-24-000030:note_history:2]
| ​ |  | December 31, | ​ | September 30, |
| (In thousands) |  | 2023 |  | 2023 |
| Total borrowings | ​ | $ | 172,000 | ​ | 102,000 |
| Current portion of long-term debt | ​ | ​ | (20,000) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 152,000 | ​ | 82,000 |

- changed (2024-05-10):
[0001410578-24-000723:note_history:3]
At March 31, 2024, the Company had approximately $303 million available to borrow under the Credit Facility, plus the $250 million increase option subject to the lenders’ consent, in addition to $59.4 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of March 31, 2024, as the Company intends to repay this amount within the next twelve months; however, the Company no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $5.8 million at March 31, 2024.
  (was, 2024-02-09, similarity 0.9596):
[0001410578-24-000030:note_history:3]
At December 31, 2023, the Company had approximately $322 million available to borrow under the Credit Facility, plus the $250 million increase option subject to the lenders’ consent, in addition to $51.4 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of December 31, 2023, as the Company intends to repay this amount within the next twelve months; however, the Company no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $5.8 million at December 31, 2023.

- changed (2024-05-10):
[0001410578-24-000723:note_history:4]
Interest on borrowings under the Credit Facility is calculated at a spread over either an Adjusted Term SOFR Rate, Adjusted EURIBOR Rate, Adjusted CDOR Rate, Alternate Base Rate or Daily Simple RFR, at the Company’s election. The Credit Facility also requires a facility fee ranging from 12.5 to 25 basis points per annum on the unused portion. The interest rate spreads and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio. The weighted average interest rates were 6.8% and 6.8% for the three and six-month periods ending March 31, 2024, respectively, and 6.0% and 5.3% for the three and six-month periods ending March 31, 2023. As of March 31, 2024, the Company was in compliance with all covenants.
  (was, 2024-02-09, similarity 0.9074):
[0001410578-24-000030:note_history:4]
Interest on borrowings under the Credit Facility is calculated at a spread over either an Adjusted Term SOFR Rate, Adjusted EURIBOR Rate, Adjusted CDOR Rate, Alternate Base Rate or Daily Simple RFR, at the Company’s election. The Credit Facility also requires a facility fee ranging from 12.5 to 25 basis points per annum on the unused portion. The interest rate spreads and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio. The weighted average interest rates were 6.8% and 4.6% for the three-month periods ending December 31, 2023 and 2022, respectively. As of December 31, 2023, the Company was in compliance with all covenants.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-10):
[0001410578-24-000723:note_history:5]
| ​ |  | March 31, | ​ | September 30, |
| (In thousands) |  | 2024 |  | 2023 |
| Total borrowings | ​ | $ | 191,000 | ​ | 102,000 |
| Current portion of long-term debt | ​ | ​ | (20,000) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 171,000 | ​ | 82,000 |
  (was, 2024-02-09, similarity 0.9768):
[0001410578-24-000030:note_history:5]
| ​ |  | December 31, | ​ | September 30, |
| (In thousands) |  | 2023 |  | 2023 |
| Total borrowings | ​ | $ | 172,000 | ​ | 102,000 |
| Current portion of long-term debt | ​ | ​ | (20,000) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 152,000 | ​ | 82,000 |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-10):
[0001410578-24-000723:note_history:6]
| Three months ended March 31, 2024 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 49,382 | ​ | $ | 85,220 | ​ | $ | 34,537 | ​ | $ | 169,139 |
| Government | ​ | ​ | 65,319 | ​ | ​ | 2,089 | ​ | ​ | 12,582 | ​ | ​ | 79,990 |
| Total revenues | ​ | $ | 114,701 | ​ | $ | 87,309 | ​ | $ | 47,119 | ​ | $ | 249,129 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 92,161 | ​ | $ | 55,763 | ​ | $ | 27,543 | ​ | $ | 175,467 |
| International | ​ | ​ | 22,540 | ​ | ​ | 31,546 | ​ | ​ | 19,576 | ​ | ​ | 73,662 |
| Total revenues | ​ | $ | 114,701 | ​ | $ | 87,309 | ​ | $ | 47,119 | ​ | $ | 249,129 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 53,463 | ​ | $ | 70,285 | ​ | $ | 10,301 | ​ | $ | 134,049 |
| Over time | ​ | ​ | 61,238 | ​ | ​ | 17,024 | ​ | ​ | 36,818 | ​ | ​ | 115,080 |
| Total revenues | ​ | $ | 114,701 | ​ | $ | 87,309 | ​ | $ | 47,119 | ​ | $ | 249,129 |
  (was, 2024-02-09, similarity 0.9843):
[0001410578-24-000030:note_history:6]
| ​ | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 37,209 | ​ | $ | 81,469 | ​ | $ | 35,087 | ​ | $ | 153,765 |
| Government | ​ | ​ | 57,524 | ​ | ​ | 1,515 | ​ | ​ | 5,510 | ​ | ​ | 64,549 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 79,901 | ​ | $ | 55,961 | ​ | $ | 22,252 | ​ | $ | 158,114 |
| International | ​ | ​ | 14,832 | ​ | ​ | 27,023 | ​ | ​ | 18,345 | ​ | ​ | 60,200 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 39,465 | ​ | $ | 66,703 | ​ | $ | 7,980 | ​ | $ | 114,148 |
| Over time | ​ | ​ | 55,268 | ​ | ​ | 16,281 | ​ | ​ | 32,617 | ​ | ​ | 104,166 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |

- changed (2024-05-10):
[0001410578-24-000723:note_history:7]
| Six months ended March 31, 2024 |  | Aerospace |  |  | ​ |  |  | ​ |  |  | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 86,591 | ​ | $ | 166,689 | ​ | $ | 69,615 | ​ | $ | 322,895 |
| Government | ​ |  | 122,843 | ​ |  | 3,604 | ​ |  | 18,101 | ​ |  | 144,548 |
| Total revenues | ​ | $ | 209,434 | ​ | $ | 170,293 | ​ | $ | 87,716 | ​ | $ | 467,443 |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| United States | ​ | $ | 172,062 | ​ | $ | 111,725 | ​ | $ | 49,795 | ​ | $ | 333,582 |
| International | ​ |  | 37,372 | ​ |  | 58,568 | ​ |  | 37,921 | ​ |  | 133,861 |
| Total revenues | ​ | $ | 209,434 | ​ | $ | 170,293 | ​ | $ | 87,716 | ​ | $ | 467,443 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 92,928 | ​ | $ | 136,989 | ​ | $ | 18,280 | ​ | $ | 248,197 |
| Over time | ​ |  | 116,506 | ​ |  | 33,304 | ​ |  | 69,436 | ​ |  | 219,246 |
| Total revenues | ​ | $ | 209,434 | ​ | $ | 170,293 | ​ | $ | 87,716 | ​ | $ | 467,443 |
  (was, 2024-02-09, similarity 0.6618):
[0001410578-24-000030:note_history:7]
| ​ | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 36,740 | ​ | $ | 70,162 | ​ | $ | 45,992 | ​ | $ | 152,894 |
| Government | ​ | ​ | 46,243 | ​ | ​ | 883 | ​ | ​ | 5,481 | ​ | ​ | 52,607 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 68,934 | ​ | $ | 46,379 | ​ | $ | 27,503 | ​ | $ | 142,816 |
| International | ​ | ​ | 14,049 | ​ | ​ | 24,666 | ​ | ​ | 23,970 | ​ | ​ | 62,685 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 33,604 | ​ | $ | 56,031 | ​ | $ | 9,101 | ​ | $ | 98,736 |
| Over time | ​ | ​ | 49,379 | ​ | ​ | 15,014 | ​ | ​ | 42,372 | ​ | ​ | 106,765 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |

- added (2024-05-10):
[0001410578-24-000723:note_history:8]
| Three months ended March 31, 2023 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 48,228 | ​ | $ | 78,110 | ​ | $ | 43,188 | ​ | $ | 169,526 |
| Government | ​ | ​ | 50,754 | ​ | ​ | 1,051 | ​ | ​ | 7,805 | ​ | ​ | 59,610 |
| Total revenues | ​ | $ | 98,982 | ​ | $ | 79,161 | ​ | $ | 50,993 | ​ | $ | 229,136 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 82,516 | ​ | $ | 53,020 | ​ | $ | 27,504 | ​ | $ | 163,040 |
| International | ​ | ​ | 16,466 | ​ | ​ | 26,141 | ​ | ​ | 23,489 | ​ | ​ | 66,096 |
| Total revenues | ​ | $ | 98,982 | ​ | $ | 79,161 | ​ | $ | 50,993 | ​ | $ | 229,136 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 47,255 | ​ | $ | 64,080 | ​ | $ | 11,968 | ​ | $ | 123,303 |
| Over time | ​ | ​ | 51,727 | ​ | ​ | 15,081 | ​ | ​ | 39,025 | ​ | ​ | 105,833 |
| Total revenues | ​ | $ | 98,982 | ​ | $ | 79,161 | ​ | $ | 50,993 | ​ | $ | 229,136 |

- added (2024-05-10):
[0001410578-24-000723:note_history:9]
| Six months ended March 31, 2023 |  | Aerospace |  |  | ​ |  |  | ​ |  |  | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 84,968 | ​ | $ | 148,273 | ​ | $ | 89,180 | ​ | $ | 322,421 |
| Government | ​ |  | 96,997 | ​ |  | 1,933 | ​ |  | 13,286 | ​ |  | 112,216 |
| Total revenues | ​ | $ | 181,965 | ​ | $ | 150,206 | ​ | $ | 102,466 | ​ | $ | 434,637 |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| United States | ​ | $ | 151,450 | ​ | $ | 99,399 | ​ | $ | 55,007 | ​ | $ | 305,856 |
| International | ​ |  | 30,515 | ​ |  | 50,807 | ​ |  | 47,459 | ​ |  | 128,781 |
| Total revenues | ​ | $ | 181,965 | ​ | $ | 150,206 | ​ | $ | 102,466 | ​ | $ | 434,637 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 80,859 | ​ | $ | 120,111 | ​ | $ | 21,069 | ​ | $ | 222,039 |
| Over time | ​ |  | 101,106 | ​ |  | 30,095 | ​ |  | 81,397 | ​ |  | 212,598 |
| Total revenues | ​ | $ | 181,965 | ​ | $ | 150,206 | ​ | $ | 102,466 | ​ | $ | 434,637 |

- removed (2024-05-10):
[0001410578-24-000030:note_history:10]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2023 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within each reportable segment.

- removed (2024-05-10):
[0001410578-24-000030:note_history:11]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2022 are presented in the table below:


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-10):
[0001410578-24-000723:note_history:12]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2024 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue within each reportable segment.
  (was, 2024-02-09, similarity 0.953):
[0001410578-24-000030:note_history:12]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2023 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within each reportable segment.

- changed (2024-05-10):
[0001410578-24-000723:note_history:13]
| Three months ended March 31, 2024 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 49,382 | ​ | $ | 85,220 | ​ | $ | 34,537 | ​ | $ | 169,139 |
| Government | ​ | ​ | 65,319 | ​ | ​ | 2,089 | ​ | ​ | 12,582 | ​ | ​ | 79,990 |
| Total revenues | ​ | $ | 114,701 | ​ | $ | 87,309 | ​ | $ | 47,119 | ​ | $ | 249,129 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 92,161 | ​ | $ | 55,763 | ​ | $ | 27,543 | ​ | $ | 175,467 |
| International | ​ | ​ | 22,540 | ​ | ​ | 31,546 | ​ | ​ | 19,576 | ​ | ​ | 73,662 |
| Total revenues | ​ | $ | 114,701 | ​ | $ | 87,309 | ​ | $ | 47,119 | ​ | $ | 249,129 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 53,463 | ​ | $ | 70,285 | ​ | $ | 10,301 | ​ | $ | 134,049 |
| Over time | ​ | ​ | 61,238 | ​ | ​ | 17,024 | ​ | ​ | 36,818 | ​ | ​ | 115,080 |
| Total revenues | ​ | $ | 114,701 | ​ | $ | 87,309 | ​ | $ | 47,119 | ​ | $ | 249,129 |
  (was, 2024-02-09, similarity 0.9843):
[0001410578-24-000030:note_history:13]
| ​ | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 37,209 | ​ | $ | 81,469 | ​ | $ | 35,087 | ​ | $ | 153,765 |
| Government | ​ | ​ | 57,524 | ​ | ​ | 1,515 | ​ | ​ | 5,510 | ​ | ​ | 64,549 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 79,901 | ​ | $ | 55,961 | ​ | $ | 22,252 | ​ | $ | 158,114 |
| International | ​ | ​ | 14,832 | ​ | ​ | 27,023 | ​ | ​ | 18,345 | ​ | ​ | 60,200 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 39,465 | ​ | $ | 66,703 | ​ | $ | 7,980 | ​ | $ | 114,148 |
| Over time | ​ | ​ | 55,268 | ​ | ​ | 16,281 | ​ | ​ | 32,617 | ​ | ​ | 104,166 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |

- changed (2024-05-10):
[0001410578-24-000723:note_history:14]
| Six months ended March 31, 2024 |  | Aerospace |  |  | ​ |  |  | ​ |  |  | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 86,591 | ​ | $ | 166,689 | ​ | $ | 69,615 | ​ | $ | 322,895 |
| Government | ​ |  | 122,843 | ​ |  | 3,604 | ​ |  | 18,101 | ​ |  | 144,548 |
| Total revenues | ​ | $ | 209,434 | ​ | $ | 170,293 | ​ | $ | 87,716 | ​ | $ | 467,443 |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| United States | ​ | $ | 172,062 | ​ | $ | 111,725 | ​ | $ | 49,795 | ​ | $ | 333,582 |
| International | ​ |  | 37,372 | ​ |  | 58,568 | ​ |  | 37,921 | ​ |  | 133,861 |
| Total revenues | ​ | $ | 209,434 | ​ | $ | 170,293 | ​ | $ | 87,716 | ​ | $ | 467,443 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 92,928 | ​ | $ | 136,989 | ​ | $ | 18,280 | ​ | $ | 248,197 |
| Over time | ​ |  | 116,506 | ​ |  | 33,304 | ​ |  | 69,436 | ​ |  | 219,246 |
| Total revenues | ​ | $ | 209,434 | ​ | $ | 170,293 | ​ | $ | 87,716 | ​ | $ | 467,443 |
  (was, 2024-02-09, similarity 0.6618):
[0001410578-24-000030:note_history:14]
| ​ | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 36,740 | ​ | $ | 70,162 | ​ | $ | 45,992 | ​ | $ | 152,894 |
| Government | ​ | ​ | 46,243 | ​ | ​ | 883 | ​ | ​ | 5,481 | ​ | ​ | 52,607 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 68,934 | ​ | $ | 46,379 | ​ | $ | 27,503 | ​ | $ | 142,816 |
| International | ​ | ​ | 14,049 | ​ | ​ | 24,666 | ​ | ​ | 23,970 | ​ | ​ | 62,685 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 33,604 | ​ | $ | 56,031 | ​ | $ | 9,101 | ​ | $ | 98,736 |
| Over time | ​ | ​ | 49,379 | ​ | ​ | 15,014 | ​ | ​ | 42,372 | ​ | ​ | 106,765 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |

- changed (2024-05-10):
[0001410578-24-000723:note_history:15]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2023 are presented in the tables below.
  (was, 2024-02-09, similarity 0.935):
[0001410578-24-000030:note_history:15]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2022 are presented in the table below:

- added (2024-05-10):
[0001410578-24-000723:note_history:16]
| Three months ended March 31, 2023 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 48,228 | ​ | $ | 78,110 | ​ | $ | 43,188 | ​ | $ | 169,526 |
| Government | ​ | ​ | 50,754 | ​ | ​ | 1,051 | ​ | ​ | 7,805 | ​ | ​ | 59,610 |
| Total revenues | ​ | $ | 98,982 | ​ | $ | 79,161 | ​ | $ | 50,993 | ​ | $ | 229,136 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 82,516 | ​ | $ | 53,020 | ​ | $ | 27,504 | ​ | $ | 163,040 |
| International | ​ | ​ | 16,466 | ​ | ​ | 26,141 | ​ | ​ | 23,489 | ​ | ​ | 66,096 |
| Total revenues | ​ | $ | 98,982 | ​ | $ | 79,161 | ​ | $ | 50,993 | ​ | $ | 229,136 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 47,255 | ​ | $ | 64,080 | ​ | $ | 11,968 | ​ | $ | 123,303 |
| Over time | ​ | ​ | 51,727 | ​ | ​ | 15,081 | ​ | ​ | 39,025 | ​ | ​ | 105,833 |
| Total revenues | ​ | $ | 98,982 | ​ | $ | 79,161 | ​ | $ | 50,993 | ​ | $ | 229,136 |

- added (2024-05-10):
[0001410578-24-000723:note_history:17]
| Six months ended March 31, 2023 |  | Aerospace |  |  | ​ |  |  | ​ |  |  | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 84,968 | ​ | $ | 148,273 | ​ | $ | 89,180 | ​ | $ | 322,421 |
| Government | ​ |  | 96,997 | ​ |  | 1,933 | ​ |  | 13,286 | ​ |  | 112,216 |
| Total revenues | ​ | $ | 181,965 | ​ | $ | 150,206 | ​ | $ | 102,466 | ​ | $ | 434,637 |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| United States | ​ | $ | 151,450 | ​ | $ | 99,399 | ​ | $ | 55,007 | ​ | $ | 305,856 |
| International | ​ |  | 30,515 | ​ |  | 50,807 | ​ |  | 47,459 | ​ |  | 128,781 |
| Total revenues | ​ | $ | 181,965 | ​ | $ | 150,206 | ​ | $ | 102,466 | ​ | $ | 434,637 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 80,859 | ​ | $ | 120,111 | ​ | $ | 21,069 | ​ | $ | 222,039 |
| Over time | ​ |  | 101,106 | ​ |  | 30,095 | ​ |  | 81,397 | ​ |  | 212,598 |
| Total revenues | ​ | $ | 181,965 | ​ | $ | 150,206 | ​ | $ | 102,466 | ​ | $ | 434,637 |

- added (2024-05-10):
[0001410578-24-000723:note_history:18]
Payment terms with our customers vary by the type and location of the customer and the products or services offered. Arrangements with customers that include payment terms extending beyond one year are not significant. The transaction price for

- changed (2024-05-10):
[0001410578-24-000723:note_history:19]
these contracts reflects our estimate of returns and discounts, which are based on historical, current and forecasted information to determine the expected amount to which we will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation. Under the typical payment terms of our long term fixed price contracts, the customer pays us either performance-based or progress payments. Performance-based payments represent interim payments based on quantifiable measures of performance or on the achievement of specified events or milestones. Progress payments are interim payments of costs incurred as the work progresses.
  (was, 2024-02-09, similarity 0.8997):
[0001410578-24-000030:note_history:19]
Payment terms with our customers vary by the type and location of the customer and the products or services offered. Arrangements with customers that include payment terms extending beyond one year are not significant. The transaction price for these contracts reflects our estimate of returns and discounts, which are based on historical, current and forecasted information to determine the expected amount to which we will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation. Under the typical payment terms of our long term fixed price contracts, the customer pays us either performance-based or progress payments. Performance-based payments represent interim payments based on quantifiable measures of performance or on the achievement of specified events or milestones. Progress payments are interim payments of costs incurred as the work progresses.

- changed (2024-05-10):
[0001410578-24-000723:note_history:20]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At March 31, 2024, the Company had $837.7 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 70% in the next twelve months.
  (was, 2024-02-09, similarity 0.9907):
[0001410578-24-000030:note_history:20]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At December 31, 2023, the Company had $847.8 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 66% in the next twelve months.

- changed (2024-05-10):
[0001410578-24-000723:note_history:21]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At March 31, 2024, contract assets, contract liabilities and accounts receivable totaled $139.3 million, $117.8 million and $187.5 million, respectively. During the first six months of 2024, the Company recognized approximately $44 million in revenues that were included in the contract liabilities balance at September 30, 2023. At September 30, 2023, contract assets, contract liabilities and accounts receivable totaled $138.6 million, $123.1 million and $198.6 million, respectively.
  (was, 2024-02-09, similarity 0.9742):
[0001410578-24-000030:note_history:21]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At December 31, 2023, contract assets, contract liabilities and accounts receivable totaled $138.4 million, $131.9 million and $194.4 million, respectively. During the first quarter of 2024, the Company recognized approximately $24.4 million in revenues that were included in the contract liabilities balance at September 30, 2023. At September 30, 2023, contract assets, contract liabilities and accounts receivable totaled $138.6 million, $123.1 million and $198.6 million, respectively.
