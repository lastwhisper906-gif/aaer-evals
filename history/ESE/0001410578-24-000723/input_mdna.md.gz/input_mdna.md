# ESE MD&A — 0001410578-24-000723


## mdna

[0001410578-24-000723:mdna:1]
[same as prior period, unchanged from 0001410578-24-000030:mdna:1]

[0001410578-24-000723:mdna:2]
[same as prior period, unchanged from 0001410578-24-000030:mdna:2]

[0001410578-24-000723:mdna:3]
References to the second quarters of 2024 and 2023 represent the three-month periods ended March 31, 2024 and 2023, respectively.

[0001410578-24-000723:mdna:4]
[same as prior period, unchanged from 0001410578-24-000030:mdna:4]

[0001410578-24-000723:mdna:5]
In the second quarter of 2024, sales, net earnings and diluted earnings per share were $249.1 million, $23.2 million and $0.90 per share, respectively, compared to $229.1 million, $17.9 million and $0.69 per share, respectively, in the second quarter of 2023. In the first six months of 2024, sales, net earnings and diluted earnings per share were $467.4 million, $38.4 million and $1.49 per share, respectively, compared to $434.6 million, $32.6 million and $1.26 per share, respectively, in the first six months of 2023.

[0001410578-24-000723:mdna:6]
[same as prior period, unchanged from 0001410578-24-000030:mdna:6]

[0001410578-24-000723:mdna:7]
In the second quarter of 2024, net sales of $249.1 million were $20.0 million, or 8.7%, higher than the $229.1 million in the second quarter of 2023. In the first six months of 2024, net sales of $467.4 million were $32.8 million, or 7.5%, higher than the $434.6 million in the first six months of 2023. The increase in net sales in the second quarter of 2024 as compared to the second quarter of 2023 was due to a $15.7 million increase in the A&D segment and an $8.1 million increase in the USG segment, partially offset by a $3.9 million decrease in the Test segment. The increase in net sales in the first six months of 2024 as compared to the first six months of 2023 was due to a $27.4 million increase in the Aerospace & Defense segment, and a $20.1 million increase in the USG segment, partially offset by a $14.8 million decrease in the Test segment.

[0001410578-24-000723:mdna:8]
[same as prior period, unchanged from 0001410578-24-000030:mdna:8]

[0001410578-24-000723:mdna:9]
In the second quarter of 2024, net sales of $114.7 million were $15.7 million, or 15.9%, higher than the $99.0 million in the second quarter of 2023. In the first six months of 2024, net sales of $209.4 million were $27.4 million, or 15.1%, higher than the $182.0 million in the first six months of 2023. The sales increase in the second quarter of 2024 compared to the second quarter of 2023 was mainly due to a $5.1 million increase in commercial aerospace shipments, a $3.1 million increase in defense aerospace shipments and a $7.1 million increase in navy revenues. The sales increase in the first six months of 2024 compared to the first six months of 2023 was mainly due to a $7.8 million increase in commercial aerospace shipments, a $5.9 million increase in defense aerospace shipments and a $10.0 million increase in navy revenues.

[0001410578-24-000723:mdna:10]
[same as prior period, unchanged from 0001410578-24-000030:mdna:10]

[0001410578-24-000723:mdna:11]
In the second quarter of 2024, net sales of $87.3 million were $8.1 million, or 10.2%, higher than the $79.2 million in the second quarter of 2023. In the first six months of 2024, net sales of $170.3 million were $20.1 million, or 13.4%, higher than the $150.2 million in the first six months of 2023. The increase in the second quarter and first six months of 2024 compared to the corresponding periods of 2023 was mainly due to an increase in service revenue and cybersecurity/compliance (DUCe) revenue and an increase in net sales at NRG driven by continued strength in the renewables end-market, primarily solar.

[0001410578-24-000723:mdna:12]
[same as prior period, unchanged from 0001410578-24-000030:mdna:12]

[0001410578-24-000723:mdna:13]
In the second quarter of 2024, net sales of $47.1 million were $3.9 million, or 7.6%, lower than the $51.0 million in the second quarter of 2023. In the first six months of 2024, net sales of $87.7 million were $14.8 million, or 14.4%, lower than the $102.5 million in the first six months of 2023. The decrease in the second quarter of 2024 as compared to the second quarter of 2023 was primarily due to a $5.2 million decrease in sales from the Company’s U.S. and European operations due to lower wireless, filters and acoustic volumes partially offset by a $1.3 million increase in sales from the segment’s Asian operations. The decrease in the first six months of 2024 compared to the first six months of 2023 was due to a $11.3 million decrease in sales from the Company’s U.S. operations, a $2.8 million decrease in sales from the Company’s European operations and a $0.7 million decrease in sales from the Company’s Asian operations due to lower wireless, filters and acoustic volumes and timing of test and measurement chamber projects.

[0001410578-24-000723:mdna:14]
[same as prior period, unchanged from 0001410578-24-000030:mdna:14]

[0001410578-24-000723:mdna:15]
Backlog was $837.7 million at March 31, 2024 compared with $772.4 million at September 30, 2023. The Company received new orders totaling $239.1 million in the second quarter of 2024 compared to $251.6 million in the second quarter of 2023. Of the new orders received in the second quarter of 2024, $116.1 million related to Aerospace & Defense products, $79.0 million related to USG products, and $43.9 million related to Test products. Of the new orders received in the second quarter of 2023, $111.7 million related

[0001410578-24-000723:mdna:16]
to Aerospace & Defense products (including $7 million of acquired backlog from the 2023 acquisition of CMT), $84.6 million related to USG products, and $55.3 million related to Test products.

[0001410578-24-000723:mdna:17]
The Company received new orders totaling $532.8 million in the first six months of 2024 compared to $480.5 million in the first six months of 2023. Of the new orders received in the first six months of 2024, $287.7 million related to Aerospace & Defense products, $156.0 million related to USG products, and $89.1 million related to Test products. Of the new orders received in the first six months of 2023, $208.9 million related to Aerospace & Defense products, $164.8 million related to USG products, and $106.8 million related to Test products.

[0001410578-24-000723:mdna:18]
[same as prior period, unchanged from 0001410578-24-000030:mdna:16]

[0001410578-24-000723:mdna:19]
Selling, general and administrative (SG&A) expenses for the second quarter of 2024 were $55.1 million (22.1% of net sales), compared with $53.9 million (23.5% of net sales) for the second quarter of 2023. For the first six months of 2024, SG&A expenses were $109.1 million (23.3% of net sales) compared to $105.2 million (24.2% of net sales) for the first six months of 2023. The increase in SG&A in the second quarter and first six months of 2024 compared to the corresponding periods of 2023 was mainly due to an increase within the USG and A&D segments due to higher sales, inflationary impacts and acquisition impacts.

[0001410578-24-000723:mdna:20]
[same as prior period, unchanged from 0001410578-24-000030:mdna:18]

[0001410578-24-000723:mdna:21]
Amortization of intangible assets was $8.6 million and $16.4 million for the second quarter and first six months of 2024, respectively, compared to $7.0 million and $13.9 million for the corresponding periods of 2023. Amortization expenses consist of amortization of acquired intangible assets from acquisitions and other identifiable intangible assets (primarily software). The increase in amortization expense in the second quarter and first six months of 2024 compared to the corresponding periods of 2023 was mainly due to an increase in amortization of capitalized software and amortization of intangible assets related to the MPE and CMT acquisitions.

[0001410578-24-000723:mdna:22]
OTHER EXPENSES (INCOME), NET

[0001410578-24-000723:mdna:23]
Other expenses, net, was $0.7 million in the second quarter of 2024 compared to $0.3 million of expenses in the second quarter of 2023. Other expenses, net, was $0.9 million in the first six months of 2024 compared to $0.7 million of expenses in the first six months of 2023. The principal component of other expenses, net, in the second quarter and first six months of 2024 was approximately $0.5 million of restructuring charges (primarily severance) within the Test and A&D segments. There were no individually significant items in other expenses, net, in the second quarter or first six months of 2023.

[0001410578-24-000723:mdna:24]
[same as prior period, unchanged from 0001410578-24-000030:mdna:23]

[0001410578-24-000723:mdna:25]
The Company evaluates the performance of its operating segments based on EBIT, and provides EBIT on a consolidated basis. EBIT is a non-GAAP financial measure. Please refer to the discussion of non-GAAP financial measures in Note 7 to the Consolidated Financial Statements, above. EBIT was $32.4 million (13.0% of net sales) for the second quarter of 2024 compared to $25.6 million (11.2% of net sales) for the second quarter of 2023. For the first six months of 2024, EBIT was $54.6 million (11.7% of net sales) compared to $46.2 million (10.6% of net sales) for the first six months of 2023.

[0001410578-24-000723:mdna:26]
The following table presents a reconciliation of EBIT to net earnings.

[0001410578-24-000723:mdna:27]
| ​ | ​ | Three Months Ended | ​ | Six Months Ended |
| ​ | ​ | March 31, | ​ | March 31, |
| (In thousands) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net earnings | ​ | $ | 23,219 | ​ | ​ | 17,878 | ​ | 38,388 | ​ | 32,605 |
| Plus: Interest expense, net | ​ | ​ | 3,226 | ​ | ​ | 2,269 | ​ | 5,893 | ​ | 3,927 |
| Plus: Income tax expense | ​ | ​ | 6,002 | ​ | ​ | 5,472 | ​ | 10,287 | ​ | 9,644 |
| Consolidated EBIT | ​ | $ | 32,447 | ​ | ​ | 25,619 | ​ | 54,568 | ​ | 46,176 |

[0001410578-24-000723:mdna:28]
[same as prior period, unchanged from 0001410578-24-000030:mdna:27]

[0001410578-24-000723:mdna:29]
EBIT in the second quarter of 2024 was $23.4 million (20.4% of net sales) compared to $18.8 million (19.0% of net sales) in the second quarter of 2023. EBIT in the first six months of 2024 was $40.0 million (19.1% of net sales) compared to $31.3 million (17.2% of net sales) in the first six months of 2023. The increase in EBIT in the second quarter and first six months of 2024 compared to the corresponding periods of 2023 was mainly driven by leverage on higher sales volumes and price increases, partially offset by inflationary pressures and mix. EBIT was negatively impacted by $0.3 million of restructuring charges (primarily severance) in the

[0001410578-24-000723:mdna:30]
second quarter and first six months of 2024. EBIT in the second quarter of 2023 was negatively impacted by a $0.6 million inventory step-up charge related to the CMT acquisition.

[0001410578-24-000723:mdna:31]
[same as prior period, unchanged from 0001410578-24-000030:mdna:29]

[0001410578-24-000723:mdna:32]
EBIT in the second quarter of 2024 was $17.6 million (20.2% of net sales) compared to $14.1 million (17.8% of net sales) in the second quarter of 2023. EBIT in the first six months of 2024 was $35.2 million (20.7% of net sales) compared to $30.2 million (20.1% of net sales) in the first six months of 2023. The increase in EBIT in the second quarter and first six months of 2024 compared to the corresponding periods of 2023 was mainly due to leverage on higher sales volumes at Doble and NRG, price increases and mix, partially offset by inflationary pressures.

[0001410578-24-000723:mdna:33]
[same as prior period, unchanged from 0001410578-24-000030:mdna:31]

[0001410578-24-000723:mdna:34]
EBIT in the second quarter of 2024 was $5.5 million (11.7% of net sales) compared to $7.2 million (14.2% of net sales) in the second quarter of 2023. EBIT in the first six months of 2024 was $7.3 million (8.3% of net sales) compared to $12.6 million (12.3% of net sales) in the first six months of 2023. The decrease in EBIT in the second quarter and first six months of 2024 compared to the corresponding periods of 2023 was primarily due to lower sales volumes mainly from the segment’s U.S and European operations and inflationary pressures partially offset by price increases and cost reduction actions. In addition, EBIT was negatively impacted by $0.2 million of restructuring charges (primarily severance) in the second quarter of 2024. In the first six months of 2024, EBIT was negatively impacted by $0.3 million of inventory step-up charges related to the MPE acquisition and $0.2 million of restructuring charges.

[0001410578-24-000723:mdna:35]
[same as prior period, unchanged from 0001410578-24-000030:mdna:33]

[0001410578-24-000723:mdna:36]
Corporate costs included in EBIT were $14.0 million and $28.0 million in the second quarter and first six months of 2024, respectively, compared to $14.5 million and $28.0 million in the corresponding periods of 2023. The decrease in Corporate costs in the second quarter of 2024 as compared to the prior year quarter was mainly due to executive management transition costs that were incurred in the prior year period.

[0001410578-24-000723:mdna:37]
[same as prior period, unchanged from 0001410578-24-000030:mdna:35]

[0001410578-24-000723:mdna:38]
Interest expense was $3.2 million and $5.9 million in the second quarter and first six months of 2024, respectively, and $2.3 million and $3.9 million in the corresponding periods of 2023. The increase in interest expense in the second quarter and first six months of 2024 compared to the corresponding periods of 2023 was mainly due to higher average interest rates and higher average outstanding borrowings. The weighted average interest rates were 6.8% and 6.8% for the three and six-month periods ending March 31, 2024, respectively, and 6.0% and 6.3% for the three and six-month periods ending March 31, 2023.

[0001410578-24-000723:mdna:39]
[same as prior period, unchanged from 0001410578-24-000030:mdna:37]

[0001410578-24-000723:mdna:40]
The second quarter 2024 effective income tax rate was 20.5% compared to 23.4% in the second quarter of 2023. The effective income tax rate in the first six months of 2024 was 21.1% compared to 22.8% for the first six months of 2023. Income tax expense in the second quarter and first six months of 2024 was favorably impacted by discrete events including the release of a foreign valuation allowance and excess tax benefit related to the vesting of share-based director compensation.

[0001410578-24-000723:mdna:41]
[same as prior period, unchanged from 0001410578-24-000030:mdna:39]

[0001410578-24-000723:mdna:42]
The Company’s overall financial position and liquidity remains strong. Working capital (current assets less current liabilities) increased to $333.0 million at March 31, 2024 from $266.4 million at September 30, 2023. Inventories increased by $27.3 million during this period due to a $13.9 million increase within the Aerospace & Defense segment, a $10.6 million increase within the USG segment and a $2.8 million increase within the Test segment resulting primarily from the timing of receipt of raw materials to meet anticipated demand and an increase in work in process inventories due to timing of manufacturing existing orders. Accrued salaries decreased by $9.2 million during this period due to timing of salaries and bonus payments.

[0001410578-24-000723:mdna:43]
Net cash provided (used) by operating activities was $19.2 million and ($5.5) million in the first six months of 2024 and 2023, respectively. The increase in net cash provided by operating activities in the first six months of 2024 as compared to the first six months of 2023 was mainly driven by lower accounts receivable balances due to an increase in collections and higher earnings.

[0001410578-24-000723:mdna:44]
Capital expenditures were $16.3 million and $10.3 million in the first six months of 2024 and 2023, respectively. The increase in the first six months of 2024 compared to the prior year period was mainly due to an increase in building improvements and machinery & equipment within the A&D segment. In addition, the Company incurred expenditures for capitalized software of $5.9 million and $5.9 million in the first six months of 2024 and 2023, respectively.

[0001410578-24-000723:mdna:45]
[same as prior period, unchanged from 0001410578-24-000030:mdna:43]

[0001410578-24-000723:mdna:46]
[same as prior period, unchanged from 0001410578-24-000030:mdna:44]

[0001410578-24-000723:mdna:47]
Credit Facility

[0001410578-24-000723:mdna:48]
At March 31, 2024, the Company had approximately $303 million available to borrow under its bank credit facility, a $250 million increase option, and $59.4 million cash on hand. At March 31, 2024, the Company had $191 million of outstanding borrowings under the credit facility in addition to outstanding letters of credit of $5.8 million. Cash flow from operations and borrowings under the Company’s credit facility are expected to meet the Company’s capital requirements and operational needs for the foreseeable future. The Company’s ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.

[0001410578-24-000723:mdna:49]
Share Repurchases

[0001410578-24-000723:mdna:50]
During the first six months of 2024, the Company repurchased approximately 72,000 shares for approximately $7.2 million. For further information on the share repurchases during the second quarter of 2024, see Part II, Item 2 of this Report.

[0001410578-24-000723:mdna:51]
[same as prior period, unchanged from 0001410578-24-000030:mdna:47]

[0001410578-24-000723:mdna:52]
A dividend of $0.08 per share, totaling $2.1 million, was paid on October 17, 2023 to stockholders of record as of October 3, 2023. A dividend of $0.08 per share, totaling $2.1 million, was paid on January 19, 2024 to stockholders of record as of January 4, 2024. Subsequent to March 31, 2024, a quarterly dividend of $0.08 per share, totaling $2.1 million, was paid on April 16, 2024 to stockholders of record as of April 1, 2024.

[0001410578-24-000723:mdna:53]
[same as prior period, unchanged from 0001410578-24-000030:mdna:49]

[0001410578-24-000723:mdna:54]
[same as prior period, unchanged from 0001410578-24-000030:mdna:50]

[0001410578-24-000723:mdna:55]
[same as prior period, unchanged from 0001410578-24-000030:mdna:51]

[0001410578-24-000723:mdna:56]
Contingencies

[0001410578-24-000723:mdna:57]
As a normal incident of the business in which the Company is engaged, various claims, charges and litigation are asserted or commenced against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. In the opinion of Management, the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company, are adequately reserved, are covered by insurance, or would not have a material adverse effect on the Company’s results from operations, capital expenditures, or competitive position.

[0001410578-24-000723:mdna:58]
[same as prior period, unchanged from 0001410578-24-000030:mdna:54]

[0001410578-24-000723:mdna:59]
Statements contained in this Form 10-Q regarding future events and the Company’s future results that reflect or are based on current expectations, estimates, forecasts, projections or assumptions about the Company’s performance and the industries in which the

[0001410578-24-000723:mdna:60]
Investors are cautioned that such statements are only predictions and speak only as of the date of this Form 10-Q, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment, including but not limited to those described in Item 1A, “Risk Factors,” of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2023, and the following: the impacts of climate change and related regulation of greenhouse gases; the impacts of labor disputes, civil disorder, wars, elections, political changes, tariffs and trade disputes, terrorist activities, cyberattacks or natural disasters on the Company’s operations and those of the Company’s customers and suppliers; disruptions in manufacturing or delivery arrangements due to shortages or unavailability of materials or components; or supply chain disruptions; inability to access work sites; the timing and content of future contract awards or customer orders; the timely appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer contracts or orders; weakening of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties or data breaches; the availability of selected acquisitions; delivery delays or defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability of certain raw materials; material changes in the cost of credit; changes in laws and regulations including but not limited to changes in accounting standards and taxation; changes in interest, inflation and employment rates; costs relating to environmental matters arising from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the integration and performance of recently acquired businesses.

[0001410578-24-000723:mdna:61]
21
