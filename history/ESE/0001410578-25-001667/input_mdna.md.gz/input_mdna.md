# ESE MD&A — 0001410578-25-001667


## mdna

[0001410578-25-001667:mdna:1]
[same as prior period, unchanged from 0001410578-25-001145:mdna:1]

[0001410578-25-001667:mdna:2]
[same as prior period, unchanged from 0001410578-25-001145:mdna:2]

[0001410578-25-001667:mdna:3]
The following discussion refers to the Company’s results from continuing operations, except where noted. In the third quarter of 2025, the Company announced it had entered into a definitive agreement to sell VACCO Industries (VACCO) to RBC Bearings Incorporated. This transaction was completed subsequent to June 30, 2025, on July 18, 2025. VACCO is reflected as discontinued operations and/or assets held for sale in the financial statements and related notes for all periods shown. References to the third quarters of 2025 and 2024 represent the three-month periods ended June 30, 2025 and 2024, respectively.

[0001410578-25-001667:mdna:4]
[same as prior period, unchanged from 0001410578-25-001145:mdna:4]

[0001410578-25-001667:mdna:5]
In the third quarter of 2025, sales, net earnings and diluted earnings per share from continuing operations were $296.3 million, $24.8 million and $0.96 per share, respectively, compared to $233.6 million, $28.3 million and $1.10 per share, respectively, in the third quarter of 2024. In the first nine months of 2025, sales, net earnings and diluted earnings per share were $742.7 million, $71.4 million and $2.76 per share, respectively, compared to $645.6 million, $63.3 million and $2.46 per share, respectively, in the first nine months of 2024.

[0001410578-25-001667:mdna:6]
[same as prior period, unchanged from 0001410578-25-001145:mdna:6]

[0001410578-25-001667:mdna:7]
In the third quarter of 2025, net sales of $296.3 million were $62.7 million, or 26.8%, higher than the $233.6 million in the third quarter of 2024. In the first nine months of 2025, net sales of $742.7 million were $97.1 million, or 15.0%, higher than the $645.6 million in the first nine months of 2024. The increase in net sales in the third quarter of 2025 as compared to the third quarter of 2024 was due to a $49.0 million increase in the A&D segment, a $11.6 million increase in the Test segment and a $2.1 million increase in the USG segment. The increase in net sales in the first nine months of 2025 as compared to the first nine months of 2024 was due to a $66.5 million increase in the A&D segment, a $21.4 million increase in the Test segment and a $9.2 million increase in the USG segment.

[0001410578-25-001667:mdna:8]
[same as prior period, unchanged from 0001410578-25-001145:mdna:8]

[0001410578-25-001667:mdna:9]
In the third quarter of 2025, net sales of $136.3 million were $49.1 million, or 56.3%, higher than the $87.2 million in the third quarter of 2024. In the first nine months of 2025, net sales of $307.8 million were $66.5 million, or 27.6%, higher than the $241.3 million in the first nine months of 2024. The sales increase in the third quarter of 2025 compared to the third quarter of 2024 was mainly due to a $34.3 million increase in navy revenues, and a $13.0 million increase in commercial and defense aerospace shipments. Organic sales (excluding $37.1 million of Maritime revenue for the two months post-closing) increased $12.0 million to $99.2 million. The sales increase in the first nine months of 2025 compared to the first nine months of 2024 was mainly due to a $37.4 million increase in navy revenues, a $30.6 million increase in commercial aerospace shipments, and a $2.2 million increase in industrial shipments partially offset by a $3.9 million decrease in defense aerospace shipments.

[0001410578-25-001667:mdna:10]
[same as prior period, unchanged from 0001410578-25-001145:mdna:10]

[0001410578-25-001667:mdna:11]
In the third quarter of 2025, net sales of $92.4 million were $2.1 million, or 2.3%, higher than the $90.3 million in the third quarter of 2024. In the first nine months of 2025, net sales of $269.8 million were $9.2 million, or 3.5%, higher than the $260.6 million in the first nine months of 2024. The increase in the third quarter of 2025 compared to the third quarter of 2024 was mainly due to an increase in net sales of NRG’s wind and solar products and an increase in net sales at Doble driven by higher offline test products. The increase in the first nine months of 2025 compared to the corresponding period of 2024 was mainly due to an increase in net sales at Doble driven by higher sales of offline products and services partially offset by lower NRG sales due to renewables market weakness.

[0001410578-25-001667:mdna:12]
[same as prior period, unchanged from 0001410578-25-001145:mdna:12]

[0001410578-25-001667:mdna:13]
In the third quarter of 2025, net sales of $67.7 million were $11.6 million, or 20.7%, higher than the $56.1 million in the third quarter of 2024. In the first nine months of 2025, net sales of $165.1 million were $21.3 million, or 14.8%, higher than the $143.8 million in the first nine months of 2024. The increase in the third quarter of 2025 as compared to the third quarter of 2024 was primarily due to a $6.9 million increase in sales from the segment’s U.S. and European operations and a $4.7 million increase in sales from the segment’s Asian operations due to higher Test and Measurement, industrial shielding, medical services, and filters volumes. The increase in the first nine months of 2025 compared to the first nine months of 2024 was due to a $18.9 million increase in sales from the segment’s U.S. and European operations and a $2.4 million increase in sales from the segment’s Asian operations for reasons mentioned above.

[0001410578-25-001667:mdna:14]
[same as prior period, unchanged from 0001410578-25-001145:mdna:14]

[0001410578-25-001667:mdna:15]
Backlog from continuing operations was $1,165 million at June 30, 2025 compared with $664 million at September 30, 2024. The Company received new orders totaling $749.1 million in the third quarter of 2025 compared to $254.9 million in the third quarter of 2024. Of the new orders received in the third quarter of 2025, $582.4 million related to A&D products (including $364.2 million of Maritime acquired backlog), $105.5 million related to USG products, and $61.2 million related to Test products. Of the new orders received in the third quarter of 2024, $90.1 million related to A&D products, $100.0 million related to USG products, and $64.8 million related to Test products.

[0001410578-25-001667:mdna:16]
The Company received new orders totaling $1,243.9 million in the first nine months of 2025 compared to $752.3 million in the first nine months of 2024. Of the new orders received in the first nine months of 2025, $753.7 million related to A&D products (including $364.2 million of Maritime acquired backlog), $287.3 million related to USG products, and $202.9 million related to Test products. Of the new orders received in the first nine months of 2024, $342.3 million related to A&D products, $256.0 million related to USG products, and $154.0 million related to Test products.

[0001410578-25-001667:mdna:17]
[same as prior period, unchanged from 0001410578-25-001145:mdna:17]

[0001410578-25-001667:mdna:18]
Selling, general and administrative (SG&A) expenses from continuing operations for the third quarter of 2025 were $62.0 million (20.9% of net sales), compared with $51.0 million (21.8% of net sales) for the third quarter of 2024. For the first nine months of 2025, SG&A expenses were $171.3 million (23.1% of net sales) compared to $152.6 million (23.6% of net sales) for the first nine months of 2024. The increase in SG&A in the third quarter and first nine months of 2025 compared to the corresponding periods of 2024 was due to an increase within the A&D segment due to the Maritime acquisition, increased expenses at all three business segments primarily related to higher sales and inflationary impacts and an increase at Corporate mainly due to acquisition costs.

[0001410578-25-001667:mdna:19]
[same as prior period, unchanged from 0001410578-25-001145:mdna:19]

[0001410578-25-001667:mdna:20]
Amortization of intangible assets was $16.8 million and $32.7 million for the third quarter and first nine months of 2025, respectively, compared to $8.1 million and $24.6 million for the corresponding periods of 2024. Amortization expenses consist of amortization of acquired intangible assets from acquisitions and other identifiable intangible assets (primarily software). The increase in amortization expense in the third quarter and first nine months of 2025 compared to the corresponding periods of 2024 was mainly due to an increase in amortization of intangible assets related to the Maritime acquisition.

[0001410578-25-001667:mdna:21]
[same as prior period, unchanged from 0001410578-25-001145:mdna:21]

[0001410578-25-001667:mdna:22]
Other expenses, net, was $2.2 million in the third quarter of 2025 compared to other (income) of ($0.3) million in the third quarter of 2024. Other expenses, net, was $1.9 million in the first nine months of 2025 compared to $0.4 million of expenses in the first nine months of 2024. The principal component of other expenses, net, in the third quarter and first nine months of 2025 was $1.3 million of UK stamp duties on the Maritime acquisition. There were no individually significant items in other expenses (income), net, in the third quarter of 2024. The principal component of other expenses, net, in the first nine months of 2024 was approximately $0.5 million of restructuring charges (primarily severance) within the Test, USG and A&D segments.

[0001410578-25-001667:mdna:23]
[same as prior period, unchanged from 0001410578-25-001145:mdna:23]

[0001410578-25-001667:mdna:24]
The Company evaluates the performance of its operating segments based on EBIT, and provides EBIT on a consolidated basis. EBIT is a non-GAAP financial measure. Please refer to the discussion of non-GAAP financial measures in Note 8 to the condensed Consolidated Financial Statements, above. EBIT from continuing operations was $41.0 million (13.8% of net sales) for the third quarter of 2025 compared to $39.3 million (16.8% of net sales) for the third quarter of 2024. For the first nine months of 2025, EBIT was $105.7 million (14.2% of net sales) compared to $89.6 million (13.9% of net sales) for the first nine months of 2024.

[0001410578-25-001667:mdna:25]
The following table presents a reconciliation of EBIT from continuing operations to net earnings.

[0001410578-25-001667:mdna:26]
| ​ | ​ | Three Months Ended | ​ | Nine Months Ended |
| ​ | ​ | June 30, | ​ | June 30, |
| (In thousands) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net earnings | ​ | $ | 24,755 | ​ | ​ | 28,312 | ​ | 71,445 | ​ | 63,330 |
| Plus: Interest expense, net | ​ | ​ | 7,921 | ​ | ​ | 3,335 | ​ | 12,373 | ​ | 9,228 |
| Plus: Income tax expense | ​ | ​ | 8,314 | ​ | ​ | 7,654 | ​ | 21,841 | ​ | 17,040 |
| Consolidated EBIT from continuing operations | ​ | $ | 40,990 | ​ | ​ | 39,301 | ​ | 105,659 | ​ | 89,598 |

[0001410578-25-001667:mdna:27]
[same as prior period, unchanged from 0001410578-25-001145:mdna:27]

[0001410578-25-001667:mdna:28]
EBIT in the third quarter of 2025 was $36.6 million (26.8% of net sales) compared to $20.2 million (23.1% of net sales) in the third quarter of 2024. EBIT in the first nine months of 2025 was $78.2 million (25.4% of net sales) compared to $55.9 million (23.2% of net sales) in the first nine months of 2024. The increase in EBIT in the third quarter and first nine months of 2025 compared to the corresponding periods of 2024 was mainly driven by leverage on higher sales volumes including the Maritime acquisition, price increases and mix, partially offset by inflationary pressures. EBIT in the third quarter and first nine months of 2025 was negatively impacted by $2.7 million of inventory step-up charges and stamp duty charges related to the Maritime acquisition.

[0001410578-25-001667:mdna:29]
[same as prior period, unchanged from 0001410578-25-001145:mdna:29]

[0001410578-25-001667:mdna:30]
EBIT in the third quarter of 2025 was $21.5 million (23.3% of net sales) compared to $22.2 million (24.5% of net sales) in the third quarter of 2024. EBIT in the first nine months of 2025 was $62.8 million (23.3% of net sales) compared to $57.4 million (22.0% of net sales) in the first nine months of 2024. The decrease in EBIT in the third quarter of 2025 compared to the third quarter of 2024 was due to unfavorable mix at Doble and inflationary pressures, partially offset by price increases. The increase in EBIT in the first nine months of 2025 compared to the corresponding periods of 2024 was mainly due to leverage on higher sales volumes at Doble and price increases, partially offset by inflationary pressures. EBIT was negatively impacted by $0.3 million of restructuring charges (primarily severance) in the first nine months of 2025.

[0001410578-25-001667:mdna:31]
[same as prior period, unchanged from 0001410578-25-001145:mdna:31]

[0001410578-25-001667:mdna:32]
EBIT in the third quarter of 2025 was $10.7 million (15.9% of net sales) compared to $9.3 million (16.6% of net sales) in the third quarter of 2024. EBIT in the first nine months of 2025 was $21.5 million (13.0% of net sales) compared to $16.6 million (11.6% of net sales) in the first nine months of 2024. The increase in EBIT in the third quarter and first nine months of 2025 compared to the corresponding periods of 2024 was primarily due to higher sales volumes, price increases and cost reduction actions partially offset by inflationary pressures. In addition, EBIT was negatively impacted by $0.4 million in the first nine months of 2025 by restructuring charges (primarily severance). EBIT was negatively impacted by $0.3 million of inventory step-up charges related to the MPE acquisition and $0.2 million of restructuring charges in the first nine months of 2024.

[0001410578-25-001667:mdna:33]
[same as prior period, unchanged from 0001410578-25-001145:mdna:33]

[0001410578-25-001667:mdna:34]
Corporate costs included in EBIT were $27.9 million and $56.9 million in the third quarter and first nine months of 2025, respectively, compared to $12.3 million and $40.3 million in the corresponding periods of 2024. The increase in Corporate costs in the third quarter and first nine months of 2025 as compared to the corresponding periods of 2024 was mainly due to an $8.4 million increase in acquisition related amortization and $5.2 million of acquisition costs, both due to the Maritime acquisition, as well as an increase in share-based compensation costs.

[0001410578-25-001667:mdna:35]
[same as prior period, unchanged from 0001410578-25-001145:mdna:35]

[0001410578-25-001667:mdna:36]
Interest expense was $7.9 million and $12.4 million in the third quarter and first nine months of 2025, respectively, and $3.3 million and $9.2 million in the corresponding periods of 2024. The increase in interest expense in the third quarter and first nine months of 2025 compared to the corresponding periods of 2024 was mainly due to higher average outstanding borrowings due to the Maritime acquisition in April 2025. The weighted average outstanding borrowings were $599 million and $274 million for the three and nine-month periods ending June 30, 2025 and $184 million and $173 million for the three and nine-month periods ending June 30, 2024.

[0001410578-25-001667:mdna:37]
[same as prior period, unchanged from 0001410578-25-001145:mdna:37]

[0001410578-25-001667:mdna:38]
The third quarter 2025 effective income tax rate from continuing operations was 25.1% compared to 21.3% in the third quarter of 2024. The effective income tax rate from continuing operations in the first nine months of 2025 was 23.4% compared to 21.2% for the first nine months of 2024. The income tax expense in the third quarter and first nine months of 2025 was unfavorably impacted by income tax consequences associated with the Maritime acquisition, including non-deductible transaction costs and additional income taxed at the UK statutory rate.

[0001410578-25-001667:mdna:39]
[same as prior period, unchanged from 0001410578-25-001145:mdna:39]

[0001410578-25-001667:mdna:40]
The Company’s overall financial position and liquidity remains strong. Working capital from continuing operations (current assets less current liabilities) decreased to $255.8 million at June 30, 2025 from $283.9 million at September 30, 2024. The main driver of the decrease was an increase in contract liabilities of $124.7 million primarily due to the Maritime acquisition and an increase within the USG segment. Inventories increased $41.6 million during this period due to a $25.4 million increase within the A&D segment primarily due to the Maritime acquisition, and a $11.5 million increase within the USG segment and a $4.7 million increase within the Test segment primarily from an increase in finished goods and raw materials inventories due to timing of manufacturing existing orders.

[0001410578-25-001667:mdna:41]
Net cash provided by operating activities from continuing operations was $88.3 million and $63.1 million in the first nine months of 2025 and 2024, respectively. The increase in net cash provided by operating activities in the first nine months of 2025 as compared to the first nine months of 2024 was mainly driven by lower working capital and higher earnings.

[0001410578-25-001667:mdna:42]
Capital expenditures for continuing operations were $24.2 million and $19.6 million in the first nine months of 2025 and 2024, respectively. In addition, the Company incurred expenditures for capitalized software and other intangible assets from continuing operations of $13.0 million and $8.5 million in the first nine months of 2025 and 2024, respectively.

[0001410578-25-001667:mdna:43]
Credit Facility

[0001410578-25-001667:mdna:44]
At June 30, 2025, the Company had approximately $338 million available to borrow under its bank credit facility, a $250 million increase option, and $78.7 million cash on hand. At June 30, 2025, the Company had $505 million of outstanding borrowings under the Credit Facility and Incremental Facility in addition to outstanding letters of credit of $7.2 million. Cash flow from operations and borrowings under the Company’s credit facility are expected to meet the Company’s capital requirements and operational needs for the foreseeable future. The Company’s ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.

[0001410578-25-001667:mdna:45]
Acquisition

[0001410578-25-001667:mdna:46]
On April 25, 2025, the Company completed the acquisition of the Signature Management & Power (SM&P) business of Ultra Maritime for a purchase price of approximately $472 million, net of cash acquired. SM&P will become part of ESCO’s Aerospace & Defense (A&D) segment and will be known as ESCO Maritime Solutions (Maritime) going forward. Their Signature Management and Power Management product lines are highly complementary to ESCO’s current naval programs. Signature Management offers solutions for surface ships and submarines that provide magnetic and electric field countermeasures to prevent underwater mine and sensor detection. Power Management provides innovative and highly-engineered motors that drive critical ship propulsion systems with an ultra-quiet design ensuring low vibration levels to increase stealth capabilities. Since the date of acquisition, the operating results for the Maritime business have been included as part of the A&D segment.

[0001410578-25-001667:mdna:47]
Divestiture

[0001410578-25-001667:mdna:48]
On May 20, 2025, the Company announced it had entered into a definitive agreement to sell VACCO Industries (VACCO) to RBC Bearings Incorporated (RBC), an international manufacturer and marketer of highly engineered precision bearings and products, headquartered in Oxford, Connecticut. Subsequent to June 30, 2025, the Company announced it had completed this divestiture on July 18, 2025. Net proceeds from the transaction were approximately $275 million reflecting customary working capital adjustments attributable to operating activities since the time of the transaction announcement on May 20, 2025.

[0001410578-25-001667:mdna:49]
[same as prior period, unchanged from 0001410578-25-001145:mdna:47]

[0001410578-25-001667:mdna:50]
A dividend of $0.08 per share, totaling $2.1 million, was paid on October 16, 2024 to stockholders of record as of October 2, 2024. A dividend of $0.08 per share, totaling $2.1 million, was paid on January 17, 2025 to stockholders of record as of January 2, 2025. A dividend of $0.08 per share, totaling $2.1 million, was paid on April 17, 2025 to stockholders of record as of April 2, 2025. Subsequent to June 30, 2025, a quarterly dividend of $0.08 per share, totaling $2.1 million, was paid on July 17, 2025 to stockholders of record as of July 12, 2025.

[0001410578-25-001667:mdna:51]
[same as prior period, unchanged from 0001410578-25-001145:mdna:49]

[0001410578-25-001667:mdna:52]
Management has evaluated the accounting policies used in the preparation of the Company’s financial statements and related notes and believes those policies to be reasonable and appropriate. Certain of these accounting policies require the application of significant judgment by Management in selecting appropriate assumptions for calculating financial estimates. By their nature, these judgments are subject to an inherent degree of uncertainty. These judgments are based on historical experience, trends in the industry, information provided by customers and information available from other outside sources, as appropriate. The most significant areas involving Management judgments and estimates may be found in the Critical Accounting Policies section of Management’s Discussion and Analysis and in Note 1 to the condensed Consolidated Financial Statements contained in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2024.

[0001410578-25-001667:mdna:53]
[same as prior period, unchanged from 0001410578-25-001145:mdna:51]

[0001410578-25-001667:mdna:54]
Contingencies

[0001410578-25-001667:mdna:55]
As a normal incident of the business in which the Company is engaged, various claims, charges and litigation are asserted or commenced against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. In the opinion of Management, the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company, are adequately reserved, are covered by insurance, or would not have a material adverse effect on the Company’s results from operations, capital expenditures, or competitive position.

[0001410578-25-001667:mdna:56]
[same as prior period, unchanged from 0001410578-25-001145:mdna:54]

[0001410578-25-001667:mdna:57]
Investors are cautioned that such statements are only predictions and speak only as of the date of this Form 10-Q, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment, including but not limited to those described in Item 1A, “Risk Factors,” of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2024, and the following: the impacts of climate change and related regulation of greenhouse gases; the impacts of labor disputes, civil disorder, wars, elections, political changes, tariffs and trade disputes, terrorist activities, cyberattacks or natural disasters on the Company’s operations and those of the Company’s customers and suppliers; disruptions in manufacturing or delivery arrangements due to shortages or unavailability of materials or components; or supply chain disruptions; inability to access work sites; the timing and content of future contract awards or customer orders; the timely appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer contracts or orders; weakening of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties or data breaches; the availability of selected acquisitions; delivery delays or defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability of certain raw materials; material changes in the cost of credit; changes in laws and regulations including but not limited to changes in accounting standards and taxation; changes in interest, inflation and employment rates; costs relating to environmental matters arising from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the integration and performance of recently acquired businesses.
