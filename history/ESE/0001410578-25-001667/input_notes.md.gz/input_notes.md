# ESE notes — 0001410578-25-001667


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001410578-25-001667:notes:1]
[same as prior period, unchanged from 0001410578-25-001145:notes:1]

[0001410578-25-001667:notes:2]
The accompanying condensed consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The condensed consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP). For further information refer to the consolidated financial statements and related notes included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2024.

[0001410578-25-001667:notes:3]
The Company’s results for the three-month period ended June 30, 2025 are not necessarily indicative of the results for the entire 2025 fiscal year. References to the third quarters of 2025 and 2024 represent the fiscal quarters ended June 30, 2025 and 2024, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:EarningsPerShareTextBlock

[0001410578-25-001667:notes:4]
[same as prior period, unchanged from 0001410578-25-001145:notes:4]

[0001410578-25-001667:notes:5]
Basic EPS is calculated using the weighted average number of common shares outstanding during the period. Diluted EPS is calculated using the weighted average number of common shares outstanding during the period plus shares issuable upon the vesting of performance-based share unit awards and time-vested restricted shares by using the treasury stock method. The number of shares used in the calculation of earnings per share for each period presented is as follows (in thousands):

[0001410578-25-001667:notes:6]
| ​ |  | Three Months | ​ | Nine Months |
| ​ | ​ | Ended June 30, | ​ | Ended June 30, |
| ​ |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Weighted Average Shares Outstanding — Basic |  | 25,825 | ​ | 25,753 | ​ | 25,806 | ​ | 25,781 |
| Dilutive Shares | ​ | 93 | ​ | 87 | ​ | 70 | ​ | 63 |
| Adjusted Shares — Diluted |  | 25,918 | ​ | 25,840 | ​ | 25,876 | ​ | 25,844 |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001410578-25-001667:notes:7]
3.    ACQUISITION

[0001410578-25-001667:notes:8]
On April 25, 2025, the Company completed the acquisition of the Signature Management & Power (SM&P) business of Ultra Maritime for a purchase price of approximately $472 million, net of cash acquired. SM&P will become part of ESCO’s Aerospace & Defense (A&D) segment and will be known as ESCO Maritime Solutions (Maritime) going forward. Their Signature Management and Power Management product lines are highly complementary to ESCO’s current naval programs. Signature Management offers solutions for surface ships and submarines that provide magnetic and electric field countermeasures to prevent underwater mine and sensor detection. Power Management provides innovative and highly-engineered motors that drive critical ship propulsion systems with an ultra-quiet design ensuring low vibration levels to increase stealth capabilities. For the quarter ended June 30, 2025, Maritime had $37.1 million of revenue since the acquisition date. Maritime’s revenues for the period from October 1, 2024 through April 25, 2025 (acquisition date) were approximately $103 million with EBIT margins in the mid-twenty percent range, which is comparable to the prior year period.

[0001410578-25-001667:notes:9]
Since the date of acquisition, the operating results for the Maritime business have been included as part of the A&D segment. The preliminary acquisition date fair value of the assets acquired and liabilities assumed were as follows: $72.2 million of cash, $22.9 million of accounts receivable, $17.0 million of inventory, $15.1 million of contract assets, $1.5 million of prepaid assets, $12.2 million of property, plant and equipment, $5.0 million of other assets, $9.7 million of accounts payable, $14.2 million of accrued expenses and other current liabilities, $104.5 million of contract liabilities, $3.5 million of other liabilities, $46.3 million of deferred tax liabilities, $290.5 million of customer relationships and $61.3 million of backlog. The customer relationships were preliminarily determined to have a useful life of fifteen years and the backlog was determined to have a useful life of two years. Management is still in the process of reviewing the purchase price allocation. The acquired goodwill of $222.7 million relates to the excess value associated with opportunities to expand the services and products that the Company can offer to its customers and access to new markets. The Company does not expect all of the goodwill will be deductible for tax purposes.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001410578-25-001667:notes:10]
4.    ASSETS HELD FOR SALE / DISCONTINUED OPERATIONS

[0001410578-25-001667:notes:11]
On May 2, 2025, the Board approved and on May 20, 2025, the Company announced it had entered into a definitive agreement to sell VACCO Industries (VACCO) to RBC Bearings Incorporated (RBC), an international manufacturer and marketer of highly engineered precision bearings and products, headquartered in Oxford, Connecticut. Subsequent to June 30, 2025, the Company announced it had completed this divestiture on July 18, 2025. Net proceeds from the transaction were approximately $275 million reflecting customary working capital adjustments attributable to operating activities since the time of the transaction announcement on May 20, 2025. VACCO’s assets and liabilities constitute a disposal group to be classified as held for sale and VACCO constitutes a component of the Company with operations and cash flows that are clearly distinguishable, operationally and for financial reporting purposes. Results of operations, financial position and cash flows for the VACCO business are reflected as discontinued operations and/or assets held for sale in the Condensed Consolidated Financial Statements and related notes for all periods presented. The sale of VACCO represents a strategic shift for the Company to exit the Space business.

[0001410578-25-001667:notes:12]
Net sales from the VACCO business were $30.3 million and $96.4 million for the three and nine-month periods ending June 30, 2025 and $27.2 million and $82.6 million for the respective prior year periods. Pretax earnings from the VACCO business were $1.9 million and $12.1 million for the three and nine-month periods ending June 30, 2025 and $1.2 million and $5.5 million for the respective prior year periods. The net proceeds from the sale of approximately $275 million and the related gain on sale will be recorded in the fourth quarter of 2025.

[0001410578-25-001667:notes:13]
The major classes of VACCO’s assets and liabilities held for sale included in the Condensed Consolidated Balance Sheet at June 30, 2025 and September 30, 2024 are shown below (in thousands).

[0001410578-25-001667:notes:14]
| ​ |  | June 30, |  | September 30, |
| ​ | ​ | 2025 | ​ | 2024 |
| Assets: |  | ​ |  |  |  |
| Accounts receivable, net | ​ | $ | 10,943 |  | 18,579 |
| Contract assets | ​ |  | 50,098 |  | 63,822 |
| Inventories | ​ |  | 13,346 |  | 13,699 |
| Other current assets | ​ |  | 2,165 |  | 1,281 |
| Current assets | ​ |  | 76,552 |  | 97,381 |
| Property, plant and equipment, net | ​ |  | 20,576 |  | 21,345 |
| Intangible assets, net | ​ |  | 3,444 |  | 4,078 |
| Goodwill | ​ |  | 9,964 |  | 9,964 |
| Other assets | ​ |  | 804 |  | 607 |
| Total assets | ​ |  | 111,340 |  | 133,375 |
| Liabilities: | ​ |  |  |  |  |
| Accounts payable | ​ |  | 8,150 |  | 9,435 |
| Contract liabilities | ​ |  | 53,858 |  | 44,001 |
| Accrued expenses and other current liabilities | ​ |  | 12,497 |  | 9,063 |
| Current liabilities | ​ |  | 74,505 |  | 62,499 |
| Other liabilities | ​ |  | 2,775 |  | 2,710 |
| Total liabilities | ​ | $ | 77,280 |  | 65,209 |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001410578-25-001667:notes:15]
5.    SHARE-BASED COMPENSATION

[0001410578-25-001667:notes:16]
[same as prior period, unchanged from 0001410578-25-001145:notes:8]

[0001410578-25-001667:notes:17]
[same as prior period, unchanged from 0001410578-25-001145:notes:9]

[0001410578-25-001667:notes:18]
Compensation expense related to these awards was $2.3 million and $6.9 million for the three and nine-month periods ended June 30, 2025, respectively, and $2.0 million and $5.5 million for the corresponding periods in 2024. As of June 30, 2025, there were 213,069 unvested stock units outstanding.

[0001410578-25-001667:notes:19]
[same as prior period, unchanged from 0001410578-25-001145:notes:11]

[0001410578-25-001667:notes:20]
Compensation expense related to the non-employee director grants was $0.4 million and $1.0 million for the three and nine-month periods ended June 30, 2025, respectively, and $0.3 million and $0.9 million for the corresponding periods in 2024.

[0001410578-25-001667:notes:21]
The total share-based compensation cost that has been recognized in the results of operations and included within selling, general and administrative expenses (SG&A) was $2.6 million and $7.9 million for the three and nine-month periods ended June 30, 2025, respectively, and $2.2 million and $6.4 million for the corresponding periods in 2024. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $0.5 million and $1.6 million for the three and nine-month periods ended June 30, 2025, respectively, and $0.5 million and $1.4 million for the corresponding periods in 2024. As of June 30, 2025, there was $14.3 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a remaining weighted-average period of 1.6 years.


## us-gaap:InventoryDisclosureTextBlock

[0001410578-25-001667:notes:22]
6.    INVENTORIES

[0001410578-25-001667:notes:23]
Inventories from continuing operations consist of the following:

[0001410578-25-001667:notes:24]
| ​ | ​ | June 30, | ​ | September 30, |
| (In thousands) |  | 2025 |  | 2024 |
| Finished goods | ​ | $ | 59,755 | ​ | 46,586 |
| Work in process | ​ | ​ | 55,052 | ​ | 40,605 |
| Raw materials | ​ | ​ | 122,303 | ​ | 108,274 |
| Total inventories | ​ | $ | 237,110 | ​ | 195,465 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001410578-25-001667:notes:25]
| 7. | GOODWILL AND OTHER INTANGIBLE ASSETS |

[0001410578-25-001667:notes:26]
Included on the Company’s condensed Consolidated Balance Sheets at June 30, 2025 and September 30, 2024 are the following intangible assets gross carrying amounts and accumulated amortization from continuing operations:

[0001410578-25-001667:notes:27]
| ​ |  | June 30, |  | September 30, |
| (Dollars in thousands) |  | 2025 |  | 2024 |
| Goodwill | ​ | $ | 760,555 | ​ | 529,935 |
| Intangible assets with determinable lives: | ​ |  | ​ | ​ | ​ |
| Patents | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 7,566 | ​ | 2,638 |
| Less: accumulated amortization | ​ |  | 1,643 | ​ | 1,415 |
| Net | ​ | $ | 5,923 | ​ | 1,223 |
| Capitalized software | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 135,564 | ​ | 126,721 |
| Less: accumulated amortization | ​ |  | 98,058 | ​ | 89,558 |
| Net | ​ | $ | 37,506 | ​ | 37,163 |
| Customer relationships | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 627,932 | ​ | 330,328 |
| Less: accumulated amortization | ​ |  | 149,786 | ​ | 132,135 |
| Net | ​ | $ | 478,146 | ​ | 198,193 |
| Other | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 77,441 | ​ | 15,182 |
| Less: accumulated amortization | ​ |  | 16,895 | ​ | 11,173 |
| Net | ​ | $ | 60,546 | ​ | 4,009 |
| Intangible assets with indefinite lives: | ​ |  | ​ | ​ | ​ |
| Trade names | ​ | $ | 162,958 | ​ | 162,936 |

[0001410578-25-001667:notes:28]
The changes in the carrying amount of goodwill attributable to each business segment from continuing operations for the nine months ended June 30, 2025 is as follows:

[0001410578-25-001667:notes:29]
| (Dollars in millions) |  | USG |  | Test |  | A&D |  | Total |
| Balance as of September 30, 2024 | ​ | $ | 356.9 |  | ​ | 67.4 |  | 105.6 |  | 529.9 |
| Acquisition activity | ​ | ​ | — | ​ | ​ | — | ​ | 222.7 | ​ | 222.7 |
| Foreign currency translation | ​ | ​ | 3.5 | ​ | ​ | 0.9 | ​ | 3.6 | ​ | 8.0 |
| Balance as of June 30, 2025 | ​ | $ | 360.4 | ​ | ​ | 68.3 | ​ | 331.9 | ​ | 760.6 |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001410578-25-001667:notes:30]
8.    BUSINESS SEGMENT INFORMATION

[0001410578-25-001667:notes:31]
The Company is organized based on the products and services that it offers and classifies its business operations in three reportable segments for financial reporting purposes: Aerospace & Defense (A&D), Utility Solutions Group (USG), and RF Test and Measurement (Test). The A&D segment’s operations consist of PTI Technologies Inc. (PTI), Crissair, Inc. (Crissair), Globe Composite Solutions, LLC (Globe), Mayday Manufacturing Co. (Mayday) and ESCO Maritime Solutions (Maritime). Previously, A&D also included VACCO Industries which is now being reported in discontinued operations. The companies within this segment primarily design and manufacture specialty filtration, fluid control and naval products, including hydraulic filter elements and fluid control devices used in aerospace and defense applications; custom designed filters for manned aircraft and submarines; products and systems to reduce vibration and/or acoustic signatures and otherwise reduce or obscure a vessel’s signature, power management and control equipment, sealing, surface control and hydrodynamic related applications to enhance U.S. Navy maritime survivability; precision-tolerance machined components for the aerospace and defense industry; metal processing services; and miniature electro-explosive devices utilized in mission-critical defense and aerospace applications.

[0001410578-25-001667:notes:32]
[same as prior period, unchanged from 0001410578-25-001145:notes:25]

[0001410578-25-001667:notes:33]
The Test segment’s operations consist primarily of ETS-Lindgren Inc. and related subsidiaries, including MPE Limited (ETS-Lindgren). ETS-Lindgren is an industry leader in designing and manufacturing products and systems to measure and control RF and acoustic energy. It serves the acoustics, medical, health and safety, electronics, wireless communications, automotive and defense markets, supplying a broad range of turnkey systems, including RF test facilities and measurement systems, acoustic test enclosures, RF and magnetically shielded rooms and secure communication facilities, and providing the design, program management, installation and integration services required to successfully complete these types of facilities. It also provides a broad range of components including RF absorptive materials, filters, antennas, field probes, test cells, proprietary measurement software and other test accessories required to perform a variety of tests and measurements, and offers a variety of services including calibration and product tests.

[0001410578-25-001667:notes:34]
Management evaluates and measures the performance of its reportable segments based on “Net Sales” and “EBIT”, which are detailed in the table below. EBIT is defined as earnings before interest and taxes. The table below is presented on the basis of continuing operations and excludes discontinued operations.

[0001410578-25-001667:notes:35]
| ​ | ​ | Three Months | ​ | Nine Months |
| ​ | ​ | Ended June 30, | ​ | Ended June 30, |
| (In thousands) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| NET SALES | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |  |
| Aerospace & Defense | ​ | $ | 136,324 | ​ | 87,235 | ​ | 307,819 | ​ | 241,279 |
| USG | ​ | ​ | 92,357 | ​ | 90,277 | ​ | 269,784 | ​ | 260,570 |
| Test | ​ | ​ | 67,663 | ​ | 56,056 | ​ | 165,111 | ​ | 143,772 |
| Consolidated totals | ​ | $ | 296,344 | ​ | 233,568 | ​ | 742,714 | ​ | 645,621 |
| EBIT | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Aerospace & Defense | ​ | $ | 36,577 | ​ | 20,150 | ​ | 78,246 | ​ | 55,919 |
| USG | ​ | ​ | 21,540 | ​ | 22,155 | ​ | 62,808 | ​ | 57,355 |
| Test | ​ | ​ | 10,732 | ​ | 9,292 | ​ | 21,523 | ​ | 16,613 |
| Corporate (loss) | ​ | ​ | (27,859) | ​ | (12,296) | ​ | (56,918) | ​ | (40,289) |
| Consolidated EBIT | ​ | ​ | 40,990 | ​ | 39,301 | ​ | 105,659 | ​ | 89,598 |
| Less: Interest expense | ​ | ​ | (7,921) | ​ | (3,335) | ​ | (12,373) | ​ | (9,228) |
| Earnings before income taxes | ​ | $ | 33,069 | ​ | 35,966 | ​ | 93,286 | ​ | 80,370 |

[0001410578-25-001667:notes:36]
[same as prior period, unchanged from 0001410578-25-001145:notes:29]

[0001410578-25-001667:notes:37]
[same as prior period, unchanged from 0001410578-25-001145:notes:30]

[0001410578-25-001667:notes:38]
The Company believes that the presentation of EBIT provides important supplemental information to investors to facilitate comparisons with other companies, many of which use similar non-GAAP financial measures to supplement their GAAP results. However, the Company’s non-GAAP financial measures may not be comparable to other companies’ non-GAAP financial performance measures. Furthermore, the use of non-GAAP financial measures is not intended to replace any measures of performance determined in accordance with GAAP.


## us-gaap:DebtDisclosureTextBlock

[0001410578-25-001667:notes:39]
9.    DEBT

[0001410578-25-001667:notes:40]
The Company’s debt is summarized as follows:

[0001410578-25-001667:notes:41]
| ​ |  | June 30, | ​ | September 30, |
| (In thousands) |  | 2025 |  | 2024 |
| Revolving credit facility | ​ | ​ | 155,000 | ​ | 122,000 |
| Incremental facility (Term loan A) | ​ | ​ | 370,000 | ​ | — |
| Total borrowings | ​ | $ | 525,000 | ​ | 122,000 |
| Current portion of long-term debt | ​ | ​ | (20,000) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 505,000 | ​ | 102,000 |

[0001410578-25-001667:notes:42]
The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of seven banks led by JP Morgan Chase Bank, N.A., as administrative agent, Bank of America, N.A., as syndication agent, and Commerce Bank and TD Bank, N.A. as co-documentation agents. The Credit Facility matures August 30, 2028, with balance due by this date.

[0001410578-25-001667:notes:43]
On August 5, 2024, the Company and certain of its subsidiaries entered into Amendment No. 1 to the Credit Facility which, among other things, (i) implements a senior incremental delayed draw term loan credit facility in an aggregate principal amount of up to $375 million (the “Incremental Facility”), and (ii) permits the direct or indirect acquisition by the Registrant or certain of its subsidiaries of all the issued and outstanding shares of Ultra PMES Limited, Measurement Systems, Inc., EMS Development

[0001410578-25-001667:notes:44]
Corporation, and DNE Technologies, Inc. (the “SM&P Acquisition), pursuant to and in accordance with the terms and conditions of that certain Sale and Purchase Agreement, dated July 8, 2024. During the third quarter of 2025, the proceeds of the loans drawn under the Incremental Facility were applied to pay a portion of the cash consideration for the Maritime Acquisition and other customary fees, premiums, expenses and costs incurred in connection with the acquisition. The Incremental Facility matures August 30, 2028, with balance due by this date.

[0001410578-25-001667:notes:45]
At June 30, 2025, the Company had approximately $338 million available to borrow under the Credit Facility, plus the $250 million increase option subject to the lenders’ consent, in addition to $78.7 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of June 30, 2025, as the Company intends to repay this amount as obligated by the repayment terms of the Incremental Facility within the next twelve months. The Company is obligated to repay the Incremental Facility Loan on the last day of each fiscal quarter, commencing on September 30, 2025 (the first full quarter ending after the Funding Date), in an amount equal to (a) 1.25% of the original aggregate principal amount of the Loans for each of the first twelve fiscal quarters ending after the Funding date, and (b) 1.875% of the original aggregate principal amount of the Loans for each fiscal quarter thereafter until the Maturity Date. The letters of credit issued and outstanding under the Credit Facility totaled $7.2 million at June 30, 2025.

[0001410578-25-001667:notes:46]
Interest on borrowings under the Credit Facility and the Incremental Facility is calculated at a spread ranging from 0.25% to 2.25% over either an Adjusted Term SOFR Rate, Adjusted EURIBOR Rate, Adjusted CDOR Rate, Alternate Base Rate or Daily Simple RFR, at the Company’s election. The Credit Facility also requires a facility fee ranging from 12.5 to 25 basis points per annum on the unused portion. The interest rate spreads and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio. The weighted average interest rates under the Credit Facility were 6.03% and 5.99% for the three and nine-month periods ending June 30, 2025, respectively, and 6.71% and 6.75% for the three and nine-month periods ending June 30, 2024. The weighted average interest rate under the Incremental Facility was 6.42% for the three-month period ending June 30, 2025. As of June 30, 2025, the Company was in compliance with all covenants.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001410578-25-001667:notes:47]
10.   INCOME TAX EXPENSE

[0001410578-25-001667:notes:48]
The third quarter 2025 effective income tax rate from continuing operations was 25.1% compared to 21.3% in the third quarter of 2024. The effective income tax rate from continuing operations in the first nine months of 2025 was 23.4% compared to 21.2% for the first nine months of 2024. The income tax expense in the third quarter and first nine months of 2025 was unfavorably impacted by income tax consequences associated with the Maritime acquisition, including non - deductible transaction costs and additional income taxed at the UK statutory rate.

[0001410578-25-001667:notes:49]
On July 4, 2025, President Trump signed H.R. 1, the “One Big Beautiful Bill Act (OBBBA)” into law. The OBBBA extends permanently, with modifications, certain individual, business and international tax provisions enacted as part of the 2017 Tax Cuts and Jobs Act that were set to expire at the end of calendar year 2025, as well as delivers additional tax relief for individuals and businesses. The Company is currently evaluating the impact of the OBBBA on its consolidated financial statements but does not anticipate a material impact to the Company’s financial position or results of operations.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001410578-25-001667:notes:50]
11.   SHAREHOLDERS’ EQUITY

[0001410578-25-001667:notes:51]
The change in shareholders’ equity for the first three and nine months of 2025 and 2024 is shown below (in thousands):

[0001410578-25-001667:notes:52]
| ​ | ​ | Three Months Ended June 30, | ​ | Nine Months Ended June 30, |
| ​ |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Common stock | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | 309 | ​ | 308 | ​ | 308 | ​ | 308 |
| Stock plans | ​ | ​ | — | ​ | — | ​ | 1 | ​ | — |
| Ending balance | ​ | ​ | 309 | ​ | 308 | ​ | 309 | ​ | 308 |
| Additional paid-in-capital | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | 311,438 | ​ | 308,065 | ​ | 311,942 | ​ | 304,850 |
| Stock plans | ​ | ​ | 2,211 | ​ | 1,917 | ​ | 1,707 | ​ | 5,132 |
| Ending balance | ​ | ​ | 313,649 | ​ | 309,982 | ​ | 313,649 | ​ | 309,982 |
| Retained earnings | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | 1,133,326 | ​ | 1,023,578 | ​ | 1,082,950 | ​ | 989,315 |
| Net earnings common stockholders | ​ | ​ | 26,065 | ​ | 29,230 | ​ | 80,571 | ​ | 67,618 |
| Dividends paid | ​ | ​ | (2,066) | ​ | (2,060) | ​ | (6,196) | ​ | (6,185) |
| Ending balance | ​ | ​ | 1,157,325 | ​ | 1,050,748 | ​ | 1,157,325 | ​ | 1,050,748 |
| Accumulated other comprehensive income (loss) | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | (20,670) | ​ | (19,300) | ​ | (10,775) | ​ | (23,969) |
| Foreign currency translation | ​ | ​ | 23,076 | ​ | (1,001) | ​ | 13,181 | ​ | 3,668 |
| Ending balance | ​ | ​ | 2,406 | ​ | (20,301) | ​ | 2,406 | ​ | (20,301) |
| Treasury stock | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | (147,075) | ​ | (146,241) | ​ | (147,075) | ​ | (139,362) |
| Share repurchases | ​ | ​ | — | ​ | (810) | ​ | — | ​ | (7,689) |
| Ending balance | ​ | ​ | (147,075) | ​ | (147,051) | ​ | (147,075) | ​ | (147,051) |
| Total equity | ​ | ​ | 1,326,614 | ​ | 1,193,686 | ​ | 1,326,614 | ​ | 1,193,686 |


## us-gaap:FairValueDisclosuresTextBlock

[0001410578-25-001667:notes:53]
12.  FAIR VALUE MEASUREMENTS

[0001410578-25-001667:notes:54]
[same as prior period, unchanged from 0001410578-25-001145:notes:46]

[0001410578-25-001667:notes:55]
[same as prior period, unchanged from 0001410578-25-001145:notes:47]

[0001410578-25-001667:notes:56]
[same as prior period, unchanged from 0001410578-25-001145:notes:48]

[0001410578-25-001667:notes:57]
[same as prior period, unchanged from 0001410578-25-001145:notes:49]

[0001410578-25-001667:notes:58]
[same as prior period, unchanged from 0001410578-25-001145:notes:50]

[0001410578-25-001667:notes:59]
The Company has estimated the fair value of its financial instruments as of June 30, 2025 and September 30, 2024 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001410578-25-001667:notes:60]
[same as prior period, unchanged from 0001410578-25-001145:notes:52]

[0001410578-25-001667:notes:61]
[same as prior period, unchanged from 0001410578-25-001145:notes:53]

[0001410578-25-001667:notes:62]
[same as prior period, unchanged from 0001410578-25-001145:notes:54]

[0001410578-25-001667:notes:63]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however, they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during the three and nine-month periods ended June 30, 2025.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001410578-25-001667:notes:64]
13.  REVENUES

[0001410578-25-001667:notes:65]
[same as prior period, unchanged from 0001410578-25-001145:notes:57]

[0001410578-25-001667:notes:66]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2025 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue from continuing operations within each reportable segment.

[0001410578-25-001667:notes:67]
| Three months ended June 30, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 57,297 | ​ | $ | 87,653 | ​ | $ | 50,591 | ​ | $ | 195,541 |
| Government | ​ | ​ | 79,027 | ​ | ​ | 4,704 | ​ | ​ | 17,072 | ​ | ​ | 100,803 |
| Total revenues | ​ | $ | 136,324 | ​ | $ | 92,357 | ​ | $ | 67,663 | ​ | $ | 296,344 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 94,518 | ​ | $ | 63,062 | ​ | $ | 36,188 | ​ | $ | 193,768 |
| International | ​ | ​ | 41,806 | ​ | ​ | 29,295 | ​ | ​ | 31,475 | ​ | ​ | 102,576 |
| Total revenues | ​ | $ | 136,324 | ​ | $ | 92,357 | ​ | $ | 67,663 | ​ | $ | 296,344 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 66,833 | ​ | $ | 74,143 | ​ | $ | 11,123 | ​ | $ | 152,099 |
| Over time | ​ | ​ | 69,491 | ​ | ​ | 18,214 | ​ | ​ | 56,540 | ​ | ​ | 144,245 |
| Total revenues | ​ | $ | 136,324 | ​ | $ | 92,357 | ​ | $ | 67,663 | ​ | $ | 296,344 |

[0001410578-25-001667:notes:68]
| Nine months ended June 30, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 151,756 | ​ | $ | 261,581 | ​ | $ | 124,831 | ​ | $ | 538,168 |
| Government | ​ | ​ | 156,063 | ​ | ​ | 8,203 | ​ | ​ | 40,280 | ​ | ​ | 204,546 |
| Total revenues | ​ | $ | 307,819 | ​ | $ | 269,784 | ​ | $ | 165,111 | ​ | $ | 742,714 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 226,444 | ​ | $ | 173,121 | ​ | $ | 97,086 | ​ | $ | 496,651 |
| International | ​ | ​ | 81,375 | ​ | ​ | 96,663 | ​ | ​ | 68,025 | ​ | ​ | 246,063 |
| Total revenues | ​ | $ | 307,819 | ​ | $ | 269,784 | ​ | $ | 165,111 | ​ | $ | 742,714 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 166,191 | ​ | $ | 216,423 | ​ | $ | 32,522 | ​ | $ | 415,136 |
| Over time | ​ | ​ | 141,628 | ​ | ​ | 53,361 | ​ | ​ | 132,589 | ​ | ​ | 327,578 |
| Total revenues | ​ | $ | 307,819 | ​ | $ | 269,784 | ​ | $ | 165,111 | ​ | $ | 742,714 |

[0001410578-25-001667:notes:69]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2024 are presented in the tables below.

[0001410578-25-001667:notes:70]
| Three months ended June 30, 2024 | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 43,927 | ​ | $ | 88,076 | ​ | $ | 42,327 | ​ | $ | 174,330 |
| Government | ​ | ​ | 43,308 | ​ | ​ | 2,201 | ​ | ​ | 13,729 | ​ | ​ | 59,238 |
| Total revenues | ​ | $ | 87,235 | ​ | $ | 90,277 | ​ | $ | 56,056 | ​ | $ | 233,568 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 69,228 | ​ | $ | 54,063 | ​ | $ | 32,575 | ​ | $ | 155,866 |
| International | ​ | ​ | 18,007 | ​ | ​ | 36,214 | ​ | ​ | 23,481 | ​ | ​ | 77,702 |
| Total revenues | ​ | $ | 87,235 | ​ | $ | 90,277 | ​ | $ | 56,056 | ​ | $ | 233,568 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 51,234 | ​ | $ | 72,985 | ​ | $ | 11,426 | ​ | $ | 135,645 |
| Over time | ​ | ​ | 36,001 | ​ | ​ | 17,292 | ​ | ​ | 44,630 | ​ | ​ | 97,923 |
| Total revenues | ​ | $ | 87,235 | ​ | $ | 90,277 | ​ | $ | 56,056 | ​ | $ | 233,568 |

[0001410578-25-001667:notes:71]
| Nine months ended June 30, 2024 | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 126,191 | ​ | $ | 254,765 | ​ | $ | 111,951 | ​ | $ | 492,907 |
| Government | ​ |  | 115,088 | ​ |  | 5,805 | ​ |  | 31,821 | ​ |  | 152,714 |
| Total revenues | ​ | $ | 241,279 | ​ | $ | 260,570 | ​ | $ | 143,772 | ​ | $ | 645,621 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 190,264 | ​ | $ | 165,789 | ​ | $ | 82,370 | ​ | $ | 438,423 |
| International | ​ |  | 51,015 | ​ |  | 94,781 | ​ |  | 61,402 | ​ |  | 207,198 |
| Total revenues | ​ | $ | 241,279 | ​ | $ | 260,570 | ​ | $ | 143,772 | ​ | $ | 645,621 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 137,769 | ​ | $ | 209,973 | ​ | $ | 29,706 | ​ | $ | 377,448 |
| Over time | ​ |  | 103,510 | ​ |  | 50,597 | ​ |  | 114,066 | ​ |  | 268,173 |
| Total revenues | ​ | $ | 241,279 | ​ | $ | 260,570 | ​ | $ | 143,772 | ​ | $ | 645,621 |

[0001410578-25-001667:notes:72]
[same as prior period, unchanged from 0001410578-25-001145:notes:64]

[0001410578-25-001667:notes:73]
[same as prior period, unchanged from 0001410578-25-001145:notes:65]

[0001410578-25-001667:notes:74]
[same as prior period, unchanged from 0001410578-25-001145:notes:66]

[0001410578-25-001667:notes:75]
[same as prior period, unchanged from 0001410578-25-001145:notes:67]

[0001410578-25-001667:notes:76]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At June 30, 2025, the Company had $1,165.4 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 66% in the next twelve months.

[0001410578-25-001667:notes:77]
[same as prior period, unchanged from 0001410578-25-001145:notes:69]

[0001410578-25-001667:notes:78]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At June 30, 2025, contract assets, contract liabilities and accounts receivable from continuing operations totaled $91.7 million, $214.1 million and $238.0 million, respectively. During the first nine months of 2025, the Company recognized approximately $54 million in revenues that were included in the contract liabilities balance at September 30, 2024. At September 30, 2024, contract assets, contract liabilities and accounts receivable from continuing operations totaled $66.7 million, $90.3 million and $222.1 million, respectively.


## ese:OperatingAndFinancingLeasesOfLesseeDisclosureTextBlock

[0001410578-25-001667:notes:79]
14.  LEASES

[0001410578-25-001667:notes:80]
[same as prior period, unchanged from 0001410578-25-001145:notes:72]

[0001410578-25-001667:notes:81]
[same as prior period, unchanged from 0001410578-25-001145:notes:73]

[0001410578-25-001667:notes:82]
[same as prior period, unchanged from 0001410578-25-001145:notes:74]

[0001410578-25-001667:notes:83]
[same as prior period, unchanged from 0001410578-25-001145:notes:75]

[0001410578-25-001667:notes:84]
[same as prior period, unchanged from 0001410578-25-001145:notes:76]

[0001410578-25-001667:notes:85]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended |
| ​ | ​ | June 30, | ​ | June 30, |
| (Dollars in thousands) |  | 2025 |  | 2024 |
| Finance lease cost | ​ | ​ | ​ | ​ | ​ | ​ |
| Amortization of right-of-use assets | ​ | $ | 372 | ​ | $ | 372 |
| Interest on lease liabilities | ​ | ​ | 199 | ​ | ​ | 213 |
| Operating lease cost | ​ | ​ | 2,067 | ​ | ​ | 1,676 |
| Total lease costs | ​ | $ | 2,638 | ​ | $ | 2,261 |

[0001410578-25-001667:notes:86]
| ​ | ​ | Nine Months Ended | ​ | Nine Months Ended |
| ​ | ​ | June 30, | ​ | June 30, |
| (Dollars in thousands) |  | 2025 |  | 2024 |
| Finance lease cost | ​ | ​ | ​ | ​ | ​ | ​ |
| Amortization of right-of-use assets |  | $ | 1,116 |  | $ | 1,137 |
| Interest on lease liabilities | ​ | ​ | 607 | ​ | ​ | 652 |
| Operating lease cost | ​ | ​ | 5,528 | ​ | ​ | 4,892 |
| Total lease costs |  | $ | 7,251 |  | $ | 6,681 |

[0001410578-25-001667:notes:87]
[same as prior period, unchanged from 0001410578-25-001145:notes:79]

[0001410578-25-001667:notes:88]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended |
| ​ | ​ | June 30, | ​ | June 30, |
| (Dollars in thousands) |  | 2025 |  | 2024 |
| Cash paid for amounts included in the measurement of lease liabilities | ​ | ​ | ​ | ​ | ​ | ​ |
| Operating cash flows from operating leases | ​ | $ | 1,958 | ​ | $ | 1,605 |
| Operating cash flows from finance leases | ​ | ​ | 199 | ​ | ​ | 213 |
| Financing cash flows from finance leases | ​ | ​ | 358 | ​ | ​ | 331 |
| Right-of-use assets obtained in exchange for operating lease liabilities | ​ | ​ | 10,259 | ​ | ​ | 515 |

[0001410578-25-001667:notes:89]
| ​ | ​ | Nine Months Ended | ​ | Nine Months Ended |
| ​ | ​ | June 30, | ​ | June 30, |
| (Dollars in thousands) |  | 2025 |  | 2024 |
| Cash paid for amounts included in the measurement of lease liabilities | ​ | ​ | ​ | ​ | ​ | ​ |
| Operating cash flows from operating leases | ​ | $ | 5,271 | ​ | $ | 4,724 |
| Operating cash flows from finance leases | ​ |  | 607 | ​ |  | 652 |
| Financing cash flows from finance leases | ​ |  | 1,065 | ​ |  | 1,013 |
| Right-of-use assets obtained in exchange for operating lease liabilities | ​ | ​ | 14,232 | ​ | ​ | 2,194 |

[0001410578-25-001667:notes:90]
| ​ | ​ | June 30, |  | June 30, | ​ |
| ​ | ​ | 2025 | ​ | 2024 | ​ |
| Weighted-average remaining lease term | ​ |  | ​ |  | ​ |
| Operating leases |  | 9.6 | years | 10.8 | years |
| Finance leases |  | 9.8 | years | 11.1 | years |
| Weighted-average discount rate |  | ​ |  | ​ |  |
| Operating leases |  | 4.75 | % | 4.58 | % |
| Finance leases |  | 4.73 | % | 4.69 | % |

[0001410578-25-001667:notes:91]
The following is a reconciliation of future undiscounted cash flows to the operating and finance lease liabilities, and the related ROU assets, presented on our condensed Consolidated Balance Sheet on June 30, 2025:

[0001410578-25-001667:notes:92]
| (Dollars in thousands) | ​ | Operating |  | Finance |
| Years Ending September 30: |  | Leases |  | Leases |
| 2025 (excluding the nine months ended June 30, 2025) | ​ | $ | 2,007 | ​ | 561 |
| 2026 | ​ | ​ | 7,470 | ​ | 2,297 |
| 2027 | ​ | ​ | 7,225 | ​ | 2,357 |
| 2028 | ​ | ​ | 7,095 | ​ | 2,417 |
| 2029 and thereafter | ​ | ​ | 38,434 | ​ | 14,053 |
| Total minimum lease payments | ​ | ​ | 62,231 | ​ | 21,685 |
| Less: amounts representing interest | ​ | ​ | 12,977 | ​ | 4,766 |
| Present value of net minimum lease payments | ​ | $ | 49,254 | ​ | 16,919 |
| Less: current portion of lease obligations | ​ | ​ | 5,621 | ​ | 1,523 |
| Non-current portion of lease obligations | ​ | ​ | 43,633 | ​ | 15,396 |
| ROU assets | ​ | $ | 46,796 | ​ | 12,566 |

[0001410578-25-001667:notes:93]
Operating lease liabilities are included in the condensed Consolidated Balance Sheet in accrued other expenses (current portion) and as a caption on the Consolidated Balance Sheet (long-term portion). Finance lease liabilities are included on the Consolidated Balance Sheet in accrued other expenses (current portion) and other liabilities (long-term portion). Operating lease ROU assets are included as a caption on the Consolidated Balance Sheet and finance lease ROU assets are included in Property, plant and equipment on the Consolidated Balance sheet.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001410578-25-001667:notes:94]
15.  NEW ACCOUNTING PRONOUNCEMENTS

[0001410578-25-001667:notes:95]
In November 2024, the FASB issued ASU 2024-03, “Disaggregation of Income Statement Expenses,” which requires disaggregated disclosure of income statement expenses for public business entities. The ASU does not change the expense captions an entity presents on the face of the income statement, rather, it requires disaggregation of certain expense captions into specified categories in disclosures within the footnotes to the financial statements. This ASU will be effective for fiscal years beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027. Other than additional disclosure, we do not expect a change to our consolidated statements of operations, financial position, or cash flows.

[0001410578-25-001667:notes:96]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures,” which provides qualitative and quantitative updates to the rate reconciliation and income taxes paid disclosures. This ASU will be effective for fiscal years beginning after December 15, 2024. Other than additional disclosure, we do not expect a change to our consolidated statements of operations, financial position, or cash flows.

[0001410578-25-001667:notes:97]
In November 2023, the FASB issued ASU 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures,” which expands annual and interim disclosure requirements for reportable segments, primarily through enhanced disclosures about significant expenses. The new segment disclosures are effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024. Other than additional disclosure, we do not expect a change to our consolidated statements of operations, financial position, or cash flows.


## us-gaap:SubsequentEventsTextBlock

[0001410578-25-001667:notes:98]
16. SUBSEQUENT EVENT

[0001410578-25-001667:notes:99]
See subsequent event item noted in footnote 4 related to the Company’s divestiture of VACCO.
