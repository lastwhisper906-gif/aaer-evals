# ESE 8-K — 0001104659-25-075202 filed 2025-08-07

## item codes, every 8-K on or before 2025-08-11

- 2025-08-07 0001104659-25-075202 — 2.02, 7.01, 9.01
- 2025-05-07 0001104659-25-045548 — 2.02, 7.01, 9.01
- 2025-04-28 0001104659-25-039819 — 2.01, 7.01, 9.01
- 2025-02-06 0001104659-25-010118 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2024-11-14 0001104659-24-118951 — 2.02, 5.02, 7.01, 9.01
- 2024-10-18 0001104659-24-109788 — 5.02
- 2024-10-01 0001104659-24-104776 — 5.02
- 2024-08-07 0001104659-24-086768 — 1.01, 2.02, 5.02, 7.01, 9.01
- 2024-07-08 0001104659-24-078312 — 1.01, 7.01, 9.01
- 2024-05-09 0001104659-24-059341 — 2.02, 7.01, 9.01
- 2024-02-08 0001104659-24-012294 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2023-11-20 0001104659-23-119761 — 5.02, 9.01
- 2023-11-16 0001104659-23-119126 — 2.02, 7.01, 9.01
- 2023-10-03 0001104659-23-106090 — 5.02, 9.01
- 2023-09-06 0001104659-23-098463 — 1.01, 2.03, 9.01
- 2023-08-08 0001104659-23-088847 — 2.02, 7.01, 9.01
- 2023-07-06 0001104659-23-078571 — 5.02, 8.01, 9.01
- 2023-05-09 0001104659-23-057736 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2023-05-05 0001104659-23-056387 — 5.02, 9.01
- 2023-02-08 0001104659-23-014539 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2023-01-06 0001104659-23-001859 — 5.02, 9.01
- 2022-11-22 0001104659-22-121229 — 5.02, 5.03, 8.01, 9.01
- 2022-11-17 0001104659-22-119898 — 2.02, 7.01, 9.01
- 2022-09-12 0001104659-22-099248 — 5.02, 7.01, 9.01
- 2022-08-08 0001104659-22-087247 — 2.02, 5.02, 7.01, 9.01
- 2022-05-09 0001104659-22-057524 — 2.02, 5.02, 7.01, 9.01
- 2022-02-08 0001104659-22-013878 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2021-12-03 0001104659-21-146361 — 4.01, 9.01 — amendment, the index does not say of what
- 2021-11-24 0001104659-21-143568 — 4.01, 9.01
- 2021-11-23 0001104659-21-142871 — 5.02, 8.01
- 2021-11-18 0001104659-21-141206 — 2.02, 7.01, 9.01
- 2021-08-09 0001104659-21-102150 — 2.02, 7.01, 9.01
- 2021-05-04 0001104659-21-060985 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2021-04-05 0001104659-21-046581 — 5.02, 9.01
- 2021-02-08 0001104659-21-013712 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2020-12-09 0001104659-20-133674 — 5.02, 9.01
- 2020-12-07 0001104659-20-132861 — 5.02, 7.01, 9.01
- 2020-11-19 0001104659-20-127352 — 2.02, 5.02, 7.01, 9.01
- 2020-08-10 0001104659-20-092734 — 2.02, 7.01, 9.01
- 2020-05-06 0001104659-20-057442 — 2.02, 7.01, 8.01, 9.01
- 2020-02-04 0001104659-20-010640 — 2.02, 5.07, 7.01, 9.01
- 2020-01-07 0001104659-20-001789 — 2.01, 9.01
- 2019-11-19 0001104659-19-065437 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2019-11-18 0001104659-19-065096 — 1.01, 2.02, 7.01, 9.01
- 2019-09-30 0001144204-19-046523 — 1.01, 1.02, 2.03, 9.01
- 2019-08-08 0001144204-19-038567 — 2.02, 7.01, 9.01
- 2019-05-07 0001144204-19-024241 — 2.02, 5.02, 7.01, 9.01
- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2025-08-11

- none on or before 2025-08-11

## item 2.02 — earnings release, exhibit 99.1

[0001104659-25-075202:8k_2_02:1]
EX-99.1
2
tm2522627d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-25-075202:8k_2_02:2]
Exhibit 99.1

[0001104659-25-075202:8k_2_02:3]
For more information contact:

[0001104659-25-075202:8k_2_02:4]
Kate Lowrey - VP of
Investor Relations

[0001104659-25-075202:8k_2_02:5]
(314) 213-7277 / klowrey@escotechnologies.com

[0001104659-25-075202:8k_2_02:6]
ESCO REPORTS
THIRD QUARTER FISCAL 2025 RESULTS

[0001104659-25-075202:8k_2_02:7]
- Q3 Sales increase 27% to $296 Million
-

[0001104659-25-075202:8k_2_02:8]
- Q3 GAAP EPS from Continuing Operations
decreases 13% to $0.96 -

[0001104659-25-075202:8k_2_02:9]
- Q3 Adjusted EPS from Continuing Operations
increases 25% to $1.60 -

[0001104659-25-075202:8k_2_02:10]
- Q3 Orders increase 194% to $749 Million
/ Book-to-Bill of 2.53x -

[0001104659-25-075202:8k_2_02:11]
- Increasing Guidance for FY’25
Adjusted EPS from Continuing Operations to $5.75-5.90 (21%-24% growth) -

[0001104659-25-075202:8k_2_02:12]
ST. LOUIS, August 7, 2025 – ESCO Technologies Inc. (NYSE:
ESE) (ESCO, or the Company) today reported its operating results for the third quarter ended June 30, 2025 (Q3 2025).

[0001104659-25-075202:8k_2_02:13]
On July 21, 2025, the Company announced
that it had completed the sale of VACCO Industries. The VACCO operating results are presented as Discontinued Operations in the
attached tables and are excluded from the following discussion of the Company’s results from Continuing Operations for the comparable
periods. Prior Adjusted Earnings per Share guidance of $1.58 to $1.72 for the third quarter included VACCO’s estimated results,
and actual Adjusted Earnings per Share on this basis was $1.67.

[0001104659-25-075202:8k_2_02:14]
Operating Highlights

[0001104659-25-075202:8k_2_02:15]
|  | · | Q3 2025 Sales increased $62.7 million (27 percent) to $296.3 million compared to $233.6 million in Q3 2024. Organic Sales (excluding $37.1 million of Maritime sales for the 2 months post-closing) increased $25.6 million (11 percent) to $259.2 million. |

[0001104659-25-075202:8k_2_02:16]
|  | · | Q3 2025 Entered Orders were $749.0 million with a book-to-bill ratio of 2.53x, resulting in record backlog of $1.17 billion. Q3 Orders included $364.2 million of acquired backlog at Maritime. |

[0001104659-25-075202:8k_2_02:17]
|  | · | Q3 2025 GAAP EPS from Continuing Operations decreased 13 percent to $0.96 per share compared to $1.10 per share in Q3 2024. The decrease in GAAP EPS was primarily due to costs related to the Maritime acquisition in the quarter. |

[0001104659-25-075202:8k_2_02:18]
|  | · | Q3 2025 Adjusted EPS from Continuing Operations increased 25 percent to $1.60 per share compared to $1.28 per share in Q3 2024. |

[0001104659-25-075202:8k_2_02:19]
|  | · | Net Cash provided by Operating Activities from Continuing Operations was $88 million YTD, an increase of $25 million compared to the prior year period. Net Cash provided by Operating Activities from Discontinued Operations was $44 million for total Cash Flow from Operating Activities of $132 million YTD, an increase of $77 million compared to the prior year period. |

[0001104659-25-075202:8k_2_02:20]
Bryan Sayler, Chief Executive
Officer and President, commented, “It has been a transformational period at ESCO as we have focused on integrating ESCO Maritime
Solutions (Maritime) and finalizing the divestiture of VACCO Industries. With the completion of these transactions, we have taken an important
step forward in the evolution of ESCO. We now have a meaningfully larger Navy business and have exited the space business. The impact
of these changes can be seen both in our top and bottom line results, as our Sales increased 27 percent, Adjusted EPS from Continuing
Operations increased 25 percent, and Adjusted EBIT margin increased 180 basis points to 21.1 percent in the quarter.

[0001104659-25-075202:8k_2_02:21]
“Our newly enhanced portfolio of businesses is well
positioned in end markets with attractive long term growth dynamics. With this strong market presence and our record backlog, we
expect to continue to deliver above market growth and are pleased to issue Q4 guidance that once again raises our
full year FY 2025 outlook.”

[0001104659-25-075202:8k_2_02:22]
Segment Performance

[0001104659-25-075202:8k_2_02:23]
Aerospace & Defense (A&D)

[0001104659-25-075202:8k_2_02:24]
|  | · | Sales increased $49.1 million (56 percent) to $136.3 million in Q3 2025 from $87.2 million in Q3 2024. The sales strength was driven by higher Navy (increased $34 million or 200 percent) and Aerospace (increased $13 million or 19 percent) compared to the prior year. Organic Sales (excluding $37.1 million of Maritime revenue for the 2 months post-closing) increased $12.0 million (14 percent) to $99.2 million. |

[0001104659-25-075202:8k_2_02:25]
|  | · | EBIT increased $16.4 million in Q3 2025 to $36.6 million from $20.2 million in Q3 2024. Adjusted EBIT increased $19.1 million in Q3 2025 to $39.3 million (28.8 percent margin) from $20.2 million (23.2 percent margin) in Q3 2024. Margin improvement was driven by price increases, mix, and leverage on higher volume, partially offset by inflationary pressures. The addition of Maritime also had a positive impact on the Adjusted EBIT margin in the quarter. |

[0001104659-25-075202:8k_2_02:26]
|  | · | Entered Orders increased $492 million (547 percent) to $582 million in Q3 2025 compared to $90 million in Q3 2024. Q3 2025 included $364 million of acquired backlog at Maritime. Without this impact, A&D orders increased $128 million (142 percent) to $218 million. The orders strength was driven by over $80 million in Virginia Class and Columbia Class orders at Globe and almost $50 million in orders at Maritime during the quarter. The segment book-to-bill was 4.27x in the quarter (1.60x without the acquired Maritime backlog), resulting in record backlog of $832 million. |

[0001104659-25-075202:8k_2_02:27]
Utility Solutions Group (USG)

[0001104659-25-075202:8k_2_02:28]
|  | · | Sales increased $2.1 million (2 percent) to $92.4 million in Q3 2025 from $90.3 million in Q3 2024. Doble’s sales increased by $0.7 million (1 percent) driven by higher offline testing products, partially offset by lower protection testing products revenue. NRG sales increased $1.4 million (8 percent) on higher wind and solar hardware sales. USG Q3 YTD Sales increased $9.2 million (4 percent) as Doble sales are up 6 percent, partially offset by lower NRG sales due to renewables market weakness. |

[0001104659-25-075202:8k_2_02:29]
|  | · | EBIT decreased $0.7 million in Q3 2025 to $21.5 million from $22.2 million in Q3 2024. Adjusted EBIT decreased $0.4 million in Q3 2025 to $21.8 million (23.6 percent margin) from $22.2 million (24.6 percent margin) in Q3 2024. Margin was unfavorably impacted by inflationary pressures and mix, partially offset by price increases. USG’s Q3 YTD Adjusted EBIT margin of 23.4 percent has increased 130 basis points over the prior year as price increases and leverage on higher volume have more than offset inflationary pressures. |

[0001104659-25-075202:8k_2_02:30]
|  | · | Entered Orders increased $6 million (6 percent) to $106 million in Q3 2025. Record quarterly orders at Doble of $87 million increased by $6 million (7 percent) over the prior year on strength across all product lines and highlighted by a large HV Test System order. NRG orders were flat to the prior year as lower orders in the U.S. were offset by higher wind orders in Canada and solar orders in Europe. The segment book-to-bill was 1.14x in the quarter, resulting in backlog of $137 million. |

[0001104659-25-075202:8k_2_02:31]
RF Test & Measurement (Test)

[0001104659-25-075202:8k_2_02:32]
|  | · | Sales increased $11.6 million (21 percent) to $67.7 million in Q3 2025 from $56.1 million in Q3 2024. Sales growth was driven by higher Test and Measurement (EMC), industrial shielding, and services sales. |

[0001104659-25-075202:8k_2_02:33]
|  | · | EBIT and Adjusted EBIT increased $1.4 million in Q3 2025 to $10.7 million (15.9 percent margin) from $9.3 million (16.6 percent margin) in Q3 2024. Margin was unfavorably impacted by inflationary pressures and tariffs, partially offset by leverage on higher volume and price increases. |

[0001104659-25-075202:8k_2_02:34]
|  | · | Entered Orders decreased $4 million (6 percent) to $61 million in Q3 2025. The decrease was primarily driven by lower U.S. industrial orders (large project booked in Q3 2024) partially offset by a strong quarter for Test & Measurement. The segment book-to-bill was 0.90x in the quarter, resulting in backlog of $196 million. |

[0001104659-25-075202:8k_2_02:35]
Business Outlook
 – 2025

[0001104659-25-075202:8k_2_02:36]
FY 2025 full year guidance for revenue from continuing operations
is being increased by $20 million and is now expected to be in the range of $1.075 to $1.105 billion (17 to 20 percent increase over
the prior year). Organic revenue from continuing operations (excluding Maritime revenue of $90 to $100 million) is expected to be
$985 to $1,005 million (7 to 9 percent increase over the prior year).

[0001104659-25-075202:8k_2_02:37]
|  |  | Guidance Range ($ Millions) |  |
| Prior Guidance including Maritime (May) |  | $ | 1,180 |  |  | $ | 1,210 |  |
| Less Discontinued Operations (VACCO) |  | $ | (125 | ) |  | $ | (125 | ) |
| Guidance Increase |  | $ | 20 |  |  | $ | 20 |  |
| Updated Sales Guidance |  | $ | 1,075 |  |  | $ | 1,105 |  |

[0001104659-25-075202:8k_2_02:38]
Due to continued market strength and
improvement in operational performance, our FY 2025 Adjusted EPS guidance reflects an increase and narrowing of our guidance range
to $5.75 to $5.90 (21 to 24 percent growth over FY 2024 EPS from Continuing Operations of $4.77).

[0001104659-25-075202:8k_2_02:39]
|  |  | Guidance Range |  |
| Previous FY 2025 Adjusted EPS Guidance including Maritime (May) |  | $ | 5.85 |  |  | $ | 6.15 |  |
| Less Discontinued Operations (VACCO) |  | $ | (0.50 | ) |  | $ | (0.50 | ) |
| Continuing Operations Guidance Increase |  | $ | 0.40 |  |  | $ | 0.25 |  |
| Updated FY 2025 Adjusted EPS Guidance - Continuing Operations |  | $ | 5.75 |  |  | $ | 5.90 |  |

[0001104659-25-075202:8k_2_02:40]
Management’s expectation is for Q4 Adjusted EPS from Continuing
Operations to be in the range of $2.04 to $2.19 (14 to 22 percent growth over Q4 2024 Adjusted EPS from Continuing Operations of $1.79).

[0001104659-25-075202:8k_2_02:41]
Dividend Payment

[0001104659-25-075202:8k_2_02:42]
The next quarterly cash dividend of $0.08
per share will be paid on October 16, 2025 to stockholders of record on October 2, 2025.

[0001104659-25-075202:8k_2_02:43]
Conference Call

[0001104659-25-075202:8k_2_02:44]
The Company will host a conference call
today, August 7, at 4:00 p.m. Central Time, to discuss the Company’s Q3 2025 results. A live audio webcast and an accompanying
slide presentation will be available in the Investor Center of ESCO’s website. Participants may also access the webcast using
this registration link. For those unable to participate, a webcast replay will be available after the call in the Investor Center of ESCO’s
website.

[0001104659-25-075202:8k_2_02:45]
Forward-Looking Statements

[0001104659-25-075202:8k_2_02:46]
Investors are cautioned that such statements are only predictions and
speak only as of the date of this presentation, and the Company undertakes no duty to update them except as may be required by applicable
laws or regulations. The Company’s actual results in the future may differ materially from those projected in the forward-looking
statements due to risks and uncertainties that exist in the Company’s operations and business environment including but not limited
to those described in Item 1A, “Risk Factors”, of the Company’s Annual Report on Form 10-K for the fiscal year
ended September 30, 2024 and the following: the impacts of climate change and related regulation of greenhouse gases; the impacts
of labor disputes, civil disorder, wars, elections, political changes, tariffs and trade disputes, terrorist activities, cyberattacks
or natural disasters on the Company’s operations and those of the Company’s customers and suppliers; disruptions in manufacturing
or delivery arrangements due to shortages or unavailability of materials or components or supply chain disruptions; inability to access
work sites; the timing and content of future contract awards or customer orders; the timely appropriation, allocation and availability
of Government funds; the termination for convenience of Government and other customer contracts or orders; weakening of economic conditions
in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies; competition;
intellectual property rights; technical difficulties or data breaches; the availability of acquisitions; delivery delays or defaults by
customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability of certain
raw materials; material changes in the cost of credit; changes in laws and regulations including but not limited to changes in accounting
standards and taxation; changes in interest, inflation and employment rates; costs relating to environmental matters arising from current
or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the integration
and performance of acquired businesses.

[0001104659-25-075202:8k_2_02:47]
Non-GAAP Financial Measures

[0001104659-25-075202:8k_2_02:48]
The financial measures EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA,
and Adjusted EPS are presented in this press release. The Company defines “EBIT” as earnings before interest and taxes, “EBITDA”
as earnings before interest, taxes, depreciation and amortization, “Adjusted EBIT” and “Adjusted EBITDA” as excluding
the net impact of the items described in the attached Reconciliation of Non-GAAP Financial Measures, and “Adjusted EPS” as
GAAP earnings per share excluding the net impact of the items described and reconciled in the attached Reconciliation of Non-GAAP Financial
Measures.

[0001104659-25-075202:8k_2_02:49]
EBIT, Adjusted EBIT, EBITDA, Adjusted
EBITDA, and Adjusted EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management
believes EBIT, Adjusted EBIT, EBITDA, and Adjusted EBITDA are useful in assessing the operational profitability of the Company’s
business segments because they exclude interest, taxes, depreciation, and amortization, which are generally accounted for across the entire
Company on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company
as well as incentive compensation. The presentation of EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA, and Adjusted EPS provides important
supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures
to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance
determined in accordance with GAAP.

[0001104659-25-075202:8k_2_02:50]
About ESCO

[0001104659-25-075202:8k_2_02:51]
ESCO Technologies is a global provider
of highly engineered products and solutions serving diverse end-markets. It manufactures filtration and fluid control products, advanced
composites, as well as signature and power management solutions for aviation, Navy, and industrial customers. ESCO is an industry leader
in designing and manufacturing RF test and measurement products and systems; and provides diagnostic instruments, software and services
to industrial power users and the electric utility and renewable energy industries. Headquartered in St. Louis, Missouri, ESCO and its
subsidiaries have offices and manufacturing facilities worldwide. For more information on ESCO and its subsidiaries, visit ESCO’s
website at www.escotechnologies.com.

[0001104659-25-075202:8k_2_02:52]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-25-075202:8k_2_02:53]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-25-075202:8k_2_02:54]
(Dollars in thousands, except per share amounts)

[0001104659-25-075202:8k_2_02:55]
|  |  | Three Months Ended June 30, 2025 |  |  | Three Months Ended June 30, 2024 |  |
| Net Sales |  | $ | 296,344 |  |  |  | 233,568 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 174,350 |  |  |  | 135,373 |  |
| Selling, general and administrative expenses |  |  | 62,042 |  |  |  | 51,013 |  |
| Amortization of intangible assets |  |  | 16,753 |  |  |  | 8,145 |  |
| Interest expense |  |  | 7,921 |  |  |  | 3,335 |  |
| Other (income) expenses, net |  |  | 2,209 |  |  |  | (264 | ) |
| Total costs and expenses |  |  | 263,275 |  |  |  | 197,602 |  |
| Earnings before income taxes |  |  | 33,069 |  |  |  | 35,966 |  |
| Income tax expense |  |  | 8,314 |  |  |  | 7,654 |  |
| Earnings from continuing operations |  |  | 24,755 |  |  |  | 28,312 |  |
| Earnings from discontinued operations, net of tax expense (benefit) of $599 and $288 |  |  | 1,310 |  |  |  | 918 |  |
| Net earnings |  | $ | 26,065 |  |  |  | 29,230 |  |
| Diluted - GAAP |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.96 |  |  |  | 1.10 |  |
| Discontinued operations |  |  | 0.05 |  |  |  | 0.03 |  |
| Net earnings |  | $ | 1.01 |  |  |  | 1.13 |  |
| Diluted - As Adjusted Basis |  |  |  |  |  |  |  |  |
| Continuing Operations |  | $ | 1.60 | (1) |  |  | 1.28 | (2) |
| Diluted average common shares O/S: |  |  | 25,918 |  |  |  | 25,840 |  |

[0001104659-25-075202:8k_2_02:56]
| (1) | Q3 2025 Adjusted EPS from continuing operations excludes $0.64 per share of after-tax charges consisting of: $0.15 of Corporate acquisition costs, $0.08 of Maritime inventory step-up charges and stamp duties, $0.01 of restructuring charges (primarily severance) within the USG segment, and $0.40 of acquisition related amortization. |
| (2) | Q3 2024 Adjusted EPS from continuing operations excludes $0.18 per share of after-tax charges consisting of: $0.02 of Corporate acquisition costs, $0.01 or restructuring charges within the A&D and USG segments, and $0.15 of acquisition related amortization. |

[0001104659-25-075202:8k_2_02:57]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-25-075202:8k_2_02:58]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-25-075202:8k_2_02:59]
(Dollars
in thousands, except per share amounts)

[0001104659-25-075202:8k_2_02:60]
|  |  | Nine Months Ended June 30, 2025 |  |  | Nine Months Ended June 30, 2024 |  |
| Net Sales |  | $ | 742,714 |  |  |  | 645,621 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 431,068 |  |  |  | 378,427 |  |
| Selling, general and administrative expenses |  |  | 171,305 |  |  |  | 152,607 |  |
| Amortization of intangible assets |  |  | 32,735 |  |  |  | 24,585 |  |
| Interest expense |  |  | 12,373 |  |  |  | 9,228 |  |
| Other expenses (income), net |  |  | 1,947 |  |  |  | 404 |  |
| Total costs and expenses |  |  | 649,428 |  |  |  | 565,251 |  |
| Earnings before income taxes |  |  | 93,286 |  |  |  | 80,370 |  |
| Income tax expense |  |  | 21,841 |  |  |  | 17,040 |  |
| Earnings from continuing operations |  |  | 71,445 |  |  |  | 63,330 |  |
| Earnings from discontinued operations, net of tax expense (benefit) of $3,006 and $1,189 |  |  | 9,126 |  |  |  | 4,288 |  |
| Net earnings |  | $ | 80,571 |  |  |  | 67,618 |  |
| Diluted - GAAP |  |  |  |  |  |  |  |  |
| Continuing operations |  |  | 2.76 |  |  |  | 2.46 |  |
| Discontinued operations |  |  | 0.35 |  |  |  | 0.16 |  |
| Net earnings |  | $ | 3.11 |  |  |  | 2.62 |  |
| Diluted - As Adjusted Basis |  |  |  |  |  |  |  |  |
| Continuing Operations |  | $ | 3.71 | (1) |  |  | 2.99 | (2) |
| Diluted average common shares O/S: |  |  | 25,876 |  |  |  | 25,844 |  |

[0001104659-25-075202:8k_2_02:61]
| (1) | YTD Q3 2025 Adjusted EPS from continuing operations excludes $0.95 per share of after-tax charges consisting primarily of: $0.15 of Corporate acquisition costs, $0.08 of Maritime inventory step-up charges and stamp duties, $0.02 of restructuring charges within the Test and USG segments, and $0.70 of acquisition related amortization. |
| (2) | YTD Q3 2024 Adjusted EPS from continuing operations excludes $0.53 per share of after-tax charges consisting of: $0.06 of MPE acquisition backlog and inventory step-up charges and acquisition costs, $0.03 of restructuring charges (primarily severance) within the Test, A&D and USG segments, and $0.44 of acquisition related amortization. |

[0001104659-25-075202:8k_2_02:62]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-25-075202:8k_2_02:63]
Condensed Business Segment Information (Unaudited) - Continuing Operations basis

[0001104659-25-075202:8k_2_02:64]
(Dollars in thousands)

[0001104659-25-075202:8k_2_02:65]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | Q3 2025 |  |  | Q3 2024 |  |  | Q3 2025 |  |  | Q3 2024 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 136,324 |  |  |  | 87,235 |  |  |  | 136,324 |  |  |  | 87,235 |  |
| USG |  |  | 92,357 |  |  |  | 90,277 |  |  |  | 92,357 |  |  |  | 90,277 |  |
| Test |  |  | 67,663 |  |  |  | 56,056 |  |  |  | 67,663 |  |  |  | 56,056 |  |
| Totals |  | $ | 296,344 |  |  |  | 233,568 |  |  |  | 296,344 |  |  |  | 233,568 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 36,577 |  |  |  | 20,150 |  |  |  | 39,319 |  |  |  | 20,233 |  |
| USG |  |  | 21,540 |  |  |  | 22,155 |  |  |  | 21,789 |  |  |  | 22,230 |  |
| Test |  |  | 10,732 |  |  |  | 9,292 |  |  |  | 10,732 |  |  |  | 9,297 |  |
| Corporate |  |  | (27,859 | ) |  |  | (12,296 | ) |  |  | (9,184 | ) |  |  | (6,566 | ) |
| Consolidated EBIT |  |  | 40,990 |  |  |  | 39,301 |  |  |  | 62,656 |  |  |  | 45,194 |  |
| Less: Interest expense |  |  | (7,921 | ) |  |  | (3,335 | ) |  |  | (7,921 | ) |  |  | (3,335 | ) |
| Less: Income tax expense |  |  | (8,314 | ) |  |  | (7,654 | ) |  |  | (13,297 | ) |  |  | (9,009 | ) |
| Net earnings |  | $ | 24,755 |  |  |  | 28,312 |  |  |  | 41,438 |  |  |  | 32,850 |  |

[0001104659-25-075202:8k_2_02:66]
Note 1: Adjusted net earnings of $41.4 million in Q3 2025 exclude $16.6 million (or $0.64 per share) of after-tax charges consisting of:  $0.15 of Corporate acquisition costs, $0.08 of Maritime inventory step-up charges and stamp duties, $0.01 of restructuring charges (primarily severance) within the USG segment, and $0.40 of acquisition related amortization.

[0001104659-25-075202:8k_2_02:67]
Note 2: Adjusted net earnings of $32.9 million in Q3 2024 exclude $4.5 million (or $0.18 per share) of after-tax charges consisting of:  $0.02 of Corporate acquisition related costs, $0.01 of restructuring charges (primarily severance) within the A&D and USG segments, and $0.15 of acquisition related amortization.

[0001104659-25-075202:8k_2_02:68]
| EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |  | Q3 2025 - |  |  | Q3 2024 - |  |
|  |  | Q3 2025 |  |  | Q3 2024 |  |  | As Adj |  |  | As Adj |  |
| Consolidated EBITDA |  | $ | 63,350 |  |  |  | 52,302 |  |  |  | 71,545 |  |  |  | 53,195 |  |
| Less: Depr & Amort |  |  | (22,360 | ) |  |  | (13,001 | ) |  |  | (8,889 | ) |  |  | (8,001 | ) |
| Consolidated EBIT |  |  | 40,990 |  |  |  | 39,301 |  |  |  | 62,656 |  |  |  | 45,194 |  |
| Less: Interest expense |  |  | (7,921 | ) |  |  | (3,335 | ) |  |  | (7,921 | ) |  |  | (3,335 | ) |
| Less: Income tax expense |  |  | (8,314 | ) |  |  | (7,654 | ) |  |  | (13,297 | ) |  |  | (9,009 | ) |
| Net earnings |  | $ | 24,755 |  |  |  | 28,312 |  |  |  | 41,438 |  |  |  | 32,850 |  |

[0001104659-25-075202:8k_2_02:69]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-25-075202:8k_2_02:70]
Condensed Business Segment Information (Unaudited) - Continuing Operations basis

[0001104659-25-075202:8k_2_02:71]
(Dollars in thousands)

[0001104659-25-075202:8k_2_02:72]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | YTD |  |  | YTD |  |  | YTD |  |  | YTD |  |
|  |  | Q3 2025 |  |  | Q3 2024 |  |  | Q3 2025 |  |  | Q3 2024 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 307,819 |  |  |  | 241,279 |  |  |  | 307,819 |  |  |  | 241,279 |  |
| USG |  |  | 269,784 |  |  |  | 260,570 |  |  |  | 269,784 |  |  |  | 260,570 |  |
| Test |  |  | 165,111 |  |  |  | 143,772 |  |  |  | 165,111 |  |  |  | 143,772 |  |
| Totals |  | $ | 742,714 |  |  |  | 645,621 |  |  |  | 742,714 |  |  |  | 645,621 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 78,246 |  |  |  | 55,919 |  |  |  | 81,016 |  |  |  | 56,061 |  |
| USG |  |  | 62,808 |  |  |  | 57,355 |  |  |  | 63,140 |  |  |  | 57,550 |  |
| Test |  |  | 21,523 |  |  |  | 16,613 |  |  |  | 21,988 |  |  |  | 17,094 |  |
| Corporate |  |  | (56,918 | ) |  |  | (40,289 | ) |  |  | (28,142 | ) |  |  | (23,426 | ) |
| Consolidated EBIT |  |  | 105,659 |  |  |  | 89,598 |  |  |  | 138,002 |  |  |  | 107,279 |  |
| Less: Interest expense |  |  | (12,373 | ) |  |  | (9,228 | ) |  |  | (12,373 | ) |  |  | (9,228 | ) |
| Less: Income tax |  |  | (21,841 | ) |  |  | (17,040 | ) |  |  | (29,279 | ) |  |  | (21,106 | ) |
| Net earnings |  | $ | 71,445 |  |  |  | 63,330 |  |  |  | 96,350 |  |  |  | 76,945 |  |

[0001104659-25-075202:8k_2_02:73]
Note 1: Adjusted net earnings of $96.4 million in YTD 2025 exclude $24.9 million (or $0.95 per share) of after-tax charges consisting of:  $0.15 of Corporate acquisition costs, $0.08 of Maritime inventory step-up charges and stamp duties, $0.02 of restructuring charges within the Test and USG segments, and $0.70 of acquisition related amortization.

[0001104659-25-075202:8k_2_02:74]
Note 2: Adjusted net earnings of $76.9 million in YTD 2024 exclude $13.6 million (or $0.53 per share) of after-tax charges consisting of $0.06 of MPE acquisition backlog and inventory step-up charges and acquisition costs, $0.03 of restructuring costs (primarily severance) within the Test, A&D and USG segments, and $0.44 of acquisition related amortization.

[0001104659-25-075202:8k_2_02:75]
| EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |  | YTD |  |  | YTD |  |
|  |  | YTD |  |  | YTD |  |  | Q3 2025 - |  |  | Q3 2024 - |  |
|  |  | Q3 2025 |  |  | Q3 2024 |  |  | As Adj |  |  | As Adj |  |
| Consolidated EBITDA |  | $ | 154,060 |  |  |  | 128,570 |  |  |  | 162,975 |  |  |  | 130,718 |  |
| Less: Depr & Amort |  |  | (48,401 | ) |  |  | (38,972 | ) |  |  | (24,973 | ) |  |  | (23,439 | ) |
| Consolidated EBIT |  |  | 105,659 |  |  |  | 89,598 |  |  |  | 138,002 |  |  |  | 107,279 |  |
| Less: Interest expense |  |  | (12,373 | ) |  |  | (9,228 | ) |  |  | (12,373 | ) |  |  | (9,228 | ) |
| Less: Income tax expense |  |  | (21,841 | ) |  |  | (17,040 | ) |  |  | (29,279 | ) |  |  | (21,106 | ) |
| Net earnings |  | $ | 71,445 |  |  |  | 63,330 |  |  |  | 96,350 |  |  |  | 76,945 |  |

[0001104659-25-075202:8k_2_02:76]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-25-075202:8k_2_02:77]
Condensed Consolidated Balance Sheets (Unaudited)

[0001104659-25-075202:8k_2_02:78]
(Dollars
in thousands)

[0001104659-25-075202:8k_2_02:79]
|  |  | June 30, 2025 |  |  | September 30, 2024 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 78,716 |  |  |  | 65,963 |  |
| Accounts receivable, net |  |  | 238,022 |  |  |  | 222,101 |  |
| Contract assets |  |  | 91,727 |  |  |  | 66,712 |  |
| Inventories |  |  | 237,110 |  |  |  | 195,465 |  |
| Other current assets |  |  | 32,596 |  |  |  | 21,027 |  |
| Assets held for sale - current |  |  | 76,552 |  |  |  | 97,381 |  |
| Total current assets |  |  | 754,723 |  |  |  | 668,649 |  |
| Property, plant and equipment, net |  |  | 167,236 |  |  |  | 149,251 |  |
| Intangible assets, net |  |  | 745,079 |  |  |  | 403,524 |  |
| Goodwill |  |  | 760,555 |  |  |  | 529,935 |  |
| Operating lease assets |  |  | 46,796 |  |  |  | 37,476 |  |
| Other assets |  |  | 17,208 |  |  |  | 13,791 |  |
| Assets held for sale - other |  |  | 34,788 |  |  |  | 35,994 |  |
|  |  | $ | 2,526,385 |  |  |  | 1,838,620 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt |  | $ | 20,000 |  |  |  | 20,000 |  |
| Accounts payable |  |  | 86,209 |  |  |  | 88,936 |  |
| Contract liabilities |  |  | 205,591 |  |  |  | 80,844 |  |
| Other current liabilities |  |  | 110,535 |  |  |  | 97,575 |  |
| Liabilities held for sale - current |  |  | 74,505 |  |  |  | 62,499 |  |
| Total current liabilities |  |  | 496,840 |  |  |  | 349,854 |  |
| Deferred tax liabilities |  |  | 115,023 |  |  |  | 72,623 |  |
| Non-current operating lease liabilities |  |  | 43,633 |  |  |  | 34,810 |  |
| Other liabilities |  |  | 36,500 |  |  |  | 39,273 |  |
| Long-term debt |  |  | 505,000 |  |  |  | 102,000 |  |
| Liabilities held for sale - other |  |  | 2,775 |  |  |  | 2,710 |  |
| Shareholders' equity |  |  | 1,326,614 |  |  |  | 1,237,350 |  |
|  |  | $ | 2,526,385 |  |  |  | 1,838,620 |  |

[0001104659-25-075202:8k_2_02:80]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-25-075202:8k_2_02:81]
Consolidated Statements of Cash Flows (Unaudited)

[0001104659-25-075202:8k_2_02:82]
(Dollars in thousands)

[0001104659-25-075202:8k_2_02:83]
|  |  | Nine Months Ended June 30, 2025 |  |  | Nine Months Ended June 30, 2024 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 80,571 |  |  |  | 67,618 |  |
| (Earnings) loss from discontinued operations |  |  | (9,126 | ) |  |  | (4,288 | ) |
| Adjustments to reconcile net earnings to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 48,401 |  |  |  | 38,972 |  |
| Stock compensation expense |  |  | 7,934 |  |  |  | 6,369 |  |
| Changes in assets and liabilities |  |  | (33,473 | ) |  |  | (39,275 | ) |
| Effect of deferred taxes |  |  | (6,008 | ) |  |  | (6,302 | ) |
| Net cash provided by operating activities - continuing operations |  |  | 88,299 |  |  |  | 63,094 |  |
| Net cash provided (used) by operating activities - disc ops |  |  | 43,703 |  |  |  | (7,640 | ) |
| Net cash provided by operating activities |  |  | 132,002 |  |  |  | 55,454 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Acquisition of business, net of cash acquired |  |  | (472,006 | ) |  |  | (56,383 | ) |
| Capital expenditures |  |  | (24,210 | ) |  |  | (19,551 | ) |
| Additions to capitalized software |  |  | (13,018 | ) |  |  | (8,515 | ) |
| Net cash used by investing activities - continuing operations |  |  | (509,234 | ) |  |  | (84,449 | ) |
| Net cash used by investing activities - discontinued operations |  |  | (966 | ) |  |  | (5,439 | ) |
| Net cash used by investing activities |  |  | (510,200 | ) |  |  | (89,888 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from long-term debt |  |  | 645,000 |  |  |  | 193,000 |  |
| Principal payments on long-term debt and short-term borrowings |  |  | (242,000 | ) |  |  | (122,000 | ) |
| Dividends paid |  |  | (6,196 | ) |  |  | (6,185 | ) |
| Purchases of common stock into treasury |  |  | 0 |  |  |  | (7,998 | ) |
| Other |  |  | (6,205 | ) |  |  | (1,516 | ) |
| Net cash provided by financing activities - continuing operations |  |  | 390,599 |  |  |  | 55,301 |  |
| Net cash used by financing activities - discontinued operations |  |  | 0 |  |  |  | 0 |  |
| Net cash provided by financing activities |  |  | 390,599 |  |  |  | 55,301 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 452 |  |  |  | 309 |  |
| Net increase in cash and cash equivalents |  |  | 12,853 |  |  |  | 21,176 |  |
| Cash and cash equivalents, beginning of period |  |  | 65,963 |  |  |  | 41,866 |  |
| Cash and cash equivalents, end of period |  | $ | 78,816 |  |  |  | 63,042 |  |

[0001104659-25-075202:8k_2_02:84]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-25-075202:8k_2_02:85]
Other Selected Financial Data (Unaudited) - Continuing Operations Basis

[0001104659-25-075202:8k_2_02:86]
(Dollars in thousands)

[0001104659-25-075202:8k_2_02:87]
| Backlog And Entered Orders - Q3 2025 |  | A&D |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 4/1/25 |  | $ | 385,491 |  |  |  | 124,274 |  |  |  | 202,971 |  |  |  | 712,736 |  |
| Entered Orders |  |  | 582,354 |  |  |  | 105,524 |  |  |  | 61,152 |  |  |  | 749,030 |  |
| Sales |  |  | (136,324 | ) |  |  | (92,357 | ) |  |  | (67,663 | ) |  |  | (296,344 | ) |
| Ending Backlog - 6/30/25 |  | $ | 831,521 |  |  |  | 137,441 |  |  |  | 196,460 |  |  |  | 1,165,422 |  |

[0001104659-25-075202:8k_2_02:88]
| Backlog And Entered Orders - YTD Q3 2025 |  | A&D |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 10/1/24 |  | $ | 385,601 |  |  |  | 119,943 |  |  |  | 158,644 |  |  |  | 664,188 |  |
| Entered Orders |  |  | 753,739 |  |  |  | 287,282 |  |  |  | 202,927 |  |  |  | 1,243,948 |  |
| Sales |  |  | (307,819 | ) |  |  | (269,784 | ) |  |  | (165,111 | ) |  |  | (742,714 | ) |
| Ending Backlog - 6/30/25 |  | $ | 831,521 |  |  |  | 137,441 |  |  |  | 196,460 |  |  |  | 1,165,422 |  |

[0001104659-25-075202:8k_2_02:89]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-25-075202:8k_2_02:90]
Reconciliation of Non-GAAP Financial Measures (Unaudited)

[0001104659-25-075202:8k_2_02:91]
| EPS – Adjusted Basis Reconciliation – Q3 2025 |  |  |  |  |
| EPS Continuing Operations– GAAP Basis – Q3 2025 |  | $ | 0.96 |  |
| Adjustments (defined below) |  |  | 0.64 |  |
| EPS Continuing Operations– As Adjusted Basis – Q3 2025 |  | $ | 1.60 |  |
| Adjustments exclude $0.64 per share consisting primarily of: $0.15 of Corporate acquisition costs, $0.08 of Maritime inventory step-up charges and stamp duties, $0.01 of restructuring charges within the USG segment, and $0.40 of acquisition related amortization. |  |  |  |  |
| EPS – Adjusted Basis Reconciliation – Q3 2024 |  |  |  |  |
| EPS Continuing Operations– GAAP Basis – Q3 2024 |  | $ | 1.10 |  |
| Adjustments (defined below) |  |  | 0.18 |  |
| EPS Continuing Operations– As Adjusted Basis – Q3 2024 |  | $ | 1.28 |  |
| Adjustments exclude $0.18 per share consisting primarily of: $0.02 of Corporate acquisition costs, $0.01 of restructuring charges within the A&D and USG segments, and $0.15 of acquisition related amortization. |  |  |  |  |
| EPS – Adjusted Basis Reconciliation – YTD Q3 2025 |  |  |  |  |
| EPS Continuing Operations– GAAP Basis – YTD Q3 2025 |  | $ | 2.76 |  |
| Adjustments (defined below) |  |  | 0.95 |  |
| EPS Continuing Operations – As Adjusted Basis – YTD Q3 2025 |  | $ | 3.71 |  |
| Adjustments exclude $0.95 per share consisting primarily of: $0.15 of Corporate acquisition costs, $0.08 of Maritime inventory step-up charges and stamp duties, $0.02 of restructuring charges within the Test and USG segments, and $0.70 of acquisition related amortization. |  |  |  |  |
| EPS – Adjusted Basis Reconciliation – YTD Q3 2024 |  |  |  |  |
| EPS Continuing Operations – GAAP Basis – YTD Q3 2024 |  | $ | 2.46 |  |
| Adjustments (defined below) |  |  | 0.53 |  |
| EPS Continuing Operations – As Adjusted Basis – YTD Q3 2024 |  | $ | 2.99 |  |
| Adjustments exclude $0.53 per share consisting primarily of: $0.06 of MPE acquisition backlog charges and inventory step-up charges and acquisition costs, $0.03 of restructuring charges, and $0.44 of acquisition related amortization. |  |  |  |  |
