# ESE 8-K — 0000866706-18-000003 filed 2018-05-08

## item codes, every 8-K on or before 2018-05-09

- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2018-05-09

- none on or before 2018-05-09

## item 2.02 — earnings release, exhibit 99.1

[0000866706-18-000003:8k_2_02:1]
EX-99.1
2
escopressrelease.htm
ESCO TECHNOLOGIES EARNINGS RELEASE

[0000866706-18-000003:8k_2_02:2]
EXHIBIT 99.1

[0000866706-18-000003:8k_2_02:3]
NEWS FROM

[0000866706-18-000003:8k_2_02:4]
For more information contact:

[0000866706-18-000003:8k_2_02:5]
Kate Lowrey

[0000866706-18-000003:8k_2_02:6]
Director, Investor Relations

[0000866706-18-000003:8k_2_02:7]
ESCO Technologies Inc.

[0000866706-18-000003:8k_2_02:8]
(314) 213-7277

[0000866706-18-000003:8k_2_02:9]
ESCO ANNOUNCES SECOND QUARTER FISCAL 2018 RESULTS

[0000866706-18-000003:8k_2_02:10]
-  Q2 GAAP EPS $0.38 ($0.10 of Cost Reduction Charges) -

[0000866706-18-000003:8k_2_02:11]
- Q2 Adjusted EPS $0.48 ($0.05 Above Guidance Range) -

[0000866706-18-000003:8k_2_02:12]
ST. LOUIS, May 8, 2018 – ESCO Technologies Inc. (NYSE: ESE) (ESCO, or the Company) today reported its operating results for the second quarter (Q2 2018) and six months year-to-date (YTD 2018) periods ended March 31, 2018.

[0000866706-18-000003:8k_2_02:13]
The financial results presented include certain non-GAAP financial measures such as EBIT, EBITDA (defined as earnings before interest, taxes, depreciation and amortization), Adjusted EBITDA (defined as EBITDA excluding certain defined charges) and Adjusted EPS. Any non-GAAP financial measures presented are reconciled to their respective GAAP equivalents.

[0000866706-18-000003:8k_2_02:14]
Management believes these non-GAAP financial measures are useful in assessing the ongoing operational profitability of the Company's business segments, and therefore, allow shareholders better visibility into the Company's underlying operations. See "Non-GAAP Financial Measures" described below.

[0000866706-18-000003:8k_2_02:15]
Earnings Summary

[0000866706-18-000003:8k_2_02:16]
Q2 2018 GAAP EPS of $0.38 per share included $2.6 million, or $0.10 per share of cost reduction charges incurred in USG and Filtration as described in the Q1 2018 earnings release dated February 6, 2018.

[0000866706-18-000003:8k_2_02:17]
Q2 2018 Adjusted EPS, excluding the $0.10 of charges noted above, was $0.48 per share and exceeded Management's Q2 2018 Adjusted EPS guidance of $0.38 to $0.43 per share, as every segment reported stronger than expected operating earnings.

[0000866706-18-000003:8k_2_02:18]
Q2 2017 GAAP EPS of $0.43 per share included pretax purchase accounting charges of $1.0 million, or $0.02 per share. Excluding these charges, Q2 2017 Adjusted EPS was $0.45 per share.

[0000866706-18-000003:8k_2_02:19]
Adjusted EBITDA was $28 million in Q2 2018, reflecting a 6 percent increase over Q2 2017 Adjusted EBITDA of $26 million.

[0000866706-18-000003:8k_2_02:20]
Operating Highlights

[0000866706-18-000003:8k_2_02:21]
| · | Q2 2018 sales increased $14 million (8 percent) to $175 million compared to $161 million in Q2 2017; |

[0000866706-18-000003:8k_2_02:22]
| · | On a segment basis, Q2 2018 Filtration sales decreased nominally from Q2 2017, but were in line with previous expectations. Commercial aerospace sales increased, industrial/automotive sales decreased at PTI as previously communicated, and Vacco's space sales decreased due to the quarterly timing of large project deliveries. Test sales increased 6 percent driven by its strong backlog, and Technical Packaging sales increased nominally. USG sales increased $14 million, or 43 percent, driven by the recent acquisitions and were consistent with previous expectations; |

[0000866706-18-000003:8k_2_02:23]
| · | SG&A expenses increased $6 million in Q2 2018 primarily due to the inclusion of the 2017 acquisitions in the current period, coupled with additional sales, marketing, R&D, and bid and proposal costs incurred to support future revenue growth; |

[0000866706-18-000003:8k_2_02:24]
| · | Amortization of intangible assets increased $1 million due to the 2017 acquisitions; |

[0000866706-18-000003:8k_2_02:25]
| · | Entered orders were $187 million in Q2 2018 (book-to-bill of 1.07x) reflecting a $13 million increase in backlog during the Quarter, resulting in an ending backlog of $417 million at March 31, 2018; |

[0000866706-18-000003:8k_2_02:26]
| · | Filtration orders were $68 million (book-to-bill of 1.03x) comprised of recurring commercial aerospace orders and additional navy products; |

[0000866706-18-000003:8k_2_02:27]
| · | Test orders were $48 million (book-to-bill of 1.18x) which reflects continued strength in the wireless, government and defense, electric vehicle, and automotive chamber markets; |

[0000866706-18-000003:8k_2_02:28]
| · | USG orders were $53 million (book-to-bill of 1.12x) which reflects increased orders for new products and solutions across the segment; |

[0000866706-18-000003:8k_2_02:29]
| · | Technical Packaging orders were $19 million (book-to-bill of 0.88x) due primarily to the timing of orders for ongoing customer projects; |

[0000866706-18-000003:8k_2_02:30]
| · | The Q2 2018 income tax rate was 26.4 percent compared to Management's expected rate of 26 percent, and compared to the Q2 2017 income tax rate of 33.7 percent; and, |

[0000866706-18-000003:8k_2_02:31]
| · | YTD 2018 net cash provided by operating activities was $33 million resulting in $222 million of net debt (outstanding borrowings less cash on hand) at March 31, 2018 and a 2.1x leverage ratio. Management is planning to repatriate a substantial portion of its foreign cash (currently $32 million) to pay down its outstanding debt and for other corporate purposes. |

[0000866706-18-000003:8k_2_02:32]
Chairman's Commentary – Q2 2018

[0000866706-18-000003:8k_2_02:33]
Vic Richey, Chairman and Chief Executive Officer, commented, "I am pleased with our results for the first half of the year. We started the year on a positive note as our Q1 operating results came in at the high end of our range, and the momentum continued in Q2 as we beat our Adjusted EPS expectations by $0.05 per share.

[0000866706-18-000003:8k_2_02:34]
"We are also ahead of Plan on cash flow and entered orders and have grown our backlog by $40 million or 11 percent from the start of the year. This provides us with confidence that we will meet our expectations entering the second half of the year with our growth projected to be meaningfully higher than our first half.

[0000866706-18-000003:8k_2_02:35]
"USG's recent acquisitions are on track and the integration has gone quite well. The Q2 cost reduction actions are complete and we should see the benefit of these actions over the balance of the year, which support my enthusiasm for USG's growth and enhanced margins. The consolidation of our sales channels, including our global rep and distributor network, has exceeded my expectations and we are seeing the positive sales impact across the entire segment platform.

[0000866706-18-000003:8k_2_02:36]
"The clear highlight of Q2 was our earnings as we beat the top of our guidance range with all of our operating segments exceeding plan. This achievement was closely followed by the continued strength of our order activity and backlog.

[0000866706-18-000003:8k_2_02:37]
"Our strong YTD 2018 cash flow and our second half cash expectations allow us to pay down debt while continuing our M&A activities without creating an unfavorable leverage situation. We will continue to balance our M&A actions with our debt levels and leverage ratios as we are committed to maintaining a prudent balance sheet.

[0000866706-18-000003:8k_2_02:38]
"Our market positions and continued growth opportunities across the Company provide me with a favorable view of the future with our goal remaining unchanged – to increase long-term shareholder value."

[0000866706-18-000003:8k_2_02:39]
Dividend Payment

[0000866706-18-000003:8k_2_02:40]
The next quarterly cash dividend of $0.08 per share will be paid on July 19, 2018 to stockholders of record on July 5, 2018.

[0000866706-18-000003:8k_2_02:41]
Business Outlook – 2018

[0000866706-18-000003:8k_2_02:42]
With the significant level of M&A activity completed over the past 18 months, coupled with the positive earnings and cash flow impact of U.S. Tax Reform, Management will continue to emphasize Adjusted EBITDA as a supplement to net income, and Adjusted EPS as a supplement to GAAP EPS, as it believes these are relevant metrics to be considered for measuring ongoing operating performance as well as the Company's enterprise valuation.

[0000866706-18-000003:8k_2_02:43]
Management continues to see meaningful sales and Adjusted EBITDA growth across each of the Company's business segments and anticipates strong growth over the remainder of 2018.

[0000866706-18-000003:8k_2_02:44]
Management's current expectations for 2018 remain consistent with the details outlined in the Business Outlook presented in the Company's February 6, 2018 release.

[0000866706-18-000003:8k_2_02:45]
To summarize, Management projects 2018 GAAP EPS in the range of $3.55 to $3.65 per share, and Adjusted EPS in the range of $2.65 to $2.75 per share, adjusting for the Q1 2018 incremental net tax benefits resulting from U.S. Tax Reform and the Q2 2018 cost reduction charges described above.

[0000866706-18-000003:8k_2_02:46]
Management continues to expect the balance of 2018's revenues, operating results and EPS to be significantly higher than the reported first half results noted above.

[0000866706-18-000003:8k_2_02:47]
Management expects Q3 2018 GAAP and Adjusted EPS to be in the range of $0.68 to $0.73 per share.

[0000866706-18-000003:8k_2_02:48]
Chairman's Commentary – 2018

[0000866706-18-000003:8k_2_02:49]
Mr. Richey continued, "Given the contributions from our acquisitions, coupled with anticipated organic growth from "legacy" operations, and supplemented by the favorable earnings and cash flow impact from U.S. Tax Reform, I continue to believe that 2018 will reflect solid sales, EBIT, EBITDA and EPS growth and position us well to meet or exceed our shareholder value-creation goals.

[0000866706-18-000003:8k_2_02:50]
"Our management teams' focus on profitable growth, cash flow, and ROIC will remain steadfast as we believe these are the key drivers of continued and sustainable share price appreciation."

[0000866706-18-000003:8k_2_02:51]
Conference Call

[0000866706-18-000003:8k_2_02:52]
The Company will host a conference call today, May 8, at 4:00 p.m. Central Time, to discuss the Company's Q2 2018 results. A live audio webcast will be available on the Company's website at www.escotechnologies.com. Please access the website at least 15 minutes prior to the call to register, download and install any necessary audio software. A replay of the conference call will be available for seven days on the Company's website noted above or by phone (dial 1-855-859-2056 and enter the pass code 6564437).

[0000866706-18-000003:8k_2_02:53]
Forward-Looking Statements

[0000866706-18-000003:8k_2_02:54]
Statements in this press release regarding the Company's expected quarterly, 2018 full year and beyond results, revenue and sales growth, EPS, Adjusted EPS, EPS growth, cash, EBIT, EBITDA, Adjusted EBITDA, gross profit, interest expense, non-cash depreciation and amortization of intangibles, corporate costs, income tax expense, effective tax rates, cash generation, repatriation of foreign cash and the uses of such cash, the impacts of U.S. Tax Reform, margin expansion and savings resulting from cost reduction actions, the Company's ability to increase operating margins, realize financial goals and increase shareholder value, the success of acquisition efforts, the size, number and timing of future sales and growth opportunities, the long-term success of the Company, and any other statements which are not strictly historical are "forward-looking" statements within the meaning of the safe harbor provisions of the federal securities laws.

[0000866706-18-000003:8k_2_02:55]
Investors are cautioned that such statements are only predictions and speak only as of the date of this release, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company's actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company's operations and business environment including, but not limited to those described in Item 1A, "Risk Factors", of the Company's Annual Report on Form 10-K for the fiscal year ended September 30, 2017, and the following: the success of the Company's competitors; weakening of economic conditions in served markets; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties; delivery delays or defaults by customers; material changes in the costs and availability of certain raw materials; the appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer contracts; the timing and content of future contract awards or customer orders; performance issues with key customers, suppliers and subcontractors; labor disputes; the impacts of natural disasters on the Company's operations and those of the Company's customers and suppliers; changes in laws and regulations, including but not limited to changes in accounting standards and taxation requirements; legal and foreign tax requirements impacting the repatriation of cash in foreign locations; changes in interest rates; costs relating to environmental matters arising from current or former facilities; financial exposure in connection with Company guarantees of certain Aclara contracts; the availability of select acquisitions; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the success and integration of recently acquired businesses.

[0000866706-18-000003:8k_2_02:56]
Non-GAAP Financial Measures

[0000866706-18-000003:8k_2_02:57]
The financial measures EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS are presented in this press release. The Company defines "EBIT" as earnings before interest and taxes, "EBITDA" as earnings before interest, taxes, depreciation and amortization, "Adjusted EBITDA" as EBITDA excluding certain defined charges, and "Adjusted EPS" as GAAP earnings per share (EPS) excluding the cost reduction charges described above which were $0.10 per share for Q2 2018.

[0000866706-18-000003:8k_2_02:58]
EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management believes that EBIT, EBITDA and Adjusted EBITDA are useful in assessing the operational profitability of the Company's business segments because they exclude interest, taxes, depreciation and amortization, which are generally accounted for across the entire Company on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company as well as incentive compensation. The Company believes that the presentation of EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS provides important supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance determined in accordance with GAAP.

[0000866706-18-000003:8k_2_02:59]
ESCO, headquartered in St. Louis: Manufactures highly-engineered filtration and fluid control products for the aviation, space and process markets worldwide; is the industry leader in RF shielding and EMC test products; provides diagnostic instruments, software and services for the benefit of industrial power users and the electric utility and renewable energy industries; and, produces custom thermoformed packaging, pulp-based packaging, and specialty products for medical and commercial markets. Further information regarding ESCO and its subsidiaries is available on the Company's website at www.escotechnologies.com.

[0000866706-18-000003:8k_2_02:60]
-tables attached-

[0000866706-18-000003:8k_2_02:61]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |  |  |  |
| Condensed Consolidated Statements of Operations (Unaudited) |  |  |  |  |
| (Dollars in thousands, except per share amounts) |  |  |  |  |
|  |  | Three Months Ended March 31, 2018 |  |  |  |  |  | Three Months Ended March 31, 2017 |  |  |  |  |
| Net Sales |  | $ | 174,778 |  |  |  |  |  |  | 161,178 |  |  |  |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 112,370 |  |  |  |  |  |  | 105,379 |  |  |  |  |
| Selling, general and administrative expenses |  |  | 40,749 |  |  |  |  |  |  | 34,889 |  |  |  |  |
| Amortization of intangible assets |  |  | 4,564 |  |  |  |  |  |  | 3,814 |  |  |  |  |
| Interest expense |  |  | 2,036 |  |  |  |  |  |  | 855 |  |  |  |  |
| Other (income) expenses, net |  |  | 1,475 |  |  |  |  |  |  | (578 | ) |  |  |  |
| Total costs and expenses |  |  | 161,194 |  |  |  |  |  |  | 144,359 |  |  |  |  |
| Earnings before income taxes |  |  | 13,584 |  |  |  |  |  |  | 16,819 |  |  |  |  |
| Income taxes |  |  | 3,590 |  |  |  |  |  |  | 5,662 |  |  |  |  |
| Net earnings |  | $ | 9,994 |  |  |  |  |  |  | 11,157 |  |  |  |  |
| Diluted EPS - GAAP |  | $ | 0.38 |  |  |  |  |  |  | 0.43 |  |  |  |  |
| Diluted EPS - As Adjusted |  | $ | 0.48 | (1) |  |  |  |  |  |  | 0.45 | (2) |  |  |  |  |
| Diluted average common shares O/S: |  |  | 25,988 |  |  |  |  |  |  |  | 25,911 |  |  |  |  |  |

[0000866706-18-000003:8k_2_02:62]
| (1) | Excludes $2.7 million, net of tax, impact of restructuring charges incurred at Doble & PTI during the second quarter of 2018. |  |
| (2) | Excludes $0.6 million, net of tax, impact of the Mayday inventory step-up charge during the second quarter of 2017. |  |

[0000866706-18-000003:8k_2_02:63]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |  |  |  |
| Condensed Consolidated Statements of Operations (Unaudited) |  |  |  |  |
| (Dollars in thousands, except per share amounts) |  |  |  |  |
|  |  | Six Months Ended March 31, 2018 |  |  |  |  |  | Six Months Ended March 31, 2017 |  |  |  |  |
| Net Sales |  | $ | 348,273 |  |  |  |  |  |  | 307,546 |  |  |  |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 224,106 |  |  |  |  |  |  | 198,293 |  |  |  |  |
| Selling, general and administrative expenses |  |  | 82,903 |  |  |  |  |  |  | 68,651 |  |  |  |  |
| Amortization of intangible assets |  |  | 9,010 |  |  |  |  |  |  | 7,463 |  |  |  |  |
| Interest expense |  |  | 4,221 |  |  |  |  |  |  | 1,539 |  |  |  |  |
| Other (income) expenses, net |  |  | 1,648 |  |  |  |  |  |  | (1,344 | ) |  |  |  |
| Total costs and expenses |  |  | 321,888 |  |  |  |  |  |  | 274,602 |  |  |  |  |
| Earnings before income taxes |  |  | 26,385 |  |  |  |  |  |  | 32,944 |  |  |  |  |
| Income taxes |  |  | (18,280 | ) |  |  |  |  |  | 11,060 |  |  |  |  |
| Net earnings |  | $ | 44,665 |  |  |  |  |  |  | 21,884 |  |  |  |  |
| Diluted EPS - GAAP |  | $ | 1.72 |  |  |  |  |  |  | 0.84 |  |  |  |  |
| Diluted EPS - As Adjusted |  | $ | 0.82 | (1) |  |  |  |  |  |  | 0.89 | (2) |  |  |  |  |
| Diluted average common shares O/S: |  |  | 26,034 |  |  |  |  |  |  |  | 25,945 |  |  |  |  |  |

[0000866706-18-000003:8k_2_02:64]
| (1) | Excludes $2.7 million, net of tax, impact of restructuring charges incurred at Doble & PTI during the first six months of 2018 and the $25 million tax benefit recorded related to U.S. Tax Reform |  |
| (2) | Excludes $1.3 million, net of tax, impact of Mayday inventory step-up charges during the first six months of 2017. |  |

[0000866706-18-000003:8k_2_02:65]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Condensed Business Segment Information (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  | GAAP |  |  | As Adjusted |  |
|  |  |  | Q2 2018 |  |  |  | Q2 2017 |  |  |  | Q2 2018 |  |  |  | Q2 2017 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 65,775 |  |  |  | 68,906 |  |  |  | 65,775 |  |  |  | 68,906 |  |
| Test |  |  | 40,805 |  |  |  | 38,367 |  |  |  | 40,805 |  |  |  | 38,367 |  |
| USG |  |  | 46,699 |  |  |  | 32,671 |  |  |  | 46,699 |  |  |  | 32,671 |  |
| Technical Packaging |  |  | 21,499 |  |  |  | 21,234 |  |  |  | 21,499 |  |  |  | 21,234 |  |
| Totals |  | $ | 174,778 |  |  |  | 161,178 |  |  |  | 174,778 |  |  |  | 161,178 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 11,118 |  |  |  | 11,625 |  |  |  | 11,566 |  |  |  | 12,593 |  |
| Test |  |  | 5,300 |  |  |  | 3,766 |  |  |  | 5,300 |  |  |  | 3,766 |  |
| USG |  |  | 5,626 |  |  |  | 7,434 |  |  |  | 7,543 |  |  |  | 7,434 |  |
| Technical Packaging |  |  | 1,885 |  |  |  | 2,196 |  |  |  | 1,885 |  |  |  | 2,196 |  |
| Corporate |  |  | (8,309 | ) |  |  | (7,347 | ) |  |  | (8,086 | ) |  |  | (7,347 | ) |
| Consolidated EBIT |  |  | 15,620 |  |  |  | 17,674 |  |  |  | 18,208 |  |  |  | 18,642 |  |
| Less: Interest expense |  |  | (2,036 | ) |  |  | (855 | ) |  |  | (2,036 | ) |  |  | (855 | ) |
| Less: Income tax expense |  |  | (3,590 | ) |  |  | (5,662 | ) |  |  | (3,524 | ) |  |  | (6,001 | ) |
| Net earnings |  | $ | 9,994 |  |  |  | 11,157 |  |  |  | 12,648 |  |  |  | 11,786 |  |
| Note 1: Adjusted net earnings were $12.6 million in Q2 '18 which excluded $2.7 million (or $0.10 per share), net of tax, impact of the restructuring charges incurred at Doble and PTI during the second quarter of 2018. |  |
| Note 2: Adjusted net earnings were $11.8 million in Q2 '17 which excluded $0.6 million (or $0.02 per share), net of tax, impact of the Mayday inventory step-up charge during the second quarter of 2017. |  |

[0000866706-18-000003:8k_2_02:66]
|  | EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000866706-18-000003:8k_2_02:67]
|  |  |  |  |  |  |  |  |  |  | Adjusted |  |  | Adjusted |  |
|  |  |  | Q2 2018 |  |  |  | Q2 2017 |  |  |  | Q2 2018 |  |  |  | Q2 2017 |  |
| Consolidated EBITDA |  | $ | 25,192 |  |  |  | 25,274 |  |  |  | 27,780 |  |  |  | 26,242 |  |
| Less: Depr & Amort |  |  | (9,572 | ) |  |  | (7,600 | ) |  |  | (9,572 | ) |  |  | (7,600 | ) |
| Consolidated EBIT |  |  | 15,620 |  |  |  | 17,674 |  |  |  | 18,208 |  |  |  | 18,642 |  |
| Less: Interest expense |  |  | (2,036 | ) |  |  | (855 | ) |  |  | (2,036 | ) |  |  | (855 | ) |
| Less: Income tax expense |  |  | (3,590 | ) |  |  | (5,662 | ) |  |  | (3,524 | ) |  |  | (6,001 | ) |
| Net earnings |  | $ | 9,994 |  |  |  | 11,157 |  |  |  | 12,648 |  |  |  | 11,786 |  |

[0000866706-18-000003:8k_2_02:68]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Condensed Business Segment Information (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | YTD Q2 2018 |  |  | YTD Q2 2017 |  |  | YTD Q2 2018 |  |  | YTD Q2 2017 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 125,810 |  |  |  | 127,690 |  |  |  | 125,810 |  |  |  | 127,690 |  |
| Test |  |  | 78,334 |  |  |  | 72,194 |  |  |  | 78,334 |  |  |  | 72,194 |  |
| USG |  |  | 102,453 |  |  |  | 68,228 |  |  |  | 102,453 |  |  |  | 68,228 |  |
| Technical Packaging |  |  | 41,676 |  |  |  | 39,434 |  |  |  | 41,676 |  |  |  | 39,434 |  |
| Totals |  | $ | 348,273 |  |  |  | 307,546 |  |  |  | 348,273 |  |  |  | 307,546 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 20,764 |  |  |  | 22,351 |  |  |  | 21,212 |  |  |  | 24,287 |  |
| Test |  |  | 7,895 |  |  |  | 6,191 |  |  |  | 7,895 |  |  |  | 6,191 |  |
| USG |  |  | 16,277 |  |  |  | 17,108 |  |  |  | 18,194 |  |  |  | 17,108 |  |
| Technical Packaging |  |  | 2,850 |  |  |  | 3,227 |  |  |  | 2,850 |  |  |  | 3,227 |  |
| Corporate |  |  | (17,180 | ) |  |  | (14,394 | ) |  |  | (16,957 | ) |  |  | (14,394 | ) |
| Consolidated EBIT |  |  | 30,606 |  |  |  | 34,483 |  |  |  | 33,194 |  |  |  | 36,419 |  |
| Less: Interest expense |  |  | (4,221 | ) |  |  | (1,539 | ) |  |  | (4,221 | ) |  |  | (1,539 | ) |
| Plus (Less): Income tax |  |  | 18,280 |  |  |  | (11,060 | ) |  |  | (6,705 | ) |  |  | (11,738 | ) |
| Net earnings |  | $ | 44,665 |  |  |  | 21,884 |  |  |  | 22,268 |  |  |  | 23,142 |  |
| Note 1: Adjusted net earnings were $22.3 million in YTD Q2 '18 which excluded $2.7 million (or $0.10 per share), net of tax, impact of the restructuring charges incurred at Doble and PTI during the first six months of 2018, and the $25 million (or $1.00 per share) tax benefit recorded related to U.S. Tax Reform. |  |
| Note 2: Adjusted net earnings were $23.1 million in YTD Q2 '17 which excluded $1.3 million (or $0.05 per share), net of tax, impact of the Mayday inventory step-up charges during the first six months of 2017. |  |

[0000866706-18-000003:8k_2_02:69]
|  | EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000866706-18-000003:8k_2_02:70]
|  |  |  |  |  |  |  |  |  |  | Adjusted |  |  | Adjusted |  |
|  |  | YTD Q2 2018 |  |  | YTD Q2 2017 |  |  | YTD Q2 2018 |  |  | YTD Q2 2017 |  |
| Consolidated EBITDA |  | $ | 49,404 |  |  |  | 49,171 |  |  |  | 51,992 |  |  |  | 51,107 |  |
| Less: Depr & Amort |  |  | (18,798 | ) |  |  | (14,688 | ) |  |  | (18,798 | ) |  |  | (14,688 | ) |
| Consolidated EBIT |  |  | 30,606 |  |  |  | 34,483 |  |  |  | 33,194 |  |  |  | 36,419 |  |
| Less: Interest expense |  |  | (4,221 | ) |  |  | (1,539 | ) |  |  | (4,221 | ) |  |  | (1,539 | ) |
| Plus (Less): Income tax |  |  | 18,280 |  |  |  | (11,060 | ) |  |  | (6,705 | ) |  |  | (11,738 | ) |
| Net earnings |  | $ | 44,665 |  |  |  | 21,884 |  |  |  | 22,268 |  |  |  | 23,142 |  |

[0000866706-18-000003:8k_2_02:71]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Condensed Consolidated Balance Sheets (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  | March 31, 2018 |  |  | September 30, 2017 |  |
| Assets |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 42,905 |  |  |  | 45,516 |  |
| Accounts receivable, net |  |  | 153,125 |  |  |  | 160,580 |  |
| Costs and estimated earnings on |  |  |  |  |  |  |  |  |
| long-term contracts |  |  | 40,285 |  |  |  | 47,286 |  |
| Inventories |  |  | 137,029 |  |  |  | 124,515 |  |
| Other current assets |  |  | 18,336 |  |  |  | 14,895 |  |
| Total current assets |  |  | 391,680 |  |  |  | 392,792 |  |
| Property, plant and equipment, net |  |  | 135,032 |  |  |  | 132,748 |  |
| Intangible assets, net |  |  | 349,631 |  |  |  | 351,134 |  |
| Goodwill |  |  | 382,141 |  |  |  | 377,879 |  |
| Other assets |  |  | 6,865 |  |  |  | 5,891 |  |
|  |  | $ | 1,265,349 |  |  |  | 1,260,444 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Short-term borrowings and current |  | $ | 20,000 |  |  |  | 20,000 |  |
| maturities of long-term debt |  |  |  |  |  |  |  |  |
| Accounts payable |  |  | 50,365 |  |  |  | 54,789 |  |
| Current portion of deferred revenue |  |  | 32,002 |  |  |  | 28,583 |  |
| Other current liabilities |  |  | 83,463 |  |  |  | 91,597 |  |
| Total current liabilities |  |  | 185,830 |  |  |  | 194,969 |  |
| Deferred tax liabilities |  |  | 59,845 |  |  |  | 86,378 |  |
| Other liabilities |  |  | 55,138 |  |  |  | 52,179 |  |
| Long-term debt |  |  | 245,000 |  |  |  | 255,000 |  |
| Shareholders' equity |  |  | 719,536 |  |  |  | 671,918 |  |
|  |  | $ | 1,265,349 |  |  |  | 1,260,444 |  |

[0000866706-18-000003:8k_2_02:72]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Consolidated Statements of Cash Flows (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  | Six Months Ended March 31, 2018 |  |
| Cash flows from operating activities: |  |  |  |
| Net earnings |  | $ | 44,665 |  |
| Adjustments to reconcile net earnings |  |  |  |  |
| to net cash provided by operating activities: |  |  |  |  |
| Depreciation and amortization |  |  | 18,798 |  |
| Stock compensation expense |  |  | 2,648 |  |
| Changes in assets and liabilities |  |  | (9,336 | ) |
| Effect of deferred taxes |  |  | (26,533 | ) |
| Change in deferred revenue and costs, net |  |  | 3,766 |  |
| Pension contributions |  |  | (537 | ) |
| Net cash provided by operating activities |  |  | 33,471 |  |
| Cash flows from investing activities: |  |  |  |  |
| Acquisition of businesses, net of cash acquired |  |  | (11,369 | ) |
| Capital expenditures |  |  | (10,095 | ) |
| Additions to capitalized software |  |  | (4,608 | ) |
| Net cash used by investing activities |  |  | (26,072 | ) |
| Cash flows from financing activities: |  |  |  |  |
| Proceeds from long-term debt |  |  | 36,000 |  |
| Principal payments on long-term debt |  |  | (46,000 | ) |
| Dividends paid |  |  | (4,134 | ) |
| Other |  |  | 560 |  |
| Net cash used by financing activities |  |  | (13,574 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 3,564 |  |
| Net decrease in cash and cash equivalents |  |  | (2,611 | ) |
| Cash and cash equivalents, beginning of period |  |  | 45,516 |  |
| Cash and cash equivalents, end of period |  | $ | 42,905 |  |

[0000866706-18-000003:8k_2_02:73]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Other Selected Financial Data (Unaudited) |  |
| (Dollars in thousands) |  |
| Backlog And Entered Orders - Q2 FY 2018 |  | Filtration |  |  | Test |  |  | USG |  |  | Technical Packaging |  |  | Total |  |
| Beginning Backlog - 1/1/18 |  | $ | 208,480 |  |  |  | 135,552 |  |  |  | 37,472 |  |  |  | 22,643 |  |  |  | 404,147 |  |
| Entered Orders |  |  | 67,836 |  |  |  | 48,048 |  |  |  | 52,504 |  |  |  | 18,918 |  |  |  | 187,306 |  |
| Sales |  |  | (65,775 | ) |  |  | (40,805 | ) |  |  | (46,699 | ) |  |  | (21,499 | ) |  |  | (174,778 | ) |
| Ending Backlog - 3/31/18 |  | $ | 210,541 |  |  |  | 142,795 |  |  |  | 43,277 |  |  |  | 20,062 |  |  |  | 416,675 |  |
| Backlog And Entered Orders - YTD Q2 FY 2018 |  | Filtration |  |  | Test |  |  | USG |  |  | Technical Packaging |  |  | Total |  |
| Beginning Backlog - 10/1/17 |  | $ | 203,120 |  |  |  | 114,792 |  |  |  | 35,581 |  |  |  | 23,614 |  |  |  | 377,107 |  |
| Entered Orders |  |  | 133,231 |  |  |  | 106,337 |  |  |  | 110,149 |  |  |  | 38,124 |  |  |  | 387,841 |  |
| Sales |  |  | (125,810 | ) |  |  | (78,334 | ) |  |  | (102,453 | ) |  |  | (41,676 | ) |  |  | (348,273 | ) |
| Ending Backlog - 3/31/18 |  | $ | 210,541 |  |  |  | 142,795 |  |  |  | 43,277 |  |  |  | 20,062 |  |  |  | 416,675 |  |
