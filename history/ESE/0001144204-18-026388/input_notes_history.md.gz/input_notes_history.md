# ESE note change history — 0001144204-18-006187 → 0001144204-18-026388


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-05-09):
[0001144204-18-026388:note_history:1]
The Company’s results for the three and six-month periods ended March 31, 2018 are not necessarily indicative of the results for the entire 2018 fiscal year. References to the second quarters of 2018 and 2017 represent the fiscal quarters ended March 31, 2018 and 2017, respectively.
  (was, 2018-02-07, similarity 0.913):
[0001144204-18-006187:note_history:1]
The Company’s results for the three-month periods ended December 31, 2017 are not necessarily indicative of the results for the entire 2018 fiscal year. References to the first quarters of 2018 and 2017 represent the fiscal quarters ended December 31, 2017 and 2016, respectively.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-09):
[0001144204-18-026388:note_history:2]
| (In thousands) |  | March 31, 2018 |  | September 30, 2017 |  |
| Total borrowings |  | $ | 265,000 |  |  | 275,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 245,000 |  |  | 255,000 |  |
  (was, 2018-02-07, similarity 0.9778):
[0001144204-18-006187:note_history:2]
| (In thousands) |  | December 31, 2017 |  | September 30, 2017 |  |
| Total borrowings |  | $ | 260,000 |  |  | 275,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 240,000 |  |  | 255,000 |  |

- changed (2018-05-09):
[0001144204-18-026388:note_history:3]
The Company’s existing credit facility (“the Credit Facility”) matures December 21, 2020. The Credit Facility includes a $450 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of nine banks led by JPMorgan Chase Bank, N.A., as Administrative Agent.
  (was, 2018-02-07, similarity 0.9924):
[0001144204-18-006187:note_history:3]
The Company’s existing credit facility (“the Credit Facility”) matures December 21, 2020. The Credit Facility includes a $450 million revolving line of credit as well as provisions allowing for the increase of the facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of nine banks led by JPMorgan Chase Bank, N.A., as Administrative Agent.

- changed (2018-05-09):
[0001144204-18-026388:note_history:4]
At March 31, 2018, the Company had approximately $176 million available to borrow under the Credit Facility, and a $250 million increase option, in addition to $42.9 million cash on hand. At March 31, 2018, the Company had $265 million of outstanding borrowings under the Credit Facility in addition to outstanding letters of credit of $9.1 million. The Company classified $20.0 million as the current portion of long-term debt as of March 31, 2018, as the Company intends to repay this amount within the next twelve month period; however, the Company has no contractual obligation to repay such amount during the next twelve month period.
  (was, 2018-02-07, similarity 0.9681):
[0001144204-18-006187:note_history:4]
At December 31, 2017, the Company had approximately $181 million available to borrow under the Credit Facility, and a $250 million increase option, in addition to $41.6 million cash on hand. At December 31, 2017, the Company had $260 million of outstanding borrowings under the Credit Facility in addition to outstanding letters of credit of $9.0 million. The Company classified $20.0 million as the current portion of long-term debt as of December 31, 2017, as the Company intends to repay this amount within the next twelve month period; however, the Company has no contractual obligation to repay such amount during the next twelve month period.

- changed (2018-05-09):
[0001144204-18-026388:note_history:5]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from  12.5 to  27.5 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a  65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were  2.99% and  2.87% for the three and six-month periods ending March 31, 2018, respectively, and  1.89% and  1.76% for the corresponding periods of 2017. At March 31, 2018, the Company was in compliance with all debt covenants.
  (was, 2018-02-07, similarity 0.9378):
[0001144204-18-006187:note_history:5]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from  12.5 to  27.5 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a  65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were  2.74% and  1.61% for the three-month periods ending December 31, 2017 and 2016, respectively. At December 31, 2017, the Company was in compliance with all debt covenants.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-09):
[0001144204-18-026388:note_history:6]
| (In thousands) |  | March 31, 2018 |  | September 30, 2017 |  |
| Total borrowings |  | $ | 265,000 |  |  | 275,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 245,000 |  |  | 255,000 |  |
  (was, 2018-02-07, similarity 0.9778):
[0001144204-18-006187:note_history:6]
| (In thousands) |  | December 31, 2017 |  | September 30, 2017 |  |
| Total borrowings |  | $ | 260,000 |  |  | 275,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 240,000 |  |  | 255,000 |  |
