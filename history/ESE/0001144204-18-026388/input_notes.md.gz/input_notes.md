# ESE notes — 0001144204-18-026388


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001144204-18-026388:notes:1]
[same as prior period, unchanged from 0001144204-18-006187:notes:31]

[0001144204-18-026388:notes:2]
[same as prior period, unchanged from 0001144204-18-006187:notes:32]

[0001144204-18-026388:notes:3]
The Company’s results for the three and six-month periods ended March 31, 2018 are not necessarily indicative of the results for the entire 2018 fiscal year. References to the second quarters of 2018 and 2017 represent the fiscal quarters ended March 31, 2018 and 2017, respectively.

[0001144204-18-026388:notes:4]
[same as prior period, unchanged from 0001144204-18-006187:notes:34]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001144204-18-026388:notes:5]
| 2. | ACQUISITION |

[0001144204-18-026388:notes:6]
On March 14, 2018, the Company acquired the assets of Manta Test Systems Inc. (Manta), a North American utility solutions provider located in Mississauga, Ontario, Canada, for a purchase price of $9.5 million in cash. Manta has annualized sales of approximately $8 million. Since the date of acquisition, the operating results for Manta have been included as a product line of Doble within the Company’s USG segment. Based on the preliminary purchase price allocation, the Company recorded approximately $0.4 million of accounts receivable, $1.1 million of inventory, $0.2 million of property, plant and equipment, $0.4 million of accounts payable and accrued expenses, $3.5 million of goodwill, $1.2 million of tradenames and $3.6 million of amortizable intangible assets consisting of customer relationships with a weighted average life of 13 years.


## us-gaap:EarningsPerShareTextBlock

[0001144204-18-026388:notes:7]
| 3. | EARNINGS PER SHARE (EPS) |

[0001144204-18-026388:notes:8]
Basic EPS is calculated using the weighted average number of common shares outstanding during the period. Diluted EPS is calculated using the weighted average number of common shares outstanding during the period plus shares issuable upon the assumed exercise of dilutive common share options and vesting of performance-accelerated restricted shares (restricted shares) by using the treasury stock method.  The number of shares used in the calculation of earnings per share for each period presented is as follows (in thousands):

[0001144204-18-026388:notes:9]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |  |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |  |
| Weighted Average Shares Outstanding - Basic |  |  | 25,844 |  |  | 25,723 |  |  | 25,840 |  |  | 25,721 |  |
| Dilutive Options and Restricted Shares |  |  | 144 |  |  | 188 |  |  | 195 |  |  | 224 |  |
| Adjusted Shares - Diluted |  |  | 25,988 |  |  | 25,911 |  |  | 26,035 |  |  | 25,945 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001144204-18-026388:notes:10]
| 4. | SHARE-BASED COMPENSATION |

[0001144204-18-026388:notes:11]
[same as prior period, unchanged from 0001144204-18-006187:notes:38]

[0001144204-18-026388:notes:12]
[same as prior period, unchanged from 0001144204-18-006187:notes:39]

[0001144204-18-026388:notes:13]
Compensation expense related to the restricted share awards was $1.0 million and $2.1 million for the three and six-month periods ended March 31, 2018, respectively, and $1.2 million and $2.4 million for the corresponding periods of 2017. There were  221,024 non-vested shares outstanding as of March 31, 2018.

[0001144204-18-026388:notes:14]
[same as prior period, unchanged from 0001144204-18-006187:notes:41]

[0001144204-18-026388:notes:15]
Compensation expense related to the non-employee director grants was $0.3 million and $0.5 million for the three and six-month periods ended March 31, 2018, respectively, and $0.2 million and $0.5 million for the corresponding periods of 2017.

[0001144204-18-026388:notes:16]
The total share-based compensation cost that has been recognized in the results of operations and included within selling, general and administrative expenses (SG&A) was $1.3 million and $2.6 million for the three-and six-month periods ended March 31, 2018, respectively, and $1.4 million and $2.9 million for the three and six-month periods ended March 31, 2017. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $0.4 million and $0.7 million for the three and six-month periods ended March 31, 2018, respectively, and $0.5 million and $1.1 million for the three and six-month periods ended March 31, 2017, respectively. As of March 31, 2018, there was $4.3 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a remaining weighted-average period of  1.5 years.


## us-gaap:InventoryDisclosureTextBlock

[0001144204-18-026388:notes:17]
| 5. | INVENTORIES |

[0001144204-18-026388:notes:18]
Inventories consist of the following:

[0001144204-18-026388:notes:19]
| (In thousands) |  | March 31, 2018 |  | September 30, 2017 |  |
| Finished goods |  | $ | 32,140 |  |  | 28,127 |  |
| Work in process |  |  | 50,658 |  |  | 43,750 |  |
| Raw materials |  |  | 54,231 |  |  | 52,638 |  |
| Total inventories |  | $ | 137,029 |  |  | 124,515 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001144204-18-026388:notes:20]
| 6. | GOODWILL AND OTHER INTANGIBLE ASSETS |

[0001144204-18-026388:notes:21]
Included on the Company’s Consolidated Balance Sheets at March 31, 2018 and September 30, 2017 are the following intangible assets gross carrying amounts and accumulated amortization:

[0001144204-18-026388:notes:22]
| (Dollars in thousands) |  | March 31, 2018 |  | September 30, 2017 |  |
| Goodwill |  | $ | 382,141 |  |  | 377,879 |  |
| Intangible assets with determinable lives: |  |  |  |  |  |  |  |
| Patents |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 972 |  |  | 928 |  |
| Less: accumulated amortization |  |  | 764 |  |  | 750 |  |
| Net |  | $ | 208 |  |  | 178 |  |
| Capitalized software |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 66,349 |  |  | 63,007 |  |
| Less: accumulated amortization |  |  | 37,910 |  |  | 34,382 |  |
| Net |  | $ | 28,439 |  |  | 28,625 |  |
| Customer relationships |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 186,002 |  |  | 181,891 |  |
| Less: accumulated amortization |  |  | 42,490 |  |  | 37,364 |  |
| Net |  | $ | 143,512 |  |  | 144,527 |  |
| Other |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 5,276 |  |  | 5,373 |  |
| Less: accumulated amortization |  |  | 1,725 |  |  | 1,383 |  |
| Net |  | $ | 3,551 |  |  | 3,990 |  |
| Intangible assets with indefinite lives: |  |  |  |  |  |  |  |
| Trade names |  | $ | 173,921 |  |  | 173,813 |  |

[0001144204-18-026388:notes:23]
The changes in the carrying amount of goodwill attributable to each business segment for the six months ended March 31, 2018 is as follows:

[0001144204-18-026388:notes:24]
| (Dollars in millions) |  | USG |  | Test |  | Filtration |  | Packaging |  | Total |  |
| Balance as of September 30, 2017 |  |  | 250.2 |  |  | 34.1 |  |  | 73.7 |  |  | 19.9 |  |  | 377.9 |  |
| Acquisition activity |  |  | 3.7 |  |  | - |  |  | - |  |  | - |  |  | 3.7 |  |
| Foreign currency translation |  |  | (0.2) |  |  | - |  |  | - |  |  | 0.7 |  |  | 0.5 |  |
| Balance as of March 31, 2018 |  | $ | 253.7 |  |  | 34.1 |  |  | 73.7 |  |  | 20.6 |  |  | 382.1 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001144204-18-026388:notes:25]
| 7. | BUSINESS SEGMENT INFORMATION |

[0001144204-18-026388:notes:26]
The Company is organized based on the products and services that it offers, and classifies its business operations in four reportable segments for financial reporting purposes: Filtration/Fluid Flow (Filtration), RF Shielding and Test (Test), Utility Solutions Group (USG) and Technical Packaging. The Filtration segment’s operations consist of PTI Technologies Inc. (PTI), VACCO Industries (VACCO), Crissair, Inc. (Crissair), Westland Technologies Inc. (Westland), Mayday Manufacturing Co. and its affiliate Hi-Tech Metals, Inc. (collectively referred to as Mayday). The companies within this segment primarily design and manufacture specialty filtration products, including hydraulic filter elements used in commercial aerospace applications, unique filter mechanisms used in micro-propulsion devices for satellites and custom designed filters for manned and unmanned aircraft; manufacture elastomeric-based signature reduction solutions for the U.S. Navy; and manufacture landing gear components for the aerospace and defense industry. The Test segment’s operations consist primarily of ETS-Lindgren Inc. (ETS-Lindgren). ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy. The USG segment’s operations consist primarily of Doble Engineering Company (Doble), Morgan Schaffer Inc. (Morgan Schaffer), and NRG Systems, Inc. (NRG). Doble provides high-end, intelligent diagnostic test solutions for the electric power delivery industry and is a leading supplier of partial discharge testing instruments used to assess the integrity of high voltage power delivery equipment. Morgan Schaffer provides an integrated offering of dissolved gas analysis, oil testing, and data management solutions for the electric power industry. NRG designs and manufactures decision support tools for the renewable energy industry, primarily wind. The Technical Packaging segment’s operations consist of Thermoform Engineered Quality LLC (TEQ) and Plastique Limited and Plastique  Sp. z o.o.  (together, Plastique). The companies within this segment provide innovative solutions to the medical and commercial markets for thermoformed packages and specialty products using a wide variety of thin gauge plastics and pulp.

[0001144204-18-026388:notes:27]
Management evaluates and measures the performance of its reportable segments based on “Net Sales” and “EBIT”, which are detailed in the table below. EBIT is defined as earnings before interest and taxes.

[0001144204-18-026388:notes:28]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |  |
| (In thousands) |  | 2018 |  | 2017 |  | 2018 |  | 2017 |  |
| NET SALES |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 65,775 |  |  | 68,906 |  |  | 125,810 |  |  | 127,690 |  |
| Test |  |  | 40,805 |  |  | 38,367 |  |  | 78,334 |  |  | 72,194 |  |
| USG |  |  | 46,699 |  |  | 32,671 |  |  | 102,453 |  |  | 68,228 |  |
| Technical Packaging |  |  | 21,499 |  |  | 21,234 |  |  | 41,676 |  |  | 39,434 |  |
| Consolidated totals |  | $ | 174,778 |  |  | 161,178 |  |  | 348,273 |  |  | 307,546 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 11,118 |  |  | 11,625 |  |  | 20,764 |  |  | 22,351 |  |
| Test |  |  | 5,300 |  |  | 3,766 |  |  | 7,895 |  |  | 6,191 |  |
| USG |  |  | 5,626 |  |  | 7,434 |  |  | 16,277 |  |  | 17,108 |  |
| Technical Packaging |  |  | 1,885 |  |  | 2,196 |  |  | 2,850 |  |  | 3,227 |  |
| Corporate (loss) |  |  | (8,309) |  |  | (7,347) |  |  | (17,180) |  |  | (14,394) |  |
| Consolidated EBIT |  |  | 15,620 |  |  | 17,674 |  |  | 30,606 |  |  | 34,483 |  |
| Less: Interest expense |  |  | (2,036) |  |  | (855) |  |  | (4,221) |  |  | (1,539) |  |
| Earnings before income taxes |  | $ | 13,584 |  |  | 16,819 |  |  | 26,385 |  |  | 32,944 |  |

[0001144204-18-026388:notes:29]
[same as prior period, unchanged from 0001144204-18-006187:notes:48]

[0001144204-18-026388:notes:30]
The financial measure “EBIT” is presented in the above table and elsewhere in this Report. EBIT on a consolidated basis is a non-GAAP financial measure. Management believes that EBIT is useful in assessing the operational profitability of the Company’s business segments because it excludes interest and taxes, which are generally accounted for across the entire Company on a consolidated basis. EBIT is also one of the measures used by management in determining resource allocations within the Company as well as incentive compensation. A reconciliation of EBIT to net earnings is set forth in Item 2, Management’s Discussion and Analysis of Financial Condition and Results of Operations – EBIT.

[0001144204-18-026388:notes:31]
[same as prior period, unchanged from 0001144204-18-006187:notes:50]


## us-gaap:DebtDisclosureTextBlock

[0001144204-18-026388:notes:32]
| 8. | DEBT |

[0001144204-18-026388:notes:33]
The Company’s debt is summarized as follows:

[0001144204-18-026388:notes:34]
| (In thousands) |  | March 31, 2018 |  | September 30, 2017 |  |
| Total borrowings |  | $ | 265,000 |  |  | 275,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 245,000 |  |  | 255,000 |  |

[0001144204-18-026388:notes:35]
The Company’s existing credit facility (“the Credit Facility”) matures December 21, 2020. The Credit Facility includes a $450 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of nine banks led by JPMorgan Chase Bank, N.A., as Administrative Agent.

[0001144204-18-026388:notes:36]
At March 31, 2018, the Company had approximately $176 million available to borrow under the Credit Facility, and a $250 million increase option, in addition to $42.9 million cash on hand. At March 31, 2018, the Company had $265 million of outstanding borrowings under the Credit Facility in addition to outstanding letters of credit of $9.1 million. The Company classified $20.0 million as the current portion of long-term debt as of March 31, 2018, as the Company intends to repay this amount within the next twelve month period; however, the Company has no contractual obligation to repay such amount during the next twelve month period.

[0001144204-18-026388:notes:37]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from  12.5 to  27.5 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a  65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were  2.99% and  2.87% for the three and six-month periods ending March 31, 2018, respectively, and  1.89% and  1.76% for the corresponding periods of 2017. At March 31, 2018, the Company was in compliance with all debt covenants.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001144204-18-026388:notes:38]
| 10. | SHAREHOLDERS’ EQUITY |

[0001144204-18-026388:notes:39]
The change in shareholders’ equity for the first six months of 2018 is shown below (in thousands):

[0001144204-18-026388:notes:40]
| Balance at September 30, 2017 |  | $ | 671,918 |  |
| Net earnings |  |  | 44,665 |  |
| Other comprehensive income (loss) |  |  | 4,280 |  |
| Cash dividends |  |  | (4,134) |  |
| Stock compensation plans |  |  | 2,807 |  |
| Balance at March 31, 2018 |  | $ | 719,536 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001144204-18-026388:notes:41]
| 11. | RETIREMENT PLANS |

[0001144204-18-026388:notes:42]
A summary of net periodic benefit expense for the Company’s defined benefit plans for the three and six-month periods ended March 31, 2018 and 2017 is shown in the following table. Net periodic benefit cost for each period presented is comprised of the following:

[0001144204-18-026388:notes:43]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |  |
| (In thousands) |  | 2018 |  | 2017 |  | 2018 |  | 2017 |  |
| Defined benefit plans |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest cost |  | $ | 821 |  |  | 737 |  |  | 1,641 |  |  | 1,702 |  |
| Expected return on assets |  |  | (975) |  |  | (942) |  |  | (1,950) |  |  | (2,036) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior service cost |  |  | - |  |  | - |  |  | - |  |  | 3 |  |
| Actuarial loss |  |  | 548 |  |  | 683 |  |  | 1,097 |  |  | 1,188 |  |
| Net periodic benefit cost |  | $ | 394 |  |  | 478 |  |  | 788 |  |  | 857 |  |


## us-gaap:ScheduleOfNotionalAmountsOfOutstandingDerivativePositionsTableTextBlock

[0001144204-18-026388:notes:44]
The following is a summary of the notional transaction amounts and fair values for the Company’s outstanding derivative financial instruments by risk category and instrument type as of March 31, 2018:

[0001144204-18-026388:notes:45]
| (In thousands) |  | Notional amount |  | Fair Value (US$) |  | Float Rate |  | Fix Rate |  |
| Forward contracts |  |  | 700 |  | GBP | (18) |  |  |  |  |  |  |  |
| Forward contracts |  |  | 4,500 |  | USD | (74) |  |  |  |  |  |  |  |
| Forward contracts |  |  | 200 |  | EUR | (1) |  |  |  |  |  |  |  |
| Interest rate swap |  |  | 150,000 |  | USD | 233 |  |  | 1.84 | % |  | 1.80 | % |
| Interest rate swap * |  |  | 150,000 |  | USD | 525 |  |  | N/A |  |  | 2.09 | % |
| Interest rate swap ** |  |  | 150,000 |  | USD | 654 |  |  | N/A |  |  | 2.24 | % |

[0001144204-18-026388:notes:46]
[same as prior period, unchanged from 0001144204-18-006187:notes:27]

[0001144204-18-026388:notes:47]
[same as prior period, unchanged from 0001144204-18-006187:notes:28]


## us-gaap:FairValueDisclosuresTextBlock

[0001144204-18-026388:notes:48]
| 13. | FAIR VALUE MEASUREMENTS |

[0001144204-18-026388:notes:49]
[same as prior period, unchanged from 0001144204-18-006187:notes:58]

[0001144204-18-026388:notes:50]
[same as prior period, unchanged from 0001144204-18-006187:notes:59]

[0001144204-18-026388:notes:51]
[same as prior period, unchanged from 0001144204-18-006187:notes:60]

[0001144204-18-026388:notes:52]
The Company has estimated the fair value of its financial instruments as of March 31, 2017 and September 30, 2016 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, debt and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001144204-18-026388:notes:53]
[same as prior period, unchanged from 0001144204-18-006187:notes:62]

[0001144204-18-026388:notes:54]
The Company’s forward contracts are classified within Level 2 of the valuation hierarchy in accordance with FASB Accounting Standards Codification (ASC) 825, as presented below as of March 31, 2018:

[0001144204-18-026388:notes:55]
| (In thousands) |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  |
| Assets (Liabilities): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Forward contracts |  | $ | - |  |  | 1,319 |  | $ | - |  |  | 1,319 |  |

[0001144204-18-026388:notes:56]
[same as prior period, unchanged from 0001144204-18-006187:notes:63]

[0001144204-18-026388:notes:57]
[same as prior period, unchanged from 0001144204-18-006187:notes:64]

[0001144204-18-026388:notes:58]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during the three and six-month periods ended March 31, 2018.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001144204-18-026388:notes:59]
| 14. | NEW ACCOUNTING STANDARDS |

[0001144204-18-026388:notes:60]
In March 2017, the FASB issued ASU 2017-07, Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost, which updates ASC 715,  Compensation – Retirement Benefits. This update permits only the service cost component of net periodic pension and postretirement expense to be reported with other compensation costs, while all other components are required to be reported separately in other deductions, outside any subtotal of operating income. These updates are effective for fiscal years beginning after December 15, 2017, with early adoption permitted, and must be adopted on a retrospective basis. The updates change presentation only and will not impact the Company’s results of operations.

[0001144204-18-026388:notes:61]
In August 2017, the FASB issued ASU 2017-12, Targeted Improvements to Accounting for Hedge Activities, which updates ASC 815, Derivatives and Hedging. This update is intended to amend the hedge accounting model to enable entities to better align the economics of risk management activities and financial reporting. The updates eliminate the requirement to separately measure and report hedge ineffectiveness and simplify hedge documentation and effectiveness assessment requirements. These updates are effective for fiscal years beginning after December 15, 2018, with early adoption permitted, and must be adopted using a modified retrospective approach. These updates are not expected to materially impact the Company’s results of operations.

[0001144204-18-026388:notes:62]
In February 2016, the FASB issued ASU No. 2016-062, Leases (Topic 842), which, among other things, requires an entity to recognize lease assets and lease liabilities on the balance sheet and disclose key information about leasing arrangements. This standard will increase an entities’ reported assets and liabilities. The standard is effective for fiscal years beginning after December 15, 2018 and mandates a modified retrospective transition period for all entities. The Company is currently assessing the impact of this standard on its consolidated financial statements and related disclosures.

[0001144204-18-026388:notes:63]
In May 2014, the FASB issued ASU No. 2014-09, Revenue from Contracts with Customers, which requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. This guidance has been further clarified and amended. The new standard will be effective for annual reporting periods beginning after December 15, 2017, and interim periods within those annual periods. The standard permits the use of either the retrospective or cumulative effect transition method. The Company is currently in the process of evaluating the effect that ASU 2014-09 will have on its consolidated financial statements and related disclosures. The Company has selected the Cumulative Effect method of transition to the new standard.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001144204-18-026388:notes:64]
| 12. | DERIVATIVE FINANCIAL INSTRUMENTS |

[0001144204-18-026388:notes:65]
Market risks relating to the Company’s operations result primarily from changes in interest rates and changes in foreign currency exchange rates. The Company is exposed to market risk related to changes in interest rates and selectively uses derivative financial instruments, including forward contracts and swaps, to manage these risks. During 2016, the Company entered into several forward contracts to purchase pounds sterling (GBP) to hedge two deferred payments due in connection with the acquisition of Plastique. During the first quarter of 2018, the Company entered into three interest rate swaps with a notional amount of $150 million to hedge some of its exposure to variability in future LIBOR-based interest payments on variable rate debt. In addition, the Company’s Canadian subsidiary Morgan Schaffer enters into foreign exchange contracts to manage foreign currency risk as a portion of their revenue is denominated in U.S. dollars. The Company expects hedging gains or losses to be essentially offset by losses or gains on the related underlying exposures. All derivative instruments are reported in either accrued expenses or other receivables on the balance sheet at fair value. For derivative instruments designated as cash flow hedges, the gain or loss on the derivative is deferred in accumulated other comprehensive income until recognized in earnings with the underlying hedged item. The interest rate swaps entered into during the first quarter of 2018 were not designated as cash flow hedges and, therefore, the gain or loss on the derivative is reflected in earnings each period.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001144204-18-026388:notes:66]
| 9. | INCOME TAX EXPENSE |

[0001144204-18-026388:notes:67]
The second quarter 2018 effective income tax rate was  26.4% compared to  33.7% in the second quarter of 2017. The income tax benefit for the first six months of 2018 was $18.3 million compared to income tax expense of $11.1 million for the first six months of 2017. The effective income tax rate for the first six months of 2018 was (69.3%) compared to  33.6% for the first six months of 2017. H.R. 1, Tax Cuts and Jobs Act (“TCJA”), was signed into law on December 22, 2017. The total impact of the TCJA in the second quarter and first six months of 2018 was a net expense of $0.7 million and a net benefit of $24.4 million, respectively. The impacts were as follows: First, the Company’s 2018 federal statutory rate decreased from  35.0% to  24.5% which required an adjustment to the value of its deferred tax assets and liabilities. This adjustment ($30.3 million provisional amount recorded in the first quarter of 2018) favorably impacted the year-to-date effective tax rate by  114.9%. Second, the TCJA subjected the Company’s cumulative foreign earnings to federal income tax ($3.6 million provisional amount of which $2.9 million was recorded in the first quarter of 2018 and $0.7 million was recorded in the second quarter of 2018) which unfavorably impacted the second quarter and year-to-date effective tax rate by  4.9% and  13.6%, respectively.

[0001144204-18-026388:notes:68]
In the first quarter of 2018, the Company recorded a $2.3 million provisional estimate of the income tax effects of the future repatriation of the cumulative earnings of its foreign subsidiaries which unfavorably impacted the year-to-date effective tax rate by  8.9%. An additional $7.5 million pension contribution for the 2017 plan year was approved increasing the value of the deferred tax liability by $1.0 million (provisional amount). This favorable adjustment, net of the $0.3 million unfavorable impact to the 2017 Domestic Production Deduction, favorably impacted the second quarter and year-to-date effective tax rate by  5.8% and  3.0%, respectively. The income tax expense in the second quarter and first six months of 2018 was also unfavorably impacted by the cancellation of debt income triggered by the dissolution of a foreign subsidiary increasing the second quarter and year-to-date effective tax rate by  1.5% and  0.8%, respectively.

[0001144204-18-026388:notes:69]
[same as prior period, unchanged from 0001144204-18-006187:notes:11]

[0001144204-18-026388:notes:70]
In the first quarter of 2018, the Company recorded reasonable estimates of the TCJA income tax effects. In the second quarter of 2018, the Company was unable to complete the accounting under ASC Topic 740 for the change in the value of the Company’s deferred tax assets and liabilities as it needs more time to collect and analyze information primarily related to depreciation expense, pension liability (see provisional adjustment described above), and percentage of completion revenue recognition. The accounting for these items will be completed within the allotted measurement period. During the second quarter of 2018, the Company collected and analyzed some of the additional information needed to complete the accounting under ASC Topic 740 for the income tax effects of subjecting the Company’s cumulative foreign earnings to federal income tax and as described above recorded an adjustment of $0.7 million. This amount remains provisional as the Company needs more time to collect and analyze the remaining information to compute the cumulative balance of earnings subject to the tax and the amount of foreign tax credit that is available to offset the tax.

[0001144204-18-026388:notes:71]
[same as prior period, unchanged from 0001144204-18-006187:notes:13]

[0001144204-18-026388:notes:72]
The TCJA includes a tax on global intangible low-taxed income (“GILTI”). The Company expects it will be subject to this tax. At its January 10, 2018 meeting, the FASB staff indicated that companies should make and disclose a policy election as to whether they will recognize deferred taxes for basis differences expected to reverse as GILTI or whether they will account for GILTI as period costs if and when incurred. Because there are interpretative questions associated with the approach that involves recognizing deferred taxes, the Company is in the process of evaluating and will make the accounting policy election during the SAB 118 measurement period.
