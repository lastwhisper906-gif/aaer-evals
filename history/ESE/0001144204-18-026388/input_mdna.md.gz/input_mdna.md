# ESE MD&A — 0001144204-18-026388


## mdna

[0001144204-18-026388:mdna:1]
[same as prior period, unchanged from 0001144204-18-006187:mdna:1]

[0001144204-18-026388:mdna:2]
[same as prior period, unchanged from 0001144204-18-006187:mdna:2]

[0001144204-18-026388:mdna:3]
References to the second quarters of 2018 and 2017 represent
the three-month periods ended March 31, 2018 and 2017, respectively.

[0001144204-18-026388:mdna:4]
[same as prior period, unchanged from 0001144204-18-006187:mdna:4]

[0001144204-18-026388:mdna:5]
In the second quarter of 2018, sales, net earnings and diluted
earnings per share were $174.8 million, $10.0 million and $0.38 per share, respectively, compared to $

[0001144204-18-026388:mdna:6]
| 16 |

[0001144204-18-026388:mdna:7]
1.2 million, $11.2 million
and $0.43 per share, respectively, in the second quarter of 2017. In the first six months of 2018, sales, net earnings and diluted
earnings per share were $348.3 million, $44.7 million and $1.72, respectively, compared to $307.5 million, $21.9 million and $0.84
per share, respectively, in the first six months of 2017.

[0001144204-18-026388:mdna:8]
[same as prior period, unchanged from 0001144204-18-006187:mdna:6]

[0001144204-18-026388:mdna:9]
Net sales increased $13.6 million, or 8.4%, to $174.8 million
in the second quarter of 2018 from $161.2 million in the second quarter of 2017. Net sales increased $40.8 million, or 13.2%, to
$348.3 million in the first six months of 2018 from $307.5 million in the first six months of 2017. The increase in net sales in
the second quarter of 2018 as compared to the second quarter of 2017 was due to a $14.0 million increase in the USG segment, a
$2.4 million increase in the Test segment and a $0.3 million increase in the Technical Packaging segment, partially offset by a
$3.1 million decrease in the Filtration segment. The increase in net sales in the first six months of 2018 as compared to the corresponding
prior year period was due to a $34.3 million increase in the USG segment, a $6.2 million increase in the Test segment and a $2.2
million increase in the Technical Packaging segment, partially offset by a $1.9 million decrease in the Filtration segment.

[0001144204-18-026388:mdna:10]
[same as prior period, unchanged from 0001144204-18-006187:mdna:8]

[0001144204-18-026388:mdna:11]
In the second quarter of 2018, net sales of $65.8 million were
$3.1 million, or 4.5%, lower than the $68.9 million in the second quarter of 2017. Net sales decreased $1.9 million, or 1.5%, to
$125.8 million in the first six months of 2018 from $127.7 million in the first six months of 2017. The sales decrease in the second
quarter of 2018 compared to the second quarter of 2017 was mainly due to a $3.6 million decrease in net sales at VACCO due to lower
shipments of its defense spares products and a $2.5 million decrease in net sales at PTI due to lower aerospace assembly and industrial/automotive
shipments, partially offset by a $2.9 million increase in net sales at Mayday due to higher aerospace shipments. The sales decrease
in the first six months of 2018 compared to the first six months of 2017 was primarily due to a $4.6 million decrease in net sales
at Westland due to timing of shipments on government programs and a $4.6 million decrease in net sales at PTI due to lower aerospace
assembly and industrial/automotive shipments, partially offset by an $8.6 million increase in net sales at Mayday due to higher
aerospace shipments.

[0001144204-18-026388:mdna:12]
[same as prior period, unchanged from 0001144204-18-006187:mdna:11]

[0001144204-18-026388:mdna:13]
In the second quarter of 2018, net sales of $40.8 million were
$2.4 million, or 6.3%, higher than the $38.4 million recorded in the second quarter of 2017. Net sales increased $6.1 million,
or 8.4%, to $78.3 million in the first six months of 2018 from $72.2 million in the first six months of 2017. The increase in the
second quarter and first six months of 2018 compared to the corresponding periods of 2017 was primarily due to higher sales from
the segment’s U.S. operations due to the timing of test and measurement chamber projects.

[0001144204-18-026388:mdna:14]
[same as prior period, unchanged from 0001144204-18-006187:mdna:13]

[0001144204-18-026388:mdna:15]
Net sales increased $14.0 million, or 42.8%, to $46.7 million
in the second quarter of 2018 from $32.7 million in the second quarter of 2017. Net sales increased $34.3 million, or 50.3%, to
$102.5 million in the first six months of 2018 from $68.2 million in the first six months of 2017. The increase in the second quarter
of 2018 compared to the second quarter of 2017 was mainly due to the sales contributions from the NRG, Morgan Schaffer and Vanguard
Instruments (Vanguard) acquisitions. The increase in the first six months of 2018 compared to the first six months of 2017 was
mainly due to the sales contributions from NRG, Morgan Schaffer and Vanguard and new products and software solutions at Doble.

[0001144204-18-026388:mdna:16]
[same as prior period, unchanged from 0001144204-18-006187:mdna:15]

[0001144204-18-026388:mdna:17]
In the second quarter of 2018, net sales of $21.5 million were
$0.3 million, or 1.4%, higher than the $21.2 million in the second quarter of 2017. Net sales increased $2.3 million, or 5.8%,
to $41.7 million in the first six months of 2018 from $39.4 million in the first six months of 2017. The increase in the second
quarter and first six months of 2018 compared to the corresponding periods of 2017 was primarily due to the increase in net sales
from Plastique due to increased shipments to new customers as well as fluctuations in currency.

[0001144204-18-026388:mdna:18]
[same as prior period, unchanged from 0001144204-18-006187:mdna:17]

[0001144204-18-026388:mdna:19]
Backlog was $416.7 million at March 31, 2018 compared with $377.1
million at September 30, 2017. The Company received new orders totaling $187.3 million in the second quarter of 2018 compared to
$166.9 million in the second quarter of 2017. Of the new orders received in the second quarter of 2018, $67.8 million related to
Filtration products, $48.1 million related to Test products, $52.5 million related to USG products, and $18.9 million related to
Technical Packaging products. Of the new orders received in the second quarter of 2017, $62.0 million related to Filtration products,
$44.2 million related to Test products, $33.0 million related to USG products, and $27.6 million related to Technical Packaging
products.

[0001144204-18-026388:mdna:20]
The Company received new orders totaling $387.8 million in the
first six months of 2018 compared to $349.8 million in the first six months of 2017. Of the new orders received in the first six
months of 2018, $133.2 million related to Filtration products, $106.4 million related to Test products, $110.1 million related
to USG products, and $38.1 million related to Technical Packaging products. Of the new orders received in the first six months
of 2017, $129.5 million related to Filtration products, $100.2 million related to Test products, $72.6 million related to USG products,
and $47.4 million related to Technical Packaging products.

[0001144204-18-026388:mdna:21]
[same as prior period, unchanged from 0001144204-18-006187:mdna:19]

[0001144204-18-026388:mdna:22]
Selling, general and administrative (SG&A) expenses for
the second quarter of 2018 were $40.7 million (23.3% of net sales), compared with $34.9 million (21.6% of net sales) for the second
quarter of 2017. For the first six months of 2018, SG&A expenses were $82.9 million (23.8% of net sales) compared to $68.7
million (22.3% of net sales) for the first six months of 2017. The increase in SG&A in the second quarter and first six months
of 2018 compared to the corresponding periods of 2017 was mainly due to an increase in the USG segment due to the Company’s
recent acquisitions (NRG, Morgan Schaffer and Vanguard) and additional sales and marketing expenses to support future revenue growth,
and at Corporate (higher professional fees including acquisition expenses).

[0001144204-18-026388:mdna:23]
[same as prior period, unchanged from 0001144204-18-006187:mdna:53]

[0001144204-18-026388:mdna:24]
[same as prior period, unchanged from 0001144204-18-006187:mdna:22]

[0001144204-18-026388:mdna:25]
Amortization of intangible assets was $4.6 million and $9.0
million for the second quarter and first six months of 2018, respectively, compared to $3.8 million and $7.5 million for the corresponding
periods of 2017. Amortization expenses consist of amortization of acquired intangible assets from acquisitions and other identifiable
intangible assets (primarily software). The increase in amortization expense in the second quarter and first six months of 2018
compared to the corresponding periods of 2017 was mainly due to an increase in amortization of intangibles related to the Morgan
Schaffer, NRG and Mayday acquisitions.

[0001144204-18-026388:mdna:26]
[same as prior period, unchanged from 0001144204-18-006187:mdna:24]

[0001144204-18-026388:mdna:27]
Other expenses, net, was $1.5 million in the second quarter
of 2018 compared to other income, net, of $0.6 million in the second quarter of 2017. The principal components in other expenses,
net, in the second quarter of 2018 were $2.1 million of charges primarily related to the USG segment restructuring activities,
including the Doble facility consolidations, partially offset by gains on derivative instruments. The restructuring charges mainly
related to severance and compensation benefits, professional fees and asset impairment charges related to abandoned assets. There
were no individually significant items in other (income) expenses, net, in the second quarter of 2017.

[0001144204-18-026388:mdna:28]
Other expenses, net, was $1.6 million in the first six months
of 2018 compared to other income, net, of $1.3 million in the first six months of 2017. The principal components in other expenses,
net, in the first six months of 2018 were $2.1 million of charges related to the USG segment restructuring activities as mentioned
above, partially offset by gains on derivative instruments. The principal component in other income, net, in the first six months
of 2017 was $0.4 million of income related to death benefit insurance proceeds from a former subsidiary.

[0001144204-18-026388:mdna:29]
[same as prior period, unchanged from 0001144204-18-006187:mdna:26]

[0001144204-18-026388:mdna:30]
The Company evaluates the performance of its operating segments
based on EBIT, and provides EBIT on a consolidated basis, which is a non-GAAP financial measure. Please refer to the discussion
of non-GAAP financial measures in Note 7 to the Consolidated Financial Statements, above. EBIT was $15.6 million (8.9% of net sales)
for the second quarter of 2018 compared to $17.7 million (11.0% of net sales) for the second quarter of 2017. For the first six
months of 2018, EBIT was $30.6 million (8.8% of net sales) compared to $34.5 million (11.2% of net sales) for the first six months
of 2017.

[0001144204-18-026388:mdna:31]
[same as prior period, unchanged from 0001144204-18-006187:mdna:28]

[0001144204-18-026388:mdna:32]
| (In thousands) |  | Three Months Ended March 31, |  |  | Six Months Ended March 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Consolidated EBIT |  | $ | 15,620 |  |  |  | 17,674 |  |  |  | 30,606 |  |  |  | 34,483 |  |
| Less: Interest expense, net |  |  | (2,036 | ) |  |  | (855 | ) |  |  | (4,221 | ) |  |  | (1,539 | ) |
| Plus (Less): Income tax |  |  | (3,590 | ) |  |  | (5,662 | ) |  |  | 18,280 |  |  |  | (11,060 | ) |
| Net earnings |  | $ | 9,994 |  |  |  | 11,157 |  |  |  | 44,665 |  |  |  | 21,884 |  |

[0001144204-18-026388:mdna:33]
[same as prior period, unchanged from 0001144204-18-006187:mdna:30]

[0001144204-18-026388:mdna:34]
EBIT in the second quarter of 2018 was $11.1 million (16.9%
of net sales) compared to $11.6 million (16.9% of net sales) in the second quarter of 20

[0001144204-18-026388:mdna:35]
| 17 |

[0001144204-18-026388:mdna:36]
. EBIT in the first six months of 20

[0001144204-18-026388:mdna:37]
| 18 |

[0001144204-18-026388:mdna:38]
was $20.8 million (16.5% of net sales) compared to $22.4 million (17.5% of net sales) in the first six months of 2017. The decrease
in EBIT in the second quarter compared to the second quarter of 2017 was mainly due to a decrease at VACCO and PTI due to the lower
sales volumes partially offset by an increase in EBIT at Mayday due to the higher sales volumes as mentioned above. The decrease
in EBIT in the first six months of 2018 compared to the corresponding period of 2017 was mainly due to a decrease at Westland and
PTI due to lower sales volumes partially offset by an increase in EBIT at Mayday. EBIT as a percent of net sales decreased in the
first six months of 2018 compared to the first six months of 2017 mainly due to $0.5 million of restructuring charges at PTI incurred
during the second quarter of 2018 related to the exit of the low margin industrial/automotive market. These charges consisted primarily
of severance and compensation benefits and asset impairment charges.

[0001144204-18-026388:mdna:39]
[same as prior period, unchanged from 0001144204-18-006187:mdna:32]

[0001144204-18-026388:mdna:40]
EBIT in the second quarter of 2018 was $5.3 million (13.0% of
net sales) compared to $3.8 million (9.8% of net sales) in the second quarter of 2017. EBIT in the first six months of 2018 was
$7.9 million (10.1% of net sales) compared to $6.2 million (8.6% of net sales) in the first six months of 2017. The increase in
EBIT in the second quarter and first six months of 2018 compared to the corresponding prior year periods was primarily due to the
increased sales volumes mainly from the segment’s U.S. operations.

[0001144204-18-026388:mdna:41]
[same as prior period, unchanged from 0001144204-18-006187:mdna:70]

[0001144204-18-026388:mdna:42]
[same as prior period, unchanged from 0001144204-18-006187:mdna:35]

[0001144204-18-026388:mdna:43]
EBIT in the second quarter of 2018 was $5.6 million (12.0%
of net sales) compared to $7.4 million (22.8% of net sales) in the second quarter of 2017. EBIT in the first six months of 2018
was $16.3 million (15.9% of net sales) compared to EBIT of $17.1 million (25.1% of net sales) in the first six months of 2017.
The decrease in EBIT in the second quarter and first six months of 2018 compared to the corresponding periods of 2017 was mainly
due to the restructuring charges incurred in the second quarter of 2018 and product mix. During the second quarter of 2018, the
Company incurred $1.9 million of charges related to closing the Doble facilities in Norway and China consisting mainly of employee
severance and compensation benefits, professional fees, and asset impairment charges.

[0001144204-18-026388:mdna:44]
[same as prior period, unchanged from 0001144204-18-006187:mdna:37]

[0001144204-18-026388:mdna:45]
EBIT in the second quarter of 2018 was $1.9 million (8.8% of
net sales) compared to $2.2 million (10.3% of net sales) in the second quarter of 2017. EBIT in the first six months of 2018 was
$2.9 million (6.8% of net sales) compared to $3.2 million (8.2% of net sales) in the first six months of 2017. The decrease in
EBIT in the second quarter and first six months of 2018 compared to the corresponding periods of 2017 was mainly due to product
mix at Plastique including lower margin projects.

[0001144204-18-026388:mdna:46]
[same as prior period, unchanged from 0001144204-18-006187:mdna:39]

[0001144204-18-026388:mdna:47]
Corporate costs included in EBIT were $8.3 million and $17.2
million in the second quarter and first six months of 2018, respectively, compared to $7.3 million and $14.4 million in the corresponding
periods of 2017. The increase in Corporate costs in the second quarter and first six months of 2018 compared to the corresponding
periods of 2017 was primarily due to higher professional fees and an increase in amortization of intangible assets related to recent
acquisitions.

[0001144204-18-026388:mdna:48]
[same as prior period, unchanged from 0001144204-18-006187:mdna:41]

[0001144204-18-026388:mdna:49]
Interest expense was $2.0 million and $4.2 million in the second
quarter and first six months of 2018, respectively, and $0.9 million and $1.5 million in the corresponding periods of 2017. The
increase in interest expense in the first six months of 2018 compared to the corresponding period of 2017 was mainly due to higher
average outstanding borrowings ($264 million compared to $167 million) and higher average interest rates (2.9% vs. 1.8%) as a result
of the additional borrowings to fund the Company’s recent acquisitions.

[0001144204-18-026388:mdna:50]
[same as prior period, unchanged from 0001144204-18-006187:mdna:47]

[0001144204-18-026388:mdna:51]
The second quarter 2018 effective income tax rate was 26.4%
compared to 33.7% in the second quarter of 2017. The income tax benefit for the first six months of 2018 was $18.3 million compared
to income tax expense of $11.1 million for the first six months of 2017. The effective income tax rate for the first six months
of 2018 was (69.3%) compared to 33.6% for the first six months of 2017. H.R. 1, Tax Cuts and Jobs Act (“TCJA”),
was signed into law on December 22, 2017. The total impact of the TCJA in the second quarter and first six months of 2018 was a
net expense of $0.7 million and a net benefit of $24.4 million, respectively. The impacts were as follows: First, the Company’s
2018 federal statutory rate decreased from 35.0% to 24.5% which required an adjustment to the value of its deferred tax assets and
liabilities. This adjustment ($30.3 million provisional amount recorded in the first quarter of 2018) favorably impacted the year-to-date
effective tax rate by 114.9%. Second, the TCJA subjected the Company’s cumulative foreign earnings to federal income tax
($3.6 million provisional amount of which $2.9 million was recorded in the first quarter of 2018 and $0.7 million was recorded
in the second quarter of 2018) which unfavorably impacted the second quarter and year-to-date effective tax rate by 4.9% and 13.6%,
respectively.

[0001144204-18-026388:mdna:52]
In the first quarter of 2018, the Company recorded a $2.3 million
provisional estimate of the income tax effects of the future repatriation of the cumulative earnings of its foreign subsidiaries
which unfavorably impacted the year-to-date effective tax rate by 8.9%. An additional $7.5 million pension contribution for
the 2017 plan year was approved increasing the value of the deferred tax liability by $1.0 million (provisional amount). This favorable
adjustment, net of the $0.3 million unfavorable impact to the 2017 Domestic Production Deduction, favorably impacted the second
quarter and year-to-date effective tax rate by 5.8% and 3.0%, respectively. The income tax expense in the second quarter and first
six months of 2018 was also unfavorably impacted by the cancellation of debt income triggered by the dissolution of a foreign subsidiary
increasing the second quarter and year-to-date effective tax rate by 1.5% and 0.8%, respectively.

[0001144204-18-026388:mdna:53]
In the first quarter of 2018, the Company recorded reasonable
estimates of the TCJA income tax effects. In the second quarter of 2018, the Company was unable to complete the accounting under
ASC Topic 740 for the change in the value of the Company’s deferred tax assets and liabilities as it needs more time to collect
and analyze information primarily related to depreciation expense, pension liability (see provisional adjustment described above),
and percentage of completion revenue recognition. The accounting for these items will be completed within the allotted measurement
period. In the second quarter of 2018, the Company collected and analyzed some of the additional information needed to complete
the accounting under ASC Topic 740 for the income tax effects of subjecting the Company’s cumulative foreign earnings to
federal income tax and as described above recorded a $0.7 million adjustment. This amount remains provisional as the Company needs
more time to collect and analyze the remaining information to compute the cumulative balance of earnings subject to the tax and
the amount of foreign tax credit that is available to offset the tax.

[0001144204-18-026388:mdna:54]
[same as prior period, unchanged from 0001144204-18-006187:mdna:52]

[0001144204-18-026388:mdna:55]
The TCJA includes a tax on global intangible low-taxed income
(“GILTI”). The Company expects it will be subject to this tax. At its January 10, 2018 meeting, the FASB staff indicated
that companies should make and disclose a policy election as to whether they will recognize deferred taxes for basis differences
expected to reverse as GILTI or whether they will account for GILTI as period costs if and when incurred. Because there are interpretative
questions associated with the approach that involves recognizing deferred taxes, the Company is in the process of evaluating and
will make the accounting policy election during the SAB 118 measurement period.

[0001144204-18-026388:mdna:56]
TCJA moved the U.S. to a federal tax system that will no longer
tax dividends from foreign corporations to U.S. corporations. The cost of transitioning to this new tax system is a deemed repatriation
of cumulative foreign earnings, the “Foreign Earnings Toll Charge”, the estimated tax cost of which was recorded in
the first quarter and trued up during the second quarter of 2018. The actual repatriation of foreign earnings triggers foreign
dividend withholding taxes and U.S. state taxes, the estimated cost of which was recorded in the first quarter and trued up during
the second quarter of 2018.

[0001144204-18-026388:mdna:57]
During the three-month period ended March 31, 2018, there were
no material changes in the unrecognized tax benefits. The Company does not anticipate a material change in the amount of unrecognized
tax benefits in the next twelve months.

[0001144204-18-026388:mdna:58]
[same as prior period, unchanged from 0001144204-18-006187:mdna:81]

[0001144204-18-026388:mdna:59]
[same as prior period, unchanged from 0001144204-18-006187:mdna:57]

[0001144204-18-026388:mdna:60]
The Company’s overall financial position and liquidity
remains strong. Working capital (current assets less current liabilities) increased to $205.9 million at March 31, 2018 from $

[0001144204-18-026388:mdna:61]
| 19 |

[0001144204-18-026388:mdna:62]
7.8
million at September 30,

[0001144204-18-026388:mdna:63]
| 20 |

[0001144204-18-026388:mdna:64]
17. Inventories increased by $12.5 million during this period mainly due to a $6.2 million increase
within the Filtration segment primarily to support new aerospace platforms and a $4.1 million increase within the USG segment.
Costs and estimated earnings in excess of billings on long-term contracts decreased $7.0 million in the first six months of 2018
due to ETS-Lindgren ($4.7 million) and VACCO ($2.3 million).

[0001144204-18-026388:mdna:65]
Net cash provided by operating activities was $33.0 million
and $36.7 million in the first six months of 2018 and 2017, respectively. The decrease in net cash provided by operating activities
in the first six months of 2018 as compared to the first six months of 2017 was due to higher working capital requirements.

[0001144204-18-026388:mdna:66]
Capital expenditures were $10.1 million and $15.4 million in
the first six months of 2018 and 2017, respectively. The decrease in the first six months of 2018 was mainly due to a decrease
in machinery and equipment at Plastique ($3.0 million) and VACCO ($1.6 million). In addition, the Company incurred expenditures
for capitalized software of $4.6 million and $3.4 million in the first six months of 2018 and 2017, respectively.

[0001144204-18-026388:mdna:67]
Credit Facility

[0001144204-18-026388:mdna:68]
At March 31, 2018, the Company had approximately $176 million
available to borrow under its bank credit facility, a $250 million increase option, and $42.9 million cash on hand. At March 31,
2018, the Company had $265 million of outstanding borrowings under the credit facility in addition to outstanding letters of credit
of $9.1 million. Cash flow from operations and borrowings under the Company’s credit facility are expected to meet the Company’s
capital requirements and operational needs for the foreseeable future. The Company’s ability to access the additional $250
million increase option of the credit facility is subject to acceptance by participating or other outside banks.

[0001144204-18-026388:mdna:69]
[same as prior period, unchanged from 0001144204-18-006187:mdna:65]

[0001144204-18-026388:mdna:70]
In March 2017, the FASB issued ASU 2017-07, Improving the
Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost, which updates ASC 715, Compensation
– Retirement Benefits. This update permits only the service cost component of net periodic pension and postretirement
expense to be reported with other compensation costs, while all other components are required to be reported separately in other
deductions, outside any subtotal of operating income. These updates are effective for fiscal years beginning after December 15,
2017, with early adoption permitted, and must be adopted on a retrospective basis. The updates change presentation only and will
not impact the Company’s results of operations.

[0001144204-18-026388:mdna:71]
In August 2017, the FASB issued ASU 2017-12, Targeted Improvements
to Accounting for Hedge Activities, which updates ASC 815, Derivatives and Hedging. This update is intended to amend
the hedge accounting model to enable entities to better align the economics of risk management activities and financial reporting.
The updates eliminate the requirement to separately measure and report hedge ineffectiveness and simplify hedge documentation and
effectiveness assessment requirements. These updates are effective for fiscal years beginning after December 15, 2018, with early
adoption permitted, and must be adopted using a modified retrospective approach. These updates are not expected to materially impact
the Company’s results of operations.

[0001144204-18-026388:mdna:72]
In February 2016, the FASB issued ASU No. 2016-062, Leases
(Topic 842), which, among other things, requires an entity to recognize lease assets and lease liabilities on the balance sheet
and disclose key information about leasing arrangements. This standard will increase an entities’ reported assets and liabilities.
The standard is effective for fiscal years beginning after December 15, 2018 and mandates a modified retrospective transition period
for all entities. The Company is currently assessing the impact of this standard on its consolidated financial statements and related
disclosures.

[0001144204-18-026388:mdna:73]
In May 2014, the FASB issued ASU No. 2014-09, Revenue from
Contracts with Customers, which requires an entity to recognize the amount of revenue to which it expects to be entitled for
the transfer of promised goods or services to customers. This guidance has been further clarified and amended. The new standard
will be effective for annual reporting periods beginning after December 15, 2017, and interim periods within those annual periods.
The standard permits the use of either the retrospective or cumulative effect transition method. The Company is currently in the
process of evaluating the effect that ASU 2014-09 will have on its consolidated financial statements and related disclosures. The
Company has selected the Cumulative Effect method of transition to the new standard.

[0001144204-18-026388:mdna:74]
Acquisitions

[0001144204-18-026388:mdna:75]
On March 14, 2018, the Company acquired the assets of Manta
Test Systems Inc. (Manta), a North American utility solutions provider located in Mississauga, Ontario, Canada, for a purchase
price of $9.5 million in cash. Manta has annualized sales of approximately $8 million. Since the date of acquisition, the operating
results for Manta have been included as a product line of Doble within the Company’s USG segment.

[0001144204-18-026388:mdna:76]
During the second quarter of 2018, the Company paid a deferred
payment of $1.6 million in connection with the 2016 acquisition of Plastique.

[0001144204-18-026388:mdna:77]
[same as prior period, unchanged from 0001144204-18-006187:mdna:71]

[0001144204-18-026388:mdna:78]
A dividend of $0.08 per share, totaling $2.1 million, was paid
on October 17, 2017 to stockholders of record as of October 3, 2017. A dividend of $0.08 per share, totaling $2.1 million, was
paid on January 19, 2018 to stockholders of record as of January 4, 2018. Subsequent to March 31, 2018, a quarterly dividend of
$0.08 per share, totaling $2.1 million, was paid on April 18, 2018 to stockholders of record as of April 3, 2018.

[0001144204-18-026388:mdna:79]
[same as prior period, unchanged from 0001144204-18-006187:mdna:73]

[0001144204-18-026388:mdna:80]
Management’s current expectations for 2018 remain consistent
with the details outlined in the Business Outlook presented in the Company’s February 6, 2018 release.

[0001144204-18-026388:mdna:81]
On a quarterly basis, Management continues to expect 2018 revenues
and EPS to reflect a profile similar to 2017, including EPS being more second-half weighted. Third quarter 2018 EPS is expected
to be in the range of $0.68 to $0.73 per share. Management expects 2018 GAAP EPS in the range of $3.55 to $3.65 per share and
Adjusted EPS in the range of $2.65 to $2.75 per share, adjusting for the first quarter 2018 incremental net tax benefits resulting
from U.S. Tax Reform and the second quarter 2018 cost reduction charges in the USG and Filtration segments.

[0001144204-18-026388:mdna:82]
19

[0001144204-18-026388:mdna:83]
[same as prior period, unchanged from 0001144204-18-006187:mdna:75]

[0001144204-18-026388:mdna:84]
Management has evaluated the accounting policies used in the
preparation of the Company’s financial statements and related notes and believes those policies to be reasonable and appropriate.
Certain of these accounting policies require the application of significant judgment by Management in selecting appropriate assumptions
for calculating financial estimates. By their nature, these judgments are subject to an inherent degree of uncertainty. These judgments
are based on historical experience, trends in the industry, information provided by customers and information available from other
outside sources, as appropriate. The most significant areas involving Management judgments and estimates may be found in the Critical
Accounting Policies section of Management’s Discussion and Analysis and in Note 1 to the Consolidated Financial Statements
contained in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2017.

[0001144204-18-026388:mdna:85]
[same as prior period, unchanged from 0001144204-18-006187:mdna:77]

[0001144204-18-026388:mdna:86]
Contingencies

[0001144204-18-026388:mdna:87]
As a normal incident of the business in which the Company is
engaged, various claims, charges and litigation are asserted or commenced against the Company. Additionally, the Company is currently
involved in various stages of investigation and remediation relating to environmental matters. In the opinion of Management, the
aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company,
are adequately reserved, are covered by insurance, or would not have a material adverse effect on the Company’s results from
operations, capital expenditures, or competitive position.

[0001144204-18-026388:mdna:88]
[same as prior period, unchanged from 0001144204-18-006187:mdna:80]

[0001144204-18-026388:mdna:89]
Investors are cautioned that such statements are only predictions
and speak only as of the date of this Form 10-Q, and the Company undertakes no duty to update them except as may be required by
applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in
the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment,
including but not limited to those described in Item 1A, “Risk Factors,” of the Company’s Annual Report on Form
10-K for the fiscal year ended September 30, 2017, and the following: the impacts of natural disasters on the Company’s operations
and those of the Company’s customers and suppliers; the timing and content of future contract awards or customer orders;
the appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer
contracts or orders; financial exposure in connection with Company guarantees of certain Aclara contracts; weakening of economic
conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies;
competition; intellectual property rights; technical difficulties; the availability of selected acquisitions; delivery delays or
defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability
of certain raw materials; labor disputes; final analysis of the impacts of the TCJA; changes in U.S. tax laws and regulations;
other changes in laws and regulations including but not limited to changes in accounting standards and foreign taxation; changes
in interest rates; costs relating to environmental matters arising from current or former facilities; uncertainty regarding the
ultimate resolution of current disputes, claims, litigation or arbitration; and the integration of recently acquired businesses.
