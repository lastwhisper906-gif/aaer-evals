# ESE 8-K — 0000866706-17-000010 filed 2017-08-08

## item codes, every 8-K on or before 2017-08-08

- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2017-08-08

- none on or before 2017-08-08

## item 2.02 — earnings release, exhibit 99.1

[0000866706-17-000010:8k_2_02:1]
EX-99.1
2
escopressrelease.htm

[0000866706-17-000010:8k_2_02:2]
EXHIBIT 99.1

[0000866706-17-000010:8k_2_02:3]
NEWS FROM

[0000866706-17-000010:8k_2_02:4]
For more information contact:

[0000866706-17-000010:8k_2_02:5]
Kate Lowrey

[0000866706-17-000010:8k_2_02:6]
Director, Investor Relations

[0000866706-17-000010:8k_2_02:7]
ESCO Technologies Inc.

[0000866706-17-000010:8k_2_02:8]
(314) 213-7277

[0000866706-17-000010:8k_2_02:9]
ESCO ANNOUNCES THIRD QUARTER 2017 RESULTS

[0000866706-17-000010:8k_2_02:10]
ST. LOUIS, August 8, 2017 – ESCO Technologies Inc. (NYSE: ESE) (ESCO, or the Company) today reported its operating results for the third quarter (Q3 2017) and nine months year-to-date (YTD 2017) periods ended June 30, 2017.

[0000866706-17-000010:8k_2_02:11]
On May 8, 2017 and May 25, 2017, the Company acquired NRG Systems Inc. (NRG) and the assets of Morgan Schaffer Inc. (Morgan Schaffer), respectively (see earlier announcements). Net sales, earnings, acquisition fees and costs, non-cash purchase accounting inventory step-up charges, and the amortization of intangible assets related to NRG and Morgan Schaffer are included in the Q3 2017 and YTD 2017 operating results from the date of acquisition.

[0000866706-17-000010:8k_2_02:12]
The financial results presented include certain non-GAAP financial measures such as EBIT, EBITDA (defined as earnings before interest, taxes, depreciation and amortization), Adjusted EBITDA (defined as EBITDA excluding certain charges, such as non-cash purchase accounting inventory "step up" charges and costs incurred to complete the acquisitions), and Adjusted EPS. Any non-GAAP financial measures presented are reconciled to their respective GAAP equivalents.

[0000866706-17-000010:8k_2_02:13]
Management believes these non-GAAP financial measures are useful in assessing the ongoing operational profitability of the Company's business segments, and therefore, allow shareholders better visibility into the Company's underlying operations. See "Non-GAAP Financial Measures" described below.

[0000866706-17-000010:8k_2_02:14]
Earnings Summary / EPS Reconciliation

[0000866706-17-000010:8k_2_02:15]
| ● | Q3 2017 GAAP EPS was $0.49 per share and Adjusted EPS was $0.51 per share, which excludes the ($0.02) per share net impact from the acquisitions of NRG and Morgan Schaffer. The ($0.02) per share net impact of the NRG and Morgan Schaffer acquisitions reflects the partial period EBIT contribution of $1.2 million, offset by ($1.3) million of costs and fees incurred to complete the acquisitions, and ($0.7) million of non-cash purchase accounting inventory step-up charges in Q3 2017; |

[0000866706-17-000010:8k_2_02:16]
| ● | Q3 2016 GAAP EPS was $0.44 per share, and Adjusted EPS was $0.49 per share (the adjustments related to the prior year restructuring charges were described in earlier releases); |

[0000866706-17-000010:8k_2_02:17]
| ● | GAAP net earnings were $12.6 million in Q3 2017 compared to $11.5 million in Q3 2016; and |

[0000866706-17-000010:8k_2_02:18]
| ● | Adjusted EBITDA increased 9.5 percent to $27.7 million in Q3 2017 from $25.3 million in Q3 2016. Adjusted EBITDA, a non-GAAP financial measure is reconciled to GAAP net earnings in the Condensed Business Segment Information table below for all periods presented. |

[0000866706-17-000010:8k_2_02:19]
Operating Highlights

[0000866706-17-000010:8k_2_02:20]
| ● | Q3 2017 sales increased $31 million (22 percent) to $171 million compared to $140 million in Q3 2016; |

[0000866706-17-000010:8k_2_02:21]
| ● | YTD 2017 sales increased $67 million (16 percent) to $479 million compared to $412 million YTD 2016; |

[0000866706-17-000010:8k_2_02:22]
| ● | On a segment basis, Q3 2017 Filtration sales increased $17 million, or 31 percent compared to Q3 2016 driven by Westland and Mayday's Q3 2017 sales of $5 million and $11 million, respectively. Technical Packaging sales were $20 million in both Q3 periods presented and Test sales increased $1 million. USG sales increased $13 million as Doble sales increased $4 million, or 14 percent, driven by the additional sales contribution from new products and software solutions, and NRG / Morgan Schaffer contributed $9 million in sales since the date of acquisition; |

[0000866706-17-000010:8k_2_02:23]
| ● | SG&A expenses increased $7 million in Q3 2017 compared to Q3 2016 primarily due to the addition of Westland, Mayday, NRG and Morgan Schaffer in the current period, additional sales and marketing expenses at Doble to support future revenue growth, and higher professional fees and transaction costs associated with recent acquisition activities; |

[0000866706-17-000010:8k_2_02:24]
| ● | Entered orders were $182 million in Q3 2017 and $532 million YTD 2017 (book-to-bill of 1.06x and 1.11x, respectively) reflecting a $53 million (16 percent) increase in backlog for the first nine months of 2017, resulting in backlog of $386 million at June 30, 2017; |

[0000866706-17-000010:8k_2_02:25]
| ● | Filtration orders were $78 million in Q3 2017 and $207 million YTD 2017 (book-to-bill of 1.09x and 1.04x, respectively) comprised of recurring commercial aerospace orders and a large order for additional space products; |

[0000866706-17-000010:8k_2_02:26]
| ● | Test orders were $38 million in Q3 2017 and $138 million YTD 2017 (book-to-bill of 1.01x and 1.26x, respectively) which reflects continued momentum in the wireless, electric vehicle, and automotive markets. Test's significant YTD 2017 order volume and current backlog supports its projected sales and profit contribution over the remainder of the year; |

[0000866706-17-000010:8k_2_02:27]
| ● | USG orders were $46 million in Q3 2017 and $119 million YTD 2017 (book-to-bill of 1.10x and 1.08x, respectively) which reflects increased orders for new products such as the Doble Universal Controller (DUC), on-line monitoring solutions, dissolved gas analyzers (DGA's), additional software applications, and the continued expansion of service contracts; |

[0000866706-17-000010:8k_2_02:28]
| ● | Technical Packaging orders were $20 million in Q3 2017 and $68 million YTD 2017 (book-to-bill of 1.0x and 1.13x, respectively) driven by higher KAZ, medical, medical device, and pharmaceutical projects; and, |

[0000866706-17-000010:8k_2_02:29]
| ● | Net cash provided by operating activities was $33 million YTD 2017, which resulted in net debt (outstanding borrowings less cash on hand) of $216 million at June 30, 2017. |

[0000866706-17-000010:8k_2_02:30]
Chairman's Commentary – Q3 2017

[0000866706-17-000010:8k_2_02:31]
Vic Richey, Chairman and Chief Executive Officer, commented, "Let me start out by saying that I'm extremely pleased with our recent acquisitions and their initial operating contributions, as well as what we anticipate in the future from each of our new partners. Not only did we add great companies to our portfolio, we also added very solid management teams who share our vision and our values.

[0000866706-17-000010:8k_2_02:32]
"The integration of NRG, Morgan Schaffer and Doble is going very well and is ahead of plan. I'm excited about the outlook for USG as it is obvious from recent meetings that the group has come together with a unified focus on sales growth, market expansion, new product development, and enhanced operating margins.

[0000866706-17-000010:8k_2_02:33]
"Because we acquired NRG and Morgan Schaffer during May, we did not get a full quarter's profit contribution, but we did incur all of the costs of the transactions in Q3 2017 as well as several significant non-cash purchase accounting charges required under GAAP. The transaction costs will not repeat in Q4, but non-cash purchase accounting charges will negatively impact our GAAP operating results in Q4 by approximately $1.5 million, or ($0.04) per share. As we enter 2018, the inventory step-up charges will be complete and we expect to present a much cleaner outlook.

[0000866706-17-000010:8k_2_02:34]
"Moving on to a few Q3 operating highlights, Doble continued to outperform previous expectations  by delivering 14 percent sales growth as new product sales are exceeding expectations and our recent software introductions and solution offerings are being well received in the utility market. Within the Filtration and Technical Packaging segments, PTI and TEQ both exceeded profit expectations in Q3, and I'm pleased to see Test deliver a 13 percent EBIT contribution at its current sales level, which validates our profit expectations driven by its lower cost structure. Order activity has remained strong throughout the year with all four operating segments achieving YTD book-to-bill ratios greater 1.0x.

[0000866706-17-000010:8k_2_02:35]
"Summarizing our Q3 performance, we supplemented our growth by adding NRG and Morgan Schaffer, hit our sales targets, performed at the top of our EPS range, generated more cash flow than previously anticipated, and booked orders across the company that once again exceeded our expectations and resulted in an all-time high backlog at June 30, 2017.

[0000866706-17-000010:8k_2_02:36]
"On the acquisition front, we've been very active recently and are currently evaluating additional opportunities. We remain optimistic that we can further supplement our organic growth in both the near term and longer term, but we remain disciplined in our approach and will continue to maintain our focus on generating an attractive ROIC (return on invested capital).

[0000866706-17-000010:8k_2_02:37]
"Moving on to our Q4 and full year outlook: Our plan and prior guidance anticipated a very large Q4 supported by the strength of our orders and backlog. While Q4 is still expected to be strong as well as significantly higher than Q4 2016, it will be short of our earlier expectations due to a few operational and non-operational items. While the acquisitions are solidly profitable, the above noted acquisition costs, non-cash inventory step-up charges, increased amortization charges, and associated interest costs are higher than the profit contributions during the short period since the date of acquisition.

[0000866706-17-000010:8k_2_02:38]
"Additionally, from a timing perspective we had a few customer-driven orders and deliveries pushed out of the year which will negatively impact several of our operating units in Q4 2017 to the benefit of 2018. And lastly, VACCO experienced some engineering and development cost growth on several space-related new products which impact 2017's operating results.

[0000866706-17-000010:8k_2_02:39]
"While the shortfall is disappointing, I'm fully confident that this is merely a "stack up" of various items, both operational and non-operational, cash and non-cash, which hit us in a short period of time, and I'm fully confident these non-recurring issues will be resolved in Q4."

[0000866706-17-000010:8k_2_02:40]
Dividend Payment

[0000866706-17-000010:8k_2_02:41]
The next quarterly cash dividend of $0.08 per share will be paid on October 17, 2017 to stockholders of record on October 3, 2017.

[0000866706-17-000010:8k_2_02:42]
Business Outlook – Fiscal Year 2017

[0000866706-17-000010:8k_2_02:43]
With the increased level of M&A activity, Management has placed more emphasis on Adjusted EBITDA and ROIC, as it believes these are the most relevant metrics to be considered for valuation. Adjusted EBITDA and ROIC are two of the key financial metrics used by Management when determining the appropriate price for acquisitions.

[0000866706-17-000010:8k_2_02:44]
Given the 2017 financial contributions from the Westland, Mayday, NRG and Morgan Schaffer acquisitions, as well as the significant costs incurred in the execution of these acquisitions, and considering both operational and non-cash purchase accounting items, the current outlook for 2017 compared to the original guidance is described as follows:

[0000866706-17-000010:8k_2_02:45]
| ● | 2017 sales compared to 2016 are expected to increase approximately $120 million, or 21 percent (previous guidance was 18 percent to 20 percent). The increase is driven by the additional sales from acquisitions, increased space and navy business at VACCO, and higher sales of Doble's new products (DUC, etc.), software and services; |

[0000866706-17-000010:8k_2_02:46]
| ● | Gross profit dollars for the year are expected to increase approximately 13 percent compared to 2016 driven by the additional sales noted above and a meaningful incremental profit contribution from Doble. Gross profit dollars and margins in 2017 are negatively impacted by $4 million ($0.10 per share after-tax) of non-cash purchase accounting inventory step-up charges at Mayday, NRG and Morgan Schaffer. Compared to previous expectations, gross profit is also negatively impacted by certain space-related new product development cost overruns at VACCO, and revised customer-driven order and delivery schedules at Test, Plastique and Westland which moved previously expected 2017 sales into 2018; |

[0000866706-17-000010:8k_2_02:47]
| ● | EBIT dollars are expected to increase by more than 21 percent over 2016 due to the sales increase noted above, despite the impact of the purchase accounting charges discussed above; |

[0000866706-17-000010:8k_2_02:48]
| ● | 2017 Adjusted EBITDA (defined above) is expected to increase approximately 21 percent over 2016, consistent with the original guidance, resulting in Adjusted EBITDA of approximately $122 million compared to 2016 Adjusted EBITDA of $101 million; |

[0000866706-17-000010:8k_2_02:49]
| ● | Interest expense on higher debt outstanding resulting from the 2017 acquisitions is expected to increase to $4.5 million (compared to $3.6 million expected in November's guidance), which reflects a $3.2 million increase from the $1.3 million of interest expense recorded in 2016; |

[0000866706-17-000010:8k_2_02:50]
| ● | Depreciation and amortization is expected to increase approximately $9 million, or ($0.22 per share after-tax) consistent with the amounts communicated in November's guidance; |

[0000866706-17-000010:8k_2_02:51]
| ● | 2017 income tax expense (dollars) is expected to increase over 2016 based on higher pretax earnings. Management expects a 33 percent effective tax rate in 2017, consistent with the 33 percent effective tax rate in 2016; |

[0000866706-17-000010:8k_2_02:52]
| ● | In summary, Management projects 2017 GAAP EPS to be in the range of $2.05 to $2.10 per share, reflecting the profit contributions from the recent acquisitions, offset by the costs of the recent acquisitions, the impact of the purchase accounting inventory step-up charges noted above, the impact of additional depreciation and amortization, and customer-driven program pushouts described above. |

[0000866706-17-000010:8k_2_02:53]
Chairman's Commentary – Preliminary 2018 Perspective

[0000866706-17-000010:8k_2_02:54]
Including the contributions from the Company's recent acquisitions, coupled with current expectations of organic growth from "legacy" operations, Management's preliminary 2018 outlook reflects solid sales and Adjusted EBITDA growth across each of the Company's business segments and anticipates growth rates in 2018 and beyond that exceed the broader industrial market.

[0000866706-17-000010:8k_2_02:55]
Mr. Richey continued, "While our current focus is on completing 2017, as we look ahead to 2018 we are encouraged by our outlook. Our core businesses remain solid and the new acquisitions will be fully integrated and contributing at a significant level in 2018. The "noise" surrounding the acquisition costs, purchase accounting, and performance issues we encountered late in 2017 will be behind us. We will move forward into 2018 with numerous growth opportunities across all of our operating segments, and expect to continue supplementing our organic growth through additional complementary acquisitions.

[0000866706-17-000010:8k_2_02:56]
"Our current backlog and expectations for additional orders have us well positioned for 2018. Our management teams' focus on profitable growth and ROIC will remain steadfast as we believe these are the key drivers of continued and sustainable share price appreciation."

[0000866706-17-000010:8k_2_02:57]
Conference Call

[0000866706-17-000010:8k_2_02:58]
The Company will host a conference call today, August 8, at 4:00 p.m. Central Time, to discuss the Company's Q3 2017 results. A live audio webcast will be available on the Company's website at www.escotechnologies.com. Please access the website at least 15 minutes prior to the call to register, download and install any necessary audio software. A replay of the conference call will be available for seven days on the Company's website noted above or by phone (dial 1-855-859-2056 and enter the pass code 46597032).

[0000866706-17-000010:8k_2_02:59]
Forward-Looking Statements

[0000866706-17-000010:8k_2_02:60]
Statements in this press release regarding the Company's expected quarterly, 2017 full year and beyond results, revenue and sales growth, EPS, EPS growth, EBIT, EBITDA, Adjusted EBITDA, gross profit, interest expense, non-cash depreciation and amortization of intangibles, corporate costs, effective tax rates, the Company's ability to increase operating margins, realize financial goals and increase shareholder value, the success of acquisition efforts, the size, number and timing of future sales and growth opportunities, the long-term success of the Company, and any other statements which are not strictly historical are "forward-looking" statements within the meaning of the safe harbor provisions of the federal securities laws.

[0000866706-17-000010:8k_2_02:61]
Investors are cautioned that such statements are only predictions and speak only as of the date of this release, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company's actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company's operations and business environment including, but not limited to those described in Item 1A, "Risk Factors", of the Company's Annual Report on Form 10-K for the fiscal year ended September 30, 2016, and the following: the success of the Company's competitors; weakening of economic conditions in served markets; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties; delivery delays or defaults by customers; material changes in the costs and availability of certain raw materials; the appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer contracts; the timing and content of future contract awards or customer orders; performance issues with key customers, suppliers and subcontractors; labor disputes; the impacts of natural disasters on the Company's operations and those of the Company's customers and suppliers; changes in laws and regulations, including but not limited to changes in accounting standards and taxation requirements; changes in interest rates; costs relating to environmental matters arising from current or former facilities; financial exposure in connection with Company guarantees of certain Aclara contracts; the availability of select acquisitions; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the success and integration of recently acquired businesses.

[0000866706-17-000010:8k_2_02:62]
Non-GAAP Financial Measures

[0000866706-17-000010:8k_2_02:63]
The financial measures EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS are presented in this press release. The Company defines "EBIT" as earnings before interest and taxes, "EBITDA" as earnings before interest, taxes, depreciation and amortization, "Adjusted EBITDA" as EBITDA excluding certain defined non-recurring charges, and "Adjusted EPS" as GAAP earnings per share (EPS) excluding the non-recurring charges described above which were $0.02 per share for Q3 2017 and $0.05 per share for Q3 2016.

[0000866706-17-000010:8k_2_02:64]
EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management believes that EBIT, EBITDA and Adjusted EBDITDA are useful in assessing the operational profitability of the Company's business segments because they exclude interest, taxes, depreciation and amortization, which are generally accounted for across the entire Company on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company as well as incentive compensation. The Company believes that the presentation of EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS provides important supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance determined in accordance with GAAP.

[0000866706-17-000010:8k_2_02:65]
ESCO, headquartered in St. Louis: Manufactures highly-engineered filtration and fluid control products for the aviation, space and process markets worldwide; is the industry leader in RF shielding and EMC test products; provides diagnostic instruments, software and services for the benefit of industrial power users and the electric utility and renewable energy industries; and, produces custom thermoformed packaging, pulp-based packaging, and specialty products for medical and commercial markets. Further information regarding ESCO and its subsidiaries is available on the Company's website at www.escotechnologies.com.

[0000866706-17-000010:8k_2_02:66]
-  tables attached -

[0000866706-17-000010:8k_2_02:67]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |  |  |  |
| Condensed Consolidated Statements of Operations (Unaudited) |  |  |  |  |
| (Dollars in thousands, except per share amounts) |  |  |  |  |
|  |  | Three Months Ended June 30, 2017 |  |  |  |  |  | Three Months Ended June 30, 2016 |  |  |  |  |
| Net Sales |  | $ | 171,189 |  |  |  |  |  |  | 140,191 |  |  |  |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 108,856 |  |  |  |  |  |  | 86,602 |  |  |  |  |
| Selling, general and administrative expenses |  |  | 38,453 |  |  |  |  |  |  | 31,369 |  |  |  |  |
| Amortization of intangible assets |  |  | 4,085 |  |  |  |  |  |  | 2,951 |  |  |  |  |
| Interest expense |  |  | 1,213 |  |  |  |  |  |  | 320 |  |  |  |  |
| Other expenses, net |  |  | 1,160 |  |  |  |  |  |  | 1,429 |  |  |  |  |
| Total costs and expenses |  |  | 153,767 |  |  |  |  |  |  | 122,671 |  |  |  |  |
| Earnings before income taxes |  |  | 17,422 |  |  |  |  |  |  | 17,520 |  |  |  |  |
| Income taxes |  |  | 4,777 |  |  |  |  |  |  | 5,992 |  |  |  |  |
| Net earnings |  | $ | 12,645 |  |  |  |  |  |  | 11,528 |  |  |  |  |
| Diluted EPS - GAAP |  | $ | 0.49 |  |  |  |  |  |  | 0.44 |  |  |  |  |
| Adjusted EPS |  | $ | 0.51 | (1) |  |  |  |  |  |  | 0.49 | (2) |  |  |  |  |
| Diluted average common shares O/S: |  |  | 26,025 |  |  |  |  |  |  |  | 25,910 |  |  |  |  |  |

[0000866706-17-000010:8k_2_02:68]
| (1) | Q3 FY 17 - Adjusted EPS was $0.51 which excluded $0.5 million (or $0.02 per share) net impact from the acquisitions of NRG and Morgan Schaffer during the third quarter of 2017. |  |
| (2) | Q3 FY 16 - Adjusted EPS was $0.49 which excluded $1.1 million (or $0.05 per share) of restructuring charges incurred at ETS and Doble during the third quarter of 2016. |  |

[0000866706-17-000010:8k_2_02:69]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |  |  |  |
| Condensed Consolidated Statements of Operations (Unaudited) |  |  |  |  |
| (Dollars in thousands, except per share amounts) |  |  |  |  |
|  |  | Nine Months Ended June 30, 2017 |  |  |  |  |  | Nine Months Ended June 30, 2016 |  |  |  |  |
| Net Sales |  | $ | 478,735 |  |  |  |  |  |  | 411,954 |  |  |  |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 307,149 |  |  |  |  |  |  | 254,769 |  |  |  |  |
| Selling, general and administrative expenses |  |  | 107,104 |  |  |  |  |  |  | 97,189 |  |  |  |  |
| Amortization of intangible assets |  |  | 11,548 |  |  |  |  |  |  | 8,540 |  |  |  |  |
| Interest expense |  |  | 2,752 |  |  |  |  |  |  | 917 |  |  |  |  |
| Other (income) expenses, net |  |  | (184 | ) |  |  |  |  |  | 6,436 |  |  |  |  |
| Total costs and expenses |  |  | 428,369 |  |  |  |  |  |  | 367,851 |  |  |  |  |
| Earnings before income taxes |  |  | 50,366 |  |  |  |  |  |  | 44,103 |  |  |  |  |
| Income taxes |  |  | 15,837 |  |  |  |  |  |  | 15,136 |  |  |  |  |
| Net earnings |  | $ | 34,529 |  |  |  |  |  |  | 28,967 |  |  |  |  |
| Diluted EPS - GAAP |  | $ | 1.33 |  |  |  |  |  |  | 1.12 |  |  |  |  |
| Adjusted EPS |  | $ | 1.41 | (1) |  |  |  |  |  |  | 1.36 | (2) |  |  |  |  |
| Diluted average common shares O/S: |  |  | 25,975 |  |  |  |  |  |  |  | 25,962 |  |  |  |  |  |

[0000866706-17-000010:8k_2_02:70]
| (1) | YTD Q3 FY 17 - Adjusted EPS was $1.41 which excluded $2.0 million (or $0.08 per share) net impact from the acquisitions of Mayday, NRG and Morgan Schaffer during the first nine months of 2017. |  |
| (2) | YTD Q3 FY 16 - Adjusted EPS was $1.36 which excluded $6.3 million (or $0.24 per share) of restructuring charges incurred at ETS and Doble during the first nine months of 2016. |  |

[0000866706-17-000010:8k_2_02:71]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Condensed Business Segment Information (Unaudited) |
| (Dollars in thousands) |
|  |  | GAAP |  |  |  |  |  |
|  |  |  | Q3 2017 |  |  |  | Q3 2016 |  |  |  |  |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 71,179 |  |  |  | 54,396 |  |  |  |  |  |
| Test |  |  | 37,544 |  |  |  | 36,234 |  |  |  |  |  |
| USG |  |  | 42,059 |  |  |  | 29,121 |  |  |  |  |  |
| Technical Packaging |  |  | 20,407 |  |  |  | 20,440 |  |  |  |  |  |
| Totals |  | $ | 171,189 |  |  |  | 140,191 |  |  |  |  |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 11,945 |  |  |  | 12,163 |  |  |  |  |  |
| Test |  |  | 4,885 |  |  |  | 3,744 |  |  |  |  |  |
| USG |  |  | 8,477 |  |  |  | 6,124 |  |  |  |  |  |
| Technical Packaging |  |  | 2,433 |  |  |  | 2,474 |  |  |  |  |  |
| Corporate |  |  | (9,105 | ) |  |  | (6,665 | ) |  |  |  |  |
| Consolidated EBIT |  |  | 18,635 |  |  |  | 17,840 |  |  |  |  |  |
| Less: Interest expense |  |  | (1,213 | ) |  |  | (320 | ) |  |  |  |  |
| Less: Income tax expense |  |  | (4,777 | ) |  |  | (5,992 | ) |  |  |  |  |
| Net earnings |  | $ | 12,645 |  |  |  | 11,528 |  |  |  |  |  |

[0000866706-17-000010:8k_2_02:72]
| Note 1: Adjusted net earnings were $13.1 million in Q3 17 which excluded $0.5 million (or $0.02 per share) net impact from the acquisitions of NRG and Morgan Schaffer during the third quarter of 2017. |
| Note 2: Adjusted net earnings were $12.6 million in Q3 16 which excluded $1.1 million (or $0.05 per share) of restructuring charges at ETS and Doble during the third quarter of 2016. |

[0000866706-17-000010:8k_2_02:73]
| EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |  |  |  |  |
|  |  |  | Q3 2017 |  |  | Q3 2017 - As Adj |  |  |  | Q3 2016 |  | Q3 2016 - As Adj |  |
| Consolidated EBITDA |  | $ | 26,970 |  |  |  | 27,724 |  |  |  | 23,811 |  |  | 25,264 |  |
| Less: Depr & Amort |  |  | (8,335 | ) |  |  | (8,335 | ) |  |  | (5,971 | ) |  | (5,971 | ) |
| Consolidated EBIT |  |  | 18,635 |  |  |  | 19,389 |  |  |  | 17,840 |  |  | 19,293 |  |
| Less: Interest expense |  |  | (1,213 | ) |  |  | (1,213 | ) |  |  | (320 | ) |  | (320 | ) |
| Less: Income tax expense |  |  | (4,777 | ) |  |  | (5,041 | ) |  |  | (5,992 | ) |  | (6,332 | ) |
| Net earnings |  | $ | 12,645 |  |  |  | 13,135 |  |  |  | 11,528 |  |  | 12,641 |  |

[0000866706-17-000010:8k_2_02:74]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Condensed Business Segment Information (Unaudited) |
| (Dollars in thousands) |
|  |  | GAAP |  |  |  |
|  |  | YTD Q3 2017 |  |  | YTD Q3 2016 |  |  |  |
| Net Sales |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 198,869 |  |  |  | 145,758 |  |  |  |
| Test |  |  | 109,738 |  |  |  | 119,608 |  |  |  |
| USG |  |  | 110,287 |  |  |  | 93,657 |  |  |  |
| Technical Packaging |  |  | 59,841 |  |  |  | 52,931 |  |  |  |
| Totals |  | $ | 478,735 |  |  |  | 411,954 |  |  |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 34,296 |  |  |  | 29,511 |  |  |  |
| Test |  |  | 11,076 |  |  |  | 8,587 |  |  |  |
| USG |  |  | 25,585 |  |  |  | 21,581 |  |  |  |
| Technical Packaging |  |  | 5,660 |  |  |  | 7,035 |  |  |  |
| Corporate |  |  | (23,499 | ) |  |  | (21,694 | ) |  |  |
| Consolidated EBIT |  |  | 53,118 |  |  |  | 45,020 |  |  |  |
| Less: Interest expense |  |  | (2,752 | ) |  |  | (917 | ) |  |  |
| Less: Income tax expense |  |  | (15,837 | ) |  |  | (15,136 | ) |  |  |
| Net earnings |  | $ | 34,529 |  |  |  | 28,967 |  |  |  |

[0000866706-17-000010:8k_2_02:75]
| Note 1: Adjusted net earnings were $36.5 million YTD Q3 17 which excluded $2.0 million (or $0.08 per share) net impact from the acquisitions of Mayday, NRG and Morgan Schaffer during the first nine months of 2017. |
| Note 2: Adjusted net earnings were $35.3 million YTD Q3 16 which excluded $6.3 million (or $0.24 per share) of restructuring charges at ETS and Doble during the first nine months of 2016. |

[0000866706-17-000010:8k_2_02:76]
| EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | YTD Q3 2017 |  |  | YTD Q3 2017 - As Adjusted |  |  |  | YTD Q3 2016 |  |  | YTD Q3 2016 - As Adjusted |  |
| Consolidated EBITDA |  | $ | 76,141 |  |  |  | 79,181 |  |  |  | 62,229 |  |  |  | 69,192 |  |
| Less: Depr & Amort |  |  | (23,023 | ) |  |  | (23,023 | ) |  |  | (17,209 | ) |  |  | (17,209 | ) |
| Consolidated EBIT |  |  | 53,118 |  |  |  | 56,158 |  |  |  | 45,020 |  |  |  | 51,983 |  |
| Less: Interest expense |  |  | (2,752 | ) |  |  | (2,752 | ) |  |  | (917 | ) |  |  | (917 | ) |
| Less: Income tax expense |  |  | (15,837 | ) |  |  | (16,901 | ) |  |  | (15,136 | ) |  |  | (15,770 | ) |
| Net earnings |  | $ | 34,529 |  |  |  | 36,505 |  |  |  | 28,967 |  |  |  | 35,296 |  |

[0000866706-17-000010:8k_2_02:77]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Condensed Consolidated Balance Sheets (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  | June 30, 2017 |  |  | September 30, 2016 |  |
| Assets |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 48,521 |  |  |  | 53,825 |  |
| Accounts receivable, net |  |  | 135,545 |  |  |  | 121,486 |  |
| Costs and estimated earnings on |  |  |  |  |  |  |  |  |
| long-term contracts |  |  | 44,753 |  |  |  | 28,746 |  |
| Inventories |  |  | 130,828 |  |  |  | 105,542 |  |
| Other current assets |  |  | 20,980 |  |  |  | 13,884 |  |
| Total current assets |  |  | 380,627 |  |  |  | 323,483 |  |
| Property, plant and equipment, net |  |  | 130,419 |  |  |  | 92,405 |  |
| Intangible assets, net |  |  | 328,545 |  |  |  | 231,759 |  |
| Goodwill |  |  | 365,965 |  |  |  | 323,616 |  |
| Other assets |  |  | 5,901 |  |  |  | 7,108 |  |
|  |  | $ | 1,211,457 |  |  |  | 978,371 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Short-term borrowings and current |  | $ | 20,000 |  |  |  | 20,000 |  |
| maturities of long-term debt |  |  |  |  |  |  |  |  |
| Accounts payable |  |  | 48,555 |  |  |  | 42,074 |  |
| Current portion of deferred revenue |  |  | 31,881 |  |  |  | 27,212 |  |
| Other current liabilities |  |  | 75,143 |  |  |  | 68,790 |  |
| Total current liabilities |  |  | 175,579 |  |  |  | 158,076 |  |
| Deferred tax liabilities |  |  | 84,184 |  |  |  | 69,562 |  |
| Other liabilities |  |  | 62,105 |  |  |  | 45,624 |  |
| Long-term debt |  |  | 245,000 |  |  |  | 90,000 |  |
| Shareholders' equity |  |  | 644,589 |  |  |  | 615,109 |  |
|  |  | $ | 1,211,457 |  |  |  | 978,371 |  |

[0000866706-17-000010:8k_2_02:78]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Consolidated Statements of Cash Flows (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  | Nine Months Ended June 30, 2017 |  |
| Cash flows from operating activities: |  |  |  |
| Net earnings |  | $ | 34,529 |  |
| Adjustments to reconcile net earnings |  |  |  |  |
| to net cash provided by operating activities: |  |  |  |  |
| Depreciation and amortization |  |  | 23,023 |  |
| Stock compensation expense |  |  | 4,130 |  |
| Changes in assets and liabilities |  |  | (24,977 | ) |
| Change in deferred revenue and costs, net |  |  | 4,863 |  |
| Effect of deferred taxes |  |  | (577 | ) |
| Pension contributions |  |  | (2,317 | ) |
| Other |  |  | (5,202 | ) |
| Net cash provided by operating activities |  |  | 33,472 |  |
| Cash flows from investing activities: |  |  |  |  |
| Acquisition of businesses, net of cash acquired |  |  | (162,268 | ) |
| Capital expenditures |  |  | (23,055 | ) |
| Additions to capitalized software |  |  | (6,213 | ) |
| Proceeds from sale of land |  |  | 1,184 |  |
| Proceeds from life insurance |  |  | 2,307 |  |
| Net cash used by investing activities |  |  | (188,045 | ) |
| Cash flows from financing activities: |  |  |  |  |
| Proceeds from long-term debt |  |  | 213,000 |  |
| Principal payments on long-term debt |  |  | (58,000 | ) |
| Dividends paid |  |  | (6,190 | ) |
| Other |  |  | (21 | ) |
| Net cash provided by financing activities |  |  | 148,789 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 480 |  |
| Net decrease in cash and cash equivalents |  |  | (5,304 | ) |
| Cash and cash equivalents, beginning of period |  |  | 53,825 |  |
| Cash and cash equivalents, end of period |  | $ | 48,521 |  |

[0000866706-17-000010:8k_2_02:79]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Other Selected Financial Data (Unaudited) |  |
| (Dollars in thousands) |  |
| Backlog And Entered Orders - Q3 FY 2017 |  | Filtration |  |  | Test |  |  | USG |  |  | Technical Packaging |  |  | Total |  |
| Beginning Backlog - 4/1/17 |  | $ | 197,651 |  |  |  | 111,219 |  |  |  | 38,073 |  |  |  | 27,645 |  |  |  | 374,588 |  |
| Entered Orders |  |  | 77,582 |  |  |  | 38,031 |  |  |  | 46,355 |  |  |  | 20,268 |  |  |  | 182,236 |  |
| Sales |  |  | (71,179 | ) |  |  | (37,544 | ) |  |  | (42,059 | ) |  |  | (20,407 | ) |  |  | (171,189 | ) |
| Ending Backlog - 6/30/17 |  | $ | 204,054 |  |  |  | 111,706 |  |  |  | 42,369 |  |  |  | 27,506 |  |  |  | 385,635 |  |
| Backlog And Entered Orders - YTD Q3 FY 2017 |  | Filtration |  |  | Test |  |  | USG |  |  | Technical Packaging |  |  | Total |  |
| Beginning Backlog - 10/1/16 |  | $ | 195,801 |  |  |  | 83,170 |  |  |  | 33,744 |  |  |  | 19,654 |  |  |  | 332,369 |  |
| Entered Orders |  |  | 207,122 |  |  |  | 138,274 |  |  |  | 118,912 |  |  |  | 67,693 |  |  |  | 532,001 |  |
| Sales |  |  | (198,869 | ) |  |  | (109,738 | ) |  |  | (110,287 | ) |  |  | (59,841 | ) |  |  | (478,735 | ) |
| Ending Backlog - 6/30/17 |  | $ | 204,054 |  |  |  | 111,706 |  |  |  | 42,369 |  |  |  | 27,506 |  |  |  | 385,635 |  |
