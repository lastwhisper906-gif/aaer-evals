# ESE MD&A — 0001144204-17-041277


## mdna

[0001144204-17-041277:mdna:1]
ITEM 2. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL
CONDITION AND RESULTS OF OPERATIONS

[0001144204-17-041277:mdna:2]
[same as prior period, unchanged from 0001144204-17-025448:mdna:2]

[0001144204-17-041277:mdna:3]
References to the third quarters of 2017 and 2016 represent
the three-month periods ended June 30, 2017 and 2016, respectively.

[0001144204-17-041277:mdna:4]
[same as prior period, unchanged from 0001144204-17-025448:mdna:4]

[0001144204-17-041277:mdna:5]
In the third quarter of 2017, sales, net earnings and diluted
earnings per share were $171.2 million, $12.6 million and $0.49 per share, respectively, compared to $140.2 million, $11.5 million
and $0.44 per share, respectively, in the third quarter of 2016. In the first nine months of 2017, sales, net earnings and diluted
earnings per share were $478.7 million, $34.5 million and $1.33, respectively, compared to $412.0 million, $29.0 million and $1.12
per share, respectively, in the first nine months of 2016.

[0001144204-17-041277:mdna:6]
[same as prior period, unchanged from 0001144204-17-025448:mdna:8]

[0001144204-17-041277:mdna:7]
Net sales increased $31.0 million, or 22.1%, to $171.2 million
in the third quarter of 2017 from $140.2 million in the third quarter of 2016. Net sales increased $66.7 million, or 16.2%, to
$478.7 million in the first nine months of 2017 from $412.0 million in the first nine months of 2016. The increase in net sales
in the third quarter of 2017 as compared to the third quarter of 2016 was due to a $16.8 million increase in the Filtration segment,
a $12.9 million increase in the USG segment and a $1.3 million increase in the Test segment. The increase in net sales in the
first nine months of 2017 as compared to the first nine months of 2016 was due to a to a $53.1 million increase in the Filtration
segment, a $16.6 million increase in the USG segment and a $6.9 million increase in the Technical Packaging segment, partially
offset by a $9.9 million decrease in the Test segment.

[0001144204-17-041277:mdna:8]
[same as prior period, unchanged from 0001144204-17-025448:mdna:10]

[0001144204-17-041277:mdna:9]
In the third quarter of 2017, net sales of $71.2 million were
$16.8 million, or 30.9%, higher than the $54.4 million in the third quarter of 2016. Net sales increased $53.1 million, or 36.4%,
to $198.9 million in the first nine months of 2017 from $145.8 million in the first nine months of 2016. The sales increase in
the third quarter of 2017 compared to the third quarter of 2016 was mainly due to the sales contributions from the Company’s
recent acquisitions of Westland ($5.5 million) and Mayday ($11.4 million); and a $2.5 million increase in net sales at VACCO due
to higher shipments of its space and defense products, partially offset by a $1.6 million decrease in sales at PTI due to lower
aerospace assembly shipments and a $1.0 million decrease in sales at Crissair due to lower aerospace shipments. The sales increase
in the first nine months of 2017 compared to the first nine months of 2016 was primarily due to the sales contributions from the
Company’s recent acquisitions of Westland ($17.6 million) and Mayday ($27.9 million); and a $9.2 million increase in net
sales at VACCO due to higher shipments of its space and defense products, partially offset by a $2.9 million decrease in sales
at Crissair due to lower aerospace shipments.

[0001144204-17-041277:mdna:10]
|  |  | 13 |

[0001144204-17-041277:mdna:11]
[same as prior period, unchanged from 0001144204-17-025448:mdna:13]

[0001144204-17-041277:mdna:12]
In the third quarter of 2017, net sales of $37.5 million were
$1.3 million, or 3.6%, higher than the $36.2 million recorded in the third quarter of 2016. Net sales decreased $9.9 million, or
8.3%, to $109.7 million in the first nine months of 2017 from $119.6 million in the first nine months of 2016. The increase in
the third quarter of 2017 compared to the third quarter of 2016 was primarily due to higher sales from the segment’s U.S.
operations due to the timing of test and measurement chamber projects. The decrease in the first nine months of 2017 compared to
the first nine months of 2016 was mainly due to a decrease in net sales from the segment’s European and U.S. operations primarily
related to the timing of projects and lower sales volumes of domestic shielding products.

[0001144204-17-041277:mdna:13]
[same as prior period, unchanged from 0001144204-17-025448:mdna:15]

[0001144204-17-041277:mdna:14]
Net sales increased $12.9 million, or 44.4%, to $42.0 million
in the third quarter of 2017 from $29.1 million in the third quarter of 2016. Net sales increased $16.6 million, or 17.8%, to $110.3
million in the first nine months of 2017 from $93.7 million in the first nine months of 2016. The increase in the third quarter
and first nine months of 2017 compared to the corresponding periods of 2016 was mainly driven by the $8.7 million sales contribution
from the NRG and Morgan Schaffer acquisitions and new products and software solutions at Doble.

[0001144204-17-041277:mdna:15]
[same as prior period, unchanged from 0001144204-17-025448:mdna:17]

[0001144204-17-041277:mdna:16]
In the third quarters of 2017 and 2016, net sales were $20.4
million, respectively. Net sales increased $6.9 million, or 13.1%, to $59.8 million in the first nine months of 2017 from $52.9
million in the first nine months of 2016. The increase in the first nine months of 2017 compared to the first nine months of 2016
was mainly due to the $8.9 million sales contribution from Plastique which was acquired in January 2016 partially offset by a $2.0
million decrease in net sales from TEQ due to lower shipments to medical customers.

[0001144204-17-041277:mdna:17]
[same as prior period, unchanged from 0001144204-17-025448:mdna:19]

[0001144204-17-041277:mdna:18]
Backlog was $385.6 million at June 30, 2017 compared with $332.4
million at September 30, 2016. The Company received new orders totaling $182.2 million in the third quarter of 2017 compared to
$125.1 million in the third quarter of 2016. Of the new orders received in the third quarter of 2017, $77.6 million related to
Filtration products, $38.0 million related to Test products, $46.3 million related to USG products, and $20.3 million related to
Technical Packaging products. Of the new orders received in the third quarter of 2016, $44.9 million related to Filtration products,
$34.8 million related to Test products, $27.7 million related to USG products, and $17.7 million related to Technical Packaging
products

[0001144204-17-041277:mdna:19]
The Company received new orders totaling $532.0 million in the
first nine months of 2017 compared to $397.7 million in the first nine months of 2016. Of the new orders received in the first
nine months of 2017, $207.1 million related to Filtration products, $138.3 million related to Test products, $118.9 million related
to USG products, and $67.7 million related to Technical Packaging products. Of the new orders received in the first nine months
of 2016, $

[0001144204-17-041277:mdna:20]
|  |  | 14 |

[0001144204-17-041277:mdna:21]
3.9 million related to Filtration products, $108.4 million related to Test products, $88.0 million related to USG products,
and $57.4 million related to Technical Packaging products.

[0001144204-17-041277:mdna:22]
[same as prior period, unchanged from 0001144204-17-025448:mdna:22]

[0001144204-17-041277:mdna:23]
Selling, general and administrative (SG&A) expenses for
the third quarter of 2017 were $38.5 million (22.5% of net sales), compared with $31.4 million (22.4% of net sales) for the third
quarter of 2016. For the first nine months of 2017, SG&A expenses were $107.1 million (22.4% of net sales) compared to $97.2
million (23.6% of net sales) for the first nine months of 2016. The increase in SG&A expenses in the third quarter of 2017
compared to the third quarter of 2016 was mainly due to an increase in the Filtration and USG segments due to the Company’s
recent acquisitions (Westland, Mayday, NRG and Morgan Schaffer), additional sales and marketing expenses at Doble and higher professional
fees at Corporate related to M&A activities. The increase in SG&A in the first nine months of 2017 compared to the first
nine months of 2016 was mainly due to an increase in SG&A expenses in the Filtration, USG and Technical Packaging segments
due to the Company’s recent acquisitions and additional sales and marketing expenses at Doble partially offset by a decrease
in SG&A expenses in the Test segment (as a result of the 2016 restructuring activities), and lower professional fees at Corporate.

[0001144204-17-041277:mdna:24]
14

[0001144204-17-041277:mdna:25]
[same as prior period, unchanged from 0001144204-17-025448:mdna:25]

[0001144204-17-041277:mdna:26]
Amortization of intangible assets was $4.1 million and $11.5
million for the third quarter and first nine months of 2017, respectively, compared to $3.0 million and $8.5 million for the corresponding
periods of 2016. Amortization expenses consist of amortization of acquired intangible assets from acquisitions and other identifiable
intangible assets (primarily software). The increase in amortization expense in the third quarter and first nine months of 2017
compared to the corresponding periods of 2016 was mainly due to an increase in amortization of intangibles related to the Morgan
Schaffer, NRG, Westland, and Mayday acquisitions.

[0001144204-17-041277:mdna:27]
[same as prior period, unchanged from 0001144204-17-025448:mdna:27]

[0001144204-17-041277:mdna:28]
Other expenses, net, were $1.2 million in the third quarter
of 2017 compared to other expenses, net, of $1.4 million in the third quarter of 2016. Other income, net, was $0.2 million in
the first nine months of 2017 compared to other expenses, net, of $6.4 million in the first nine months of 2016. The principal
component in other income, net, in the first nine months of 2017 was $0.4 million of income related to death benefit insurance
proceeds from a former employee. The principal components in other expenses, net, in the first nine months of 2016 were $4.5 million
of restructuring costs related to the Test segment and $1.9 million of costs related to the USG segment restructuring activities.

[0001144204-17-041277:mdna:29]
[same as prior period, unchanged from 0001144204-17-025448:mdna:30]

[0001144204-17-041277:mdna:30]
The Company evaluates the performance of its operating segments
based on EBIT, and provides EBIT on a consolidated basis, which is a non-GAAP financial measure. Please refer to the discussion
of non-GAAP financial measures in Note 7 to the Consolidated Financial Statements, above. EBIT was $18.6 million (10.9% of net
sales) for the third quarter of 2017 compared to $17.8 million (12.7% of net sales) for the third quarter of 2016. For the first
nine months of 2017, EBIT was $53.1 million (11.1% of net sales) compared to $45.0 million (10.9% of net sales) for the first nine
months of 2016.

[0001144204-17-041277:mdna:31]
[same as prior period, unchanged from 0001144204-17-025448:mdna:32]

[0001144204-17-041277:mdna:32]
| (In thousands) |  | Three Months Ended June 30, |  |  | Nine Months Ended June 30, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Consolidated EBIT |  | $ | 18,635 |  |  |  | 17,840 |  |  |  | 53,118 |  |  |  | 45,020 |  |
| Less: Interest expense, net |  |  | (1,213 | ) |  |  | (320 | ) |  |  | (2,752 | ) |  |  | (917 | ) |
| Less: Income tax expense |  |  | (4,777 | ) |  |  | (5,992 | ) |  |  | (15,837 | ) |  |  | (15,136 | ) |
| Net earnings |  | $ | 12,645 |  |  |  | 11,528 |  |  |  | 34,529 |  |  |  | 28,967 |  |

[0001144204-17-041277:mdna:33]
[same as prior period, unchanged from 0001144204-17-025448:mdna:34]

[0001144204-17-041277:mdna:34]
EBIT in the third quarter of 2017 was $11.9 million (16.8% of
net sales) compared to $12.2 million (22.4% of net sales) in the third quarter of 2016. In the first nine months of 2017, EBIT
was $34.3 million (17.2% of net sales) compared to $29.5 million (20.2% of net sales) in the first nine months of 2016. The decrease
in EBIT dollars and as a percent of net sales in the third quarter of 2017 compared to the third quarter of 2016 was mainly due
to lower sales volumes at PTI and engineering and development cost growth on certain fixed price development contracts at VACCO.
The increase in EBIT in the first nine months of 2017 compared to the first nine months of 2016 was mainly due to the EBIT contribution
from the Westland and Mayday acquisitions and an increase at PTI. EBIT as a percent of net sales decreased in the first nine months
of 2017 compared to the respective 2016 period mainly due to the purchase accounting inventory step-up charge at Mayday of $1.9
million in the first nine months of 2017.

[0001144204-17-041277:mdna:35]
[same as prior period, unchanged from 0001144204-17-025448:mdna:36]

[0001144204-17-041277:mdna:36]
EBIT in the third quarter of 2017 was $4.9 million (13.0% of
net sales) compared to $3.7 million (10.3% of net sales) in the third quarter of 2016. In the first nine months of 2017, EBIT was
$11.1 million (10.1% of net sales) compared to $8.6 million (7.2% of net sales) in the first nine months of 2016. EBIT increased
in the third quarter and first nine months of 2017 compared to the corresponding periods of 2016 primarily due to the $4.7 million
of restructuring charges incurred in the first nine months of 2016 related to closing the Test business operating facilities in
Germany and England, consisting mainly of employee severance and compensation benefits, professional fees, and asset impairment
charges.

[0001144204-17-041277:mdna:37]
|  |  | 15 |

[0001144204-17-041277:mdna:38]
[same as prior period, unchanged from 0001144204-17-025448:mdna:39]

[0001144204-17-041277:mdna:39]
EBIT in the third quarter of 2017 was $8.5 million (20.2% of
net sales) compared to $6.1 million (21.0% of net sales) in the third quarter of 20

[0001144204-17-041277:mdna:40]
|  |  | 16 |

[0001144204-17-041277:mdna:41]
. In the first nine months of 20

[0001144204-17-041277:mdna:42]
|  |  | 17 |

[0001144204-17-041277:mdna:43]
, EBIT
was $25.6 million (23.2% of net sales) compared to EBIT of $21.6 million (23.0% of net sales) in the first nine months of 2016.
The increase in EBIT in the third quarter and first nine months of 2017 compared to the corresponding periods of 2016 was mainly
due to higher sales volumes and additional contribution from new products and software solutions, as well as the EBIT contribution
from NRG (May 8, 2017 acquisition) and Morgan Schaffer (May 25, 2017 acquisition). EBIT as a percent of net sales decreased in
the third quarter compared to the third quarter of 2016 mainly due to the purchase accounting inventory step-up charges at NRG
and Morgan Schafer totaling $0.7 million in the third quarter of 2017. EBIT as a percent of net sales increased in the first nine
months of 2017 compared to the first nine months of 2016 mainly due to the increase in margins on new products and software solutions
at Doble.

[0001144204-17-041277:mdna:44]
[same as prior period, unchanged from 0001144204-17-025448:mdna:45]

[0001144204-17-041277:mdna:45]
EBIT in the third quarter of 2017 was $2.4 million (11.9% of
net sales) compared to $2.5 million (12.1% of net sales) in the third quarter of 2016. In the first nine months of 2017, EBIT was
$5.7 million (9.5% of net sales) compared to $7.0 million (13.3% of net sales) in the first nine months of 2016. The decrease in
EBIT in the third quarter and first nine months of 2017 compared to the corresponding periods of 2016 was mainly due to higher
SG&A expense at Plastique.

[0001144204-17-041277:mdna:46]
[same as prior period, unchanged from 0001144204-17-025448:mdna:47]

[0001144204-17-041277:mdna:47]
Corporate costs included in EBIT were $9.1 million and $23.5
million in the third quarter and first nine months of 2017, respectively, compared to $6.7 million and $21.7 million in the corresponding
periods of 2016. The increase in Corporate costs in the third quarter and first nine months of 2017 compared to the corresponding
periods of 2016 was primarily due to higher acquisition costs, including professional fees, and an increase in amortization of
intangible assets related to the recent acquisitions.

[0001144204-17-041277:mdna:48]
[same as prior period, unchanged from 0001144204-17-025448:mdna:49]

[0001144204-17-041277:mdna:49]
Interest expense was $1.2 million and $2.8 million in the third
quarter and first nine months of 2017, respectively, and $0.3 million and $0.9 million in the corresponding periods of 2016. The
increase in interest expense in the third quarter and first nine months of 2017 compared to the corresponding periods of 2016 was
mainly due to higher outstanding borrowings during the current year as a result of the Company’s recent acquisitions (Morgan
Schaffer, NRG, Mayday and Westland).

[0001144204-17-041277:mdna:50]
[same as prior period, unchanged from 0001144204-17-025448:mdna:51]

[0001144204-17-041277:mdna:51]
The third quarter 2017 effective income tax rate was 27.4% compared
to 34.2% in the third quarter of 2016. The effective income tax rate for the first nine months of 2017 was 31.4% compared to 34.3%
for the first nine months of 2016. The Company elected to early adopt Accounting Standards Update No. 2016-09, Improvements
to Employee Share-Based Payment Accounting, resulting in the income tax expense in the third quarter and first nine months
of 2017 being favorably impacted by additional tax benefits on share-based compensation that vested during the quarter decreasing
the effective tax rate by 5.1% and 1.8%, respectively.

[0001144204-17-041277:mdna:52]
The income tax expense in the first nine months of 2016 was
unfavorably impacted by a U.K. foreign valuation allowance that increased the year-to-date effective tax rate by1.5%. The income
tax expense in the third quarter and first nine months of 2016 was favorably impacted by the extension of the research credit
as a result of The Protecting Americans from Tax Hikes Act reducing the year-to-date effective tax rate by 1.8%. The income tax
expense in the third quarter and first nine months of 2016 was unfavorably impacted by return to provision true-ups increasing
the third quarter and year-to-date effective tax rate by 1.3% and 0.5%, respectively. The income tax expense in the first nine
months of 2016 was unfavorably impacted by losses in foreign jurisdictions for which no tax benefit was recorded, increasing the
year-to-date effective tax rate by 1.7%.

[0001144204-17-041277:mdna:53]
The Company estimates the fiscal 2017 effective tax rate will
be approximately 33%. During the three-month period ended June 30, 2017, there were no material changes in the unrecognized tax
benefits. The Company does not anticipate a material change in the amount of unrecognized tax benefits in the next twelve months.

[0001144204-17-041277:mdna:54]
The Company’s foreign subsidiaries had accumulated unremitted
earnings of $50.4 million and cash of $38.2 million at June 30, 2017. No deferred taxes have been provided on the accumulated unremitted
earnings because these funds are not needed to meet the liquidity requirements of the Company’s U.S. operations and it is
the Company’s intention to reinvest these earnings indefinitely. In the event these foreign entities’ earnings were
distributed, it is estimated that U.S. taxes, net of available foreign tax credits, of approximately $8.8 million would be due,
which would correspondingly reduce the Company’s net earnings.

[0001144204-17-041277:mdna:55]
[same as prior period, unchanged from 0001144204-17-025448:mdna:56]

[0001144204-17-041277:mdna:56]
[same as prior period, unchanged from 0001144204-17-025448:mdna:57]

[0001144204-17-041277:mdna:57]
The Company’s overall financial position and liquidity
remains strong. Working capital (current assets less current liabilities) increased to $205.0 million at June 30, 2017 from $165.4
million at September 30, 2016. Inventories increased by $25.3 million during this period mainly due to a $12.6 million increase
within the Filtration segment primarily related to the acquisition of Mayday in the first quarter of 2017 and a $9.5 million increase
within the USG segment related to the acquisitions of NRG and Morgan Schaffer. Accounts receivable increased $14.1 million mainly
related to the acquisitions of Mayday, NRG and Morgan Schaffer. Costs and estimated earnings in excess of billings on long-term
contracts increased $16.0 million in the first nine months of 2017 due to ETS ($9.9 million) and VACCO ($6.1 million).

[0001144204-17-041277:mdna:58]
Net cash provided by operating activities was $33.5 million
and $33.2 million in the first nine months of 2017 and 2016, respectively. The increase in net cash provided by operating activities
in the first nine months of 2017 as compared to the first nine months of 2016 was mainly due to higher net earnings.

[0001144204-17-041277:mdna:59]
Capital expenditures were $23.1 million and $7.8 million in
the first nine months of 2017 and 2016, respectively. The increase in the first nine months of 2017 was mainly due to an increase
in machinery and equipment additions at Plastique ($4.8 million) and VACCO ($3.2 million). In addition, the Company incurred expenditures
for capitalized software of $6.2 million and $6.3 million in the first nine months of 2017 and 2016, respectively.

[0001144204-17-041277:mdna:60]
Credit Facility

[0001144204-17-041277:mdna:61]
At June 30, 2017, the Company had approximately $178 million
available to borrow under its Credit Facility, a $250 million increase option, and $48.5 million cash on hand. At June 30, 2017,
the Company had $265.0 million of outstanding borrowings under the Credit Facility in addition to outstanding letters of credit
of $7.2 million. Cash flow from operations and borrowings under the Company’s Credit Facility are expected to meet the Company’s
capital requirements and operational needs for the foreseeable future. The Company’s ability to access the additional $250
million increase option of the facility is subject to acceptance by participating or other outside banks.

[0001144204-17-041277:mdna:62]
Acquisitions

[0001144204-17-041277:mdna:63]
On May 25, 2017, the Company acquired the assets of Morgan Schaffer,
located in Montreal, Quebec, Canada, for a purchase price of $48.8 million in cash. Since the date of acquisition the consolidated
operating results for Morgan Schaffer have been included in the Company’s USG segment.

[0001144204-17-041277:mdna:64]
On May 8, 2017, the Company acquired NRG, located in Hinesburg,
Vermont, for a purchase price of $38.6 million, less cash acquired. Since the date of acquisition the consolidated operating results
for NRG have been included in the Company’s USG segment.

[0001144204-17-041277:mdna:65]
[same as prior period, unchanged from 0001144204-17-025448:mdna:66]

[0001144204-17-041277:mdna:66]
New Accounting Standards

[0001144204-17-041277:mdna:67]
In March 2016, the FASB issued Accounting Standards Update (ASU)
No. 2016-09, Improvements to Employee Share-Based Payment Accounting, which simplified the income tax consequences, accounting
for forfeitures and classification on the Statements of Consolidated Cash Flows. The Company adopted this standard in the current
year resulting in the income tax expense in the third quarter and first nine months of 2017 being favorably impacted by additional
tax benefits on share-based compensation that vested during the third quarter of 2017, decreasing the effective tax rate by 5.1%
and 1.8%, respectively.

[0001144204-17-041277:mdna:68]
In February 2016, the FASB issued ASU No. 2016-062, Leases
(Topic 842), which, among other things, requires an entity to recognize lease assets and lease liabilities on the balance sheet
and disclose key information about leasing arrangements. This standard will increase an entities’ reported assets and liabilities.
The standard is effective for fiscal years beginning after December 15, 20

[0001144204-17-041277:mdna:69]
|  |  | 18 |

[0001144204-17-041277:mdna:70]
and mandates a modified retrospective transition period
for all entities. The Company is currently assessing the impact of this standard on its consolidated financial statements and related
disclosures.

[0001144204-17-041277:mdna:71]
In May 2014, the FASB issued ASU No. 2014-09, Revenue from
Contracts with Customers, which requires an entity to recognize the amount of revenue to which it expects to be entitled for
the transfer of promised goods or services to customers. This guidance has been further clarified and amended. The new standard
will be effective for annual reporting periods beginning after December 15, 2017, and interim periods within those annual periods.
The standard permits the use of either the retrospective or cumulative effect transition method. The Company is currently in the
process of evaluating the effect that ASU 2014-09 will have on its consolidated financial statements and related disclosures and
selecting the method of transition to the new standard.

[0001144204-17-041277:mdna:72]
[same as prior period, unchanged from 0001144204-17-025448:mdna:67]

[0001144204-17-041277:mdna:73]
A dividend of $0.08 per share, totaling $2.1 million, was paid
on April 18, 2017 to stockholders of record as of April 3, 2017. Following the end of the third quarter, the quarterly dividend
of $0.08 per share, or $2.1 million, was paid on July

[0001144204-17-041277:mdna:74]
|  |  | 19 |

[0001144204-17-041277:mdna:75]
, 2017 to stockholders of record as of July 5, 2017.

[0001144204-17-041277:mdna:76]
[same as prior period, unchanged from 0001144204-17-025448:mdna:73]

[0001144204-17-041277:mdna:77]
Given the 2017 financial contributions from the Westland, Mayday,
NRG and Morgan Schaffer acquisitions, as well as the significant costs incurred in the execution of these acquisitions, and considering
both operational and non-cash purchase accounting items, the current outlook for 2017 compared to the original guidance is updated
as follows: Management projects 2017 GAAP EPS to be in the range of $2.05 to $2.10 per share, reflecting the profit contributions
from the recent acquisitions, offset by the costs of the acquisitions, the impact of the purchase accounting inventory step-up
charges, the impact of additional depreciation and amortization, and customer-driven program pushouts from 2017 to 2018.

[0001144204-17-041277:mdna:78]
[same as prior period, unchanged from 0001144204-17-025448:mdna:77]

[0001144204-17-041277:mdna:79]
[same as prior period, unchanged from 0001144204-17-025448:mdna:78]

[0001144204-17-041277:mdna:80]
[same as prior period, unchanged from 0001144204-17-025448:mdna:79]

[0001144204-17-041277:mdna:81]
[same as prior period, unchanged from 0001144204-17-025448:mdna:80]

[0001144204-17-041277:mdna:82]
Contingencies

[0001144204-17-041277:mdna:83]
As a normal incident of the business in which the Company is
engaged, various claims, charges and litigation are asserted or commenced against the Company. Additionally, the Company is currently
involved in various stages of investigation and remediation relating to environmental matters. In the opinion of Management, the
aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company,
are adequately reserved, are covered by insurance, or would not have a material adverse effect on the Company’s results from
operations, capital expenditures, or competitive position.

[0001144204-17-041277:mdna:84]
[same as prior period, unchanged from 0001144204-17-025448:mdna:83]

[0001144204-17-041277:mdna:85]
Investors are cautioned that such statements are only predictions
and speak only as of the date of this Form 10-Q, and the Company undertakes no duty to update them except as may be required by
applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in
the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment,
including but not limited to those described in Item 1A, “Risk Factors,” of the Company’s Annual Report on Form
10-K for the fiscal year ended September 30, 2016, and the following: the impacts of natural disasters on the Company’s operations
and those of the Company’s customers and suppliers; the timing and content of future contract awards or customer orders;
the appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer
contracts or orders; financial exposure in connection with Company guarantees of certain Aclara contracts; weakening of economic
conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies;
competition; intellectual property rights; technical difficulties; the availability of select acquisitions; delivery delays or
defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability
of certain raw materials; labor disputes; changes in laws and regulations including but not limited to changes in accounting standards
and taxation requirements; changes in interest rates; costs relating to environmental matters arising from current or former facilities;
uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the integration of recently
acquired businesses.
