# ESE notes — 0001144204-17-041277


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001144204-17-041277:notes:1]
[same as prior period, unchanged from 0001144204-17-025448:notes:1]

[0001144204-17-041277:notes:2]
[same as prior period, unchanged from 0001144204-17-025448:notes:2]

[0001144204-17-041277:notes:3]
The Company’s results for the three and nine-month periods ended June 30, 2017 are not necessarily indicative of the results for the entire 2017 fiscal year. References to the third quarters of 2017 and 2016 represent the fiscal quarters ended June 30, 2017 and 2016, respectively.

[0001144204-17-041277:notes:4]
[same as prior period, unchanged from 0001144204-17-025448:notes:4]


## us-gaap:ScheduleOfDerivativeLiabilitiesAtFairValueTableTextBlock

[0001144204-17-041277:notes:5]
The Company’s forward contracts are classified within Level 2 of the valuation hierarchy in accordance with FASB Accounting Standards Codification (ASC) 825, as presented below as of June 30, 2017:

[0001144204-17-041277:notes:6]
| (In thousands) |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Forward contracts |  | $ | - |  |  | (188) |  | $ | - |  |  | (188) |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001144204-17-041277:notes:7]
|  | 2. | ACQUISITIONS |

[0001144204-17-041277:notes:8]
On May 25, 2017, the Company acquired the assets of Morgan Schaffer Inc. (Morgan Schaffer), a global utilities provider located in Montreal, Quebec, Canada, for a purchase price of $48.8 million in cash. Morgan Schaffer, founded in 1965, has annualized sales of approximately $25 million. Morgan Schaffer designs, develops, manufactures and markets an integrated offering of dissolved gas analysis, oil testing, and data management solutions which enhance the ability of electric utilities to accurately monitor the health of critical power transformers. Since the date of acquisition, the operating results for Morgan Schaffer have been included in the Company’s Utilities Solution Group (USG) segment. Based on the preliminary purchase price allocation, the Company recorded approximately $2.5 million of accounts receivable, $5.2 million of inventory, $1.7 million of property, plant and equipment, $0.4 million of other assets, $3.8 million of accounts payable and accrued expenses, $4.8 million of goodwill, $34.6 million of trade names and $3.4 million of amortizable intangible assets consisting of customer relationships and developed technology with a weighted average life of approximately 10 years.

[0001144204-17-041277:notes:9]
On May 8, 2017, the Company acquired NRG Systems, Inc. (NRG), doing business as Renewable NRG Systems, located in Hinesburg, Vermont, for a purchase price of $38.6 million, less cash acquired. NRG, founded in 1982, is the global market leader in the design and manufacture of decision support tools for the renewable energy industry, primarily wind. NRG has annualized sales of approximately $45 million. Since the date of acquisition, the operating results for NRG have been included in the Company’s USG segment. Based on the preliminary purchase price allocation, the Company recorded approximately $1.5 million of cash, $4.1 million of accounts receivable, $5.1 million of inventory, $1.0 million of other assets, $9.4 million of property, plant and equipment (including a capital lease), $4.1 million of accounts payable and accrued expenses, $9.7 million of lease liability, $7.5 million of goodwill, $8.1 million of trade names and $17.2 million of amortizable intangible assets consisting of customer relationships with a weighted average life of approximately  14 years.

[0001144204-17-041277:notes:10]
On November 7, 2016, the Company acquired aerospace suppliers Mayday Manufacturing Co. and its affiliate, Hi-Tech Metals, Inc. (collectively referred to as Mayday), which share a  130,000 square foot facility in Denton, Texas, for a purchase price of $75 million in cash.  Mayday Manufacturing Co. is a manufacturer of mission-critical bushings, pins, sleeves and precision-tolerance machined components for landing gear, rotor heads, engine mounts, flight controls, and actuation systems for the aerospace and defense industry.  Hi-Tech Metals, Inc. is a full-service metal processor offering aerospace OEM’s, Tier 1 suppliers, a large portfolio of processing services including anodizing, cadmium and zinc-nickel plating, organic coatings, non-destructive testing, and heat treatment.  Mayday has annual sales of approximately $40 million. Since the date of acquisition the consolidated operating results for Mayday have been included in the Company’s Filtration segment.  Based on the preliminary purchase price allocation, the Company recorded approximately $7.4 million of accounts receivable, $11.0 million of inventory, $16.6 million of property, plant and equipment (including a capital lease), $9.5 million of lease liability, $15.7 million of deferred tax liabilities, $30.1 million of goodwill (non-deductible for tax purposes), $4.8 million of trade names and $32.8 million of amortizable identifiable intangible assets consisting primarily of customer relationships with a weighted-average life of approximately 20 years.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001144204-17-041277:notes:11]
|  | 12. | DERIVATIVE FINANCIAL INSTRUMENTS |

[0001144204-17-041277:notes:12]
Market risks relating to the Company’s operations result primarily from changes in interest rates and changes in foreign currency exchange rates. The Company is exposed to market risk related to changes in interest rates and selectively uses derivative financial instruments, including forward contracts and swaps, to manage these risks. During 2016, the Company entered into several forward contracts to purchase pounds sterling (GBP) to hedge two deferred payments due in connection with the acquisition of Plastique. In addition, our Canadian subsidiary Morgan Schaffer enters into foreign exchange contracts to manage foreign currency risk as a portion of their revenue is denominated in U.S. dollars. The Company expects hedging gains or losses to be essentially offset by losses or gains on the related underlying exposures. All derivative instruments are reported in either accrued expenses or other receivables on the balance sheet at fair value. For derivative instruments designated as cash flow hedges, the gain or loss on the derivative is deferred in accumulated other comprehensive income until recognized in earnings with the underlying hedged item.

[0001144204-17-041277:notes:13]
The following is a summary of the notional transaction amounts and fair values for the Company’s outstanding derivative financial instruments by risk category and instrument type as of June 30, 2017:

[0001144204-17-041277:notes:14]
|  |  |  |  |  | Fair |  |
|  |  | Notional |  |  | Value |  |
| (In thousands) |  | amount |  |  | (US$) |  |
| Forward contracts |  |  | 1,859 | GBP |  |  | (238) |  |
| Forward contracts |  |  | 4,750 | USD |  |  | 64 |  |
| Forward contracts |  |  | 500 | EUR |  |  | (14) |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001144204-17-041277:notes:15]
[same as prior period, unchanged from 0001144204-17-025448:notes:64]

[0001144204-17-041277:notes:16]
A summary of net periodic benefit expense for the Company’s defined benefit plans for the three and nine-month periods ended June 30, 2017 and 2016 is shown in the following table. Net periodic benefit cost for each period presented is comprised of the following:

[0001144204-17-041277:notes:17]
|  |  | Three Months |  | Nine Months |  |
|  |  | Ended June 30, |  | Ended June 30, |  |
| (In thousands) |  | 2017 |  | 2016 |  | 2017 |  | 2016 |  |
| Defined benefit plans |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest cost |  | $ | 737 |  |  | 963 |  |  | 2,438 |  |  | 2,888 |  |
| Expected return on assets |  |  | (942) |  |  | (1,093) |  |  | (2,978) |  |  | (3,280) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior service cost |  |  | - |  |  | 3 |  |  | 3 |  |  | 10 |  |
| Actuarial loss |  |  | 683 |  |  | 486 |  |  | 1,871 |  |  | 1,459 |  |
| Net periodic benefit cost |  | $ | 478 |  |  | 359 |  |  | 1,334 |  |  | 1,077 |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0001144204-17-041277:notes:18]
The change in shareholders’ equity for the first nine months of 2017 is shown below (in thousands):

[0001144204-17-041277:notes:19]
| Balance at September 30, 2016 |  | $ | 615,109 |  |
| Net earnings |  |  | 34,529 |  |
| Other comprehensive income |  |  | 2,958 |  |
| Cash dividends |  |  | (6,190) |  |
| Stock compensation plans |  |  | (1,817) |  |
| Balance at June 30, 2017 |  | $ | 644,589 |  |


## us-gaap:ScheduleOfWeightedAverageNumberOfSharesTableTextBlock

[0001144204-17-041277:notes:20]
The number of shares used in the calculation of earnings per share for each period presented is as follows (in thousands):

[0001144204-17-041277:notes:21]
|  |  | Three Months |  | Nine Months |  |
|  |  | Ended June 30, |  | Ended June 30, |  |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |  |
| Weighted Average Shares Outstanding - Basic |  |  | 25,815 |  |  | 25,725 |  |  | 25,756 |  |  | 25,777 |  |
| Dilutive Options and Restricted Shares |  |  | 210 |  |  | 185 |  |  | 219 |  |  | 185 |  |
| Adjusted Shares - Diluted |  |  | 26,025 |  |  | 25,910 |  |  | 25,975 |  |  | 25,962 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001144204-17-041277:notes:22]
|  | 4. | SHARE-BASED COMPENSATION |

[0001144204-17-041277:notes:23]
[same as prior period, unchanged from 0001144204-17-025448:notes:58]

[0001144204-17-041277:notes:24]
[same as prior period, unchanged from 0001144204-17-025448:notes:59]

[0001144204-17-041277:notes:25]
Compensation expense related to the restricted share awards was $1.0 million and $3.3 million for the three and nine-month periods ended June 30, 2017, respectively, and $0.8 million and $3.1 million for the corresponding periods of 2016. There were  335,825 non-vested shares outstanding as of June 30, 2017.

[0001144204-17-041277:notes:26]
[same as prior period, unchanged from 0001144204-17-025448:notes:61]

[0001144204-17-041277:notes:27]
Compensation expense related to the non-employee director grants was $0.3 million and $0.8 million for the three and nine-month periods ended June 30, 2017, respectively, and $0.2 million and $0.6 million for the corresponding periods of 2016.

[0001144204-17-041277:notes:28]
The total share-based compensation cost that has been recognized in the results of operations and included within selling, general and administrative expenses (SG&A) was $1.3 million and $4.1 million for the three-and nine-month periods ended June 30, 2017, respectively, and $1.0 million and $3.7 million for the corresponding periods of 2016. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $1.2 million and $2.2 million for the three and nine-month periods ended June 30, 2017, respectively, and $0.4 million and $1.3 million for the corresponding periods of 2016, respectively. As of June 30, 2017, there was $7.3 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a remaining weighted-average period of  1.8 years.


## us-gaap:InventoryDisclosureTextBlock

[0001144204-17-041277:notes:29]
|  | 5. | INVENTORIES |

[0001144204-17-041277:notes:30]
Inventories consist of the following:

[0001144204-17-041277:notes:31]
|  |  | June 30, |  | September 30, |  |
| (In thousands) |  | 2017 |  | 2016 |  |
| Finished goods |  | $ | 28,559 |  |  | 19,451 |  |
| Work in process |  |  | 46,178 |  |  | 37,922 |  |
| Raw materials |  |  | 56,091 |  |  | 48,169 |  |
| Total inventories |  | $ | 130,828 |  |  | 105,542 |  |


## us-gaap:ScheduleOfIntangibleAssetsAndGoodwillTableTextBlock

[0001144204-17-041277:notes:32]
Included on the Company’s Consolidated Balance Sheets at June 30, 2017 and September 30, 2016 are the following intangible assets gross carrying amounts and accumulated amortization:

[0001144204-17-041277:notes:33]
| (Dollars in thousands) |  | June 30, 2017 |  | September 30, 2016 |  |
| Goodwill |  | $ | 365,965 |  |  | 323,616 |  |
| Intangible assets with determinable lives: |  |  |  |  |  |  |  |
| Patents |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 927 |  |  | 917 |  |
| Less: accumulated amortization |  |  | 742 |  |  | 726 |  |
| Net |  | $ | 185 |  |  | 191 |  |
| Capitalized software |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 60,216 |  |  | 54,003 |  |
| Less: accumulated amortization |  |  | 32,136 |  |  | 26,737 |  |
| Net |  | $ | 28,080 |  |  | 27,266 |  |
| Customer relationships |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 163,331 |  |  | 111,887 |  |
| Less: accumulated amortization |  |  | 35,005 |  |  | 28,633 |  |
| Net |  | $ | 128,325 |  |  | 83,254 |  |
| Other |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 5,255 |  |  | 2,777 |  |
| Less: accumulated amortization |  |  | 1,220 |  |  | 859 |  |
| Net |  | $ | 4,035 |  |  | 1,918 |  |
| Intangible assets with indefinite lives: |  |  |  |  |  |  |  |
| Trade names |  | $ | 167,920 |  |  | 119,128 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0001144204-17-041277:notes:34]
The changes in the carrying amount of goodwill attributable to each business segment for the nine months ended June 30, 2017 is as follows:

[0001144204-17-041277:notes:35]
| (Dollars in millions) |  | USG |  | Test |  | Filtration |  | Packaging |  | Total |  |
| Balance as of September 30, 2016 |  |  | 226.2 |  |  | 34.1 |  |  | 43.9 |  |  | 19.4 |  |  | 323.6 |  |
| Acquisition activity |  |  | 12.3 |  |  | - |  |  | 30.1 |  |  | - |  |  | 42.4 |  |
| Foreign currency translation and other |  |  | 0.2 |  |  | - |  |  | (0.5) |  |  | 0.3 |  |  | - |  |
| Balance as of June 30, 2017 |  | $ | 238.7 |  |  | 34.1 |  |  | 73.5 |  |  | 19.7 |  |  | 366.0 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001144204-17-041277:notes:36]
|  | 6. | GOODWILL AND OTHER INTANGIBLE ASSETS |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001144204-17-041277:notes:37]
[same as prior period, unchanged from 0001144204-17-025448:notes:52]

[0001144204-17-041277:notes:38]
The Company is organized based on the products and services that it offers, and classifies its business operations in four segments for financial reporting purposes: Filtration/Fluid Flow (Filtration), RF Shielding and Test (Test), Utility Solutions Group (USG) and Technical Packaging. The Filtration segment’s operations consist of PTI Technologies Inc. (PTI), VACCO Industries (VACCO), Crissair, Inc. (Crissair), Westland Technologies Inc. (Westland), and Mayday. The companies within this segment primarily design and manufacture specialty filtration products, including hydraulic filter elements used in commercial aerospace applications, unique filter mechanisms used in micro-propulsion devices for satellites and custom designed filters for manned and unmanned aircraft; manufacture elastomeric-based signature reduction solutions for the U.S. Navy; and manufacture landing gear components for the aerospace and defense industry. The Test segment’s operations consist primarily of ETS-Lindgren Inc. (ETS-Lindgren). ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy. The USG segment’s operations consist primarily of Doble Engineering Company (Doble), Morgan Schaffer, and NRG. Doble provides high-end, intelligent diagnostic test solutions for the electric power delivery industry and is a leading supplier of partial discharge testing instruments used to assess the integrity of high voltage power delivery equipment. Morgan Schaffer provides an integrated offering of dissolved gas analysis, oil testing, and data management solutions for the electric power industry. NRG designs and manufactures decision support tools for the renewable energy industry, primarily wind. The Technical Packaging segment’s operations consist of Thermoform Engineered Quality LLC (TEQ) and Plastique Limited and Plastique Sp. zoo (together, Plastique). The companies within this segment provide innovative solutions to the medical and commercial markets for thermoformed packages and specialty products using a wide variety of thin gauge plastics and pulp.

[0001144204-17-041277:notes:39]
Management evaluates and measures the performance of its reportable segments based on “Net Sales” and “EBIT”, which are detailed in the table below. EBIT is defined as earnings before interest and taxes.

[0001144204-17-041277:notes:40]
|  |  | Three Months |  | Nine Months |  |
| (In thousands) |  | Ended June 30, |  | Ended June 30, |  |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |  |
| NET SALES |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 71,179 |  |  | 54,396 |  |  | 198,869 |  |  | 145,758 |  |
| Test |  |  | 37,544 |  |  | 36,234 |  |  | 109,738 |  |  | 119,608 |  |
| USG |  |  | 42,059 |  |  | 29,121 |  |  | 110,287 |  |  | 93,657 |  |
| Technical Packaging |  |  | 20,407 |  |  | 20,440 |  |  | 59,841 |  |  | 52,931 |  |
| Consolidated totals |  | $ | 171,189 |  |  | 140,191 |  |  | 478,735 |  |  | 411,954 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 11,945 |  |  | 12,163 |  |  | 34,296 |  |  | 29,511 |  |
| Test |  |  | 4,885 |  |  | 3,744 |  |  | 11,076 |  |  | 8,587 |  |
| USG |  |  | 8,477 |  |  | 6,124 |  |  | 25,585 |  |  | 21,581 |  |
| Technical Packaging |  |  | 2,433 |  |  | 2,474 |  |  | 5,660 |  |  | 7,035 |  |
| Corporate (loss) |  |  | (9,105) |  |  | (6,665) |  |  | (23,499) |  |  | (21,694) |  |
| Consolidated EBIT |  |  | 18,635 |  |  | 17,840 |  |  | 53,118 |  |  | 45,020 |  |
| Less: Interest expense, net |  |  | (1,213) |  |  | (320) |  |  | (2,752) |  |  | (917) |  |
| Earnings before income taxes |  | $ | 17,422 |  |  | 17,520 |  |  | 50,366 |  |  | 44,103 |  |

[0001144204-17-041277:notes:41]
[same as prior period, unchanged from 0001144204-17-025448:notes:54]

[0001144204-17-041277:notes:42]
[same as prior period, unchanged from 0001144204-17-025448:notes:55]

[0001144204-17-041277:notes:43]
[same as prior period, unchanged from 0001144204-17-025448:notes:56]


## us-gaap:ScheduleOfDebtTableTextBlock

[0001144204-17-041277:notes:44]
The Company’s debt is summarized as follows:

[0001144204-17-041277:notes:45]
|  |  | June 30, |  | September 30, |  |
| (In thousands) |  | 2017 |  | 2016 |  |
| Total borrowings |  | $ | 265,000 |  |  | 110,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 245,000 |  |  | 90,000 |  |


## us-gaap:DebtDisclosureTextBlock

[0001144204-17-041277:notes:46]
|  | 8. | DEBT |

[0001144204-17-041277:notes:47]
The Company’s existing credit facility (“the Credit Facility”) matures December 21, 2020. The Credit Facility includes a $450 million revolving line of credit as well as provisions allowing for the increase of the facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of nine banks led by JPMorgan Chase Bank, N.A., as Administrative Agent.

[0001144204-17-041277:notes:48]
At June 30, 2017, the Company had approximately $178 million available to borrow under the Credit Facility, and a $250 million increase option, in addition to $48.5 million cash on hand. At June 30, 2017, the Company had $265 million of outstanding borrowings under the Credit Facility in addition to outstanding letters of credit of $7.2 million. The Company classified $20.0 million as the current portion of long-term debt as of June 30, 2017, as the Company intends to repay this amount within the next twelve month period; however, the Company has no contractual obligation to repay such amount during the next twelve month period.

[0001144204-17-041277:notes:49]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from  12.5 to  27.5 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a  65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were  2.11% and  1.90% for the three and nine-month periods ending June 30, 2017, respectively, and  1.50% and  1.58% for the corresponding periods of 2016. At June 30, 2017, the Company was in compliance with all debt covenants.


## us-gaap:EarningsPerShareTextBlock

[0001144204-17-041277:notes:50]
|  | 3. | EARNINGS PER SHARE (EPS) |

[0001144204-17-041277:notes:51]
[same as prior period, unchanged from 0001144204-17-025448:notes:8]


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001144204-17-041277:notes:52]
|  | 10. | SHAREHOLDERS’ EQUITY |


## us-gaap:FairValueDisclosuresTextBlock

[0001144204-17-041277:notes:53]
|  | 13. | FAIR VALUE MEASUREMENTS |

[0001144204-17-041277:notes:54]
[same as prior period, unchanged from 0001144204-17-025448:notes:42]

[0001144204-17-041277:notes:55]
|  | · | Level 1 – inputs to the valuation methodology are quoted prices (unadjusted) for identical assets or liabilities in active markets. |
|  | · | Level 2 – inputs to the valuation methodology include quoted prices for similar assets and liabilities in active markets, and inputs that are observable for the asset or liability, either directly or indirectly, for substantially the full term of the financial instrument. |
|  | · | Level 3 – inputs to the valuation methodology are unobservable and significant to the fair value measurement. |

[0001144204-17-041277:notes:56]
[same as prior period, unchanged from 0001144204-17-025448:notes:46]

[0001144204-17-041277:notes:57]
The Company has estimated the fair value of its financial instruments as of June 30, 2017 and September 30, 2016 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, debt and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001144204-17-041277:notes:58]
[same as prior period, unchanged from 0001144204-17-025448:notes:48]

[0001144204-17-041277:notes:59]
[same as prior period, unchanged from 0001144204-17-025448:notes:49]

[0001144204-17-041277:notes:60]
[same as prior period, unchanged from 0001144204-17-025448:notes:50]

[0001144204-17-041277:notes:61]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during the three and nine-month periods ended June 30, 2017.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001144204-17-041277:notes:62]
|  | 14. | NEW ACCOUNTING STANDARDS |

[0001144204-17-041277:notes:63]
In March 2016, the FASB issued Accounting Standards Update (ASU) No. 2016-09, Improvements to Employee Share-Based Payment Accounting, which simplified the income tax consequences, accounting for forfeitures and classification on the Statements of Consolidated Cash Flows. The Company adopted this standard in the current year resulting in the income tax expense in the third quarter and first nine months of 2017 being favorably impacted by additional tax benefits on share-based compensation that vested during the third quarter of 2017 decreasing the effective tax rate by  5.1% and  1.8%, respectively.

[0001144204-17-041277:notes:64]
In February 2016, the FASB issued ASU No. 2016-062, Leases (Topic 842), which, among other things, requires an entity to recognize lease assets and lease liabilities on the balance sheet and disclose key information about leasing arrangements. This standard will increase an entities’ reported assets and liabilities. The standard is effective for fiscal years beginning after December 15, 2018 and mandates a modified retrospective transition period for all entities. The Company is currently assessing the impact of this standard on its consolidated financial statements and related disclosures.

[0001144204-17-041277:notes:65]
In May 2014, the FASB issued ASU No. 2014-09, Revenue from Contracts with Customers, which requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. This guidance has been further clarified and amended. The new standard will be effective for annual reporting periods beginning after December 15, 2017, and interim periods within those annual periods. The standard permits the use of either the retrospective or cumulative effect transition method. The Company is currently in the process of evaluating the effect that ASU 2014-09 will have on its consolidated financial statements and related disclosures and selecting the method of transition to the new standard.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001144204-17-041277:notes:66]
|  | 9. | INCOME TAX EXPENSE |

[0001144204-17-041277:notes:67]
The third quarter 2017 effective income tax rate was  27.4% compared to  34.2% in the third quarter of 2016. The effective income tax rate for the first nine months of 2017 was  31.4% compared to  34.3% for the first nine months of 2016. The Company elected to early adopt Accounting Standards Update No. 2016-09,  Improvements to Employee Share-Based Payment Accounting, resulting in the income tax expense in the third quarter and first nine months of 2017 being favorably impacted by additional tax benefits on share-based compensation that vested during the quarter decreasing the effective tax rate by  5.1% and  1.8%, respectively.

[0001144204-17-041277:notes:68]
The income tax expense in the first nine months of 2016 was unfavorably impacted by a U.K. foreign valuation allowance that increased the year-to-date effective tax rate by1.5%. The income tax expense in the third quarter and first nine months of 2016 was favorably impacted by the extension of the research credit as a result of The Protecting Americans from Tax Hikes Act reducing the year-to-date effective tax rate by  1.8%. The income tax expense in the third quarter and first nine months of 2016 was unfavorably impacted by return to provision true-ups increasing the third quarter and year-to-date effective tax rate by  1.3% and  0.5%, respectively. The income tax expense in the first nine months of 2016 was unfavorably impacted by losses in foreign jurisdictions for which no tax benefit was recorded, increasing the year-to-date effective tax rate by  1.7%.
