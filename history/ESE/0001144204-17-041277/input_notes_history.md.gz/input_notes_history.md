# ESE note change history — 0001144204-17-025448 → 0001144204-17-041277


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-08-08):
[0001144204-17-041277:note_history:1]
The Company’s results for the three and nine-month periods ended June 30, 2017 are not necessarily indicative of the results for the entire 2017 fiscal year. References to the third quarters of 2017 and 2016 represent the fiscal quarters ended June 30, 2017 and 2016, respectively.
  (was, 2017-05-09, similarity 0.9344):
[0001144204-17-025448:note_history:1]
The Company’s results for the three and six-month periods ended March 31, 2017 are not necessarily indicative of the results for the entire 2017 fiscal year. References to the second quarters of 2017 and 2016 represent the fiscal quarters ended March 31, 2017 and 2016, respectively.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-08-08):
[0001144204-17-041277:note_history:2]
|  | 8. | DEBT |
  (was, 2017-05-09, similarity 0.9231):
[0001144204-17-025448:note_history:2]
| 8. | DEBT |

- changed (2017-08-08):
[0001144204-17-041277:note_history:3]
|  |  | June 30, |  | September 30, |  |
| (In thousands) |  | 2017 |  | 2016 |  |
| Total borrowings |  | $ | 265,000 |  |  | 110,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 245,000 |  |  | 90,000 |  |
  (was, 2017-05-09, similarity 0.8583):
[0001144204-17-025448:note_history:3]
|  |  | March 31, | September 30, |  |
| (In thousands) |  | 2017 | 2016 |  |
| Total borrowings |  | $ | 170,000 |  |  | 110,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 150,000 |  |  | 90,000 |  |

- changed (2017-08-08):
[0001144204-17-041277:note_history:4]
The Company’s existing credit facility (“the Credit Facility”) matures December 21, 2020. The Credit Facility includes a $450 million revolving line of credit as well as provisions allowing for the increase of the facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of nine banks led by JPMorgan Chase Bank, N.A., as Administrative Agent.
  (was, 2017-05-09, similarity 0.9537):
[0001144204-17-025448:note_history:4]
The Company’s existing credit facility maturity date is December 21, 2020. The credit facility includes a $450 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of nine banks led by JPMorgan Chase Bank, N.A., as Administrative Agent.

- changed (2017-08-08):
[0001144204-17-041277:note_history:5]
At June 30, 2017, the Company had approximately $178 million available to borrow under the Credit Facility, and a $250 million increase option, in addition to $48.5 million cash on hand. At June 30, 2017, the Company had $265 million of outstanding borrowings under the Credit Facility in addition to outstanding letters of credit of $7.2 million. The Company classified $20.0 million as the current portion of long-term debt as of June 30, 2017, as the Company intends to repay this amount within the next twelve month period; however, the Company has no contractual obligation to repay such amount during the next twelve month period.
  (was, 2017-05-09, similarity 0.9777):
[0001144204-17-025448:note_history:5]
At March 31, 2017, the Company had approximately $276 million available to borrow under the Credit Facility, and a $250 million increase option, in addition to $53.5 million cash on hand. At March 31, 2017, the Company had $170 million of outstanding borrowings under the credit facility in addition to outstanding letters of credit of $4.6 million. The Company classified $20.0 million as the current portion of long-term debt as of March 31, 2017, as the Company intends to repay this amount within the next twelve month period; however, the Company has no contractual obligation to repay such amount during the next twelve month period.

- changed (2017-08-08):
[0001144204-17-041277:note_history:6]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from  12.5 to  27.5 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a  65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were  2.11% and  1.90% for the three and nine-month periods ending June 30, 2017, respectively, and  1.50% and  1.58% for the corresponding periods of 2016. At June 30, 2017, the Company was in compliance with all debt covenants.
  (was, 2017-05-09, similarity 0.9853):
[0001144204-17-025448:note_history:6]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from  12.5 to  27.5 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a  65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were  1.89% and  1.76% for the three and six-month periods ending March 31, 2017, respectively, and  1.76% and  1.61% for the corresponding periods of 2016. At March 31, 2017, the Company was in compliance with all debt covenants.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-08-08):
[0001144204-17-041277:note_history:7]
|  |  | June 30, |  | September 30, |  |
| (In thousands) |  | 2017 |  | 2016 |  |
| Total borrowings |  | $ | 265,000 |  |  | 110,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 245,000 |  |  | 90,000 |  |
  (was, 2017-05-09, similarity 0.8583):
[0001144204-17-025448:note_history:7]
|  |  | March 31, | September 30, |  |
| (In thousands) |  | 2017 | 2016 |  |
| Total borrowings |  | $ | 170,000 |  |  | 110,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 150,000 |  |  | 90,000 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2017-08-08):
[0001144204-17-025448:note_history:8]
| 14. | SUBSEQUENT EVENT |

- removed (2017-08-08):
[0001144204-17-025448:note_history:9]
On May 8, 2017, the Company acquired NRG Systems, Inc. (NRG), doing business as Renewable NRG Systems, located in Hinesburg, Vermont. NRG, founded in 1982, is the global market leader in the design and manufacture of decision support tools for the renewable energy industry, primarily wind. NRG has annualized sales of approximately $45 million and will be included in the Company’s Utilities Solution Group (USG) segment.
