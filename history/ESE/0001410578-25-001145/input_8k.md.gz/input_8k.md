# ESE 8-K — 0001104659-25-045548 filed 2025-05-07

## item codes, every 8-K on or before 2025-05-09

- 2025-05-07 0001104659-25-045548 — 2.02, 7.01, 9.01
- 2025-04-28 0001104659-25-039819 — 2.01, 7.01, 9.01
- 2025-02-06 0001104659-25-010118 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2024-11-14 0001104659-24-118951 — 2.02, 5.02, 7.01, 9.01
- 2024-10-18 0001104659-24-109788 — 5.02
- 2024-10-01 0001104659-24-104776 — 5.02
- 2024-08-07 0001104659-24-086768 — 1.01, 2.02, 5.02, 7.01, 9.01
- 2024-07-08 0001104659-24-078312 — 1.01, 7.01, 9.01
- 2024-05-09 0001104659-24-059341 — 2.02, 7.01, 9.01
- 2024-02-08 0001104659-24-012294 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2023-11-20 0001104659-23-119761 — 5.02, 9.01
- 2023-11-16 0001104659-23-119126 — 2.02, 7.01, 9.01
- 2023-10-03 0001104659-23-106090 — 5.02, 9.01
- 2023-09-06 0001104659-23-098463 — 1.01, 2.03, 9.01
- 2023-08-08 0001104659-23-088847 — 2.02, 7.01, 9.01
- 2023-07-06 0001104659-23-078571 — 5.02, 8.01, 9.01
- 2023-05-09 0001104659-23-057736 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2023-05-05 0001104659-23-056387 — 5.02, 9.01
- 2023-02-08 0001104659-23-014539 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2023-01-06 0001104659-23-001859 — 5.02, 9.01
- 2022-11-22 0001104659-22-121229 — 5.02, 5.03, 8.01, 9.01
- 2022-11-17 0001104659-22-119898 — 2.02, 7.01, 9.01
- 2022-09-12 0001104659-22-099248 — 5.02, 7.01, 9.01
- 2022-08-08 0001104659-22-087247 — 2.02, 5.02, 7.01, 9.01
- 2022-05-09 0001104659-22-057524 — 2.02, 5.02, 7.01, 9.01
- 2022-02-08 0001104659-22-013878 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2021-12-03 0001104659-21-146361 — 4.01, 9.01 — amendment, the index does not say of what
- 2021-11-24 0001104659-21-143568 — 4.01, 9.01
- 2021-11-23 0001104659-21-142871 — 5.02, 8.01
- 2021-11-18 0001104659-21-141206 — 2.02, 7.01, 9.01
- 2021-08-09 0001104659-21-102150 — 2.02, 7.01, 9.01
- 2021-05-04 0001104659-21-060985 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2021-04-05 0001104659-21-046581 — 5.02, 9.01
- 2021-02-08 0001104659-21-013712 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2020-12-09 0001104659-20-133674 — 5.02, 9.01
- 2020-12-07 0001104659-20-132861 — 5.02, 7.01, 9.01
- 2020-11-19 0001104659-20-127352 — 2.02, 5.02, 7.01, 9.01
- 2020-08-10 0001104659-20-092734 — 2.02, 7.01, 9.01
- 2020-05-06 0001104659-20-057442 — 2.02, 7.01, 8.01, 9.01
- 2020-02-04 0001104659-20-010640 — 2.02, 5.07, 7.01, 9.01
- 2020-01-07 0001104659-20-001789 — 2.01, 9.01
- 2019-11-19 0001104659-19-065437 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2019-11-18 0001104659-19-065096 — 1.01, 2.02, 7.01, 9.01
- 2019-09-30 0001144204-19-046523 — 1.01, 1.02, 2.03, 9.01
- 2019-08-08 0001144204-19-038567 — 2.02, 7.01, 9.01
- 2019-05-07 0001144204-19-024241 — 2.02, 5.02, 7.01, 9.01
- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2025-05-09

- none on or before 2025-05-09

## item 2.02 — earnings release, exhibit 99.1

[0001104659-25-045548:8k_2_02:1]
EX-99.1
2
tm2514315d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-25-045548:8k_2_02:2]
Exhibit 99.1

[0001104659-25-045548:8k_2_02:3]
| NEWS FROM |  |

[0001104659-25-045548:8k_2_02:4]
For more information contact:

[0001104659-25-045548:8k_2_02:5]
Kate Lowrey - VP of Investor Relations

[0001104659-25-045548:8k_2_02:6]
(314) 213-7277
/ klowrey@escotechnologies.com

[0001104659-25-045548:8k_2_02:7]
ESCO REPORTS SECOND QUARTER FISCAL 2025 RESULTS

[0001104659-25-045548:8k_2_02:8]
- Q2 Sales increase 7% to $266 Million -

[0001104659-25-045548:8k_2_02:9]
- Q2 GAAP EPS increases 33% to $1.20 -

[0001104659-25-045548:8k_2_02:10]
- Q2 Adjusted EPS increases 24% to $1.35
-

[0001104659-25-045548:8k_2_02:11]
- Q2 Orders increase 22% to $291 Million
/ Book-to-Bill of 1.10x -

[0001104659-25-045548:8k_2_02:12]
ST. LOUIS, May 7, 2025 – ESCO Technologies
Inc. (NYSE: ESE) (ESCO, or the Company) today reported its operating results for the second quarter ended March 31, 2025 (Q2 2025).

[0001104659-25-045548:8k_2_02:13]
Operating Highlights

[0001104659-25-045548:8k_2_02:14]
|  | · | Q2 2025 Sales increased $16.4 million (7 percent) to $265.5 million compared to $249.1 million in Q2 2024. |

[0001104659-25-045548:8k_2_02:15]
|  | · | Q2 2025 Entered Orders were $290.8 million for a book-to-bill ratio of 1.10x, resulting in record backlog of $932 million. |

[0001104659-25-045548:8k_2_02:16]
|  | · | Q2 2025 GAAP EPS increased 33 percent to $1.20 per share compared to $0.90 per share in Q2 2024. |

[0001104659-25-045548:8k_2_02:17]
|  | · | Q2 2025 Adjusted EPS increased 24 percent to $1.35 per share compared to $1.09 per share in Q2 2024. |

[0001104659-25-045548:8k_2_02:18]
|  | · | Net cash provided by operating activities was $58 million YTD, an increase of $39 million compared to the prior year period. |

[0001104659-25-045548:8k_2_02:19]
Bryan Sayler, Chief Executive Officer and President,
commented, “Q2 was another strong quarter as we delivered 7 percent top line growth, 250 basis points of Adjusted EBITDA margin
expansion, and a 24 percent increase in Adjusted EPS compared to the prior year. All three segments delivered solid revenue growth, highlighted
by strength across our Navy, commercial aerospace, utility, and Test end-markets. It was very positive to see orders increase 22 percent
over the prior year, with particular strength in both USG and Test.

[0001104659-25-045548:8k_2_02:20]
“As previously announced, we closed the
SM&P acquisition on April 25th. Going forward, SM&P will be known as ESCO Maritime Solutions (Maritime). We are
happy to welcome the Maritime employees to the ESCO team. Maritime’s signature and power management solutions meaningfully
expand our naval product offerings in both the US and UK. We are optimistic about the future of ESCO and are pleased to have
Maritime join us as an integral part of that journey.”

[0001104659-25-045548:8k_2_02:21]
Segment Performance

[0001104659-25-045548:8k_2_02:22]
Aerospace & Defense (A&D)

[0001104659-25-045548:8k_2_02:23]
|  | · | Sales increased $8.7 million (8 percent) to $123.4 million in Q2 2025 from $114.7 million in Q2 2024. The Q2 increase was driven by strength in Navy and aerospace sales. |

[0001104659-25-045548:8k_2_02:24]
|  | · | EBIT increased $6.9 million in Q2 2025 to $30.3 million from $23.4 million in Q2 2024. Adjusted EBIT increased $6.7 million in Q2 2025 to $30.3 million (24.6 percent margin) from $23.6 million (20.6 percent margin) in Q2 2024. Margin improvement was driven by price increases and mix, partially offset by inflationary pressures. |

[0001104659-25-045548:8k_2_02:25]
|  | · | Entered Orders increased $6 million (5 percent) to $122 million in Q2 2025 compared to $116 million in Q2 2024. Q2 2025 included a $6M order for PTI’s cartridge actuated devices/propellant actuated devices (CAD/PAD) products. The segment book-to-bill was 0.99x in the quarter, resulting in ending backlog of $605 million. |

[0001104659-25-045548:8k_2_02:26]
Utility Solutions Group (USG)

[0001104659-25-045548:8k_2_02:27]
|  | · | Sales increased $3.5 million (4 percent) to $90.8 million in Q2 2025 from $87.3 million in Q2 2024. Doble’s sales increased by $3.5 million (5 percent) driven by a strong quarter for offline and protection testing products and services, partially offset by lower cybersecurity/compliance (DUCe) solutions. NRG sales were flat to the prior year due to moderation in renewable energy projects. |

[0001104659-25-045548:8k_2_02:28]
|  | · | EBIT increased $3.2 million in Q2 2025 to $20.8 million from $17.6 million in Q2 2024. Adjusted EBIT increased $3.3 million in Q2 2025 to $20.9 million (23.0 percent margin) from $17.6 million (20.1 percent margin) in Q2 2024. Margin was favorably impacted by leverage on higher volume, price increases and mix, partially offset by inflationary pressures. |

[0001104659-25-045548:8k_2_02:29]
|  | · | Entered Orders increased $13 million (17 percent) to $92 million in Q2 2025. Doble orders increased by $11 million (17 percent) on strong offline test equipment and services orders. NRG orders increased by $2 million (15 percent) driven by solar orders in North America and EMEA. The segment book-to-bill was 1.02x in the quarter, resulting in ending backlog of $124 million. |

[0001104659-25-045548:8k_2_02:30]
RF Test & Measurement (Test)

[0001104659-25-045548:8k_2_02:31]
|  | · | Sales increased $4.3 million (9 percent) to $51.4 million in Q2 2025 from $47.1 million in Q2 2024. Sales growth was primarily driven by higher Test and Measurement, industrial shielding, and medical services in the US, along with a strong quarter for MPE filters projects. |

[0001104659-25-045548:8k_2_02:32]
|  | · | EBIT increased $0.9 million in Q2 2025 to $6.4 million from $5.5 million in Q2 2024. Adjusted EBIT increased $0.7 million in Q2 2025 to $6.4 million (12.4 percent margin) from $5.7 million (12.2 percent margin) in Q2 2024. Margin was favorably impacted by leverage on higher volume, price increases, and cost reduction efforts, partially offset by unfavorable mix and inflationary pressures. |

[0001104659-25-045548:8k_2_02:33]
|  | · | Entered Orders increased $33 million (75 percent) to $77 million in Q2 2025. The increase was primarily driven by a strong quarter for US Test & Measurement, filters, and medical and industrial shielding orders. In addition, orders in China increased $9M in the quarter, primarily related to Test & Measurement projects. The segment book-to-bill was 1.50x in the quarter, resulting in ending backlog of $203 million. |

[0001104659-25-045548:8k_2_02:34]
Business Outlook – 2025

[0001104659-25-045548:8k_2_02:35]
Guidance for Q3 2025 and FY 2025 is being shown both
with and without the impact of Maritime to provide insight into our expectations for Maritime’s impact on the remainder of Q3 2025
(approximately 2 months) and FY 2025 (approximately 5 months). The transaction costs and purchase accounting amortization associated with
the Maritime acquisition have not yet been finalized and are not included in our current business outlook.

[0001104659-25-045548:8k_2_02:36]
Consistent with our initial FY 2025 guidance, organic
sales are expected to grow 6 to 8 percent in FY 2025. Maritime is expected to contribute sales in the range of $90 to $100 million in
FY 2025.

[0001104659-25-045548:8k_2_02:37]
|  |  | Guidance Range ($ Millions) |  |
| Sales Guidance excluding Maritime |  | $ | 1,090 |  |  | $ | 1,110 |  |
| Maritime Impact |  | $ | 90 |  |  | $ | 100 |  |
| Sales Guidance including Maritime |  | $ | 1,180 |  |  | $ | 1,210 |  |

[0001104659-25-045548:8k_2_02:38]
In our Q1 2025 earnings release (dated 2/6/2025), FY 2025 Adjusted
EPS guidance was increased to $5.55-$5.75. Due to continued market strength and improvement in operational performance, we are raising
our full-year guidance by another $0.10 to $5.65 to $5.85 (18 to 23 percent growth over the prior year). Maritime is expected to contribute
Adjusted EPS in the range of $0.20 - $0.30 in FY 2025.

[0001104659-25-045548:8k_2_02:39]
|  |  | Guidance Range |  |
| Previous FY 2025 Adjusted EPS Guidance |  | $ | 5.55 |  |  | $ | 5.75 |  |
| Guidance Increase |  | $ | 0.10 |  |  | $ | 0.10 |  |
| Updated FY'25 Adjusted EPS Guidance excluding Maritime |  | $ | 5.65 |  |  | $ | 5.85 |  |
| Maritime Impact |  | $ | 0.20 |  |  | $ | 0.30 |  |
| Updated FY'25 Adjusted EPS Guidance including Maritime |  | $ | 5.85 |  |  | $ | 6.15 |  |

[0001104659-25-045548:8k_2_02:40]
Management’s expectation is
for Q3 Adjusted EPS without Maritime to be in the range of $1.50 to $1.60 (15 to 22 percent growth over the prior year quarter). Maritime
is expected to add Adjusted EPS in the range of $0.08 to $0.12 in Q3 2025.

[0001104659-25-045548:8k_2_02:41]
|  |  | Guidance Range |  |
| Q3 2025 Adjusted EPS Guidance excluding Maritime |  | $ | 1.50 |  |  | $ | 1.60 |  |
| Maritime Impact |  | $ | 0.08 |  |  | $ | 0.12 |  |
| Q3 2025 Adjusted EPS Guidance including Maritime |  | $ | 1.58 |  |  | $ | 1.72 |  |

[0001104659-25-045548:8k_2_02:42]
Dividend Payment

[0001104659-25-045548:8k_2_02:43]
The next quarterly cash dividend
of $0.08 per share will be paid on July 17, 2025 to stockholders of record on July 2, 2025.

[0001104659-25-045548:8k_2_02:44]
Conference Call

[0001104659-25-045548:8k_2_02:45]
The Company will host a conference call today, May 7, at 4:00 p.m.
Central Time, to discuss the Company’s Q2 2025 results. A live audio webcast and an accompanying slide presentation will be available
in the Investor Center of ESCO’s website. Participants may also access the webcast using this registration link. For those unable
to participate, a webcast replay will be available after the call in the Investor Center of ESCO’s website.

[0001104659-25-045548:8k_2_02:46]
Forward-Looking Statements

[0001104659-25-045548:8k_2_02:47]
Investors are cautioned that such statements are only predictions
and speak only as of the date of this presentation, and the Company undertakes no duty to update them except as may be required by
applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the
forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment
including but not limited to those described in Item 1A, “Risk Factors”, of the Company’s Annual Report on Form
10-K for the fiscal year ended September 30, 2024 and the following: the timing and outcome, if any, of the Company’s
strategic alternatives review of the VACCO business; the impacts of climate change and related regulation of greenhouse gases; the
impacts of labor disputes, civil disorder, wars, elections, political changes, tariffs and trade disputes, terrorist activities,
cyberattacks or natural disasters on the Company’s operations and those of the Company’s customers and suppliers;
disruptions in manufacturing or delivery arrangements due to shortages or unavailability of materials or components or supply chain
disruptions; inability to access work sites; the timing and content of future contract awards or customer orders; the timely
appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer
contracts or orders; weakening of economic conditions in served markets; the success of the Company’s competitors; changes in
customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties or data breaches; the
availability of acquisitions; delivery delays or defaults by customers; performance issues with key customers, suppliers and
subcontractors; material changes in the costs and availability of certain raw materials; material changes in the cost of credit;
changes in laws and regulations including but not limited to changes in accounting standards and taxation; changes in interest,
inflation and employment rates; costs relating to environmental matters arising from current or former facilities; uncertainty
regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the integration and performance of
acquired businesses.

[0001104659-25-045548:8k_2_02:48]
Non-GAAP Financial Measures

[0001104659-25-045548:8k_2_02:49]
The financial measures EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA,
and Adjusted EPS are presented in this press release. The Company defines “EBIT” as earnings before interest and taxes, “EBITDA”
as earnings before interest, taxes, depreciation and amortization, “Adjusted EBIT” and “Adjusted EBITDA” as excluding
the net impact of the items described in the attached Reconciliation of Non-GAAP Financial Measures, and “Adjusted EPS” as
GAAP earnings per share excluding the net impact of the items described and reconciled in the attached Reconciliation of Non-GAAP Financial
Measures.

[0001104659-25-045548:8k_2_02:50]
EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA, and
Adjusted EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management believes
EBIT, Adjusted EBIT, EBITDA, and Adjusted EBITDA are useful in assessing the operational profitability of the Company’s business
segments because they exclude interest, taxes, depreciation, and amortization, which are generally accounted for across the entire Company
on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company as
well as incentive compensation. The presentation of EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA, and Adjusted EPS provides important
supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures
to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance determined
in accordance with GAAP.

[0001104659-25-045548:8k_2_02:51]
About ESCO

[0001104659-25-045548:8k_2_02:52]
ESCO Technologies is a global provider of highly engineered products
and solutions serving diverse end-markets. It manufactures filtration and fluid control products, advanced composites, as well as signature
and power management solutions for aviation, Navy, space, and industrial customers. ESCO is an industry leader in designing and manufacturing
RF test and measurement products and systems; and provides diagnostic instruments, software and services to industrial power users and
the electric utility and renewable energy industries. Headquartered in St. Louis, Missouri, ESCO and its subsidiaries have offices and
manufacturing facilities worldwide. For more information on ESCO and its subsidiaries, visit ESCO’s website at www.escotechnologies.com.

[0001104659-25-045548:8k_2_02:53]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-25-045548:8k_2_02:54]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-25-045548:8k_2_02:55]
(Dollars in thousands, except per share amounts)

[0001104659-25-045548:8k_2_02:56]
|  |  | Three Months Ended March 31, 2025 |  |  | Three Months Ended March 31, 2024 |  |
| Net Sales |  | $ | 265,519 |  |  |  | 249,129 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 156,298 |  |  |  | 152,347 |  |
| Selling, general and administrative expenses |  |  | 58,163 |  |  |  | 55,097 |  |
| Amortization of intangible assets |  |  | 7,989 |  |  |  | 8,572 |  |
| Interest expense |  |  | 2,195 |  |  |  | 3,226 |  |
| Other expenses (income), net |  |  | 375 |  |  |  | 666 |  |
| Total costs and expenses |  |  | 225,020 |  |  |  | 219,908 |  |
| Earnings before income taxes |  |  | 40,499 |  |  |  | 29,221 |  |
| Income tax expense |  |  | 9,466 |  |  |  | 6,002 |  |
| Net earnings |  | $ | 31,033 |  |  |  | 23,219 |  |
| Earnings Per Share (EPS) |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 1.20 |  |  |  | 0.90 |  |
| Diluted - As Adjusted Basis |  | $ | 1.35 | (1) |  |  | 1.09 | (2) |
| Diluted average common shares O/S: |  |  | 25,877 |  |  |  | 25,847 |  |

[0001104659-25-045548:8k_2_02:57]
| (1) | Q2 2025 Adjusted EPS excludes $0.15 per share of after-tax charges consisting primarily of acquisition related amortization. |
| (2) | Q2 2024 Adjusted EPS excludes $0.19 per share of after-tax charges consisting of: $0.02 of MPE acquisition backlog charges, $0.02 of restructuring charges (primarily severance) within the Test and A&D segments, and $0.15 of acquisition related amortization. |

[0001104659-25-045548:8k_2_02:58]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Condensed Consolidated Statements of Operations (Unaudited) |
| (Dollars in thousands, except per share amounts) |

[0001104659-25-045548:8k_2_02:59]
|  |  | Six Months Ended March 31, 2025 |  |  | Six Months Ended March 31, 2024 |  |
| Net Sales |  | $ | 512,545 |  |  |  | 467,443 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 304,940 |  |  |  | 286,498 |  |
| Selling, general and administrative expenses |  |  | 116,947 |  |  |  | 109,065 |  |
| Amortization of intangible assets |  |  | 15,982 |  |  |  | 16,440 |  |
| Interest expense |  |  | 4,452 |  |  |  | 5,893 |  |
| Other expenses (income), net |  |  | (216 | ) |  |  | 872 |  |
| Total costs and expenses |  |  | 442,105 |  |  |  | 418,768 |  |
| Earnings before income taxes |  |  | 70,440 |  |  |  | 48,675 |  |
| Income tax expense |  |  | 15,934 |  |  |  | 10,287 |  |
| Net earnings |  | $ | 54,506 |  |  |  | 38,388 |  |
| Earnings Per Share (EPS) |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 2.11 |  |  |  | 1.49 |  |
| Diluted - As Adjusted Basis |  | $ | 2.42 | (1) |  |  | 1.85 | (2) |
| Diluted average common shares O/S: |  |  | 25,854 |  |  |  | 25,846 |  |

[0001104659-25-045548:8k_2_02:60]
| (1) | YTD Q2 2025 Adjusted EPS excludes $0.31 per share of after-tax charges consisting primarily of $0.01 of restructuring charges within the Test segment and $0.30 of acquisition related amortization. |
| (2) | YTD Q2 2024 Adjusted EPS excludes $0.36 per share of after-tax charges consisting of: $0.05 of MPE acquisition backlog and inventory step-up charges and acquisition costs, $0.02 of restructuring charges (primarily severance) within the Test and A&D segments, and $0.29 of acquisition related amortization. |

[0001104659-25-045548:8k_2_02:61]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Condensed Business Segment Information (Unaudited) |
| (Dollars in thousands) |

[0001104659-25-045548:8k_2_02:62]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | Q2 2025 |  |  | Q2 2024 |  |  | Q2 2025 |  |  | Q2 2024 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 123,369 |  |  |  | 114,701 |  |  |  | 123,369 |  |  |  | 114,701 |  |
| USG |  |  | 90,767 |  |  |  | 87,309 |  |  |  | 90,767 |  |  |  | 87,309 |  |
| Test |  |  | 51,383 |  |  |  | 47,119 |  |  |  | 51,383 |  |  |  | 47,119 |  |
| Totals |  | $ | 265,519 |  |  |  | 249,129 |  |  |  | 265,519 |  |  |  | 249,129 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 30,296 |  |  |  | 23,377 |  |  |  | 30,298 |  |  |  | 23,640 |  |
| USG |  |  | 20,779 |  |  |  | 17,575 |  |  |  | 20,862 |  |  |  | 17,575 |  |
| Test |  |  | 6,369 |  |  |  | 5,542 |  |  |  | 6,369 |  |  |  | 5,745 |  |
| Corporate |  |  | (14,750 | ) |  |  | (14,047 | ) |  |  | (9,648 | ) |  |  | (8,260 | ) |
| Consolidated EBIT |  |  | 42,694 |  |  |  | 32,447 |  |  |  | 47,881 |  |  |  | 38,700 |  |
| Less: Interest expense |  |  | (2,195 | ) |  |  | (3,226 | ) |  |  | (2,195 | ) |  |  | (3,226 | ) |
| Less: Income tax expense |  |  | (9,466 | ) |  |  | (6,002 | ) |  |  | (10,659 | ) |  |  | (7,440 | ) |
| Net earnings |  | $ | 31,033 |  |  |  | 23,219 |  |  |  | 35,027 |  |  |  | 28,034 |  |

[0001104659-25-045548:8k_2_02:63]
Note 1: Adjusted net earnings of $35.0 million in Q2 2025 exclude $4.0
million (or $0.15 per share) of after-tax charges consisting primarily of acquisition related amortization.

[0001104659-25-045548:8k_2_02:64]
Note 2: Adjusted net earnings of $28.0 million in Q2 2024 exclude $4.8
million (or $0.19 per share) of after-tax charges consisting of: $0.02 of MPE acquisition backlog charges, $0.02 of restructuring charges
(primarily severance) within the Test and A&D segments, and $0.15 of acquisition related amortization.

[0001104659-25-045548:8k_2_02:65]
EBITDA Reconciliation to Net earnings:

[0001104659-25-045548:8k_2_02:66]
|  |  |  |  |  |  |  |  | Q2 2025 - |  |  | Q2 2024 - |  |
|  |  | Q2 2025 |  |  | Q2 2024 |  |  | As Adjusted |  |  | As Adjusted |  |
| Consolidated EBITDA |  | $ | 56,668 |  |  |  | 46,550 |  |  |  | 56,895 |  |  |  | 47,174 |  |
| Less: Depr & Amort |  |  | (13,974 | ) |  |  | (14,103 | ) |  |  | (9,014 | ) |  |  | (8,474 | ) |
| Consolidated EBIT |  |  | 42,694 |  |  |  | 32,447 |  |  |  | 47,881 |  |  |  | 38,700 |  |
| Less: Interest expense |  |  | (2,195 | ) |  |  | (3,226 | ) |  |  | (2,195 | ) |  |  | (3,226 | ) |
| Less: Income tax expense |  |  | (9,466 | ) |  |  | (6,002 | ) |  |  | (10,659 | ) |  |  | (7,440 | ) |
| Net earnings |  | $ | 31,033 |  |  |  | 23,219 |  |  |  | 35,027 |  |  |  | 28,034 |  |

[0001104659-25-045548:8k_2_02:67]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Condensed Business Segment Information (Unaudited) |
| (Dollars in thousands) |

[0001104659-25-045548:8k_2_02:68]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | YTD Q2 2025 |  |  | YTD Q2 2024 |  |  | YTD Q2 2025 |  |  | YTD Q2 2024 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 237,670 |  |  |  | 209,434 |  |  |  | 237,670 |  |  |  | 209,434 |  |
| USG |  |  | 177,427 |  |  |  | 170,293 |  |  |  | 177,427 |  |  |  | 170,293 |  |
| Test |  |  | 97,448 |  |  |  | 87,716 |  |  |  | 97,448 |  |  |  | 87,716 |  |
| Totals |  | $ | 512,545 |  |  |  | 467,443 |  |  |  | 512,545 |  |  |  | 467,443 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 51,892 |  |  |  | 40,040 |  |  |  | 51,920 |  |  |  | 40,303 |  |
| USG |  |  | 41,269 |  |  |  | 35,200 |  |  |  | 41,352 |  |  |  | 35,320 |  |
| Test |  |  | 10,791 |  |  |  | 7,321 |  |  |  | 11,256 |  |  |  | 7,797 |  |
| Corporate |  |  | (29,060 | ) |  |  | (27,993 | ) |  |  | (18,959 | ) |  |  | (16,860 | ) |
| Consolidated EBIT |  |  | 74,892 |  |  |  | 54,568 |  |  |  | 85,569 |  |  |  | 66,560 |  |
| Less: Interest expense |  |  | (4,452 | ) |  |  | (5,893 | ) |  |  | (4,452 | ) |  |  | (5,893 | ) |
| Less: Income tax |  |  | (15,934 | ) |  |  | (10,287 | ) |  |  | (18,390 | ) |  |  | (13,045 | ) |
| Net earnings |  | $ | 54,506 |  |  |  | 38,388 |  |  |  | 62,727 |  |  |  | 47,622 |  |

[0001104659-25-045548:8k_2_02:69]
Note 1: Adjusted net earnings of $62.7 million in YTD 2025 exclude
$8.2 million (or $0.31 per share) of after-tax charges consisting of: $0.01 of restructuring charges within the Test segment and acquisition
related costs at Corporate, and $0.30 of acquisition related amortization.

[0001104659-25-045548:8k_2_02:70]
Note 2: Adjusted net earnings of $47.6 million in YTD 2024 exclude
$9.2 million (or $0.36 per share) of after-tax charges consisting of: $0.05 of MPE acquisition backlog and inventory step-up charges and
acquisition costs, $0.02 of restructuring costs (primarily severance) within the Test and A&D segments, and $0.29 of acquisition related
amortization.

[0001104659-25-045548:8k_2_02:71]
EBITDA Reconciliation to Net earnings:

[0001104659-25-045548:8k_2_02:72]
|  |  |  |  |  |  |  |  | YTD |  |  | YTD |  |
|  |  | YTD |  |  | YTD |  |  | Q2 2025 - |  |  | Q2 2024 - |  |
|  |  | Q2 2025 |  |  | Q2 2024 |  |  | As Adjusted |  |  | As Adjusted |  |
| Consolidated EBITDA |  | $ | 102,673 |  |  |  | 82,123 |  |  |  | 103,393 |  |  |  | 83,582 |  |
| Less: Depr & Amort |  |  | (27,781 | ) |  |  | (27,555 | ) |  |  | (17,824 | ) |  |  | (17,022 | ) |
| Consolidated EBIT |  |  | 74,892 |  |  |  | 54,568 |  |  |  | 85,569 |  |  |  | 66,560 |  |
| Less: Interest expense |  |  | (4,452 | ) |  |  | (5,893 | ) |  |  | (4,452 | ) |  |  | (5,893 | ) |
| Less: Income tax expense |  |  | (15,934 | ) |  |  | (10,287 | ) |  |  | (18,390 | ) |  |  | (13,045 | ) |
| Net earnings |  | $ | 54,506 |  |  |  | 38,388 |  |  |  | 62,727 |  |  |  | 47,622 |  |

[0001104659-25-045548:8k_2_02:73]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Condensed Consolidated Balance Sheets (Unaudited) |
| (Dollars in thousands) |

[0001104659-25-045548:8k_2_02:74]
|  |  | March 31, 2025 |  |  | September 30, 2024 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 57,397 |  |  |  | 65,963 |  |
| Accounts receivable, net |  |  | 218,123 |  |  |  | 240,680 |  |
| Contract assets |  |  | 125,281 |  |  |  | 130,534 |  |
| Inventories |  |  | 231,200 |  |  |  | 209,164 |  |
| Other current assets |  |  | 28,752 |  |  |  | 22,308 |  |
| Total current assets |  |  | 660,753 |  |  |  | 668,649 |  |
| Property, plant and equipment, net |  |  | 172,081 |  |  |  | 170,596 |  |
| Intangible assets, net |  |  | 394,594 |  |  |  | 407,602 |  |
| Goodwill |  |  | 536,222 |  |  |  | 539,899 |  |
| Operating lease assets |  |  | 38,322 |  |  |  | 37,744 |  |
| Other assets |  |  | 13,690 |  |  |  | 14,130 |  |
|  |  | $ | 1,815,662 |  |  |  | 1,838,620 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt |  | $ | 20,000 |  |  |  | 20,000 |  |
| Accounts payable |  |  | 81,244 |  |  |  | 98,371 |  |
| Contract liabilities |  |  | 128,114 |  |  |  | 124,845 |  |
| Other current liabilities |  |  | 92,661 |  |  |  | 106,638 |  |
| Total current liabilities |  |  | 322,019 |  |  |  | 349,854 |  |
| Deferred tax liabilities |  |  | 72,580 |  |  |  | 75,333 |  |
| Non-current operating lease liabilities |  |  | 35,948 |  |  |  | 34,810 |  |
| Other liabilities |  |  | 39,787 |  |  |  | 39,273 |  |
| Long-term debt |  |  | 68,000 |  |  |  | 102,000 |  |
| Shareholders' equity |  |  | 1,277,328 |  |  |  | 1,237,350 |  |
|  |  | $ | 1,815,662 |  |  |  | 1,838,620 |  |

[0001104659-25-045548:8k_2_02:75]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Consolidated Statements of Cash Flows (Unaudited) |
| (Dollars in thousands) |

[0001104659-25-045548:8k_2_02:76]
|  |  | Six Months Ended March 31, 2025 |  |  | Six Months Ended March 31, 2024 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 54,506 |  |  |  | 38,388 |  |
| Adjustments to reconcile net earnings to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 27,781 |  |  |  | 27,555 |  |
| Stock compensation expense |  |  | 5,323 |  |  |  | 4,144 |  |
| Changes in assets and liabilities |  |  | (27,207 | ) |  |  | (47,869 | ) |
| Effect of deferred taxes |  |  | (2,128 | ) |  |  | (2,981 | ) |
| Net cash provided by operating activities |  |  | 58,275 |  |  |  | 19,237 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Acquisition of business, net of cash acquired |  |  | - |  |  |  | (56,179 | ) |
| Capital expenditures |  |  | (15,350 | ) |  |  | (16,301 | ) |
| Additions to capitalized software |  |  | (5,465 | ) |  |  | (5,912 | ) |
| Net cash used by investing activities |  |  | (20,815 | ) |  |  | (78,392 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from long-term debt |  |  | 66,000 |  |  |  | 154,000 |  |
| Principal payments on long-term debt and short-term borrowings |  |  | (100,000 | ) |  |  | (65,000 | ) |
| Dividends paid |  |  | (4,130 | ) |  |  | (4,125 | ) |
| Purchases of common stock into treasury |  |  | - |  |  |  | (7,189 | ) |
| Other |  |  | (6,146 | ) |  |  | (1,432 | ) |
| Net cash (used) provided by financing activities |  |  | (44,276 | ) |  |  | 76,254 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (1,750 | ) |  |  | 471 |  |
| Net (decrease) increase in cash and cash equivalents |  |  | (8,566 | ) |  |  | 17,570 |  |
| Cash and cash equivalents, beginning of period |  |  | 65,963 |  |  |  | 41,866 |  |
| Cash and cash equivalents, end of period |  | $ | 57,397 |  |  |  | 59,436 |  |

[0001104659-25-045548:8k_2_02:77]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Other Selected Financial Data (Unaudited) |
| (Dollars in thousands) |

[0001104659-25-045548:8k_2_02:78]
| Backlog And Entered Orders - Q2 2025 |  | A&D |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 1/1/25 |  | $ | 606,687 |  |  |  | 122,857 |  |  |  | 177,404 |  |  |  | 906,948 |  |
| Entered Orders |  |  | 121,706 |  |  |  | 92,184 |  |  |  | 76,950 |  |  |  | 290,840 |  |
| Sales |  |  | (123,369 | ) |  |  | (90,767 | ) |  |  | (51,383 | ) |  |  | (265,519 | ) |
| Ending Backlog - 3/31/25 |  | $ | 605,024 |  |  |  | 124,274 |  |  |  | 202,971 |  |  |  | 932,269 |  |

[0001104659-25-045548:8k_2_02:79]
| Backlog And Entered Orders - YTD Q2 2025 |  | A&D |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 10/1/24 |  | $ | 600,382 |  |  |  | 119,943 |  |  |  | 158,644 |  |  |  | 878,969 |  |
| Entered Orders |  |  | 242,312 |  |  |  | 181,758 |  |  |  | 141,775 |  |  |  | 565,845 |  |
| Sales |  |  | (237,670 | ) |  |  | (177,427 | ) |  |  | (97,448 | ) |  |  | (512,545 | ) |
| Ending Backlog - 3/31/25 |  | $ | 605,024 |  |  |  | 124,274 |  |  |  | 202,971 |  |  |  | 932,269 |  |

[0001104659-25-045548:8k_2_02:80]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-25-045548:8k_2_02:81]
Reconciliation of Non-GAAP Financial Measures (Unaudited)

[0001104659-25-045548:8k_2_02:82]
| EPS – Adjusted Basis Reconciliation – Q2 2025 |  |  |  |
| EPS – GAAP Basis – Q2 2025 |  | $ | 1.20 |  |
| Adjustments (defined below) |  |  | 0.15 |  |
| EPS – As Adjusted Basis – Q2 2025 |  | $ | 1.35 |  |

[0001104659-25-045548:8k_2_02:83]
Adjustments exclude $0.15
per share consisting primarily of acquisition related amortization.

[0001104659-25-045548:8k_2_02:84]
The $0.15 of EPS adjustments per share consists of $5.2 million of
pre-tax charges offset by $1.2 million of tax benefit for net impact of $4 million.

[0001104659-25-045548:8k_2_02:85]
| EPS – Adjusted Basis Reconciliation – Q2 2024 |  |  |  |  |
| EPS – GAAP Basis – Q2 2024 |  | $ | 0.90 |  |
| Adjustments (defined below) |  |  | 0.19 |  |
| EPS – As Adjusted Basis – Q2 2024 |  | $ | 1.09 |  |

[0001104659-25-045548:8k_2_02:86]
Adjustments exclude $0.19 per share
consisting primarily of $0.02 of MPE acquisition backlog charges, $0.02 of restructuring charges within the Test and A&D
segments, and $0.15 of acquisition related amortization.

[0001104659-25-045548:8k_2_02:87]
The $0.19 of EPS adjustments per share consists of $6.2 million of pre-tax
charges offset by $1.4 million of tax benefit for net impact of $4.8 million.

[0001104659-25-045548:8k_2_02:88]
| EPS – Adjusted Basis Reconciliation – YTD Q2 2025 |  |  |  |  |
| EPS – GAAP Basis – YTD Q2 2025 |  | $ | 2.11 |  |
| Adjustments (defined below) |  |  | 0.31 |  |
| EPS – As Adjusted Basis – YTD Q2 2025 |  | $ | 2.42 |  |

[0001104659-25-045548:8k_2_02:89]
Adjustments exclude $0.31 per share consisting
primarily of $0.01 of restructuring charges within the Test segment and $0.30 of acquisition related amortization.

[0001104659-25-045548:8k_2_02:90]
The $0.31 of EPS adjustments
per share consists of $10.7 million of pre-tax charges offset by $2.5 million of tax benefit for net impact of $8.2 million.

[0001104659-25-045548:8k_2_02:91]
| EPS – Adjusted Basis Reconciliation – YTD Q2 2024 |  |  |  |  |
| EPS – GAAP Basis – YTD Q2 2024 |  | $ | 1.49 |  |
| Adjustments (defined below) |  |  | 0.36 |  |
| EPS – As Adjusted Basis – YTD Q2 2024 |  | $ | 1.85 |  |

[0001104659-25-045548:8k_2_02:92]
Adjustments exclude $0.36
per share consisting primarily of $0.05 of MPE acquisition backlog charges, inventory step-up charges and acquisition costs, $0.02 of
restructuring charges, and $0.29 of acquisition related amortization.

[0001104659-25-045548:8k_2_02:93]
The $0.36 of EPS adjustments per share consists of $12 million
of pre-tax charges offset by $2.8 million of tax benefit for net impact of $9.2 million.
