# ESE notes — 0001410578-25-001145


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001410578-25-001145:notes:1]
[same as prior period, unchanged from 0001410578-25-000100:notes:1]

[0001410578-25-001145:notes:2]
[same as prior period, unchanged from 0001410578-25-000100:notes:2]

[0001410578-25-001145:notes:3]
The Company’s results for the three-month period ended March 31, 2025 are not necessarily indicative of the results for the entire 2025 fiscal year. References to the second quarters of 2025 and 2024 represent the fiscal quarters ended March 31, 2025 and 2024, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:EarningsPerShareTextBlock

[0001410578-25-001145:notes:4]
[same as prior period, unchanged from 0001410578-25-000100:notes:4]

[0001410578-25-001145:notes:5]
Basic EPS is calculated using the weighted average number of common shares outstanding during the period. Diluted EPS is calculated using the weighted average number of common shares outstanding during the period plus shares issuable upon the assumed exercise of dilutive common share options and vesting of performance-based share unit awards and time-vested restricted shares by using the treasury stock method. The number of shares used in the calculation of earnings per share for each period presented is as follows (in thousands):

[0001410578-25-001145:notes:6]
| ​ |  | Three Months | ​ | Six Months |
| ​ | ​ | Ended March 31, | ​ | Ended March 31, |
| ​ |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Weighted Average Shares Outstanding — Basic |  | 25,816 | ​ | 25,792 | ​ | 25,798 | ​ | 25,794 |
| Dilutive Restricted Shares | ​ | 61 | ​ | 55 | ​ | 57 | ​ | 52 |
| Adjusted Shares — Diluted |  | 25,877 | ​ | 25,847 | ​ | 25,855 | ​ | 25,846 |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001410578-25-001145:notes:7]
[same as prior period, unchanged from 0001410578-25-000100:notes:7]

[0001410578-25-001145:notes:8]
The Company provides compensation benefits to certain key employees under several share-based plans providing for a combination of performance-based share unit (PSU) awards and time-vested restricted share unit (RSU) awards and to non-employee directors under a separate compensation plan.

[0001410578-25-001145:notes:9]
Performance Share Unit (PSU) Awards and Time-Vested Restricted Stock Unit (RSU) Awards

[0001410578-25-001145:notes:10]
Compensation expense related to these awards was $2.4 million and $4.6 million for the three and six-month periods ended March 31, 2025, respectively, and $1.7 million and $3.5 million for the corresponding periods in 2024. As of March 31, 2025, there were 206,373 unvested stock units outstanding.

[0001410578-25-001145:notes:11]
[same as prior period, unchanged from 0001410578-25-000100:notes:11]

[0001410578-25-001145:notes:12]
Compensation expense related to the non-employee director grants was $0.4 million and $0.7 million for the three and six-month periods ended March 31, 2025, respectively, and $0.3 million and $0.6 million for the corresponding periods in 2024.

[0001410578-25-001145:notes:13]
The total share-based compensation cost that has been recognized in the results of operations and included within selling, general and administrative expenses (SG&A) was $2.8 million and $5.3 million for the three and six-month periods ended March 31, 2025, respectively, and $2.0 million and $4.1 million for the corresponding periods in 2024. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $0.6 million and $1.1 million for the three and six-month periods ended March 31, 2025, respectively, and $0.3 million and $0.5 million for the corresponding periods in 2024. As of March 31, 2025, there was $15.5 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a remaining weighted-average period of 1.8 years.


## us-gaap:InventoryDisclosureTextBlock

[0001410578-25-001145:notes:14]
[same as prior period, unchanged from 0001410578-25-000100:notes:14]

[0001410578-25-001145:notes:15]
[same as prior period, unchanged from 0001410578-25-000100:notes:15]

[0001410578-25-001145:notes:16]
| ​ | ​ | March 31, | ​ | September 30, |
| (In thousands) |  | 2025 |  | 2024 |
| Finished goods | ​ | $ | 56,666 | ​ | 46,586 |
| Work in process | ​ | ​ | 54,145 | ​ | 47,903 |
| Raw materials | ​ | ​ | 120,389 | ​ | 114,675 |
| Total inventories | ​ | $ | 231,200 | ​ | 209,164 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001410578-25-001145:notes:17]
[same as prior period, unchanged from 0001410578-25-000100:notes:17]

[0001410578-25-001145:notes:18]
Included on the Company’s Consolidated Balance Sheets at March 31, 2025 and September 30, 2024 are the following intangible assets gross carrying amounts and accumulated amortization:

[0001410578-25-001145:notes:19]
| ​ |  | March 31, |  | September 30, |
| (Dollars in thousands) |  | 2025 |  | 2024 |
| Goodwill | ​ | $ | 536,222 | ​ | 539,899 |
| Intangible assets with determinable lives: | ​ |  | ​ | ​ | ​ |
| Patents | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 2,653 | ​ | 2,638 |
| Less: accumulated amortization | ​ |  | 1,513 | ​ | 1,415 |
| Net | ​ | $ | 1,140 | ​ | 1,223 |
| Capitalized software | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 140,111 | ​ | 134,119 |
| Less: accumulated amortization | ​ |  | 98,842 | ​ | 92,878 |
| Net | ​ | $ | 41,269 | ​ | 41,241 |
| Customer relationships | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 328,618 | ​ | 330,328 |
| Less: accumulated amortization | ​ |  | 141,684 | ​ | 132,135 |
| Net | ​ | $ | 186,934 | ​ | 198,193 |
| Other | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 14,872 | ​ | 15,182 |
| Less: accumulated amortization | ​ |  | 11,545 | ​ | 11,173 |
| Net | ​ | $ | 3,327 | ​ | 4,009 |
| Intangible assets with indefinite lives: | ​ |  | ​ | ​ | ​ |
| Trade names | ​ | $ | 161,924 | ​ | 162,936 |

[0001410578-25-001145:notes:20]
The changes in the carrying amount of goodwill attributable to each business segment for the six months ended March 31, 2025 is as follows:

[0001410578-25-001145:notes:21]
| (Dollars in millions) |  | USG |  | Test |  | A&D |  | Total |
| Balance as of September 30, 2024 | ​ | $ | 356.9 |  | ​ | 67.4 |  | 115.6 |  | 539.9 |
| Foreign currency translation | ​ | ​ | (2.8) | ​ | ​ | (0.9) | ​ | — | ​ | (3.7) |
| Balance as of March 31, 2025 | ​ | $ | 354.1 | ​ | ​ | 66.5 | ​ | 115.6 | ​ | 536.2 |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001410578-25-001145:notes:22]
[same as prior period, unchanged from 0001410578-25-000100:notes:22]

[0001410578-25-001145:notes:23]
The Company is organized based on the products and services that it offers and classifies its business operations in three reportable segments for financial reporting purposes: Aerospace & Defense (A&D), Utility Solutions Group (USG), and RF Test and Measurement (Test). The A&D segment’s operations consist of PTI Technologies Inc. (PTI), VACCO Industries (VACCO),

[0001410578-25-001145:notes:24]
Crissair, Inc. (Crissair), Globe Composite Solutions, LLC (Globe) and Mayday Manufacturing Co. (Mayday). The companies within this segment primarily design and manufacture specialty filtration, fluid control and naval products, including hydraulic filter elements and fluid control devices used in aerospace and defense applications; unique filter mechanisms used in micro-propulsion devices for satellites, custom designed filters for manned aircraft and submarines; products and systems to reduce vibration and/or acoustic signatures and otherwise reduce or obscure a vessel’s signature, and other communications, sealing, surface control and hydrodynamic related applications to enhance U.S. Navy maritime survivability; precision-tolerance machined components for the aerospace and defense industry; metal processing services; and miniature electro-explosive devices utilized in mission-critical defense and aerospace applications.

[0001410578-25-001145:notes:25]
The USG segment’s operations consist primarily of Doble Engineering Company and related subsidiaries including Morgan Schaffer and Altanova (collectively, Doble), and NRG Systems, Inc. (NRG). Doble is an industry leader in the development, manufacture and delivery of diagnostic testing solutions that enable electric power grid operators to assess the integrity of high voltage power delivery equipment. It combines three core elements for customers – diagnostic test and condition monitoring instruments, expert consulting, and testing services – and provides access to its large reserve of related empirical knowledge. NRG is a global market leader in the design and manufacture of decision support tools for the renewable energy industry, primarily wind and solar.

[0001410578-25-001145:notes:26]
[same as prior period, unchanged from 0001410578-25-000100:notes:26]

[0001410578-25-001145:notes:27]
[same as prior period, unchanged from 0001410578-25-000100:notes:27]

[0001410578-25-001145:notes:28]
| ​ | ​ | Three Months | ​ | Six Months |
| ​ | ​ | Ended March 31, | ​ | Ended March 31, |
| (In thousands) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| NET SALES | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ |  |
| Aerospace & Defense | ​ | $ | 123,369 | ​ | 114,701 | ​ | 237,670 | ​ | 209,434 |
| USG | ​ | ​ | 90,767 | ​ | 87,309 | ​ | 177,427 | ​ | 170,293 |
| Test | ​ | ​ | 51,383 | ​ | 47,119 | ​ | 97,448 | ​ | 87,716 |
| Consolidated totals | ​ | $ | 265,519 | ​ | 249,129 | ​ | 512,545 | ​ | 467,443 |
| EBIT | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Aerospace & Defense | ​ | $ | 30,296 | ​ | 23,377 | ​ | 51,892 | ​ | 40,040 |
| USG | ​ | ​ | 20,779 | ​ | 17,575 | ​ | 41,269 | ​ | 35,200 |
| Test | ​ | ​ | 6,369 | ​ | 5,542 | ​ | 10,791 | ​ | 7,321 |
| Corporate (loss) | ​ | ​ | (14,750) | ​ | (14,047) | ​ | (29,060) | ​ | (27,993) |
| Consolidated EBIT | ​ | ​ | 42,694 | ​ | 32,447 | ​ | 74,892 | ​ | 54,568 |
| Less: Interest expense | ​ | ​ | (2,195) | ​ | (3,226) | ​ | (4,452) | ​ | (5,893) |
| Earnings before income taxes | ​ | $ | 40,499 | ​ | 29,221 | ​ | 70,440 | ​ | 48,675 |

[0001410578-25-001145:notes:29]
[same as prior period, unchanged from 0001410578-25-000100:notes:29]

[0001410578-25-001145:notes:30]
[same as prior period, unchanged from 0001410578-25-000100:notes:30]

[0001410578-25-001145:notes:31]
The Company believes that the presentation of EBIT provides important supplemental information to investors to facilitate comparisons with other companies, many of which use similar non-GAAP financial measures to supplement their GAAP results.

[0001410578-25-001145:notes:32]
However, the Company’s non-GAAP financial measures may not be comparable to other companies’ non-GAAP financial performance measures. Furthermore, the use of non-GAAP financial measures is not intended to replace any measures of performance determined in accordance with GAAP.


## us-gaap:DebtDisclosureTextBlock

[0001410578-25-001145:notes:33]
7.    DEBT

[0001410578-25-001145:notes:34]
The Company’s debt is summarized as follows:

[0001410578-25-001145:notes:35]
| ​ |  | March 31, | ​ | September 30, |
| (In thousands) |  | 2025 |  | 2024 |
| Total borrowings | ​ | $ | 88,000 | ​ | 122,000 |
| Current portion of long-term debt | ​ | ​ | (20,000) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 68,000 | ​ | 102,000 |

[0001410578-25-001145:notes:36]
The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of seven banks led by JP Morgan Chase Bank, N.A., as administrative agent, Bank of America, N.A., as syndication agent, and Commerce Bank and TD Bank, N.A. as co-documentation agents. The Credit Facility matures August 30, 2028, with balance due by this date.

[0001410578-25-001145:notes:37]
On August 5, 2024, the Company and certain of its subsidiaries entered into Amendment No. 1 (the “Amendment”) to the Credit Facility which, among other things, (i) implements a senior incremental delayed draw term loan credit facility in an aggregate principal amount of up to $375 million (the “Incremental Facility”), and (ii) permits the direct or indirect acquisition by the Registrant or certain of its subsidiaries of all the issued and outstanding shares of Ultra PMES Limited, Measurement Systems, Inc., EMS Development Corporation, and DNE Technologies, Inc. (the “SM&P Acquisition), pursuant to and in accordance with the terms and conditions of that certain Sale and Purchase Agreement, dated July 8, 2024, among Ultra Electronics Holdings Limited, as parent seller, the Registrant, as guarantor, and certain of the Registrant’s subsidiaries as buyers. The proceeds of the loans drawn under the Incremental Facility will be applied to pay a portion of the cash consideration for the SM&P Acquisition and other customary fees, premiums, expenses and costs incurred in connection with the SM&P Acquisition.

[0001410578-25-001145:notes:38]
At March 31, 2025, the Company had approximately $407 million available to borrow under the Credit Facility, excluding the Incremental Facility, plus the $250 million increase option subject to the lenders’ consent, in addition to $57.4 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of March 31, 2025, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $5.1 million at March 31, 2025.

[0001410578-25-001145:notes:39]
Interest on borrowings under the Credit Facility is calculated at a spread over either an Adjusted Term SOFR Rate, Adjusted EURIBOR Rate, Adjusted CDOR Rate, Alternate Base Rate or Daily Simple RFR, at the Company’s election. The Credit Facility also requires a facility fee ranging from 12.5 to 25 basis points per annum on the unused portion. The interest rate spreads and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio. The weighted average interest rates were 5.8% and 6.0% for the three and six-month periods ending March 31, 2025, respectively, and 6.8% and 6.8% for the three and six-month periods ending March 31, 2024. As of March 31, 2025, the Company was in compliance with all covenants.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001410578-25-001145:notes:40]
[same as prior period, unchanged from 0001410578-25-000100:notes:40]

[0001410578-25-001145:notes:41]
The second quarter 2025 effective income tax rate was 23.4% compared to 20.5% in the second quarter of 2024. The effective income tax rate in the first six months of 2025 was 22.6% compared to 21.1% for the first six months of 2024. The increase in income tax expense in the second quarter and first six months of 2025 was due to prior year discrete events including the release of a foreign valuation allowance and excess tax benefit related to the vesting of share-based director compensation favorably impacting the income tax rate in the corresponding periods of 2024.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001410578-25-001145:notes:42]
[same as prior period, unchanged from 0001410578-25-000100:notes:42]

[0001410578-25-001145:notes:43]
The change in shareholders’ equity for the first three and six months of 2025 and 2024 is shown below (in thousands):

[0001410578-25-001145:notes:44]
| ​ | ​ | Three Months Ended March 31, | ​ | Six Months Ended March 31, |
| ​ |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Common stock | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | 309 | ​ | 308 | ​ | 308 | ​ | 308 |
| Stock plans | ​ | ​ | — | ​ | — | ​ | 1 | ​ | — |
| Ending balance | ​ | ​ | 309 | ​ | 308 | ​ | 309 | ​ | 308 |
| Additional paid-in-capital | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | 308,143 | ​ | 305,283 | ​ | 311,942 | ​ | 304,850 |
| Stock plans | ​ | ​ | 3,295 | ​ | 2,782 | ​ | (504) | ​ | 3,215 |
| Ending balance | ​ | ​ | 311,438 | ​ | 308,065 | ​ | 311,438 | ​ | 308,065 |
| Retained earnings | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | 1,104,359 | ​ | 1,002,420 | ​ | 1,082,950 | ​ | 989,315 |
| Net earnings common stockholders | ​ | ​ | 31,033 | ​ | 23,219 | ​ | 54,506 | ​ | 38,388 |
| Dividends paid | ​ | ​ | (2,066) | ​ | (2,061) | ​ | (4,130) | ​ | (4,125) |
| Ending balance | ​ | ​ | 1,133,326 | ​ | 1,023,578 | ​ | 1,133,326 | ​ | 1,023,578 |
| Accumulated other comprehensive income (loss) | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | (28,803) | ​ | (14,555) | ​ | (10,775) | ​ | (23,969) |
| Foreign currency translation | ​ | ​ | 8,133 | ​ | (4,745) | ​ | (9,895) | ​ | 4,669 |
| Ending balance | ​ | ​ | (20,670) | ​ | (19,300) | ​ | (20,670) | ​ | (19,300) |
| Treasury stock | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | (147,075) | ​ | (139,362) | ​ | (147,075) | ​ | (139,362) |
| Share repurchases | ​ | ​ | — | ​ | (6,879) | ​ | — | ​ | (6,879) |
| Ending balance | ​ | ​ | (147,075) | ​ | (146,241) | ​ | (147,075) | ​ | (146,241) |
| Total equity | ​ | ​ | 1,277,328 | ​ | 1,166,410 | ​ | 1,277,328 | ​ | 1,166,410 |


## us-gaap:FairValueDisclosuresTextBlock

[0001410578-25-001145:notes:45]
[same as prior period, unchanged from 0001410578-25-000100:notes:45]

[0001410578-25-001145:notes:46]
[same as prior period, unchanged from 0001410578-25-000100:notes:46]

[0001410578-25-001145:notes:47]
[same as prior period, unchanged from 0001410578-25-000100:notes:47]

[0001410578-25-001145:notes:48]
[same as prior period, unchanged from 0001410578-25-000100:notes:48]

[0001410578-25-001145:notes:49]
[same as prior period, unchanged from 0001410578-25-000100:notes:49]

[0001410578-25-001145:notes:50]
[same as prior period, unchanged from 0001410578-25-000100:notes:50]

[0001410578-25-001145:notes:51]
The Company has estimated the fair value of its financial instruments as of March 31, 2025 and September 30, 2024 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001410578-25-001145:notes:52]
[same as prior period, unchanged from 0001410578-25-000100:notes:52]

[0001410578-25-001145:notes:53]
[same as prior period, unchanged from 0001410578-25-000100:notes:53]

[0001410578-25-001145:notes:54]
[same as prior period, unchanged from 0001410578-25-000100:notes:54]

[0001410578-25-001145:notes:55]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however, they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during the three and six-month periods ended March 31, 2025.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001410578-25-001145:notes:56]
[same as prior period, unchanged from 0001410578-25-000100:notes:56]

[0001410578-25-001145:notes:57]
[same as prior period, unchanged from 0001410578-25-000100:notes:57]

[0001410578-25-001145:notes:58]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2025 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue within each reportable segment.

[0001410578-25-001145:notes:59]
| Three months ended March 31, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 50,788 | ​ | $ | 89,649 | ​ | $ | 37,891 | ​ | $ | 178,328 |
| Government | ​ | ​ | 72,581 | ​ | ​ | 1,118 | ​ | ​ | 13,492 | ​ | ​ | 87,191 |
| Total revenues | ​ | $ | 123,369 | ​ | $ | 90,767 | ​ | $ | 51,383 | ​ | $ | 265,519 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 98,335 | ​ | $ | 54,944 | ​ | $ | 32,267 | ​ | $ | 185,546 |
| International | ​ | ​ | 25,034 | ​ | ​ | 35,823 | ​ | ​ | 19,116 | ​ | ​ | 79,973 |
| Total revenues | ​ | $ | 123,369 | ​ | $ | 90,767 | ​ | $ | 51,383 | ​ | $ | 265,519 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 56,052 | ​ | $ | 73,002 | ​ | $ | 11,607 | ​ | $ | 140,661 |
| Over time | ​ | ​ | 67,317 | ​ | ​ | 17,765 | ​ | ​ | 39,776 | ​ | ​ | 124,858 |
| Total revenues | ​ | $ | 123,369 | ​ | $ | 90,767 | ​ | $ | 51,383 | ​ | $ | 265,519 |

[0001410578-25-001145:notes:60]
| Six months ended March 31, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 98,288 | ​ | $ | 173,928 | ​ | $ | 74,240 | ​ | $ | 346,456 |
| Government | ​ | ​ | 139,382 | ​ | ​ | 3,499 | ​ | ​ | 23,208 | ​ | ​ | 166,089 |
| Total revenues | ​ | $ | 237,670 | ​ | $ | 177,427 | ​ | $ | 97,448 | ​ | $ | 512,545 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 195,038 | ​ | $ | 114,860 | ​ | $ | 60,897 | ​ | $ | 370,795 |
| International | ​ | ​ | 42,632 | ​ | ​ | 62,567 | ​ | ​ | 36,551 | ​ | ​ | 141,750 |
| Total revenues | ​ | $ | 237,670 | ​ | $ | 177,427 | ​ | $ | 97,448 | ​ | $ | 512,545 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 106,178 | ​ | $ | 142,280 | ​ | $ | 21,398 | ​ | $ | 269,856 |
| Over time | ​ | ​ | 131,492 | ​ | ​ | 35,147 | ​ | ​ | 76,050 | ​ | ​ | 242,689 |
| Total revenues | ​ | $ | 237,670 | ​ | $ | 177,427 | ​ | $ | 97,448 | ​ | $ | 512,545 |

[0001410578-25-001145:notes:61]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2024 are presented in the tables below.

[0001410578-25-001145:notes:62]
| Three months ended March 31, 2024 | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 49,382 | ​ | $ | 85,220 | ​ | $ | 34,537 | ​ | $ | 169,139 |
| Government | ​ | ​ | 65,319 | ​ | ​ | 2,089 | ​ | ​ | 12,582 | ​ | ​ | 79,990 |
| Total revenues | ​ | $ | 114,701 | ​ | $ | 87,309 | ​ | $ | 47,119 | ​ | $ | 249,129 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 92,161 | ​ | $ | 55,763 | ​ | $ | 27,543 | ​ | $ | 175,467 |
| International | ​ | ​ | 22,540 | ​ | ​ | 31,546 | ​ | ​ | 19,576 | ​ | ​ | 73,662 |
| Total revenues | ​ | $ | 114,701 | ​ | $ | 87,309 | ​ | $ | 47,119 | ​ | $ | 249,129 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 53,463 | ​ | $ | 70,285 | ​ | $ | 10,301 | ​ | $ | 134,049 |
| Over time | ​ | ​ | 61,238 | ​ | ​ | 17,024 | ​ | ​ | 36,818 | ​ | ​ | 115,080 |
| Total revenues | ​ | $ | 114,701 | ​ | $ | 87,309 | ​ | $ | 47,119 | ​ | $ | 249,129 |

[0001410578-25-001145:notes:63]
| Six months ended March 31, 2024 | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 86,591 | ​ | $ | 166,689 | ​ | $ | 69,615 | ​ | $ | 322,895 |
| Government | ​ |  | 122,843 | ​ |  | 3,604 | ​ |  | 18,101 | ​ |  | 144,548 |
| Total revenues | ​ | $ | 209,434 | ​ | $ | 170,293 | ​ | $ | 87,716 | ​ | $ | 467,443 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 172,062 | ​ | $ | 111,725 | ​ | $ | 49,795 | ​ | $ | 333,582 |
| International | ​ |  | 37,372 | ​ |  | 58,568 | ​ |  | 37,921 | ​ |  | 133,861 |
| Total revenues | ​ | $ | 209,434 | ​ | $ | 170,293 | ​ | $ | 87,716 | ​ | $ | 467,443 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 92,928 | ​ | $ | 136,989 | ​ | $ | 18,280 | ​ | $ | 248,197 |
| Over time | ​ |  | 116,506 | ​ |  | 33,304 | ​ |  | 69,436 | ​ |  | 219,246 |
| Total revenues | ​ | $ | 209,434 | ​ | $ | 170,293 | ​ | $ | 87,716 | ​ | $ | 467,443 |

[0001410578-25-001145:notes:64]
[same as prior period, unchanged from 0001410578-25-000100:notes:62]

[0001410578-25-001145:notes:65]
[same as prior period, unchanged from 0001410578-25-000100:notes:63]

[0001410578-25-001145:notes:66]
[same as prior period, unchanged from 0001410578-25-000100:notes:64]

[0001410578-25-001145:notes:67]
[same as prior period, unchanged from 0001410578-25-000100:notes:65]

[0001410578-25-001145:notes:68]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At March 31, 2025, the Company had $932.3 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 74% in the next twelve months.

[0001410578-25-001145:notes:69]
[same as prior period, unchanged from 0001410578-25-000100:notes:67]

[0001410578-25-001145:notes:70]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At March 31, 2025, contract assets, contract liabilities and accounts receivable totaled $125.3 million, $138.5 million and $218.1 million, respectively. During the first six months of 2025, the Company recognized approximately $56 million in revenues that were included in the contract liabilities balance at September 30, 2024. At September 30, 2024, contract assets, contract liabilities and accounts receivable totaled $130.5 million, $134.3 million and $240.7 million, respectively.


## ese:OperatingAndFinancingLeasesOfLesseeDisclosureTextBlock

[0001410578-25-001145:notes:71]
[same as prior period, unchanged from 0001410578-25-000100:notes:69]

[0001410578-25-001145:notes:72]
[same as prior period, unchanged from 0001410578-25-000100:notes:70]

[0001410578-25-001145:notes:73]
[same as prior period, unchanged from 0001410578-25-000100:notes:71]

[0001410578-25-001145:notes:74]
In addition to the base rent, real estate leases typically contain provisions for common-area maintenance and other similar services, which are considered non-lease components for accounting purposes. Non-lease components are excluded from our ROU assets and lease liabilities and expensed as incurred.

[0001410578-25-001145:notes:75]
[same as prior period, unchanged from 0001410578-25-000100:notes:73]

[0001410578-25-001145:notes:76]
[same as prior period, unchanged from 0001410578-25-000100:notes:74]

[0001410578-25-001145:notes:77]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended |
| ​ | ​ | March 31, | ​ | March 31, |
| (Dollars in thousands) |  | 2025 |  | 2024 |
| Finance lease cost | ​ | ​ | ​ | ​ | ​ | ​ |
| Amortization of right-of-use assets | ​ | $ | 372 | ​ | $ | 372 |
| Interest on lease liabilities | ​ | ​ | 202 | ​ | ​ | 216 |
| Operating lease cost | ​ | ​ | 2,000 | ​ | ​ | 1,874 |
| Total lease costs | ​ | $ | 2,574 | ​ | $ | 2,462 |

[0001410578-25-001145:notes:78]
| ​ | ​ | Six Months Ended | ​ | Six Months Ended |
| ​ | ​ | March 31, | ​ | March 31, |
| (Dollars in thousands) |  | 2025 |  | 2024 |
| Finance lease cost | ​ | ​ | ​ | ​ | ​ | ​ |
| Amortization of right-of-use assets |  | $ | 744 |  | $ | 765 |
| Interest on lease liabilities | ​ | ​ | 408 | ​ | ​ | 439 |
| Operating lease cost | ​ | ​ | 3,999 | ​ | ​ | 3,738 |
| Total lease costs |  | $ | 5,151 |  | $ | 4,942 |

[0001410578-25-001145:notes:79]
[same as prior period, unchanged from 0001410578-25-000100:notes:76]

[0001410578-25-001145:notes:80]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended |
| ​ | ​ | March 31, | ​ | March 31, |
| (Dollars in thousands) |  | 2025 |  | 2024 |
| Cash paid for amounts included in the measurement of lease liabilities | ​ | ​ | ​ | ​ | ​ | ​ |
| Operating cash flows from operating leases | ​ | $ | 1,937 | ​ | $ | 1,824 |
| Operating cash flows from finance leases | ​ | ​ | 202 | ​ | ​ | 216 |
| Financing cash flows from finance leases | ​ | ​ | 355 | ​ | ​ | 328 |
| Right-of-use assets obtained in exchange for operating lease liabilities | ​ | ​ | 1,040 | ​ | ​ | 1,679 |

[0001410578-25-001145:notes:81]
| ​ | ​ | Six Months Ended | ​ | Six Months Ended |
| ​ | ​ | March 31, | ​ | March 31, |
| (Dollars in thousands) |  | 2025 |  | 2024 |
| Cash paid for amounts included in the measurement of lease liabilities | ​ | ​ | ​ | ​ | ​ | ​ |
| Operating cash flows from operating leases | ​ | $ | 3,851 | ​ | $ | 3,643 |
| Operating cash flows from finance leases | ​ |  | 408 | ​ |  | 439 |
| Financing cash flows from finance leases | ​ |  | 706 | ​ |  | 683 |
| Right-of-use assets obtained in exchange for operating lease liabilities | ​ | ​ | 4,508 | ​ | ​ | 1,679 |

[0001410578-25-001145:notes:82]
| ​ | ​ | March 31, |  | March 31, | ​ |
| ​ |  | 2025 | ​ | 2024 | ​ |
| Weighted-average remaining lease term | ​ |  | ​ |  | ​ |
| Operating leases |  | 10.2 | years | 10.8 | years |
| Finance leases |  | 10.0 | years | 11.1 | years |
| Weighted-average discount rate |  | ​ |  | ​ |  |
| Operating leases |  | 4.70 | % | 4.55 | % |
| Finance leases |  | 4.72 | % | 4.68 | % |

[0001410578-25-001145:notes:83]
The following is a reconciliation of future undiscounted cash flows to the operating and finance lease liabilities, and the related ROU assets, presented on our Consolidated Balance Sheet on March 31, 2025:

[0001410578-25-001145:notes:84]
| (Dollars in thousands) | ​ | Operating |  | Finance |
| Years Ending September 30: |  | Leases |  | Leases |
| 2025 (excluding the six months ended March 31, 2025) | ​ | $ | 3,531 | ​ | 1,118 |
| 2026 | ​ | ​ | 5,402 | ​ | 2,297 |
| 2027 | ​ | ​ | 5,125 | ​ | 2,357 |
| 2028 | ​ | ​ | 5,041 | ​ | 2,417 |
| 2029 and thereafter | ​ | ​ | 32,710 | ​ | 14,053 |
| Total minimum lease payments | ​ | ​ | 51,809 | ​ | 22,242 |
| Less: amounts representing interest | ​ | ​ | 11,246 | ​ | 4,965 |
| Present value of net minimum lease payments | ​ | $ | 40,563 | ​ | 17,277 |
| Less: current portion of lease obligations | ​ | ​ | 4,615 | ​ | 1,491 |
| Non-current portion of lease obligations | ​ | ​ | 35,948 | ​ | 15,786 |
| ROU assets | ​ | $ | 38,322 | ​ | 12,938 |

[0001410578-25-001145:notes:85]
Operating lease liabilities are included in the Consolidated Balance Sheet in accrued other expenses (current portion) and as a caption on the Consolidated Balance Sheet (long-term portion). Finance lease liabilities are included on the Consolidated Balance Sheet in accrued other expenses (current portion) and other liabilities (long-term portion). Operating lease ROU assets are included as a caption on the Consolidated Balance Sheet and finance lease ROU assets are included in Property, plant and equipment on the Consolidated Balance sheet.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001410578-25-001145:notes:86]
13.  NEW ACCOUNTING PRONOUNCEMENTS

[0001410578-25-001145:notes:87]
In November 2024, the FASB issued ASU 2024-03, “Disaggregation of Income Statement Expenses,” which requires disaggregated disclosure of income statement expenses for public business entities. The ASU does not change the expense captions an entity presents on the face of the income statement, rather, it requires disaggregation of certain expense captions into specified categories in disclosures within the footnotes to the financial statements. This ASU will be effective for fiscal years beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027. Other than additional disclosure, we do not expect a change to our consolidated statements of operations, financial position, or cash flows.

[0001410578-25-001145:notes:88]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures,” which provides qualitative and quantitative updates to the rate reconciliation and income taxes paid disclosures. This ASU will be effective for fiscal years beginning after December 15, 2024. Other than additional disclosure, we do not expect a change to our consolidated statements of operations, financial position, or cash flows.

[0001410578-25-001145:notes:89]
In November 2023, the FASB issued ASU 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures,” which expands annual and interim disclosure requirements for reportable segments, primarily through enhanced disclosures about significant expenses. The new segment disclosures are effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024. Other than additional disclosure, we do not expect a change to our consolidated statements of operations, financial position, or cash flows.


## us-gaap:SubsequentEventsTextBlock

[0001410578-25-001145:notes:90]
14. SUBSEQUENT EVENT

[0001410578-25-001145:notes:91]
On April 25, 2025, the Company completed the acquisition of the Signature Management & Power (SM&P) business of Ultra Maritime for a purchase price of approximately $550 million in cash. SM&P will become part of ESCO’s Aerospace & Defense (A&D) segment and will be known as ESCO Maritime Solutions (Maritime) going forward. Their Signature Management and Power Management product lines are highly complementary to ESCO’s current naval programs. Signature Management offers solutions for surface ships and submarines that provide magnetic and electric field countermeasures to prevent underwater mine and sensor detection. Power Management provides innovative and highly-engineered motors that drive critical ship propulsion systems with an ultra-quiet design ensuring low vibration levels to increase stealth capabilities.
