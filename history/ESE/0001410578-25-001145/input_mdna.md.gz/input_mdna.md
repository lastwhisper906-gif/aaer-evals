# ESE MD&A — 0001410578-25-001145


## mdna

[0001410578-25-001145:mdna:1]
[same as prior period, unchanged from 0001410578-25-000100:mdna:1]

[0001410578-25-001145:mdna:2]
[same as prior period, unchanged from 0001410578-25-000100:mdna:2]

[0001410578-25-001145:mdna:3]
References to the second quarters of 2025 and 2024 represent the three-month periods ended March 31, 2025 and 2024, respectively.

[0001410578-25-001145:mdna:4]
[same as prior period, unchanged from 0001410578-25-000100:mdna:4]

[0001410578-25-001145:mdna:5]
In the second quarter of 2025, sales, net earnings and diluted earnings per share were $265.5 million, $31.0 million and $1.20 per share, respectively, compared to $249.1 million, $23.2 million and $0.90 per share, respectively, in the second quarter of 2024. In the first six months of 2025, sales, net earnings and diluted earnings per share were $512.5 million, $54.5 million and $2.11 per share, respectively, compared to $467.4 million, $38.4 million and $1.49 per share, respectively, in the first six months of 2024.

[0001410578-25-001145:mdna:6]
[same as prior period, unchanged from 0001410578-25-000100:mdna:6]

[0001410578-25-001145:mdna:7]
In the second quarter of 2025, net sales of $265.5 million were $16.4 million, or 6.6%, higher than the $249.1 million in the second quarter of 2024. In the first six months of 2025, net sales of $512.5 million were $45.1 million, or 9.6%, higher than the $467.4 million in the first six months of 2024. The increase in net sales in the second quarter of 2025 as compared to the second quarter of 2024 was due to a $8.7 million increase in the A&D segment, a $4.3 million increase in the Test segment and a $3.4 million increase in the USG segment. The increase in net sales in the first six months of 2025 as compared to the first six months of 2024 was due to a $28.2 million increase in the A&D segment, a $9.7 million increase in the Test segment and a $7.1 million increase in the USG segment.

[0001410578-25-001145:mdna:8]
[same as prior period, unchanged from 0001410578-25-000100:mdna:8]

[0001410578-25-001145:mdna:9]
In the second quarter of 2025, net sales of $123.4 million were $8.7 million, or 7.6%, higher than the $114.7 million in the second quarter of 2024. In the first six months of 2025, net sales of $237.7 million were $28.3 million, or 13.5%, higher than the $209.4 million in the first six months of 2024. The sales increase in the second quarter of 2025 compared to the second quarter of 2024 was mainly due to a $7.4 million increase in commercial aerospace shipments, a $4.5 million increase in navy revenues partially offset by a $2.3 million decrease in defense aerospace shipments. The sales increase in the first six months of 2025 compared to the first six months of 2024 was mainly due to a $19.4 million increase in commercial aerospace shipments, a $17.1 million increase in navy revenues partially offset by a $5.2 million decrease in defense aerospace shipments.

[0001410578-25-001145:mdna:10]
[same as prior period, unchanged from 0001410578-25-000100:mdna:10]

[0001410578-25-001145:mdna:11]
In the second quarter of 2025, net sales of $90.8 million were $3.5 million, or 4.0%, higher than the $87.3 million in the second quarter of 2024. In the first six months of 2025, net sales of $177.4 million were $7.1 million, or 4.2%, higher than the $170.3 million in the first six months of 2024. The increase in the second quarter and first six months of 2025 compared to the corresponding periods of 2024 was mainly due to an increase in net sales at Doble driven by higher sales of offline and protection testing products and services partially offset by lower cybersecurity/compliance (DUCe) solutions.

[0001410578-25-001145:mdna:12]
[same as prior period, unchanged from 0001410578-25-000100:mdna:12]

[0001410578-25-001145:mdna:13]
In the second quarter of 2025, net sales of $51.4 million were $4.3 million, or 9.1%, higher than the $47.1 million in the second quarter of 2024. In the first six months of 2025, net sales of $97.4 million were $9.7 million, or 11.1%, higher than the $87.7 million in the first six months of 2024. The increase in the second quarter of 2025 as compared to the second quarter of 2024 was primarily due to a $6.3 million increase in sales from the Company’s U.S. and European operations due to higher Test and Measurement, industrial shielding, medical services, and filters volumes partially offset by a $2.0 million decrease in sales from the segment’s Asian operations. The increase in the first six months of 2025 compared to the first six months of 2024 was due to a $12.0 million increase in sales from the Company’s U.S. and European operations for reasons mentioned above partially offset by a $2.3 million decrease in sales from the Company’s Asian operations.

[0001410578-25-001145:mdna:14]
[same as prior period, unchanged from 0001410578-25-000100:mdna:14]

[0001410578-25-001145:mdna:15]
Backlog was $932.3 million at March 31, 2025 compared with $879.0 million at September 30, 2024. The Company received new orders totaling $290.8 million in the second quarter of 2025 compared to $239.1 million in the second quarter of 2024. Of the new orders received in the second quarter of 2025, $121.7 million related to A&D products, $92.2 million related to USG products, and $76.9 million related to Test products. Of the new orders received in the second quarter of 2024, $116.1 million related to A&D products, $79.0 million related to USG products, and $43.9 million related to Test products.

[0001410578-25-001145:mdna:16]
The Company received new orders totaling $565.8 million in the first six months of 2025 compared to $532.8 million in the first six months of 2024. Of the new orders received in the first six months of 2025, $242.3 million related to A&D products, $181.7 million related to USG products, and $141.8 million related to Test products. Of the new orders received in the first six months of 2024, $287.7 million related to A&D products, $156.0 million related to USG products, and $89.1 million related to Test products.

[0001410578-25-001145:mdna:17]
[same as prior period, unchanged from 0001410578-25-000100:mdna:16]

[0001410578-25-001145:mdna:18]
Selling, general and administrative (SG&A) expenses for the second quarter of 2025 were $58.2 million (21.9% of net sales), compared with $55.1 million (22.1% of net sales) for the second quarter of 2024. For the first six months of 2025, SG&A expenses were $116.9 million (22.8% of net sales) compared to $109.1 million (23.3% of net sales) for the first six months of 2024. The increase in SG&A in the second quarter and first six months of 2025 compared to the corresponding periods of 2024 was due to an increase within all three business segments mainly due to increased expenses related to higher sales, inflationary impacts, R&D expenses and commission expenses.

[0001410578-25-001145:mdna:19]
[same as prior period, unchanged from 0001410578-25-000100:mdna:18]

[0001410578-25-001145:mdna:20]
Amortization of intangible assets was $8.0 million and $16.0 million for the second quarter and first six months of 2025, respectively, compared to $8.6 million and $16.4 million for the corresponding periods of 2024. Amortization expenses consist of amortization of acquired intangible assets from acquisitions and other identifiable intangible assets (primarily software). The decrease in amortization expense in the second quarter and first six months of 2025 compared to the corresponding periods of 2024 was mainly due to a decrease in amortization of intangible assets related to the MPE acquisition.

[0001410578-25-001145:mdna:21]
OTHER EXPENSES (INCOME), NET

[0001410578-25-001145:mdna:22]
Other expenses, net, was $0.4 million in the second quarter of 2025 compared to $0.7 million in the second quarter of 2024. Other (income) expenses, net, was $(0.2) million in the first six months of 2025 compared to $0.9 million of expenses in the first six months of 2024. There were no individually significant items in other expenses (income), net, in the second quarter and first six months of 2025. The principal component of other expenses, net, in the second quarter and first six months of 2024 was approximately $0.5 million of restructuring charges (primarily severance) within the Test and A&D segments.

[0001410578-25-001145:mdna:23]
[same as prior period, unchanged from 0001410578-25-000100:mdna:22]

[0001410578-25-001145:mdna:24]
The Company evaluates the performance of its operating segments based on EBIT, and provides EBIT on a consolidated basis. EBIT is a non-GAAP financial measure. Please refer to the discussion of non-GAAP financial measures in Note 6 to the Consolidated Financial Statements, above. EBIT was $42.7 million (16.1% of net sales) for the second quarter of 2025 compared to $32.4 million (13.0% of net sales) for the second quarter of 2024. For the first six months of 2025, EBIT was $74.9 million (14.6% of net sales) compared to $54.6 million (11.7% of net sales) for the first six months of 2024.

[0001410578-25-001145:mdna:25]
The following table presents a reconciliation of EBIT to net earnings.

[0001410578-25-001145:mdna:26]
| ​ | ​ | Three Months Ended | ​ | Six Months Ended |
| ​ | ​ | March 31, | ​ | March 31, |
| (In thousands) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net earnings | ​ | $ | 31,033 | ​ | ​ | 23,219 | ​ | 54,506 | ​ | 38,388 |
| Plus: Interest expense, net | ​ | ​ | 2,195 | ​ | ​ | 3,226 | ​ | 4,452 | ​ | 5,893 |
| Plus: Income tax expense | ​ | ​ | 9,466 | ​ | ​ | 6,002 | ​ | 15,934 | ​ | 10,287 |
| Consolidated EBIT | ​ | $ | 42,694 | ​ | ​ | 32,447 | ​ | 74,892 | ​ | 54,568 |

[0001410578-25-001145:mdna:27]
[same as prior period, unchanged from 0001410578-25-000100:mdna:26]

[0001410578-25-001145:mdna:28]
EBIT in the second quarter of 2025 was $30.3 million (24.6% of net sales) compared to $23.4 million (20.4% of net sales) in the second quarter of 2024. EBIT in the first six months of 2025 was $51.9 million (21.8% of net sales) compared to $40.0 million (19.1% of net sales) in the first six months of 2024. The increase in EBIT in the second quarter and first six months of 2025 compared to the corresponding periods of 2024 was mainly driven by leverage on higher sales volumes, price increases and mix, partially offset by inflationary pressures. EBIT was negatively impacted by $0.3 million of restructuring charges (primarily severance) in the second quarter and first six months of 2024.

[0001410578-25-001145:mdna:29]
[same as prior period, unchanged from 0001410578-25-000100:mdna:28]

[0001410578-25-001145:mdna:30]
EBIT in the second quarter of 2025 was $20.8 million (22.9% of net sales) compared to $17.6 million (20.1% of net sales) in the second quarter of 2024. EBIT in the first six months of 2025 was $41.3 million (23.3% of net sales) compared to $35.2 million (20.7% of net sales) in the first six months of 2024. The increase in EBIT in the second quarter and first six months of 2025 compared to the corresponding periods of 2024 was mainly due to leverage on higher sales volumes at Doble, price increases and mix, partially offset by inflationary pressures.

[0001410578-25-001145:mdna:31]
[same as prior period, unchanged from 0001410578-25-000100:mdna:30]

[0001410578-25-001145:mdna:32]
EBIT in the second quarter of 2025 was $6.4 million (12.4% of net sales) compared to $5.5 million (11.8% of net sales) in the second quarter of 2024. EBIT in the first six months of 2025 was $10.8 million (11.1% of net sales) compared to $7.3 million (8.3% of net sales) in the first six months of 2024. The increase in EBIT in the second quarter and first six months of 2025 compared to the corresponding periods of 2024 was primarily due to higher sales volumes mainly from the segment’s U.S and European operations, price increases and cost reduction actions partially offset by unfavorable mix, inflationary pressures and lower sales volumes from the segment’s Asian operations. In addition, EBIT was negatively impacted by $0.4 million in the first six months of 2025 of restructuring charges (primarily severance). EBIT was negatively impacted by $0.3 million of inventory step-up charges related to the MPE acquisition and $0.2 million of restructuring charges in the first six months of 2024.

[0001410578-25-001145:mdna:33]
[same as prior period, unchanged from 0001410578-25-000100:mdna:32]

[0001410578-25-001145:mdna:34]
Corporate costs included in EBIT were $14.8 million and $29.1 million in the second quarter and first six months of 2025, respectively, compared to $14.0 million and $28.0 million in the corresponding periods of 2024. The increase in Corporate costs in the second quarter and first six months of 2025 as compared to the corresponding periods of 2024 was mainly due to an increase in share based compensation costs and acquisition costs.

[0001410578-25-001145:mdna:35]
[same as prior period, unchanged from 0001410578-25-000100:mdna:34]

[0001410578-25-001145:mdna:36]
Interest expense was $2.2 million and $4.5 million in the second quarter and first six months of 2025, respectively, and $3.2 million and $5.9 million in the corresponding periods of 2024. The decrease in interest expense in the second quarter and first six months of 2025 compared to the corresponding periods of 2024 was mainly due to lower average interest rates and lower average outstanding borrowings. The weighted average interest rates were 5.8% and 6.0% for the three and six-month periods ending March 31, 2025, respectively, and 6.8% and 6.8% for the three and six-month periods ending March 31, 2024.

[0001410578-25-001145:mdna:37]
[same as prior period, unchanged from 0001410578-25-000100:mdna:36]

[0001410578-25-001145:mdna:38]
The second quarter 2025 effective income tax rate was 23.4% compared to 20.5% in the second quarter of 2024. The effective income tax rate in the first six months of 2025 was 22.6% compared to 21.1% for the first six months of 2024. The increase in income tax expense in the second quarter and first six months of 2025 was due to prior year discrete events including the release of a foreign valuation allowance and excess tax benefit related to the vesting of share-based director compensation favorably impacting the income tax rate in the corresponding periods of 2024.

[0001410578-25-001145:mdna:39]
[same as prior period, unchanged from 0001410578-25-000100:mdna:38]

[0001410578-25-001145:mdna:40]
The Company’s overall financial position and liquidity remains strong. Working capital (current assets less current liabilities) increased to $338.7 million at March 31, 2025 from $318.8 million at September 30, 2024. Accounts receivable decreased $22.6 million during this period mainly due to a $11.3 million decrease within the USG segment, a $6.8 million decrease within the A&D segment and a $4.5 million decrease within the Test segment due to strong cash collections during the period. Inventories increased $22.0 million during this period due to a $12.1 million increase within the USG segment, a $6.4 million increase within the A&D segment and a $3.5 million increase within the Test segment primarily from an increase in finished goods and raw materials inventories due to timing of manufacturing existing orders. Accrued salaries decreased by $7.9 million during this period due to timing of salaries and bonus payments.

[0001410578-25-001145:mdna:41]
Net cash provided by operating activities was $58.3 million and $19.2 million in the first six months of 2025 and 2024, respectively. The increase in net cash provided by operating activities in the first six months of 2025 as compared to the first six months of 2024 was mainly driven by lower accounts receivable balances due to an increase in collections and higher earnings.

[0001410578-25-001145:mdna:42]
Capital expenditures were $15.4 million and $16.3 million in the first six months of 2025 and 2024, respectively. In addition, the Company incurred expenditures for capitalized software of $5.5 million and $5.9 million in the first six months of 2025 and 2024, respectively.

[0001410578-25-001145:mdna:43]
Credit Facility

[0001410578-25-001145:mdna:44]
At March 31, 2025, the Company had approximately $407 million available to borrow under its bank credit facility, a $250 million increase option, and $57.4 million cash on hand. At March 31, 2025, the Company had $88 million of outstanding borrowings under the credit facility in addition to outstanding letters of credit of $5.1 million. Cash flow from operations and borrowings under the Company’s credit facility are expected to meet the Company’s capital requirements and operational needs for the foreseeable future. The Company’s ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.

[0001410578-25-001145:mdna:45]
Subsequent Event

[0001410578-25-001145:mdna:46]
On April 25, 2025, the Company completed the acquisition of the Signature Management & Power (SM&P) business of Ultra Maritime for a purchase price of approximately $550 million in cash. SM&P will become part of ESCO’s Aerospace & Defense (A&D) segment and will be known as ESCO Maritime Solutions going forward. Their Signature Management and Power Management product lines are highly complementary to ESCO’s current naval programs. Signature Management offers solutions for surface ships and submarines that provide magnetic and electric field countermeasures to prevent underwater mine and sensor detection. Power Management provides innovative and highly-engineered motors that drive critical ship propulsion systems with an ultra-quiet design ensuring low vibration levels to increase stealth capabilities.

[0001410578-25-001145:mdna:47]
[same as prior period, unchanged from 0001410578-25-000100:mdna:46]

[0001410578-25-001145:mdna:48]
A dividend of $0.08 per share, totaling $2.1 million, was paid on October 16, 2024 to stockholders of record as of October 2, 2024. A dividend of $0.08 per share, totaling $2.1 million, was paid on January 17, 2025 to stockholders of record as of January 2, 2025. Subsequent to March 31, 2025, a quarterly dividend of $0.08 per share, totaling $2.1 million, was paid on April 17, 2025 to stockholders of record as of April 2, 2025.

[0001410578-25-001145:mdna:49]
[same as prior period, unchanged from 0001410578-25-000100:mdna:48]

[0001410578-25-001145:mdna:50]
Management has evaluated the accounting policies used in the preparation of the Company’s financial statements and related notes and believes those policies to be reasonable and appropriate. Certain of these accounting policies require the application of significant judgment by Management in selecting appropriate assumptions for calculating financial estimates. By their nature, these judgments are subject to an inherent degree of uncertainty. These judgments are based on historical experience, trends in the industry, information provided by customers and information available from other outside sources, as appropriate. The most significant areas involving Management judgments and estimates may be found in the Critical Accounting Policies section of Management’s Discussion and Analysis and in Note 1 to the Consolidated Financial Statements contained in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2024.

[0001410578-25-001145:mdna:51]
[same as prior period, unchanged from 0001410578-25-000100:mdna:51]

[0001410578-25-001145:mdna:52]
Contingencies

[0001410578-25-001145:mdna:53]
As a normal incident of the business in which the Company is engaged, various claims, charges and litigation are asserted or commenced against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. In the opinion of Management, the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company, are adequately reserved, are covered by insurance, or would not have a material adverse effect on the Company’s results from operations, capital expenditures, or competitive position.

[0001410578-25-001145:mdna:54]
[same as prior period, unchanged from 0001410578-25-000100:mdna:54]

[0001410578-25-001145:mdna:55]
Investors are cautioned that such statements are only predictions and speak only as of the date of this Form 10-Q, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment, including but not limited to those described in Item 1A, “Risk Factors,” of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2024, and the following: the impacts of climate change and related regulation of greenhouse gases; the impacts of labor disputes, civil disorder, wars, elections, political changes, tariffs and trade disputes, terrorist activities, cyberattacks or natural disasters on the Company’s operations and those of the Company’s customers and suppliers; disruptions in manufacturing or delivery arrangements due to shortages or unavailability of materials or components; or supply chain disruptions; inability to access work sites; the timing and content of future contract awards or customer orders; the timely appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer contracts or orders; weakening of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties or data breaches; the availability of selected acquisitions; delivery delays or defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability of certain raw materials; material changes in the cost of credit; changes in laws and regulations including but not limited to changes in accounting standards and taxation; changes in interest, inflation and employment rates; costs relating to environmental matters arising from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the integration and performance of recently acquired businesses.
