# ESE note change history — 0001410578-25-000100 → 0001410578-25-001145


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-05-09):
[0001410578-25-001145:note_history:1]
The Company’s results for the three-month period ended March 31, 2025 are not necessarily indicative of the results for the entire 2025 fiscal year. References to the second quarters of 2025 and 2024 represent the fiscal quarters ended March 31, 2025 and 2024, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.
  (was, 2025-02-10, similarity 0.9616):
[0001410578-25-000100:note_history:1]
The Company’s results for the three-month period ended December 31, 2024 are not necessarily indicative of the results for the entire 2025 fiscal year. References to the first quarters of 2025 and 2024 represent the fiscal quarters ended December 31, 2024 and 2023, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-09):
[0001410578-25-001145:note_history:2]
| ​ |  | March 31, | ​ | September 30, |
| (In thousands) |  | 2025 |  | 2024 |
| Total borrowings | ​ | $ | 88,000 | ​ | 122,000 |
| Current portion of long-term debt | ​ | ​ | (20,000) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 68,000 | ​ | 102,000 |
  (was, 2025-02-10, similarity 0.9768):
[0001410578-25-000100:note_history:2]
| ​ |  | December 31, | ​ | September 30, |
| (In thousands) |  | 2024 |  | 2024 |
| Total borrowings | ​ | $ | 112,000 | ​ | 122,000 |
| Current portion of long-term debt | ​ | ​ | (20,000) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 92,000 | ​ | 102,000 |

- changed (2025-05-09):
[0001410578-25-001145:note_history:3]
On August 5, 2024, the Company and certain of its subsidiaries entered into Amendment No. 1 (the “Amendment”) to the Credit Facility which, among other things, (i) implements a senior incremental delayed draw term loan credit facility in an aggregate principal amount of up to $375 million (the “Incremental Facility”), and (ii) permits the direct or indirect acquisition by the Registrant or certain of its subsidiaries of all the issued and outstanding shares of Ultra PMES Limited, Measurement Systems, Inc., EMS Development Corporation, and DNE Technologies, Inc. (the “SM&P Acquisition), pursuant to and in accordance with the terms and conditions of that certain Sale and Purchase Agreement, dated July 8, 2024, among Ultra Electronics Holdings Limited, as parent seller, the Registrant, as guarantor, and certain of the Registrant’s subsidiaries as buyers. The proceeds of the loans drawn under the Incremental Facility will be applied to pay a portion of the cash consideration for the SM&P Acquisition and other customary fees, premiums, expenses and costs incurred in connection with the SM&P Acquisition.
  (was, 2025-02-10, similarity 0.9995):
[0001410578-25-000100:note_history:3]
On August 5, 2024, the Company and certain of its subsidiaries entered into Amendment No. 1 (the “Amendment”) to the Credit Facility which, among other things, (i) implements a senior incremental delayed draw term loan credit facility in an aggregate principal amount of up to $375 million (the “Incremental Facility”), and (ii) permits the direct or indirect acquisition by the Registrant or certain of its subsidiaries of all the issued and outstanding shares of Ultra PMES Limited, Measurement Systems, Inc., EMS Development Corporation, and DNE Technologies, Inc. (the “SM&P Acquisition”), pursuant to and in accordance with the terms and conditions of that certain Sale and Purchase Agreement, dated July 8, 2024, among Ultra Electronics Holdings Limited, as parent seller, the Registrant, as guarantor, and certain of the Registrant’s subsidiaries as buyers. The proceeds of the loans drawn under the Incremental Facility will be applied to pay a portion of the cash consideration for the SM&P Acquisition and other customary fees, premiums, expenses and costs incurred in connection with the SM&P Acquisition.

- changed (2025-05-09):
[0001410578-25-001145:note_history:4]
At March 31, 2025, the Company had approximately $407 million available to borrow under the Credit Facility, excluding the Incremental Facility, plus the $250 million increase option subject to the lenders’ consent, in addition to $57.4 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of March 31, 2025, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $5.1 million at March 31, 2025.
  (was, 2025-02-10, similarity 0.9622):
[0001410578-25-000100:note_history:4]
At December 31, 2024, the Company had approximately $383 million available to borrow under the Credit Facility, excluding the Incremental Facility, plus the $250 million increase option subject to the lenders’ consent, in addition to $71.3 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of December 31, 2024, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $4.8 million at December 31, 2024.

- changed (2025-05-09):
[0001410578-25-001145:note_history:5]
Interest on borrowings under the Credit Facility is calculated at a spread over either an Adjusted Term SOFR Rate, Adjusted EURIBOR Rate, Adjusted CDOR Rate, Alternate Base Rate or Daily Simple RFR, at the Company’s election. The Credit Facility also requires a facility fee ranging from 12.5 to 25 basis points per annum on the unused portion. The interest rate spreads and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio. The weighted average interest rates were 5.8% and 6.0% for the three and six-month periods ending March 31, 2025, respectively, and 6.8% and 6.8% for the three and six-month periods ending March 31, 2024. As of March 31, 2025, the Company was in compliance with all covenants.
  (was, 2025-02-10, similarity 0.9074):
[0001410578-25-000100:note_history:5]
Interest on borrowings under the Credit Facility is calculated at a spread over either an Adjusted Term SOFR Rate, Adjusted EURIBOR Rate, Adjusted CDOR Rate, Alternate Base Rate or Daily Simple RFR, at the Company’s election. The Credit Facility also requires a facility fee ranging from 12.5 to 25 basis points per annum on the unused portion. The interest rate spreads and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio. The weighted average interest rates were 6.1% and 6.8% for the three-month periods ending December 31, 2024 and 2023, respectively. As of December 31, 2024, the Company was in compliance with all covenants.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-09):
[0001410578-25-001145:note_history:6]
| ​ |  | March 31, | ​ | September 30, |
| (In thousands) |  | 2025 |  | 2024 |
| Total borrowings | ​ | $ | 88,000 | ​ | 122,000 |
| Current portion of long-term debt | ​ | ​ | (20,000) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 68,000 | ​ | 102,000 |
  (was, 2025-02-10, similarity 0.9768):
[0001410578-25-000100:note_history:6]
| ​ |  | December 31, | ​ | September 30, |
| (In thousands) |  | 2024 |  | 2024 |
| Total borrowings | ​ | $ | 112,000 | ​ | 122,000 |
| Current portion of long-term debt | ​ | ​ | (20,000) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 92,000 | ​ | 102,000 |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-09):
[0001410578-25-001145:note_history:7]
| Three months ended March 31, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 50,788 | ​ | $ | 89,649 | ​ | $ | 37,891 | ​ | $ | 178,328 |
| Government | ​ | ​ | 72,581 | ​ | ​ | 1,118 | ​ | ​ | 13,492 | ​ | ​ | 87,191 |
| Total revenues | ​ | $ | 123,369 | ​ | $ | 90,767 | ​ | $ | 51,383 | ​ | $ | 265,519 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 98,335 | ​ | $ | 54,944 | ​ | $ | 32,267 | ​ | $ | 185,546 |
| International | ​ | ​ | 25,034 | ​ | ​ | 35,823 | ​ | ​ | 19,116 | ​ | ​ | 79,973 |
| Total revenues | ​ | $ | 123,369 | ​ | $ | 90,767 | ​ | $ | 51,383 | ​ | $ | 265,519 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 56,052 | ​ | $ | 73,002 | ​ | $ | 11,607 | ​ | $ | 140,661 |
| Over time | ​ | ​ | 67,317 | ​ | ​ | 17,765 | ​ | ​ | 39,776 | ​ | ​ | 124,858 |
| Total revenues | ​ | $ | 123,369 | ​ | $ | 90,767 | ​ | $ | 51,383 | ​ | $ | 265,519 |
  (was, 2025-02-10, similarity 0.9542):
[0001410578-25-000100:note_history:7]
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 47,500 | ​ | $ | 84,279 | ​ | $ | 36,349 | ​ | $ | 168,128 |
| Government | ​ | ​ | 66,801 | ​ | ​ | 2,381 | ​ | ​ | 9,716 | ​ | ​ | 78,898 |
| Total revenues | ​ | $ | 114,301 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 247,026 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 96,703 | ​ | $ | 59,917 | ​ | $ | 28,630 | ​ | $ | 185,250 |
| International | ​ | ​ | 17,598 | ​ | ​ | 26,743 | ​ | ​ | 17,435 | ​ | ​ | 61,776 |
| Total revenues | ​ | $ | 114,301 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 247,026 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 50,126 | ​ | $ | 69,278 | ​ | $ | 9,791 | ​ | $ | 129,195 |
| Over time | ​ | ​ | 64,175 | ​ | ​ | 17,382 | ​ | ​ | 36,274 | ​ | ​ | 117,831 |
| Total revenues | ​ | $ | 114,301 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 247,026 |

- changed (2025-05-09):
[0001410578-25-001145:note_history:8]
| Six months ended March 31, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 98,288 | ​ | $ | 173,928 | ​ | $ | 74,240 | ​ | $ | 346,456 |
| Government | ​ | ​ | 139,382 | ​ | ​ | 3,499 | ​ | ​ | 23,208 | ​ | ​ | 166,089 |
| Total revenues | ​ | $ | 237,670 | ​ | $ | 177,427 | ​ | $ | 97,448 | ​ | $ | 512,545 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 195,038 | ​ | $ | 114,860 | ​ | $ | 60,897 | ​ | $ | 370,795 |
| International | ​ | ​ | 42,632 | ​ | ​ | 62,567 | ​ | ​ | 36,551 | ​ | ​ | 141,750 |
| Total revenues | ​ | $ | 237,670 | ​ | $ | 177,427 | ​ | $ | 97,448 | ​ | $ | 512,545 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 106,178 | ​ | $ | 142,280 | ​ | $ | 21,398 | ​ | $ | 269,856 |
| Over time | ​ | ​ | 131,492 | ​ | ​ | 35,147 | ​ | ​ | 76,050 | ​ | ​ | 242,689 |
| Total revenues | ​ | $ | 237,670 | ​ | $ | 177,427 | ​ | $ | 97,448 | ​ | $ | 512,545 |
  (was, 2025-02-10, similarity 0.9561):
[0001410578-25-000100:note_history:8]
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 37,209 | ​ | $ | 81,469 | ​ | $ | 35,087 | ​ | $ | 153,765 |
| Government | ​ | ​ | 57,524 | ​ | ​ | 1,515 | ​ | ​ | 5,510 | ​ | ​ | 64,549 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 79,901 | ​ | $ | 55,961 | ​ | $ | 22,252 | ​ | $ | 158,114 |
| International | ​ | ​ | 14,832 | ​ | ​ | 27,023 | ​ | ​ | 18,345 | ​ | ​ | 60,200 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 39,465 | ​ | $ | 66,703 | ​ | $ | 7,980 | ​ | $ | 114,148 |
| Over time | ​ | ​ | 55,268 | ​ | ​ | 16,281 | ​ | ​ | 32,617 | ​ | ​ | 104,166 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |

- added (2025-05-09):
[0001410578-25-001145:note_history:9]
| Three months ended March 31, 2024 | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 49,382 | ​ | $ | 85,220 | ​ | $ | 34,537 | ​ | $ | 169,139 |
| Government | ​ | ​ | 65,319 | ​ | ​ | 2,089 | ​ | ​ | 12,582 | ​ | ​ | 79,990 |
| Total revenues | ​ | $ | 114,701 | ​ | $ | 87,309 | ​ | $ | 47,119 | ​ | $ | 249,129 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 92,161 | ​ | $ | 55,763 | ​ | $ | 27,543 | ​ | $ | 175,467 |
| International | ​ | ​ | 22,540 | ​ | ​ | 31,546 | ​ | ​ | 19,576 | ​ | ​ | 73,662 |
| Total revenues | ​ | $ | 114,701 | ​ | $ | 87,309 | ​ | $ | 47,119 | ​ | $ | 249,129 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 53,463 | ​ | $ | 70,285 | ​ | $ | 10,301 | ​ | $ | 134,049 |
| Over time | ​ | ​ | 61,238 | ​ | ​ | 17,024 | ​ | ​ | 36,818 | ​ | ​ | 115,080 |
| Total revenues | ​ | $ | 114,701 | ​ | $ | 87,309 | ​ | $ | 47,119 | ​ | $ | 249,129 |

- added (2025-05-09):
[0001410578-25-001145:note_history:10]
| Six months ended March 31, 2024 | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 86,591 | ​ | $ | 166,689 | ​ | $ | 69,615 | ​ | $ | 322,895 |
| Government | ​ |  | 122,843 | ​ |  | 3,604 | ​ |  | 18,101 | ​ |  | 144,548 |
| Total revenues | ​ | $ | 209,434 | ​ | $ | 170,293 | ​ | $ | 87,716 | ​ | $ | 467,443 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 172,062 | ​ | $ | 111,725 | ​ | $ | 49,795 | ​ | $ | 333,582 |
| International | ​ |  | 37,372 | ​ |  | 58,568 | ​ |  | 37,921 | ​ |  | 133,861 |
| Total revenues | ​ | $ | 209,434 | ​ | $ | 170,293 | ​ | $ | 87,716 | ​ | $ | 467,443 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 92,928 | ​ | $ | 136,989 | ​ | $ | 18,280 | ​ | $ | 248,197 |
| Over time | ​ |  | 116,506 | ​ |  | 33,304 | ​ |  | 69,436 | ​ |  | 219,246 |
| Total revenues | ​ | $ | 209,434 | ​ | $ | 170,293 | ​ | $ | 87,716 | ​ | $ | 467,443 |

- removed (2025-05-09):
[0001410578-25-000100:note_history:11]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2024 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within each reportable segment.

- removed (2025-05-09):
[0001410578-25-000100:note_history:12]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2023 are presented in the table below:


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-09):
[0001410578-25-001145:note_history:13]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2025 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue within each reportable segment.
  (was, 2025-02-10, similarity 0.953):
[0001410578-25-000100:note_history:13]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2024 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within each reportable segment.

- changed (2025-05-09):
[0001410578-25-001145:note_history:14]
| Three months ended March 31, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 50,788 | ​ | $ | 89,649 | ​ | $ | 37,891 | ​ | $ | 178,328 |
| Government | ​ | ​ | 72,581 | ​ | ​ | 1,118 | ​ | ​ | 13,492 | ​ | ​ | 87,191 |
| Total revenues | ​ | $ | 123,369 | ​ | $ | 90,767 | ​ | $ | 51,383 | ​ | $ | 265,519 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 98,335 | ​ | $ | 54,944 | ​ | $ | 32,267 | ​ | $ | 185,546 |
| International | ​ | ​ | 25,034 | ​ | ​ | 35,823 | ​ | ​ | 19,116 | ​ | ​ | 79,973 |
| Total revenues | ​ | $ | 123,369 | ​ | $ | 90,767 | ​ | $ | 51,383 | ​ | $ | 265,519 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 56,052 | ​ | $ | 73,002 | ​ | $ | 11,607 | ​ | $ | 140,661 |
| Over time | ​ | ​ | 67,317 | ​ | ​ | 17,765 | ​ | ​ | 39,776 | ​ | ​ | 124,858 |
| Total revenues | ​ | $ | 123,369 | ​ | $ | 90,767 | ​ | $ | 51,383 | ​ | $ | 265,519 |
  (was, 2025-02-10, similarity 0.9542):
[0001410578-25-000100:note_history:14]
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 47,500 | ​ | $ | 84,279 | ​ | $ | 36,349 | ​ | $ | 168,128 |
| Government | ​ | ​ | 66,801 | ​ | ​ | 2,381 | ​ | ​ | 9,716 | ​ | ​ | 78,898 |
| Total revenues | ​ | $ | 114,301 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 247,026 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 96,703 | ​ | $ | 59,917 | ​ | $ | 28,630 | ​ | $ | 185,250 |
| International | ​ | ​ | 17,598 | ​ | ​ | 26,743 | ​ | ​ | 17,435 | ​ | ​ | 61,776 |
| Total revenues | ​ | $ | 114,301 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 247,026 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 50,126 | ​ | $ | 69,278 | ​ | $ | 9,791 | ​ | $ | 129,195 |
| Over time | ​ | ​ | 64,175 | ​ | ​ | 17,382 | ​ | ​ | 36,274 | ​ | ​ | 117,831 |
| Total revenues | ​ | $ | 114,301 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 247,026 |

- changed (2025-05-09):
[0001410578-25-001145:note_history:15]
| Six months ended March 31, 2025 | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 98,288 | ​ | $ | 173,928 | ​ | $ | 74,240 | ​ | $ | 346,456 |
| Government | ​ | ​ | 139,382 | ​ | ​ | 3,499 | ​ | ​ | 23,208 | ​ | ​ | 166,089 |
| Total revenues | ​ | $ | 237,670 | ​ | $ | 177,427 | ​ | $ | 97,448 | ​ | $ | 512,545 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 195,038 | ​ | $ | 114,860 | ​ | $ | 60,897 | ​ | $ | 370,795 |
| International | ​ | ​ | 42,632 | ​ | ​ | 62,567 | ​ | ​ | 36,551 | ​ | ​ | 141,750 |
| Total revenues | ​ | $ | 237,670 | ​ | $ | 177,427 | ​ | $ | 97,448 | ​ | $ | 512,545 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 106,178 | ​ | $ | 142,280 | ​ | $ | 21,398 | ​ | $ | 269,856 |
| Over time | ​ | ​ | 131,492 | ​ | ​ | 35,147 | ​ | ​ | 76,050 | ​ | ​ | 242,689 |
| Total revenues | ​ | $ | 237,670 | ​ | $ | 177,427 | ​ | $ | 97,448 | ​ | $ | 512,545 |
  (was, 2025-02-10, similarity 0.9561):
[0001410578-25-000100:note_history:15]
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 37,209 | ​ | $ | 81,469 | ​ | $ | 35,087 | ​ | $ | 153,765 |
| Government | ​ | ​ | 57,524 | ​ | ​ | 1,515 | ​ | ​ | 5,510 | ​ | ​ | 64,549 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 79,901 | ​ | $ | 55,961 | ​ | $ | 22,252 | ​ | $ | 158,114 |
| International | ​ | ​ | 14,832 | ​ | ​ | 27,023 | ​ | ​ | 18,345 | ​ | ​ | 60,200 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 39,465 | ​ | $ | 66,703 | ​ | $ | 7,980 | ​ | $ | 114,148 |
| Over time | ​ | ​ | 55,268 | ​ | ​ | 16,281 | ​ | ​ | 32,617 | ​ | ​ | 104,166 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |

- changed (2025-05-09):
[0001410578-25-001145:note_history:16]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2024 are presented in the tables below.
  (was, 2025-02-10, similarity 0.935):
[0001410578-25-000100:note_history:16]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2023 are presented in the table below:

- added (2025-05-09):
[0001410578-25-001145:note_history:17]
| Three months ended March 31, 2024 | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 49,382 | ​ | $ | 85,220 | ​ | $ | 34,537 | ​ | $ | 169,139 |
| Government | ​ | ​ | 65,319 | ​ | ​ | 2,089 | ​ | ​ | 12,582 | ​ | ​ | 79,990 |
| Total revenues | ​ | $ | 114,701 | ​ | $ | 87,309 | ​ | $ | 47,119 | ​ | $ | 249,129 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 92,161 | ​ | $ | 55,763 | ​ | $ | 27,543 | ​ | $ | 175,467 |
| International | ​ | ​ | 22,540 | ​ | ​ | 31,546 | ​ | ​ | 19,576 | ​ | ​ | 73,662 |
| Total revenues | ​ | $ | 114,701 | ​ | $ | 87,309 | ​ | $ | 47,119 | ​ | $ | 249,129 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 53,463 | ​ | $ | 70,285 | ​ | $ | 10,301 | ​ | $ | 134,049 |
| Over time | ​ | ​ | 61,238 | ​ | ​ | 17,024 | ​ | ​ | 36,818 | ​ | ​ | 115,080 |
| Total revenues | ​ | $ | 114,701 | ​ | $ | 87,309 | ​ | $ | 47,119 | ​ | $ | 249,129 |

- added (2025-05-09):
[0001410578-25-001145:note_history:18]
| Six months ended March 31, 2024 | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 86,591 | ​ | $ | 166,689 | ​ | $ | 69,615 | ​ | $ | 322,895 |
| Government | ​ |  | 122,843 | ​ |  | 3,604 | ​ |  | 18,101 | ​ |  | 144,548 |
| Total revenues | ​ | $ | 209,434 | ​ | $ | 170,293 | ​ | $ | 87,716 | ​ | $ | 467,443 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 172,062 | ​ | $ | 111,725 | ​ | $ | 49,795 | ​ | $ | 333,582 |
| International | ​ |  | 37,372 | ​ |  | 58,568 | ​ |  | 37,921 | ​ |  | 133,861 |
| Total revenues | ​ | $ | 209,434 | ​ | $ | 170,293 | ​ | $ | 87,716 | ​ | $ | 467,443 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 92,928 | ​ | $ | 136,989 | ​ | $ | 18,280 | ​ | $ | 248,197 |
| Over time | ​ |  | 116,506 | ​ |  | 33,304 | ​ |  | 69,436 | ​ |  | 219,246 |
| Total revenues | ​ | $ | 209,434 | ​ | $ | 170,293 | ​ | $ | 87,716 | ​ | $ | 467,443 |

- changed (2025-05-09):
[0001410578-25-001145:note_history:19]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At March 31, 2025, the Company had $932.3 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 74% in the next twelve months.
  (was, 2025-02-10, similarity 0.9696):
[0001410578-25-000100:note_history:19]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to performance obligations that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At December 31, 2024, the Company had $906.9 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 72% in the next twelve months.

- changed (2025-05-09):
[0001410578-25-001145:note_history:20]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At March 31, 2025, contract assets, contract liabilities and accounts receivable totaled $125.3 million, $138.5 million and $218.1 million, respectively. During the first six months of 2025, the Company recognized approximately $56 million in revenues that were included in the contract liabilities balance at September 30, 2024. At September 30, 2024, contract assets, contract liabilities and accounts receivable totaled $130.5 million, $134.3 million and $240.7 million, respectively.
  (was, 2025-02-10, similarity 0.9742):
[0001410578-25-000100:note_history:20]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At December 31, 2024, contract assets, contract liabilities and accounts receivable totaled $131.4 million, $138.4 million and $202.7 million, respectively. During the first quarter of 2025, the Company recognized approximately $35.1 million in revenues that were included in the contract liabilities balance at September 30, 2024. At September 30, 2024, contract assets, contract liabilities and accounts receivable totaled $130.5 million, $134.3 million and $240.7 million, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2025-05-09):
[0001410578-25-001145:note_history:21]
14. SUBSEQUENT EVENT

- added (2025-05-09):
[0001410578-25-001145:note_history:22]
On April 25, 2025, the Company completed the acquisition of the Signature Management & Power (SM&P) business of Ultra Maritime for a purchase price of approximately $550 million in cash. SM&P will become part of ESCO’s Aerospace & Defense (A&D) segment and will be known as ESCO Maritime Solutions (Maritime) going forward. Their Signature Management and Power Management product lines are highly complementary to ESCO’s current naval programs. Signature Management offers solutions for surface ships and submarines that provide magnetic and electric field countermeasures to prevent underwater mine and sensor detection. Power Management provides innovative and highly-engineered motors that drive critical ship propulsion systems with an ultra-quiet design ensuring low vibration levels to increase stealth capabilities.
