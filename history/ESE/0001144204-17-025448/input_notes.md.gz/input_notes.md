# ESE notes — 0001144204-17-025448


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001144204-17-025448:notes:1]
[same as prior period, unchanged from 0001144204-17-006696:notes:17]

[0001144204-17-025448:notes:2]
[same as prior period, unchanged from 0001144204-17-006696:notes:18]

[0001144204-17-025448:notes:3]
The Company’s results for the three and six-month periods ended March 31, 2017 are not necessarily indicative of the results for the entire 2017 fiscal year. References to the second quarters of 2017 and 2016 represent the fiscal quarters ended March 31, 2017 and 2016, respectively.

[0001144204-17-025448:notes:4]
[same as prior period, unchanged from 0001144204-17-006696:notes:20]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001144204-17-025448:notes:5]
[same as prior period, unchanged from 0001144204-17-006696:notes:21]

[0001144204-17-025448:notes:6]
On November 7, 2016, the Company acquired aerospace suppliers Mayday Manufacturing Co. and its affiliate, Hi-Tech Metals, Inc. (collectively referred to as Mayday), which share a  130,000 square foot facility in Denton, Texas, for a purchase price of $75 million in cash.  Mayday Manufacturing Co. is a leading manufacturer of mission-critical bushings, pins, sleeves and precision-tolerance machined components for landing gear, rotor heads, engine mounts, flight controls, and actuation systems for the aerospace and defense industry.  Hi-Tech Metals, Inc. is a full-service metal processor offering aerospace OEM’s, Tier 1 suppliers, a large portfolio of processing services including anodizing, cadmium and zinc-nickel plating, organic coatings, non-destructive testing, and heat treatment.  Mayday has annual sales of approximately $40 million. Since the date of acquisition the consolidated operating results for Mayday have been included in the Company’s Filtration segment.  Based on the preliminary purchase price allocation, the Company recorded approximately $7.4 million of accounts receivable, $11.0 million of inventory, $16.6 million of property, plant and equipment (including a capital lease), $9.5 million of lease liability, $15.7 million of deferred tax liabilities, $30.1 million of goodwill (non-deductible for tax purposes), $4.8 million of trade names and $32.8 million of amortizable identifiable intangible assets consisting primarily of customer relationships with a weighted-average life of approximately 20 years.


## us-gaap:EarningsPerShareTextBlock

[0001144204-17-025448:notes:7]
[same as prior period, unchanged from 0001144204-17-006696:notes:23]

[0001144204-17-025448:notes:8]
[same as prior period, unchanged from 0001144204-17-006696:notes:24]

[0001144204-17-025448:notes:9]
|  |  | Three Months |  | Six Months |  |
|  |  | Ended March 31, |  | Ended March 31, |  |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |  |
| Weighted Average Shares Outstanding - Basic |  |  | 25,723 |  |  | 25,786 |  |  | 25,721 |  |  | 25,801 |  |
| Dilutive Options and Restricted Shares |  |  | 188 |  |  | 145 |  |  | 224 |  |  | 185 |  |
| Adjusted Shares - Diluted |  |  | 25,911 |  |  | 25,931 |  |  | 25,945 |  |  | 25,986 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001144204-17-025448:notes:10]
Inventories consist of the following:

[0001144204-17-025448:notes:11]
|  |  | March 31, |  | September 30, |  |
| (In thousands) |  | 2017 |  | 2016 |  |
| Finished goods |  | $ | 23,718 |  |  | 19,451 |  |
| Work in process |  |  | 44,019 |  |  | 37,922 |  |
| Raw materials |  |  | 49,772 |  |  | 48,169 |  |
| Total inventories |  | $ | 117,509 |  |  | 105,542 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001144204-17-025448:notes:12]
[same as prior period, unchanged from 0001144204-17-006696:notes:3]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001144204-17-025448:notes:13]
| 6. | GOODWILL AND OTHER INTANGIBLE ASSETS |

[0001144204-17-025448:notes:14]
Included on the Company’s Consolidated Balance Sheets at March 31, 2017 and September 30, 2016 are the following intangible assets gross carrying amounts and accumulated amortization:

[0001144204-17-025448:notes:15]
| (Dollars in thousands) |  | March 31, 2017 |  | September 30, 2016 |  |
| Goodwill |  | $ | 353,984 |  |  | 323,616 |  |
| Intangible assets with determinable lives: |  |  |  |  |  |  |  |
| Patents |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 931 |  |  | 917 |  |
| Less: accumulated amortization |  |  | 751 |  |  | 726 |  |
| Net |  | $ | 180 |  |  | 191 |  |
| Capitalized software |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 57,451 |  |  | 54,003 |  |
| Less: accumulated amortization |  |  | 30,301 |  |  | 26,737 |  |
| Net |  | $ | 27,150 |  |  | 27,266 |  |
| Customer relationships |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 144,287 |  |  | 111,887 |  |
| Less: accumulated amortization |  |  | 32,244 |  |  | 28,633 |  |
| Net |  | $ | 112,043 |  |  | 83,254 |  |
| Other |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 3,178 |  |  | 2,777 |  |
| Less: accumulated amortization |  |  | 1,084 |  |  | 859 |  |
| Net |  | $ | 2,094 |  |  | 1,918 |  |
| Intangible assets with indefinite lives: |  |  |  |  |  |  |  |
| Trade names |  | $ | 123,807 |  |  | 119,128 |  |

[0001144204-17-025448:notes:16]
The changes in the carrying amount of goodwill attributable to each business segment for the six months ended March 31, 2017 is as follows:

[0001144204-17-025448:notes:17]
| (Dollars in millions) |  | USG |  | Test |  | Filtration |  | Packaging |  | Total |  |
| Balance as of September 30, 2016 |  |  | 226.2 |  |  | 34.1 |  |  | 43.9 |  |  | 19.4 |  |  | 323.6 |  |
| Acquisition activity |  |  | - |  |  | - |  |  | 30.7 |  |  |  |  |  | 30.7 |  |
| Foreign currency translation |  |  | - |  |  | - |  |  | - |  |  | (0.3) |  |  | (0.3) |  |
| Balance as of March 31, 2017 |  | $ | 226.2 |  |  | 34.1 |  |  | 74.6 |  |  | 19.1 |  |  | 354.0 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001144204-17-025448:notes:18]
Management evaluates and measures the performance of its reportable segments based on “Net Sales” and “EBIT”, which are detailed in the table below. EBIT is defined as earnings before interest and taxes.

[0001144204-17-025448:notes:19]
|  |  | Three Months |  | Six Months |  |
| (In thousands) |  | Ended March 31, |  | Ended March 31, |  |
|  |  | 2017 | 2016 |  | 2017 | 2016 |  |
| NET SALES |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 68,906 |  |  | 49,045 |  |  | 127,690 |  |  | 91,361 |  |
| Test |  |  | 38,367 |  |  | 40,601 |  |  | 72,194 |  |  | 83,374 |  |
| USG |  |  | 32,671 |  |  | 30,014 |  |  | 68,228 |  |  | 64,537 |  |
| Technical Packaging |  |  | 21,234 |  |  | 19,270 |  |  | 39,434 |  |  | 32,491 |  |
| Consolidated totals |  | $ | 161,178 |  |  | 138,930 |  |  | 307,546 |  |  | 271,763 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 11,625 |  |  | 9,064 |  |  | 22,351 |  |  | 17,348 |  |
| Test |  |  | 3,766 |  |  | 2,505 |  |  | 6,191 |  |  | 4,843 |  |
| USG |  |  | 7,434 |  |  | 7,208 |  |  | 17,108 |  |  | 15,457 |  |
| Technical Packaging |  |  | 2,196 |  |  | 2,747 |  |  | 3,227 |  |  | 4,560 |  |
| Corporate (loss) |  |  | (7,347) |  |  | (7,541) |  |  | (14,394) |  |  | (15,028) |  |
| Consolidated EBIT |  |  | 17,674 |  |  | 13,983 |  |  | 34,483 |  |  | 27,180 |  |
| Less: Interest expense |  |  | (855) |  |  | (368) |  |  | (1,539) |  |  | (597) |  |
| Earnings before income taxes |  | $ | 16,819 |  |  | 13,615 |  |  | 32,944 |  |  | 26,583 |  |


## us-gaap:DebtDisclosureTextBlock

[0001144204-17-025448:notes:20]
| 8. | DEBT |

[0001144204-17-025448:notes:21]
The Company’s debt is summarized as follows:

[0001144204-17-025448:notes:22]
|  |  | March 31, | September 30, |  |
| (In thousands) |  | 2017 | 2016 |  |
| Total borrowings |  | $ | 170,000 |  |  | 110,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 150,000 |  |  | 90,000 |  |

[0001144204-17-025448:notes:23]
The Company’s existing credit facility maturity date is December 21, 2020. The credit facility includes a $450 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of nine banks led by JPMorgan Chase Bank, N.A., as Administrative Agent.

[0001144204-17-025448:notes:24]
At March 31, 2017, the Company had approximately $276 million available to borrow under the Credit Facility, and a $250 million increase option, in addition to $53.5 million cash on hand. At March 31, 2017, the Company had $170 million of outstanding borrowings under the credit facility in addition to outstanding letters of credit of $4.6 million. The Company classified $20.0 million as the current portion of long-term debt as of March 31, 2017, as the Company intends to repay this amount within the next twelve month period; however, the Company has no contractual obligation to repay such amount during the next twelve month period.

[0001144204-17-025448:notes:25]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from  12.5 to  27.5 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a  65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were  1.89% and  1.76% for the three and six-month periods ending March 31, 2017, respectively, and  1.76% and  1.61% for the corresponding periods of 2016. At March 31, 2017, the Company was in compliance with all debt covenants.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001144204-17-025448:notes:26]
| 9. | INCOME TAX EXPENSE |

[0001144204-17-025448:notes:27]
The second quarter 2017 effective income tax rate was  33.7% compared to  36.8% in the second quarter of 2016. The effective income tax rate for the first six months of 2017 was  33.6% compared to  34.4% for the first six months of 2016. The income tax expense in the second quarter and first six months of 2017 was unfavorably impacted by a decrease in the foreign tax rate benefit of  0.8% and  1.4%, respectively.

[0001144204-17-025448:notes:28]
The income tax expense in the second quarter and first six months of 2016 was unfavorably impacted by a U.K. foreign valuation allowance that increased the second quarter and year-to-date effective tax rate by  4.8% and  2.5%, respectively. The income tax expense in the first six months of 2016 was favorably impacted by the extension of the research credit as a result of The Protecting Americans from Tax Hikes Act reducing the year-to-date effective tax rate by  3.0%. The income tax expense in the first six months of 2016 was unfavorably impacted by losses in foreign jurisdictions for which no tax benefit was recorded, increasing the year-to-date effective tax rate by  2.8%.

[0001144204-17-025448:notes:29]
The Company estimates the fiscal 2017 effective tax rate will be approximately  34%. During the three-month period ended March 31, 2017, there were no material changes in the unrecognized tax benefits. The Company does not anticipate a material change in the amount of unrecognized tax benefits in the next twelve months.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001144204-17-025448:notes:30]
[same as prior period, unchanged from 0001144204-17-006696:notes:64]

[0001144204-17-025448:notes:31]
The change in shareholders’ equity for the first six months of 2017 is shown below (in thousands):

[0001144204-17-025448:notes:32]
| Balance at September 30, 2016 |  | $ | 615,109 |  |
| Net earnings |  |  | 21,884 |  |
| Other comprehensive loss |  |  | (1,918) |  |
| Cash dividends |  |  | (4,123) |  |
| Stock compensation plans |  |  | 2,683 |  |
| Balance at March 31, 2017 |  | $ | 633,635 |  |


## us-gaap:ScheduleOfChangesInProjectedBenefitObligationsTableTextBlock

[0001144204-17-025448:notes:33]
A summary of net periodic benefit expense for the Company’s defined benefit plans for the three and six-month periods ended March 31, 2017 and 2016 is shown in the following table. Net periodic benefit cost for each period presented is comprised of the following:

[0001144204-17-025448:notes:34]
|  |  | Three Months |  | Six Months |  |
|  |  | Ended March 31, |  | Ended March 31, |  |
| (In thousands) |  | 2017 |  | 2016 |  | 2017 |  | 2016 |  |
| Defined benefit plans |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest cost |  | $ | 737 |  |  | 963 |  |  | 1,702 |  |  | 1,925 |  |
| Expected return on assets |  |  | (942) |  |  | (1,093) |  |  | (2,036) |  |  | (2,187) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior service cost |  |  | - |  |  | 3 |  |  | 3 |  |  | 7 |  |
| Actuarial loss |  |  | 683 |  |  | 486 |  |  | 1,188 |  |  | 972 |  |
| Net periodic benefit cost |  | $ | 478 |  |  | 359 |  |  | 857 |  |  | 717 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001144204-17-025448:notes:35]
| 12. | DERIVATIVE FINANCIAL INSTRUMENTS |

[0001144204-17-025448:notes:36]
[same as prior period, unchanged from 0001144204-17-006696:notes:50]

[0001144204-17-025448:notes:37]
The following is a summary of the notional transaction amounts and fair values for the Company’s outstanding derivative financial instruments by risk category and instrument type as of March 31, 2017:

[0001144204-17-025448:notes:38]
|  |  | Notional |  | Fair |  |
|  |  | amount |  | Value |  |
| (In thousands) |  | (GBP) |  | (US$) |  |
| Forward contracts |  |  | 1,859 |  |  | (318) |  |


## us-gaap:ScheduleOfDerivativeLiabilitiesAtFairValueTableTextBlock

[0001144204-17-025448:notes:39]
The Company’s forward contracts are classified within Level 2 of the valuation hierarchy in accordance with FASB Accounting Standards Codification (ASC) 825, as presented below as of March 31, 2017:

[0001144204-17-025448:notes:40]
| (In thousands) |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Forward contracts |  | $ | - |  |  | (318) |  | $ | - |  |  | (318) |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001144204-17-025448:notes:41]
[same as prior period, unchanged from 0001144204-17-006696:notes:51]

[0001144204-17-025448:notes:42]
[same as prior period, unchanged from 0001144204-17-006696:notes:52]

[0001144204-17-025448:notes:43]
|  | ⋅ | Level 1 – inputs to the valuation methodology are quoted prices (unadjusted) for identical assets or liabilities in active markets. |

[0001144204-17-025448:notes:44]
|  | ⋅ | Level 2 – inputs to the valuation methodology include quoted prices for similar assets and liabilities in active markets, and inputs that are observable for the asset or liability, either directly or indirectly, for substantially the full term of the financial instrument. |

[0001144204-17-025448:notes:45]
|  | ⋅ | Level 3 – inputs to the valuation methodology are unobservable and significant to the fair value measurement. |

[0001144204-17-025448:notes:46]
[same as prior period, unchanged from 0001144204-17-006696:notes:56]

[0001144204-17-025448:notes:47]
The Company has estimated the fair value of its financial instruments as of March 31, 2017 and September 30, 2016 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, debt and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001144204-17-025448:notes:48]
[same as prior period, unchanged from 0001144204-17-006696:notes:58]

[0001144204-17-025448:notes:49]
[same as prior period, unchanged from 0001144204-17-006696:notes:59]

[0001144204-17-025448:notes:50]
[same as prior period, unchanged from 0001144204-17-006696:notes:60]

[0001144204-17-025448:notes:51]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during the three and six-month periods ended March 31, 2017.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001144204-17-025448:notes:52]
|  | 7. | BUSINESS SEGMENT INFORMATION |

[0001144204-17-025448:notes:53]
The Company is organized based on the products and services that it offers, and classifies its business operations in four segments for financial reporting purposes: Filtration/Fluid Flow (Filtration), RF Shielding and Test (Test), Utility Solutions Group (USG) and Technical Packaging. The Filtration segment’s operations consist of PTI Technologies Inc. (PTI), VACCO Industries (VACCO), Crissair, Inc. (Crissair), Westland Technologies Inc. (Westland), Mayday and its affiliate Hi-Tech. The companies within this segment primarily design and manufacture specialty filtration products, including hydraulic filter elements used in commercial aerospace applications, unique filter mechanisms used in micro-propulsion devices for satellites and custom designed filters for manned and unmanned aircraft; manufacture elastomeric-based signature reduction solutions for the U.S. Navy; and manufacture landing gear components for the aerospace and defense industry. The Test segment’s operations consist primarily of ETS-Lindgren Inc. (ETS-Lindgren). ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy. The USG segment’s operations consist primarily of Doble Engineering Company (Doble). Doble provides high-end, intelligent diagnostic test solutions for the electric power delivery industry and is a leading supplier of partial discharge testing instruments used to assess the integrity of high voltage power delivery equipment. The Technical Packaging segment’s operations consist of Thermoform Engineered Quality LLC (TEQ) and Plastique Limited and Plastique Sp. zoo (together, Plastique). The companies within this segment provide innovative solutions to the medical and commercial markets for thermoformed packages and specialty products using a wide variety of thin gauge plastics and pulp.

[0001144204-17-025448:notes:54]
[same as prior period, unchanged from 0001144204-17-006696:notes:39]

[0001144204-17-025448:notes:55]
The financial measure “EBIT” is presented in the above table and elsewhere in this Report. EBIT on a consolidated basis is a non-GAAP financial measure. Management believes that EBIT is useful in assessing the operational profitability of the Company’s business segments because it excludes interest and taxes, which are generally accounted for across the entire Company on a consolidated basis. EBIT is also one of the measures used by management in determining resource allocations within the Company as well as incentive compensation. A reconciliation of EBIT to net earnings is set forth in Item 2, Management’s Discussion and Analysis of Financial Condition and Results of Operations – EBIT.

[0001144204-17-025448:notes:56]
The Company believes that the presentation of EBIT provides important supplemental information to investors to facilitate comparisons with other companies, many of which use similar non-GAAP financial measures to supplement their GAAP results. However, the Company’s non-GAAP financial measures may not be comparable to other companies’ non-GAAP financial performance measures. Furthermore, the use of non-GAAP financial measures is not intended to replace any measures of performance determined in accordance with GAAP.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001144204-17-025448:notes:57]
4.      SHARE-BASED COMPENSATION

[0001144204-17-025448:notes:58]
[same as prior period, unchanged from 0001144204-17-006696:notes:26]

[0001144204-17-025448:notes:59]
[same as prior period, unchanged from 0001144204-17-006696:notes:27]

[0001144204-17-025448:notes:60]
Compensation expense related to the restricted share awards was $1.2 million and $2.4 million for the three and six-month periods ended March 31, 2017, respectively, and $1.2 million and $2.3 million for the corresponding periods of 2016. There were  324,225 non-vested shares outstanding as of March 31, 2017.

[0001144204-17-025448:notes:61]
[same as prior period, unchanged from 0001144204-17-006696:notes:29]

[0001144204-17-025448:notes:62]
Compensation expense related to the non-employee director grants was $0.2 million and $0.5 million for the three and six-month periods ended March 31, 2017, respectively, and $0.2 million and $0.4 million for the corresponding periods of 2016.

[0001144204-17-025448:notes:63]
The total share-based compensation cost that has been recognized in the results of operations and included within selling, general and administrative expenses (SG&A) was $1.4 million and $2.9 million for the three-and six-month periods ended March 31, 2017, respectively, and $1.4 million and $2.7 million for the three and six-month periods ended March 31, 2016. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $0.5 million and $1.1 million for the three and six-month periods ended March 31, 2017, respectively, and $0.5 million and $1.0 million for the three and six-month periods ended March 31, 2016, respectively. As of March 31, 2017, there was $7.6 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a remaining weighted-average period of  1.9 years.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001144204-17-025448:notes:64]
|  | 11. | RETIREMENT PLANS |


## us-gaap:SubsequentEventsTextBlock

[0001144204-17-025448:notes:65]
| 14. | SUBSEQUENT EVENT |

[0001144204-17-025448:notes:66]
On May 8, 2017, the Company acquired NRG Systems, Inc. (NRG), doing business as Renewable NRG Systems, located in Hinesburg, Vermont. NRG, founded in 1982, is the global market leader in the design and manufacture of decision support tools for the renewable energy industry, primarily wind. NRG has annualized sales of approximately $45 million and will be included in the Company’s Utilities Solution Group (USG) segment.
