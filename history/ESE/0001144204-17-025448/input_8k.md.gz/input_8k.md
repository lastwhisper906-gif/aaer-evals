# ESE 8-K — 0000866706-17-000006 filed 2017-05-04

## item codes, every 8-K on or before 2017-05-09

- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2017-05-09

- none on or before 2017-05-09

## item 2.02 — earnings release, exhibit 99.1

[0000866706-17-000006:8k_2_02:1]
EX-99.1
2
escopressrelease.htm
ESCO PRESS RELEASE

[0000866706-17-000006:8k_2_02:2]
escopressrelease.htm

[0000866706-17-000006:8k_2_02:3]
EXHIBIT 99.1

[0000866706-17-000006:8k_2_02:4]
NEWS FROM

[0000866706-17-000006:8k_2_02:5]
For more information contact:

[0000866706-17-000006:8k_2_02:6]
Kate Lowrey

[0000866706-17-000006:8k_2_02:7]
Director, Investor Relations

[0000866706-17-000006:8k_2_02:8]
ESCO Technologies Inc.

[0000866706-17-000006:8k_2_02:9]
(314) 213-7277

[0000866706-17-000006:8k_2_02:10]
ESCO ANNOUNCES SECOND QUARTER 2017 RESULTS

[0000866706-17-000006:8k_2_02:11]
GAAP EPS of $0.43 Tops February Guidance Range of $0.37 - $0.42

[0000866706-17-000006:8k_2_02:12]
ST. LOUIS, May 4, 2017 – ESCO Technologies Inc. (NYSE: ESE) (ESCO, or the Company) today reported its operating results for the second quarter (Q2 2017) and six months year-to-date (YTD 2017) periods ended March 31, 2017.

[0000866706-17-000006:8k_2_02:13]
In 2016, Management completed its defined restructuring actions and presented its 2016 operating results on an “EPS – As Adjusted” basis, and reconciled these amounts to their respective GAAP equivalents.

[0000866706-17-000006:8k_2_02:14]
This release includes certain non-GAAP financial measures such as EPS – As Adjusted, and earnings before interest, taxes, depreciation and amortization (EBITDA). Management believes these non-GAAP financial measures are useful in assessing the operational profitability of the Company’s business segments, and therefore, allow shareholders better visibility into the Company’s underlying operations. See “Non-GAAP Financial Measures” described below.

[0000866706-17-000006:8k_2_02:15]
Earnings Summary

[0000866706-17-000006:8k_2_02:16]
| · | Q2 2017 GAAP EPS was $0.43 per share compared to Management’s previous GAAP guidance range of $0.37 to $0.42 per share; |

[0000866706-17-000006:8k_2_02:17]
| · | Compared to February’s guidance, the additional earnings were driven by higher sales and better than planned operating efficiencies at PTI and VACCO within the Filtration segment, coupled with lower corporate spending; |

[0000866706-17-000006:8k_2_02:18]
| · | Q2 2016 GAAP EPS was $0.33 per share, and EPS – As Adjusted was $0.40 per share; |

[0000866706-17-000006:8k_2_02:19]
| · | GAAP net earnings were $11.2 million in Q2 2017, $8.6 million in Q2 2016, and net earnings – As Adjusted of $10.4 million in Q2 2016; and, |

[0000866706-17-000006:8k_2_02:20]
| · | Q2 2017 EBITDA increased 19 percent to $25.3 million from $21.2 million in Q2 2016 – As Adjusted. A reconciliation of EBITDA, a non-GAAP financial measure, to GAAP Net Earnings is presented in the Condensed Business Segment Information table below. |

[0000866706-17-000006:8k_2_02:21]
Operating Highlights

[0000866706-17-000006:8k_2_02:22]
| · | Q2 2017 sales increased $22 million (16 percent) to $161 million compared to $139 million in Q2 2016; |

[0000866706-17-000006:8k_2_02:23]
| · | On a segment basis, Q2 2017 Filtration sales increased $20 million, or 40 percent compared to Q2 2016 driven by additional commercial aerospace deliveries, higher navy and space product sales, and Westland and Mayday’s Q2 2017 sales of $5 million and $10 million, respectively. Technical Packaging sales increased $2 million driven by Plastique sales included for 3 months versus 2 months in Q2 2016; Test sales decreased $2 million resulting from the quarterly timing of projects in the respective periods (orders and backlog increases are described below); and, Doble sales increased $3 million driven by the additional contribution from new products and software solutions; |

[0000866706-17-000006:8k_2_02:24]
| · | SG&A expenses increased $2 million in Q2 2017 compared to Q2 2016 primarily due to the addition of Plastique, Westland and Mayday in the current period, and additional sales and marketing expenses at Doble to support future revenue growth. These increases were partially mitigated by lower operating costs at Test, Crissair and Corporate; |

[0000866706-17-000006:8k_2_02:25]
| · | Other (income) expenses, net in Q2 2016 included charges of $1.4 million related to the prior year restructuring costs incurred at Test and Doble; |

[0000866706-17-000006:8k_2_02:26]
| · | The effective tax rate was 33.7 percent in Q2 2017 compared to 30.9 percent on a comparable EPS As – Adjusted basis in Q2 2016. The 36.8 percent tax rate reported in Q2 2016 on a GAAP basis was unfavorably impacted by a portion of the 2016 restructuring costs which resulted in no tax benefit; |

[0000866706-17-000006:8k_2_02:27]
| · | Entered orders were $167 million in Q2 2017 and $350 million YTD 2017 (book-to-bill of 1.04x and 1.14x, respectively) reflecting a $42 million (13 percent) increase in backlog for the first half of 2017, which resulted in an ending backlog of $375 million at March 31, 2017; |

[0000866706-17-000006:8k_2_02:28]
| · | Test orders were $44 million in Q2 2017 and $100 million YTD 2017 (book-to-bill of 1.15x and 1.39x, respectively) which reflects continued momentum in the wireless market and the catch-up of previously anticipated orders from a key customer. Test’s significant order volume and current backlog supports its projected sales and profit contribution over the remainder of the year; |

[0000866706-17-000006:8k_2_02:29]
| · | Doble orders were $33 million in Q2 2017 and $73 million YTD 2017 (book-to-bill of 1.01x and 1.06x, respectively) which reflects increased orders for new products such as the Doble Universal Controller (DUC), on-line monitoring solutions such as PRIME and ARMS, additional software applications, and the continued expansion of service contracts; |

[0000866706-17-000006:8k_2_02:30]
| · | Filtration orders were $62 million in Q2 2017 and $130 million YTD 2017 (book-to-bill of 0.90x and 1.01x, respectively) comprised of recurring commercial aerospace orders, offset by the sales run-off of large, multi-year submarine orders awarded in previous periods at VACCO and Westland; |

[0000866706-17-000006:8k_2_02:31]
| · | Technical Packaging orders were $28 million in Q2 2017 and $47 million YTD 2017 (book-to-bill of 1.30x and 1.20x, respectively) driven by higher KAZ, medical, medical device, and pharmaceutical projects; and, |

[0000866706-17-000006:8k_2_02:32]
| · | Net cash provided by operating activities was $37 million YTD 2017, which reduced net debt (outstanding borrowings less cash on hand) to $116 million at March 31, 2017. |

[0000866706-17-000006:8k_2_02:33]
Chairman’s Commentary – Q2 2017

[0000866706-17-000006:8k_2_02:34]
Vic Richey, Chairman and Chief Executive Officer, commented, “I’m pleased with our operating performance on several financial metrics as we were again able to exceed our earnings commitments provided in February. Summarizing our Q2 performance, we hit our sales targets, exceeded the top end of our EPS goals, generated far more cash flow than previously anticipated, and booked orders across the company that exceeded our expectations.

[0000866706-17-000006:8k_2_02:35]
“Our year-to-date earnings performance was primarily driven by the continued strength of Doble and the success of its recently introduced new products, solutions and software offerings which are being very well received by our utility customers. This result, coupled with better than expected Filtration performance driven by platform breadth and product diversity within our aerospace businesses, strong contributions from our navy and space applications, and lower than planned spending, enabled us to exceed our financial goals.

[0000866706-17-000006:8k_2_02:36]
“Of special note, cash flow and entered orders for the first six months were stronger than expected as we generated $37 million in cash from operating activities and recorded $350 million of new orders, which resulted in a book-to-bill ratio greater than 1.0 in every segment, and a $42 million increase in backlog from the start of the year. The $100 million of orders and $111 million of project backlog in Test are noteworthy as this gives me confidence that Test will be able to deliver its second half commitments and meet our expectations for the year.

[0000866706-17-000006:8k_2_02:37]
“Doble’s results continue to exceed expectations on nearly every financial metric, as YTD 2017 sales and earnings were above plan and included higher than expected deliveries of new products such as the DUC and Doble Prime, as well as additional software and service revenues which carry higher margins. Doble’s Q2 2017 EBIT dollars and margins reflect the costs incurred hosting the Annual Client Conference, which occurred in Q2 2017 compared to Q3 2016.

[0000866706-17-000006:8k_2_02:38]
“The Filtration group remains on track for the year despite some earlier sales push-out at VACCO resulting from project timing on a few large programs. PTI and Crissair continue to deliver strong operating results and their YTD 2017 operating margins are ahead of plan driven by the continued strength of our commercial aerospace platforms. Westland and Mayday are performing as expected and we see additional growth opportunities in the future based on the expanded level of bid and proposal activity we are participating in today.

[0000866706-17-000006:8k_2_02:39]
“Technical Packaging delivered its Q2 2017 financial commitments and we are pleased to see the KAZ program running at full production. We expect to see significant seasonal growth over the balance of the year.

[0000866706-17-000006:8k_2_02:40]
“Over the past few years, we have communicated our expectations with the goal of demonstrating consistency and predictability within our diversified, multi-segment operating structure, which is designed to reduce volatility and provide stable earnings. I believe our performance in 2017 demonstrates that our focused strategy and our lean cost structure are working.

[0000866706-17-000006:8k_2_02:41]
“On the acquisition front, I’m excited about the current opportunities we are evaluating and remain optimistic that we can further supplement our organic growth in both the near term and longer term. We will remain disciplined in our approach and will continue to maintain our focus on generating an attractive ROIC.

[0000866706-17-000006:8k_2_02:42]
“We plan to continue to build on our current momentum, and we are maintaining a favorable view of our future with our goal remaining the same – to increase long-term shareholder value.”

[0000866706-17-000006:8k_2_02:43]
Dividend Payment

[0000866706-17-000006:8k_2_02:44]
The next quarterly cash dividend of $0.08 per share will be paid on July 19, 2017 to stockholders of record on July 5, 2017.

[0000866706-17-000006:8k_2_02:45]
Business Outlook – 2017

[0000866706-17-000006:8k_2_02:46]
Management’s current expectations for 2017 remain consistent with the details outlined in the Business Outlook presented in the Company’s November 7, 2016 release.

[0000866706-17-000006:8k_2_02:47]
Management continues to see meaningful sales, EBIT and EBITDA growth across each of the Company’s business segments and anticipates growth rates in 2017 and beyond, that exceed the Company’s defined peer group and the broader industrial market.

[0000866706-17-000006:8k_2_02:48]
Management continues to expect 2017 GAAP EPS in the range of $2.16 to $2.26 per share, which includes the previously defined impact of the Mayday inventory “step up” charge in the first half of 2017 and the additional depreciation and amortization of intangibles resulting from recent acquisitions.

[0000866706-17-000006:8k_2_02:49]
On a quarterly basis, Management continues to expect 2017 operating results to reflect a profile similar to 2016 and previous years, with revenues and EPS being more second-half weighted. As with past years, projected Q4 2017 sales and EPS are expected to be the strongest/highest of the fiscal year.

[0000866706-17-000006:8k_2_02:50]
Management expects Q3 2017 GAAP EPS to be in the range of $0.46 to $0.51 per share, which includes the quarterly impact of the incremental depreciation and amortization resulting from recent acquisitions as detailed and quantified at the beginning of the year within the November earnings release.

[0000866706-17-000006:8k_2_02:51]
Chairman’s Commentary – 2017

[0000866706-17-000006:8k_2_02:52]
Mr. Richey continued, “Given the challenges facing the overall industrial landscape, I’m very pleased with our performance over the first six months, and I remain confident that we are on track to achieve the sales, EPS, EBIT and EBITDA growth that we projected for 2017. Despite some project timing between Quarters that we tend to face regularly across our business platforms, we wrapped up first half EPS on track and well ahead of plan on cash flow and entered orders. Our current backlog and the expectations for additional orders over the remainder of the year have us well positioned to meet our 2017 commitments.

[0000866706-17-000006:8k_2_02:53]
“We remain focused on sales and earnings growth, and our market leadership positions as well as the breadth and diversity of our new product offerings should allow us to outperform the majority of our industrial peers and the overall industrial market.

[0000866706-17-000006:8k_2_02:54]
“I believe our outlook puts us in a solid position to meet our shareholder value-creation goals, both short-term and longer-term, and we continue to see opportunities to supplement our growth through accretive acquisitions. We remain committed to our longer-term growth targets and goals.”

[0000866706-17-000006:8k_2_02:55]
Conference Call

[0000866706-17-000006:8k_2_02:56]
The Company will host a conference call today, May 4, at 4:00 p.m. Central Time, to discuss the Company’s Q2 2017 results. A live audio webcast will be available on the Company’s website at www.escotechnologies.com. Please access the website at least 15 minutes prior to the call to register, download and install any necessary audio software. A replay of the conference call will be available for seven days on the Company’s website noted above or by phone (dial 1-855-859-2056 and enter the pass code 6835503).

[0000866706-17-000006:8k_2_02:57]
Forward-Looking Statements

[0000866706-17-000006:8k_2_02:58]
Statements in this press release regarding the Company’s expected quarterly, 2017 full year and beyond results, revenue and sales growth, EPS, EPS growth, EBIT, EBITDA, gross profit, interest expense, non-cash depreciation and amortization of intangibles, corporate costs, effective tax rates, the Company’s ability to increase operating margins, realize financial goals and increase shareholder value, the success of acquisition efforts, the size, number and timing of future sales and growth opportunities, the long-term success of the Company, and any other statements which are not strictly historical are “forward-looking” statements within the meaning of the safe harbor provisions of the federal securities laws.

[0000866706-17-000006:8k_2_02:59]
Investors are cautioned that such statements are only predictions and speak only as of the date of this release, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment including, but not limited to those described in Item 1A, “Risk Factors”, of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2016, and the following: the success of the Company’s competitors; site readiness issues with Test segment customers; weakening of economic conditions in served markets; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties; unforeseen charges impacting corporate operating expenses; delivery delays or defaults by customers; the performance of the Company’s international operations; material changes in the costs and availability of certain raw materials; the appropriation and allocation of Government funds; the termination for convenience of Government and other customer contracts; the timing and content of future contract awards or customer orders; containment of engineering and development costs; performance issues with key customers, suppliers and subcontractors; labor disputes; the impacts of natural disasters on the Company’s operations and those of the Company’s customers and suppliers; changes in laws and regulations, including but not limited to changes in accounting standards and taxation requirements; costs relating to environmental matters arising from current or former facilities; financial exposure in connection with Company guarantees of certain Aclara contracts; the availability of select acquisitions; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the Company’s successful execution of cost reduction and profit improvement initiatives.

[0000866706-17-000006:8k_2_02:60]
Non-GAAP Financial Measures

[0000866706-17-000006:8k_2_02:61]
The financial measures EBIT, EBITDA, and EPS – As Adjusted are presented in this press release. The Company defines “EBIT” as earnings before interest and taxes, “EBITDA” as earnings before interest, taxes, depreciation and amortization, and “EPS – As Adjusted” as GAAP earnings per share (EPS) excluding the restructuring charges described above which were $0.07 per share for Q2 2016.

[0000866706-17-000006:8k_2_02:62]
EBIT, EBITDA and EPS – As Adjusted are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management believes that EBIT and EBITDA are useful in assessing the operational profitability of the Company’s business segments because they exclude interest, taxes, depreciation and amortization, which are generally accounted for across the entire Company on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company as well as incentive compensation. The Company believes that the presentation of EBIT, EBITDA, and EPS – As Adjusted provides important supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance determined in accordance with GAAP.

[0000866706-17-000006:8k_2_02:63]
ESCO, headquartered in St. Louis: Manufactures highly-engineered filtration and fluid control products for the aviation, space and process markets worldwide; is the industry leader in RF shielding and EMC test products; provides diagnostic instruments, software and services for the benefit of the electric utility industry and industrial power users; and, produces custom thermoformed packaging, pulp based packaging, and specialty products for medical and commercial markets. Further information regarding ESCO and its subsidiaries is available on the Company’s website at www.escotechnologies.com.

[0000866706-17-000006:8k_2_02:64]
-  tables attached -

[0000866706-17-000006:8k_2_02:65]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Condensed Consolidated Statements of Operations (Unaudited) |  |
| (Dollars in thousands, except per share amounts) |  |

[0000866706-17-000006:8k_2_02:66]
|  |  | Three Months Ended March 31, 2017 |  |  | Three Months Ended March 31, 2016 |  |
| Net Sales |  | $ | 161,178 |  |  |  | 138,930 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 105,379 |  |  |  | 88,118 |  |
| Selling, general and administrative expenses |  |  | 34,889 |  |  |  | 32,529 |  |
| Amortization of intangible assets |  |  | 3,814 |  |  |  | 2,895 |  |
| Interest expense |  |  | 855 |  |  |  | 368 |  |
| Other (income) expenses, net |  |  | (578 | ) |  |  | 1,405 |  |
| Total costs and expenses |  |  | 144,359 |  |  |  | 125,315 |  |
| Earnings before income taxes |  |  | 16,819 |  |  |  | 13,615 |  |
| Income taxes |  |  | 5,662 |  |  |  | 5,005 |  |
| Net earnings |  | $ | 11,157 |  |  |  | 8,610 |  |
| Diluted EPS – GAAP |  | $ | 0.43 | (1) |  |  | 0.33 | (2) |
| Diluted average common shares O/S: |  |  | 25,911 |  |  |  | 25,931 |  |

[0000866706-17-000006:8k_2_02:67]
|  | (1) |  | Includes Mayday inventory step up charge of $1.0 million. |
|  | (2) |  | Q2 FY 16 - As Adjusted EPS was $0.40 which excluded $1.7 million (or $0.07 per share) of restructuring charges incurred at ETS & Doble during the second quarter of fiscal 2016. |

[0000866706-17-000006:8k_2_02:68]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Condensed Consolidated Statements of Operations (Unaudited) |  |
| (Dollars in thousands, except per share amounts) |  |

[0000866706-17-000006:8k_2_02:69]
|  |  |  |  |  | Six Months Ended March 31, 2017 |  |  | Six Months Ended March 31, 2016 |  |
| Net Sales | $ | 307,546 |  |  | 271,763 |  |
| Cost and Expenses: |  |  |  |  |  |  |
|  | Cost of sales |  | 198,293 |  |  | 168,167 |  |
|  | Selling, general and administrative expenses |  | 68,651 |  |  | 65,820 |  |
|  | Amortization of intangible assets |  | 7,463 |  |  | 5,589 |  |
|  | Interest expense |  | 1,539 |  |  | 597 |  |
|  | Other (income) expenses, net |  | (1,344) |  |  | 5,007 |  |
|  |  | Total costs and expenses |  | 274,602 |  |  | 245,180 |  |
| Earnings before income taxes |  | 32,944 |  |  | 26,583 |  |
| Income taxes |  | 11,060 |  |  | 9,144 |  |
|  |  | Net earnings | $ | 21,884 |  |  | 17,439 |  |
|  |  | Diluted EPS - GAAP | $ | 0.84 | (1) |  | 0.67 | (2) |
|  |  | Diluted average common shares O/S: |  | 25,945 |  |  | 25,986 |  |

[0000866706-17-000006:8k_2_02:70]
| (1) | Includes Mayday inventory step up charge of $1.9 million. |
| (2) | YTD Q2 FY 16 - As Adjusted EPS was $0.87 which excluded $5.2 million (or $0.20 per share) of restructuring charges incurred at ETS & Doble during the first six months of fiscal 2016. |

[0000866706-17-000006:8k_2_02:71]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Condensed Business Segment Information (Unaudited) |
| (Dollars in thousands) |

[0000866706-17-000006:8k_2_02:72]
|  |  |  |  | GAAP |  | Q2 2016 Adjustments (1) |  | As Adjusted |
|  |  |  |  | Q2 2017 |  | Q2 2016 |  |  |  | Q2 2017 |  | Q2 2016 |
| Net Sales |  |  |  |  |  |  |  |  |  |  |
|  | Filtration | $ | 68,906 |  | 49,045 |  | - |  | 68,906 |  | 49,045 |
|  | Test |  | 38,367 |  | 40,601 |  | - |  | 38,367 |  | 40,601 |
|  | USG |  | 32,671 |  | 30,014 |  | - |  | 32,671 |  | 30,014 |
|  | Technical Packaging |  | 21,234 |  | 19,270 |  | - |  | 21,234 |  | 19,270 |
|  |  | Totals | $ | 161,178 |  | 138,930 |  | - |  | 161,178 |  | 138,930 |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |
|  | Filtration | $ | 11,625 |  | 9,064 |  | - |  | 11,625 |  | 9,064 |
|  | Test |  | 3,766 |  | 2,505 |  | 1,201 |  | 3,766 |  | 3,706 |
|  | USG |  | 7,434 |  | 7,208 |  | 171 |  | 7,434 |  | 7,379 |
|  | Technical Packaging |  | 2,196 |  | 2,747 |  | - |  | 2,196 |  | 2,747 |
|  | Corporate |  | (7,347) |  | (7,541) |  | 10 |  | (7,347) |  | (7,531) |
|  |  | Consolidated EBIT |  | 17,674 |  | 13,983 |  | 1,382 |  | 17,674 |  | 15,365 |
|  |  | Less: Interest expense |  | (855) |  | (368) |  | - |  | (855) |  | (368) |
|  |  | Less: Income tax expense |  | (5,662) |  | (5,005) |  | 367 |  | (5,662) |  | (4,638) |
|  |  | Net earnings | $ | 11,157 |  | 8,610 |  | 1,749 |  | 11,157 |  | 10,359 |

[0000866706-17-000006:8k_2_02:73]
| (1) |  | Adjustments consist of $1.7 million (or $0.07 per share) of restructuring charges at ETS & Doble during the second quarter of 2016. |

[0000866706-17-000006:8k_2_02:74]
| EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Q2 2016 |  |  |  |  |  |  |
|  |  |  |  | Q2 2017 |  | - As Adjusted |  |  |  |  |  |  |
| Consolidated EBITDA | $ | 25,274 |  | 21,243 |  |  |  |  |  |  |
| Less: Depr & Amort |  | (7,600) |  | (5,878) |  |  |  |  |  |  |
| Consolidated EBIT |  | 17,674 |  | 15,365 |  |  |  |  |  |  |
| Less: Interest expense |  | (855) |  | (368) |  |  |  |  |  |  |
| Less: Income tax expense |  | (5,662) |  | (4,638) |  |  |  |  |  |  |
| Net earnings | $ | 11,157 |  | 10,359 |  |  |  |  |  |  |

[0000866706-17-000006:8k_2_02:75]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Condensed Business Segment Information (Unaudited) |
| (Dollars in thousands) |

[0000866706-17-000006:8k_2_02:76]
|  |  |  |  | GAAP |  | YTD Q2 2016 Adjustments (1) |  | As Adjusted |
|  |  |  |  | YTD Q2 2017 |  | YTD Q2 2016 |  |  |  | YTD Q2 2017 |  | YTD Q2 2016 |
| Net Sales |  |  |  |  |  |  |  |  |  |  |
|  | Filtration | $ | 127,690 |  | 91,361 |  | - |  | 127,690 |  | 91,361 |
|  | Test |  | 72,194 |  | 83,374 |  | - |  | 72,194 |  | 83,374 |
|  | USG |  | 68,228 |  | 64,537 |  | - |  | 68,228 |  | 64,537 |
|  | Technical Packaging |  | 39,434 |  | 32,491 |  | - |  | 39,434 |  | 32,491 |
|  |  | Totals | $ | 307,546 |  | 271,763 |  | - |  | 307,546 |  | 271,763 |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |
|  | Filtration | $ | 22,351 |  | 17,348 |  | 0 |  | 22,351 |  | 17,348 |
|  | Test |  | 6,191 |  | 4,843 |  | 3,713 |  | 6,191 |  | 8,556 |
|  | USG |  | 17,108 |  | 15,457 |  | 1,494 |  | 17,108 |  | 16,951 |
|  | Technical Packaging |  | 3,227 |  | 4,560 |  | 0 |  | 3,227 |  | 4,560 |
|  | Corporate |  | (14,394) |  | (15,028) |  | 303 |  | (14,394) |  | (14,725) |
|  |  | Consolidated EBIT |  | 34,483 |  | 27,180 |  | 5,510 |  | 34,483 |  | 32,690 |
|  |  | Less: Interest expense |  | (1,539) |  | (597) |  | 0 |  | (1,539) |  | (597) |
|  |  | Less: Income tax expense |  | (11,060) |  | (9,144) |  | (294) |  | (11,060) |  | (9,438) |
|  |  | Net earnings | $ | 21,884 |  | 17,439 |  | 5,216 |  | 21,884 |  | 22,655 |

[0000866706-17-000006:8k_2_02:77]
| (1) |  | Adjustments consist of $5.2 million (or $0.20 per share) of restructuring charges at ETS & Doble during the first six months of 2016. |

[0000866706-17-000006:8k_2_02:78]
| EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |  |  |
|  |  |  |  | YTD Q2 2017 |  | YTD Q2 2016 - As Adjusted |  |  |  |  |  |  |
| Consolidated EBITDA | $ | 49,171 |  | 43,928 |  |  |  |  |  |  |
| Less: Depr & Amort |  | (14,688) |  | (11,238) |  |  |  |  |  |  |
| Consolidated EBIT |  | 34,483 |  | 32,690 |  |  |  |  |  |  |
| Less: Interest expense |  | (1,539) |  | (597) |  |  |  |  |  |  |
| Less: Income tax expense |  | (11,060) |  | (9,438) |  |  |  |  |  |  |
| Net earnings | $ | 21,884 |  | 22,655 |  |  |  |  |  |  |

[0000866706-17-000006:8k_2_02:79]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Condensed Consolidated Balance Sheets (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  | March 31, 2017 |  |  | September 30, 2016 |  |
| Assets |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 53,500 |  |  |  | 53,825 |  |
| Accounts receivable, net |  |  | 119,674 |  |  |  | 121,486 |  |
| Costs and estimated earnings on |  |  |  |  |  |  |  |  |
| long-term contracts |  |  | 36,261 |  |  |  | 28,746 |  |
| Inventories |  |  | 117,509 |  |  |  | 105,542 |  |
| Other current assets |  |  | 11,118 |  |  |  | 13,884 |  |
| Total current assets |  |  | 338,062 |  |  |  | 323,483 |  |
| Property, plant and equipment, net |  |  | 116,945 |  |  |  | 92,405 |  |
| Intangible assets, net |  |  | 265,273 |  |  |  | 231,759 |  |
| Goodwill |  |  | 353,984 |  |  |  | 323,616 |  |
| Other assets |  |  | 5,379 |  |  |  | 7,108 |  |
|  |  | $ | 1,079,643 |  |  |  | 978,371 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Short-term borrowings and current |  | $ | 20,000 |  |  |  | 20,000 |  |
| maturities of long-term debt |  |  |  |  |  |  |  |  |
| Accounts payable |  |  | 42,442 |  |  |  | 42,074 |  |
| Current portion of deferred revenue |  |  | 31,090 |  |  |  | 27,212 |  |
| Other current liabilities |  |  | 63,327 |  |  |  | 68,790 |  |
| Total current liabilities |  |  | 156,859 |  |  |  | 158,076 |  |
| Deferred tax liabilities |  |  | 84,134 |  |  |  | 69,562 |  |
| Other liabilities |  |  | 55,015 |  |  |  | 45,624 |  |
| Long-term debt |  |  | 150,000 |  |  |  | 90,000 |  |
| Shareholders' equity |  |  | 633,635 |  |  |  | 615,109 |  |
|  |  | $ | 1,079,643 |  |  |  | 978,371 |  |

[0000866706-17-000006:8k_2_02:80]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Consolidated Statements of Cash Flows (Unaudited) |
| (Dollars in thousands) |

[0000866706-17-000006:8k_2_02:81]
|  |  | Six Months Ended March 31, 2017 |  |
| Cash flows from operating activities: |  |  |  |
| Net earnings |  | $ | 21,884 |  |
| Adjustments to reconcile net earnings |  |  |  |  |
| to net cash provided by operating activities: |  |  |  |  |
| Depreciation and amortization |  |  | 14,688 |  |
| Stock compensation expense |  |  | 2,870 |  |
| Changes in assets and liabilities |  |  | (4,972 | ) |
| Change in deferred revenue and costs, net |  |  | 3,948 |  |
| Effect of deferred taxes |  |  | (1,645 | ) |
| Other |  |  | (118 | ) |
| Net cash provided by operating activities |  |  | 36,655 |  |
| Cash flows from investing activities: |  |  |  |  |
| Acquisition of business, net of cash acquired |  |  | (75,000 | ) |
| Capital expenditures |  |  | (15,435 | ) |
| Additions to capitalized software |  |  | (3,445 | ) |
| Proceeds from life insurance |  |  | 2,307 |  |
| Net cash used by investing activities |  |  | (91,573 | ) |
| Cash flows from financing activities: |  |  |  |  |
| Proceeds from long-term debt |  |  | 103,000 |  |
| Principal payments on long-term debt |  |  | (43,000 | ) |
| Dividends paid |  |  | (4,115 | ) |
| Other |  |  | (112 | ) |
| Net cash provided by financing activities |  |  | 55,773 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (1,180 | ) |
| Net decrease in cash and cash equivalents |  |  | (325 | ) |
| Cash and cash equivalents, beginning of period |  |  | 53,825 |  |
| Cash and cash equivalents, end of period |  | $ | 53,500 |  |

[0000866706-17-000006:8k_2_02:82]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Other Selected Financial Data (Unaudited) |
| (Dollars in thousands) |

[0000866706-17-000006:8k_2_02:83]
| Backlog And Entered Orders - Q2 FY 2017 |  | Filtration |  |  | Test |  |  | USG |  |  | Technical Packaging |  |  | Total |  |
| Beginning Backlog - 1/1/17 |  | $ | 204,521 |  |  |  | 105,358 |  |  |  | 37,708 |  |  |  | 21,314 |  |  |  | 368,901 |  |
| Entered Orders |  |  | 62,036 |  |  |  | 44,228 |  |  |  | 33,036 |  |  |  | 27,565 |  |  |  | 166,865 |  |
| Sales |  |  | (68,906 | ) |  |  | (38,367 | ) |  |  | (32,671 | ) |  |  | (21,234 | ) |  |  | (161,178 | ) |
| Ending Backlog - 3/31/17 |  | $ | 197,651 |  |  |  | 111,219 |  |  |  | 38,073 |  |  |  | 27,645 |  |  |  | 374,588 |  |
| Backlog And Entered Orders - YTD Q2 FY 2017 |  | Filtration |  |  | Test |  |  | USG |  |  | Technical Packaging |  |  | Total |  |
| Beginning Backlog - 10/1/16 |  | $ | 195,801 |  |  |  | 83,170 |  |  |  | 33,744 |  |  |  | 19,654 |  |  |  | 332,369 |  |
| Entered Orders |  |  | 129,540 |  |  |  | 100,243 |  |  |  | 72,557 |  |  |  | 47,425 |  |  |  | 349,765 |  |
| Sales |  |  | (127,690 | ) |  |  | (72,194 | ) |  |  | (68,228 | ) |  |  | (39,434 | ) |  |  | (307,546 | ) |
| Ending Backlog - 3/31/17 |  | $ | 197,651 |  |  |  | 111,219 |  |  |  | 38,073 |  |  |  | 27,645 |  |  |  | 374,588 |  |
