# ESE MD&A — 0001144204-17-025448


## mdna

[0001144204-17-025448:mdna:1]
ITEM 2. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION
AND RESULTS OF OPERATIONS

[0001144204-17-025448:mdna:2]
[same as prior period, unchanged from 0001144204-17-006696:mdna:2]

[0001144204-17-025448:mdna:3]
References to the second quarters of 2017 and 2016 represent
the three-month periods ended March 31, 2017 and 2016, respectively.

[0001144204-17-025448:mdna:4]
[same as prior period, unchanged from 0001144204-17-006696:mdna:4]

[0001144204-17-025448:mdna:5]
In the second quarter of 2017, sales, net earnings and diluted
earnings per share were $161.2 million, $11.2 million and $0.43 per share, respectively, compared to $

[0001144204-17-025448:mdna:6]
|  | 13 |

[0001144204-17-025448:mdna:7]
8.9 million, $8.6 million
and $0.33 per share, respectively, in the second quarter of 2016. In the first six months of 2017, sales, net earnings and diluted
earnings per share were $307.5 million, $21.9 million and $0.84, respectively, compared to $271.8 million, $17.4 million and $0.67
per share, respectively, in the first six months of 2016.

[0001144204-17-025448:mdna:8]
[same as prior period, unchanged from 0001144204-17-006696:mdna:6]

[0001144204-17-025448:mdna:9]
Net sales increased $22.2 million, or 16.0%, to $161.2 million
in the second quarter of 2017 from $138.9 million in the second quarter of 2016. Net sales increased $35.8 million, or 13.2%, to
$307.5 million in the first six months of 2017 from $271.8 million in the first six months of 2016. The increase in net sales in
the second quarter of 2017 as compared to the second quarter of 2016 was due to a $19.9 million increase in the Filtration segment,
a $2.7 million increase in the USG segment and a $2.0 million increase in the Technical Packaging segment, partially offset by
a $2.2 million decrease in the Test segment. The increase in net sales in the first six months of 2017 as compared to the corresponding
prior year period was due to a to a $36.3 million increase in the Filtration segment, a $6.9 million increase in the Technical
Packaging segment and a $3.7 million increase in the USG segment, partially offset by a $11.2 million decrease in the Test segment.

[0001144204-17-025448:mdna:10]
-Filtration

[0001144204-17-025448:mdna:11]
In the second quarter of 2017, net sales of $68.9 million were
$19.9 million, or 40.5%, higher than the $49.0 million in the second quarter of 2016. Net sales increased $36.3 million, or 39.8%,
to $127.7 million in the first six months of 2017 from $91.4 million in the first six months of 2016. The sales increase in the
second quarter of 2017 compared to the second quarter of 2016 was mainly due to the sales contributions from the Company’s
recent acquisitions of Westland ($5.4 million) and Mayday ($10.3 million); and a $3.4 million increase in net sales at VACCO due
to higher shipments of its space and defense products. The sales increase in the first six months of 2017 compared to the first
six months of 2016 was primarily due to the sales contributions from the Company’s recent acquisitions of Westland ($12.1
million) and Mayday ($16.6 million); and a $6.7 million increase in net sales at VACCO due to higher shipments of its space and
defense products.

[0001144204-17-025448:mdna:12]
13

[0001144204-17-025448:mdna:13]
[same as prior period, unchanged from 0001144204-17-006696:mdna:10]

[0001144204-17-025448:mdna:14]
In the second quarter of 2017, net sales of $38.4 million were
$2.2 million, or 5.5%, lower than the $40.6 million recorded in the second quarter of 2016. Net sales decreased $11.2 million,
or 13.4%, to $72.2 million in the first six months of 2017 from $83.4 million in the first six months of 2016. The decrease in
the second quarter of 2017 compared to the second quarter of 2016 was primarily due to lower sales from the segment’s European
operations. The decrease in the first six months of 2017 compared to the first six months of 2016 was mainly due to a decrease
in net sales from the segment’s U.S. and European operations mainly due to the timing of projects and lower sales volumes
of domestic shielding products.

[0001144204-17-025448:mdna:15]
-Utility Solutions Group (USG)

[0001144204-17-025448:mdna:16]
Net sales increased $2.7 million, or 8.9%, to $32.7 million
in the second quarter of 2017 from $30.0 million in the second quarter of 2016. Net sales increased $3.7 million, or 5.7%, to $68.2
million in the first six months of 2017 from $64.5 million in the first six months of 2016. The increase in the second quarter
and first six months of 2017 compared to the corresponding periods of 2016 was mainly driven by the additional contribution from
new products and software solutions at Doble.

[0001144204-17-025448:mdna:17]
[same as prior period, unchanged from 0001144204-17-006696:mdna:14]

[0001144204-17-025448:mdna:18]
In the second quarter of 2017, net sales of $21.2 million
were $1.9 million, or 10.2%, higher than the $19.3 million in the second quarter of 2016. Net sales increased $6.9 million,
or 21.4%, to $39.4 million in the first six months of 2017 from $32.5 million in the first six months of 2016. The increase
in the second quarter of 2017 compared to the second quarter of 2016 was due to the sales contribution from Plastique which
was acquired in January 2016. The increase in the first six months of 2017 compared to the first six months of 2016 was
mainly due to the $9.0 million sales contribution from Plastique partially offset by a $2.1 million decrease in net sales
from TEQ due to lower shipments to medical customers.

[0001144204-17-025448:mdna:19]
[same as prior period, unchanged from 0001144204-17-006696:mdna:16]

[0001144204-17-025448:mdna:20]
Backlog was $374.6 million at March 31, 2017 compared with $332.4
million at September 30, 2016. The Company received new orders totaling $166.9 million in the second quarter of 2017 compared to
$129.9 million in the second quarter of 2016. Of the new orders received in the second quarter of 2017, $62.0 million related to
Filtration products, $44.2 million related to Test products, $33.0 million related to USG products, and $27.6 million related to
Technical Packaging products. Of the new orders received in the second quarter of 2016, $42.2 million related to Filtration products,
$34.7 million related to Test products, $29.0 million related to USG products, and $24.0 million related to Technical Packaging
products

[0001144204-17-025448:mdna:21]
The Company received new orders totaling $349.8 million in the
first six months of 2017 compared to $272.6 million in the first six months of 2016. Of the new orders received in the first six
months of 2017, $129.5 million related to Filtration products, $100.2 million related to Test products, $72.6 million related to
USG products, and $47.4 million related to Technical Packaging products. Of the new orders received in the first six months of
2016, $99.0 million related to Filtration products, $73.6 million related to Test products, $60.3 million related to USG products,
and $39.7 million related to Technical Packaging products.

[0001144204-17-025448:mdna:22]
[same as prior period, unchanged from 0001144204-17-006696:mdna:18]

[0001144204-17-025448:mdna:23]
Selling, general and administrative (SG&A) expenses for
the second quarter of 2017 were $34.9 million (21.6% of net sales), compared with $32.5 million (23.4% of net sales) for the second
quarter of 2016. For the first six months of 2017, SG&A expenses were $68.7 million (22.3% of net sales) compared to $65.8
million (24.2% of net sales) for the first six months of 2016. The increase in SG&A in the second quarter and first six months
of 2017 compared to the corresponding periods of 2016 was mainly due to an increase in SG&A expenses in the Filtration and
Technical Packaging segments due to the Company’s recent acquisitions (Westland, Mayday and Plastique) and additional sales
and marketing expenses at Doble partially offset by a decrease in SG&A expenses in the Test segment (as a result of the 2016
restructuring activities), Crissair and Corporate (lower professional fees related to M&A activities).

[0001144204-17-025448:mdna:24]
|  | 14 |

[0001144204-17-025448:mdna:25]
[same as prior period, unchanged from 0001144204-17-006696:mdna:20]

[0001144204-17-025448:mdna:26]
Amortization of intangible assets was $3.8 million and $7.5
million for the second quarter and first six months of 2017, respectively, compared to $2.9 million and $5.6 million for the corresponding
periods of 2016. Amortization expenses consist of amortization of acquired intangible assets from acquisitions and other
identifiable intangible assets (primarily software). The increase in amortization expense in the second quarter and first six months
of 2017 compared to the corresponding periods of 2016 was mainly due to an increase in amortization of intangibles related to the
Westland, Mayday and Plastique acquisitions.

[0001144204-17-025448:mdna:27]
OTHER (INCOME) EXPENSES, NET

[0001144204-17-025448:mdna:28]
Other income, net, was $0.6 million in the second quarter of
2017 compared to other expenses, net, of $1.4 million in the second quarter of 2016. There were no individually significant items
in other (income) expenses, net, in the second quarter of 2017. The principal components in other expenses, net, in the second
quarter of 2016 were $1.2 million of restructuring costs related to the Test segment facility consolidation and $0.2 million of
costs related to the USG segment restructuring activities. The restructuring costs mainly related to severance and compensation
benefits, professional fees and asset impairment charges related to abandoned assets.

[0001144204-17-025448:mdna:29]
Other income, net, was $1.3 million in the first six months
of 2017 compared to other expenses, net, of $5.0 million in the first six months of 2016. The principal component in other income,
net, in the first six months of 2017 was $0.4 million of income related to death benefit insurance proceeds from a former employee.
The principal components in other expenses, net, in the first six months of 2016 were $3.5 million of restructuring costs related
to the Test segment and $1.5 million of costs related to the USG segment restructuring activities.

[0001144204-17-025448:mdna:30]
EBIT

[0001144204-17-025448:mdna:31]
The Company evaluates the performance of its operating segments
based on EBIT, and provides EBIT on a consolidated basis, which is a non-GAAP financial measure. Please refer to the discussion
of non-GAAP financial measures in Note 7 to the Consolidated Financial Statements, above. EBIT was $17.7 million (11.0% of net
sales) for the second quarter of 2017 compared to $14.0 million (10.1% of net sales) for the second quarter of 2016. For the first
six months of 2017, EBIT was $34.5 million (11.2% of net sales) compared to $27.2 million (10.0% of net sales) for the first six
months of 2016.

[0001144204-17-025448:mdna:32]
The following table presents a reconciliation of EBIT to net
earnings.

[0001144204-17-025448:mdna:33]
| (In thousands) |  | Three Months Ended March 31, |  |  | Six Months Ended March 31, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Consolidated EBIT |  | $ | 17,674 |  |  |  | 13,983 |  |  |  | 34,483 |  |  |  | 27,180 |  |
| Less: Interest expense, net |  |  | (855 | ) |  |  | (368 | ) |  |  | (1,539 | ) |  |  | (597 | ) |
| Less: Income tax expense |  |  | (5,662 | ) |  |  | (5,005 | ) |  |  | (11,060 | ) |  |  | (9,144 | ) |
| Net earnings |  | $ | 11,157 |  |  |  | 8,610 |  |  |  | 21,884 |  |  |  | 17,439 |  |

[0001144204-17-025448:mdna:34]
-Filtration

[0001144204-17-025448:mdna:35]
EBIT in the second quarter of 2017 was $11.6 million (16.9%
of net sales) compared to $9.1 million (18.5% of net sales) in the second quarter of 2016. In the first six months of 2017, EBIT
was $22.4 million (17.5% of net sales) compared to $17.3 million (19.0% of net sales) in the first six months of 2016. The increase
in EBIT in the second quarter and first six months of 2017 compared to the corresponding prior year periods was mainly due to the
EBIT contribution from Westland (September 2, 2016 acquisition) and an increase at PTI and VACCO due to the higher sales volumes.
EBIT as a percent of net sales decreased in the second quarter and first six months of 2017 compared to the respective 2016 periods
mainly due to the inventory step-up charge at Mayday of $1.0 million and $1.9 million in the second quarter and first six months
of 2017, respectively.

[0001144204-17-025448:mdna:36]
-Test

[0001144204-17-025448:mdna:37]
EBIT in the second quarter of 2017 was $3.8 million (9.8% of
net sales) compared to $2.5 million (6.2% of net sales) in the second quarter of 2016. In the first six months of 2017, EBIT was
$6.2 million (8.6% of net sales) compared to $4.8 million (5.8% of net sales) in the first six months of 2016. EBIT increased in
the first six months of 2017 compared to the first six months of 2016 primarily due to the $3.7 million of restructuring charges
incurred in the first six months of 2016 related to closing the Test business operating facilities in Germany and England, consisting
mainly of employee severance and compensation benefits, professional fees, and asset impairment charges; partially offset by a
decrease in EBIT related to the lower sales volumes.

[0001144204-17-025448:mdna:38]
|  | 15 |

[0001144204-17-025448:mdna:39]
-Utility Solutions Group

[0001144204-17-025448:mdna:40]
EBIT in the second quarter of 2017 was $7.4 million (22.8%
of net sales) compared to $7.2 million (24.0% of net sales) in the second quarter of 20

[0001144204-17-025448:mdna:41]
|  | 16 |

[0001144204-17-025448:mdna:42]
. In the first six months of 20

[0001144204-17-025448:mdna:43]
|  | 17 |

[0001144204-17-025448:mdna:44]
,
EBIT was $17.1 million (25.1% of net sales) compared to EBIT of $15.5 million (24.0% of net sales) in the first six months of
2016. The increase in EBIT in the second quarter and first six months of 2017 compared to the corresponding periods of 2016
was mainly due to higher sales volumes and additional contribution from new products and software solutions, partially offset
by higher expenditures due to the timing of the annual Client Conference.

[0001144204-17-025448:mdna:45]
[same as prior period, unchanged from 0001144204-17-006696:mdna:34]

[0001144204-17-025448:mdna:46]
EBIT in the second quarter of 2017 was $2.2 million (10.3% of
net sales) compared to $2.7 million (14.3% of net sales) in the second quarter of 2016. In the first six months of 2017, EBIT was
$3.2 million (8.2% of net sales) compared to $4.6 million (14.0% of net sales) in the first six months of 2016. The decrease in
EBIT in the second quarter and first six months of 2017 compared to the corresponding periods of 2016 was mainly due to lower sales
volumes at TEQ and higher SG&A expense.

[0001144204-17-025448:mdna:47]
-Corporate

[0001144204-17-025448:mdna:48]
Corporate costs included in EBIT were $7.3 million and $14.4
million in the second quarter and first six months of 2017, respectively, compared to $7.5 million and $15.0 million in the corresponding
periods of 2016. The decrease in Corporate costs in the second quarter and first six months of 2017 compared to the corresponding
periods of 2016 was primarily due to lower professional fees.

[0001144204-17-025448:mdna:49]
[same as prior period, unchanged from 0001144204-17-006696:mdna:38]

[0001144204-17-025448:mdna:50]
Interest expense was $0.9 million and $1.5 million in the second
quarter and first six months of 2017, respectively, and $0.4 million and $0.6 million in the corresponding periods of 2016. The
increase in interest expense in the second quarter and first six months of 2017 compared to the corresponding periods of 2016 was
mainly due to higher outstanding borrowings during the current year as a result of the Company’s recent acquisitions (Westland
and Mayday).

[0001144204-17-025448:mdna:51]
[same as prior period, unchanged from 0001144204-17-006696:mdna:40]

[0001144204-17-025448:mdna:52]
The second quarter 2017 effective income tax rate was 33.7%
compared to 36.8% in the second quarter of 2016. The effective income tax rate for the first six months of 2017 was 33.6% compared
to 34.4% for the first six months of 2016. The income tax expense in the second quarter and first six months of 2017 was unfavorably
impacted by a decrease in the foreign tax rate benefit of 0.8% and 1.4%, respectively.

[0001144204-17-025448:mdna:53]
The income tax expense in the second quarter and first six months
of 2016 was unfavorably impacted by a U.K. foreign valuation allowance that increased the second quarter and year-to-date effective
tax rate by 4.8% and 2.5%, respectively. The income tax expense in the first six months of 2016 was favorably impacted by the extension
of the research credit as a result of The Protecting Americans from Tax Hikes Act reducing the year-to-date effective tax rate
by 3.0%. The income tax expense in the first six months of 2016 was unfavorably impacted by losses in foreign jurisdictions for
which no tax benefit was recorded, increasing the year-to-date effective tax rate by 2.8%.

[0001144204-17-025448:mdna:54]
The Company estimates the fiscal 2017 effective tax rate will
be approximately 34%. During the three-month period ended March 31, 2017, there were no material changes in the unrecognized tax
benefits. The Company does not anticipate a material change in the amount of unrecognized tax benefits in the next twelve months.

[0001144204-17-025448:mdna:55]
The Company’s foreign subsidiaries had accumulated unremitted
earnings of $49.8 million and cash of $40.1 million at March 31, 2017. No deferred taxes have been provided on the accumulated
unremitted earnings because these funds are not needed to meet the liquidity requirements of the Company’s U.S. operations
and it is the Company’s intention to reinvest these earnings indefinitely. In the event these foreign entities’ earnings
were distributed, it is estimated that U.S. taxes, net of available foreign tax credits, of approximately $4.8 million would be
due, which would correspondingly reduce the Company’s net earnings.

[0001144204-17-025448:mdna:56]
16

[0001144204-17-025448:mdna:57]
[same as prior period, unchanged from 0001144204-17-006696:mdna:44]

[0001144204-17-025448:mdna:58]
The Company’s overall financial position and liquidity
remains strong. Working capital (current assets less current liabilities) increased to $

[0001144204-17-025448:mdna:59]
|  | 18 |

[0001144204-17-025448:mdna:60]
1.2 million at March 31, 2017 from $165.4
million at September 30, 2016. Inventories increased by $12.0 million during this period mainly due to an $11.5 million increase
within the Filtration segment primarily related to the acquisition of Mayday in the first quarter of 2017. Costs and estimated
earnings in excess of billings on long-term contracts increased $7.5 million in the first six months of 2017 due to VACCO ($5.5
million) and ETS ($2.0 million).

[0001144204-17-025448:mdna:61]
Net cash provided by operating activities was $36.7 million and $9.1 million in the first six
months of 2017 and 2016, respectively. The increase in net cash provided by operating activities in the first six months of 2017
as compared to the first six months of 2016 was due to higher net earnings and lower working capital requirements.

[0001144204-17-025448:mdna:62]
Capital expenditures were $15.4 million and $5.3 million in
the first six months of 2017 and 2016, respectively. The increase in the first six months of 2017 was mainly due to an increase
in machinery and equipment additions at Plastique ($4.1 million) and VACCO ($3.1 million). In addition, the Company incurred expenditures
for capitalized software of $3.4 million and $3.7 million in the first six months of 2017 and 2016, respectively.

[0001144204-17-025448:mdna:63]
Credit Facility

[0001144204-17-025448:mdna:64]
At March 31, 2017, the Company had approximately $276 million
available to borrow under its bank credit facility, a $250 million increase option, and $53.5 million cash on hand. At March 31,
2017, the Company had $170.0 million of outstanding borrowings under the credit facility in addition to outstanding letters of
credit of $4.6 million. Cash flow from operations and borrowings under the Company’s credit facility are expected to meet
the Company’s capital requirements and operational needs for the foreseeable future. The Company’s ability to access
the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.

[0001144204-17-025448:mdna:65]
[same as prior period, unchanged from 0001144204-17-006696:mdna:50]

[0001144204-17-025448:mdna:66]
On November 7, 2016, the Company acquired aerospace supplier
Mayday, located in Denton, Texas, for a purchase price of $75 million in cash. Since the date of acquisition the consolidated operating
results for Mayday have been included in the Company’s Filtration segment.

[0001144204-17-025448:mdna:67]
[same as prior period, unchanged from 0001144204-17-006696:mdna:52]

[0001144204-17-025448:mdna:68]
A dividend of $0.08 per share was paid on October 17, 2016 to
stockholders of record as of October 3, 2016, totaling $2.1 million. A dividend of $0.08 per share was paid on January

[0001144204-17-025448:mdna:69]
|  | 19 |

[0001144204-17-025448:mdna:70]
, 2017
to stockholders of record as of January 4, 2017, totaling $2.1 million. Subsequent to March 31, 2017, a quarterly dividend of $0.08
per share, totaling $2.1 million, was paid on April 18, 2017 to stockholders of record as of April 3, 2017.

[0001144204-17-025448:mdna:71]
Subsequent Event

[0001144204-17-025448:mdna:72]
On May 8, 2017, the Company acquired NRG Systems, Inc. (NRG),
doing business as Renewable NRG Systems, located in Hinesburg, Vermont. NRG, founded in 1982, is the global market leader
in the design and manufacture of decision support tools for the renewable energy industry, primarily wind. NRG has annualized
sales of approximately $45 million and will be included in the Company’s Utilities Solution Group (USG) segment.

[0001144204-17-025448:mdna:73]
[same as prior period, unchanged from 0001144204-17-006696:mdna:54]

[0001144204-17-025448:mdna:74]
Excluding the impact of the NRG acquisition announced on May
8, 2017, Management’s current expectations for 2017 remain consistent with the details outlined in the Business Outlook presented
in the Company’s November 7, 2016 release.

[0001144204-17-025448:mdna:75]
The partial year contribution from the NRG acquisition to 2017
expected sales and EPS, net of any non-cash purchase accounting charges or inventory step-up, is currently being finalized and
is not included in the following guidance. Management will update its 2017 outlook once the balance of the year forecast and related
purchase accounting is finalized.

[0001144204-17-025448:mdna:76]
On a quarterly basis, Management continues to expect 2017 revenues
and EPS to reflect a profile similar to 2016, including EPS being more second-half weighted. Third quarter 2017 EPS is expected
to be in the range of $0.46 to $0.51 per share, excluding the impact of the NRG acquisition. Management expects 2017 EPS to be
in the range of $2.16 - $2.26 per share, excluding the impact of the NRG acquisition.

[0001144204-17-025448:mdna:77]
17

[0001144204-17-025448:mdna:78]
[same as prior period, unchanged from 0001144204-17-006696:mdna:56]

[0001144204-17-025448:mdna:79]
[same as prior period, unchanged from 0001144204-17-006696:mdna:57]

[0001144204-17-025448:mdna:80]
[same as prior period, unchanged from 0001144204-17-006696:mdna:58]

[0001144204-17-025448:mdna:81]
Contingencies

[0001144204-17-025448:mdna:82]
As a normal incident of the business in which the Company is
engaged, various claims, charges and litigation are asserted or commenced against the Company. Additionally, the Company is currently
involved in various stages of investigation and remediation relating to environmental matters. In the opinion of Management, the
aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company,
are adequately reserved, are covered by insurance, or would not have a material adverse effect on the Company’s results from
operations, capital expenditures, or competitive position.

[0001144204-17-025448:mdna:83]
[same as prior period, unchanged from 0001144204-17-006696:mdna:61]

[0001144204-17-025448:mdna:84]
Investors are cautioned that such statements are only predictions
and speak only as of the date of this Form 10-Q, and the Company undertakes no duty to update them except as may be required by
applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in
the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment,
including but not limited to those described in Item 1A, “Risk Factors,” of the Company’s Annual Report on Form
10-K for the fiscal year ended September 30, 2016, and the following: the impacts of natural disasters on the Company’s operations
and those of the Company’s customers and suppliers; the timing and content of future contract awards or customer orders;
termination for convenience of customer contracts or orders; financial exposure in connection with Company guarantees of certain
Aclara contracts; weakening of economic conditions in served markets; the success of the Company’s competitors; changes in
customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties; the availability
of selected acquisitions; delivery delays or defaults by customers; performance issues with key customers, suppliers and subcontractors;
material changes in the costs of certain raw materials; labor disputes; changes in laws and regulations including but not limited
to changes in accounting standards and taxation requirements; changes in interest rates; costs relating to environmental matters;
litigation uncertainty; and the integration of recently acquired businesses.
