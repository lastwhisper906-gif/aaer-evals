# ESE notes — 0001144204-17-006696


## us-gaap:ScheduleOfWeightedAverageNumberOfSharesTableTextBlock

[0001144204-17-006696:notes:1]
[same as prior period, unchanged from 0001144204-16-117178:notes:6]

[0001144204-17-006696:notes:2]
|  |  | Three Months Ended December 31, |  |
|  |  | 2016 |  | 2015 |  |
| Weighted Average Shares Outstanding - Basic |  |  | 25,720 |  |  | 25,820 |  |
| Dilutive Options and Restricted Shares |  |  | 259 |  |  | 224 |  |
| Adjusted Shares - Diluted |  |  | 25,979 |  |  | 26,044 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001144204-17-006696:notes:3]
[same as prior period, unchanged from 0001144204-16-117178:notes:37]

[0001144204-17-006696:notes:4]
[same as prior period, unchanged from 0001144204-16-117178:notes:38]

[0001144204-17-006696:notes:5]
| (In thousands) |  | December 31, 2016 |  | September 30, 2016 |  |
| Finished goods |  | $ | 25,464 |  |  | 19,451 |  |
| Work in process |  |  | 41,837 |  |  | 37,922 |  |
| Raw materials |  |  | 49,595 |  |  | 48,169 |  |
| Total inventories |  | $ | 116,896 |  |  | 105,542 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001144204-17-006696:notes:6]
Management evaluates and measures the performance of its operating segments based on “Net Sales” and “EBIT”, which are detailed in the table below. EBIT is defined as earnings before interest and taxes.

[0001144204-17-006696:notes:7]
| (In thousands) |  | Three Months Ended December 31, |  |
|  |  | 2016 |  | 2015 |  |
| NET SALES |  |  |  |  |  |  |  |
| Filtration |  | $ | 58,785 |  |  | 42,317 |  |
| Test |  |  | 33,827 |  |  | 42,773 |  |
| USG |  |  | 35,556 |  |  | 34,522 |  |
| Technical Packaging |  |  | 18,200 |  |  | 13,221 |  |
| Consolidated totals |  | $ | 146,368 |  |  | 132,833 |  |
| EBIT |  |  |  |  |  |  |  |
| Filtration |  | $ | 10,726 |  |  | 8,284 |  |
| Test |  |  | 2,425 |  |  | 2,338 |  |
| USG |  |  | 9,674 |  |  | 8,249 |  |
| Technical Packaging |  |  | 1,031 |  |  | 1,813 |  |
| Corporate (loss) |  |  | (7,047) |  |  | (7,487) |  |
| Consolidated EBIT |  |  | 16,809 |  |  | 13,197 |  |
| Less: Interest expense |  |  | (684) |  |  | (229) |  |
| Earnings before income taxes |  | $ | 16,125 |  |  | 12,968 |  |


## us-gaap:ScheduleOfDebtTableTextBlock

[0001144204-17-006696:notes:8]
The Company’s debt is summarized as follows:

[0001144204-17-006696:notes:9]
| (In thousands) |  | December 31, 2016 |  | September 30, 2016 |  |
| Total borrowings |  | $ | 180,000 |  |  | 110,000 |  |
| Current portion of long-term debt |  |  | (20,000) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 160,000 |  |  | 90,000 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001144204-17-006696:notes:10]
| 11. | RETIREMENT PLANS |

[0001144204-17-006696:notes:11]
A summary of net periodic benefit expense for the Company’s defined benefit plans for the three-month periods ended December 31, 2016 and 2015 is shown in the following table. Net periodic benefit cost for each period presented is comprised of the following:

[0001144204-17-006696:notes:12]
|  |  | Three Months Ended December 31, |  |
| (In thousands) |  | 2016 |  | 2015 |  |
| Defined benefit plans |  |  |  |  |  |  |  |
| Interest cost |  | $ | 965 |  |  | 963 |  |
| Expected return on assets |  |  | (1,094) |  |  | (1,093) |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost |  |  | 3 |  |  | 3 |  |
| Actuarial loss |  |  | 505 |  |  | 486 |  |
| Net periodic benefit cost |  | $ | 379 |  |  | 359 |  |


## us-gaap:ScheduleOfNotionalAmountsOfOutstandingDerivativePositionsTableTextBlock

[0001144204-17-006696:notes:13]
The following is a summary of the notional transaction amounts and fair values for the Company’s outstanding derivative financial instruments by risk category and instrument type as of December 31, 2016:

[0001144204-17-006696:notes:14]
| (In thousands) |  | Notional amount (GBP) |  | Fair Value (US$) |  |
| Forward contracts |  |  | 1,859 |  |  | (348) |  |


## us-gaap:ScheduleOfDerivativeLiabilitiesAtFairValueTableTextBlock

[0001144204-17-006696:notes:15]
The Company’s forward contracts are classified within Level 2 of the valuation hierarchy in accordance with FASB Accounting Standards Codification (ASC) 825, as presented below as of December 31, 2016:

[0001144204-17-006696:notes:16]
| (In thousands) |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Forward contracts |  | $ | - |  |  | (348) |  | $ | - |  |  | (348) |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001144204-17-006696:notes:17]
|  | 1. | BASIS OF PRESENTATION |

[0001144204-17-006696:notes:18]
The accompanying consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP). For further information, refer to the consolidated financial statements and related notes included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2016.

[0001144204-17-006696:notes:19]
The Company’s results for the three-month period ended December 31, 2016 are not necessarily indicative of the results for the entire 2017 fiscal year. References to the first quarters of 2017 and 2016 represent the fiscal quarters ended December 31, 2016 and 2015, respectively.

[0001144204-17-006696:notes:20]
The preparation of financial statements in conformity with GAAP requires Management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001144204-17-006696:notes:21]
| 2. | ACQUISITION |

[0001144204-17-006696:notes:22]
On November 7, 2016, the Company acquired aerospace suppliers Mayday Manufacturing Co. and its affiliate, Hi-Tech Metals, Inc. (collectively referred to as Mayday), which share a  130,000 square foot facility in Denton, Texas, for a purchase price of $75 million in cash. Mayday Manufacturing Co. is a leading manufacturer of mission-critical bushings, pins, sleeves and precision-tolerance machined components for landing gear, rotor heads, engine mounts, flight controls, and actuation systems for the aerospace and defense industry. Hi-Tech Metals, Inc. is a full-service metal processor offering aerospace OEM’s, Tier 1 suppliers, a large portfolio of processing services including anodizing, cadmium and zinc-nickel plating, organic coatings, non-destructive testing, and heat treatment. Mayday has annual sales of approximately $40 million. Since the date of acquisition the consolidated operating results for Mayday have been included in the Company’s Filtration segment. Based on the preliminary purchase price allocation, the Company recorded approximately $7.4 million of accounts receivable, $11.0 million of inventory, $16.6 million of property, plant and equipment (including a capital lease), $9.5 million of lease liability, $15.7 million of deferred tax liabilities, $30.1 million of goodwill (non-deductible for tax purposes), $4.8 million of trade names and $32.8 million of amortizable identifiable intangible assets consisting primarily of customer relationships with a weighted-average life of approximately 20 years.


## us-gaap:EarningsPerShareTextBlock

[0001144204-17-006696:notes:23]
[same as prior period, unchanged from 0001144204-16-117178:notes:41]

[0001144204-17-006696:notes:24]
[same as prior period, unchanged from 0001144204-16-117178:notes:42]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001144204-17-006696:notes:25]
|  | 4. | SHARE-BASED COMPENSATION |

[0001144204-17-006696:notes:26]
[same as prior period, unchanged from 0001144204-16-117178:notes:9]

[0001144204-17-006696:notes:27]
[same as prior period, unchanged from 0001144204-16-117178:notes:10]

[0001144204-17-006696:notes:28]
Compensation expense related to the restricted share awards was $1.2 million and $1.1 million for the three-month periods ended December 31, 2016 and 2015, respectively. There were  526,260 non-vested shares outstanding as of December 31, 2016.

[0001144204-17-006696:notes:29]
[same as prior period, unchanged from 0001144204-16-117178:notes:12]

[0001144204-17-006696:notes:30]
Compensation expense related to the non-employee director grants was $0.2 million and $0.2 million for the three-month periods ended December 31, 2016 and 2015, respectively.

[0001144204-17-006696:notes:31]
The total share-based compensation cost that has been recognized in the results of operations and included within selling, general and administrative expenses (SG&A) was $1.4 million and $1.3 million for the three-month periods ended December 31, 2016 and 2015, respectively. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $0.5 million and $0.5 million for the three-month periods ended December 31, 2016 and 2015, respectively. As of December 31, 2016, there was $8.8 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a remaining weighted-average period of  1.4 years.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001144204-17-006696:notes:32]
|  | 6. | GOODWILL AND OTHER INTANGIBLE ASSETS |

[0001144204-17-006696:notes:33]
Included on the Company’s Consolidated Balance Sheets at December 31, 2016 and September 30, 2016 are the following intangible assets gross carrying amounts and accumulated amortization:

[0001144204-17-006696:notes:34]
| (Dollars in thousands) |  | December 31, 2016 |  | September 30, 2016 |  |
| Goodwill |  | $ | 353,303 |  |  | 323,616 |  |
| Intangible assets with determinable lives: |  |  |  |  |  |  |  |
| Patents |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 917 |  |  | 917 |  |
| Less: accumulated amortization |  |  | 738 |  |  | 726 |  |
| Net |  | $ | 179 |  |  | 191 |  |
| Capitalized software |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 55,438 |  |  | 54,003 |  |
| Less: accumulated amortization |  |  | 28,504 |  |  | 26,737 |  |
| Net |  | $ | 26,934 |  |  | 27,266 |  |
| Customer Relationships |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 144,288 |  |  | 111,887 |  |
| Less: accumulated amortization |  |  | 30,972 |  |  | 28,633 |  |
| Net |  | $ | 113,316 |  |  | 83,254 |  |
| Other |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 3,176 |  |  | 2,777 |  |
| Less: accumulated amortization |  |  | 968 |  |  | 859 |  |
| Net |  | $ | 2,208 |  |  | 1,918 |  |
| Intangible assets with indefinite lives: |  |  |  |  |  |  |  |
| Trade names |  | $ | 123,771 |  |  | 119,128 |  |

[0001144204-17-006696:notes:35]
The changes in the carrying amount of goodwill attributable to each business segment for the three months ended December 31, 2016 is as follows:

[0001144204-17-006696:notes:36]
| (Dollars in millions) |  | USG |  | Test |  | Filtration |  | Packaging |  | Total |  |
| Balance as of September 30, 2016 |  |  | 226.2 |  |  | 34.1 |  |  | 43.9 |  |  | 19.4 |  |  | 323.6 |  |
| Adjustments |  |  | - |  |  | - |  |  | 30.4 |  |  | (0.7) |  |  | 29.7 |  |
| Balance as of December 31, 2016 |  | $ | 226.2 |  |  | 34.1 |  |  | 74.3 |  |  | 18.7 |  |  | 353.3 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001144204-17-006696:notes:37]
[same as prior period, unchanged from 0001144204-16-117178:notes:48]

[0001144204-17-006696:notes:38]
The Company is organized based on the products and services that it offers and classifies its business operations in four segments for financial reporting purposes: Filtration/Fluid Flow (Filtration), RF Shielding and Test (Test), Utility Solutions Group (USG) and Technical Packaging. The Filtration segment’s operations consist of PTI Technologies Inc. (PTI), VACCO Industries (VACCO), Crissair, Inc. (Crissair), Westland Technologies Inc. (Westland), Mayday and its affiliate Hi-Tech. The companies within this segment primarily design and manufacture specialty filtration products, including hydraulic filter elements used in commercial aerospace applications, unique filter mechanisms used in micro-propulsion devices for satellites and custom designed filters for manned and unmanned aircraft; manufacture elastomeric-based signature reduction solutions for the U.S. Navy; and manufacture landing gear components for the aerospace and defense industry. The Test segment’s operations consist of ETS-Lindgren Inc. and related subsidiaries (ETS-Lindgren). ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy. The USG segment’s operations consist of Doble Engineering Company and related subsidiaries (Doble). Doble provides high-end, intelligent diagnostic test solutions for the electric power delivery industry and is a leading supplier of partial discharge testing instruments used to assess the integrity of high voltage power delivery equipment. The Technical Packaging segment’s operations consist of Thermoform Engineered Quality LLC (TEQ) and Plastique Limited and Plastique Sp. Z.o.o (together, Plastique). The companies within this segment provide innovative solutions to the medical and commercial markets for thermoformed and precision molded pulp fiber packages and specialty products using a wide variety of thin gauge plastics and pulp.

[0001144204-17-006696:notes:39]
[same as prior period, unchanged from 0001144204-16-117178:notes:51]

[0001144204-17-006696:notes:40]
The financial measure “EBIT” is presented in the above table and elsewhere in this Report. EBIT on a consolidated basis is a non-GAAP financial measure. Management believes that EBIT is useful in assessing the operational profitability of the Company’s business segments because it excludes interest and taxes, which are generally accounted for across the entire Company on a consolidated basis. EBIT is also one of the measures used by management in determining resource allocations within the Company as well as incentive compensation. A reconciliation of EBIT to net earnings is set forth in Item 2, Management’s Discussion and Analysis of Financial Condition and Results of Operations – EBIT, below.

[0001144204-17-006696:notes:41]
[same as prior period, unchanged from 0001144204-16-117178:notes:53]


## us-gaap:DebtDisclosureTextBlock

[0001144204-17-006696:notes:42]
| 8. | DEBT |

[0001144204-17-006696:notes:43]
The Company’s existing credit facility maturity date is December 21, 2020. The credit facility includes a $450 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the new facility is comprised of a diverse group of nine banks led by JPMorgan Chase Bank, N.A., as Administrative Agent.

[0001144204-17-006696:notes:44]
At December 31, 2016, the Company had approximately $265 million available to borrow under the Credit Facility, and a $250 million increase option, in addition to $51.8 million of cash on hand. At December 31, 2016, the Company had $180 million of outstanding borrowings under the credit facility in addition to outstanding letters of credit of $4.6 million. The Company classified $20.0 million as the current portion of long-term debt as of December 31, 2016, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months.

[0001144204-17-006696:notes:45]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from  12.5 to  27.5 basis points per annum on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a  65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were  1.61% and  1.41% for the three-month periods ending December 31, 2016 and 2015, respectively. At December 31, 2016, the Company was in compliance with all debt covenants.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001144204-17-006696:notes:46]
[same as prior period, unchanged from 0001144204-16-117178:notes:15]

[0001144204-17-006696:notes:47]
The first quarter 2017 effective income tax rate was  33.5% compared to  31.9% in the first quarter of 2016. The increase in the effective income tax rate in the first quarter of 2017 was mainly due to the income tax expense in the first quarter of 2016 being favorably impacted by the extension of the research credit as a result of The Protecting Americans from Tax Hikes Act reducing the 2016 first quarter effective tax rate by  6.6%. In addition, income tax expense in the first quarter of 2016 was unfavorably impacted by losses in foreign jurisdictions for which no tax benefit was recorded increasing the 2016 first quarter effective tax rate by  5.7%.

[0001144204-17-006696:notes:48]
The Company estimates the fiscal 2017 effective tax rate will be approximately  34%. During the three-month period ended December 31, 2016, there was no material change in the unrecognized tax benefits. The Company does not anticipate a material change in the amount of unrecognized tax benefits in the next twelve months.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001144204-17-006696:notes:49]
|  | 12. | DERIVATIVE FINANCIAL INSTRUMENTS |

[0001144204-17-006696:notes:50]
Market risks relating to the Company’s operations result primarily from changes in interest rates and changes in foreign currency exchange rates. The Company is exposed to market risk related to changes in interest rates and selectively uses derivative financial instruments, including forward contracts and swaps, to manage these risks. During 2016, the Company entered into several forward contracts to purchase pounds sterling (GBP) to hedge two deferred payments due in connection with the acquisition of Plastique. The Company expects hedging gains or losses to be essentially offset by losses or gains on the related underlying exposures. All derivative instruments are reported in accrued expenses on the balance sheet at fair value. The derivative instruments are designated as cash flow hedges and the gain or loss on the derivative is deferred in accumulated other comprehensive income until recognized in earnings with the underlying hedged item.


## us-gaap:FairValueDisclosuresTextBlock

[0001144204-17-006696:notes:51]
| 13. | FAIR VALUE MEASUREMENTS |

[0001144204-17-006696:notes:52]
[same as prior period, unchanged from 0001144204-16-117178:notes:55]

[0001144204-17-006696:notes:53]
·    Level 1 – inputs to the valuation methodology are quoted prices (unadjusted) for identical assets or liabilities in active markets.

[0001144204-17-006696:notes:54]
·    Level 2 – inputs to the valuation methodology include quoted prices for similar assets and liabilities in active markets, and inputs that are observable for the asset or liability, either directly or indirectly, for substantially the full term of the financial instrument.

[0001144204-17-006696:notes:55]
·    Level 3 – inputs to the valuation methodology are unobservable and significant to the fair value measurement.

[0001144204-17-006696:notes:56]
[same as prior period, unchanged from 0001144204-16-117178:notes:59]

[0001144204-17-006696:notes:57]
The Company has estimated the fair value of its financial instruments as of December 31, 2016 and September 30, 2016 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, debt and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001144204-17-006696:notes:58]
[same as prior period, unchanged from 0001144204-16-117178:notes:61]

[0001144204-17-006696:notes:59]
[same as prior period, unchanged from 0001144204-16-117178:notes:62]

[0001144204-17-006696:notes:60]
[same as prior period, unchanged from 0001144204-16-117178:notes:63]

[0001144204-17-006696:notes:61]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during the three months ended December 31, 2016.


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0001144204-17-006696:notes:62]
The change in shareholders’ equity for the first three months of 2017 is shown below (in thousands):

[0001144204-17-006696:notes:63]
| Balance at September 30, 2016 |  | $ | 615,109 |  |
| Net earnings |  |  | 10,727 |  |
| Other comprehensive loss |  |  | (4,496) |  |
| Cash dividends |  |  | (2,057) |  |
| Stock compensation plans |  |  | 1,354 |  |
| Balance at December 31, 2016 |  | $ | 620,637 |  |


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001144204-17-006696:notes:64]
| 10. | SHAREHOLDERS’ EQUITY |
