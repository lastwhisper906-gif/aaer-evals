# ESE note change history — 0001144204-16-117178 → 0001144204-17-006696


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-02-08):
[0001144204-17-006696:note_history:1]
|  | 1. | BASIS OF PRESENTATION |
  (was, 2016-08-08, similarity 0.9667):
[0001144204-16-117178:note_history:1]
| 1. | BASIS OF PRESENTATION |

- changed (2017-02-08):
[0001144204-17-006696:note_history:2]
The accompanying consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP). For further information, refer to the consolidated financial statements and related notes included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2016.
  (was, 2016-08-08, similarity 0.9986):
[0001144204-16-117178:note_history:2]
The accompanying consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP). For further information, refer to the consolidated financial statements and related notes included in the Company's Annual Report on Form 10-K for the fiscal year ended September 30, 2015.

- changed (2017-02-08):
[0001144204-17-006696:note_history:3]
The Company’s results for the three-month period ended December 31, 2016 are not necessarily indicative of the results for the entire 2017 fiscal year. References to the first quarters of 2017 and 2016 represent the fiscal quarters ended December 31, 2016 and 2015, respectively.
  (was, 2016-08-08, similarity 0.7197):
[0001144204-16-117178:note_history:3]
The Company’s business is typically not impacted by seasonality; however, the results for the three and nine-month periods ended June 30, 2016 are not necessarily indicative of the results for the entire 2016 fiscal year. References to the third quarters of 2016 and 2015 represent the fiscal quarters ended June 30, 2016 and 2015, respectively.

- added (2017-02-08):
[0001144204-17-006696:note_history:4]
The preparation of financial statements in conformity with GAAP requires Management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.

- removed (2017-02-08):
[0001144204-16-117178:note_history:5]
In preparing the financial statements, the Company uses estimates and assumptions that may affect reported amounts and disclosures. The Company regularly evaluates the estimates and assumptions related to the allowance for doubtful trade receivables, inventory obsolescence, warranty reserves, value of equity-based awards, goodwill and purchased intangible asset valuations, asset impairments, employee benefit plan liabilities, income tax liabilities and assets and related valuation allowances, uncertain tax positions, and claims, litigation and other loss contingencies. Actual results could differ from those estimates.

- removed (2017-02-08):
[0001144204-16-117178:note_history:6]
The Company is organized based on the products and services that it offers. To enhance shareholders’ understanding of the Company’s underlying operations, beginning in the second quarter of 2016, Management expanded the presentation of its reporting segments to include “Technical Packaging”. The new Technical Packaging reporting segment was created to separately disclose Thermoform Engineered Quality LLC (TEQ) along with the recent acquisitions of Plastique Group Limited and Fremont Plastics, Inc., as it no longer met the criteria for aggregation with our Filtration/Fluid Flow (Filtration) reporting segment.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-02-08):
[0001144204-17-006696:note_history:7]
| 8. | DEBT |
  (was, 2016-08-08, similarity 0.9231):
[0001144204-16-117178:note_history:7]
|  | 8. | DEBT |

- added (2017-02-08):
[0001144204-17-006696:note_history:8]
| (In thousands) |  | December 31, 2016 |  | September 30, 2016 |  |
| Total borrowings |  | $ | 180,000 |  |  | 110,000 |  |
| Current portion of long-term debt |  |  | (20,000) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 160,000 |  |  | 90,000 |  |

- changed (2017-02-08):
[0001144204-17-006696:note_history:9]
The Company’s existing credit facility maturity date is December 21, 2020. The credit facility includes a $450 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the new facility is comprised of a diverse group of nine banks led by JPMorgan Chase Bank, N.A., as Administrative Agent.
  (was, 2016-08-08, similarity 0.7465):
[0001144204-16-117178:note_history:9]
On December 21, 2015, the Company amended its existing credit facility to extend the maturity date from May 13, 2017 through December 21, 2020, and to reduce the outstanding borrowing rates and commitment fees. Consistent with the prior credit facility, the amended facility includes a $450 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the new facility is comprised of a diverse group of nine banks led by JPMorgan Chase Bank, N.A., as Administrative Agent.

- added (2017-02-08):
[0001144204-17-006696:note_history:10]
At December 31, 2016, the Company had approximately $265 million available to borrow under the Credit Facility, and a $250 million increase option, in addition to $51.8 million of cash on hand. At December 31, 2016, the Company had $180 million of outstanding borrowings under the credit facility in addition to outstanding letters of credit of $4.6 million. The Company classified $20.0 million as the current portion of long-term debt as of December 31, 2016, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months.

- changed (2017-02-08):
[0001144204-17-006696:note_history:11]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from  12.5 to  27.5 basis points per annum on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a  65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were  1.61% and  1.41% for the three-month periods ending December 31, 2016 and 2015, respectively. At December 31, 2016, the Company was in compliance with all debt covenants.
  (was, 2016-08-08, similarity 0.8604):
[0001144204-16-117178:note_history:11]
The credit facility requires, as determined by certain financial ratios, a facility fee ranging from  12.5 to  27.5 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a  65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the credit facility also include a leverage ratio and an interest coverage ratio. The weighted average interest rates were  1.50% and  1.58% for the three and nine-month periods ending June 30, 2016, respectively, and  1.14% and  1.28% for the corresponding periods of 2015. At June 30, 2016, the Company was in compliance with all debt covenants.

- removed (2017-02-08):
[0001144204-16-117178:note_history:12]
| (In thousands) |  | June 30, 2016 |  | September 30, 2015 |  |
| Total borrowings |  | $ | 86,458 |  |  | 50,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (21,458) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 65,000 |  |  | 30,000 |  |

- removed (2017-02-08):
[0001144204-16-117178:note_history:13]
At June 30, 2016, the Company had approximately $361 million available to borrow under the credit facility, and a $250 million increase option, in addition to $40.5 million of cash on hand. At June 30, 2016, the Company had $85.0 million of outstanding borrowings under the credit facility and $1.5 million of other short-term borrowings in addition to outstanding letters of credit of $4.4 million. The Company’s ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-02-08):
[0001144204-17-006696:note_history:14]
| (In thousands) |  | December 31, 2016 |  | September 30, 2016 |  |
| Total borrowings |  | $ | 180,000 |  |  | 110,000 |  |
| Current portion of long-term debt |  |  | (20,000) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 160,000 |  |  | 90,000 |  |

- removed (2017-02-08):
[0001144204-16-117178:note_history:15]
| (In thousands) |  | June 30, 2016 |  | September 30, 2015 |  |
| Total borrowings |  | $ | 86,458 |  |  | 50,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (21,458) |  |  | (20,000) |  |
| Total long-term debt, less current portion |  | $ | 65,000 |  |  | 30,000 |  |
