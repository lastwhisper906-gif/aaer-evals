# ESE 10-Q controls and the auditor's report


## item_4_controls

[0001144204-17-006696:item_4_controls:1]
|  | ITEM 4. | CONTROLS AND PROCEDURES |

[0001144204-17-006696:item_4_controls:2]
The Company
carried out an evaluation, under the supervision and with the participation of Management, including the Company’s Chief
Executive Officer and Chief Financial Officer, of the effectiveness of the design and operation of the Company’s disclosure
controls and procedures as of the end of the period covered by this report. Based upon that evaluation, the Company’s Chief
Executive Officer and Chief Financial Officer concluded that the Company’s disclosure controls and procedures were effective
as of that date. Disclosure controls and procedures are controls and procedures that are designed to ensure that information required
to be disclosed in Company reports filed or submitted under the Securities Exchange Act of 1934 (the “Exchange Act”)
is recorded, processed, summarized and reported within the time periods specified in the Securities and Exchange Commission’s
rules and forms. There has been no change in the Company’s internal control over financial reporting (as defined in Rule
13a-15(f) under the Exchange Act) during the period covered by this report that has materially affected, or is reasonably likely
to materially affect, the Company’s internal control over financial reporting.

[0001144204-17-006696:item_4_controls:3]
15

[0001144204-17-006696:item_4_controls:4]
|  | PART II. | OTHER INFORMATION |

[0001144204-17-006696:item_4_controls:5]
|  | ITEM 6. | EXHIBITS |

[0001144204-17-006696:item_4_controls:6]
| Exhibit Number |  |  |  |  |
| 3.1(a) |  | Restated Articles of Incorporation |  | Incorporated by reference to Exhibit 3(a) to Form 10-K for the fiscal year ended September 30, 1999 (File No. 1-10596) |
| 3.1(b) |  | Amended Certificate of Designation, Preferences and Rights of Series A Participating Cumulative Preferred Stock of the Registrant |  | Incorporated by reference to Exhibit 4(e) to Form 10-Q for the fiscal quarter ended March 31, 2000 (File No. 1-10596) |
| 3.1(c) |  | Articles of Merger effective July 10, 2000 |  | Incorporated by reference to Exhibit 3(c) to Form 10-Q for the fiscal quarter ended June 30, 2000 (File No. 1-10596) |
| 3.2 |  | Bylaws |  | Incorporated by reference to Exhibit 3 to Form 8-K filed May 7, 2014 (File No. 1-10596) |
| 4.1 |  | Specimen revised Common Stock Certificate |  | Incorporated by reference to Exhibit 4.1 to Form 10-Q for the fiscal quarter ended March 31, 2010 (File No. 1-10596) |
| 4.2 |  | Amended and Restated Credit Agreement dated as of December 21, 2015 among the Registrant, the Foreign Subsidiary Borrowers from time to time party thereto, the Lenders from time to time party thereto, JP Morgan Chase Bank, N.A. as Administrative Agent, and Bank of America, N.A., BMO Harris Bank, N.A., SunTrust Bank and Wells Fargo Bank, National Association as Co-Documentation Agents |  | Incorporated by reference to Exhibit 4.1 to Form 8-K dated December 23, 2015 (File No. 1-10596) |
| 4.3 |  | Amendment No. 1 to December 21, 2015 Credit Agreement, effective September 30, 2016 |  | Incorporated by reference to Exhibit 4.4 to Form 10-K for the fiscal year ended September 30, 2016 (File No. 1-10596) |
| 31.1 |  | Certification of Chief Executive Officer relating to Form 10-Q for period ended December 31, 2016 |  | Filed herewith |
| 31.2 |  | Certification of Chief Financial Officer relating to Form 10-Q for period ended December 31, 2016 |  | Filed herewith |
| 32 |  | Certification of Chief Executive Officer and Chief Financial Officer relating to Form 10-Q for period ended December 31, 2016 |  | Filed herewith |
| 101.INS |  | XBRL Instance Document* |  | Submitted herewith |
| 101.SCH |  | XBRL Schema Document* |  | Submitted herewith |
| 101.CAL |  | XBRL Calculation Linkbase Document* |  | Submitted herewith |
| 101.DEF |  | XBRL Definition Linkbase Document* |  | Submitted herewith |
| 101.LAB |  | XBRL Label Linkbase Document* |  | Submitted herewith |
| 101.PRE |  | XBRL Presentation Linkbase Document* |  | Submitted herewith |

[0001144204-17-006696:item_4_controls:7]
*Exhibit 101 to this report consists of documents formatted
in XBRL (Extensible Business Reporting Language). The financial information contained in the XBRL – related documents is
“unaudited” or “unreviewed”.

[0001144204-17-006696:item_4_controls:8]
16

[0001144204-17-006696:item_4_controls:9]
SIGNATURE

[0001144204-17-006696:item_4_controls:10]
Pursuant to the requirements of the Securities Exchange Act
of 1934, the registrant has duly caused this report to be signed on its behalf by the undersigned thereunto duly authorized.

[0001144204-17-006696:item_4_controls:11]
|  | ESCO TECHNOLOGIES INC. |
|  | /s/ Gary E. Muenster |
|  | Gary E. Muenster |
|  | Executive Vice President and Chief Financial Officer |
|  | (As duly authorized officer and principal accounting and financial officer of the registrant) |

[0001144204-17-006696:item_4_controls:12]
Dated: February 8, 2017

[0001144204-17-006696:item_4_controls:13]
17
