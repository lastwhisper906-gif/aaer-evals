# ESE MD&A — 0001144204-17-006696


## mdna

[0001144204-17-006696:mdna:1]
|  | ITEM 2. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001144204-17-006696:mdna:2]
[same as prior period, unchanged from 0001144204-16-117178:mdna:2]

[0001144204-17-006696:mdna:3]
References to the first quarters of 2017 and 2016 represent
the three-month periods ended December 31, 2016 and 2015, respectively.

[0001144204-17-006696:mdna:4]
[same as prior period, unchanged from 0001144204-16-117178:mdna:4]

[0001144204-17-006696:mdna:5]
In the first quarter of 2017, sales, net earnings and diluted
earnings per share were $146.4 million, $10.7 million and $0.41 per share, respectively, compared to $132.8 million, $8.8 million
and $0.34 per share in the first quarter of 2016.

[0001144204-17-006696:mdna:6]
[same as prior period, unchanged from 0001144204-16-117178:mdna:6]

[0001144204-17-006696:mdna:7]
Net sales increased $13.6 million, or
10.2%, to $146.4 million in the first quarter of 2017 from $132.8 million in the first quarter of 2016. The increase in net sales
in the first quarter of 2017 as compared to the first quarter of 2016 was due to a $16.5 million increase in the Filtration segment,
a $5.0 million increase in the Technical Packaging segment, a $1.0 million increase in the USG segment, partially offset by an
$8.9 million decrease in the Test segment.

[0001144204-17-006696:mdna:8]
- Filtration

[0001144204-17-006696:mdna:9]
In the first quarter of 2017, net sales of $58 million were
$16.5 million, or 38.9%, higher than the $42.3 million in the first quarter of 2016. The sales increase in the first quarter of
2017 compared to the first quarter of 2016 was mainly due to: the sales contributions from the Company’s recent acquisitions
of Westland ($6.7 million) and Mayday ($6.2 million); and a $3.3 million increase in net sales at VACCO due to higher shipments
of its space and defense products.

[0001144204-17-006696:mdna:10]
[same as prior period, unchanged from 0001144204-16-117178:mdna:12]

[0001144204-17-006696:mdna:11]
In the first quarter of 2017, net sales
of $33.8 million were $8.9 million, or 20.9%, lower than the $42.8 million recorded in the first quarter of 2016. The sales decrease
in the first quarter of 2017 compared to the first quarter of 2016 was primarily due to a decrease in net sales from the segment’s
U.S. operations and European operations due to the timing of projects and lower sales volumes of domestic shielding products.

[0001144204-17-006696:mdna:12]
- Utility Solutions Group (USG)

[0001144204-17-006696:mdna:13]
Net sales increased $1.0 million, or 3.0%,
to $35.6 million in the first quarter of 2017 from $34.5 million in the first quarter of 2016. The sales increase in the first
quarter of 2017 compared to the first quarter of 2016 was mainly due to additional software and service revenue at Doble.

[0001144204-17-006696:mdna:14]
[same as prior period, unchanged from 0001144204-16-117178:mdna:10]

[0001144204-17-006696:mdna:15]
Net sales increased $5.0 million, or
37.7%, to $18.2 million in the first quarter of 2017 from $13.2 million in the first quarter of 2016. The sales increase in
the first quarter of 2017 compared to the first quarter of 2016 was primarily due to the $7.1 million sales contribution from
Plastique (acquired January 29, 2016), partially offset by a $2.1 million decrease in net sales from TEQ due to
lower shipments to medical customers.

[0001144204-17-006696:mdna:16]
[same as prior period, unchanged from 0001144204-16-117178:mdna:16]

[0001144204-17-006696:mdna:17]
Backlog was $368.9 million at December 31, 2016 compared with
$332.4 million at September 30, 2016. The Company received new orders totaling $182.9 million in the first quarter of 2017 compared
to $142.7 million in the first quarter of 2016. Of the new orders received in the first quarter of 2017, $67.5 million related
to Filtration products, $56.0 million related to Test products, $39.5 million related to USG products and $19.9 million related
to Technical Packaging products. Of the new orders received in the first quarter of 2016, $56.8 million related to Filtration products,
$38.9 million related to Test products, $31.2 million related to USG products and $15.8 million related to Technical Packaging
products.

[0001144204-17-006696:mdna:18]
[same as prior period, unchanged from 0001144204-16-117178:mdna:19]

[0001144204-17-006696:mdna:19]
Selling, general and administrative
(SG&A) expenses for the first quarter of 2017 were $33.8 million (23.1% of net sales), compared with $33.3 million (25.1%
of net sales) for the first quarter of 2016. The increase in SG&A expenses in the first quarter of 2017 compared to the first
quarter of 2016 was mainly due to an increase in SG&A expenses in the Filtration and Technical Packaging segments due to the
Company’s recent acquisitions (Westland, Mayday and Plastique) partially offset by a decrease in SG&A expenses in the
Test segment (as a result of the 2016 restructuring activities) and Corporate (lower professional fees related to M&A activities).

[0001144204-17-006696:mdna:20]
[same as prior period, unchanged from 0001144204-16-117178:mdna:21]

[0001144204-17-006696:mdna:21]
Amortization of intangible assets was $3.6 million and $2.7
million for the first quarters of 2017 and 2016, respectively. Amortization expenses consist of amortization of acquired intangible
assets from recent acquisitions and other identifiable intangible assets (primarily software, patents and licenses). The increase
in amortization expense in the first quarter of 2017 compared to the first quarter of 2016 was mainly due to an increase in amortization
of intangibles related to the Plastique, Westland and Mayday acquisitions.

[0001144204-17-006696:mdna:22]
[same as prior period, unchanged from 0001144204-16-117178:mdna:23]

[0001144204-17-006696:mdna:23]
Other income, net, was $0.8 million in
the first quarter of 2017 compared to other expenses, net, of $3.6 million in the first quarter of 2016. The principal component
in other income, net, in the first quarter of 2017 was $0.4 million of income related to death benefit insurance proceeds from
a former employee. The principal components in other expenses, net, in the first quarter of 2016 were $2.3 million of restructuring
costs related to the Test segment facility consolidation and $1.3 million of costs related to the USG segment restructuring activities.
The restructuring costs mainly related to severance and compensation benefits, professional fees and asset impairment charges related
to abandoned assets.

[0001144204-17-006696:mdna:24]
EBIT (Earnings before interest and taxes)

[0001144204-17-006696:mdna:25]
The Company evaluates the performance
of its operating segments based on EBIT, and provides EBIT on a consolidated basis, which is a non-GAAP financial measure. Please
refer to the discussion of non-GAAP financial measures in Note 7 to the Consolidated Financial Statements, above. EBIT was $16.8
million (11.5% of net sales) for the first quarter of 2017 compared to $13.2 million (9.9% of net sales) for the first quarter
of 2016.

[0001144204-17-006696:mdna:26]
The following table presents a reconciliation of
consolidated EBIT to net earnings.

[0001144204-17-006696:mdna:27]
| (In thousands) |  | Three Months Ended December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Consolidated EBIT |  | $ | 16,809 |  |  |  | 13,197 |  |
| Less: Interest expense, net |  |  | (684 | ) |  |  | (229 | ) |
| Less: Income tax expense |  |  | (5,398 | ) |  |  | (4,139 | ) |
| Net earnings |  | $ | 10,727 |  |  |  | 8,829 |  |

[0001144204-17-006696:mdna:28]
- Filtration

[0001144204-17-006696:mdna:29]
EBIT in the first quarter of 2017 was $10.7 million (18.2% of
net sales) compared to $8.3 million (19.6% of net sales) in the first quarter of 2016. The increase in EBIT in the first quarter
of 2017 compared to the first quarter of 2016 was due to the EBIT contribution from Westland (September 2, 2016 acquisition) and
an increase at PTI due to changes in product mix.

[0001144204-17-006696:mdna:30]
- Test

[0001144204-17-006696:mdna:31]
EBIT in the first quarter of 2017 was $2.4
million (7.2% of net sales) compared to $2.3 million (5.5% of net sales) in the first quarter of 2016. EBIT increased in the first
quarter of 2017 compared to the first quarter of 2016 mainly due to the $2.5 million of restructuring charges incurred in the first
quarter of 2016 related to closing the operating facilities in Taufkirchen, Germany and Stevenage, England; partially offset by
decrease in EBIT due to the lower sales volumes in the first quarter of 2017.

[0001144204-17-006696:mdna:32]
- Utility Solutions Group

[0001144204-17-006696:mdna:33]
EBIT in the first quarter of 2017 was $9.7
million (27.2% of net sales) compared to $8.2 million (23.9% of net sales) in the first quarter of 2016. The increase in EBIT in
the first quarter of 2017 compared to the first quarter of 2016 was primarily due to $1.3 million of restructuring charges incurred
in the first quarter of 2016 related to the closing of the Brazil office consisting mainly of employee severance and compensation
benefits and asset write downs.

[0001144204-17-006696:mdna:34]
[same as prior period, unchanged from 0001144204-16-117178:mdna:31]

[0001144204-17-006696:mdna:35]
EBIT in the first quarter of 2017 was
$1.0 million (5.7% of net sales) compared to $1.8 million (13.7% of net sales) in the first quarter of 2016. The decrease in EBIT
in the first quarter of 2017 compared to the first quarter of 2016 was mainly due to the lower sales volumes at TEQ and higher
SG&A expense.

[0001144204-17-006696:mdna:36]
- Corporate

[0001144204-17-006696:mdna:37]
Corporate costs included in EBIT were $7.0 million and $7.5
million in the first quarter of 2017 and 2016, respectively. The decrease in Corporate costs in the first quarter of 2017 compared
to the first quarter of 2016 was due to lower professional fees mainly related to M&A activities.

[0001144204-17-006696:mdna:38]
[same as prior period, unchanged from 0001144204-16-117178:mdna:39]

[0001144204-17-006696:mdna:39]
Interest expense was $0.7 million in the first quarter of 2017
compared to $0.2 million in the first quarter of 2016. The increase in interest expense in the first quarter of 2017 as compared
to the first quarter of 2016 was due to higher average interest rates (1.6% vs 1.4%) and higher average outstanding borrowings
($160.3 million vs. $70.3 million) as a result of the additional borrowings to fund the Company’s recent acquisitions.

[0001144204-17-006696:mdna:40]
[same as prior period, unchanged from 0001144204-16-117178:mdna:41]

[0001144204-17-006696:mdna:41]
Income tax expense in the first quarter
of 2017 was $5.4 million compared to $4.1 million in the first quarter of 2016. The first quarter 2017 effective income tax rate
was 33.5% compared to 31.9% in the first quarter of 2016. The increase in the effective income tax rate in the first quarter of
2017 was mainly due to the income tax expense in the first quarter of 2016 being favorably impacted by the extension of the research
credit as a result of The Protecting Americans from Tax Hikes Act reducing the 2016 first quarter effective tax rate by 6.6%.
In addition, the income tax expense in the first quarter of 2016 was unfavorably impacted by losses in foreign jurisdictions for
which no tax benefit was recorded increasing the 2016 first quarter effective tax rate by 5.7%.

[0001144204-17-006696:mdna:42]
The Company estimates the fiscal 2017 effective tax rate will
be approximately 34%. During the three-month period ended December 31, 2016, there was no material change in the unrecognized tax
benefits. The Company does not anticipate a material change in the amount of unrecognized tax benefits in the next twelve months.

[0001144204-17-006696:mdna:43]
The Company’s foreign subsidiaries
had accumulated unremitted earnings of $47.4 million and cash of $42.4 million at December 31, 2016. No deferred taxes have been
provided on the accumulated unremitted earnings because these funds are not needed to meet the liquidity requirements of the Company’s
U.S. operations and it is the Company’s intention to reinvest these earnings indefinitely. In the event these foreign entities’
earnings were distributed, it is estimated that U.S. taxes, net of available foreign tax credits, of approximately $7.7 million
would be due, which would correspondingly reduce the Company’s net earnings.

[0001144204-17-006696:mdna:44]
[same as prior period, unchanged from 0001144204-16-117178:mdna:46]

[0001144204-17-006696:mdna:45]
The Company’s overall financial
position and liquidity remains strong. Working capital (current assets less current liabilities) increased to $183.3 million at
December 31, 2016 from $165.4 million at September 30, 2016. The $11.4 million increase in inventories at December 31, 2016 was
mainly due to: a $10.8 million increase within the Filtration segment primarily related to the acquisition of Mayday in the first
quarter of 2017. Accounts receivable increased $5.7 million at December 31, 2016 primarily related to the acquisition of Mayday.
Accounts payable decreased $4.8 million in the first quarter of 2017 primarily due to a $4.3 million decrease within the Test
segment due to timing of payments.

[0001144204-17-006696:mdna:46]
Net cash provided by operating activities was $15.7 million
in the first quarter of 2017 compared to $1.3 million in the first quarter of 2016. The increase in the net cash provided by operating
activities in the first quarter of 2017 as compared to the first quarter of 2016 was mainly due to higher net earnings and lower
operating working capital requirements.

[0001144204-17-006696:mdna:47]
Capital expenditures were $7.0 million and $2.7 million in the
first quarter of 2017 and 2016, respectively. The increase in the first quarter of 2017 was mainly due an increase in machinery
and equipment additions at VACCO ($1.7 million) and Plastique ($1.3 million). In addition, the Company incurred expenditures for
capitalized software of $1.4 million and $1.7 million in the first quarter of 2017 and 2016, respectively.

[0001144204-17-006696:mdna:48]
Credit Facility

[0001144204-17-006696:mdna:49]
At December 31, 2016, the Company had approximately $265 million
available to borrow under its bank credit facility, a $250 million increase option, and $51.8 million cash on hand. At December
31, 2016, the Company had $180 million of outstanding borrowings under the credit facility in addition to outstanding letters of
credit of $4.6 million. Cash flow from operations and borrowings under the Company’s credit facility are expected to meet
the Company’s capital requirements and operational needs for the foreseeable future. The Company’s ability to access
the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.

[0001144204-17-006696:mdna:50]
Acquisition

[0001144204-17-006696:mdna:51]
On November 7, 2016, the Company acquired
aerospace suppliers Mayday Manufacturing Co. and its affiliate, Hi-Tech Metals, Inc. (collectively referred to as Mayday), located
in Denton, Texas, for a purchase price of $75 million in cash. Since the date of acquisition the consolidated operating results
for Mayday have been included in the Company’s Filtration segment.

[0001144204-17-006696:mdna:52]
[same as prior period, unchanged from 0001144204-16-117178:mdna:57]

[0001144204-17-006696:mdna:53]
A dividend of $0.08 per share was paid on October 17, 2016 to
stockholders of record as of October 3, 2016, totaling $2.1 million. Subsequent to December 31, 2016, the next quarterly dividend
of $0.08 per share, or $2.1 million, was paid on January 19, 2017 to stockholders of record as of January 4, 2017.

[0001144204-17-006696:mdna:54]
[same as prior period, unchanged from 0001144204-16-117178:mdna:59]

[0001144204-17-006696:mdna:55]
On a quarterly basis, Management continues
to expect 2017 revenues and EPS to reflect a profile similar to 2016, including EPS being more second-half weighted. Second quarter
2017 EPS is expected to be in the range of $0.37 to $0.42 per share. Management expects 2017 to be in the range of $2.16 - $2.26
per share.

[0001144204-17-006696:mdna:56]
[same as prior period, unchanged from 0001144204-16-117178:mdna:62]

[0001144204-17-006696:mdna:57]
Management has evaluated the accounting policies used in the
preparation of the Company’s financial statements and related notes and believes those policies to be reasonable and appropriate.
Certain of these accounting policies require the application of significant judgment by Management in selecting appropriate assumptions
for calculating financial estimates. By their nature, these judgments are subject to an inherent degree of uncertainty. These judgments
are based on historical experience, trends in the industry, information provided by customers and information available from other
outside sources, as appropriate. The most significant areas involving Management judgments and estimates may be found in the Critical
Accounting Policies section of Management’s Discussion and Analysis and in Note 1 to the Consolidated Financial Statements
contained in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2016.

[0001144204-17-006696:mdna:58]
[same as prior period, unchanged from 0001144204-16-117178:mdna:64]

[0001144204-17-006696:mdna:59]
Contingencies

[0001144204-17-006696:mdna:60]
As a normal incident of the business in
which the Company is engaged, various claims, charges and litigation are asserted or commenced against the Company. Additionally,
the Company is currently involved in various stages of investigation and remediation relating to environmental matters. In the
opinion of Management, the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might
be rendered against the Company, are adequately reserved, are covered by insurance, or would not have a material adverse effect
on the Company’s results from operations, capital expenditures, or competitive position.

[0001144204-17-006696:mdna:61]
[same as prior period, unchanged from 0001144204-16-117178:mdna:67]

[0001144204-17-006696:mdna:62]
Investors are cautioned that such statements
are only predictions and speak only as of the date of this Form 10-Q, and the Company undertakes no duty to update them except
as may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from
those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and
business environment, including but not limited to those described in Item 1A, “Risk Factors,” of the Company’s
Annual Report on Form 10-K for the fiscal year ended September 30, 2016, and the following: the impacts of natural disasters on
the Company’s operations and those of the Company’s customers and suppliers; the timing and content of future contract
awards or customer orders; termination for convenience of customer contracts or orders; financial exposure in connection with Company
guarantees of certain Aclara contracts; weakening of economic conditions in served markets; the success of the Company’s
competitors; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties;
the availability of selected acquisitions; delivery delays or defaults by customers; performance issues with key customers, suppliers
and subcontractors; material changes in the costs of certain raw materials; labor disputes; changes in laws and regulations including
but not limited to changes in accounting standards and taxation requirements; changes in interest rates; costs relating to environmental
matters; litigation uncertainty; and the Company’s successful execution of internal restructuring plans.
