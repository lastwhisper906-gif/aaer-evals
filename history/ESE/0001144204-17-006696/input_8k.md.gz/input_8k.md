# ESE 8-K — 0000866706-17-000002 filed 2017-02-07

## item codes, every 8-K on or before 2017-02-08

- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2017-02-08

- none on or before 2017-02-08

## item 2.02 — earnings release, exhibit 99.1

[0000866706-17-000002:8k_2_02:1]
EX-99.1
2
escopressrelease.htm
ESCO TECHNOLOGIES EARNINGS RELEASE

[0000866706-17-000002:8k_2_02:2]
escopressrelease.htm

[0000866706-17-000002:8k_2_02:3]
EXHIBIT 99.1

[0000866706-17-000002:8k_2_02:4]
NEWS FROM

[0000866706-17-000002:8k_2_02:5]
For more information contact:

[0000866706-17-000002:8k_2_02:6]
Kate Lowrey

[0000866706-17-000002:8k_2_02:7]
Director, Investor Relations

[0000866706-17-000002:8k_2_02:8]
ESCO Technologies Inc.

[0000866706-17-000002:8k_2_02:9]
(314) 213-7277

[0000866706-17-000002:8k_2_02:10]
ESCO ANNOUNCES FIRST QUARTER 2017 RESULTS

[0000866706-17-000002:8k_2_02:11]
EPS of $0.41 Tops November Guidance Range of $0.35 - $0.40

[0000866706-17-000002:8k_2_02:12]
ST. LOUIS, February 7, 2017 – ESCO Technologies Inc. (NYSE: ESE) (ESCO or the Company) today reported its operating results for the first quarter (Q1 2017) ended December 31, 2016.

[0000866706-17-000002:8k_2_02:13]
In 2016, Management completed its defined restructuring actions and presented its 2016 operating results on an “EPS – As Adjusted” basis, and reconciled these amounts to their respective GAAP equivalents.

[0000866706-17-000002:8k_2_02:14]
This release includes certain non-GAAP financial measures such as EPS – As Adjusted, and earnings before interest, taxes, depreciation and amortization (EBITDA). Management believes these non-GAAP financial measures are more representative of the Company’s ongoing performance, and therefore, allow shareholders better visibility into the Company’s underlying operations. See “Non-GAAP Financial Measures” described below.

[0000866706-17-000002:8k_2_02:15]
Earnings Summary

[0000866706-17-000002:8k_2_02:16]
| · | Q1 2017 GAAP EPS was $0.41 per share compared to Management’s previous GAAP guidance range of $0.35 to $0.40 per share; |

[0000866706-17-000002:8k_2_02:17]
| · | Compared to November expected guidance, the higher earnings were driven by increased software sales at Doble, additional operating efficiencies and a more favorable mix of commercial aerospace sales in Filtration, coupled with lower corporate spending. These were partially offset by lower sales and earnings resulting from the quarterly timing of deliveries on large projects at VACCO and Test; |

[0000866706-17-000002:8k_2_02:18]
| · | Q1 2016 GAAP EPS was $0.34 per share and EPS – As Adjusted was $0.47 per share; and, |

[0000866706-17-000002:8k_2_02:19]
| · | Q1 2017 EBITDA increased to $23.9 million from $18.6 million in Q1 2016. |

[0000866706-17-000002:8k_2_02:20]
Operating Highlights

[0000866706-17-000002:8k_2_02:21]
| · | Q1 2017 sales increased $14 million (10 percent) to $146 million compared to $133 million in Q1 2016; |

[0000866706-17-000002:8k_2_02:22]
| · | On a segment basis, Q1 2017 Filtration sales increased $16.5 million, or 39 percent (Westland and Mayday added $6.7 million and $6.2 million, respectively); Technical Packaging sales increased $5 million (Plastique added $7 million in sales and TEQ sales decreased $2 million due to the slowdown of KAZ deliveries described in the November release); Test sales decreased $9 million (quarterly timing of orders now in backlog described below); and Doble sales increased $1 million (additional new products); |

[0000866706-17-000002:8k_2_02:23]
| · | Despite the addition of the Plastique, Westland and Mayday acquisitions, Q1 2017 SG&A increased by only $0.5 million compared to Q1 2016. The additional SG&A costs related to these acquisitions were mitigated by a lower cost structure at Test and Doble, lower operating costs at PTI and Crissair, and lower Corporate spending; |

[0000866706-17-000002:8k_2_02:24]
| · | Other (income) expenses, net in Q1 2016 included restructuring costs incurred at Test and Doble; |

[0000866706-17-000002:8k_2_02:25]
| · | The effective tax rate was 33.5 percent in Q1 2017 compared to 31.9 percent in Q1 2016 which was favorably impacted by the extension of the research tax credit; |

[0000866706-17-000002:8k_2_02:26]
| · | Q1 2017 orders were $183 million (book-to-bill of 1.25x) reflecting a $37 million (11 percent) increase in backlog during Q1 2017, which resulted in an ending backlog of $369 million at December 31, 2016; |

[0000866706-17-000002:8k_2_02:27]
| · | Test orders were $56 million (book-to-bill of 1.66x) which reflects the catch-up of previously anticipated orders from a large/key customer, along with several other chamber project awards expected to be completed over the balance of 2017; |

[0000866706-17-000002:8k_2_02:28]
| · | Doble orders were $40 million (book-to-bill of 1.11x) including strong orders for new products such as the Doble Universal Controller (DUC), additional software applications, and expanded service contracts; |

[0000866706-17-000002:8k_2_02:29]
| · | Filtration orders were $68 million (book-to-bill of 1.15x) comprised of additional commercial aerospace orders and the addition of Mayday; |

[0000866706-17-000002:8k_2_02:30]
| · | Technical Packaging orders were $20 million (book-to-bill of 1.09x) driven by higher medical, medical device, and pharmaceutical projects; and, |

[0000866706-17-000002:8k_2_02:31]
| · | Net debt (outstanding borrowings less cash on hand) was $128 million at December 31, 2016. |

[0000866706-17-000002:8k_2_02:32]
Chairman’s Commentary – Q1 2017

[0000866706-17-000002:8k_2_02:33]
Vic Richey, Chairman and Chief Executive Officer, commented, “Despite facing some headwind from project timing at VACCO and Test, we were able to exceed our earnings commitments driven by the continued strength of Doble and our commercial aerospace businesses. Our cash flow and entered orders were strong in Q1 as we generated $16 million in cash from operating activities and recorded a positive book-to-bill ratio in every operating segment. The $56 million of Test orders are of special note as we’ve been experiencing order delays from one of our key customers for the past year, and I’m pleased to see these orders released in Q1 which gives me more confidence that Test will be able to meet its commitments for the year.

[0000866706-17-000002:8k_2_02:34]
“Doble’s results were above expectations on nearly every financial metric. Q1 sales were above plan and included higher than expected deliveries of new products such as the DUC and Doble Prime, as well as additional software and service revenues which carry higher margins.

[0000866706-17-000002:8k_2_02:35]
“Filtration exceeded expectations despite the sales push-out at VACCO resulting from project timing on a few large programs, which we expect to see delivered in the near future. Both PTI and Crissair delivered strong operating results and exceeded our Q1 targets driven by the continued strength of our commercial aerospace platform. Westland and Mayday are being integrated into the group and that process is going extremely well. The management teams that joined ESCO as part of these acquisitions are solid and are fully engaged in contributing to our success. Both companies are off to a good start by exceeding earnings and cash expectations in Q1.

[0000866706-17-000002:8k_2_02:36]
“Technical Packaging delivered its financial commitments and now that the KAZ program is back up and running at full rate, we expect to see its growth return to a more normalized level for the balance of the year.

[0000866706-17-000002:8k_2_02:37]
“Over the past few years, we have communicated our expectations with the goal of demonstrating consistency and predictability within our diversified, multi-segment operating structure, which is designed to reduce volatility and provide stable earnings. I believe Q1 demonstrates that our strategy and our structure are working.

[0000866706-17-000002:8k_2_02:38]
“On the acquisition front, I’m really impressed with the way our recent M&A partners have so quickly acclimated to being a part of ESCO as a public company, which is not an easy transition. The management teams we’ve added are a strong complement to the teams we have throughout the company. We continue to evaluate additional acquisitions and remain optimistic that we can further supplement our organic growth. We will remain disciplined in our approach and will continue to maintain our focus on generating an attractive ROIC.

[0000866706-17-000002:8k_2_02:39]
“We plan to continue to build on the current momentum we have, and we are maintaining a favorable view of our future with our goal remaining the same – to increase long-term shareholder value.”

[0000866706-17-000002:8k_2_02:40]
Dividend Payment

[0000866706-17-000002:8k_2_02:41]
The next quarterly cash dividend of $0.08 per share will be paid on April 18, 2017 to stockholders of record on April 3, 2017.

[0000866706-17-000002:8k_2_02:42]
Acquisition Update – 2017

[0000866706-17-000002:8k_2_02:43]
As described in the Company’s November 7, 2016 release, the Company acquired industry leading aerospace suppliers, Mayday Manufacturing Co. (Mayday) and its affiliate, Hi-Tech Metals, Inc. (Hi-Tech) located in Denton, Texas (collectively, Mayday). Mayday’s Q1 2017 results from the date of acquisition are included in the Company’s Filtration operating segment.

[0000866706-17-000002:8k_2_02:44]
Business Outlook – 2017

[0000866706-17-000002:8k_2_02:45]
Management’s current expectations for 2017 remain consistent with the details outlined in the Business Outlook presented in the Company’s November 7, 2016 release.

[0000866706-17-000002:8k_2_02:46]
Management continues to see meaningful sales, EBIT and EBITDA growth across each of the Company’s business segments and anticipates growth rates in 2017 and beyond, that exceed the Company’s defined peer group and the broader industrial market.

[0000866706-17-000002:8k_2_02:47]
Management continues to project 2017 GAAP EPS in the range of $2.16 to $2.26 per share, which includes the previously defined impact of the Mayday inventory “step up” charge in the first half of 2017 and the additional depreciation and amortization of intangibles resulting from the recent acquisitions.

[0000866706-17-000002:8k_2_02:48]
On a quarterly basis, Management continues to expect 2017 operating results to reflect a profile similar to 2016 and previous years, with revenues and EPS being more second-half weighted. As with past years, projected Q4 2017 sales and EPS are expected to be the strongest/highest of the fiscal year.

[0000866706-17-000002:8k_2_02:49]
Management expects Q2 2017 GAAP EPS to be in the range of $0.37 to $0.42 per share, which reflects the impact of the remaining balance of the inventory step-up charge of approximately $1 million, or $0.02 per share, as well as the quarterly impact of the incremental depreciation and amortization resulting from recent acquisitions as quantified previously.

[0000866706-17-000002:8k_2_02:50]
The timing of project deliveries on large programs can impact the timing of quarterly sales and earnings within the comparable quarters of 2017 and 2016.

[0000866706-17-000002:8k_2_02:51]
Chairman’s Commentary – 2017

[0000866706-17-000002:8k_2_02:52]
Mr. Richey continued, “We remain on track to achieve the sales, EPS, EBIT and EBITDA growth that we projected at the start of the year. Despite some project timing between Quarters, we wrapped up Q1 ahead of our earnings plan, and coupled with the significant Q1 orders received, provides me with additional confidence that we are well positioned to meet our 2017 commitments.

[0000866706-17-000002:8k_2_02:53]
“We remain focused on sales and earnings growth, and our market leadership positions as well as the breadth and diversity of our new product offerings should allow us to outperform the majority of our industrial peers and the overall industrial market.

[0000866706-17-000002:8k_2_02:54]
“I believe our outlook puts us in a solid position to meet our shareholder value-creation goals, both short-term and longer-term, and we continue to see opportunities to supplement our growth through accretive acquisitions. We remain committed to our longer-term growth targets and goals.”

[0000866706-17-000002:8k_2_02:55]
Conference Call

[0000866706-17-000002:8k_2_02:56]
The Company will host a conference call today, February 7, at 4:00 p.m. Central Time, to discuss the Company’s Q1 2017 results. A live audio webcast will be available on the Company’s website at www.escotechnologies.com. Please access the website at least 15 minutes prior to the call to register, download and install any necessary audio software. A replay of the conference call will be available for seven days on the Company’s website noted above or by phone (dial 1-855-859-2056 and enter the pass code 52559554).

[0000866706-17-000002:8k_2_02:57]
Forward-Looking Statements

[0000866706-17-000002:8k_2_02:58]
Statements in this press release regarding the Company’s expected quarterly and 2017 full year operating results, revenue and sales growth, EPS, EPS growth, EBIT, EBITDA, gross profit, interest expense, non-cash depreciation and amortization of intangibles, corporate costs, effective tax rates, the Company’s ability to increase operating margins, realize financial goals and increase shareholder value, the success of acquisition efforts, the size, number and timing of future sales and growth opportunities, the long-term success of the Company, and any other statements which are not strictly historical are “forward-looking” statements within the meaning of the safe harbor provisions of the federal securities laws.

[0000866706-17-000002:8k_2_02:59]
Investors are cautioned that such statements are only predictions and speak only as of the date of this release, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment including, but not limited to those described in Item 1A, “Risk Factors”, of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2016, and the following: the success of the Company’s competitors; site readiness issues with Test segment customers; weakening of economic conditions in served markets; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties; unforeseen charges impacting corporate operating expenses; delivery delays or defaults by customers; the performance of the Company’s international operations; material changes in the costs and availability of certain raw materials; the appropriation and allocation of Government funds; the termination for convenience of Government and other customer contracts; the timing and content of future contract awards or customer orders; containment of engineering and development costs; performance issues with key customers, suppliers and subcontractors; labor disputes; the impacts of natural disasters on the Company’s operations and those of the Company’s customers and suppliers; changes in laws and regulations, including but not limited to changes in accounting standards and taxation requirements; costs relating to environmental matters arising from current or former facilities; financial exposure in connection with Company guarantees of certain Aclara contracts; the availability of select acquisitions; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the Company’s successful execution of cost reduction and profit improvement initiatives.

[0000866706-17-000002:8k_2_02:60]
Non-GAAP Financial Measures

[0000866706-17-000002:8k_2_02:61]
The financial measures EBIT, EBITDA, and EPS – As Adjusted are presented in this press release. The Company defines “EBIT” as earnings before interest and taxes, “EBITDA” as earnings before interest, taxes, depreciation and amortization, and “EPS – As Adjusted” as GAAP earnings per share (EPS) excluding the restructuring charges described above which were $0.13 per share for Q1 2016.

[0000866706-17-000002:8k_2_02:62]
EBIT, EBITDA and EPS – As Adjusted are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management believes that EBIT and EBITDA are useful in assessing the operational profitability of the Company’s business segments because they exclude interest, taxes, depreciation and amortization, which are generally accounted for across the entire Company on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company as well as incentive compensation. The Company believes that the presentation of EBIT, EBITDA, and EPS – As Adjusted provides important supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance determined in accordance with GAAP.

[0000866706-17-000002:8k_2_02:63]
ESCO, headquartered in St. Louis: Manufactures highly-engineered filtration and fluid control products for the aviation, space and process markets worldwide; is the industry leader in RF shielding and EMC test products; provides diagnostic instruments, software and services for the benefit of the electric utility industry and industrial power users; and, produces custom thermoformed packaging, pulp based packaging, and specialty products for medical and commercial markets. Further information regarding ESCO and its subsidiaries is available on the Company’s website at www.escotechnologies.com.

[0000866706-17-000002:8k_2_02:64]
-  tables attached -

[0000866706-17-000002:8k_2_02:65]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Condensed Consolidated Statements of Operations (Unaudited) |  |
| (Dollars in thousands, except per share amounts) |  |

[0000866706-17-000002:8k_2_02:66]
|  |  | Three Months Ended December 31, 2016 |  |  |  |  |  | Three Months Ended December 31, 2015 |  |  |  |  |
| Net Sales |  | $ | 146,368 |  |  |  |  |  |  | 132,833 |  |  |  |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 92,914 |  |  |  |  |  |  | 80,049 |  |  |  |  |
| Selling, general and administrative expenses |  |  | 33,762 |  |  |  |  |  |  | 33,291 |  |  |  |  |
| Amortization of intangible assets |  |  | 3,649 |  |  |  |  |  |  | 2,694 |  |  |  |  |
| Interest expense |  |  | 684 |  |  |  |  |  |  | 229 |  |  |  |  |
| Other (income) expenses, net |  |  | (766 | ) |  |  |  |  |  | 3,602 |  |  |  |  |
| Total costs and expenses |  |  | 130,243 |  |  |  |  |  |  | 119,865 |  |  |  |  |
| Earnings before income taxes |  |  | 16,125 |  |  |  |  |  |  | 12,968 |  |  |  |  |
| Income taxes |  |  | 5,398 |  |  |  |  |  |  | 4,139 |  |  |  |  |
| Net earnings |  | $ | 10,727 |  |  |  |  |  |  | 8,829 |  |  |  |  |
| Diluted EPS - GAAP |  | $ | 0.41 | (1) |  |  |  |  |  |  | 0.34 | (2) |  |  |  |  |
| Diluted average common shares O/S: |  |  | 25,979 |  |  |  |  |  |  |  | 26,044 |  |  |  |  |  |

[0000866706-17-000002:8k_2_02:67]
| (1) | Includes Mayday inventory step up charge of $1.0 million and $1.7 million of additional depreciation and amortization compared to Q1 2016. |
| (2) | Q1 2016 EPS - As Adjusted was $0.47 which excluded $4.1 million (or $0.13 per share) of restructuring charges incurred at ETS & Doble. |

[0000866706-17-000002:8k_2_02:68]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Condensed Business Segment Information (Unaudited) |
| (Dollars in thousands) |

[0000866706-17-000002:8k_2_02:69]
|  |  | GAAP |  |  | Q1 2016 Adjustments (1) |  |  | As Adjusted |  |
|  |  |  | Q1 2017 |  |  |  | Q1 2016 |  |  |  |  |  |  | Q1 2017 |  |  |  | Q1 2016 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 58,785 |  |  |  | 42,317 |  |  |  | - |  |  |  | 58,785 |  |  |  | 42,317 |  |
| Test |  |  | 33,827 |  |  |  | 42,773 |  |  |  | - |  |  |  | 33,827 |  |  |  | 42,773 |  |
| USG |  |  | 35,556 |  |  |  | 34,522 |  |  |  | - |  |  |  | 35,556 |  |  |  | 34,522 |  |
| Technical Packaging |  |  | 18,200 |  |  |  | 13,221 |  |  |  | - |  |  |  | 18,200 |  |  |  | 13,221 |  |
| Totals |  | $ | 146,368 |  |  |  | 132,833 |  |  |  | - |  |  |  | 146,368 |  |  |  | 132,833 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 10,726 |  |  |  | 8,284 |  |  |  |  |  |  |  | 10,726 |  |  |  | 8,284 |  |
| Test |  |  | 2,425 |  |  |  | 2,338 |  |  |  | 2,512 |  |  |  | 2,425 |  |  |  | 4,850 |  |
| USG |  |  | 9,674 |  |  |  | 8,249 |  |  |  | 1,323 |  |  |  | 9,674 |  |  |  | 9,572 |  |
| Technical Packaging |  |  | 1,031 |  |  |  | 1,813 |  |  |  | - |  |  |  | 1,031 |  |  |  | 1,813 |  |
| Corporate |  |  | (7,047 | ) |  |  | (7,487 | ) |  |  | 293 |  |  |  | (7,047 | ) |  |  | (7,194 | ) |
| Consolidated EBIT |  |  | 16,809 |  |  |  | 13,197 |  |  |  | 4,128 |  |  |  | 16,809 |  |  |  | 17,325 |  |
| Less: Interest expense |  |  | (684 | ) |  |  | (229 | ) |  |  | - |  |  |  | (684 | ) |  |  | (229 | ) |
| Less: Income tax expense |  |  | (5,398 | ) |  |  | (4,139 | ) |  |  | (661 | ) |  |  | (5,398 | ) |  |  | (4,800 | ) |
| Net earnings |  | $ | 10,727 |  |  |  | 8,829 |  |  |  | 3,467 |  |  |  | 10,727 |  |  |  | 12,296 |  |

[0000866706-17-000002:8k_2_02:70]
| Note: | Depreciation and amortization expense increased $1.7 million in Q1 2017 and was $7.1 million and $5.4 million for the quarters ended December 31, 2016 and 2015, respectively. |
| (1) |  | Adjustments consist of $4.1 million (or $0.13 per share) of restructuring charges incurred at ETS and Doble during Q1 2016. |

[0000866706-17-000002:8k_2_02:71]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Condensed Consolidated Balance Sheets (Unaudited) |
| (Dollars in thousands) |

[0000866706-17-000002:8k_2_02:72]
|  |  | December 31, 2016 |  |  | September 30, 2016 |  |
| Assets |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 51,755 |  |  |  | 53,825 |  |
| Accounts receivable, net |  |  | 127,231 |  |  |  | 121,486 |  |
| Costs and estimated earnings on |  |  |  |  |  |  |  |  |
| long-term contracts |  |  | 25,165 |  |  |  | 28,746 |  |
| Inventories |  |  | 116,896 |  |  |  | 105,542 |  |
| Other current assets |  |  | 11,669 |  |  |  | 13,884 |  |
| Total current assets |  |  | 332,716 |  |  |  | 323,483 |  |
| Property, plant and equipment, net |  |  | 111,946 |  |  |  | 92,405 |  |
| Intangible assets, net |  |  | 266,408 |  |  |  | 231,759 |  |
| Goodwill |  |  | 353,303 |  |  |  | 323,616 |  |
| Other assets |  |  | 5,123 |  |  |  | 7,108 |  |
|  |  | $ | 1,069,496 |  |  |  | 978,371 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Short-term borrowings and current |  | $ | 20,000 |  |  |  | 20,000 |  |
| maturities of long-term debt |  |  |  |  |  |  |  |  |
| Accounts payable |  |  | 37,310 |  |  |  | 42,074 |  |
| Current portion of deferred revenue |  |  | 26,868 |  |  |  | 27,212 |  |
| Other current liabilities |  |  | 65,213 |  |  |  | 68,790 |  |
| Total current liabilities |  |  | 149,391 |  |  |  | 158,076 |  |
| Deferred tax liabilities |  |  | 84,498 |  |  |  | 69,562 |  |
| Other liabilities |  |  | 54,970 |  |  |  | 45,624 |  |
| Long-term debt |  |  | 160,000 |  |  |  | 90,000 |  |
| Shareholders' equity |  |  | 620,637 |  |  |  | 615,109 |  |
|  |  | $ | 1,069,496 |  |  |  | 978,371 |  |

[0000866706-17-000002:8k_2_02:73]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Consolidated Statements of Cash Flows (Unaudited) |
| (Dollars in thousands) |

[0000866706-17-000002:8k_2_02:74]
|  |  | Three Months Ended December 31, 2016 |  |
| Cash flows from operating activities: |  |  |  |
| Net earnings |  | $ | 10,727 |  |
| Adjustments to reconcile net earnings |  |  |  |  |
| to net cash provided by operating activities: |  |  |  |  |
| Depreciation and amortization |  |  | 7,088 |  |
| Stock compensation expense |  |  | 1,437 |  |
| Changes in assets and liabilities |  |  | (2,053 | ) |
| Effect of deferred taxes |  |  | (1,393 | ) |
| Other |  |  | (70 | ) |
| Net cash provided by operating activities |  |  | 15,736 |  |
| Cash flows from investing activities: |  |  |  |  |
| Acquisition of business, net of cash acquired |  |  | (75,000 | ) |
| Capital expenditures |  |  | (6,989 | ) |
| Additions to capitalized software |  |  | (1,433 | ) |
| Net cash used by investing activities |  |  | (83,422 | ) |
| Cash flows from financing activities: |  |  |  |  |
| Proceeds from long-term debt |  |  | 90,000 |  |
| Principal payments on long-term debt |  |  | (20,000 | ) |
| Dividends paid |  |  | (2,057 | ) |
| Other |  |  | (134 | ) |
| Net cash provided by financing activities |  |  | 67,809 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (2,193 | ) |
| Net decrease in cash and cash equivalents |  |  | (2,070 | ) |
| Cash and cash equivalents, beginning of period |  |  | 53,825 |  |
| Cash and cash equivalents, end of period |  | $ | 51,755 |  |

[0000866706-17-000002:8k_2_02:75]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |
| Other Selected Financial Data (Unaudited) |
| (Dollars in thousands) |

[0000866706-17-000002:8k_2_02:76]
| Backlog And Entered Orders - Q1 FY 2017 |  | USG |  |  | Test |  |  | Filtration |  |  | Technical Packaging |  |  | Total |  |
| Beginning Backlog - 10/1/16 |  | $ | 33,744 |  |  |  | 83,170 |  |  |  | 195,801 |  |  |  | 19,654 |  |  |  | 332,369 |  |
| Entered Orders |  |  | 39,520 |  |  |  | 56,015 |  |  |  | 67,505 |  |  |  | 19,860 |  |  |  | 182,900 |  |
| Sales |  |  | (35,556 | ) |  |  | (33,827 | ) |  |  | (58,785 | ) |  |  | (18,200 | ) |  |  | (146,368 | ) |
| Ending Backlog - 12/31/16 |  | $ | 37,708 |  |  |  | 105,358 |  |  |  | 204,521 |  |  |  | 21,314 |  |  |  | 368,901 |  |
