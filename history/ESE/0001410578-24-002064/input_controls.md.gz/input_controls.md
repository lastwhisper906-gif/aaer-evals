# ESE 10-K controls and the auditor's report


## auditors_report

[0001410578-24-002064:auditors_report:1]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001410578-24-002064:auditors_report:2]
Board of Directors and Shareholders

[0001410578-24-002064:auditors_report:3]
ESCO Technologies Inc.

[0001410578-24-002064:auditors_report:4]
Opinion on the financial statements

[0001410578-24-002064:auditors_report:5]
We have audited the accompanying consolidated balance sheets of ESCO Technologies Inc. (a Missouri corporation) and subsidiaries (the “Company”) as of September 30, 2024 and 2023, the related consolidated statements of operations, comprehensive income, shareholders’ equity, and cash flows for each of the three years in the period ended September 30, 2024, and the related notes (collectively referred to as the “financial statements”). In our opinion, the financial statements present fairly, in all material respects, the financial position of the Company as of September 30, 2024 and 2023, and the results of its operations and its cash flows for each of the three years in the period ended September 30, 2024, in conformity with accounting principles generally accepted in the United States of America.

[0001410578-24-002064:auditors_report:6]
We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (“PCAOB”), the Company’s internal control over financial reporting as of September 30, 2024, based on criteria established in the 2013 Internal Control—Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (“COSO”), and our report dated November 29, 2024, expressed an unqualified opinion.

[0001410578-24-002064:auditors_report:7]
Basis for opinion

[0001410578-24-002064:auditors_report:8]
These financial statements are the responsibility of the Company’s management. Our responsibility is to express an opinion on the Company’s financial statements based on our audits. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001410578-24-002064:auditors_report:9]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0001410578-24-002064:auditors_report:10]
Critical audit matter

[0001410578-24-002064:auditors_report:11]
The critical audit matter communicated below is a matter arising from the current period audit of the financial statements that was communicated or required to be communicated to the audit committee and that: (1) relates to accounts or disclosures that are material to the financial statements and (2) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0001410578-24-002064:auditors_report:12]
Revenue Recognition – Estimate of contract costs expected at completion

[0001410578-24-002064:auditors_report:13]
As described further in note 1 and 12 to the financial statements, the Company’s Aerospace & Defense and Test segments enter into certain long-term fixed price contracts with their customers to produce certain products that do not have an alternative use to the Company and for which the Company has an enforceable right to payment for costs incurred to date plus a reasonable margin. For the Aerospace & Defense segment, the Company uses a cost-to-cost method to recognize the revenue for these contracts over time. Using the cost-to-cost method, the Company measures progress to contract completion using the ratio of contracts’ costs incurred to date compared to estimated total contract cost at completion. Judgment is required in estimating the total contract cost at completion due to the unique specifications and requirements for each individual contract relating to the design, development, manufacturing, and installation of the build-to-spec products.

[0001410578-24-002064:auditors_report:14]
We identified the determination of the estimated total contract costs at completion for certain contracts in the Aerospace & Defense segment for which revenue is recognized over time using the cost-to-cost method as a critical audit matter.

[0001410578-24-002064:auditors_report:15]
F-2

[0001410578-24-002064:auditors_report:16]
The principal considerations for our determination that the estimated total contract costs at completion are a critical audit matter are that the estimated total contract costs at completion require complex judgment to evaluate the engineering and production requirements of the contract and the related labor and material costs, which are assumptions with a high level of estimation uncertainty and susceptibility to potential management bias. Changes to the assumptions used in developing these estimates may significantly impact the net sales and earnings recorded during the fiscal year.

[0001410578-24-002064:auditors_report:17]
Our audit procedures related to the estimated total contract costs at completion include the following, among others. We evaluated the design and tested the operating effectiveness of certain internal controls related to the Company’s revenue recognition and job cost processes. This included controls over the accumulation and estimation of costs to complete the contracts. For a selection of completed contracts, we compared the Company’s initial estimated costs and profit margin to the actual costs and profit margin to assess the Company’s ability to accurately estimate costs. We also tested the Company’s assumptions for labor hours, materials, and overhead to be incurred for a selection of in-process contracts by:

[0001410578-24-002064:auditors_report:18]
|  | ● | inspecting a sample of underlying contracts, including any applicable amendments, to obtain an understanding of the contractual requirements and deliverables and the nature of the costs necessary to fulfill those contracts. |

[0001410578-24-002064:auditors_report:19]
|  | ● | assessing the progress towards completion by performing inquiries of key financial and operational executives to evaluate the progress to date and factors impacting the estimated total contract costs expected at completion as well as attending certain regular operational meetings to observe discussions over progress and total estimated remaining costs. |

[0001410578-24-002064:auditors_report:20]
|  | ● | comparing the actual costs incurred to date, as a percentage of the estimated total contract costs at completion, and comparing that to the revenue recognized to date. |

[0001410578-24-002064:auditors_report:21]
|  | ● | comparing the margins experienced to date on in-process contracts to margins for similar contracts completed during the year. |

[0001410578-24-002064:auditors_report:22]
|  | ● | evaluating the estimates for indicators of management bias through the procedures described above. |

[0001410578-24-002064:auditors_report:23]
We have served as the Company’s auditor since 2021.

[0001410578-24-002064:auditors_report:24]
/s/ GRANT THORNTON LLP

[0001410578-24-002064:auditors_report:25]
St. Louis, Missouri

[0001410578-24-002064:auditors_report:26]
November 29, 2024

[0001410578-24-002064:auditors_report:27]
F-3

[0001410578-24-002064:auditors_report:28]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001410578-24-002064:auditors_report:29]
Board of Directors and Shareholders

[0001410578-24-002064:auditors_report:30]
ESCO Technologies Inc.

[0001410578-24-002064:auditors_report:31]
Opinion on internal control over financial reporting

[0001410578-24-002064:auditors_report:32]
We have audited the internal control over financial reporting of ESCO Technologies Inc. (a Missouri corporation) and subsidiaries (the “Company”) as of September 30, 2024, based on criteria established in the 2013 Internal Control—Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (“COSO”). In our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of September 30, 2024, based on criteria established in the 2013 Internal Control—Integrated Framework issued by COSO.

[0001410578-24-002064:auditors_report:33]
We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (“PCAOB”), the consolidated financial statements of the Company as of and for the year ended September 30, 2024, and our report dated November 29, 2024 expressed an unqualified opinion on those financial statements.

[0001410578-24-002064:auditors_report:34]
Basis for opinion

[0001410578-24-002064:auditors_report:35]
The Company’s management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Report on Internal Control Over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001410578-24-002064:auditors_report:36]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0001410578-24-002064:auditors_report:37]
Definition and limitations of internal control over financial reporting

[0001410578-24-002064:auditors_report:38]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001410578-24-002064:auditors_report:39]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001410578-24-002064:auditors_report:40]
/s/ GRANT THORNTON LLP

[0001410578-24-002064:auditors_report:41]
St. Louis, Missouri

[0001410578-24-002064:auditors_report:42]
November 29, 2024

[0001410578-24-002064:auditors_report:43]
F-4


## item_9a

[0001410578-24-002064:item_9a:1]
Item 9A. Controls and Procedures

[0001410578-24-002064:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001410578-24-002064:item_9a:3]
Our Chief Executive Officer and Chief Financial Officer (“Certifying Officers”) carried out an evaluation of the effectiveness of the design and operation of the Company’s disclosure controls and procedures, as defined in Rules 13a-1(c)) and 15(c)5(e) under the Securities Exchange Act of 1934, as amended (the Exchange Act) as of September 30, 2024. The evaluation was conducted under the supervision and with the participation of the Company’s Management, including the Company’s Chief Executive Officer and Chief Financial Officer, using the Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). Disclosure controls and procedures are designed to ensure that information required to be disclosed by the Company in reports filed or submitted under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the Securities and Exchange Commission’s rules and forms. Based upon that evaluation, the Company’s Chief Executive Officer and Chief Financial Officer concluded that the Company’s disclosure controls and procedures were effective as of September 30, 2024.

[0001410578-24-002064:item_9a:4]
Management’s Report on Internal Control Over Financial Reporting

[0001410578-24-002064:item_9a:5]
Management is responsible for establishing and maintaining adequate internal control over financial reporting, as defined in Rules 13a-15(f) and 15d-15(f) of the Exchange Act. The Company’s Management, with participation of the Certifying Officers, under the oversight of our Board of Directors, evaluated the effectiveness of the Company’s internal control over financial reporting as of September 30, 2024 using the framework in Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).  Because of its inherent limitations, any system of internal control over financial reporting, no matter how well designed, may not prevent or detect misstatement due to the possibility that a control can be circumvented or overridden or that misstatements due to error or fraud may occur that are not detected. Also, because of changes in conditions, internal control effectiveness may vary over time.

[0001410578-24-002064:item_9a:6]
Management assessed the effectiveness of the Company’s internal control over financial reporting as of September 30, 2024, using criteria established in Internal Control – Integrated Framework (2013) issued by COSO and concluded that the Company maintained effective internal control over financial reporting as of September 30, 2024, based on these criteria.

[0001410578-24-002064:item_9a:7]
Our internal control over financial reporting as of September 30, 2024, has been audited by Grant Thornton, an independent registered public accounting firm, as stated in its report which is included herein and incorporated herein by reference.

[0001410578-24-002064:item_9a:8]
Changes in Internal Control Over Financial Reporting

[0001410578-24-002064:item_9a:9]
No changes in the Company’s internal control over financial reporting (as defined in Rule 13a-15(f) under the Exchange Act) occurred during the fiscal quarter ended September 30, 2024, that have materially affected, or are reasonably likely to materially affect, the Company’s internal control over financial reporting.

[0001410578-24-002064:item_9a:10]
27
