# ESE MD&A — 0001410578-24-002064


## mdna

[0001410578-24-002064:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001410578-24-002064:mdna:2]
The following discussion should be read in conjunction with the Consolidated Financial Statements and Notes thereto and refers to our results from continuing operations except where noted.

[0001410578-24-002064:mdna:3]
Selected financial information for each of our business segments is provided in the discussion below and in Note 9 to the Company’s Consolidated Financial Statements.

[0001410578-24-002064:mdna:4]
This section includes comparisons of certain 2024 financial information to the same information for 2023. Year-to-year comparisons of the 2023 financial information to the same information for 2022 are contained in Item 7 of our Form 10-K for 2023 filed with the Securities and Exchange Commission on November 29, 2023 and available through the SEC’s website at https://www.sec.gov/edgar/searchedgar/companysearch.html.

[0001410578-24-002064:mdna:5]
Introduction

[0001410578-24-002064:mdna:6]
We classify our business operations into three segments for financial reporting purposes, although for reporting certain financial information we treat Corporate activities as a separate segment. Our three operating segments during 2024 were Aerospace & Defense (A&D), Utility Solutions Group (USG), and RF Test & Measurement (Test). Our operating segments are comprised of the following primary operating subsidiaries:

[0001410578-24-002064:mdna:7]
|  | ● | A&D: PTI Technologies Inc. (PTI); VACCO Industries (VACCO); Crissair, Inc. (Crissair); Globe Composite Solutions, LLC (Globe, including Westland Technologies, Inc.); and Mayday Manufacturing Co. (Mayday);. |

[0001410578-24-002064:mdna:8]
|  | ● | USG: Doble Engineering Company, Morgan Schaffer Ltd. (Morgan Schaffer) and I.S.A. – Altanova Group S.r.l. and affiliates (Altanova) (collectively, Doble); and NRG Systems, Inc. (NRG). |

[0001410578-24-002064:mdna:9]
|  | ● | Test: ETS-Lindgren Inc. (ETS-Lindgren) and MPE Limited (MPE). |

[0001410578-24-002064:mdna:10]
A&D.  PTI, VACCO and Crissair primarily design and manufacture specialty filtration products, including hydraulic filter elements and fluid control devices used in commercial and defense aerospace applications, unique filter mechanisms used in micro-propulsion devices for satellites and custom designed filters for manned aircraft and submarines. Globe designs, develops and manufactures elastomeric-based signature reduction solutions for U.S. naval vessels. Mayday manufactures mission-critical bushings, pins, sleeves and precision-tolerance machined components for landing gear, rotor heads, engine mounts, flight controls, and actuation systems for the aerospace and defense industries.

[0001410578-24-002064:mdna:11]
USG.  Doble develops, manufactures and delivers diagnostic testing solutions that enable electric power grid operators to assess the integrity of high-voltage power delivery equipment. NRG designs and manufactures decision support tools for the renewable energy industry, primarily wind and solar.

[0001410578-24-002064:mdna:12]
Test.  ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and control magnetic, electromagnetic and acoustic energy.

[0001410578-24-002064:mdna:13]
We continue to operate with meaningful growth prospects in our primary served markets and with considerable financial flexibility. We continue to focus on new products that incorporate proprietary design and process technologies. Our Management is committed to delivering shareholder value through organic growth, ongoing performance improvement initiatives, and acquisitions.

[0001410578-24-002064:mdna:14]
Highlights of 2024

[0001410578-24-002064:mdna:15]
|  | ● | Sales and net earnings in 2024 were $1,026.8 million and $101.9 million, respectively, compared to sales and net earnings in 2023 of $956.0 million and $92.5 million, respectively. |

[0001410578-24-002064:mdna:16]
|  | ● | Diluted EPS – GAAP for 2024 increased 10.1% to $3.94, compared to Diluted EPS – GAAP for 2023 of $3.58. |

[0001410578-24-002064:mdna:17]
|  | ● | Diluted EPS – As Adjusted for 2024 was $4.18 excluding $8.0 million of pretax charges (or $0.24 per share after tax), consisting of debt financing and acquisition costs at Corporate primarily related to the pending SM&P Acquisition that was announced in July 2024, restructuring charges in the A&D, Test and USG segments, and MPE purchase accounting adjustments. Diluted EPS – As Adjusted for 2023 was $3.70 excluding $4.1 million of pretax charges (or $0.12 per share after tax), consisting of executive management transition costs and acquisition related costs at Corporate, CMT purchase accounting adjustments, and restructuring charges primarily within the A&D segment. See “Non-GAAP Financial Measures” below. |

[0001410578-24-002064:mdna:18]
| ​ | ​ | Fiscal year ended |
| (Dollars in millions) |  | 2024 |  | 2023 |
| Diluted EPS – GAAP | ​ | $ | 3.94 |  | 3.58 |
| Debt financing costs related to pending SM&P Acquisition | ​ |  | 0.09 |  | — |
| Acquisition related costs | ​ |  | 0.06 |  | 0.01 |
| Restructuring adjustments | ​ | ​ | 0.05 |  | 0.03 |
| Purchase accounting adjustments | ​ | ​ | 0.04 | ​ | 0.02 |
| Executive management transition costs | ​ | ​ | — | ​ | 0.06 |
| Diluted EPS – As Adjusted | ​ | $ | 4.18 | ​ | 3.70 |

[0001410578-24-002064:mdna:19]
|  | ● | At September 30, 2024, cash on hand was $66.0 million and outstanding debt was $122.0 million, for a net debt position (total debt less cash on hand) of approximately $56.0 million. |

[0001410578-24-002064:mdna:20]
|  | ● | Entered orders for 2024 were $1,133.4 million resulting in a book-to-bill ratio of 1.10x. Backlog at September 30, 2024 was $879.0 million, an increase of $106.6 million, or 13.8%, compared to backlog of $772.4 million at September 30, 2023. |

[0001410578-24-002064:mdna:21]
|  | ● | The Company declared dividends of $0.32 per share during 2024, totaling $8.2 million in dividend payments. |

[0001410578-24-002064:mdna:22]
Results of Operations

[0001410578-24-002064:mdna:23]
Net Sales

[0001410578-24-002064:mdna:24]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | Change |  |
| ​ | ​ | Fiscal year ended | ​ | 2024 |  |
| (Dollars in millions) |  | 2024 |  | 2023 |  | vs. 2023 |  |
| A&D | ​ | $ | 448.2 |  | 392.4 |  | 14.2 | % |
| USG | ​ |  | 369.1 |  | 342.3 |  | 7.8 | % |
| Test | ​ |  | 209.5 |  | 221.3 |  | (5.3) | % |
| Total | ​ | $ | 1,026.8 |  | 956.0 |  | 7.4 | % |

[0001410578-24-002064:mdna:25]
Net sales increased $70.8 million, or 7.4%, to $1,026.8 million in 2024 from $956.0 million in 2023. The increase in net sales in 2024 as compared to 2023 was mainly due to a $55.8 million increase in the A&D segment and a $26.8 million increase in the USG segment, partially offset by an $11.8 million decrease in the Test segment.

[0001410578-24-002064:mdna:26]
A&D.

[0001410578-24-002064:mdna:27]
The $55.8 million, or 14.2%, increase in net sales in 2024 as compared to 2023 was mainly due to a $15.7 million increase in commercial aerospace revenues, a $20.3 million increase in defense aerospace revenues and a $20.0 million increase in navy revenues.

[0001410578-24-002064:mdna:28]
By subsidiary, the $55.8 million increase in net sales in 2024 as compared to 2023 was due to an $18.1 million increase in net sales at PTI, a $12.6 million increase in net sales at Globe, a $10.1 million increase in net sales at Crissair, a $7.6 million increase in net sales at Mayday and a $7.4 million increase in net sales at VACCO.

[0001410578-24-002064:mdna:29]
USG.

[0001410578-24-002064:mdna:30]
The $26.8 million, or 7.8%, increase in net sales in 2024 as compared to 2023 was mainly due to an $18.9 million increase in net sales at Doble mainly due to higher shipments of condition monitoring products and service revenue partially offset by lower shipments of protection testing products, and a $7.9 million increase in net sales at NRG driven by higher shipments of solar products.

[0001410578-24-002064:mdna:31]
Test.

[0001410578-24-002064:mdna:32]
The $11.8 million, or 5.3%, decrease in net sales in 2024 as compared to 2023 was due to an $11.8 million decrease in sales from the Company’s U.S. operations and a $2.8 million decrease in sales from the Company’s Asian operations due to lower wireless, filters and acoustic volumes and timing of test and measurement chamber projects partially offset by a $2.8 million increase in sales from the segment’s European operations. MPE contributed $10 million in revenue in 2024 since the date of acquisition.

[0001410578-24-002064:mdna:33]
Orders and Backlog

[0001410578-24-002064:mdna:34]
New orders received were $1,133.4 million in 2024 and $1,033.3 million in 2023. Order backlog was $879.0 million at September 30, 2024, compared to order backlog of $772.4 million at September 30, 2023. Orders are entered into backlog as firm purchase order commitments are received.

[0001410578-24-002064:mdna:35]
By operating segment, 2024 orders were $564.5 million related to A&D products, $355.6 million related to USG products, and $213.3 million related to Test products, and 2023 orders were $468.2 million related to A&D products, $347.6 million related to USG products, and $217.5 million related to Test products.

[0001410578-24-002064:mdna:36]
Selling, General and Administrative Expenses

[0001410578-24-002064:mdna:37]
Selling, general and administrative (SG&A) expenses were $224.0 million, or 21.8% of net sales, in 2024, and $217.1 million, or 22.7% of net sales, in 2023. The $6.9 million increase in SG&A expenses in 2024 as compared to 2023 was mainly due to an increase within the A&D and USG segments due to higher sales; inflationary impacts; and MPE acquisition impacts.

[0001410578-24-002064:mdna:38]
Amortization of Intangible Assets

[0001410578-24-002064:mdna:39]
Amortization of intangible assets was $32.8 million in 2024 and $29.0 million in 2023, including $20.7 million and $18.8 million of amortization of acquired intangible assets in 2024 and 2023, respectively, related to our acquisitions. The amortization of acquired intangible assets related to acquisitions is included in the Corporate segment’s results. The remaining amortization expenses relate to other identifiable intangible assets (primarily software, patents and licenses), which are included in the respective segment’s operating results. The increase in amortization expense in 2024 as compared to 2023 was mainly due to an increase in amortization of capitalized software and amortization of intangible assets related to the MPE acquisition.

[0001410578-24-002064:mdna:40]
Other Expenses, Net

[0001410578-24-002064:mdna:41]
Other expenses, net, was $2.1 million in 2024, compared to other expenses, net, of $1.9 million in 2023. The principal component of other expenses, net, in 2024 was approximately $1.8 million of restructuring costs within the A&D, USG and Test segments (mainly severance charges).  There were no individually significant items in other expenses, net in 2023.

[0001410578-24-002064:mdna:42]
Non-GAAP Financial Measures

[0001410578-24-002064:mdna:43]
The information reported herein includes the financial measures Diluted EPS As Adjusted, which we define as Diluted EPS excluding the per-share net impact of discrete debt financing and acquisition related costs at Corporate primarily related to the pending SM&P Acquisition, restructuring charges in the A&D, Test and USG segments (primarily severance) and purchase accounting charges related to the MPE acquisition in 2024; discrete compensation and acquisition related costs at Corporate, purchase accounting charges related to the CMT acquisition, and restructuring charges primarily within the A&D segment (primarily severance) in 2023; and the per-share net impact of discrete compensation and acquisition related costs, severance charges primarily within the A&D segment, and purchase accounting charges related to the Company’s acquisitions (Altanova and NEco) in 2022; EBIT, which we define as earnings before interest and taxes; and EBIT margin, which we define as EBIT expressed as a percentage of net sales. Diluted EPS –As Adjusted, EBIT on a consolidated basis, and EBIT margin on a consolidated basis are not recognized in accordance with U.S. generally accepted

[0001410578-24-002064:mdna:44]
accounting principles (GAAP). However, we believe that EBIT and EBIT margin provide investors and Management with valuable information for assessing our operating results. Management evaluates the performance of our operating segments based on EBIT and believes that EBIT is useful to investors to demonstrate the operational profitability of our business segments by excluding interest and taxes, which are generally accounted for across the entire company on a consolidated basis. EBIT is also one of the measures Management uses to determine resource allocations and incentive compensation. We believe that the presentation of EBIT, EBIT margin and Diluted EPS –As Adjusted provides important supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance determined in accordance with GAAP.

[0001410578-24-002064:mdna:45]
EBIT

[0001410578-24-002064:mdna:46]
The reconciliation of EBIT to a GAAP financial measure is as follows:

[0001410578-24-002064:mdna:47]
| (Dollars in millions) |  | 2024 |  | 2023 |
| Net earnings | ​ | $ | 101.9 | ​ | 92.5 |
| Add: Interest expense, net | ​ |  | 15.2 |  | 8.8 |
| Add: Income tax expense | ​ |  | 28.0 |  | 26.4 |
| EBIT | ​ | $ | 145.1 | ​ | 127.7 |

[0001410578-24-002064:mdna:48]
EBIT by business segment is as follows:

[0001410578-24-002064:mdna:49]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | Change |  |
| ​ | ​ | Fiscal year ended | ​ | 2024 |  |
| (Dollars in millions) |  | 2024 |  | 2023 |  | vs. 2023 |  |
| A&D | ​ | $ | 84.7 |  | 71.6 |  | 18.3 | % |
| % of net sales | ​ |  | 18.9 | % | 18.2 | % | — | ​ |
| USG | ​ |  | 85.9 |  | 76.7 |  | 12.0 | % |
| % of net sales | ​ |  | 23.3 | % | 22.4 | % | — | ​ |
| Test | ​ |  | 28.6 |  | 32.4 |  | (11.7) | % |
| % of net sales | ​ |  | 13.7 | % | 14.6 | % | — | ​ |
| Corporate | ​ |  | (54.1) |  | (53.0) |  | (2.1) | % |
| Total | ​ | $ | 145.1 |  | 127.7 |  | 13.6 | % |
| % of net sales | ​ |  | 14.1 | % | 13.4 | % | — | ​ |

[0001410578-24-002064:mdna:50]
A&D

[0001410578-24-002064:mdna:51]
The $13.1 million, or 18.3%, increase in EBIT in 2024 as compared to 2023 was primarily due to leverage on higher sales volumes and price increases at Mayday, PTI, Crissair and Globe partially offset by a decrease in EBIT at VACCO due to margin erosion on certain space development contracts, revenue mix and inflationary pressures. EBIT in 2024 was negatively impacted by $1.2 million in restructuring charges (mainly severance).

[0001410578-24-002064:mdna:52]
USG

[0001410578-24-002064:mdna:53]
The $9.2 million, or 12.0%, increase in EBIT in 2024 as compared to 2023 was mainly due to leverage on higher sales volumes at Doble and NRG with a favorable product mix and price increases, partially offset by inflationary pressures and higher commissions related to increased sales. EBIT in 2024 was negatively impacted by $0.2 million of restructuring charges (mainly severance).

[0001410578-24-002064:mdna:54]
Test

[0001410578-24-002064:mdna:55]
The $3.8 million, or 11.7%, decrease in EBIT in 2024 as compared to 2023 was primarily due to a decrease in EBIT from the segment’s U.S. and Asian operations and inflationary pressure, partially offset by leverage on higher sales volumes from the segment’s European operations and price increases and cost reduction actions from the segment’s U.S. operations. EBIT in 2024 was negatively impacted by $0.3 million of inventory step-up charges related to the MPE acquisition and $0.2 million of restructuring charges (mainly severance).

[0001410578-24-002064:mdna:56]
Corporate

[0001410578-24-002064:mdna:57]
Corporate operating charges included in 2024 consolidated EBIT increased to $54.1 million as compared to $53.0 million in 2023 mainly due to an increase in professional fees, including acquisition related costs, and amortization expense of acquired intangible assets related to the Company’s recent acquisition of MPE.

[0001410578-24-002064:mdna:58]
The “Reconciliation to Consolidated Totals (Corporate)” in Note 9 to the Consolidated Financial Statements represents Corporate office operating charges.

[0001410578-24-002064:mdna:59]
Interest Expense, Net

[0001410578-24-002064:mdna:60]
Interest expense, net was $15.2 million and $8.8 million in 2024 and 2023, respectively. The increase in interest expense in 2024 was mainly due to the $3.1 million of debt financing costs related to the pending SM&P Acquisition, higher average interest rates and higher outstanding borrowings. The weighted average interest rates were 6.72% in 2024 compared to 5.82% in 2023. Average outstanding borrowings were $167 million in 2024 compared to $140 million in 2023.

[0001410578-24-002064:mdna:61]
Income Tax Expense

[0001410578-24-002064:mdna:62]
The effective tax rates for 2024 and 2023 were 21.6% and 22.2%, respectively. The decrease in the 2024 effective tax rate as compared to 2023 was primarily due to a decrease in non-deductible executive compensation partially offset by an increase in state income tax expense.

[0001410578-24-002064:mdna:63]
Cash repatriated to the U.S. is generally not subject to U.S. federal income taxes. No provision has been made in 2024 for foreign withholding or any applicable U.S. income taxes on the undistributed earnings of non-U.S. subsidiaries where these earnings are considered indefinitely invested or otherwise retained for continuing international operations. Determination of the amount of taxes that might be paid on these undistributed earnings if eventually remitted is not practicable.

[0001410578-24-002064:mdna:64]
The Organization for Economic Co-operation and Development’s (OECD) Global Anti-Base Erosion Model (Pillar Two) rules are effective beginning with the Company’s fiscal year ending September 30, 2025. Pillar Two rules generally provide for a 15 percent minimum effective tax rate in every jurisdiction in which the Company operates. At present, Pillar Two is not expected to have a significant impact on our consolidated financial statements or related disclosures.

[0001410578-24-002064:mdna:65]
Acquisitions

[0001410578-24-002064:mdna:66]
Information regarding our acquisitions during 2024, 2023 and 2022 is set forth in Note 2 to the Consolidated Financial Statements, which Note is incorporated by reference herein.

[0001410578-24-002064:mdna:67]
All of our acquisitions have been accounted for using the purchase method of accounting, and accordingly, the respective purchase prices were allocated to the assets (including intangible assets) acquired and liabilities assumed based on estimated fair values at the date of acquisition. The financial results from these acquisitions have been included in our financial statements from the date of acquisition.

[0001410578-24-002064:mdna:68]
On July 8, 2024, the Company and certain of its wholly owned subsidiaries entered into a Sale and Purchase Agreement (“Purchase Agreement”) with Ultra Electronics Holdings Limited, a private limited liability company incorporated in England & Wales (“Ultra”), pursuant to which one or more wholly owned subsidiaries of the Company will acquire from Ultra or its subsidiaries Ultra’s Signature Management & Power (“SM&P”) business, including all of the issued and outstanding equity interests of (i) Ultra PMES Limited, a private limited liability company incorporated in England & Wales (“the UK Target Company”), (ii) Measurement Systems, Inc., a Delaware corporation, (iii) EMS Development Corporation, a New York corporation, and (iv) DNE Technologies, a Delaware corporation, for a purchase price of approximately $550 million, plus or minus certain customary adjustments at closing and post-closing for cash, debt, working capital and transaction expenses as specified in the Purchase Agreement (the “SM&P Acquisition”). The closing of the SM&P Acquisition is subject to certain conditions, including receipt of clearance under the UK National Security and Investment Act of 2021.

[0001410578-24-002064:mdna:69]
Capital Resources and Liquidity

[0001410578-24-002064:mdna:70]
Our overall financial position and liquidity are strong. Working capital (current assets less current liabilities) increased to $318.8 million at September 30, 2024 from $266.4 million at September 30, 2023. Accounts receivable increased by $42.1 million during 2024 mainly due to a $20.4 million increase within the A&D segment, a $12.2 million increase within the Test segment and a $9.5 million increase within the USG segment, driven by timing and higher sales volumes in the current year. Inventories increased by $25.1 million during 2024 mainly due to a $14.1 million increase within the A&D segment and a $10.8 million increase within the USG segment resulting primarily from the timing of finished goods and receipt of raw materials to meet anticipated demand and an increase in work in process inventories due to timing of manufacturing existing orders. Accounts payable increased by $11.4 million during 2024 mainly due to a $4.5 million increase within the A&D segment, a $3.1 million increase within the Test segment, a $2.3 million increase within the USG segment, and a $1.5 million increase at Corporate due to the timing of payments.

[0001410578-24-002064:mdna:71]
Net cash provided by operating activities was $127.5 million in 2024 and $76.9 million in 2023. The increase in net cash provided by operating activities in 2024 as compared to 2023 was mainly driven by higher net earnings and lower working capital requirements.

[0001410578-24-002064:mdna:72]
Net cash used in investing activities was $104.6 million in 2024 and $52.5 million in 2023. The increase in 2024 as compared to 2023 was mainly due to the MPE acquisition in the current year. Capital expenditures were $36.2 million in 2024 and $22.4 million in 2023. The increase in 2024 as compared to 2023 was mainly due to an increase in building improvements and machinery & equipment within the A&D segment. In addition, the Company incurred expenditures for capitalized software of $12.1 million in 2024 and $12.4 million in 2023.

[0001410578-24-002064:mdna:73]
There were no commitments outstanding that were considered material for capital expenditures at September 30, 2024.

[0001410578-24-002064:mdna:74]
Net cash used by financing activities was $0.8 million in 2024 and $78.3 million in 2023, primarily due to the increase in debt borrowings during 2024.

[0001410578-24-002064:mdna:75]
Bank Credit Facility

[0001410578-24-002064:mdna:76]
A description of our credit facility (the “Credit Facility”) is set forth in Note 6 to the Consolidated Financial Statements, which Note is incorporated by reference herein.

[0001410578-24-002064:mdna:77]
Cash flow from operations and borrowings under the Credit Facility is expected to provide adequate resources to meet our capital requirements and operational needs both for the next 12 months and for the foreseeable future.

[0001410578-24-002064:mdna:78]
Dividends

[0001410578-24-002064:mdna:79]
During both 2024 and 2023 we paid a regular quarterly cash dividend at an annual rate of $0.32 per share, totaling $8.2 million and $8.3 million in 2024 and 2023, respectively.

[0001410578-24-002064:mdna:80]
Off-Balance-Sheet Arrangements

[0001410578-24-002064:mdna:81]
We had no off-balance-sheet arrangements outstanding at September 30, 2024.

[0001410578-24-002064:mdna:82]
Share Repurchases

[0001410578-24-002064:mdna:83]
During 2024, the Company repurchased approximately 80,500 shares for approximately $8.0 million. During 2023, the Company repurchased approximately 140,000 shares for approximately $12.4 million. The Company did not purchase any shares during the fourth quarter of 2024.

[0001410578-24-002064:mdna:84]
Critical Accounting Estimates

[0001410578-24-002064:mdna:85]
The preparation of financial statements in conformity with U.S. generally accepted accounting principles (GAAP) requires Management to make estimates and assumptions in certain circumstances that affect amounts reported in the Consolidated Financial Statements. In preparing these financial statements, Management has made its best estimates and judgments of certain amounts included in the Consolidated Financial Statements, giving due consideration to materiality. We do not believe there is a great

[0001410578-24-002064:mdna:86]
likelihood that materially different amounts would be reported under different conditions or using different assumptions related to the accounting policies described below. However, application of these accounting policies involves the exercise of judgment and use of assumptions as to future uncertainties and, as a result, actual results could differ from these estimates. Our senior Management discusses the critical accounting policies described below with the Audit and Finance Committee of our Board of Directors on a periodic basis.

[0001410578-24-002064:mdna:87]
The following discussion of critical accounting policies is intended to bring to the attention of readers those accounting policies which Management believes are critical to the Consolidated Financial Statements and other financial disclosure. It is not intended to be a comprehensive list of all significant accounting policies that are more fully described in Note 1 to the Consolidated Financial Statements.

[0001410578-24-002064:mdna:88]
Revenue Recognition

[0001410578-24-002064:mdna:89]
We account for revenue in accordance with ASC Topic 606, Revenue from Contracts with Customers. The unit of account in ASC Topic 606 is a performance obligation. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration, as applicable, which are based on historical, current and forecasted information. The transaction price is allocated to each distinct performance obligation within the contract and recognized as revenue when, or as, the performance obligation is satisfied. Certain of our long-term contracts contain incentive fees that can increase the transaction price. These variable amounts generally are awarded upon achievement of certain performance metrics, program milestones or cost targets and can be based upon customer discretion. We include estimated amounts in the transaction price to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur. The estimated amounts are based on an assessment of our anticipated performance and all other information that is reasonably available to us.

[0001410578-24-002064:mdna:90]
Approximately 52% of the A&D segment’s revenue (23% of consolidated revenue) is recognized over time as the products do not have an alternative use and either we have an enforceable right to payment for costs incurred plus a reasonable margin or the inventory is owned by the customer. Selecting the method to measure progress towards completion for our contracts requires judgment and is based on the nature of the products or services to be provided.

[0001410578-24-002064:mdna:91]
The A&D segment generally uses the cost-to-cost method to measure progress on our contracts, as the rate at which costs are incurred to fulfill a contract best depicts the transfer of control to the customer. Under this method, we measure the extent of progress towards completion based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and we record revenue proportionally as costs are incurred based on an estimated profit margin.

[0001410578-24-002064:mdna:92]
The Test segment generally uses the milestone output method to measure progress on our contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. Under this method, we estimate profit as the difference between total revenue and total estimated costs at completion of a contract and recognize these revenues and costs based on milestones achieved.

[0001410578-24-002064:mdna:93]
Total contract cost estimates are based on current contract specifications and expected engineering requirements and require us to make estimates on expected profit. The estimates on profit are based on judgments we make to project the outcome of future events, and can often span more than one year and include labor productivity and availability, the complexity of the work to be performed, change orders issued by our customers, and other specialized engineering and production related activities. Our cost estimation process is based on historical results of contracts and historical actuals to original estimates, and the application of professional knowledge and experience of engineers and program managers along with finance professionals to these historical results. We review and update our estimates of costs quarterly or more frequently when circumstances significantly change, which can affect the profitability of our contracts.

[0001410578-24-002064:mdna:94]
For contracts where revenue is recognized over time, we recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. We have net revenue recognized in the current year from performance obligations satisfied in the prior year due to changes in our estimated costs to complete the related performance obligations. We recognize anticipated losses on contracts in full in the period in which the losses become known.

[0001410578-24-002064:mdna:95]
The impact of adjustments in contract estimates on our operating earnings can be reflected in either revenue or operating costs and expenses. The aggregate impact of adjustments in contract estimates decreased our earnings before income tax and diluted earnings per share by approximately $13 million and $0.38 per share, respectively, in 2024.

[0001410578-24-002064:mdna:96]
Income Taxes

[0001410578-24-002064:mdna:97]
We operate in numerous taxing jurisdictions and are subject to examination by various U.S. Federal, state and foreign jurisdictions for various tax periods. Our income tax positions are based on research and interpretations of the income tax laws and rulings in each of the jurisdictions in which we do business. Due to the subjectivity of interpretations of laws and rulings in each jurisdiction, the differences and interplay in tax laws between those jurisdictions, as well as the inherent uncertainty in estimating the final resolution of complex tax audit matters, Management’s estimates of income tax liabilities may differ from actual payments or assessments.

[0001410578-24-002064:mdna:98]
We account for income taxes under the asset and liability method. We recognize deferred tax assets and liabilities for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. We measure deferred tax assets and liabilities using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. We may reduce deferred tax assets by a valuation allowance if it is more likely than not that some portion of the deferred tax assets will not be realized. We recognize the effect on deferred tax assets and liabilities of a change in tax rates in income in the period that includes the enactment date. We regularly review our deferred tax assets for recoverability and establish a valuation allowance when Management believes it is more likely than not such assets will not be recovered, taking into consideration historical operating results, expectations of future earnings, tax planning strategies, and the expected timing of the reversals of existing temporary differences.

[0001410578-24-002064:mdna:99]
Goodwill and Other Long-Lived Assets

[0001410578-24-002064:mdna:100]
Our Management annually reviews goodwill and other long-lived assets for impairment or whenever events or changes in circumstances indicate the carrying amount may not be recoverable. If we determine that the carrying value of the goodwill and other long-lived assets may not be recoverable, we record a permanent impairment charge for the amount by which the carrying value of the goodwill and other long-lived assets exceeds its fair value. We measure fair value based on a discounted cash flow method using a discount rate determined by Management to be commensurate with the risk inherent in each of our reporting units’ or asset groups’ current business models. Our estimates of cash flows and discount rate are subject to change due to the economic environment, including such factors as interest rates, expected market returns and volatility of markets served. We believe that Management’s estimates of future cash flows and fair value are reasonable; however, changes in estimates could result in impairment charges. At September 30, 2024 we have determined that no goodwill or other long-lived assets were impaired.

[0001410578-24-002064:mdna:101]
We amortize intangible assets with estimable useful lives over their respective estimated useful lives to their estimated residual values, and review them for impairment whenever events or changes in business circumstances indicate the carrying value of the assets may not be recoverable.

[0001410578-24-002064:mdna:102]
Other Matters

[0001410578-24-002064:mdna:103]
Quantitative and Qualitative Disclosures about Market Risk

[0001410578-24-002064:mdna:104]
Market risks relating to our operations result primarily from changes in interest rates and changes in foreign currency exchange rates. We are exposed to market risk related to changes in interest rates, and we selectively use derivative financial instruments, including forward contracts and swaps, to manage these risks. Our Canadian subsidiary Morgan Schaffer has entered into foreign exchange contracts to manage foreign currency risk, because a portion of their revenue is denominated in U.S. dollars. We report all derivative instruments on our balance sheet at fair value. For derivative instruments designated as cash flow hedges, we defer the gain or loss on the derivative in accumulated other comprehensive income until recognized in earnings with the underlying hedged item.
