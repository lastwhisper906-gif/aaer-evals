# ESE 8-K — 0001104659-24-118951 filed 2024-11-14

## item codes, every 8-K on or before 2024-11-29

- 2024-11-14 0001104659-24-118951 — 2.02, 5.02, 7.01, 9.01
- 2024-10-18 0001104659-24-109788 — 5.02
- 2024-10-01 0001104659-24-104776 — 5.02
- 2024-08-07 0001104659-24-086768 — 1.01, 2.02, 5.02, 7.01, 9.01
- 2024-07-08 0001104659-24-078312 — 1.01, 7.01, 9.01
- 2024-05-09 0001104659-24-059341 — 2.02, 7.01, 9.01
- 2024-02-08 0001104659-24-012294 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2023-11-20 0001104659-23-119761 — 5.02, 9.01
- 2023-11-16 0001104659-23-119126 — 2.02, 7.01, 9.01
- 2023-10-03 0001104659-23-106090 — 5.02, 9.01
- 2023-09-06 0001104659-23-098463 — 1.01, 2.03, 9.01
- 2023-08-08 0001104659-23-088847 — 2.02, 7.01, 9.01
- 2023-07-06 0001104659-23-078571 — 5.02, 8.01, 9.01
- 2023-05-09 0001104659-23-057736 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2023-05-05 0001104659-23-056387 — 5.02, 9.01
- 2023-02-08 0001104659-23-014539 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2023-01-06 0001104659-23-001859 — 5.02, 9.01
- 2022-11-22 0001104659-22-121229 — 5.02, 5.03, 8.01, 9.01
- 2022-11-17 0001104659-22-119898 — 2.02, 7.01, 9.01
- 2022-09-12 0001104659-22-099248 — 5.02, 7.01, 9.01
- 2022-08-08 0001104659-22-087247 — 2.02, 5.02, 7.01, 9.01
- 2022-05-09 0001104659-22-057524 — 2.02, 5.02, 7.01, 9.01
- 2022-02-08 0001104659-22-013878 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2021-12-03 0001104659-21-146361 — 4.01, 9.01 — amendment, the index does not say of what
- 2021-11-24 0001104659-21-143568 — 4.01, 9.01
- 2021-11-23 0001104659-21-142871 — 5.02, 8.01
- 2021-11-18 0001104659-21-141206 — 2.02, 7.01, 9.01
- 2021-08-09 0001104659-21-102150 — 2.02, 7.01, 9.01
- 2021-05-04 0001104659-21-060985 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2021-04-05 0001104659-21-046581 — 5.02, 9.01
- 2021-02-08 0001104659-21-013712 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2020-12-09 0001104659-20-133674 — 5.02, 9.01
- 2020-12-07 0001104659-20-132861 — 5.02, 7.01, 9.01
- 2020-11-19 0001104659-20-127352 — 2.02, 5.02, 7.01, 9.01
- 2020-08-10 0001104659-20-092734 — 2.02, 7.01, 9.01
- 2020-05-06 0001104659-20-057442 — 2.02, 7.01, 8.01, 9.01
- 2020-02-04 0001104659-20-010640 — 2.02, 5.07, 7.01, 9.01
- 2020-01-07 0001104659-20-001789 — 2.01, 9.01
- 2019-11-19 0001104659-19-065437 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2019-11-18 0001104659-19-065096 — 1.01, 2.02, 7.01, 9.01
- 2019-09-30 0001144204-19-046523 — 1.01, 1.02, 2.03, 9.01
- 2019-08-08 0001144204-19-038567 — 2.02, 7.01, 9.01
- 2019-05-07 0001144204-19-024241 — 2.02, 5.02, 7.01, 9.01
- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2024-11-29

- none on or before 2024-11-29

## item 2.02 — earnings release, exhibit 99.1

[0001104659-24-118951:8k_2_02:1]
EX-99.1
2
tm2428429d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-24-118951:8k_2_02:2]
Exhibit 99.1

[0001104659-24-118951:8k_2_02:3]
| NEWS FROM |  |

[0001104659-24-118951:8k_2_02:4]
For more information contact:

[0001104659-24-118951:8k_2_02:5]
Kate Lowrey - VP of Investor Relations

[0001104659-24-118951:8k_2_02:6]
(314) 213-7277
/ klowrey@escotechnologies.com

[0001104659-24-118951:8k_2_02:7]
ESCO REPORTS FOURTH QUARTER AND FISCAL
2024 RESULTS

[0001104659-24-118951:8k_2_02:8]
- Q4 Sales increase 9.5% to $299 Million

[0001104659-24-118951:8k_2_02:9]
- Q4 GAAP EPS increase 6.5% to $1.32 -

[0001104659-24-118951:8k_2_02:10]
- Q4 Adjusted EPS increase 16.8% to $1.46
-

[0001104659-24-118951:8k_2_02:11]
- FY 2024 Sales increase 7.4% to $1.0 Billion
-

[0001104659-24-118951:8k_2_02:12]
- FY 2024 Entered Orders increase 9.7% to
$1.1 Billion -

[0001104659-24-118951:8k_2_02:13]
- FY 2024 GAAP EPS increase 10.1% to $3.94
-

[0001104659-24-118951:8k_2_02:14]
- FY 2024 Adjusted EPS increase 13.0% to
$4.18 -

[0001104659-24-118951:8k_2_02:15]
ST. LOUIS, November 14, 2024 – ESCO Technologies Inc. (NYSE:
ESE) (ESCO, or the Company) today reported its operating results for the fourth quarter and fiscal year ended September 30, 2024 (Q4 2024
and FY 2024, respectively).

[0001104659-24-118951:8k_2_02:16]
Operating Highlights

[0001104659-24-118951:8k_2_02:17]
|  | · | Q4 2024 Sales increased $26 million (9.5 percent) to $299 million compared to $273 million in Q4 2023. Q4 organic sales increased $23 million (8.5 percent) and the MPE acquisition contributed $3 million (1.0 percent) of revenue in the quarter. |

[0001104659-24-118951:8k_2_02:18]
|  | · | FY 2024 Sales increased $71 million (7.4 percent) to $1.03 billion compared to $956 million in FY 2023. Organic sales increased $61 million (6.4 percent) and the MPE acquisition added $10 million (1.0 percent) of revenue growth for the full year. |

[0001104659-24-118951:8k_2_02:19]
|  | · | Q4 2024 GAAP EPS increased 6.5 percent to $1.32 per share compared to $1.24 per share in Q4 2023. Q4 2024 Adjusted EPS increased 16.8 percent to $1.46 per share compared to $1.25 per share in Q4 2023. |

[0001104659-24-118951:8k_2_02:20]
|  | · | FY 2024 GAAP EPS increased 10.1 percent to $3.94 per share compared to $3.58 per share in FY 2023. FY 2024 Adjusted EPS increased 13.0 percent to $4.18 per share compared to $3.70 per share in FY 2023. |

[0001104659-24-118951:8k_2_02:21]
|  | · | Q4 2024 Entered Orders decreased $51 million (14.9 percent) to $289 million (book-to-bill of 0.97x). |

[0001104659-24-118951:8k_2_02:22]
|  | · | FY 2024 Entered Orders increased $100 million (9.7 percent) to $1.1 billion (book-to-bill of 1.10x), resulting in record year-end backlog of $879 million. |

[0001104659-24-118951:8k_2_02:23]
|  | · | Net cash provided by operating activities was $72 million in Q4 2024 and $128 million for FY 2024 (an increase of $51 million compared to FY 2023). |

[0001104659-24-118951:8k_2_02:24]
Bryan Sayler, Chief Executive Officer and President,
commented, “We finished the year strong with a solid Q4, highlighted by 9 percent sales growth, 130 basis points of Adjusted EBIT
margin improvement, and a 17 percent increase in Adjusted EPS. It was great to see all three segments deliver sales growth and margin
improvement in the quarter. We were also able to offset the impacts of profitability erosion on Space development programs at VACCO through
outstanding performance across our other businesses. PTI and Crissair in particular delivered excellent results in the quarter.

[0001104659-24-118951:8k_2_02:25]
“Overall, it was a great year as we delivered
record financial performance and notably eclipsed the $1 billion mark on sales and orders. I would like to thank our entire team for their
hard work and dedication in achieving these excellent results. We could not deliver multiple record years in a row without the strong
and engaged teams that exist across the Company.

[0001104659-24-118951:8k_2_02:26]
“As we enter 2025 there is a lot to be excited
about across the company and we continue to see strong growth drivers in place across our core aerospace, Navy, and electric power end
markets.”

[0001104659-24-118951:8k_2_02:27]
Segment Performance

[0001104659-24-118951:8k_2_02:28]
Aerospace & Defense (A&D)

[0001104659-24-118951:8k_2_02:29]
|  | · | Q4 2024 sales increased $17 million (16.2 percent) to $124 million from $107 million in Q4 2023. FY 2024 sales increased $56 million (14.2 percent) to $448 million from $392 million in FY 2023. Sales growth in both the quarter and the year was driven by strength across Navy, commercial aerospace, and defense aerospace programs. |

[0001104659-24-118951:8k_2_02:30]
|  | · | Q4 2024 EBIT increased $4.7 million to $23.4 million from $18.7 million in Q4 2023. Adjusted EBIT increased $5.1 million in Q4 2024 to $24.2 million (19.4 percent margin) from $19.1 million (17.8 percent margin) in Q4 2023. FY 2024 EBIT increased $13.1 million to $84.7 million from $71.6 million in FY 2023. FY 2024 Adjusted EBIT increased $12.8 million to $85.9 million (19.2 percent margin) from $73.1 million (18.6 percent margin) in FY 2023. Leverage on higher volume and price increases more than offset margin erosion on certain space development contracts and inflationary pressures in both the quarter and the year. |

[0001104659-24-118951:8k_2_02:31]
|  | · | Q4 2024 entered orders decreased $47 million (26.7 percent) to $130 million (book-to-bill of 1.05). Orders were lower in the quarter due to the timing of large Navy orders in the prior year Q4 (machining of Virginia Class Block V hull treatments and ejection valves). FY 2024 entered orders increased $96 million (20.6 percent) to $564 million (book-to-bill of 1.26). Growth in the year was driven by defense and commercial aerospace and large Navy orders (Virginia Class Block V additional hull treatments and QARMS), resulting in record year-end backlog of $600 million. |

[0001104659-24-118951:8k_2_02:32]
Utility Solutions Group (USG)

[0001104659-24-118951:8k_2_02:33]
|  | · | Q4 2024 sales increased $6 million (6.2 percent) to $108 million from $102 million in Q4 2023. Doble sales increased by $4.7 million (5.6 percent) and NRG sales increased by $1.7 million (8.6 percent). FY 2024 sales increased $27 million (7.8 percent) to $369 million from $342 million in FY 2023. Doble sales increased $19 million (6.8 percent) and NRG sales increased $8 million (12.2 percent) for the year. Sales growth in both the quarter and the year was driven by services and condition monitoring partially offset by lower protection testing at Doble and strong performance across our renewables product lines at NRG. |

[0001104659-24-118951:8k_2_02:34]
|  | · | Q4 2024 EBIT and Adjusted EBIT both increased $2.4 million to $28.6 million (26.4 percent margin) from $26.2 million (25.7 percent margin) in Q4 2023. FY 2024 EBIT increased $9.2 million to $85.9 million from $76.7 million in FY 2023. FY 2024 Adjusted EBIT also increased $9.2 million to $86.1 million (23.3 percent margin) from $76.9 million (22.5 percent margin) in FY 2023. Adjusted EBIT increases for the quarter and year were largely driven by leverage on higher volumes and price increases, partially offset by inflationary pressures. |

[0001104659-24-118951:8k_2_02:35]
|  | · | Q4 2024 entered orders increased $2 million (2.2 percent) to $100 million (book-to-bill of 0.92) as Doble orders decreased $5 million (5.4 percent) to $81 million and NRG orders increased $7 million (56.0 percent) to $19 million compared to the prior year quarter. FY 2024 entered orders increased $8 million (2.3 percent) to $356 million (book-to-bill of 0.96) resulting in year-end backlog of $120 million. For the year, Doble orders increased $11 million (3.9 percent) on increased electric utility spending and NRG orders decreased $3 million (4.3 percent) as the market moved beyond last year’s elevated activity related to the initial Inflation Reduction Act spending. |

[0001104659-24-118951:8k_2_02:36]
RF Test & Measurement (Test)

[0001104659-24-118951:8k_2_02:37]
|  | · | Q4 2024 sales increased $2 million (3.6 percent) to $66 million from $64 million in Q4 2023. Organic sales were down slightly, but more than offset by $2.8 million of revenue related to the MPE acquisition which was completed in Q1 2024. FY 2024 sales decreased $12 million (5.3 percent) to $210 million. Test’s revenues were somewhat soft throughout the year related to lower wireless sales and weakness in China. However, the addition of MPE and strength in medical shielding and T&M projects for Aerospace and Defense customers helped drive a return to year-over-year growth in the back half of the year. |

[0001104659-24-118951:8k_2_02:38]
|  | · | Q4 2024 EBIT and Adjusted EBIT both increased $0.9 million to $12.0 million (18.3 percent margin) from $11.1 million (17.5 percent margin) in Q4 2023. Test’s record Q4 margin was driven by high-margin MPE content, cost reduction actions and price increases, partially offset by inflationary pressures. FY 2024 EBIT decreased $3.8 million to $28.6 million from $32.4 million in FY 2023. FY 2024 Adjusted EBIT decreased $3.3 million to $29.1 million (13.9 percent margin) from $32.4 million (14.6 percent margin) in FY 2023. For the year margin was impacted by lower sales of high-margin wireless and US filters volume and inflationary pressures, largely mitigated by price increases, cost reduction actions, and the addition of higher margin MPE content. |

[0001104659-24-118951:8k_2_02:39]
|  | · | Q4 2024 entered orders decreased $5.5 million (8.5 percent) to $59 million. The decrease was primarily related to a large utility shielding order that was booked in Q4 2023. FY 2024 entered orders decreased $4 million to $213 million (book-to-bill of 1.02) resulting in year-end backlog of $159 million. The decrease in orders for the year was primarily driven by lower wireless activity and delays on test and measurement projects in China. |

[0001104659-24-118951:8k_2_02:40]
SM&P Acquisition

[0001104659-24-118951:8k_2_02:41]
As announced on July 8, 2024, ESCO
has agreed to acquire the Signature Management & Power (SM&P) business of Ultra Maritime for a purchase price of $550 million.
The closing of the transaction is subject to certain conditions, including the completion of the regulatory approval processes in the
United States (US) and the United Kingdom (UK). The US closing conditions have been met. The UK government is currently assessing the
transaction, and we are optimistic that the assessment will be positively resolved. Our current expectation would be to close the transaction
in our second fiscal quarter. SM&P’s sole source product offerings will add significant scale to the ESCO Navy business, providing
increased content on domestic Navy submarine and surface ship programs and expansion into vital UK and AUKUS navy platforms.

[0001104659-24-118951:8k_2_02:42]
Business Outlook – 2025

[0001104659-24-118951:8k_2_02:43]
Management expects growth in sales, Adjusted EBIT, and Adjusted EBITDA
across each of the Company’s business segments in 2025. Our FY 2025 guidance excludes the impacts of:

[0001104659-24-118951:8k_2_02:44]
|  | · | SM&P – the SM&P acquisition is expected to close in Q2 FY’25 and our guidance will be adjusted after the closing. |

[0001104659-24-118951:8k_2_02:45]
|  | · | Our ongoing strategic review of the Space business at VACCO. |

[0001104659-24-118951:8k_2_02:46]
Management’s expectations for growth in 2025 compared to 2024:

[0001104659-24-118951:8k_2_02:47]
|  | · | Net sales are expected to grow 6 to 8 percent to a range of $1.09 to $1.11 billion on a consolidated basis, with A&D growing 7 to 9 percent, USG growing 7 to 9 percent, and Test growing 3 to 5 percent. |

[0001104659-24-118951:8k_2_02:48]
|  | · | Adjusted EBIT is expected to increase approximately 12 to 15 percent with Adjusted EBIT margins increasing to 15.3 to 15.7 percent of sales. |

[0001104659-24-118951:8k_2_02:49]
|  | · | Adjusted EBITDA is expected to increase approximately 10 to 13 percent with Adjusted EBITDA margins increasing to 20.5 to 21.0 percent of sales. |

[0001104659-24-118951:8k_2_02:50]
|  | · | The effective income tax rate is expected to be in the range of 23.0 to 23.5 percent in 2025. |

[0001104659-24-118951:8k_2_02:51]
|  | · | FY 2025 Adjusted EPS is expected to increase 12 to 17 percent to a range of $4.70 to $4.90 per share. |

[0001104659-24-118951:8k_2_02:52]
|  | · | Management expects Q1 2025 Adjusted EPS to increase 10 to 21 percent compared to the prior year first quarter and to be in the range of $0.68 - $0.75 per share. Consistent with prior years, revenues and Adjusted EPS are expected to grow sequentially throughout the year. |

[0001104659-24-118951:8k_2_02:53]
VACCO Space Business Strategic Review

[0001104659-24-118951:8k_2_02:54]
The Company is in the process of conducting a strategic review of alternatives
for the Space business at VACCO. The intent is to optimize ESCO’s portfolio of businesses and create value for ESCO shareholders.
This decision was made as part of our continual strategic portfolio analysis, which is focused on positioning the Company to serve high-growth
markets that have high-margin potential. As we conduct this review, we remain committed to executing on our current Space programs and
serving the needs of our customers. VACCO operates two distinct product lines today, Space and Defense. As this review has evolved, our
key consideration has become the feasibility of splitting these two businesses apart.

[0001104659-24-118951:8k_2_02:55]
There is no deadline or definitive timetable for
completion of the strategic alternatives review process and there can be no assurance that this process will result in the Company pursuing
a transaction or any other strategic outcome. The Company does not intend to make any further public comment regarding the review of strategic
alternatives for the Space business at VACCO until it has been completed or the Company determines that a disclosure is required or otherwise
deemed appropriate.

[0001104659-24-118951:8k_2_02:56]
Share Repurchase Program

[0001104659-24-118951:8k_2_02:57]
The Company did not repurchase any shares of stock
during Q4 2024. During FY 2024 the Company repurchased approximately 80,000 shares for $8 million.

[0001104659-24-118951:8k_2_02:58]
Dividend Payment

[0001104659-24-118951:8k_2_02:59]
The next quarterly cash dividend
of $0.08 per share will be paid on January 17, 2025 to stockholders of record on January 2, 2025.

[0001104659-24-118951:8k_2_02:60]
2025 Annual Meeting

[0001104659-24-118951:8k_2_02:61]
The 2025 Annual Meeting of the Company’s shareholders will be
held on February 4, 2025.

[0001104659-24-118951:8k_2_02:62]
Conference Call

[0001104659-24-118951:8k_2_02:63]
The Company will host a conference call today, November 14, at 4:00
p.m. Central Time, to discuss the Company’s Q4 2024 results. A live audio webcast and an accompanying slide presentation will be
available in the Investor Center of ESCO’s website. Participants may also access the webcast using this registration link.
For those unable to participate, a webcast replay will be available after the call in the Investor Center of ESCO’s website.

[0001104659-24-118951:8k_2_02:64]
Forward-Looking Statements

[0001104659-24-118951:8k_2_02:65]
Investors are cautioned that such statements are
only predictions and speak only as of the date of this release, and the Company undertakes no duty to update them except as may be required
by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the
forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment including
but not limited to those described in Item 1A, “Risk Factors”, of the Company’s Annual Report on Form 10-K for the fiscal
year ended September 30, 2023 and the following: the timing and outcome, if any, of the Company’s strategic alternatives review
for the Space business at VACCO; of the Company’s pending acquisition of SM&P; the impacts of climate change and related regulation
of greenhouse gases; the impacts of labor disputes, civil disorder, wars, elections, political changes, tariffs and trade disputes, terrorist
activities, cyberattacks or natural disasters on the Company’s operations and those of the Company’s customers and suppliers;
disruptions in manufacturing or delivery arrangements due to shortages or unavailability of materials or components or supply chain disruptions;
inability to access work sites; the timing and content of future contract awards or customer orders; the timely appropriation, allocation
and availability of Government funds; the termination for convenience of Government and other customer contracts or orders; weakening
of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies;
competition; intellectual property rights; technical difficulties or data breaches; the availability of acquisitions; delivery delays
or defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability
of certain raw materials; material changes in the cost of credit; changes in laws and regulations including but not limited to changes
in accounting standards and taxation; changes in interest, inflation and employment rates; costs relating to environmental matters arising
from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration;
and the integration and performance of acquired businesses.

[0001104659-24-118951:8k_2_02:66]
Non-GAAP Financial Measures

[0001104659-24-118951:8k_2_02:67]
The financial measures EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA,
and Adjusted EPS are presented in this press release. The Company defines “EBIT” as earnings before interest and taxes, “EBITDA”
as earnings before interest, taxes, depreciation and amortization, “Adjusted EBIT” and “Adjusted EBITDA” as excluding
the net impact of the items described in the attached Reconciliation of Non-GAAP Financial Measures, and “Adjusted EPS” as
GAAP earnings per share excluding the net impact of the items described and reconciled in the attached Reconciliation of Non-GAAP Financial
Measures.

[0001104659-24-118951:8k_2_02:68]
EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA, and
Adjusted EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management believes
EBIT, Adjusted EBIT, EBITDA, and Adjusted EBITDA are useful in assessing the operational profitability of the Company’s business
segments because they exclude interest, taxes, depreciation, and amortization, which are generally accounted for across the entire Company
on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company as
well as incentive compensation. The presentation of EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA, and Adjusted EPS provides important
supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures
to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance determined
in accordance with GAAP.

[0001104659-24-118951:8k_2_02:69]
ESCO is a global provider of highly engineered products and solutions
serving diverse end-markets. It manufactures filtration and fluid control products for the aviation, Navy, space, and process markets
worldwide and composite-based products and solutions for Navy, defense, and industrial customers. ESCO is an industry leader in designing
and manufacturing RF test and measurement products and systems; and provides diagnostic instruments, software and services to industrial
power users and the electric utility and renewable energy industries. Headquartered in St. Louis, Missouri, ESCO and its subsidiaries
have offices and manufacturing facilities worldwide. For more information on ESCO and its subsidiaries, visit the Company’s website
at www.escotechnologies.com.

[0001104659-24-118951:8k_2_02:70]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-118951:8k_2_02:71]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-24-118951:8k_2_02:72]
(Dollars in thousands, except per share amounts)

[0001104659-24-118951:8k_2_02:73]
|  |  | Three Months Ended September 30, 2024 |  |  | Three Months Ended September 30, 2023 |  |
| Net Sales |  | $ | 298,533 |  |  |  | 272,647 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 178,808 |  |  |  | 164,424 |  |
| Selling, general and administrative expenses |  |  | 59,995 |  |  |  | 56,555 |  |
| Amortization of intangible assets |  |  | 8,219 |  |  |  | 7,930 |  |
| Interest expense |  |  | 6,019 |  |  |  | 2,347 |  |
| Other expenses (income), net |  |  | 1,450 |  |  |  | 199 |  |
| Total costs and expenses |  |  | 254,491 |  |  |  | 231,455 |  |
| Earnings before income taxes |  |  | 44,042 |  |  |  | 41,192 |  |
| Income tax expense |  |  | 9,779 |  |  |  | 9,195 |  |
| Net earnings |  | $ | 34,263 |  |  |  | 31,997 |  |
| Earnings Per Share (EPS) |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 1.32 |  |  |  | 1.24 |  |
| Diluted - As Adjusted Basis |  |  | $1.46 | (1) |  |  | 1.25 | (2) |
| Diluted average common shares O/S: |  |  | 25,854 |  |  |  | 25,862 |  |

[0001104659-24-118951:8k_2_02:74]
|  | (1) | Q4 2024 Adjusted EPS excludes $0.14 per share of after-tax charges consisting primarily of $0.09 of debt financing and $0.03 of acquisition costs at Corporate related to the pending SM&P acquisition that was announced in July 2024, and $0.02 of restructuring charges (primarily severance) in the A&D segment. |

[0001104659-24-118951:8k_2_02:75]
|  | (2) | Q4 2023 Adjusted EPS excludes $0.01 per share of after-tax restructuring charges primarily at Westland (severance and asset write-off). |

[0001104659-24-118951:8k_2_02:76]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-118951:8k_2_02:77]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-24-118951:8k_2_02:78]
(Dollars in thousands, except per share amounts)

[0001104659-24-118951:8k_2_02:79]
|  |  | Year Ended September 30, 2024 |  |  | Year Ended September 30, 2023 |  |
| Net Sales |  | $ | 1,026,759 |  |  |  | 956,033 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 622,741 |  |  |  | 580,377 |  |
| Selling, general and administrative expenses |  |  | 224,015 |  |  |  | 217,110 |  |
| Amortization of intangible assets |  |  | 32,804 |  |  |  | 28,953 |  |
| Interest expense |  |  | 15,247 |  |  |  | 8,769 |  |
| Other expenses (income), net |  |  | 2,063 |  |  |  | 1,877 |  |
| Total costs and expenses |  |  | 896,870 |  |  |  | 837,086 |  |
| Earnings before income taxes |  |  | 129,889 |  |  |  | 118,947 |  |
| Income tax expense |  |  | 28,008 |  |  |  | 26,402 |  |
| Net earnings |  | $ | 101,881 |  |  |  | 92,545 |  |
| Earnings Per Share (EPS) |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 3.94 |  |  |  | 3.58 |  |
| Diluted - As Adjusted Basis |  |  | $4.18 | (1) |  |  | 3.70 | (2) |
| Diluted average common shares O/S: |  |  | 25,872 |  |  |  | 25,879 |  |

[0001104659-24-118951:8k_2_02:80]
|  | (1) | FY 24 Adjusted EPS excludes $0.24 per share of after-tax charges consisting primarily of $0.09 of debt financing and $0.06 of acquisition costs at Corporate related to the pending SM&P acquisition that was announced in July 2024; $0.05 of restructuring charges (primarily severance) in the A&D, Test and USG segments; and $0.04 of MPE acquisition backlog and inventory step-up charges. |

[0001104659-24-118951:8k_2_02:81]
|  | (2) | FY 23 Adjusted EPS excludes $0.12 per share of after-tax charges consisting of $0.06 of executive management transition costs at Corporate, $0.02 of CMT acquisition inventory step-up charges, $0.03 of restructuring charges within the A&D segment and $0.01 of Corporate acquisition related costs. |

[0001104659-24-118951:8k_2_02:82]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-118951:8k_2_02:83]
Condensed Business Segment Information (Unaudited)

[0001104659-24-118951:8k_2_02:84]
(Dollars in thousands)

[0001104659-24-118951:8k_2_02:85]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | Q4 2024 |  |  | Q4 2023 |  |  | Q4 2024 |  |  | Q4 2023 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 124,291 |  |  |  | 107,009 |  |  |  | 124,291 |  |  |  | 107,009 |  |
| USG |  |  | 108,491 |  |  |  | 102,148 |  |  |  | 108,491 |  |  |  | 102,148 |  |
| Test |  |  | 65,751 |  |  |  | 63,490 |  |  |  | 65,751 |  |  |  | 63,490 |  |
| Totals |  | $ | 298,533 |  |  |  | 272,647 |  |  |  | 298,533 |  |  |  | 272,647 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 23,351 |  |  |  | 18,647 |  |  |  | 24,170 |  |  |  | 19,075 |  |
| USG |  |  | 28,563 |  |  |  | 26,179 |  |  |  | 28,593 |  |  |  | 26,242 |  |
| Test |  |  | 12,015 |  |  |  | 11,115 |  |  |  | 12,015 |  |  |  | 11,115 |  |
| Corporate |  |  | (13,868 | ) |  |  | (12,402 | ) |  |  | (12,955 | ) |  |  | (12,402 | ) |
| Consolidated EBIT |  |  | 50,061 |  |  |  | 43,539 |  |  |  | 51,823 |  |  |  | 44,030 |  |
| Less: Interest expense |  |  | (6,019 | ) |  |  | (2,347 | ) |  |  | (2,969 | ) |  |  | (2,347 | ) |
| Less: Income tax expense |  |  | (9,779 | ) |  |  | (9,195 | ) |  |  | (10,886 | ) |  |  | (9,308 | ) |
| Net earnings |  | $ | 34,263 |  |  |  | 31,997 |  |  |  | 37,968 |  |  |  | 32,375 |  |

[0001104659-24-118951:8k_2_02:86]
Note 1: Adjusted net earnings of $38.0 million in Q4 2024 exclude $3.7 million (or $0.14 per share) of after-tax charges consisting primarily of $0.12 of debt financing and acquisition costs at Corporate related to the pending SM&P acquisition that was announced in July 2024 and $0.02 of restructuring charges (primarily severance) in the A&D segment.

[0001104659-24-118951:8k_2_02:87]
Note 2: Adjusted net earnings of $32.4 million in Q4 2023 exclude $0.4 million (or $0.01 per share) of after-tax restructuring charges primarily at Westland (severance and asset write-off)

[0001104659-24-118951:8k_2_02:88]
| EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |  | Q4 2024 |  |  | Q4 2023 |  |
|  |  | Q4 2024 |  |  | Q4 2023 |  |  | As Adjusted |  |  | As Adjusted |  |
| Consolidated EBITDA |  | $ | 64,112 |  |  |  | 56,363 |  |  |  | 65,874 |  |  |  | 56,854 |  |
| Less: Depr & Amort |  |  | (14,051 | ) |  |  | (12,824 | ) |  |  | (14,051 | ) |  |  | (12,824 | ) |
| Consolidated EBIT |  |  | 50,061 |  |  |  | 43,539 |  |  |  | 51,823 |  |  |  | 44,030 |  |
| Less: Interest expense |  |  | (6,019 | ) |  |  | (2,347 | ) |  |  | (2,969 | ) |  |  | (2,347 | ) |
| Less: Income tax expense |  |  | (9,779 | ) |  |  | (9,195 | ) |  |  | (10,886 | ) |  |  | (9,308 | ) |
| Net earnings |  | $ | 34,263 |  |  |  | 31,997 |  |  |  | 37,968 |  |  |  | 32,375 |  |

[0001104659-24-118951:8k_2_02:89]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-118951:8k_2_02:90]
Condensed Business Segment Information (Unaudited)

[0001104659-24-118951:8k_2_02:91]
(Dollars in thousands)

[0001104659-24-118951:8k_2_02:92]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | FY 2024 |  |  | FY 2023 |  |  | FY 2024 |  |  | FY 2023 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 448,175 |  |  |  | 392,443 |  |  |  | 448,175 |  |  |  | 392,443 |  |
| USG |  |  | 369,061 |  |  |  | 342,320 |  |  |  | 369,061 |  |  |  | 342,320 |  |
| Test |  |  | 209,523 |  |  |  | 221,270 |  |  |  | 209,523 |  |  |  | 221,270 |  |
| Totals |  | $ | 1,026,759 |  |  |  | 956,033 |  |  |  | 1,026,759 |  |  |  | 956,033 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 84,747 |  |  |  | 71,643 |  |  |  | 85,917 |  |  |  | 73,070 |  |
| USG |  |  | 85,918 |  |  |  | 76,722 |  |  |  | 86,143 |  |  |  | 76,915 |  |
| Test |  |  | 28,629 |  |  |  | 32,395 |  |  |  | 29,110 |  |  |  | 32,395 |  |
| Corporate |  |  | (54,158 | ) |  |  | (53,044 | ) |  |  | (51,079 | ) |  |  | (50,531 | ) |
| Consolidated EBIT |  |  | 145,136 |  |  |  | 127,716 |  |  |  | 150,091 |  |  |  | 131,849 |  |
| Less: Interest expense |  |  | (15,247 | ) |  |  | (8,769 | ) |  |  | (12,197 | ) |  |  | (8,769 | ) |
| Less: Income tax expense |  |  | (28,008 | ) |  |  | (26,402 | ) |  |  | (29,849 | ) |  |  | (27,353 | ) |
| Net earnings |  | $ | 101,881 |  |  |  | 92,545 |  |  |  | 108,045 |  |  |  | 95,727 |  |

[0001104659-24-118951:8k_2_02:93]
Note 1: Adjusted net earnings of $108.0 million in FY 2024 exclude $6.2 million (or $0.24 per share) of after-tax charges consisting primarily of $0.15 of debt financing and acquisition costs at Corporate related to the pending SM&P acquisition that was announced in July 2024; $0.05 of restructuring charges (primarily severance) in the A&D, Test and USG segments; and $0.04 of MPE acquisition backlog and inventory step-up charges.

[0001104659-24-118951:8k_2_02:94]
Note 2: Adjusted net earnings of $95.7 million in FY 2023 exclude $3.2 million (or $0.12 per share) of after-tax charges consisting of $0.06 of executive management transition costs at Corporate, $0.02 of CMT acquisition inventory step-up charges, $0.03 of restructuring charges within the A&D segment, and $0.01 of Corporate acquisition related costs.

[0001104659-24-118951:8k_2_02:95]
| EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |  | FY 2024 |  |  | FY 2023 |  |
|  |  | FY 2024 |  |  | FY 2023 |  |  | As Adjusted |  |  | As Adjusted |  |
| Consolidated EBITDA |  | $ | 200,545 |  |  |  | 178,239 |  |  |  | 204,664 |  |  |  | 182,372 |  |
| Less: Depr & Amort |  |  | (55,409 | ) |  |  | (50,523 | ) |  |  | (54,573 | ) |  |  | (50,523 | ) |
| Consolidated EBIT |  |  | 145,136 |  |  |  | 127,716 |  |  |  | 150,091 |  |  |  | 131,849 |  |
| Less: Interest expense |  |  | (15,247 | ) |  |  | (8,769 | ) |  |  | (12,197 | ) |  |  | (8,769 | ) |
| Less: Income tax expense |  |  | (28,008 | ) |  |  | (26,402 | ) |  |  | (29,849 | ) |  |  | (27,353 | ) |
| Net earnings |  | $ | 101,881 |  |  |  | 92,545 |  |  |  | 108,045 |  |  |  | 95,727 |  |

[0001104659-24-118951:8k_2_02:96]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-118951:8k_2_02:97]
Condensed Consolidated Balance Sheets (Unaudited)

[0001104659-24-118951:8k_2_02:98]
(Dollars in thousands)

[0001104659-24-118951:8k_2_02:99]
|  |  | September 30, 2024 |  |  | September 30, 2023 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 65,963 |  |  |  | 41,866 |  |
| Accounts receivable, net |  |  | 240,680 |  |  |  | 198,557 |  |
| Contract assets |  |  | 130,534 |  |  |  | 138,633 |  |
| Inventories |  |  | 209,164 |  |  |  | 184,067 |  |
| Other current assets |  |  | 22,308 |  |  |  | 17,972 |  |
| Total current assets |  |  | 668,649 |  |  |  | 581,095 |  |
| Property, plant and equipment, net |  |  | 170,596 |  |  |  | 155,484 |  |
| Intangible assets, net |  |  | 407,602 |  |  |  | 392,124 |  |
| Goodwill |  |  | 539,899 |  |  |  | 503,177 |  |
| Operating lease assets |  |  | 37,744 |  |  |  | 39,839 |  |
| Other assets |  |  | 14,130 |  |  |  | 11,495 |  |
|  |  | $ | 1,838,620 |  |  |  | 1,683,214 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt |  | $ | 20,000 |  |  |  | 20,000 |  |
| Accounts payable |  |  | 98,371 |  |  |  | 86,973 |  |
| Contract liabilities |  |  | 124,845 |  |  |  | 112,277 |  |
| Other current liabilities |  |  | 106,638 |  |  |  | 95,401 |  |
| Total current liabilities |  |  | 349,854 |  |  |  | 314,651 |  |
| Deferred tax liabilities |  |  | 75,333 |  |  |  | 75,531 |  |
| Non-current operating lease liabilities |  |  | 34,810 |  |  |  | 36,554 |  |
| Other liabilities |  |  | 39,273 |  |  |  | 43,336 |  |
| Long-term debt |  |  | 102,000 |  |  |  | 82,000 |  |
| Shareholders' equity |  |  | 1,237,350 |  |  |  | 1,131,142 |  |
|  |  | $ | 1,838,620 |  |  |  | 1,683,214 |  |

[0001104659-24-118951:8k_2_02:100]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-118951:8k_2_02:101]
Consolidated Statements of Cash Flows

[0001104659-24-118951:8k_2_02:102]
(Dollars in thousands)

[0001104659-24-118951:8k_2_02:103]
|  |  | Year Ended September 30, 2024 |  |  | Year Ended September 30, 2023 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 101,881 |  |  |  | 92,545 |  |
| Adjustments to reconcile net earnings to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 55,409 |  |  |  | 50,523 |  |
| Stock compensation expense |  |  | 8,599 |  |  |  | 8,910 |  |
| Changes in assets and liabilities |  |  | (29,385 | ) |  |  | (68,821 | ) |
| Effect of deferred taxes |  |  | (8,962 | ) |  |  | (6,267 | ) |
| Net cash provided by operating activities |  |  | 127,542 |  |  |  | 76,890 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Acquisition of business, net of cash acquired |  |  | (56,383 | ) |  |  | (17,694 | ) |
| Capital expenditures |  |  | (36,166 | ) |  |  | (22,377 | ) |
| Additions to capitalized software |  |  | (12,090 | ) |  |  | (12,397 | ) |
| Net cash used by investing activities |  |  | (104,639 | ) |  |  | (52,468 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from long-term debt |  |  | 217,000 |  |  |  | 103,000 |  |
| Principal payments on long-term debt and short-term borrowings |  |  | (197,000 | ) |  |  | (154,000 | ) |
| Dividends paid |  |  | (8,246 | ) |  |  | (8,252 | ) |
| Purchases of common stock into treasury |  |  | (7,998 | ) |  |  | (12,401 | ) |
| Debt issuance costs |  |  | (2,988 | ) |  |  | (1,826 | ) |
| Other |  |  | (1,541 | ) |  |  | (4,851 | ) |
| Net cash used by financing activities |  |  | (773 | ) |  |  | (78,330 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 1,967 |  |  |  | (1,950 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 24,097 |  |  |  | (55,858 | ) |
| Cash and cash equivalents, beginning of period |  |  | 41,866 |  |  |  | 97,724 |  |
| Cash and cash equivalents, end of period |  | $ | 65,963 |  |  |  | 41,866 |  |

[0001104659-24-118951:8k_2_02:104]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-118951:8k_2_02:105]
Other Selected Financial Data (Unaudited)

[0001104659-24-118951:8k_2_02:106]
(Dollars in thousands)

[0001104659-24-118951:8k_2_02:107]
| Backlog And Entered Orders - Q4 2024 |  | A&D |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 7/1/24 |  | $ | 594,742 |  |  |  | 128,890 |  |  |  | 165,027 |  |  |  | 888,659 |  |
| Entered Orders |  |  | 129,931 |  |  |  | 99,544 |  |  |  | 59,368 |  |  |  | 288,843 |  |
| Sales |  |  | (124,291 | ) |  |  | (108,491 | ) |  |  | (65,751 | ) |  |  | (298,533 | ) |
| Ending Backlog - 9/30/24 |  | $ | 600,382 |  |  |  | 119,943 |  |  |  | 158,644 |  |  |  | 878,969 |  |

[0001104659-24-118951:8k_2_02:108]
| Backlog And Entered Orders - FY 2024 |  | A&D |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 10/1/23 |  | $ | 484,069 |  |  |  | 133,459 |  |  |  | 154,834 |  |  |  | 772,362 |  |
| Entered Orders |  |  | 564,488 |  |  |  | 355,545 |  |  |  | 213,333 |  |  |  | 1,133,366 |  |
| Sales |  |  | (448,175 | ) |  |  | (369,061 | ) |  |  | (209,523 | ) |  |  | (1,026,759 | ) |
| Ending Backlog - 9/30/24 |  | $ | 600,382 |  |  |  | 119,943 |  |  |  | 158,644 |  |  |  | 878,969 |  |

[0001104659-24-118951:8k_2_02:109]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-24-118951:8k_2_02:110]
Reconciliation of Non-GAAP Financial Measures (Unaudited)

[0001104659-24-118951:8k_2_02:111]
| EPS – Adjusted Basis Reconciliation – Q4 2024 |  |  |  |  |
| EPS – GAAP Basis – Q4 2024 |  | $ | 1.32 |  |
| Adjustments (defined below) |  |  | 0.14 |  |
| EPS – As Adjusted Basis – Q4 2024 |  | $ | 1.46 |  |
| Adjustments exclude $0.14 per share consisting of after-tax charges primarily of $0.09 of debt financing and $0.03 of acquisition costs at Corporate related to the pending SM&P acquisition, and $0.02 of restructuring charges (primarily severance) in the A&D segment. The $0.14 of EPS adjustments per share consists of $4.8 million of pre-tax charges offset by $1.1 million of tax benefit for net impact of $3.7 million. |  |  |  |  |
| EPS – Adjusted Basis Reconciliation – FY 2024 |  |  |  |  |
| EPS – GAAP Basis – FY 2024 |  | $ | 3.94 |  |
| Adjustments (defined below) |  |  | 0.24 |  |
| EPS – As Adjusted Basis – FY 2024 |  | $ | 4.18 |  |
| Adjustments exclude $0.24 per share of after-tax charges consisting primarily of $0.09 of debt financing and $0.06 of acquisition costs at Corporate related to the pending SM&P acquisition, $0.05 of restructuring charges (primarily severance) in the A&D, Test and USG segments, and $0.04 of MPE acquisition backlog and inventory step-up charges. |  |  |  |  |
| The $0.24 of EPS adjustments per share consists of $8.0 million of pre-tax charges offset by $1.8 million of tax benefit for net impact of $6.2 million. |  |  |  |  |
| EPS – Adjusted Basis Reconciliation – Q4 2023 |  |  |  |  |
| EPS – GAAP Basis – Q4 2023 |  | $ | 1.24 |  |
| Adjustments (defined below) |  |  | 0.01 |  |
| EPS – As Adjusted Basis – Q4 2023 |  | $ | 1.25 |  |
| Adjustments exclude $0.01 per share consisting of after-tax restructuring charges primarily at Westland (severance and asset write-off). |  |  |  |  |
| The $0.01 of EPS adjustments per share consists of $0.5 million of pre-tax charges offset by $0.1 million of tax benefit for net impact of $0.4 million. |  |  |  |  |
| EPS – Adjusted Basis Reconciliation – FY 2023 |  |  |  |  |
| EPS – GAAP Basis – FY 2023 |  | $ | 3.58 |  |
| Adjustments (defined below) |  |  | 0.12 |  |
| EPS – As Adjusted Basis – FY 2023 |  | $ | 3.70 |  |
| Adjustments exclude $0.12 per share of after-tax charges consisting of executive management transition costs at Corporate, CMT acquisition inventory step-up charges, restructuring charges within the A&D segment and Corporate acquisition related costs. |  |  |  |  |
| The $0.12 of EPS adjustments per share consists of $4.1 million of pre-tax charges offset by $0.9 million of tax benefit for net impact of $3.2 million. |  |  |  |  |

## item 5.02 — body, verbatim

[0001104659-24-118951:8k_body:1]
Item 5.02 Departure of Directors
or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers

[0001104659-24-118951:8k_body:2]
Executive Officers – Long-Term Equity
Incentive Awards

[0001104659-24-118951:8k_body:3]
On November 7, 2024, the Human Resources and Compensation Committee
of the Company’s Board of Directors approved the fiscal 2025 awards of time-based Restricted Share Units (RSUs) and Performance
Share Units (PSUs) to the Company’s three executive officers and the other participants in the Company’s LTI program, effective
November 7, 2024.

[0001104659-24-118951:8k_body:4]
Other than the share amounts, the terms of the fiscal 2025 RSUs (and
future RSUs except to the extent hereafter amended by the HRCC) are substantially similar to those awarded for fiscal 2024, vesting over
a period of approximately three years, in three equal portions approximately 12, 24 and 36 months after the grant date; for the fiscal
2025 awards, vesting will occur on the last NYSE trading days in November 2025, 2026 and 2027.

[0001104659-24-118951:8k_body:5]
The terms of the fiscal 2025 PSUs (and future PSUs except to the extent
hereafter amended by the HRCC) are substantially similar to those awarded for fiscal 2024 other than the specific share amounts and performance
goals. The fiscal 2025 PSUs will vest after a three-year performance period beginning October 1, 2024 and ending on September 30, 2027,
on the last trading day of the month in which the HRCC approves and certifies the extent to which the applicable performance goals have
been achieved. Upon vesting, the awards will be converted into a currently undeterminable number of shares of Company common stock, which
may be less than or greater than the number of PSUs awarded, within certain specified threshold and maximum limits, depending on the degree
to which the Company has achieved one or more specified performance goals. If the performance is less than the threshold goal for a particular
performance measure, there will be no payout of that portion of the PSUs dependent on that measure.

[0001104659-24-118951:8k_body:6]
The performance goals for the fiscal 2025 PSUs are specified Committee-approved
targets for EBITDA (60%) and Return on Invested Capital (40%), with the resulting number of shares potentially subject to increase or
decrease based on the Company’s Total Shareholder Return (TSR) over the performance period compared to the TSR of the companies
in a peer group based on the S&P Small-Cap 600 Industrials Index (rTSR). If the Company’s rTSR is below the 25th
percentile or above the 75th percentile, the resulting number of shares will be decreased by 20% or increased by 20%, respectively;
if the Company’s rTSR is from the 25th percentile to the 75th percentile, no adjustment will be made.

[0001104659-24-118951:8k_body:7]
The target number of shares in each RSU and PSU award equals the Committee-approved
target values divided by the 15-day average trading price of the Company’s stock. The actual payout of the RSUs and PSUs will be
in shares, whose value at the time of payout may be greater or less than the target values.

[0001104659-24-118951:8k_body:8]
For the executive officers, the numbers of RSUs granted and the PSU
threshold, target and maximum numbers of shares payable according to the performance criteria, were as follows:

[0001104659-24-118951:8k_body:9]
Name and Title

[0001104659-24-118951:8k_body:10]
RSU

[0001104659-24-118951:8k_body:11]
Target Values

[0001104659-24-118951:8k_body:12]
as of

[0001104659-24-118951:8k_body:13]
Grant Date

[0001104659-24-118951:8k_body:14]
Number

[0001104659-24-118951:8k_body:15]
of RSUs

[0001104659-24-118951:8k_body:16]
Granted

[0001104659-24-118951:8k_body:17]
PSU

[0001104659-24-118951:8k_body:18]
Target Values

[0001104659-24-118951:8k_body:19]
as of

[0001104659-24-118951:8k_body:20]
Grant Date

[0001104659-24-118951:8k_body:21]
PSU
    Payout Potential (Shares)

[0001104659-24-118951:8k_body:22]
At Threshold

[0001104659-24-118951:8k_body:23]
Performance

[0001104659-24-118951:8k_body:24]
(50%

[0001104659-24-118951:8k_body:25]
of Target)

[0001104659-24-118951:8k_body:26]
At Target

[0001104659-24-118951:8k_body:27]
Performance

[0001104659-24-118951:8k_body:28]
At Maximum

[0001104659-24-118951:8k_body:29]
Performance

[0001104659-24-118951:8k_body:30]
(200% of

[0001104659-24-118951:8k_body:31]
Target)

[0001104659-24-118951:8k_body:32]
Bryan H. Sayler

[0001104659-24-118951:8k_body:33]
Chief Executive Officer & President

[0001104659-24-118951:8k_body:34]
$810,000

[0001104659-24-118951:8k_body:35]
6,226

[0001104659-24-118951:8k_body:36]
$1,890,000

[0001104659-24-118951:8k_body:37]
7,263

[0001104659-24-118951:8k_body:38]
14,526

[0001104659-24-118951:8k_body:39]
29,052

[0001104659-24-118951:8k_body:40]
Christopher L. Tucker

[0001104659-24-118951:8k_body:41]
Senior Vice President

[0001104659-24-118951:8k_body:42]
& Chief Financial Officer

[0001104659-24-118951:8k_body:43]
$231,180

[0001104659-24-118951:8k_body:44]
1,777

[0001104659-24-118951:8k_body:45]
$539,420

[0001104659-24-118951:8k_body:46]
2,073

[0001104659-24-118951:8k_body:47]
4,146

[0001104659-24-118951:8k_body:48]
8,292

[0001104659-24-118951:8k_body:49]
David M. Schatz

[0001104659-24-118951:8k_body:50]
Senior Vice President,

[0001104659-24-118951:8k_body:51]
General Counsel & Secretary

[0001104659-24-118951:8k_body:52]
$127,830

[0001104659-24-118951:8k_body:53]
982

[0001104659-24-118951:8k_body:54]
$298,270

[0001104659-24-118951:8k_body:55]
1,146

[0001104659-24-118951:8k_body:56]
2,292

[0001104659-24-118951:8k_body:57]
4,584
