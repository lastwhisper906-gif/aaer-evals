# ESE 8-K — 0001104659-23-057736 filed 2023-05-09

## item codes, every 8-K on or before 2023-05-10

- 2023-05-09 0001104659-23-057736 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2023-05-05 0001104659-23-056387 — 5.02, 9.01
- 2023-02-08 0001104659-23-014539 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2023-01-06 0001104659-23-001859 — 5.02, 9.01
- 2022-11-22 0001104659-22-121229 — 5.02, 5.03, 8.01, 9.01
- 2022-11-17 0001104659-22-119898 — 2.02, 7.01, 9.01
- 2022-09-12 0001104659-22-099248 — 5.02, 7.01, 9.01
- 2022-08-08 0001104659-22-087247 — 2.02, 5.02, 7.01, 9.01
- 2022-05-09 0001104659-22-057524 — 2.02, 5.02, 7.01, 9.01
- 2022-02-08 0001104659-22-013878 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2021-12-03 0001104659-21-146361 — 4.01, 9.01 — amendment, the index does not say of what
- 2021-11-24 0001104659-21-143568 — 4.01, 9.01
- 2021-11-23 0001104659-21-142871 — 5.02, 8.01
- 2021-11-18 0001104659-21-141206 — 2.02, 7.01, 9.01
- 2021-08-09 0001104659-21-102150 — 2.02, 7.01, 9.01
- 2021-05-04 0001104659-21-060985 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2021-04-05 0001104659-21-046581 — 5.02, 9.01
- 2021-02-08 0001104659-21-013712 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2020-12-09 0001104659-20-133674 — 5.02, 9.01
- 2020-12-07 0001104659-20-132861 — 5.02, 7.01, 9.01
- 2020-11-19 0001104659-20-127352 — 2.02, 5.02, 7.01, 9.01
- 2020-08-10 0001104659-20-092734 — 2.02, 7.01, 9.01
- 2020-05-06 0001104659-20-057442 — 2.02, 7.01, 8.01, 9.01
- 2020-02-04 0001104659-20-010640 — 2.02, 5.07, 7.01, 9.01
- 2020-01-07 0001104659-20-001789 — 2.01, 9.01
- 2019-11-19 0001104659-19-065437 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2019-11-18 0001104659-19-065096 — 1.01, 2.02, 7.01, 9.01
- 2019-09-30 0001144204-19-046523 — 1.01, 1.02, 2.03, 9.01
- 2019-08-08 0001144204-19-038567 — 2.02, 7.01, 9.01
- 2019-05-07 0001144204-19-024241 — 2.02, 5.02, 7.01, 9.01
- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2023-05-10

- none on or before 2023-05-10

## item 2.02 — earnings release, exhibit 99.1

[0001104659-23-057736:8k_2_02:1]
EX-99.1
2
tm2315148d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-23-057736:8k_2_02:2]
Exhibit 99.1

[0001104659-23-057736:8k_2_02:3]
| NEWS FROM |  |

[0001104659-23-057736:8k_2_02:4]
For more information contact:

[0001104659-23-057736:8k_2_02:5]
Kate Lowrey - VP of Investor Relations

[0001104659-23-057736:8k_2_02:6]
(314) 213-7277
/ klowrey@escotechnologies.com

[0001104659-23-057736:8k_2_02:7]
ESCO REPORTS SECOND QUARTER FISCAL 2023
RESULTS

[0001104659-23-057736:8k_2_02:8]
- Q2 GAAP EPS $0.69 / Adjusted EPS $0.76
-

[0001104659-23-057736:8k_2_02:9]
- Q2 Sales increase 12% to $229 Million -

[0001104659-23-057736:8k_2_02:10]
- $252 Million in Q2 Orders / Book-to-bill
of 1.10x -

[0001104659-23-057736:8k_2_02:11]
ST. LOUIS, May 9, 2023 – ESCO Technologies
Inc. (NYSE: ESE) (ESCO, or the Company) today reported its operating results for the second quarter ended March 31, 2023 (Q2 2023).

[0001104659-23-057736:8k_2_02:12]
Operating Highlights

[0001104659-23-057736:8k_2_02:13]
|  | · | Q2 2023 GAAP EPS increased 8 percent to $0.69 per share compared to $0.64 per share in Q2 2022. Q2 2023 Adjusted EPS increased 17 percent to $0.76 per share compared to $0.65 per share in Q2 2022. |
|  | · | Q2 2023 Sales increased $24.2 million (11.8 percent) to $229.1 million compared to $204.9 million in Q2 2022. |
|  | · | Q2 2023 Entered Orders increased $15.1 million (6 percent) over the prior year period to $251.6 million (book-to-bill of 1.10x), resulting in record ending backlog of $741 million. |
|  | · | Net cash used by operating activities was $5 million YTD 2023, as cash flow was negatively impacted by higher working capital requirements, with higher accounts receivable being driven by increased sales and higher inventory related to timing and supply chain issues. |
|  | · | Net debt (total borrowings less cash on hand) was $113 million, resulting in a 0.86x leverage ratio and $582 million in liquidity at March 31, 2023. |

[0001104659-23-057736:8k_2_02:14]
Bryan Sayler, Chief Executive Officer and
President, commented, “Q2 was another solid quarter operationally, as ESCO delivered double-digit revenue growth, expanded
operating margins, and achieved 17 percent adjusted earnings per share growth. It has been an exciting time for me to step into the
CEO role. The business has clear momentum and secular growth drivers that should carry us through this year and beyond. We continue
to see exciting developments across our aerospace and defense portfolio, with commercial aerospace, military aerospace and Navy
customers driving high levels of business activity. We also see growth drivers continue to solidify in the utility and renewable
energy markets, which makes us feel good about the long-term prospects for our Utility Solutions Group. Our Test business had a
slightly down quarter but serves a variety of strong end markets and offers broad capabilities that give us confidence in its
long-term outlook. It is an exciting time to be at ESCO and I look forward to working with leadership across the company as we move
our businesses forward.

[0001104659-23-057736:8k_2_02:15]
“Entered orders remained strong in the quarter,
with solid growth in commercial aerospace and renewables. All three segments had book-to-bills above 1.0 and for the second consecutive
quarter, we achieved record ending backlog at $741 million.

[0001104659-23-057736:8k_2_02:16]
“Our teams across the company continue to do
an excellent job driving growth and delivering solid operating results while navigating challenges related to inflation, supply chain
constraints and labor shortages. Even with our strong performance year-to-date, we are still managing some past-due backlog challenges
driven by these factors. I’d like to personally thank all of our employees for their dedication, persistence, and tremendous efforts.
Their commitment is key to our solid results.”

[0001104659-23-057736:8k_2_02:17]
Segment Performance

[0001104659-23-057736:8k_2_02:18]
Aerospace & Defense (A&D)

[0001104659-23-057736:8k_2_02:19]
|  | · | Sales increased $14.2 million (17 percent) to $99.0 million in Q2 2023 from $84.8 million in Q2 2022. Sales growth was driven by commercial aerospace, which increased $8.1 million (27 percent) to $38.2 million in the quarter. In addition, defense aerospace and Navy also delivered solid sales growth. |
|  | · | Q2 2023 EBIT increased $4.5 million to $18.8 million from $14.3 million in Q2 2022. Adjusted EBIT increased $5.1 million (35.2 percent) in Q2 2023 to $19.6 million (19.8 percent margin) from $14.5 million (17.1 percent margin) in Q2 2022. |
|  | · | Entered Orders increased $17 million (18 percent) to $112 million in Q2 2023 compared to $95 million in Q2 2022. The orders strength was driven by commercial OEM build rate increases, market share gains at Mayday, a large aftermarket order at PTI, and $7 million in acquired backlog related to CMT. A&D’s book-to-bill of 1.13x in the quarter resulted in record ending backlog of $435 million. |

[0001104659-23-057736:8k_2_02:20]
Utility Solutions Group (USG)

[0001104659-23-057736:8k_2_02:21]
|  | · | Sales increased $15.0 million (23 percent) to $79.2 million in Q2 2023 from $64.2 million in Q2 2022. Doble’s sales increased by $10.5 million (19 percent) driven by a strong quarter for condition monitoring products, services, and high voltage test equipment at Phenix. NRG sales increased $4.5 million (47 percent) on continued strength in the renewables end-market. |
|  | · | EBIT increased $2.8 million in Q2 2023 to $14.1 million from $11.3 million in Q2 2022. There were no adjustments to Q2 2023 EBIT of $14.1 million (17.8 percent margin), which also increased $2.8 million from Q2 2022 Adjusted EBIT of $11.3 million (17.7 percent margin). Margins were unfavorably impacted by product mix and increased event costs as trade show activity continued to normalize post-COVID. |

[0001104659-23-057736:8k_2_02:22]
|  | · | Entered Orders decreased $2 million (2 percent) to $85 million in Q2 2023. The decrease in orders was primarily driven by an $8 million (11 percent) decrease at Doble related to the timing of a large multi-year DUC contract renewal in the prior year Q2. Order strength continues across the Doble portfolio, highlighted by significant condition monitoring orders. NRG orders increased by $6 million (54 percent) related to continuing strength in both wind and solar, and with significant orders by solar resource monitoring (SRM) customers in the U.S. and Europe. USG’s book-to-bill of 1.07x in the quarter resulted in an ending backlog of $143 million, which is up $26 million compared to prior year. |

[0001104659-23-057736:8k_2_02:23]
Test

[0001104659-23-057736:8k_2_02:24]
|  | · | Sales decreased $4.9 million (9 percent) to $51.0 million in Q2 2023 from $55.9 million in Q2 2022, with sales increases in Europe more than offset by declines in the U.S. and Asia. There were disruptions in test and measurement project execution in China related to re-opening of the economy after prior zero-COVID policies. |
|  | · | EBIT decreased $1.3 million in Q2 2023 to $7.2 million (14.2 percent margin) from $8.5 million (15.2 percent margin) in Q2 2022 related to lower volume in China. There were no adjustments in either year for the Test segment. |
|  | · | Entered Orders decreased $0.1 million to $55.3 million in Q2 2023 compared to $55.4 million in Q2 2022. Despite the slight decrease in orders, it was a solid orders quarter for Test with a book-to-bill of 1.09x, which resulted in an ending backlog of $163 million. |

[0001104659-23-057736:8k_2_02:25]
Share Repurchase Program

[0001104659-23-057736:8k_2_02:26]
During Q2 2023, the Company repurchased approximately
81,000 shares for $7.1 million. $8.1 million was paid in the quarter related to the Q2 shares purchased and included $1.0 million related
to December purchases that settled in January. Year-to-date, the company has repurchased approximately 138,000 shares for $12.2 million.

[0001104659-23-057736:8k_2_02:27]
Dividend Payment

[0001104659-23-057736:8k_2_02:28]
The next quarterly cash dividend
of $0.08 per share will be paid on July 19, 2023 to stockholders of record on July 5, 2023.

[0001104659-23-057736:8k_2_02:29]
Business Outlook – 2023

[0001104659-23-057736:8k_2_02:30]
The strength of our first half results gives us added
confidence in our ability to deliver solid revenue and earnings growth in 2023 and we are again increasing our earnings guidance. We now
expect current year adjusted EPS in the range of $3.55 to $3.65 (11 to 14 percent growth). This is based on sales in a range of $930 to
$950 million (8 to 11 percent annual growth). Consistent with prior years, revenues and Adjusted EPS are expected to grow sequentially
throughout the year. Our expectation is for Q3 Adjusted EPS to be in the range of $0.96 to $1.01 per share (8 to 13 percent growth).

[0001104659-23-057736:8k_2_02:31]
Board of Directors

[0001104659-23-057736:8k_2_02:32]
Effective June 30, 2023, and consistent with the succession plan previously
announced, Vic Richey will retire from his roles as a director of the Company, the Executive Chair of the Board, and an employee of the
Company. Related to this change, independent director Robert Phillippy has been appointed to serve as Chair of the Board. James Stolze
will remain a director but has resigned his position as Lead Director. In addition, given that the role of Board Chair will be held by
an independent director, the position of Lead Director has been eliminated by the Board. Patrick Dewar has been appointed to serve as
Chair of the Audit and Finance Committee. All of the foregoing changes are effective June 30, 2023.

[0001104659-23-057736:8k_2_02:33]
Conference Call

[0001104659-23-057736:8k_2_02:34]
The Company will host a conference call today, May 9, at 4:00 p.m.
Central Time, to discuss the Company’s Q2 2023 results. A live audio webcast and an accompanying slide presentation will be available
on ESCO’s investor website at https://investor.escotechnologies.com. For those unable to participate, a webcast replay will be available
after the call on ESCO’s investor website.

[0001104659-23-057736:8k_2_02:35]
Forward-Looking Statements

[0001104659-23-057736:8k_2_02:36]
Investors are cautioned that such statements
are only predictions and speak only as of the date of this release, and the Company undertakes no duty to update them except as may
be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those
projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business
environment including but not limited to those described in Item 1A, “Risk Factors”, of the Company’s Annual
Report on Form 10-K for the fiscal year ended September 30, 2022; the availability and acceptance of viable COVID-19 vaccines by
enough of the U.S. and world’s population to curtail the pandemic; the continuing impact of the COVID-19 pandemic and the
effects of known or unknown COVID-19 variants including labor shortages, facility closures, shelter in place policies or
quarantines, material shortages, transportation delays, termination or delays of Company contracts, and the inability of our
suppliers or customers to perform; the impacts of natural disasters on the Company’s operations and those of the
Company’s customers and suppliers; the timing and content of future contract awards or customer orders; the appropriation,
allocation and availability of Government funds; the termination for convenience of Government and other customer contracts or
orders; weakening of economic conditions in served markets; the success of the Company’s competitors; changes in customer
demands or customer insolvencies; competition; intellectual property rights; technical difficulties; the success of the
Company’s acquisition efforts; delivery delays or defaults by customers; performance issues with key customers, suppliers and
subcontractors; changes in the costs and availability of certain raw materials; labor disputes; changes in U.S. tax laws and
regulations; other changes in laws and regulations including but not limited to changes in accounting standards and foreign
taxation; changes in interest rates; costs relating to environmental matters arising from current or former facilities; uncertainty
regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the integration of recently acquired
businesses.

[0001104659-23-057736:8k_2_02:37]
Non-GAAP Financial Measures

[0001104659-23-057736:8k_2_02:38]
The financial measures EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA
and Adjusted EPS are presented in this press release. The Company defines “EBIT” as earnings before interest and taxes, “EBITDA”
as earnings before interest, taxes, depreciation and amortization, “Adjusted EBIT” and “Adjusted EBITDA” as excluding
the net impact of the items described in the attached Reconciliation of Non-GAAP Financial Measures, and “Adjusted EPS” as
GAAP earnings per share (EPS) excluding the net impact of the items described and reconciled in the attached Reconciliation of Non-GAAP
Financial Measures.

[0001104659-23-057736:8k_2_02:39]
EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA and
Adjusted EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management believes
EBIT, Adjusted EBIT, EBITDA and Adjusted EBITDA are useful in assessing the operational profitability of the Company’s business
segments because they exclude interest, taxes, depreciation and amortization, which are generally accounted for across the entire Company
on a consolidated basis. EBIT and EBITDA are also measures used by Management in determining resource allocations within the Company as
well as incentive compensation. The presentation of EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS provides important supplemental
information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures to supplement
their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance determined in accordance
with GAAP.

[0001104659-23-057736:8k_2_02:40]
About ESCO Technologies

[0001104659-23-057736:8k_2_02:41]
ESCO is a global provider of highly engineered products and solutions
serving diverse end-markets. It manufactures filtration and fluid control products for the aviation, Navy, space, and process markets
worldwide and composite-based products and solutions for Navy, defense, and industrial customers. ESCO is the industry leader in RF shielding
and EMC test products; and provides diagnostic instruments, software and services to industrial power users and the electric utility and
renewable energy industries. Headquartered in St. Louis, Missouri, ESCO and its subsidiaries have offices and manufacturing facilities
worldwide. For more information on ESCO and its subsidiaries, visit the Company’s website at www.escotechnologies.com.

[0001104659-23-057736:8k_2_02:42]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-23-057736:8k_2_02:43]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-23-057736:8k_2_02:44]
(Dollars in thousands, except per share amounts)

[0001104659-23-057736:8k_2_02:45]
|  |  | Three Months Ended March 31, 2023 |  |  | Three Months Ended March 31, 2022 |  |
| Net Sales |  | $ | 229,136 |  |  |  | 204,928 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 142,296 |  |  |  | 128,375 |  |
| Selling, general and administrative expenses |  |  | 53,877 |  |  |  | 47,959 |  |
| Amortization of intangible assets |  |  | 7,030 |  |  |  | 6,510 |  |
| Interest expense |  |  | 2,269 |  |  |  | 1,020 |  |
| Other expenses (income), net |  |  | 314 |  |  |  | (604 | ) |
| Total costs and expenses |  |  | 205,786 |  |  |  | 183,260 |  |
| Earnings before income taxes |  |  | 23,350 |  |  |  | 21,668 |  |
| Income tax expense |  |  | 5,472 |  |  |  | 5,085 |  |
| Net earnings |  | $ | 17,878 |  |  |  | 16,583 |  |
| Diluted - GAAP |  | $ | 0.69 |  |  |  | 0.64 |  |
| Diluted - As Adjusted Basis |  | $ | 0.76 | (1) |  |  | 0.65 | (2) |
| Diluted average common shares O/S: |  |  | 25,895 |  |  |  | 26,045 |  |

[0001104659-23-057736:8k_2_02:46]
| (1) | Q2 2023 Adjusted EPS excludes $0.07 per share of after-tax charges consisting of $0.04 of executive management transition costs at Corporate, $0.02 of CMT acquisition inventory step-up charges and $0.01 of restructuring charges within the A&D segment. |
| (2) | Q2 2022 Adjusted EPS excludes $0.01 per share of after-tax charges associated with the NEco acquisition inventory step-up charge and Corporate acquisition related costs. |

[0001104659-23-057736:8k_2_02:47]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-23-057736:8k_2_02:48]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-23-057736:8k_2_02:49]
(Dollars in thousands, except per share amounts)

[0001104659-23-057736:8k_2_02:50]
|  |  | Six Months Ended March 31, 2023 |  |  | Six Months Ended March 31, 2022 |  |
| Net Sales |  | $ | 434,637 |  |  |  | 381,938 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 268,679 |  |  |  | 236,680 |  |
| Selling, general and administrative expenses |  |  | 105,179 |  |  |  | 94,594 |  |
| Amortization of intangible assets |  |  | 13,891 |  |  |  | 12,977 |  |
| Interest expense |  |  | 3,927 |  |  |  | 1,753 |  |
| Other expenses (income), net |  |  | 712 |  |  |  | (571 | ) |
| Total costs and expenses |  |  | 392,388 |  |  |  | 345,433 |  |
| Earnings before income taxes |  |  | 42,249 |  |  |  | 36,505 |  |
| Income tax expense |  |  | 9,644 |  |  |  | 8,398 |  |
| Net earnings |  | $ | 32,605 |  |  |  | 28,107 |  |
| Diluted - GAAP |  | $ | 1.26 |  |  |  | 1.08 |  |
| Diluted - As Adjusted Basis |  | $ | 1.36 | (1) |  |  | 1.11 | (2) |
| Diluted average common shares O/S: |  |  | 25,919 |  |  |  | 26,098 |  |

[0001104659-23-057736:8k_2_02:51]
| (1) | YTD Q2 2023 Adjusted EPS excludes $0.10 per share of after-tax charges consisting of $0.06 of executive management transition costs at Corporate, $0.02 of CMT acquisition inventory step-up charges and $0.02 of restructuring charges within the A&D segment. |
| (2) | YTD Q2 2022 Adjusted EPS excludes $0.03 per share of after-tax charges associated with the Altanova & NEco acquisition inventory step-up charges and Corporate acquisition related costs. |

[0001104659-23-057736:8k_2_02:52]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-23-057736:8k_2_02:53]
Condensed Business Segment Information (Unaudited)

[0001104659-23-057736:8k_2_02:54]
(Dollars in thousands)

[0001104659-23-057736:8k_2_02:55]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | Q2 2023 |  |  | Q2 2022 |  |  | Q2 2023 |  |  | Q2 2022 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 98,982 |  |  |  | 84,821 |  |  |  | 98,982 |  |  |  | 84,821 |  |
| USG |  |  | 79,161 |  |  |  | 64,191 |  |  |  | 79,161 |  |  |  | 64,191 |  |
| Test |  |  | 50,993 |  |  |  | 55,916 |  |  |  | 50,993 |  |  |  | 55,916 |  |
| Totals |  | $ | 229,136 |  |  |  | 204,928 |  |  |  | 229,136 |  |  |  | 204,928 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 18,795 |  |  |  | 14,349 |  |  |  | 19,595 |  |  |  | 14,489 |  |
| USG |  |  | 14,061 |  |  |  | 11,314 |  |  |  | 14,061 |  |  |  | 11,331 |  |
| Test |  |  | 7,226 |  |  |  | 8,494 |  |  |  | 7,226 |  |  |  | 8,494 |  |
| Corporate |  |  | (14,463 | ) |  |  | (11,469 | ) |  |  | (12,963 | ) |  |  | (11,344 | ) |
| Consolidated EBIT |  |  | 25,619 |  |  |  | 22,688 |  |  |  | 27,919 |  |  |  | 22,970 |  |
| Less: Interest expense |  |  | (2,269 | ) |  |  | (1,020 | ) |  |  | (2,269 | ) |  |  | (1,020 | ) |
| Less: Income tax expense |  |  | (5,472 | ) |  |  | (5,085 | ) |  |  | (6,001 | ) |  |  | (5,150 | ) |
| Net earnings |  | $ | 17,878 |  |  |  | 16,583 |  |  |  | 19,649 |  |  |  | 16,800 |  |

[0001104659-23-057736:8k_2_02:56]
Note 1: Adjusted net earnings were $19.6 million
in Q2 2023 which excludes $0.07 per share of after-tax charges consisting of $0.04 of executive management transition costs at Corporate,
$0.02 of CMT acquisition inventory step-up charges and $0.01 of restructuring charges within the A&D segment.

[0001104659-23-057736:8k_2_02:57]
Note 2: Adjusted net earnings were $16.8 million in Q2 2022 which excludes $0.01 per share of after-tax charges associated with the NEco acquisition inventory step-up charge and Corporate acquisition related costs.

[0001104659-23-057736:8k_2_02:58]
| EBITDA Reconciliation to Net earnings: |  |  |  |  | Q2 2023 |  |  | Q2 2022 |  |
|  |  | Q2 2023 |  |  | Q2 2022 |  |  | - As Adjusted |  |  | - As Adjusted |  |
| Consolidated EBITDA |  | $ | 38,162 |  |  |  | 34,808 |  |  |  | 40,462 |  |  |  | 35,090 |  |
| Less: Depr & Amort |  |  | (12,543 | ) |  |  | (12,120 | ) |  |  | (12,543 | ) |  |  | (12,120 | ) |
| Consolidated EBIT |  |  | 25,619 |  |  |  | 22,688 |  |  |  | 27,919 |  |  |  | 22,970 |  |
| Less: Interest expense |  |  | (2,269 | ) |  |  | (1,020 | ) |  |  | (2,269 | ) |  |  | (1,020 | ) |
| Less: Income tax expense |  |  | (5,472 | ) |  |  | (5,085 | ) |  |  | (6,001 | ) |  |  | (5,150 | ) |
| Net earnings |  | $ | 17,878 |  |  |  | 16,583 |  |  |  | 19,649 |  |  |  | 16,800 |  |

[0001104659-23-057736:8k_2_02:59]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-23-057736:8k_2_02:60]
Condensed Business Segment Information (Unaudited)

[0001104659-23-057736:8k_2_02:61]
(Dollars in thousands)

[0001104659-23-057736:8k_2_02:62]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | YTD Q2 2023 |  |  | YTD Q2 2022 |  |  | YTD Q2 2023 |  |  | YTD Q2 2022 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 181,965 |  |  |  | 155,065 |  |  |  | 181,965 |  |  |  | 155,065 |  |
| USG |  |  | 150,206 |  |  |  | 127,676 |  |  |  | 150,206 |  |  |  | 127,676 |  |
| Test |  |  | 102,466 |  |  |  | 99,197 |  |  |  | 102,466 |  |  |  | 99,197 |  |
| Totals |  | $ | 434,637 |  |  |  | 381,938 |  |  |  | 434,637 |  |  |  | 381,938 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 31,331 |  |  |  | 24,304 |  |  |  | 32,330 |  |  |  | 24,639 |  |
| USG |  |  | 30,192 |  |  |  | 24,705 |  |  |  | 30,192 |  |  |  | 25,172 |  |
| Test |  |  | 12,637 |  |  |  | 12,459 |  |  |  | 12,637 |  |  |  | 12,459 |  |
| Corporate |  |  | (27,984 | ) |  |  | (23,210 | ) |  |  | (25,691 | ) |  |  | (22,905 | ) |
| Consolidated EBIT |  |  | 46,176 |  |  |  | 38,258 |  |  |  | 49,468 |  |  |  | 39,365 |  |
| Less: Interest expense |  |  | (3,927 | ) |  |  | (1,753 | ) |  |  | (3,927 | ) |  |  | (1,753 | ) |
| Less: Income tax expense |  |  | (9,644 | ) |  |  | (8,398 | ) |  |  | (10,401 | ) |  |  | (8,653 | ) |
| Net earnings |  | $ | 32,605 |  |  |  | 28,107 |  |  |  | 35,140 |  |  |  | 28,959 |  |

[0001104659-23-057736:8k_2_02:63]
Note 1: Adjusted net earnings were $35.1 million in YTD 2023 which excludes $0.10 per share of after-tax charges consisting of $0.06 of executive management transition costs at Corporate, $0.02 of CMT acquisition inventory step-up charges and $0.02 of restructuring charges within the A&D segment.

[0001104659-23-057736:8k_2_02:64]
Note 2: Adjusted net earnings were $29.0 million in YTD Q2 2022 which excludes $0.03 per share of after-tax charges associated with the Altanova & NEco acquisition inventory step-up charges and Corporate acquisition related costs.

[0001104659-23-057736:8k_2_02:65]
| EBITDA Reconciliation to Net earnings: |  |  |  |  | YTD Q2 2023 |  |  | YTD Q2 2022 |  |
|  |  | YTD Q2 2023 |  |  | YTD Q2 2022 |  |  | - As Adjusted |  |  | - As Adjusted |  |
| Consolidated EBITDA |  | $ | 71,086 |  |  |  | 62,550 |  |  |  | 74,378 |  |  |  | 63,657 |  |
| Less: Depr & Amort |  |  | (24,910 | ) |  |  | (24,292 | ) |  |  | (24,910 | ) |  |  | (24,292 | ) |
| Consolidated EBIT |  |  | 46,176 |  |  |  | 38,258 |  |  |  | 49,468 |  |  |  | 39,365 |  |
| Less: Interest expense |  |  | (3,927 | ) |  |  | (1,753 | ) |  |  | (3,927 | ) |  |  | (1,753 | ) |
| Less: Income tax expense |  |  | (9,644 | ) |  |  | (8,398 | ) |  |  | (10,401 | ) |  |  | (8,653 | ) |
| Net earnings |  | $ | 32,605 |  |  |  | 28,107 |  |  |  | 35,140 |  |  |  | 28,959 |  |

[0001104659-23-057736:8k_2_02:66]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-23-057736:8k_2_02:67]
Condensed Consolidated Balance Sheets (Unaudited)

[0001104659-23-057736:8k_2_02:68]
(Dollars in thousands)

[0001104659-23-057736:8k_2_02:69]
|  |  | March 31, 2023 |  |  | September 30, 2022 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 48,221 |  |  |  | 97,724 |  |
| Accounts receivable, net |  |  | 180,817 |  |  |  | 164,645 |  |
| Contract assets |  |  | 128,205 |  |  |  | 125,154 |  |
| Inventories |  |  | 185,753 |  |  |  | 162,403 |  |
| Other current assets |  |  | 27,144 |  |  |  | 22,696 |  |
| Total current assets |  |  | 570,140 |  |  |  | 572,622 |  |
| Property, plant and equipment, net |  |  | 154,020 |  |  |  | 155,973 |  |
| Intangible assets, net |  |  | 401,717 |  |  |  | 394,464 |  |
| Goodwill |  |  | 505,194 |  |  |  | 492,709 |  |
| Operating lease assets |  |  | 41,418 |  |  |  | 29,150 |  |
| Other assets |  |  | 10,113 |  |  |  | 9,538 |  |
|  |  | $ | 1,682,602 |  |  |  | 1,654,456 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt |  | $ | 20,000 |  |  |  | 20,000 |  |
| Accounts payable |  |  | 79,619 |  |  |  | 78,746 |  |
| Contract liabilities |  |  | 119,970 |  |  |  | 125,009 |  |
| Other current liabilities |  |  | 77,466 |  |  |  | 94,374 |  |
| Total current liabilities |  |  | 297,055 |  |  |  | 318,129 |  |
| Deferred tax liabilities |  |  | 81,150 |  |  |  | 82,023 |  |
| Non-current operating lease liabilities |  |  | 37,657 |  |  |  | 24,853 |  |
| Other liabilities |  |  | 44,945 |  |  |  | 48,294 |  |
| Long-term debt |  |  | 141,000 |  |  |  | 133,000 |  |
| Shareholders' equity |  |  | 1,080,795 |  |  |  | 1,048,157 |  |
|  |  | $ | 1,682,602 |  |  |  | 1,654,456 |  |

[0001104659-23-057736:8k_2_02:70]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-23-057736:8k_2_02:71]
Consolidated Statements of Cash Flows (Unaudited)

[0001104659-23-057736:8k_2_02:72]
(Dollars in thousands)

[0001104659-23-057736:8k_2_02:73]
|  |  | Six Months Ended March 31, 2023 |  |  | Six Months Ended March 31, 2022 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 32,605 |  |  |  | 28,107 |  |
| Adjustments to reconcile net earnings to net cash (used) provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 24,910 |  |  |  | 24,292 |  |
| Stock compensation expense |  |  | 5,309 |  |  |  | 3,428 |  |
| Changes in assets and liabilities |  |  | (67,140 | ) |  |  | (41,451 | ) |
| Effect of deferred taxes |  |  | (1,145 | ) |  |  | 8,627 |  |
| Net cash (used) provided by operating activities |  |  | (5,461 | ) |  |  | 23,003 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Acquisition of business, net of cash acquired |  |  | (17,901 | ) |  |  | (15,592 | ) |
| Capital expenditures |  |  | (10,305 | ) |  |  | (20,715 | ) |
| Additions to capitalized software |  |  | (5,918 | ) |  |  | (4,727 | ) |
| Net cash used by investing activities |  |  | (34,124 | ) |  |  | (41,034 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from long-term debt |  |  | 68,000 |  |  |  | 88,000 |  |
| Principal payments on long-term debt and short-term borrowings |  |  | (60,000 | ) |  |  | (46,000 | ) |
| Dividends paid |  |  | (4,128 | ) |  |  | (4,150 | ) |
| Purchases of common stock into treasury |  |  | (12,217 | ) |  |  | (17,878 | ) |
| Other |  |  | (2,374 | ) |  |  | (2,719 | ) |
| Net cash (used) provided by financing activities |  |  | (10,719 | ) |  |  | 17,253 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 801 |  |  |  | (1,130 | ) |
| Net decrease in cash and cash equivalents |  |  | (49,503 | ) |  |  | (1,908 | ) |
| Cash and cash equivalents, beginning of period |  |  | 97,724 |  |  |  | 56,232 |  |
| Cash and cash equivalents, end of period |  | $ | 48,221 |  |  |  | 54,324 |  |

[0001104659-23-057736:8k_2_02:74]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-23-057736:8k_2_02:75]
Other Selected Financial Data (Unaudited)

[0001104659-23-057736:8k_2_02:76]
(Dollars in thousands)

[0001104659-23-057736:8k_2_02:77]
| Backlog And Entered Orders - Q2 2023 |  | Aerospace & Defense |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 1/1/23 |  | $ | 422,551 |  |  |  | 137,286 |  |  |  | 158,584 |  |  |  | 718,421 |  |
| Entered Orders |  |  | 111,677 |  |  |  | 84,571 |  |  |  | 55,328 |  |  |  | 251,576 |  |
| Sales |  |  | (98,982 | ) |  |  | (79,161 | ) |  |  | (50,993 | ) |  |  | (229,136 | ) |
| Ending Backlog - 3/31/23 |  | $ | 435,246 |  |  |  | 142,696 |  |  |  | 162,919 |  |  |  | 740,861 |  |

[0001104659-23-057736:8k_2_02:78]
| Backlog And Entered Orders - YTD Q2 2023 |  | Aerospace & Defense |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 10/1/22 |  | $ | 408,269 |  |  |  | 128,156 |  |  |  | 158,597 |  |  |  | 695,022 |  |
| Entered Orders |  |  | 208,942 |  |  |  | 164,746 |  |  |  | 106,788 |  |  |  | 480,476 |  |
| Sales |  |  | (181,965 | ) |  |  | (150,206 | ) |  |  | (102,466 | ) |  |  | (434,637 | ) |
| Ending Backlog - 3/31/23 |  | $ | 435,246 |  |  |  | 142,696 |  |  |  | 162,919 |  |  |  | 740,861 |  |

[0001104659-23-057736:8k_2_02:79]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-23-057736:8k_2_02:80]
Reconciliation of Non-GAAP Financial Measures (Unaudited)

[0001104659-23-057736:8k_2_02:81]
| EPS – Adjusted Basis Reconciliation – Q2 2023 |  |  |  |  |
| EPS – GAAP Basis – Q2 2023 |  | $ | 0.69 |  |
| Adjustments (defined below) |  |  | 0.07 |  |
| EPS – As Adjusted Basis – Q2 2023 |  | $ | 0.76 |  |
| Adjustments exclude $0.07 per share consisting of executive management transition costs at Corporate, CMT acquisition inventory step-up charges and restructuring charges within the A&D segment in the second quarter of 2023. |  |  |  |  |
| The $0.07 of EPS adjustments per share consists of $2.3M of pre-tax charges offset by $529K of tax benefit for net impact of $1,771K. |  |  |  |  |
| EPS – Adjusted Basis Reconciliation – Q2 2022 |  |  |  |  |
| EPS – GAAP Basis – Q2 2022 |  | $ | 0.64 |  |
| Adjustments (defined below) |  |  | 0.01 |  |
| EPS – As Adjusted Basis – Q2 2022 |  | $ | 0.65 |  |
| Adjustments exclude $0.01 per share consisting of NEco acquisition inventory step-up charges and Corporate related acquisition costs in the second quarter of 2022. |  |  |  |  |
| The $0.01 of EPS adjustments per share consists of $282K of pre-tax charges offset by $65K of tax benefit for net impact of $217K. |  |  |  |  |
| EPS – Adjusted Basis Reconciliation – YTD Q2 2023 |  |  |  |  |
| EPS – GAAP Basis – YTD Q2 2023 |  | $ | 1.26 |  |
| Adjustments (defined below) |  |  | 0.10 |  |
| EPS – As Adjusted Basis – YTD Q2 2023 |  | $ | 1.36 |  |
| Adjustments exclude $0.10 per share consisting of executive management transition costs at Corporate, CMT acquisition inventory step-up charges and restructuring charges within the A&D segment in the first six months of 2023. |  |  |  |  |
| The $0.10 of EPS adjustments per share consists of $3,292K of pre-tax charges offset by $757K of tax benefit for net impact of $2,535K. |  |  |  |  |
| EPS – Adjusted Basis Reconciliation – YTD Q2 2022 |  |  |  |  |
| EPS – GAAP Basis – YTD Q2 2022 |  | $ | 1.08 |  |
| Adjustments (defined below) |  |  | 0.03 |  |
| EPS – As Adjusted Basis – YTD Q2 2022 |  | $ | 1.11 |  |
| Adjustments exclude $0.03 per share consisting of Altanova & NEco acquisition inventory step-up charges and Corporate related acquisition costs in the first six months of 2022. |  |  |  |  |
| The $0.03 of EPS adjustments per share consists of $1,107K of pre-tax charges offset by $255K of tax benefit for net impact of $852K. |  |  |  |  |

## item 5.02 — body, verbatim

[0001104659-23-057736:8k_body:1]
Item 5.02

[0001104659-23-057736:8k_body:2]
Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements
of Certain Officers

[0001104659-23-057736:8k_body:3]
Today, May 9, 2023, the Board of Directors announced in a press release
(Exhibit 99.1) that on May 3, 2023 it had accepted the resignation of Victor L. Richey as a director of the Company, as Executive Chair
of the Board, and as an employee of the Company, all effective June 30, 2023. Mr. Richey’s resignation as a director was due to
his retirement and was not due to any disagreement with the Company on any matter.

[0001104659-23-057736:8k_body:4]
See also Item 8.01, Other Events, below.
