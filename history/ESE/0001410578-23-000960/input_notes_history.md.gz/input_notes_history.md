# ESE note change history — 0001410578-23-000086 → 0001410578-23-000960


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-05-10):
[0001410578-23-000960:note_history:1]
The Company’s results for the three-month period ended March 31, 2023 are not necessarily indicative of the results for the entire 2023 fiscal year. References to the second quarters of 2023 and 2022 represent the fiscal quarters ended March 31, 2023 and 2022, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.
  (was, 2023-02-09, similarity 0.9616):
[0001410578-23-000086:note_history:1]
The Company’s results for the three-month period ended December 31, 2022 are not necessarily indicative of the results for the entire 2023 fiscal year. References to the first quarters of 2023 and 2022 represent the fiscal quarters ended December 31, 2022 and 2021, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-10):
[0001410578-23-000960:note_history:2]
| ​ |  | March 31, | ​ | September 30, |
| (In thousands) |  | 2023 |  | 2022 |
| Total borrowings | ​ | $ | 161,000 |  | 153,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 141,000 |  | 133,000 |
  (was, 2023-02-09, similarity 0.976):
[0001410578-23-000086:note_history:2]
| ​ |  | December 31, | ​ | September 30, |
| (In thousands) |  | 2022 |  | 2022 |
| Total borrowings | ​ | $ | 132,000 |  | 153,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 112,000 |  | 133,000 |

- changed (2023-05-10):
[0001410578-23-000960:note_history:3]
The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024, with balance due by this date.
  (was, 2023-02-09, similarity 0.9989):
[0001410578-23-000086:note_history:3]
The Credit Facility includes a $500 million revolving line of credit, as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024, with balance due by this date.

- changed (2023-05-10):
[0001410578-23-000960:note_history:4]
At March 31, 2023, the Company had approximately $332 million available to borrow under the Credit Facility, plus the $250 million increase option, subject to lenders’ consent, in addition to $48.2 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of March 31, 2023, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $7.3 million at March 31, 2023.
  (was, 2023-02-09, similarity 0.9588):
[0001410578-23-000086:note_history:4]
At December 31, 2022, the Company had approximately $360 million available to borrow under the Credit Facility, plus the $250 million increase option subject to lenders’ consent, in addition to $51.9 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of December 31, 2022, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $8.2 million at December 31, 2022.

- changed (2023-05-10):
[0001410578-23-000960:note_history:5]
Interest on borrowings under the Credit Facility is calculated at a spread over either the Standard Overnight Financing Rate (SOFR) or the prime rate depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The interest rate spreads on the facility and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio.  The weighted average interest rates were 5.97% and 5.33% for the three and six-month periods ending March 31, 2023, respectively, and 1.29% and 1.23% for the three and six-month periods ending March 31, 2022. As of March 31, 2023, the Company was in compliance with all covenants.
  (was, 2023-02-09, similarity 0.8074):
[0001410578-23-000086:note_history:5]
Interest on borrowings under the Credit Facility is calculated at a spread over either the New York Federal Reserve Bank Rate, the prime rate, or the London Interbank Offered Rate (LIBOR), depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The interest rate spreads on the facility and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio.  The weighted average interest rates were 4.56% and 1.17% for the three-month periods ending December 31, 2022 and 2021, respectively. As of December 31, 2022, the Company was in compliance with all covenants.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-10):
[0001410578-23-000960:note_history:6]
| ​ |  | March 31, | ​ | September 30, |
| (In thousands) |  | 2023 |  | 2022 |
| Total borrowings | ​ | $ | 161,000 |  | 153,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 141,000 |  | 133,000 |
  (was, 2023-02-09, similarity 0.976):
[0001410578-23-000086:note_history:6]
| ​ |  | December 31, | ​ | September 30, |
| (In thousands) |  | 2022 |  | 2022 |
| Total borrowings | ​ | $ | 132,000 |  | 153,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 112,000 |  | 133,000 |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-10):
[0001410578-23-000960:note_history:7]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2023 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue within each reportable segment.
  (was, 2023-02-09, similarity 0.953):
[0001410578-23-000086:note_history:7]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2022 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within each reportable segment.

- changed (2023-05-10):
[0001410578-23-000960:note_history:8]
| Three months ended March 31, 2023 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 48,228 | ​ | $ | 78,110 | ​ | $ | 43,188 | ​ | $ | 169,526 |
| Government | ​ |  | 50,754 | ​ |  | 1,051 | ​ |  | 7,805 | ​ |  | 59,610 |
| Total revenues | ​ | $ | 98,982 | ​ | $ | 79,161 | ​ | $ | 50,993 | ​ | $ | 229,136 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 82,516 | ​ | $ | 53,020 | ​ | $ | 27,504 | ​ | $ | 163,040 |
| International | ​ |  | 16,466 | ​ |  | 26,141 | ​ |  | 23,489 | ​ |  | 66,096 |
| Total revenues | ​ | $ | 98,982 | ​ | $ | 79,161 | ​ | $ | 50,993 | ​ | $ | 229,136 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 47,255 | ​ | $ | 64,080 | ​ | $ | 11,968 | ​ | $ | 123,303 |
| Over time | ​ |  | 51,727 | ​ |  | 15,081 | ​ |  | 39,025 | ​ |  | 105,833 |
| Total revenues | ​ | $ | 98,982 | ​ | $ | 79,161 | ​ | $ | 50,993 | ​ | $ | 229,136 |
  (was, 2023-02-09, similarity 0.9808):
[0001410578-23-000086:note_history:8]
| ​ | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 36,740 | ​ | $ | 70,162 | ​ | $ | 45,992 | ​ | $ | 152,894 |
| U.S. Government | ​ |  | 46,243 | ​ |  | 883 | ​ |  | 5,481 | ​ |  | 52,607 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 68,934 | ​ | $ | 46,379 | ​ | $ | 27,503 | ​ | $ | 142,816 |
| International | ​ |  | 14,049 | ​ |  | 24,666 | ​ |  | 23,970 | ​ |  | 62,685 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 33,604 | ​ | $ | 56,031 | ​ | $ | 9,101 | ​ | $ | 98,736 |
| Over time | ​ |  | 49,379 | ​ |  | 15,014 | ​ |  | 42,372 | ​ |  | 106,765 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |

- changed (2023-05-10):
[0001410578-23-000960:note_history:9]
| Six months ended March 31, 2023 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial |  | $ | 84,968 | ​ | $ | 148,273 | ​ | $ | 89,180 | ​ | $ | 322,421 |
| Government | ​ | ​ | 96,997 | ​ |  | 1,933 | ​ |  | 13,286 | ​ |  | 112,216 |
| Total revenues |  | $ | 181,965 | ​ | $ | 150,206 | ​ | $ | 102,466 | ​ | $ | 434,637 |
| Geographic location: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States |  | $ | 151,450 | ​ | $ | 99,399 | ​ | $ | 55,007 | ​ | $ | 305,856 |
| International | ​ | ​ | 30,515 | ​ |  | 50,807 | ​ |  | 47,459 | ​ |  | 128,781 |
| Total revenues |  | $ | 181,965 | ​ | $ | 150,206 | ​ | $ | 102,466 | ​ | $ | 434,637 |
| Revenue recognition method: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time |  | $ | 80,859 | ​ | $ | 120,111 | ​ | $ | 21,069 | ​ | $ | 222,039 |
| Over time | ​ | ​ | 101,106 | ​ |  | 30,095 | ​ |  | 81,397 | ​ |  | 212,598 |
| Total revenues |  | $ | 181,965 | ​ | $ | 150,206 | ​ | $ | 102,466 | ​ | $ | 434,637 |
  (was, 2023-02-09, similarity 0.9818):
[0001410578-23-000086:note_history:9]
| ​ | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial |  | $ | 28,075 | ​ | $ | 62,842 | ​ | $ | 41,037 | ​ | $ | 131,954 |
| U.S. Government | ​ | ​ | 42,169 | ​ |  | 643 | ​ |  | 2,244 | ​ |  | 45,056 |
| Total revenues |  | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 |
| Geographic location: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States |  | $ | 60,687 | ​ | $ | 38,741 | ​ | $ | 22,975 | ​ | $ | 122,403 |
| International | ​ | ​ | 9,557 | ​ |  | 24,744 | ​ |  | 20,306 | ​ |  | 54,607 |
| Total revenues |  | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 |
| Revenue recognition method: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time |  | $ | 28,558 | ​ | $ | 50,835 | ​ | $ | 12,821 | ​ | $ | 92,214 |
| Over time | ​ | ​ | 41,686 | ​ |  | 12,650 | ​ |  | 30,460 | ​ |  | 84,796 |
| Total revenues |  | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 |

- changed (2023-05-10):
[0001410578-23-000960:note_history:10]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2022 are presented in the tables below.
  (was, 2023-02-09, similarity 0.935):
[0001410578-23-000086:note_history:10]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2021 are presented in the table below:

- added (2023-05-10):
[0001410578-23-000960:note_history:11]
| Three months ended March 31, 2022 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 33,562 | ​ | $ | 63,379 | ​ | $ | 51,903 | ​ | $ | 148,844 |
| Government | ​ |  | 51,259 | ​ |  | 812 | ​ |  | 4,013 | ​ |  | 56,084 |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 72,621 | ​ | $ | 41,458 | ​ | $ | 31,071 | ​ | $ | 145,150 |
| International | ​ |  | 12,200 | ​ |  | 22,733 | ​ |  | 24,845 | ​ |  | 59,778 |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 35,666 | ​ | $ | 51,202 | ​ | $ | 14,838 | ​ | $ | 101,706 |
| Over time | ​ |  | 49,155 | ​ |  | 12,989 | ​ |  | 41,078 | ​ |  | 103,222 |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 |

- added (2023-05-10):
[0001410578-23-000960:note_history:12]
| Six months ended March 31, 2022 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 61,489 | ​ | $ | 126,221 | ​ | $ | 92,941 | ​ | $ | 280,651 |
| Government | ​ |  | 93,576 | ​ |  | 1,455 | ​ |  | 6,256 | ​ |  | 101,287 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 133,313 | ​ | $ | 80,199 | ​ | $ | 54,047 | ​ | $ | 267,559 |
| International | ​ |  | 21,752 | ​ |  | 47,477 | ​ |  | 45,150 | ​ |  | 114,379 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 64,223 | ​ | $ | 102,037 | ​ | $ | 27,660 | ​ | $ | 193,920 |
| Over time | ​ |  | 90,842 | ​ |  | 25,639 | ​ |  | 71,537 | ​ |  | 188,018 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-10):
[0001410578-23-000960:note_history:13]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2023 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue within each reportable segment.
  (was, 2023-02-09, similarity 0.953):
[0001410578-23-000086:note_history:13]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2022 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within each reportable segment.

- changed (2023-05-10):
[0001410578-23-000960:note_history:14]
| Three months ended March 31, 2023 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 48,228 | ​ | $ | 78,110 | ​ | $ | 43,188 | ​ | $ | 169,526 |
| Government | ​ |  | 50,754 | ​ |  | 1,051 | ​ |  | 7,805 | ​ |  | 59,610 |
| Total revenues | ​ | $ | 98,982 | ​ | $ | 79,161 | ​ | $ | 50,993 | ​ | $ | 229,136 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 82,516 | ​ | $ | 53,020 | ​ | $ | 27,504 | ​ | $ | 163,040 |
| International | ​ |  | 16,466 | ​ |  | 26,141 | ​ |  | 23,489 | ​ |  | 66,096 |
| Total revenues | ​ | $ | 98,982 | ​ | $ | 79,161 | ​ | $ | 50,993 | ​ | $ | 229,136 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 47,255 | ​ | $ | 64,080 | ​ | $ | 11,968 | ​ | $ | 123,303 |
| Over time | ​ |  | 51,727 | ​ |  | 15,081 | ​ |  | 39,025 | ​ |  | 105,833 |
| Total revenues | ​ | $ | 98,982 | ​ | $ | 79,161 | ​ | $ | 50,993 | ​ | $ | 229,136 |
  (was, 2023-02-09, similarity 0.9808):
[0001410578-23-000086:note_history:14]
| ​ | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 36,740 | ​ | $ | 70,162 | ​ | $ | 45,992 | ​ | $ | 152,894 |
| U.S. Government | ​ |  | 46,243 | ​ |  | 883 | ​ |  | 5,481 | ​ |  | 52,607 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 68,934 | ​ | $ | 46,379 | ​ | $ | 27,503 | ​ | $ | 142,816 |
| International | ​ |  | 14,049 | ​ |  | 24,666 | ​ |  | 23,970 | ​ |  | 62,685 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 33,604 | ​ | $ | 56,031 | ​ | $ | 9,101 | ​ | $ | 98,736 |
| Over time | ​ |  | 49,379 | ​ |  | 15,014 | ​ |  | 42,372 | ​ |  | 106,765 |
| Total revenues | ​ | $ | 82,983 | ​ | $ | 71,045 | ​ | $ | 51,473 | ​ | $ | 205,501 |

- changed (2023-05-10):
[0001410578-23-000960:note_history:15]
| Six months ended March 31, 2023 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial |  | $ | 84,968 | ​ | $ | 148,273 | ​ | $ | 89,180 | ​ | $ | 322,421 |
| Government | ​ | ​ | 96,997 | ​ |  | 1,933 | ​ |  | 13,286 | ​ |  | 112,216 |
| Total revenues |  | $ | 181,965 | ​ | $ | 150,206 | ​ | $ | 102,466 | ​ | $ | 434,637 |
| Geographic location: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States |  | $ | 151,450 | ​ | $ | 99,399 | ​ | $ | 55,007 | ​ | $ | 305,856 |
| International | ​ | ​ | 30,515 | ​ |  | 50,807 | ​ |  | 47,459 | ​ |  | 128,781 |
| Total revenues |  | $ | 181,965 | ​ | $ | 150,206 | ​ | $ | 102,466 | ​ | $ | 434,637 |
| Revenue recognition method: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time |  | $ | 80,859 | ​ | $ | 120,111 | ​ | $ | 21,069 | ​ | $ | 222,039 |
| Over time | ​ | ​ | 101,106 | ​ |  | 30,095 | ​ |  | 81,397 | ​ |  | 212,598 |
| Total revenues |  | $ | 181,965 | ​ | $ | 150,206 | ​ | $ | 102,466 | ​ | $ | 434,637 |
  (was, 2023-02-09, similarity 0.9818):
[0001410578-23-000086:note_history:15]
| ​ | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial |  | $ | 28,075 | ​ | $ | 62,842 | ​ | $ | 41,037 | ​ | $ | 131,954 |
| U.S. Government | ​ | ​ | 42,169 | ​ |  | 643 | ​ |  | 2,244 | ​ |  | 45,056 |
| Total revenues |  | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 |
| Geographic location: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States |  | $ | 60,687 | ​ | $ | 38,741 | ​ | $ | 22,975 | ​ | $ | 122,403 |
| International | ​ | ​ | 9,557 | ​ |  | 24,744 | ​ |  | 20,306 | ​ |  | 54,607 |
| Total revenues |  | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 |
| Revenue recognition method: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time |  | $ | 28,558 | ​ | $ | 50,835 | ​ | $ | 12,821 | ​ | $ | 92,214 |
| Over time | ​ | ​ | 41,686 | ​ |  | 12,650 | ​ |  | 30,460 | ​ |  | 84,796 |
| Total revenues |  | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 |

- changed (2023-05-10):
[0001410578-23-000960:note_history:16]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2022 are presented in the tables below.
  (was, 2023-02-09, similarity 0.935):
[0001410578-23-000086:note_history:16]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2021 are presented in the table below:

- added (2023-05-10):
[0001410578-23-000960:note_history:17]
| Three months ended March 31, 2022 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 33,562 | ​ | $ | 63,379 | ​ | $ | 51,903 | ​ | $ | 148,844 |
| Government | ​ |  | 51,259 | ​ |  | 812 | ​ |  | 4,013 | ​ |  | 56,084 |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 72,621 | ​ | $ | 41,458 | ​ | $ | 31,071 | ​ | $ | 145,150 |
| International | ​ |  | 12,200 | ​ |  | 22,733 | ​ |  | 24,845 | ​ |  | 59,778 |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 35,666 | ​ | $ | 51,202 | ​ | $ | 14,838 | ​ | $ | 101,706 |
| Over time | ​ |  | 49,155 | ​ |  | 12,989 | ​ |  | 41,078 | ​ |  | 103,222 |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 |

- added (2023-05-10):
[0001410578-23-000960:note_history:18]
| Six months ended March 31, 2022 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 61,489 | ​ | $ | 126,221 | ​ | $ | 92,941 | ​ | $ | 280,651 |
| Government | ​ |  | 93,576 | ​ |  | 1,455 | ​ |  | 6,256 | ​ |  | 101,287 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 133,313 | ​ | $ | 80,199 | ​ | $ | 54,047 | ​ | $ | 267,559 |
| International | ​ |  | 21,752 | ​ |  | 47,477 | ​ |  | 45,150 | ​ |  | 114,379 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 64,223 | ​ | $ | 102,037 | ​ | $ | 27,660 | ​ | $ | 193,920 |
| Over time | ​ |  | 90,842 | ​ |  | 25,639 | ​ |  | 71,537 | ​ |  | 188,018 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |

- changed (2023-05-10):
[0001410578-23-000960:note_history:19]
For our overtime revenue recognized using the output method of costs incurred, contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to one or more years, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change. In addition, in the USG
  (was, 2023-02-09, similarity 0.7045):
[0001410578-23-000086:note_history:19]
For our overtime revenue recognized using the output method of costs incurred, contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to one or more years, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change. In addition, in the USG segment, we recognize revenue as a series of distinct services based on each day of providing services (straight-line over the contract term) for certain of our USG segment contracts. Under the typical payment terms of our service contracts, the customer pays us in advance of when services are performed. In addition, in the Test segment, we use milestones to measure progress for our Test segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts.

- added (2023-05-10):
[0001410578-23-000960:note_history:20]
segment, we recognize revenue as a series of distinct services based on each day of providing services (straight-line over the contract term) for certain of our USG segment contracts. Under the typical payment terms of our service contracts, the customer pays us in advance of when services are performed. In addition, in the Test segment, we use milestones to measure progress for our Test segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts.

- changed (2023-05-10):
[0001410578-23-000960:note_history:21]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At March 31, 2023, the Company had $740.9 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 79% in the next twelve months.
  (was, 2023-02-09, similarity 0.9907):
[0001410578-23-000086:note_history:21]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At December 31, 2022, the Company had $718.4 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 80% in the next twelve months.

- changed (2023-05-10):
[0001410578-23-000960:note_history:22]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred. At March 31, 2023, contract assets and liabilities totaled $128.2 million and $131.7 million, respectively. During the first six months of 2023, the Company recognized approximately $55 million in revenues that were included in the contract liabilities balance at September 30, 2022. At September 30, 2022, contract assets and liabilities totaled $125.2 million and $137.6 million, respectively.
  (was, 2023-02-09, similarity 0.9784):
[0001410578-23-000086:note_history:22]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred. At December 31, 2022, contract assets and liabilities totaled $122.5 million and $133.6 million, respectively. During the first quarter of 2023, the Company recognized approximately $31.0 million in revenues that were included in the contract liabilities balance at September 30, 2022. At September 30, 2022, contract assets and liabilities totaled $125.2 million and $137.6 million, respectively.
