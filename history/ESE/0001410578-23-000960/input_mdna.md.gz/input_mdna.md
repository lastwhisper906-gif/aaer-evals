# ESE MD&A — 0001410578-23-000960


## mdna

[0001410578-23-000960:mdna:1]
[same as prior period, unchanged from 0001410578-23-000086:mdna:1]

[0001410578-23-000960:mdna:2]
[same as prior period, unchanged from 0001410578-23-000086:mdna:2]

[0001410578-23-000960:mdna:3]
References to the second quarters of 2023 and 2022 represent the three-month periods ended March 31, 2023 and 2022, respectively.

[0001410578-23-000960:mdna:4]
[same as prior period, unchanged from 0001410578-23-000086:mdna:4]

[0001410578-23-000960:mdna:5]
In the second quarter of 2023, sales, net earnings and diluted earnings per share were $229.1 million, $17.9 million and $0.69 per share, respectively, compared to $204.9 million, $16.6 million and $0.64 per share, respectively, in the second quarter of 2022. In the first six months of 2023, sales, net earnings and diluted earnings per share were $434.6 million, $32.6 million and $1.26 per share, respectively, compared to $381.9 million, $28.1 million and $1.08 per share, respectively, in the first six months of 2022.

[0001410578-23-000960:mdna:6]
[same as prior period, unchanged from 0001410578-23-000086:mdna:6]

[0001410578-23-000960:mdna:7]
In the second quarter of 2023, net sales of $229.1 million were $24.2 million, or 11.8%, higher than the $204.9 million in the second quarter of 2022. In the first six months of 2023, net sales of $434.6 million were $52.7 million, or 13.8%, higher than the $381.9 million in the first six months of 2022. The increase in net sales in the second quarter of 2023 as compared to the second quarter of 2022 was due to a $15.0 million increase in the USG segment, a $14.2 million increase in the Aerospace & Defense segment, partially offset by a $4.9 million decrease in the Test segment. The increase in net sales in the first six months of 2023 as compared to the first six months of 2022 was due to a $26.9 million increase in the Aerospace & Defense segment, a $22.5 million increase in the USG segment, and a $3.3 million increase in the Test segment.

[0001410578-23-000960:mdna:8]
[same as prior period, unchanged from 0001410578-23-000086:mdna:8]

[0001410578-23-000960:mdna:9]
In the second quarter of 2023, net sales of $99.0 million were $14.2 million, or 16.7%, higher than the $84.8 million in the second quarter of 2022. In the first six months of 2023, net sales of $182.0 million were $26.9 million, or 17.3%, higher than the $155.1 million in the first six months of 2022. The sales increase in the second quarter of 2023 compared to the second quarter of 2022 was mainly due to a $6.8 million increase in net sales at Mayday, a $3.1 million increase in net sales at Globe driven by the CMT acquisition, a $2.6 million increase in net sales at Crissair, a $2.6 million increase in net sales at PTI, a $1.3 million increase in net sales at VACCO, partially offset by a $2.2 million decrease in sales at Westland driven by timing of navy projects. The sales increase in the first six months of 2023 compared to the first six months of 2022 was mainly due to an $11.8 million increase in net sales at Mayday, a $4.9 million increase in net sales at VACCO, a $4.8 million increase in net sales at Crissair, a $4.6 million increase in net sales at PTI, and a $4.6 million increase in net sales at Globe driven by the CMT acquisition, partially offset by a $3.8 million decrease in net sales at Westland driven by timing of navy projects. The increase in net sales at Mayday, Crissair and PTI in the second quarter and first six months of 2023 as compared to the corresponding periods of 2022 was primarily due to an increase in commercial aerospace sales driven by the rebound from the COVID-19 pandemic.

[0001410578-23-000960:mdna:10]
[same as prior period, unchanged from 0001410578-23-000086:mdna:10]

[0001410578-23-000960:mdna:11]
In the second quarter of 2023, net sales of $79.2 million were $15.0 million, or 23.4%, higher than the $64.2 million in the second quarter of 2022. In the first six months of 2023, net sales of $150.2 million were $22.5 million, or 17.6%, higher than the $127.7 million in the first six months of 2022. The increase in the second quarter and first six months of 2023 compared to the corresponding periods of 2022 was mainly due to higher shipments of condition monitoring products and service revenue at Doble and an increase in product sales at NRG.

[0001410578-23-000960:mdna:12]
[same as prior period, unchanged from 0001410578-23-000086:mdna:12]

[0001410578-23-000960:mdna:13]
In the second quarter of 2023, net sales of $51.0 million were $4.9 million, or 8.8%, lower than the $55.9 million in the second quarter of 2022. In the first six months of 2023, net sales of $102.5 million were $3.3 million, or 3.3%, higher than the $99.2 million in the first six months of 2022. The decrease in the second quarter of 2023 as compared to the second quarter of 2022 was primarily due to a $9.7 million decrease in sales from the Company’s U.S. and Asian operations driven by COVID disruptions in China partially offset by a $4.8 million increase in sales from the segment’s European operations due to strength from test and measurement chamber projects. The increase in the first six months of 2023 compared to the first six months of 2022 was due to a $10.3 million increase in sales from the Company’s European and U.S. operations partially offset by a $7.0 million decrease in sales from the segment’s Asian operations due to COVID disruptions in China and timing of test and measurement chamber projects.

[0001410578-23-000960:mdna:14]
[same as prior period, unchanged from 0001410578-23-000086:mdna:14]

[0001410578-23-000960:mdna:15]
Backlog was $740.9 million at March 31, 2023 compared with $695.0 million at September 30, 2022. The Company received new orders totaling $251.6 million in the second quarter of 2023 compared to $236.5 million in the second quarter of 2022. Of the new orders received in the second quarter of 2023, $111.7 million related to Aerospace & Defense products (including $7 million of acquired backlog from the CMT acquisition), $84.6 million related to USG products, and $55.3 million related to Test products. Of the new orders received in the second quarter of 2022, $94.6 million related to Aerospace & Defense products, $86.5 million related to USG products, and $55.4 million related to Test products.

[0001410578-23-000960:mdna:16]
The Company received new orders totaling $480.5 million in the first six months of 2023 compared to $460.9 million in the first six months of 2022. Of the new orders received in the first six months of 2023, $208.9 million related to Aerospace & Defense products, $164.8 million related to USG products, and $106.8 million related to Test products. Of the new orders received in the first six months of 2022, $184.8 million related to Aerospace & Defense products, $152.7 million related to USG products, and $123.4 million related to Test products.

[0001410578-23-000960:mdna:17]
[same as prior period, unchanged from 0001410578-23-000086:mdna:16]

[0001410578-23-000960:mdna:18]
Selling, general and administrative (SG&A) expenses for the second quarter of 2023 were $53.9 million (23.5% of net sales), compared with $48.0 million (23.4% of net sales) for the second quarter of 2022. For the first six months of 2023, SG&A expenses were $105.2 million (24.2% of net sales) compared to $94.6 million (24.8% of net sales) for the first six months of 2022. The increase in SG&A in the second quarter and first six months of 2023 compared to the corresponding periods of 2022 was mainly due to higher expenses at Corporate due to executive management transition costs and professional fees and higher expenses at Doble as a result of increased sales and marketing and event costs.

[0001410578-23-000960:mdna:19]
[same as prior period, unchanged from 0001410578-23-000086:mdna:18]

[0001410578-23-000960:mdna:20]
Amortization of intangible assets was $7.0 million and $13.9 million for the second quarter and first six months of 2023, respectively, compared to $6.5 million and $13.0 million for the corresponding periods of 2022. Amortization expenses consist of amortization of acquired intangible assets from acquisitions and other identifiable intangible assets (primarily software). The increase in amortization expense in the second quarter and first six months of 2023 compared to the corresponding periods of 2022 was mainly due to the Company’s recent acquisition of CMT.

[0001410578-23-000960:mdna:21]
OTHER EXPENSES (INCOME), NET

[0001410578-23-000960:mdna:22]
Other expenses, net, was $0.3 million in the second quarter of 2023 compared to ($0.6) million of income in the second quarter of 2022. Other expenses, net, was $0.7 million in the first six months of 2023 compared to ($0.6) million of income in the first six months of 2022. There were no individually significant items in other expenses (income), net, in the second quarter or first six months of 2023 or 2022, respectively.

[0001410578-23-000960:mdna:23]
[same as prior period, unchanged from 0001410578-23-000086:mdna:22]

[0001410578-23-000960:mdna:24]
The Company evaluates the performance of its operating segments based on EBIT, and provides EBIT on a consolidated basis, which is a non-GAAP financial measure. Please refer to the discussion of non-GAAP financial measures in Note 7 to the Consolidated Financial Statements, above. EBIT was $25.6 million (11.2% of net sales) for the second quarter of 2023 compared to $22.7 million (11.1% of net sales) for the second quarter of 2022. For the first six months of 2023, EBIT was $46.2 million (10.6% of net sales) compared to $38.3 million (10.0% of net sales) for the first six months of 2022.

[0001410578-23-000960:mdna:25]
The following table presents a reconciliation of EBIT to net earnings.

[0001410578-23-000960:mdna:26]
| ​ | ​ | Three Months Ended | ​ | Six Months Ended |
| ​ | ​ | March 31, | ​ | March 31, |
| (In thousands) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net earnings | ​ | $ | 17,878 | ​ | ​ | 16,583 | ​ | 32,605 | ​ | 28,107 |
| Plus: Interest expense, net | ​ |  | 2,269 | ​ | ​ | 1,020 | ​ | 3,927 | ​ | 1,753 |
| Plus: Income tax expense | ​ |  | 5,472 | ​ | ​ | 5,085 | ​ | 9,644 | ​ | 8,398 |
| Consolidated EBIT | ​ | $ | 25,619 | ​ | ​ | 22,688 | ​ | 46,176 | ​ | 38,258 |

[0001410578-23-000960:mdna:27]
[same as prior period, unchanged from 0001410578-23-000086:mdna:26]

[0001410578-23-000960:mdna:28]
EBIT in the second quarter of 2023 was $18.8 million (19.0% of net sales) compared to $14.3 million (16.9% of net sales) in the second quarter of 2022. EBIT in the first six months of 2023 was $31.3 million (17.2% of net sales) compared to $24.3 million (15.7% of net sales) in the first six months of 2022. The increase in EBIT in the second quarter and first six months of 2023 compared to the corresponding periods of 2022 was mainly due to higher sales volumes at Mayday, VACCO, PTI, Crissair and Globe partially offset by a decrease in EBIT at Westland due to the lower sales volumes as mentioned above.  EBIT in the second quarter of 2023 was negatively impacted by a $0.6 million inventory step-up charge related to the CMT acquisition. EBIT in the first six months of 2022 was negatively impacted by a $0.3 million inventory step-up charge related to the NEco acquisition.

[0001410578-23-000960:mdna:29]
[same as prior period, unchanged from 0001410578-23-000086:mdna:28]

[0001410578-23-000960:mdna:30]
EBIT in the second quarter of 2023 was $14.1 million (17.8% of net sales) compared to $11.3 million (17.6% of net sales) in the second quarter of 2022. EBIT in the first six months of 2023 was $30.2 million (20.1% of net sales) compared to $24.7 million (19.3% of net sales) in the first six months of 2022. The increase in EBIT in the second quarter and first six months of 2023 compared to the corresponding periods of 2022 was mainly due to the higher sales volumes at Doble and NRG as mentioned above. EBIT in the first six months of 2022 was negatively impacted by approximately $0.5 million of inventory step-up charges related to the Altanova acquisition.

[0001410578-23-000960:mdna:31]
[same as prior period, unchanged from 0001410578-23-000086:mdna:30]

[0001410578-23-000960:mdna:32]
EBIT in the second quarter of 2023 was $7.2 million (14.2% of net sales) compared to $8.5 million (15.2% of net sales) in the second quarter of 2022. EBIT in the first six months of 2023 was $12.6 million (12.3% of net sales) compared to $12.5 million (12.6% of net sales) in the first six months of 2022. The decrease in EBIT in the second quarter of 2023 compared to the second quarter of 2022 was primarily due to lower sales volumes mainly from the segment’s Asian operations due to the COVID disruptions in China. The increase in EBIT in the first six months of 2023 compared to the first six months of 2022 was primarily due to the higher sales volumes from the segment’s European operations.

[0001410578-23-000960:mdna:33]
[same as prior period, unchanged from 0001410578-23-000086:mdna:32]

[0001410578-23-000960:mdna:34]
Corporate costs included in EBIT were $14.5 million and $28.0 million in the second quarter and first six months of 2023, respectively, compared to $11.5 million and $23.2 million in the corresponding periods of 2022. The increase in Corporate costs in the second quarter and first six months of 2023 compared to the corresponding periods of 2022 was mainly due to executive management transition costs and an increase in professional fees and amortization expense of acquired intangible assets related to the Company’s recent acquisition of CMT.

[0001410578-23-000960:mdna:35]
[same as prior period, unchanged from 0001410578-23-000086:mdna:34]

[0001410578-23-000960:mdna:36]
Interest expense was $2.3 million and $3.9 million in the second quarter and first six months of 2023, respectively, and $1.0 million and $1.8 million in the corresponding periods of 2022. The increase in interest expense in the second quarter and first six months of 2023 compared to the corresponding periods of 2022 was mainly due to higher average interest rates. The weighted average interest rates were 5.97% and 5.33% for the three and six-month periods ending March 31, 2023, respectively, and 1.29% and 1.23% for the three and six-month periods ending March 31, 2022.

[0001410578-23-000960:mdna:37]
[same as prior period, unchanged from 0001410578-23-000086:mdna:36]

[0001410578-23-000960:mdna:38]
The second quarter 2023 effective income tax rate was 23.4% compared to 23.5% in the second quarter of 2022. The effective income tax rate in the first six months of 2023 was 22.8% compared to 23.0% for the first six months of 2022. There were no significant or unusual items impacting the 2023 second quarter or year-to-date effective tax rate.

[0001410578-23-000960:mdna:39]
[same as prior period, unchanged from 0001410578-23-000086:mdna:38]

[0001410578-23-000960:mdna:40]
The Company’s overall financial position and liquidity remains strong. Working capital (current assets less current liabilities) increased to $273.1 million at March 31, 2023 from $254.5 million at September 30, 2022. Inventories increased by $23.4 million during this period due to a $12.8 million increase within the USG segment, a $9.3 million increase within the Aerospace & Defense segment and a $1.3 million increase within the Test segment resulting primarily from the timing of receipt of raw materials to meet anticipated demand and an increase in work in process inventories due to timing of manufacturing existing orders. Accounts receivable increased $16.2 million during this period mainly due to a $12.3 million increase within the Test segment and a $4.2 million increase within the A&D segment, due to timing of projects within the Test segment and higher sales volumes. within the A&D segment.

[0001410578-23-000960:mdna:41]
Net cash (used) provided by operating activities was ($5.5) million and $23.0 million in the first six months of 2023 and 2022, respectively. The decrease in net cash provided by operating activities in the first six months of 2023 as compared to the first six months of 2022 was mainly driven by higher working capital requirements, including an increase in inventories and accounts receivable.

[0001410578-23-000960:mdna:42]
Capital expenditures were $10.3 million and $20.7 million in the first six months of 2023 and 2022, respectively. The decrease in the first six months of 2023 compared to the prior year period was mainly due to the purchase of the NRG building of approximately $10 million in the first quarter of 2022. In addition, the Company incurred expenditures for capitalized software of $5.9 million and $4.7 million in the first six months of 2023 and 2022, respectively.

[0001410578-23-000960:mdna:43]
Acquisition

[0001410578-23-000960:mdna:44]
On February 1, 2023, the Company acquired CMT Materials, LLC and its affiliate Engineered Syntactic Systems, LLC (CMT) for a purchase price of $18 million. CMT, based in Attleboro, Massachusetts, is a leading supplier of syntactic materials for buoyancy and specialty applications. Since the date of acquisition, the operating results for the CMT business have been included as part of Globe within the A&D segment.

[0001410578-23-000960:mdna:45]
Credit Facility

[0001410578-23-000960:mdna:46]
At March 31, 2023, the Company had approximately $332 million available to borrow under its bank credit facility, a $250 million increase option, and $48.2 million cash on hand. At March 31, 2023, the Company had $161 million of outstanding borrowings under the credit facility in addition to outstanding letters of credit of $7.3 million. Cash flow from operations and borrowings under the Company’s credit facility are expected to meet the Company’s capital requirements and operational needs for the foreseeable future. The Company’s ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.

[0001410578-23-000960:mdna:47]
[same as prior period, unchanged from 0001410578-23-000086:mdna:44]

[0001410578-23-000960:mdna:48]
During the first six months of 2023, the Company repurchased approximately 138,000 shares for approximately $12.2 million. For further information on the share repurchases during the second quarter of 2023, see Part II, Item 2 of this Report.

[0001410578-23-000960:mdna:49]
[same as prior period, unchanged from 0001410578-23-000086:mdna:46]

[0001410578-23-000960:mdna:50]
A dividend of $0.08 per share, totaling $2.1 million, was paid on October 18, 2022 to stockholders of record as of October 4, 2022. A dividend of $0.08 per share, totaling $2.1 million, was paid on January 20, 2023 to stockholders of record as of January 5, 2023. Subsequent to March 31, 2023, a quarterly dividend of $0.08 per share, totaling $2.1 million, was paid on April 18, 2023 to stockholders of record as of April 3, 2023.

[0001410578-23-000960:mdna:51]
[same as prior period, unchanged from 0001410578-23-000086:mdna:50]

[0001410578-23-000960:mdna:52]
[same as prior period, unchanged from 0001410578-23-000086:mdna:51]

[0001410578-23-000960:mdna:53]
[same as prior period, unchanged from 0001410578-23-000086:mdna:52]

[0001410578-23-000960:mdna:54]
Contingencies

[0001410578-23-000960:mdna:55]
As a normal incident of the business in which the Company is engaged, various claims, charges and litigation are asserted or commenced against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. In the opinion of Management, the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company, are adequately reserved, are covered by insurance, or would not have a material adverse effect on the Company’s results from operations, capital expenditures, or competitive position.

[0001410578-23-000960:mdna:56]
[same as prior period, unchanged from 0001410578-23-000086:mdna:55]

[0001410578-23-000960:mdna:57]
Investors are cautioned that such statements are only predictions and speak only as of the date of this Form 10-Q, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment, including but not limited to those described in Item 1A, “Risk Factors,” of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2022, and the following: the continuing impact of the COVID-19 pandemic including the impacts of known or unknown COVID-19 variants, labor shortages, facility closures, shelter in place policies or quarantines, material shortages, transportation delays, termination or delays of Company contracts and the inability of our suppliers or customers to perform, the impacts of natural disasters on the Company’s operations and those of the Company’s customers and suppliers; the timing and content of future contract awards or customer orders; the appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer contracts or orders; weakening of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties; the availability of selected acquisitions; delivery delays or defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability of certain raw materials; inflationary pressures on the Company’s costs of labor, materials, components and supplies; labor disputes; changes in U.S. tax laws and regulations; other changes in laws and regulations including but not limited to changes in accounting standards and foreign taxation; changes in interest rates; costs relating to environmental matters arising from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the integration of recently acquired businesses.
