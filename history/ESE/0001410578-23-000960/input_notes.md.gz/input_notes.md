# ESE notes — 0001410578-23-000960


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001410578-23-000960:notes:1]
[same as prior period, unchanged from 0001410578-23-000086:notes:1]

[0001410578-23-000960:notes:2]
[same as prior period, unchanged from 0001410578-23-000086:notes:2]

[0001410578-23-000960:notes:3]
The Company’s results for the three-month period ended March 31, 2023 are not necessarily indicative of the results for the entire 2023 fiscal year. References to the second quarters of 2023 and 2022 represent the fiscal quarters ended March 31, 2023 and 2022, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:EarningsPerShareTextBlock

[0001410578-23-000960:notes:4]
[same as prior period, unchanged from 0001410578-23-000086:notes:4]

[0001410578-23-000960:notes:5]
[same as prior period, unchanged from 0001410578-23-000086:notes:5]

[0001410578-23-000960:notes:6]
| ​ |  | Three Months | ​ | Six Months |
| ​ | ​ | Ended March 31, | ​ | Ended March 31, |
| ​ |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Weighted Average Shares Outstanding — Basic |  | 25,800 |  | 25,953 | ​ | 25,831 |  | 26,008 |
| Dilutive Restricted Shares | ​ | 95 | ​ | 92 | ​ | 88 | ​ | 90 |
| Adjusted Shares — Diluted |  | 25,895 |  | 26,045 | ​ | 25,919 |  | 26,098 |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001410578-23-000960:notes:7]
3.    ACQUISITION

[0001410578-23-000960:notes:8]
On February 1, 2023, the Company acquired CMT Materials, LLC and its affiliate Engineered Syntactic Systems, LLC (CMT) for a purchase price of approximately $18 million, net of cash acquired. CMT, based in Attleboro, Massachusetts, is a supplier of syntactic materials for buoyancy and specialty applications. Since the date of acquisition, the operating results for the CMT business have been included as part of Globe in the A&D segment. The acquisition date fair value of the assets acquired and liabilities assumed primarily were as follows: approximately $1.7 million of accounts receivable, $3.0 million of inventory, $1.3 million of property, plant and equipment, $1.2 million of accounts payable and accrued expenses, $7.3 million of identifiable intangible assets, mainly consisting of customer relationships totaling $6.2 million. The acquired goodwill of $5.7 million related to excess value associated with opportunities to expand the services and products that the Company can offer to its customers. The Company anticipates that the goodwill will be deductible for tax purposes.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001410578-23-000960:notes:9]
4.    SHARE-BASED COMPENSATION

[0001410578-23-000960:notes:10]
The Company provides compensation benefits to certain key employees under several share-based plans providing for performance-accelerated and/or time-vested restricted stock unit awards, and to non-employee directors under a non-employee directors compensation plan.

[0001410578-23-000960:notes:11]
Performance-Accelerated Restricted Stock Unit (PARS) Awards and Time-Vested Restricted Stock Unit (RSU) Awards

[0001410578-23-000960:notes:12]
Compensation expense related to the PARS/RSU awards was $3.1 million and $4.7 million for the three and six-month periods ended March 31, 2023, respectively, and $1.5 million and $2.8 million for the corresponding periods in 2022. As of March 31, 2023, there were 244,387 unvested stock units outstanding.

[0001410578-23-000960:notes:13]
[same as prior period, unchanged from 0001410578-23-000086:notes:11]

[0001410578-23-000960:notes:14]
Compensation expense related to the non-employee director grants was $0.3 million and $0.6 million for the three and six-month periods ended March 31, 2023, respectively, and $0.3 million and $0.6 million for the corresponding periods in 2022.

[0001410578-23-000960:notes:15]
The total share-based compensation cost that has been recognized in the results of operations and included within selling, general and administrative expenses (SG&A) was $3.4 million and $5.3 million for the three and six-month periods ended March 31, 2023, respectively, and $1.7 million and $3.4 million for the corresponding periods in 2022. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $0.3 million and $0.6 million for the three and six-month periods ended March 31, 2023, respectively, and $0.3 million and $0.5 million for the corresponding periods in 2022. As of March 31, 2023, there was $10.8 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a remaining weighted-average period of 1.7 years.


## us-gaap:InventoryDisclosureTextBlock

[0001410578-23-000960:notes:16]
5.    INVENTORIES

[0001410578-23-000960:notes:17]
[same as prior period, unchanged from 0001410578-23-000086:notes:15]

[0001410578-23-000960:notes:18]
| ​ | ​ | March 31, | ​ | September 30, |
| (In thousands) |  | 2023 |  | 2022 |
| Finished goods | ​ | $ | 32,712 |  | 32,471 |
| Work in process | ​ |  | 46,596 |  | 38,492 |
| Raw materials | ​ |  | 106,445 |  | 91,440 |
| Total inventories, net | ​ | $ | 185,753 |  | 162,403 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001410578-23-000960:notes:19]
| 6. | GOODWILL AND OTHER INTANGIBLE ASSETS |

[0001410578-23-000960:notes:20]
Included on the Company’s Consolidated Balance Sheets at March 31, 2023 and September 30, 2022 are the following intangible assets gross carrying amounts and accumulated amortization:

[0001410578-23-000960:notes:21]
| ​ |  | March 31, |  | September 30, |
| (Dollars in thousands) |  | 2023 |  | 2022 |
| Goodwill | ​ | $ | 505,194 |  | 492,709 |
| Intangible assets with determinable lives: | ​ |  | ​ | ​ | ​ |
| Patents | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 2,425 | ​ | 2,353 |
| Less: accumulated amortization | ​ |  | 1,154 | ​ | 1,091 |
| Net | ​ | $ | 1,271 | ​ | 1,262 |
| Capitalized software | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 115,191 | ​ | 106,583 |
| Less: accumulated amortization | ​ |  | 74,787 | ​ | 70,476 |
| Net | ​ | $ | 40,404 | ​ | 36,107 |
| Customer relationships | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 298,005 | ​ | 287,447 |
| Less: accumulated amortization | ​ |  | 105,013 | ​ | 96,921 |
| Net | ​ | $ | 192,992 | ​ | 190,526 |
| Other | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 14,298 | ​ | 13,985 |
| Less: accumulated amortization | ​ |  | 8,779 | ​ | 7,440 |
| Net | ​ | $ | 5,519 | ​ | 6,545 |
| Intangible assets with indefinite lives: | ​ |  | ​ | ​ | ​ |
| Trade names | ​ | $ | 161,531 | ​ | 160,024 |

[0001410578-23-000960:notes:22]
The changes in the carrying amount of goodwill attributable to each business segment for the six months ended March 31, 2023 is as follows:

[0001410578-23-000960:notes:23]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | Aerospace | ​ | ​ |
| (Dollars in millions) |  | USG |  | Test |  | & Defense |  | Total |
| Balance as of September 30, 2022 | ​ | $ | 348.7 |  | ​ | 34.0 |  | 110.0 |  | 492.7 |
| Acquisition activity and adjustments | ​ | ​ | — | ​ | ​ | — | ​ | 5.7 | ​ | 5.7 |
| Foreign currency translation | ​ | ​ | 6.8 | ​ | ​ | — | ​ | — | ​ | 6.8 |
| Balance as of March 31, 2023 | ​ | $ | 355.5 | ​ | ​ | 34.0 | ​ | 115.7 | ​ | 505.2 |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001410578-23-000960:notes:24]
7.    BUSINESS SEGMENT INFORMATION

[0001410578-23-000960:notes:25]
The Company is organized based on the products and services that it offers and classifies its continuing business operations in three reportable segments for financial reporting purposes: Aerospace & Defense, Utility Solutions Group (USG), and RF Shielding and Test (Test).

[0001410578-23-000960:notes:26]
The Aerospace & Defense segment’s operations consist of PTI Technologies Inc. (PTI), VACCO Industries (VACCO), Crissair, Inc. (Crissair), Westland Technologies Inc. (Westland), Mayday Manufacturing Co. (Mayday) and Globe Composite Solutions, LLC (Globe). The companies within this segment primarily design and manufacture specialty filtration, fluid control and naval products, including hydraulic filter elements and fluid control devices used in aerospace and defense applications; unique filter mechanisms used in micro-propulsion devices for satellites, custom designed filters for manned aircraft and submarines; products and systems to reduce vibration and/or acoustic signatures and otherwise reduce or obscure a vessel’s signature, and other communications, sealing, surface control and hydrodynamic related applications to enhance U.S. Navy maritime survivability; precision-tolerance machined components for the aerospace and defense industry; and metal processing services.

[0001410578-23-000960:notes:27]
The USG segment’s operations consist primarily of Doble Engineering Company and related subsidiaries including Morgan Schaffer and Altanova (collectively, Doble), and NRG Systems, Inc. (NRG). Doble is an industry leader in the development, manufacture and delivery of diagnostic testing solutions that enable electric power grid operators to assess the integrity of high voltage power delivery equipment. It combines three core elements for customers – diagnostic test and condition monitoring instruments, expert consulting, and testing services – and provides access to its large reserve of related empirical knowledge. NRG is a global market leader in the design and manufacture of decision support tools for the renewable energy industry, primarily wind and solar.

[0001410578-23-000960:notes:28]
[same as prior period, unchanged from 0001410578-23-000086:notes:25]

[0001410578-23-000960:notes:29]
Management evaluates and measures the performance of its reportable segments based on “Net Sales” and “EBIT”, which are detailed in the table below. EBIT is defined as earnings before interest and taxes.

[0001410578-23-000960:notes:30]
| ​ | ​ | Three Months | ​ | Six Months |
| ​ | ​ | Ended March 31, | ​ | Ended March 31, |
| (In thousands) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| NET SALES | ​ | ​ |  | ​ |  | ​ |  | ​ |  |
| Aerospace & Defense | ​ | $ | 98,982 | ​ | 84,821 | ​ | 181,965 | ​ | 155,065 |
| USG | ​ | ​ | 79,161 | ​ | 64,191 | ​ | 150,206 | ​ | 127,676 |
| Test | ​ | ​ | 50,993 | ​ | 55,916 | ​ | 102,466 | ​ | 99,197 |
| Consolidated totals | ​ | $ | 229,136 | ​ | 204,928 | ​ | 434,637 | ​ | 381,938 |
| EBIT | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Aerospace & Defense | ​ | $ | 18,795 | ​ | 14,349 | ​ | 31,331 | ​ | 24,304 |
| USG | ​ | ​ | 14,061 | ​ | 11,314 | ​ | 30,192 | ​ | 24,705 |
| Test | ​ | ​ | 7,226 | ​ | 8,494 | ​ | 12,637 | ​ | 12,459 |
| Corporate (loss) | ​ | ​ | (14,463) | ​ | (11,469) | ​ | (27,984) | ​ | (23,210) |
| Consolidated EBIT | ​ | ​ | 25,619 | ​ | 22,688 | ​ | 46,176 | ​ | 38,258 |
| Less: Interest expense | ​ | ​ | (2,269) | ​ | (1,020) | ​ | (3,927) | ​ | (1,753) |
| Earnings before income taxes | ​ | $ | 23,350 | ​ | 21,668 | ​ | 42,249 | ​ | 36,505 |

[0001410578-23-000960:notes:31]
[same as prior period, unchanged from 0001410578-23-000086:notes:28]

[0001410578-23-000960:notes:32]
[same as prior period, unchanged from 0001410578-23-000086:notes:29]

[0001410578-23-000960:notes:33]
[same as prior period, unchanged from 0001410578-23-000086:notes:30]


## us-gaap:DebtDisclosureTextBlock

[0001410578-23-000960:notes:34]
8.    DEBT

[0001410578-23-000960:notes:35]
The Company’s debt is summarized as follows:

[0001410578-23-000960:notes:36]
| ​ |  | March 31, | ​ | September 30, |
| (In thousands) |  | 2023 |  | 2022 |
| Total borrowings | ​ | $ | 161,000 |  | 153,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 141,000 |  | 133,000 |

[0001410578-23-000960:notes:37]
The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024, with balance due by this date.

[0001410578-23-000960:notes:38]
At March 31, 2023, the Company had approximately $332 million available to borrow under the Credit Facility, plus the $250 million increase option, subject to lenders’ consent, in addition to $48.2 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of March 31, 2023, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $7.3 million at March 31, 2023.

[0001410578-23-000960:notes:39]
Interest on borrowings under the Credit Facility is calculated at a spread over either the Standard Overnight Financing Rate (SOFR) or the prime rate depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The interest rate spreads on the facility and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio.  The weighted average interest rates were 5.97% and 5.33% for the three and six-month periods ending March 31, 2023, respectively, and 1.29% and 1.23% for the three and six-month periods ending March 31, 2022. As of March 31, 2023, the Company was in compliance with all covenants.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001410578-23-000960:notes:40]
9.    INCOME TAX EXPENSE

[0001410578-23-000960:notes:41]
The second quarter 2023 effective income tax rate was 23.4% compared to 23.5% in the second quarter of 2022. The effective income tax rate in the first six months of 2023 was 22.8% compared to 23.0% for the first six months of 2022. There were no significant or unusual items impacting the 2023 second quarter or year-to-date effective tax rate.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001410578-23-000960:notes:42]
10.    SHAREHOLDERS’ EQUITY

[0001410578-23-000960:notes:43]
The change in shareholders’ equity for the first three and six months of 2023 and 2022 is shown below (in thousands):

[0001410578-23-000960:notes:44]
| ​ | ​ | Three Months Ended March 31, | ​ | Six Months Ended March 31, |
| ​ |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Common stock | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | 307 | ​ | 307 | ​ | 307 | ​ | 307 |
| Stock plans | ​ | ​ | 1 | ​ | — | ​ | 1 | ​ | — |
| Ending balance | ​ | ​ | 308 | ​ | 307 | ​ | 308 | ​ | 307 |
| Additional paid-in-capital | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | 300,697 | ​ | 296,277 | ​ | 301,553 | ​ | 297,644 |
| Stock plans | ​ | ​ | 3,487 | ​ | 2,076 | ​ | 2,631 | ​ | 709 |
| Ending balance | ​ | ​ | 304,184 | ​ | 298,353 | ​ | 304,184 | ​ | 298,353 |
| Retained earnings | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | 917,682 | ​ | 840,434 | ​ | 905,022 | ​ | 830,989 |
| Net earnings common stockholders | ​ | ​ | 17,878 | ​ | 16,583 | ​ | 32,605 | ​ | 28,107 |
| Dividends paid | ​ | ​ | (2,061) | ​ | (2,071) | ​ | (4,128) | ​ | (4,150) |
| Ending balance | ​ | ​ | 933,499 | ​ | 854,946 | ​ | 933,499 | ​ | 854,946 |
| Accumulated other comprehensive income (loss) | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | (20,251) | ​ | (4,661) | ​ | (31,764) | ​ | (2,161) |
| Foreign currency translation | ​ | ​ | 2,233 | ​ | (2,811) | ​ | 13,746 | ​ | (5,311) |
| Ending balance | ​ | ​ | (18,018) | ​ | (7,472) | ​ | (18,018) | ​ | (7,472) |
| Treasury stock | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | (132,037) | ​ | (117,080) | ​ | (126,961) | ​ | (107,083) |
| Share repurchases | ​ | ​ | (7,141) | ​ | (7,881) | ​ | (12,217) | ​ | (17,878) |
| Ending balance | ​ | ​ | (139,178) | ​ | (124,961) | ​ | (139,178) | ​ | (124,961) |
| Total equity | ​ | ​ | 1,080,795 | ​ | 1,021,173 | ​ | 1,080,795 | ​ | 1,021,173 |


## us-gaap:FairValueDisclosuresTextBlock

[0001410578-23-000960:notes:45]
11.  FAIR VALUE MEASUREMENTS

[0001410578-23-000960:notes:46]
[same as prior period, unchanged from 0001410578-23-000086:notes:43]

[0001410578-23-000960:notes:47]
[same as prior period, unchanged from 0001410578-23-000086:notes:44]

[0001410578-23-000960:notes:48]
[same as prior period, unchanged from 0001410578-23-000086:notes:45]

[0001410578-23-000960:notes:49]
[same as prior period, unchanged from 0001410578-23-000086:notes:46]

[0001410578-23-000960:notes:50]
[same as prior period, unchanged from 0001410578-23-000086:notes:47]

[0001410578-23-000960:notes:51]
The Company has estimated the fair value of its financial instruments as of March 31, 2023 and September 30, 2022 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001410578-23-000960:notes:52]
[same as prior period, unchanged from 0001410578-23-000086:notes:49]

[0001410578-23-000960:notes:53]
[same as prior period, unchanged from 0001410578-23-000086:notes:50]

[0001410578-23-000960:notes:54]
[same as prior period, unchanged from 0001410578-23-000086:notes:51]

[0001410578-23-000960:notes:55]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during the three and six-month periods ended March 31, 2023.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001410578-23-000960:notes:56]
12.  REVENUES

[0001410578-23-000960:notes:57]
[same as prior period, unchanged from 0001410578-23-000086:notes:54]

[0001410578-23-000960:notes:58]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2023 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue within each reportable segment.

[0001410578-23-000960:notes:59]
| Three months ended March 31, 2023 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 48,228 | ​ | $ | 78,110 | ​ | $ | 43,188 | ​ | $ | 169,526 |
| Government | ​ |  | 50,754 | ​ |  | 1,051 | ​ |  | 7,805 | ​ |  | 59,610 |
| Total revenues | ​ | $ | 98,982 | ​ | $ | 79,161 | ​ | $ | 50,993 | ​ | $ | 229,136 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 82,516 | ​ | $ | 53,020 | ​ | $ | 27,504 | ​ | $ | 163,040 |
| International | ​ |  | 16,466 | ​ |  | 26,141 | ​ |  | 23,489 | ​ |  | 66,096 |
| Total revenues | ​ | $ | 98,982 | ​ | $ | 79,161 | ​ | $ | 50,993 | ​ | $ | 229,136 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 47,255 | ​ | $ | 64,080 | ​ | $ | 11,968 | ​ | $ | 123,303 |
| Over time | ​ |  | 51,727 | ​ |  | 15,081 | ​ |  | 39,025 | ​ |  | 105,833 |
| Total revenues | ​ | $ | 98,982 | ​ | $ | 79,161 | ​ | $ | 50,993 | ​ | $ | 229,136 |

[0001410578-23-000960:notes:60]
| Six months ended March 31, 2023 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial |  | $ | 84,968 | ​ | $ | 148,273 | ​ | $ | 89,180 | ​ | $ | 322,421 |
| Government | ​ | ​ | 96,997 | ​ |  | 1,933 | ​ |  | 13,286 | ​ |  | 112,216 |
| Total revenues |  | $ | 181,965 | ​ | $ | 150,206 | ​ | $ | 102,466 | ​ | $ | 434,637 |
| Geographic location: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States |  | $ | 151,450 | ​ | $ | 99,399 | ​ | $ | 55,007 | ​ | $ | 305,856 |
| International | ​ | ​ | 30,515 | ​ |  | 50,807 | ​ |  | 47,459 | ​ |  | 128,781 |
| Total revenues |  | $ | 181,965 | ​ | $ | 150,206 | ​ | $ | 102,466 | ​ | $ | 434,637 |
| Revenue recognition method: | ​ | ​ | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time |  | $ | 80,859 | ​ | $ | 120,111 | ​ | $ | 21,069 | ​ | $ | 222,039 |
| Over time | ​ | ​ | 101,106 | ​ |  | 30,095 | ​ |  | 81,397 | ​ |  | 212,598 |
| Total revenues |  | $ | 181,965 | ​ | $ | 150,206 | ​ | $ | 102,466 | ​ | $ | 434,637 |

[0001410578-23-000960:notes:61]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2022 are presented in the tables below.

[0001410578-23-000960:notes:62]
| Three months ended March 31, 2022 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 33,562 | ​ | $ | 63,379 | ​ | $ | 51,903 | ​ | $ | 148,844 |
| Government | ​ |  | 51,259 | ​ |  | 812 | ​ |  | 4,013 | ​ |  | 56,084 |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 72,621 | ​ | $ | 41,458 | ​ | $ | 31,071 | ​ | $ | 145,150 |
| International | ​ |  | 12,200 | ​ |  | 22,733 | ​ |  | 24,845 | ​ |  | 59,778 |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 35,666 | ​ | $ | 51,202 | ​ | $ | 14,838 | ​ | $ | 101,706 |
| Over time | ​ |  | 49,155 | ​ |  | 12,989 | ​ |  | 41,078 | ​ |  | 103,222 |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 |

[0001410578-23-000960:notes:63]
| Six months ended March 31, 2022 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 61,489 | ​ | $ | 126,221 | ​ | $ | 92,941 | ​ | $ | 280,651 |
| Government | ​ |  | 93,576 | ​ |  | 1,455 | ​ |  | 6,256 | ​ |  | 101,287 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 133,313 | ​ | $ | 80,199 | ​ | $ | 54,047 | ​ | $ | 267,559 |
| International | ​ |  | 21,752 | ​ |  | 47,477 | ​ |  | 45,150 | ​ |  | 114,379 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 64,223 | ​ | $ | 102,037 | ​ | $ | 27,660 | ​ | $ | 193,920 |
| Over time | ​ |  | 90,842 | ​ |  | 25,639 | ​ |  | 71,537 | ​ |  | 188,018 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |

[0001410578-23-000960:notes:64]
[same as prior period, unchanged from 0001410578-23-000086:notes:59]

[0001410578-23-000960:notes:65]
[same as prior period, unchanged from 0001410578-23-000086:notes:60]

[0001410578-23-000960:notes:66]
For our overtime revenue recognized using the output method of costs incurred, contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to one or more years, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change. In addition, in the USG

[0001410578-23-000960:notes:67]
segment, we recognize revenue as a series of distinct services based on each day of providing services (straight-line over the contract term) for certain of our USG segment contracts. Under the typical payment terms of our service contracts, the customer pays us in advance of when services are performed. In addition, in the Test segment, we use milestones to measure progress for our Test segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts.

[0001410578-23-000960:notes:68]
[same as prior period, unchanged from 0001410578-23-000086:notes:62]

[0001410578-23-000960:notes:69]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At March 31, 2023, the Company had $740.9 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 79% in the next twelve months.

[0001410578-23-000960:notes:70]
[same as prior period, unchanged from 0001410578-23-000086:notes:64]

[0001410578-23-000960:notes:71]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred. At March 31, 2023, contract assets and liabilities totaled $128.2 million and $131.7 million, respectively. During the first six months of 2023, the Company recognized approximately $55 million in revenues that were included in the contract liabilities balance at September 30, 2022. At September 30, 2022, contract assets and liabilities totaled $125.2 million and $137.6 million, respectively.


## ese:OperatingAndFinancingLeasesOfLesseeDisclosureTextBlock

[0001410578-23-000960:notes:72]
13.  LEASES

[0001410578-23-000960:notes:73]
[same as prior period, unchanged from 0001410578-23-000086:notes:67]

[0001410578-23-000960:notes:74]
[same as prior period, unchanged from 0001410578-23-000086:notes:68]

[0001410578-23-000960:notes:75]
In addition to the base rent, real estate leases typically contain provisions for common-area maintenance and other similar services, which are considered non-lease components for accounting purposes. Non-lease components are excluded from our ROU assets and lease liabilities and expensed as incurred.

[0001410578-23-000960:notes:76]
[same as prior period, unchanged from 0001410578-23-000086:notes:70]

[0001410578-23-000960:notes:77]
[same as prior period, unchanged from 0001410578-23-000086:notes:71]

[0001410578-23-000960:notes:78]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended |
| ​ | ​ | March 31, | ​ | March 31, |
| (Dollars in thousands) |  | 2023 |  | 2022 |
| Finance lease cost | ​ | ​ |  | ​ | ​ |  |
| Amortization of right-of-use assets | ​ | $ | 393 | ​ | $ | 393 |
| Interest on lease liabilities | ​ |  | 233 | ​ |  | 245 |
| Operating lease cost | ​ |  | 1,853 | ​ |  | 1,578 |
| Total lease costs | ​ | $ | 2,479 | ​ | $ | 2,216 |

[0001410578-23-000960:notes:79]
| ​ |  | Six Months |  | Six Months |
| ​ | ​ | Ended | ​ | Ended |
| ​ | ​ | March 31, | ​ | March 31, |
| (Dollars in thousands) |  | 2023 |  | 2022 |
| Finance lease cost | ​ | ​ | ​ | ​ | ​ | ​ |
| Amortization of right-of-use assets | ​ | $ | 786 | ​ | $ | 826 |
| Interest on lease liabilities | ​ |  | 469 | ​ |  | 511 |
| Operating lease cost | ​ |  | 3,498 | ​ |  | 3,131 |
| Total lease costs | ​ | $ | 4,753 | ​ | $ | 4,468 |

[0001410578-23-000960:notes:80]
[same as prior period, unchanged from 0001410578-23-000086:notes:73]

[0001410578-23-000960:notes:81]
| ​ |  | Three Months Ended |  | Three Months Ended |
| ​ | ​ | March 31, | ​ | March 31, |
| (Dollars in thousands) | ​ | 2023 | ​ | 2022 |
| Cash paid for amounts included in the measurement of lease liabilities | ​ | ​ | ​ | ​ | ​ | ​ |
| Operating cash flows from operating leases | ​ | $ | 1,779 | ​ | $ | 1,512 |
| Operating cash flows from finance leases | ​ |  | 233 | ​ |  | 245 |
| Financing cash flows from finance leases | ​ |  | 330 | ​ |  | 304 |
| Right-of-use assets obtained in exchange for operating lease liabilities | ​ |  | 618 | ​ |  | 346 |

[0001410578-23-000960:notes:82]
| ​ | ​ | Six Months Ended | ​ | Six Months Ended | ​ |
| ​ | ​ | March 31, | ​ | March 31, | ​ |
| (Dollars in thousands) |  | 2023 |  | 2022 | ​ |
| Cash paid for amounts included in the measurement of lease liabilities | ​ | ​ |  | ​ | ​ |  | ​ |
| Operating cash flows from operating leases | ​ | $ | 3,380 | ​ | $ | 3,008 | ​ |
| Operating cash flows from finance leases | ​ |  | 469 | ​ |  | 511 | ​ |
| Financing cash flows from finance leases | ​ |  | 658 | ​ |  | 665 | ​ |
| Right-of-use assets obtained in exchange for operating lease liabilities | ​ | ​ | 14,582 | ​ | ​ | 1,247 | ​ |
| ​ | ​ | ​ | March 31, 2023 | ​ | ​ | March 31, 2022 | ​ |
| Weighted-average remaining lease term | ​ |  | ​ | ​ |  | ​ | ​ |
| Operating leases | ​ |  | 11.5 | years |  | 9.9 | years |
| Finance leases | ​ |  | 11.5 | years |  | 12.3 | years |
| Weighted-average discount rate | ​ |  | ​ | ​ |  | ​ | ​ |
| Operating leases | ​ |  | 4.40 | % |  | 3.12 | % |
| Finance leases | ​ |  | 4.61 | % |  | 4.58 | % |

[0001410578-23-000960:notes:83]
The following is a reconciliation of future undiscounted cash flows to the operating and finance lease liabilities, and the related ROU assets, presented on our Consolidated Balance Sheet on March 31, 2023:

[0001410578-23-000960:notes:84]
| (Dollars in thousands) | ​ | Operating |  | Finance |
| Years Ending September 30: |  | Leases |  | Leases |
| 2023 (excluding the six months ended March 31, 2023) | ​ | $ | 3,579 |  | 1,130 |
| 2024 | ​ |  | 6,387 |  | 2,315 |
| 2025 | ​ |  | 5,085 |  | 2,370 |
| 2026 | ​ |  | 4,213 |  | 2,434 |
| 2027 and thereafter | ​ |  | 36,773 |  | 18,996 |
| Total minimum lease payments | ​ |  | 56,037 |  | 27,245 |
| Less: amounts representing interest | ​ |  | 12,936 |  | 6,721 |
| Present value of net minimum lease payments | ​ | $ | 43,101 |  | 20,524 |
| Less: current portion of lease obligations | ​ |  | 5,444 |  | 1,387 |
| Non-current portion of lease obligations | ​ | ​ | 37,657 |  | 19,137 |
| ROU assets | ​ | $ | 41,418 |  | 16,557 |

[0001410578-23-000960:notes:85]
Operating lease liabilities are included in the Consolidated Balance Sheet in accrued other expenses (current portion) and as a caption on the Consolidated Balance Sheet (long-term portion). Finance lease liabilities are included on the Consolidated Balance Sheet in accrued other expenses (current portion) and other liabilities (long-term portion). Operating lease ROU assets are included as a caption on the Consolidated Balance Sheet and finance lease ROU assets are included in Property, plant and equipment on the Consolidated Balance sheets.
