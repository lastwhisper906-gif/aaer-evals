# ESE notes — 0001410578-25-000100


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001410578-25-000100:notes:1]
[same as prior period, unchanged from 0001410578-24-001264:notes:1]

[0001410578-25-000100:notes:2]
The accompanying consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP).

[0001410578-25-000100:notes:3]
The Company’s results for the three-month period ended December 31, 2024 are not necessarily indicative of the results for the entire 2025 fiscal year. References to the first quarters of 2025 and 2024 represent the fiscal quarters ended December 31, 2024 and 2023, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:EarningsPerShareTextBlock

[0001410578-25-000100:notes:4]
[same as prior period, unchanged from 0001410578-24-001264:notes:4]

[0001410578-25-000100:notes:5]
Basic EPS is calculated using the weighted average number of common shares outstanding during the period. Diluted EPS is calculated using the weighted average number of common shares outstanding during the period plus shares issuable upon the assumed exercise of dilutive common share options and vesting of performance-based share unit awards and time-vested restricted share unit awards by using the treasury stock method. The number of shares used in the calculation of earnings per share for each period presented is as follows (in thousands):

[0001410578-25-000100:notes:6]
| ​ |  | Three Months |
| ​ | ​ | Ended December 31, |
| ​ |  | 2024 |  | 2023 |
| Weighted Average Shares Outstanding — Basic |  | 25,781 | ​ | 25,797 |
| Dilutive Restricted Shares | ​ | 53 | ​ | 49 |
| Adjusted Shares — Diluted |  | 25,834 | ​ | 25,846 |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001410578-25-000100:notes:7]
3.    SHARE-BASED COMPENSATION

[0001410578-25-000100:notes:8]
The Company provides compensation benefits to certain key employees under several share-based plans providing for a combination of performance-based share unit (PSU) awards and time-vested restricted share unit (RSU) awards, and to non-employee directors under a separate compensation plan. Prior to fiscal 2021, the Company provided certain key employees with performance-accelerated restricted share (PARS) awards, the last of which vested during the first quarter of fiscal 2024.

[0001410578-25-000100:notes:9]
RSU, PSU and PARS Awards

[0001410578-25-000100:notes:10]
Compensation expense related to these awards was $2.2 million and $1.9 million for the three-month periods ended December 31, 2024 and 2023, respectively. There were 209,274 non-vested shares outstanding as of December 31, 2024.

[0001410578-25-000100:notes:11]
[same as prior period, unchanged from 0001410578-24-001264:notes:13]

[0001410578-25-000100:notes:12]
Compensation expense related to the non-employee director grants was $0.3 million and $0.3 million for the three-month periods ended December 31, 2024 and 2023, respectively.

[0001410578-25-000100:notes:13]
The total share-based compensation cost that has been recognized in the results of operations and included within selling, general and administrative expenses (SG&A) was $2.5 million and $2.2 million for the three-month periods ended December 31, 2024 and 2023, respectively. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $0.8 million and $0.2 million for the three-month periods ended December 31, 2024 and 2023, respectively. As of December 31, 2024 there was $17.7 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a remaining weighted-average period of 2.0 years.


## us-gaap:InventoryDisclosureTextBlock

[0001410578-25-000100:notes:14]
4.    INVENTORIES

[0001410578-25-000100:notes:15]
[same as prior period, unchanged from 0001410578-24-001264:notes:17]

[0001410578-25-000100:notes:16]
| ​ | ​ | December 31, | ​ | September 30, |
| (In thousands) |  | 2024 |  | 2024 |
| Finished goods | ​ | $ | 53,839 | ​ | 46,586 |
| Work in process | ​ | ​ | 47,836 | ​ | 47,903 |
| Raw materials | ​ | ​ | 117,708 | ​ | 114,675 |
| Total inventories | ​ | $ | 219,383 | ​ | 209,164 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001410578-25-000100:notes:17]
| 5. | GOODWILL AND OTHER INTANGIBLE ASSETS |

[0001410578-25-000100:notes:18]
Included on the Company’s Consolidated Balance Sheets at December 31, 2024 and September 30, 2024 are the following intangible assets gross carrying amounts and accumulated amortization from continuing operations:

[0001410578-25-000100:notes:19]
| ​ |  | December 31, |  | September 30, |
| (Dollars in thousands) |  | 2024 |  | 2024 |
| Goodwill | ​ | $ | 532,312 | ​ | 539,899 |
| Intangible assets with determinable lives: | ​ |  | ​ | ​ | ​ |
| Patents | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 2,635 | ​ | 2,638 |
| Less: accumulated amortization | ​ |  | 1,467 | ​ | 1,415 |
| Net | ​ | $ | 1,168 | ​ | 1,223 |
| Capitalized software | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 136,634 | ​ | 134,119 |
| Less: accumulated amortization | ​ |  | 95,844 | ​ | 92,878 |
| Net | ​ | $ | 40,790 | ​ | 41,241 |
| Customer relationships | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 326,027 | ​ | 330,328 |
| Less: accumulated amortization | ​ |  | 136,922 | ​ | 132,135 |
| Net | ​ | $ | 189,105 | ​ | 198,193 |
| Other | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 14,917 | ​ | 15,182 |
| Less: accumulated amortization | ​ |  | 11,361 | ​ | 11,173 |
| Net | ​ | $ | 3,556 | ​ | 4,009 |
| Intangible assets with indefinite lives: | ​ |  | ​ | ​ | ​ |
| Trade names | ​ | $ | 161,683 | ​ | 162,936 |

[0001410578-25-000100:notes:20]
The changes in the carrying amount of goodwill attributable to each business segment for the three months ended December 31, 2024 are as follows:

[0001410578-25-000100:notes:21]
| (Dollars in millions) |  | USG |  | Test |  | A&D |  | Total |
| Balance as of September 30, 2024 | ​ | $ | 356.9 |  | ​ | 67.4 |  | 115.6 |  | 539.9 |
| Foreign currency translation | ​ | ​ | (5.5) | ​ | ​ | (2.1) | ​ | — | ​ | (7.6) |
| Balance as of December 31, 2024 | ​ | $ | 351.4 | ​ | ​ | 65.3 | ​ | 115.6 | ​ | 532.3 |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001410578-25-000100:notes:22]
6.    BUSINESS SEGMENT INFORMATION

[0001410578-25-000100:notes:23]
The Company is organized based on the products and services that it offers and classifies its business operations in three reportable segments for financial reporting purposes: Aerospace & Defense (A&D), Utility Solutions Group (USG) and RF Test & Measurement (Test). The A&D segment’s operations consist of PTI Technologies Inc. (PTI), VACCO Industries (VACCO), Crissair, Inc. (Crissair), Globe Composite Solutions, LLC (Globe) and Mayday Manufacturing Co. (Mayday). The companies

[0001410578-25-000100:notes:24]
within this segment primarily design and manufacture specialty filtration, fluid control and naval products, including hydraulic filter elements and fluid control devices used in aerospace and defense applications; unique filter mechanisms used in micro-propulsion devices for satellites, custom designed filters for manned aircraft and submarines, products and systems to reduce vibration and/or acoustic signatures and otherwise reduce or obscure a vessel’s signature, and other communications, sealing, surface control and hydrodynamic related applications to enhance U.S. Navy maritime survivability; precision-tolerance machined components for the aerospace and defense industry; metal processing services; and miniature electro-explosive devices utilized in mission-critical defense and aerospace applications.

[0001410578-25-000100:notes:25]
The USG segment’s operations consist primarily of Doble Engineering Company and related subsidiaries including Morgan Schaffer and Altanova (collectively, Doble), and NRG Systems, Inc. (NRG). Doble is an industry leader in the development, manufacture and delivery of diagnostic testing and data management solutions that enable electric power grid operators to assess the integrity of high voltage power delivery equipment. It combines three core elements for customers – diagnostic test and condition monitoring instruments, expert consulting, and testing services – and provides access to its large reserve of related empirical knowledge. NRG is a global market leader in the design and manufacture of decision support tools for the renewable energy industry, primarily wind and solar.

[0001410578-25-000100:notes:26]
[same as prior period, unchanged from 0001410578-24-001264:notes:29]

[0001410578-25-000100:notes:27]
[same as prior period, unchanged from 0001410578-24-001264:notes:30]

[0001410578-25-000100:notes:28]
| ​ | ​ | Three Months |
| ​ | ​ | Ended December 31, |
| (In thousands) |  | 2024 |  | 2023 |
| NET SALES | ​ | ​ | ​ | ​ | ​ |
| A&D | ​ | $ | 114,301 | ​ | 94,733 |
| USG | ​ | ​ | 86,660 | ​ | 82,984 |
| Test | ​ | ​ | 46,065 | ​ | 40,597 |
| Consolidated totals | ​ | $ | 247,026 | ​ | 218,314 |
| EBIT | ​ | ​ | ​ | ​ | ​ |
| A&D | ​ | $ | 21,596 | ​ | 16,663 |
| USG | ​ | ​ | 20,489 | ​ | 17,625 |
| Test | ​ | ​ | 4,422 | ​ | 1,779 |
| Corporate (loss) | ​ | ​ | (14,309) | ​ | (13,946) |
| Consolidated EBIT | ​ | ​ | 32,198 | ​ | 22,121 |
| Less: Interest expense | ​ | ​ | (2,257) | ​ | (2,667) |
| Earnings before income taxes | ​ | $ | 29,941 | ​ | 19,454 |

[0001410578-25-000100:notes:29]
[same as prior period, unchanged from 0001410578-24-001264:notes:32]

[0001410578-25-000100:notes:30]
[same as prior period, unchanged from 0001410578-24-001264:notes:33]

[0001410578-25-000100:notes:31]
The Company believes that the presentation of EBIT provides important supplemental information to investors to facilitate comparisons with other companies, many of which use similar non-GAAP financial measures to supplement their GAAP results. However, the Company’s non-GAAP financial measures may not be comparable to other companies’ non-GAAP financial

[0001410578-25-000100:notes:32]
performance measures. Furthermore, the use of non-GAAP financial measures is not intended to replace any measures of performance determined in accordance with GAAP.


## us-gaap:DebtDisclosureTextBlock

[0001410578-25-000100:notes:33]
7.    DEBT

[0001410578-25-000100:notes:34]
The Company’s debt is summarized as follows:

[0001410578-25-000100:notes:35]
| ​ |  | December 31, | ​ | September 30, |
| (In thousands) |  | 2024 |  | 2024 |
| Total borrowings | ​ | $ | 112,000 | ​ | 122,000 |
| Current portion of long-term debt | ​ | ​ | (20,000) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 92,000 | ​ | 102,000 |

[0001410578-25-000100:notes:36]
The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of seven banks led by JP Morgan Chase Bank, N.A., as administrative agent, Bank of America, N.A., as syndication agent, and Commerce Bank and TD Bank, N.A. as co-documentation agents. The Credit Facility matures August 30, 2028, with balance due by this date.

[0001410578-25-000100:notes:37]
On August 5, 2024, the Company and certain of its subsidiaries entered into Amendment No. 1 (the “Amendment”) to the Credit Facility which, among other things, (i) implements a senior incremental delayed draw term loan credit facility in an aggregate principal amount of up to $375 million (the “Incremental Facility”), and (ii) permits the direct or indirect acquisition by the Registrant or certain of its subsidiaries of all the issued and outstanding shares of Ultra PMES Limited, Measurement Systems, Inc., EMS Development Corporation, and DNE Technologies, Inc. (the “SM&P Acquisition”), pursuant to and in accordance with the terms and conditions of that certain Sale and Purchase Agreement, dated July 8, 2024, among Ultra Electronics Holdings Limited, as parent seller, the Registrant, as guarantor, and certain of the Registrant’s subsidiaries as buyers. The proceeds of the loans drawn under the Incremental Facility will be applied to pay a portion of the cash consideration for the SM&P Acquisition and other customary fees, premiums, expenses and costs incurred in connection with the SM&P Acquisition.

[0001410578-25-000100:notes:38]
At December 31, 2024, the Company had approximately $383 million available to borrow under the Credit Facility, excluding the Incremental Facility, plus the $250 million increase option subject to the lenders’ consent, in addition to $71.3 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of December 31, 2024, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $4.8 million at December 31, 2024.

[0001410578-25-000100:notes:39]
Interest on borrowings under the Credit Facility is calculated at a spread over either an Adjusted Term SOFR Rate, Adjusted EURIBOR Rate, Adjusted CDOR Rate, Alternate Base Rate or Daily Simple RFR, at the Company’s election. The Credit Facility also requires a facility fee ranging from 12.5 to 25 basis points per annum on the unused portion. The interest rate spreads and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio. The weighted average interest rates were 6.1% and 6.8% for the three-month periods ending December 31, 2024 and 2023, respectively. As of December 31, 2024, the Company was in compliance with all covenants.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001410578-25-000100:notes:40]
8.    INCOME TAX EXPENSE

[0001410578-25-000100:notes:41]
The first quarter 2025 effective income tax rate was 21.6% compared to 22.0% in the first quarter of 2024. Income tax expense in the first quarter of 2025 was favorably impacted by additional tax benefits related to the vesting of share-based compensation awards.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001410578-25-000100:notes:42]
9.    SHAREHOLDERS’ EQUITY

[0001410578-25-000100:notes:43]
The change in shareholders’ equity for the first three months ended December 31, 2024 and 2023 is shown below (in thousands):

[0001410578-25-000100:notes:44]
| ​ | ​ | Three Months Ended December 31, |
| ​ |  | 2024 |  | 2023 |
| Common stock | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | $ | 308 | ​ | 308 |
| Stock plans | ​ | ​ | 1 | ​ | — |
| Ending balance | ​ | ​ | 309 | ​ | 308 |
| Additional paid-in-capital | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | 311,942 | ​ | 304,850 |
| Stock plans | ​ | ​ | (3,799) | ​ | 433 |
| Ending balance | ​ | ​ | 308,143 | ​ | 305,283 |
| Retained earnings | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | 1,082,950 | ​ | 989,315 |
| Net earnings common stockholders | ​ | ​ | 23,473 | ​ | 15,169 |
| Dividends paid | ​ | ​ | (2,064) | ​ | (2,064) |
| Ending balance | ​ | ​ | 1,104,359 | ​ | 1,002,420 |
| Accumulated other comprehensive income (loss) | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | (10,775) | ​ | (23,969) |
| Foreign currency translation | ​ | ​ | (18,028) | ​ | 9,414 |
| Ending balance | ​ | ​ | (28,803) | ​ | (14,555) |
| Treasury stock | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | (147,075) | ​ | (139,362) |
| Share repurchases | ​ | ​ | — | ​ | — |
| Ending balance | ​ | ​ | (147,075) | ​ | (139,362) |
| Total equity | ​ | $ | 1,236,933 | ​ | 1,154,094 |


## us-gaap:FairValueDisclosuresTextBlock

[0001410578-25-000100:notes:45]
10.  FAIR VALUE MEASUREMENTS

[0001410578-25-000100:notes:46]
[same as prior period, unchanged from 0001410578-24-001264:notes:47]

[0001410578-25-000100:notes:47]
[same as prior period, unchanged from 0001410578-24-001264:notes:48]

[0001410578-25-000100:notes:48]
[same as prior period, unchanged from 0001410578-24-001264:notes:49]

[0001410578-25-000100:notes:49]
[same as prior period, unchanged from 0001410578-24-001264:notes:50]

[0001410578-25-000100:notes:50]
[same as prior period, unchanged from 0001410578-24-001264:notes:51]

[0001410578-25-000100:notes:51]
The Company has estimated the fair value of its financial instruments as of December 31, 2024 and September 30, 2024 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001410578-25-000100:notes:52]
[same as prior period, unchanged from 0001410578-24-001264:notes:53]

[0001410578-25-000100:notes:53]
[same as prior period, unchanged from 0001410578-24-001264:notes:54]

[0001410578-25-000100:notes:54]
[same as prior period, unchanged from 0001410578-24-001264:notes:55]

[0001410578-25-000100:notes:55]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however, they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during the three-month period ended December 31, 2024.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001410578-25-000100:notes:56]
11.  REVENUES

[0001410578-25-000100:notes:57]
[same as prior period, unchanged from 0001410578-24-001264:notes:58]

[0001410578-25-000100:notes:58]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2024 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within each reportable segment.

[0001410578-25-000100:notes:59]
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 47,500 | ​ | $ | 84,279 | ​ | $ | 36,349 | ​ | $ | 168,128 |
| Government | ​ | ​ | 66,801 | ​ | ​ | 2,381 | ​ | ​ | 9,716 | ​ | ​ | 78,898 |
| Total revenues | ​ | $ | 114,301 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 247,026 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 96,703 | ​ | $ | 59,917 | ​ | $ | 28,630 | ​ | $ | 185,250 |
| International | ​ | ​ | 17,598 | ​ | ​ | 26,743 | ​ | ​ | 17,435 | ​ | ​ | 61,776 |
| Total revenues | ​ | $ | 114,301 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 247,026 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 50,126 | ​ | $ | 69,278 | ​ | $ | 9,791 | ​ | $ | 129,195 |
| Over time | ​ | ​ | 64,175 | ​ | ​ | 17,382 | ​ | ​ | 36,274 | ​ | ​ | 117,831 |
| Total revenues | ​ | $ | 114,301 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 247,026 |

[0001410578-25-000100:notes:60]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2023 are presented in the table below:

[0001410578-25-000100:notes:61]
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 37,209 | ​ | $ | 81,469 | ​ | $ | 35,087 | ​ | $ | 153,765 |
| Government | ​ | ​ | 57,524 | ​ | ​ | 1,515 | ​ | ​ | 5,510 | ​ | ​ | 64,549 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 79,901 | ​ | $ | 55,961 | ​ | $ | 22,252 | ​ | $ | 158,114 |
| International | ​ | ​ | 14,832 | ​ | ​ | 27,023 | ​ | ​ | 18,345 | ​ | ​ | 60,200 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 39,465 | ​ | $ | 66,703 | ​ | $ | 7,980 | ​ | $ | 114,148 |
| Over time | ​ | ​ | 55,268 | ​ | ​ | 16,281 | ​ | ​ | 32,617 | ​ | ​ | 104,166 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |

[0001410578-25-000100:notes:62]
[same as prior period, unchanged from 0001410578-24-001264:notes:65]

[0001410578-25-000100:notes:63]
[same as prior period, unchanged from 0001410578-24-001264:notes:66]

[0001410578-25-000100:notes:64]
[same as prior period, unchanged from 0001410578-24-001264:notes:67]

[0001410578-25-000100:notes:65]
[same as prior period, unchanged from 0001410578-24-001264:notes:68]

[0001410578-25-000100:notes:66]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to performance obligations that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At December 31, 2024, the Company had $906.9 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 72% in the next twelve months.

[0001410578-25-000100:notes:67]
[same as prior period, unchanged from 0001410578-24-001264:notes:70]

[0001410578-25-000100:notes:68]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At December 31, 2024, contract assets, contract liabilities and accounts receivable totaled $131.4 million, $138.4 million and $202.7 million, respectively. During the first quarter of 2025, the Company recognized approximately $35.1 million in revenues that were included in the contract liabilities balance at September 30, 2024. At September 30, 2024, contract assets, contract liabilities and accounts receivable totaled $130.5 million, $134.3 million and $240.7 million, respectively.


## ese:OperatingAndFinancingLeasesOfLesseeDisclosureTextBlock

[0001410578-25-000100:notes:69]
12.  LEASES

[0001410578-25-000100:notes:70]
[same as prior period, unchanged from 0001410578-24-001264:notes:73]

[0001410578-25-000100:notes:71]
[same as prior period, unchanged from 0001410578-24-001264:notes:74]

[0001410578-25-000100:notes:72]
In addition to the base rent, real estate leases typically contain provisions for common-area maintenance and other similar services, which are considered non-lease components for accounting purposes. Non-lease components are excluded from ROU assets and lease liabilities and expensed as incurred.

[0001410578-25-000100:notes:73]
[same as prior period, unchanged from 0001410578-24-001264:notes:76]

[0001410578-25-000100:notes:74]
[same as prior period, unchanged from 0001410578-24-001264:notes:77]

[0001410578-25-000100:notes:75]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended |
| ​ | ​ | December 31, | ​ | December 31, |
| (Dollars in thousands) |  | 2024 |  | 2023 |
| Finance lease cost | ​ | ​ | ​ | ​ | ​ | ​ |
| Amortization of right-of-use assets | ​ | $ | 372 | ​ | ​ | 393 |
| Interest on lease liabilities | ​ | ​ | 206 | ​ | ​ | 223 |
| Operating lease cost | ​ | ​ | 1,983 | ​ | ​ | 1,864 |
| Total lease costs | ​ | $ | 2,561 | ​ | ​ | 2,480 |

[0001410578-25-000100:notes:76]
[same as prior period, unchanged from 0001410578-24-001264:notes:80]

[0001410578-25-000100:notes:77]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended |
| ​ | ​ | December 31, | ​ | December 31, |
| (Dollars in thousands) |  | 2024 |  | 2023 |
| Cash paid for amounts included in the measurement of lease liabilities | ​ | ​ | ​ | ​ | ​ | ​ |
| Operating cash flows from operating leases | ​ | $ | 1,914 | ​ | ​ | 1,819 |
| Operating cash flows from finance leases | ​ | ​ | 206 | ​ | ​ | 223 |
| Financing cash flows from finance leases | ​ | ​ | 351 | ​ | ​ | 355 |
| Right-of-use assets obtained in exchange for lease liabilities | ​ | ​ | ​ | ​ | ​ | ​ |
| Operating leases | ​ | $ | 1,776 | ​ | ​ | — |

[0001410578-25-000100:notes:78]
| ​ |  | Three Months Ended | ​ | Three Months Ended | ​ |
| ​ | ​ | December 31, |  | December 31, | ​ |
| ​ | ​ | 2024 | ​ | 2023 | ​ |
| Weighted-average remaining lease term | ​ |  | ​ |  | ​ |
| Operating leases |  | 8.5 | years | 11.1 | years |
| Finance leases |  | 10.2 | years | 11.1 | years |
| Weighted-average discount rate |  | ​ |  | ​ |  |
| Operating leases |  | 4.4 | % | 4.5 | % |
| Finance leases |  | 4.7 | % | 4.7 | % |

[0001410578-25-000100:notes:79]
The following is a reconciliation of future undiscounted cash flows to the operating and finance lease liabilities, and the related ROU assets, presented on the Consolidated Balance Sheet on December 31, 2024:

[0001410578-25-000100:notes:80]
| (Dollars in thousands) | ​ | Operating |  | Finance |
| Years Ending September 30: |  | Leases |  | Leases |
| 2025 (excluding the three months ended December 31, 2024) | ​ | $ | 4,807 | ​ | 1,676 |
| 2026 | ​ | ​ | 5,241 | ​ | 2,297 |
| 2027 | ​ | ​ | 4,965 | ​ | 2,357 |
| 2028 | ​ | ​ | 4,883 | ​ | 2,417 |
| 2029 and thereafter | ​ | ​ | 32,623 | ​ | 14,052 |
| Total minimum lease payments | ​ | ​ | 52,519 | ​ | 22,799 |
| Less: amounts representing interest | ​ | ​ | 11,637 | ​ | 5,167 |
| Present value of net minimum lease payments | ​ | $ | 40,882 | ​ | 17,632 |
| Less: current portion of lease obligations | ​ | ​ | 4,482 | ​ | 1,461 |
| Non-current portion of lease obligations | ​ | $ | 36,400 | ​ | 16,171 |
| ROU assets | ​ | $ | 38,710 | ​ | 13,311 |

[0001410578-25-000100:notes:81]
Operating lease liabilities are included on the Consolidated Balance Sheet in accrued other expenses (current portion) and as a caption on the Consolidated Balance Sheet (long-term portion). Finance lease liabilities are included on the Consolidated Balance Sheet in accrued other expenses (current portion) and other liabilities (long-term portion). Operating lease ROU assets are included as a caption on the Consolidated Balance Sheet and finance lease ROU assets are included in Property, plant and equipment on the Consolidated Balance sheet.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001410578-25-000100:notes:82]
13.  RECENT ACCOUNTING PRONOUNCEMENTS

[0001410578-25-000100:notes:83]
In November 2024, the FASB issued ASU 2024-03, “Disaggregation of Income Statement Expenses,” which requires disaggregated disclosure of income statement expenses for public business entities. The ASU does not change the expense captions an entity presents on the face of the income statement; rather, it requires disaggregation of certain expense captions into specified categories in disclosures within the footnotes to the financial statements. This ASU will be effective for fiscal years beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027. Other than additional disclosure, we do not expect a change to our consolidated statements of operations, financial position, or cash flows.

[0001410578-25-000100:notes:84]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures,” which provides qualitative and quantitative updates to the rate reconciliation and income taxes paid disclosures. This ASU will be effective for fiscal years beginning after December 15, 2024. Other than additional disclosure, we do not expect a change to our consolidated statements of operations, financial position, or cash flows.

[0001410578-25-000100:notes:85]
In November 2023, the FASB issued ASU 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures,” which expands annual and interim disclosure requirements for reportable segments, primarily through enhanced disclosures about significant expenses. The new segment disclosures are effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024. Other than additional disclosure, we do not expect a change to our consolidated statements of operations, financial position, or cash flows.
