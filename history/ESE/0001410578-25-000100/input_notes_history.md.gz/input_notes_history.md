# ESE note change history — 0001410578-24-001264 → 0001410578-25-000100


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-02-10):
[0001410578-25-000100:note_history:1]
The accompanying consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP).
  (was, 2024-08-09, similarity 0.7867):
[0001410578-24-001264:note_history:1]
The accompanying unaudited condensed consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The unaudited condensed consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP) and should be read in conjunction with the audited consolidated financial statements and notes thereto contained in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2023, as filed with the SEC on November 29, 2023.

- changed (2025-02-10):
[0001410578-25-000100:note_history:2]
The Company’s results for the three-month period ended December 31, 2024 are not necessarily indicative of the results for the entire 2025 fiscal year. References to the first quarters of 2025 and 2024 represent the fiscal quarters ended December 31, 2024 and 2023, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.
  (was, 2024-08-09, similarity 0.8744):
[0001410578-24-001264:note_history:2]
The Company’s results for the three-month period ended June 30, 2024 are not necessarily indicative of the results for the entire 2024 fiscal year. References to the third quarters of 2024 and 2023 represent the fiscal quarters ended June 30, 2024 and 2023, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates. Certain prior period amounts have been reclassified to conform to the current period presentation.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-02-10):
[0001410578-25-000100:note_history:3]
| ​ |  | December 31, | ​ | September 30, |
| (In thousands) |  | 2024 |  | 2024 |
| Total borrowings | ​ | $ | 112,000 | ​ | 122,000 |
| Current portion of long-term debt | ​ | ​ | (20,000) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 92,000 | ​ | 102,000 |
  (was, 2024-08-09, similarity 0.9747):
[0001410578-24-001264:note_history:3]
| ​ |  | June 30, | ​ | September 30, |
| (In thousands) |  | 2024 |  | 2023 |
| Total borrowings | ​ | $ | 173,000 | ​ | 102,000 |
| Current portion of long-term debt | ​ | ​ | (20,000) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 153,000 | ​ | 82,000 |

- added (2025-02-10):
[0001410578-25-000100:note_history:4]
On August 5, 2024, the Company and certain of its subsidiaries entered into Amendment No. 1 (the “Amendment”) to the Credit Facility which, among other things, (i) implements a senior incremental delayed draw term loan credit facility in an aggregate principal amount of up to $375 million (the “Incremental Facility”), and (ii) permits the direct or indirect acquisition by the Registrant or certain of its subsidiaries of all the issued and outstanding shares of Ultra PMES Limited, Measurement Systems, Inc., EMS Development Corporation, and DNE Technologies, Inc. (the “SM&P Acquisition”), pursuant to and in accordance with the terms and conditions of that certain Sale and Purchase Agreement, dated July 8, 2024, among Ultra Electronics Holdings Limited, as parent seller, the Registrant, as guarantor, and certain of the Registrant’s subsidiaries as buyers. The proceeds of the loans drawn under the Incremental Facility will be applied to pay a portion of the cash consideration for the SM&P Acquisition and other customary fees, premiums, expenses and costs incurred in connection with the SM&P Acquisition.

- added (2025-02-10):
[0001410578-25-000100:note_history:5]
At December 31, 2024, the Company had approximately $383 million available to borrow under the Credit Facility, excluding the Incremental Facility, plus the $250 million increase option subject to the lenders’ consent, in addition to $71.3 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of December 31, 2024, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $4.8 million at December 31, 2024.

- changed (2025-02-10):
[0001410578-25-000100:note_history:6]
Interest on borrowings under the Credit Facility is calculated at a spread over either an Adjusted Term SOFR Rate, Adjusted EURIBOR Rate, Adjusted CDOR Rate, Alternate Base Rate or Daily Simple RFR, at the Company’s election. The Credit Facility also requires a facility fee ranging from 12.5 to 25 basis points per annum on the unused portion. The interest rate spreads and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio. The weighted average interest rates were 6.1% and 6.8% for the three-month periods ending December 31, 2024 and 2023, respectively. As of December 31, 2024, the Company was in compliance with all covenants.
  (was, 2024-08-09, similarity 0.8307):
[0001410578-24-001264:note_history:6]
Interest on borrowings under the Credit Facility is calculated at a spread over either an Adjusted Term SOFR Rate, Adjusted EURIBOR Rate, Adjusted CDOR Rate, Alternate Base Rate or Daily Simple RFR, at the Company’s election. The Credit Facility also requires a facility fee ranging from 12.5 to 25 basis points per annum on the unused portion. The interest rate spreads and the facility fee are subject to increase or decrease depending on the Company’s leverage ratio. The weighted average interest rates were 6.7% and 6.8% for the three and nine-month periods ending June 30, 2024, respectively, and 6.05% and 5.57% for the three and nine-month periods ending June 30, 2023. As of June 30, 2024, the Company was in compliance with all covenants.

- removed (2025-02-10):
[0001410578-24-001264:note_history:7]
At June 30, 2024, the Company had approximately $321 million available to borrow under the Credit Facility, plus the $250 million increase option subject to the lenders’ consent, in addition to $63.0 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of June 30, 2024, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $5.5 million at June 30, 2024.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-02-10):
[0001410578-25-000100:note_history:8]
| ​ |  | December 31, | ​ | September 30, |
| (In thousands) |  | 2024 |  | 2024 |
| Total borrowings | ​ | $ | 112,000 | ​ | 122,000 |
| Current portion of long-term debt | ​ | ​ | (20,000) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 92,000 | ​ | 102,000 |
  (was, 2024-08-09, similarity 0.9747):
[0001410578-24-001264:note_history:8]
| ​ |  | June 30, | ​ | September 30, |
| (In thousands) |  | 2024 |  | 2023 |
| Total borrowings | ​ | $ | 173,000 | ​ | 102,000 |
| Current portion of long-term debt | ​ | ​ | (20,000) | ​ | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 153,000 | ​ | 82,000 |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-02-10):
[0001410578-25-000100:note_history:9]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2024 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within each reportable segment.

- changed (2025-02-10):
[0001410578-25-000100:note_history:10]
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 47,500 | ​ | $ | 84,279 | ​ | $ | 36,349 | ​ | $ | 168,128 |
| Government | ​ | ​ | 66,801 | ​ | ​ | 2,381 | ​ | ​ | 9,716 | ​ | ​ | 78,898 |
| Total revenues | ​ | $ | 114,301 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 247,026 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 96,703 | ​ | $ | 59,917 | ​ | $ | 28,630 | ​ | $ | 185,250 |
| International | ​ | ​ | 17,598 | ​ | ​ | 26,743 | ​ | ​ | 17,435 | ​ | ​ | 61,776 |
| Total revenues | ​ | $ | 114,301 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 247,026 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 50,126 | ​ | $ | 69,278 | ​ | $ | 9,791 | ​ | $ | 129,195 |
| Over time | ​ | ​ | 64,175 | ​ | ​ | 17,382 | ​ | ​ | 36,274 | ​ | ​ | 117,831 |
| Total revenues | ​ | $ | 114,301 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 247,026 |
  (was, 2024-08-09, similarity 0.9483):
[0001410578-24-001264:note_history:10]
| Three months ended June 30, 2024 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 45,404 | ​ | $ | 88,076 | ​ | $ | 42,327 | ​ | $ | 175,807 |
| Government | ​ | ​ | 69,046 | ​ | ​ | 2,201 | ​ | ​ | 13,729 | ​ | ​ | 84,976 |
| Total revenues | ​ | $ | 114,450 | ​ | $ | 90,277 | ​ | $ | 56,056 | ​ | $ | 260,783 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 95,265 | ​ | $ | 54,063 | ​ | $ | 32,575 | ​ | $ | 181,903 |
| International | ​ | ​ | 19,185 | ​ | ​ | 36,214 | ​ | ​ | 23,481 | ​ | ​ | 78,880 |
| Total revenues | ​ | $ | 114,450 | ​ | $ | 90,277 | ​ | $ | 56,056 | ​ | $ | 260,783 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 53,148 | ​ | $ | 72,985 | ​ | $ | 11,426 | ​ | $ | 137,559 |
| Over time | ​ | ​ | 61,302 | ​ | ​ | 17,292 | ​ | ​ | 44,630 | ​ | ​ | 123,224 |
| Total revenues | ​ | $ | 114,450 | ​ | $ | 90,277 | ​ | $ | 56,056 | ​ | $ | 260,783 |

- added (2025-02-10):
[0001410578-25-000100:note_history:11]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2023 are presented in the table below:

- changed (2025-02-10):
[0001410578-25-000100:note_history:12]
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 37,209 | ​ | $ | 81,469 | ​ | $ | 35,087 | ​ | $ | 153,765 |
| Government | ​ | ​ | 57,524 | ​ | ​ | 1,515 | ​ | ​ | 5,510 | ​ | ​ | 64,549 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 79,901 | ​ | $ | 55,961 | ​ | $ | 22,252 | ​ | $ | 158,114 |
| International | ​ | ​ | 14,832 | ​ | ​ | 27,023 | ​ | ​ | 18,345 | ​ | ​ | 60,200 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 39,465 | ​ | $ | 66,703 | ​ | $ | 7,980 | ​ | $ | 114,148 |
| Over time | ​ | ​ | 55,268 | ​ | ​ | 16,281 | ​ | ​ | 32,617 | ​ | ​ | 104,166 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |
  (was, 2024-08-09, similarity 0.9523):
[0001410578-24-001264:note_history:12]
| Three months ended June 30, 2023 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 45,574 | ​ | $ | 88,442 | ​ | $ | 48,407 | ​ | $ | 182,423 |
| Government | ​ | ​ | 57,895 | ​ | ​ | 1,524 | ​ | ​ | 6,907 | ​ | ​ | 66,326 |
| Total revenues | ​ | $ | 103,469 | ​ | $ | 89,966 | ​ | $ | 55,314 | ​ | $ | 248,749 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 86,031 | ​ | $ | 55,011 | ​ | $ | 32,246 | ​ | $ | 173,288 |
| International | ​ | ​ | 17,438 | ​ | ​ | 34,955 | ​ | ​ | 23,068 | ​ | ​ | 75,461 |
| Total revenues | ​ | $ | 103,469 | ​ | $ | 89,966 | ​ | $ | 55,314 | ​ | $ | 248,749 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 48,496 | ​ | $ | 74,128 | ​ | $ | 11,496 | ​ | $ | 134,120 |
| Over time | ​ | ​ | 54,973 | ​ | ​ | 15,838 | ​ | ​ | 43,818 | ​ | ​ | 114,629 |
| Total revenues | ​ | $ | 103,469 | ​ | $ | 89,966 | ​ | $ | 55,314 | ​ | $ | 248,749 |

- removed (2025-02-10):
[0001410578-24-001264:note_history:13]
| Nine months ended June 30, 2024 |  | Aerospace |  |  | ​ |  |  | ​ |  |  | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 131,993 | ​ | $ | 254,765 | ​ | $ | 111,951 | ​ | $ | 498,709 |
| Government | ​ |  | 191,891 | ​ |  | 5,805 | ​ |  | 31,821 | ​ |  | 229,517 |
| Total revenues | ​ | $ | 323,884 | ​ | $ | 260,570 | ​ | $ | 143,772 | ​ | $ | 728,226 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 267,325 | ​ | $ | 165,789 | ​ | $ | 82,370 | ​ | $ | 515,484 |
| International | ​ |  | 56,559 | ​ |  | 94,781 | ​ |  | 61,402 | ​ |  | 212,742 |
| Total revenues | ​ | $ | 323,884 | ​ | $ | 260,570 | ​ | $ | 143,772 | ​ | $ | 728,226 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 146,076 | ​ | $ | 209,973 | ​ | $ | 29,706 | ​ | $ | 385,755 |
| Over time | ​ |  | 177,808 | ​ |  | 50,597 | ​ |  | 114,066 | ​ |  | 342,471 |
| Total revenues | ​ | $ | 323,884 | ​ | $ | 260,570 | ​ | $ | 143,772 | ​ | $ | 728,226 |

- removed (2025-02-10):
[0001410578-24-001264:note_history:14]
| Nine months ended June 30, 2023 |  | Aerospace |  |  | ​ |  |  | ​ |  |  | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 128,016 | ​ | $ | 236,715 | ​ | $ | 137,587 | ​ | $ | 502,318 |
| Government | ​ |  | 157,418 | ​ |  | 3,457 | ​ |  | 20,193 | ​ |  | 181,068 |
| Total revenues | ​ | $ | 285,434 | ​ | $ | 240,172 | ​ | $ | 157,780 | ​ | $ | 683,386 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 237,481 | ​ | $ | 154,410 | ​ | $ | 87,253 | ​ | $ | 479,144 |
| International | ​ |  | 47,953 | ​ |  | 85,762 | ​ |  | 70,527 | ​ |  | 204,242 |
| Total revenues | ​ | $ | 285,434 | ​ | $ | 240,172 | ​ | $ | 157,780 | ​ | $ | 683,386 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 129,355 | ​ | $ | 194,240 | ​ | $ | 32,565 | ​ | $ | 356,160 |
| Over time | ​ |  | 156,079 | ​ |  | 45,932 | ​ |  | 125,215 | ​ |  | 327,226 |
| Total revenues | ​ | $ | 285,434 | ​ | $ | 240,172 | ​ | $ | 157,780 | ​ | $ | 683,386 |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-02-10):
[0001410578-25-000100:note_history:15]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2024 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within each reportable segment.
  (was, 2024-08-09, similarity 0.953):
[0001410578-24-001264:note_history:15]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2024 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue within each reportable segment.

- changed (2025-02-10):
[0001410578-25-000100:note_history:16]
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 47,500 | ​ | $ | 84,279 | ​ | $ | 36,349 | ​ | $ | 168,128 |
| Government | ​ | ​ | 66,801 | ​ | ​ | 2,381 | ​ | ​ | 9,716 | ​ | ​ | 78,898 |
| Total revenues | ​ | $ | 114,301 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 247,026 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 96,703 | ​ | $ | 59,917 | ​ | $ | 28,630 | ​ | $ | 185,250 |
| International | ​ | ​ | 17,598 | ​ | ​ | 26,743 | ​ | ​ | 17,435 | ​ | ​ | 61,776 |
| Total revenues | ​ | $ | 114,301 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 247,026 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 50,126 | ​ | $ | 69,278 | ​ | $ | 9,791 | ​ | $ | 129,195 |
| Over time | ​ | ​ | 64,175 | ​ | ​ | 17,382 | ​ | ​ | 36,274 | ​ | ​ | 117,831 |
| Total revenues | ​ | $ | 114,301 | ​ | $ | 86,660 | ​ | $ | 46,065 | ​ | $ | 247,026 |
  (was, 2024-08-09, similarity 0.9483):
[0001410578-24-001264:note_history:16]
| Three months ended June 30, 2024 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 45,404 | ​ | $ | 88,076 | ​ | $ | 42,327 | ​ | $ | 175,807 |
| Government | ​ | ​ | 69,046 | ​ | ​ | 2,201 | ​ | ​ | 13,729 | ​ | ​ | 84,976 |
| Total revenues | ​ | $ | 114,450 | ​ | $ | 90,277 | ​ | $ | 56,056 | ​ | $ | 260,783 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 95,265 | ​ | $ | 54,063 | ​ | $ | 32,575 | ​ | $ | 181,903 |
| International | ​ | ​ | 19,185 | ​ | ​ | 36,214 | ​ | ​ | 23,481 | ​ | ​ | 78,880 |
| Total revenues | ​ | $ | 114,450 | ​ | $ | 90,277 | ​ | $ | 56,056 | ​ | $ | 260,783 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 53,148 | ​ | $ | 72,985 | ​ | $ | 11,426 | ​ | $ | 137,559 |
| Over time | ​ | ​ | 61,302 | ​ | ​ | 17,292 | ​ | ​ | 44,630 | ​ | ​ | 123,224 |
| Total revenues | ​ | $ | 114,450 | ​ | $ | 90,277 | ​ | $ | 56,056 | ​ | $ | 260,783 |

- changed (2025-02-10):
[0001410578-25-000100:note_history:17]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2023 are presented in the table below:
  (was, 2024-08-09, similarity 0.9288):
[0001410578-24-001264:note_history:17]
Revenues by customer type, geographic location, and revenue recognition method for the three and nine-month periods ended June 30, 2023 are presented in the tables below.

- changed (2025-02-10):
[0001410578-25-000100:note_history:18]
| (In thousands) |  | A&D |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 37,209 | ​ | $ | 81,469 | ​ | $ | 35,087 | ​ | $ | 153,765 |
| Government | ​ | ​ | 57,524 | ​ | ​ | 1,515 | ​ | ​ | 5,510 | ​ | ​ | 64,549 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 79,901 | ​ | $ | 55,961 | ​ | $ | 22,252 | ​ | $ | 158,114 |
| International | ​ | ​ | 14,832 | ​ | ​ | 27,023 | ​ | ​ | 18,345 | ​ | ​ | 60,200 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 39,465 | ​ | $ | 66,703 | ​ | $ | 7,980 | ​ | $ | 114,148 |
| Over time | ​ | ​ | 55,268 | ​ | ​ | 16,281 | ​ | ​ | 32,617 | ​ | ​ | 104,166 |
| Total revenues | ​ | $ | 94,733 | ​ | $ | 82,984 | ​ | $ | 40,597 | ​ | $ | 218,314 |
  (was, 2024-08-09, similarity 0.9523):
[0001410578-24-001264:note_history:18]
| Three months ended June 30, 2023 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 45,574 | ​ | $ | 88,442 | ​ | $ | 48,407 | ​ | $ | 182,423 |
| Government | ​ | ​ | 57,895 | ​ | ​ | 1,524 | ​ | ​ | 6,907 | ​ | ​ | 66,326 |
| Total revenues | ​ | $ | 103,469 | ​ | $ | 89,966 | ​ | $ | 55,314 | ​ | $ | 248,749 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States | ​ | $ | 86,031 | ​ | $ | 55,011 | ​ | $ | 32,246 | ​ | $ | 173,288 |
| International | ​ | ​ | 17,438 | ​ | ​ | 34,955 | ​ | ​ | 23,068 | ​ | ​ | 75,461 |
| Total revenues | ​ | $ | 103,469 | ​ | $ | 89,966 | ​ | $ | 55,314 | ​ | $ | 248,749 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time | ​ | $ | 48,496 | ​ | $ | 74,128 | ​ | $ | 11,496 | ​ | $ | 134,120 |
| Over time | ​ | ​ | 54,973 | ​ | ​ | 15,838 | ​ | ​ | 43,818 | ​ | ​ | 114,629 |
| Total revenues | ​ | $ | 103,469 | ​ | $ | 89,966 | ​ | $ | 55,314 | ​ | $ | 248,749 |

- added (2025-02-10):
[0001410578-25-000100:note_history:19]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to performance obligations that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At December 31, 2024, the Company had $906.9 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 72% in the next twelve months.

- changed (2025-02-10):
[0001410578-25-000100:note_history:20]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At December 31, 2024, contract assets, contract liabilities and accounts receivable totaled $131.4 million, $138.4 million and $202.7 million, respectively. During the first quarter of 2025, the Company recognized approximately $35.1 million in revenues that were included in the contract liabilities balance at September 30, 2024. At September 30, 2024, contract assets, contract liabilities and accounts receivable totaled $130.5 million, $134.3 million and $240.7 million, respectively.
  (was, 2024-08-09, similarity 0.9742):
[0001410578-24-001264:note_history:20]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At June 30, 2024, contract assets, contract liabilities and accounts receivable totaled $134.6 million, $123.5 million and $213.6 million, respectively. During the first nine months of 2024, the Company recognized approximately $54 million in revenues that were included in the contract liabilities balance at September 30, 2023. At September 30, 2023, contract assets, contract liabilities and accounts receivable totaled $138.6 million, $123.1 million and $198.6 million, respectively.

- removed (2025-02-10):
[0001410578-24-001264:note_history:21]
| Nine months ended June 30, 2024 |  | Aerospace |  |  | ​ |  |  | ​ |  |  | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 131,993 | ​ | $ | 254,765 | ​ | $ | 111,951 | ​ | $ | 498,709 |
| Government | ​ |  | 191,891 | ​ |  | 5,805 | ​ |  | 31,821 | ​ |  | 229,517 |
| Total revenues | ​ | $ | 323,884 | ​ | $ | 260,570 | ​ | $ | 143,772 | ​ | $ | 728,226 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 267,325 | ​ | $ | 165,789 | ​ | $ | 82,370 | ​ | $ | 515,484 |
| International | ​ |  | 56,559 | ​ |  | 94,781 | ​ |  | 61,402 | ​ |  | 212,742 |
| Total revenues | ​ | $ | 323,884 | ​ | $ | 260,570 | ​ | $ | 143,772 | ​ | $ | 728,226 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 146,076 | ​ | $ | 209,973 | ​ | $ | 29,706 | ​ | $ | 385,755 |
| Over time | ​ |  | 177,808 | ​ |  | 50,597 | ​ |  | 114,066 | ​ |  | 342,471 |
| Total revenues | ​ | $ | 323,884 | ​ | $ | 260,570 | ​ | $ | 143,772 | ​ | $ | 728,226 |

- removed (2025-02-10):
[0001410578-24-001264:note_history:22]
| Nine months ended June 30, 2023 |  | Aerospace |  |  | ​ |  |  | ​ |  |  | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 128,016 | ​ | $ | 236,715 | ​ | $ | 137,587 | ​ | $ | 502,318 |
| Government | ​ |  | 157,418 | ​ |  | 3,457 | ​ |  | 20,193 | ​ |  | 181,068 |
| Total revenues | ​ | $ | 285,434 | ​ | $ | 240,172 | ​ | $ | 157,780 | ​ | $ | 683,386 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 237,481 | ​ | $ | 154,410 | ​ | $ | 87,253 | ​ | $ | 479,144 |
| International | ​ |  | 47,953 | ​ |  | 85,762 | ​ |  | 70,527 | ​ |  | 204,242 |
| Total revenues | ​ | $ | 285,434 | ​ | $ | 240,172 | ​ | $ | 157,780 | ​ | $ | 683,386 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 129,355 | ​ | $ | 194,240 | ​ | $ | 32,565 | ​ | $ | 356,160 |
| Over time | ​ |  | 156,079 | ​ |  | 45,932 | ​ |  | 125,215 | ​ |  | 327,226 |
| Total revenues | ​ | $ | 285,434 | ​ | $ | 240,172 | ​ | $ | 157,780 | ​ | $ | 683,386 |

- removed (2025-02-10):
[0001410578-24-001264:note_history:23]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At June 30, 2024, the Company had $888.7 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 68% in the next twelve months.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2025-02-10):
[0001410578-24-001264:note_history:24]
15.  SUBSEQUENT EVENT

- removed (2025-02-10):
[0001410578-24-001264:note_history:25]
On July 8, 2024, the Company announced that it has agreed to acquire the Signature Management & Power (or the “Business”) business of Ultra Maritime for a purchase price of approximately $550 million. The transaction will be funded through cash on hand and incremental debt, with committed financing in place. Signature Management & Power is a provider of mission-critical signature and power management solutions for submarines and surface ships for the U.S. and UK naval defense markets.  The Business is headquartered in Long Island, New York, operates out of four facilities based in the U.S. and the UK, and has approximately 410 employees.  Signature Management & Power will become part of ESCO’s Aerospace & Defense segment and is expected to have approximately $175 million of revenue in calendar year 2024.  The closing of the transaction is subject to certain conditions, including the (i) expiration or termination of the applicable waiting period under the Hart-Scott-Rodino Antitrust Improvements Act of 1976 in the U.S. and (ii) receipt of clearance under the UK National Security and Investment Act of 2021.

- removed (2025-02-10):
[0001410578-24-001264:note_history:26]
Pursuant to a Commitment Letter entered into on July 8, 2024 between the Company and JPMorgan Chase Bank, N.A., on August 5, 2024 the Registrant and certain of its subsidiaries entered into Amendment No. 1 (the “Amendment”) to its Amended and Restated Credit Agreement dated August 30, 2023 (the “2023 Credit Agreement”) among the Company and certain of its subsidiaries, JPMorgan Chase Bank, N.A., as administrative agent thereunder, the initial lenders party thereto and Citibank, N.A. The Amendment, among other things, (i) implements a senior incremental delayed draw term loan credit facility in an aggregate principal amount of up to $375 million (the “Incremental Facility”), and (ii) permits the direct or indirect acquisition by the

- removed (2025-02-10):
[0001410578-24-001264:note_history:27]
Registrant or certain of its subsidiaries of all of the issued and outstanding shares of Ultra PMES Limited, Measurement Systems, Inc., EMS Development Corporation, and DNE Technologies, Inc. (the “Transaction”), pursuant to and in accordance with the terms and conditions of that certain Sale and Purchase Agreement, dated July 8, 2024, among Ultra Electronics Holdings Limited, as parent seller, the Registrant, as guarantor, and certain of the Registrant’s subsidiaries as buyers. The proceeds of the loans drawn under the Incremental Facility will be applied to pay a portion of the cash consideration for the Transaction and other customary fees, premiums, expenses and costs incurred in connection with the Transaction. See further discussion of the transaction and financing arrangements in the Company’s Form 8-K’s filed on July 8, 2024 and August 7, 2024.
