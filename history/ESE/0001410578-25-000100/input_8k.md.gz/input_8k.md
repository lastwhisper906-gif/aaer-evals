# ESE 8-K — 0001104659-25-010118 filed 2025-02-06

## item codes, every 8-K on or before 2025-02-10

- 2025-02-06 0001104659-25-010118 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2024-11-14 0001104659-24-118951 — 2.02, 5.02, 7.01, 9.01
- 2024-10-18 0001104659-24-109788 — 5.02
- 2024-10-01 0001104659-24-104776 — 5.02
- 2024-08-07 0001104659-24-086768 — 1.01, 2.02, 5.02, 7.01, 9.01
- 2024-07-08 0001104659-24-078312 — 1.01, 7.01, 9.01
- 2024-05-09 0001104659-24-059341 — 2.02, 7.01, 9.01
- 2024-02-08 0001104659-24-012294 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2023-11-20 0001104659-23-119761 — 5.02, 9.01
- 2023-11-16 0001104659-23-119126 — 2.02, 7.01, 9.01
- 2023-10-03 0001104659-23-106090 — 5.02, 9.01
- 2023-09-06 0001104659-23-098463 — 1.01, 2.03, 9.01
- 2023-08-08 0001104659-23-088847 — 2.02, 7.01, 9.01
- 2023-07-06 0001104659-23-078571 — 5.02, 8.01, 9.01
- 2023-05-09 0001104659-23-057736 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2023-05-05 0001104659-23-056387 — 5.02, 9.01
- 2023-02-08 0001104659-23-014539 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2023-01-06 0001104659-23-001859 — 5.02, 9.01
- 2022-11-22 0001104659-22-121229 — 5.02, 5.03, 8.01, 9.01
- 2022-11-17 0001104659-22-119898 — 2.02, 7.01, 9.01
- 2022-09-12 0001104659-22-099248 — 5.02, 7.01, 9.01
- 2022-08-08 0001104659-22-087247 — 2.02, 5.02, 7.01, 9.01
- 2022-05-09 0001104659-22-057524 — 2.02, 5.02, 7.01, 9.01
- 2022-02-08 0001104659-22-013878 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2021-12-03 0001104659-21-146361 — 4.01, 9.01 — amendment, the index does not say of what
- 2021-11-24 0001104659-21-143568 — 4.01, 9.01
- 2021-11-23 0001104659-21-142871 — 5.02, 8.01
- 2021-11-18 0001104659-21-141206 — 2.02, 7.01, 9.01
- 2021-08-09 0001104659-21-102150 — 2.02, 7.01, 9.01
- 2021-05-04 0001104659-21-060985 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2021-04-05 0001104659-21-046581 — 5.02, 9.01
- 2021-02-08 0001104659-21-013712 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2020-12-09 0001104659-20-133674 — 5.02, 9.01
- 2020-12-07 0001104659-20-132861 — 5.02, 7.01, 9.01
- 2020-11-19 0001104659-20-127352 — 2.02, 5.02, 7.01, 9.01
- 2020-08-10 0001104659-20-092734 — 2.02, 7.01, 9.01
- 2020-05-06 0001104659-20-057442 — 2.02, 7.01, 8.01, 9.01
- 2020-02-04 0001104659-20-010640 — 2.02, 5.07, 7.01, 9.01
- 2020-01-07 0001104659-20-001789 — 2.01, 9.01
- 2019-11-19 0001104659-19-065437 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2019-11-18 0001104659-19-065096 — 1.01, 2.02, 7.01, 9.01
- 2019-09-30 0001144204-19-046523 — 1.01, 1.02, 2.03, 9.01
- 2019-08-08 0001144204-19-038567 — 2.02, 7.01, 9.01
- 2019-05-07 0001144204-19-024241 — 2.02, 5.02, 7.01, 9.01
- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2025-02-10

- none on or before 2025-02-10

## item 2.02 — earnings release, exhibit 99.1

[0001104659-25-010118:8k_2_02:1]
EX-99.1
2
tm255521d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-25-010118:8k_2_02:2]
Exhibit 99.1

[0001104659-25-010118:8k_2_02:3]
| NEWS FROM |  |

[0001104659-25-010118:8k_2_02:4]
For more information contact:

[0001104659-25-010118:8k_2_02:5]
Kate
Lowrey - VP of Investor Relations

[0001104659-25-010118:8k_2_02:6]
(314)
213-7277 / klowrey@escotechnologies.com

[0001104659-25-010118:8k_2_02:7]
ESCO
REPORTS FIRST QUARTER FISCAL 2025 RESULTS

[0001104659-25-010118:8k_2_02:8]
- Q1 Sales increase 13% to $247 Million
-

[0001104659-25-010118:8k_2_02:9]
- Q1 GAAP EPS increases 54% to $0.91 -

[0001104659-25-010118:8k_2_02:10]
- Q1 Adjusted EPS as defined in prior guidance
increases 48% to $0.92 -

[0001104659-25-010118:8k_2_02:11]
- Q1 Adjusted EPS excluding Acquisition
Related Amortization increases 41% to $1.07 -

[0001104659-25-010118:8k_2_02:12]
ST. LOUIS, February 6, 2025 – ESCO Technologies Inc. (NYSE:
ESE) (ESCO, or the Company) today reported its operating results for the first quarter ended December 31, 2024 (Q1 2025).

[0001104659-25-010118:8k_2_02:13]
Operating
Highlights

[0001104659-25-010118:8k_2_02:14]
|  | · | Q1 2025 Sales increased $28.7 million (13.2 percent) to $247.0 million compared to $218.3 million in Q1 2024. |

[0001104659-25-010118:8k_2_02:15]
|  | · | Q1 2025 Entered Orders were $275.0 million for a book-to-bill ratio of 1.11x, resulting in record backlog of $907 million. |

[0001104659-25-010118:8k_2_02:16]
|  | · | Q1 2025 GAAP EPS increased 54 percent to $0.91 per share compared to $0.59 per share in Q1 2024. |

[0001104659-25-010118:8k_2_02:17]
|  | · | Q1 2025 Adjusted EPS as defined in prior guidance increased 48 percent to $0.92 per share compared to $0.62 per share in Q1 2024. |

[0001104659-25-010118:8k_2_02:18]
|  | · | Beginning in Q1 2025 we are excluding acquisition related amortization (which was $0.15 per share in Q1 2025) from our Adjusted EPS calculation. Q1 2025 Adjusted EPS excluding acquisition related amortization increased 41 percent to $1.07 per share compared to $0.76 per share in Q1 2024. |

[0001104659-25-010118:8k_2_02:19]
|  | · | Net cash provided by operating activities was $34 million in Q1 2025, an increase of $25 million compared to the prior year period, as cash flow was positively impacted by higher net earnings and favorable working capital impacts. |

[0001104659-25-010118:8k_2_02:20]
Bryan
Sayler, Chief Executive Officer and President, commented, “Our fiscal year got off to an outstanding start as we delivered
13 percent top line growth, over 200 basis points of Adjusted EBITDA margin expansion, and a 41 percent increase in Adjusted EPS compared
to the prior year. All three segments delivered solid revenue growth, highlighted by notable strength across our Navy, commercial aerospace
and utility end-markets. It was also great to see our Test business deliver a solid quarter with improving order flow, double digit revenue
growth, and over 500 basis points of margin expansion.

[0001104659-25-010118:8k_2_02:21]
“The ESCO team continues to build upon our strong position in
attractive markets to increase value across the enterprise. Overall, it was a great way to start the year, with continuing momentum across
our end markets giving us the confidence to raise our full year earnings guidance.”

[0001104659-25-010118:8k_2_02:22]
Segment Performance

[0001104659-25-010118:8k_2_02:23]
Aerospace & Defense (A&D)

[0001104659-25-010118:8k_2_02:24]
|  | · | Sales increased $19.6 million (21 percent) to $114.3 million in Q1 2025 from $94.7 million in Q1 2024. The Q1 increase was driven by strength in Navy and commercial aerospace, partially offset by lower defense aerospace. |

[0001104659-25-010118:8k_2_02:25]
|  | · | Q1 2025 EBIT and Adjusted EBIT both increased $4.9 million to $21.6 million (18.9 percent margin) from $16.7 million (17.6 percent margin) in Q1 2024. Margin improvement was driven by leverage on higher volume and price increases, partially offset by inflationary pressures and mix. |

[0001104659-25-010118:8k_2_02:26]
|  | · | Entered Orders decreased $51 million (30 percent) to $121 million in Q1 2025 compared to $172 million in Q1 2024. The decrease in orders was primarily driven by large Navy orders for Virginia Class Block V surface hull tiles and Block VI long lead material procurement for the Light-Weight Wide Aperture Array (LWWAA) in Q1 2024, partially offset by higher Q1 2025 Navy ejection valve and spares orders. Orders in the quarter resulted in a segment book-to-bill of 1.06x and record ending backlog of $607 million. |

[0001104659-25-010118:8k_2_02:27]
Utility Solutions Group (USG)

[0001104659-25-010118:8k_2_02:28]
|  | · | Sales increased $3.7 million (4 percent) to $86.7 million in Q1 2025 from $83.0 million in Q1 2024. Doble’s sales increased by $7.9 million (12 percent) driven by a strong quarter for offline and protection testing products and services. NRG sales decreased $4.2 million (22 percent) due to moderation in renewable energy projects in the quarter. |

[0001104659-25-010118:8k_2_02:29]
|  | · | EBIT increased $2.9 million in Q1 2025 to $20.5 million from $17.6 million in Q1 2024. Adjusted EBIT increased $2.8 million to $20.5 million (23.6 percent margin) from $17.7 million (21.4 percent margin) in Q1 2024. Margin was favorably impacted by leverage on higher volume, price increases, and mix, partially offset by inflationary pressures. |

[0001104659-25-010118:8k_2_02:30]
|  | · | Entered Orders increased $13 million (16 percent) to $90 million in Q1 2025. Doble orders increased by $10 million (15 percent) on strength across their product portfolio and highlighted by a $4.3 million order for offline test equipment at Phenix. NRG orders increased by $3 million in the quarter. The segment book-to-bill was 1.03x in the quarter and resulted in an ending backlog of $123 million. |

[0001104659-25-010118:8k_2_02:31]
RF Test & Measurement (Test)

[0001104659-25-010118:8k_2_02:32]
|  | · | Sales increased $5.5 million (13 percent) to $46.1 million in Q1 2025 from $40.6 million in Q1 2024. Sales growth primarily related to higher U.S. shielding, Test and Measurement in EMEA, and MPE filter sales. |

[0001104659-25-010118:8k_2_02:33]
|  | · | EBIT increased $2.6 million in Q1 2025 to $4.4 million from $1.8 million in Q1 2024. Adjusted EBIT increased $2.8 million in Q1 2025 to $4.9 million (10.6 percent margin) from $2.1 million (5.1 percent margin) in Q1 2024. Margin was favorably impacted by leverage on higher volume, price increases, and cost reduction efforts, partially offset by inflationary pressures and mix. |

[0001104659-25-010118:8k_2_02:34]
|  | · | Entered Orders increased $20 million (43 percent) to $65 million in Q1 2025. The increase was driven by a strong quarter for EMC Test & Measurement, A&D, and medical and industrial shielding orders. The segment book-to-bill was 1.41x in the quarter and resulted in ending backlog of $177 million. |

[0001104659-25-010118:8k_2_02:35]
Business
Outlook – 2025

[0001104659-25-010118:8k_2_02:36]
Beginning in Q1 2025, acquisition related amortization will be excluded
from our Adjusted Earnings calculation. Our current assessment of FY 2025 acquisition related amortization does not include the impact
of the pending SM&P acquisition. The initial fiscal 2025 guidance issued in our November press release is revised as follows:

[0001104659-25-010118:8k_2_02:37]
|  |  | Guidance Range |  |
| November FY 2025 Adjusted EPS Guidance |  | $ | 4.70 |  |  | $ | 4.90 |  |
| Acquisition Related Amortization |  | $ | 0.60 |  |  | $ | 0.60 |  |
| Revised November FY 2025 Adjusted EPS Guidance |  | $ | 5.30 |  |  | $ | 5.50 |  |

[0001104659-25-010118:8k_2_02:38]
Due to strong market conditions and continued improvement in operational
performance, we are raising our full-year guidance by $0.25 to a range of $5.55 to $5.75 (16 to 21 percent growth over the prior year)
from $5.30 to $5.50. This guidance is in line with our initial revenue guidance range of $1.09 to $1.11 billion (6 to 8 percent annual
growth).

[0001104659-25-010118:8k_2_02:39]
|  |  | Guidance Range |  |
| Revised November FY 2025 Adjusted EPS Guidance |  | $ | 5.30 |  |  | $ | 5.50 |  |
| Guidance Increase |  | $ | 0.25 |  |  | $ | 0.25 |  |
| Revised FY 2025 Adjusted EPS Guidance |  | $ | 5.55 |  |  | $ | 5.75 |  |

[0001104659-25-010118:8k_2_02:40]
Management’s current expectation is for Q2 Adjusted EPS in the
range of $1.20 to $1.30, which represents 10 to 19 percent growth over the prior year quarter.

[0001104659-25-010118:8k_2_02:41]
|  |  | Guidance Range |  |
| Q2 2025 Adjusted EPS Guidance (prior methodology) |  | $ | 1.05 |  |  | $ | 1.15 |  |
| Acquisition Related Amortization |  | $ | 0.15 |  |  | $ | 0.15 |  |
| Q2 2025 Adjusted EPS Guidance |  | $ | 1.20 |  |  | $ | 1.30 |  |

[0001104659-25-010118:8k_2_02:42]
SM&P Acquisition

[0001104659-25-010118:8k_2_02:43]
As announced on July 8, 2024, ESCO has agreed to acquire the
Signature Management & Power (SM&P) business of Ultra Maritime for a purchase price of $550 million. The closing of the
transaction is subject to certain conditions, including the completion of the regulatory approval processes in the United States (US)
and the United Kingdom (UK). The US closing conditions have been met. We are in the final stages of the UK government assessment of the
transaction and we are optimistic that the assessment will be positively resolved in the near term. Our current expectation would be
to close the transaction either in our second or early in our third fiscal quarter. SM&P’s sole source product offerings will
add significant scale to the ESCO Navy business, providing increased content on domestic Navy submarine and surface ship programs and
expansion into vital UK and AUKUS navy platforms.

[0001104659-25-010118:8k_2_02:44]
Dividend
Payment

[0001104659-25-010118:8k_2_02:45]
The
next quarterly cash dividend of $0.08 per share will be paid on April 17, 2025 to stockholders of record on April 2,
2025.

[0001104659-25-010118:8k_2_02:46]
Conference Call

[0001104659-25-010118:8k_2_02:47]
The
Company will host a conference call today, February 6, at 4:00 p.m. Central Time, to discuss the Company’s Q1 2025 results.
A live audio webcast and an accompanying slide presentation will be available in the Investor Center of ESCO’s website.
Participants may also access the webcast using this registration link. For those unable to participate, a webcast replay will
be available after the call in the Investor Center of ESCO’s website.

[0001104659-25-010118:8k_2_02:48]
Forward-Looking Statements

[0001104659-25-010118:8k_2_02:49]
Investors are cautioned that such statements are only predictions
and speak only as of the date of this presentation, and the Company undertakes no duty to update them except as may be required by applicable
laws or regulations. The Company’s actual results in the future may differ materially from those projected in the forward-looking
statements due to risks and uncertainties that exist in the Company’s operations and business environment including but not limited
to those described in Item 1A, “Risk Factors”, of the Company’s Annual Report on Form 10-K for the fiscal year
ended September 30, 2024 and the following: the timing and outcome, if any, of the Company’s strategic alternatives review
of VACCO and its Space business; of the Company’s pending acquisition of SM&P; the impacts of climate change and related regulation
of greenhouse gases; the impacts of labor disputes, civil disorder, wars, elections, political changes, tariffs and trade disputes, terrorist
activities, cyberattacks or natural disasters on the Company’s operations and those of the Company’s customers and suppliers;
disruptions in manufacturing or delivery arrangements due to shortages or unavailability of materials or components or supply chain disruptions;
inability to access work sites; the timing and content of future contract awards or customer orders; the timely appropriation, allocation
and availability of Government funds; the termination for convenience of Government and other customer contracts or orders; weakening
of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies;
competition; intellectual property rights; technical difficulties or data breaches; the availability of acquisitions; delivery delays
or defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability
of certain raw materials; material changes in the cost of credit; changes in laws and regulations including but not limited to changes
in accounting standards and taxation; changes in interest, inflation and employment rates; costs relating to environmental matters arising
from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration;
and the integration and performance of acquired businesses.

[0001104659-25-010118:8k_2_02:50]
Non-GAAP Financial Measures

[0001104659-25-010118:8k_2_02:51]
The financial measures EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA,
and Adjusted EPS are presented in this press release. The Company defines “EBIT” as earnings before interest and taxes, “EBITDA”
as earnings before interest, taxes, depreciation and amortization, “Adjusted EBIT” and “Adjusted EBITDA” as excluding
the net impact of the items described in the attached Reconciliation of Non-GAAP Financial Measures, and “Adjusted EPS” as
GAAP earnings per share excluding the net impact of the items described and reconciled in the attached Reconciliation of Non-GAAP Financial
Measures.

[0001104659-25-010118:8k_2_02:52]
EBIT,
Adjusted EBIT, EBITDA, Adjusted EBITDA, and Adjusted EPS are not recognized in accordance with U.S. generally accepted accounting principles
(GAAP). However, Management believes EBIT, Adjusted EBIT, EBITDA, and Adjusted EBITDA are useful in assessing the operational profitability
of the Company’s business segments because they exclude interest, taxes, depreciation, and amortization, which are generally accounted
for across the entire Company on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations
within the Company as well as incentive compensation. The presentation of EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA, and Adjusted
EPS provides important supplemental information to investors by facilitating comparisons with other companies, many of which use similar
non-GAAP financial measures to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace
any measures of performance determined in accordance with GAAP.

[0001104659-25-010118:8k_2_02:53]
About ESCO

[0001104659-25-010118:8k_2_02:54]
ESCO
is a global provider of highly engineered products and solutions serving diverse end-markets. It manufactures filtration and fluid control
products for the aviation, Navy, space, and process markets worldwide and composite-based products and solutions for Navy, defense, and
industrial customers. ESCO is an industry leader in designing and manufacturing RF test and measurement products and systems; and provides
diagnostic instruments, software and services to industrial power users and the electric utility and renewable energy industries. Headquartered
in St. Louis, Missouri, ESCO and its subsidiaries have offices and manufacturing facilities worldwide. For more information on ESCO and
its subsidiaries, visit the Company’s website at www.escotechnologies.com.

[0001104659-25-010118:8k_2_02:55]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-25-010118:8k_2_02:56]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-25-010118:8k_2_02:57]
(Dollars in thousands, except per share amounts)

[0001104659-25-010118:8k_2_02:58]
|  |  | Three Months Ended December 31, 2024 |  |  | Three Months Ended December 31, 2023 |  |
| Net Sales |  | $ | 247,026 |  |  |  | 218,314 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 148,642 |  |  |  | 134,151 |  |
| Selling, general and administrative expenses |  |  | 58,784 |  |  |  | 53,968 |  |
| Amortization of intangible assets |  |  | 7,993 |  |  |  | 7,868 |  |
| Interest expense |  |  | 2,257 |  |  |  | 2,667 |  |
| Other (income) expenses, net |  |  | (591 | ) |  |  | 206 |  |
| Total costs and expenses |  |  | 217,085 |  |  |  | 198,860 |  |
| Earnings before income taxes |  |  | 29,941 |  |  |  | 19,454 |  |
| Income tax expense |  |  | 6,468 |  |  |  | 4,285 |  |
| Net earnings |  | $ | 23,473 |  |  |  | 15,169 |  |
| Earnings Per Share (EPS) |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.91 |  |  |  | 0.59 |  |
| Diluted - As Adjusted Basis |  |  | $1.07 | (1) |  |  | 0.76 | (2) |
| Diluted average common shares O/S: |  |  | 25,834 |  |  |  | 25,846 |  |

[0001104659-25-010118:8k_2_02:59]
|  | (1) | Q1 2025 Adjusted EPS excludes $0.16 per share of after-tax charges consisting primarily of $0.01 of restructuring charges within the Test segment and acquisition related costs at Corporate and $0.15 of acquisition related amortization. |

[0001104659-25-010118:8k_2_02:60]
|  | (2) | Q1 2024 Adjusted EPS excludes $0.17 per share of after-tax charges consisting primarily of $0.03 of MPE acquisition inventory step-up and backlog charges and acquisition related costs and $0.14 of acquisition related amortization. |

[0001104659-25-010118:8k_2_02:61]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-25-010118:8k_2_02:62]
Condensed Business Segment Information (Unaudited)

[0001104659-25-010118:8k_2_02:63]
(Dollars in thousands)

[0001104659-25-010118:8k_2_02:64]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | Q1 2025 |  |  | Q1 2024 |  |  | Q1 2025 |  |  | Q1 2024 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 114,301 |  |  |  | 94,733 |  |  |  | 114,301 |  |  |  | 94,733 |  |
| USG |  |  | 86,660 |  |  |  | 82,984 |  |  |  | 86,660 |  |  |  | 82,984 |  |
| Test |  |  | 46,065 |  |  |  | 40,597 |  |  |  | 46,065 |  |  |  | 40,597 |  |
| Totals |  | $ | 247,026 |  |  |  | 218,314 |  |  |  | 247,026 |  |  |  | 218,314 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 21,596 |  |  |  | 16,663 |  |  |  | 21,622 |  |  |  | 16,663 |  |
| USG |  |  | 20,489 |  |  |  | 17,625 |  |  |  | 20,489 |  |  |  | 17,745 |  |
| Test |  |  | 4,422 |  |  |  | 1,779 |  |  |  | 4,887 |  |  |  | 2,052 |  |
| Corporate |  |  | (14,309 | ) |  |  | (13,946 | ) |  |  | (9,310 | ) |  |  | (8,600 | ) |
| Consolidated EBIT |  |  | 32,198 |  |  |  | 22,121 |  |  |  | 37,688 |  |  |  | 27,860 |  |
| Less: Interest expense |  |  | (2,257 | ) |  |  | (2,667 | ) |  |  | (2,257 | ) |  |  | (2,667 | ) |
| Less: Income tax expense |  |  | (6,468 | ) |  |  | (4,285 | ) |  |  | (7,730 | ) |  |  | (5,605 | ) |
| Net earnings |  | $ | 23,473 |  |  |  | 15,169 |  |  |  | 27,701 |  |  |  | 19,588 |  |

[0001104659-25-010118:8k_2_02:65]
Note
1: Adjusted net earnings of $27.7 million in Q1 2025 exclude $4.2 million (or $0.16 per share) of after-tax charges consisting primarily
of restructuring charges within the Test segment and acquisition related costs at Corporate, and acquisition related amortization.

[0001104659-25-010118:8k_2_02:66]
Note 2: Adjusted net earnings of $19.6 million in Q1 2024 exclude $4.4 million (or $0.17 per share) of after-tax charges consisting primarily of MPE acquisition inventory step-up and backlog charges and acquisition related costs, and acquisition related amortization.

[0001104659-25-010118:8k_2_02:67]
| EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |  | Adjusted |  |  | Adjusted |  |
|  |  | Q1 2025 |  |  | Q1 2024 |  |  | Q1 2025 |  |  | Q1 2024 |  |
| Consolidated EBITDA |  | $ | 46,005 |  |  |  | 35,573 |  |  |  | 46,498 |  |  |  | 36,408 |  |
| Less: Depr & Amort |  |  | (13,807 | ) |  |  | (13,452 | ) |  |  | (8,810 | ) |  |  | (8,548 | ) |
| Consolidated EBIT |  |  | 32,198 |  |  |  | 22,121 |  |  |  | 37,688 |  |  |  | 27,860 |  |
| Less: Interest expense |  |  | (2,257 | ) |  |  | (2,667 | ) |  |  | (2,257 | ) |  |  | (2,667 | ) |
| Less: Income tax expense |  |  | (6,468 | ) |  |  | (4,285 | ) |  |  | (7,730 | ) |  |  | (5,605 | ) |
| Net earnings |  | $ | 23,473 |  |  |  | 15,169 |  |  |  | 27,701 |  |  |  | 19,588 |  |

[0001104659-25-010118:8k_2_02:68]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-25-010118:8k_2_02:69]
Condensed Consolidated Balance Sheets (Unaudited)

[0001104659-25-010118:8k_2_02:70]
(Dollars in thousands)

[0001104659-25-010118:8k_2_02:71]
|  |  | December 31, 2024 |  |  | September 30, 2024 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 71,284 |  |  |  | 65,963 |  |
| Accounts receivable, net |  |  | 202,661 |  |  |  | 240,680 |  |
| Contract assets |  |  | 131,404 |  |  |  | 130,534 |  |
| Inventories |  |  | 219,383 |  |  |  | 209,164 |  |
| Other current assets |  |  | 20,779 |  |  |  | 22,308 |  |
| Total current assets |  |  | 645,511 |  |  |  | 668,649 |  |
| Property, plant and equipment, net |  |  | 168,468 |  |  |  | 170,596 |  |
| Intangible assets, net |  |  | 396,302 |  |  |  | 407,602 |  |
| Goodwill |  |  | 532,312 |  |  |  | 539,899 |  |
| Operating lease assets |  |  | 38,710 |  |  |  | 37,744 |  |
| Other assets |  |  | 13,761 |  |  |  | 14,130 |  |
|  |  | $ | 1,795,064 |  |  |  | 1,838,620 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt |  | $ | 20,000 |  |  |  | 20,000 |  |
| Accounts payable |  |  | 75,881 |  |  |  | 98,371 |  |
| Contract liabilities |  |  | 129,737 |  |  |  | 124,845 |  |
| Other current liabilities |  |  | 90,491 |  |  |  | 106,638 |  |
| Total current liabilities |  |  | 316,109 |  |  |  | 349,854 |  |
| Deferred tax liabilities |  |  | 75,520 |  |  |  | 75,333 |  |
| Non-current operating lease liabilities |  |  | 36,400 |  |  |  | 34,810 |  |
| Other liabilities |  |  | 38,102 |  |  |  | 39,273 |  |
| Long-term debt |  |  | 92,000 |  |  |  | 102,000 |  |
| Shareholders' equity |  |  | 1,236,933 |  |  |  | 1,237,350 |  |
|  |  | $ | 1,795,064 |  |  |  | 1,838,620 |  |

[0001104659-25-010118:8k_2_02:72]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-25-010118:8k_2_02:73]
Consolidated Statements of Cash Flows

[0001104659-25-010118:8k_2_02:74]
(Dollars in thousands)

[0001104659-25-010118:8k_2_02:75]
|  |  | Three Months Ended December 31, 2024 |  |  | Three Months Ended December 31, 2023 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 23,473 |  |  |  | 15,169 |  |
| Adjustments to reconcile net earnings to net cash |  |  |  |  |  |  |  |  |
| provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 13,807 |  |  |  | 13,452 |  |
| Stock compensation expense |  |  | 2,524 |  |  |  | 2,180 |  |
| Changes in assets and liabilities |  |  | (7,151 | ) |  |  | (22,539 | ) |
| Effect of deferred taxes |  |  | 1,521 |  |  |  | 484 |  |
| Net cash provided by operating activities |  |  | 34,174 |  |  |  | 8,746 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Acquisition of business, net of cash acquired |  |  | - |  |  |  | (56,179 | ) |
| Capital expenditures |  |  | (5,208 | ) |  |  | (7,848 | ) |
| Additions to capitalized software |  |  | (2,587 | ) |  |  | (2,942 | ) |
| Net cash used by investing activities |  |  | (7,795 | ) |  |  | (66,969 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from long-term debt |  |  | 42,000 |  |  |  | 99,000 |  |
| Principal payments on long-term debt and short-term borrowings |  |  | (52,000 | ) |  |  | (29,000 | ) |
| Dividends paid |  |  | (2,064 | ) |  |  | (2,064 | ) |
| Purchases of common stock into treasury |  |  | - |  |  |  | - |  |
| Other |  |  | (6,031 | ) |  |  | (1,432 | ) |
| Net cash (used) provided by financing activities |  |  | (18,095 | ) |  |  | 66,504 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (2,963 | ) |  |  | 1,249 |  |
| Net increase in cash and cash equivalents |  |  | 5,321 |  |  |  | 9,530 |  |
| Cash and cash equivalents, beginning of period |  |  | 65,963 |  |  |  | 41,866 |  |
| Cash and cash equivalents, end of period |  | $ | 71,284 |  |  |  | 51,396 |  |

[0001104659-25-010118:8k_2_02:76]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-25-010118:8k_2_02:77]
Other Selected Financial Data (Unaudited)

[0001104659-25-010118:8k_2_02:78]
(Dollars in thousands)

[0001104659-25-010118:8k_2_02:79]
| Backlog And Entered Orders - Q1 2025 |  | A&D |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 10/1/24 |  | $ | 600,382 |  |  |  | 119,943 |  |  |  | 158,644 |  |  |  | 878,969 |  |
| Entered Orders |  |  | 120,606 |  |  |  | 89,574 |  |  |  | 64,825 |  |  |  | 275,005 |  |
| Sales |  |  | (114,301 | ) |  |  | (86,660 | ) |  |  | (46,065 | ) |  |  | (247,026 | ) |
| Ending Backlog - 12/31/24 |  | $ | 606,687 |  |  |  | 122,857 |  |  |  | 177,404 |  |  |  | 906,948 |  |

[0001104659-25-010118:8k_2_02:80]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-25-010118:8k_2_02:81]
Reconciliation of Non-GAAP Financial Measures (Unaudited)

[0001104659-25-010118:8k_2_02:82]
| EPS – Adjusted Basis Reconciliation – Q1 2025 |  |  |  |
| EPS – GAAP Basis – Q1 2025 |  | $ | 0.91 |  |
| Adjustments (defined below) |  |  | 0.16 |  |
| EPS – As Adjusted Basis – Q1 2025 |  | $ | 1.07 |  |

[0001104659-25-010118:8k_2_02:83]
Adjustments
exclude $0.16 per share consisting primarily of $0.01 of restructuring charges within the Test segment and acquisition related costs
at Corporate and $0.15 of acquisition related amortization. The $0.16 of EPS adjustments per share consists of $5,490K of pre-tax charges
offset by $1,262K of tax benefit for net impact of $4,228K.

[0001104659-25-010118:8k_2_02:84]
| EPS – Adjusted Basis Reconciliation – Q1 2024 |  |  |  |
| EPS – GAAP Basis – Q1 2024 |  | $ | 0.59 |  |
| Adjustments (defined below) |  |  | 0.17 |  |
| EPS – As Adjusted Basis – Q1 2024 |  | $ | 0.76 |  |

[0001104659-25-010118:8k_2_02:85]
Adjustments
exclude $0.17 per share consisting primarily of $0.03 of MPE acquisition inventory step-up and backlog charges and acquisition
related costs and $0.14 of acquisition related amortization. The $0.17 of EPS adjustments per share consists of $5,739K of pre-tax
charges offset by $1,320K of tax benefit for net impact of $4,419K.

[0001104659-25-010118:8k_2_02:86]
| EPS – Adjusted Basis Reconciliation – Q2 2025 Guidance |  | Low |  |  | High |  |
| EPS – GAAP Basis – Q2 2025 |  | $ | 1.05 |  |  |  | 1.15 |  |
| Adjustments (defined below) |  |  | 0.15 |  |  |  | 0.15 |  |
| EPS – As Adjusted Basis – Q2 2025 |  | $ | 1.20 |  |  |  | 1.30 |  |

[0001104659-25-010118:8k_2_02:87]
Adjustments
exclude an estimated $0.15 of acquisition related amortization. The estimated $0.15 of EPS adjustment per share consists of $5.0 million
of pre-tax charges offset by $1.15 million of tax benefit for net impact of $3.85 million.

[0001104659-25-010118:8k_2_02:88]
| EPS – Adjusted Basis Reconciliation – FY 2025 Guidance |  | Low |  |  | High |  |
| EPS – GAAP Basis – FY 2025 |  | $ | 4.94 |  |  |  | 5.14 |  |
| Adjustments (defined below) |  |  | 0.61 |  |  |  | 0.61 |  |
| EPS – As Adjusted Basis – FY 2025 |  | $ | 5.55 |  |  |  | 5.75 |  |

[0001104659-25-010118:8k_2_02:89]
Adjustments exclude $0.61 per share consisting
primarily of $0.01 of restructuring charges within the Test segment and acquisition related costs at Corporate and an estimated $0.60
of acquisition related amortization. The estimated $0.61 of EPS adjustments per share consists of $20.5 million of pre-tax
charges offset by $4.7 million of tax benefits for net impact of $15.8 million.
