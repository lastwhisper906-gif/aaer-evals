# ESE MD&A — 0001410578-25-000100


## mdna

[0001410578-25-000100:mdna:1]
[same as prior period, unchanged from 0001410578-24-001264:mdna:1]

[0001410578-25-000100:mdna:2]
[same as prior period, unchanged from 0001410578-24-001264:mdna:2]

[0001410578-25-000100:mdna:3]
References to the first quarters of 2025 and 2024 represent the three-month periods ended December 31, 2024 and 2023, respectively.

[0001410578-25-000100:mdna:4]
[same as prior period, unchanged from 0001410578-24-001264:mdna:4]

[0001410578-25-000100:mdna:5]
Sales, net earnings and diluted earnings per share were $247.0 million, $23.5 million and $0.91 per share, respectively, in the first quarter of 2025 compared to $218.3 million, $15.2 million and $0.59 per share, respectively, in the first quarter of 2024.

[0001410578-25-000100:mdna:6]
[same as prior period, unchanged from 0001410578-24-001264:mdna:6]

[0001410578-25-000100:mdna:7]
Net sales increased $28.7 million, or 13.2%, to $247.0 million in the first quarter of 2025 from $218.3 million in the first quarter of 2024. The increase in net sales in the first quarter of 2025 as compared to the first quarter of 2024 was due to a $19.5 million increase in the A&D segment, a $5.5 million increase in the Test segment, and a $3.7 million increase in the USG segment.

[0001410578-25-000100:mdna:8]
-A&D

[0001410578-25-000100:mdna:9]
Net sales of $114.3 million in the first quarter of 2025 were $19.6 million, or 20.7%, higher than the $94.7 million in the first quarter of 2024. The sales increase in the first quarter of 2025 compared to the first quarter of 2024 was primarily due to an approximately $9.1 million increase in aerospace shipments at Crissair and PTI, and a $12.6 million increase in navy sales at VACCO and Globe.

[0001410578-25-000100:mdna:10]
[same as prior period, unchanged from 0001410578-24-001264:mdna:10]

[0001410578-25-000100:mdna:11]
Net sales of $86.7 million in the first quarter of 2025 were $3.7 million, or 4.5% higher than the $83.0 million in the first quarter of 2024. The increase in the first quarter of 2025 compared to the first quarter of 2024 was mainly due to a $7.9 million increase in net sales at Doble driven by higher sales of offline and protection testing products and services, partially offset by a $4.2 million decrease in net sales at NRG as we experienced moderation in the renewables end-market.

[0001410578-25-000100:mdna:12]
[same as prior period, unchanged from 0001410578-24-001264:mdna:12]

[0001410578-25-000100:mdna:13]
Net sales of $46.1 million in the first quarter of 2025 were $5.5 million, or 13.5%, higher than the $40.6 million in the first quarter of 2024. The increase in the first quarter of 2025 compared to the first quarter of 2024 was primarily due to $2.8 million of higher sales from the segment’s European and Asian operations and $2.7 million of higher sales from the segment’s U.S operations.

[0001410578-25-000100:mdna:14]
[same as prior period, unchanged from 0001410578-24-001264:mdna:14]

[0001410578-25-000100:mdna:15]
Backlog was $906.9 million at December 31, 2024 compared with $879.0 million at September 30, 2024. The Company received new orders totaling $275.0 million in the first quarter of 2025 compared to $293.7 million in the first quarter of 2024. Of the new orders received in the first quarter of 2025, $120.6 million related to A&D products, $89.6 million related to USG products, and $64.8 million related to Test products. Of the new orders received in the first quarter of 2024, $171.5 million related to A&D products, $77.0 million related to USG products, and $45.2 million related to Test products.

[0001410578-25-000100:mdna:16]
[same as prior period, unchanged from 0001410578-24-001264:mdna:17]

[0001410578-25-000100:mdna:17]
Selling, general and administrative (SG&A) expenses were $58.8 million (23.8% of net sales) for the first quarter of 2025, compared with $54.0 million (24.7% of net sales) for the first quarter of 2024. The increase in SG&A in the first quarter of 2025 compared to the first quarter of 2024 was due to an increase within all three business segments mainly due to higher sales, inflationary impacts, R&D expenses and commission expenses.

[0001410578-25-000100:mdna:18]
[same as prior period, unchanged from 0001410578-24-001264:mdna:19]

[0001410578-25-000100:mdna:19]
Amortization of intangible assets was $8.0 million and $7.9 million for the first quarter of 2025 and 2024, respectively. Amortization expenses consist of amortization of acquired intangible assets from acquisitions and other identifiable intangible assets (primarily software). The increase in amortization expense in the first quarter of 2025 compared to the first quarter of 2024 was mainly due to an increase in amortization of capitalized software and amortization of intangible assets related to the MPE acquisition.

[0001410578-25-000100:mdna:20]
OTHER (INCOME) EXPENSES, NET

[0001410578-25-000100:mdna:21]
Other (income), net, was ($0.6) million in the first quarter of 2025 compared to other expenses, net, of $0.2 million in the first quarter of 2024. There were no individually significant items in other (income) expenses, net, in the first quarter of 2025 or 2024.

[0001410578-25-000100:mdna:22]
[same as prior period, unchanged from 0001410578-24-001264:mdna:23]

[0001410578-25-000100:mdna:23]
The Company evaluates the performance of its operating segments based on EBIT, and provides EBIT on a consolidated basis, which is a non-GAAP financial measure. Please refer to the discussion of non-GAAP financial measures in Note 7 to the Consolidated Financial Statements, above. EBIT was $32.2 million (13.0% of net sales) for the first quarter of 2025 compared to $22.1 million (10.1% of net sales) for the first quarter of 2024.

[0001410578-25-000100:mdna:24]
The following table presents a reconciliation of EBIT to a GAAP financial measure:

[0001410578-25-000100:mdna:25]
| ​ | ​ | Three Months Ended |
| ​ | ​ | December 31, |
| (In thousands) |  | 2024 |  | 2023 |
| Net earnings | ​ | $ | 23,473 | ​ | ​ | 15,169 |
| Plus: Interest expense, net | ​ | ​ | 2,257 | ​ | ​ | 2,667 |
| Plus: Income tax expense | ​ | ​ | 6,468 | ​ | ​ | 4,285 |
| Consolidated EBIT | ​ | $ | 32,198 | ​ | ​ | 22,121 |

[0001410578-25-000100:mdna:26]
-A&D

[0001410578-25-000100:mdna:27]
EBIT was $21.6 million (18.9% of net sales) in the first quarter of 2025 compared to $16.7 million (17.6% of net sales) in the first quarter of 2024. The increase in EBIT in the first quarter of 2025 compared to the first quarter of 2024 was mainly due to higher sales volumes at Crissair, PTI, VACCO and Globe as mentioned above and price increases, partially offset by inflationary pressures and mix.

[0001410578-25-000100:mdna:28]
[same as prior period, unchanged from 0001410578-24-001264:mdna:29]

[0001410578-25-000100:mdna:29]
EBIT was $20.5 million (23.6% of net sales) in the first quarter of 2025 compared to $17.6 million (21.2% of net sales) in the first quarter of 2024. The increase in EBIT in the first quarter of 2025 compared to the first quarter of 2024 was mainly due to the higher sales volumes at Doble in the first quarter of 2025, price increases, and mix, partially offset by inflationary pressures.

[0001410578-25-000100:mdna:30]
[same as prior period, unchanged from 0001410578-24-001264:mdna:31]

[0001410578-25-000100:mdna:31]
EBIT was $4.4 million (9.6% of net sales) in the first quarter of 2025 compared to $1.8 million (4.4% of net sales) in the first quarter of 2024. The increase in EBIT in the first quarter of 2025 compared to the first quarter of 2024 was primarily driven by the higher sales volumes from the segment’s European and Asian operations, price increases, and cost reduction efforts, partially offset by inflationary pressures and mix. In addition, EBIT in the first quarter of 2025 was negatively impacted by $0.4 million of restructuring charges (primarily severance).

[0001410578-25-000100:mdna:32]
[same as prior period, unchanged from 0001410578-24-001264:mdna:33]

[0001410578-25-000100:mdna:33]
Corporate costs included in EBIT were $14.3 million and $13.9 million in the first quarter of 2025 and 2024, respectively. The increase in Corporate costs in the first quarter of 2025 compared to the first quarter of 2024 was mainly due to an increase in share based compensation costs and acquisition costs.

[0001410578-25-000100:mdna:34]
[same as prior period, unchanged from 0001410578-24-001264:mdna:35]

[0001410578-25-000100:mdna:35]
Interest expense was $2.3 million and $2.7 million in the first quarter of 2025 and 2024, respectively. The decrease in interest expense in the first quarter of 2025 as compared to the first quarter of 2024 was mainly due to lower average outstanding borrowings and lower average interest rates (6.1% in the first quarter of 2025 compared to 6.8% in the first quarter of 2024).

[0001410578-25-000100:mdna:36]
[same as prior period, unchanged from 0001410578-24-001264:mdna:37]

[0001410578-25-000100:mdna:37]
The effective income tax rate was 21.6% in the first quarter of 2025 compared to 22.0% in the first quarter of 2024. Income tax expense in the first quarter of 2025 was favorably impacted by additional tax benefits related to the vesting of share-based compensation awards.

[0001410578-25-000100:mdna:38]
[same as prior period, unchanged from 0001410578-24-001264:mdna:39]

[0001410578-25-000100:mdna:39]
The Company’s overall financial position and liquidity remain strong. Working capital (current assets less current liabilities) increased to $329.4 million at December 31, 2024 from $318.8 million at September 30, 2024. Accounts receivable decreased $38.0 million during this period mainly due to a $19.9 million decrease within the A&D segment, an $11.8 million decrease within the Test segment and a $6.3 million decrease within the USG segment due to strong cash collections during the quarter. Inventories increased $10.2 million during this period mainly due to a $7.9 million increase within the USG segment and a $2.5 million increase within the A&D segment primarily from an increase in finished goods and raw materials inventories due to timing of manufacturing existing orders. Accrued salaries decreased by $7.7 million during this period due to timing of salaries and bonus payments.

[0001410578-25-000100:mdna:40]
Net cash provided by operating activities was $34.2 million and $8.7 million in the first quarters of 2025 and 2024, respectively. The increase in net cash provided by operating activities in the first quarter of 2025 as compared to the first quarter of 2024 was mainly driven by an increase in net earnings and lower accounts receivable balances due to timing of collections.

[0001410578-25-000100:mdna:41]
Capital expenditures were $5.2 million and $7.8 million in the first quarters of 2025 and 2024, respectively. The decrease in the first quarter of 2025 was mainly due to a decrease in building improvements and machinery & equipment within the A&D segment. In addition, the Company incurred expenditures for capitalized software of approximately $2.6 million and $2.9 million in the first quarters of 2025 and 2024, respectively.

[0001410578-25-000100:mdna:42]
Credit Facility

[0001410578-25-000100:mdna:43]
At December 31, 2024, the Company had approximately $383 million available to borrow under its bank credit facility, excluding the Incremental Facility, plus a $250 million increase option, and $71.3 million cash on hand. At December 31, 2024, the Company had $112 million of outstanding borrowings under the credit facility in addition to outstanding letters of credit of $4.8 million. Cash flow from operations and borrowings under the Company’s credit facility are expected to meet the Company’s capital requirements and operational needs for the foreseeable future. The Company’s ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.

[0001410578-25-000100:mdna:44]
SM&P Acquisition

[0001410578-25-000100:mdna:45]
On July 8, 2024, the Company and certain of its wholly owned subsidiaries entered into a Sale and Purchase Agreement with Ultra Electronics Holdings Limited, a private limited liability company incorporated in England & Wales (“Ultra”), pursuant to which one or more wholly owned subsidiaries of the Company will acquire from Ultra or its subsidiaries Ultra’s Signature Management & Power (“SM&P”) business, including all of the issued and outstanding equity interests of (i) Ultra PMES Limited, a private limited liability company incorporated in England & Wales (“the UK Target Company”), (ii) Measurement Systems, Inc., a Delaware corporation, (iii) EMS Development Corporation, a New York corporation, and (iv) DNE Technologies, a Delaware corporation, for a purchase price of approximately $550 million, plus or minus certain customary adjustments at closing and post-closing for cash, debt, working capital and transaction expenses as specified in the Purchase Agreement (the “SM&P Acquisition”). The closing of the SM&P acquisition is subject to certain conditions, including receipt of clearance under the UK National Security and Investment Act of 2021. We currently expect to close on this transaction either in our second quarter or early in our third fiscal quarter.

[0001410578-25-000100:mdna:46]
[same as prior period, unchanged from 0001410578-24-001264:mdna:52]

[0001410578-25-000100:mdna:47]
A dividend of $0.08 per share, totaling $2.1 million, was paid on October 16, 2024 to stockholders of record as of October 2, 2024. Subsequent to December 31, 2024, a quarterly dividend of $0.08 per share, totaling $2.1 million, was paid on January 17, 2025 to stockholders of record as of January 2, 2025.

[0001410578-25-000100:mdna:48]
[same as prior period, unchanged from 0001410578-24-001264:mdna:54]

[0001410578-25-000100:mdna:49]
Management has evaluated the accounting policies used in the preparation of the Company’s financial statements and related notes and believes those policies to be reasonable and appropriate. Certain of these accounting policies require the application of significant judgment by Management in selecting appropriate assumptions for calculating financial estimates. By their nature, these judgments

[0001410578-25-000100:mdna:50]
are subject to an inherent degree of uncertainty. These judgments are based on historical experience, trends in the industry, information provided by customers and information available from other outside sources, as appropriate. The most significant areas involving Management judgments and estimates may be found in the Critical Accounting Policies section of Management’s Discussion and Analysis and in Note 1 to the Consolidated Financial Statements contained in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2024.

[0001410578-25-000100:mdna:51]
[same as prior period, unchanged from 0001410578-24-001264:mdna:56]

[0001410578-25-000100:mdna:52]
Contingencies

[0001410578-25-000100:mdna:53]
As a normal incident of the business in which the Company is engaged, various claims, charges and litigation are asserted or commenced against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. In the opinion of Management, the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company, are adequately reserved, are covered by insurance, or would not have a material adverse effect on the Company’s results from operations, capital expenditures, or competitive position.

[0001410578-25-000100:mdna:54]
[same as prior period, unchanged from 0001410578-24-001264:mdna:59]

[0001410578-25-000100:mdna:55]
Investors are cautioned that such statements are only predictions and speak only as of the date of this Form 10-Q, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment, including but not limited to those described in Item 1A, “Risk Factors,” of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2024, and the following: the impacts of climate change and related regulation of greenhouse gases; the impacts of labor disputes, civil disorder, wars, elections, political changes, tariffs and trade disputes, terrorist activities, cyberattacks or natural disasters on the Company’s operations and those of the Company’s customers and suppliers; disruptions in manufacturing or delivery arrangements due to shortages or unavailability of materials or components; or supply chain disruptions; inability to access work sites; the timing and content of future contract awards or customer orders; the timely appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer contracts or orders; weakening of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties or data breaches; the availability of selected acquisitions; delivery delays or defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability of certain raw materials; material changes in the cost of credit; changes in laws and regulations including but not limited to changes in accounting standards and taxation; changes in interest rates; costs relating to environmental matters arising from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the integration and performance of recently acquired businesses.
