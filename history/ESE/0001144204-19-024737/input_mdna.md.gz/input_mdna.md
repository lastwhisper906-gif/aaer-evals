# ESE MD&A — 0001144204-19-024737


## mdna

[0001144204-19-024737:mdna:1]
[same as prior period, unchanged from 0001144204-19-006206:mdna:1]

[0001144204-19-024737:mdna:2]
[same as prior period, unchanged from 0001144204-19-006206:mdna:2]

[0001144204-19-024737:mdna:3]
References to the second quarters of 2019 and 2018 represent
the three-month periods ended March 31, 2019 and 2018, respectively.

[0001144204-19-024737:mdna:4]
[same as prior period, unchanged from 0001144204-19-006206:mdna:6]

[0001144204-19-024737:mdna:5]
In the second quarter of 2019, sales, net earnings and diluted
earnings per share were $193.9 million, $18.8 million and $0.72 per share, respectively, compared to $174.8 million, $10.0 million
and $0.38 per share, respectively, in the second quarter of 2018. In the first six months of 2019, sales, net earnings and diluted
earnings per share were $376.5 million, $36.1 million and $1.38, respectively, compared to $348.3 million, $44.7 million and $1.72
per share, respectively, in the first six months of 2018.

[0001144204-19-024737:mdna:6]
[same as prior period, unchanged from 0001144204-19-006206:mdna:8]

[0001144204-19-024737:mdna:7]
In the second quarter of 2019, net sales of $193.9 million were
$19.1 million, or 10.9%, higher than the $174.8 million in the second quarter of 2018. In the first six months of 2019, net sales
of $376.5 million were $28.2 million, or 8.1%, higher than the $348.3 million in the first six months of 2018. The increase in
net sales in the second quarter of 2019 as compared to the second quarter of 2018 was due to a $13.7 million increase in the Filtration
segment, a $2.2 million increase in the USG segment, a $2.1 million increase in the Test segment and a $1.2 million increase in
the Technical Packaging segment. The increase in net sales in the first six months of 2019 as compared to the first six months
of 2018 was due to a $19.9 million increase in the Filtration segment, a $2.3 million increase in the USG segment, a $5.8 million
increase in the Test segment and a $0.3 million increase in the Technical Packaging segment.

[0001144204-19-024737:mdna:8]
[same as prior period, unchanged from 0001144204-19-006206:mdna:10]

[0001144204-19-024737:mdna:9]
In the second quarter of 2019, net sales of $79.5 million were
$13.7 million, or 20.8%, higher than the $65.8 million in the second quarter of 2018. In the first six months of 2019, net sales
of $145.7 million were $19.9 million, or 15.8%, higher than the $125.8 million in the first six months of 2018. The increase in
the second quarter of 2019 compared to the second quarter of 2018 was mainly due to a $4.8 million increase in net sales at Crissair
due to higher aerospace shipments, a $3.5 million increase in net sales at PTI due to higher aerospace assembly and element shipments,
a $2.3 million increase in net sales at VACCO due to higher shipments of defense spares, a $1.8 million increase in net sales at
Mayday due to higher aerospace shipments and a $1.3 million increase in net sales at Westland due to timing of shipments. The increase
in the first six months of 2019 compared to the first six months of 2018 was primarily due to an $8.0 million increase in net sales
at Crissair due to higher aerospace shipments, a $5.0 million increase in net sales at PTI due to higher aerospace assembly and
element shipments, a $3.6 million increase in net sales at Westland due to timing of shipments on government programs and a $3.3
million increase in net sales at Mayday due to higher aerospace shipments.

[0001144204-19-024737:mdna:10]
[same as prior period, unchanged from 0001144204-19-006206:mdna:12]

[0001144204-19-024737:mdna:11]
In the second quarter of 2019, net sales of $42.9 million were
$2.1 million, or 5.1%, higher than the $40.8 million in the second quarter of 2018. In the first six months of 2019, net sales
of $84.2 million were $5.9 million, or 7.5%, higher than the $78.3 million in the first six months of 2018. The increase in the
second quarter and first six months of 2019 compared to the corresponding periods of 2018 was primarily due to higher sales from
the segment’s U.S. operations due to the timing of test and measurement chamber projects.

[0001144204-19-024737:mdna:12]
[same as prior period, unchanged from 0001144204-19-006206:mdna:14]

[0001144204-19-024737:mdna:13]
In the second quarter of 2019, net sales of $48.9 million were
$2.2 million, or 4.7%, higher than the $46.7 million in the second quarter of 2018. In the first six months of 2019, net sales
of $104.7 million were $2.3 million, or 2.2%, higher than the $102.5 million in the first six months of 2018. The increase in the
second quarter and first six months of 2019 compared to the corresponding periods of 2018 was mainly due to the sales contributions
from the Vanguard Instruments and Manta product lines and new products and software solutions at Doble.

[0001144204-19-024737:mdna:14]
[same as prior period, unchanged from 0001144204-19-006206:mdna:16]

[0001144204-19-024737:mdna:15]
In the second quarter of 2019, net sales of $22.7 million were
$1.2 million, or 5.6%, higher than the $21.5 million in the second quarter of 2018. In the first six months of 2019, net sales
of $41.9 million were $0.2 million, or 0.6%, higher than the $41.7 million in the first six months of 2018. The increase in the
second quarter and first six months of 2019 compared to the corresponding periods of 2018 was primarily due to the increase in
net sales from TEQ due to increased shipments to new customers.

[0001144204-19-024737:mdna:16]
[same as prior period, unchanged from 0001144204-19-006206:mdna:18]

[0001144204-19-024737:mdna:17]
Backlog was $436.1 million at March 31, 2019 compared with $382.8
million at September 30, 2018. The Company received new orders totaling $231.7 million in the second quarter of 2019 compared to
$187.3 million in the second quarter of 2018. Of the new orders received in the second quarter of 2019, $100.8 million related
to Filtration products, $57.6 million related to Test products, $51.0 million related to USG products, and $22.3 million related
to Technical Packaging products. Of the new orders received in the second quarter of 2018, $67.8 million related to Filtration
products, $48.1 million related to Test products, $52.5 million related to USG products, and $18.9 million related to Technical
Packaging products.

[0001144204-19-024737:mdna:18]
The Company received new orders totaling $429.8 million in the
first six months of 2019 compared to $387.8 million in the first six months of 2018. Of the new orders received in the first six
months of 2019, $184.5 million related to Filtration products, $103.0 million related to Test products, $103.0 million related
to USG products, and $39.3 million related to Technical Packaging products. Of the new orders received in the first six months
of 2018, $133.2 million related to Filtration products, $106.4 million related to Test products, $110.1 million related to USG
products, and $38.1 million related to Technical Packaging products.

[0001144204-19-024737:mdna:19]
[same as prior period, unchanged from 0001144204-19-006206:mdna:20]

[0001144204-19-024737:mdna:20]
Selling, general and administrative (SG&A) expenses for
the second quarter of 2019 were $41.7 million (21.5% of net sales), compared with $40.7 million (23.3% of net sales) for the second
quarter of 2018. For the first six months of 2019, SG&A expenses were $82.7 million (22.0% of net sales) compared to $82.9
million (23.8% of net sales) for the first six months of 2018. The increase in SG&A in the second quarter and first six months
of 2019 compared to the corresponding periods of 2018 was mainly due to an increase in the USG segment due to the Company’s
recent acquisitions (Manta) and additional sales and marketing expenses to support future revenue growth.

[0001144204-19-024737:mdna:21]
[same as prior period, unchanged from 0001144204-19-006206:mdna:23]

[0001144204-19-024737:mdna:22]
Amortization of intangible assets was $4.6 million and $9.3
million for the second quarter and first six months of 2019, respectively, compared to $4.6 million and $9.0 million for the corresponding
periods of 2018. Amortization expenses consist of amortization of acquired intangible assets from acquisitions and other identifiable
intangible assets (primarily software). The increase in amortization expense in the first six months of 2019 compared to the first
six months of 2018 was mainly due to an increase in amortization of intangibles related to the Manta acquisition.

[0001144204-19-024737:mdna:23]
OTHER EXPENSES (INCOME), NET

[0001144204-19-024737:mdna:24]
Other expenses, net, was $2.4 million in the second quarter
of 2019 compared to $1.5 million in the second quarter of 2018. The principal components in other expenses, net, in the second
quarter of 2019 were $1.3 million of restructuring charges related to the closure of Plastique’s headquarters in Tunbridge
Wells, UK; the consolidation of VACCO’s aircraft/aerospace business into PTI’s aerospace facility in Oxnard, California;
the completion of other restructuring activities begun in 2018; and losses on derivative instruments. The principal components
in other expenses, net, in the second quarter of 2018 were $2.1 million of charges primarily related to the USG segment restructuring
activities, including the Doble facility consolidations, partially offset by gains on derivative instruments. The restructuring
charges mainly related to severance and compensation benefits, professional fees and asset impairment charges related to abandoned
assets.

[0001144204-19-024737:mdna:25]
Other income, net, was $4.7 million in the first six months
of 2019 compared to other expenses, net, of $1.6 million in the first six months of 2018. The principal component in other income,
net, in the first six months of 2019 was a gain of approximately $8 million on the sale of the Doble Watertown, MA building and
land, partially offset by certain restructuring activities at Doble, PTI, VACCO and Plastique and losses on derivative instruments.
The principal components in other expenses, net, in the first six months of 2018 were $2.1 million of charges related to the USG
segment restructuring activities as mentioned above, partially offset by gains on derivative instruments.

[0001144204-19-024737:mdna:26]
[same as prior period, unchanged from 0001144204-19-006206:mdna:27]

[0001144204-19-024737:mdna:27]
The Company evaluates the performance of its operating segments
based on EBIT, and provides EBIT on a consolidated basis, which is a non-GAAP financial measure. Please refer to the discussion
of non-GAAP financial measures in Note 7 to the Consolidated Financial Statements, above. EBIT was $23.3 million (12.0% of net
sales) for the second quarter of 2019 compared to $15.6 million (8.9% of net sales) for the second quarter of 2018. For the first
six months of 2019, EBIT was $48.4 million (12.9% of net sales) compared to $30.6 million (8.8% of net sales) for the first six
months of 2018.

[0001144204-19-024737:mdna:28]
[same as prior period, unchanged from 0001144204-19-006206:mdna:29]

[0001144204-19-024737:mdna:29]
| (In thousands) |  | Three Months Ended March 31, |  |  | Six Months Ended March 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Consolidated EBIT |  | $ | 23,280 |  |  |  | 15,620 |  |  |  | 48,427 |  |  |  | 30,606 |  |
| Less: Interest expense, net |  |  | (1,925 | ) |  |  | (2,036 | ) |  |  | (3,815 | ) |  |  | (4,221 | ) |
| (Less) Plus: Income tax |  |  | (2,558 | ) |  |  | (3,590 | ) |  |  | (8,498 | ) |  |  | 18,280 |  |
| Net earnings |  | $ | 18,797 |  |  |  | 9,994 |  |  |  | 36,114 |  |  |  | 44,665 |  |

[0001144204-19-024737:mdna:30]
[same as prior period, unchanged from 0001144204-19-006206:mdna:31]

[0001144204-19-024737:mdna:31]
EBIT in the second quarter of 2019 was $17.4 million (21.9%
of net sales) compared to $11.1 million (16.9% of net sales) in the second quarter of 2018. EBIT in the first six months of 2019
was $28.1 million (19.3% of net sales) compared to $20.8 million (16.5% of net sales) in the first six months of 2018. The increase
in EBIT in the second quarter compared to the second quarter of 2018 was mainly due to an increase across all companies within
the segment due to the higher sales volumes as mentioned above. The increase in EBIT in the first six months of 2019 compared to
the first six months of 2018 was mainly due to an increase at PTI, Crissair, Westland and Mayday due to the higher sales volumes
as mentioned above partially offset by a decrease in EBIT at VACCO. EBIT in the second quarter and first six months of 2019 was
negatively impacted by restructuring charges incurred related to the consolidation of VACCO’s aircraft/aerospace business
into PTI’s aerospace facility in Oxnard, California, ($0.4 million in the second quarter of 2019 and $0.5 million in the
first six months of 2019). These charges consisted primarily of severance and compensation benefits.

[0001144204-19-024737:mdna:32]
[same as prior period, unchanged from 0001144204-19-006206:mdna:37]

[0001144204-19-024737:mdna:33]
EBIT in the second quarter of 2019 was $5.6 million (13.0% of
net sales) compared to $5.3 million (13.0% of net sales) in the second quarter of 2018. EBIT in the first six months of 2019 was
$8.9 million (10.5% of net sales) compared to $7.9 million (10.1% of net sales) in the first six months of 2018. The increase in
EBIT in the second quarter and first six months of 2019 compared to the corresponding prior year periods was primarily due to the
increased sales volumes mainly from the segment’s U.S. operations.

[0001144204-19-024737:mdna:34]
[same as prior period, unchanged from 0001144204-19-006206:mdna:40]

[0001144204-19-024737:mdna:35]
EBIT in the second quarter of 2019 was $8.8 million (17.9% of
net sales) compared to $5.6 million (12.0% of net sales) in the second quarter of 2018. EBIT in the first six months of 2019 was
$30.3 million (28.9% of net sales) compared to EBIT of $16.3 million (15.9% of net sales) in the first six months of 2018. The
increase in EBIT in the second quarter and first six months of 2019 compared to the corresponding periods of 2018 was mainly due
to the gain on sale of the Doble Watertown facility of approximately $8 million in the first quarter of 2019, as well as an increase
in EBIT from Morgan Schaffer and Manta product lines partially offset by a decrease in EBIT from NRG due to market softness.

[0001144204-19-024737:mdna:36]
[same as prior period, unchanged from 0001144204-19-006206:mdna:44]

[0001144204-19-024737:mdna:37]
EBIT in the second quarter of 2019 was $1.6 million (7.1% of
net sales) compared to $1.9 million (8.8% of net sales) in the second quarter of 2018. EBIT in the first six months of 2019 was
$1.7 million (4.1% of net sales) compared to $2.9 million (6.8% of net sales) in the first six months of 2018. The decrease in
EBIT in the second quarter and first six months of 2019 compared to the corresponding periods of 2018 was mainly due to the restructuring
charges incurred related to the Plastique facility consolidation, ($0.4 million in the second quarter of 2019 and $0.7 million
in the first six months of 2019). These charges consisted primarily of severance and compensation benefits and asset impairment
charges.

[0001144204-19-024737:mdna:38]
[same as prior period, unchanged from 0001144204-19-006206:mdna:46]

[0001144204-19-024737:mdna:39]
Corporate costs included in EBIT were $10.0 million and $20.5
million in the second quarter and first six months of 2019, respectively, compared to $8.3 million and $17.2 million in the corresponding
periods of 2018. The increase in Corporate costs in the second quarter and first six months of 2019 compared to the corresponding
periods of 2018 was primarily due to higher professional fees and timing of other Corporate costs recorded in the first six months
of 2019.

[0001144204-19-024737:mdna:40]
[same as prior period, unchanged from 0001144204-19-006206:mdna:48]

[0001144204-19-024737:mdna:41]
Interest expense was $1.9 million and $3.8 million in the second
quarter and first six months of 2019, respectively, and $2.0 million and $4.2 million in the corresponding periods of 2018. The
decrease in interest expense in the first six months of 2019 compared to the first six months of 2018 was mainly due to lower average
outstanding borrowings ($215 million compared to $264 million).

[0001144204-19-024737:mdna:42]
[same as prior period, unchanged from 0001144204-19-006206:mdna:50]

[0001144204-19-024737:mdna:43]
The second quarter 2019 effective income tax rate was 12.0%
compared to 26.4% in the second quarter of 2018. The income tax expense for the first six months of 2019 was $8.5 million compared
to income tax benefit of $18.3 million for the first six months of 2018. The effective income tax rate for the first six months
of 2019 was 19.0% compared to (69.3%) for the first six months of 2018. The income tax expense in the second quarter and first
six months of 2019 was favorably impacted by tax planning strategies to increase foreign tax credits claimed retrospectively. The
Company reduced the valuation allowance for excess foreign tax credits by $2.3 million and recorded an amended return receivable
of $0.2 million which favorably impacted the second quarter and year-to-date effective tax rate by 12.1% and 5.8%, respectively.

[0001144204-19-024737:mdna:44]
H.R. 1, Tax Cuts and Jobs Act (“TCJA”), was
signed into law on December 22, 2017. The total impact of the TCJA in the second quarter and first six months of 2018 was a net
expense of $0.7 million and a net benefit of $24.4 million, respectively. The impacts were as follows: First, the Company’s
2018 federal statutory rate dropped from 35.0% to 24.5% which required an adjustment to the value of its deferred tax assets and
liabilities. This adjustment ($30.3 million provisional amount recorded in Q1) favorably impacted the year-to-date 2018 effective
tax rate by 114.9%. Second, the TCJA subjected the Company’s cumulative foreign earnings to federal income tax ($3.6 million
provisional amount of which $2.9 million was recorded in the first quarter of 2018 and $0.7 million was recorded in the second
quarter of 2018) which unfavorably impacted the second quarter and year-to-date 2018 effective tax rate by 4.9% and 13.6%, respectively.

[0001144204-19-024737:mdna:45]
In the first quarter of 2018, the Company recorded a $2.3 million
provisional estimate of the income tax effects of the future repatriation of the cumulative earnings of its foreign subsidiaries
which unfavorably impacted the year-to-date effective tax rate by 8.9%. An additional $7.5 million pension contribution for the
2017 plan year was approved during the second quarter of 2018 increasing the value of the deferred tax liability by $1.0 million.
This favorable adjustment, net of the $0.3 million unfavorable impact to the 2017 Domestic Production Deduction, favorably impacted
the second quarter and year-to-date effective tax rate by 5.8% and 3.0%, respectively. The income tax expense in the second quarter
and first six months of 2018 was also unfavorably impacted by the cancellation of debt income triggered by the dissolution of a
foreign subsidiary increasing the second quarter and year-to-date effective tax rate by 1.5% and 0.8%, respectively.

[0001144204-19-024737:mdna:46]
Provisions under the TCJA that became effective for the Company
in the current fiscal year include a further reduction in the U.S. statutory rate to 21%, a new minimum tax on global intangible
low-taxed income (“GILTI”), the benefit of the deduction for foreign-derived intangible income (“FDII”),
and changes to IRC Section 162(m) related to the deductibility of executive compensation.

[0001144204-19-024737:mdna:47]
[same as prior period, unchanged from 0001144204-19-006206:mdna:60]

[0001144204-19-024737:mdna:48]
The Company’s overall financial position and liquidity
remains strong. Working capital (current assets less current liabilities) increased to $234.0 million at March 31, 2019 from $195.5
million at September 30, 2018. Inventories decreased by $10.9 million during this period mainly due to a $12.9 million decrease
within the Filtration segment resulting primarily from the adoption of ASU No. 2014-09, Revenue from Contracts with Customers
(ASC 606). Contract assets increased $47.5 million in the first six months of 2019 mainly due to the adoption of ASC 606 within
the Filtration segment.

[0001144204-19-024737:mdna:49]
Net cash provided by operating activities was $17.0 million
and $33.5 million in the first six months of 2019 and 2018, respectively. The decrease in net cash provided by operating activities
in the first six months of 2019 as compared to the first six months of 2018 was due to higher working capital requirements.

[0001144204-19-024737:mdna:50]
Capital expenditures were $17.4 million and $10.1 million in
the first six months of 2019 and 2018, respectively. The increase in the first six months of 2019 was mainly due to a $7.1 million
facility expansion at TEQ. In addition, the Company incurred expenditures for capitalized software of $4.5 million and $4.6 million
in the first six months of 2019 and 2018, respectively.

[0001144204-19-024737:mdna:51]
Credit Facility

[0001144204-19-024737:mdna:52]
At March 31, 2019, the Company had approximately $207.0 million
available to borrow under its bank credit facility, a $250 million increase option, and $35.0 million cash on hand. At March 31,
2019, the Company had $217.0 million of outstanding borrowings under the credit facility in addition to outstanding letters of
credit of $8.3 million. Cash flow from operations and borrowings under the Company’s credit facility are expected to meet
the Company’s capital requirements and operational needs for the foreseeable future. The Company’s ability to access
the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.

[0001144204-19-024737:mdna:53]
[same as prior period, unchanged from 0001144204-19-006206:mdna:66]

[0001144204-19-024737:mdna:54]
In February 2016, the FASB issued ASU No. 2016-062, Leases
(Topic 842), which, among other things, requires an entity to recognize lease assets and lease liabilities on the balance sheet
and disclose key information about leasing arrangements. This standard will increase an entities’ reported assets and liabilities.
The standard is effective for fiscal years beginning after December 15, 2018 and mandates a modified retrospective transition period
for all entities. The Company is currently assessing the impact of this standard on its consolidated financial statements and related
disclosures.

[0001144204-19-024737:mdna:55]
In October 2016, the FASB issued ASU No. 2016-16, Intra-Entity
Transfers of Assets Other Than Inventory, which eliminates the exception for all intra-entity sale of assets other than inventory.
This standard is effective for annual periods beginning after December 15, 2017. There was no significant impact to the Company’s
consolidated financial statements as a result of adopting this new standard.

[0001144204-19-024737:mdna:56]
[same as prior period, unchanged from 0001144204-19-006206:mdna:69]

[0001144204-19-024737:mdna:57]
A dividend of $0.08 per share, totaling $2.1 million, was paid
on October 17, 2018 to stockholders of record as of October 3, 2018. A dividend of $0.08 per share, totaling $2.1 million, was paid
on January 18, 2019 to stockholders of record as of January 3, 2019. Subsequent to March 31, 2019, a quarterly dividend of $0.08
per share, totaling $2.1 million, was paid on April 18, 2019 to stockholders of record as of April 3, 2019.

[0001144204-19-024737:mdna:58]
[same as prior period, unchanged from 0001144204-19-006206:mdna:71]

[0001144204-19-024737:mdna:59]
As a result of the Company’s year-to-date performance
and its improved outlook for the remainder of the year, Management is raising its 2019 Adjusted EPS guidance to $3.05 to $3.10
per share from its earlier expectations of $2.95 to $3.05 per share. Management is excluding the following expected adjustments
to 2019 GAAP EPS: A pre-tax gain from the October 2018 sale of Doble’s headquarters building in Watertown, Massachusetts;
and pre-tax costs related to the relocation of Doble’s headquarters, the closure of Plastique’s headquarters in Tunbridge
Wells, UK and the consolidation of its product design and administrative functions into its facilities in Nottingham, UK and Poznan,
Poland; the consolidation of VACCO’s aircraft/aerospace business into PTI’s aerospace facility in Oxnard, California;
and the completion of other restructuring activities begun in 2018. Management expects the 2019 third quarter Adjusted EPS to
be in the range of $0.75 to $0.80.

[0001144204-19-024737:mdna:60]
[same as prior period, unchanged from 0001144204-19-006206:mdna:74]

[0001144204-19-024737:mdna:61]
Management has evaluated the accounting policies used in the
preparation of the Company’s financial statements and related notes and believes those policies to be reasonable and appropriate.
Certain of these accounting policies require the application of significant judgment by management in selecting appropriate assumptions
for calculating financial estimates. By their nature, these judgments are subject to an inherent degree of uncertainty. These judgments
are based on historical experience, trends in the industry, information provided by customers and information available from other
outside sources, as appropriate. The most significant areas involving management judgments and estimates may be found in the Critical
Accounting Policies section of Management’s Discussion and Analysis and in Note 1 to the Consolidated Financial Statements
contained in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2018.

[0001144204-19-024737:mdna:62]
[same as prior period, unchanged from 0001144204-19-006206:mdna:76]

[0001144204-19-024737:mdna:63]
Contingencies

[0001144204-19-024737:mdna:64]
As a normal incident of the business in which the Company is
engaged, various claims, charges and litigation are asserted or commenced against the Company. Additionally, the Company is currently
involved in various stages of investigation and remediation relating to environmental matters. In the opinion of management, the
aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company,
are adequately reserved, are covered by insurance, or would not have a material adverse effect on the Company’s results from
operations, capital expenditures, or competitive position.

[0001144204-19-024737:mdna:65]
[same as prior period, unchanged from 0001144204-19-006206:mdna:79]

[0001144204-19-024737:mdna:66]
Investors are cautioned that such statements are only predictions
and speak only as of the date of this Form 10-Q, and the Company undertakes no duty to update them except as may be required by
applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in
the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment,
including but not limited to those described in Item 1A, “Risk Factors,” of the Company’s Annual Report on Form
10-K for the fiscal year ended September 30, 2018, and the following: the impacts of natural disasters on the Company’s operations
and those of the Company’s customers and suppliers; the timing and content of future contract awards or customer orders;
the appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer
contracts or orders; financial exposure in connection with Company guarantees of certain Aclara contracts; weakening of economic
conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies;
competition; intellectual property rights; technical difficulties; the availability of selected acquisitions; delivery delays or
defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability
of certain raw materials; labor disputes; changes in U.S. tax laws and regulations; other changes in laws and regulations including
but not limited to changes in accounting standards and foreign taxation; changes in interest rates; costs relating to environmental
matters arising from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation
or arbitration; and the integration of recently acquired businesses.
