# ESE note change history — 0001144204-19-006206 → 0001144204-19-024737


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-05-09):
[0001144204-19-024737:note_history:1]
The Company’s results for the three and six-month periods ended March 31, 2019 are not necessarily indicative of the results for the entire 2019 fiscal year. References to the second quarters of 2019 and 2018 represent the fiscal quarters ended March 31, 2019 and 2018, respectively.
  (was, 2019-02-11, similarity 0.8837):
[0001144204-19-006206:note_history:1]
The Company’s results for the three-month period ended December 31, 2018 are not necessarily indicative of the results for the entire 2019 fiscal year. References to the first quarters of 2019 and 2018 represent the fiscal quarters ended December 31, 2018 and 2017, respectively.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-05-09):
[0001144204-19-024737:note_history:2]
. Significant changes to our policies resulting from the adoption are provided below. We adopted ASC 606 using the modified retrospective transition method applied to contracts that were not substantially complete at the end of fiscal year 2018. We recorded a $4.2 million adjustment to increase retained earnings to reflect the cumulative impact of adopting this standard at the beginning of fiscal year 2019, primarily related to certain long-term contracts our Filtration and Technical Packaging segments have that converted to the cost-to-cost method for revenue recognition. The comparative information has not been restated and is reported under the accounting standards in effect for those periods. A reconciliation of the financial statement line items impacted for the three and six months ended March 31, 2019 under ASC 606 to the prior accounting standards is provided in Note 14.
  (was, 2019-02-11, similarity 0.9729):
[0001144204-19-006206:note_history:2]
. Significant changes to our policies resulting from the adoption are provided below. We adopted ASC 606 using the modified retrospective transition method applied to contracts that were not substantially complete at the end of fiscal year 2018. We recorded a $5.5 million adjustment to increase retained earnings to reflect the cumulative impact of adopting this standard at the beginning of fiscal year 2019, primarily related to certain long-term contracts our Filtration and Technical Packaging segments have that converted to the cost-to-cost method for revenue recognition. The comparative information has not been restated and is reported under the accounting standards in effect for those periods. A reconciliation of the financial statement line items impacted for the three months ended December 31, 2018 under ASC 606 to the prior accounting standards is provided in Note 14.

- added (2019-05-09):
[0001144204-19-024737:note_history:3]
Approximately

- added (2019-05-09):
[0001144204-19-024737:note_history:4]
52

- changed (2019-05-09):
[0001144204-19-024737:note_history:5]
% of the segment’s revenues (approximately
  (was, 2019-02-11, similarity 0.6372):
[0001144204-19-006206:note_history:5]
Within the Test segment, approximately 25% of revenues (approximately 6%

- added (2019-05-09):
[0001144204-19-024737:note_history:6]
19

- added (2019-05-09):
[0001144204-19-024737:note_history:7]
% of consolidated revenues)

- changed (2019-05-09):
[0001144204-19-024737:note_history:8]
are accounted for over time as the product does not have an alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin or the inventory is owned by the customer. The related contracts are primarily cost-plus or fixed price contracts related to the design, development and manufacture of complex fluid control products, quiet valves, manifolds, shock and vibration dampening, thermal insulation and systems primarily for the commercial aerospace and military (U.S. Government) markets. The contracts may contain multiple products, which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. Our contracts are frequently modified for changes in contract specifications and requirements. Most of our contract modifications are for products that are not distinct from the existing contract and are accounted for as part of that existing contract.
  (was, 2019-02-11, similarity 0.9225):
[0001144204-19-006206:note_history:8]
Approximately 52% of the segment’s revenues (approximately 19% 
of consolidated revenues) are accounted for over time as the products do not have alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin or the inventory is owned by the customer. The related contracts are primarily cost-plus or fixed price contracts related to the design, development and manufacture of complex fluid control products, quiet valves, manifolds, shock and vibration dampening, thermal insulation and systems primarily for the commercial aerospace and military (U.S. Government) markets. The contracts may contain multiple products, which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. Our contracts are frequently modified for changes in contract specifications and requirements. Most of our contract modifications are for products that are not distinct from the existing contract and are accounted for as part of that existing contract.

- changed (2019-05-09):
[0001144204-19-024737:note_history:9]
Within the Test segment, approximately 25% of revenues (approximately 6% of consolidated revenues) are recognized at a point in time when products such as, antennas and probes are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.
  (was, 2019-02-11, similarity 0.9905):
[0001144204-19-006206:note_history:9]
:
 Within the USG segment, approximately 80% of revenues (approximately 24% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

- added (2019-05-09):
[0001144204-19-024737:note_history:10]
:

- changed (2019-05-09):
[0001144204-19-024737:note_history:11]
Within the USG segment, approximately 80% of revenues (approximately 24% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.
  (was, 2019-02-11, similarity 0.94):
[0001144204-19-006206:note_history:11]
of consolidated revenues) are recognized at a point in time when products such as, antennas and probes are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

- changed (2019-05-09):
[0001144204-19-024737:note_history:12]
Within the Technical Packaging segment, 100% of the revenues (approximately 10% of consolidated revenues) are recognized over time as the product does not have an alternative use and the Company has an enforceable right to payment. Selecting the method to measure progress towards completion for the contracts requires judgment and is based on the nature of the products to be provided. We use the cost-to-cost method to measure progress for our Technical Packaging segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. Under this measure, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and revenue is recorded proportionally as costs are incurred. The transaction price for our contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant.
  (was, 2019-02-11, similarity 0.9745):
[0001144204-19-006206:note_history:12]
Within the Technical Packaging segment, 
100
% of the revenues (approximately 10% of consolidated revenues) are recognized over time as the product does not have an alternative use and the Company has an enforceable right to payment. Selecting the method to measure progress towards completion for the contracts requires judgment and is based on the nature of the products to be provided. We use the cost-to-cost method to measure progress for our Technical Packaging segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. Under this measure, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and revenue is recorded proportionally as costs are incurred. The transaction price for our contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-09):
[0001144204-19-024737:note_history:13]
| (In thousands) |  | March 31,2019 |  |  | September 30, 2018 |  |
| Total borrowings |  | $ | 217,000 |  |  |  | 220,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000 | ) |  |  | (20,000 | ) |
| Total long-term debt, less current portion |  | $ | 197,000 |  |  |  | 200,000 |  |
  (was, 2019-02-11, similarity 0.9785):
[0001144204-19-006206:note_history:13]
| (In thousands) |  | December 31,2018 |  |  | September 30, 2018 |  |
| Total borrowings |  | $ | 215,273 |  |  |  | 220,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,273 | ) |  |  | (20,000 | ) |
| Total long-term debt, less current portion |  | $ | 195,000 |  |  |  | 200,000 |  |

- changed (2019-05-09):
[0001144204-19-024737:note_history:14]
At March 31, 2019, the Company had approximately $207.0 million available to borrow under the Credit Facility, and a $250 million increase option, in addition to $35.0 million cash on hand. At March 31, 2019, the Company had $217.0 million of outstanding borrowings under the Credit Facility in addition to outstanding letters of credit of $8.3 million. The Company classified $20.0 million as the current portion of long-term debt as of March 31, 2019, as the Company intends to repay this amount within the next twelve month period; however, the Company has no contractual obligation to repay such amount during the next twelve month period.
  (was, 2019-02-11, similarity 0.9472):
[0001144204-19-006206:note_history:14]
At December 31, 2018, the Company had approximately $209 million available to borrow under the Credit Facility, and a $250 million increase option subject to lender approval, in addition to $36.6 million cash on hand. At December 31, 2018, the Company had $215 million of outstanding borrowings under the Credit Facility in addition to outstanding letters of credit of $8.2 million. The Company classified $20.0 million as the current portion of long-term debt as of December 31, 2018, as the Company intends to repay this amount within the next twelve month period; however, the Company has no contractual obligation to repay such amount during the next twelve month period.

- changed (2019-05-09):
[0001144204-19-024737:note_history:15]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from 12.5 to 27.5 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a 65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 3.20% and 3.23% for the three and six-month periods ending March 31, 2019, respectively, and 2.99% and 2.87% for the corresponding periods of 2018. At March 31, 2019, the Company was in compliance with all debt covenants.
  (was, 2019-02-11, similarity 0.9378):
[0001144204-19-006206:note_history:15]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from 12.5 to 27.5 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a 65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 3.25% and 2.74% for the three-month periods ending December 31, 2018 and 2017, respectively. At December 31, 2018, the Company was in compliance with all debt covenants.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-09):
[0001144204-19-024737:note_history:16]
| (In thousands) |  | March 31,2019 |  |  | September 30, 2018 |  |
| Total borrowings |  | $ | 217,000 |  |  |  | 220,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000 | ) |  |  | (20,000 | ) |
| Total long-term debt, less current portion |  | $ | 197,000 |  |  |  | 200,000 |  |
  (was, 2019-02-11, similarity 0.9785):
[0001144204-19-006206:note_history:16]
| (In thousands) |  | December 31,2018 |  |  | September 30, 2018 |  |
| Total borrowings |  | $ | 215,273 |  |  |  | 220,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,273 | ) |  |  | (20,000 | ) |
| Total long-term debt, less current portion |  | $ | 195,000 |  |  |  | 200,000 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-05-09):
[0001144204-19-024737:note_history:17]
Our revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2019 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within our reportable segments.
  (was, 2019-02-11, similarity 0.9569):
[0001144204-19-006206:note_history:17]
Our revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2018 
are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within our reportable segments.

- changed (2019-05-09):
[0001144204-19-024737:note_history:18]
| Three Months Ended March 31, 2019(In thousands) |  | Filtration |  |  | Test |  |  | USG |  |  | Technical Packaging |  |  | Total |  |
| Customer type: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial |  | $ | 46,325 |  |  | $ | 37,451 |  |  | $ | 47,551 |  |  | $ | 22,630 |  |  | $ | 153,957 |  |
| Government |  |  | 33,153 |  |  |  | 5,424 |  |  |  | 1,339 |  |  |  | 76 |  |  |  | 39,992 |  |
| Total revenues |  | $ | 79,478 |  |  | $ | 42,875 |  |  | $ | 48,890 |  |  | $ | 22,706 |  |  | $ | 193,949 |  |
| Geographic location: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 66,068 |  |  | $ | 26,694 |  |  | $ | 33,798 |  |  | $ | 11,457 |  |  | $ | 138,017 |  |
| International |  |  | 13,410 |  |  |  | 16,181 |  |  |  | 15,092 |  |  |  | 11,249 |  |  |  | 55,932 |  |
| Total revenues |  | $ | 79,478 |  |  | $ | 42,875 |  |  | $ | 48,890 |  |  | $ | 22,706 |  |  | $ | 193,949 |  |
| Revenue recognition method: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Point in time |  | $ | 42,400 |  |  | $ | 12,166 |  |  | $ | 36,874 |  |  | $ | - |  |  | $ | 91,440 |  |
| Over time |  |  | 37,078 |  |  |  | 30,709 |  |  |  | 12,016 |  |  |  | 22,706 |  |  |  | 102,509 |  |
| Total revenues |  | $ | 79,478 |  |  | $ | 42,875 |  |  | $ | 48,890 |  |  | $ | 22,706 |  |  | $ | 193,949 |  |
  (was, 2019-02-11, similarity 0.9264):
[0001144204-19-006206:note_history:18]
| (In thousands) |  | Filtration |  |  | Test |  |  | USG |  |  | Technical Packaging |  |  | Total |  |
| Customer type: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial |  | $ | 37,523 |  |  | $ | 36,297 |  |  | $ | 54,662 |  |  | $ | 19,114 |  |  | $ | 147,596 |  |
| U.S. Government |  |  | 28,701 |  |  |  | 4,989 |  |  |  | 1,193 |  |  |  | 118 |  |  |  | 35,001 |  |
| Total revenues |  | $ | 66,224 |  |  | $ | 41,286 |  |  | $ | 55,855 |  |  | $ | 19,232 |  |  | $ | 182,597 |  |
| Geographic location: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 54,847 |  |  | $ | 28,453 |  |  | $ | 40,228 |  |  | $ | 9,849 |  |  | $ | 133,377 |  |
| International |  |  | 11,377 |  |  |  | 12,833 |  |  |  | 15,627 |  |  |  | 9,383 |  |  |  | 49,220 |  |
| Total revenues |  | $ | 66,224 |  |  | $ | 41,286 |  |  | $ | 55,855 |  |  | $ | 19,232 |  |  | $ | 182,597 |  |
| Revenue recognition method: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Point in time |  | $ | 32,054 |  |  | $ | 10,382 |  |  | $ | 44,303 |  |  | $ | - |  |  | $ | 86,739 |  |
| Over time |  |  | 34,170 |  |  |  | 30,904 |  |  |  | 11,552 |  |  |  | 19,232 |  |  |  | 95,858 |  |
| Total revenues |  | $ | 66,224 |  |  | $ | 41,286 |  |  | $ | 55,855 |  |  | $ | 19,232 |  |  | $ | 182,597 |  |

- added (2019-05-09):
[0001144204-19-024737:note_history:19]
| Six Months Ended March 31, 2019(In thousands) |  | Filtration |  |  | Test |  |  | USG |  |  | Technical Packaging |  |  | Total |  |
| Customer type: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial |  | $ | 83,546 |  |  | $ | 73,688 |  |  | $ | 102,206 |  |  | $ | 41,744 |  |  | $ | 301,184 |  |
| Government |  |  | 62,156 |  |  |  | 10,473 |  |  |  | 2,539 |  |  |  | 194 |  |  |  | 75,362 |  |
| Total revenues |  | $ | 145,702 |  |  | $ | 84,161 |  |  | $ | 104,745 |  |  | $ | 41,938 |  |  | $ | 376,546 |  |
| Geographic location: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 120,833 |  |  | $ | 55,148 |  |  | $ | 73,879 |  |  | $ | 21,306 |  |  | $ | 271,166 |  |
| International |  |  | 24,869 |  |  |  | 29,013 |  |  |  | 30,866 |  |  |  | 20,632 |  |  |  | 105,380 |  |
| Total revenues |  | $ | 145,702 |  |  | $ | 84,161 |  |  | $ | 104,745 |  |  | $ | 41,938 |  |  | $ | 376,546 |  |
| Revenue recognition method: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Point in time |  | $ | 74,214 |  |  | $ | 22,608 |  |  | $ | 81,107 |  |  | $ | - |  |  | $ | 177,929 |  |
| Over time |  |  | 71,488 |  |  |  | 61,553 |  |  |  | 23,638 |  |  |  | 41,938 |  |  |  | 198,617 |  |
| Total revenues |  | $ | 145,702 |  |  | $ | 84,161 |  |  | $ | 104,745 |  |  | $ | 41,938 |  |  | $ | 376,546 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2019-05-09):
[0001144204-19-024737:note_history:20]
Approximately

- added (2019-05-09):
[0001144204-19-024737:note_history:21]
52

- changed (2019-05-09):
[0001144204-19-024737:note_history:22]
% of the segment’s revenues (approximately
  (was, 2019-02-11, similarity 0.6372):
[0001144204-19-006206:note_history:22]
Within the Test segment, approximately 25% of revenues (approximately 6%

- added (2019-05-09):
[0001144204-19-024737:note_history:23]
19

- added (2019-05-09):
[0001144204-19-024737:note_history:24]
% of consolidated revenues)

- changed (2019-05-09):
[0001144204-19-024737:note_history:25]
are accounted for over time as the product does not have an alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin or the inventory is owned by the customer. The related contracts are primarily cost-plus or fixed price contracts related to the design, development and manufacture of complex fluid control products, quiet valves, manifolds, shock and vibration dampening, thermal insulation and systems primarily for the commercial aerospace and military (U.S. Government) markets. The contracts may contain multiple products, which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. Our contracts are frequently modified for changes in contract specifications and requirements. Most of our contract modifications are for products that are not distinct from the existing contract and are accounted for as part of that existing contract.
  (was, 2019-02-11, similarity 0.9225):
[0001144204-19-006206:note_history:25]
Approximately 52% of the segment’s revenues (approximately 19% 
of consolidated revenues) are accounted for over time as the products do not have alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin or the inventory is owned by the customer. The related contracts are primarily cost-plus or fixed price contracts related to the design, development and manufacture of complex fluid control products, quiet valves, manifolds, shock and vibration dampening, thermal insulation and systems primarily for the commercial aerospace and military (U.S. Government) markets. The contracts may contain multiple products, which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. Our contracts are frequently modified for changes in contract specifications and requirements. Most of our contract modifications are for products that are not distinct from the existing contract and are accounted for as part of that existing contract.

- changed (2019-05-09):
[0001144204-19-024737:note_history:26]
Within the Test segment, approximately 25% of revenues (approximately 6% of consolidated revenues) are recognized at a point in time when products such as, antennas and probes are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.
  (was, 2019-02-11, similarity 0.9905):
[0001144204-19-006206:note_history:26]
:
 Within the USG segment, approximately 80% of revenues (approximately 24% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

- added (2019-05-09):
[0001144204-19-024737:note_history:27]
:

- changed (2019-05-09):
[0001144204-19-024737:note_history:28]
Within the USG segment, approximately 80% of revenues (approximately 24% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.
  (was, 2019-02-11, similarity 0.94):
[0001144204-19-006206:note_history:28]
of consolidated revenues) are recognized at a point in time when products such as, antennas and probes are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

- changed (2019-05-09):
[0001144204-19-024737:note_history:29]
Within the Technical Packaging segment, 100% of the revenues (approximately 10% of consolidated revenues) are recognized over time as the product does not have an alternative use and the Company has an enforceable right to payment. Selecting the method to measure progress towards completion for the contracts requires judgment and is based on the nature of the products to be provided. We use the cost-to-cost method to measure progress for our Technical Packaging segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. Under this measure, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and revenue is recorded proportionally as costs are incurred. The transaction price for our contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant.
  (was, 2019-02-11, similarity 0.9745):
[0001144204-19-006206:note_history:29]
Within the Technical Packaging segment, 
100
% of the revenues (approximately 10% of consolidated revenues) are recognized over time as the product does not have an alternative use and the Company has an enforceable right to payment. Selecting the method to measure progress towards completion for the contracts requires judgment and is based on the nature of the products to be provided. We use the cost-to-cost method to measure progress for our Technical Packaging segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. Under this measure, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and revenue is recorded proportionally as costs are incurred. The transaction price for our contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant.
