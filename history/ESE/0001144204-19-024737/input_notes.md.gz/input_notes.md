# ESE notes — 0001144204-19-024737


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001144204-19-024737:notes:1]
[same as prior period, unchanged from 0001144204-19-006206:notes:110]

[0001144204-19-024737:notes:2]
Our significant accounting policies are included in Note 1 of our Annual Report on Form 10-K for the year ended September 30, 2018. On October 1, 2018, we adopted ASU No. 2014-09,

[0001144204-19-024737:notes:3]
[same as prior period, unchanged from 0001144204-19-006206:notes:112]

[0001144204-19-024737:notes:4]
. Significant changes to our policies resulting from the adoption are provided below. We adopted ASC 606 using the modified retrospective transition method applied to contracts that were not substantially complete at the end of fiscal year 2018. We recorded a $4.2 million adjustment to increase retained earnings to reflect the cumulative impact of adopting this standard at the beginning of fiscal year 2019, primarily related to certain long-term contracts our Filtration and Technical Packaging segments have that converted to the cost-to-cost method for revenue recognition. The comparative information has not been restated and is reported under the accounting standards in effect for those periods. A reconciliation of the financial statement line items impacted for the three and six months ended March 31, 2019 under ASC 606 to the prior accounting standards is provided in Note 14.

[0001144204-19-024737:notes:5]
Revenue Recognition

[0001144204-19-024737:notes:6]
Revenue is recognized when control of the goods or services promised under the contract is transferred to the customer either at a point in time (e.g., upon delivery) or over time (e.g., as we perform under the contract). We account for a contract when it has approval and commitment from both parties, the rights and payment terms of the parties are identified, the contract has commercial substance and collectability of consideration is probable. Contracts are reviewed to determine whether there is one or multiple performance obligations. A performance obligation is a promise to transfer a distinct good or service to a customer and represents the unit of accounting for revenue recognition. For contracts with multiple performance obligations, the expected consideration, or the transaction price, is allocated to each performance obligation identified in the contract based on the relative standalone selling price of each performance obligation. Revenue is then recognized for the transaction price allocated to the performance obligation when control of the promised goods or services underlying the performance obligation is transferred.

[0001144204-19-024737:notes:7]
Payment terms with customers vary by the type and location of the customer and the products or services offered. The Company does not adjust the promised amount of consideration for the effects of significant financing components based on the expectation that the period between when the Company transfers a promised good or service to a customer and when the customer pays for that good or service will be one year or less. Arrangements with customers that include payment terms extending beyond one year are not significant.

[0001144204-19-024737:notes:8]
Filtration:

[0001144204-19-024737:notes:9]
Within the Filtration segment, approximately 48% of revenues (approximately 18% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial and military customers and have a single performance obligation as there is only one good promised or the promise to transfer the goods or services is not distinct or separately identifiable from other promises in the contract. The transaction price for these contracts reflects our estimate of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

[0001144204-19-024737:notes:10]
Approximately

[0001144204-19-024737:notes:11]
52

[0001144204-19-024737:notes:12]
% of the segment’s revenues (approximately

[0001144204-19-024737:notes:13]
19

[0001144204-19-024737:notes:14]
% of consolidated revenues)

[0001144204-19-024737:notes:15]
are accounted for over time as the product does not have an alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin or the inventory is owned by the customer. The related contracts are primarily cost-plus or fixed price contracts related to the design, development and manufacture of complex fluid control products, quiet valves, manifolds, shock and vibration dampening, thermal insulation and systems primarily for the commercial aerospace and military (U.S. Government) markets. The contracts may contain multiple products, which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. Our contracts are frequently modified for changes in contract specifications and requirements. Most of our contract modifications are for products that are not distinct from the existing contract and are accounted for as part of that existing contract.

[0001144204-19-024737:notes:16]
Contracts with the U.S. Government generally contain clauses that provide lien rights to work-in-process along with clauses that allow the customer to unilaterally terminate the contract for convenience, pay us for costs incurred plus a reasonable profit and take control of any work-in-process. Due to the continuous transfer of control to the U.S. Government, we recognize revenue over the time that we perform under the contract.

[0001144204-19-024737:notes:17]
Selecting the method to measure progress towards completion for the commercial and military contracts requires judgment and is based on the nature of the products or service to be provided. We generally use the cost-to-cost method to measure progress for our Filtration segment contracts the rate at which costs are incurred to fulfill a contract best depicts the transfer of control to the customer. Under this measure, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and revenue is recorded proportionally as costs are incurred based on an estimated profit margin.

[0001144204-19-024737:notes:18]
The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Certain of our long-term contracts contain incentive fees that can increase the transaction price. These variable amounts generally are awarded upon achievement of certain performance metrics, program milestones or cost targets and can be based upon customer discretion. We include estimated amounts in the transaction price to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimates of variable consideration and determination of whether to include estimated amounts in the transaction price are based largely on an assessment of our anticipated performance and all other information that is reasonably available to us.

[0001144204-19-024737:notes:19]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to one or more years, and the estimation of these costs requires substantial judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

[0001144204-19-024737:notes:20]
Under the typical payment terms of our long term fixed price contracts, the customer pays us either performance-based or progress payments. Performance-based payments represent interim payments based on quantifiable measures of performance or on the achievement of specified events or milestones. Progress payments are interim payments of costs incurred as the work progresses. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred, which we present as contract assets and contract liabilities, respectively, in the Consolidated Balance Sheets. Amounts billed and due from our customers are classified in Accounts receivable, net. For short term fixed price and cost-type contracts, we are generally paid within a short period of time.

[0001144204-19-024737:notes:21]
For contracts where revenue is recognized over time, we generally recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. Anticipated losses on contracts are recognized in full in the period in which the losses become probable and estimable.

[0001144204-19-024737:notes:22]
Test:

[0001144204-19-024737:notes:23]
Within the Test segment, approximately 25% of revenues (approximately 6% of consolidated revenues) are recognized at a point in time when products such as, antennas and probes are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

[0001144204-19-024737:notes:24]
Approximately 75% of the segment’s revenues (approximately 17% of consolidated revenues) are recorded over time as the product does not have an alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin. Products accounted for under this guidance include the construction and installation of complex test chambers to a buyer’s specifications that provide its customers with the ability to measure and contain magnetic, electromagnetic and acoustic energy. The goods and services related to each installed test chamber are not distinct due to the significant amount of integration provided and each installed chamber is accounted for as a single performance obligation. Selecting the method to measure progress towards completion for these contracts requires judgment and is based on the nature of the products and service to be provided. We use milestones to measure progress for our Test segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. For arrangements that are accounted for under this guidance, the Company estimates profit as the difference between total revenue and total estimated cost of a contract and recognizes these revenues and costs based primarily on contract milestones. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable.

[0001144204-19-024737:notes:25]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to a year, and the estimation of these costs requires substantial judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

[0001144204-19-024737:notes:26]
Under the typical payment terms of our fixed price contracts, the customer pays us either performance-based or progress payments. Performance-based payments represent interim payments based on quantifiable measures of performance or on the achievement of specified events or milestones. Progress payments are interim payments of costs incurred as the work progresses. Because of the timing difference of revenue recognition and customer billing, these contracts result in revenue recognized in excess of billings and billings in excess of costs incurred, which we present as contract assets and contract liabilities, respectively, in the Consolidated Balance Sheets. Amounts billed and due from our customers are classified in Accounts receivable, net.

[0001144204-19-024737:notes:27]
For contracts where revenue is recognized over time, we generally recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. Anticipated losses on contracts are recognized in full in the period in which the losses become probable and estimable.

[0001144204-19-024737:notes:28]
USG

[0001144204-19-024737:notes:29]
:

[0001144204-19-024737:notes:30]
Within the USG segment, approximately 80% of revenues (approximately 24% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

[0001144204-19-024737:notes:31]
Approximately 20% of the segment’s revenues (approximately 6% of consolidated revenues) are recognized over time as services are performed. The services accounted for under this method include an obligation to provide testing services using hardware and embedded software, software maintenance, training, lab testing, and consulting services. The related contracts contain a bundle of goods and services that are integrated in the context of the contract. Therefore, the goods and services are not distinct and the Company has a single performance obligation. Selecting the method to measure progress towards completion for these contracts requires judgment and is based on the nature of the products and service to be provided. We will recognize revenue as a series of distinct services based on each day of providing services (straight-line over the contract term) for our USG segment contracts. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Under the typical payment terms of our service contracts, the customer pays us in advance of when services are performed. Because of the timing difference of revenue recognition and customer payment, which is typically received upon commencement of the contract, these contracts result in deferred revenue, which we present as contract liabilities, in the Consolidated Balance Sheets.

[0001144204-19-024737:notes:32]
Included in this category, approximately 8% of the segment’s revenues (approximately 2% of consolidated revenues) are recognized based on the terms of the software contract. For contracts that transfer a software license to the customer, revenue will be recognized at a point in time. These type of software contracts represent a right to use the software, or a functional license, in which revenue should be recognized upon transfer of the license. For contracts in software as a service (SaaS) arrangements, revenue will be recognized over time. The customer receives and consumes the benefits of the SaaS arrangement through access to the system which is for a stated period. We will recognize revenue based on each day of providing access (straight-line over the contract term). The transaction price for our contracts represent our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Under the typical payment terms of our software contracts, the customer pays us in advance of when services are performed. Because of the timing difference of revenue recognition and customer payment, these contracts result in deferred revenue, which we present as contract liabilities, in the Consolidated Balance Sheets.

[0001144204-19-024737:notes:33]
Technical Packaging:

[0001144204-19-024737:notes:34]
Within the Technical Packaging segment, 100% of the revenues (approximately 10% of consolidated revenues) are recognized over time as the product does not have an alternative use and the Company has an enforceable right to payment. Selecting the method to measure progress towards completion for the contracts requires judgment and is based on the nature of the products to be provided. We use the cost-to-cost method to measure progress for our Technical Packaging segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. Under this measure, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and revenue is recorded proportionally as costs are incurred. The transaction price for our contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant.

[0001144204-19-024737:notes:35]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of weeks, minimizing the amount of judgment in developing the cost estimate. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

[0001144204-19-024737:notes:36]
Under the typical payment terms of our contracts, the customer is billed upon shipment of product. Amounts billed and due from our customers are classified in Accounts receivable, net. Because of the timing difference of revenue recognition and customer billing, these contracts result in revenue recognized in excess of billings, which we present as contract assets in the Consolidated Balance Sheets.

[0001144204-19-024737:notes:37]
For contracts where revenue is recognized over time, we generally recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. Anticipated losses on contracts are recognized in full in the period in which the losses become probable and estimable.

[0001144204-19-024737:notes:38]
Contract Assets and Liabilities

[0001144204-19-024737:notes:39]
Contract assets arise from contracts when revenue is recognized over time and the amount of revenue recognized, including our estimate of variable consideration that has been included in the transaction price, exceeds the amount billed to the customer. These amounts are included in contract assets until the right to payment is no longer conditional on events other than the passage of time. These contract assets are reclassified to receivables when the right to consideration becomes unconditional. Contract liabilities include deposits, deferred revenue, upfront payments and billings in excess of revenue recognized. Liabilities for customer rebates and discounts are included in other current liabilities in the accompanying balance sheet.


## us-gaap:EarningsPerShareTextBlock

[0001144204-19-024737:notes:40]
[same as prior period, unchanged from 0001144204-19-006206:notes:45]

[0001144204-19-024737:notes:41]
Basic EPS is calculated using the weighted average number of common shares outstanding during the period. Diluted EPS is calculated using the weighted average number of common shares outstanding during the period plus shares issuable upon the assumed exercise of dilutive common share options and vesting of performance-accelerated restricted shares (restricted shares) by using the treasury stock method. The number of shares used in the calculation of earnings per share for each period presented is as follows (in thousands):

[0001144204-19-024737:notes:42]
|  |  | Three MonthsEnded March 31, |  |  | Six Months Ended March 31, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Weighted Average Shares Outstanding - Basic |  |  | 25,918 |  |  |  | 25,844 |  |  |  | 25,915 |  |  |  | 25,840 |  |
| Dilutive Options and Restricted Shares |  |  | 118 |  |  |  | 144 |  |  |  | 163 |  |  |  | 195 |  |
| Adjusted Shares - Diluted |  |  | 26,036 |  |  |  | 25,988 |  |  |  | 26,078 |  |  |  | 26,035 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001144204-19-024737:notes:43]
[same as prior period, unchanged from 0001144204-19-006206:notes:49]

[0001144204-19-024737:notes:44]
[same as prior period, unchanged from 0001144204-19-006206:notes:50]

[0001144204-19-024737:notes:45]
[same as prior period, unchanged from 0001144204-19-006206:notes:51]

[0001144204-19-024737:notes:46]
Compensation expense related to the restricted share awards was $0.9 million and $2.0 million for the three and six-month periods ended March 31, 2019, respectively, and $1.0 million and $2.1 million for the corresponding periods of 2018. There were 204,392 non-vested shares outstanding as of March 31, 2019.

[0001144204-19-024737:notes:47]
[same as prior period, unchanged from 0001144204-19-006206:notes:53]

[0001144204-19-024737:notes:48]
Compensation expense related to the non-employee director grants was $0.3 million and $0.5 million for the three and six-month periods ended March 31, 2019, respectively, and $0.3 million and $0.5 million for the corresponding periods of 2018.

[0001144204-19-024737:notes:49]
The total share-based compensation cost that has been recognized in the results of operations and included within selling, general and administrative expenses (SG&A) was $1.2 million and $2.6 million for the three-and six-month periods ended March 31, 2019, respectively, and $1.3 million and $2.6 million for the three and six-month periods ended March 31, 2018. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $0.3 million and $0.6 million for the three and six-month periods ended March 31, 2019, respectively, and $0.4 million and $0.7 million for the three and six-month periods ended March 31, 2018, respectively. As of March 31, 2019, there was $5.6 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a remaining weighted-average period of 1.2 years.


## us-gaap:InventoryDisclosureTextBlock

[0001144204-19-024737:notes:50]
[same as prior period, unchanged from 0001144204-19-006206:notes:7]

[0001144204-19-024737:notes:51]
[same as prior period, unchanged from 0001144204-19-006206:notes:8]

[0001144204-19-024737:notes:52]
| (In thousands) |  | March 31,2019 |  |  | September 30, 2018 |  |
| Finished goods |  | $ | 19,029 |  |  |  | 26,678 |  |
| Work in process |  |  | 41,677 |  |  |  | 47,765 |  |
| Raw materials |  |  | 63,787 |  |  |  | 60,973 |  |
| Total inventories |  | $ | 124,493 |  |  |  | 135,416 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001144204-19-024737:notes:53]
[same as prior period, unchanged from 0001144204-19-006206:notes:10]

[0001144204-19-024737:notes:54]
Included on the Company’s Consolidated Balance Sheets at March 31, 2019 and September 30, 2018 are the following intangible assets gross carrying amounts and accumulated amortization:

[0001144204-19-024737:notes:55]
| (Dollars in thousands) |  | March 31,2019 |  |  | September 30, 2018 |  |
| Goodwill |  | $ | 381,304 |  |  |  | 381,652 |  |
| Intangible assets with determinable lives: |  |  |  |  |  |  |  |  |
| Patents |  |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 1,866 |  |  |  | 1,833 |  |
| Less: accumulated amortization |  |  | 846 |  |  |  | 791 |  |
| Net |  | $ | 1,020 |  |  |  | 1,042 |  |
| Capitalized software |  |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 75,789 |  |  |  | 71,294 |  |
| Less: accumulated amortization |  |  | 45,304 |  |  |  | 41,624 |  |
| Net |  | $ | 30,485 |  |  |  | 29,670 |  |
| Customer relationships |  |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 184,924 |  |  |  | 185,333 |  |
| Less: accumulated amortization |  |  | 53,030 |  |  |  | 47,802 |  |
| Net |  | $ | 131,894 |  |  |  | 137,531 |  |
| Other |  |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 5,303 |  |  |  | 5,468 |  |
| Less: accumulated amortization |  |  | 2,365 |  |  |  | 2,056 |  |
| Net |  | $ | 2,938 |  |  |  | 3,412 |  |
| Intangible assets with indefinite lives: |  |  |  |  |  |  |  |  |
| Trade names |  | $ | 172,177 |  |  |  | 173,698 |  |

[0001144204-19-024737:notes:56]
The changes in the carrying amount of goodwill attributable to each business segment for the six months ended March 31, 2019 is as follows:

[0001144204-19-024737:notes:57]
| (Dollars in millions) |  | USG |  |  | Test |  |  | Filtration |  |  | Packaging |  |  | Total |  |
| Balance as of September 30, 2018 |  |  | 254.1 |  |  |  | 34.1 |  |  |  | 73.7 |  |  |  | 19.8 |  |  |  | 381.7 |  |
| Foreign currency translation |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (0.4 | ) |  |  | (0.4 | ) |
| Balance as of March 31, 2019 |  | $ | 254.1 |  |  |  | 34.1 |  |  |  | 73.7 |  |  |  | 19.4 |  |  |  | 381.3 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001144204-19-024737:notes:58]
[same as prior period, unchanged from 0001144204-19-006206:notes:15]

[0001144204-19-024737:notes:59]
The Company is organized based on the products and services that it offers, and classifies its business operations in four reportable segments for financial reporting purposes: Filtration/Fluid Flow (Filtration), RF Shielding and Test (Test), Utility Solutions Group (USG) and Technical Packaging. The Filtration segment’s operations consist of PTI Technologies Inc. (PTI), VACCO Industries (VACCO), Crissair, Inc. (Crissair), Westland Technologies Inc. (Westland), and Mayday Manufacturing Co. and its affiliate Hi-Tech Metals, Inc. (collectively referred to as Mayday). The companies within this segment primarily design and manufacture specialty filtration products, including hydraulic filter elements used in commercial aerospace applications, unique filter mechanisms used in micro-propulsion devices for satellites and custom designed filters for manned and unmanned aircraft; manufacture elastomeric-based signature reduction solutions for the U.S. Navy; and manufacture landing gear components for the aerospace and defense industry. The Test segment’s operations consist primarily of ETS-Lindgren Inc. (ETS-Lindgren). ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy. The USG segment’s operations consist primarily of Doble Engineering Company (Doble), Morgan Schaffer Inc. (Morgan Schaffer), and NRG Systems, Inc. (NRG). Doble provides high-end, intelligent diagnostic test solutions for the electric power delivery industry and is a leading supplier of partial discharge testing instruments used to assess the integrity of high voltage power delivery equipment. Morgan Schaffer provides an integrated offering of dissolved gas analysis, oil testing, and data management solutions for the electric power industry. NRG designs and manufactures decision support tools for the renewable energy industry, primarily wind. The Technical Packaging segment’s operations consist of Thermoform Engineered Quality LLC (TEQ) and Plastique Limited and Plastique Sp. z o.o. (together, Plastique). The companies within this segment provide innovative solutions to the medical and commercial markets for thermoformed packages and specialty products using a wide variety of thin gauge plastics and pulp.

[0001144204-19-024737:notes:60]
[same as prior period, unchanged from 0001144204-19-006206:notes:17]

[0001144204-19-024737:notes:61]
|  |  | Three MonthsEnded March 31, |  |  | Six MonthsEnded March 31, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| NET SALES |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 79,478 |  |  |  | 65,775 |  |  |  | 145,702 |  |  |  | 125,810 |  |
| Test |  |  | 42,875 |  |  |  | 40,805 |  |  |  | 84,161 |  |  |  | 78,334 |  |
| USG |  |  | 48,890 |  |  |  | 46,699 |  |  |  | 104,745 |  |  |  | 102,453 |  |
| Technical Packaging |  |  | 22,706 |  |  |  | 21,499 |  |  |  | 41,938 |  |  |  | 41,676 |  |
| Consolidated totals |  | $ | 193,949 |  |  |  | 174,778 |  |  |  | 376,546 |  |  |  | 348,273 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 17,443 |  |  |  | 11,118 |  |  |  | 28,053 |  |  |  | 20,764 |  |
| Test |  |  | 5,554 |  |  |  | 5,300 |  |  |  | 8,864 |  |  |  | 7,895 |  |
| USG |  |  | 8,767 |  |  |  | 5,626 |  |  |  | 30,313 |  |  |  | 16,277 |  |
| Technical Packaging |  |  | 1,602 |  |  |  | 1,885 |  |  |  | 1,708 |  |  |  | 2,850 |  |
| Corporate (loss) |  |  | (10,086 | ) |  |  | (8,309 | ) |  |  | (20,511 | ) |  |  | (17,180 | ) |
| Consolidated EBIT |  |  | 23,280 |  |  |  | 15,620 |  |  |  | 48,427 |  |  |  | 30,606 |  |
| Less: Interest expense |  |  | (1,925 | ) |  |  | (2,036 | ) |  |  | (3,815 | ) |  |  | (4,221 | ) |
| Earnings before income taxes |  | $ | 21,355 |  |  |  | 13,584 |  |  |  | 44,612 |  |  |  | 26,385 |  |

[0001144204-19-024737:notes:62]
[same as prior period, unchanged from 0001144204-19-006206:notes:19]

[0001144204-19-024737:notes:63]
[same as prior period, unchanged from 0001144204-19-006206:notes:20]

[0001144204-19-024737:notes:64]
[same as prior period, unchanged from 0001144204-19-006206:notes:21]


## us-gaap:DebtDisclosureTextBlock

[0001144204-19-024737:notes:65]
|  | 8. | DEBT |

[0001144204-19-024737:notes:66]
The Company’s debt is summarized as follows:

[0001144204-19-024737:notes:67]
| (In thousands) |  | March 31,2019 |  |  | September 30, 2018 |  |
| Total borrowings |  | $ | 217,000 |  |  |  | 220,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000 | ) |  |  | (20,000 | ) |
| Total long-term debt, less current portion |  | $ | 197,000 |  |  |  | 200,000 |  |

[0001144204-19-024737:notes:68]
The Company’s existing credit facility (“the Credit Facility”) matures December 21, 2020. The Credit Facility includes a $450 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of nine banks led by JPMorgan Chase Bank, N.A., as Administrative Agent.

[0001144204-19-024737:notes:69]
At March 31, 2019, the Company had approximately $207.0 million available to borrow under the Credit Facility, and a $250 million increase option, in addition to $35.0 million cash on hand. At March 31, 2019, the Company had $217.0 million of outstanding borrowings under the Credit Facility in addition to outstanding letters of credit of $8.3 million. The Company classified $20.0 million as the current portion of long-term debt as of March 31, 2019, as the Company intends to repay this amount within the next twelve month period; however, the Company has no contractual obligation to repay such amount during the next twelve month period.

[0001144204-19-024737:notes:70]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from 12.5 to 27.5 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a 65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 3.20% and 3.23% for the three and six-month periods ending March 31, 2019, respectively, and 2.99% and 2.87% for the corresponding periods of 2018. At March 31, 2019, the Company was in compliance with all debt covenants.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001144204-19-024737:notes:71]
[same as prior period, unchanged from 0001144204-19-006206:notes:28]

[0001144204-19-024737:notes:72]
The second quarter 2019 effective income tax rate was 12.0% compared to 26.4% in the second quarter of 2018. The income tax expense for the first six months of 2019 was $8.5 million compared to income tax benefit of $18.3 million for the first six months of 2018. The effective income tax rate for the first six months of 2019 was 19.0% compared to (69.3%) for the first six months of 2018. The income tax expense in the second quarter and first six months of 2019 was favorably impacted by tax planning strategies to increase foreign tax credits claimed retrospectively. The Company reduced the valuation allowance for excess foreign tax credits by $2.3 million and recorded an amended return receivable of $0.2 million which favorably impacted the second quarter and year-to-date effective tax rate by 12.1% and 5.8%, respectively.

[0001144204-19-024737:notes:73]
H.R. 1,

[0001144204-19-024737:notes:74]
[same as prior period, unchanged from 0001144204-19-006206:notes:30]

[0001144204-19-024737:notes:75]
(“TCJA”), was signed into law on December 22, 2017. The total impact of the TCJA in the second quarter and first six months of 2018 was a net expense of $0.7 million and a net benefit of $24.4 million, respectively. The impacts were as follows: First, the Company’s 2018 federal statutory rate dropped from 35.0% to 24.5% which required an adjustment to the value of its deferred tax assets and liabilities. This adjustment ($30.3 million provisional amount recorded in Q1) favorably impacted the year-to-date 2018 effective tax rate by 114.9%. Second, the TCJA subjected the Company’s cumulative foreign earnings to federal income tax ($3.6 million provisional amount of which $2.9 million was recorded in the first quarter of 2018 and $0.7 million was recorded in the second quarter of 2018) which unfavorably impacted the second quarter and year-to-date 2018 effective tax rate by 4.9% and 13.6%, respectively.

[0001144204-19-024737:notes:76]
In the first quarter of 2018, the Company recorded a $2.3 million provisional estimate of the income tax effects of the future repatriation of the cumulative earnings of its foreign subsidiaries which unfavorably impacted the year-to-date effective tax rate by 8.9%. An additional $7.5 million pension contribution for the 2017 plan year was approved during the second quarter of 2018 increasing the value of the deferred tax liability by $1.0 million. This favorable adjustment, net of the $0.3 million unfavorable impact to the 2017 Domestic Production Deduction, favorably impacted the second quarter and year-to-date effective tax rate by 5.8% and 3.0%, respectively. The income tax expense in the second quarter and first six months of 2018 was also unfavorably impacted by the cancellation of debt income triggered by the dissolution of a foreign subsidiary increasing the second quarter and year-to-date effective tax rate by 1.5% and 0.8%, respectively.

[0001144204-19-024737:notes:77]
Provisions under the TCJA that became effective for the Company in the current fiscal year include a further reduction in the U.S. statutory rate to 21%, a new minimum tax on global intangible low-taxed income (“GILTI”), the benefit of the deduction for foreign-derived intangible income (“FDII”), and changes to IRC Section 162(m) related to the deductibility of executive compensation.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001144204-19-024737:notes:78]
[same as prior period, unchanged from 0001144204-19-006206:notes:34]

[0001144204-19-024737:notes:79]
The change in shareholders’ equity for the first six months of 2019 is shown below (in thousands):

[0001144204-19-024737:notes:80]
| Balance at September 30, 2018 |  | $ | 759,410 |  |
| Net earnings |  |  | 36,114 |  |
| Other comprehensive (loss) |  |  | (3,752 | ) |
| Cash dividends |  |  | (4,146 | ) |
| Impact of ASC 606, Revenue Recognition |  |  | 4,213 |  |
| Stock compensation plans |  |  | 2,557 |  |
| Balance at March 31, 2019 |  | $ | 794,396 |  |


## us-gaap:ScheduleOfChangesInProjectedBenefitObligationsTableTextBlock

[0001144204-19-024737:notes:81]
A summary of net periodic benefit expense for the Company’s defined benefit plans for the three and six-month periods ended March 31, 2019 and 2018 is shown in the following table. Net periodic benefit cost for each period presented is comprised of the following:

[0001144204-19-024737:notes:82]
|  |  | Three MonthsEnded March 31, |  |  | Six Months Ended March 31, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Defined benefit plans |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest cost |  | $ | 875 |  |  |  | 821 |  |  |  | 1,750 |  |  |  | 1,641 |  |
| Expected return on assets |  |  | (1,086 | ) |  |  | (975 | ) |  |  | (2,172 | ) |  |  | (1,950 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior service cost |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Actuarial loss |  |  | 487 |  |  |  | 548 |  |  |  | 974 |  |  |  | 1,097 |  |
| Net periodic benefit cost |  | $ | 276 |  |  |  | 394 |  |  |  | 552 |  |  |  | 788 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001144204-19-024737:notes:83]
[same as prior period, unchanged from 0001144204-19-006206:notes:37]


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001144204-19-024737:notes:84]
[same as prior period, unchanged from 0001144204-19-006206:notes:40]

[0001144204-19-024737:notes:85]
[same as prior period, unchanged from 0001144204-19-006206:notes:41]

[0001144204-19-024737:notes:86]
The following is a summary of the notional transaction amounts and fair values for the Company’s outstanding derivative financial instruments by risk category and instrument type as of March 31, 2018:

[0001144204-19-024737:notes:87]
| (In thousands) |  | Notionalamount |  |  | Fair Value(US$) |  |  | FloatRate |  |  | FixRate |  |
| Forward contracts |  |  | 700 |  |  |  | GBP |  |  |  | 7 |  |  |  |  |  |  |  |  |  |
| Forward contracts |  |  | 7,500 |  |  |  | USD |  |  |  | (227 | ) |  |  |  |  |  |  |  |  |
| Interest rate swap |  |  | 150,000 |  |  |  | USD |  |  |  | 327 |  |  |  | 2.48 | % |  |  | 2.09 | % |
| Interest rate swap * |  |  | 150,000 |  |  |  | USD |  |  |  | (101 | ) |  |  | N/A |  |  |  | 2.24 | % |

[0001144204-19-024737:notes:88]
[same as prior period, unchanged from 0001144204-19-006206:notes:44]


## us-gaap:FairValueDisclosuresTextBlock

[0001144204-19-024737:notes:89]
[same as prior period, unchanged from 0001144204-19-006206:notes:56]

[0001144204-19-024737:notes:90]
[same as prior period, unchanged from 0001144204-19-006206:notes:57]

[0001144204-19-024737:notes:91]
[same as prior period, unchanged from 0001144204-19-006206:notes:58]

[0001144204-19-024737:notes:92]
[same as prior period, unchanged from 0001144204-19-006206:notes:59]

[0001144204-19-024737:notes:93]
[same as prior period, unchanged from 0001144204-19-006206:notes:60]

[0001144204-19-024737:notes:94]
[same as prior period, unchanged from 0001144204-19-006206:notes:61]

[0001144204-19-024737:notes:95]
The Company has estimated the fair value of its financial instruments as of March 31, 2019 and September 30, 2018 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, debt and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001144204-19-024737:notes:96]
[same as prior period, unchanged from 0001144204-19-006206:notes:63]

[0001144204-19-024737:notes:97]
The Company’s forward contracts are classified within Level

[0001144204-19-024737:notes:98]
2

[0001144204-19-024737:notes:99]
of the valuation hierarchy in accordance with FASB Accounting Standards Codification (ASC)

[0001144204-19-024737:notes:100]
825

[0001144204-19-024737:notes:101]
, as presented below as of

[0001144204-19-024737:notes:102]
March 31, 2019

[0001144204-19-024737:notes:103]
| (In thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets (Liabilities): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Forward contracts |  | $ | - |  |  |  | 6 |  |  | $ | - |  |  |  | 6 |  |

[0001144204-19-024737:notes:104]
[same as prior period, unchanged from 0001144204-19-006206:notes:66]

[0001144204-19-024737:notes:105]
[same as prior period, unchanged from 0001144204-19-006206:notes:67]

[0001144204-19-024737:notes:106]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during the three and six-month periods ended March 31, 2019.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001144204-19-024737:notes:107]
|  | 15. | NEW ACCOUNTING STANDARDS |

[0001144204-19-024737:notes:108]
In February 2016, the FASB issued ASU No. 2016-062,

[0001144204-19-024737:notes:109]
Leases (Topic 842)

[0001144204-19-024737:notes:110]
, which, among other things, requires an entity to recognize lease assets and lease liabilities on the balance sheet and disclose key information about leasing arrangements. This standard will increase an entities’ reported assets and liabilities. The standard is effective for fiscal years beginning after December 15, 2018 and mandates a modified retrospective transition period for all entities. The Company is currently assessing the impact of this standard on its consolidated financial statements and related disclosures.

[0001144204-19-024737:notes:111]
In October 2016, the FASB issued ASU No. 2016-16,

[0001144204-19-024737:notes:112]
Intra-Entity Transfers of Assets Other Than Inventory

[0001144204-19-024737:notes:113]
, which eliminates the exception for all intra-entity sale of assets other than inventory. This standard is effective for annual periods beginning after December 15, 2017. There was no significant impact to the Company’s consolidated financial statements as a result of adopting this new standard.


## ese:RevenuesTextBlock

[0001144204-19-024737:notes:114]
[same as prior period, unchanged from 0001144204-19-006206:notes:115]

[0001144204-19-024737:notes:115]
[same as prior period, unchanged from 0001144204-19-006206:notes:116]

[0001144204-19-024737:notes:116]
Our revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2019 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within our reportable segments.

[0001144204-19-024737:notes:117]
| Three Months Ended March 31, 2019(In thousands) |  | Filtration |  |  | Test |  |  | USG |  |  | Technical Packaging |  |  | Total |  |
| Customer type: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial |  | $ | 46,325 |  |  | $ | 37,451 |  |  | $ | 47,551 |  |  | $ | 22,630 |  |  | $ | 153,957 |  |
| Government |  |  | 33,153 |  |  |  | 5,424 |  |  |  | 1,339 |  |  |  | 76 |  |  |  | 39,992 |  |
| Total revenues |  | $ | 79,478 |  |  | $ | 42,875 |  |  | $ | 48,890 |  |  | $ | 22,706 |  |  | $ | 193,949 |  |
| Geographic location: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 66,068 |  |  | $ | 26,694 |  |  | $ | 33,798 |  |  | $ | 11,457 |  |  | $ | 138,017 |  |
| International |  |  | 13,410 |  |  |  | 16,181 |  |  |  | 15,092 |  |  |  | 11,249 |  |  |  | 55,932 |  |
| Total revenues |  | $ | 79,478 |  |  | $ | 42,875 |  |  | $ | 48,890 |  |  | $ | 22,706 |  |  | $ | 193,949 |  |
| Revenue recognition method: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Point in time |  | $ | 42,400 |  |  | $ | 12,166 |  |  | $ | 36,874 |  |  | $ | - |  |  | $ | 91,440 |  |
| Over time |  |  | 37,078 |  |  |  | 30,709 |  |  |  | 12,016 |  |  |  | 22,706 |  |  |  | 102,509 |  |
| Total revenues |  | $ | 79,478 |  |  | $ | 42,875 |  |  | $ | 48,890 |  |  | $ | 22,706 |  |  | $ | 193,949 |  |

[0001144204-19-024737:notes:118]
| Six Months Ended March 31, 2019(In thousands) |  | Filtration |  |  | Test |  |  | USG |  |  | Technical Packaging |  |  | Total |  |
| Customer type: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial |  | $ | 83,546 |  |  | $ | 73,688 |  |  | $ | 102,206 |  |  | $ | 41,744 |  |  | $ | 301,184 |  |
| Government |  |  | 62,156 |  |  |  | 10,473 |  |  |  | 2,539 |  |  |  | 194 |  |  |  | 75,362 |  |
| Total revenues |  | $ | 145,702 |  |  | $ | 84,161 |  |  | $ | 104,745 |  |  | $ | 41,938 |  |  | $ | 376,546 |  |
| Geographic location: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 120,833 |  |  | $ | 55,148 |  |  | $ | 73,879 |  |  | $ | 21,306 |  |  | $ | 271,166 |  |
| International |  |  | 24,869 |  |  |  | 29,013 |  |  |  | 30,866 |  |  |  | 20,632 |  |  |  | 105,380 |  |
| Total revenues |  | $ | 145,702 |  |  | $ | 84,161 |  |  | $ | 104,745 |  |  | $ | 41,938 |  |  | $ | 376,546 |  |
| Revenue recognition method: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Point in time |  | $ | 74,214 |  |  | $ | 22,608 |  |  | $ | 81,107 |  |  | $ | - |  |  | $ | 177,929 |  |
| Over time |  |  | 71,488 |  |  |  | 61,553 |  |  |  | 23,638 |  |  |  | 41,938 |  |  |  | 198,617 |  |
| Total revenues |  | $ | 145,702 |  |  | $ | 84,161 |  |  | $ | 104,745 |  |  | $ | 41,938 |  |  | $ | 376,546 |  |

[0001144204-19-024737:notes:119]
[same as prior period, unchanged from 0001144204-19-006206:notes:117]

[0001144204-19-024737:notes:120]
Our remaining performance obligations, which is the equivalent of our backlog, represent the expected transaction price allocated to our contracts that we expect to recognize as revenue in future periods when we perform under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At March 31, 2019, we had $436.1 million in remaining performance obligations of which we expect to recognize revenues of 
83%

[0001144204-19-024737:notes:121]
in the next twelve months.

[0001144204-19-024737:notes:122]
[same as prior period, unchanged from 0001144204-19-006206:notes:119]

[0001144204-19-024737:notes:123]
Assets and liabilities related to our contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At March 31, 2019, contract assets and liabilities totaled $100.5 million and $55.5 million, respectively. Upon adoption of ASC 606 on October 1, 2018, contract assets and liabilities related to our contracts with customers were $87 million and $51 million, respectively. During the first six months of 2019, we recognized approximately $30 million in revenues that were included in the contract liabilities balance at the adoption date.

[0001144204-19-024737:notes:124]
[same as prior period, unchanged from 0001144204-19-006206:notes:121]

[0001144204-19-024737:notes:125]
The amount by which each financial statement line item is affected in 2019 as a result of applying the new accounting standard as discussed in Note 2 is presented below:

[0001144204-19-024737:notes:126]
|  |  | March 31, 2019 |  |
| (In thousands) |  | As Reported |  |  | Effect of theadoption ofASC 606 |  |  | Under PriorAccounting |  |
| Consolidated Balance Sheets |  |  |  |  |  |  |  |  |  |  |  |  |
| Contract assets (1) |  | $ | 100,540 |  |  | $ | (39,565 | ) |  | $ | 60,975 |  |
| Inventories |  |  | 124,493 |  |  |  | 34,692 |  |  |  | 159,185 |  |
| Total current assets |  |  | 435,959 |  |  |  | (4,874 | ) |  |  | 431,085 |  |
| Total assets |  |  | 1,293,963 |  |  |  | (4,874 | ) |  |  | 1,289,089 |  |
| Contract liabilities (2) |  |  | 55,453 |  |  |  | 1,754 |  |  |  | 57,207 |  |
| Total current liabilities |  |  | 201,945 |  |  |  | 1,754 |  |  |  | 203,699 |  |
| Deferred tax liabilities |  |  | 62,938 |  |  |  | (1,122 | ) |  |  | 61,816 |  |
| Total liabilities |  |  | 499,567 |  |  |  | 631 |  |  |  | 500,198 |  |
| Retained earnings |  |  | 643,018 |  |  |  | (5,505 | ) |  |  | 637,513 |  |
| Total shareholders’ equity |  |  | 794,396 |  |  |  | (5,505 | ) |  |  | 788,891 |  |
| Total liabilities and shareholders’ equity |  | $ | 1,293,963 |  |  |  | (4,874 | ) |  |  | 1,289,089 |  |

[0001144204-19-024737:notes:127]
|  | (1) | Previously “cost and estimated earnings on long-term contracts” |

[0001144204-19-024737:notes:128]
|  | (2) | Previously “advance payments on long-term contracts” and “current portion of deferred revenue” |

[0001144204-19-024737:notes:129]
|  |  | Three Months EndedMarch 31, 2019 |  |
| (In thousands, except per share amounts) |  | As Reported |  |  | Effect of theadoption ofASC 606 |  |  | Under PriorAccounting |  |
| Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 193,949 |  |  | $ | (2,879 | ) |  | $ | 191,070 |  |
| Cost of sales |  |  | 121,946 |  |  |  | (3,719 | ) |  |  | 118,227 |  |
| Total costs and expenses |  |  | 172,594 |  |  |  | (3,719 | ) |  |  | 168,875 |  |
| Earnings before income tax |  |  | 21,355 |  |  |  | 839 |  |  |  | 22,194 |  |
| Income tax expense (benefit) |  |  | 2,558 |  |  |  | 117 |  |  |  | 2,675 |  |
| Net earnings |  |  | 18,797 |  |  |  | 723 |  |  |  | 19,520 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 0.73 |  |  | $ | 0.02 |  |  | $ | 0.75 |  |
| Diluted: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 0.72 |  |  | $ | 0.03 |  |  | $ | 0.75 |  |
| Consolidated Statements of Comprehensive Income |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 18,797 |  |  | $ | 723 |  |  | $ | 19,520 |  |
| Comprehensive income |  |  | 19,600 |  |  |  | 723 |  |  |  | 20,323 |  |

[0001144204-19-024737:notes:130]
|  |  | Six Months EndedMarch 31, 2019 |  |
| (In thousands, except per share amounts) |  | As Reported |  |  | Effect of theadoption ofASC 606 |  |  | Under PriorAccounting |  |
| Consolidated Statements of Operations |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 376,546 |  |  | $ | (5,779 | ) |  | $ | 370,767 |  |
| Cost of sales |  |  | 240,854 |  |  |  | (6,981 | ) |  |  | 233,873 |  |
| Total costs and expenses |  |  | 331,934 |  |  |  | (6,981 | ) |  |  | 324,953 |  |
| Earnings before income tax |  |  | 44,612 |  |  |  | 1,201 |  |  |  | 45,813 |  |
| Income tax expense (benefit) |  |  | 8,498 |  |  |  | 228 |  |  |  | 8,726 |  |
| Net earnings |  |  | 36,114 |  |  |  | 973 |  |  |  | 37,087 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 1.39 |  |  | $ | 0.04 |  |  | $ | 1.43 |  |
| Diluted: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 1.38 |  |  | $ | 0.04 |  |  | $ | 1.42 |  |
| Consolidated Statements of Comprehensive Income |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 36,114 |  |  | $ | 973 |  |  | $ | 37,087 |  |
| Comprehensive income |  |  | 32,363 |  |  |  | 973 |  |  |  | 33,336 |  |
| Consolidated Statements of Cash flows |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 36,114 |  |  | $ | 973 |  |  | $ | 37,087 |  |
| Adjustments to reconcile net earnings to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Change in assets and liabilities |  | $ | (28,847 | ) |  |  | (973 | ) |  | $ | (29,820 | ) |
| Net cash provided by operating activities |  |  | 16,992 |  |  |  | - |  |  |  | 16,992 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001144204-19-024737:notes:131]
[same as prior period, unchanged from 0001144204-19-006206:notes:1]

[0001144204-19-024737:notes:132]
[same as prior period, unchanged from 0001144204-19-006206:notes:2]

[0001144204-19-024737:notes:133]
The Company’s results for the three and six-month periods ended March 31, 2019 are not necessarily indicative of the results for the entire 2019 fiscal year. References to the second quarters of 2019 and 2018 represent the fiscal quarters ended March 31, 2019 and 2018, respectively.

[0001144204-19-024737:notes:134]
[same as prior period, unchanged from 0001144204-19-006206:notes:4]
