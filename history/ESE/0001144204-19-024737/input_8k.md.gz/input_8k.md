# ESE 8-K — 0001144204-19-024241 filed 2019-05-07

## item codes, every 8-K on or before 2019-05-09

- 2019-05-07 0001144204-19-024241 — 2.02, 5.02, 7.01, 9.01
- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2019-05-09

- none on or before 2019-05-09

## item 2.02 — earnings release, exhibit 99.1

[0001144204-19-024241:8k_2_02:1]
EX-99.1
3
tv520571_ex99-1.htm
EXHIBIT 99.1

[0001144204-19-024241:8k_2_02:2]
EXHIBIT 99.1

[0001144204-19-024241:8k_2_02:3]
| NEWS FROM |  |  |

[0001144204-19-024241:8k_2_02:4]
For more information contact:

[0001144204-19-024241:8k_2_02:5]
Kate Lowrey

[0001144204-19-024241:8k_2_02:6]
Director, Investor Relations

[0001144204-19-024241:8k_2_02:7]
ESCO Technologies Inc.

[0001144204-19-024241:8k_2_02:8]
(314) 213-7277

[0001144204-19-024241:8k_2_02:9]
ESCO ANNOUNCES SECOND QUARTER FISCAL
2019 RESULTS

[0001144204-19-024241:8k_2_02:10]
- Q2 GAAP EPS $0.72 (Includes $0.04
of Cost Reduction Charges) -

[0001144204-19-024241:8k_2_02:11]
- Q2 Adjusted EPS $0.76 ($0.13 above
Guidance Range / 58 Percent above Q2 2018) –

[0001144204-19-024241:8k_2_02:12]
- Management Raises 2019 EPS Guidance
to $3.05 to $3.10 -

[0001144204-19-024241:8k_2_02:13]
ST. LOUIS, May 7, 2019 – ESCO
Technologies Inc. (NYSE: ESE) (ESCO, or the Company) today reported its operating results for the second quarter ended March 31,
2019 (Q2 2019), compared to the quarter ended March 31, 2018 (Q2 2018).

[0001144204-19-024241:8k_2_02:14]
The financial results presented include
certain non-GAAP financial measures such as EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS, as defined within the “Non-GAAP
Financial Measures” described below. Any non-GAAP financial measures presented are reconciled to their respective GAAP equivalents.

[0001144204-19-024241:8k_2_02:15]
Management believes these non-GAAP financial
measures are useful in assessing the ongoing operational profitability of the Company’s business segments, and therefore,
allow shareholders better visibility into the Company’s underlying operations. See “Non-GAAP Financial Measures”
described below.

[0001144204-19-024241:8k_2_02:16]
Earnings Summary

[0001144204-19-024241:8k_2_02:17]
Q2 2019 GAAP EPS of $0.72 per share included
$0.04 per share of previously described cost reduction charges in Technical Packaging and at Doble, and costs incurred to
move the aircraft / aerospace business from VACCO to PTI. The $0.04 per share was excluded when determining Q2 2019 Adjusted EPS
of $0.76 per share. GAAP net earnings were $19 million in Q2 2019.

[0001144204-19-024241:8k_2_02:18]
Q2 2018 GAAP EPS of $0.38 per share included
$0.10 per share of previously disclosed cost reduction charges incurred in USG and Filtration. The $0.10 per share was excluded
when determining Q2 2018 Adjusted EPS of $0.48 per share. GAAP net earnings were $10 million in Q2 2018.

[0001144204-19-024241:8k_2_02:19]
Q2 2019 Adjusted EPS of $0.76 per share
significantly exceeded Management’s previous guidance of $0.58 to $0.63 per share, and increased 58 percent over Q2 2018
Adjusted EPS of $0.48 per share.

[0001144204-19-024241:8k_2_02:20]
Adjusted EBITDA was $34 million in Q2 2019,
reflecting a 22 percent increase over Q2 2018 Adjusted EBITDA of $28 million.

[0001144204-19-024241:8k_2_02:21]
The increases in Adjusted EBITDA and Adjusted
EPS were driven by higher sales and improved operating performance across the Company, supplemented by specific tax planning strategies
implemented in Q2 2019 which generated a lower effective tax rate in the Quarter versus previous expectations.

[0001144204-19-024241:8k_2_02:22]
Operating Highlights

[0001144204-19-024241:8k_2_02:23]
|  | · | Q2 2019 sales increased 11 percent to $194 million compared to $175 million in Q2 2018. |

[0001144204-19-024241:8k_2_02:24]
|  | · | On a segment basis, Q2 2019 Filtration sales exceeded expectations and increased 20 percent from Q2 2018 with all operating units contributing to the growth driven by significantly higher aerospace (commercial and defense) and navy sales. Test sales increased 5 percent driven by strong project sales domestically and in China. USG sales from Doble increased significantly, while NRG’s sales to renewable energy customers decreased, resulting in a net 5 percent increase in USG sales. Technical Packaging sales increased 6 percent resulting from new product introductions. |

[0001144204-19-024241:8k_2_02:25]
|  | · | SG&A expenses increased nominally (2 percent) in Q2 2019 compared to Q2 2018 primarily as a result of higher sales commissions and normal cost of living adjustments, partially offset by cost reductions. |

[0001144204-19-024241:8k_2_02:26]
|  | · | Entered orders were $232 million in Q2 2019 (book-to-bill of 1.19x) which resulted in an ending backlog of $436 million at March 31, 2019, an increase of $53 million, or 14 percent, from September 30, 2018. |

[0001144204-19-024241:8k_2_02:27]
|  | · | The Q2 2019 effective income tax rate was lower than expected as a result of significant tax planning strategies implemented during the Quarter. |

[0001144204-19-024241:8k_2_02:28]
|  | · | 2019 net cash provided by operating activities was $17 million resulting in $182 million of net debt outstanding (total borrowings less cash on hand) at March 31, 2019, and a 1.5x leverage ratio. Cash flow in Q2 was negatively impacted by the timing of several large cash payments which moved out of the quarter and were received in early April. |

[0001144204-19-024241:8k_2_02:29]
Chairman’s Commentary – Q2
2019

[0001144204-19-024241:8k_2_02:30]
Vic Richey, Chairman and Chief
Executive Officer, commented, “I’m extremely pleased with our Q2 operating results, which came in well above our
expectations. Sales, operating profit, our effective tax rate, Adjusted EPS and entered orders were all better than our plan
and enabled us to significantly beat the top end of our guidance range. Higher sales and operational improvements drove
our Adjusted EPS $0.05 per share above our earlier expectations, and our tax strategies drove a favorable tax rate in Q2 2019
which contributed $0.08 per share above expectations.

[0001144204-19-024241:8k_2_02:31]
“Comparing Q2 2019 to Q2 2018,
we increased sales by 11 percent and improved our Adjusted EBITDA by over 22 percent and 2 points of margin driven by the
strength of the Filtration group and our legacy Doble business. Our Test and Packaging businesses came in generally as
expected and both improved their operating performance over prior year. I’m certain that the current cost
reduction actions we have taken in our Packaging business will have a favorable impact on the second half of the year.

[0001144204-19-024241:8k_2_02:32]
“Looking at Adjusted EBIT margins by segment, Filtration delivered 22 percent up from 18 percent in prior year; Test
maintained 13 percent in both periods; and USG increased to 19 percent up from 16 percent. This operational growth supplemented
by our tax strategies resulted in an increase in our Q2 Adjusted EPS of $0.28 per share, or 58 percent from prior year.

[0001144204-19-024241:8k_2_02:33]
“Test’s Q2 2019 entered
orders were a clear highlight as the group significantly exceeded expectations by booking $58 million in the Quarter and $103
million YTD. Our consolidated orders and strong backlog certainly bode well for the remainder of the year and gives
me confidence for meeting our increased commitments.

[0001144204-19-024241:8k_2_02:34]
“On the M&A front we maintain a
robust pipeline of opportunities in both Filtration and USG and continue to work these aggressively, and I’m hopeful that
we will add to our portfolio before the end of the fiscal year. Consistent with our history, we will remain prudent and committed
to our disciplined approach of balancing ROIC and protecting our balance sheet.

[0001144204-19-024241:8k_2_02:35]
“Updating the Doble
headquarters relocation from Watertown to Marlborough, we recently signed the lease on the new property and we expect to be
moved in and fully operational by December 31, 2019. The Doble team is looking forward to having all of its Boston area
staff co-located in a single, customer-friendly facility as we all believe it will further enhance our operational efficiency
and effectiveness, while lowering our facility operating costs.

[0001144204-19-024241:8k_2_02:36]
“As we look toward the second half of
2019, we plan to build on the successes we achieved in the first half and expect to continue benefitting from our disciplined operating
culture and our lower cost structure. Our solid market positions and tangible growth opportunities across the Company provide us
with a favorable view of the future with our goal remaining unchanged – to increase long-term shareholder value.”

[0001144204-19-024241:8k_2_02:37]
Dividend Payment

[0001144204-19-024241:8k_2_02:38]
The next quarterly cash dividend of $0.08
per share will be paid on July 19, 2019 to stockholders of record on July 5, 2019.

[0001144204-19-024241:8k_2_02:39]
New Revenue Recognition Standard

[0001144204-19-024241:8k_2_02:40]
On October 1, 2018, the Company
formally adopted ASC Topic 606, Revenue from Contracts with Customers (“New Revenue Recognition Standard”)
using the modified retrospective method. Operating results for reporting periods beginning after October 1, 2018 will be
presented under the New Revenue Recognition Standard, while the results from prior periods will not be adjusted and will
continue to be presented using the accounting standards in effect for those periods.  This
new standard will have no impact on 2019 cash flows.

[0001144204-19-024241:8k_2_02:41]
Previously Disclosed Cost Reduction / Restructuring Actions

[0001144204-19-024241:8k_2_02:42]
Refer to our November 15, 2018 and
February 7, 2019 earnings releases for details of our cost reduction and restructuring actions related to the Doble
building sale and relocation, Technical Packaging’s cost reduction actions, and VACCO’s aircraft / aerospace business
move to PTI.

[0001144204-19-024241:8k_2_02:43]
All of these actions are intended to improve
operating efficiency, enhance ROIC, generate additional free cash flow, and enhance the Company’s competitiveness across
several end-markets, thereby, accelerating sales and earnings growth in the future.

[0001144204-19-024241:8k_2_02:44]
Updated Business Outlook – 2019

[0001144204-19-024241:8k_2_02:45]
As a result of the Company’s YTD performance
and its improved outlook for the remainder of the year, Management is raising its 2019 Adjusted EPS guidance to $3.05 to $3.10
per share from its earlier expectations of $2.95 to $3.05 per share.

[0001144204-19-024241:8k_2_02:46]
Management continues to see meaningful
organic sales, Adjusted EBIT, and Adjusted EBITDA growth opportunities across each of the Company’s business segments
and anticipates growth rates in 2019 and beyond that will generally exceed the broader industrial market. The organic growth
described in previous earnings releases is expected to be enhanced by additional M&A contributions.

[0001144204-19-024241:8k_2_02:47]
Management expects Q3 2019 Adjusted EPS
to be in the range of $0.75 to $0.80 per share. The timing of quarterly sales and earnings throughout the year, coupled with the
discrete charges described above within the respective quarters will impact quarterly comparability.

[0001144204-19-024241:8k_2_02:48]
Conference Call

[0001144204-19-024241:8k_2_02:49]
The Company will host a conference call
today, May 7, at 4:00 p.m. Central Time, to discuss the Company’s Q2 2019 results. A live audio webcast will be
available on the Company’s website at www.escotechnologies.com. Please access the website at least 15 minutes prior
to the call to register, download and install any necessary audio software. A replay of the conference call will be available on the Company’s website noted above or by phone (dial 1-855-859-2056 and enter the pass code 6106418).

[0001144204-19-024241:8k_2_02:50]
Forward-Looking Statements

[0001144204-19-024241:8k_2_02:51]
Statements in this press release regarding
the timing and amounts of the Company’s expected quarterly, 2019 full year and beyond results, revenue and sales growth,
EPS, Adjusted EPS, EPS growth, cash, EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA, the realization of operational efficiencies,
the Company’s competitiveness and the costs and savings resulting from operational improvements and cost reduction actions,
the Company’s ability to increase operating margins, realize financial goals and increase shareholder value, the success
of acquisition efforts, the long-term success of the Company, and any other statements which are not strictly historical are “forward-looking”
statements within the meaning of the safe harbor provisions of the federal securities laws.

[0001144204-19-024241:8k_2_02:52]
Investors are cautioned that such
statements are only predictions and speak only as of the date of this release, and the Company undertakes no duty to update
them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ
materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the
Company’s operations and business environment including but not limited to those described in Item 1A, “Risk
Factors”, of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2018, and
the following: the success of the Company’s competitors; weakening of economic conditions in served markets; changes in
customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties; delivery delays
or defaults by customers; material  changes in the costs and availability of certain raw materials; the appropriation,
allocation and availability of Government funds; the termination for convenience of Government and other customer contracts;
the timing and content of future contract awards or customer orders; performance issues with key customers, suppliers and
subcontractors; labor disputes; the impacts of natural disasters on the Company’s operations and those of the
Company’s customers and suppliers; changes in laws and regulations, including but not limited to changes in accounting
standards and taxation requirements; changes in interest rates; costs relating to environmental matters arising from current
or former facilities; financial exposure in connection with Company guarantees of certain Aclara contracts; the availability
of select acquisitions; and the uncertainty regarding the ultimate resolution of current disputes, claims, litigation or
arbitration.

[0001144204-19-024241:8k_2_02:53]
Non-GAAP Financial Measures

[0001144204-19-024241:8k_2_02:54]
The financial measures EBIT, EBITDA, Adjusted
EBITDA and Adjusted EPS are presented in this press release. The Company defines “EBIT” as earnings before interest
and taxes, “EBITDA” as earnings before interest, taxes, depreciation and amortization, “Adjusted EBITDA”
as EBITDA excluding certain defined charges, and “Adjusted EPS” as GAAP earnings per share (EPS) excluding the net
impact of the items described above which were $0.04 per share in Q2 2019.

[0001144204-19-024241:8k_2_02:55]
EBIT, EBITDA, Adjusted EBITDA and Adjusted
EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management believes that
EBIT, EBITDA and Adjusted EBITDA are useful in assessing the operational profitability of the Company’s business segments
because they exclude interest, taxes, depreciation and amortization, which are generally accounted for across the entire Company
on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company
as well as incentive compensation. The Company believes that the presentation of EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS
provides important supplemental information to investors by facilitating comparisons with other companies, many of which use similar
non-GAAP financial measures to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace
any measures of performance determined in accordance with GAAP.

[0001144204-19-024241:8k_2_02:56]
ESCO, headquartered in St. Louis, Missouri:
Manufactures highly-engineered filtration and fluid control products for the aviation, space and process markets worldwide; is
the industry leader in RF shielding and EMC test products; provides diagnostic instruments, software and services for the benefit
of industrial power users and the electric utility and renewable energy industries; and, produces custom thermoformed packaging,
pulp-based packaging, and specialty products for medical and commercial markets. Further information regarding ESCO and its subsidiaries
is available on the Company’s website at www.escotechnologies.com.

[0001144204-19-024241:8k_2_02:57]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001144204-19-024241:8k_2_02:58]
Condensed Consolidated Statements of Operations
(Unaudited)

[0001144204-19-024241:8k_2_02:59]
(Dollars in thousands, except per share
amounts)

[0001144204-19-024241:8k_2_02:60]
|  |  | Three Months Ended March 31, 2019 |  |  | Three Months Ended March 31, 2018 |  |
| Net Sales |  | $ | 193,949 |  |  |  | 174,778 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 121,946 |  |  |  | 112,370 |  |
| Selling, general and administrative expenses |  |  | 41,673 |  |  |  | 40,749 |  |
| Amortization of intangible assets |  |  | 4,620 |  |  |  | 4,564 |  |
| Interest expense |  |  | 1,925 |  |  |  | 2,036 |  |
| Other (income) expenses, net |  |  | 2,430 |  |  |  | 1,475 |  |
| Total costs and expenses |  |  | 172,594 |  |  |  | 161,194 |  |
| Earnings before income taxes |  |  | 21,355 |  |  |  | 13,584 |  |
| Income taxes |  |  | 2,558 |  |  |  | 3,590 |  |
| Net earnings |  | $ | 18,797 |  |  |  | 9,994 |  |
| Diluted EPS - GAAP |  | $ | 0.72 |  |  |  | 0.38 |  |
| Diluted EPS - As Adjusted |  | $ | 0.76 | (1) |  |  | 0.48 | (2) |
| Diluted average common shares O/S: |  |  | 26,036 |  |  |  | 25,988 |  |

[0001144204-19-024241:8k_2_02:61]
|  | (1) | Q2 2019 Adjusted EPS excluded $0.04 per share net impact of restructuring charges incurred primarily at Plastique, Doble and PTI/VACCO during the second quarter of 2019. |
|  | (2) | Q2 2018 Adjusted EPS excluded $0.10 per share net impact of restructuring charges incurred at Doble & PTI during the second quarter of 2018. |

[0001144204-19-024241:8k_2_02:62]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001144204-19-024241:8k_2_02:63]
Condensed Consolidated Statements of Operations
(Unaudited)

[0001144204-19-024241:8k_2_02:64]
(Dollars in thousands, except per share
amounts)

[0001144204-19-024241:8k_2_02:65]
|  |  | Six Months Ended March 31, 2019 |  |  | Six Months Ended March 31, 2018 |  |
| Net Sales |  | $ | 376,546 |  |  |  | 348,273 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 240,854 |  |  |  | 224,106 |  |
| Selling, general and administrative expenses |  |  | 82,666 |  |  |  | 82,903 |  |
| Amortization of intangible assets |  |  | 9,272 |  |  |  | 9,010 |  |
| Interest expense |  |  | 3,815 |  |  |  | 4,221 |  |
| Other (income) expenses, net |  |  | (4,673 | ) |  |  | 1,648 |  |
| Total costs and expenses |  |  | 331,934 |  |  |  | 321,888 |  |
| Earnings before income taxes |  |  | 44,612 |  |  |  | 26,385 |  |
| Income taxes |  |  | 8,498 |  |  |  | (18,280 | ) |
| Net earnings |  | $ | 36,114 |  |  |  | 44,665 |  |
| Diluted EPS - GAAP |  | $ | 1.38 |  |  |  | 1.72 |  |
| Diluted EPS - As Adjusted |  | $ | 1.23 | (1) |  |  | 0.82 | (2) |
| Diluted average common shares O/S: |  |  | 26,078 |  |  |  | 26,034 |  |

[0001144204-19-024241:8k_2_02:66]
| (1) | YTD Q2 2019 Adjusted EPS excluded $0.15 per share net impact mainly from the gain on the sale of the Doble Watertown property partially offset by certain restructuring charges primarily at Plastique, PTI/VACCO & Doble. |
| (2) | YTD Q2 2018 Adjusted EPS excluded $0.90 per share net impact of the $25 million tax benefit recorded related to U.S. Tax Reform partially offset by restructuring charges incurred at Doble & PTI during the first six months of 2018. |

[0001144204-19-024241:8k_2_02:67]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001144204-19-024241:8k_2_02:68]
Condensed Business Segment Information (Unaudited)

[0001144204-19-024241:8k_2_02:69]
(Dollars in thousands)

[0001144204-19-024241:8k_2_02:70]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | Q2 2019 |  |  | Q2 2018 |  |  | Q2 2019 |  |  | Q2 2018 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 79,478 |  |  |  | 65,775 |  |  |  | 79,478 |  |  |  | 65,775 |  |
| Test |  |  | 42,875 |  |  |  | 40,805 |  |  |  | 42,875 |  |  |  | 40,805 |  |
| USG |  |  | 48,890 |  |  |  | 46,699 |  |  |  | 48,890 |  |  |  | 46,699 |  |
| Technical Packaging |  |  | 22,706 |  |  |  | 21,499 |  |  |  | 22,706 |  |  |  | 21,499 |  |
| Totals |  | $ | 193,949 |  |  |  | 174,778 |  |  |  | 193,949 |  |  |  | 174,778 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 17,443 |  |  |  | 11,118 |  |  |  | 17,806 |  |  |  | 11,566 |  |
| Test |  |  | 5,554 |  |  |  | 5,300 |  |  |  | 5,554 |  |  |  | 5,300 |  |
| USG |  |  | 8,767 |  |  |  | 5,626 |  |  |  | 9,241 |  |  |  | 7,543 |  |
| Technical Packaging |  |  | 1,602 |  |  |  | 1,885 |  |  |  | 2,021 |  |  |  | 1,885 |  |
| Corporate |  |  | (10,086 | ) |  |  | (8,309 | ) |  |  | (9,977 | ) |  |  | (8,086 | ) |
| Consolidated EBIT |  |  | 23,280 |  |  |  | 15,620 |  |  |  | 24,645 |  |  |  | 18,208 |  |
| Less: Interest expense |  |  | (1,925 | ) |  |  | (2,036 | ) |  |  | (1,925 | ) |  |  | (2,036 | ) |
| Less: Income tax expense |  |  | (2,558 | ) |  |  | (3,590 | ) |  |  | (2,853 | ) |  |  | (3,524 | ) |
| Net earnings |  | $ | 18,797 |  |  |  | 9,994 |  |  |  | 19,867 |  |  |  | 12,648 |  |

[0001144204-19-024241:8k_2_02:71]
Note 1: Adjusted net earnings were $19.9 million in Q2 ‘19
which excluded $1.1 million (or $0.04 per share) net impact of the restructuring charges incurred at Doble, Plastique, PTI and
VACCO during the second quarter of 2019.

[0001144204-19-024241:8k_2_02:72]
Note 2: Adjusted net earnings were $12.6 million in Q2 ‘18
which excluded $2.7 million (or $0.10 per share) net impact of the restructuring charges incurred at Doble and PTI during the second
quarter of 2018.

[0001144204-19-024241:8k_2_02:73]
EBITDA Reconciliation to Net earnings:

[0001144204-19-024241:8k_2_02:74]
|  |  |  |  |  |  |  |  | Adjusted |  |  | Adjusted |  |
|  |  | Q2 2019 |  |  | Q2 2018 |  |  | Q2 2019 |  |  | Q2 2018 |  |
| Consolidated EBITDA |  | $ | 32,555 |  |  |  | 25,192 |  |  |  | 33,920 |  |  |  | 27,780 |  |
| Less: Depr & Amort |  |  | (9,275 | ) |  |  | (9,572 | ) |  |  | (9,275 | ) |  |  | (9,572 | ) |
| Consolidated EBIT |  |  | 23,280 |  |  |  | 15,620 |  |  |  | 24,645 |  |  |  | 18,208 |  |
| Less: Interest expense |  |  | (1,925 | ) |  |  | (2,036 | ) |  |  | (1,925 | ) |  |  | (2,036 | ) |
| Less: Income tax expense |  |  | (2,558 | ) |  |  | (3,590 | ) |  |  | (2,853 | ) |  |  | (3,524 | ) |
| Net earnings |  | $ | 18,797 |  |  |  | 9,994 |  |  |  | 19,867 |  |  |  | 12,648 |  |

[0001144204-19-024241:8k_2_02:75]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001144204-19-024241:8k_2_02:76]
Condensed Business Segment Information (Unaudited)

[0001144204-19-024241:8k_2_02:77]
(Dollars in thousands)

[0001144204-19-024241:8k_2_02:78]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | YTD Q2 |  |  | YTD Q2 |  |  | YTD Q2 |  |  | YTD Q2 |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 145,702 |  |  |  | 125,810 |  |  |  | 145,702 |  |  |  | 125,810 |  |
| Test |  |  | 84,161 |  |  |  | 78,334 |  |  |  | 84,161 |  |  |  | 78,334 |  |
| USG |  |  | 104,745 |  |  |  | 102,453 |  |  |  | 104,745 |  |  |  | 102,453 |  |
| Technical Packaging |  |  | 41,938 |  |  |  | 41,676 |  |  |  | 41,938 |  |  |  | 41,676 |  |
| Totals |  | $ | 376,546 |  |  |  | 348,273 |  |  |  | 376,546 |  |  |  | 348,273 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 28,053 |  |  |  | 20,764 |  |  |  | 28,513 |  |  |  | 21,212 |  |
| Test |  |  | 8,864 |  |  |  | 7,895 |  |  |  | 8,864 |  |  |  | 7,895 |  |
| USG |  |  | 30,313 |  |  |  | 16,277 |  |  |  | 23,100 |  |  |  | 18,194 |  |
| Technical Packaging |  |  | 1,708 |  |  |  | 2,850 |  |  |  | 2,396 |  |  |  | 2,850 |  |
| Corporate |  |  | (20,511 | ) |  |  | (17,180 | ) |  |  | (20,037 | ) |  |  | (16,957 | ) |
| Consolidated EBIT |  |  | 48,427 |  |  |  | 30,606 |  |  |  | 42,836 |  |  |  | 33,194 |  |
| Less: Interest expense |  |  | (3,815 | ) |  |  | (4,221 | ) |  |  | (3,815 | ) |  |  | (4,221 | ) |
| Less: Income tax |  |  | (8,498 | ) |  |  | 18,280 |  |  |  | (6,899 | ) |  |  | (6,705 | ) |
| Net earnings |  | $ | 36,114 |  |  |  | 44,665 |  |  |  | 32,122 |  |  |  | 22,268 |  |

[0001144204-19-024241:8k_2_02:79]
Note 1: Adjusted net earnings were $32.1 million in YTD Q2 ‘19
which excluded $4.0 million (or $0.15 per share) net impact of the gain on the sale of the Doble Watertown property partially offset
by charges related to restructuring actions at Doble, Plastique, PTI & VACCO.

[0001144204-19-024241:8k_2_02:80]
Note 2: Adjusted net earnings were $22.3 million in YTD Q2 ‘18
which excluded $2.7 million (or $0.10 per share) net impact of the restructuring charges incurred at Doble and PTI during the first
six months of 2018, and the $25 million (or $1.00 per share) tax benefit recorded related to U.S. Tax Reform.

[0001144204-19-024241:8k_2_02:81]
EBITDA Reconciliation to Net earnings:

[0001144204-19-024241:8k_2_02:82]
|  |  |  |  |  |  |  |  | Adjusted |  |  | Adjusted |  |
|  |  | YTD Q2 |  |  | YTD Q2 |  |  | YTD Q2 |  |  | YTD Q2 |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Consolidated EBITDA |  | $ | 67,206 |  |  |  | 49,404 |  |  |  | 61,615 |  |  |  | 51,992 |  |
| Less: Depr & Amort |  |  | (18,779 | ) |  |  | (18,798 | ) |  |  | (18,779 | ) |  |  | (18,798 | ) |
| Consolidated EBIT |  |  | 48,427 |  |  |  | 30,606 |  |  |  | 42,836 |  |  |  | 33,194 |  |
| Less: Interest expense |  |  | (3,815 | ) |  |  | (4,221 | ) |  |  | (3,815 | ) |  |  | (4,221 | ) |
| (Less) Plus: Income tax |  |  | (8,498 | ) |  |  | 18,280 |  |  |  | (6,899 | ) |  |  | (6,705 | ) |
| Net earnings |  | $ | 36,114 |  |  |  | 44,665 |  |  |  | 32,122 |  |  |  | 22,268 |  |

[0001144204-19-024241:8k_2_02:83]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001144204-19-024241:8k_2_02:84]
Condensed Consolidated Balance Sheets (Unaudited)

[0001144204-19-024241:8k_2_02:85]
(Dollars in thousands)

[0001144204-19-024241:8k_2_02:86]
|  |  | March 31, 2019 |  |  | September 30, 2018 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 34,955 |  |  |  | 30,477 |  |
| Accounts receivable, net |  |  | 159,923 |  |  |  | 163,740 |  |
| Contract assets |  |  | 100,540 |  |  |  | 53,034 |  |
| Inventories |  |  | 124,493 |  |  |  | 135,416 |  |
| Other current assets |  |  | 16,048 |  |  |  | 13,356 |  |
| Total current assets |  |  | 435,959 |  |  |  | 396,023 |  |
| Property, plant and equipment, net |  |  | 132,806 |  |  |  | 134,954 |  |
| Intangible assets, net |  |  | 338,514 |  |  |  | 345,353 |  |
| Goodwill |  |  | 381,304 |  |  |  | 381,652 |  |
| Other assets |  |  | 5,380 |  |  |  | 7,140 |  |
|  |  | $ | 1,293,963 |  |  |  | 1,265,122 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Short-term borrowings and current |  | $ | 20,000 |  |  |  | 20,000 |  |
| maturities of long-term debt |  |  |  |  |  |  |  |  |
| Accounts payable |  |  | 58,090 |  |  |  | 63,033 |  |
| Contract liabilities |  |  | 55,453 |  |  |  | 49,035 |  |
| Other current liabilities |  |  | 68,402 |  |  |  | 68,462 |  |
| Total current liabilities |  |  | 201,945 |  |  |  | 200,530 |  |
| Deferred tax liabilities |  |  | 62,938 |  |  |  | 64,794 |  |
| Other liabilities |  |  | 37,684 |  |  |  | 40,388 |  |
| Long-term debt |  |  | 197,000 |  |  |  | 200,000 |  |
| Shareholders’ equity |  |  | 794,396 |  |  |  | 759,410 |  |
|  |  | $ | 1,293,963 |  |  |  | 1,265,122 |  |

[0001144204-19-024241:8k_2_02:87]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001144204-19-024241:8k_2_02:88]
Consolidated Statements of Cash Flows (Unaudited)

[0001144204-19-024241:8k_2_02:89]
(Dollars in thousands)

[0001144204-19-024241:8k_2_02:90]
|  |  | Six Months Ended March 31, 2019 |  |
| Cash flows from operating activities: |  |  |  |  |
| Net earnings |  | $ | 36,114 |  |
| Adjustments to reconcile net earnings |  |  |  |  |
| to net cash provided by operating activities: |  |  |  |  |
| Depreciation and amortization |  |  | 18,779 |  |
| Stock compensation expense |  |  | 2,557 |  |
| Changes in assets and liabilities |  |  | (28,847 | ) |
| Change in PP&E from gain on building sale |  |  | (8,922 | ) |
| Pension contributions |  |  | (833 | ) |
| Effect of deferred taxes |  |  | (1,856 | ) |
| Net cash provided by operating activities |  |  | 16,992 |  |
| Cash flows from investing activities: |  |  |  |  |
| Capital expenditures |  |  | (17,425 | ) |
| Additions to capitalized software |  |  | (4,494 | ) |
| Proceeds from sale of building and land |  |  | 17,201 |  |
| Net cash used by investing activities |  |  | (4,718 | ) |
| Cash flows from financing activities: |  |  |  |  |
| Proceeds from long-term debt and short-term borrowings |  |  | 23,000 |  |
| Principal payments on long-term debt |  |  | (26,000 | ) |
| Dividends paid |  |  | (4,146 | ) |
| Other |  |  | 370 |  |
| Net cash used by financing activities |  |  | (6,776 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (1,020 | ) |
| Net increase in cash and cash equivalents |  |  | 4,478 |  |
| Cash and cash equivalents, beginning of period |  |  | 30,477 |  |
| Cash and cash equivalents, end of period |  | $ | 34,955 |  |

[0001144204-19-024241:8k_2_02:91]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001144204-19-024241:8k_2_02:92]
Other Selected Financial Data (Unaudited)

[0001144204-19-024241:8k_2_02:93]
(Dollars in thousands)

[0001144204-19-024241:8k_2_02:94]
| Backlog And Entered Orders - Q2 FY 2019 |  | Filtration |  |  | Test |  |  | USG |  |  | Technical Packaging |  |  | Total |  |
| Beginning Backlog - 1/1/19 |  | $ | 221,735 |  |  |  | 126,494 |  |  |  | 36,872 |  |  |  | 13,196 |  |  |  | 398,297 |  |
| Entered Orders |  |  | 100,750 |  |  |  | 57,586 |  |  |  | 51,037 |  |  |  | 22,342 |  |  |  | 231,715 |  |
| Sales |  |  | (79,478 | ) |  |  | (42,875 | ) |  |  | (48,890 | ) |  |  | (22,706 | ) |  |  | (193,949 | ) |
| Ending Backlog - 3/31/19 |  | $ | 243,007 |  |  |  | 141,205 |  |  |  | 39,019 |  |  |  | 12,832 |  |  |  | 436,063 |  |

[0001144204-19-024241:8k_2_02:95]
| Backlog And Entered Orders - YTD Q2 FY 2019 |  | Filtration |  |  | Test |  |  | USG |  |  | Technical Packaging |  |  | Total |  |
| Beginning Backlog - 10/1/18 |  | $ | 204,227 |  |  |  | 122,350 |  |  |  | 40,727 |  |  |  | 15,467 |  |  |  | 382,771 |  |
| Entered Orders |  |  | 184,482 |  |  |  | 103,016 |  |  |  | 103,037 |  |  |  | 39,303 |  |  |  | 429,838 |  |
| Sales |  |  | (145,702 | ) |  |  | (84,161 | ) |  |  | (104,745 | ) |  |  | (41,938 | ) |  |  | (376,546 | ) |
| Ending Backlog - 3/31/19 |  | $ | 243,007 |  |  |  | 141,205 |  |  |  | 39,019 |  |  |  | 12,832 |  |  |  | 436,063 |  |

## item 5.02 — body, verbatim

[0001144204-19-024241:8k_body:1]
Item 5.02  Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements
of Certain Officers

[0001144204-19-024241:8k_body:2]
Amendment to Form of Performance-Accelerated Restricted
Share Award Agreement

[0001144204-19-024241:8k_body:3]
On May 1, 2019, the Human Resources and Compensation Committee
of the Company’s Board of Directors approved an amended standard form of Award Agreement for performance-accelerated restricted
share (PARS) awards granted under the Company’s 2018 Omnibus Incentive Plan (the “Plan”) to the Company’s
executive officers and certain other management personnel, effective beginning with the awards granted on that date. The amended
form of Award Agreement is included herein as Exhibit 10.1.

[0001144204-19-024241:8k_body:4]
In addition to updating certain language in the award, the amended
form includes alternative language tailored to Massachusetts law for recipients in that state, adds an express acknowledgment of
review and understanding by the recipient, and conforms the language regarding share ownership requirements to the Company’s
share ownership policy requiring a Named Executive Officer of the Company to hold 100% of the shares distributed to him/her pursuant
to the award (net of tax withholdings) until his/her ownership requirement is satisfied.
