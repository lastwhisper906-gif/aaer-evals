# ESE 10-Q controls and the auditor's report


## item_4_controls

[0001144204-19-006206:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0001144204-19-006206:item_4_controls:2]
The Company carried out an evaluation, under the supervision
and with the participation of Management, including the Company’s Chief Executive Officer and Chief Financial Officer, of
the effectiveness of the design and operation of the Company’s disclosure controls and procedures as of the end of the period
covered by this report. Based upon that evaluation, due to the material weakness in the Company’s internal control over financial
reporting related to the ineffective design and operation of controls impacting the deferred revenue general ledger account, the
Company’s Chief Executive Officer and Chief Financial Officer concluded that the Company’s disclosure controls and
procedures were ineffective as of that date.

[0001144204-19-006206:item_4_controls:3]
As previously disclosed in Part II Item 9A in the Company’s
Annual Report on Form 10-K for the year ended September 30, 2018, Management concluded there was a material weakness in the Company’s
internal control over financial reporting related to the ineffective design and operation of controls impacting the deferred revenue
general ledger account. Remedial actions have been identified to address these controls, including enhancing our policies and procedures
related to the deferred revenue reconciliation and review, and providing additional training to our segment finance department.
These new procedures are in the process of being implemented but have not been in place long enough to provide sufficient assurances
to support the conclusion that the above identified material weakness has been fully remediated as of December 31, 2018.

[0001144204-19-006206:item_4_controls:4]
Other than the above, there have been no changes in the Company’s
internal control over financial reporting (as defined in Rule 13a-15(f) under the Exchange Act) during the period covered by this
report that has materially affected, or is reasonably likely to materially affect, the Company’s internal control over financial
reporting.

[0001144204-19-006206:item_4_controls:5]
23
