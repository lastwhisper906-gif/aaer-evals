# ESE 8-K — 0000866706-19-000004 filed 2019-02-07

## item codes, every 8-K on or before 2019-02-11

- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2019-02-11

- none on or before 2019-02-11

## item 2.02 — earnings release, exhibit 99.1

[0000866706-19-000004:8k_2_02:1]
EX-99.1
3
escopressreleasefeb2019.htm
ESCO FIRST QUARTER FISCAL 2019 RESULTS

[0000866706-19-000004:8k_2_02:2]
EXHIBIT 99.1

[0000866706-19-000004:8k_2_02:3]
NEWS FROM

[0000866706-19-000004:8k_2_02:4]
For more information contact:

[0000866706-19-000004:8k_2_02:5]
Kate Lowrey

[0000866706-19-000004:8k_2_02:6]
Director, Investor Relations

[0000866706-19-000004:8k_2_02:7]
ESCO Technologies Inc.

[0000866706-19-000004:8k_2_02:8]
(314) 213-7277

[0000866706-19-000004:8k_2_02:9]
ESCO ANNOUNCES FIRST QUARTER FISCAL 2019 RESULTS

[0000866706-19-000004:8k_2_02:10]
- GAAP EPS $0.66 Driven by Gain on Sale of Doble Headquarters Building -

[0000866706-19-000004:8k_2_02:11]
- Adjusted EPS $0.47 Beats Mgmt Guidance by $0.02 and Consensus by $0.03 -

[0000866706-19-000004:8k_2_02:12]
ST. LOUIS, February 7, 2019 – ESCO Technologies Inc. (NYSE: ESE) (ESCO, or the Company) today reported its operating results for the first quarter ended December 31, 2018 (Q1 2019), compared to the first quarter ended December 31, 2017 (Q1 2018).

[0000866706-19-000004:8k_2_02:13]
The financial results presented include certain non-GAAP financial measures such as EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS, as defined within the "Non-GAAP Financial Measures" described below. Any non-GAAP financial measures presented are reconciled to their respective GAAP equivalents.

[0000866706-19-000004:8k_2_02:14]
Management believes these non-GAAP financial measures are useful in assessing the ongoing operational profitability of the Company's business segments, and therefore, allow shareholders better visibility into the Company's underlying operations. See "Non-GAAP Financial Measures" described below.

[0000866706-19-000004:8k_2_02:15]
Earnings Summary

[0000866706-19-000004:8k_2_02:16]
Q1 2019 GAAP EPS of $0.66 per share included $0.19 per share from a gain on the sale of Doble's headquarters building in Watertown, Massachusetts, partially offset by charges incurred from cost reduction actions taken in Technical Packaging and at Doble, and costs incurred to move the aircraft / aerospace business from VACCO to PTI as described in the Company's November 15, 2018 earnings release. The $0.19 per share was excluded when determining Q1 2019 Adjusted EPS. GAAP net earnings were $17 million in Q1 2019.

[0000866706-19-000004:8k_2_02:17]
Q1 2018 GAAP EPS of $1.33 per share included a net tax benefit of $25 million, or $1.00 per share from the implementation of the December 2017 "Tax Cuts and Jobs Act" (U.S. Tax Reform). The $1.00 per share was excluded when determining Q1 2018 Adjusted EPS. GAAP net earnings were $35 million in Q1 2018.

[0000866706-19-000004:8k_2_02:18]
Q1 2019 Adjusted EPS of $0.47 per share exceeded Management's previous guidance of $0.40 to $0.45 per share, and increased 42 percent over Q1 2018 Adjusted EPS of $0.33 per share.

[0000866706-19-000004:8k_2_02:19]
Adjusted EBITDA was $28 million in Q1 2019, reflecting a 14 percent increase over Q1 2018 Adjusted EBITDA of $24 million.

[0000866706-19-000004:8k_2_02:20]
The increases in Adjusted EPS and Adjusted EBITDA were driven by higher sales and improved operating performance within Filtration, USG, and Test.

[0000866706-19-000004:8k_2_02:21]
Operating Highlights

[0000866706-19-000004:8k_2_02:22]
| · | Q1 2019 sales increased 5 percent to $183 million compared to $173 million in Q1 2018. |

[0000866706-19-000004:8k_2_02:23]
| · | On a segment basis, Q1 2019 Filtration sales exceeded expectations and increased 10 percent from Q1 2018 as commercial aerospace and navy sales increased significantly. Test sales also exceeded expectations and increased 10 percent driven by strong project sales domestically and in China. USG sales from Doble, Morgan Schaffer and Vanguard increased 4 percent, while NRG's sales to renewable energy customers decreased, resulting in flat USG net sales. Technical Packaging sales decreased five percent (consistent with expectations) due to project timing. |

[0000866706-19-000004:8k_2_02:24]
| · | SG&A expenses decreased 3 percent in Q1 2019 compared to Q1 2018 as a result of the cost reduction actions taken throughout 2018. |

[0000866706-19-000004:8k_2_02:25]
| · | Entered orders were $198 million in Q1 2019 (book-to-bill of 1.08x) which resulted in an ending backlog of $398 million at December 31, 2018, an increase of $15 million, or 4 percent, from September 30, 2018. |

[0000866706-19-000004:8k_2_02:26]
| · | Q1 2019 GAAP and Adjusted income tax rates were 25.5 percent and 24.8 percent, respectively, which were slightly higher than Management's previous expectations of 24 percent. The GAAP effective tax rate in Q1 2018 was significantly impacted by the $25 million net tax benefit recorded as a result of U.S. Tax Reform, and was 33.5 percent on an Adjusted basis when excluding the net tax benefit. |

[0000866706-19-000004:8k_2_02:27]
| · | Q1 2019 net cash provided by operating activities was $8 million resulting in $179 million of net debt outstanding (total borrowings less cash on hand) at December 31, 2018, with a 1.5x leverage ratio. |

[0000866706-19-000004:8k_2_02:28]
Chairman's Commentary – Q1 2019

[0000866706-19-000004:8k_2_02:29]
Vic Richey, Chairman and Chief Executive Officer, commented, "I'm pleased with the way we started the year as Q1's operating results came in above our original expectations at most of our operating units. Sales, earnings, cash flow and entered orders all came in better than plan which enabled us to beat the top end of our Adjusted EPS guidance range by $0.02 per share.

[0000866706-19-000004:8k_2_02:30]
"On an Adjusted basis, we increased our Q1 2019 earnings 44 percent over prior year driven by the strength of our Filtration, Test and USG businesses which all contributed meaningfully to our earnings growth. Our Packaging business came in generally as expected and I'm certain that the cost reduction actions that are underway will begin to have a favorable impact in the second half of the year.

[0000866706-19-000004:8k_2_02:31]
"Touching on a few highlights of our Q1 performance compared to Q1 2018: Filtration sales increased 10 percent driven by the continued strength of our commercial aerospace and navy business; Test sales also increased 10 percent on the strength of its backlog and new project wins; Doble, Vanguard and Morgan Schaffer had solid sales and earnings growth and exceeded expectations, but we continued to experience some softness in the renewable energy space. Despite some softness at NRG, USG delivered an Adjusted EBIT margin of 25 percent in Q1 2019, up from 19 percent in Q1 2018.

[0000866706-19-000004:8k_2_02:32]
"Our entered orders were another bright spot in Q1 as we booked nearly $200 million of new business and increased our backlog over $15 million from the start of the year, and that is despite beating our sales forecast. I believe this bodes well for meeting our commitments for the balance of the year.

[0000866706-19-000004:8k_2_02:33]
"Additionally, we generated a meaningful amount of cash during Q1 which enabled us to continue to pay down debt and positions us well for future M&A spending.

[0000866706-19-000004:8k_2_02:34]
"On the M&A front we continue to evaluate and diligence a robust pipeline of opportunities in both Filtration and USG and continue to work these aggressively. Consistent with our history, we will remain prudent and committed to our disciplined approach of balancing ROIC and protecting our balance sheet.

[0000866706-19-000004:8k_2_02:35]
"Our cost reduction actions are proceeding as planned and are on budget and on schedule. I'm pleased to report that we are in lease negotiations for a new Doble headquarters building in Marlborough. I'm looking forward to having all of the Doble staff co-located in a single, customer-friendly facility as I believe it will further enhance our operational efficiency and effectiveness, while lowering our operating costs. The move is expected to be completed by December 2019.

[0000866706-19-000004:8k_2_02:36]
"As we look forward in 2019, we plan to build on the successes we achieved in Q1 and expect to continue benefitting from our lower cost structure. Our solid market positions and tangible growth opportunities across the Company provide us with a favorable view of the future with our goal remaining unchanged – to increase long-term shareholder value."

[0000866706-19-000004:8k_2_02:37]
Dividend Payment

[0000866706-19-000004:8k_2_02:38]
The next quarterly cash dividend of $0.08 per share will be paid on April 18, 2019 to stockholders of record on April 3, 2019.

[0000866706-19-000004:8k_2_02:39]
New Revenue Recognition Standard

[0000866706-19-000004:8k_2_02:40]
On October 1, 2018, the Company formally adopted ASC Topic 606, Revenue from Contracts with Customers ("New Revenue Recognition Standard") using the modified retrospective method. Operating results for reporting periods beginning after October 1, 2018 will be presented under the New Revenue Recognition Standard, while the results from prior periods will not be adjusted and will continue to be presented using our historic accounting policies. This new standard will have no impact on 2019 cash flows.

[0000866706-19-000004:8k_2_02:41]
Cost Reduction / Restructuring Actions

[0000866706-19-000004:8k_2_02:42]
To enhance Doble's ROIC and further improve its operating efficiency, in October 2018, the Company sold Doble's headquarters building in Watertown Massachusetts to a real estate developer for approximately $18 million in cash, and later in 2019, will consolidate its operations into one location in Marlborough Massachusetts where Doble has an existing administrative facility. The sale resulted in a pretax gain recognized in Q1 2019. The net proceeds were used to further pay down debt, and the upcoming move will improve operational efficiency by having Doble's entire Boston area operations co-located in a single, lower cost, more modern facility by the end of calendar 2019. The building gain and the restructuring / move costs will be excluded when calculating 2019 Adjusted EPS.

[0000866706-19-000004:8k_2_02:43]
To reduce Technical Packaging's cost structure and increase its EBIT margins, the Company initiated a cost reduction action in Europe to close Plastique's headquarters in Tunbridge Wells, UK and consolidate its new product design and administrative functions into the remaining facilities in Nottingham, UK and Poznan, Poland. This move is expected to generate meaningful operating improvements and will enable Plastique to be more competitive in its various end-markets. The shut down and move costs (approximately $2 million, pretax) will be excluded when calculating 2019 Adjusted EPS.

[0000866706-19-000004:8k_2_02:44]
Additionally, the Company is moving VACCO's aircraft / aerospace business (approximately $8 million in annual revenue) from South El Monte California and consolidating it into PTI's aerospace facility in Oxnard California. This will enable PTI to maximize its aircraft / aerospace customer relationships and market expertise and utilize manufacturing floor space made available by the elimination of its automotive / industrial business during 2018, while allowing VACCO to concentrate on its growing navy / submarine and space business. These move costs (approximately $1 million) will also be excluded when calculating 2019 Adjusted EPS.

[0000866706-19-000004:8k_2_02:45]
All of these actions are intended to improve operating efficiency, generate additional free cash flow, and enhance the Company's competitiveness across several end-markets, thereby, accelerating annual sales and earnings growth in the future.

[0000866706-19-000004:8k_2_02:46]
Business Outlook – 2019 (Summarized)

[0000866706-19-000004:8k_2_02:47]
Management's expectations for 2019 remain consistent with the details outlined in the "Business Outlook – 2019" section of the November 15, 2018 earnings release.

[0000866706-19-000004:8k_2_02:48]
Management continues to see meaningful organic sales, Adjusted EBIT, and Adjusted EBITDA growth across each of the Company's business segments and anticipates growth rates in 2019 and beyond that will generally exceed the broader industrial market. The organic growth described in the previous earnings release is expected to be enhanced by additional M&A contributions.

[0000866706-19-000004:8k_2_02:49]
Management's focus on profitable growth, increased cash flow, an enhanced cost structure driving efficiency and creating competitive advantages, coupled with incremental ROIC, will be the key drivers of sustainable share price appreciation.

[0000866706-19-000004:8k_2_02:50]
To recap, Management expects 2019 Adjusted EPS to be in the range of $2.95 to $3.05 per share reflecting meaningful organic sales and Adjusted EBITDA growth partially offset by the additional depreciation and amortization charges and incremental tax expense as detailed previously.

[0000866706-19-000004:8k_2_02:51]
On a quarterly basis, Management expects 2019 revenues and Adjusted EPS to be more back half weighted with the second half of the year being stronger than the first half.

[0000866706-19-000004:8k_2_02:52]
Management expects Q2 2019 Adjusted EPS to be in the range of $0.58 to $0.63 per share. The timing of quarterly sales and earnings throughout the year, coupled with the discrete charges described above within the respective quarters will impact quarterly comparability.

[0000866706-19-000004:8k_2_02:53]
Conference Call

[0000866706-19-000004:8k_2_02:54]
The Company will host a conference call today, February 7, at 4:00 p.m. Central Time, to discuss the Company's Q1 2019 results. A live audio webcast will be available on the Company's website at www.escotechnologies.com. Please access the website at least 15 minutes prior to the call to register, download and install any necessary audio software. A replay of the conference call will be available for seven days on the Company's website noted above or by phone (dial 1-855-859-2056 and enter the pass code 5468674).

[0000866706-19-000004:8k_2_02:55]
Forward-Looking Statements

[0000866706-19-000004:8k_2_02:56]
Statements in this press release regarding the timing and amounts of the Company's expected quarterly, 2019 full year and beyond results, revenue and sales growth, EPS, Adjusted EPS, EPS growth, cash, EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA, interest expense, income tax expense, effective tax rates, cash generation, sustainable share price appreciation, the realization of operational efficiencies, the Company's competitiveness and the costs and savings resulting from operational improvements and cost reduction actions, the Company's ability to increase operating margins, realize financial goals and increase shareholder value, the success of acquisition efforts, the long-term success of the Company, and any other statements which are not strictly historical are "forward-looking" statements within the meaning of the safe harbor provisions of the federal securities laws.

[0000866706-19-000004:8k_2_02:57]
Investors are cautioned that such statements are only predictions and speak only as of the date of this release, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company's actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company's operations and business environment including but not limited to those described in Item 1A, "Risk Factors", of the Company's Annual Report on Form 10-K for the fiscal year ended September 30, 2018, and the following: the success of the Company's competitors; weakening of economic conditions in served markets; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties; delivery delays or defaults by customers; material changes in the costs and availability of certain raw materials; the appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer contracts; the timing and content of future contract awards or customer orders; performance issues with key customers, suppliers and subcontractors; labor disputes; the impacts of natural disasters on the Company's operations and those of the Company's customers and suppliers; changes in laws and regulations, including but not limited to changes in accounting standards and taxation requirements; changes in interest rates; costs relating to environmental matters arising from current or former facilities; financial exposure in connection with Company guarantees of certain Aclara contracts; the availability of select acquisitions; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the success and integration of recently acquired businesses.

[0000866706-19-000004:8k_2_02:58]
Non-GAAP Financial Measures

[0000866706-19-000004:8k_2_02:59]
The financial measures EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS are presented in this press release. The Company defines "EBIT" as earnings before interest and taxes, "EBITDA" as earnings before interest, taxes, depreciation and amortization, "Adjusted EBITDA" as EBITDA excluding certain defined charges, and "Adjusted EPS" as GAAP earnings per share (EPS) excluding the net impact of the items described above which were $0.19 per share in Q1 2019.

[0000866706-19-000004:8k_2_02:60]
EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management believes that EBIT, EBITDA and Adjusted EBITDA are useful in assessing the operational profitability of the Company's business segments because they exclude interest, taxes, depreciation and amortization, which are generally accounted for across the entire Company on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company as well as incentive compensation. The Company believes that the presentation of EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS provides important supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance determined in accordance with GAAP.

[0000866706-19-000004:8k_2_02:61]
ESCO, headquartered in St. Louis, Missouri: Manufactures highly-engineered filtration and fluid control products for the aviation, space and process markets worldwide; is the industry leader in RF shielding and EMC test products; provides diagnostic instruments, software and services for the benefit of industrial power users and the electric utility and renewable energy industries; and, produces custom thermoformed packaging, pulp-based packaging, and specialty products for medical and commercial markets. Further information regarding ESCO and its subsidiaries is available on the Company's website at www.escotechnologies.com.

[0000866706-19-000004:8k_2_02:62]
-tables attached-

[0000866706-19-000004:8k_2_02:63]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |  |  |  |
| Condensed Consolidated Statements of Operations (Unaudited) |  |  |  |  |
| (Dollars in thousands, except per share amounts) |  |  |  |  |
|  |  | Three Months Ended December 31, 2018 |  |  |  |  |  | Three Months Ended December 31, 2017 |  |  |  |  |
| Net Sales |  | $ | 182,597 |  |  |  |  |  |  | 173,495 |  |  |  |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 118,908 |  |  |  |  |  |  | 111,736 |  |  |  |  |
| Selling, general and administrative expenses |  |  | 40,993 |  |  |  |  |  |  | 42,154 |  |  |  |  |
| Amortization of intangible assets |  |  | 4,652 |  |  |  |  |  |  | 4,446 |  |  |  |  |
| Interest expense |  |  | 1,890 |  |  |  |  |  |  | 2,185 |  |  |  |  |
| Other (income) expenses, net |  |  | (7,103 | ) |  |  |  |  |  | 173 |  |  |  |  |
| Total costs and expenses |  |  | 159,340 |  |  |  |  |  |  | 160,694 |  |  |  |  |
| Earnings before income taxes |  |  | 23,257 |  |  |  |  |  |  | 12,801 |  |  |  |  |
| Income tax expense (benefit) |  |  | 5,940 |  |  |  |  |  |  | (21,870 | ) |  |  |  |
| Net earnings |  | $ | 17,317 |  |  |  |  |  |  | 34,671 |  |  |  |  |
| Diluted EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP EPS |  | $ | 0.66 |  |  |  |  |  |  | 1.33 |  |  |  |  |
| Adjusted EPS |  | $ | 0.47 | (1) |  |  |  |  |  |  | 0.33 | (2) |  |  |  |  |
| Diluted average common shares O/S: |  |  | 26,120 |  |  |  |  |  |  |  | 26,080 |  |  |  |  |  |

[0000866706-19-000004:8k_2_02:64]
| (1) | Q1 2019 Adjusted EPS excludes $0.19 per share of after-tax income mainly resulting from gain on the sale of the Doble Watertown property partially offset by certain restructuring charges primarily at Doble and Plastique. |  |
| (2) | Q1 2018 Adjusted EPS excludes $1.00 per share of net tax benefit recorded related to the December 2017 "Tax Cuts and Jobs Act" (U.S. Tax Reform). |  |

[0000866706-19-000004:8k_2_02:65]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Condensed Business Segment Information (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  | GAAP |  |  | As Adjusted |  |
|  |  |  | Q1 2019 |  |  |  | Q1 2018 |  |  |  | Q1 2019 |  |  |  | Q1 2018 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 66,224 |  |  |  | 60,035 |  |  |  | 66,224 |  |  |  | 60,035 |  |
| Test |  |  | 41,286 |  |  |  | 37,530 |  |  |  | 41,286 |  |  |  | 37,530 |  |
| USG |  |  | 55,855 |  |  |  | 55,754 |  |  |  | 55,855 |  |  |  | 55,754 |  |
| Technical Packaging |  |  | 19,232 |  |  |  | 20,176 |  |  |  | 19,232 |  |  |  | 20,176 |  |
| Totals |  | $ | 182,597 |  |  |  | 173,495 |  |  |  | 182,597 |  |  |  | 173,495 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 10,610 |  |  |  | 9,645 |  |  |  | 10,707 |  |  |  | 9,645 |  |
| Test |  |  | 3,310 |  |  |  | 2,596 |  |  |  | 3,310 |  |  |  | 2,596 |  |
| USG |  |  | 21,546 |  |  |  | 10,651 |  |  |  | 13,859 |  |  |  | 10,651 |  |
| Technical Packaging |  |  | 106 |  |  |  | 965 |  |  |  | 375 |  |  |  | 965 |  |
| Corporate |  |  | (10,425 | ) |  |  | (8,871 | ) |  |  | (10,060 | ) |  |  | (8,871 | ) |
| Consolidated EBIT |  |  | 25,147 |  |  |  | 14,986 |  |  |  | 18,191 |  |  |  | 14,986 |  |
| Less: Interest expense |  |  | (1,890 | ) |  |  | (2,185 | ) |  |  | (1,890 | ) |  |  | (2,185 | ) |
| Plus (Less): Income tax |  |  | (5,940 | ) |  |  | 21,870 |  |  |  | (4,046 | ) |  |  | (4,288 | ) |
| Net earnings |  | $ | 17,317 |  |  |  | 34,671 |  |  |  | 12,255 |  |  |  | 8,513 |  |

[0000866706-19-000004:8k_2_02:66]
| Note 1: Adjusted net earnings were $12.3 million in Q1 2019 which excluded $0.19 per share of after-tax income primarily related to the Q1 2019 gain on the sale of the Doble Watertown facility partially offset by charges related to other restructuring actions. |  |
| Note 2: Adjusted net earnings were $8.5 million in Q1 2018 which excluded $1.00 per share of net tax benefit recorded related to the December 2017 "Tax Cuts and Jobs Act" (U.S. Tax Reform). |  |

[0000866706-19-000004:8k_2_02:67]
| EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  | Q1 2019 |  |  |  |  |  |  |  | Q1 2018 |  |
|  |  |  | Q1 2019 |  |  | - As Adj |  |  |  | Q1 2018 |  |  | - As Adj |  |
| Consolidated EBITDA |  | $ | 34,651 |  |  |  | 27,695 |  |  |  | 24,212 |  |  |  | 24,212 |  |
| Less: Depr & Amort |  |  | (9,504 | ) |  |  | (9,504 | ) |  |  | (9,226 | ) |  |  | (9,226 | ) |
| Consolidated EBIT |  |  | 25,147 |  |  |  | 18,191 |  |  |  | 14,986 |  |  |  | 14,986 |  |
| Less: Interest expense |  |  | (1,890 | ) |  |  | (1,890 | ) |  |  | (2,185 | ) |  |  | (2,185 | ) |
| Plus (Less): Income Tax |  |  | (5,940 | ) |  |  | (4,046 | ) |  |  | 21,870 |  |  |  | (4,288 | ) |
| Net earnings |  | $ | 17,317 |  |  |  | 12,255 |  |  |  | 34,671 |  |  |  | 8,513 |  |

[0000866706-19-000004:8k_2_02:68]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Condensed Consolidated Balance Sheets (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  | December 31, 2018 |  |  | September 30, 2018 |  |
| Assets |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 36,630 |  |  |  | 30,477 |  |
| Accounts receivable, net |  |  | 146,668 |  |  |  | 163,740 |  |
| Contract assets |  |  | 94,082 |  |  |  | 53,034 |  |
| Inventories |  |  | 119,659 |  |  |  | 135,416 |  |
| Other current assets |  |  | 14,880 |  |  |  | 13,356 |  |
| Total current assets |  |  | 411,919 |  |  |  | 396,023 |  |
| Property, plant and equipment, net |  |  | 129,443 |  |  |  | 134,954 |  |
| Intangible assets, net |  |  | 340,195 |  |  |  | 345,353 |  |
| Goodwill |  |  | 381,198 |  |  |  | 381,652 |  |
| Other assets |  |  | 5,456 |  |  |  | 7,140 |  |
|  |  | $ | 1,268,211 |  |  |  | 1,265,122 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Short-term borrowings and current |  | $ | 20,273 |  |  |  | 20,000 |  |
| maturities of long-term debt |  |  |  |  |  |  |  |  |
| Accounts payable |  |  | 54,395 |  |  |  | 63,033 |  |
| Contract liabilities |  |  | 53,251 |  |  |  | 49,035 |  |
| Other current liabilities |  |  | 66,749 |  |  |  | 68,462 |  |
| Total current liabilities |  |  | 194,668 |  |  |  | 200,530 |  |
| Deferred tax liabilities |  |  | 61,536 |  |  |  | 64,794 |  |
| Other liabilities |  |  | 40,215 |  |  |  | 40,388 |  |
| Long-term debt |  |  | 195,000 |  |  |  | 200,000 |  |
| Shareholders' equity |  |  | 776,792 |  |  |  | 759,410 |  |
|  |  | $ | 1,268,211 |  |  |  | 1,265,122 |  |

[0000866706-19-000004:8k_2_02:69]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Consolidated Statements of Cash Flows (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  | Three Months Ended December 31, 2018 |  |
| Cash flows from operating activities: |  |  |  |
| Net earnings |  | $ | 17,317 |  |
| Adjustments to reconcile net earnings |  |  |  |  |
| to net cash provided by operating activities: |  |  |  |  |
| Depreciation and amortization |  |  | 9,504 |  |
| Stock compensation expense |  |  | 1,373 |  |
| Changes in assets and liabilities |  |  | (7,912 | ) |
| Change in PP&E from gain on building sale |  |  | (8,922 | ) |
| Effect of deferred taxes |  |  | (3,258 | ) |
| Net cash provided by operating activities |  |  | 8,102 |  |
| Cash flows from investing activities: |  |  |  |  |
| Capital expenditures |  |  | (8,885 | ) |
| Additions to capitalized software |  |  | (2,060 | ) |
| Proceeds from sale of building and land |  |  | 17,201 |  |
| Net cash provided by investing activities |  |  | 6,256 |  |
| Cash flows from financing activities: |  |  |  |  |
| Proceeds from long-term debt and short-term borrowings |  |  | 8,273 |  |
| Principal payments on long-term debt |  |  | (13,000 | ) |
| Dividends paid |  |  | (2,073 | ) |
| Other |  |  | (159 | ) |
| Net cash used by financing activities |  |  | (6,959 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (1,246 | ) |
| Net increase in cash and cash equivalents |  |  | 6,153 |  |
| Cash and cash equivalents, beginning of period |  |  | 30,477 |  |
| Cash and cash equivalents, end of period |  | $ | 36,630 |  |

[0000866706-19-000004:8k_2_02:70]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Other Selected Financial Data (Unaudited) |  |
| (Dollars in thousands) |  |
| Backlog And Entered Orders - Q1 FY 2019 |  | Filtration |  |  | Test |  |  | USG |  |  | Technical Packaging |  |  | Total |  |
| Beginning Backlog - 10/1/18 |  | $ | 204,227 |  |  |  | 122,350 |  |  |  | 40,727 |  |  |  | 15,467 |  |  |  | 382,771 |  |
| Entered Orders |  |  | 83,732 |  |  |  | 45,430 |  |  |  | 52,000 |  |  |  | 16,961 |  |  |  | 198,123 |  |
| Sales |  |  | (66,224 | ) |  |  | (41,286 | ) |  |  | (55,855 | ) |  |  | (19,232 | ) |  |  | (182,597 | ) |
| Ending Backlog - 12/31/18 |  | $ | 221,735 |  |  |  | 126,494 |  |  |  | 36,872 |  |  |  | 13,196 |  |  |  | 398,297 |  |

## item 5.02 — body, verbatim

[0000866706-19-000004:8k_body:1]
Item 5.02                          Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers

[0000866706-19-000004:8k_body:2]
At the Registrant's Annual Meeting of Shareholders held on February 5, 2019, the Registrant's shareholders approved an amendment to the Registrant's Employee Stock Purchase Plan (the "ESPP"), increasing by 75,000 the number of shares which could be purchased under the ESPP with matching funds contributed by the Registrant. The amendment was fully described in the Registrant's Proxy Statement for the Annual Meeting filed with the Securities and Exchange Commission on December 12, 2018. A copy of the ESPP restated to include the approved amendment is attached as Exhibit 10.1.
