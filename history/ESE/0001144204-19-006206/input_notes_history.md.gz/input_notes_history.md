# ESE note change history — 0001144204-18-042749 → 0001144204-19-006206


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-02-11):
[0001144204-19-006206:note_history:1]
The Company’s results for the three-month period ended December 31, 2018 are not necessarily indicative of the results for the entire 2019 fiscal year. References to the first quarters of 2019 and 2018 represent the fiscal quarters ended December 31, 2018 and 2017, respectively.
  (was, 2018-08-08, similarity 0.8872):
[0001144204-18-042749:note_history:1]
The Company’s results for the three and nine-month periods ended June 30, 2018 are not necessarily indicative of the results for the entire 2018 fiscal year. References to the third quarters of 2018 and 2017 represent the fiscal quarters ended June 30, 2018 and 2017, respectively.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: no_prior_note, score: 0.0

- added (2019-02-11):
[0001144204-19-006206:note_history:2]
|  | 2. | SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES UPDATE |

- added (2019-02-11):
[0001144204-19-006206:note_history:3]
Our significant accounting policies are included in Note 1 of our Annual Report on Form 10-K for the year ended September 30, 2018. On October 1, 2018, we adopted ASU No. 2014-09,

- added (2019-02-11):
[0001144204-19-006206:note_history:4]
Revenue from Contracts with Customers (ASC 606)

- added (2019-02-11):
[0001144204-19-006206:note_history:5]
. Significant changes to our policies resulting from the adoption are provided below. We adopted ASC 606 using the modified retrospective transition method applied to contracts that were not substantially complete at the end of fiscal year 2018. We recorded a $5.5 million adjustment to increase retained earnings to reflect the cumulative impact of adopting this standard at the beginning of fiscal year 2019, primarily related to certain long-term contracts our Filtration and Technical Packaging segments have that converted to the cost-to-cost method for revenue recognition. The comparative information has not been restated and is reported under the accounting standards in effect for those periods. A reconciliation of the financial statement line items impacted for the three months ended December 31, 2018 under ASC 606 to the prior accounting standards is provided in Note 14.

- added (2019-02-11):
[0001144204-19-006206:note_history:6]
Revenue Recognition

- added (2019-02-11):
[0001144204-19-006206:note_history:7]
Revenue is recognized when control of the goods or services promised under the contract is transferred to the customer either at a point in time (e.g., upon delivery) or over time (e.g., as we perform under the contract). We account for a contract when it has approval and commitment from both parties, the rights and payment terms of the parties are identified, the contract has commercial substance and collectability of consideration is probable. Contracts are reviewed to determine whether there is one or multiple performance obligations. A performance obligation is a promise to transfer a distinct good or service to a customer and represents the unit of accounting for revenue recognition. For contracts with multiple performance obligations, the expected consideration, or the transaction price, is allocated to each performance obligation identified in the contract based on the relative standalone selling price of each performance obligation. Revenue is then recognized for the transaction price allocated to the performance obligation when control of the promised goods or services underlying the performance obligation is transferred.

- added (2019-02-11):
[0001144204-19-006206:note_history:8]
Payment terms with customers vary by the type and location of the customer and the products or services offered. The Company does not adjust the promised amount of consideration for the effects of significant financing components based on the expectation that the period between when the Company transfers a promised good or service to a customer and when the customer pays for that good or service will be one year or less. Arrangements with customers that include payment terms extending beyond one year are not significant.

- added (2019-02-11):
[0001144204-19-006206:note_history:9]
Filtration:

- added (2019-02-11):
[0001144204-19-006206:note_history:10]
Within the Filtration segment, approximately 48% of revenues (approximately 18% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial and military customers and have a single performance obligation as there is only one good promised or the promise to transfer the goods or services is not distinct or separately identifiable from other promises in the contract. The transaction price for these contracts reflects our estimate of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

- added (2019-02-11):
[0001144204-19-006206:note_history:11]
Approximately 52% of the segment’s revenues (approximately 19% 
of consolidated revenues) are accounted for over time as the products do not have alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin or the inventory is owned by the customer. The related contracts are primarily cost-plus or fixed price contracts related to the design, development and manufacture of complex fluid control products, quiet valves, manifolds, shock and vibration dampening, thermal insulation and systems primarily for the commercial aerospace and military (U.S. Government) markets. The contracts may contain multiple products, which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. Our contracts are frequently modified for changes in contract specifications and requirements. Most of our contract modifications are for products that are not distinct from the existing contract and are accounted for as part of that existing contract.

- added (2019-02-11):
[0001144204-19-006206:note_history:12]
Contracts with the U.S. Government generally contain clauses that provide lien rights to work-in-process along with clauses that allow the customer to unilaterally terminate the contract for convenience, pay us for costs incurred plus a reasonable profit and take control of any work-in-process. Due to the continuous transfer of control to the U.S. Government, we recognize revenue over the time that we perform under the contract.

- added (2019-02-11):
[0001144204-19-006206:note_history:13]
Selecting the method to measure progress towards completion for the commercial and military contracts requires judgment and is based on the nature of the products or service to be provided. We generally use the cost-to-cost method to measure progress for our Filtration segment contracts the rate at which costs are incurred to fulfill a contract best depicts the transfer of control to the customer. Under this measure, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and revenue is recorded proportionally as costs are incurred based on an estimated profit margin.

- added (2019-02-11):
[0001144204-19-006206:note_history:14]
The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Certain of our long-term contracts contain incentive fees that can increase the transaction price. These variable amounts generally are awarded upon achievement of certain performance metrics, program milestones or cost targets and can be based upon customer discretion. We include estimated amounts in the transaction price to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimates of variable consideration and determination of whether to include estimated amounts in the transaction price are based largely on an assessment of our anticipated performance and all other information that is reasonably available to us.

- added (2019-02-11):
[0001144204-19-006206:note_history:15]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to one or more years, and the estimation of these costs requires substantial judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

- added (2019-02-11):
[0001144204-19-006206:note_history:16]
Under the typical payment terms of our long term fixed price contracts, the customer pays us either performance-based or progress payments. Performance-based payments represent interim payments based on quantifiable measures of performance or on the achievement of specified events or milestones. Progress payments are interim payments of costs incurred as the work progresses. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred, which we present as contract assets and contract liabilities, respectively, in the Consolidated Balance Sheets. Amounts billed and due from our customers are classified in Accounts receivable, net. For short term fixed price and cost-type contracts, we are generally paid within a short period of time.

- added (2019-02-11):
[0001144204-19-006206:note_history:17]
For contracts where revenue is recognized over time, we generally recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. Anticipated losses on contracts are recognized in full in the period in which the losses become probable and estimable.

- added (2019-02-11):
[0001144204-19-006206:note_history:18]
Test:

- added (2019-02-11):
[0001144204-19-006206:note_history:19]
Within the Test segment, approximately 25% of revenues (approximately 6%

- added (2019-02-11):
[0001144204-19-006206:note_history:20]
of consolidated revenues) are recognized at a point in time when products such as, antennas and probes are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

- added (2019-02-11):
[0001144204-19-006206:note_history:21]
Approximately 75% of the segment’s revenues (approximately 17% of consolidated revenues) are recorded over time as the product does not have an alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin. Products accounted for under this guidance include the construction and installation of complex test chambers to a buyer’s specifications that provide its customers with the ability to measure and contain magnetic, electromagnetic and acoustic energy. The goods and services related to each installed test chamber are not distinct due to the significant amount of integration provided and each installed chamber is accounted for as a single performance obligation. Selecting the method to measure progress towards completion for these contracts requires judgment and is based on the nature of the products and service to be provided. We use milestones to measure progress for our Test segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. For arrangements that are accounted for under this guidance, the Company estimates profit as the difference between total revenue and total estimated cost of a contract and recognizes these revenues and costs based primarily on contract milestones. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable.

- added (2019-02-11):
[0001144204-19-006206:note_history:22]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to a year, and the estimation of these costs requires substantial judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

- added (2019-02-11):
[0001144204-19-006206:note_history:23]
Under the typical payment terms of our fixed price contracts, the customer pays us either performance-based or progress payments. Performance-based payments represent interim payments based on quantifiable measures of performance or on the achievement of specified events or milestones. Progress payments are interim payments of costs incurred as the work progresses. Because of the timing difference of revenue recognition and customer billing, these contracts result in revenue recognized in excess of billings and billings in excess of costs incurred, which we present as contract assets and contract liabilities, respectively, in the Consolidated Balance Sheets. Amounts billed and due from our customers are classified in Accounts receivable, net.

- added (2019-02-11):
[0001144204-19-006206:note_history:24]
For contracts where revenue is recognized over time, we generally recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. Anticipated losses on contracts are recognized in full in the period in which the losses become probable and estimable.

- added (2019-02-11):
[0001144204-19-006206:note_history:25]
USG

- added (2019-02-11):
[0001144204-19-006206:note_history:26]
:
 Within the USG segment, approximately 80% of revenues (approximately 24% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

- added (2019-02-11):
[0001144204-19-006206:note_history:27]
Approximately 20% of the segment’s revenues (approximately 6% of consolidated revenues) are recognized over time as services are performed. The services accounted for under this method include an obligation to provide testing services using hardware and embedded software, software maintenance, training, lab testing, and consulting services. The related contracts contain a bundle of goods and services that are integrated in the context of the contract. Therefore, the goods and services are not distinct and the Company has a single performance obligation. Selecting the method to measure progress towards completion for these contracts requires judgment and is based on the nature of the products and service to be provided. We will recognize revenue as a series of distinct services based on each day of providing services (straight-line over the contract term) for our USG segment contracts. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Under the typical payment terms of our service contracts, the customer pays us in advance of when services are performed. Because of the timing difference of revenue recognition and customer payment, which is typically received upon commencement of the contract, these contracts result in deferred revenue, which we present as contract liabilities, in the Consolidated Balance Sheets.

- added (2019-02-11):
[0001144204-19-006206:note_history:28]
Included in this category, approximately 8% of the segment’s revenues (approximately 2% 
of consolidated revenues) are recognized based on the terms of the software contract. For contracts that transfer a software license to the customer, revenue will be recognized at a point in time. These type of software contracts represent a right to use the software, or a functional license, in which revenue should be recognized upon transfer of the license. For contracts in software as a service (SaaS) arrangements, revenue will be recognized over time. The customer receives and consumes the benefits of the SaaS arrangement through access to the system which is for a stated period. We will recognize revenue based on each day of providing access (straight-line over the contract term). The transaction price for our contracts represent our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Under the typical payment terms of our software contracts, the customer pays us in advance of when services are performed. Because of the timing difference of revenue recognition and customer payment, these contracts result in deferred revenue, which we present as contract liabilities, in the Consolidated Balance Sheets.

- added (2019-02-11):
[0001144204-19-006206:note_history:29]
Technical Packaging:

- added (2019-02-11):
[0001144204-19-006206:note_history:30]
Within the Technical Packaging segment, 
100
% of the revenues (approximately 10% of consolidated revenues) are recognized over time as the product does not have an alternative use and the Company has an enforceable right to payment. Selecting the method to measure progress towards completion for the contracts requires judgment and is based on the nature of the products to be provided. We use the cost-to-cost method to measure progress for our Technical Packaging segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. Under this measure, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and revenue is recorded proportionally as costs are incurred. The transaction price for our contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant.

- added (2019-02-11):
[0001144204-19-006206:note_history:31]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of weeks, minimizing the amount of judgment in developing the cost estimate. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

- added (2019-02-11):
[0001144204-19-006206:note_history:32]
Under the typical payment terms of our contracts, the customer is billed upon shipment of product. Amounts billed and due from our customers are classified in Accounts receivable, net. Because of the timing difference of revenue recognition and customer billing, these contracts result in revenue recognized in excess of billings, which we present as contract assets in the Consolidated Balance Sheets.

- added (2019-02-11):
[0001144204-19-006206:note_history:33]
For contracts where revenue is recognized over time, we generally recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. Anticipated losses on contracts are recognized in full in the period in which the losses become probable and estimable.

- added (2019-02-11):
[0001144204-19-006206:note_history:34]
Contract Assets and Liabilities

- added (2019-02-11):
[0001144204-19-006206:note_history:35]
Contract assets arise from contracts when revenue is recognized over time and the amount of revenue recognized, including our estimate of variable consideration that has been included in the transaction price, exceeds the amount billed to the customer. These amounts are included in contract assets until the right to payment is no longer conditional on events other than the passage of time. These contract assets are reclassified to receivables when the right to consideration becomes unconditional. Contract liabilities include deposits, deferred revenue, upfront payments and billings in excess of revenue recognized. Liabilities for customer rebates and discounts are included in other current liabilities in the accompanying balance sheet.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-02-11):
[0001144204-19-006206:note_history:36]
| (In thousands) |  | December 31,2018 |  |  | September 30, 2018 |  |
| Total borrowings |  | $ | 215,273 |  |  |  | 220,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,273 | ) |  |  | (20,000 | ) |
| Total long-term debt, less current portion |  | $ | 195,000 |  |  |  | 200,000 |  |

- changed (2019-02-11):
[0001144204-19-006206:note_history:37]
At December 31, 2018, the Company had approximately $209 million available to borrow under the Credit Facility, and a $250 million increase option subject to lender approval, in addition to $36.6 million cash on hand. At December 31, 2018, the Company had $215 million of outstanding borrowings under the Credit Facility in addition to outstanding letters of credit of $8.2 million. The Company classified $20.0 million as the current portion of long-term debt as of December 31, 2018, as the Company intends to repay this amount within the next twelve month period; however, the Company has no contractual obligation to repay such amount during the next twelve month period.
  (was, 2018-08-08, similarity 0.698):
[0001144204-18-042749:note_history:37]
At June 30, 2018, the Company had approximately $180 million available to borrow under the Credit Facility, and a $250 million increase option 
subject to lender approval
, in addition to $43.3 million cash on hand. At June 30, 2018, the Company had $262 million of outstanding borrowings under the Credit Facility in addition to outstanding letters of credit of $8.3 million. The Company classified $20.0 million as the current portion of long-term debt as of June 30, 2018, as the Company intends to repay this amount within the next twelve month period; however, the Company has no contractual obligation to repay such amount during the next twelve month period.

- changed (2019-02-11):
[0001144204-19-006206:note_history:38]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from 12.5 to 27.5 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a 65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 3.25% and 2.74% for the three-month periods ending December 31, 2018 and 2017, respectively. At December 31, 2018, the Company was in compliance with all debt covenants.
  (was, 2018-08-08, similarity 0.8684):
[0001144204-18-042749:note_history:38]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from 12.5 to 27.5 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a 65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 3.17% and 2.97% for the three and nine-month periods ending June 30, 2018, respectively, and 2.11% and 1.90% for the corresponding periods of 2017. At June 30, 2018, the Company was in compliance with all debt covenants.

- removed (2019-02-11):
[0001144204-18-042749:note_history:39]
| (In thousands) |  | June 30,2018 |  |  | September 30, 2017 |  |
| Total borrowings |  | $ | 262,000 |  |  |  | 275,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000 | ) |  |  | (20,000 | ) |
| Total long-term debt, less current portion |  | $ | 242,000 |  |  |  | 255,000 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-02-11):
[0001144204-19-006206:note_history:40]
| (In thousands) |  | December 31,2018 |  |  | September 30, 2018 |  |
| Total borrowings |  | $ | 215,273 |  |  |  | 220,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,273 | ) |  |  | (20,000 | ) |
| Total long-term debt, less current portion |  | $ | 195,000 |  |  |  | 200,000 |  |

- removed (2019-02-11):
[0001144204-18-042749:note_history:41]
| (In thousands) |  | June 30,2018 |  |  | September 30, 2017 |  |
| Total borrowings |  | $ | 262,000 |  |  |  | 275,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,000 | ) |  |  | (20,000 | ) |
| Total long-term debt, less current portion |  | $ | 242,000 |  |  |  | 255,000 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2019-02-11):
[0001144204-19-006206:note_history:42]
Our revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2018 
are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within our reportable segments.

- added (2019-02-11):
[0001144204-19-006206:note_history:43]
| (In thousands) |  | Filtration |  |  | Test |  |  | USG |  |  | Technical Packaging |  |  | Total |  |
| Customer type: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial |  | $ | 37,523 |  |  | $ | 36,297 |  |  | $ | 54,662 |  |  | $ | 19,114 |  |  | $ | 147,596 |  |
| U.S. Government |  |  | 28,701 |  |  |  | 4,989 |  |  |  | 1,193 |  |  |  | 118 |  |  |  | 35,001 |  |
| Total revenues |  | $ | 66,224 |  |  | $ | 41,286 |  |  | $ | 55,855 |  |  | $ | 19,232 |  |  | $ | 182,597 |  |
| Geographic location: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 54,847 |  |  | $ | 28,453 |  |  | $ | 40,228 |  |  | $ | 9,849 |  |  | $ | 133,377 |  |
| International |  |  | 11,377 |  |  |  | 12,833 |  |  |  | 15,627 |  |  |  | 9,383 |  |  |  | 49,220 |  |
| Total revenues |  | $ | 66,224 |  |  | $ | 41,286 |  |  | $ | 55,855 |  |  | $ | 19,232 |  |  | $ | 182,597 |  |
| Revenue recognition method: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Point in time |  | $ | 32,054 |  |  | $ | 10,382 |  |  | $ | 44,303 |  |  | $ | - |  |  | $ | 86,739 |  |
| Over time |  |  | 34,170 |  |  |  | 30,904 |  |  |  | 11,552 |  |  |  | 19,232 |  |  |  | 95,858 |  |
| Total revenues |  | $ | 66,224 |  |  | $ | 41,286 |  |  | $ | 55,855 |  |  | $ | 19,232 |  |  | $ | 182,597 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2019-02-11):
[0001144204-19-006206:note_history:44]
Revenue Recognition

- added (2019-02-11):
[0001144204-19-006206:note_history:45]
Revenue is recognized when control of the goods or services promised under the contract is transferred to the customer either at a point in time (e.g., upon delivery) or over time (e.g., as we perform under the contract). We account for a contract when it has approval and commitment from both parties, the rights and payment terms of the parties are identified, the contract has commercial substance and collectability of consideration is probable. Contracts are reviewed to determine whether there is one or multiple performance obligations. A performance obligation is a promise to transfer a distinct good or service to a customer and represents the unit of accounting for revenue recognition. For contracts with multiple performance obligations, the expected consideration, or the transaction price, is allocated to each performance obligation identified in the contract based on the relative standalone selling price of each performance obligation. Revenue is then recognized for the transaction price allocated to the performance obligation when control of the promised goods or services underlying the performance obligation is transferred.

- added (2019-02-11):
[0001144204-19-006206:note_history:46]
Payment terms with customers vary by the type and location of the customer and the products or services offered. The Company does not adjust the promised amount of consideration for the effects of significant financing components based on the expectation that the period between when the Company transfers a promised good or service to a customer and when the customer pays for that good or service will be one year or less. Arrangements with customers that include payment terms extending beyond one year are not significant.

- added (2019-02-11):
[0001144204-19-006206:note_history:47]
Filtration:

- added (2019-02-11):
[0001144204-19-006206:note_history:48]
Within the Filtration segment, approximately 48% of revenues (approximately 18% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial and military customers and have a single performance obligation as there is only one good promised or the promise to transfer the goods or services is not distinct or separately identifiable from other promises in the contract. The transaction price for these contracts reflects our estimate of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

- added (2019-02-11):
[0001144204-19-006206:note_history:49]
Approximately 52% of the segment’s revenues (approximately 19% 
of consolidated revenues) are accounted for over time as the products do not have alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin or the inventory is owned by the customer. The related contracts are primarily cost-plus or fixed price contracts related to the design, development and manufacture of complex fluid control products, quiet valves, manifolds, shock and vibration dampening, thermal insulation and systems primarily for the commercial aerospace and military (U.S. Government) markets. The contracts may contain multiple products, which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. Our contracts are frequently modified for changes in contract specifications and requirements. Most of our contract modifications are for products that are not distinct from the existing contract and are accounted for as part of that existing contract.

- added (2019-02-11):
[0001144204-19-006206:note_history:50]
Contracts with the U.S. Government generally contain clauses that provide lien rights to work-in-process along with clauses that allow the customer to unilaterally terminate the contract for convenience, pay us for costs incurred plus a reasonable profit and take control of any work-in-process. Due to the continuous transfer of control to the U.S. Government, we recognize revenue over the time that we perform under the contract.

- added (2019-02-11):
[0001144204-19-006206:note_history:51]
Selecting the method to measure progress towards completion for the commercial and military contracts requires judgment and is based on the nature of the products or service to be provided. We generally use the cost-to-cost method to measure progress for our Filtration segment contracts the rate at which costs are incurred to fulfill a contract best depicts the transfer of control to the customer. Under this measure, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and revenue is recorded proportionally as costs are incurred based on an estimated profit margin.

- added (2019-02-11):
[0001144204-19-006206:note_history:52]
The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Certain of our long-term contracts contain incentive fees that can increase the transaction price. These variable amounts generally are awarded upon achievement of certain performance metrics, program milestones or cost targets and can be based upon customer discretion. We include estimated amounts in the transaction price to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimates of variable consideration and determination of whether to include estimated amounts in the transaction price are based largely on an assessment of our anticipated performance and all other information that is reasonably available to us.

- added (2019-02-11):
[0001144204-19-006206:note_history:53]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to one or more years, and the estimation of these costs requires substantial judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

- added (2019-02-11):
[0001144204-19-006206:note_history:54]
Under the typical payment terms of our long term fixed price contracts, the customer pays us either performance-based or progress payments. Performance-based payments represent interim payments based on quantifiable measures of performance or on the achievement of specified events or milestones. Progress payments are interim payments of costs incurred as the work progresses. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred, which we present as contract assets and contract liabilities, respectively, in the Consolidated Balance Sheets. Amounts billed and due from our customers are classified in Accounts receivable, net. For short term fixed price and cost-type contracts, we are generally paid within a short period of time.

- added (2019-02-11):
[0001144204-19-006206:note_history:55]
For contracts where revenue is recognized over time, we generally recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. Anticipated losses on contracts are recognized in full in the period in which the losses become probable and estimable.

- added (2019-02-11):
[0001144204-19-006206:note_history:56]
Test:

- added (2019-02-11):
[0001144204-19-006206:note_history:57]
Within the Test segment, approximately 25% of revenues (approximately 6%

- added (2019-02-11):
[0001144204-19-006206:note_history:58]
of consolidated revenues) are recognized at a point in time when products such as, antennas and probes are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

- added (2019-02-11):
[0001144204-19-006206:note_history:59]
Approximately 75% of the segment’s revenues (approximately 17% of consolidated revenues) are recorded over time as the product does not have an alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin. Products accounted for under this guidance include the construction and installation of complex test chambers to a buyer’s specifications that provide its customers with the ability to measure and contain magnetic, electromagnetic and acoustic energy. The goods and services related to each installed test chamber are not distinct due to the significant amount of integration provided and each installed chamber is accounted for as a single performance obligation. Selecting the method to measure progress towards completion for these contracts requires judgment and is based on the nature of the products and service to be provided. We use milestones to measure progress for our Test segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. For arrangements that are accounted for under this guidance, the Company estimates profit as the difference between total revenue and total estimated cost of a contract and recognizes these revenues and costs based primarily on contract milestones. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable.

- added (2019-02-11):
[0001144204-19-006206:note_history:60]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to a year, and the estimation of these costs requires substantial judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

- added (2019-02-11):
[0001144204-19-006206:note_history:61]
Under the typical payment terms of our fixed price contracts, the customer pays us either performance-based or progress payments. Performance-based payments represent interim payments based on quantifiable measures of performance or on the achievement of specified events or milestones. Progress payments are interim payments of costs incurred as the work progresses. Because of the timing difference of revenue recognition and customer billing, these contracts result in revenue recognized in excess of billings and billings in excess of costs incurred, which we present as contract assets and contract liabilities, respectively, in the Consolidated Balance Sheets. Amounts billed and due from our customers are classified in Accounts receivable, net.

- added (2019-02-11):
[0001144204-19-006206:note_history:62]
For contracts where revenue is recognized over time, we generally recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. Anticipated losses on contracts are recognized in full in the period in which the losses become probable and estimable.

- added (2019-02-11):
[0001144204-19-006206:note_history:63]
USG

- added (2019-02-11):
[0001144204-19-006206:note_history:64]
:
 Within the USG segment, approximately 80% of revenues (approximately 24% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

- added (2019-02-11):
[0001144204-19-006206:note_history:65]
Approximately 20% of the segment’s revenues (approximately 6% of consolidated revenues) are recognized over time as services are performed. The services accounted for under this method include an obligation to provide testing services using hardware and embedded software, software maintenance, training, lab testing, and consulting services. The related contracts contain a bundle of goods and services that are integrated in the context of the contract. Therefore, the goods and services are not distinct and the Company has a single performance obligation. Selecting the method to measure progress towards completion for these contracts requires judgment and is based on the nature of the products and service to be provided. We will recognize revenue as a series of distinct services based on each day of providing services (straight-line over the contract term) for our USG segment contracts. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Under the typical payment terms of our service contracts, the customer pays us in advance of when services are performed. Because of the timing difference of revenue recognition and customer payment, which is typically received upon commencement of the contract, these contracts result in deferred revenue, which we present as contract liabilities, in the Consolidated Balance Sheets.

- added (2019-02-11):
[0001144204-19-006206:note_history:66]
Included in this category, approximately 8% of the segment’s revenues (approximately 2% 
of consolidated revenues) are recognized based on the terms of the software contract. For contracts that transfer a software license to the customer, revenue will be recognized at a point in time. These type of software contracts represent a right to use the software, or a functional license, in which revenue should be recognized upon transfer of the license. For contracts in software as a service (SaaS) arrangements, revenue will be recognized over time. The customer receives and consumes the benefits of the SaaS arrangement through access to the system which is for a stated period. We will recognize revenue based on each day of providing access (straight-line over the contract term). The transaction price for our contracts represent our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Under the typical payment terms of our software contracts, the customer pays us in advance of when services are performed. Because of the timing difference of revenue recognition and customer payment, these contracts result in deferred revenue, which we present as contract liabilities, in the Consolidated Balance Sheets.

- added (2019-02-11):
[0001144204-19-006206:note_history:67]
Technical Packaging:

- added (2019-02-11):
[0001144204-19-006206:note_history:68]
Within the Technical Packaging segment, 
100
% of the revenues (approximately 10% of consolidated revenues) are recognized over time as the product does not have an alternative use and the Company has an enforceable right to payment. Selecting the method to measure progress towards completion for the contracts requires judgment and is based on the nature of the products to be provided. We use the cost-to-cost method to measure progress for our Technical Packaging segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. Under this measure, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and revenue is recorded proportionally as costs are incurred. The transaction price for our contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant.

- added (2019-02-11):
[0001144204-19-006206:note_history:69]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of weeks, minimizing the amount of judgment in developing the cost estimate. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

- added (2019-02-11):
[0001144204-19-006206:note_history:70]
Under the typical payment terms of our contracts, the customer is billed upon shipment of product. Amounts billed and due from our customers are classified in Accounts receivable, net. Because of the timing difference of revenue recognition and customer billing, these contracts result in revenue recognized in excess of billings, which we present as contract assets in the Consolidated Balance Sheets.

- added (2019-02-11):
[0001144204-19-006206:note_history:71]
For contracts where revenue is recognized over time, we generally recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. Anticipated losses on contracts are recognized in full in the period in which the losses become probable and estimable.
