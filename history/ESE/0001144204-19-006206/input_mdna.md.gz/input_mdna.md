# ESE MD&A — 0001144204-19-006206


## mdna

[0001144204-19-006206:mdna:1]
[same as prior period, unchanged from 0001144204-18-042749:mdna:1]

[0001144204-19-006206:mdna:2]
[same as prior period, unchanged from 0001144204-18-042749:mdna:2]

[0001144204-19-006206:mdna:3]
References to the first quarters of 2019 and 20

[0001144204-19-006206:mdna:4]
|  | 18 |

[0001144204-19-006206:mdna:5]
represent
the three-month periods ended December 31, 2018 and 2017, respectively.

[0001144204-19-006206:mdna:6]
[same as prior period, unchanged from 0001144204-18-042749:mdna:4]

[0001144204-19-006206:mdna:7]
In the first quarter of 2019, sales, net earnings and diluted
earnings per share were $182.6 million, $17.3 million and $0.66 per share, respectively, compared to $173.5 million, $34.7 million
and $1.33 per share, respectively, in the first quarter of 2018. The decrease in net earnings and diluted earnings per share in
the first quarter of 2019 as compared to the first quarter of 2018 was mainly due to the $25.1 million net tax benefit the Company
recorded in the first quarter of 2018 as a result of the Tax Cuts and Jobs Act that was signed into law on December 22,
2017.

[0001144204-19-006206:mdna:8]
[same as prior period, unchanged from 0001144204-18-042749:mdna:6]

[0001144204-19-006206:mdna:9]
Net sales increased $9.1 million, or 5.2%, to $182.6 million
in the first quarter of 2019 from $173.5 million in the first quarter of 2018. The increase in net sales in the first quarter of
2019 as compared to the first quarter of 2018 was due to a $6.2 million increase in the Filtration segment, a $3.8 million increase
in the Test segment and a $0.1 million increase in the USG segment, partially offset by a $0.9 million decrease in the Technical
Packaging segment.

[0001144204-19-006206:mdna:10]
[same as prior period, unchanged from 0001144204-18-042749:mdna:8]

[0001144204-19-006206:mdna:11]
In the first quarter of 2019, net sales of $66.2 million were
$6.2 million, or 10.3%, higher than the $60.0 million in the first quarter of 2018. The sales increase in the first quarter of
2019 compared to the first quarter of 2018 was mainly due to a $3.2 million increase in net sales at Crissair due to higher aerospace
shipments, a $2.3 million increase in net sales at Westland due to timing of revenue on government programs, a $1.5 million increase
in net sales at PTI due to higher aerospace assembly shipments, a $1.5 million increase in net sales at Mayday due to higher aerospace
shipments, partially offset by a $2.3 million decrease in net sales at VACCO due to lower revenue from its space products.

[0001144204-19-006206:mdna:12]
[same as prior period, unchanged from 0001144204-18-042749:mdna:10]

[0001144204-19-006206:mdna:13]
In the first quarter of 2019, net sales of $41.3 million were
$3.8 million, or 10.0%, higher than the $37.5 million in the first quarter of 2018. The increase in the first quarter of 2019 compared
to the first quarter of 2018 was primarily due to higher sales from the segment’s U.S. operations due to the timing of test
and measurement chamber projects.

[0001144204-19-006206:mdna:14]
[same as prior period, unchanged from 0001144204-18-042749:mdna:12]

[0001144204-19-006206:mdna:15]
In the first quarter of 2019, net sales of $55.9 million were
$0.1 million, or 0.2% higher than the $55.8 million in the first quarter of 2018. The increase in the first quarter of 2019 compared
to the first quarter of 2018 was mainly due to net sales increases from Morgan Schaffer and the Vanguard Instruments product line
and new products and software solutions at Doble partially offset by a decrease in net sales at NRG due to softness in the renewable
energy market.

[0001144204-19-006206:mdna:16]
[same as prior period, unchanged from 0001144204-18-042749:mdna:14]

[0001144204-19-006206:mdna:17]
In the first quarter of 2019, net sales of $19.2 million were
$0.9 million, or 4.7%, lower than the $20.2 million in the first quarter of 2018. The decrease in the first quarter of 2019 compared
to the first quarter of 2018 was primarily due to the decrease in net sales from Plastique driven by timing of projects.

[0001144204-19-006206:mdna:18]
[same as prior period, unchanged from 0001144204-18-042749:mdna:16]

[0001144204-19-006206:mdna:19]
Backlog was $398.3 million at December 31, 2018 compared with $382.8 million at September 30, 2018. The
Company received new orders totaling $198.1 million in the first quarter of 2019 compared to $200.5 million in the first quarter
of 2018. Of the new orders received in the first quarter of 2019, $83.7 million related to Filtration products, $45.4 million related
to Test products, $52.0 million related to USG products, and $17.0 million related to Technical Packaging products. Of the new
orders received in the first quarter of 2018, $65.4 million related to Filtration products, $58.3 million related to Test products,
$57.6 million related to USG products, and $19.2 million related to Technical Packaging products.

[0001144204-19-006206:mdna:20]
[same as prior period, unchanged from 0001144204-18-042749:mdna:21]

[0001144204-19-006206:mdna:21]
Selling, general and administrative (SG&A) expenses for
the first quarter of 2019 were $41.0 million (22.4% of net sales), compared with $42.2 million (24.3% of net sales) for the first
quarter of 2018. The decrease in SG&A in the first quarter of 2019 compared to the first quarter of 2018 was mainly due to
a decrease in the USG segment due to the impact of the Company’s recent cost reduction actions incurred throughout 2018.

[0001144204-19-006206:mdna:22]
[same as prior period, unchanged from 0001144204-18-042749:mdna:54]

[0001144204-19-006206:mdna:23]
[same as prior period, unchanged from 0001144204-18-042749:mdna:24]

[0001144204-19-006206:mdna:24]
Amortization of intangible assets was $4.7 million and $4.4
million for the first quarter of 2019 and 2018, respectively. Amortization expenses consist of amortization of acquired intangible
assets from acquisitions and other identifiable intangible assets (primarily software). The increase in amortization expense in
the first quarter of 2019 compared to the first quarter of 2018 was mainly due to an increase in amortization of intangibles related
to the Manta acquisition.

[0001144204-19-006206:mdna:25]
OTHER (INCOME) EXPENSES, NET

[0001144204-19-006206:mdna:26]
Other income, net, was $7.1 million in the first quarter of
2019 compared to other expenses, net, of $0.2 million in the first quarter of 2018. The principal component in other income, net,
in the first quarter of 2019 was a gain of approximately $8 million on the sale of the Doble Watertown, MA building and land.
There were no individually significant items in other (income) expenses, net, in the first quarter of 2018.

[0001144204-19-006206:mdna:27]
[same as prior period, unchanged from 0001144204-18-042749:mdna:29]

[0001144204-19-006206:mdna:28]
The Company evaluates the performance of its operating segments
based on EBIT, and provides EBIT on a consolidated basis, which is a non-GAAP financial measure. Please refer to the discussion
of non-GAAP financial measures in Note 7 to the Consolidated Financial Statements, above. EBIT was $25.1 million (13.8% of net
sales) for the first quarter of 2019 compared to $15.0 million (8.6% of net sales) for the first quarter of 2018.

[0001144204-19-006206:mdna:29]
[same as prior period, unchanged from 0001144204-18-042749:mdna:31]

[0001144204-19-006206:mdna:30]
| (In thousands) |  | Three Months Ended December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Consolidated EBIT |  | $ | 25,147 |  |  |  | 14,986 |  |
| Less: Interest expense, net |  |  | (1,890 | ) |  |  | (2,185 | ) |
| Plus (Less): Income tax |  |  | (5,940 | ) |  |  | 21,870 |  |
| Net earnings |  | $ | 17,317 |  |  |  | 34,671 |  |

[0001144204-19-006206:mdna:31]
[same as prior period, unchanged from 0001144204-18-042749:mdna:33]

[0001144204-19-006206:mdna:32]
EBIT in the first quarter of 20

[0001144204-19-006206:mdna:33]
|  | 19 |

[0001144204-19-006206:mdna:34]
was $10.6 million (16.0% of
net sales) compared to $9.6 million (16.1% of net sales) in the first quarter of

[0001144204-19-006206:mdna:35]
|  | 20 |

[0001144204-19-006206:mdna:36]
18. The increase in EBIT in the first quarter
compared to the first quarter of 2018 was mainly due to an increase at Crissair and Westland due to higher sales volumes partially
offset by a decrease in EBIT at VACCO due to the lower sales volumes mentioned above.

[0001144204-19-006206:mdna:37]
[same as prior period, unchanged from 0001144204-18-042749:mdna:39]

[0001144204-19-006206:mdna:38]
EBIT in the first quarter of 2019 was $3.3 million (8.0% of
net sales) compared to $2.6 million (6.9% of net sales) in the first quarter of 2018. The increase in EBIT in the first quarter
of 2019 compared to the first quarter of 2018 was primarily due to the increased sales volumes mainly from the segment’s
U.S. operations.

[0001144204-19-006206:mdna:39]
19

[0001144204-19-006206:mdna:40]
[same as prior period, unchanged from 0001144204-18-042749:mdna:42]

[0001144204-19-006206:mdna:41]
EBIT in the first quarter of 2019 was $

[0001144204-19-006206:mdna:42]
|  | 21 |

[0001144204-19-006206:mdna:43]
.5 million (38.6% of
net sales) compared to $10.7 million (19.1% of net sales) in the first quarter of 2018. The increase in EBIT in the first quarter
of 2019 compared to the first quarter of 2018 was mainly due to the gain on sale of the Doble Watertown facility of approximately
$8 million as well as an increase in EBIT from Morgan Schaffer and the Vanguard Instruments and Manta product lines.

[0001144204-19-006206:mdna:44]
[same as prior period, unchanged from 0001144204-18-042749:mdna:44]

[0001144204-19-006206:mdna:45]
EBIT in the first quarter of 2019 was $0.1 million (0.6% of
net sales) compared to $1.0 million (4.8% of net sales) in the first quarter of 2018. The decrease in EBIT in the first quarter
of 2019 compared to the first quarter of 2018 was mainly due to the decrease in sales volumes at Plastique. In addition, EBIT in
the first quarter of 2019 included $0.3 million of restructuring charges related to the Plastique facility consolidation, which
were recorded in the first quarter of 2019. These charges consisted primarily of severance and compensation benefits and asset
impairment charges.

[0001144204-19-006206:mdna:46]
[same as prior period, unchanged from 0001144204-18-042749:mdna:46]

[0001144204-19-006206:mdna:47]
Corporate costs included in EBIT were $10.4 million and $8.9
million in the first quarter of 2019 and 2018, respectively. The increase in Corporate costs in the first quarter of 2019 compared
to the first quarter of 2018 was mainly due to the $1.2 million of losses on derivative instruments recorded in the first quarter
of 2019.

[0001144204-19-006206:mdna:48]
[same as prior period, unchanged from 0001144204-18-042749:mdna:48]

[0001144204-19-006206:mdna:49]
Interest expense was $1.9 million and $2.2 million in the first
quarter of 2019 and 2018, respectively. The decrease in interest expense in the first quarter of 2019 as compared to the first
quarter of 2018 was mainly due to lower average outstanding borrowings ($212 million compared to $265.7 million), partially offset
by higher average interest rates (3.3% vs. 2.7%).

[0001144204-19-006206:mdna:50]
[same as prior period, unchanged from 0001144204-18-042749:mdna:50]

[0001144204-19-006206:mdna:51]
Income tax expense in the first quarter of 2019 was $5.9 million
compared to income tax benefit of $21.9 million in the first quarter of 2018. The first quarter 2019 effective income tax rate
was 25.5% compared to (170.8%) in the first quarter of 2018. Income tax expense in the first quarter 2019 was unfavorably impacted
by return to provision true-ups increasing the first quarter effective tax rate by 1.3%. H.R. 1, Tax Cuts and Jobs Act (“TCJA”),
was signed into law on December

[0001144204-19-006206:mdna:52]
|  | 22 |

[0001144204-19-006206:mdna:53]
, 2017. The total impact of the TCJA in the first quarter of 2018 was a net benefit of $25.1
million. The impacts were as follows: First, the Company’s 2018 federal statutory rate dropped from 35.0% to 24.5% which
required an adjustment to the value of its deferred tax assets and liabilities since the first quarter of 2018 was the period that
included the enactment date. This adjustment resulted in a favorable impact ($30.3 million provisional amount in the first quarter
of 2018) which lowered the first quarter of 2018 effective tax rate by

[0001144204-19-006206:mdna:54]
|  | 23 |

[0001144204-19-006206:mdna:55]
6.8%. Second, the TCJA subjected the Company’s cumulative
foreign earnings to federal income tax ($2.9 million provisional amount in the first quarter of 2018) which unfavorably impacted
the first quarter of 2018 effective tax rate by 22.8%. The Company also recorded a $2.3 million provisional estimate of the income
tax effects of the future repatriation of the cumulative earnings of its foreign subsidiaries which unfavorably impacted the first
quarter of 2018 effective tax rate by 18.3%.

[0001144204-19-006206:mdna:56]
Staff Accounting Bulletin No. 118 (SAB 118) was issued
by the SEC effective December 22, 2017. SAB 118 allows registrants to record provisional amounts of the income tax effects of the
TCJA where the information necessary to complete the accounting under ASC Topic 740 is not available but the amounts are based
on reasonable estimates. SAB 118 permits registrants to record adjustments to its provisional amounts during the measurement period
(which cannot exceed one year).

[0001144204-19-006206:mdna:57]
The Company recorded a provisional charge for the Transition
Tax of $3.7 million for the year ended September 30, 2018 and this charge is complete as of December 31, 2018 with minimal changes.
Provisions under the TCJA that became effective for the Company in the current fiscal year include a further reduction in the U.S.
statutory rate to 21%, a new minimum tax on global intangible low-taxed income (“GILTI”), the benefit of the deduction
for foreign-derived intangible income (“FDII”), and changes to IRC Section 162(m) related to the deductibility of executive
compensation.

[0001144204-19-006206:mdna:58]
The Company’s foreign subsidiaries had accumulated unremitted
earnings of $4.0 million at December 31, 2018. No deferred taxes have been provided on these accumulated unremitted earnings because
these funds are not needed to meet the liquidity requirements of the Company’s U.S. operations and it is the Company’s
intention to indefinitely reinvest these earnings in continuing international operations. In the event these foreign entities’
earnings were distributed, it is estimated that approximately $0.4 million of foreign tax withholding would be paid. The Company
does not expect that these taxes would be creditable against U.S. income tax, so they would correspondingly reduce the Company’s
net earnings. No significant portion of the Company’s foreign subsidiaries’ earnings was taxed at a rate significantly
less than the U.S. statutory tax rate.

[0001144204-19-006206:mdna:59]
[same as prior period, unchanged from 0001144204-18-042749:mdna:83]

[0001144204-19-006206:mdna:60]
[same as prior period, unchanged from 0001144204-18-042749:mdna:61]

[0001144204-19-006206:mdna:61]
The Company’s overall financial position and liquidity
remains strong. Working capital (current assets less current liabilities) increased to $217.3 million at December 31, 2018 from
$195.5 million at September 30, 2018. Accounts receivable decreased by $17.1 million during this period mainly due to a $12.6 million
decrease within the Filtration segment driven by the timing of sales and focused collection efforts. Inventories decreased by $15.8
million during this period mainly due to a $15.8 million decrease within the Filtration segment resulting primarily from the adoption
of ASU No. 2014-09, Revenue from Contracts with Customers (ASC 606). Contract assets increased $41.0 million in the first
quarter of 2019 mainly due to the adoption of ASC 606 within the Filtration segment.

[0001144204-19-006206:mdna:62]
Net cash provided by operating activities was $8.1 million and
$17.8 million in the first quarters of 2019 and 2018, respectively. The decrease in net cash provided by operating activities in
the first quarter of 2019 as compared to the first quarter of 2018 was driven by lower earnings and higher working capital requirements.

[0001144204-19-006206:mdna:63]
Capital expenditures were $8.9 million and $3.6 million in the
first quarters of 2019 and 2018, respectively. The increase in the first quarter of 2019 was mainly due to a facility expansion
at TEQ ($3.8 million). In addition, the Company incurred expenditures for capitalized software of $2.1 million in both of the first
quarters of 2019 and 2018, respectively.

[0001144204-19-006206:mdna:64]
Credit Facility

[0001144204-19-006206:mdna:65]
At December 31, 2018, the Company had approximately $209 million
available to borrow under its bank credit facility, a $250 million increase option subject to lender approval, and $36.6 million
cash on hand. At December 31, 2018, the Company had $215 million of outstanding borrowings under the credit facility in addition
to outstanding letters of credit of $8.2 million. Cash flow from operations and borrowings under the Company’s credit facility
are expected to meet the Company’s capital requirements and operational needs for the foreseeable future. The Company’s
ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating
or other outside banks.

[0001144204-19-006206:mdna:66]
[same as prior period, unchanged from 0001144204-18-042749:mdna:71]

[0001144204-19-006206:mdna:67]
In February 2016, the FASB issued ASU No. 2016-062, Leases
(Topic 842), which, among other things, requires an entity to recognize lease assets and lease liabilities on the balance sheet
and disclose key information about leasing arrangements. This standard will increase an entities’ reported assets and liabilities.
The standard is effective for fiscal years beginning after December 15, 2018 and mandates a modified retrospective transition period
for all entities. The Company is currently assessing the impact of this standard on its consolidated financial statements and related
disclosures.

[0001144204-19-006206:mdna:68]
In October 2016, the FASB issued ASU No. 2016-16, Intra-Entity
Transfers of Assets Other Than Inventory, which eliminates the exception for all intra-entity sale of assets other than inventory.
This standard is effective for annual periods beginning after December 15, 2017. There was no significant impact to the Company’s
consolidated financial statements as a result of adopting this new standard.

[0001144204-19-006206:mdna:69]
[same as prior period, unchanged from 0001144204-18-042749:mdna:79]

[0001144204-19-006206:mdna:70]
A dividend of $0.08 per share, totaling $2.1 million, was paid
on October 17, 2018 to stockholders of record as of October 3, 2018. Subsequent to December 31, 2018, a quarterly dividend of $0.08
per share, totaling $2.1 million, was paid on January 18, 2019 to stockholders of record as of January 3, 2019.

[0001144204-19-006206:mdna:71]
[same as prior period, unchanged from 0001144204-18-042749:mdna:81]

[0001144204-19-006206:mdna:72]
Management’s current expectations for 2018 remain consistent
with the details outlined in the Business Outlook presented in the November 15, 2018 press release. Management expects 2019 Adjusted
EPS to be in the range of $2.95 to $3.05 per share reflecting meaningful organic sales growth. Management is excluding the following
expected adjustments to 2019 GAAP EPS: A pre-tax gain from the October 2018 sale of Doble’s headquarters building in Watertown,
Massachusetts; and pre-tax costs related to the relocation of Doble’s headquarters, the closure of Plastique’s headquarters
in Tunbridge Wells, UK and the consolidation of its product design and administrative functions into its facilities in Nottingham,
UK and Poznan, Poland; the consolidation of VACCO’s aircraft/aerospace business into PTI’s aerospace facility in Oxnard,
California; and the completion of other restructuring activities begun in 2018. Management expects the 2019 second quarter Adjusted
EPS to be in the range of $0.58 to $0.63.

[0001144204-19-006206:mdna:73]
21

[0001144204-19-006206:mdna:74]
[same as prior period, unchanged from 0001144204-18-042749:mdna:84]

[0001144204-19-006206:mdna:75]
Management has evaluated the accounting policies used in the
preparation of the Company’s financial statements and related notes and believes those policies to be reasonable and appropriate.
Certain of these accounting policies require the application of significant judgment by Management in selecting appropriate assumptions
for calculating financial estimates. By their nature, these judgments are subject to an inherent degree of uncertainty. These judgments
are based on historical experience, trends in the industry, information provided by customers and information available from other
outside sources, as appropriate. The most significant areas involving Management judgments and estimates may be found in the Critical
Accounting Policies section of Management’s Discussion and Analysis and in Note 1 to the Consolidated Financial Statements
contained in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2018.

[0001144204-19-006206:mdna:76]
[same as prior period, unchanged from 0001144204-18-042749:mdna:86]

[0001144204-19-006206:mdna:77]
Contingencies

[0001144204-19-006206:mdna:78]
As a normal incident of the business in which the Company is
engaged, various claims, charges and litigation are asserted or commenced against the Company. Additionally, the Company is currently
involved in various stages of investigation and remediation relating to environmental matters. In the opinion of Management, the
aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company,
are adequately reserved, are covered by insurance, or would not have a material adverse effect on the Company’s results from
operations, capital expenditures, or competitive position.

[0001144204-19-006206:mdna:79]
[same as prior period, unchanged from 0001144204-18-042749:mdna:89]

[0001144204-19-006206:mdna:80]
Investors are cautioned that such statements are only predictions and speak only as of the date of this
Form 10-Q, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company’s
actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties
that exist in the Company’s operations and business environment, including but not limited to those described in Item 1A,
“Risk Factors,” of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2018, and
the following: the impacts of natural disasters on the Company’s operations and those of the Company’s customers and
suppliers; the timing and content of future contract awards or customer orders; the appropriation, allocation and availability
of Government funds; the termination for convenience of Government and other customer contracts or orders; financial exposure in
connection with Company guarantees of certain Aclara contracts; weakening of economic conditions in served markets; the success
of the Company’s competitors; changes in customer demands or customer insolvencies; competition; intellectual property rights;
technical difficulties; the availability of selected acquisitions; delivery delays or defaults by customers; performance issues
with key customers, suppliers and subcontractors; material changes in the costs and availability of certain raw materials; labor
disputes; changes in U.S. tax laws and regulations; other changes in laws and regulations including but not limited to changes
in accounting standards and foreign taxation; changes in interest rates; costs relating to environmental matters arising from current
or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and
the integration of recently acquired businesses.
