# ESE notes — 0001144204-19-006206


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001144204-19-006206:notes:1]
[same as prior period, unchanged from 0001144204-18-042749:notes:13]

[0001144204-19-006206:notes:2]
The accompanying consolidated financial statements, in the opinion of management, include all adjustments, consisting of normal recurring accruals, necessary for a fair presentation of the results for the interim periods presented. The consolidated financial statements are presented in accordance with the requirements of Form 10-Q and consequently do not include all the disclosures required for annual financial statements by accounting principles generally accepted in the United States of America (GAAP). For further information, refer to the consolidated financial statements and related notes included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2018.

[0001144204-19-006206:notes:3]
The Company’s results for the three-month period ended December 31, 2018 are not necessarily indicative of the results for the entire 2019 fiscal year. References to the first quarters of 2019 and 2018 represent the fiscal quarters ended December 31, 2018 and 2017, respectively.

[0001144204-19-006206:notes:4]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## ese:ContractAssetsAndLiabilitiesPolicyTextBlock

[0001144204-19-006206:notes:5]
Contract Assets and Liabilities

[0001144204-19-006206:notes:6]
Contract assets arise from contracts when revenue is recognized over time and the amount of revenue recognized exceeds the amount billed to the customer. These amounts are included in contract assets until the right to payment is no longer conditional on events other than the passage of time. Contract liabilities include deposits and billings in excess of revenue recognized.


## us-gaap:InventoryDisclosureTextBlock

[0001144204-19-006206:notes:7]
[same as prior period, unchanged from 0001144204-18-042749:notes:29]

[0001144204-19-006206:notes:8]
[same as prior period, unchanged from 0001144204-18-042749:notes:30]

[0001144204-19-006206:notes:9]
| (In thousands) |  | December 31,2018 |  |  | September 30, 2018 |  |
| Finished goods |  | $ | 19,125 |  |  |  | 26,678 |  |
| Work in process |  |  | 39,636 |  |  |  | 47,765 |  |
| Raw materials |  |  | 60,898 |  |  |  | 60,973 |  |
| Total inventories |  | $ | 119,659 |  |  |  | 135,416 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001144204-19-006206:notes:10]
[same as prior period, unchanged from 0001144204-18-042749:notes:32]

[0001144204-19-006206:notes:11]
Included on the Company’s Consolidated Balance Sheets at December 31, 2018 and September 30, 2018 are the following intangible assets gross carrying amounts and accumulated amortization:

[0001144204-19-006206:notes:12]
| (Dollars in thousands) |  | December 31,2018 |  |  | September 30, 2018 |  |
| Goodwill |  | $ | 381,198 |  |  |  | 381,652 |  |
| Intangible assets with determinable lives: |  |  |  |  |  |  |  |  |
| Patents |  |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 1,833 |  |  |  | 1,833 |  |
| Less: accumulated amortization |  |  | 818 |  |  |  | 791 |  |
| Net |  | $ | 1,015 |  |  |  | 1,042 |  |
| Capitalized software |  |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 73,355 |  |  |  | 71,294 |  |
| Less: accumulated amortization |  |  | 43,480 |  |  |  | 41,624 |  |
| Net |  | $ | 29,875 |  |  |  | 29,670 |  |
| Customer relationships |  |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 184,915 |  |  |  | 185,333 |  |
| Less: accumulated amortization |  |  | 50,415 |  |  |  | 47,802 |  |
| Net |  | $ | 134,500 |  |  |  | 137,531 |  |
| Other |  |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 5,368 |  |  |  | 5,468 |  |
| Less: accumulated amortization |  |  | 2,211 |  |  |  | 2,056 |  |
| Net |  | $ | 3,157 |  |  |  | 3,412 |  |
| Intangible assets with indefinite lives: |  |  |  |  |  |  |  |  |
| Trade names |  | $ | 171,648 |  |  |  | 173,698 |  |

[0001144204-19-006206:notes:13]
The changes in the carrying amount of goodwill attributable to each business segment for the three months ended December 31, 2018 is as follows:

[0001144204-19-006206:notes:14]
| (Dollars in millions) |  | USG |  |  | Test |  |  | Filtration |  |  | Packaging |  |  | Total |  |
| Balance as of September 30, 2018 |  |  | 254.1 |  |  |  | 34.1 |  |  |  | 73.7 |  |  |  | 19.8 |  |  |  | 381.7 |  |
| Foreign currency translation |  |  | (0.3 | ) |  |  | - |  |  |  | - |  |  |  | (0.2 | ) |  |  | (0.5 | ) |
| Balance as of December 31, 2018 |  | $ | 253.8 |  |  |  | 34.1 |  |  |  | 73.7 |  |  |  | 19.6 |  |  |  | 381.2 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001144204-19-006206:notes:15]
[same as prior period, unchanged from 0001144204-18-042749:notes:39]

[0001144204-19-006206:notes:16]
[same as prior period, unchanged from 0001144204-18-042749:notes:40]

[0001144204-19-006206:notes:17]
Management evaluates and measures the performance of its reportable segments based on “Net Sales” and “EBIT”, which are detailed in the table below. EBIT is defined as earnings before interest and taxes.

[0001144204-19-006206:notes:18]
|  |  | Three MonthsEnded December 31, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |
| NET SALES |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 66,224 |  |  |  | 60,035 |  |
| Test |  |  | 41,286 |  |  |  | 37,530 |  |
| USG |  |  | 55,855 |  |  |  | 55,754 |  |
| Technical Packaging |  |  | 19,232 |  |  |  | 20,176 |  |
| Consolidated totals |  | $ | 182,597 |  |  |  | 173,495 |  |
| EBIT |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 10,610 |  |  |  | 9,645 |  |
| Test |  |  | 3,310 |  |  |  | 2,596 |  |
| USG |  |  | 21,546 |  |  |  | 10,651 |  |
| Technical Packaging |  |  | 106 |  |  |  | 965 |  |
| Corporate (loss) |  |  | (10,425 | ) |  |  | (8,871 | ) |
| Consolidated EBIT |  |  | 25,147 |  |  |  | 14,986 |  |
| Less: Interest expense |  |  | (1,890 | ) |  |  | (2,185 | ) |
| Earnings before income taxes |  | $ | 23,257 |  |  |  | 12,801 |  |

[0001144204-19-006206:notes:19]
[same as prior period, unchanged from 0001144204-18-042749:notes:41]

[0001144204-19-006206:notes:20]
[same as prior period, unchanged from 0001144204-18-042749:notes:42]

[0001144204-19-006206:notes:21]
[same as prior period, unchanged from 0001144204-18-042749:notes:43]


## us-gaap:DebtDisclosureTextBlock

[0001144204-19-006206:notes:22]
|  | 8. | DEBT |

[0001144204-19-006206:notes:23]
The Company’s debt is summarized as follows:

[0001144204-19-006206:notes:24]
| (In thousands) |  | December 31,2018 |  |  | September 30, 2018 |  |
| Total borrowings |  | $ | 215,273 |  |  |  | 220,000 |  |
| Short-term borrowings and current portion of long-term debt |  |  | (20,273 | ) |  |  | (20,000 | ) |
| Total long-term debt, less current portion |  | $ | 195,000 |  |  |  | 200,000 |  |

[0001144204-19-006206:notes:25]
The Company’s existing credit facility (“the Credit Facility”) matures December 21, 2020. The Credit Facility includes a $450 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of nine banks led by JPMorgan Chase Bank, N.A., as Administrative Agent.

[0001144204-19-006206:notes:26]
At December 31, 2018, the Company had approximately $209 million available to borrow under the Credit Facility, and a $250 million increase option subject to lender approval, in addition to $36.6 million cash on hand. At December 31, 2018, the Company had $215 million of outstanding borrowings under the Credit Facility in addition to outstanding letters of credit of $8.2 million. The Company classified $20.0 million as the current portion of long-term debt as of December 31, 2018, as the Company intends to repay this amount within the next twelve month period; however, the Company has no contractual obligation to repay such amount during the next twelve month period.

[0001144204-19-006206:notes:27]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from 12.5 to 27.5 basis points per year on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a 65% pledge of the material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 3.25% and 2.74% for the three-month periods ending December 31, 2018 and 2017, respectively. At December 31, 2018, the Company was in compliance with all debt covenants.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001144204-19-006206:notes:28]
[same as prior period, unchanged from 0001144204-18-042749:notes:48]

[0001144204-19-006206:notes:29]
Income tax expense in the first quarter of 2019 was $5.9 million compared to income tax benefit of $21.9 million in the first quarter of 2018. The first quarter 2019 effective income tax rate was 25.5% compared to (170.8%) in the first quarter of 2018. Income tax expense in the first quarter 2019 was unfavorably impacted by return to provision true-ups increasing the first quarter effective tax rate by 1.3%. H.R. 1,

[0001144204-19-006206:notes:30]
Tax Cuts and Jobs Act

[0001144204-19-006206:notes:31]
(“TCJA”), was signed into law on December 22, 2017. The total impact of the TCJA in the first quarter of 2018 was a net benefit of $25.1 million. The impacts were as follows: First, the Company’s 2018 federal statutory rate dropped from 35.0% to 24.5% which required an adjustment to the value of its deferred tax assets and liabilities since the first quarter of 2018 was the period that included the enactment date. This adjustment resulted in a favorable impact ($30.3 million provisional amount in the first quarter of 2018) which lowered the first quarter of 2018 effective tax rate by 236.8%. Second, the TCJA subjected the Company’s cumulative foreign earnings to federal income tax ($2.9 million provisional amount in the first quarter of 2018) which unfavorably impacted the first quarter of 2018 effective tax rate by 22.8%. The Company also recorded a $2.3 million provisional estimate of the income tax effects of the future repatriation of the cumulative earnings of its foreign subsidiaries which unfavorably impacted the first quarter of 2018 effective tax rate by 18.3%.

[0001144204-19-006206:notes:32]
[same as prior period, unchanged from 0001144204-18-042749:notes:51]

[0001144204-19-006206:notes:33]
The Company recorded a provisional charge for the Transition Tax of $3.7 million for the year ended September 30, 2018 and this charge is complete as of December 31, 2018 with minimal changes. Provisions under the TCJA that became effective for the Company in the current fiscal year include a further reduction in the U.S. statutory rate to 21%, a new minimum tax on global intangible low-taxed income (“GILTI”), the benefit of the deduction for foreign-derived intangible income (“FDII”), and changes to IRC Section 162(m) related to the deductibility of executive compensation.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001144204-19-006206:notes:34]
[same as prior period, unchanged from 0001144204-18-042749:notes:55]

[0001144204-19-006206:notes:35]
The change in shareholders’ equity for the first three months of 2019 is shown below (in thousands):

[0001144204-19-006206:notes:36]
| Balance at September 30, 2018 |  | $ | 759,410 |  |
| Net earnings |  |  | 17,317 |  |
| Other comprehensive (loss) |  |  | (4,554 | ) |
| Cash dividends |  |  | (2,073 | ) |
| Impact of ASC 606, Revenue Recognition |  |  | 5,588 |  |
| Stock compensation plans |  |  | 1,104 |  |
| Balance at December 31, 2018 |  | $ | 776,792 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001144204-19-006206:notes:37]
[same as prior period, unchanged from 0001144204-18-042749:notes:56]

[0001144204-19-006206:notes:38]
A summary of net periodic benefit expense for the Company’s defined benefit plans for the three-month periods ended December 31, 2018 and 2017 is shown in the following table. Net periodic benefit cost for each period presented is comprised of the following:

[0001144204-19-006206:notes:39]
|  |  | Three Months Ended December 31, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |
| Defined benefit plans |  |  |  |  |  |  |  |  |
| Interest cost |  | $ | 875 |  |  |  | 820 |  |
| Expected return on assets |  |  | (1,086 | ) |  |  | (975 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |
| Prior service cost |  |  | - |  |  |  | - |  |
| Actuarial loss |  |  | 487 |  |  |  | 549 |  |
| Net periodic benefit cost |  | $ | 276 |  |  |  | 394 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001144204-19-006206:notes:40]
[same as prior period, unchanged from 0001144204-18-042749:notes:57]

[0001144204-19-006206:notes:41]
Market risks relating to the Company’s operations result primarily from changes in interest rates and changes in foreign currency exchange rates. The Company is exposed to market risk related to changes in interest rates and selectively uses derivative financial instruments, including forward contracts and swaps, to manage these risks. In 2018, the Company entered into three interest rate swaps with a notional amount of $150 million to hedge some of its exposure to variability in future LIBOR-based interest payments on variable rate debt. In addition, the Company’s Canadian subsidiary Morgan Schaffer enters into foreign exchange contracts to manage foreign currency risk as a portion of their revenue is denominated in U.S. dollars. The Company expects hedging gains or losses to be essentially offset by losses or gains on the related underlying exposures. All derivative instruments are reported in either accrued expenses or other receivables on the balance sheet at fair value. For derivative instruments designated as cash flow hedges, the gain or loss on the derivative is deferred in accumulated other comprehensive income until recognized in earnings with the underlying hedged item. The interest rate swaps entered into during 2018 were not designated as cash flow hedges and, therefore, the gain or loss on the derivative is reflected in earnings each period.

[0001144204-19-006206:notes:42]
The following is a summary of the notional transaction amounts and fair values for the Company’s outstanding derivative financial instruments by risk category and instrument type as of December 31, 2018:

[0001144204-19-006206:notes:43]
| (In thousands) |  | Notionalamount |  |  | FairValue(US$) |  |  | FloatRate |  |  | FixRate |  |
| Forward contracts |  |  | 700 |  |  | GBP | (119 | ) |  |  |  |  |  |  |  |  |
| Forward contracts |  |  | 8,500 |  |  | USD | (416 | ) |  |  |  |  |  |  |  |  |
| Interest rate swap |  |  | 150,000 |  |  | USD | 599 |  |  |  | 2.48 | % |  |  | 2.09 | % |
| Interest rate swap * |  |  | 150,000 |  |  | USD | 308 |  |  |  | N/A |  |  |  | 2.24 | % |

[0001144204-19-006206:notes:44]
*This swap represents a forward contract and will be effective in November 2019.


## us-gaap:EarningsPerShareTextBlock

[0001144204-19-006206:notes:45]
[same as prior period, unchanged from 0001144204-18-042749:notes:19]

[0001144204-19-006206:notes:46]
Basic EPS is calculated using the weighted average number of common shares outstanding during the period. Diluted EPS is calculated using the weighted average number of common shares outstanding during the period plus shares issuable upon the assumed exercise of dilutive common share options and vesting of performance-accelerated restricted shares (restricted shares) by using the treasury stock method.

[0001144204-19-006206:notes:47]
The number of shares used in the calculation of earnings per share for each period presented is as follows (in thousands):

[0001144204-19-006206:notes:48]
|  |  | Three Months Ended December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Weighted Average Shares Outstanding - Basic |  |  | 25,911 |  |  |  | 25,836 |  |
| Dilutive Options and Restricted Shares |  |  | 209 |  |  |  | 244 |  |
| Adjusted Shares - Diluted |  |  | 26,120 |  |  |  | 26,080 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001144204-19-006206:notes:49]
|  | 4. | SHARE-BASED COMPENSATION |

[0001144204-19-006206:notes:50]
[same as prior period, unchanged from 0001144204-18-042749:notes:23]

[0001144204-19-006206:notes:51]
[same as prior period, unchanged from 0001144204-18-042749:notes:24]

[0001144204-19-006206:notes:52]
Compensation expense related to the restricted share awards was $1.1 million and $1.1 million for the three-month periods ended December 31, 2018 and 2017, respectively. There were 316,794 non-vested shares outstanding as of December 31, 2018.

[0001144204-19-006206:notes:53]
[same as prior period, unchanged from 0001144204-18-042749:notes:26]

[0001144204-19-006206:notes:54]
Compensation expense related to the non-employee director grants was $0.3 million and $0.3 million for the three-month periods ended December 31, 2018 and 2017, respectively.

[0001144204-19-006206:notes:55]
The total share-based compensation cost that has been recognized in the results of operations and included within selling, general and administrative expenses (SG&A) was $1.4 million and $1.4 million for the three-month periods ended December 31, 2018 and 2017, respectively. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $0.3 million and $0.4 million for the three-month periods ended December 31, 2018 and 2017, respectively. As of December 31, 2018, there was $6.8 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a remaining weighted-average period of 1.4 years.


## us-gaap:FairValueDisclosuresTextBlock

[0001144204-19-006206:notes:56]
[same as prior period, unchanged from 0001144204-18-042749:notes:59]

[0001144204-19-006206:notes:57]
[same as prior period, unchanged from 0001144204-18-042749:notes:60]

[0001144204-19-006206:notes:58]
|  |  | Level 1 – inputs to the valuation methodology are quoted prices (unadjusted) for identical assets or liabilities in active markets. |

[0001144204-19-006206:notes:59]
|  |  | Level 2 – inputs to the valuation methodology include quoted prices for similar assets and liabilities in active markets, and inputs that are observable for the asset or liability, either directly or indirectly, for substantially the full term of the financial instrument. |

[0001144204-19-006206:notes:60]
|  |  | Level 3 – inputs to the valuation methodology are unobservable and significant to the fair value measurement. |

[0001144204-19-006206:notes:61]
[same as prior period, unchanged from 0001144204-18-042749:notes:62]

[0001144204-19-006206:notes:62]
The Company has estimated the fair value of its financial instruments as of December 31, 2018 and September 30, 2018 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, debt and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001144204-19-006206:notes:63]
[same as prior period, unchanged from 0001144204-18-042749:notes:64]

[0001144204-19-006206:notes:64]
The Company’s forward contracts and interest rate swaps are classified within Level 2 of the valuation hierarchy in accordance with FASB Accounting Standards Codification (ASC) 825, as presented below as of December 31, 2018:

[0001144204-19-006206:notes:65]
| (In thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets (Liabilities): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Forward contracts and interest rate swaps |  | $ | - |  |  |  | 372 |  |  | $ | - |  |  |  | 372 |  |

[0001144204-19-006206:notes:66]
[same as prior period, unchanged from 0001144204-18-042749:notes:65]

[0001144204-19-006206:notes:67]
[same as prior period, unchanged from 0001144204-18-042749:notes:66]

[0001144204-19-006206:notes:68]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during the three-month period ended December 31, 2018.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001144204-19-006206:notes:69]
|  | 15. | NEW ACCOUNTING STANDARDS |

[0001144204-19-006206:notes:70]
In February 2016, the FASB issued ASU No. 2016-062,

[0001144204-19-006206:notes:71]
Leases (Topic 842)

[0001144204-19-006206:notes:72]
, which, among other things, requires an entity to recognize lease assets and lease liabilities on the balance sheet and disclose key information about leasing arrangements. This standard will increase an entities’ reported assets and liabilities. The standard is effective for fiscal years beginning after December 15, 2018 and mandates a modified retrospective transition period for all entities. The Company is currently assessing the impact of this standard on its consolidated financial statements and related disclosures.

[0001144204-19-006206:notes:73]
In October 2016, the FASB issued ASU No. 2016-16,

[0001144204-19-006206:notes:74]
Intra-Entity Transfers of Assets Other Than Inventory

[0001144204-19-006206:notes:75]
, which eliminates the exception for all intra-entity sale of assets other than inventory. This standard is effective for annual periods beginning after December 15, 2017. There was no significant impact to the Company’s consolidated financial statements as a result of adopting this new standard.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001144204-19-006206:notes:76]
Revenue Recognition

[0001144204-19-006206:notes:77]
Revenue is recognized when control of the goods or services promised under the contract is transferred to the customer either at a point in time (e.g., upon delivery) or over time (e.g., as we perform under the contract). We account for a contract when it has approval and commitment from both parties, the rights and payment terms of the parties are identified, the contract has commercial substance and collectability of consideration is probable. Contracts are reviewed to determine whether there is one or multiple performance obligations. A performance obligation is a promise to transfer a distinct good or service to a customer and represents the unit of accounting for revenue recognition. For contracts with multiple performance obligations, the expected consideration, or the transaction price, is allocated to each performance obligation identified in the contract based on the relative standalone selling price of each performance obligation. Revenue is then recognized for the transaction price allocated to the performance obligation when control of the promised goods or services underlying the performance obligation is transferred.

[0001144204-19-006206:notes:78]
Payment terms with customers vary by the type and location of the customer and the products or services offered. The Company does not adjust the promised amount of consideration for the effects of significant financing components based on the expectation that the period between when the Company transfers a promised good or service to a customer and when the customer pays for that good or service will be one year or less. Arrangements with customers that include payment terms extending beyond one year are not significant.

[0001144204-19-006206:notes:79]
Filtration:

[0001144204-19-006206:notes:80]
Within the Filtration segment, approximately 48% of revenues (approximately 18% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial and military customers and have a single performance obligation as there is only one good promised or the promise to transfer the goods or services is not distinct or separately identifiable from other promises in the contract. The transaction price for these contracts reflects our estimate of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

[0001144204-19-006206:notes:81]
Approximately 52% of the segment’s revenues (approximately 19% 
of consolidated revenues) are accounted for over time as the products do not have alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin or the inventory is owned by the customer. The related contracts are primarily cost-plus or fixed price contracts related to the design, development and manufacture of complex fluid control products, quiet valves, manifolds, shock and vibration dampening, thermal insulation and systems primarily for the commercial aerospace and military (U.S. Government) markets. The contracts may contain multiple products, which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. Our contracts are frequently modified for changes in contract specifications and requirements. Most of our contract modifications are for products that are not distinct from the existing contract and are accounted for as part of that existing contract.

[0001144204-19-006206:notes:82]
Contracts with the U.S. Government generally contain clauses that provide lien rights to work-in-process along with clauses that allow the customer to unilaterally terminate the contract for convenience, pay us for costs incurred plus a reasonable profit and take control of any work-in-process. Due to the continuous transfer of control to the U.S. Government, we recognize revenue over the time that we perform under the contract.

[0001144204-19-006206:notes:83]
Selecting the method to measure progress towards completion for the commercial and military contracts requires judgment and is based on the nature of the products or service to be provided. We generally use the cost-to-cost method to measure progress for our Filtration segment contracts the rate at which costs are incurred to fulfill a contract best depicts the transfer of control to the customer. Under this measure, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and revenue is recorded proportionally as costs are incurred based on an estimated profit margin.

[0001144204-19-006206:notes:84]
The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Certain of our long-term contracts contain incentive fees that can increase the transaction price. These variable amounts generally are awarded upon achievement of certain performance metrics, program milestones or cost targets and can be based upon customer discretion. We include estimated amounts in the transaction price to the extent it is probable that a significant reversal of cumulative revenue recognized will not occur when the uncertainty associated with the variable consideration is resolved. Our estimates of variable consideration and determination of whether to include estimated amounts in the transaction price are based largely on an assessment of our anticipated performance and all other information that is reasonably available to us.

[0001144204-19-006206:notes:85]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to one or more years, and the estimation of these costs requires substantial judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

[0001144204-19-006206:notes:86]
Under the typical payment terms of our long term fixed price contracts, the customer pays us either performance-based or progress payments. Performance-based payments represent interim payments based on quantifiable measures of performance or on the achievement of specified events or milestones. Progress payments are interim payments of costs incurred as the work progresses. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred, which we present as contract assets and contract liabilities, respectively, in the Consolidated Balance Sheets. Amounts billed and due from our customers are classified in Accounts receivable, net. For short term fixed price and cost-type contracts, we are generally paid within a short period of time.

[0001144204-19-006206:notes:87]
For contracts where revenue is recognized over time, we generally recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. Anticipated losses on contracts are recognized in full in the period in which the losses become probable and estimable.

[0001144204-19-006206:notes:88]
Test:

[0001144204-19-006206:notes:89]
Within the Test segment, approximately 25% of revenues (approximately 6%

[0001144204-19-006206:notes:90]
of consolidated revenues) are recognized at a point in time when products such as, antennas and probes are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

[0001144204-19-006206:notes:91]
Approximately 75% of the segment’s revenues (approximately 17% of consolidated revenues) are recorded over time as the product does not have an alternative use and the Company has an enforceable right to payment for costs incurred plus a reasonable margin. Products accounted for under this guidance include the construction and installation of complex test chambers to a buyer’s specifications that provide its customers with the ability to measure and contain magnetic, electromagnetic and acoustic energy. The goods and services related to each installed test chamber are not distinct due to the significant amount of integration provided and each installed chamber is accounted for as a single performance obligation. Selecting the method to measure progress towards completion for these contracts requires judgment and is based on the nature of the products and service to be provided. We use milestones to measure progress for our Test segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. For arrangements that are accounted for under this guidance, the Company estimates profit as the difference between total revenue and total estimated cost of a contract and recognizes these revenues and costs based primarily on contract milestones. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable.

[0001144204-19-006206:notes:92]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to a year, and the estimation of these costs requires substantial judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

[0001144204-19-006206:notes:93]
Under the typical payment terms of our fixed price contracts, the customer pays us either performance-based or progress payments. Performance-based payments represent interim payments based on quantifiable measures of performance or on the achievement of specified events or milestones. Progress payments are interim payments of costs incurred as the work progresses. Because of the timing difference of revenue recognition and customer billing, these contracts result in revenue recognized in excess of billings and billings in excess of costs incurred, which we present as contract assets and contract liabilities, respectively, in the Consolidated Balance Sheets. Amounts billed and due from our customers are classified in Accounts receivable, net.

[0001144204-19-006206:notes:94]
For contracts where revenue is recognized over time, we generally recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. Anticipated losses on contracts are recognized in full in the period in which the losses become probable and estimable.

[0001144204-19-006206:notes:95]
USG

[0001144204-19-006206:notes:96]
:
 Within the USG segment, approximately 80% of revenues (approximately 24% of consolidated revenues) are recognized at a point in time when products are shipped (when control of the goods transfers) to unaffiliated customers. The related contracts are with commercial customers. The contracts may contain multiple products which are capable of being distinct as the customer could benefit from each product on its own or together with other readily available resources. Each product is separately identifiable from the other products in the contract. Therefore, each product is distinct in context of the contract and will be accounted for as a separate performance obligation. The transaction price for these contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. Amounts billed to customers for shipping and handling are included in the transaction price as the related activities are performed prior to customer obtaining control of the products. They generally are not treated as separate performance obligations as these costs fulfill a promise to transfer the product to the customer and are expensed in selling, general, and other costs in the period they are incurred. Taxes collected from customers and remitted to government authorities are recorded on a net basis. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation.

[0001144204-19-006206:notes:97]
Approximately 20% of the segment’s revenues (approximately 6% of consolidated revenues) are recognized over time as services are performed. The services accounted for under this method include an obligation to provide testing services using hardware and embedded software, software maintenance, training, lab testing, and consulting services. The related contracts contain a bundle of goods and services that are integrated in the context of the contract. Therefore, the goods and services are not distinct and the Company has a single performance obligation. Selecting the method to measure progress towards completion for these contracts requires judgment and is based on the nature of the products and service to be provided. We will recognize revenue as a series of distinct services based on each day of providing services (straight-line over the contract term) for our USG segment contracts. The transaction price for our contracts represents our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Under the typical payment terms of our service contracts, the customer pays us in advance of when services are performed. Because of the timing difference of revenue recognition and customer payment, which is typically received upon commencement of the contract, these contracts result in deferred revenue, which we present as contract liabilities, in the Consolidated Balance Sheets.

[0001144204-19-006206:notes:98]
Included in this category, approximately 8% of the segment’s revenues (approximately 2% 
of consolidated revenues) are recognized based on the terms of the software contract. For contracts that transfer a software license to the customer, revenue will be recognized at a point in time. These type of software contracts represent a right to use the software, or a functional license, in which revenue should be recognized upon transfer of the license. For contracts in software as a service (SaaS) arrangements, revenue will be recognized over time. The customer receives and consumes the benefits of the SaaS arrangement through access to the system which is for a stated period. We will recognize revenue based on each day of providing access (straight-line over the contract term). The transaction price for our contracts represent our best estimate of the consideration we will receive and includes assumptions regarding variable consideration as applicable. Under the typical payment terms of our software contracts, the customer pays us in advance of when services are performed. Because of the timing difference of revenue recognition and customer payment, these contracts result in deferred revenue, which we present as contract liabilities, in the Consolidated Balance Sheets.

[0001144204-19-006206:notes:99]
Technical Packaging:

[0001144204-19-006206:notes:100]
Within the Technical Packaging segment, 
100
% of the revenues (approximately 10% of consolidated revenues) are recognized over time as the product does not have an alternative use and the Company has an enforceable right to payment. Selecting the method to measure progress towards completion for the contracts requires judgment and is based on the nature of the products to be provided. We use the cost-to-cost method to measure progress for our Technical Packaging segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts. Under this measure, the extent of progress towards completion is measured based on the ratio of costs incurred to date to the estimated costs at completion of the performance obligation, and revenue is recorded proportionally as costs are incurred. The transaction price for our contracts reflects our estimate of variable consideration in the form of returns, rebates and discounts, which are based on historical, current and forecasted information to determine the expected amount to which the Company will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant.

[0001144204-19-006206:notes:101]
Total contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of weeks, minimizing the amount of judgment in developing the cost estimate. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change.

[0001144204-19-006206:notes:102]
Under the typical payment terms of our contracts, the customer is billed upon shipment of product. Amounts billed and due from our customers are classified in Accounts receivable, net. Because of the timing difference of revenue recognition and customer billing, these contracts result in revenue recognized in excess of billings, which we present as contract assets in the Consolidated Balance Sheets.

[0001144204-19-006206:notes:103]
For contracts where revenue is recognized over time, we generally recognize changes in estimated contract revenues, costs and profits using the cumulative catch-up method of accounting. This method recognizes the cumulative effect of changes on current and prior periods with the impact of the change from inception-to-date recorded in the current period. Anticipated losses on contracts are recognized in full in the period in which the losses become probable and estimable.


## ese:AmountOfEachFinancialStatementLineItemAffectedWhenApplyingNewAccountingStandardTableTextBlock

[0001144204-19-006206:notes:104]
The amount by which each financial statement line item is affected in 2019 as a result of applying the new accounting standard as discussed in Note 2 is presented below:

[0001144204-19-006206:notes:105]
|  |  | December 31, 2018 |
| (In thousands) |  | As Reported |  | Effect of theadoption ofASC 606 |  | Under PriorAccounting |
| Consolidated Balance Sheets |  |  |  |  |  |  |
| Contract assets (1) |  | $ | 94,082 |  |  | $ | (41,836 | ) |  | $ | 52,246 |  |
| Inventories |  |  | 119,659 |  |  |  | 34,697 |  |  |  | 154,356 |  |
| Total current assets |  |  | 411,919 |  |  |  | (7,139 | ) |  |  | 404,780 |  |
| Total assets |  |  | 1,268,211 |  |  |  | (7,139 | ) |  |  | 1,261,072 |  |
| Contract liabilities (2) |  |  | 53,251 |  |  |  | 1,423 |  |  |  | 54,674 |  |
| Total current liabilities |  |  | 194,668 |  |  |  | 1,423 |  |  |  | 196,091 |  |
| Deferred tax liabilities |  |  | 61,536 |  |  |  | 226 |  |  |  | 61,762 |  |
| Total liabilities |  |  | 491,419 |  |  |  | 1,423 |  |  |  | 492,842 |  |
| Retained earnings |  |  | 627,670 |  |  |  | (8,562 | ) |  |  | 619,108 |  |
| Total shareholders’ equity |  |  | 776,792 |  |  |  | (8,562 | ) |  |  | 768,230 |  |
| Total liabilities and shareholders’ equity |  | $ | 1,268,211 |  |  |  | (7,139 | ) |  |  | 1,261,072 |  |

[0001144204-19-006206:notes:106]
|  | (1) | Previously “cost and estimated earnings on long-term contracts” |
|  | (2) | Previously “advance payments on long-term contracts” and “current portion of deferred revenue” |

[0001144204-19-006206:notes:107]
|  |  | Three Months EndedDecember 31, 2018 |
| (In thousands, except per share amounts) |  | As Reported |  | Effect of theadoption ofASC 606 |  | Under PriorAccounting |
| Consolidated Statements of Operations |  |  |  |  |  |  |
| Net sales |  | $ | 182,597 |  |  | $ | (4,746 | ) |  | $ | 177,851 |  |
| Cost of sales |  |  | 118,908 |  |  |  | (4,448 | ) |  |  | 114,460 |  |
| Total costs and expenses |  |  | 159,340 |  |  |  | (4,448 | ) |  |  | 154,892 |  |
| Earnings before income tax |  |  | 23,257 |  |  |  | (297 | ) |  |  | 22,960 |  |
| Income tax (benefit) expense |  |  | 5,940 |  |  |  | (64 | ) |  |  | 5,876 |  |
| Net earnings |  |  | 17,317 |  |  |  | (234 | ) |  |  | 17,083 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 0.67 |  |  | $ | (0.01 | ) |  | $ | 0.66 |  |
| Diluted: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 0.66 |  |  | $ | (0.01 | ) |  | $ | 0.65 |  |
| Consolidated Statements of Comprehensive Income |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 17,317 |  |  | $ | (234 | ) |  | $ | 17,083 |  |
| Comprehensive income |  |  | 12,763 |  |  |  | (234 | ) |  |  | 12,529 |  |
| Consolidated Statements of Cash flows |  |  |  |  |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 17,317 |  |  | $ | (234 | ) |  | $ | 17,083 |  |
| Adjustments to reconcile net earnings to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Change in assets and liabilities |  | $ | (7,912 | ) |  |  | 234 |  |  | $ | (7,678 | ) |
| Net cash provided by operating activities |  |  | 8,102 |  |  |  | - |  |  |  | 8,102 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001144204-19-006206:notes:108]
Our revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2018 
are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within our reportable segments.

[0001144204-19-006206:notes:109]
| (In thousands) |  | Filtration |  |  | Test |  |  | USG |  |  | Technical Packaging |  |  | Total |  |
| Customer type: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial |  | $ | 37,523 |  |  | $ | 36,297 |  |  | $ | 54,662 |  |  | $ | 19,114 |  |  | $ | 147,596 |  |
| U.S. Government |  |  | 28,701 |  |  |  | 4,989 |  |  |  | 1,193 |  |  |  | 118 |  |  |  | 35,001 |  |
| Total revenues |  | $ | 66,224 |  |  | $ | 41,286 |  |  | $ | 55,855 |  |  | $ | 19,232 |  |  | $ | 182,597 |  |
| Geographic location: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  | $ | 54,847 |  |  | $ | 28,453 |  |  | $ | 40,228 |  |  | $ | 9,849 |  |  | $ | 133,377 |  |
| International |  |  | 11,377 |  |  |  | 12,833 |  |  |  | 15,627 |  |  |  | 9,383 |  |  |  | 49,220 |  |
| Total revenues |  | $ | 66,224 |  |  | $ | 41,286 |  |  | $ | 55,855 |  |  | $ | 19,232 |  |  | $ | 182,597 |  |
| Revenue recognition method: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Point in time |  | $ | 32,054 |  |  | $ | 10,382 |  |  | $ | 44,303 |  |  | $ | - |  |  | $ | 86,739 |  |
| Over time |  |  | 34,170 |  |  |  | 30,904 |  |  |  | 11,552 |  |  |  | 19,232 |  |  |  | 95,858 |  |
| Total revenues |  | $ | 66,224 |  |  | $ | 41,286 |  |  | $ | 55,855 |  |  | $ | 19,232 |  |  | $ | 182,597 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001144204-19-006206:notes:110]
|  | 2. | SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES UPDATE |

[0001144204-19-006206:notes:111]
Our significant accounting policies are included in Note 1 of our Annual Report on Form 10-K for the year ended September 30, 2018. On October 1, 2018, we adopted ASU No. 2014-09,

[0001144204-19-006206:notes:112]
Revenue from Contracts with Customers (ASC 606)

[0001144204-19-006206:notes:113]
. Significant changes to our policies resulting from the adoption are provided below. We adopted ASC 606 using the modified retrospective transition method applied to contracts that were not substantially complete at the end of fiscal year 2018. We recorded a $5.5 million adjustment to increase retained earnings to reflect the cumulative impact of adopting this standard at the beginning of fiscal year 2019, primarily related to certain long-term contracts our Filtration and Technical Packaging segments have that converted to the cost-to-cost method for revenue recognition. The comparative information has not been restated and is reported under the accounting standards in effect for those periods. A reconciliation of the financial statement line items impacted for the three months ended December 31, 2018 under ASC 606 to the prior accounting standards is provided in Note 14.

[0001144204-19-006206:notes:114]
Contract assets arise from contracts when revenue is recognized over time and the amount of revenue recognized, including our estimate of variable consideration that has been included in the transaction price, exceeds the amount billed to the customer. These amounts are included in contract assets until the right to payment is no longer conditional on events other than the passage of time. These contract assets are reclassified to receivables when the right to consideration becomes unconditional. Contract liabilities include deposits, deferred revenue, upfront payments and billings in excess of revenue recognized. Liabilities for customer rebates and discounts are included in other current liabilities in the accompanying balance sheet.


## ese:RevenuesTextBlock

[0001144204-19-006206:notes:115]
|  | 14. | REVENUES |

[0001144204-19-006206:notes:116]
Disaggregation of Revenues

[0001144204-19-006206:notes:117]
Remaining Performance Obligations

[0001144204-19-006206:notes:118]
Our remaining performance obligations, which is the equivalent of our backlog, represent the expected transaction price allocated to our contracts that we expect to recognize as revenue in future periods when we perform under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At December 31, 2018, 
we had $398.3 million in remaining performance obligations of which we expect to recognize revenues of approximately 83% in the next twelve months.

[0001144204-19-006206:notes:119]
Contract assets and liabilities

[0001144204-19-006206:notes:120]
Assets and liabilities related to our contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At December 31, 2018, contract assets and liabilities totaled $
94.1
 million and $
53.3
 million, respectively. Upon adoption of ASC 606 on October 1, 2018, contract assets and liabilities related to our contracts with customers were 
$87 million and $51 million, 
respectively. During the first quarter of 2019, we recognized approximately 
$20 million in revenues
 that were included in the contract liabilities balance at the adoption date.

[0001144204-19-006206:notes:121]
Reconciliation of ASC 606 to Prior Accounting Standards
