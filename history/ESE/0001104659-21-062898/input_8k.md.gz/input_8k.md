# ESE 8-K — 0001104659-21-060985 filed 2021-05-04

## item codes, every 8-K on or before 2021-05-07

- 2021-05-04 0001104659-21-060985 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2021-04-05 0001104659-21-046581 — 5.02, 9.01
- 2021-02-08 0001104659-21-013712 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2020-12-09 0001104659-20-133674 — 5.02, 9.01
- 2020-12-07 0001104659-20-132861 — 5.02, 7.01, 9.01
- 2020-11-19 0001104659-20-127352 — 2.02, 5.02, 7.01, 9.01
- 2020-08-10 0001104659-20-092734 — 2.02, 7.01, 9.01
- 2020-05-06 0001104659-20-057442 — 2.02, 7.01, 8.01, 9.01
- 2020-02-04 0001104659-20-010640 — 2.02, 5.07, 7.01, 9.01
- 2020-01-07 0001104659-20-001789 — 2.01, 9.01
- 2019-11-19 0001104659-19-065437 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2019-11-18 0001104659-19-065096 — 1.01, 2.02, 7.01, 9.01
- 2019-09-30 0001144204-19-046523 — 1.01, 1.02, 2.03, 9.01
- 2019-08-08 0001144204-19-038567 — 2.02, 7.01, 9.01
- 2019-05-07 0001144204-19-024241 — 2.02, 5.02, 7.01, 9.01
- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2021-05-07

- none on or before 2021-05-07

## item 2.02 — earnings release, exhibit 99.1

[0001104659-21-060985:8k_2_02:1]
EX-99.1
2
tm2115025d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-21-060985:8k_2_02:2]
Exhibit 99.1

[0001104659-21-060985:8k_2_02:3]
| NEWS FROM |  |

[0001104659-21-060985:8k_2_02:4]
For more information contact:

[0001104659-21-060985:8k_2_02:5]
Kate Lowrey

[0001104659-21-060985:8k_2_02:6]
Director, Investor Relations

[0001104659-21-060985:8k_2_02:7]
ESCO Technologies Inc.

[0001104659-21-060985:8k_2_02:8]
(314)
213-7277

[0001104659-21-060985:8k_2_02:9]
ESCO ANNOUNCES
SECOND QUARTER FISCAL 2021 RESULTS

[0001104659-21-060985:8k_2_02:10]
- Q2 GAAP
EPS $0.62 and Adjusted EPS $0.59 (Tops Consensus Estimate) -

[0001104659-21-060985:8k_2_02:11]
- YTD 2021
Adjusted EPS $1.15 versus $1.11 YTD 2020 (Pre-COVID) -

[0001104659-21-060985:8k_2_02:12]
- Record YTD
Cash Flow from Operations -

[0001104659-21-060985:8k_2_02:13]
ST. LOUIS, May 4,
2021 – ESCO Technologies Inc. (NYSE: ESE) (ESCO, or the Company) today reported its operating results for the second quarter and
six months ended March 31, 2021 (Q2 2021 and YTD 2021) compared to the second quarter and six months ended March 31, 2020 (Q2 2020 and
YTD 2020).

[0001104659-21-060985:8k_2_02:14]
Vic Richey, Chairman
and Chief Executive Officer, commented, “We continue to successfully manage through the COVID-19 global pandemic and our primary
focus remains the health and safety of our employees, customers and suppliers. I’m proud of our entire team for how they’ve
responded to the challenges over the past year, and I’m confident that we are positioning ourselves to be a stronger, more profitable
company as we emerge from the pandemic and our end-markets fully recover.

[0001104659-21-060985:8k_2_02:15]
“Our second
quarter and year-to-date operating results reflect the importance of maintaining diversity across our end-markets, as this diversity,
coupled with our substantial liquidity will continue to support our long-term growth. Our multi-segment platform enabled us to substantially
mitigate the pandemic’s impact on our operating results, and our disciplined approach around working capital management allowed
us to generate record cash flow in 2021.

[0001104659-21-060985:8k_2_02:16]
“Given the
strength of the first half of 2020 pre-COVID, we previously communicated that we expected the first half of 2021 to be slightly lower,
comparatively. Through March 31st, we are ahead of our original profit expectations as our continued focus on operating execution
and effective cost management drove our first-half Adjusted EPS to $1.15 per share, an increase of 4 percent over the Adjusted EPS of
$1.11 per share reported in the first half of 2020. This was accomplished despite a 6 percent decrease in sales primarily due to COVID’s
impact.

[0001104659-21-060985:8k_2_02:17]
“Regarding
our upcoming executive management team retirements announced previously, I’m pleased to welcome Chris Tucker to our executive
leadership team as Senior Vice President and Chief Financial Officer replacing Gary Muenster, who’s retiring after 31 years at
ESCO, with the past 18 years serving as Executive Vice President and Chief Financial Officer. Chris possesses a strong financial
skill-set and a keen understanding of strategy, capital allocation, ROIC, and shareholder value creation developed during his 24
year career at Emerson.

[0001104659-21-060985:8k_2_02:18]
“Additionally,
Dave Schatz, who has been with ESCO for the past 23 years, has been promoted to Senior Vice President, General Counsel & Secretary
replacing Alyson Barclay who is retiring after 33 years with the Company, most recently serving as Senior Vice President and with the
past 21 years as General Counsel & Secretary. I look forward to working with Chris and Dave in their new roles, and I’d like
to thank Gary and Alyson for their substantial contributions to ESCO’s success over their long careers.”

[0001104659-21-060985:8k_2_02:19]
Discrete Items

[0001104659-21-060985:8k_2_02:20]
During Q2 2021,
the Company recorded a $1.9 million pretax gain from the contingent cash settlement of the fiscal 2019 sale of the former Doble headquarters
property in Watertown, Massachusetts, partially offset by $0.7 million of facility shut-down costs related to the closure of a former
USG manufacturing facility in Toronto (described in the November 2020 earnings release). The combined impact resulted in a net after-tax
gain of $0.03 per share which is excluded from the calculation of Adjusted EBITDA and Adjusted EPS in Q2 2021.

[0001104659-21-060985:8k_2_02:21]
There were no Discrete
Items identified in Q2 2020 impacting GAAP EPS or Adjusted EPS.

[0001104659-21-060985:8k_2_02:22]
During Q1 2020,
the company completed the sale of its Technical Packaging segment which resulted in gross cash proceeds of $191 million and a net gain
on the sale of $77 million, or $2.93 per share, which is recorded as discontinued operations. The impact of discontinued operations is
excluded from the calculation of Adjusted EBITDA and Adjusted EPS in 2020.

[0001104659-21-060985:8k_2_02:23]
The financial results
presented include certain non-GAAP financial measures such as EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS, as defined within the “Non-GAAP
Financial Measures” described below. Any non-GAAP financial measures presented are reconciled to their respective GAAP equivalents.

[0001104659-21-060985:8k_2_02:24]
Management believes
these non-GAAP financial measures are useful in assessing the ongoing operational profitability of the Company’s business segments,
and therefore, allow shareholders better visibility into the Company’s underlying operations. See “Non-GAAP Financial
Measures” described below.

[0001104659-21-060985:8k_2_02:25]
Earnings Summary

[0001104659-21-060985:8k_2_02:26]
Q2 2021 GAAP EPS
was $0.62 per share (GAAP net earnings of $16.3 million) and included the net earnings’ impact of the Q2 2021 Discrete Items described
above. Excluding the net earnings impact of the Discrete Items, Q2 2021 Adjusted EPS was $0.59 per share.

[0001104659-21-060985:8k_2_02:27]
Q2 2020 GAAP EPS
and Adjusted EPS was $0.68 per share (GAAP net earnings of $17.8 million).

[0001104659-21-060985:8k_2_02:28]
Adjusted EBITDA
was $31 million in Q2 2021 and Q2 2020, and YTD Adjusted EBITDA increased to $60 million, from $59 million YTD 2020.

[0001104659-21-060985:8k_2_02:29]
Operating Highlights
 – Q2

[0001104659-21-060985:8k_2_02:30]
|  | · | Net sales were $167 million in Q2 2021, compared to $180 million in Q2 2020, pre-COVID. |
|  | · | A&D segment sales decreased $12 million in Q2 2021, resulting from lower commercial aerospace sales due to COVID, partially offset by a $4 million increase in Navy sales. |

[0001104659-21-060985:8k_2_02:31]
|  | · | Driven by an increase in chamber project deliveries internationally, Test sales increased to $44 million in Q2 2021 from $42 million in Q2 2020. |
|  | · | USG sales were $40 million in Q2 2021 compared to $44 million in Q2 2020 as a result of COVID restrictions impacting on-site personnel at substations, large transformers and other customer locations. Q2 2021 sales were also impacted by the higher volume of sales reported in Q1 2021 as several utility customers accelerated calendar year-end spending for equipment and software requirements. The quarterly timing of YTD 2021 sales resulted in a modest decrease in sales from YTD 2020, pre-COVID. |
|  | · | Consolidated gross margin percentage increased to 38.1 percent in Q2 2021 from 37.3 percent in Q2 2020 driven by a favorable sales mix coupled with manufacturing cost reduction actions previously implemented across the company. |
|  | · | SG&A expenses decreased $1.2 million in Q2 2021 compared to Q2 2020 as a result of lower spending (lower headcount, less travel, no pension costs) which helped to offset the reduced sales due to COVID. |
|  | · | Interest expense decreased $0.9 million in Q2 2021 compared to Q2 2020 due to lower debt outstanding. |
|  | · | The effective income tax rate increased to 23.5 percent in Q2 2021 from 11 percent in Q2 2020. The significantly lower tax rate in Q2 2020 reflected the favorable impact of certain one-time tax strategies implemented in the prior year which were not repeated. |
|  | · | Entered orders were $176 million in Q2 2021 (book-to-bill of 1.06x) with all three operating segments reporting backlog growth, resulting in ending backlog of $522 million at March 31, 2021. |
|  | · | YTD 2021 net cash provided by operating activities was $57 million, resulting in a net cash position (total cash on hand, less total borrowings) of $24 million at March 31, 2021 reflecting a 0.23x leverage ratio. |

[0001104659-21-060985:8k_2_02:32]
Chairman’s
Commentary

[0001104659-21-060985:8k_2_02:33]
Vic Richey, Chairman
and Chief Executive Officer, commented, “While still being impacted by COVID within our commercial aerospace and utility businesses,
I’m really pleased with our Q2 and YTD results as we continue to see numerous highlights across the company which offset the obvious
headwinds.

[0001104659-21-060985:8k_2_02:34]
“Driven by
our increased focus on working capital management and cash conversion, a clear highlight for the first half of the year is the strength
of our cash generation which continued to increase our liquidity. Our strong balance sheet has us positioned favorably as we move forward
on current acquisition opportunities and continue to expand our internal investments in new product development across the company.

[0001104659-21-060985:8k_2_02:35]
“From an operations
perspective, A&D clearly led our Q2 2021 success by substantially exceeding our internal expectations on both sales and earnings,
as the segment reported an Adjusted EBIT margin of nearly 22 percent in the Quarter. A&D’s margin contribution was impressive
given the noted decrease in commercial aerospace sales, which have historically been a meaningful profit contributor to the segment.
This solid margin was achieved as a result of our actions to reduce costs and resize the business during 2020 in response to the downturn
in commercial air travel.

[0001104659-21-060985:8k_2_02:36]
“Delivering
a solid operating margin in A&D during COVID reflects the strength of our program, product and end-market diversity, as the Navy
and defense markets remained resilient. A&D’s longer-term operating margins are expected to improve as the commercial aerospace
market recovers over time, while further benefitting from our lower operating cost structure. The defense portion of A&D, both military
aerospace and Navy products, is expected to remain strong for the foreseeable future given its sizeable backlog coupled with the timing
of expected platform deliveries.

[0001104659-21-060985:8k_2_02:37]
“We continue
to see tangible signs of recovery in commercial aerospace as passenger boardings continue to increase and we’ve noted that more
airlines are adding idled aircraft back into the fleet. We believe as COVID vaccinations become more widespread, the hesitance within
the traveling public will diminish and this will accelerate pent-up travel demand.

[0001104659-21-060985:8k_2_02:38]
“The performance
of the Test segment continues to be solid as we increased our Q2 2021 sales by over 5 percent and delivered an EBIT margin of 13 percent.
While not immune from COVID’s impact, our Test business continues to demonstrate its resilience by delivering consistently solid
operating results, and we expect Test’s outlook to remain positive given the strength of its served markets, primarily related
to new communications technologies such as 5G, and our growing shielding business. Our view of 5G’s future is favorable given the
size of the investments being made by numerous large, global companies leading its development.

[0001104659-21-060985:8k_2_02:39]
“While USG’s
Q2 2021 sales were softer than originally projected, primarily due to the timing within the respective quarters in the first half of
2021, I’m pleased with their performance year-to-date both from a sales and Adjusted EBIT perspective. Doble was most impacted
by the sales timing profile in Q2 2021, while NRG’s renewable energy business significantly exceeded our internal expectations
and prior year.

[0001104659-21-060985:8k_2_02:40]
“USG’s
YTD 2021 sales were down modestly from prior year due to COVID’s impact on the utility industry world-wide, but I’m pleased
to see the YTD 2021 Adjusted EBIT margin of 20 percent, up from 15 percent YTD 2020. A favorable sales mix in addition to our cost reduction
actions implemented last year are having a positive impact on our operating margins, and we expect that trend to continue.

[0001104659-21-060985:8k_2_02:41]
“We expect
to see some continued deferrals of test equipment purchases and maintenance-related projects for the next few months, but our positive
outlook for the second half of the year remains unchanged.

[0001104659-21-060985:8k_2_02:42]
“I’m
encouraged by the enthusiasm being generated in the market surrounding several new products and solutions recently introduced at Doble,
and we continue to see NRG’s end markets gaining momentum as investments in renewable energy have been increasing in both wind
and solar. Sales of our recently upgraded solar products have been growing far better than anticipated and we expect that growth to continue.

[0001104659-21-060985:8k_2_02:43]
“Wrapping
up, I’m pleased that we continue to generate substantial cash from operations and were able to increase our Q2 2021 Adjusted EBITDA
margin to 19 percent, up from 17 percent in Q2 2020, despite the lower contribution from our commercial aerospace business and the timing
of USG’s quarterly sales.

[0001104659-21-060985:8k_2_02:44]
“Given
our strong financial condition, we expect to fund future acquisitions while organically growing our business through continued
investment in new products and solutions. We are evaluating a solid pipeline of M&A opportunities and we are confident that we
will add to our current portfolio. We are clearly focused on targets that will increase shareholder value by adding complementary
businesses that deliver meaningful returns.

[0001104659-21-060985:8k_2_02:45]
“We have positioned
ourselves favorably from a cost structure standpoint and we anticipate a gradual return to a more normal operating environment in the
second half of 2021. I continue to have a strong, favorable view of our future.”

[0001104659-21-060985:8k_2_02:46]
Dividend Payment

[0001104659-21-060985:8k_2_02:47]
The
next quarterly cash dividend of $0.08 per share will be paid on July 16, 2021 to stockholders of record on July 1, 2021.

[0001104659-21-060985:8k_2_02:48]
Business Outlook
 – 2021 (COVID Uncertainty)

[0001104659-21-060985:8k_2_02:49]
Our current Business
Outlook for the remainder of 2021 is consistent with the commentary included in the Company’s previous earnings releases and is
summarized below.

[0001104659-21-060985:8k_2_02:50]
In mid-year 2020,
business disruptions related to the pandemic began to affect the Company’s operations and continued throughout the balance of the
year. During 2021, the commercial aerospace and utility end-markets have seen some degree of customer stabilization, as well as notable
pockets of recovery; however, there is still uncertainty as to the timing and pace of the recovery in these areas.

[0001104659-21-060985:8k_2_02:51]
The wide distribution
of viable COVID-19 vaccines is anticipated to benefit and accelerate the recovery of commercial air travel and utility spending with
customers resuming normal testing protocols and equipment purchases, but Management has determined that it is advisable to wait before
resuming specific guidance.

[0001104659-21-060985:8k_2_02:52]
Given this uncertainty,
it is difficult to predict how the balance of 2021 will be affected using normal forecasting methodologies, therefore, the Company will
continue its suspension of forward-looking guidance.

[0001104659-21-060985:8k_2_02:53]
To assist shareholders
and analysts, Management will continue offering “directional” guidance for the balance of 2021, by stating that the Company
continues to see tangible signs of recovery that point to a solid outlook for the back half of the year, and the second half of 2021
is expected to compare favorably to the second half of 2020 given the anticipated elements of recovery.

[0001104659-21-060985:8k_2_02:54]
Management’s
current expectations for 2021 show growth in Sales, Adjusted EBITDA, Adjusted EPS, and cash flow from operating activities compared to
2020, with Adjusted EBITDA reasonably consistent with 2019, pre-COVID.

[0001104659-21-060985:8k_2_02:55]
Conference Call

[0001104659-21-060985:8k_2_02:56]
The Company will
host a conference call today, May 4, at 4:00 p.m. Central Time, to discuss the Company’s Q2 2021 results. A live audio webcast
will be available on the Company’s website at www.escotechnologies.com. Please access the website at least 15 minutes prior to
the call to register, download and install any necessary audio software. A replay of the conference call will be available on the Company’s
website noted above or by phone (dial 1-855-859-2056 and enter the pass code 9334419).

[0001104659-21-060985:8k_2_02:57]
Forward-Looking
Statements

[0001104659-21-060985:8k_2_02:58]
Statements in this
press release regarding the timing and magnitude of recovery in the Company’s end markets resulting from the availability of viable
COVID-19 vaccines, the continuing impacts of COVID-19 on the Company’s results, Sales, Adjusted EBITDA, Adjusted EPS, cash flow,
results of cost reduction efforts, margins, growth, the financial success of the Company, the strength of its end markets, the outlook
for the A&D, Test and USG segments, the ability to increase shareholder value, the timing and success of acquisition efforts, internal
investments in new products and solutions, the long-term success of the Company, and any other statements which are not strictly historical
are “forward-looking” statements within the meaning of the safe harbor provisions of the federal securities laws.

[0001104659-21-060985:8k_2_02:59]
Investors are cautioned
that such statements are only predictions and speak only as of the date of this release, and the Company undertakes no duty to update
them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially
from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and
business environment including but not limited to those described in Item 1A, “Risk Factors”, of the Company’s Annual
Report on Form 10-K for the fiscal year ended September 30, 2020; the availability and acceptance of viable COVID-19 vaccines by enough
of the U.S. and world’s population to curtail the pandemic; the continuing impact of the COVID-19 pandemic including labor shortages,
facility closures, shelter in place policies or quarantines, material shortages, transportation delays, termination or delays of Company
contracts, and the inability of our suppliers or customers to perform; the impacts of natural disasters on the Company’s operations
and those of the Company’s customers and suppliers; the timing and content of future contract awards or customer orders; the appropriation,
allocation and availability of Government funds; the termination for convenience of Government and other customer contracts or orders;
weakening of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer
insolvencies; competition; intellectual property rights; technical difficulties; the success of the Company’s acquisition efforts;
delivery delays or defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the
costs and availability of certain raw materials; labor disputes; changes in U.S. tax laws and regulations; other changes in laws and
regulations including but not limited to changes in accounting standards and foreign taxation; changes in interest rates; costs relating
to environmental matters arising from current or former facilities; uncertainty regarding the ultimate resolution of current disputes,
claims, litigation or arbitration; and the integration of recently acquired businesses.

[0001104659-21-060985:8k_2_02:60]
Non-GAAP Financial
Measures

[0001104659-21-060985:8k_2_02:61]
The financial
measures EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS are presented in this press release. The Company defines “EBIT”
as earnings before interest and taxes, “EBITDA” as earnings before interest, taxes, depreciation and amortization,
 “Adjusted EBITDA” as EBITDA excluding certain defined charges, and “Adjusted EPS” as GAAP earnings per share
(EPS) excluding the net impact of the items described above which were ($0.03) per share in Q2 2021.

[0001104659-21-060985:8k_2_02:62]
EBIT, EBITDA, Adjusted
EBITDA and Adjusted EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management
believes that EBIT, EBITDA and Adjusted EBITDA are useful in assessing the operational profitability of the Company’s business
segments because they exclude interest, taxes, depreciation and amortization, which are generally accounted for across the entire Company
on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company as
well as incentive compensation. The presentation of EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS provides important supplemental information
to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures to supplement their
GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance determined in accordance
with GAAP.

[0001104659-21-060985:8k_2_02:63]
ESCO, headquartered
in St. Louis, Missouri: Manufactures highly-engineered filtration and fluid control products for the aviation, Navy, space and process
markets worldwide, as well as composite-based products and solutions for Navy, defense and industrial customers; is the industry leader
in RF shielding and EMC test products; and provides diagnostic instruments, software and services for the benefit of industrial power
users and the electric utility and renewable energy industries. Further information regarding ESCO and its subsidiaries is available
on the Company’s website at www.escotechnologies.com.

[0001104659-21-060985:8k_2_02:64]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-21-060985:8k_2_02:65]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-21-060985:8k_2_02:66]
(Dollars in thousands, except per share amounts)

[0001104659-21-060985:8k_2_02:67]
|  |  | Three Months Ended March 31, 2021 |  |  | Three Months Ended March 31, 2020 |  |
| Net Sales |  | $ | 166,644 |  |  |  | 180,492 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 103,113 |  |  |  | 113,242 |  |
| Selling, general and administrative expenses |  |  | 38,746 |  |  |  | 39,982 |  |
| Amortization of intangible assets |  |  | 4,917 |  |  |  | 5,220 |  |
| Interest expense |  |  | 432 |  |  |  | 1,320 |  |
| Other (income) expenses, net |  |  | (1,903 | ) |  |  | 703 |  |
| Total costs and expenses |  |  | 145,305 |  |  |  | 160,467 |  |
| Earnings before income taxes |  |  | 21,339 |  |  |  | 20,025 |  |
| Income tax expense |  |  | 5,025 |  |  |  | 2,203 |  |
| Net earnings |  | $ | 16,314 |  |  |  | 17,822 |  |
| Diluted EPS: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 0.62 |  |  |  | 0.68 |  |
| Diluted - As Adjusted Basis |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.59 | (1) |  |  | 0.68 |  |
| Diluted average common shares O/S: |  |  | 26,201 |  |  |  | 26,088 |  |

[0001104659-21-060985:8k_2_02:68]
| (1) | Q2 2021 Adjusted EPS excludes $0.03 per share of after-tax income associated with the final settlement from the sale of the Doble Watertown facility partially offset by charges related to the Doble Manta facility consolidation. |

[0001104659-21-060985:8k_2_02:69]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-21-060985:8k_2_02:70]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-21-060985:8k_2_02:71]
(Dollars in thousands, except per share amounts)

[0001104659-21-060985:8k_2_02:72]
|  |  | Six Months Ended March 31, 2021 |  |  | Six Months Ended March 31, 2020 |  |
| Net Sales |  | $ | 329,593 |  |  |  | 352,220 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 201,890 |  |  |  | 219,969 |  |
| Selling, general and administrative expenses |  |  | 79,746 |  |  |  | 82,087 |  |
| Amortization of intangible assets |  |  | 9,865 |  |  |  | 11,030 |  |
| Interest expense |  |  | 973 |  |  |  | 3,741 |  |
| Other (income) expenses, net |  |  | (1,880 | ) |  |  | 998 |  |
| Total costs and expenses |  |  | 290,594 |  |  |  | 317,825 |  |
| Earnings before income taxes |  |  | 38,999 |  |  |  | 34,395 |  |
| Income tax expense |  |  | 8,999 |  |  |  | 5,809 |  |
| Earnings from continuing operations |  |  | 30,000 |  |  |  | 28,586 |  |
| (Loss) earnings from discontinued operations, net of tax expense of $269 |  |  | - |  |  |  | (601 | ) |
| Gain on sale of discontinued operations, net of tax expense of $23,734 |  |  | - |  |  |  | 76,614 |  |
| Earnings from discontinued operations |  |  | - |  |  |  | 76,013 |  |
| Net earnings |  | $ | 30,000 |  |  |  | 104,599 |  |
| Diluted EPS: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 1.15 |  |  |  | 1.09 |  |
| Discontinued operations |  |  | 0.00 |  |  |  | 2.91 |  |
| Net earnings |  | $ | 1.15 |  |  |  | 4.00 |  |
| Diluted - As Adjusted Basis |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 1.15 | (1) |  |  | 1.11 | (2) |
| Diluted average common shares O/S: |  |  | 26,192 |  |  |  | 26,126 |  |

[0001104659-21-060985:8k_2_02:73]
| (1) | YTD Q2 2021 Adjusted EPS excludes after-tax income associated with the final settlement from the sale of the Doble Watertown facility which was offset by charges related to the Doble Manta facility consolidation and ATM acquisition inventory step-up. |
| (2) | YTD Q2 2020 Adjusted EPS excludes $0.02 per share of after-tax charges primarily related to the move of the Doble headquarters facility. |

[0001104659-21-060985:8k_2_02:74]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-21-060985:8k_2_02:75]
Condensed Business Segment Information (Unaudited)

[0001104659-21-060985:8k_2_02:76]
(Dollars in thousands)

[0001104659-21-060985:8k_2_02:77]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | Q2 2021 |  |  | Q2 2020 |  |  | Q2 2021 |  |  | Q2 2020 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 83,278 |  |  |  | 95,124 |  |  |  | 83,278 |  |  |  | 95,124 |  |
| USG |  |  | 39,555 |  |  |  | 43,768 |  |  |  | 39,555 |  |  |  | 43,768 |  |
| Test |  |  | 43,811 |  |  |  | 41,600 |  |  |  | 43,811 |  |  |  | 41,600 |  |
| Totals |  | $ | 166,644 |  |  |  | 180,492 |  |  |  | 166,644 |  |  |  | 180,492 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 18,196 |  |  |  | 21,736 |  |  |  | 18,236 |  |  |  | 21,736 |  |
| USG |  |  | 6,725 |  |  |  | 4,866 |  |  |  | 5,461 |  |  |  | 4,866 |  |
| Test |  |  | 5,688 |  |  |  | 5,651 |  |  |  | 5,688 |  |  |  | 5,651 |  |
| Corporate |  |  | (8,838 | ) |  |  | (10,908 | ) |  |  | (8,548 | ) |  |  | (10,908 | ) |
| Consolidated EBIT |  |  | 21,771 |  |  |  | 21,345 |  |  |  | 20,837 |  |  |  | 21,345 |  |
| Less: Interest expense |  |  | (432 | ) |  |  | (1,320 | ) |  |  | (432 | ) |  |  | (1,320 | ) |
| Less: Income tax expense |  |  | (5,025 | ) |  |  | (2,203 | ) |  |  | (4,810 | ) |  |  | (2,203 | ) |
| Net earnings from cont ops |  | $ | 16,314 |  |  |  | 17,822 |  |  |  | 15,595 |  |  |  | 17,822 |  |

[0001104659-21-060985:8k_2_02:78]
Note 1: Adjusted net earnings of $15.6 million in Q2 2021 excludes $0.03 per share of after-tax income associated with the final settlement from the sale of the Doble Watertown facility partially offset by charges related to the Doble Manta facility consolidation.

[0001104659-21-060985:8k_2_02:79]
EBITDA Reconciliation
to Net earnings from continuing operations:

[0001104659-21-060985:8k_2_02:80]
|  |  |  |  |  |  |  |  | Adjusted |  |  | Adjusted |  |
|  |  | Q2 2021 |  |  | Q2 2020 |  |  | Q2 2021 |  |  | Q2 2020 |  |
| Consolidated EBITDA |  | $ | 31,874 |  |  |  | 31,388 |  |  |  | 30,940 |  |  |  | 31,388 |  |
| Less: Depr & Amort |  |  | (10,103 | ) |  |  | (10,043 | ) |  |  | (10,103 | ) |  |  | (10,043 | ) |
| Consolidated EBIT |  |  | 21,771 |  |  |  | 21,345 |  |  |  | 20,837 |  |  |  | 21,345 |  |
| Less: Interest expense |  |  | (432 | ) |  |  | (1,320 | ) |  |  | (432 | ) |  |  | (1,320 | ) |
| Less: Income tax expense |  |  | (5,025 | ) |  |  | (2,203 | ) |  |  | (4,810 | ) |  |  | (2,203 | ) |
| Net earnings from cont ops |  | $ | 16,314 |  |  |  | 17,822 |  |  |  | 15,595 |  |  |  | 17,822 |  |

[0001104659-21-060985:8k_2_02:81]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-21-060985:8k_2_02:82]
Condensed Business Segment Information (Unaudited)

[0001104659-21-060985:8k_2_02:83]
(Dollars in thousands)

[0001104659-21-060985:8k_2_02:84]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | YTD Q2 2021 |  |  | YTD Q2 2020 |  |  | YTD Q2 2021 |  |  | YTD Q2 2020 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 150,169 |  |  |  | 172,635 |  |  |  | 150,169 |  |  |  | 172,635 |  |
| USG |  |  | 94,095 |  |  |  | 96,602 |  |  |  | 94,095 |  |  |  | 96,602 |  |
| Test |  |  | 85,329 |  |  |  | 82,983 |  |  |  | 85,329 |  |  |  | 82,983 |  |
| Totals |  | $ | 329,593 |  |  |  | 352,220 |  |  |  | 329,593 |  |  |  | 352,220 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 27,576 |  |  |  | 34,249 |  |  |  | 27,936 |  |  |  | 34,319 |  |
| USG |  |  | 19,456 |  |  |  | 14,153 |  |  |  | 18,842 |  |  |  | 14,773 |  |
| Test |  |  | 11,030 |  |  |  | 10,307 |  |  |  | 11,030 |  |  |  | 10,307 |  |
| Corporate |  |  | (18,090 | ) |  |  | (20,573 | ) |  |  | (17,740 | ) |  |  | (20,573 | ) |
| Consolidated EBIT |  |  | 39,972 |  |  |  | 38,136 |  |  |  | 40,068 |  |  |  | 38,826 |  |
| Less: Interest expense |  |  | (973 | ) |  |  | (3,741 | ) |  |  | (973 | ) |  |  | (3,741 | ) |
| Less: Income tax |  |  | (8,999 | ) |  |  | (5,809 | ) |  |  | (9,021 | ) |  |  | (5,975 | ) |
| Net earnings from cont ops |  | $ | 30,000 |  |  |  | 28,586 |  |  |  | 30,074 |  |  |  | 29,110 |  |

[0001104659-21-060985:8k_2_02:85]
Note 1: Adjusted
net earnings of $30.1 million in YTD Q2 2021 excludes income from the final settlement on the sale of the Doble Watertown facility offset
by charges related to the Doble Manta facility consolidation and ATM acquisition inventory step-up.

[0001104659-21-060985:8k_2_02:86]
Note 2: Adjusted net earnings of $29.1 million in YTD Q2 2020 excludes $0.02 per share of after-tax charges related primarily to the facility move at Doble.

[0001104659-21-060985:8k_2_02:87]
EBITDA Reconciliation
to Net earnings from continuing operations:

[0001104659-21-060985:8k_2_02:88]
|  |  |  |  |  |  |  |  | Adjusted |  |  | Adjusted |  |
|  |  | YTD Q2 |  |  | YTD Q2 |  |  | YTD Q2 |  |  | YTD Q2 |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Consolidated EBITDA |  | $ | 60,087 |  |  |  | 58,719 |  |  |  | 60,183 |  |  |  | 59,409 |  |
| Less: Depr & Amort |  |  | (20,115 | ) |  |  | (20,583 | ) |  |  | (20,115 | ) |  |  | (20,583 | ) |
| Consolidated EBIT |  |  | 39,972 |  |  |  | 38,136 |  |  |  | 40,068 |  |  |  | 38,826 |  |
| Less: Interest expense |  |  | (973 | ) |  |  | (3,741 | ) |  |  | (973 | ) |  |  | (3,741 | ) |
| Less: Income tax expense |  |  | (8,999 | ) |  |  | (5,809 | ) |  |  | (9,021 | ) |  |  | (5,975 | ) |
| Net earnings from cont ops |  | $ | 30,000 |  |  |  | 28,586 |  |  |  | 30,074 |  |  |  | 29,110 |  |

[0001104659-21-060985:8k_2_02:89]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-21-060985:8k_2_02:90]
Condensed Consolidated Balance Sheets (Unaudited)

[0001104659-21-060985:8k_2_02:91]
(Dollars in thousands)

[0001104659-21-060985:8k_2_02:92]
|  |  | March 31, 2021 |  |  | September 30, 2020 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 45,653 |  |  |  | 52,560 |  |
| Accounts receivable, net |  |  | 124,580 |  |  |  | 144,082 |  |
| Contract assets |  |  | 95,002 |  |  |  | 96,746 |  |
| Inventories |  |  | 145,342 |  |  |  | 136,189 |  |
| Other current assets |  |  | 17,523 |  |  |  | 17,053 |  |
| Total current assets |  |  | 428,100 |  |  |  | 446,630 |  |
| Property, plant and equipment, net |  |  | 143,401 |  |  |  | 139,870 |  |
| Intangible assets, net |  |  | 345,261 |  |  |  | 346,632 |  |
| Goodwill |  |  | 411,661 |  |  |  | 408,063 |  |
| Operating lease assets |  |  | 18,929 |  |  |  | 21,390 |  |
| Other assets |  |  | 10,050 |  |  |  | 10,938 |  |
|  |  | $ | 1,357,402 |  |  |  | 1,373,523 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt & short-term borrowings |  | $ | 20,000 |  |  |  | 22,368 |  |
| Accounts payable |  |  | 47,091 |  |  |  | 50,525 |  |
| Contract liabilities |  |  | 106,622 |  |  |  | 100,551 |  |
| Other current liabilities |  |  | 72,870 |  |  |  | 82,585 |  |
| Total current liabilities |  |  | 246,583 |  |  |  | 256,029 |  |
| Deferred tax liabilities |  |  | 59,949 |  |  |  | 60,938 |  |
| Non-current operating lease liabilities |  |  | 14,501 |  |  |  | 16,785 |  |
| Other liabilities |  |  | 39,362 |  |  |  | 38,176 |  |
| Long-term debt |  |  | 2,000 |  |  |  | 40,000 |  |
| Shareholders' equity |  |  | 995,007 |  |  |  | 961,595 |  |
|  |  | $ | 1,357,402 |  |  |  | 1,373,523 |  |

[0001104659-21-060985:8k_2_02:93]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-21-060985:8k_2_02:94]
Consolidated Statements of Cash Flows (Unaudited)

[0001104659-21-060985:8k_2_02:95]
(Dollars in thousands)

[0001104659-21-060985:8k_2_02:96]
|  |  | Six Months Ended March 31, 2021 |  |
| Cash flows from operating activities: |  |  |  |  |
| Net earnings |  | $ | 30,000 |  |
| Adjustments to reconcile net earnings to net cash provided by operating activities: |  |  |  |  |
| Depreciation and amortization |  |  | 20,115 |  |
| Stock compensation expense |  |  | 2,745 |  |
| Changes in assets and liabilities |  |  | 7,401 |  |
| Gain on sale of building and land |  |  | (1,950 | ) |
| Effect of deferred taxes |  |  | (989 | ) |
| Net cash provided by operating activities |  |  | 57,322 |  |
| Cash flows from investing activities: |  |  |  |  |
| Acquisition of business, net of cash acquired |  |  | (6,684 | ) |
| Proceeds from sale of building and land |  |  | 1,950 |  |
| Capital expenditures |  |  | (13,153 | ) |
| Additions to capitalized software |  |  | (3,973 | ) |
| Net cash used by investing activities |  |  | (21,860 | ) |
| Cash flows from financing activities: |  |  |  |  |
| Proceeds from long-term debt |  |  | 34,000 |  |
| Principal payments on long-term debt and short-term borrowings |  |  | (74,368 | ) |
| Dividends paid |  |  | (4,167 | ) |
| Net cash used by financing activities |  |  | (44,535 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 2,166 |  |
| Net decrease in cash and cash equivalents |  |  | (6,907 | ) |
| Cash and cash equivalents, beginning of period |  |  | 52,560 |  |
| Cash and cash equivalents, end of period |  | $ | 45,653 |  |

[0001104659-21-060985:8k_2_02:97]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-21-060985:8k_2_02:98]
Other Selected Financial Data (Unaudited)

[0001104659-21-060985:8k_2_02:99]
(Dollars in thousands)

[0001104659-21-060985:8k_2_02:100]
| Backlog And Entered Orders - Q2 2021 |  | Aerospace & Defense |  |  | Test |  |  | USG |  |  | Total |  |
| Beginning Backlog - 1/1/21 |  | $ | 343,212 |  |  |  | 124,010 |  |  |  | 44,859 |  |  |  | 512,081 |  |
| Entered Orders |  |  | 88,206 |  |  |  | 44,403 |  |  |  | 43,639 |  |  |  | 176,248 |  |
| Sales |  |  | (83,278 | ) |  |  | (43,811 | ) |  |  | (39,555 | ) |  |  | (166,644 | ) |
| Ending Backlog - 3/31/21 |  | $ | 348,140 |  |  |  | 124,602 |  |  |  | 48,943 |  |  |  | 521,685 |  |

[0001104659-21-060985:8k_2_02:101]
| Backlog And Entered Orders - YTD Q2 2021 |  | Aerospace & Defense |  |  | Test |  |  | USG |  |  | Total |  |
| Beginning Backlog - 10/1/20 |  | $ | 344,661 |  |  |  | 122,032 |  |  |  | 50,688 |  |  |  | 517,381 |  |
| Entered Orders |  |  | 153,648 |  |  |  | 87,899 |  |  |  | 92,350 |  |  |  | 333,897 |  |
| Sales |  |  | (150,169 | ) |  |  | (85,329 | ) |  |  | (94,095 | ) |  |  | (329,593 | ) |
| Ending Backlog - 3/31/21 |  | $ | 348,140 |  |  |  | 124,602 |  |  |  | 48,943 |  |  |  | 521,685 |  |

[0001104659-21-060985:8k_2_02:102]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-21-060985:8k_2_02:103]
Reconciliation of Non-GAAP Financial Measures (Unaudited)

[0001104659-21-060985:8k_2_02:104]
| EPS – Adjusted Basis Reconciliation – Q2 2021 |  |  |  |
| EPS – GAAP Basis – Q2 2021 |  | $ | 0.62 |  |
| Adjustments (defined below) |  |  | (0.03 | ) |
| EPS – As Adjusted Basis – Q2 2021 |  | $ | 0.59 |  |

[0001104659-21-060985:8k_2_02:105]
Adjustments exclude $0.03
per share consisting of income associated with the final settlement from the sale of the Doble Watertown facility partially offset by
charges related to the Doble Manta facility consolidation in the second quarter of 2021. (The $0.03 of EPS adjustments per share consists
of $934K of pre-tax income offset by $215K of tax expense for net impact of $719K.)

[0001104659-21-060985:8k_2_02:106]
| EPS – Adjusted Basis Reconciliation – YTD Q2 2020 |  |  |  |  |
| EPS from Continuing Ops – GAAP Basis – YTD Q2 2020 |  | $ | 1.09 |  |
| Adjustments (defined below) |  |  | 0.02 |  |
| EPS from Continuing Ops – As Adjusted Basis – YTD Q2 2020 |  | $ | 1.11 |  |

[0001104659-21-060985:8k_2_02:107]
Adjustments exclude $0.02
per share consisting of move costs associated with the Doble facility consolidation in the first six months of 2020. (The $0.02 of
EPS adjustments per share consists of $690K of pre-tax charges offset by $166K of tax benefit for net impact of $524K.)
