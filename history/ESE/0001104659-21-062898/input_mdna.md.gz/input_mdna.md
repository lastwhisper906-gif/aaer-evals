# ESE MD&A — 0001104659-21-062898


## mdna

[0001104659-21-062898:mdna:1]
[same as prior period, unchanged from 0001104659-21-016643:mdna:1]

[0001104659-21-062898:mdna:2]
[same as prior period, unchanged from 0001104659-21-016643:mdna:4]

[0001104659-21-062898:mdna:3]
The COVID-19 global pandemic has created significant and unprecedented challenges, and during these highly uncertain times, our top priority remains the health and safety of our employees, customers and suppliers, thereby securing the financial well-being of the Company and supporting business continuity. Our businesses have been deemed essential and are currently operational, supplying our customers with vital and necessary products. To date, our global supply chains have not been materially affected by the pandemic. Given our diverse portfolio of strong, durable businesses serving non-discretionary end-markets, the strength and resilience of our business model positions us to continue our long-term outlook. Recognizing the uncertainty presented by this global pandemic, we are continuing to suspend our practice of providing financial guidance. Our businesses continue to face varying levels of pressure depending on the markets they serve and the impact on the Company cannot be reasonably estimated at this time. A portion of our workforce has worked from home at times due to COVID-19, however we have not had to redesign or design new internal controls over financial reporting at this time. Depending on the duration of COVID-19, it may become necessary for us to redesign or design new internal controls over financial reporting in a future period. We do not believe such an event will have a material impact on our business.

[0001104659-21-062898:mdna:4]
The economic uncertainty, changes in the propensity for the general public to travel by air, and reductions in demand for commercial aircraft as a result of the COVID-19 pandemic have adversely impacted net sales and operating results in certain of our Aerospace and Defense reporting units. In addition, our Westland facility had a partial shutdown of its facility for several weeks during the first quarter of 2021 due to COVID-19. We are also monitoring the impacts of COVID-19 on the fair value of assets. We do not currently anticipate any material impairments on assets as a result of COVID-19. We determined that there was no impairment for the three and six months ended March 31, 2021 and the fair value of each reporting unit substantially exceeded carrying value, with the exception of Mayday where fair value exceeded carrying value by less than 10%. At March 31, 2021, we had $30 million of goodwill recorded for Mayday. The valuation methodology we use involves estimates of discounted cash flows, which are subject to change, and if they change negatively it could result in the need to write down those assets to fair value. We will continue to monitor the impacts of COVID-19 on the fair value of assets. For further discussion, refer to Management’s Discussion and Analysis contained in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2020.

[0001104659-21-062898:mdna:5]
See the “Outlook” and “Part II – Other Information, Item 1A, Risk Factors” sections below for additional details.

[0001104659-21-062898:mdna:6]
[same as prior period, unchanged from 0001104659-21-016643:mdna:2]

[0001104659-21-062898:mdna:7]
References to the second quarters of 2021 and 2020 represent the three-month periods ended March 31, 2021 and 2020, respectively.

[0001104659-21-062898:mdna:8]
[same as prior period, unchanged from 0001104659-21-016643:mdna:7]

[0001104659-21-062898:mdna:9]
In the second quarter of 2021, sales, net earnings and diluted earnings per share were $166.6 million, $16.3 million and $0.62 per share, respectively, compared to $180.5 million, $17.8 million and $0.68 per share, respectively, in the second quarter of 2020. In the first six months of 2021, sales, net earnings and diluted earnings per share from continuing operations were $329.6 million, $30.0 million and $1.15 per share, respectively, compared to $352.2 million, $28.6 million and $1.09 per share, respectively, in the first six months of 2020.

[0001104659-21-062898:mdna:10]
[same as prior period, unchanged from 0001104659-21-016643:mdna:9]

[0001104659-21-062898:mdna:11]
In the second quarter of 2021, net sales of $166.6 million were $13.9 million, or 7.7%, lower than the $180.5 million in the second quarter of 2020. In the first six months of 2021, net sales of $329.6 million were $22.6 million, or 6.4%, lower than the $352.2 million in the first six months of 2020. The decrease in net sales in the second quarter of 2021 as compared to the second quarter of 2020 was due to an $11.8 million decrease in the Aerospace & Defense segment and a $4.2 million decrease in the USG segment, partially offset by a $2.2 million increase in the Test segment. The decrease in net sales in the first six months of 2021 as compared to the first six months of 2020 was due to a $22.4 million decrease in the Aerospace & Defense segment and a $2.5 million decrease in the USG segment, partially offset by a $2.3 million increase in the Test segment.

[0001104659-21-062898:mdna:12]
-Aerospace & Defense (A&D)

[0001104659-21-062898:mdna:13]
In the second quarter of 2021, net sales of $83.3 million were $11.8 million, or 12.4%, lower than the $95.1 million in the second quarter of 2020. In the first six months of 2021, net sales of $150.2 million were $22.4 million, or 13.0%, lower than the $172.6

[0001104659-21-062898:mdna:14]
million in the first six months of 2020. The sales decrease in the second quarter of 2021 compared to the second quarter of 2020 was mainly due to a $6.3 million decrease in net sales at Mayday, a $5.4 million decrease in net sales at Crissair, a $4.7 million decrease in net sales at PTI primarily driven by the impact of the COVID-19 pandemic, partially offset by a $3.9 million increase in sales at VACCO driven by navy defense. The sales decrease in the first six months of 2021 compared to the first six months of 2020 was mainly due to an $11.5 million decrease in net sales at Mayday, a $9.4 million decrease in net sales at Crissair, a $9.3 million decrease in net sales at PTI, and a $1.5 million decrease in net sales at Westland primarily driven by the impact of the COVID-19 pandemic, partially offset by a $7.8 million increase in net sales at VACCO and a $1.5 million increase in net sales at Globe.

[0001104659-21-062898:mdna:15]
-USG

[0001104659-21-062898:mdna:16]
In the second quarter of 2021, net sales of $39.6 million were $4.2 million, or 9.6%, lower than the $43.8 million in the second quarter of 2020. In the first six months of 2021, net sales of $94.1 million were $2.5 million, or 2.6%, lower than the $96.6 million in the first six months of 2020. The decrease in the second quarter and first six months of 2021 compared to the corresponding periods of 2020 was mainly due to lower product and service revenue at Doble primarily driven by the impact of COVID-19, partially offset by an increase in product sales at NRG.

[0001104659-21-062898:mdna:17]
-Test

[0001104659-21-062898:mdna:18]
In the second quarter of 2021, net sales of $43.8 million were $2.2 million, or 5.3%, higher than the $41.6 million in the second quarter of 2020. In the first six months of 2021, net sales of $85.3 million were $2.3 million, or 2.8%, higher than the $83.0 million in the first six months of 2020. The increase in the second quarter of 2021 as compared to the second quarter of 2020 was primarily due to higher sales from the Company’s Asian and European operations totaling $4.1 million partially offset by a $1.9 million decrease in sales from the segment’s U.S. operations due to the timing of test and measurement chamber projects. The increase in the first six months of 2021 compared to the first six months of 2020 was due to higher sales from the Company’s Asian and European operations totaling $7.7 million partially offset by a $5.4 million decrease in sales from the segment’s U.S. operations due to the timing of test and measurement chamber projects.

[0001104659-21-062898:mdna:19]
[same as prior period, unchanged from 0001104659-21-016643:mdna:17]

[0001104659-21-062898:mdna:20]
Backlog was $521.7 million at March 31, 2021 compared with $517.4 million at September 30, 2020. The Company received new orders totaling $176.2 million in the second quarter of 2021 compared to $245.6 million in the second quarter of 2020. Of the new orders received in the second quarter of 2021, $88.2 million related to Aerospace & Defense products, $44.4 million related to Test products, and $43.6 million related to USG products. Of the new orders received in the second quarter of 2020, $156.0 million related to Aerospace & Defense products, $41.8 million related to Test products, and $47.8 million related to USG products.

[0001104659-21-062898:mdna:21]
The Company received new orders totaling $333.9 million in the first six months of 2021 compared to $466.1 million in the first six months of 2020. Of the new orders received in the first six months of 2021, $153.6 million related to Aerospace & Defense products, $87.9 million related to Test products, and $92.4 million related to USG products. Of the new orders received in the first six months of 2020, $285.0 million related to Aerospace & Defense products, $80.3 million related to Test products, and $100.8 million related to USG products.

[0001104659-21-062898:mdna:22]
[same as prior period, unchanged from 0001104659-21-016643:mdna:19]

[0001104659-21-062898:mdna:23]
Selling, general and administrative (SG&A) expenses for the second quarter of 2021 were $38.7 million (23.2% of net sales), compared with $40.0 million (22.2% of net sales) for the second quarter of 2020. For the first six months of 2021, SG&A expenses from continuing operations were $79.7 million (24.2% of net sales) compared to $82.1 million (23.3% of net sales) for the first six months of 2020. The decrease in SG&A in the second quarter and first six months of 2021 compared to the corresponding periods of 2020 was mainly due to lower discretionary spending related to travel and other discretionary expenses due to the COVID-19 pandemic.

[0001104659-21-062898:mdna:24]
[same as prior period, unchanged from 0001104659-21-016643:mdna:21]

[0001104659-21-062898:mdna:25]
Amortization of intangible assets from continuing operations was $4.9 million and $9.9 million for the second quarter and first six months of 2021, respectively, compared to $5.2 million and $11.0 million for the corresponding periods of 2020. Amortization expenses consist of amortization of acquired intangible assets from acquisitions and other identifiable intangible assets (primarily

[0001104659-21-062898:mdna:26]
software). The decrease in amortization expense in the second quarter and first six months of 2021 compared to the corresponding periods of 2020 was mainly due to a decrease in amortization of capitalized software.

[0001104659-21-062898:mdna:27]
OTHER (INCOME) EXPENSES, NET

[0001104659-21-062898:mdna:28]
Other (income) expenses, net, was $(1.9) million of income in the second quarter of 2021 compared to other expenses, net, of $0.7 million in the second quarter of 2020. The principal component of other income, net, in the second quarter of 2021 was a gain of approximately $2 million for the final settlement on the sale of the Doble Watertown, MA building, partially offset by facility consolidation charges for the Doble Manta facility.  There were no individually significant items in other (income) expenses, net, in the second quarter of 2020.

[0001104659-21-062898:mdna:29]
Other (income) expenses, net, was $(1.9) million of income in the first six months of 2021 compared to other expenses, net, of $1.0 million in the first six months of 2020. The principal component of other (income), expenses, net, in the first six months of 2021 was a gain of approximately $2 million for the final settlement on the sale of the Doble Watertown, MA building, partially offset by facility consolidation charges for the Doble Manta facility. The principal component of other expenses, net, in the first six months of 2020 were losses on derivative instruments of $0.8 million.

[0001104659-21-062898:mdna:30]
[same as prior period, unchanged from 0001104659-21-016643:mdna:25]

[0001104659-21-062898:mdna:31]
The Company evaluates the performance of its operating segments based on EBIT, and provides EBIT on a consolidated basis, which is a non-GAAP financial measure. Please refer to the discussion of non-GAAP financial measures in Note 6 to the Consolidated Financial Statements, above. EBIT was $21.8 million (13.1% of net sales) for the second quarter of 2021 compared to $21.3 million (11.8% of net sales) for the second quarter of 2020. For the first six months of 2021, EBIT was $40.0 million (12.1% of net sales) compared to $38.1 million (10.8% of net sales) for the first six months of 2020.

[0001104659-21-062898:mdna:32]
[same as prior period, unchanged from 0001104659-21-016643:mdna:27]

[0001104659-21-062898:mdna:33]
| ​ | ​ | Three Months Ended | ​ | Six Months Ended |
| ​ | ​ | March 31, | ​ | March 31, |
| (In thousands) |  | 2021 | ​ | 2020 | ​ | 2021 |  | 2020 |
| Consolidated EBIT | ​ | $ | 21,771 | ​ | ​ | 21,345 | ​ | 39,972 | ​ | 38,136 |
| Less: Interest expense, net | ​ |  | (432) |  | ​ | (1,320) |  | (973) |  | (3,741) |
| Less: Income tax | ​ |  | (5,025) |  |  | (2,203) |  | (8,999) |  | (5,809) |
| Net earnings from continuing operations | ​ | $ | 16,314 |  | ​ | 17,822 |  | 30,000 |  | 28,586 |

[0001104659-21-062898:mdna:34]
-Aerospace & Defense

[0001104659-21-062898:mdna:35]
EBIT in the second quarter of 2021 was $18.2 million (21.8% of net sales) compared to $21.7 million (22.8% of net sales) in the second quarter of 2020. EBIT in the first six months of 2021 was $27.6 million (18.4% of net sales) compared to $34.2 million (19.8% of net sales) in the first six months of 2020. The decrease in EBIT in the second quarter and first six months of 2021 compared to the corresponding periods of 2020 was mainly due to lower sales volumes at Mayday, Crissair and PTI partially offset by an increase in EBIT at VACCO and Globe due to the higher sales volumes as mentioned above.  In addition, EBIT in the first quarter of 2021 was negatively impacted by a $0.3 million inventory step-up charge related to the ATM acquisition.

[0001104659-21-062898:mdna:36]
-USG

[0001104659-21-062898:mdna:37]
EBIT in the second quarter of 2021 was $6.7 million (17.0% of net sales) compared to $4.9 million (11.1% of net sales) in the second quarter of 2020. EBIT in the first six months of 2021 was $19.5 million (20.7% of net sales) compared to $14.2 million (14.7% of net sales) in the first six months of 2020. The increase in EBIT in the second quarter of 2021 compared to the second quarter of 2020 was mainly due to the final settlement received on the sale of the Doble Watertown facility of approximately $2 million partially offset by $0.7 million of facility consolidation charges at its Doble Manta facility, and an increase in EBIT at NRG due to higher sales volumes as mentioned above.  The increase in EBIT in the first six months of 2021 compared to the first six months of 2020 was mainly due to higher EBIT at Doble driven by favorable product mix, $2 million final settlement received on the sale of the Doble Watertown facility, partially offset by $1.3 million of facility consolidation charges at its Doble Manta facility, and an increase in EBIT at NRG due to higher sales volumes.

[0001104659-21-062898:mdna:38]
-Test

[0001104659-21-062898:mdna:39]
EBIT in the second quarter of 2021 was $5.7 million (13.0% of net sales) compared to $5.7 million (13.6% of net sales) in the second quarter of 2020. EBIT in the first six months of 2021 was $11.0 million (12.9% of net sales) compared to $10.3 million (12.4% of net sales) in the first six months of 2020. The increase in EBIT in the first six months of 2021 compared to the first six months of 2020 was primarily due to product mix and higher margins on projects mainly from the segment’s Asian operations.

[0001104659-21-062898:mdna:40]
-Corporate

[0001104659-21-062898:mdna:41]
Corporate costs included in EBIT were $8.8 million and $18.1 million in the second quarter and first six months of 2021, respectively, compared to $10.9 million and $20.6 million in the corresponding periods of 2020. The decrease in Corporate costs in the second quarter and first six months of 2021 compared to the corresponding periods of 2020 was mainly due to the decrease in pension expense as a result of the defined benefit pension plan termination in the fourth quarter of 2020 and losses on derivative instruments of $0.8 million recorded in the first six months of 2020.

[0001104659-21-062898:mdna:42]
[same as prior period, unchanged from 0001104659-21-016643:mdna:37]

[0001104659-21-062898:mdna:43]
Interest expense was $0.4 million and $1.0 million in the second quarter and first six months of 2021, respectively, and $1.3 million and $3.7 million in the corresponding periods of 2020. The decrease in interest expense in the second quarter and first six months of 2021 compared to the corresponding periods of 2020 was mainly due to lower average outstanding borrowings and lower average interest rates. Average outstanding borrowings were $23 million and $47 million in the second quarter and first six months of 2021, respectively, and $150 million and $215 million in the corresponding periods of 2020.

[0001104659-21-062898:mdna:44]
[same as prior period, unchanged from 0001104659-21-016643:mdna:39]

[0001104659-21-062898:mdna:45]
The second quarter 2021 effective income tax rate from continuing operations was 23.5% compared to 11.0% in the second quarter of 2020. The effective income tax rate in the first six months of 2021 was 23.1% compared to 16.9% for the first six months of 2020. Income tax expense in the second quarter of 2021 was unfavorably impacted by return to provision true-ups increasing the second quarter and year-to-date effective tax rate by 0.6% and 0.3%, respectively. Income tax expense in the second quarter of 2020 was favorably impacted by the release of a valuation allowance of $2.8 million for foreign net operating losses decreasing the second quarter 2020 and year-to-date effective tax rate by 14.3% and 8.2%, respectively.

[0001104659-21-062898:mdna:46]
[same as prior period, unchanged from 0001104659-21-016643:mdna:41]

[0001104659-21-062898:mdna:47]
The Company’s overall financial position and liquidity remains strong. The effects of COVID-19 have not materially affected liquidity. Working capital from continuing operations (current assets less current liabilities) decreased to $181.5 million at March 31, 2021 from $190.6 million at September 30, 2020. Accounts receivable decreased by $19.5 million during this period due to a $12.5 million decrease within the Test segment, a $5.7 million decrease within the Aerospace & Defense segment and a $1.3 million decrease within the USG segment; due to increased focus on collections during the period and timing of payments.   Inventories increased by $9.2 million during this period due to a $3.2 million increase within the Aerospace & Defense segment, a $3.3 million increase within the Test segment and a $2.7 million increase within the USG segment; resulting primarily from the timing of receipt of raw materials to meet anticipated demand and timing of manufacturing existing orders.

[0001104659-21-062898:mdna:48]
Net cash provided by operating activities from continuing operations was $57.3 million and $36.7 million in the first six months of 2021 and 2020, respectively. The increase in net cash provided by operating activities from continuing operations in the first six months of 2021 as compared to the first six months of 2020 was mainly driven by lower working capital requirements.

[0001104659-21-062898:mdna:49]
Capital expenditures from continuing operations were $13.2 million and $21.2 million in the first six months of 2021 and 2020, respectively. The decrease in the first six months of 2021 compared to the prior year period was mainly due to the building improvement additions in 2020 at the new Doble headquarters facility of approximately $7 million. In addition, the Company incurred expenditures for capitalized software of $4.0 million and $4.3 million in the first six months of 2021 and 2020, respectively.

[0001104659-21-062898:mdna:50]
Credit Facility

[0001104659-21-062898:mdna:51]
At March 31, 2021, the Company had approximately $468 million available to borrow under its bank credit facility, a $250 million increase option subject to lender approval, and $45.7 million cash on hand. At March 31, 2021, the Company had $22 million of

[0001104659-21-062898:mdna:52]
outstanding borrowings under the credit facility in addition to outstanding letters of credit of $10.4 million. Cash flow from operations and borrowings under the Company’s credit facility are expected to meet the Company’s capital requirements and operational needs for the foreseeable future. The Company’s ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.

[0001104659-21-062898:mdna:53]
[same as prior period, unchanged from 0001104659-21-016643:mdna:49]

[0001104659-21-062898:mdna:54]
A dividend of $0.08 per share, totaling $2.1 million, was paid on October 15, 2020 to stockholders of record as of October 1, 2020. A dividend of $0.08 per share, totaling $2.1 million, was paid on January 19, 2021 to stockholders of record as of January 4, 2021. Subsequent to March 31, 2021, a quarterly dividend of $0.08 per share, totaling $2.1 million, was paid on April 16, 2021 to stockholders of record as of April 1, 2021.

[0001104659-21-062898:mdna:55]
[same as prior period, unchanged from 0001104659-21-016643:mdna:51]

[0001104659-21-062898:mdna:56]
Management’s current expectations for 2021 remain consistent with the details outlined in the Business Outlook section presented in the November 19, 2020 press release. In mid-year 2020, business disruptions related to the COVID-19 pandemic began to affect the Company’s operations and continued throughout the balance of the year. During 2021, the commercial aerospace and utility end-markets have seen some degree of customer stabilization, as well as notable pockets of recovery; however there is still uncertainty as to the timing and pace of the recovery in these areas. The wide distribution of viable COVID-19 vaccines is anticipated to benefit and accelerate the recovery of commercial air travel and utility spending with customers resuming normal testing protocols and equipment purchases, but Management has determined that it is advisable to wait before resuming specific guidance. Given this uncertainty, it is difficult to predict how the balance of 2021 will be affected using normal forecasting methodologies; therefore, the Company will continue its suspension of forward-looking guidance.

[0001104659-21-062898:mdna:57]
To assist shareholders and analysts, Management will continue offering “directional” guidance for 2021, by stating that the Company is seeing tangible signs of recovery in the second half of fiscal 2021 that point to a solid outlook for the back half of the year. The outlook for the second half of 2021 is expected to compare favorably to the second half of 2020 given the anticipated elements of COVID-19 recovery. Management’s current expectations for 2021 show growth in Sales, Adjusted EBITDA, and Adjusted EPS compared to 2020, with Adjusted EBITDA and Adjusted EPS reasonably consistent with 2019.

[0001104659-21-062898:mdna:58]
[same as prior period, unchanged from 0001104659-21-016643:mdna:54]

[0001104659-21-062898:mdna:59]
Management has evaluated the accounting policies used in the preparation of the Company’s financial statements and related notes and believes those policies to be reasonable and appropriate. Certain of these accounting policies require the application of significant judgment by Management in selecting appropriate assumptions for calculating financial estimates. By their nature, these judgments are subject to an inherent degree of uncertainty. These judgments are based on historical experience, trends in the industry, information provided by customers and information available from other outside sources, as appropriate. The most significant areas involving Management judgments and estimates may be found in the Critical Accounting Policies section of Management’s Discussion and Analysis and in Note 1 to the Consolidated Financial Statements contained in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2020.

[0001104659-21-062898:mdna:60]
[same as prior period, unchanged from 0001104659-21-016643:mdna:57]

[0001104659-21-062898:mdna:61]
Contingencies

[0001104659-21-062898:mdna:62]
As a normal incident of the business in which the Company is engaged, various claims, charges and litigation are asserted or commenced against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. In the opinion of Management, the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company, are adequately reserved, are covered by insurance, or would not have a material adverse effect on the Company’s results from operations, capital expenditures, or competitive position.

[0001104659-21-062898:mdna:63]
[same as prior period, unchanged from 0001104659-21-016643:mdna:60]

[0001104659-21-062898:mdna:64]
securities laws. These include, but are not necessarily limited to, statements about: the second quarter results, growth in Sales, Adjusted EBITDA, Adjusted EPS; the effects of a widely available COVID-19 vaccine; the continuing effects of the COVID-19 pandemic including any impairment of the Company’s assets, impacts to commercial aerospace, military and navy markets which the Company serves, the strength of the markets served by the Company’s Test and USG segments, and the timing of the recovery of certain end markets which the Company serves; the adequacy of the Company’s credit facility and the Company’s ability to increase it; the outcome of current litigation, claims and charges; cash flow; timing of the repayment of the current portion of the Company’s long-term debt; future revenues from remaining performance obligations; fair values of reporting units; the Company’s ability to hedge against or otherwise manage market risks through the use of derivative financial instruments; the extent to which hedging gains or losses will be offset by losses or gains on related underlying exposures; and any other statements contained herein which are not strictly historical. Words such as expects, anticipates, targets, goals, projects, intends, plans, believes, estimates, variations of such words, and similar expressions are intended to identify such forward-looking statements.

[0001104659-21-062898:mdna:65]
Investors are cautioned that such statements are only predictions and speak only as of the date of this Form 10-Q, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment, including but not limited to those described in Item 1A, “Risk Factors,” of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2020 and in this Quarterly Report on Form 10-Q, and the following: the success and timing of available COVID-19 vaccines in ending the pandemic; the continuing impact of the COVID-19 pandemic including labor shortages, facility closures, shelter in place policies or quarantines, material shortages, transportation delays, termination or delays of Company contracts and the inability of our suppliers or customers to perform, the impacts of natural disasters on the Company’s operations and those of the Company’s customers and suppliers; the timing and content of future contract awards or customer orders; the appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer contracts or orders; weakening of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties; the availability of selected acquisitions; delivery delays or defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability of certain raw materials; labor disputes; changes in U.S. tax laws and regulations; other changes in laws and regulations including but not limited to changes in accounting standards and foreign taxation; changes in interest rates; costs relating to environmental matters arising from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the integration of recently acquired businesses.
