# ESE notes — 0001104659-21-062898


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001104659-21-062898:notes:1]
[same as prior period, unchanged from 0001104659-21-016643:notes:1]

[0001104659-21-062898:notes:2]
[same as prior period, unchanged from 0001104659-21-016643:notes:2]

[0001104659-21-062898:notes:3]
The Company’s results for the three-month period ended March 31, 2021 are not necessarily indicative of the results for the entire 2021 fiscal year. References to the second quarters of 2021 and 2020 represent the fiscal quarters ended March 31, 2021 and 2020, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:EarningsPerShareTextBlock

[0001104659-21-062898:notes:4]
[same as prior period, unchanged from 0001104659-21-016643:notes:4]

[0001104659-21-062898:notes:5]
[same as prior period, unchanged from 0001104659-21-016643:notes:5]

[0001104659-21-062898:notes:6]
| ​ |  | Three Months | ​ | Six Months |
| ​ | ​ | Ended March 31, | ​ | Ended March 31, |
| ​ | ​ | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Weighted Average Shares Outstanding — Basic |  | 26,038 |  | 25,988 |  | 26,038 |  | 25,985 |
| Dilutive Options and Restricted Shares | ​ | 163 | ​ | 100 | ​ | 154 | ​ | 141 |
| Adjusted Shares — Diluted |  | 26,201 |  | 26,088 |  | 26,192 |  | 26,126 |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001104659-21-062898:notes:7]
[same as prior period, unchanged from 0001104659-21-016643:notes:7]

[0001104659-21-062898:notes:8]
[same as prior period, unchanged from 0001104659-21-016643:notes:8]

[0001104659-21-062898:notes:9]
[same as prior period, unchanged from 0001104659-21-016643:notes:9]

[0001104659-21-062898:notes:10]
Compensation expense related to the restricted share awards was $1.1 million and $2.1 million for the three and six-month periods ended March 31, 2021, respectively, and $1.1 million and $2.3 million for the corresponding periods in 2020. There were 220,430 non-vested shares outstanding as of March 31, 2021.

[0001104659-21-062898:notes:11]
[same as prior period, unchanged from 0001104659-21-016643:notes:11]

[0001104659-21-062898:notes:12]
Compensation expense related to the non-employee director grants was $0.3 million and $0.6 million for the three and six-month periods ended March 31, 2021, respectively, and $0.3 million and $0.6 million for the corresponding periods in 2020.

[0001104659-21-062898:notes:13]
The total share-based compensation cost that has been recognized in the results of operations and included within selling, general and administrative expenses (SG&A) was $1.4 million and $2.7 million for the three and six-month periods ended March 31, 2021, respectively, and $1.5 million and $2.9 million for the corresponding periods in 2020. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $0.3 million and $0.7 million for the three and six-month periods ended March 31, 2021, respectively, and $0.3 million and $0.7 million for the corresponding periods in

[0001104659-21-062898:notes:14]
2020. As of March 31, 2021, there was $6.1 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a remaining weighted-average period of 1.5 years.


## us-gaap:InventoryDisclosureTextBlock

[0001104659-21-062898:notes:15]
[same as prior period, unchanged from 0001104659-21-016643:notes:14]

[0001104659-21-062898:notes:16]
[same as prior period, unchanged from 0001104659-21-016643:notes:15]

[0001104659-21-062898:notes:17]
| ​ |  | March 31, |  | September 30, |
| (In thousands) |  | 2021 |  | 2020 |
| Finished goods | ​ | $ | 29,363 |  | 28,471 |
| Work in process | ​ |  | 37,905 |  | 30,183 |
| Raw materials | ​ |  | 78,074 |  | 77,535 |
| Total inventories | ​ | $ | 145,342 |  | 136,189 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001104659-21-062898:notes:18]
[same as prior period, unchanged from 0001104659-21-016643:notes:17]

[0001104659-21-062898:notes:19]
Included on the Company’s Consolidated Balance Sheets at March 31, 2021 and September 30, 2020 are the following intangible assets gross carrying amounts and accumulated amortization from continuing operations:

[0001104659-21-062898:notes:20]
| ​ |  | March 31, |  | September 30, |
| (Dollars in thousands) |  | 2021 |  | 2020 |
| Goodwill | ​ | $ | 411,661 |  | 408,063 |
| Intangible assets with determinable lives: | ​ |  | ​ | ​ | ​ |
| Patents | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 2,136 | ​ | 2,092 |
| Less: accumulated amortization | ​ |  | 915 | ​ | 858 |
| Net | ​ | $ | 1,221 | ​ | 1,234 |
| Capitalized software | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 88,862 | ​ | 84,888 |
| Less: accumulated amortization | ​ |  | 60,563 | ​ | 57,302 |
| Net | ​ | $ | 28,299 | ​ | 27,586 |
| Customer relationships | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 229,322 | ​ | 227,178 |
| Less: accumulated amortization | ​ |  | 73,864 | ​ | 67,643 |
| Net | ​ | $ | 155,458 | ​ | 159,535 |
| Other | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 5,356 | ​ | 5,156 |
| Less: accumulated amortization | ​ |  | 3,586 | ​ | 3,260 |
| Net | ​ | $ | 1,770 | ​ | 1,896 |
| Intangible assets with indefinite lives: | ​ |  | ​ | ​ | ​ |
| Trade names | ​ | $ | 158,513 | ​ | 156,381 |

[0001104659-21-062898:notes:21]
The changes in the carrying amount of goodwill attributable to each business segment for the six months ended March 31, 2021 is as follows on a continuing operations basis:

[0001104659-21-062898:notes:22]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | Aerospace | ​ | ​ |
| (Dollars in millions) |  | USG |  | Test |  | & Defense |  | Total |
| Balance as of September 30, 2020 | ​ | ​ | 271.9 |  | 34.1 |  | 102.1 |  | 408.1 |
| Acquisition activity | ​ | ​ | — | ​ | — | ​ | 2.5 | ​ | 2.5 |
| Foreign currency translation | ​ | ​ | 1.1 | ​ | — | ​ | — | ​ | 1.1 |
| Balance as of March 31, 2021 | ​ | $ | 273.0 | ​ | 34.1 | ​ | 104.6 | ​ | 411.7 |

[0001104659-21-062898:notes:23]
The economic uncertainty, changes in the propensity for the general public to travel by air, and reductions in demand for commercial aircraft as a result of the COVID-19 pandemic have adversely impacted net sales and operating results in certain of the Aerospace and Defense reporting units. There were no impairment charges incurred for the three and six-month periods ended March 31, 2021, however, the fair value of the Mayday reporting unit exceeded carrying value by less than 10%. At March 31, 2021, we had $30 million of goodwill recorded for Mayday.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001104659-21-062898:notes:24]
[same as prior period, unchanged from 0001104659-21-016643:notes:24]

[0001104659-21-062898:notes:25]
The Company is organized based on the products and services that it offers and classifies its continuing business operations in three reportable segments for financial reporting purposes: Aerospace & Defense, Utility Solutions Group (USG), and RF Shielding and Test (Test). The Aerospace & Defense segment’s operations consist of PTI Technologies Inc. (PTI), VACCO Industries (VACCO), Crissair, Inc. (Crissair), Westland Technologies Inc. (Westland), Mayday Manufacturing Co. and its affiliate Hi-Tech Metals, Inc. (collectively referred to as Mayday) and Globe Composite Solutions, LLC (Globe). The companies within this segment primarily design and manufacture specialty filtration, fluid control and naval products, including hydraulic filter elements and fluid control devices used in aerospace and defense applications; unique filter mechanisms used in micro-propulsion devices for satellites and custom designed filters for manned aircraft and submarines; products and systems to reduce vibration and/or acoustic signatures and otherwise reduce or obscure a vessel’s signature, and other communications, sealing, surface control and hydrodynamic related applications to enhance U.S. Navy maritime survivability; precision-tolerance machined components for the aerospace and defense industry; and metal processing services. The USG segment’s operations consist primarily of Doble Engineering Company and Morgan Schaffer Ltd. (together Doble), and NRG Systems, Inc. (NRG). Doble is an industry leader in the development, manufacture and delivery of diagnostic testing solutions that enable electric power grid operators to assess the integrity of high voltage power delivery equipment. NRG designs and manufactures decision support tools for the renewable energy industry, primarily wind and solar. The Test segment’s operations consist primarily of ETS-Lindgren Inc. (ETS-Lindgren). ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy. ETS-Lindgren also manufactures radio frequency shielding products and components used by manufacturers of medical equipment, communications systems, electronic products, and shielded rooms for high-security data processing and secure communication.

[0001104659-21-062898:notes:26]
[same as prior period, unchanged from 0001104659-21-016643:notes:26]

[0001104659-21-062898:notes:27]
| ​ | ​ | Three Months | ​ | Six Months |
| ​ | ​ | Ended March 31, | ​ | Ended March 31, |
| (In thousands) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| NET SALES | ​ | ​ |  | ​ |  | ​ |  | ​ |  |
| Aerospace & Defense | ​ | $ | 83,278 | ​ | 95,124 | ​ | 150,169 | ​ | 172,635 |
| USG | ​ | ​ | 39,555 | ​ | 43,768 | ​ | 94,095 | ​ | 96,602 |
| Test | ​ | ​ | 43,811 | ​ | 41,600 | ​ | 85,329 | ​ | 82,983 |
| Consolidated totals | ​ | $ | 166,644 | ​ | 180,492 | ​ | 329,593 | ​ | 352,220 |
| EBIT | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Aerospace & Defense | ​ | $ | 18,196 | ​ | 21,736 | ​ | 27,576 | ​ | 34,249 |
| USG | ​ | ​ | 6,725 | ​ | 4,866 | ​ | 19,456 | ​ | 14,153 |
| Test | ​ | ​ | 5,688 | ​ | 5,651 | ​ | 11,030 | ​ | 10,307 |
| Corporate (loss) | ​ | ​ | (8,838) | ​ | (10,908) | ​ | (18,090) | ​ | (20,573) |
| Consolidated EBIT | ​ | ​ | 21,771 | ​ | 21,345 | ​ | 39,972 | ​ | 38,136 |
| Less: Interest expense | ​ | ​ | (432) | ​ | (1,320) | ​ | (973) | ​ | (3,741) |
| Earnings before income taxes | ​ | $ | 21,339 | ​ | 20,025 | ​ | 38,999 | ​ | 34,395 |

[0001104659-21-062898:notes:28]
[same as prior period, unchanged from 0001104659-21-016643:notes:28]

[0001104659-21-062898:notes:29]
The financial measure “EBIT” is presented in the above table and elsewhere in this Report. EBIT on a consolidated basis is a non-GAAP financial measure. Management believes that EBIT is useful in assessing the operational profitability of the Company’s business segments because it excludes interest and taxes, which are generally accounted for across the entire Company on a consolidated basis. EBIT is also one of the measures used by management in determining resource allocations within the

[0001104659-21-062898:notes:30]
Company as well as incentive compensation. A reconciliation of EBIT to net earnings from continuing operations is set forth in Item 2, Management’s Discussion and Analysis of Financial Condition and Results of Operations – EBIT.

[0001104659-21-062898:notes:31]
[same as prior period, unchanged from 0001104659-21-016643:notes:30]


## us-gaap:DebtDisclosureTextBlock

[0001104659-21-062898:notes:32]
7.    DEBT

[0001104659-21-062898:notes:33]
The Company’s debt is summarized as follows:

[0001104659-21-062898:notes:34]
| ​ |  | March 31, | ​ | September 30, |
| (In thousands) |  | 2021 |  | 2020 |
| Total borrowings | ​ | $ | 22,000 |  | 62,368 |
| Current portion of long-term debt and short-term borrowings | ​ |  | (20,000) |  | (22,368) |
| Total long-term debt, less current portion | ​ | $ | 2,000 |  | 40,000 |

[0001104659-21-062898:notes:35]
The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024.

[0001104659-21-062898:notes:36]
At March 31, 2021, the Company had approximately $468 million available to borrow under the Credit Facility, plus the $250 million increase option, subject to lender approval, in addition to $45.7 million cash on hand. The Company classified $20.0 million as the current portion of long-term debt as of March 31, 2021, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $10.4 million at March 31, 2021.

[0001104659-21-062898:notes:37]
Interest on borrowings under the Credit Facility is calculated at a spread over either the London Interbank Offered Rate (LIBOR), the New York Federal Reserve Bank Rate or the prime rate, depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The Credit Facility is secured by the unlimited guaranty of the Company’s direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of its direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 1.27% and 1.40% for the three and six- month periods ending March 31, 2021, respectively, and 3.24% and 3.21% for the three and six-month periods ending March 31, 2020. As of March 31, 2021, the Company was in compliance with all covenants.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001104659-21-062898:notes:38]
[same as prior period, unchanged from 0001104659-21-016643:notes:37]

[0001104659-21-062898:notes:39]
The second quarter 2021 effective income tax rate from continuing operations was 23.5% compared to 11.0% in the second quarter of 2020. The effective income tax rate in the first six months of 2021 was 23.1% compared to 16.9% for the first six months of 2020. Income tax expense in the second quarter of 2021 was unfavorably impacted by a change in our estimate of the fiscal 2020 research credit increasing the second quarter and year-to-date effective tax rate by 0.6% and 0.3%, respectively. Income tax expense in the second quarter of 2020 was favorably impacted by the release of a valuation allowance of $2.8 million for foreign net operating losses decreasing the second quarter 2020 and year-to-date effective tax rate by 14.3% and 8.2%, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001104659-21-062898:notes:40]
[same as prior period, unchanged from 0001104659-21-016643:notes:39]

[0001104659-21-062898:notes:41]
The change in shareholders’ equity for the first three and six  months of 2020 and 2019 is shown below (in thousands):

[0001104659-21-062898:notes:42]
| ​ | ​ | Three Months Ended March 31, | ​ | Six Months Ended March 31, |
| ​ |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Common stock | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 306 | ​ | 306 | ​ | 306 | ​ | 306 |
| Stock plans | ​ | — | ​ | — | ​ | — | ​ | — |
| Ending balance | ​ | 306 | ​ | 306 | ​ | 306 | ​ | 306 |
| Additional paid-in-capital | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 294,735 | ​ | 293,056 | ​ | 293,682 | ​ | 292,408 |
| Stock plans | ​ | 1,061 | ​ | 1,731 | ​ | 2,114 | ​ | 2,379 |
| Ending balance | ​ | 295,796 | ​ | 294,787 | ​ | 295,796 | ​ | 294,787 |
| Retained earnings | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 790,000 | ​ | 769,439 | ​ | 778,398 | ​ | 684,741 |
| Net earnings common stockholders | ​ | 16,314 | ​ | 17,822 | ​ | 30,000 | ​ | 104,599 |
| Dividends paid | ​ | (2,083) | ​ | (2,077) | ​ | (4,167) | ​ | (4,156) |
| Ending balance | ​ | 804,231 | ​ | 785,184 | ​ | 804,231 | ​ | 785,184 |
| Accumulated other comprehensive income (loss) | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | 1,692 | ​ | (40,051) | ​ | (3,657) | ​ | (43,974) |
| Foreign currency translation | ​ | 116 | ​ | (6,885) | ​ | 5,465 | ​ | (2,962) |
| Ending balance | ​ | 1,808 | ​ | (46,936) | ​ | 1,808 | ​ | (46,936) |
| Treasury stock | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | (107,134) | ​ | (107,259) | ​ | (107,134) | ​ | (107,259) |
| Issued under stock plans | ​ | — | ​ | 125 | ​ | — | ​ | 125 |
| Ending balance | ​ | (107,134) | ​ | (107,134) | ​ | (107,134) | ​ | (107,134) |
| Total equity | ​ | 995,007 | ​ | 926,207 | ​ | 995,007 | ​ | 926,207 |


## us-gaap:FairValueDisclosuresTextBlock

[0001104659-21-062898:notes:43]
10.  FAIR VALUE MEASUREMENTS

[0001104659-21-062898:notes:44]
[same as prior period, unchanged from 0001104659-21-016643:notes:48]

[0001104659-21-062898:notes:45]
[same as prior period, unchanged from 0001104659-21-016643:notes:49]

[0001104659-21-062898:notes:46]
[same as prior period, unchanged from 0001104659-21-016643:notes:50]

[0001104659-21-062898:notes:47]
[same as prior period, unchanged from 0001104659-21-016643:notes:51]

[0001104659-21-062898:notes:48]
[same as prior period, unchanged from 0001104659-21-016643:notes:52]

[0001104659-21-062898:notes:49]
The Company has estimated the fair value of its financial instruments as of March 31, 2021 and September 30, 2020 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, debt and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001104659-21-062898:notes:50]
[same as prior period, unchanged from 0001104659-21-016643:notes:54]

[0001104659-21-062898:notes:51]
The Company’s forward contracts and interest rate swaps are classified within Level 2 of the valuation hierarchy in accordance with FASB Accounting Standards Codification (ASC) 825, as presented below as of March 31, 2021:

[0001104659-21-062898:notes:52]
| (In thousands) |  | Level 1 |  | Level 2 |  | ​ | Level 3 |  | Total |
| Assets (Liabilities): | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Forward contracts | ​ | $ | — |  | 141 |  | $ | — |  | 141 |

[0001104659-21-062898:notes:53]
[same as prior period, unchanged from 0001104659-21-016643:notes:57]

[0001104659-21-062898:notes:54]
[same as prior period, unchanged from 0001104659-21-016643:notes:58]

[0001104659-21-062898:notes:55]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during the three and six-month periods ended March 31, 2021.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001104659-21-062898:notes:56]
11.  REVENUES

[0001104659-21-062898:notes:57]
[same as prior period, unchanged from 0001104659-21-016643:notes:61]

[0001104659-21-062898:notes:58]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2021 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue within each reportable segment on a continuing operations basis.

[0001104659-21-062898:notes:59]
| Three months ended March 31, 2021 |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total | ​ |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 33,973 | ​ | $ | 38,549 | ​ | $ | 39,305 | ​ | $ | 111,827 | ​ |
| U.S. Government | ​ |  | 49,305 | ​ | ​ | 1,006 | ​ | ​ | 4,506 | ​ |  | 54,817 | ​ |
| Total revenues | ​ | $ | 83,278 | ​ | $ | 39,555 | ​ | $ | 43,811 | ​ | $ | 166,644 | ​ |
| Geographic location: | ​ |  |  | ​ | ​ |  | ​ | ​ |  | ​ |  |  | ​ |
| United States | ​ | $ | 73,037 | ​ | $ | 27,445 | ​ | $ | 22,965 | ​ | $ | 123,447 | ​ |
| International | ​ |  | 10,241 | ​ | ​ | 12,110 | ​ | ​ | 20,846 | ​ |  | 43,197 | ​ |
| Total revenues | ​ | $ | 83,278 | ​ | $ | 39,555 | ​ | $ | 43,811 | ​ | $ | 166,644 | ​ |
| Revenue recognition method: | ​ |  |  | ​ | ​ |  | ​ | ​ |  | ​ |  |  | ​ |
| Point in time | ​ | $ | 37,127 | ​ | $ | 27,563 | ​ | $ | 9,248 | ​ | $ | 73,938 | ​ |
| Over time | ​ |  | 46,151 | ​ | ​ | 11,992 | ​ | ​ | 34,563 | ​ |  | 92,706 | ​ |
| Total revenues | ​ | $ | 83,278 | ​ | $ | 39,555 | ​ | $ | 43,811 | ​ | $ | 166,644 | ​ |

[0001104659-21-062898:notes:60]
| Six months ended March 31, 2021 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |  |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 62,114 | ​ | $ | 92,414 | ​ | $ | 76,027 | ​ | $ | 230,555 | ​ |
| U.S. Government | ​ |  | 88,055 | ​ |  | 1,681 | ​ |  | 9,302 | ​ |  | 99,038 | ​ |
| Total revenues | ​ | $ | 150,169 | ​ | $ | 94,095 | ​ | $ | 85,329 | ​ | $ | 329,593 | ​ |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  |  | ​ |  |  | ​ |
| United States | ​ | $ | 130,849 | ​ | $ | 64,490 | ​ | $ | 46,231 | ​ | $ | 241,570 | ​ |
| International | ​ |  | 19,320 | ​ |  | 29,605 | ​ |  | 39,098 | ​ |  | 88,023 | ​ |
| Total revenues | ​ | $ | 150,169 | ​ | $ | 94,095 | ​ | $ | 85,329 | ​ | $ | 329,593 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  |  | ​ |  |  | ​ |
| Point in time | ​ | $ | 64,000 | ​ | $ | 69,931 | ​ | $ | 18,116 | ​ | $ | 152,047 | ​ |
| Over time | ​ |  | 86,169 | ​ |  | 24,164 | ​ |  | 67,213 | ​ |  | 177,546 | ​ |
| Total revenues | ​ | $ | 150,169 | ​ | $ | 94,095 | ​ | $ | 85,329 | ​ | $ | 329,593 | ​ |

[0001104659-21-062898:notes:61]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2020 are presented in the tables below.

[0001104659-21-062898:notes:62]
| Three months ended March 31, 2020 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 51,550 | ​ | $ | 43,736 | ​ | $ | 33,952 | ​ | $ | 129,238 |
| U.S. Government | ​ |  | 43,574 | ​ |  | 32 | ​ |  | 7,648 | ​ |  | 51,254 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 43,768 | ​ | $ | 41,600 | ​ | $ | 180,492 |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| United States | ​ | $ | 81,458 | ​ | $ | 28,706 | ​ | $ | 25,121 | ​ | $ | 135,285 |
| International | ​ |  | 13,666 | ​ |  | 15,062 | ​ |  | 16,479 | ​ |  | 45,207 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 43,768 | ​ | $ | 41,600 | ​ | $ | 180,492 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 46,610 | ​ | $ | 32,209 | ​ | $ | 8,009 | ​ | $ | 86,828 |
| Over time | ​ |  | 48,514 | ​ |  | 11,559 | ​ |  | 33,591 | ​ |  | 93,664 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 43,768 | ​ | $ | 41,600 | ​ | $ | 180,492 |

[0001104659-21-062898:notes:63]
| Six months ended March 31, 2020 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 93,417 | ​ | $ | 95,971 | ​ | $ | 69,194 | ​ | $ | 258,582 |
| U.S. Government | ​ |  | 79,218 | ​ |  | 631 | ​ |  | 13,789 | ​ |  | 93,638 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 96,602 | ​ | $ | 82,983 | ​ | $ | 352,220 |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| United States | ​ | $ | 146,164 | ​ | $ | 63,665 | ​ | $ | 49,959 | ​ | $ | 259,788 |
| International | ​ |  | 26,471 | ​ |  | 32,937 | ​ |  | 33,024 | ​ |  | 92,432 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 96,602 | ​ | $ | 82,983 | ​ | $ | 352,220 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 82,897 | ​ | $ | 72,524 | ​ | $ | 17,019 | ​ | $ | 172,440 |
| Over time | ​ |  | 89,738 | ​ |  | 24,078 | ​ |  | 65,964 | ​ |  | 179,780 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 96,602 | ​ | $ | 82,983 | ​ | $ | 352,220 |

[0001104659-21-062898:notes:64]
[same as prior period, unchanged from 0001104659-21-016643:notes:65]

[0001104659-21-062898:notes:65]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At March 31, 2021, the Company had $521.7 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 72% in the next twelve months.

[0001104659-21-062898:notes:66]
[same as prior period, unchanged from 0001104659-21-016643:notes:67]

[0001104659-21-062898:notes:67]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At March 31, 2021, contract assets and liabilities totaled $95.0 million and $106.6 million, respectively. Contract assets and liabilities are presented as current in the consolidated balance sheets as it is expected all related transaction activity with customers will be substantially completed within twelve months. During the first six months of 2021, the Company recognized approximately $56 million in revenues that were included in the contract liabilities balance at September 30, 2020.


## us-gaap:LeasesOfLesseeDisclosureTextBlock

[0001104659-21-062898:notes:68]
12.  LEASES

[0001104659-21-062898:notes:69]
[same as prior period, unchanged from 0001104659-21-016643:notes:70]

[0001104659-21-062898:notes:70]
[same as prior period, unchanged from 0001104659-21-016643:notes:71]

[0001104659-21-062898:notes:71]
In addition to the base rent, real estate leases typically contain provisions for common-area maintenance and other similar services, which are considered non-lease components for accounting purposes. Non-lease components are excluded from our ROU assets and lease liabilities and expensed as incurred.

[0001104659-21-062898:notes:72]
[same as prior period, unchanged from 0001104659-21-016643:notes:73]

[0001104659-21-062898:notes:73]
[same as prior period, unchanged from 0001104659-21-016643:notes:74]

[0001104659-21-062898:notes:74]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended |
| ​ | ​ | March 31, | ​ | March 31, |
| (Dollars in thousands) |  | 2021 |  | 2020 |
| Finance lease cost | ​ | ​ |  | ​ | ​ |  |
| Amortization of right-of-use assets | ​ | $ | 492 | ​ | $ | 622 |
| Interest on lease liabilities | ​ |  | 311 | ​ |  | 198 |
| Operating lease cost | ​ |  | 1,424 | ​ |  | 1,402 |
| Total lease costs | ​ | $ | 2,227 | ​ | $ | 2,222 |

[0001104659-21-062898:notes:75]
| ​ |  | Six Months |  | Six Months |
| ​ | ​ | Ended | ​ | Ended |
| ​ | ​ | March 31, | ​ | March 31, |
| (Dollars in thousands) |  | 2021 |  | 2020 |
| Finance lease cost | ​ | ​ | ​ | ​ | ​ | ​ |
| Amortization of right-of-use assets | ​ | $ | 985 | ​ | $ | 1,245 |
| Interest on lease liabilities | ​ |  | 623 | ​ |  | 335 |
| Operating lease cost | ​ |  | 2,877 | ​ |  | 2,750 |
| Total lease costs | ​ | $ | 4,485 | ​ | $ | 4,330 |

[0001104659-21-062898:notes:76]
[same as prior period, unchanged from 0001104659-21-016643:notes:76]

[0001104659-21-062898:notes:77]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended | ​ |
| ​ | ​ | March 31, | ​ | March 31, | ​ |
| (Dollars in thousands) |  | 2021 |  | 2020 | ​ |
| Cash paid for amounts included in the measurement of lease liabilities | ​ | ​ |  | ​ | ​ |  | ​ |
| Operating cash flows from operating leases | ​ | $ | 1,375 | ​ | $ | 1,380 | ​ |
| Operating cash flows from finance leases | ​ |  | 311 | ​ |  | 198 | ​ |
| Financing cash flows from finance leases | ​ |  | 419 | ​ |  | 377 | ​ |

[0001104659-21-062898:notes:78]
| ​ |  | Six Months |  | Six Months |
| ​ | ​ | March 31, | ​ | March 31, |
| (Dollars in thousands) |  | 2021 |  | 2020 |
| Cash paid for amounts included in the measurement of lease liabilities | ​ | ​ | ​ | ​ | ​ | ​ |
| Operating cash flows from operating leases | ​ | $ | 2,800 | ​ | $ | 2,717 |
| Operating cash flows from finance leases | ​ |  | 623 | ​ |  | 335 |
| Financing cash flows from finance leases | ​ |  | 838 | ​ |  | 753 |

[0001104659-21-062898:notes:79]
| Weighted-average remaining lease term |  | March 31, 2021 |  | March 31, 2020 |  |
| Operating leases |  | 5.76 years |  | 6.37 years | ​ |
| Finance leases |  | 12.2 years |  | 12.7 years | ​ |
| Weighted-average discount rate |  |  |  |  | ​ |
| Operating leases |  | 3.11 | % | 3.08 | % |
| Finance leases |  | 4.31 | % | 4.28 | % |

[0001104659-21-062898:notes:80]
The following is a reconciliation of future undiscounted cash flows to the operating and finance lease liabilities, and the related ROU assets, presented on our Consolidated Balance Sheet on March 31, 2021:

[0001104659-21-062898:notes:81]
| (Dollars in thousands) | ​ | Operating |  | Finance |
| Years Ending September 30: |  | Leases |  | Leases |
| 2021 (excluding the six months ended March 31, 2021) | ​ | $ | 2,732 |  | ​ | 1,473 |
| 2022 | ​ |  | 4,907 |  | ​ | 3,015 |
| 2023 | ​ |  | 3,984 |  | ​ | 3,098 |
| 2024 | ​ |  | 2,438 |  | ​ | 3,181 |
| 2025 and thereafter | ​ |  | 7,173 |  | ​ | 28,285 |
| Total minimum lease payments | ​ |  | 21,234 |  | ​ | 39,052 |
| Less: amounts representing interest | ​ |  | 1,894 |  |  | 9,625 |
| Present value of net minimum lease payments | ​ | $ | 19,340 |  | ​ | 29,427 |
| Less: current portion of lease obligations | ​ |  | 4,839 |  | ​ | 2,001 |
| Non-current portion of lease obligations | ​ | ​ | 14,501 |  | ​ | 27,426 |
| ROU assets | ​ | $ | 18,929 |  | ​ | 25,182 |

[0001104659-21-062898:notes:82]
Operating lease liabilities are included in the Consolidated Balance Sheet in accrued other expenses (current portion) and as a caption on the Consolidated Balance Sheet (long-term portion). Finance lease liabilities are included on the Consolidated Balance Sheet in accrued other expenses (current portion) and other liabilities (long-term portion). Operating lease ROU assets are included as a caption on the Consolidated Balance Sheet and finance lease ROU assets are included in Property, plant and equipment on the Consolidated Balance sheets.
