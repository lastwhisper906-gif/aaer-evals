# ESE note change history — 0001104659-21-016643 → 0001104659-21-062898


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-05-07):
[0001104659-21-062898:note_history:1]
The Company’s results for the three-month period ended March 31, 2021 are not necessarily indicative of the results for the entire 2021 fiscal year. References to the second quarters of 2021 and 2020 represent the fiscal quarters ended March 31, 2021 and 2020, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.
  (was, 2021-02-09, similarity 0.9616):
[0001104659-21-016643:note_history:1]
The Company’s results for the three-month period ended December 31, 2020 are not necessarily indicative of the results for the entire 2021 fiscal year. References to the first quarters of 2021 and 2020 represent the fiscal quarters ended December 31, 2020 and 2019, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-07):
[0001104659-21-062898:note_history:2]
| ​ |  | March 31, | ​ | September 30, |
| (In thousands) |  | 2021 |  | 2020 |
| Total borrowings | ​ | $ | 22,000 |  | 62,368 |
| Current portion of long-term debt and short-term borrowings | ​ |  | (20,000) |  | (22,368) |
| Total long-term debt, less current portion | ​ | $ | 2,000 |  | 40,000 |
  (was, 2021-02-09, similarity 0.9785):
[0001104659-21-016643:note_history:2]
| ​ |  | December 31, | ​ | September 30, |
| (In thousands) |  | 2020 |  | 2020 |
| Total borrowings | ​ | $ | 55,842 |  | 62,368 |
| Current portion of long-term debt and short-term borrowings | ​ |  | (21,842) |  | (22,368) |
| Total long-term debt, less current portion | ​ | $ | 34,000 |  | 40,000 |

- changed (2021-05-07):
[0001104659-21-062898:note_history:3]
The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024.
  (was, 2021-02-09, similarity 0.9988):
[0001104659-21-016643:note_history:3]
The Credit Facility includes a $500 million revolving line of credit, as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024.

- changed (2021-05-07):
[0001104659-21-062898:note_history:4]
At March 31, 2021, the Company had approximately $468 million available to borrow under the Credit Facility, plus the $250 million increase option, subject to lender approval, in addition to $45.7 million cash on hand. The Company classified $20.0 million as the current portion of long-term debt as of March 31, 2021, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $10.4 million at March 31, 2021.
  (was, 2021-02-09, similarity 0.9339):
[0001104659-21-016643:note_history:4]
At December 31, 2020, the Company had approximately $434 million available to borrow under the Credit Facility, plus the $250 million increase option, in addition to $57.4 million cash on hand. The Company classified $20.0 million as the current portion of long-term debt as of December 31, 2020, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $9.9 million at December 31, 2020.

- changed (2021-05-07):
[0001104659-21-062898:note_history:5]
Interest on borrowings under the Credit Facility is calculated at a spread over either the London Interbank Offered Rate (LIBOR), the New York Federal Reserve Bank Rate or the prime rate, depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The Credit Facility is secured by the unlimited guaranty of the Company’s direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of its direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 1.27% and 1.40% for the three and six- month periods ending March 31, 2021, respectively, and 3.24% and 3.21% for the three and six-month periods ending March 31, 2020. As of March 31, 2021, the Company was in compliance with all covenants.
  (was, 2021-02-09, similarity 0.9029):
[0001104659-21-016643:note_history:5]
Interest on borrowings under the Credit Facility is calculated at a spread over either the London Interbank Offered Rate (LIBOR ), the New York Federal Reserve Bank Rate or the prime rate, depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The Credit Facility is secured by the unlimited guaranty of the Company’s direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of its direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 1.45% and 3.18% for the three-month periods ending December 31, 2020 and 2019, respectively. As of December 31, 2020, the Company was in compliance with all covenants.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-07):
[0001104659-21-062898:note_history:6]
| ​ |  | March 31, | ​ | September 30, |
| (In thousands) |  | 2021 |  | 2020 |
| Total borrowings | ​ | $ | 22,000 |  | 62,368 |
| Current portion of long-term debt and short-term borrowings | ​ |  | (20,000) |  | (22,368) |
| Total long-term debt, less current portion | ​ | $ | 2,000 |  | 40,000 |
  (was, 2021-02-09, similarity 0.9785):
[0001104659-21-016643:note_history:6]
| ​ |  | December 31, | ​ | September 30, |
| (In thousands) |  | 2020 |  | 2020 |
| Total borrowings | ​ | $ | 55,842 |  | 62,368 |
| Current portion of long-term debt and short-term borrowings | ​ |  | (21,842) |  | (22,368) |
| Total long-term debt, less current portion | ​ | $ | 34,000 |  | 40,000 |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-05-07):
[0001104659-21-062898:note_history:7]
| Three months ended March 31, 2021 |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total | ​ |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 33,973 | ​ | $ | 38,549 | ​ | $ | 39,305 | ​ | $ | 111,827 | ​ |
| U.S. Government | ​ |  | 49,305 | ​ | ​ | 1,006 | ​ | ​ | 4,506 | ​ |  | 54,817 | ​ |
| Total revenues | ​ | $ | 83,278 | ​ | $ | 39,555 | ​ | $ | 43,811 | ​ | $ | 166,644 | ​ |
| Geographic location: | ​ |  |  | ​ | ​ |  | ​ | ​ |  | ​ |  |  | ​ |
| United States | ​ | $ | 73,037 | ​ | $ | 27,445 | ​ | $ | 22,965 | ​ | $ | 123,447 | ​ |
| International | ​ |  | 10,241 | ​ | ​ | 12,110 | ​ | ​ | 20,846 | ​ |  | 43,197 | ​ |
| Total revenues | ​ | $ | 83,278 | ​ | $ | 39,555 | ​ | $ | 43,811 | ​ | $ | 166,644 | ​ |
| Revenue recognition method: | ​ |  |  | ​ | ​ |  | ​ | ​ |  | ​ |  |  | ​ |
| Point in time | ​ | $ | 37,127 | ​ | $ | 27,563 | ​ | $ | 9,248 | ​ | $ | 73,938 | ​ |
| Over time | ​ |  | 46,151 | ​ | ​ | 11,992 | ​ | ​ | 34,563 | ​ |  | 92,706 | ​ |
| Total revenues | ​ | $ | 83,278 | ​ | $ | 39,555 | ​ | $ | 43,811 | ​ | $ | 166,644 | ​ |
  (was, 2021-02-09, similarity 0.9197):
[0001104659-21-016643:note_history:7]
| ​ |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total | ​ |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 27,879 | ​ | $ | 53,864 | ​ | $ | 36,722 | ​ | $ | 118,465 | ​ |
| U.S. Government | ​ |  | 39,012 | ​ | ​ | 676 | ​ | ​ | 4,796 | ​ |  | 44,484 | ​ |
| Total revenues | ​ | $ | 66,891 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,949 | ​ |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| United States | ​ | $ | 57,813 | ​ | $ | 37,045 | ​ | $ | 23,266 | ​ | $ | 118,124 | ​ |
| International | ​ |  | 9,078 | ​ | ​ | 17,495 | ​ | ​ | 18,252 | ​ |  | 44,825 | ​ |
| Total revenues | ​ | $ | 66,891 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,949 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 26,946 | ​ | $ | 42,367 | ​ | $ | 8,868 | ​ | $ | 78,181 | ​ |
| Over time | ​ |  | 39,945 | ​ | ​ | 12,173 | ​ | ​ | 32,650 | ​ |  | 84,768 | ​ |
| Total revenues | ​ | $ | 66,891 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,949 | ​ |

- added (2021-05-07):
[0001104659-21-062898:note_history:8]
| Six months ended March 31, 2021 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |  |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 62,114 | ​ | $ | 92,414 | ​ | $ | 76,027 | ​ | $ | 230,555 | ​ |
| U.S. Government | ​ |  | 88,055 | ​ |  | 1,681 | ​ |  | 9,302 | ​ |  | 99,038 | ​ |
| Total revenues | ​ | $ | 150,169 | ​ | $ | 94,095 | ​ | $ | 85,329 | ​ | $ | 329,593 | ​ |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  |  | ​ |  |  | ​ |
| United States | ​ | $ | 130,849 | ​ | $ | 64,490 | ​ | $ | 46,231 | ​ | $ | 241,570 | ​ |
| International | ​ |  | 19,320 | ​ |  | 29,605 | ​ |  | 39,098 | ​ |  | 88,023 | ​ |
| Total revenues | ​ | $ | 150,169 | ​ | $ | 94,095 | ​ | $ | 85,329 | ​ | $ | 329,593 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  |  | ​ |  |  | ​ |
| Point in time | ​ | $ | 64,000 | ​ | $ | 69,931 | ​ | $ | 18,116 | ​ | $ | 152,047 | ​ |
| Over time | ​ |  | 86,169 | ​ |  | 24,164 | ​ |  | 67,213 | ​ |  | 177,546 | ​ |
| Total revenues | ​ | $ | 150,169 | ​ | $ | 94,095 | ​ | $ | 85,329 | ​ | $ | 329,593 | ​ |

- added (2021-05-07):
[0001104659-21-062898:note_history:9]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2020 are presented in the tables below.

- added (2021-05-07):
[0001104659-21-062898:note_history:10]
| Three months ended March 31, 2020 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 51,550 | ​ | $ | 43,736 | ​ | $ | 33,952 | ​ | $ | 129,238 |
| U.S. Government | ​ |  | 43,574 | ​ |  | 32 | ​ |  | 7,648 | ​ |  | 51,254 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 43,768 | ​ | $ | 41,600 | ​ | $ | 180,492 |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| United States | ​ | $ | 81,458 | ​ | $ | 28,706 | ​ | $ | 25,121 | ​ | $ | 135,285 |
| International | ​ |  | 13,666 | ​ |  | 15,062 | ​ |  | 16,479 | ​ |  | 45,207 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 43,768 | ​ | $ | 41,600 | ​ | $ | 180,492 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 46,610 | ​ | $ | 32,209 | ​ | $ | 8,009 | ​ | $ | 86,828 |
| Over time | ​ |  | 48,514 | ​ |  | 11,559 | ​ |  | 33,591 | ​ |  | 93,664 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 43,768 | ​ | $ | 41,600 | ​ | $ | 180,492 |

- added (2021-05-07):
[0001104659-21-062898:note_history:11]
| Six months ended March 31, 2020 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 93,417 | ​ | $ | 95,971 | ​ | $ | 69,194 | ​ | $ | 258,582 |
| U.S. Government | ​ |  | 79,218 | ​ |  | 631 | ​ |  | 13,789 | ​ |  | 93,638 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 96,602 | ​ | $ | 82,983 | ​ | $ | 352,220 |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| United States | ​ | $ | 146,164 | ​ | $ | 63,665 | ​ | $ | 49,959 | ​ | $ | 259,788 |
| International | ​ |  | 26,471 | ​ |  | 32,937 | ​ |  | 33,024 | ​ |  | 92,432 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 96,602 | ​ | $ | 82,983 | ​ | $ | 352,220 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 82,897 | ​ | $ | 72,524 | ​ | $ | 17,019 | ​ | $ | 172,440 |
| Over time | ​ |  | 89,738 | ​ |  | 24,078 | ​ |  | 65,964 | ​ |  | 179,780 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 96,602 | ​ | $ | 82,983 | ​ | $ | 352,220 |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-05-07):
[0001104659-21-062898:note_history:12]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2021 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue within each reportable segment on a continuing operations basis.
  (was, 2021-02-09, similarity 0.6667):
[0001104659-21-016643:note_history:12]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2020 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net

- changed (2021-05-07):
[0001104659-21-062898:note_history:13]
| Three months ended March 31, 2021 |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total | ​ |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 33,973 | ​ | $ | 38,549 | ​ | $ | 39,305 | ​ | $ | 111,827 | ​ |
| U.S. Government | ​ |  | 49,305 | ​ | ​ | 1,006 | ​ | ​ | 4,506 | ​ |  | 54,817 | ​ |
| Total revenues | ​ | $ | 83,278 | ​ | $ | 39,555 | ​ | $ | 43,811 | ​ | $ | 166,644 | ​ |
| Geographic location: | ​ |  |  | ​ | ​ |  | ​ | ​ |  | ​ |  |  | ​ |
| United States | ​ | $ | 73,037 | ​ | $ | 27,445 | ​ | $ | 22,965 | ​ | $ | 123,447 | ​ |
| International | ​ |  | 10,241 | ​ | ​ | 12,110 | ​ | ​ | 20,846 | ​ |  | 43,197 | ​ |
| Total revenues | ​ | $ | 83,278 | ​ | $ | 39,555 | ​ | $ | 43,811 | ​ | $ | 166,644 | ​ |
| Revenue recognition method: | ​ |  |  | ​ | ​ |  | ​ | ​ |  | ​ |  |  | ​ |
| Point in time | ​ | $ | 37,127 | ​ | $ | 27,563 | ​ | $ | 9,248 | ​ | $ | 73,938 | ​ |
| Over time | ​ |  | 46,151 | ​ | ​ | 11,992 | ​ | ​ | 34,563 | ​ |  | 92,706 | ​ |
| Total revenues | ​ | $ | 83,278 | ​ | $ | 39,555 | ​ | $ | 43,811 | ​ | $ | 166,644 | ​ |
  (was, 2021-02-09, similarity 0.9197):
[0001104659-21-016643:note_history:13]
| ​ |  | Aerospace |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total | ​ |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 27,879 | ​ | $ | 53,864 | ​ | $ | 36,722 | ​ | $ | 118,465 | ​ |
| U.S. Government | ​ |  | 39,012 | ​ | ​ | 676 | ​ | ​ | 4,796 | ​ |  | 44,484 | ​ |
| Total revenues | ​ | $ | 66,891 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,949 | ​ |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| United States | ​ | $ | 57,813 | ​ | $ | 37,045 | ​ | $ | 23,266 | ​ | $ | 118,124 | ​ |
| International | ​ |  | 9,078 | ​ | ​ | 17,495 | ​ | ​ | 18,252 | ​ |  | 44,825 | ​ |
| Total revenues | ​ | $ | 66,891 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,949 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 26,946 | ​ | $ | 42,367 | ​ | $ | 8,868 | ​ | $ | 78,181 | ​ |
| Over time | ​ |  | 39,945 | ​ | ​ | 12,173 | ​ | ​ | 32,650 | ​ |  | 84,768 | ​ |
| Total revenues | ​ | $ | 66,891 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,949 | ​ |

- added (2021-05-07):
[0001104659-21-062898:note_history:14]
| Six months ended March 31, 2021 | ​ | Aerospace | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |  |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 62,114 | ​ | $ | 92,414 | ​ | $ | 76,027 | ​ | $ | 230,555 | ​ |
| U.S. Government | ​ |  | 88,055 | ​ |  | 1,681 | ​ |  | 9,302 | ​ |  | 99,038 | ​ |
| Total revenues | ​ | $ | 150,169 | ​ | $ | 94,095 | ​ | $ | 85,329 | ​ | $ | 329,593 | ​ |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  |  | ​ |  |  | ​ |
| United States | ​ | $ | 130,849 | ​ | $ | 64,490 | ​ | $ | 46,231 | ​ | $ | 241,570 | ​ |
| International | ​ |  | 19,320 | ​ |  | 29,605 | ​ |  | 39,098 | ​ |  | 88,023 | ​ |
| Total revenues | ​ | $ | 150,169 | ​ | $ | 94,095 | ​ | $ | 85,329 | ​ | $ | 329,593 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  |  | ​ |  |  | ​ |
| Point in time | ​ | $ | 64,000 | ​ | $ | 69,931 | ​ | $ | 18,116 | ​ | $ | 152,047 | ​ |
| Over time | ​ |  | 86,169 | ​ |  | 24,164 | ​ |  | 67,213 | ​ |  | 177,546 | ​ |
| Total revenues | ​ | $ | 150,169 | ​ | $ | 94,095 | ​ | $ | 85,329 | ​ | $ | 329,593 | ​ |

- added (2021-05-07):
[0001104659-21-062898:note_history:15]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2020 are presented in the tables below.

- added (2021-05-07):
[0001104659-21-062898:note_history:16]
| Three months ended March 31, 2020 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 51,550 | ​ | $ | 43,736 | ​ | $ | 33,952 | ​ | $ | 129,238 |
| U.S. Government | ​ |  | 43,574 | ​ |  | 32 | ​ |  | 7,648 | ​ |  | 51,254 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 43,768 | ​ | $ | 41,600 | ​ | $ | 180,492 |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| United States | ​ | $ | 81,458 | ​ | $ | 28,706 | ​ | $ | 25,121 | ​ | $ | 135,285 |
| International | ​ |  | 13,666 | ​ |  | 15,062 | ​ |  | 16,479 | ​ |  | 45,207 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 43,768 | ​ | $ | 41,600 | ​ | $ | 180,492 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 46,610 | ​ | $ | 32,209 | ​ | $ | 8,009 | ​ | $ | 86,828 |
| Over time | ​ |  | 48,514 | ​ |  | 11,559 | ​ |  | 33,591 | ​ |  | 93,664 |
| Total revenues | ​ | $ | 95,124 | ​ | $ | 43,768 | ​ | $ | 41,600 | ​ | $ | 180,492 |

- added (2021-05-07):
[0001104659-21-062898:note_history:17]
| Six months ended March 31, 2020 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial | ​ | $ | 93,417 | ​ | $ | 95,971 | ​ | $ | 69,194 | ​ | $ | 258,582 |
| U.S. Government | ​ |  | 79,218 | ​ |  | 631 | ​ |  | 13,789 | ​ |  | 93,638 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 96,602 | ​ | $ | 82,983 | ​ | $ | 352,220 |
| Geographic location: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| United States | ​ | $ | 146,164 | ​ | $ | 63,665 | ​ | $ | 49,959 | ​ | $ | 259,788 |
| International | ​ |  | 26,471 | ​ |  | 32,937 | ​ |  | 33,024 | ​ |  | 92,432 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 96,602 | ​ | $ | 82,983 | ​ | $ | 352,220 |
| Revenue recognition method: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Point in time | ​ | $ | 82,897 | ​ | $ | 72,524 | ​ | $ | 17,019 | ​ | $ | 172,440 |
| Over time | ​ |  | 89,738 | ​ |  | 24,078 | ​ |  | 65,964 | ​ |  | 179,780 |
| Total revenues | ​ | $ | 172,635 | ​ | $ | 96,602 | ​ | $ | 82,983 | ​ | $ | 352,220 |

- changed (2021-05-07):
[0001104659-21-062898:note_history:18]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At March 31, 2021, the Company had $521.7 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 72% in the next twelve months.
  (was, 2021-02-09, similarity 0.9907):
[0001104659-21-016643:note_history:18]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At December 31, 2020, the Company had $512.1 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 72% in the next twelve months.

- added (2021-05-07):
[0001104659-21-062898:note_history:19]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At March 31, 2021, contract assets and liabilities totaled $95.0 million and $106.6 million, respectively. Contract assets and liabilities are presented as current in the consolidated balance sheets as it is expected all related transaction activity with customers will be substantially completed within twelve months. During the first six months of 2021, the Company recognized approximately $56 million in revenues that were included in the contract liabilities balance at September 30, 2020.

- removed (2021-05-07):
[0001104659-21-016643:note_history:20]
sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within each reportable segment on a continuing operations basis.

- removed (2021-05-07):
[0001104659-21-016643:note_history:21]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. At December 31, 2020, contract assets and liabilities totaled $93.8 million and $112.3 million, respectively.  During the first quarter of 2021, the Company recognized approximately $30 million in revenues that were included in the contract liabilities balance at the adoption date.
