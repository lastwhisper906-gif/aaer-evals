# ESE notes — 0001410578-22-001243


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001410578-22-001243:notes:1]
[same as prior period, unchanged from 0001410578-22-000098:notes:1]

[0001410578-22-001243:notes:2]
[same as prior period, unchanged from 0001410578-22-000098:notes:2]

[0001410578-22-001243:notes:3]
The Company’s results for the three-month period ended March 31, 2022 are not necessarily indicative of the results for the entire 2022 fiscal year. References to the second quarters of 2022 and 2021 represent the fiscal quarters ended March 31, 2022 and 2021, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates. Certain prior period deferred revenue amounts have been reclassified to noncurrent to conform with the current year presentation.


## us-gaap:EarningsPerShareTextBlock

[0001410578-22-001243:notes:4]
[same as prior period, unchanged from 0001410578-22-000098:notes:4]

[0001410578-22-001243:notes:5]
[same as prior period, unchanged from 0001410578-22-000098:notes:5]

[0001410578-22-001243:notes:6]
| ​ |  | Three Months |  | Six Months |
| ​ | ​ | Ended March 31, | ​ | Ended March 31, |
| ​ |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Weighted Average Shares Outstanding — Basic |  | 25,953 |  | 26,038 | ​ | 26,008 | ​ | 26,038 |
| Dilutive Restricted Shares | ​ | 92 | ​ | 163 | ​ | 90 | ​ | 154 |
| Adjusted Shares — Diluted |  | 26,045 |  | 26,201 | ​ | 26,098 | ​ | 26,192 |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001410578-22-001243:notes:7]
[same as prior period, unchanged from 0001410578-22-000098:notes:8]

[0001410578-22-001243:notes:8]
[same as prior period, unchanged from 0001410578-22-000098:notes:9]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001410578-22-001243:notes:9]
[same as prior period, unchanged from 0001410578-22-000098:notes:10]

[0001410578-22-001243:notes:10]
The Company provides compensation benefits to certain key employees under several share-based plans providing for performance-accelerated and/or time-vested restricted stock unit awards, and to non-employee directors under a non-employee directors compensation plan.

[0001410578-22-001243:notes:11]
[same as prior period, unchanged from 0001410578-22-000098:notes:12]

[0001410578-22-001243:notes:12]
Compensation expense related to the PARS/RSU awards was $1.5 million and $2.8 million for the three and six-month periods ended March 31, 2022, respectively, and $1.1 million and $2.1 million for the corresponding periods in 2021. As of March 31, 2022, there were 210,119 unvested stock units outstanding.

[0001410578-22-001243:notes:13]
[same as prior period, unchanged from 0001410578-22-000098:notes:14]

[0001410578-22-001243:notes:14]
Compensation expense related to the non-employee director grants was $0.3 million and $0.6 million for the three and six-month periods ended March 31, 2022, respectively, and $0.3 million and $0.6 million for the corresponding periods in 2021.

[0001410578-22-001243:notes:15]
The total share-based compensation cost that has been recognized in the results of operations and included within selling, general and administrative expenses (SG&A) was $1.7 million and $3.4 million for the three and six-month periods ended March 31, 2022, respectively, and $1.4 million and $2.7 million for the corresponding periods in 2021. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $0.3 million and $0.5 million for the three and six-month periods ended March 31, 2022, respectively, and $0.3 million and $0.7 million for the corresponding periods in 2021. As of March 31, 2022, there was $10.9 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a remaining weighted-average period of 1.9 years.


## us-gaap:InventoryDisclosureTextBlock

[0001410578-22-001243:notes:16]
[same as prior period, unchanged from 0001410578-22-000098:notes:17]

[0001410578-22-001243:notes:17]
Inventories, net, consist of the following:

[0001410578-22-001243:notes:18]
| ​ |  | March 31, |  | September 30, |
| (In thousands) |  | 2022 |  | 2021 |
| Finished goods | ​ | $ | 37,434 |  | 32,998 |
| Work in process | ​ |  | 46,447 |  | 34,201 |
| Raw materials | ​ |  | 91,271 |  | 79,949 |
| Total inventories, net | ​ | $ | 175,152 |  | 147,148 |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001410578-22-001243:notes:19]
[same as prior period, unchanged from 0001410578-22-000098:notes:21]

[0001410578-22-001243:notes:20]
Included on the Company’s Consolidated Balance Sheets at March 31, 2022 and September 30, 2021 are the following intangible assets gross carrying amounts and accumulated amortization:

[0001410578-22-001243:notes:21]
| ​ |  | March 31, |  | September 30, |
| (Dollars in thousands) |  | 2022 |  | 2021 |
| Goodwill | ​ | $ | 508,406 |  | 504,853 |
| Intangible assets with determinable lives: | ​ |  | ​ | ​ | ​ |
| Patents | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 2,208 | ​ | 2,131 |
| Less: accumulated amortization | ​ |  | 1,029 | ​ | 972 |
| Net | ​ | $ | 1,178 | ​ | 1,159 |
| Capitalized software | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 98,398 | ​ | 93,671 |
| Less: accumulated amortization | ​ |  | 67,013 | ​ | 63,740 |
| Net | ​ | $ | 31,385 | ​ | 29,931 |
| Customer relationships | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 292,887 | ​ | 288,530 |
| Less: accumulated amortization | ​ |  | 88,933 | ​ | 80,882 |
| Net | ​ | $ | 203,954 | ​ | 207,648 |
| Other | ​ |  | ​ | ​ | ​ |
| Gross carrying amount | ​ | $ | 14,567 | ​ | 13,080 |
| Less: accumulated amortization | ​ |  | 5,897 | ​ | 4,301 |
| Net | ​ | $ | 8,670 | ​ | 8,779 |
| Intangible assets with indefinite lives: | ​ |  | ​ | ​ | ​ |
| Trade names | ​ | $ | 162,016 | ​ | 161,733 |

[0001410578-22-001243:notes:22]
The changes in the carrying amount of goodwill attributable to each business segment for the six months ended March 31, 2022 is as follows:

[0001410578-22-001243:notes:23]
| ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | Aerospace | ​ | ​ |
| (Dollars in millions) |  | USG | ​ | Test |  | & Defense |  | Total |
| Balance as of September 30, 2021 | ​ | ​ | 366.5 |  | ​ | 34.1 |  | 104.3 |  | 504.9 |
| Acquisition activity and adjustments | ​ | ​ | 0.3 | ​ | ​ | — | ​ | 5.7 | ​ | 6.0 |
| Foreign currency translation | ​ | ​ | (2.5) | ​ | ​ | — | ​ | — | ​ | (2.5) |
| Balance as of March 31, 2022 | ​ | $ | 364.3 | ​ | ​ | 34.1 | ​ | 110.0 | ​ | 508.4 |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001410578-22-001243:notes:24]
[same as prior period, unchanged from 0001410578-22-000098:notes:27]

[0001410578-22-001243:notes:25]
The Company is organized based on the products and services that it offers and classifies its continuing business operations in three reportable segments for financial reporting purposes: Aerospace & Defense, Utility Solutions Group (USG), and RF Shielding and Test (Test).

[0001410578-22-001243:notes:26]
The Aerospace & Defense segment’s operations consist of PTI Technologies Inc. (PTI), VACCO Industries (VACCO), Crissair, Inc. (Crissair), Westland Technologies Inc. (Westland), Mayday Manufacturing Co. (Mayday) and Globe Composite Solutions, LLC (Globe). The companies within this segment primarily design and manufacture specialty filtration, fluid control and naval products, including hydraulic filter elements and fluid control devices used in aerospace and defense applications; unique filter mechanisms used in micro-propulsion devices for satellites, custom designed filters for manned aircraft and submarines; products and systems to reduce vibration and/or acoustic signatures and otherwise reduce or obscure a vessel’s signature, and other communications, sealing, surface control and hydrodynamic related applications to enhance U.S. Navy maritime survivability; precision-tolerance machined components for the aerospace and defense industry; and metal processing services.

[0001410578-22-001243:notes:27]
The USG segment’s operations consist primarily of Doble Engineering Company and related subsidiaries including Morgan Schaffer and Altanova (collectively, Doble), and NRG Systems, Inc. (NRG). Doble is an industry leader in the development, manufacture and delivery of diagnostic testing solutions that enable electric power grid operators to assess the integrity of high voltage power delivery equipment. It combines three core elements for customers – diagnostic test and condition monitoring instruments, expert consulting, and testing services – and provides access to its large reserve of related empirical knowledge. NRG is a global market leader in the design and manufacture of decision support tools for the renewable energy industry, primarily wind and solar.

[0001410578-22-001243:notes:28]
[same as prior period, unchanged from 0001410578-22-000098:notes:30]

[0001410578-22-001243:notes:29]
Management evaluates and measures the performance of its reportable segments based on “Net Sales” and “EBIT”, which are detailed in the table below. EBIT is defined as earnings before interest and taxes.

[0001410578-22-001243:notes:30]
| ​ | ​ | Three Months | ​ | Six Months |
| ​ | ​ | Ended March 31, | ​ | Ended March 31, |
| (In thousands) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| NET SALES | ​ | ​ |  | ​ |  | ​ |  | ​ |  |
| Aerospace & Defense | ​ | $ | 84,821 | ​ | 82,528 | ​ | 155,065 | ​ | 149,144 |
| USG | ​ | ​ | 64,191 | ​ | 39,555 | ​ | 127,676 | ​ | 94,095 |
| Test | ​ | ​ | 55,916 | ​ | 43,811 | ​ | 99,197 | ​ | 85,329 |
| Consolidated totals | ​ | $ | 204,928 | ​ | 165,894 | ​ | 381,938 | ​ | 328,568 |
| EBIT | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Aerospace & Defense | ​ | $ | 14,349 | ​ | 17,006 | ​ | 24,304 | ​ | 25,266 |
| USG | ​ | ​ | 11,314 | ​ | 6,725 | ​ | 24,705 | ​ | 19,456 |
| Test | ​ | ​ | 8,494 | ​ | 5,688 | ​ | 12,459 | ​ | 11,030 |
| Corporate (loss) | ​ | ​ | (11,469) | ​ | (8,838) | ​ | (23,210) | ​ | (18,090) |
| Consolidated EBIT | ​ | ​ | 22,688 | ​ | 20,581 | ​ | 38,258 | ​ | 37,662 |
| Less: Interest expense | ​ | ​ | (1,020) | ​ | (432) | ​ | (1,753) | ​ | (973) |
| Earnings before income taxes | ​ | $ | 21,668 | ​ | 20,149 | ​ | 36,505 | ​ | 36,689 |

[0001410578-22-001243:notes:31]
[same as prior period, unchanged from 0001410578-22-000098:notes:33]

[0001410578-22-001243:notes:32]
The financial measure “EBIT” is presented in the above table and elsewhere in this Report. EBIT on a consolidated basis is a non-GAAP financial measure. Management believes that EBIT is useful in assessing the operational profitability of the Company’s business segments because it excludes interest and taxes, which are generally accounted for across the entire Company on a consolidated basis. EBIT is also one of the measures used by management in determining resource allocations within the Company as well as incentive compensation. A reconciliation of EBIT to net earnings is set forth in Item 2, Management’s Discussion and Analysis of Financial Condition and Results of Operations – EBIT.

[0001410578-22-001243:notes:33]
[same as prior period, unchanged from 0001410578-22-000098:notes:35]


## us-gaap:DebtDisclosureTextBlock

[0001410578-22-001243:notes:34]
8.    DEBT

[0001410578-22-001243:notes:35]
The Company’s debt is summarized as follows:

[0001410578-22-001243:notes:36]
| ​ |  | March 31, | ​ | September 30, |
| (In thousands) |  | 2022 |  | 2021 |
| Total borrowings | ​ | $ | 196,000 |  | 154,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 176,000 |  | 134,000 |

[0001410578-22-001243:notes:37]
The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024.

[0001410578-22-001243:notes:38]
At March 31, 2022, the Company had approximately $296 million available to borrow under the Credit Facility, plus the $250 million increase option, subject to lender approval, in addition to $54.3 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of March 31, 2022, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $8.1 million at March 31, 2022.

[0001410578-22-001243:notes:39]
Interest on borrowings under the Credit Facility is calculated at a spread over either the New York Federal Reserve Bank Rate, the prime rate or the London Interbank Offered Rate (LIBOR), depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The Credit Facility is secured by the unlimited guaranty of the Company’s direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of its direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 1.29% and 1.23% for the three and six-month periods ending March 31, 2022, respectively, and 1.27% and 1.40% for the three and six-month periods ending March 31, 2021. As of March 31, 2022, the Company was in compliance with all covenants.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001410578-22-001243:notes:40]
[same as prior period, unchanged from 0001410578-22-000098:notes:42]

[0001410578-22-001243:notes:41]
The second quarter 2022 effective income tax rate was 23.5% compared to 23.5% in the second quarter of 2021. The effective income tax rate in the first six months of 2022 was 23.0% compared to 23.1% for the first six months of 2021. There were no significant or unusual items impacting the 2022 second quarter or year-to-date effective tax rate.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001410578-22-001243:notes:42]
[same as prior period, unchanged from 0001410578-22-000098:notes:44]

[0001410578-22-001243:notes:43]
The change in shareholders’ equity for the first three and six months of 2022 and 2021 is shown below (in thousands):

[0001410578-22-001243:notes:44]
| ​ | ​ | Three Months Ended March 31, | ​ | Six Months Ended March 31, |
| ​ |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Common stock | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | 307 | ​ | 306 | ​ | 307 | ​ | 306 |
| Stock plans | ​ | ​ | — | ​ | — | ​ | — | ​ | — |
| Ending balance | ​ | ​ | 307 | ​ | 306 | ​ | 307 | ​ | 306 |
| Additional paid-in-capital | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | 296,277 | ​ | 294,735 | ​ | 297,644 | ​ | 293,682 |
| Stock plans | ​ | ​ | 2,076 | ​ | 1,061 | ​ | 709 | ​ | 2,114 |
| Ending balance | ​ | ​ | 298,353 | ​ | 295,796 | ​ | 298,353 | ​ | 295,796 |
| Retained earnings | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | 840,434 | ​ | 786,563 | ​ | 830,989 | ​ | 775,829 |
| Net earnings common stockholders | ​ | ​ | 16,583 | ​ | 15,404 | ​ | 28,107 | ​ | 28,222 |
| Dividends paid | ​ | ​ | (2,071) | ​ | (2,083) | ​ | (4,150) | ​ | (4,167) |
| Ending balance | ​ | ​ | 854,946 | ​ | 799,884 | ​ | 854,946 | ​ | 799,884 |
| Accumulated other comprehensive income (loss) | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | (4,661) | ​ | 1,692 | ​ | (2,161) | ​ | (3,657) |
| Foreign currency translation | ​ | ​ | (2,811) | ​ | 116 | ​ | (5,311) | ​ | 5,465 |
| Ending balance | ​ | ​ | (7,472) | ​ | 1,808 | ​ | (7,472) | ​ | 1,808 |
| Treasury stock | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Beginning balance | ​ | ​ | (117,080) | ​ | (107,134) | ​ | (107,083) | ​ | (107,134) |
| Issued under stock plans | ​ | ​ | (7,881) | ​ | — | ​ | (17,878) | ​ | — |
| Ending balance | ​ | ​ | (124,961) | ​ | (107,134) | ​ | (124,961) | ​ | (107,134) |
| Total equity | ​ | ​ | 1,021,173 | ​ | 990,660 | ​ | 1,021,173 | ​ | 990,660 |


## us-gaap:FairValueDisclosuresTextBlock

[0001410578-22-001243:notes:45]
[same as prior period, unchanged from 0001410578-22-000098:notes:47]

[0001410578-22-001243:notes:46]
[same as prior period, unchanged from 0001410578-22-000098:notes:48]

[0001410578-22-001243:notes:47]
[same as prior period, unchanged from 0001410578-22-000098:notes:49]

[0001410578-22-001243:notes:48]
[same as prior period, unchanged from 0001410578-22-000098:notes:50]

[0001410578-22-001243:notes:49]
[same as prior period, unchanged from 0001410578-22-000098:notes:51]

[0001410578-22-001243:notes:50]
[same as prior period, unchanged from 0001410578-22-000098:notes:52]

[0001410578-22-001243:notes:51]
The Company has estimated the fair value of its financial instruments as of March 31, 2022 and September 30, 2021 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables, and other current assets and liabilities approximate fair value because of the short maturity of those instruments.

[0001410578-22-001243:notes:52]
[same as prior period, unchanged from 0001410578-22-000098:notes:54]

[0001410578-22-001243:notes:53]
[same as prior period, unchanged from 0001410578-22-000098:notes:55]

[0001410578-22-001243:notes:54]
[same as prior period, unchanged from 0001410578-22-000098:notes:56]

[0001410578-22-001243:notes:55]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during the three and six-month periods ended March 31, 2022.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001410578-22-001243:notes:56]
[same as prior period, unchanged from 0001410578-22-000098:notes:58]

[0001410578-22-001243:notes:57]
[same as prior period, unchanged from 0001410578-22-000098:notes:59]

[0001410578-22-001243:notes:58]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2022 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue within each reportable segment.

[0001410578-22-001243:notes:59]
| Three months ended March 31, 2022 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total |  |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 33,562 | ​ | $ | 63,379 | ​ | $ | 51,903 | ​ | $ | 148,844 | ​ |
| U.S. Government | ​ |  | 51,259 | ​ | ​ | 812 | ​ | ​ | 4,013 | ​ |  | 56,084 | ​ |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 | ​ |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| United States | ​ | $ | 72,621 | ​ | $ | 41,458 | ​ | $ | 31,071 | ​ | $ | 145,150 | ​ |
| International | ​ |  | 12,200 | ​ | ​ | 22,733 | ​ | ​ | 24,845 | ​ |  | 59,778 | ​ |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 35,666 | ​ | $ | 51,202 | ​ | $ | 14,838 | ​ | $ | 101,706 | ​ |
| Over time | ​ |  | 49,155 | ​ | ​ | 12,989 | ​ | ​ | 41,078 | ​ |  | 103,222 | ​ |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 | ​ |

[0001410578-22-001243:notes:60]
| Six months ended March 31, 2022 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 61,489 | ​ | $ | 126,221 | ​ | $ | 92,941 | ​ | $ | 280,651 |
| U.S. Government | ​ |  | 93,576 | ​ |  | 1,455 | ​ |  | 6,256 | ​ |  | 101,287 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 133,313 | ​ | $ | 80,199 | ​ | $ | 54,047 | ​ | $ | 267,559 |
| International | ​ |  | 21,752 | ​ |  | 47,477 | ​ |  | 45,150 | ​ |  | 114,379 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 64,223 | ​ | $ | 102,037 | ​ | $ | 27,660 | ​ | $ | 193,920 |
| Over time | ​ |  | 90,842 | ​ |  | 25,639 | ​ |  | 71,537 | ​ |  | 188,018 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |

[0001410578-22-001243:notes:61]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2021 are presented in the tables below.

[0001410578-22-001243:notes:62]
| Three months ended March 31, 2021 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial |  | $ | 33,223 |  | $ | 38,549 |  | $ | 39,305 |  | $ | 111,077 |
| U.S. Government | ​ | ​ | 49,305 | ​ | ​ | 1,006 | ​ | ​ | 4,506 | ​ | ​ | 54,817 |
| Total revenues |  | $ | 82,528 |  | $ | 39,555 |  | $ | 43,811 |  | $ | 165,894 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States |  | $ | 72,287 |  | $ | 27,445 |  | $ | 22,965 |  | $ | 122,697 |
| International | ​ | ​ | 10,241 | ​ | ​ | 12,110 | ​ | ​ | 20,846 | ​ | ​ | 43,197 |
| Total revenues |  | $ | 82,528 |  | $ | 39,555 |  | $ | 43,811 |  | $ | 165,894 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time |  | $ | 37,127 |  | $ | 27,563 |  | $ | 9,248 |  | $ | 73,938 |
| Over time | ​ | ​ | 45,401 | ​ | ​ | 11,992 | ​ | ​ | 34,563 | ​ | ​ | 91,956 |
| Total revenues |  | $ | 82,528 |  | $ | 39,555 |  | $ | 43,811 |  | $ | 165,894 |

[0001410578-22-001243:notes:63]
| Six months ended March 31, 2021 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial |  | $ | 61,089 |  | $ | 92,414 |  | $ | 76,027 |  | $ | 229,530 |
| U.S. Government | ​ | ​ | 88,055 | ​ | ​ | 1,681 | ​ | ​ | 9,302 | ​ | ​ | 99,038 |
| Total revenues |  | $ | 149,144 |  | $ | 94,095 |  | $ | 85,329 |  | $ | 328,568 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States |  | $ | 129,824 |  | $ | 64,490 |  | $ | 46,231 |  | $ | 240,545 |
| International | ​ | ​ | 19,320 | ​ | ​ | 29,605 | ​ | ​ | 39,098 | ​ | ​ | 88,023 |
| Total revenues |  | $ | 149,144 |  | $ | 94,095 |  | $ | 85,329 |  | $ | 328,568 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time |  | $ | 64,000 |  | $ | 69,931 |  | $ | 18,116 |  | $ | 152,047 |
| Over time | ​ | ​ | 85,144 | ​ | ​ | 24,164 | ​ | ​ | 67,213 | ​ | ​ | 176,521 |
| Total revenues |  | $ | 149,144 |  | $ | 94,095 |  | $ | 85,329 |  | $ | 328,568 |

[0001410578-22-001243:notes:64]
[same as prior period, unchanged from 0001410578-22-000098:notes:64]

[0001410578-22-001243:notes:65]
[same as prior period, unchanged from 0001410578-22-000098:notes:65]

[0001410578-22-001243:notes:66]
[same as prior period, unchanged from 0001410578-22-000098:notes:66]

[0001410578-22-001243:notes:67]
[same as prior period, unchanged from 0001410578-22-000098:notes:67]

[0001410578-22-001243:notes:68]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At March 31, 2022, the Company had $670.9 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 77% in the next twelve months.

[0001410578-22-001243:notes:69]
[same as prior period, unchanged from 0001410578-22-000098:notes:69]

[0001410578-22-001243:notes:70]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred. At March 31, 2022, contract assets and liabilities totaled

[0001410578-22-001243:notes:71]
$111.5 million and $113.0 million, respectively. During the first six months of 2022, the Company recognized approximately $51 million in revenues that were included in the contract liabilities balance at September 30, 2021. The increase in net contract assets in the first six months of 2022 was due to revenue being recognized for performance completed during the period that exceeded customer billings. Other factors that impacted the change in net contract liabilities were immaterial. At October 1, 2020, contract assets and liabilities totaled $94.3 million and $100.6 million, respectively.


## ese:OperatingAndFinancingLeasesOfLesseeDisclosureTextBlock

[0001410578-22-001243:notes:72]
[same as prior period, unchanged from 0001410578-22-000098:notes:71]

[0001410578-22-001243:notes:73]
[same as prior period, unchanged from 0001410578-22-000098:notes:72]

[0001410578-22-001243:notes:74]
[same as prior period, unchanged from 0001410578-22-000098:notes:73]

[0001410578-22-001243:notes:75]
In addition to the base rent, real estate leases typically contain provisions for common-area maintenance and other similar services, which are considered non-lease components for accounting purposes. Non-lease components are excluded from our ROU assets and lease liabilities and expensed as incurred.

[0001410578-22-001243:notes:76]
[same as prior period, unchanged from 0001410578-22-000098:notes:75]

[0001410578-22-001243:notes:77]
[same as prior period, unchanged from 0001410578-22-000098:notes:76]

[0001410578-22-001243:notes:78]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended |
| ​ | ​ | March 31, | ​ | March 31, |
| (Dollars in thousands) |  | 2022 |  | 2021 |
| Finance lease cost | ​ | ​ |  | ​ | ​ |  |
| Amortization of right-of-use assets | ​ | $ | 607 | ​ | $ | 492 |
| Interest on lease liabilities | ​ |  | 291 | ​ |  | 311 |
| Operating lease cost | ​ |  | 1,578 | ​ |  | 1,424 |
| Total lease costs | ​ | $ | 2,476 | ​ | $ | 2,227 |

[0001410578-22-001243:notes:79]
| ​ |  | Six Months |  | Six Months |
| ​ | ​ | Ended | ​ | Ended |
| ​ | ​ | March 31, | ​ | March 31, |
| (Dollars in thousands) |  | 2022 |  | 2021 |
| Finance lease cost | ​ | ​ | ​ | ​ | ​ | ​ |
| Amortization of right-of-use assets |  | $ | 1,214 |  | $ | 985 |
| Interest on lease liabilities | ​ | ​ | 593 | ​ | ​ | 623 |
| Operating lease cost | ​ | ​ | 3,131 | ​ | ​ | 2,877 |
| Total lease costs |  | $ | 4,938 |  | $ | 4,485 |

[0001410578-22-001243:notes:80]
[same as prior period, unchanged from 0001410578-22-000098:notes:78]

[0001410578-22-001243:notes:81]
| ​ | ​ | Three Months Ended | ​ | Three Months Ended |
| ​ | ​ | March 31, | ​ | March 31, |
| (Dollars in thousands) |  | 2022 |  | 2021 |
| Cash paid for amounts included in the measurement of lease liabilities | ​ | ​ |  | ​ | ​ |  |
| Operating cash flows from operating leases | ​ | $ | 1,512 | ​ | $ | 1,375 |
| Operating cash flows from finance leases | ​ |  | 245 | ​ |  | 311 |
| Financing cash flows from finance leases | ​ |  | 304 | ​ |  | 419 |
| Right-of-use assets obtained in exchange for operating lease liabilities | ​ | ​ | 346 | ​ | ​ | — |

[0001410578-22-001243:notes:82]
| ​ |  | Six Months Ended |  | Six Months Ended |
| ​ | ​ | March 31, | ​ | March 31, |
| (Dollars in thousands) |  | 2022 |  | 2021 |
| Cash paid for amounts included in the measurement of lease liabilities | ​ | ​ | ​ | ​ | ​ | ​ |
| Operating cash flows from operating leases |  | $ | 3,008 |  | $ | 2,800 |
| Operating cash flows from finance leases | ​ | ​ | 492 | ​ | ​ | 623 |
| Financing cash flows from finance leases | ​ | ​ | 605 | ​ | ​ | 838 |
| Right-of-use assets obtained in exchange for operating lease liabilities | ​ | ​ | 1,247 | ​ | ​ | — |

[0001410578-22-001243:notes:83]
| ​ |  | March 31, 2022 |  | March 31, 2021 | ​ |
| Weighted-average remaining lease term | ​ | ​ | ​ | ​ | ​ |
| Operating leases |  | 9.9 | years | 5.8 | years |
| Finance leases |  | 12.5 | years | 12.2 | years |
| Weighted-average discount rate |  |  |  |  | ​ |
| Operating leases |  | 3.12 | % | 3.11 | % |
| Finance leases |  | 4.58 | % | 4.31 | % |

[0001410578-22-001243:notes:84]
The following is a reconciliation of future undiscounted cash flows to the operating and finance lease liabilities, and the related ROU assets, presented on our Consolidated Balance Sheet on March 31, 2022:

[0001410578-22-001243:notes:85]
| (Dollars in thousands) | ​ | Operating |  | Finance |
| Years Ending September 30: |  | Leases |  | Leases |
| 2022 (excluding the six months ended March 31, 2022) | ​ | $ | 2,843 |  | 1,100 |
| 2023 | ​ |  | 5,244 |  | 2,256 |
| 2024 | ​ |  | 4,198 |  | 2,315 |
| 2025 | ​ |  | 3,639 |  | 2,370 |
| 2026 and thereafter | ​ |  | 20,161 |  | 21,431 |
| Total minimum lease payments | ​ |  | 36,085 |  | 29,472 |
| Less: amounts representing interest | ​ |  | 5,145 |  | 7,670 |
| Present value of net minimum lease payments | ​ | $ | 30,940 |  | 21,802 |
| Less: current portion of lease obligations | ​ |  | 4,638 |  | 1,277 |
| Non-current portion of lease obligations | ​ | ​ | 26,302 |  | 20,525 |
| ROU assets | ​ | $ | 30,139 |  | 18,129 |

[0001410578-22-001243:notes:86]
Operating lease liabilities are included in the Consolidated Balance Sheet in accrued other expenses (current portion) and as a caption on the Consolidated Balance Sheet (long-term portion). Finance lease liabilities are included on the Consolidated Balance Sheet in accrued other expenses (current portion) and other liabilities (long-term portion). Operating lease ROU assets are included as a caption on the Consolidated Balance Sheet and finance lease ROU assets are included in Property, plant and equipment on the Consolidated Balance sheets.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001410578-22-001243:notes:87]
[same as prior period, unchanged from 0001410578-22-000098:notes:83]

[0001410578-22-001243:notes:88]
During 2021, the Company identified immaterial errors in the historical consolidated financial statements of Westland, within the A&D segment, that are being corrected as an immaterial revision of those financial statements. Specifically, the adjustments include net sales being overstated by $0.8 million in the second quarter of 2021, along with inventory being overstated and cost of goods sold being understated by $0.4 million in the second quarter of 2021. The tax impact of correcting these errors was a reduction in tax expense of $0.3 million in the second quarter of 2021. The table below shows the impact of these adjustments to the second quarter of 2021. Management has determined that these adjustments are not material to the prior year period.

[0001410578-22-001243:notes:89]
| ​ |  | Second Quarter |  | Second Quarter |
| (Dollars in thousands, except per share amounts) | ​ | (As Reported) | ​ | (As Adjusted) |
| 2021 | ​ | ​ | ​ | ​ | ​ |
| Net sales | ​ | $ | 166,644 | ​ | 165,894 |
| Cost of sales | ​ |  | 103,113 | ​ | 103,553 |
| Earnings before income taxes | ​ |  | 21,339 | ​ | 20,149 |
| Income tax expense | ​ |  | 5,025 | ​ | 4,745 |
| Net earnings | ​ |  | 16,314 | ​ | 15,404 |
| Diluted earnings (loss) per share: | ​ |  | ​ | ​ | ​ |
| Net earnings | ​ | $ | 0.62 | ​ | 0.59 |
