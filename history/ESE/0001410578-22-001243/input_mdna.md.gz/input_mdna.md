# ESE MD&A — 0001410578-22-001243


## mdna

[0001410578-22-001243:mdna:1]
[same as prior period, unchanged from 0001410578-22-000098:mdna:1]

[0001410578-22-001243:mdna:2]
[same as prior period, unchanged from 0001410578-22-000098:mdna:4]

[0001410578-22-001243:mdna:3]
The COVID-19 global pandemic has continued to create significant and unprecedented challenges, including constraints on the Company’s supply chain. The economic uncertainty, changes in the propensity for the general public to travel by air, and reductions in demand for commercial aircraft as a result of the COVID-19 pandemic have adversely impacted net sales and operating results in certain of our A&D reporting units. Additionally, the electric utility market has been impacted by reduced domestic electricity consumption related to the pandemic, which in turn impacts utility spending on investments in grid maintenance and testing.

[0001410578-22-001243:mdna:4]
Throughout 2021 and the first six months of 2022, our Navy, defense aerospace, space and Test segment end-markets have remained solid and we are now seeing recovery in our core markets most affected by the pandemic. We are encouraged by the growing strength of our entered orders across the commercial aerospace, electric utility and renewable energy end-markets. While there is still uncertainty as to the timing and pace of recovery in the commercial aerospace and electric utility markets, we have seen these markets begin to stabilize and expect strong growth in the second half of fiscal 2022.

[0001410578-22-001243:mdna:5]
We are also monitoring the impacts of COVID-19 on the fair value of assets. We do not currently anticipate any material asset impairments as a result of the COVID-19 global pandemic. We determined that there was no impairment for the three and six-month period ended March 31, 2022. We will continue to monitor the impacts of COVID-19 on the fair value of assets. For further discussion, refer to Management’s Discussion and Analysis contained in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2021.

[0001410578-22-001243:mdna:6]
[same as prior period, unchanged from 0001410578-22-000098:mdna:2]

[0001410578-22-001243:mdna:7]
References to the second quarters of 2022 and 2021 represent the three-month periods ended March 31, 2022 and 2021, respectively.

[0001410578-22-001243:mdna:8]
[same as prior period, unchanged from 0001410578-22-000098:mdna:8]

[0001410578-22-001243:mdna:9]
In the second quarter of 2022, sales, net earnings and diluted earnings per share were $204.9 million, $16.6 million and $0.64 per share, respectively, compared to $165.9 million, $15.4 million and $0.59 per share, respectively, in the second quarter of 2021. In the first six months of 2022, sales, net earnings and diluted earnings per share were $381.9 million, $28.1 million and $1.08 per share, respectively, compared to $328.6 million, $28.2 million and $1.08 per share, respectively, in the first six months of 2021.

[0001410578-22-001243:mdna:10]
[same as prior period, unchanged from 0001410578-22-000098:mdna:10]

[0001410578-22-001243:mdna:11]
In the second quarter of 2022, net sales of $204.9 million were $39.0 million, or 23.5%, higher than the $165.9 million in the second quarter of 2021. In the first six months of 2022, net sales of $381.9 million were $53.3 million, or 16.2%, higher than the $328.6 million in the first six months of 2021. The increase in net sales in the second quarter of 2022 as compared to the second quarter of 2021 was due to a $24.6 million increase in the USG segment, a $12.1 million increase in the Test segment, and a $2.3 million increase in the Aerospace & Defense segment. The increase in net sales in the first six months of 2022 as compared to the first six months of 2021 was due to a $33.5 million increase in the USG segment, a $13.8 million increase in the Test segment, and a $6.0 million increase in the Aerospace & Defense segment.

[0001410578-22-001243:mdna:12]
[same as prior period, unchanged from 0001410578-22-000098:mdna:12]

[0001410578-22-001243:mdna:13]
In the second quarter of 2022, net sales of $84.8 million were $2.3 million, or 2.8%, higher than the $82.5 million in the second quarter of 2021. In the first six months of 2022, net sales of $155.1 million were $6.0 million, or 4.0%, higher than the $149.1 million in the first six months of 2021. The sales increase in the second quarter of 2022 compared to the second quarter of 2021 was mainly due to a $2.8 million increase in net sales at Mayday, a $1.0 million increase in net sales at PTI, a $0.9 million increase in net sales at Globe, an $0.8 million increase in net sales at Westland, a $0.4 million increase in net sales at Crissair, primarily due to an increase in commercial aerospace sales driven by the rebound from the COVID-19 pandemic, partially offset by a $3.6 million decrease in sales at VACCO driven by timing of navy defense projects. The sales increase in the first six months of 2022 compared to the first six months of 2021 was mainly due to a $4.5 million increase in net sales at Mayday, a $5.4 million increase in net sales at PTI, a $3.4 million increase in net sales at Westland, and a $0.3 million increase in net sales at Globe, primarily due to an increase in commercial aerospace sales driven by the rebound from the COVID-19 pandemic, partially offset by a $7.6 million decrease in net sales at VACCO driven by timing of navy defense projects.

[0001410578-22-001243:mdna:14]
[same as prior period, unchanged from 0001410578-22-000098:mdna:14]

[0001410578-22-001243:mdna:15]
In the second quarter of 2022, net sales of $64.2 million were $24.6 million, or 62.1%, higher than the $39.6 million in the second quarter of 2021. In the first six months of 2022, net sales of $127.7 million were $33.6 million, or 35.7%, higher than the $94.1 million in the first six months of 2021. The increase in the second quarter and first six months of 2022 compared to the corresponding periods of 2021 was mainly due to higher product and service revenue at Doble primarily driven by the acquisitions of Altanova and Phenix, and an increase in product sales at NRG. The revenue contribution from the Altanova and Phenix acquisitions totaled $10.4 million and $25.0 million for the second quarter and first six months of 2022, respectively.

[0001410578-22-001243:mdna:16]
[same as prior period, unchanged from 0001410578-22-000098:mdna:16]

[0001410578-22-001243:mdna:17]
In the second quarter of 2022, net sales of $55.9 million were $12.1 million, or 27.6%, higher than the $43.8 million in the second quarter of 2021. In the first six months of 2022, net sales of $99.2 million were $13.9 million, or 16.3%, higher than the $85.3 million in the first six months of 2021. The increase in the second quarter of 2022 as compared to the second quarter of 2021 was primarily due to higher sales from the Company’s U.S. and Asian operations totaling $12.8 million partially offset by a $0.7 million decrease in sales from the segment’s European operations due to the timing of test and measurement chamber projects. The increase in the first six months of 2022 compared to the first six months of 2021 was due to higher sales from the Company’s Asian and U.S. operations totaling $17.3 million partially offset by a $3.4 million decrease in sales from the segment’s European operations due to the timing of test and measurement chamber projects.

[0001410578-22-001243:mdna:18]
[same as prior period, unchanged from 0001410578-22-000098:mdna:18]

[0001410578-22-001243:mdna:19]
Backlog was $670.9 million at March 31, 2022 compared with $592.0 million at September 30, 2021. The Company received new orders totaling $236.5 million in the second quarter of 2022 compared to $176.2 million in the second quarter of 2021. Of the new orders received in the second quarter of 2022, $94.6 million related to Aerospace & Defense products, $86.5 million related to USG products, and $55.4 million related to Test products. Of the new orders received in the second quarter of 2021, $88.2 million related to Aerospace & Defense products, $43.6 million related to USG products, and $44.4 million related to Test products.

[0001410578-22-001243:mdna:20]
The Company received new orders totaling $460.9 million in the first six months of 2022 compared to $333.9 million in the first six months of 2021. Of the new orders received in the first six months of 2022, $184.8 million related to Aerospace & Defense products, $152.7 million related to USG products, and $123.4 million related to Test products. Of the new orders received in the first six months of 2021, $153.6 million related to Aerospace & Defense products, $92.4 million related to USG products, and $87.9 million related to Test products.

[0001410578-22-001243:mdna:21]
[same as prior period, unchanged from 0001410578-22-000098:mdna:20]

[0001410578-22-001243:mdna:22]
Selling, general and administrative (SG&A) expenses for the second quarter of 2022 were $48.0 million (23.4% of net sales), compared with $38.7 million (23.3% of net sales) for the second quarter of 2021. For the first six months of 2022, SG&A expenses were $94.6 million (24.8% of net sales) compared to $79.7 million (24.3% of net sales) for the first six months of 2021. The increase in SG&A in the second quarter and first six months of 2022 compared to the corresponding periods of 2021 was mainly due to higher expenses at Doble as a result of the SG&A contribution from the Altanova and Phenix acquisitions and higher expenses at Corporate due to acquisition related costs and professional fees.

[0001410578-22-001243:mdna:23]
[same as prior period, unchanged from 0001410578-22-000098:mdna:22]

[0001410578-22-001243:mdna:24]
Amortization of intangible assets from continuing operations was $6.5 million and $13.0 million for the second quarter and first six months of 2022, respectively, compared to $4.9 million and $9.9 million for the corresponding periods of 2021. Amortization expenses consist of amortization of acquired intangible assets from acquisitions and other identifiable intangible assets (primarily software). The increase in amortization expense in the second quarter and first six months of 2022 compared to the corresponding periods of 2021 was mainly due to the Company’s recent acquisitions of Phenix, Altanova and NEco.

[0001410578-22-001243:mdna:25]
OTHER INCOME, NET

[0001410578-22-001243:mdna:26]
Other income, net, was $0.6 million of income in the second quarter of 2022 compared to $1.9 million of income in the second quarter of 2021. There were no individually significant items in other income, net, in the second quarter of 2022. The principal component of

[0001410578-22-001243:mdna:27]
other income, net, in the second quarter of 2021 was a gain of approximately $2 million for the final settlement on the sale of the Doble Watertown, MA building, partially offset by facility consolidation charges for the Doble Manta facility.

[0001410578-22-001243:mdna:28]
Other income, net, was $0.6 million of income in the first six months of 2022 compared to $1.9 million of income in the first six months of 2021. There were no individually significant items in other income, net, in the first six months of 2022. The principal component of other income, net, in the first six months of 2021 was a gain of approximately $2 million for the final settlement on the sale of the Doble Watertown, MA building, partially offset by facility consolidation charges for the Doble Manta facility.

[0001410578-22-001243:mdna:29]
[same as prior period, unchanged from 0001410578-22-000098:mdna:26]

[0001410578-22-001243:mdna:30]
The Company evaluates the performance of its operating segments based on EBIT, and provides EBIT on a consolidated basis, which is a non-GAAP financial measure. Please refer to the discussion of non-GAAP financial measures in Note 7 to the Consolidated Financial Statements, above. EBIT was $22.7 million (11.1% of net sales) for the second quarter of 2022 compared to $20.6 million (12.4% of net sales) for the second quarter of 2021. For the first six months of 2022, EBIT was $38.3 million (10.0% of net sales) compared to $37.7 million (11.5% of net sales) for the first six months of 2021.

[0001410578-22-001243:mdna:31]
The following table presents a reconciliation of EBIT to net earnings.

[0001410578-22-001243:mdna:32]
| ​ | ​ | Three Months Ended | ​ | Six Months Ended |
| ​ | ​ | March 31, | ​ | March 31, |
| (In thousands) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net earnings | ​ | $ | 16,583 | ​ | ​ | 15,404 | ​ | 28,107 | ​ | 28,222 |
| Plus: Interest expense, net | ​ |  | 1,020 | ​ | ​ | 432 | ​ | 1,753 | ​ | 973 |
| Plus: Income tax expense | ​ |  | 5,085 | ​ | ​ | 4,745 | ​ | 8,398 | ​ | 8,467 |
| Consolidated EBIT | ​ | $ | 22,688 | ​ | ​ | 20,581 | ​ | 38,258 | ​ | 37,662 |

[0001410578-22-001243:mdna:33]
[same as prior period, unchanged from 0001410578-22-000098:mdna:30]

[0001410578-22-001243:mdna:34]
EBIT in the second quarter of 2022 was $14.3 million (16.9% of net sales) compared to $17.0 million (20.6% of net sales) in the second quarter of 2021. EBIT in the first six months of 2022 was $24.3 million (15.7% of net sales) compared to $25.3 million (16.9% of net sales) in the first six months of 2021. The decrease in EBIT in the second quarter and first six months of 2022 compared to the corresponding periods of 2021 was mainly due to lower sales volumes at VACCO and unfavorable product mix impact at PTI and Crissair partially offset by an increase in EBIT at Westland, Mayday and Globe due to the higher sales volumes as mentioned above.  EBIT in the first six months of 2022 was negatively impacted by a $0.3 million inventory step-up charge related to the NEco acquisition. EBIT in the first six months of 2021 was negatively impacted by a $0.3 million inventory step-up charge related to the ATM acquisition.

[0001410578-22-001243:mdna:35]
-USG

[0001410578-22-001243:mdna:36]
EBIT in the second quarter of 2022 was $11.3 million (17.6% of net sales) compared to $6.7 million (17.0% of net sales) in the second quarter of 2021. EBIT in the first six months of 2022 was $24.7 million (19.3% of net sales) compared to $19.5 million (20.7% of net sales) in the first six months of 2021. The increase in EBIT in the second quarter and first six months of 2022 compared to the corresponding periods of 2021 was mainly due to the higher sales volumes at Doble and NRG as mentioned above. EBIT in the first six months of 2022 was negatively impacted by approximately $0.5 million of inventory step-up charges related to the Altanova acquisition.

[0001410578-22-001243:mdna:37]
-Test

[0001410578-22-001243:mdna:38]
EBIT in the second quarter of 2022 was $8.5 million (15.2% of net sales) compared to $5.7 million (13.0% of net sales) in the second quarter of 2021. EBIT in the first six months of 2022 was $12.5 million (12.6% of net sales) compared to $11.0 million (12.9% of net sales) in the first six months of 2021. The increase in EBIT in the second quarter and first six months of 2022 compared to the corresponding periods of 2021 was primarily due to product mix and higher margins on projects mainly from the segment’s Asian and U.S. operations.

[0001410578-22-001243:mdna:39]
[same as prior period, unchanged from 0001410578-22-000098:mdna:36]

[0001410578-22-001243:mdna:40]
Corporate costs included in EBIT were $11.5 million and $23.2 million in the second quarter and first six months of 2022, respectively, compared to $8.8 million and $18.1 million in the corresponding periods of 2021. The increase in Corporate costs in the second quarter and first six months of 2022 compared to the corresponding periods of 2021 was mainly due to the increase in amortization expense of acquired intangible assets related to the Company’s recent acquisitions of Phenix, Altanova and NEco.

[0001410578-22-001243:mdna:41]
[same as prior period, unchanged from 0001410578-22-000098:mdna:38]

[0001410578-22-001243:mdna:42]
Interest expense was $1.0 million and $1.8 million in the second quarter and first six months of 2022, respectively, and $0.4 million and $1.0 million in the corresponding periods of 2021. The increase in interest expense in the second quarter and first six months of 2022 compared to the corresponding periods of 2021 was mainly due to higher average outstanding borrowings. Average outstanding borrowings were $197 million and $190 million in the second quarter and first six months of 2022, respectively, and $23 million and $47 million in the corresponding periods of 2021.

[0001410578-22-001243:mdna:43]
[same as prior period, unchanged from 0001410578-22-000098:mdna:40]

[0001410578-22-001243:mdna:44]
The second quarter 2022 effective income tax rate was 23.5% compared to 23.5% in the second quarter of 2021. The effective income tax rate in the first six months of 2022 was 23.0% compared to 23.1% for the first six months of 2021. There were no significant or unusual items impacting the 2022 second quarter or year-to-date effective tax rate.

[0001410578-22-001243:mdna:45]
[same as prior period, unchanged from 0001410578-22-000098:mdna:42]

[0001410578-22-001243:mdna:46]
The Company’s overall financial position and liquidity remains strong. Working capital (current assets less current liabilities) increased to $235.6 million at March 31, 2022 from $191.2 million at September 30, 2021. Inventories increased by $28.0 million during this period due to a $12.6 million increase within the Test segment, a $10.2 million increase within the USG segment and a $5.2 million increase within the Aerospace & Defense segment resulting primarily from the timing of receipt of raw materials to meet anticipated demand and an increase in work in process inventories due to timing of manufacturing existing orders.

[0001410578-22-001243:mdna:47]
Net cash provided by operating activities was $23.0 million and $57.3 million in the first six months of 2022 and 2021, respectively. The decrease in net cash provided by operating activities in the first six months of 2022 as compared to the first six months of 2021 was mainly driven by higher working capital requirements.

[0001410578-22-001243:mdna:48]
Capital expenditures were $20.7 million and $13.2 million in the first six months of 2022 and 2021, respectively. The increase in the first six months of 2022 compared to the prior year period was mainly due to the purchase of the NRG building of approximately $10 million in the first quarter of 2022. In addition, the Company incurred expenditures for capitalized software of $4.7 million and $4.0 million in the first six months of 2022 and 2021, respectively.

[0001410578-22-001243:mdna:49]
[same as prior period, unchanged from 0001410578-22-000098:mdna:46]

[0001410578-22-001243:mdna:50]
[same as prior period, unchanged from 0001410578-22-000098:mdna:47]

[0001410578-22-001243:mdna:51]
Credit Facility

[0001410578-22-001243:mdna:52]
At March 31, 2022, the Company had approximately $296 million available to borrow under its bank credit facility, a $250 million increase option subject to lender approval, and $54.3 million cash on hand. At March 31, 2022, the Company had $196 million of outstanding borrowings under the credit facility in addition to outstanding letters of credit of $8.1 million. Cash flow from operations and borrowings under the Company’s credit facility are expected to meet the Company’s capital requirements and operational needs for the foreseeable future. The Company’s ability to access the additional $250 million increase option of the credit facility is subject to acceptance by participating or other outside banks.

[0001410578-22-001243:mdna:53]
[same as prior period, unchanged from 0001410578-22-000098:mdna:50]

[0001410578-22-001243:mdna:54]
During the first six months of 2022, the Company repurchased approximately 229,000 shares for approximately $18.0 million. For further information on the share repurchases during the second quarter of 2022, see Part II, Item 2 of this Report.

[0001410578-22-001243:mdna:55]
[same as prior period, unchanged from 0001410578-22-000098:mdna:52]

[0001410578-22-001243:mdna:56]
A dividend of $0.08 per share, totaling $2.1 million, was paid on October 15, 2021 to stockholders of record as of October 1, 2021. A dividend of $0.08 per share, totaling $2.1 million, was paid on January 19, 2022 to stockholders of record as of January 4, 2022. Subsequent to March 31, 2022, a quarterly dividend of $0.08 per share, totaling $2.1 million, was paid on April 19, 2022 to stockholders of record as of April 4, 2022.

[0001410578-22-001243:mdna:57]
[same as prior period, unchanged from 0001410578-22-000098:mdna:54]

[0001410578-22-001243:mdna:58]
[same as prior period, unchanged from 0001410578-22-000098:mdna:55]

[0001410578-22-001243:mdna:59]
[same as prior period, unchanged from 0001410578-22-000098:mdna:56]

[0001410578-22-001243:mdna:60]
Contingencies

[0001410578-22-001243:mdna:61]
As a normal incident of the business in which the Company is engaged, various claims, charges and litigation are asserted or commenced against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. In the opinion of Management, the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company, are adequately reserved, are covered by insurance, or would not have a material adverse effect on the Company’s results from operations, capital expenditures, or competitive position.

[0001410578-22-001243:mdna:62]
[same as prior period, unchanged from 0001410578-22-000098:mdna:59]

[0001410578-22-001243:mdna:63]
Investors are cautioned that such statements are only predictions and speak only as of the date of this Form 10-Q, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment, including but not limited to those described in Item 1A, “Risk Factors,” of the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2021, and the following: the continuing impact of

[0001410578-22-001243:mdna:64]
the COVID-19 pandemic including the impacts of known or unknown COVID-19 variants, labor shortages, facility closures, shelter in place policies or quarantines, material shortages, transportation delays, termination or delays of Company contracts and the inability of our suppliers or customers to perform, the impacts of natural disasters on the Company’s operations and those of the Company’s customers and suppliers; the timing and content of future contract awards or customer orders; the appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer contracts or orders; weakening of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties; the availability of selected acquisitions; delivery delays or defaults by customers; performance issues with key customers, suppliers and subcontractors; material changes in the costs and availability of certain raw materials; inflationary pressures on the Company’s costs of materials, components and supplies; labor disputes; changes in U.S. tax laws and regulations; other changes in laws and regulations including but not limited to changes in accounting standards and foreign taxation; changes in interest rates; costs relating to environmental matters arising from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the integration of recently acquired businesses.
