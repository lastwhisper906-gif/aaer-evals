# ESE 8-K — 0001104659-22-057524 filed 2022-05-09

## item codes, every 8-K on or before 2022-05-10

- 2022-05-09 0001104659-22-057524 — 2.02, 5.02, 7.01, 9.01
- 2022-02-08 0001104659-22-013878 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2021-12-03 0001104659-21-146361 — 4.01, 9.01 — amendment, the index does not say of what
- 2021-11-24 0001104659-21-143568 — 4.01, 9.01
- 2021-11-23 0001104659-21-142871 — 5.02, 8.01
- 2021-11-18 0001104659-21-141206 — 2.02, 7.01, 9.01
- 2021-08-09 0001104659-21-102150 — 2.02, 7.01, 9.01
- 2021-05-04 0001104659-21-060985 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2021-04-05 0001104659-21-046581 — 5.02, 9.01
- 2021-02-08 0001104659-21-013712 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2020-12-09 0001104659-20-133674 — 5.02, 9.01
- 2020-12-07 0001104659-20-132861 — 5.02, 7.01, 9.01
- 2020-11-19 0001104659-20-127352 — 2.02, 5.02, 7.01, 9.01
- 2020-08-10 0001104659-20-092734 — 2.02, 7.01, 9.01
- 2020-05-06 0001104659-20-057442 — 2.02, 7.01, 8.01, 9.01
- 2020-02-04 0001104659-20-010640 — 2.02, 5.07, 7.01, 9.01
- 2020-01-07 0001104659-20-001789 — 2.01, 9.01
- 2019-11-19 0001104659-19-065437 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2019-11-18 0001104659-19-065096 — 1.01, 2.02, 7.01, 9.01
- 2019-09-30 0001144204-19-046523 — 1.01, 1.02, 2.03, 9.01
- 2019-08-08 0001144204-19-038567 — 2.02, 7.01, 9.01
- 2019-05-07 0001144204-19-024241 — 2.02, 5.02, 7.01, 9.01
- 2019-02-07 0000866706-19-000004 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2022-05-10

- none on or before 2022-05-10

## item 2.02 — earnings release, exhibit 99.1

[0001104659-22-057524:8k_2_02:1]
EX-99.1
2
tm2214747d1_ex99-1.htm
EXHIBIT 99.1

[0001104659-22-057524:8k_2_02:2]
Exhibit 99.1

[0001104659-22-057524:8k_2_02:3]
| NEWS FROM |  |

[0001104659-22-057524:8k_2_02:4]
For more information contact:

[0001104659-22-057524:8k_2_02:5]
Kate Lowrey

[0001104659-22-057524:8k_2_02:6]
Vice President of Investor Relations

[0001104659-22-057524:8k_2_02:7]
ESCO Technologies Inc.

[0001104659-22-057524:8k_2_02:8]
(314) 213-7277

[0001104659-22-057524:8k_2_02:9]
ESCO REPORTS SECOND QUARTER FISCAL 2022 RESULTS

[0001104659-22-057524:8k_2_02:10]
- Q2 GAAP EPS $0.64 and Adjusted EPS $0.65
-

[0001104659-22-057524:8k_2_02:11]
- Q2 Sales increase 23.5% to $205 Million
-

[0001104659-22-057524:8k_2_02:12]
- $236 Million in Q2 Orders / Book-to-bill
of 1.15x -

[0001104659-22-057524:8k_2_02:13]
ST. LOUIS, May 9, 2022 – ESCO Technologies
Inc. (NYSE: ESE) (ESCO, or the Company) today reported its operating results for the second quarter ended March 31, 2022 (Q2 2022) compared
to the second quarter ended March 31, 2021 (Q2 2021).

[0001104659-22-057524:8k_2_02:14]
Operating Highlights

[0001104659-22-057524:8k_2_02:15]
|  | · | Q2 2022 GAAP EPS was $0.64 per share compared to $0.59 in Q2 2021. Q2 2022 Adjusted EPS increased $0.09 per share (16 percent) to $0.65 per share compared to $0.56 per share in Q2 2021. |

[0001104659-22-057524:8k_2_02:16]
|  | · | Q2 2022 Sales of $204.9 million increased $39.0 million (23.5 percent) compared to Q2 2021. Organic sales increased $27.3 million (16.5 percent) and recent acquisitions contributed $11.7 million (7.0 percent) of revenue in the quarter. |

[0001104659-22-057524:8k_2_02:17]
|  | · | Q2 2022 Entered Orders increased $60.2 million (34 percent) over the prior year period to $236.5 million (book-to-bill of 1.15x), resulting in record ending backlog of $671 million. |

[0001104659-22-057524:8k_2_02:18]
|  | · | Net cash provided by operating activities was $23 million YTD 2022. Operating cash flow was negatively impacted by higher inventories to support record backlogs, supply chain challenges that reduced manufacturing output, and the timing of milestone payments. |

[0001104659-22-057524:8k_2_02:19]
|  | · | Net debt (total borrowings less cash on hand) was $142 million, resulting in a 1.27x leverage ratio and $546 million in liquidity at March 31, 2022. |

[0001104659-22-057524:8k_2_02:20]
Vic Richey, Chairman and Chief Executive Officer, commented, “Our
global team delivered strong orders, sales, and earnings growth in Q2, I was particularly pleased to see increased activity from our North
American utility customers drive revenue growth and margin improvement in our USG segment. In A&D, it was also encouraging to see
our Q2 commercial aerospace revenue at the highest level since the beginning of the pandemic. Overall, the combination of meaningful organic
growth and the contribution of recent acquisitions helped us deliver record Q2 revenue of $205 million and 16 percent growth in Adjusted
EPS.

[0001104659-22-057524:8k_2_02:21]
“The quarter was not without its challenges, as supply chain
issues and wage and material cost inflation continue to present headwinds. Our teams continue to work diligently to navigate supply chain
issues and implement price increases to offset the impacts of inflation. These actions enabled us to exceed earnings expectations in the
quarter. It is through the hard work and dedication of our employees that we were able overcome these economic disruptions to support
our customers and deliver meaningfully improved operating results.

[0001104659-22-057524:8k_2_02:22]
“We continue to see strong entered orders across our commercial
aerospace, electric utility, renewables and Test end-markets. Our year-to-date orders of $461 million are up 38% over the prior year,
resulting in record backlog which gives us confidence in our ability to deliver our stated revenue and earnings goals for 2022. Our end-market
exposure is favorable and we are well-positioned to deliver profitable long-term growth and shareholder value as market demand continues
to recover.

[0001104659-22-057524:8k_2_02:23]
Segment Performance

[0001104659-22-057524:8k_2_02:24]
Aerospace & Defense (A&D)

[0001104659-22-057524:8k_2_02:25]
|  | · | Sales increased $2.3 million (3 percent) to $84.8 million in Q2 2022 from $82.5 million in Q2 2021. Commercial aerospace sales increased $7.2 million (30 percent) to $31 million, partially offset by lower Navy and industrial sales at VACCO compared to the prior year quarter. |

[0001104659-22-057524:8k_2_02:26]
|  | · | EBIT decreased $2.7 million in Q2 2022 to $14.3 million from $17.0 million in Q2 2021. Adjusted EBIT decreased $2.5 million in Q2 2022 to $14.5 million (17.1 percent margin) from $17.0 million (20.7 percent margin) in Q2 2021. The decrease in margin was driven by lower revenue at VACCO and unfavorable product mix in the aerospace business. We expect A&D’s continuing order strength and record backlog to drive revenue growth and margin expansion in the second half of the year. |

[0001104659-22-057524:8k_2_02:27]
|  | · | Entered Orders were $95 million in Q2 2022 (book-to-bill of 1.11x) compared to $88 million in Q2 2021. The order strength was driven by the continuing recovery of commercial aerospace, the 737 production ramp, increased MRO activity, and business jet orders. The 7 percent increase in orders over the prior year quarter resulted in ending backlog of $397 million. |

[0001104659-22-057524:8k_2_02:28]
Utility Solutions Group (USG)

[0001104659-22-057524:8k_2_02:29]
|  | · | Sales increased $24.6 million (62 percent) to $64.2 million in Q2 2022 from $39.6 million in Q2 2021. Doble organic sales increased $12.4 million (39.0 percent) as demand from North American utility customers rebounded sharply. In addition, Phenix and Altanova contributed $10.4 million in revenue and NRG sales increased $1.8 million (23 percent) as the strength in the renewables end-market continues. |

[0001104659-22-057524:8k_2_02:30]
|  | · | EBIT increased $4.6 million in Q2 2022 to $11.3 million from $6.7 million in Q2 2021. Adjusted EBIT increased $5.8 million in Q2 2022 to $11.3 million (17.7 percent margin) from $5.5 million (13.8 percent margin) in Q2 2021. The margin increase was primarily driven by leverage on higher revenue and price increases, partially offset by wage and material cost inflation and expenses related to the return of trade shows and customer events. |

[0001104659-22-057524:8k_2_02:31]
|  | · | Entered Orders were $86 million in Q2 2022 (book-to-bill of 1.35x). Orders increased $43 million (98 percent) over the prior year quarter and resulted in ending backlog of $117 million. Doble core electric utility orders increased $27 million (76 percent) reflecting broad strength across the product portfolio, including a large long-term contract for upgraded Doble Universal Controller™ (DUC) hardware and service, protection testing orders, and service contract renewals. Phenix and Altanova added $13 million, and NRG renewables orders increased $3 million (40 percent) compared to the prior year. |

[0001104659-22-057524:8k_2_02:32]
Test

[0001104659-22-057524:8k_2_02:33]
|  | · | Sales increased $12.1 million (28 percent) to $55.9 million in Q2 2022 from $43.8 million in Q2 2021, due to increased volume related to medical shielding, power filters, and test and measurement projects in the U.S and China. |

[0001104659-22-057524:8k_2_02:34]
|  | · | EBIT increased $2.8 million in Q2 2022 to $8.5 million (15.2 percent margin) from $5.7 million (13.0 percent margin) in Q2 2021. The increase in profitability was driven by higher volume and price increases, which more than offset material cost and wage inflation. |

[0001104659-22-057524:8k_2_02:35]
|  | · | Entered Orders were $55 million in Q2 2022 (book-to-bill of .99x) compared to $44 million in Q2 2021. The order growth was driven by domestic medical shielding and global demand for test and measurement projects. The $11 million (25 percent) increase in Q2 2022 orders resulted in an ending backlog of $157 million. |

[0001104659-22-057524:8k_2_02:36]
Share Repurchase Program

[0001104659-22-057524:8k_2_02:37]
As previously announced in our August 9, 2021 press
release, the Company’s Board of Directors approved a new stock repurchase program. During Q2 2022, the Company repurchased approximately
113,000 shares for $8 million. As of March 31, 2022, the Company has repurchased approximately 229,000 shares for $18 million.

[0001104659-22-057524:8k_2_02:38]
Dividend Payment

[0001104659-22-057524:8k_2_02:39]
The next quarterly cash dividend
of $0.08 per share will be paid on July 19, 2022 to stockholders of record on July 5, 2022.

[0001104659-22-057524:8k_2_02:40]
Board of Directors

[0001104659-22-057524:8k_2_02:41]
Effective May 4, 2022, the Company added an additional independent
director, Janice L. Hess, to the Company’s Board of Directors. She was also named to the Nominating and Corporate Governance Committee
of the Board of Directors.

[0001104659-22-057524:8k_2_02:42]
Since 2014, Ms. Hess has been the President of the Engineered Systems
Segment (ESS) and Teledyne Brown Engineering of Teledyne Technologies Incorporated (NYSE:TDY), a diversified multinational company which
provides enabling technologies for industrial growth markets that require advanced technology and high reliability. She has full responsibility
for ESS strategic positioning, growth, and profitability. Serving energy, space, maritime, and defense markets, ESS designs,
develops and delivers a diverse array of advanced technology-driven solutions, systems, products, and services for complex and harsh environments.
She previously served in a number of positions of increasing financial, operational, and executive responsibility with Teledyne from 2000
to 2014, including as ESS’s Executive Vice President and Chief Financial Officer.

[0001104659-22-057524:8k_2_02:43]
She was selected to serve on the Company’s Board on the
basis of her four decades of operational, financial, and leadership experience, her commitment to continuous improvement, and her
performance in growing traditional, adjacent, and emerging markets similar to those served by the Company, which will enable her to
assist the Board in guiding Company strategy at the highest level.

[0001104659-22-057524:8k_2_02:44]
Ms. Hess has a BSBA in Accounting from Auburn University. She holds
a Certificate in Management from the University of Virginia’s Darden Graduate School of Business, as well as a professional designation
in Advanced Government Contracting. She is a Certified Public Accountant in Alabama (inactive) and a graduate of Leadership Alabama.

[0001104659-22-057524:8k_2_02:45]
Business Outlook – 2022

[0001104659-22-057524:8k_2_02:46]
Management’s expectations for 2022 remain consistent with the
details outlined in our November 18, 2021 release.  Our 2022 guidance represents meaningful growth in sales, Adjusted EBIT, and Adjusted
EBITDA across each of the Company’s business segments.

[0001104659-22-057524:8k_2_02:47]
Our year-to-date results have generally matched
our expectations as presented in November. Consistent with prior years and our November guidance, our revenue and earnings will be more
second half weighted and reflect a significant ramp compared to the first half of the year. With solid backlog driving revenue growth
and improving margins, we are on track to deliver our stated goal for the year of adjusted earnings per share in the range of $3.10 to
$3.20. Our expectation is for Q3 Adjusted EPS in the range of  $0.84 to $0.91 per share, representing
growth of 25 to 35 percent over the prior year.

[0001104659-22-057524:8k_2_02:48]
Conference Call

[0001104659-22-057524:8k_2_02:49]
The Company will host a conference call today, May 9, at 4:00 p.m.
Central Time, to discuss the Company’s Q2 2022 results. A live audio webcast and an accompanying slide presentation will be available
on the Company’s website at https://investor.escotechnologies.com. A replay of the conference call will be available on the Company’s
website noted above or by phone (dial 1-855-859-2056 and enter the pass code 9495619).

[0001104659-22-057524:8k_2_02:50]
Forward-Looking Statements

[0001104659-22-057524:8k_2_02:51]
Statements in this press release regarding the
timing and magnitude of recovery in the Company’s end markets, the continuing impacts of COVID-19 on the Company’s
results, sales, Adjusted SG&A, Adjusted EBIT, Adjusted EBITDA, Adjusted EPS, cash flow, results of cost reduction efforts,
margins, growth, the financial success of the Company, the strength of its end markets, the outlook for the A&D, Test and USG
segments, the ability to increase shareholder value, the timing and success of acquisition efforts, internal investments in new
products and solutions, the impacts of inflation, the long-term success of the Company, and any other statements which are not
strictly historical are “forward-looking” statements within the meaning of the safe harbor provisions of the federal
securities laws.

[0001104659-22-057524:8k_2_02:52]
Investors are cautioned that such statements are
only predictions and speak only as of the date of this release, and the Company undertakes no duty to update them except as may be required
by applicable laws or regulations. The Company’s actual results in the future may differ materially from those projected in the
forward-looking statements due to risks and uncertainties that exist in the Company’s operations and business environment including
but not limited to those described in Item 1A, “Risk Factors”, of the Company’s Annual Report on Form 10-K for the fiscal
year ended September 30, 2021; the availability and acceptance of viable COVID-19 vaccines by enough of the U.S. and world’s population
to curtail the pandemic; the continuing impact of the COVID-19 pandemic and the effects of known or unknown COVID-19 variants including
labor shortages, facility closures, shelter in place policies or quarantines, material shortages, transportation delays, termination or
delays of Company contracts, and the inability of our suppliers or customers to perform; the impacts of Executive Order 14042 and other
vaccine mandates on our employees and businesses; the impacts of natural disasters on the Company’s operations and those of the
Company’s customers and suppliers; the timing and content of future contract awards or customer orders; the appropriation, allocation
and availability of Government funds; the termination for convenience of Government and other customer contracts or orders; weakening
of economic conditions in served markets; the success of the Company’s competitors; changes in customer demands or customer insolvencies;
competition; intellectual property rights; technical difficulties; the success of the Company’s acquisition efforts; delivery delays
or defaults by customers; performance issues with key customers, suppliers and subcontractors; changes in the costs and availability of
certain raw materials; labor disputes; changes in U.S. tax laws and regulations; other changes in laws and regulations including but not
limited to changes in accounting standards and foreign taxation; changes in interest rates; costs relating to environmental matters arising
from current or former facilities; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration;
and the integration of recently acquired businesses.

[0001104659-22-057524:8k_2_02:53]
Non-GAAP Financial Measures

[0001104659-22-057524:8k_2_02:54]
The financial measures EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA
and Adjusted EPS are presented in this press release. The Company defines “EBIT” as earnings before interest and taxes, “EBITDA”
as earnings before interest, taxes, depreciation and amortization, “Adjusted EBIT” and “Adjusted EBITDA” as excluding
the net impact of the items described in the attached Reconciliation of Non-GAAP Financials Measures, and “Adjusted EPS” as
GAAP earnings per share (EPS) excluding the net impact of the items described and reconciled in the attached Reconciliation of Non-GAAP
Financial Measures, which were ($0.01) per share in Q2 2022.

[0001104659-22-057524:8k_2_02:55]
EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA and
Adjusted EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management believes
EBIT, Adjusted EBIT, EBITDA and Adjusted EBITDA are useful in assessing the operational profitability of the Company’s business
segments because they exclude interest, taxes, depreciation and amortization, which are generally accounted for across the entire Company
on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company as
well as incentive compensation. The presentation of EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS provides important supplemental
information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures to supplement
their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance determined in accordance
with GAAP.

[0001104659-22-057524:8k_2_02:56]
ESCO, headquartered in St. Louis, Missouri: Manufactures
highly-engineered filtration and fluid control products for the aviation, Navy, space and process markets worldwide, as well as composite-based
products and solutions for Navy, defense and industrial customers; is the industry leader in RF shielding and EMC test products; and provides
diagnostic instruments, software and services for the benefit of industrial power users and the electric utility and renewable energy
industries. Further information regarding ESCO and its subsidiaries is available on the Company’s website at www.escotechnologies.com.

[0001104659-22-057524:8k_2_02:57]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-22-057524:8k_2_02:58]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-22-057524:8k_2_02:59]
(Dollars in thousands, except per share amounts)

[0001104659-22-057524:8k_2_02:60]
|  |  | Three Months Ended March 31, 2022 |  |  | Three Months Ended March 31, 2021 |  |
| Net Sales |  | $ | 204,928 |  |  |  | 165,894 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 128,375 |  |  |  | 103,553 |  |
| Selling, general and administrative expenses |  |  | 47,959 |  |  |  | 38,746 |  |
| Amortization of intangible assets |  |  | 6,510 |  |  |  | 4,917 |  |
| Interest expense |  |  | 1,020 |  |  |  | 432 |  |
| Other (income) expenses, net |  |  | (604 | ) |  |  | (1,903 | ) |
| Total costs and expenses |  |  | 183,260 |  |  |  | 145,745 |  |
| Earnings before income taxes |  |  | 21,668 |  |  |  | 20,149 |  |
| Income tax expense |  |  | 5,085 |  |  |  | 4,745 |  |
| Net earnings |  | $ | 16,583 |  |  |  | 15,404 |  |
| Diluted EPS: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 0.64 |  |  |  | 0.59 |  |
| Diluted - As Adjusted Basis |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 0.65 | (1) |  |  | 0.56 | (2) |
| Diluted average common shares O/S: |  |  | 26,045 |  |  |  | 26,201 |  |

[0001104659-22-057524:8k_2_02:61]
|  | (1) | Q2 2022 Adjusted EPS excludes $0.01 per share of after-tax charges associated with the NEco acquisition inventory step-up charge and Corporate acquisition related costs. |

[0001104659-22-057524:8k_2_02:62]
|  | (2) | Q2 2021 Adjusted EPS excludes $0.03 per share of after-tax income associated with the final settlement from the sale of the Doble Watertown facility partially offset by charges related to the Doble Manta facility consolidation. |

[0001104659-22-057524:8k_2_02:63]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-22-057524:8k_2_02:64]
Condensed Consolidated Statements of Operations (Unaudited)

[0001104659-22-057524:8k_2_02:65]
(Dollars in thousands, except per share amounts)

[0001104659-22-057524:8k_2_02:66]
|  |  | Six Months Ended March 31, 2022 |  |  | Six Months Ended March 31, 2021 |  |
| Net Sales |  | $ | 381,938 |  |  |  | 328,568 |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 236,680 |  |  |  | 203,175 |  |
| Selling, general and administrative expenses |  |  | 94,594 |  |  |  | 79,746 |  |
| Amortization of intangible assets |  |  | 12,977 |  |  |  | 9,865 |  |
| Interest expense |  |  | 1,753 |  |  |  | 973 |  |
| Other (income) expenses, net |  |  | (571 | ) |  |  | (1,880 | ) |
| Total costs and expenses |  |  | 345,433 |  |  |  | 291,879 |  |
| Earnings before income taxes |  |  | 36,505 |  |  |  | 36,689 |  |
| Income tax expense |  |  | 8,398 |  |  |  | 8,467 |  |
| Net earnings |  | $ | 28,107 |  |  |  | 28,222 |  |
| Diluted EPS: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 1.08 |  |  |  | 1.08 |  |
| Diluted - As Adjusted Basis |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 1.11 | (1) |  |  | 1.08 | (2) |
| Diluted average common shares O/S: |  |  | 26,098 |  |  |  | 26,192 |  |

[0001104659-22-057524:8k_2_02:67]
|  | (1) | YTD Q2 2022 Adjusted EPS excludes $0.03 per share of after-tax charges associated with the Altanova & NEco acquisition inventory step-up charges and Corporate acquisition related costs. |

[0001104659-22-057524:8k_2_02:68]
|  | (2) | YTD Q2 2021 Adjusted EPS excludes after-tax income associated with the final settlement from the sale of the Doble Watertown facility offset by charges related to the Doble Manta facility consolidation and ATM acquisition inventory step-up. |

[0001104659-22-057524:8k_2_02:69]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-22-057524:8k_2_02:70]
Condensed Business Segment Information (Unaudited)

[0001104659-22-057524:8k_2_02:71]
(Dollars in thousands)

[0001104659-22-057524:8k_2_02:72]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | Q2 2022 |  |  | Q2 2021 |  |  | Q2 2022 |  |  | Q2 2021 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 84,821 |  |  |  | 82,528 |  |  |  | 84,821 |  |  |  | 82,528 |  |
| USG |  |  | 64,191 |  |  |  | 39,555 |  |  |  | 64,191 |  |  |  | 39,555 |  |
| Test |  |  | 55,916 |  |  |  | 43,811 |  |  |  | 55,916 |  |  |  | 43,811 |  |
| Totals |  | $ | 204,928 |  |  |  | 165,894 |  |  |  | 204,928 |  |  |  | 165,894 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 14,349 |  |  |  | 17,006 |  |  |  | 14,489 |  |  |  | 17,046 |  |
| USG |  |  | 11,314 |  |  |  | 6,725 |  |  |  | 11,331 |  |  |  | 5,461 |  |
| Test |  |  | 8,494 |  |  |  | 5,688 |  |  |  | 8,494 |  |  |  | 5,688 |  |
| Corporate |  |  | (11,469 | ) |  |  | (8,838 | ) |  |  | (11,344 | ) |  |  | (8,548 | ) |
| Consolidated EBIT |  |  | 22,688 |  |  |  | 20,581 |  |  |  | 22,970 |  |  |  | 19,647 |  |
| Less: Interest expense |  |  | (1,020 | ) |  |  | (432 | ) |  |  | (1,020 | ) |  |  | (432 | ) |
| Less: Income tax expense |  |  | (5,085 | ) |  |  | (4,745 | ) |  |  | (5,150 | ) |  |  | (4,530 | ) |
| Net earnings |  | $ | 16,583 |  |  |  | 15,404 |  |  |  | 16,800 |  |  |  | 14,685 |  |

[0001104659-22-057524:8k_2_02:73]
Note 1: Adjusted net earnings were $16.8 million
in Q2 2022 which excludes $0.01 per share of after-tax charges associated with the NEco acquisition inventory step-up charge and Corporate
acquisition related costs.

[0001104659-22-057524:8k_2_02:74]
Note 2: Adjusted net earnings were $14.7 million in Q2 2021 which excludes $0.03 per share of after-tax income associated with the final settlement from the sale of the Doble Watertown facility partially offset by charges related to the Doble Manta facility consolidation.

[0001104659-22-057524:8k_2_02:75]
| EBITDA Reconciliation to Net earnings: |  |  |  |  | Adjusted |  |  | Adjusted |  |
|  |  | Q2 2022 |  |  | Q2 2021 |  |  | Q2 2022 |  |  | Q2 2021 |  |
| Consolidated EBITDA |  | $ | 34,808 |  |  |  | 30,684 |  |  |  | 35,090 |  |  |  | 29,750 |  |
| Less: Depr & Amort |  |  | (12,120 | ) |  |  | (10,103 | ) |  |  | (12,120 | ) |  |  | (10,103 | ) |
| Consolidated EBIT |  |  | 22,688 |  |  |  | 20,581 |  |  |  | 22,970 |  |  |  | 19,647 |  |
| Less: Interest expense |  |  | (1,020 | ) |  |  | (432 | ) |  |  | (1,020 | ) |  |  | (432 | ) |
| Less: Income tax expense |  |  | (5,085 | ) |  |  | (4,745 | ) |  |  | (5,150 | ) |  |  | (4,530 | ) |
| Net earnings |  | $ | 16,583 |  |  |  | 15,404 |  |  |  | 16,800 |  |  |  | 14,685 |  |

[0001104659-22-057524:8k_2_02:76]
ESCO TECHNOLOGIES INC. AND
SUBSIDIARIES

[0001104659-22-057524:8k_2_02:77]
Condensed Business Segment Information (Unaudited)

[0001104659-22-057524:8k_2_02:78]
(Dollars in thousands)

[0001104659-22-057524:8k_2_02:79]
|  |  | GAAP |  |  | As Adjusted |  |
|  |  | YTD Q2 |  |  | YTD Q2 |  |  | YTD Q2 |  |  | YTD Q2 |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 155,065 |  |  |  | 149,144 |  |  |  | 155,065 |  |  |  | 149,144 |  |
| USG |  |  | 127,676 |  |  |  | 94,095 |  |  |  | 127,676 |  |  |  | 94,095 |  |
| Test |  |  | 99,197 |  |  |  | 85,329 |  |  |  | 99,197 |  |  |  | 85,329 |  |
| Totals |  | $ | 381,938 |  |  |  | 328,568 |  |  |  | 381,938 |  |  |  | 328,568 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aerospace & Defense |  | $ | 24,304 |  |  |  | 25,266 |  |  |  | 24,639 |  |  |  | 25,626 |  |
| USG |  |  | 24,705 |  |  |  | 19,456 |  |  |  | 25,172 |  |  |  | 18,842 |  |
| Test |  |  | 12,459 |  |  |  | 11,030 |  |  |  | 12,459 |  |  |  | 11,030 |  |
| Corporate |  |  | (23,210 | ) |  |  | (18,090 | ) |  |  | (22,905 | ) |  |  | (17,740 | ) |
| Consolidated EBIT |  |  | 38,258 |  |  |  | 37,662 |  |  |  | 39,365 |  |  |  | 37,758 |  |
| Less: Interest expense |  |  | (1,753 | ) |  |  | (973 | ) |  |  | (1,753 | ) |  |  | (973 | ) |
| Less: Income tax |  |  | (8,398 | ) |  |  | (8,467 | ) |  |  | (8,653 | ) |  |  | (8,489 | ) |
| Net earnings |  | $ | 28,107 |  |  |  | 28,222 |  |  |  | 28,959 |  |  |  | 28,296 |  |

[0001104659-22-057524:8k_2_02:80]
Note 1: Adjusted net earnings were $29.0 million
in YTD Q2 2022 which excludes $0.03 per share of after-tax charges associated with the Altanova & NEco acquisition inventory step-up
charges and Corporate acquisition related costs.

[0001104659-22-057524:8k_2_02:81]
Note 2: Adjusted net earnings were $28.3 million in YTD Q2 2021 which excludes income from the final settlement on the sale of the Doble Watertown facility offset by charges related to the Doble Manta facility consolidation and ATM acquisition inventory step-up.

[0001104659-22-057524:8k_2_02:82]
| EBITDA Reconciliation to Net earnings: |  |  |  |  | Adjusted |  |  | Adjusted |  |
|  |  | YTD Q2 |  |  | YTD Q2 |  |  | YTD Q2 |  |  | YTD Q2 |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Consolidated EBITDA |  | $ | 62,550 |  |  |  | 57,777 |  |  |  | 63,657 |  |  |  | 57,873 |  |
| Less: Depr & Amort |  |  | (24,292 | ) |  |  | (20,115 | ) |  |  | (24,292 | ) |  |  | (20,115 | ) |
| Consolidated EBIT |  |  | 38,258 |  |  |  | 37,662 |  |  |  | 39,365 |  |  |  | 37,758 |  |
| Less: Interest expense |  |  | (1,753 | ) |  |  | (973 | ) |  |  | (1,753 | ) |  |  | (973 | ) |
| Less: Income tax expense |  |  | (8,398 | ) |  |  | (8,467 | ) |  |  | (8,653 | ) |  |  | (8,489 | ) |
| Net earnings |  | $ | 28,107 |  |  |  | 28,222 |  |  |  | 28,959 |  |  |  | 28,296 |  |

[0001104659-22-057524:8k_2_02:83]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-22-057524:8k_2_02:84]
Condensed Consolidated Balance Sheets (Unaudited)

[0001104659-22-057524:8k_2_02:85]
(Dollars in thousands)

[0001104659-22-057524:8k_2_02:86]
|  |  | March 31, 2022 |  |  | September 30, 2021 |  |
| Assets |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 54,324 |  |  |  | 56,232 |  |
| Accounts receivable, net |  |  | 140,497 |  |  |  | 146,341 |  |
| Contract assets |  |  | 111,453 |  |  |  | 93,771 |  |
| Inventories |  |  | 175,152 |  |  |  | 147,148 |  |
| Other current assets |  |  | 31,972 |  |  |  | 22,662 |  |
| Total current assets |  |  | 513,398 |  |  |  | 466,154 |  |
| Property, plant and equipment, net |  |  | 156,963 |  |  |  | 154,265 |  |
| Intangible assets, net |  |  | 407,203 |  |  |  | 409,250 |  |
| Goodwill |  |  | 508,406 |  |  |  | 504,853 |  |
| Operating lease assets |  |  | 30,139 |  |  |  | 31,846 |  |
| Other assets |  |  | 9,677 |  |  |  | 10,977 |  |
|  |  | $ | 1,625,786 |  |  |  | 1,577,345 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Current maturities of long-term debt |  | $ | 20,000 |  |  |  | 20,000 |  |
| Accounts payable |  |  | 71,811 |  |  |  | 56,669 |  |
| Contract liabilities |  |  | 108,629 |  |  |  | 106,045 |  |
| Other current liabilities |  |  | 77,355 |  |  |  | 92,281 |  |
| Total current liabilities |  |  | 277,795 |  |  |  | 274,995 |  |
| Deferred tax liabilities |  |  | 82,187 |  |  |  | 73,560 |  |
| Non-current operating lease liabilities |  |  | 26,302 |  |  |  | 28,032 |  |
| Other liabilities |  |  | 42,329 |  |  |  | 47,062 |  |
| Long-term debt |  |  | 176,000 |  |  |  | 134,000 |  |
| Shareholders' equity |  |  | 1,021,173 |  |  |  | 1,019,696 |  |
|  |  | $ | 1,625,786 |  |  |  | 1,577,345 |  |

[0001104659-22-057524:8k_2_02:87]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-22-057524:8k_2_02:88]
Consolidated Statements of Cash Flows (Unaudited)

[0001104659-22-057524:8k_2_02:89]
(Dollars in thousands)

[0001104659-22-057524:8k_2_02:90]
|  |  | Six Months Ended March 31, 2022 |  |  | Six Months Ended March 31, 2021 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net earnings |  | $ | 28,107 |  |  |  | 28,222 |  |
| Adjustments to reconcile net earnings to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 24,292 |  |  |  | 20,115 |  |
| Stock compensation expense |  |  | 3,428 |  |  |  | 2,745 |  |
| Changes in assets and liabilities |  |  | (41,451 | ) |  |  | 9,179 |  |
| Gain on sale of building and land |  |  | 0 |  |  |  | (1,950 | ) |
| Effect of deferred taxes |  |  | 8,627 |  |  |  | (989 | ) |
| Net cash provided by operating activities |  |  | 23,003 |  |  |  | 57,322 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Acquisition of business, net of cash acquired |  |  | (15,592 | ) |  |  | (6,684 | ) |
| Capital expenditures |  |  | (20,715 | ) |  |  | (13,153 | ) |
| Additions to capitalized software |  |  | (4,727 | ) |  |  | (3,973 | ) |
| Proceeds from sale of building and land |  |  | 0 |  |  |  | 1,950 |  |
| Net cash used by investing activities |  |  | (41,034 | ) |  |  | (21,860 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from long-term debt |  |  | 88,000 |  |  |  | 34,000 |  |
| Principal payments on long-term debt and short-term borrowings |  |  | (46,000 | ) |  |  | (74,368 | ) |
| Dividends paid |  |  | (4,150 | ) |  |  | (4,167 | ) |
| Purchases of common stock into treasury |  |  | (17,878 | ) |  |  | 0 |  |
| Other |  |  | (2,719 | ) |  |  | 0 |  |
| Net cash provided (used) by financing activities |  |  | 17,253 |  |  |  | (44,535 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (1,130 | ) |  |  | 2,166 |  |
| Net (decrease) increase in cash and cash equivalents |  |  | (1,908 | ) |  |  | (6,907 | ) |
| Cash and cash equivalents, beginning of period |  |  | 56,232 |  |  |  | 52,560 |  |
| Cash and cash equivalents, end of period |  | $ | 54,324 |  |  |  | 45,653 |  |

[0001104659-22-057524:8k_2_02:91]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-22-057524:8k_2_02:92]
Other Selected Financial Data (Unaudited)

[0001104659-22-057524:8k_2_02:93]
(Dollars in thousands)

[0001104659-22-057524:8k_2_02:94]
| Backlog And Entered Orders - Q2 2022 |  | Aerospace & Defense |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 1/1/22 |  | $ | 387,173 |  |  |  | 94,382 |  |  |  | 157,844 |  |  |  | 639,399 |  |
| Entered Orders |  |  | 94,550 |  |  |  | 86,485 |  |  |  | 55,443 |  |  |  | 236,478 |  |
| Sales |  |  | (84,821 | ) |  |  | (64,191 | ) |  |  | (55,916 | ) |  |  | (204,928 | ) |
| Ending Backlog - 3/31/22 |  | $ | 396,902 |  |  |  | 116,676 |  |  |  | 157,371 |  |  |  | 670,949 |  |

[0001104659-22-057524:8k_2_02:95]
| Backlog And Entered Orders - YTD Q2 2022 |  | Aerospace & Defense |  |  | USG |  |  | Test |  |  | Total |  |
| Beginning Backlog - 10/1/21 |  | $ | 367,216 |  |  |  | 91,631 |  |  |  | 133,176 |  |  |  | 592,023 |  |
| Entered Orders |  |  | 184,751 |  |  |  | 152,721 |  |  |  | 123,392 |  |  |  | 460,864 |  |
| Sales |  |  | (155,065 | ) |  |  | (127,676 | ) |  |  | (99,197 | ) |  |  | (381,938 | ) |
| Ending Backlog - 3/31/22 |  | $ | 396,902 |  |  |  | 116,676 |  |  |  | 157,371 |  |  |  | 670,949 |  |

[0001104659-22-057524:8k_2_02:96]
ESCO TECHNOLOGIES INC. AND SUBSIDIARIES

[0001104659-22-057524:8k_2_02:97]
Reconciliation of Non-GAAP Financial Measures (Unaudited)

[0001104659-22-057524:8k_2_02:98]
| EPS – Adjusted Basis Reconciliation – Q2 2022 |  |  |  |
| EPS – GAAP Basis – Q2 2022 |  | $ | 0.64 |  |
| Adjustments (defined below) |  |  | 0.01 |  |
| EPS – As Adjusted Basis – Q2 2022 |  | $ | 0.65 |  |

[0001104659-22-057524:8k_2_02:99]
Adjustments exclude $0.01
per share consisting of NEco acquisition inventory step-up charges and Corporate related acquisition costs in the second quarter of 2022.
The $0.01 of EPS adjustments per share consists of $282K of pre-tax charges offset by $65K of tax benefit for net impact of $217K.

[0001104659-22-057524:8k_2_02:100]
| EPS – Adjusted Basis Reconciliation – Q2 2021 |  |  |  |
| EPS GAAP Basis – Q2 2021 |  | $ | 0.59 |  |
| Adjustments (defined below) |  |  | (0.03 | ) |
| EPS – As Adjusted Basis – Q2 2021 |  | $ | 0.56 |  |

[0001104659-22-057524:8k_2_02:101]
Adjustments exclude $0.03 per share consisting
of income associated with the final settlement from the sale of the Doble Watertown facility partially offset by charges related to the
Doble Manta facility consolidation in the second quarter of 2021. The $0.03 of EPS adjustments per share consists of $934K of pre-tax
income offset by $215K of tax expense for net impact of $719K.

[0001104659-22-057524:8k_2_02:102]
| EPS – Adjusted Basis Reconciliation – YTD Q2 2022 |  |  |  |
| EPS – GAAP Basis – YTD Q2 2022 |  | $ | 1.08 |  |
| Adjustments (defined below) |  |  | 0.03 |  |
| EPS – As Adjusted Basis – YTD Q2 2022 |  | $ | 1.11 |  |

[0001104659-22-057524:8k_2_02:103]
Adjustments exclude $0.03 per share
consisting of Altanova & NEco acquisition inventory step-up charges and Corporate related acquisition costs in the first six
months of 2022. The $0.03 of EPS adjustments per share consists of $1,107K of pre-tax charges offset by $255K of tax benefit for net
impact of $852K.

## item 5.02 — body, verbatim

[0001104659-22-057524:8k_body:1]
Item 5.02

[0001104659-22-057524:8k_body:2]
Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements
of Certain Officers

[0001104659-22-057524:8k_body:3]
Election of New Director and Reclassification
of Directors

[0001104659-22-057524:8k_body:4]
On May 4, 2022 the Company’s Board of Directors, by unanimous
written consent pursuant to Section 3.1 of its Bylaws, increased the authorized size of the Board of Directors from seven to eight members
and elected Janice L. Hess, age 63, as a director to fill the vacancy thereby created. Ms. Hess was designated as a Class II Director,
to serve for a term ending at the 2025 annual meeting of shareholders. She was also named to the Nominating and Corporate Governance Committee
of the Board of Directors.

[0001104659-22-057524:8k_body:5]
Since
2014 Ms. Hess has been the President of the Engineered Systems Segment of Teledyne Technologies Incorporated (NYSE:TDY), a diversified
multinational company which provides enabling technologies for industrial growth markets that require advanced technology and high
reliability. She previously served in a number of positions of increasing financial, operational and executive responsibility with Teledyne
from 2000 to 2014, including as Engineered Systems’ Executive Vice President and Chief Financial Officer from 2007 to 2014.

[0001104659-22-057524:8k_body:6]
Serving
the energy, space, maritime and defense markets, the Engineered Systems Segment designs, develops and delivers a diverse array of advanced
technology-driven solutions, systems, products and services for complex and harsh environments. Its core business base includes
NASA, the U.S. Department of Defense and the U.S. Department of Energy. In 2021 it represented approximately 9% of Teledyne’s $4.6
billion in net sales. As President, Ms. Hess has full responsibility for the segment’s strategic positioning, growth and profitability,
and its 1,200 employees. Ms. Hess intends to retire from Teledyne at the end of July 2022.

[0001104659-22-057524:8k_body:7]
From 1984 to 2000 Ms. Hess held positions of increasing responsibility
with Intergraph Corporation (now Hexagon AB), including as Vice President, Finance and Administration and Chief Financial Officer, Computer
Systems. She has her BSBA in Accounting from Auburn University, and was a staff accountant with PricewaterhouseCoopers LLP from 1981 to
1983. She has also served on the boards of various privately-held and non-profit entities.

[0001104659-22-057524:8k_body:8]
Ms. Hess holds a Certificate in Management from the University of Virginia’s
Darden Graduate School of Business, as well as a professional designation in Advanced Government Contracting. She is a Certified Public
Accountant in Alabama (inactive) and a graduate of Leadership Alabama.

[0001104659-22-057524:8k_body:9]
Ms. Hess was selected to serve the Company on the basis of her four
decades of operational, financial and leadership experience, her commitment to continuous improvement, and her performance in growing
traditional, adjacent and emerging markets similar to those served by the Company, which will enable her to assist the board in guiding
Company strategy at the highest level.

[0001104659-22-057524:8k_body:10]
Since at least the beginning of the Company’s last fiscal year
Ms. Hess has had no reportable transactions with related persons or affiliates of the Company, and she meets all of the qualifications
of an independent director under the rules and regulations of the Securities and Exchange Commission and the New York Stock Exchange.

[0001104659-22-057524:8k_body:11]
Ms. Hess will receive compensation for her service on the Board of
Directors and its Committees pursuant to the Company’s Sub-Plan for the Compensation Plan for Non-Employee Directors adopted under
its 2018 Omnibus Incentive Plan (the “Plan”), on the same basis as the Company’s other directors; provided that as compensation
for her service during the remainder of calendar 2022 she will receive compensation prorated at 75% of the standard annual compensation,
consisting of $37,500 in cash plus an award of restricted share units valued at $135,000 based on the NYSE closing price of the Company’s
common stock on the effective grant date, with a one-year vesting requirement. Under the Plan, Ms. Hess has 30 days from the date of her
election to elect whether or not to receive all or part of her compensation on a deferred basis as provided in the Plan.
