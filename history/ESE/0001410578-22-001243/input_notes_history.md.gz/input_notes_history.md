# ESE note change history — 0001410578-22-000098 → 0001410578-22-001243


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-05-10):
[0001410578-22-001243:note_history:1]
The Company’s results for the three-month period ended March 31, 2022 are not necessarily indicative of the results for the entire 2022 fiscal year. References to the second quarters of 2022 and 2021 represent the fiscal quarters ended March 31, 2022 and 2021, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates. Certain prior period deferred revenue amounts have been reclassified to noncurrent to conform with the current year presentation.
  (was, 2022-02-09, similarity 0.8472):
[0001410578-22-000098:note_history:1]
The Company’s results for the three-month period ended December 31, 2021 are not necessarily indicative of the results for the entire 2022 fiscal year. References to the first quarters of 2022 and 2021 represent the fiscal quarters ended December 31, 2021 and 2020, respectively. The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-10):
[0001410578-22-001243:note_history:2]
| ​ |  | March 31, | ​ | September 30, |
| (In thousands) |  | 2022 |  | 2021 |
| Total borrowings | ​ | $ | 196,000 |  | 154,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 176,000 |  | 134,000 |
  (was, 2022-02-09, similarity 0.976):
[0001410578-22-000098:note_history:2]
| ​ |  | December 31, | ​ | September 30, |
| (In thousands) |  | 2021 |  | 2021 |
| Total borrowings | ​ | $ | 198,000 |  | 154,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 178,000 |  | 134,000 |

- changed (2022-05-10):
[0001410578-22-001243:note_history:3]
The Credit Facility includes a $500 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024.
  (was, 2022-02-09, similarity 0.9988):
[0001410578-22-000098:note_history:3]
The Credit Facility includes a $500 million revolving line of credit, as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of eight banks led by JP Morgan Chase Bank, N.A., as Administrative Agent. The Credit Facility matures September 27, 2024.

- changed (2022-05-10):
[0001410578-22-001243:note_history:4]
At March 31, 2022, the Company had approximately $296 million available to borrow under the Credit Facility, plus the $250 million increase option, subject to lender approval, in addition to $54.3 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of March 31, 2022, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $8.1 million at March 31, 2022.
  (was, 2022-02-09, similarity 0.9339):
[0001410578-22-000098:note_history:4]
At December 31, 2021, the Company had approximately $291 million available to borrow under the Credit Facility, plus the $250 million increase option, in addition to $55.7 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of December 31, 2021, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months. The letters of credit issued and outstanding under the Credit Facility totaled $10.7 million at December 31, 2021.

- changed (2022-05-10):
[0001410578-22-001243:note_history:5]
Interest on borrowings under the Credit Facility is calculated at a spread over either the New York Federal Reserve Bank Rate, the prime rate or the London Interbank Offered Rate (LIBOR), depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The Credit Facility is secured by the unlimited guaranty of the Company’s direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of its direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 1.29% and 1.23% for the three and six-month periods ending March 31, 2022, respectively, and 1.27% and 1.40% for the three and six-month periods ending March 31, 2021. As of March 31, 2022, the Company was in compliance with all covenants.
  (was, 2022-02-09, similarity 0.9273):
[0001410578-22-000098:note_history:5]
Interest on borrowings under the Credit Facility is calculated at a spread over either the New York Federal Reserve Bank Rate, the prime rate, or the London Interbank Offered Rate (LIBOR), depending on various factors. The Credit Facility also requires a facility fee ranging from 10 to 25 basis points per annum on the unused portion. The Credit Facility is secured by the unlimited guaranty of the Company’s direct and indirect material U.S. subsidiaries and the pledge of 100% of the equity interests of its direct and indirect material foreign subsidiaries. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. The weighted average interest rates were 1.17% and 1.45% for the three-month periods ending December 31, 2021 and 2020, respectively. As of December 31, 2021, the Company was in compliance with all covenants.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-10):
[0001410578-22-001243:note_history:6]
| ​ |  | March 31, | ​ | September 30, |
| (In thousands) |  | 2022 |  | 2021 |
| Total borrowings | ​ | $ | 196,000 |  | 154,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 176,000 |  | 134,000 |
  (was, 2022-02-09, similarity 0.976):
[0001410578-22-000098:note_history:6]
| ​ |  | December 31, | ​ | September 30, |
| (In thousands) |  | 2021 |  | 2021 |
| Total borrowings | ​ | $ | 198,000 |  | 154,000 |
| Current portion of long-term debt | ​ |  | (20,000) |  | (20,000) |
| Total long-term debt, less current portion | ​ | $ | 178,000 |  | 134,000 |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-05-10):
[0001410578-22-001243:note_history:7]
| Three months ended March 31, 2022 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total |  |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 33,562 | ​ | $ | 63,379 | ​ | $ | 51,903 | ​ | $ | 148,844 | ​ |
| U.S. Government | ​ |  | 51,259 | ​ | ​ | 812 | ​ | ​ | 4,013 | ​ |  | 56,084 | ​ |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 | ​ |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| United States | ​ | $ | 72,621 | ​ | $ | 41,458 | ​ | $ | 31,071 | ​ | $ | 145,150 | ​ |
| International | ​ |  | 12,200 | ​ | ​ | 22,733 | ​ | ​ | 24,845 | ​ |  | 59,778 | ​ |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 35,666 | ​ | $ | 51,202 | ​ | $ | 14,838 | ​ | $ | 101,706 | ​ |
| Over time | ​ |  | 49,155 | ​ | ​ | 12,989 | ​ | ​ | 41,078 | ​ |  | 103,222 | ​ |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 | ​ |
  (was, 2022-02-09, similarity 0.985):
[0001410578-22-000098:note_history:7]
| ​ | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total |  |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 28,075 | ​ | $ | 62,842 | ​ | $ | 41,037 | ​ | $ | 131,954 | ​ |
| U.S. Government | ​ |  | 42,169 | ​ | ​ | 643 | ​ | ​ | 2,244 | ​ |  | 45,056 | ​ |
| Total revenues | ​ | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 | ​ |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| United States | ​ | $ | 60,687 | ​ | $ | 38,741 | ​ | $ | 22,975 | ​ | $ | 122,403 | ​ |
| International | ​ |  | 9,557 | ​ | ​ | 24,744 | ​ | ​ | 20,306 | ​ |  | 54,607 | ​ |
| Total revenues | ​ | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 28,558 | ​ | $ | 50,835 | ​ | $ | 12,821 | ​ | $ | 92,214 | ​ |
| Over time | ​ |  | 41,686 | ​ | ​ | 12,650 | ​ | ​ | 30,460 | ​ |  | 84,796 | ​ |
| Total revenues | ​ | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 | ​ |

- changed (2022-05-10):
[0001410578-22-001243:note_history:8]
| Six months ended March 31, 2022 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 61,489 | ​ | $ | 126,221 | ​ | $ | 92,941 | ​ | $ | 280,651 |
| U.S. Government | ​ |  | 93,576 | ​ |  | 1,455 | ​ |  | 6,256 | ​ |  | 101,287 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 133,313 | ​ | $ | 80,199 | ​ | $ | 54,047 | ​ | $ | 267,559 |
| International | ​ |  | 21,752 | ​ |  | 47,477 | ​ |  | 45,150 | ​ |  | 114,379 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 64,223 | ​ | $ | 102,037 | ​ | $ | 27,660 | ​ | $ | 193,920 |
| Over time | ​ |  | 90,842 | ​ |  | 25,639 | ​ |  | 71,537 | ​ |  | 188,018 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |
  (was, 2022-02-09, similarity 0.9848):
[0001410578-22-000098:note_history:8]
| ​ | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 27,604 | ​ | $ | 53,864 | ​ | $ | 36,722 | ​ | $ | 118,190 |
| U.S. Government | ​ |  | 39,012 | ​ |  | 676 | ​ |  | 4,796 | ​ |  | 44,484 |
| Total revenues | ​ | $ | 66,616 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,674 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 57,538 | ​ | $ | 37,045 | ​ | $ | 23,266 | ​ | $ | 117,849 |
| International | ​ |  | 9,078 | ​ |  | 17,495 | ​ |  | 18,252 | ​ |  | 44,825 |
| Total revenues | ​ | $ | 66,616 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,674 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 26,946 | ​ | $ | 42,367 | ​ | $ | 8,868 | ​ | $ | 78,181 |
| Over time | ​ |  | 39,670 | ​ |  | 12,173 | ​ |  | 32,650 | ​ |  | 84,493 |
| Total revenues | ​ | $ | 66,616 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,674 |

- changed (2022-05-10):
[0001410578-22-001243:note_history:9]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2021 are presented in the tables below.
  (was, 2022-02-09, similarity 0.935):
[0001410578-22-000098:note_history:9]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2020 are presented in the table below:

- added (2022-05-10):
[0001410578-22-001243:note_history:10]
| Three months ended March 31, 2021 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial |  | $ | 33,223 |  | $ | 38,549 |  | $ | 39,305 |  | $ | 111,077 |
| U.S. Government | ​ | ​ | 49,305 | ​ | ​ | 1,006 | ​ | ​ | 4,506 | ​ | ​ | 54,817 |
| Total revenues |  | $ | 82,528 |  | $ | 39,555 |  | $ | 43,811 |  | $ | 165,894 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States |  | $ | 72,287 |  | $ | 27,445 |  | $ | 22,965 |  | $ | 122,697 |
| International | ​ | ​ | 10,241 | ​ | ​ | 12,110 | ​ | ​ | 20,846 | ​ | ​ | 43,197 |
| Total revenues |  | $ | 82,528 |  | $ | 39,555 |  | $ | 43,811 |  | $ | 165,894 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time |  | $ | 37,127 |  | $ | 27,563 |  | $ | 9,248 |  | $ | 73,938 |
| Over time | ​ | ​ | 45,401 | ​ | ​ | 11,992 | ​ | ​ | 34,563 | ​ | ​ | 91,956 |
| Total revenues |  | $ | 82,528 |  | $ | 39,555 |  | $ | 43,811 |  | $ | 165,894 |

- added (2022-05-10):
[0001410578-22-001243:note_history:11]
| Six months ended March 31, 2021 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial |  | $ | 61,089 |  | $ | 92,414 |  | $ | 76,027 |  | $ | 229,530 |
| U.S. Government | ​ | ​ | 88,055 | ​ | ​ | 1,681 | ​ | ​ | 9,302 | ​ | ​ | 99,038 |
| Total revenues |  | $ | 149,144 |  | $ | 94,095 |  | $ | 85,329 |  | $ | 328,568 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States |  | $ | 129,824 |  | $ | 64,490 |  | $ | 46,231 |  | $ | 240,545 |
| International | ​ | ​ | 19,320 | ​ | ​ | 29,605 | ​ | ​ | 39,098 | ​ | ​ | 88,023 |
| Total revenues |  | $ | 149,144 |  | $ | 94,095 |  | $ | 85,329 |  | $ | 328,568 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time |  | $ | 64,000 |  | $ | 69,931 |  | $ | 18,116 |  | $ | 152,047 |
| Over time | ​ | ​ | 85,144 | ​ | ​ | 24,164 | ​ | ​ | 67,213 | ​ | ​ | 176,521 |
| Total revenues |  | $ | 149,144 |  | $ | 94,095 |  | $ | 85,329 |  | $ | 328,568 |

- removed (2022-05-10):
[0001410578-22-000098:note_history:12]
Revenue Recognition

- removed (2022-05-10):
[0001410578-22-000098:note_history:13]
Payment terms with our customers vary by the type and location of the customer and the products or services offered. Arrangements with customers that include payment terms extending beyond one year are not significant. The transaction price for these contracts reflects our estimate of returns and discounts, which are based on historical, current and forecasted information to determine the expected amount to which we will be entitled in exchange for transferring the promised goods or services to the customer. The realization of variable consideration occurs within a short period of time from product delivery; therefore, the time value of money effect is not significant. We primarily provide standard warranty programs for products in our commercial businesses for periods that typically range from one to two years. These assurance-type programs typically cannot be purchased separately and do not meet the criteria to be considered a performance obligation. Under the typical payment terms of our long term fixed price contracts, the customer pays us either performance-based or progress payments. Performance-based payments represent interim payments based on quantifiable measures of performance or on the achievement of specified events or milestones. Progress payments are interim payments of costs incurred as the work progresses.

- removed (2022-05-10):
[0001410578-22-000098:note_history:14]
For our overtime revenue recognized using the output method of costs incurred, contract cost is estimated utilizing current contract specifications and expected engineering requirements. Contract costs typically are incurred over a period of several months to one or more years, and the estimation of these costs requires judgment. Our cost estimation process is based on the professional knowledge and experience of engineers and program managers along with finance professionals. We review and update our projections of costs quarterly or more frequently when circumstances significantly change. In addition, in the USG segment, we recognize revenue as a series of distinct services based on each day of providing services (straight-line over the contract term) for certain of our USG segment contracts. Under the typical payment terms of our service contracts, the customer pays us in advance of when services are performed. In addition, in the Test segment, we use milestones to measure progress for our Test segment contracts because it best depicts the transfer of control to the customer that occurs as we incur costs on our contracts.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-05-10):
[0001410578-22-001243:note_history:15]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2022 are presented in the tables below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The tables below also include a reconciliation of the disaggregated revenue within each reportable segment.
  (was, 2022-02-09, similarity 0.953):
[0001410578-22-000098:note_history:15]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2021 are presented in the table below as the Company deems it best depicts how the nature, amount, timing and uncertainty of net sales and cash flows are affected by economic factors. The table below also includes a reconciliation of the disaggregated revenue within each reportable segment.

- changed (2022-05-10):
[0001410578-22-001243:note_history:16]
| Three months ended March 31, 2022 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total |  |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 33,562 | ​ | $ | 63,379 | ​ | $ | 51,903 | ​ | $ | 148,844 | ​ |
| U.S. Government | ​ |  | 51,259 | ​ | ​ | 812 | ​ | ​ | 4,013 | ​ |  | 56,084 | ​ |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 | ​ |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| United States | ​ | $ | 72,621 | ​ | $ | 41,458 | ​ | $ | 31,071 | ​ | $ | 145,150 | ​ |
| International | ​ |  | 12,200 | ​ | ​ | 22,733 | ​ | ​ | 24,845 | ​ |  | 59,778 | ​ |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 35,666 | ​ | $ | 51,202 | ​ | $ | 14,838 | ​ | $ | 101,706 | ​ |
| Over time | ​ |  | 49,155 | ​ | ​ | 12,989 | ​ | ​ | 41,078 | ​ |  | 103,222 | ​ |
| Total revenues | ​ | $ | 84,821 | ​ | $ | 64,191 | ​ | $ | 55,916 | ​ | $ | 204,928 | ​ |
  (was, 2022-02-09, similarity 0.985):
[0001410578-22-000098:note_history:16]
| ​ | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) | ​ | & Defense | ​ | USG | ​ | Test | ​ | Total |  |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial | ​ | $ | 28,075 | ​ | $ | 62,842 | ​ | $ | 41,037 | ​ | $ | 131,954 | ​ |
| U.S. Government | ​ |  | 42,169 | ​ | ​ | 643 | ​ | ​ | 2,244 | ​ |  | 45,056 | ​ |
| Total revenues | ​ | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 | ​ |
| Geographic location: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| United States | ​ | $ | 60,687 | ​ | $ | 38,741 | ​ | $ | 22,975 | ​ | $ | 122,403 | ​ |
| International | ​ |  | 9,557 | ​ | ​ | 24,744 | ​ | ​ | 20,306 | ​ |  | 54,607 | ​ |
| Total revenues | ​ | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 | ​ |
| Revenue recognition method: | ​ |  | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  | ​ | ​ |
| Point in time | ​ | $ | 28,558 | ​ | $ | 50,835 | ​ | $ | 12,821 | ​ | $ | 92,214 | ​ |
| Over time | ​ |  | 41,686 | ​ | ​ | 12,650 | ​ | ​ | 30,460 | ​ |  | 84,796 | ​ |
| Total revenues | ​ | $ | 70,244 | ​ | $ | 63,485 | ​ | $ | 43,281 | ​ | $ | 177,010 | ​ |

- changed (2022-05-10):
[0001410578-22-001243:note_history:17]
| Six months ended March 31, 2022 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 61,489 | ​ | $ | 126,221 | ​ | $ | 92,941 | ​ | $ | 280,651 |
| U.S. Government | ​ |  | 93,576 | ​ |  | 1,455 | ​ |  | 6,256 | ​ |  | 101,287 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 133,313 | ​ | $ | 80,199 | ​ | $ | 54,047 | ​ | $ | 267,559 |
| International | ​ |  | 21,752 | ​ |  | 47,477 | ​ |  | 45,150 | ​ |  | 114,379 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 64,223 | ​ | $ | 102,037 | ​ | $ | 27,660 | ​ | $ | 193,920 |
| Over time | ​ |  | 90,842 | ​ |  | 25,639 | ​ |  | 71,537 | ​ |  | 188,018 |
| Total revenues | ​ | $ | 155,065 | ​ | $ | 127,676 | ​ | $ | 99,197 | ​ | $ | 381,938 |
  (was, 2022-02-09, similarity 0.9848):
[0001410578-22-000098:note_history:17]
| ​ | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: |  | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |
| Commercial | ​ | $ | 27,604 | ​ | $ | 53,864 | ​ | $ | 36,722 | ​ | $ | 118,190 |
| U.S. Government | ​ |  | 39,012 | ​ |  | 676 | ​ |  | 4,796 | ​ |  | 44,484 |
| Total revenues | ​ | $ | 66,616 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,674 |
| Geographic location: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| United States | ​ | $ | 57,538 | ​ | $ | 37,045 | ​ | $ | 23,266 | ​ | $ | 117,849 |
| International | ​ |  | 9,078 | ​ |  | 17,495 | ​ |  | 18,252 | ​ |  | 44,825 |
| Total revenues | ​ | $ | 66,616 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,674 |
| Revenue recognition method: | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ | ​ |  | ​ |
| Point in time | ​ | $ | 26,946 | ​ | $ | 42,367 | ​ | $ | 8,868 | ​ | $ | 78,181 |
| Over time | ​ |  | 39,670 | ​ |  | 12,173 | ​ |  | 32,650 | ​ |  | 84,493 |
| Total revenues | ​ | $ | 66,616 | ​ | $ | 54,540 | ​ | $ | 41,518 | ​ | $ | 162,674 |

- changed (2022-05-10):
[0001410578-22-001243:note_history:18]
Revenues by customer type, geographic location, and revenue recognition method for the three and six-month periods ended March 31, 2021 are presented in the tables below.
  (was, 2022-02-09, similarity 0.935):
[0001410578-22-000098:note_history:18]
Revenues by customer type, geographic location, and revenue recognition method for the three-month period ended December 31, 2020 are presented in the table below:

- added (2022-05-10):
[0001410578-22-001243:note_history:19]
| Three months ended March 31, 2021 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ |  |  | ​ |  |  | ​ |  |  | ​ |  |  |
| Commercial |  | $ | 33,223 |  | $ | 38,549 |  | $ | 39,305 |  | $ | 111,077 |
| U.S. Government | ​ | ​ | 49,305 | ​ | ​ | 1,006 | ​ | ​ | 4,506 | ​ | ​ | 54,817 |
| Total revenues |  | $ | 82,528 |  | $ | 39,555 |  | $ | 43,811 |  | $ | 165,894 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States |  | $ | 72,287 |  | $ | 27,445 |  | $ | 22,965 |  | $ | 122,697 |
| International | ​ | ​ | 10,241 | ​ | ​ | 12,110 | ​ | ​ | 20,846 | ​ | ​ | 43,197 |
| Total revenues |  | $ | 82,528 |  | $ | 39,555 |  | $ | 43,811 |  | $ | 165,894 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time |  | $ | 37,127 |  | $ | 27,563 |  | $ | 9,248 |  | $ | 73,938 |
| Over time | ​ | ​ | 45,401 | ​ | ​ | 11,992 | ​ | ​ | 34,563 | ​ | ​ | 91,956 |
| Total revenues |  | $ | 82,528 |  | $ | 39,555 |  | $ | 43,811 |  | $ | 165,894 |

- added (2022-05-10):
[0001410578-22-001243:note_history:20]
| Six months ended March 31, 2021 | ​ | Aerospace | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |  |
| (In thousands) |  | & Defense |  | USG |  | Test |  | Total |
| Customer type: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Commercial |  | $ | 61,089 |  | $ | 92,414 |  | $ | 76,027 |  | $ | 229,530 |
| U.S. Government | ​ | ​ | 88,055 | ​ | ​ | 1,681 | ​ | ​ | 9,302 | ​ | ​ | 99,038 |
| Total revenues |  | $ | 149,144 |  | $ | 94,095 |  | $ | 85,329 |  | $ | 328,568 |
| Geographic location: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| United States |  | $ | 129,824 |  | $ | 64,490 |  | $ | 46,231 |  | $ | 240,545 |
| International | ​ | ​ | 19,320 | ​ | ​ | 29,605 | ​ | ​ | 39,098 | ​ | ​ | 88,023 |
| Total revenues |  | $ | 149,144 |  | $ | 94,095 |  | $ | 85,329 |  | $ | 328,568 |
| Revenue recognition method: | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ | ​ |
| Point in time |  | $ | 64,000 |  | $ | 69,931 |  | $ | 18,116 |  | $ | 152,047 |
| Over time | ​ | ​ | 85,144 | ​ | ​ | 24,164 | ​ | ​ | 67,213 | ​ | ​ | 176,521 |
| Total revenues |  | $ | 149,144 |  | $ | 94,095 |  | $ | 85,329 |  | $ | 328,568 |

- changed (2022-05-10):
[0001410578-22-001243:note_history:21]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At March 31, 2022, the Company had $670.9 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 77% in the next twelve months.
  (was, 2022-02-09, similarity 0.9907):
[0001410578-22-000098:note_history:21]
Remaining performance obligations, which is the equivalent of backlog, represent the expected transaction price allocated to contracts that the Company expects to recognize as revenue in future periods when the Company performs under the contracts. These remaining obligations include amounts that have been formally appropriated under contracts with the U.S. Government, and exclude unexercised contract options and potential orders under ordering-type contracts such as Indefinite Delivery, Indefinite Quantity contracts. At December 31, 2021, the Company had $639.4 million in remaining performance obligations of which the Company expects to recognize revenues of approximately 77% in the next twelve months.

- added (2022-05-10):
[0001410578-22-001243:note_history:22]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred. At March 31, 2022, contract assets and liabilities totaled

- changed (2022-05-10):
[0001410578-22-001243:note_history:23]
$111.5 million and $113.0 million, respectively. During the first six months of 2022, the Company recognized approximately $51 million in revenues that were included in the contract liabilities balance at September 30, 2021. The increase in net contract assets in the first six months of 2022 was due to revenue being recognized for performance completed during the period that exceeded customer billings. Other factors that impacted the change in net contract liabilities were immaterial. At October 1, 2020, contract assets and liabilities totaled $94.3 million and $100.6 million, respectively.
  (was, 2022-02-09, similarity 0.664):
[0001410578-22-000098:note_history:23]
Assets and liabilities related to contracts with customers are reported on a contract-by-contract basis at the end of each reporting period. Because of the timing difference of revenue recognition and customer billing, these contracts will often result in revenue recognized in excess of billings and billings in excess of costs incurred. At December 31, 2021, contract assets and liabilities totaled $100.9 million and $111.6 million, respectively. During the first quarter of 2022, the Company recognized approximately $29 million in revenues that were included in the contract liabilities balance at September 30, 2021. The increase in net contract assets in the first quarter of 2022 was due to revenue being recognized for performance completed during the period that exceeded customer billings. Other factors that impacted the change in net contract liabilities were immaterial. At October 1, 2020, contract assets and liabilities totaled $94.3 million and $100.6 million, respectively.
