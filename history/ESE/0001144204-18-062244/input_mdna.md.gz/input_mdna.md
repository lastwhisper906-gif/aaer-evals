# ESE MD&A — 0001144204-18-062244


## mdna

[0001144204-18-062244:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial
Condition and Results of Operations

[0001144204-18-062244:mdna:2]
The following discussion should be read in conjunction with the
Consolidated Financial Statements included herein and Notes thereto and refers to the Company’s results from continuing operations,
except where noted.

[0001144204-18-062244:mdna:3]
Introduction

[0001144204-18-062244:mdna:4]
ESCO Technologies Inc. and its wholly owned subsidiaries (the Company)
are organized into four operating segments for financial reporting purposes: Filtration/Fluid Flow (Filtration), RF Shielding and
Test (Test), Utility Solutions Group (USG), and Technical Packaging. The Company’s business segments are comprised of the
following primary operating entities:

[0001144204-18-062244:mdna:5]
| · | Filtration: PTI Technologies Inc. (PTI); VACCO Industries (VACCO); Crissair, Inc. (Crissair); Westland Technologies, Inc. (Westland); and Mayday Manufacturing Co. (Mayday) and its affiliate Hi-Tech Metals, Inc. (Hi-Tech). |

[0001144204-18-062244:mdna:6]
| · | Test: ETS-Lindgren Inc. (ETS-Lindgren). |

[0001144204-18-062244:mdna:7]
| · | USG: Doble Engineering Company (Doble); Morgan Schaffer Ltd. (Morgan Schaffer); and NRG Systems, Inc. (NRG). |

[0001144204-18-062244:mdna:8]
| · | Technical Packaging: Thermoform Engineered Quality LLC (TEQ); Plastique Limited and Plastique Sp. z o.o. (together, Plastique). |

[0001144204-18-062244:mdna:9]
|  | 18 |  |

[0001144204-18-062244:mdna:10]
Filtration.
PTI, VACCO and Crissair primarily design and manufacture specialty filtration products, including hydraulic filter elements and
fluid control devices used in commercial aerospace applications, unique filter mechanisms used in micro-propulsion devices for
satellites and custom designed filters for manned aircraft and submarines. Westland designs, develops and manufactures elastomeric-based
signature reduction solutions for U.S. naval vessels. Mayday designs and manufactures mission-critical bushings, pins, sleeves
and precision-tolerance machined components for landing gear, rotor heads, engine mounts, flight controls, and actuation systems
for the aerospace and defense industries. Hi-Tech is a full-service metal processor serving aerospace suppliers.

[0001144204-18-062244:mdna:11]
Test.
ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and contain magnetic, electromagnetic
and acoustic energy.

[0001144204-18-062244:mdna:12]
USG.
Doble provides high-end, intelligent diagnostic test solutions for the electric power delivery industry and is a leading supplier
of power factor and partial discharge testing instruments used to assess the integrity of high-voltage power delivery equipment.
Morgan Schaffer provides an integrated offering of dissolved gas analysis, oil testing, and data management solutions which enhance
the ability of electric utilities to accurately monitor the health of critical power transformers. NRG designs and manufactures
decision support tools for the renewable energy industry, primarily wind.

[0001144204-18-062244:mdna:13]
Technical
Packaging. The companies within this segment provide innovative solutions to the medical and commercial markets
for thermoformed and precision molded pulp fiber packages and specialty products using a wide variety of thin gauge plastics and
pulp.

[0001144204-18-062244:mdna:14]
Selected financial information for each of the Company’s business
segments is provided in the discussion below and in Note 13 to the Company’s Consolidated Financial Statements beginning
on page F-1 of this Annual Report.

[0001144204-18-062244:mdna:15]
The Company continues to operate with meaningful growth prospects
in its primary served markets and with considerable financial flexibility. The Company continues to focus on new products that
incorporate proprietary design and process technologies. Management is committed to delivering shareholder value through organic
growth, ongoing performance improvement initiatives, and acquisitions.

[0001144204-18-062244:mdna:16]
Highlights of 2018 Operations

[0001144204-18-062244:mdna:17]
| · | Sales, net earnings and diluted earnings per share in 2018 were $771.6 million, $92.1 million and $3.54 per share, respectively, compared to sales, net earnings and diluted earnings per share in 2017 of $685.7 million, $53.7 million and $2.07 per share, respectively. |

[0001144204-18-062244:mdna:18]
| · | Diluted EPS – As Adjusted for 2018 was $2.77 and excludes $4.8 million of pretax charges (or $0.17 per share after tax) consisting primarily of charges related to closing the Doble offices in Norway, China, Dubai and Mexico, consisting of employee severance and compensation benefits, professional fees, and asset impairment charges; and restructuring charges at PTI related to the exit of the low margin industrial/automotive market. Also excluded was a $24.4 million (or $0.94 per share) of net tax benefit recorded resulting from the implementation of U.S. Tax Reform in 2018. Diluted EPS – As Adjusted for 2017 was $2.22 and excludes $6.1 million of pretax charges (or $0.15 per share after tax) of non-cash purchase accounting inventory step-up charges and costs incurred to complete the Company’s 2017 acquisitions. |

[0001144204-18-062244:mdna:19]
| · | Net cash provided by operating activities was approximately $93.2 million in 2018 compared to $67.3 million in 2017, mainly due to the increase in net earnings. |

[0001144204-18-062244:mdna:20]
| · | At September 30, 2018, cash on hand was $30.5 million and outstanding debt was $220.0 million, for a net debt position (total debt less net cash) of approximately $189.5 million. |

[0001144204-18-062244:mdna:21]
| · | Entered orders for 2018 were $777.2 million resulting in a book-to-bill ratio of 1.01x. Backlog at September 30, 2018 was $382.8 million compared to $377.1 million at September 30, 2017. |

[0001144204-18-062244:mdna:22]
| · | In March 2018, the Company acquired the assets of Manta Test Systems Ltd. (Manta), a North American utility solutions provider located in Mississauga, Ontario, for a purchase price of $9.5 million in cash. Since the date of acquisition, the operating results for Manta have been included as a product line of Doble within the Company’s USG segment. |

[0001144204-18-062244:mdna:23]
| · | The Company declared dividends of $0.32 per share during 2018, totaling $8.3 million in dividend payments. |

[0001144204-18-062244:mdna:24]
|  | 19 |  |

[0001144204-18-062244:mdna:25]
Results of Operations

[0001144204-18-062244:mdna:26]
Net Sales

[0001144204-18-062244:mdna:27]
|  |  |  |  |  |  |  |  |  |  |  | Change |  |  | Change |  |
|  |  | Fiscal year ended |  |  | 2018 |  |  | 2017 |  |
| (Dollars in millions) |  | 2018 |  |  | 2017 |  |  | 2016 |  |  | vs. 2017 |  |  | vs. 2016 |  |
| Filtration |  | $ | 286.8 |  |  |  | 279.5 |  |  |  | 207.8 |  |  |  | 2.6 | % |  |  | 34.5 | % |
| Test |  |  | 182.9 |  |  |  | 160.9 |  |  |  | 161.5 |  |  |  | 13.7 | % |  |  | (0.4 | )% |
| USG |  |  | 214.0 |  |  |  | 162.4 |  |  |  | 127.8 |  |  |  | 31.8 | % |  |  | 27.1 | % |
| Technical Packaging |  |  | 87.9 |  |  |  | 82.9 |  |  |  | 74.4 |  |  |  | 6.0 | % |  |  | 11.4 | % |
| Total |  | $ | 771.6 |  |  |  | 685.7 |  |  |  | 571.5 |  |  |  | 12.5 | % |  |  | 20.0 | % |

[0001144204-18-062244:mdna:28]
Net sales increased $85.9 million, or 12.5%, to $771.6 million in

[0001144204-18-062244:mdna:29]
|  | 20 |  |

[0001144204-18-062244:mdna:30]
18 from $685.7 million in 2017. The increase in net sales in 2018 as compared to 2017 was due to a $51.6 million increase in
the USG segment, a $22.0 million increase in the Test segment, a $7.3 million increase in the Filtration segment, and a $5.0 million
increase in the Technical Packaging segment.

[0001144204-18-062244:mdna:31]
Net sales increased $114.2 million, or 20.0%, to $685.7 million
in 2017 from $571.5 million in 2016. The increase in net sales in 2017 as compared to 2016 was due to a $71.7 million increase
in the Filtration segment, a $34.6 million increase in the USG segment and an $8.5 million increase in the Technical Packaging
segment, partially offset by a $0.6 million decrease in the Test segment.

[0001144204-18-062244:mdna:32]
Filtration.

[0001144204-18-062244:mdna:33]
The $7.3 million, 2.6% increase in net sales in 2018 as compared
to 2017 was mainly due to a $12.1 million increase in net sales at Mayday (acquired in November 2016) and a $3.3 million increase
in net sales at Crissair both due to higher aerospace shipments, partially offset by a $7.4 million decrease in net sales at PTI
due to lower aerospace assembly and industrial/automotive shipments.

[0001144204-18-062244:mdna:34]
The $71.7 million, or 34.5% increase in net sales in 2017 as compared
to 2016 was primarily driven by the Company’s acquisitions of Westland and Mayday, which contributed $

[0001144204-18-062244:mdna:35]
|  | 21 |  |

[0001144204-18-062244:mdna:36]
.0 million and $40.0 million, respectively; and a $12.4 million increase at VACCO due to higher shipments
of its defense products including Navy spares, partially offset by a $2.4 million decrease in sales at Crissair due to lower aerospace
shipments.

[0001144204-18-062244:mdna:37]
Test.

[0001144204-18-062244:mdna:38]
The net sales increase of $22.0 million, or 13.7% in 2018 as
compared to 2017 was mainly due a $17.0 million increase in net sales from the segment’s U.S. operations and a $3.8
million increase in net sales from the segment’s Asian operations both due to increased shipments of test and
measurement chamber projects.

[0001144204-18-062244:mdna:39]
The net sales decrease of $0.6 million in 2017 as compared to
2016 was mainly due to a $6.4 million decrease in net sales from the segment’s European operations due to the 2016
restructuring activities to close the Test business operating facilities in Germany and England, offset by a $7.5 million
increase in net sales from its U.S. operations related to higher sales volumes of chamber projects.

[0001144204-18-062244:mdna:40]
USG.

[0001144204-18-062244:mdna:41]
The net sales increase of $51.6 million, or 31.8% in 2018 as compared
to 2017 was mainly due to the Company’s acquisitions of NRG, Morgan Schaffer, and Vanguard Instruments, which contributed $21.2 million, $19.7 million and $11.9 million, respectively.

[0001144204-18-062244:mdna:42]
The net sales increase of $34.6 million, or 27.1% in 2017 as
compared to 2016 was mainly driven by the Company’s acquisitions of NRG and Morgan Schaffer, which contributed $16.2
million and $6.5 million, respectively; and an $11.9 million increase in net sales at Doble from new products and software
solutions.

[0001144204-18-062244:mdna:43]
Technical Packaging.

[0001144204-18-062244:mdna:44]
The $5.0 million, or 6.0%, increase in net sales in 2018 as compared
to 2017 was mainly due to the $2.7 million increase in sales from Plastique driven by fluctuations in currency and a $2.3 million
increase in net sales from TEQ due to higher shipments to medical customers.

[0001144204-18-062244:mdna:45]
20

[0001144204-18-062244:mdna:46]
The $8.5 million, or 11.4%, increase in net sales in 2017 as compared
to 2016 was mainly due to the $9.3 million increase in sales contribution from Plastique which was acquired in January 2016 partially
offset by a $0.8 million decrease in net sales from TEQ due to lower shipments to medical customers.

[0001144204-18-062244:mdna:47]
Orders and Backlog

[0001144204-18-062244:mdna:48]
New orders received in 2018 were $777.2 million as compared to $736.6
million in 2017, resulting in order backlog of $382.8 million at September 30, 2018 as compared to order backlog of $377.1 million
at September 30, 2017. Orders are entered into backlog as firm purchase order commitments are received.

[0001144204-18-062244:mdna:49]
In 2018, the Company recorded $287.9 million of orders related to
Filtration products, $190.4 million of orders related to Test products, $219.1 million of orders related to USG products and $79.8
million of orders related to Technical Packaging products. In 2017, the Company recorded $286.8 million of orders related to Filtration
products, $198.6 million of orders related to Test products, $164.3 million of orders related to USG products and $86.9 million
of orders related to Technical Packaging products.

[0001144204-18-062244:mdna:50]
Selling, General and Administrative Expenses

[0001144204-18-062244:mdna:51]
Selling, general and administrative (SG&A) expenses were $162.4
million, or 21.0% of net sales, in 2018; $148.4 million, or 21.6% of net sales, in 2017; and $131.5 million, or 23.0% of net sales,
in 2016.

[0001144204-18-062244:mdna:52]
The increase in SG&A expenses in 2018 as compared to 2017 was
mainly due to an increase in SG&A expenses within the USG segment due to the Company’s recent acquisitions (NRG, Morgan
Schaffer, Vanguard Instruments and Manta) as well as additional sales and marketing expenses at Doble, and higher professional
fees and headcount expenses at Corporate.

[0001144204-18-062244:mdna:53]
The increase in SG&A expenses in 2017 as compared to 2016 was
mainly due to an increase in SG&A expenses both within the Filtration segment (due to the acquisitions of Mayday and Westland,
which contributed $9.3 million to the increase) and the USG segment (due to the acquisitions of NRG and Morgan Schaffer, which
contributed $6.9 million to the increase, as well as additional sales and marketing expenses at Doble), partially offset by a decrease
in SG&A expenses in the Test segment (as a result of the 2016 restructuring activities).

[0001144204-18-062244:mdna:54]
Amortization of Intangible Assets

[0001144204-18-062244:mdna:55]
Amortization of intangible assets was $18.3 million in 2018, $16.3
million in 2017 and $11.6 million in 2016. Amortization of intangible assets included $10.9 million, $8.6 million and $4.9 million
of amortization of acquired intangible assets in 2018, 2017 and 2016, respectively, related to the Company’s acquisitions.
The amortization of acquired intangible assets related to the Company’s acquisitions is included in the Corporate operating
segment’s results. The remaining amortization expenses relate to other identifiable intangible assets (primarily software,
patents and licenses), which are included in the respective segment’s operating results. The increase in amortization expense
in 2018 as compared to 2017 was mainly due to an increase in amortization of intangibles related to the Company’s recent
acquisitions. The increase in amortization expense in 2017 as compared to 2016 was mainly due to the amortization of intangibles
related to the Company’s acquisitions and an increase in software amortization.

[0001144204-18-062244:mdna:56]
Other Expenses or Income, Net

[0001144204-18-062244:mdna:57]
Other expenses, net, were $3.7 million in 2018, compared to other
income, net, of $0.7 million in 2017 and other expenses, net, of $7.8 million in 2016. The principal components of other expenses,
net, in 2018 included $3.0 million of charges related to the USG segment restructuring activities, including the Doble facility
consolidations in Norway, China, Dubai and Mexico; and $0.8 million of charges within the Filtration segment due to the exit of
the low margin industrial/automotive market. The principal components of other income, net, in 2017 included $0.6 million from
the sale of certain intellectual property and $0.4 million related to death benefit insurance proceeds from a former subsidiary.
The principal components of other expenses, net, in 2016 included $4.9 million of restructuring costs related to the Test segment
facility consolidation and $2.2 million of costs related to the USG segment restructuring activities. The restructuring costs mainly
related to severance and compensation benefits, professional fees and asset impairment charges related to abandoned assets. There
were no other individually significant items included in other expenses (income), net, in 2018, 2017 or 2016.

[0001144204-18-062244:mdna:58]
21

[0001144204-18-062244:mdna:59]
Non-GAAP Financial Measures

[0001144204-18-062244:mdna:60]
The information reported herein includes the financial
measures EPS – As Adjusted, which the Company defines as EPS excluding per-share restructuring charges related to the
Company’s restructuring actions in 2018 and the net recorded per-share tax benefit resulting from the implementation of
U.S. Tax Reform in 2018, defined purchase accounting inventory step-up charges and acquisition costs in 2017 and the
restructuring charges related to the Test and Doble restructuring actions in 2016; EBIT, which the Company defines as
earnings before interest and taxes, without adjustment for the defined purchase accounting inventory step-up charges,
acquisition costs and restructuring charges; and EBIT margin, which the Company defines as EBIT expressed as a percentage of
net sales. EPS – As Adjusted, EBIT on a consolidated basis, and EBIT margin on a consolidated basis are not recognized
in accordance with U.S. generally accepted accounting principles (GAAP). However, the Company believes that EBIT and EBIT
margin provide investors and Management with valuable information for assessing the Company’s operating results.
Management evaluates the performance of its operating segments based on EBIT and believes that EBIT is useful to investors to
demonstrate the operational profitability of the Company’s business segments by excluding interest and taxes, which are
generally accounted for across the entire company on a consolidated basis. EBIT is also one of the measures Management uses
to determine resource allocations and incentive compensation. The Company believes that the presentation of EBIT, EBIT margin
and EPS – As Adjusted provides important supplemental information to investors by facilitating comparisons with other
companies, many of which use similar non-GAAP financial measures to supplement their GAAP results. The use of
non-GAAP financial measures is not intended to replace any measures of performance determined in accordance with GAAP.

[0001144204-18-062244:mdna:61]
EBIT

[0001144204-18-062244:mdna:62]
|  |  |  |  |  |  |  |  |  |  |  | Change |  |  | Change |  |
|  |  | Fiscal year ended |  |  | 2018 |  |  | 2017 |  |
| (Dollars in millions) |  | 2018 |  |  | 2017 |  |  | 2016 |  |  | vs. 2017 |  |  | vs. 2016 |  |
| Filtration |  | $ | 58.7 |  |  |  | 52.2 |  |  |  | 45.2 |  |  |  | 12.5 | % |  |  | 15.5 | % |
| % of net sales |  |  | 20.5 | % |  |  | 18.7 | % |  |  | 21.8 | % |  |  |  |  |  |  |  |  |
| Test |  |  | 23.8 |  |  |  | 19.5 |  |  |  | 13.9 |  |  |  | 22.1 | % |  |  | 40.3 | % |
| % of net sales |  |  | 13.0 | % |  |  | 12.1 | % |  |  | 8.6 | % |  |  |  |  |  |  |  |  |
| USG |  |  | 43.2 |  |  |  | 36.6 |  |  |  | 31.1 |  |  |  | 18.0 | % |  |  | 17.7 | % |
| % of net sales |  |  | 20.2 | % |  |  | 22.5 | % |  |  | 24.3 | % |  |  |  |  |  |  |  |  |
| Technical Packaging |  |  | 8.1 |  |  |  | 8.5 |  |  |  | 9.6 |  |  |  | (4.7 | )% |  |  | (11.5 | )% |
| % of net sales |  |  | 9.2 | % |  |  | 10.3 | % |  |  | 12.9 | % |  |  |  |  |  |  |  |  |
| Corporate |  |  | (37.0 | ) |  |  | (32.1 | ) |  |  | (30.1 | ) |  |  | 15.3 | % |  |  | 6.6 | % |
| Total |  | $ | 96.8 |  |  |  | 84.7 |  |  |  | 69.7 |  |  |  | 14.3 | % |  |  | 21.5 | % |
| % of net sales |  |  | 12.5 | % |  |  | 12.4 | % |  |  | 12.2 | % |  |  |  |  |  |  |  |  |

[0001144204-18-062244:mdna:63]
The reconciliation of EBIT to a GAAP financial measure is as follows:

[0001144204-18-062244:mdna:64]
| (Dollars in millions) |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Net earnings from continuing operations |  | $ | 92.1 |  |  |  | 53.7 |  |  |  | 45.9 |  |
| Add: Interest expense |  |  | 8.8 |  |  |  | 4.6 |  |  |  | 1.3 |  |
| (Less) Add: Income taxes |  |  | (4.1 | ) |  |  | 26.4 |  |  |  | 22.5 |  |
| EBIT |  | $ | 96.8 |  |  |  | 84.7 |  |  |  | 69.7 |  |

[0001144204-18-062244:mdna:65]
Filtration

[0001144204-18-062244:mdna:66]
EBIT increased $6.5 million in 2018 as compared to 2017 primarily
due to the EBIT contribution from Mayday and Crissair due to increased sales volumes, partially offset by a decrease at PTI due
to the decrease in sales volumes and the 2018 restructuring charges related to the exit of the low margin industrial/automotive
market consisting primarily of severance and compensation benefits and asset impairment charges.

[0001144204-18-062244:mdna:67]
EBIT increased $7.0 million in 2017 as compared to 2016 mainly due
to the EBIT contribution from the Westland and Mayday acquisitions and an increase at VACCO and PTI due to increased sales volumes.
EBIT as a percent of net sales decreased in 2017 compared to 2016 mainly due to the purchase accounting inventory step-up charge
at Mayday of $1.9 million in 2017 and engineering and development cost growth on certain fixed price development contracts at VACCO.

[0001144204-18-062244:mdna:68]
Test

[0001144204-18-062244:mdna:69]
The $4.3 million increase in EBIT in 2018 as compared to 2017 was
primarily due to the increased sales volumes mainly from the segment’s U.S. operations.

[0001144204-18-062244:mdna:70]
The $5.6 million increase in EBIT in 2017 as compared to 2016 was
primarily due to the $5.1 million of restructuring charges incurred in 2016 related to closing the Test business operating facilities
in Germany and England, consisting mainly of employee severance and compensation benefits, professional fees, and asset impairment
charges.

[0001144204-18-062244:mdna:71]
|  | 22 |  |

[0001144204-18-062244:mdna:72]
USG

[0001144204-18-062244:mdna:73]
The $6.6 million increase in EBIT in 2018 as compared to 2017 was
mainly due to the higher sales volumes as well as the EBIT contribution from the acquisitions of NRG, Morgan Schaffer and
Vanguard Instruments. EBIT in 2018 was negatively impacted by $3 million of charges recorded related to closing the
Doble facilities in Norway, China, Dubai and Mexico, consisting mainly of employee severance and compensation benefits, professional
fees, and asset impairment charges.

[0001144204-18-062244:mdna:74]
The $5.5 million increase in EBIT in 2017 as compared to 2016 was
primarily due to higher sales volumes and additional contribution from new products and software solutions, as well as the EBIT
contribution from the 2017 acquisitions of NRG, Morgan Schaffer and Vanguard Instruments. EBIT as a percent of net sales decreased
in 2017 compared to 2016 mainly due to the purchase accounting inventory step-up charges at NRG, Morgan Schaffer and Vanguard Instruments
totaling $1.9 million.

[0001144204-18-062244:mdna:75]
Technical Packaging

[0001144204-18-062244:mdna:76]
EBIT decreased $0.4 million in 2018 as compared to 2017 mainly due
to product mix at TEQ and Plastique including lower margin projects and higher material prices.

[0001144204-18-062244:mdna:77]
EBIT decreased $1.1 million in 2017 as compared to 2016 mainly due
to higher SG&A expenses at Plastique due to the full year being included in 2017.

[0001144204-18-062244:mdna:78]
Corporate

[0001144204-18-062244:mdna:79]
Corporate operating charges included in 2018 consolidated EBIT increased
to $37.0 million as compared to $32.1 million in 2017 due to an increase in professional fees and increased amortization of intangible
assets on acquisitions.

[0001144204-18-062244:mdna:80]
Corporate operating charges included in 2017 consolidated EBIT increased
to $32.1 million as compared to $30.1 million in 2016 due to an increase in acquisition related expenses, mainly from increased
amortization of intangible assets on acquisitions.

[0001144204-18-062244:mdna:81]
The “Reconciliation to Consolidated Totals (Corporate)”
in Note 13 to the Consolidated Financial Statements included herein represents Corporate office operating charges.

[0001144204-18-062244:mdna:82]
Interest Expense, Net

[0001144204-18-062244:mdna:83]
Interest expense was $8.8 million in 2018, $4.6 million in 2017
and $1.3 million in 2016. The increase in interest expense in 2018 as compared to 2017 was due to higher average outstanding borrowings
($258.8 million compared to $211.3 million) and higher average interest rates (3.0% vs. 2.1%) as a result of the additional borrowings
to fund the Company’s recent acquisitions. The increase in interest expense in 2017 as compared to 2016 was due to higher
average outstanding borrowings ($211.3 million compared to $89.2 million) and higher average interest rates (2.1% vs. 1.6%) as
a result of the additional borrowings to fund the Company’s 2017 acquisitions (Mayday, Morgan Schaffer, NRG and Vanguard
Instruments).

[0001144204-18-062244:mdna:84]
Income Tax Expense

[0001144204-18-062244:mdna:85]
On December 22, 2017, President Trump signed into law new tax legislation
commonly referred to as the Tax Cut and Jobs Act (the “TCJA”). The TCJA includes broad and complex changes to the U.S.
tax code that impacted the Company’s accounting and reporting for income taxes in 2018. These impacts primarily resulted
from a reduction in the U.S. federal corporate income tax rate from 35% to 21%, effective January 1, 2018; a remeasurement of U.S.
deferred tax assets and liabilities; and a one-time mandatory deemed repatriation tax on unremitted foreign earnings (the “Transition
Tax”), which may be paid over an eight-year period. The Company also established a liability related to foreign withholding
taxes in connection with the reversal of our indefinite reinvestment assertion related to foreign earnings subject to the Transition
Tax.

[0001144204-18-062244:mdna:86]
See Note 7, Income Taxes, to the Consolidated Financial Statements
of the Company included in the Financial Information section of this Annual Report for further discussion related to the TCJA.

[0001144204-18-062244:mdna:87]
|  | 23 |  |

[0001144204-18-062244:mdna:88]
The effective tax rates for 2018, 2017 and 2016 were (4.7)%, 33.0%
and 32.9%, respectively. The decrease in the 2018 effective tax rate as compared to 2017 was primarily due to the enactment of
the TCJA, which was signed into law on December 22, 2017. The total impact of the TCJA in 2018 was a net benefit of $24.4 million.
The specific impacts of the TCJA were primarily as follows:

[0001144204-18-062244:mdna:89]
|  | · | The Company’s 2018 federal statutory rate decreased from 35.0% to 24.5% which required an adjustment to the value of its deferred tax assets and liabilities. This adjustment of $30.6 million (complete as of September 30, 2018) favorably impacted the 2018 effective tax rate by 34.8%. |

[0001144204-18-062244:mdna:90]
|  | · | The TCJA subjected the Company’s cumulative foreign earnings to $3.7 million (provisional amount, refer to Note 7 to the Company’s Consolidated Financial Statement included in this Report) of federal income tax which unfavorably impacted the 2018 effective tax rate by 4.2%. In addition to the impacts from the TCJA, the Company recorded $2.4 million (complete as of September 30, 2018) for the income tax effects of the current and future repatriation of the cumulative earnings of its foreign subsidiaries which unfavorably impacted the 2018 effective tax rate by 2.8%. |

[0001144204-18-062244:mdna:91]
|  | · | The Company approved an additional $7.5 million pension contribution for the 2017 plan year during the second quarter of 2018 resulting in a favorable adjustment to the 2018 effective tax rate of 0.9%. |

[0001144204-18-062244:mdna:92]
|  | · | An accounting method change was filed with the 2017 tax return which resulted in a favorable adjustment to the 2018 effective tax rate of 0.7%. |

[0001144204-18-062244:mdna:93]
The increase in the 2017 effective tax rate as compared to 2016
was primarily due to normal tax fluctuations within the ordinary course of business.

[0001144204-18-062244:mdna:94]
The Company’s foreign subsidiaries had accumulated unremitted
earnings of $3.5 million at September 30, 2018. No deferred taxes have been provided on these accumulated unremitted earnings because
these funds are not needed to meet the liquidity requirements of the Company’s U.S. operations and it is the Company’s
intention to indefinitely reinvest these earnings in continuing international operations. In the event these foreign entities’
earnings were distributed, it is estimated that approximately $0.3 million of foreign tax withholding would be paid. The Company
does not expect that these taxes would be creditable against U.S. income tax, so they would correspondingly reduce the Company’s
net earnings. No significant portion of the Company’s foreign subsidiaries’ earnings was taxed at a rate significantly
less than the U.S. statutory tax rate.

[0001144204-18-062244:mdna:95]
Capital Resources and Liquidity

[0001144204-18-062244:mdna:96]
The Company’s overall financial position and liquidity are
strong. Working capital (current assets less current liabilities) decreased to $195.5 million at September 30, 2018 from $197.8
million at September 30, 2017, mainly due to higher accounts payable balances. The $8.2 million increase in accounts payable at
September 30, 2018 was mainly due to a $4.9 million increase within the Test segment and a $4.0 million increase within the Technical
Packaging segment both due to the timing of payments. The $10.9 million increase in inventory at September 30, 2018 was mainly
due to a $7.0 million increase in the Filtration segment and a $4.0 million increase in the USG segment due to the timing of receipt
of raw materials to meet increased sales volumes and the acquisition of Manta.

[0001144204-18-062244:mdna:97]
Net cash provided by operating activities was $93.3 million, $67.3
million and $73.9 million in 2018, 2017 and 2016, respectively; the changes were mainly due to changes in working capital and an
increase in net earnings in 2018.

[0001144204-18-062244:mdna:98]
Net cash used in investing activities was $41.6 million, $233.9
million and $104.6 million in 2018, 2017, and 2016, respectively. The decrease in net cash used in investing activities in 2018
as compared to 2017 was due to the Company’s 2017 acquisitions of Mayday, NRG, Morgan Schaffer and Vanguard Instruments.
The increase in net cash used in investing activities in 2017 as compared to 2016 was due to those acquisitions. Capital expenditures
were $20.6 million, $29.7 million and $13.8 million in 2018, 2017 and 2016, respectively. The decrease in capital expenditures
in 2018 as compared to 2017 was mainly due to higher levels of capital expenditures in 2017 including machinery and equipment at
VACCO and a facility expansion at Plastique. The increase in capital expenditures in 2017 as compared to 2016 was mainly due to
an increase in machinery and equipment at VACCO, a facility expansion at Plastique and the capital expenditures specific to the
Company’s recently acquired entities. There were no commitments outstanding that were considered material for capital expenditures
at September 30, 2018. In addition, the Company incurred expenditures for capitalized software of $9.5 million, $9.0 million
and $8.7 million in 2018, 2017 and 2016, respectively.

[0001144204-18-062244:mdna:99]
The Company made pension contributions of $10.0
million (including the additional $7.5 million contribution for 2017 described above), $2.7 million and $0 in 2018, 2017 and
2016, respectively.

[0001144204-18-062244:mdna:100]
Net cash used by financing activities was $66.4 million in
2018, compared to net cash provided by financing activities of $156.8 million and $46.2 million in 2017 and 2016,
respectively. The change in 2018 as compared to 2017 was primarily due to the Company’s repayment of outstanding debt
of $55 million in 2018 under its Credit Facility. The increase in 2017 compared to 2016 was mainly due to an increase in
borrowings related to the Company’s acquisitions.

[0001144204-18-062244:mdna:101]
|  | 24 |  |

[0001144204-18-062244:mdna:102]
Acquisitions

[0001144204-18-062244:mdna:103]
Information regarding the Company’s acquisitions during 2018,
2017 and 2016 is set forth in Note 2 to the Company’s Consolidated Financial Statements beginning on Page F-1 of this Annual
Report, which Note is incorporated by reference herein.

[0001144204-18-062244:mdna:104]
All of the Company’s acquisitions have been accounted for
using the purchase method of accounting, and accordingly, the respective purchase prices were allocated to the assets (including
intangible assets) acquired and liabilities assumed based on estimated fair values at the date of acquisition. The financial
results from these acquisitions have been included in the Company’s financial statements from the date of acquisition.

[0001144204-18-062244:mdna:105]
Subsequent Event

[0001144204-18-062244:mdna:106]
In October 2018, the Company sold its Doble headquarters facility
in Watertown, Massachusetts, and plans to consolidate its headquarters operations into a single, more cost-efficient facility in
Marlborough, Massachusetts over the next twelve to fifteen months.

[0001144204-18-062244:mdna:107]
Bank Credit Facility

[0001144204-18-062244:mdna:108]
A description of the Company’s credit facility (the “Credit
Facility”) is set forth in Note 8 to the Company’s Consolidated Financial Statements beginning on Page F-1 of this
Annual Report, which Note is incorporated by reference herein.

[0001144204-18-062244:mdna:109]
Cash flow from operations and borrowings under the Credit Facility
is expected to provide adequate resources to meet the Company’s capital requirements and operational needs for the foreseeable
future.

[0001144204-18-062244:mdna:110]
Dividends

[0001144204-18-062244:mdna:111]
Since 2010 the Company has paid a regular quarterly cash dividend
at an annual rate of $0.32 per share. The Company paid dividends of $8.3 million, $8.3 million and $8.2 million in 2018, 2017
and 2016, respectively.

[0001144204-18-062244:mdna:112]
Contractual Obligations

[0001144204-18-062244:mdna:113]
The following table shows the Company’s contractual obligations
as of September 30, 2018:

[0001144204-18-062244:mdna:114]
|  |  | Payments due by period |  |
|  |  |  |  |  | Less than |  |  | 1 to 3 |  |  | 3 to 5 |  |  | More than |  |
| (Dollars in millions) |  | Total |  |  | 1 year |  |  | years |  |  | years |  |  | 5 years |  |
| Long-Term Debt Obligation |  | $ | 220.0 |  |  |  | - |  |  |  | 220.0 |  |  |  | - |  |  |  | - |  |
| Estimated Interest Payments (1) |  |  | 23.2 |  |  |  | 7.7 |  |  |  | 12.0 |  |  |  | 3.5 |  |  |  | - |  |
| Operating Lease Obligations |  |  | 22.0 |  |  |  | 6.7 |  |  |  | 9.0 |  |  |  | 5.1 |  |  |  | 1.2 |  |
| Purchase Obligations (2) |  |  | 23.2 |  |  |  | 21.0 |  |  |  | 2.2 |  |  |  | - |  |  |  | - |  |
| Total |  | $ | 288.4 |  |  |  | 35.4 |  |  |  | 243.2 |  |  |  | 8.6 |  |  |  | 1.2 |  |

[0001144204-18-062244:mdna:115]
|  | (1) | Estimated interest payments for the Company’s debt obligations were calculated based on Management’s determination of the estimated applicable interest rates and payment dates. |

[0001144204-18-062244:mdna:116]
|  | (2) | A purchase obligation is defined as a legally binding and enforceable agreement to purchase goods and services that specifies all significant terms. Since the majority of the Company’s purchase orders can be cancelled, they are not included in the table above. |

[0001144204-18-062244:mdna:117]
As of September 30, 2018, the Company had $0.1 million of liabilities
for uncertain tax positions. The unrecognized tax benefits have been excluded from the table above due to uncertainty as to the
amounts and timing of settlement with taxing authorities.

[0001144204-18-062244:mdna:118]
The Company had no off-balance-sheet arrangements outstanding at
September 30, 2018.

[0001144204-18-062244:mdna:119]
Share Repurchases

[0001144204-18-062244:mdna:120]
In August 2012, the Company’s Board of Directors authorized
a common stock repurchase program under which the Company may repurchase shares of its stock from time to time in its discretion,
in the open market or otherwise, up to a maximum total repurchase amount of $100 million (or such lesser amount as may be permitted
under the Company’s bank credit agreements). This program has been twice extended by the Company’s Board of Directors
and is currently scheduled to expire September 30, 2019. There were no share repurchases in 2017 or 2018. The Company repurchased
approximately 120,000 shares for $4.3 million in 2016. At September 30, 2018, approximately $50.4 million remained available for
repurchases under the program.

[0001144204-18-062244:mdna:121]
|  | 25 |  |

[0001144204-18-062244:mdna:122]
Pension Funding Requirements

[0001144204-18-062244:mdna:123]
The minimum cash funding requirements related to the Company’s
defined benefit pension plans are estimated to be approximately $0.8 million in 2019, $1.3 million in 2020, and $1.9 million in
2021.

[0001144204-18-062244:mdna:124]
Other

[0001144204-18-062244:mdna:125]
As a normal incident of the business in which the Company is engaged,
various claims, charges and litigation are asserted or commenced from time to time against the Company. Additionally, the Company
is currently involved in various stages of investigation and remediation relating to environmental matters. It is the opinion of
Management that the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered
against the Company are adequately reserved for, are covered by insurance or are not likely to have a material adverse effect on
the Company’s results of operations, capital expenditures or competitive position.

[0001144204-18-062244:mdna:126]
Outlook

[0001144204-18-062244:mdna:127]
Management continues to
see meaningful organic sales, Adjusted EBIT and Adjusted EBITDA growth across each of the Company’s business segments,
and anticipates that growth rates in 2019 and beyond will generally exceed the broader industrial market. The details of
management’s growth expectations for 2019 compared to 2018 are as follows:

[0001144204-18-062244:mdna:128]
|  | · | Organic sales are expected to increase in the mid-single digits on a consolidated basis, with Filtration and Technical Packaging growing four to six percent each, USG growing five to seven percent (partially muted by slower growth in the renewable energy space at NRG), and Test growing three to five percent; |

[0001144204-18-062244:mdna:129]
|  | · | Interest expense is expected to be similar to 2018 despite the lower debt levels as the Company is projecting higher interest rates over the next twelve months; |

[0001144204-18-062244:mdna:130]
|  | · | Non-cash depreciation and amortization of intangibles is expected to increase approximately $3.7 million (or $0.11 per share after-tax) related to previous acquisitions and capital spending; |

[0001144204-18-062244:mdna:131]
|  | · | Income tax expense is expected to increase as management is projecting a 24 percent effective tax rate calculated on higher pretax earnings; |

[0001144204-18-062244:mdna:132]
|  | · | In summary, management projects 2019 Adjusted EPS to be in the range of $2.95 to $3.05 reflecting meaningful organic sales growth offset by the additional depreciation and amortization charges and incremental tax expense noted above. In making this projection management is excluding the following expected adjustments to 2019 GAAP EPS: |

[0001144204-18-062244:mdna:133]
|  | – | A pre-tax gain of approximately $7 million from the October 2018 sale of Doble’s headquarters building in Watertown, Massachusetts; and |

[0001144204-18-062244:mdna:134]
|  | – | Pre-tax costs aggregating approximately $4.5 million related to the relocation of Doble’s headquarters, the closure of Plastique’s headquarters in Tunbridge Wells, UK and the consolidation of its product design and administrative functions into its facilities in Nottingham, UK and Poznan, Poland, the consolidation of VACCO’s aircraft/aerospace business into PTI’s aerospace facility in Oxnard, California, and the completion of other restructuring activities begun in 2018. |

[0001144204-18-062244:mdna:135]
On a quarterly basis and consistent with prior years, management
expects 2019 revenues and Adjusted EPS to be more second-half weighted . Management expects Q1 2019 Adjusted EPS to be in the
range of $0.40 to $0.45 per share.

[0001144204-18-062244:mdna:136]
Market Risk Exposure

[0001144204-18-062244:mdna:137]
Market risks relating to the Company’s operations result primarily
from changes in interest rates and changes in foreign currency exchange rates. The Company is exposed to market risk related to
changes in interest rates and selectively uses derivative financial instruments, including forward contracts and swaps, to manage
these risks. During 2016, the Company entered into forward contracts to purchase pounds sterling (GBP) to hedge two deferred payments
due in connection with the acquisition of Plastique. During 2018, the Company entered into three interest rate swaps with a notional
amount of $150 million to hedge some of its exposure to variability in future LIBOR-based interest payments on variable rate debt.
In addition, the Company’s Canadian subsidiary Morgan Schaffer entered into foreign exchange contracts to manage foreign
currency risk, as a portion of their revenue is denominated in U.S. dollars. All derivative instruments are reported on the balance
sheet at fair value. For derivative instruments designated as cash flow hedges, the gain or loss on the derivative is deferred
in accumulated other comprehensive income until recognized in earnings with the underlying hedged item. The interest rate swaps
entered into during 2018 were not designated as cash flow hedges and therefore the gain or loss on the derivative is reflected
in earnings each period.

[0001144204-18-062244:mdna:138]
The Company is also subject to foreign currency exchange rate risk
inherent in its sales commitments, anticipated sales, anticipated purchases and assets and liabilities denominated in currencies
other than the U.S. dollar. The foreign currencies most significant to the Company’s operations are the Canadian Dollar and
the Euro. The Company occasionally hedges certain foreign currency commitments by purchasing foreign currency forward contracts.
The Company does not have material foreign currency market risk; net foreign currency transaction gain/loss was less than 2% of
net earnings for 2018, 2017 and 2016.

[0001144204-18-062244:mdna:139]
The Company has determined that the market risk related to interest
rates with respect to its variable debt is not material. The Company estimates that if market interest rates averaged one percentage
point higher, the effect would have been less than 3% of net earnings for the year ended September 30, 2018.

[0001144204-18-062244:mdna:140]
For more information about the Company’s derivative financial
instruments, see Note 12 to the Company’s Consolidated Financial Statements beginning on page F-1 of this Annual Report.

[0001144204-18-062244:mdna:141]
|  | 26 |  |

[0001144204-18-062244:mdna:142]
Critical Accounting Policies

[0001144204-18-062244:mdna:143]
The preparation of financial statements in conformity with U.S.
generally accepted accounting principles (GAAP) requires Management to make estimates and assumptions in certain circumstances
that affect amounts reported in the accompanying Consolidated Financial Statements. In preparing these financial statements, Management
has made its best estimates and judgments of certain amounts included in the Consolidated Financial Statements, giving due consideration
to materiality. The Company does not believe there is a great likelihood that materially different amounts would be reported under
different conditions or using different assumptions related to the accounting policies described below. However, application of
these accounting policies involves the exercise of judgment and use of assumptions as to future uncertainties and, as a result,
actual results could differ from these estimates. The Company’s senior Management discusses the critical accounting policies
described below with the Audit and Finance Committee of the Company’s Board of Directors on a periodic basis.

[0001144204-18-062244:mdna:144]
The following discussion of critical accounting policies is
intended to bring to the attention of readers those accounting policies which Management believes are critical to the Consolidated
Financial Statements and other financial disclosure. It is not intended to be a comprehensive list of all significant accounting
policies that are more fully described in Note 1 to the Consolidated Financial Statements included herein.

[0001144204-18-062244:mdna:145]
Revenue Recognition

[0001144204-18-062244:mdna:146]
Information regarding the recognition of revenue by the entities
in each of the Company’s business segments is set forth in Note 1.E to the Company’s Consolidated Financial Statements
beginning on page F-1 of this Annual Report, which Note is incorporated by reference herein.

[0001144204-18-062244:mdna:147]
Income Taxes

[0001144204-18-062244:mdna:148]
The Company operates in numerous taxing jurisdictions and is
subject to examination by various U.S. Federal, state and foreign jurisdictions for various tax periods. The Company’s income
tax positions are based on research and interpretations of the income tax laws and rulings in each of the jurisdictions in which
the Company does business. Due to the subjectivity of interpretations of laws and rulings in each jurisdiction, the differences
and interplay in tax laws between those jurisdictions, as well as the inherent uncertainty in estimating the final resolution of
complex tax audit matters, Management’s estimates of income tax liabilities may differ from actual payments or assessments.

[0001144204-18-062244:mdna:149]
At the end of each interim reporting period, Management estimates
the effective tax rate expected to apply to the full fiscal year. The estimated effective tax rate contemplates the expected jurisdiction
where income is earned. Current and projected growth in income in higher tax jurisdictions
may result in an increasing effective tax rate over time. If the actual results differ from Management’s estimates, Management
may have to adjust the effective tax rate in the interim period if such determination is made.

[0001144204-18-062244:mdna:150]
On December 22, 2017, the U.S. government enacted the TCJA,
which, among other things, lowered the U.S. corporate statutory income tax rate and established a modified territorial system requiring
a mandatory deemed repatriation on undistributed earnings of foreign subsidiaries.

[0001144204-18-062244:mdna:151]
In accordance with Securities and Exchange Commission (“SEC”)
Staff Accounting Bulletin 118, as of September 30, 2018, the Company recorded certain TCJA related provisional charges using available
information and estimates. Adjustments to the provisional charges will be recorded in the period in which those adjustments become
reasonably estimable and/or the accounting is complete. Such adjustments may result from, among other things, future guidance,
interpretations and regulatory changes from the U.S. Internal Revenue Service, the SEC, the Financial Accounting Standards Board
and/or various state and local tax jurisdictions. The Company will complete this analysis no later than December 22, 2018.

[0001144204-18-062244:mdna:152]
Income taxes are accounted for under the asset and liability
method. Deferred tax assets and liabilities are recognized for the future tax consequences attributable to differences between
the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets
and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary
differences are expected to be recovered or settled. Deferred tax assets may be reduced by a valuation allowance if it is more
likely than not that some portion of the deferred tax assets will not be realized. The effect on deferred tax assets and liabilities
of a change in tax rates is recognized in income in the period that includes the enactment date. The Company regularly reviews
its deferred tax assets for recoverability and establishes a valuation allowance when Management believes it is more likely than
not such assets will not be recovered, taking into consideration historical operating results, expectations of future earnings,
tax planning strategies, and the expected timing of the reversals of existing temporary differences.

[0001144204-18-062244:mdna:153]
|  | 27 |  |

[0001144204-18-062244:mdna:154]
Goodwill And Other Long-Lived Assets

[0001144204-18-062244:mdna:155]
Management annually reviews goodwill and other long-lived assets
with indefinite useful lives for impairment or whenever events or changes in circumstances indicate the carrying amount may not
be recoverable. If the Company determines that the carrying value of the long-lived asset may not be recoverable, a permanent impairment
charge is recorded for the amount by which the carrying value of the long-lived asset exceeds its fair value. Fair value is measured
based on a discounted cash flow method using a discount rate determined by Management to be commensurate with the risk inherent
in the Company’s current business model. The estimates of cash flows and discount rate are subject to change due to the economic
environment, including such factors as interest rates, expected market returns and volatility of markets served. Management believes
that the estimates of future cash flows and fair value are reasonable; however, changes in estimates could result in impairment
charges. At September 30, 2018, the Company has determined that no reporting units are at risk of goodwill impairment
as the fair value of each reporting unit substantially exceeded its carrying value.

[0001144204-18-062244:mdna:156]
Intangible assets with estimable useful lives are amortized
over their respective estimated useful lives to their estimated residual values, and are reviewed for impairment whenever events
or changes in business circumstances indicate the carrying value of the assets may not be recoverable.

[0001144204-18-062244:mdna:157]
Other Matters

[0001144204-18-062244:mdna:158]
Contingencies

[0001144204-18-062244:mdna:159]
As a normal incident of the businesses in which the Company
is engaged, various claims, charges and litigation are asserted or commenced from time to time against the Company. Additionally,
the Company is currently involved in various stages of investigation and remediation relating to environmental matters. It is the
opinion of Management that the aggregate costs involved in the resolution of these matters, and final judgments, if any, which
might be rendered against the Company are adequately accrued, are covered by insurance or are not likely to have a material adverse
effect on the Company’s results from continuing operations, capital expenditures, or competitive position.

[0001144204-18-062244:mdna:160]
Quantitative and Qualitative Disclosures About Market
Risk

[0001144204-18-062244:mdna:161]
Market risks relating to the Company’s operations result
primarily from changes in interest rates and changes in foreign currency exchange rates. The Company is exposed to market risk
related to changes in interest rates and selectively uses derivative financial instruments, including forward contracts and swaps,
to manage these risks. During 2016 the Company entered into several forward contracts to purchase pounds sterling (GBP) to hedge
two deferred payments  due in connection with the acquisition of Plastique.
During 2018, the Company entered into three interest rate swaps with a notional amount of $150 million to hedge some of its exposure
to variability in future LIBOR-based interest payments on variable rate debt. In addition, the Company’s Canadian subsidiary
Morgan Schaffer has entered into foreign exchange contracts to manage foreign currency risk as a portion of their revenue is denominated
in U.S. dollars. All derivative instruments are reported on the balance sheet at fair value. For derivative instruments designated
as cash flow hedges, the gain or loss on the derivative is deferred in accumulated other comprehensive income until recognized
in earnings with the underlying hedged item. See further discussion regarding the Company’s market risks in “Market Risk
Analysis,” above.

[0001144204-18-062244:mdna:162]
Controls and Procedures

[0001144204-18-062244:mdna:163]
For a description of the Company’s evaluation of its disclosure
controls and procedures, see Item 9A, “Controls and Procedures.”

[0001144204-18-062244:mdna:164]
New Accounting Pronouncements

[0001144204-18-062244:mdna:165]
Information regarding new and updated accounting standards which
affect the content and/or presentation of the Company’s financial information is set forth in Note 1.W to the Company’s
Consolidated Financial Statements beginning on page F-1 of this Annual Report, which Note is incorporated by reference herein.
