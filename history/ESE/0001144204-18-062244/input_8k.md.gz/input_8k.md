# ESE 8-K — 0000866706-18-000011 filed 2018-11-15

## item codes, every 8-K on or before 2018-11-29

- 2018-11-15 0000866706-18-000011 — 2.02, 5.02, 7.01
- 2018-08-07 0000866706-18-000006 — 2.02, 7.01, 9.01
- 2018-05-08 0000866706-18-000003 — 2.02, 7.01, 9.01
- 2018-02-07 0001144204-18-006155 — 5.03, 9.01
- 2018-02-06 0001144204-18-006014 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2017-11-14 0000866706-17-000014 — 2.02, 5.02, 7.01, 8.01, 9.01
- 2017-08-08 0000866706-17-000010 — 2.02, 7.01, 9.01
- 2017-05-04 0000866706-17-000006 — 2.02, 7.01, 9.01
- 2017-02-07 0000866706-17-000002 — 2.02, 5.07, 7.01, 8.01, 9.01
- 2016-11-17 0000866706-16-000028 — 5.02
- 2016-11-14 0000866706-16-000026 — 2.02, 5.02, 7.01, 9.01
- 2016-08-02 0000866706-16-000023 — 2.02, 7.01, 9.01
- 2016-05-03 0000866706-16-000020 — 2.02, 7.01, 9.01
- 2016-02-09 0000866706-16-000017 — 2.02, 5.07, 7.01, 9.01
- 2015-12-23 0001144204-15-072560 — 1.01, 2.03, 9.01
- 2015-11-30 0000866706-15-000014 — 5.02, 9.01 — amendment of 0000866706-15-000012
- 2015-11-12 0000866706-15-000012 — 2.02, 5.02, 7.01, 9.01
- 2015-10-08 0000866706-15-000010 — 2.02, 7.01, 9.01
- 2015-08-10 0000866706-15-000008 — 2.02, 7.01, 9.01
- 2015-05-05 0000866706-15-000005 — 2.02, 7.01, 9.01
- 2015-02-09 0000866706-15-000002 — 2.02, 5.07, 7.01, 9.01
- 2014-11-13 0000866706-14-000015 — 2.02, 5.02, 7.01, 9.01
- 2014-10-02 0000866706-14-000010 — 5.02, 8.01, 9.01
- 2014-08-07 0001144204-14-047705 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-05-07 0000866706-14-000008 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2014-03-28 0001144204-14-018877 — 2.01, 9.01
- 2014-03-17 0000866706-14-000005 — 1.01, 7.01, 9.01
- 2014-02-06 0000866706-14-000002 — 2.02, 5.07, 7.01, 9.01
- 2013-11-12 0001144204-13-060357 — 2.02, 5.02, 9.01
- 2013-08-08 0000866706-13-000029 — 2.02, 7.01, 9.01
- 2013-05-09 0000866706-13-000027 — 7.01
- 2013-05-07 0000866706-13-000023 — 2.02, 7.01, 9.01
- 2013-04-17 0000866706-13-000020 — 2.02, 7.01, 9.01
- 2013-02-14 0000866706-13-000018 — 5.02
- 2013-02-07 0000866706-13-000002 — 2.02, 5.02, 5.07, 7.01, 9.01
- 2012-11-13 0000866706-12-000021 — 2.02, 5.02, 9.01
- 2012-10-09 0000866706-12-000019 — 2.02, 7.01, 9.01
- 2012-08-09 0000866706-12-000015 — 2.02, 7.01, 9.01
- 2012-05-18 0000866706-12-000013 — 1.01, 1.02, 2.03, 9.01
- 2012-05-09 0000866706-12-000009 — 2.02, 7.01, 9.01
- 2012-02-07 0000866706-12-000003 — 2.02, 5.07, 7.01, 9.01
- 2011-11-08 0000866706-11-000020 — 2.02, 5.02, 7.01, 9.01
- 2011-08-02 0000866706-11-000012 — 2.02, 7.01, 9.01
- 2011-05-03 0000866706-11-000006 — 2.02, 7.01, 9.01
- 2011-02-03 0000866706-11-000002 — 2.02, 5.07, 7.01, 9.01
- 2010-11-17 0000866706-10-000031 — 2.02, 5.02, 7.01, 9.01
- 2010-11-12 0000866706-10-000029 — 2.02, 7.01, 9.01
- 2010-08-03 0000866706-10-000022 — 2.02, 5.02, 7.01, 9.01
- 2010-05-04 0000866706-10-000017 — 2.02, 7.01, 9.01
- 2010-02-10 0000866706-10-000008 — 5.02, 9.01
- 2010-02-04 0000866706-10-000004 — 2.02, 7.01, 9.01
- 2010-01-15 0000866706-10-000002 — 1.01, 2.03, 9.01
- 2009-12-17 0000866706-09-000108 — 5.02
- 2009-11-12 0000866706-09-000103 — 2.02, 7.01, 8.01, 9.01
- 2009-08-04 0000866706-09-000074 — 2.02, 7.01, 9.01
- 2009-05-05 0000866706-09-000036 — 2.02, 7.01, 9.01
- 2009-02-05 0000866706-09-000014 — 2.02, 7.01, 9.01
- 2008-11-17 0000866706-08-000096 — 5.02
- 2008-11-12 0000866706-08-000094 — 2.02, 7.01, 9.01
- 2008-10-22 0000866706-08-000090 — 2.02, 9.01
- 2008-08-07 0000866706-08-000070 — 2.02, 7.01, 9.01
- 2008-05-06 0000866706-08-000053 — 2.02, 7.01, 8.01, 9.01
- 2008-02-15 0000950137-08-002412 — 9.01 — amendment of 0000866706-07-000090
- 2008-02-12 0000866706-08-000028 — 5.02, 9.01
- 2008-02-07 0000866706-08-000014 — 2.02, 7.01, 9.01
- 2008-01-07 0000866706-08-000012 — 5.02, 9.01
- 2007-12-06 0000866706-07-000090 — 1.01, 2.01, 2.03, 9.01
- 2007-11-28 0000950137-07-017923 — 1.01, 2.01, 9.01
- 2007-11-15 0000866706-07-000088 — 5.02
- 2007-11-13 0000950137-07-017081 — 7.01, 9.01
- 2007-11-13 0000866706-07-000080 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2007-11-09 0000866706-07-000078 — 1.01, 9.01
- 2007-11-07 0000950124-07-005603 — 7.01, 9.01
- 2007-08-07 0000866706-07-000062 — 2.02, 7.01, 9.01
- 2007-05-08 0000866706-07-000044 — 2.02, 7.01, 9.01
- 2007-02-05 0000866706-07-000017 — 2.02, 5.03, 7.01, 9.01
- 2006-11-15 0000866706-06-000132 — 5.02
- 2006-11-14 0000866706-06-000127 — 2.02, 7.01, 9.01
- 2006-08-08 0000866706-06-000089 — 1.02, 2.02, 5.02, 7.01, 9.01
- 2006-05-09 0000866706-06-000058 — 2.02, 7.01, 9.01
- 2006-02-07 0000866706-06-000024 — 1.01, 9.01
- 2006-02-02 0000866706-06-000018 — 1.01, 2.01, 2.02, 2.03, 7.01, 9.01
- 2005-12-21 0000866706-05-000139 — 1.01
- 2005-12-01 0000950134-05-022448 — 7.01, 9.01
- 2005-11-15 0000866706-05-000136 — 2.02, 7.01, 9.01
- 2005-08-09 0000866706-05-000077 — 2.02, 7.01, 9.01
- 2005-05-10 0000866706-05-000056 — 2.02, 7.01, 9.01
- 2005-02-04 0000866706-05-000020 — 2.02, 7.01, 9.01
- 2004-11-18 0000866706-04-000116 — 7.01, 9.01
- 2004-11-16 0000866706-04-000114 — 2.02, 7.01, 9.01
- 2004-10-12 0000950137-04-008426 — 1.01, 2.03
- 2004-08-10 0000866706-04-000077 — 7, 9
- 2004-05-11 0000866706-04-000057 — 12, 7, 9
- 2004-04-05 0000866706-04-000035 — 5
- 2004-02-05 0000950134-04-001117 — 12, 7, 9
- 2003-11-20 0000950134-03-015684 — 12, 7, 9
- 2003-08-12 0000950134-03-011367 — 12, 7, 9
- 2003-07-31 0000866706-03-000017 — 12, 9
- 2003-05-13 0000866706-03-000008 — 7
- 2003-02-13 0000866706-03-000004 — 7
- 2003-02-06 0000950134-03-001725 — 7, 9
- 2003-01-13 0000950134-03-000479 — 7, 9
- 2002-12-26 0001035704-02-000649 — 7, 9
- 2002-12-02 0000950134-02-015135 — 7, 9
- 2002-11-12 0000950134-02-013855 — 7, 9
- 2002-08-07 0000950134-02-009113 — 7, 9
- 2002-06-05 0000950134-02-006739 — 7, 9
- 2002-02-07 0000950134-02-000861 — 7, 9
- 2002-02-05 0000950134-02-000804 — 7, 9
- 2001-11-29 0000950134-01-509079 — 7 — amendment of 0000950134-01-509049
- 2001-11-28 0000950134-01-509049 — 7, 9
- 2001-10-09 0000950134-01-507116 — 5, 7
- 2000-11-14 0000950124-00-006943 — 7, 9
- 2000-07-20 0000950124-00-004304 — 5, 7
- 2000-02-07 0000950124-00-000406 — 5, 7
- 1999-10-13 0000866706-99-000014 — 2, 7
- 1997-04-18 0000950114-97-000209 — 2, 7
- 1996-08-06 0000866706-96-000015 — 3

## late-filing notifications on or before 2018-11-29

- none on or before 2018-11-29

## item 2.02 — earnings release, exhibit 99.1

[0000866706-18-000011:8k_2_02:1]
EX-99.1
2
escopressreleasenov2018.htm
ESCO PRESS RELEASE

[0000866706-18-000011:8k_2_02:2]
EXHIBIT 99.1

[0000866706-18-000011:8k_2_02:3]
NEWS FROM

[0000866706-18-000011:8k_2_02:4]
For more information contact:

[0000866706-18-000011:8k_2_02:5]
Kate Lowrey

[0000866706-18-000011:8k_2_02:6]
Director, Investor Relations

[0000866706-18-000011:8k_2_02:7]
ESCO Technologies Inc.

[0000866706-18-000011:8k_2_02:8]
(314) 213-7277

[0000866706-18-000011:8k_2_02:9]
ESCO ANNOUNCES FISCAL 2018 RESULTS

[0000866706-18-000011:8k_2_02:10]
- GAAP EPS $3.54 Driven by Large Tax Benefit -

[0000866706-18-000011:8k_2_02:11]
- Adjusted EPS $2.77 ($0.02 Above Guide Range / $0.07 Above Consensus / 25% Above 2017) -

[0000866706-18-000011:8k_2_02:12]
ST. LOUIS, November 15, 2018 – ESCO Technologies Inc. (NYSE: ESE) (ESCO, or the Company) today reported its operating results for the fourth quarter (Q4 2018) and fiscal year ended September 30, 2018 (2018).

[0000866706-18-000011:8k_2_02:13]
The financial results presented include certain non-GAAP financial measures such as EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS, as defined within the "Non-GAAP Financial Measures" described below. Any non-GAAP financial measures presented are reconciled to their respective GAAP equivalents.

[0000866706-18-000011:8k_2_02:14]
Management believes these non-GAAP financial measures are useful in assessing the ongoing operational profitability of the Company's business segments, and therefore, allow shareholders better visibility into the Company's underlying operations. See "Non-GAAP Financial Measures" described below.

[0000866706-18-000011:8k_2_02:15]
Earnings Summary – Full Year

[0000866706-18-000011:8k_2_02:16]
2018 GAAP EPS of $3.54 per share reflects the favorable net impact of the December 2017 "Tax Cuts and Jobs Act" (U.S. Tax Reform) which resulted in a tax benefit of $24.4 million, or $0.94 per share, partially offset by $4.8 million, or $0.17 per share of cost reduction / restructuring charges incurred throughout the year and described in previous releases. The net effect of these discrete items is $0.77 per share.

[0000866706-18-000011:8k_2_02:17]
2018 Adjusted EPS, excluding the $0.77 per share noted above, was $2.77 per share and exceeded Management's Adjusted EPS guidance range of $2.65 to $2.75 per share, and was above the 2018 Adjusted EPS consensus estimate of $2.70 per share.

[0000866706-18-000011:8k_2_02:18]
2017 GAAP EPS was $2.07 per share and Adjusted EPS was $2.22 per share, which excluded $6.1 million, or $0.15 per share of non-cash purchase accounting inventory step-up charges and the costs incurred to complete the 2017 acquisitions described in previous releases.

[0000866706-18-000011:8k_2_02:19]
Adjusted EBITDA was $139 million in 2018, reflecting a 13 percent increase over 2017 Adjusted EBITDA of $123 million.

[0000866706-18-000011:8k_2_02:20]
Earnings Summary – Q4

[0000866706-18-000011:8k_2_02:21]
Q4 2018 GAAP EPS was $1.09 per share and Adjusted EPS was $1.22 per share, excluding $0.13 per share of after-tax charges related to cost reduction / restructuring actions taken to reduce future operating costs, and the true-up of income tax expense resulting from the implementation of U.S. Tax Reform.

[0000866706-18-000011:8k_2_02:22]
Q4 2017 GAAP EPS was $0.74 per share and Adjusted EPS was $0.79 per share, excluding $0.05 per share of non-cash purchase accounting inventory step-up charges and the costs incurred related to the 2017 acquisitions described previously.

[0000866706-18-000011:8k_2_02:23]
Q4 2018 Adjusted EPS increased 54 percent over Q4 2017 Adjusted EPS as Filtration, USG and Test significantly increased their respective EBIT contributions year-over-year.

[0000866706-18-000011:8k_2_02:24]
Adjusted EBITDA was $52 million in Q4 2018, reflecting a 21 percent increase over Q4 2017 Adjusted EBITDA of $43 million.

[0000866706-18-000011:8k_2_02:25]
Operating Highlights

[0000866706-18-000011:8k_2_02:26]
| · | Q4 2018 sales increased $24 million (12 percent) to $231 million compared to $207 million in Q4 2017; |

[0000866706-18-000011:8k_2_02:27]
| · | On a segment basis, Q4 2018 Filtration sales exceeded expectations and increased $11 million (13 percent) from Q4 2017 as aerospace and navy sales increased significantly, partially offset by lower industrial/automotive sales at PTI as previously communicated. Test sales increased 16 percent driven by strong backlog conversion to sales, and Technical Packaging sales increased 5 percent. USG sales from Doble, Morgan Schaffer and Vanguard increased 14 percent in the aggregate, while NRG's sales to renewable energy customers decreased, resulting in USG's net sales increase of 7 percent; |

[0000866706-18-000011:8k_2_02:28]
| · | SG&A expenses decreased $2 million in Q4 2018 compared to Q4 2017 due to the impact of the cost reduction actions taken throughout the year; |

[0000866706-18-000011:8k_2_02:29]
| · | Entered orders were $188 million in Q4 2018 (book-to-bill of .81x) and $777 million for 2018 (book-to-bill of 1.01x) which resulted in an ending backlog of $383 million at September 30, 2018. The Q4 2018 book-to-bill ratio resulted from the strength of Q4 2018's record sales level; |

[0000866706-18-000011:8k_2_02:30]
| · | Q4 2018 GAAP income tax rate was 25.8 percent which was consistent with Management's previous expectations of 26 percent. The GAAP effective tax rate of (4.7) percent in 2018 was significantly impacted by U.S. Tax Reform, and was modified when calculating Adjusted EPS as noted above; |

[0000866706-18-000011:8k_2_02:31]
| · | 2018 net cash provided by operating activities was $93 million ($103 million excluding pension funding contributions intended to reduce the operating costs of the previously frozen plan) resulting in $190 million of net debt outstanding (total borrowings less cash on hand) at September 30, 2018, with a 1.7x leverage ratio. During Q4 2018, the Company repatriated a substantial portion of its foreign cash to pay down its outstanding debt and for general corporate purposes. |

[0000866706-18-000011:8k_2_02:32]
Chairman's Commentary – 2018

[0000866706-18-000011:8k_2_02:33]
Vic Richey, Chairman and Chief Executive Officer, commented, "2018 was a successful year across several financial and operational metrics. I'm really pleased with our solid performance in Q4 which allowed us to wrap up 2018 in a strong fashion by meeting, or exceeding many of the goals we established at the start of the year. We set aggressive targets last November, and through the tremendous efforts of our entire team, coupled with our multi-segment strategy which allows us to diversify our risk across numerous end-markets, we achieved our stated objectives and delivered our earnings commitments. I'm proud to report that we delivered quarterly operating results that were at the high end, or exceeded, our 2018 earnings targets while delivering a record level of operating cash flow.

[0000866706-18-000011:8k_2_02:34]
"Touching on a few highlights of our Q4 performance compared to Q4 2017: Filtration sales increased 13 percent resulting in a 26 percent EBIT margin compared to 22 percent; Test sales increased 16 percent on the strength of its backlog and delivered an impressive 17 percent EBIT margin, up from 16 percent; USG increased sales despite some softness in the renewable energy space, and with its favorable sales mix, delivered an Adjusted EBIT margin of 29 percent, up from 23 percent; and, Technical Packaging increased sales 5 percent and maintained an EBIT margin of approximately 12 percent in the comparable periods.

[0000866706-18-000011:8k_2_02:35]
"We generated nearly $40 million of cash from operating activities during Q4 and $103 million for the year, when excluding pension funding contributions. This allowed us to significantly pay down debt and positions us well for future M&A spending.

[0000866706-18-000011:8k_2_02:36]
"The inability to close on additional M&A transactions in 2018 was disappointing, but it was not for lack of effort or opportunity. Several deals where we were fully engaged, ended up trading for multiples well above our ROIC metrics. We currently have a robust M&A pipeline in both Filtration and USG and continue to work these opportunities, but we will remain prudent and committed to our disciplined approach of balancing ROIC and protecting our balance sheet.

[0000866706-18-000011:8k_2_02:37]
"Our recent acquisitions, now fully integrated, are making meaningful contributions and we continue to see additional sales opportunities from rationalizing our distribution channels and maximizing our sales efficiency.

[0000866706-18-000011:8k_2_02:38]
"Consistent with our previous restructuring actions announced at Doble, during Q4 we eliminated additional direct sales offices and related staff and expanded our use of lower cost rep and distributor sales channels. These cost reduction and margin enhancement opportunities should produce immediate and measureable savings in 2019, and we will continue this unrelenting diligence in identifying improved operating efficiencies across all of our platforms globally.

[0000866706-18-000011:8k_2_02:39]
"As we enter 2019, we plan to build on the successes we achieved in 2018 and expect to benefit from our lower cost structure going forward. Our market positions and continued growth opportunities across the Company provide us with a favorable view of the future with our goal remaining unchanged – to increase long-term shareholder value."

[0000866706-18-000011:8k_2_02:40]
Dividend Payment

[0000866706-18-000011:8k_2_02:41]
The next quarterly cash dividend of $0.08 per share will be paid on January 18, 2019 to stockholders of record on January 3, 2019.

[0000866706-18-000011:8k_2_02:42]
New Revenue Recognition Standard

[0000866706-18-000011:8k_2_02:43]
On October 1, 2018, the Company formally adopted ASC Topic 606, Revenue from Contracts with Customers ("New Revenue Recognition Standard") using the modified retrospective method. Operating results for reporting periods beginning after October 1, 2018 will be presented under the New Revenue Recognition Standard, while the results from prior periods will not be adjusted and will continue to be presented using our historic accounting method.

[0000866706-18-000011:8k_2_02:44]
Adoption of the New Revenue Recognition Standard will primarily affect the Filtration segment (VACCO, in particular) and is estimated to negatively impact 2019 GAAP reported sales and EBIT by approximately $9 million and $2 million, respectively. These amounts will have no impact on 2019 cash flows.

[0000866706-18-000011:8k_2_02:45]
Business Outlook – 2019

[0000866706-18-000011:8k_2_02:46]
Management continues to see meaningful organic sales, Adjusted EBIT, and Adjusted EBITDA growth across each of the Company's business segments and anticipates growth rates in 2019 and beyond that will generally exceed the broader industrial market. The organic growth described below is expected to be enhanced by additional M&A contributions.

[0000866706-18-000011:8k_2_02:47]
Management's focus on profitable growth, increased cash flow, an enhanced cost structure driving efficiency and creating competitive advantages, coupled with incremental ROIC, will be the key drivers of sustainable share price appreciation.

[0000866706-18-000011:8k_2_02:48]
To enhance Doble's ROIC and further improve its operating efficiency, in October 2018, the Company sold Doble's headquarters building in Watertown Massachusetts to a real estate developer for approximately $18 million in cash, and later in 2019, will consolidate its operations into one location in Marlborough Massachusetts where Doble has an existing administrative facility. The sale resulted in a pretax gain that will be recognized in Q1 2019. The net proceeds were used to further pay down debt, and the upcoming move will improve operational efficiency by having Doble's entire U.S. operations co-located in a single, lower cost, more modern facility. The gain (approximately $7 million, pretax) and the restructuring / move costs (approximately $1.5 million, pretax) will be excluded when calculating 2019 Adjusted EPS.

[0000866706-18-000011:8k_2_02:49]
To reduce Technical Packaging's cost structure and increase its EBIT margins, the Company initiated a cost reduction action in Europe to close Plastique's headquarters in Tunbridge Wells, UK and consolidate its new product design and administrative functions into the remaining facilities in Nottingham, UK and Poznan, Poland. This move is expected to generate meaningful operating improvements and will enable Plastique to be more competitive in its various end-markets. The shut down and move costs (approximately $2 million, pretax) will be excluded when calculating 2019 Adjusted EPS.

[0000866706-18-000011:8k_2_02:50]
Additionally, the Company will be moving VACCO's aircraft / aerospace business (approximately $8 million in annual revenue) from South El Monte California and consolidating it into PTI's aerospace facility in Oxnard California. This will enable PTI to maximize its aircraft / aerospace customer relationships and market expertise and utilize manufacturing floor space made available by the elimination of its automotive / industrial business during 2018, while allowing VACCO to concentrate on its growing navy / submarine and space business. These move costs (approximately $1 million) will also be excluded when calculating 2019 Adjusted EPS.

[0000866706-18-000011:8k_2_02:51]
All of these actions are intended to improve operating efficiency, generate additional free cash flow, and enhance the Company's competitiveness across several end-markets, thereby, accelerating annual sales and earnings growth in the future.

[0000866706-18-000011:8k_2_02:52]
Given these actions, Management's expectations for sales growth, Adjusted EBIT, Adjusted EBIT margins, Adjusted EBITDA and Adjusted EPS for 2019 compared to 2018 are as follows:

[0000866706-18-000011:8k_2_02:53]
| · | Organic sales are expected to increase in 2019 in the mid-single digits on a consolidated basis, with Filtration and Technical Packaging growing 4 to 6 percent each, USG growing 5 to 7 percent (partially muted by slower growth in the renewable energy space at NRG) and Test growing 3 to 5 percent; |

[0000866706-18-000011:8k_2_02:54]
| · | Adjusted EBIT and Adjusted EBITDA are expected to increase approximately 9 to 10 percent with Adjusted EBIT and Adjusted EBITDA margins increasing nearly a full point; |

[0000866706-18-000011:8k_2_02:55]
| · | Interest expense is expected to be similar to 2018 despite the lower debt levels as the Company is projecting higher interest rates over the next 12 months; |

[0000866706-18-000011:8k_2_02:56]
| · | Non-cash depreciation and amortization of intangibles is expected to increase approximately $3.7 million (or $0.11 per share after-tax) related to previous acquisitions and capital spending; |

[0000866706-18-000011:8k_2_02:57]
| · | Income tax expense is expected to increase in 2019 as Management is projecting a 24 percent effective tax rate calculated on higher pretax earnings, compared to the 22 percent effective tax rate used in calculating 2018 Adjusted EPS. The 2 percent tax rate increase impacts 2019 Adjusted EPS by ($0.08) per share; |

[0000866706-18-000011:8k_2_02:58]
| · | In summary, Management projects 2019 Adjusted EPS to be in the range of $2.95 to $3.05 per share reflecting meaningful organic sales and Adjusted EBITDA growth partially offset by the additional depreciation and amortization charges and incremental tax expense as noted above. |

[0000866706-18-000011:8k_2_02:59]
On a quarterly basis during and consistent with prior years, Management expects 2019 revenues and Adjusted EPS to be more back half weighted with the second half of the year being stronger than the first half.

[0000866706-18-000011:8k_2_02:60]
Management expects Q1 2019 Adjusted EPS to be in the range of $0.40 to $0.45 per share. The timing of quarterly sales and earnings throughout the year, coupled with the discrete charges described above within the respective quarters will impact quarterly comparability.

[0000866706-18-000011:8k_2_02:61]
Conference Call

[0000866706-18-000011:8k_2_02:62]
The Company will host a conference call today, November 15, at 4:00 p.m. Central Time, to discuss the Company's 2018 results. A live audio webcast will be available on the Company's website at www.escotechnologies.com. Please access the website at least 15 minutes prior to the call to register, download and install any necessary audio software. A replay of the conference call will be available for seven days on the Company's website noted above or by phone (dial 1-855-859-2056 and enter the pass code 2888246).

[0000866706-18-000011:8k_2_02:63]
Forward-Looking Statements

[0000866706-18-000011:8k_2_02:64]
Statements in this press release regarding the timing and amounts of the Company's expected quarterly, 2019 full year and beyond results, revenue and sales growth, EPS, Adjusted EPS, EPS growth, cash, EBIT, Adjusted EBIT, EBITDA, Adjusted EBITDA, interest expense, income tax expense, effective tax rates, cash generation, the realization of operational efficiencies, and the costs and savings resulting from operational improvements and cost reduction actions, the Company's ability to increase operating margins, realize financial goals and increase shareholder value, the success of acquisition efforts, the long-term success of the Company, and any other statements which are not strictly historical are "forward-looking" statements within the meaning of the safe harbor provisions of the federal securities laws.

[0000866706-18-000011:8k_2_02:65]
Investors are cautioned that such statements are only predictions and speak only as of the date of this release, and the Company undertakes no duty to update them except as may be required by applicable laws or regulations. The Company's actual results in the future may differ materially from those projected in the forward-looking statements due to risks and uncertainties that exist in the Company's operations and business environment including, but not limited to those described in Item 1A, "Risk Factors", of the Company's Annual Report on Form 10-K for the fiscal year ended September 30, 2017, and the following: the success of the Company's competitors; weakening of economic conditions in served markets; changes in customer demands or customer insolvencies; competition; intellectual property rights; technical difficulties; delivery delays or defaults by customers; material changes in the costs and availability of certain raw materials; the appropriation, allocation and availability of Government funds; the termination for convenience of Government and other customer contracts; the timing and content of future contract awards or customer orders; performance issues with key customers, suppliers and subcontractors; labor disputes; the impacts of natural disasters on the Company's operations and those of the Company's customers and suppliers; changes in laws and regulations, including but not limited to changes in accounting standards and taxation requirements; changes in interest rates; costs relating to environmental matters arising from current or former facilities; financial exposure in connection with Company guarantees of certain Aclara contracts; the availability of select acquisitions; uncertainty regarding the ultimate resolution of current disputes, claims, litigation or arbitration; and the success and integration of recently acquired businesses.

[0000866706-18-000011:8k_2_02:66]
Non-GAAP Financial Measures

[0000866706-18-000011:8k_2_02:67]
The financial measures EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS are presented in this press release. The Company defines "EBIT" as earnings before interest and taxes, "EBITDA" as earnings before interest, taxes, depreciation and amortization, "Adjusted EBITDA" as EBITDA excluding certain defined charges, and "Adjusted EPS" as GAAP earnings per share (EPS) excluding the net impact of the items described above which were $0.77 per share in 2018.

[0000866706-18-000011:8k_2_02:68]
EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS are not recognized in accordance with U.S. generally accepted accounting principles (GAAP). However, Management believes that EBIT, EBITDA and Adjusted EBITDA are useful in assessing the operational profitability of the Company's business segments because they exclude interest, taxes, depreciation and amortization, which are generally accounted for across the entire Company on a consolidated basis. EBIT is also one of the measures used by Management in determining resource allocations within the Company as well as incentive compensation. The Company believes that the presentation of EBIT, EBITDA, Adjusted EBITDA and Adjusted EPS provides important supplemental information to investors by facilitating comparisons with other companies, many of which use similar non-GAAP financial measures to supplement their GAAP results. The use of non-GAAP financial measures is not intended to replace any measures of performance determined in accordance with GAAP.

[0000866706-18-000011:8k_2_02:69]
ESCO, headquartered in St. Louis: Manufactures highly-engineered filtration and fluid control products for the aviation, space and process markets worldwide; is the industry leader in RF shielding and EMC test products; provides diagnostic instruments, software and services for the benefit of industrial power users and the electric utility and renewable energy industries; and, produces custom thermoformed packaging, pulp-based packaging, and specialty products for medical and commercial markets. Further information regarding ESCO and its subsidiaries is available on the Company's website at www.escotechnologies.com.

[0000866706-18-000011:8k_2_02:70]
-tables attached-

[0000866706-18-000011:8k_2_02:71]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |  |  |
| Condensed Consolidated Statements of Operations (Unaudited) |  |  |  |
| (Dollars in thousands, except per share amounts) |  |  |  |
|  |  | Three Months Ended September 30, 2018 |  |  |  |  | Three Months Ended September 30, 2017 |  |  |  |
| Net Sales |  | $ | 231,086 |  |  |  |  |  | 207,005 |  |  |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 143,486 |  |  |  |  |  | 129,769 |  |  |  |
| Selling, general and administrative expenses |  |  | 39,618 |  |  |  |  |  | 41,329 |  |  |  |
| Amortization of intangible assets |  |  | 4,713 |  |  |  |  |  | 4,790 |  |  |  |
| Interest expense |  |  | 2,284 |  |  |  |  |  | 1,826 |  |  |  |
| Other expenses, net |  |  | 2,663 |  |  |  |  |  | (496 | ) |  |  |
| Total costs and expenses |  |  | 192,764 |  |  |  |  |  | 177,218 |  |  |  |
| Earnings before income taxes |  |  | 38,322 |  |  |  |  |  | 29,787 |  |  |  |
| Income taxes |  |  | 9,870 |  |  |  |  |  | 10,613 |  |  |  |
| Net earnings |  | $ | 28,452 |  |  |  |  |  | 19,174 |  |  |  |
| Diluted EPS: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP EPS |  | $ | 1.09 |  |  |  |  |  | 0.74 |  |  |  |
| Adjusted EPS |  | $ | 1.22 | (1) |  |  |  |  |  |  | 0.79 | (2) |  |  |  |  |
| Diluted average common shares O/S: |  |  | 26,103 |  |  |  |  |  |  |  | 26,057 |  |  |  |  |  |

[0000866706-18-000011:8k_2_02:72]
| (1) |  | Q4 2018 Adjusted EPS excludes $0.13 per share of after-tax charges incurred related to the Q4 2018 restructuring actions and the true-up of tax expense recorded resulting from the implementation of U.S. Tax Reform. |  |
| (2) |  | Q4 2017 Adjusted EPS excludes $0.05 per share of after-tax purchase accounting inventory step-up charges and acquisition costs incurred during the quarter. |  |

[0000866706-18-000011:8k_2_02:73]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |  |  |
| Condensed Consolidated Statements of Operations (Unaudited) |  |  |  |
| (Dollars in thousands, except per share amounts) |  |  |  |
|  |  | Year Ended September 30, 2018 |  |  |  |  | Year Ended September 30, 2017 |  |  |  |
| Net Sales |  | $ | 771,582 |  |  |  |  |  | 685,740 |  |  |  |
| Cost and Expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of sales |  |  | 490,397 |  |  |  |  |  | 436,918 |  |  |  |
| Selling, general and administrative expenses |  |  | 162,431 |  |  |  |  |  | 148,433 |  |  |  |
| Amortization of intangible assets |  |  | 18,328 |  |  |  |  |  | 16,338 |  |  |  |
| Interest expense |  |  | 8,748 |  |  |  |  |  | 4,578 |  |  |  |
| Other (income) expenses, net |  |  | 3,655 |  |  |  |  |  | (680 | ) |  |  |
| Total costs and expenses |  |  | 683,559 |  |  |  |  |  | 605,587 |  |  |  |
| Earnings before income taxes |  |  | 88,023 |  |  |  |  |  | 80,153 |  |  |  |
| Income taxes |  |  | (4,113 | ) |  |  |  |  | 26,450 |  |  |  |
| Net earnings |  | $ | 92,136 |  |  |  |  |  | 53,703 |  |  |  |
| Diluted EPS: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP EPS |  | $ | 3.54 |  |  |  |  |  | 2.07 |  |  |  |
| Adjusted EPS |  | $ | 2.77 | (1) |  |  |  |  |  |  | 2.22 | (2) |  |  |  |  |
| Diluted average common shares O/S: |  |  | 26,058 |  |  |  |  |  |  |  | 25,995 |  |  |  |  |  |

[0000866706-18-000011:8k_2_02:74]
| (1) |  | FY 2018 Adjusted EPS excludes $0.17 per share of after-tax charges incurred related to the 2018 restructuring actions, and excludes a ($.94) net tax benefit recorded resulting from the implementation of U.S. Tax Reform. |  |
| (2) |  | FY 2017 Adjusted EPS excludes $0.15 per share of after-tax purchase accounting inventory step-up charges and acquisition costs incurred during 2017. |  |

[0000866706-18-000011:8k_2_02:75]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Condensed Business Segment Information (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  | GAAP |  |  | As Adjusted |  |
|  |  |  | Q4 2018 |  |  |  | Q4 2017 |  |  |  | Q4 2018 |  |  |  | Q4 2017 |  |
| Net Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 91,274 |  |  |  | 80,640 |  |  |  | 91,274 |  |  |  | 80,640 |  |
| Test |  |  | 59,523 |  |  |  | 51,115 |  |  |  | 59,523 |  |  |  | 51,115 |  |
| USG |  |  | 56,013 |  |  |  | 52,183 |  |  |  | 56,013 |  |  |  | 52,183 |  |
| Technical Packaging |  |  | 24,276 |  |  |  | 23,067 |  |  |  | 24,276 |  |  |  | 23,067 |  |
| Totals |  | $ | 231,086 |  |  |  | 207,005 |  |  |  | 231,086 |  |  |  | 207,005 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 23,615 |  |  |  | 17,905 |  |  |  | 23,961 |  |  |  | 17,905 |  |
| Test |  |  | 10,029 |  |  |  | 8,404 |  |  |  | 10,029 |  |  |  | 8,404 |  |
| USG |  |  | 15,364 |  |  |  | 11,010 |  |  |  | 16,399 |  |  |  | 12,196 |  |
| Technical Packaging |  |  | 2,721 |  |  |  | 2,836 |  |  |  | 2,721 |  |  |  | 2,836 |  |
| Corporate |  |  | (11,123 | ) |  |  | (8,542 | ) |  |  | (10,252 | ) |  |  | (7,911 | ) |
| Consolidated EBIT |  |  | 40,606 |  |  |  | 31,613 |  |  |  | 42,858 |  |  |  | 33,430 |  |
| Less: Interest expense |  |  | (2,284 | ) |  |  | (1,826 | ) |  |  | (2,284 | ) |  |  | (1,826 | ) |
| Less: Income tax expense |  |  | (9,870 | ) |  |  | (10,613 | ) |  |  | (8,582 | ) |  |  | (11,249 | ) |
| Net earnings |  | $ | 28,452 |  |  |  | 19,174 |  |  |  | 31,992 |  |  |  | 20,355 |  |

[0000866706-18-000011:8k_2_02:76]
| Note 1: Adjusted net earnings were $32.0 million in Q4 18 which excludes $0.13 per share of after-tax charges incurred related to the Q4 18 restructuring actions, and the true-up of tax expense recorded resulting from the implementation of U.S. Tax Reform. |  |
| Note 2: Adjusted net earnings were $20.4 million in Q4 17 which excludes $0.05 per share of after-tax purchase accounting inventory step-up charges and acquisition costs incurred during Q4 17. |  |

[0000866706-18-000011:8k_2_02:77]
| EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Q4 2018 |  |  |  |  |  |  | Q4 2017 |  |
|  |  |  | Q4 2018 |  | - As Adj |  |  |  | Q4 2017 |  | - As Adj |  |
| Consolidated EBITDA |  | $ | 50,011 |  |  |  | 52,263 |  |  |  | 40,819 |  |  |  | 42,636 |  |
| Less: Depr & Amort |  |  | (9,405 | ) |  |  | (9,405 | ) |  |  | (9,206 | ) |  |  | (9,206 | ) |
| Consolidated EBIT |  |  | 40,606 |  |  |  | 42,858 |  |  |  | 31,613 |  |  |  | 33,430 |  |
| Less: Interest expense |  |  | (2,284 | ) |  |  | (2,284 | ) |  |  | (1,826 | ) |  |  | (1,826 | ) |
| Plus (Less): Income Tax |  |  | (9,870 | ) |  |  | (8,582 | ) |  |  | (10,613 | ) |  |  | (11,249 | ) |
| Net earnings |  | $ | 28,452 |  |  |  | 31,992 |  |  |  | 19,174 |  |  |  | 20,355 |  |

[0000866706-18-000011:8k_2_02:78]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Condensed Business Segment Information (Unaudited) |  |
| (Dollars in thousands) |  |
|  | GAAP |  | As Adjusted |  |
|  | FY 2018 |  | FY 2017 |  | FY 2018 |  | FY 2017 |  |
| Net Sales |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 286,805 |  |  |  | 279,510 |  |  |  | 286,805 |  |  |  | 279,510 |  |
| Test |  |  | 182,892 |  |  |  | 160,853 |  |  |  | 182,892 |  |  |  | 160,853 |  |
| USG |  |  | 213,953 |  |  |  | 162,469 |  |  |  | 213,953 |  |  |  | 162,469 |  |
| Technical Packaging |  |  | 87,932 |  |  |  | 82,908 |  |  |  | 87,932 |  |  |  | 82,908 |  |
| Totals |  | $ | 771,582 |  |  |  | 685,740 |  |  |  | 771,582 |  |  |  | 685,740 |  |
| EBIT |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Filtration |  | $ | 58,670 |  |  |  | 52,201 |  |  |  | 59,464 |  |  |  | 54,137 |  |
| Test |  |  | 23,826 |  |  |  | 19,481 |  |  |  | 23,826 |  |  |  | 19,481 |  |
| USG |  |  | 43,169 |  |  |  | 36,596 |  |  |  | 46,121 |  |  |  | 38,477 |  |
| Technical Packaging |  |  | 8,075 |  |  |  | 8,495 |  |  |  | 8,075 |  |  |  | 8,495 |  |
| Corporate |  |  | (36,969 | ) |  |  | (32,042 | ) |  |  | (35,875 | ) |  |  | (29,775 | ) |
| Consolidated EBIT |  |  | 96,771 |  |  |  | 84,731 |  |  |  | 101,611 |  |  |  | 90,815 |  |
| Less: Interest expense |  |  | (8,748 | ) |  |  | (4,578 | ) |  |  | (8,748 | ) |  |  | (4,578 | ) |
| Less: Income tax expense |  |  | 4,113 |  |  |  | (26,450 | ) |  |  | (20,665 | ) |  |  | (28,579 | ) |
| Net earnings |  | $ | 92,136 |  |  |  | 53,703 |  |  |  | 72,198 |  |  |  | 57,658 |  |

[0000866706-18-000011:8k_2_02:79]
| Note 1: Adjusted net earnings were $72.2 million in FY 18 which excludes $0.17 per share of after-tax charges incurred related to the 2018 restructuring actions, and excludes a ($.94) net tax benefit recorded resulting from the implementation of U.S. Tax Reform. |  |
| Note 2: Adjusted net earnings were $57.7 million in FY 17 which excludes $0.15 per share of after-tax purchase accounting inventory step-up charges and acquisition costs incurred during 2017. |  |

[0000866706-18-000011:8k_2_02:80]
| EBITDA Reconciliation to Net earnings: |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  | FY 2018 |  |  |  |  |  | FY 2017 |  |
|  | FY 2018 |  | - As Adj |  | FY 2017 |  | - As Adj |  |
| Consolidated EBITDA |  | $ | 134,526 |  |  |  | 139,366 |  |  |  | 116,960 |  |  |  | 123,044 |  |
| Less: Depr & Amort |  |  | (37,755 | ) |  |  | (37,755 | ) |  |  | (32,229 | ) |  |  | (32,229 | ) |
| Consolidated EBIT |  |  | 96,771 |  |  |  | 101,611 |  |  |  | 84,731 |  |  |  | 90,815 |  |
| Less: Interest expense |  |  | (8,748 | ) |  |  | (8,748 | ) |  |  | (4,578 | ) |  |  | (4,578 | ) |
| Plus (Less): Income Tax |  |  | 4,113 |  |  |  | (20,665 | ) |  |  | (26,450 | ) |  |  | (28,579 | ) |
| Net earnings |  | $ | 92,136 |  |  |  | 72,198 |  |  |  | 53,703 |  |  |  | 57,658 |  |

[0000866706-18-000011:8k_2_02:81]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Condensed Consolidated Balance Sheets (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  | September 30, 2018 |  |  | September 30, 2017 |  |
| Assets |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 30,477 |  |  |  | 45,516 |  |
| Accounts receivable, net |  |  | 163,740 |  |  |  | 160,580 |  |
| Costs and estimated earnings on |  |  |  |  |  |  |  |  |
| long-term contracts |  |  | 53,034 |  |  |  | 47,286 |  |
| Inventories |  |  | 135,416 |  |  |  | 124,515 |  |
| Other current assets |  |  | 13,356 |  |  |  | 14,895 |  |
| Total current assets |  |  | 396,023 |  |  |  | 392,792 |  |
| Property, plant and equipment, net |  |  | 134,954 |  |  |  | 132,748 |  |
| Intangible assets, net |  |  | 345,353 |  |  |  | 351,134 |  |
| Goodwill |  |  | 381,652 |  |  |  | 377,879 |  |
| Other assets |  |  | 7,140 |  |  |  | 5,891 |  |
|  |  | $ | 1,265,122 |  |  |  | 1,260,444 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |  |  |
| Short-term borrowings and current |  | $ | 20,000 |  |  |  | 20,000 |  |
| maturities of long-term debt |  |  |  |  |  |  |  |  |
| Accounts payable |  |  | 63,033 |  |  |  | 54,789 |  |
| Current portion of deferred revenue |  |  | 29,568 |  |  |  | 28,583 |  |
| Other current liabilities |  |  | 87,929 |  |  |  | 91,597 |  |
| Total current liabilities |  |  | 200,530 |  |  |  | 194,969 |  |
| Deferred tax liabilities |  |  | 64,794 |  |  |  | 86,378 |  |
| Other liabilities |  |  | 40,388 |  |  |  | 52,179 |  |
| Long-term debt |  |  | 200,000 |  |  |  | 255,000 |  |
| Shareholders' equity |  |  | 759,410 |  |  |  | 671,918 |  |
|  |  | $ | 1,265,122 |  |  |  | 1,260,444 |  |

[0000866706-18-000011:8k_2_02:82]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Consolidated Statements of Cash Flows (Unaudited) |  |
| (Dollars in thousands) |  |
|  |  | Year Ended September 30, 2018 |  |
| Cash flows from operating activities: |  |  |  |
| Net earnings |  | $ | 92,136 |  |
| Adjustments to reconcile net earnings |  |  |  |  |
| to net cash provided by operating activities: |  |  |  |  |
| Depreciation and amortization |  |  | 37,755 |  |
| Stock compensation expense |  |  | 5,218 |  |
| Changes in assets and liabilities |  |  | (11,833 | ) |
| Effect of deferred taxes |  |  | (21,584 | ) |
| Change in deferred revenue and costs, net |  |  | 1,518 |  |
| Pension contributions |  |  | (9,951 | ) |
| Net cash provided by operating activities |  |  | 93,259 |  |
| Cash flows from investing activities: |  |  |  |  |
| Acquisition of business, net of cash acquired |  |  | (11,445 | ) |
| Capital expenditures |  |  | (20,589 | ) |
| Additions to capitalized software |  |  | (9,573 | ) |
| Net cash used by investing activities |  |  | (41,607 | ) |
| Cash flows from financing activities: |  |  |  |  |
| Proceeds from long-term debt |  |  | 55,000 |  |
| Principal payments on long-term debt |  |  | (110,000 | ) |
| Dividends paid |  |  | (8,278 | ) |
| Other |  |  | (3,078 | ) |
| Net cash used by financing activities |  |  | (66,356 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (335 | ) |
| Net decrease in cash and cash equivalents |  |  | (15,039 | ) |
| Cash and cash equivalents, beginning of period |  |  | 45,516 |  |
| Cash and cash equivalents, end of period |  | $ | 30,477 |  |

[0000866706-18-000011:8k_2_02:83]
| ESCO TECHNOLOGIES INC. AND SUBSIDIARIES |  |
| Other Selected Financial Data (Unaudited) |  |
| (Dollars in thousands) |  |
| Backlog And Entered Orders - Q4 FY 2018 | Filtration |  | Test |  | USG |  | Technical Packaging |  | Total |  |
| Beginning Backlog - 7/1/18 |  | $ | 226,731 |  |  |  | 135,626 |  |  |  | 45,616 |  |  |  | 17,545 |  |  |  | 425,518 |  |
| Entered Orders |  |  | 68,770 |  |  |  | 46,247 |  |  |  | 51,124 |  |  |  | 22,198 |  |  |  | 188,339 |  |
| Sales |  |  | (91,274 | ) |  |  | (59,523 | ) |  |  | (56,013 | ) |  |  | (24,276 | ) |  |  | (231,086 | ) |
| Ending Backlog - 9/30/18 |  | $ | 204,227 |  |  |  | 122,350 |  |  |  | 40,727 |  |  |  | 15,467 |  |  |  | 382,771 |  |
| Backlog And Entered Orders - FY 2018 | Filtration |  | Test |  | USG |  | Technical Packaging |  | Total |  |
| Beginning Backlog - 10/1/17 |  | $ | 203,120 |  |  |  | 114,792 |  |  |  | 35,581 |  |  |  | 23,614 |  |  |  | 377,107 |  |
| Entered Orders |  |  | 287,912 |  |  |  | 190,450 |  |  |  | 219,099 |  |  |  | 79,785 |  |  |  | 777,246 |  |
| Sales |  |  | (286,805 | ) |  |  | (182,892 | ) |  |  | (213,953 | ) |  |  | (87,932 | ) |  |  | (771,582 | ) |
| Ending Backlog - 9/30/18 |  | $ | 204,227 |  |  |  | 122,350 |  |  |  | 40,727 |  |  |  | 15,467 |  |  |  | 382,771 |  |

## item 5.02 — body, verbatim

[0000866706-18-000011:8k_body:1]
Item 5.02                          Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers

[0000866706-18-000011:8k_body:2]
On November 14, 2018, the Human Resources and Compensation Committee (the "Committee") of the Company's Board of Directors approved the following fiscal 2019 base salaries and target cash incentive compensation opportunities for its executive officers. The Committee determined that for each of the executive officers a 4.0% increase in total cash compensation was warranted, and (as it had done for 2018) provided the executive officers with the discretion to allocate the increase prospectively between their base salaries and their cash incentive targets. Mr. Richey elected to allocate all of his increase to his cash incentive target, and Mr. Muenster and Ms. Barclay elected to allocate their increases between their base salaries and their cash incentive targets, as follows:

[0000866706-18-000011:8k_body:3]
Officer

[0000866706-18-000011:8k_body:4]
Fiscal 2019

[0000866706-18-000011:8k_body:5]
Base Salary

[0000866706-18-000011:8k_body:6]
% Increase from

[0000866706-18-000011:8k_body:7]
Fiscal 2018

[0000866706-18-000011:8k_body:8]
Fiscal 2019 Target Cash Incentive Compensation

[0000866706-18-000011:8k_body:9]
% Increase from

[0000866706-18-000011:8k_body:10]
Fiscal 2018

[0000866706-18-000011:8k_body:11]
Victor L. Richey

[0000866706-18-000011:8k_body:12]
$

[0000866706-18-000011:8k_body:13]
824,500

[0000866706-18-000011:8k_body:14]
None

[0000866706-18-000011:8k_body:15]
$

[0000866706-18-000011:8k_body:16]
852,500

[0000866706-18-000011:8k_body:17]
8.2

[0000866706-18-000011:8k_body:18]
%

[0000866706-18-000011:8k_body:19]
Gary E. Muenster

[0000866706-18-000011:8k_body:20]
$

[0000866706-18-000011:8k_body:21]
576,000

[0000866706-18-000011:8k_body:22]
4.7

[0000866706-18-000011:8k_body:23]
%

[0000866706-18-000011:8k_body:24]
$

[0000866706-18-000011:8k_body:25]
460,600

[0000866706-18-000011:8k_body:26]
3.1

[0000866706-18-000011:8k_body:27]
%

[0000866706-18-000011:8k_body:28]
Alyson S. Barclay

[0000866706-18-000011:8k_body:29]
$

[0000866706-18-000011:8k_body:30]
350,600

[0000866706-18-000011:8k_body:31]
3.9

[0000866706-18-000011:8k_body:32]
%

[0000866706-18-000011:8k_body:33]
$

[0000866706-18-000011:8k_body:34]
217,800

[0000866706-18-000011:8k_body:35]
4.2

[0000866706-18-000011:8k_body:36]
%

[0000866706-18-000011:8k_body:37]
For fiscal 2019 the Committee determined to allocate 100% of the executive officers' cash incentive compensation opportunity to the Company's Performance Compensation Plan ("PCP"). The Committee also approved the fiscal 2019 performance criteria for determining the percentage of such target incentive compensation opportunity that will actually be earned by the executive officers, depending on actual fiscal 2019 results compared to the criteria. The Committee established two performance criteria for fiscal 2019:

[0000866706-18-000011:8k_body:38]
·

[0000866706-18-000011:8k_body:39]
Earnings per share adjusted for certain defined non-recurring gains and charges  ("Adjusted EPS"), weighted at 70% of the total target opportunity; and

[0000866706-18-000011:8k_body:40]
·

[0000866706-18-000011:8k_body:41]
Cash generated from operations at the subsidiary level, including corporate cash activity related to debt and interest payments, tax payments, pension contributions and corporate general administrative expenses, and excluding corporate cash activity related to acquisitions, dividends and share repurchases ("Cash Flow"), weighted at 30% of the total target opportunity.

[0000866706-18-000011:8k_body:42]
The actual cash incentive compensation payable under the PCP for fiscal 2019 will range from 0.2 to 2.0 times the target opportunity for both Adjusted EPS and Cash Flow, depending on actual 2019 performance, based on a separate matrix for each of the measures.
