# ESE 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001144204-18-062244:item_9a:1]
Item 9A. Controls and Procedures

[0001144204-18-062244:item_9a:2]
For 2018, the Company carried out an evaluation of the effectiveness
of the design and operation of the Company’s disclosure controls and procedures, as defined in Rules 13a-15(e) and 15d-15(e)
under the Securities Exchange Act of 1934, as amended (the Exchange Act). The evaluation was conducted under the supervision and
with the participation of the Company’s Management, including the Company’s Chief Executive Officer and Chief Financial
Officer, using the Internal Control – Integrated Framework (2013) issued by the Committee of Sponsoring Organizations
of the Treadway Commission (COSO). Disclosure controls and procedures are designed to ensure that information required to be disclosed
by the Company in reports filed or submitted under the Exchange Act is recorded, processed, summarized and reported within the
time periods specified in the Securities and Exchange Commission’s rules and forms. Based upon that evaluation, the Company’s
Chief Executive Officer and Chief Financial Officer concluded that the Company’s disclosure controls and procedures were
not effective as of September 30, 2018, as a result of a material weakness in the Company’s internal control over financial
reporting related to the ineffective design and operation of controls impacting the deferred revenue general ledger account, as
described in Management’s Report on Internal Control over Financial Reporting.

[0001144204-18-062244:item_9a:3]
Notwithstanding the material weakness impacting the deferred
revenue general ledger account, Management has concluded that the Consolidated Financial Statements included in this Form 10-K
fairly present, in all material respects, the financial position of the Company as of September 30, 2018 and 2017 and the consolidated
results of operations and cash flows for each of the three years in the period ended September 30, 2018, in conformity with U.S.
generally accepted accounting principles.

[0001144204-18-062244:item_9a:4]
For additional information required by this item, see “Management’s
Report on Internal Control over Financial Reporting” in the Financial Information section beginning on page F-1 of this Form 10-K, which is incorporated into
this Item by reference.

[0001144204-18-062244:item_9a:5]
Other than identifying the specific deficiencies related to
the material weakness disclosed, there were no changes in the Company’s internal control over financial reporting (as defined
in Rule 13a-15(f) under the Exchange Act) during the fiscal quarter ended September 30, 2018 that have materially affected, or
are reasonably likely to materially affect, the Company’s internal control over financial reporting.

[0001144204-18-062244:item_9a:6]
The Company is in the process of remediating the material
weakness and has taken the following actions: enhanced our policies and procedures related to the deferred revenue
reconciliation and review and provided additional training to certain personnel in our finance department. We believe these
measures will remediate the control deficiencies and strengthen our internal control over financial reporting. We will test
the operating effectiveness of the revised and new controls subsequent to full implementation, and will consider the material
weakness remediated after the applicable controls have operated effectively for a sufficient period of time.
