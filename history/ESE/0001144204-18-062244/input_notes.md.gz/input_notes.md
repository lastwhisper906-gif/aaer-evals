# ESE notes — 0001144204-18-062244


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001144204-18-062244:notes:1]
Net Sales

[0001144204-18-062244:notes:2]
| (Dollars in millions) |  |  |  |  |  |  |  |  |  |
| Year ended September 30, |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Filtration |  | $ | 286.8 |  |  |  | 279.5 |  |  |  | 207.8 |  |
| Test |  |  | 182.9 |  |  |  | 160.9 |  |  |  | 161.5 |  |
| USG |  |  | 214.0 |  |  |  | 162.4 |  |  |  | 127.8 |  |
| Technical Packaging |  |  | 87.9 |  |  |  | 82.9 |  |  |  | 74.4 |  |
| Consolidated totals |  | $ | 771.6 |  |  |  | 685.7 |  |  |  | 571.5 |  |

[0001144204-18-062244:notes:3]
No customer exceeded 10% of sales in 2018 or 2017.

[0001144204-18-062244:notes:4]
EBIT

[0001144204-18-062244:notes:5]
| (Dollars in millions) |  |  |  |  |  |  |  |  |  |
| Year ended September 30, |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Filtration |  | $ | 58.7 |  |  |  | 52.2 |  |  |  | 45.2 |  |
| Test |  |  | 23.8 |  |  |  | 19.5 |  |  |  | 13.9 |  |
| USG |  |  | 43.2 |  |  |  | 36.6 |  |  |  | 31.1 |  |
| Technical Packaging |  |  | 8.1 |  |  |  | 8.5 |  |  |  | 9.6 |  |
| Reconciliation to consolidated totals (Corporate) |  |  | (37.0 | ) |  |  | (32.1 | ) |  |  | (30.1 | ) |
| Consolidated EBIT |  |  | 96.8 |  |  |  | 84.7 |  |  |  | 69.7 |  |
| Less: interest expense |  |  | (8.8 | ) |  |  | (4.6 | ) |  |  | (1.3 | ) |
| Earnings before income tax |  | $ | 88.0 |  |  |  | 80.1 |  |  |  | 68.4 |  |


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0001144204-18-062244:notes:6]
Identifiable Assets

[0001144204-18-062244:notes:7]
| (Dollars in millions) |  |  |  |  |  |  |
| Year ended September 30, |  | 2018 |  |  | 2017 |  |
| Filtration |  | $ | 204.7 |  |  |  | 194.2 |  |
| Test |  |  | 138.3 |  |  |  | 132.2 |  |
| USG |  |  | 176.9 |  |  |  | 175.5 |  |
| Technical Packaging |  |  | 50.9 |  |  |  | 47.1 |  |
| Corporate – Goodwill |  |  | 381.7 |  |  |  | 377.9 |  |
| Corporate – Other assets |  |  | 312.6 |  |  |  | 333.5 |  |
| Consolidated totals |  | $ | 1,265.1 |  |  |  | 1,260.4 |  |


## ese:ScheduleOfCapitalExpenditureTableTextBlock

[0001144204-18-062244:notes:8]
Capital Expenditures

[0001144204-18-062244:notes:9]
| (Dollars in millions) |  |  |  |  |  |  |  |  |  |
| Year ended September 30, |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Filtration |  | $ | 7.0 |  |  |  | 10.2 |  |  |  | 3.3 |  |
| Test |  |  | 3.0 |  |  |  | 4.5 |  |  |  | 3.3 |  |
| USG |  |  | 5.2 |  |  |  | 7.6 |  |  |  | 3.3 |  |
| Technical Packaging |  |  | 5.4 |  |  |  | 7.4 |  |  |  | 3.9 |  |
| Corporate |  |  | – |  |  |  | – |  |  |  | – |  |
| Consolidated totals |  | $ | 20.6 |  |  |  | 29.7 |  |  |  | 13.8 |  |


## ese:ScheduleOfDepreciationAndAmortizationsTableTextBlock

[0001144204-18-062244:notes:10]
Depreciation and Amortization

[0001144204-18-062244:notes:11]
| (Dollars in millions) |  |  |  |  |  |  |  |  |  |
| Year ended September 30, |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Filtration |  | $ | 7.6 |  |  |  | 6.6 |  |  |  | 4.0 |  |
| Test |  |  | 4.5 |  |  |  | 3.6 |  |  |  | 3.6 |  |
| USG |  |  | 11.0 |  |  |  | 9.8 |  |  |  | 8.1 |  |
| Technical Packaging |  |  | 4.1 |  |  |  | 3.5 |  |  |  | 2.9 |  |
| Corporate |  |  | 10.6 |  |  |  | 8.7 |  |  |  | 5.0 |  |
| Consolidated totals |  | $ | 37.8 |  |  |  | 32.2 |  |  |  | 23.6 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001144204-18-062244:notes:12]
Geographic Information

[0001144204-18-062244:notes:13]
| (Dollars in millions) |  |  |  |  |  |  |  |  |  |
| Year ended September 30, |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| United States |  | $ | 536.7 |  |  |  | 503.1 |  |  |  | 403.6 |  |
| Asia |  |  | 94.5 |  |  |  | 69.8 |  |  |  | 68.1 |  |
| Europe |  |  | 85.0 |  |  |  | 75.4 |  |  |  | 71.6 |  |
| Canada |  |  | 30.3 |  |  |  | 22.2 |  |  |  | 12.9 |  |
| India |  |  | 9.4 |  |  |  | 4.8 |  |  |  | 2.9 |  |
| Other |  |  | 15.7 |  |  |  | 10.4 |  |  |  | 12.4 |  |
| Consolidated totals |  | $ | 771.6 |  |  |  | 685.7 |  |  |  | 571.5 |  |


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001144204-18-062244:notes:14]
Long-Lived Assets

[0001144204-18-062244:notes:15]
| (Dollars in millions) |  |  |  |  |  |  |
| Year ended September 30, |  | 2018 |  |  | 2017 |  |
| United States |  | $ | 113.2 |  |  |  | 111.5 |  |
| Europe |  |  | 17.1 |  |  |  | 16.8 |  |
| Other |  |  | 4.7 |  |  |  | 4.4 |  |
| Consolidated totals |  | $ | 135.0 |  |  |  | 132.7 |  |


## us-gaap:ScheduleOfDerivativeLiabilitiesAtFairValueTableTextBlock

[0001144204-18-062244:notes:16]
The Company’s forward contracts are classified within Level 2 of the valuation hierarchy in accordance with FASB Accounting Standards Codification (ASC) 825, as presented below as of September 30, 2018:

[0001144204-18-062244:notes:17]
| (In thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Asset: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Forward contracts |  | $ | – |  |  |  | 2,137 |  |  |  | – |  |  |  | 2,137 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001144204-18-062244:notes:18]
1.       Summary of Significant Accounting Policies

[0001144204-18-062244:notes:19]
A.       Principles of Consolidation

[0001144204-18-062244:notes:20]
The Consolidated Financial Statements include the accounts of ESCO Technologies Inc. (ESCO) and its wholly owned subsidiaries (the Company). All significant intercompany transactions and accounts have been eliminated in consolidation.

[0001144204-18-062244:notes:21]
B.       Basis of Presentation

[0001144204-18-062244:notes:22]
The Company’s fiscal year ends September 30. Throughout these Consolidated Financial Statements, unless the context indicates otherwise, references to a year (for example 2018) refer to the Company’s fiscal year ending on September 30 of that year.

[0001144204-18-062244:notes:23]
The Company accounts for shipping and handling costs on a gross basis and they are included in net sales. The Company accounts for taxes collected from customers and remitted to governmental authorities on a net basis and they are excluded from net sales.

[0001144204-18-062244:notes:24]
C.       Nature of Operations

[0001144204-18-062244:notes:25]
The Company is organized based on the products and services it offers, and classifies its business operations in segments for financial reporting purposes. Under the current organization structure, the Company has four segments for financial reporting purposes: Filtration/Fluid Flow (Filtration), RF Shielding and Test (Test), Utility Solutions Group (USG) and Technical Packaging.

[0001144204-18-062244:notes:26]
Filtration:

[0001144204-18-062244:notes:27]
The companies within this segment primarily design and manufacture specialty filtration products, including hydraulic filter elements and fluid control devices used in commercial aerospace applications, unique filter mechanisms used in micro-propulsion devices for satellites, custom designed filters for manned aircraft and submarines, elastomeric-based signature reduction solutions to enhance U.S. Navy maritime survivability, precision-tolerance machined components for the aerospace and defense industry, and metal processing services.

[0001144204-18-062244:notes:28]
Test:

[0001144204-18-062244:notes:29]
ETS-Lindgren Inc. provides its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy.

[0001144204-18-062244:notes:30]
USG:

[0001144204-18-062244:notes:31]
The companies within this segment provide high-end, intelligent, diagnostic test and data management solutions for the electric power delivery industry, and decision support tools for the renewable energy industry, primarily wind.

[0001144204-18-062244:notes:32]
Technical Packaging:

[0001144204-18-062244:notes:33]
The companies within this segment provide innovative solutions to the medical and commercial markets for thermoformed and precision molded pulp fiber packages and specialty products using a wide variety of thin gauge plastics and pulp.

[0001144204-18-062244:notes:34]
D.       Use of Estimates

[0001144204-18-062244:notes:35]
The preparation of financial statements in conformity with GAAP requires Management to make estimates and assumptions that affect the reported amounts of assets and liabilities. Actual results could differ from those estimates.

[0001144204-18-062244:notes:36]
E.       Revenue Recognition

[0001144204-18-062244:notes:37]
Within the Filtration segment, approximately 85% of revenues (approximately 31% of consolidated revenues) are recognized when products are delivered (when title and risk of ownership transfers) or when services are performed for unaffiliated customers.

[0001144204-18-062244:notes:38]
Approximately 15% of the segment’s revenues (approximately 6% of consolidated revenues) are recorded under the percentage-of-completion method. The majority of these contracts are cost-reimbursable contracts which provide for the payment of allowable costs incurred during the performance of the contract plus an incentive fee. The remainder of the contracts are fixed-price contracts. Products accounted for under this guidance include the design, development and manufacture of complex fluid control products, quiet valves, manifolds and systems primarily for the aerospace and military markets. For fixed-price contracts that are accounted for under this guidance, the Company estimates profit as the difference between total estimated revenue and total estimated cost of a contract and recognizes these revenues and costs based on units delivered. The percentage-of-completion method of accounting involves the use of various techniques to estimate expected costs at completion. These estimates are based on Management’s judgment and the Company’s substantial experience in developing these types of estimates.

[0001144204-18-062244:notes:39]
Within the Test segment, approximately 25% of revenues (approximately 6% of consolidated revenues) are recognized when products are delivered (when title and risk of ownership transfers) or when services are performed for unaffiliated customers.

[0001144204-18-062244:notes:40]
Approximately 75% of the segment’s revenues (approximately 18% of consolidated revenues) are recorded under the percentage-of-completion method due to the complex nature of the enclosures that are designed and produced under these contracts. Products accounted for under this guidance include the construction and installation of complex test chambers to a buyer’s specifications that provide its customers with the ability to measure and contain magnetic, electromagnetic and acoustic energy. As discussed above, for arrangements that are accounted for under this guidance, the Company estimates profit as the difference between total revenue and total estimated cost of a contract and recognizes these revenues and costs based primarily on contract milestones. The percentage-of-completion method of accounting involves the use of various techniques to estimate expected costs at completion. These estimates are based on Management’s judgment and the Company’s substantial experience in developing these types of estimates.

[0001144204-18-062244:notes:41]
USG

[0001144204-18-062244:notes:42]
:

[0001144204-18-062244:notes:43]
Within the USG segment, approximately 75% of revenues (approximately 21% of consolidated revenues) are recognized when products are delivered (when title and risk of ownership transfers), or when services are performed for unaffiliated customers. Approximately 17% of the segment’s revenues (approximately 5% of consolidated revenues) are recognized on a straight-line basis over the term. Approximately 8% of the segment’s revenues (approximately 2% of consolidated revenues) are recognized based on the terms of the software contract.

[0001144204-18-062244:notes:44]
Within the Technical Packaging segment, 100% of revenues (approximately 11% of consolidated revenues) are recognized when products are delivered (when title and risk of ownership transfers) or when services are performed for unaffiliated customers.

[0001144204-18-062244:notes:45]
See the further discussion of the Company’s revenue recognition in Note 1.W, below.

[0001144204-18-062244:notes:46]
F.       Cash and Cash Equivalents

[0001144204-18-062244:notes:47]
Cash equivalents include temporary investments that are readily convertible into cash, such as money market funds, with original maturities of three months or less.

[0001144204-18-062244:notes:48]
G.       Accounts Receivable

[0001144204-18-062244:notes:49]
Accounts receivable have been reduced by an allowance for amounts that the Company estimates are uncollectible in the future. This estimated allowance is based on Management’s evaluation of the financial condition of the customer and historical write-off experience.

[0001144204-18-062244:notes:50]
H.       Costs and Estimated Earnings on Long-Term Contracts

[0001144204-18-062244:notes:51]
Costs and estimated earnings on long-term contracts represent unbilled revenues, including accrued profits, accounted for under the percentage-of-completion method, net of progress billings.

[0001144204-18-062244:notes:52]
I.       Inventories

[0001144204-18-062244:notes:53]
Inventories are valued at the lower of cost (first-in, first-out) or market value. Inventories are regularly reviewed for excess quantities and obsolescence based upon historical experience, specific identification of discontinued items, future demand, and market conditions. Inventories under long-term contracts reflect accumulated production costs, factory overhead, initial tooling and other related costs less the portion of such costs charged to cost of sales.

[0001144204-18-062244:notes:54]
J.       Property, Plant and Equipment

[0001144204-18-062244:notes:55]
Property, plant and equipment are recorded at cost. Depreciation and amortization are computed primarily on a straight-line basis over the estimated useful lives of the assets: buildings, 10-40 years; machinery and equipment, 3-10 years; and office furniture and equipment, 3-10 years. Leasehold improvements are amortized over the remaining term of the applicable lease or their estimated useful lives, whichever is shorter. Long-lived tangible assets are reviewed for impairment whenever events or changes in business circumstances indicate the carrying value of the assets may not be recoverable. Impairment losses are recognized based on fair value.

[0001144204-18-062244:notes:56]
K.       Leases

[0001144204-18-062244:notes:57]
Lease agreements are evaluated to determine whether they are capital or operating leases in accordance with ASC 840,

[0001144204-18-062244:notes:58]
Leases

[0001144204-18-062244:notes:59]
(ASC 840). When any one of the four test criteria in ASC 840 is met, the lease then qualifies as a capital lease. Capital leases are capitalized at the lower of the net present value of the total amount payable under the leasing agreement (excluding finance charges) or the fair market value of the leased asset. Capital lease assets are depreciated on a straight-line basis, over a period consistent with the Company’s normal depreciation policy for tangible fixed assets. The Company allocates each lease payment between a reduction of the lease obligation and interest expense using the effective interest method. Rent expense for operating leases, which may include free rent or fixed escalation amounts in addition to minimum lease payments, is recognized on a straight-line basis over the duration of the lease term. Capital lease obligations are included within other long-term liabilities (long-term portion) and accrued other expenses (current portion).

[0001144204-18-062244:notes:60]
L.       Goodwill and Other Long-Lived Assets

[0001144204-18-062244:notes:61]
Goodwill represents the excess of purchase price over the fair value of net identifiable assets acquired in business acquisitions. Management annually reviews goodwill and other long-lived assets with indefinite useful lives for impairment or whenever events or changes in circumstances indicate the carrying amount may not be recoverable. If the Company determines that the carrying value of the long-lived asset may not be recoverable, a permanent impairment charge is recorded for the amount by which the carrying value of the long-lived asset exceeds its fair value. Fair value is measured based on a discounted cash flow method using a discount rate determined by Management to be commensurate with the risk inherent in the Company’s current business model.

[0001144204-18-062244:notes:62]
Other intangible assets represent costs allocated to identifiable intangible assets, principally customer relationships, capitalized software, patents, trademarks, and technology rights. Intangible assets with estimable useful lives are amortized over their respective estimated useful lives to their estimated residual values, and are reviewed for impairment whenever events or changes in business circumstances indicate the carrying value of the assets may not be recoverable. See Note 3 regarding goodwill and other intangible assets activity.

[0001144204-18-062244:notes:63]
M.       Capitalized Software

[0001144204-18-062244:notes:64]
The costs incurred for the development of computer software that will be sold, leased, or otherwise marketed are charged to expense when incurred as research and development until technological feasibility has been established for the product. Technological feasibility is typically established upon completion of a detailed program design. Costs incurred after this point are capitalized on a project-by-project basis. Capitalized costs consist of internal and external development costs. Upon general release of the product to customers, the Company ceases capitalization and begins amortization, which is calculated on a project-by-project basis as the greater of (1) the ratio of current gross revenues for a product to the total of current and anticipated future gross revenues for the product or (2) the straight-line method over the estimated economic life of the product. The Company generally amortizes the software development costs over a three-to-seven year period based upon the estimated future economic life of the product. Factors considered in determining the estimated future economic life of the product include anticipated future revenues, and changes in software and hardware technologies. Management annually reviews the carrying values of capitalized costs for impairment or whenever events or changes in circumstances indicate the carrying amount may not be recoverable. If expected cash flows are insufficient to recover the carrying amount of the asset, then an impairment loss is recognized to state the asset at its net realizable value.

[0001144204-18-062244:notes:65]
N.       Income Taxes

[0001144204-18-062244:notes:66]
Income taxes are accounted for under the asset and liability method. Deferred tax assets and liabilities are recognized for the future tax consequences attributable to differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. Deferred tax assets may be reduced by a valuation allowance if it is more likely than not that some portion or all of the deferred tax assets will not be realized. The effect on deferred tax assets and liabilities of a change in tax rates is recognized in income in the period that includes the enactment date. The Company regularly reviews its deferred tax assets for recoverability and establishes a valuation allowance when Management believes it is more likely than not such assets will not be recovered, taking into consideration historical operating results, expectations of future earnings, tax planning strategies, and the expected timing of the reversals of existing temporary differences.

[0001144204-18-062244:notes:67]
|  | O. | Research and Development Costs |

[0001144204-18-062244:notes:68]
Company-sponsored research and development costs include research and development and bid and proposal efforts related to the Company’s products and services. Company-sponsored product development costs are charged to expense when incurred. Customer-sponsored research and development costs incurred pursuant to contracts are accounted for similarly to other program costs. Customer-sponsored research and development costs refer to certain situations whereby customers provide funding to support specific contractually defined research and development costs. Total Company and customer-sponsored research and development expenses were approximately $13.1 million, $14.0 million and $12.2 million for 2018, 2017 and 2016, respectively. These expense amounts exclude certain engineering costs primarily associated with product line extensions, modifications and maintenance, which amounted to approximately $13.1 million, $10.4 million and $8.2 million for 2018, 2017 and 2016, respectively.

[0001144204-18-062244:notes:69]
|  | P. | Foreign Currency Translation |

[0001144204-18-062244:notes:70]
The financial statements of the Company’s foreign operations are translated into U.S. dollars in accordance with FASB ASC Topic 830,

[0001144204-18-062244:notes:71]
Foreign Currency Matters

[0001144204-18-062244:notes:72]
. The resulting translation adjustments are recorded as a separate component of accumulated other comprehensive income.

[0001144204-18-062244:notes:73]
|  | Q. | Earnings Per Share |

[0001144204-18-062244:notes:74]
Basic earnings per share is calculated using the weighted average number of common shares outstanding during the period. Diluted earnings per share is calculated using the weighted average number of common shares outstanding during the period plus shares issuable upon the assumed exercise of dilutive common share options and vesting of performance-accelerated restricted shares using the treasury stock method. There are no anti-dilutive shares.

[0001144204-18-062244:notes:75]
The number of shares used in the calculation of earnings per share for each year presented is as follows:

[0001144204-18-062244:notes:76]
| (in thousands) |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Weighted Average Shares Outstanding — Basic |  |  | 25,874 |  |  |  | 25,774 |  |  |  | 25,762 |  |
| Performance- Accelerated Restricted Stock |  |  | 184 |  |  |  | 221 |  |  |  | 206 |  |
| Shares — Diluted |  |  | 26,058 |  |  |  | 25,995 |  |  |  | 25,968 |  |

[0001144204-18-062244:notes:77]
|  | R. | Share-Based Compensation |

[0001144204-18-062244:notes:78]
The Company provides compensation benefits to certain key employees under several share-based plans providing for employee stock options and/or performance-accelerated restricted shares (restricted shares), and to non-employee directors under a non-employee directors compensation plan. Share-based payment expense is measured at the grant date based on the fair value of the award and is recognized on a straight-line basis over the requisite service period (generally the vesting period of the award).

[0001144204-18-062244:notes:79]
|  | S. | Accumulated Other Comprehensive Loss |

[0001144204-18-062244:notes:80]
Accumulated other comprehensive loss of $(31.5) million at September 30, 2018 consisted of $(30.9) million related to the pension net actuarial loss; $(0.5) million related to currency translation adjustments; and $(0.1) million related to forward exchange contracts. Accumulated other comprehensive loss of $(27.3) million at September 30, 2017 consisted of $(28.9) million related to the pension net actuarial loss; $1.7 million related to currency translation adjustments; and $(0.1) million related to forward exchange contracts.

[0001144204-18-062244:notes:81]
|  | T. | Deferred Revenue and Costs |

[0001144204-18-062244:notes:82]
Deferred revenue and costs are recorded when products or services have been provided or cash has been received but the criteria for revenue recognition have not been met. If there is a customer acceptance provision or there is uncertainty about customer acceptance, revenue and costs are deferred until the customer has accepted the product or service.

[0001144204-18-062244:notes:83]
|  | U. | Derivative Financial Instruments |

[0001144204-18-062244:notes:84]
All derivative financial instruments are reported on the balance sheet at fair value. The accounting for changes in fair value of a derivative instrument depends on whether it has been designated and qualifies as a hedge and on the type of hedge. For each derivative instrument designated as a cash flow hedge, the effective portion of the gain or loss on the derivative is deferred in accumulated other comprehensive income until recognized in earnings with the underlying hedged item. For each derivative instrument designated as a fair value hedge, the gain or loss on the derivative and the offsetting gain or loss on the hedged item are recognized immediately in earnings. Regardless of type, a fully effective hedge will result in no net earnings impact while the derivative is outstanding. To the extent that any hedge is ineffective at offsetting cash flow or fair value changes in the underlying hedged item, there could be a net earnings impact.

[0001144204-18-062244:notes:85]
|  | V. | Fair Value Measurements |

[0001144204-18-062244:notes:86]
Fair value is defined as the price at which an asset could be exchanged in a current transaction between knowledgeable, willing parties or the amount that would be paid to transfer a liability to a new obligor, not the amount that would be paid to settle the liability with the creditor. Where available, fair value is based on observable market prices or parameters or derived from such prices or parameters. Where observable prices or inputs are not available, valuation models are applied. These valuation techniques involve some level of Management estimation and judgment, the degree of which is dependent on the price transparency for the instruments or market and the instruments’ complexity.

[0001144204-18-062244:notes:87]
The accounting guidance establishes a three-level hierarchy for disclosure of fair value measurements, based upon the transparency of inputs to the valuation of an asset or liability as of the measurement date, as follows:

[0001144204-18-062244:notes:88]
Level 1 – Inputs to the valuation methodology are quoted prices (unadjusted) for identical assets or liabilities in active markets.

[0001144204-18-062244:notes:89]
Level 2 –Inputs to the valuation methodology include quoted prices for similar assets and liabilities in active markets, and inputs that are observable for the asset or liability, either directly or indirectly, for substantially the full term of the financial instrument.

[0001144204-18-062244:notes:90]
Level 3 – Inputs to the valuation methodology are unobservable and significant to the fair value measurement.

[0001144204-18-062244:notes:91]
Financial Assets and Liabilities

[0001144204-18-062244:notes:92]
The Company has estimated the fair value of its financial instruments as of September 30, 2018 using available market information or other appropriate valuation methodologies. The carrying amounts of cash and cash equivalents, receivables, inventories, payables and other current assets and liabilities approximate fair value because of the short maturity of those instruments. The carrying amounts due under the revolving credit facility approximate fair value as the interest on outstanding borrowings is calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election.

[0001144204-18-062244:notes:93]
Nonfinancial Assets and Liabilities

[0001144204-18-062244:notes:94]
The Company’s nonfinancial assets such as property, plant and equipment, and other intangible assets are not measured at fair value on a recurring basis; however they are subject to fair value adjustments in certain circumstances, such as when there is evidence that an impairment may exist. No impairments were recorded during 2018.

[0001144204-18-062244:notes:95]
|  | W. | New Accounting Standards |

[0001144204-18-062244:notes:96]
Revenue Recognition

[0001144204-18-062244:notes:97]
In May 2014, the FASB issued ASU No. 2014-09,

[0001144204-18-062244:notes:98]
Revenue from Contracts with Customers

[0001144204-18-062244:notes:99]
, which requires an entity to recognize the amount of revenue to which it expects to be entitled for the transfer of promised goods or services to customers. This guidance has been further clarified and amended. This new standard became effective for the Company as of October 1, 2018, and will be adopted using the modified retrospective transition method. Under this method, the Company will record the cumulative effect of adopting the new standard in the first quarter of 2019.

[0001144204-18-062244:notes:100]
Because the new standard impacts the Company’s business processes, systems and controls, it developed a project plan to guide the implementation. This project plan included analyzing the standard’s impact on the Company’s contract portfolio, comparing the Company’s historical accounting policies and practices to the requirements of the new standard, and identifying differences from applying the requirements of the new standard to the Company’s contracts. The Company developed internal controls to ensure that it adequately evaluated its portfolio of contracts under the five-step model to ensure proper assessment of the Company’s operating results under ASU 2014-09. Management reported on the progress of the implementation to the Company’s Audit Committee and the Board of Directors on a regular basis during the project’s duration. The primary impact of the adoption of ASU 2014-09 on the Company’s portfolio of contracts and its Consolidated Financial Statements is that more of the Company’s contracts within the Filtration and Technical Packaging segments will recognize revenue and earnings over time as the work progresses versus at a single point of time.

[0001144204-18-062244:notes:101]
Based on review and analysis of the Company’s contracts, the standard primarily impacts the Filtration and Technical Packaging segments, which have long-term production contracts with the U.S. Government and other commercial customers. Revenue for certain of the contracts within the Filtration segment, and the majority of contracts within the Technical Packaging segment will be recognized over time primarily as: (i) services performed or products installed by the Company are for the enhancement of assets owned and controlled by the customer, (ii) customized products and services performed do not have an alternative use to the Company; and (iii) there is continuous transfer of control to the customer.

[0001144204-18-062244:notes:102]
Prior to adoption of the new standard, revenue was generally recognized for these contracts as units were delivered, while under the new standard, revenue will be recognized over time, principally as costs are incurred. This change will generally result in an acceleration of revenue for these contracts. The Company determined that revenues in the Test and USG segments are expected to follow a revenue recognition pattern under the new guidance consistent with the Company’s current practice. The Company identified required changes under the new guidance for the recognition of capitalization of commissions on contracts within the Company’s Test segment; however, based on the review of contracts within the Test segment, changes related to this item are expected to have an inconsequential impact on the timing or amount of liabilities accrued as compared to current business practices.

[0001144204-18-062244:notes:103]
At the adoption date, the impact of recognizing these revenues under the new standard for historical periods ending prior to September 30, 2018 is expected to result in a cumulative pretax transition adjustment to increase retained earnings by approximately $5 million, related to the Filtration and Technical Packaging segments. In addition, the transition adjustment will establish contract assets of approximately $35 million, with corresponding decreases in inventory of approximately $30 million and in contract liabilities (deferred revenue and customer deposits) and accounts receivables, primarily reflecting the conversion of contracts to the cost-to-cost method. This change is not expected to have a significant impact on the Company’s future operating results as the revenue on contracts that would have been recognized under the units-of-delivery method in future years will essentially be replaced by the acceleration of revenue on contracts into earlier periods using the cost-to-cost method. The new standard will have no impact on cash flows and does not affect the economics of the underlying customer contracts.

[0001144204-18-062244:notes:104]
The Company implemented changes to its financial reporting processes, systems and controls to comply with the disclosure requirements of the new guidance including: (i) changes to balances in contract assets and contract liabilities; and (ii) disaggregation of revenues. The Company expects to change the presentation of certain financial statement accounts to align with the new standard. The most notable change will be presenting costs and estimated earnings in excess of billings as contract assets and billings in excess of costs and estimated earnings as contract liabilities. The Company will report contract balances as a net contract asset or liability position on a contract-by-contract basis at the end of each reporting period.

[0001144204-18-062244:notes:105]
Other Standards

[0001144204-18-062244:notes:106]
In January 2018, the FASB issued ASU No. 2018-02,

[0001144204-18-062244:notes:107]
Income Statement – Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income

[0001144204-18-062244:notes:108]
, which gives entities the option to reclassify to retained earnings the tax effects resulting from the Act related to items in accumulated other comprehensive income (loss) (AOCI) that the FASB refers to as having been stranded in AOCI. This new standard is effective for annual periods beginning after December 15, 2018. The Company adopted this ASU in the fourth quarter of 2018 and, as a result of adopting this standard, the Company reclassified $6.3 million from AOCI to retained earnings.

[0001144204-18-062244:notes:109]
In March 2017, the FASB issued ASU 2017-07,

[0001144204-18-062244:notes:110]
Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost

[0001144204-18-062244:notes:111]
, which updates ASC 715,

[0001144204-18-062244:notes:112]
Compensation – Retirement Benefits

[0001144204-18-062244:notes:113]
. This update permits only the service cost component of net periodic pension and postretirement expense to be reported with other compensation costs, while all other components are required to be reported separately in other deductions, outside any subtotal of operating income. These updates are effective for fiscal years beginning after December 15, 2017, with early adoption permitted, and must be adopted on a retrospective basis. The updates change presentation only and will not impact the Company’s results of operations.

[0001144204-18-062244:notes:114]
In August 2017, the FASB issued ASU 2017-12,

[0001144204-18-062244:notes:115]
Targeted Improvements to Accounting for Hedge Activities

[0001144204-18-062244:notes:116]
, which updates ASC 815,

[0001144204-18-062244:notes:117]
Derivatives and Hedging

[0001144204-18-062244:notes:118]
. This update is intended to amend the hedge accounting model to enable entities to better align the economics of risk management activities and financial reporting. The updates eliminate the requirement to separately measure and report hedge ineffectiveness and simplify hedge documentation and effectiveness assessment requirements. These updates are effective for fiscal years beginning after December 15, 2018, with early adoption permitted, and must be adopted using a modified retrospective approach. These updates are not expected to materially impact the Company’s results of operations.

[0001144204-18-062244:notes:119]
In January 2017, the FASB issued Accounting Standards Update (ASU) No. 2017-04,

[0001144204-18-062244:notes:120]
Simplifying the Test for Goodwill Impairment

[0001144204-18-062244:notes:121]
(ASU 2017-04), which eliminates Step 2 from the goodwill impairment test. Under the amendments in this update, an entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value; however, the loss recognized should not exceed the total amount of goodwill allocated to that reporting unit. The new standard is effective for fiscal years beginning after December 15, 2019. Early adoption is permitted for interim or annual goodwill impairment test performed on testing dates after January 1, 2017. The Company adopted this standard in the fourth quarter of 2017 with its annual goodwill impairment tests. The adoption of ASU 2017-04 did not have an impact on the Company’s consolidated financial statements.

[0001144204-18-062244:notes:122]
In March 2016, the FASB issued ASU No. 2016-09,

[0001144204-18-062244:notes:123]
Improvements to Employee Share-Based Payment Accounting

[0001144204-18-062244:notes:124]
, which simplified the income tax consequences, accounting for forfeitures and classification on the Statements of Consolidated Cash Flows. The Company adopted this standard in 2017 resulting in the income tax expense in the third quarter and fiscal year 2017 being favorably impacted by additional tax benefits on share-based compensation that vested during the third quarter of 2017 decreasing the effective tax rate by 5.1% and 1.1%, respectively.

[0001144204-18-062244:notes:125]
In February 2016, the FASB issued ASU No. 2016-062,

[0001144204-18-062244:notes:126]
Leases (Topic 842)

[0001144204-18-062244:notes:127]
, which, among other things, requires an entity to recognize lease assets and lease liabilities on the balance sheet and disclose key information about leasing arrangements. This standard will increase an entity’s reported assets and liabilities. The new standard is effective for fiscal years beginning after December 15, 2018 and mandates a modified retrospective transition period for all entities. The Company is currently assessing the impact of this new standard on its consolidated financial statements and related disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001144204-18-062244:notes:128]
|  | 2. | Acquisitions |

[0001144204-18-062244:notes:129]
2018

[0001144204-18-062244:notes:130]
On March 14, 2018, the Company acquired the assets of Manta Test Systems Inc. (Manta), a North American utility solutions provider located in Mississauga, Ontario, Canada, for a purchase price of $9.5 million in cash. Manta has annualized sales of approximately $8 million. Since the date of acquisition, the operating results for Manta have been included as a product line of Doble Engineering Company within the Company’s USG segment. Based on the purchase price allocation, the Company recorded approximately $0.4 million of accounts receivable, $1.1 million of inventory, $0.2 million of property, plant and equipment, $0.4 million of accounts payable and accrued expenses, $3.5 million of goodwill, $1.2 million of tradenames and $3.5 million of amortizable intangible assets consisting of customer relationships with a weighted average life of 13 years.

[0001144204-18-062244:notes:131]
2017

[0001144204-18-062244:notes:132]
On August 30, 2017, the Company acquired the assets of Vanguard Instruments Company (Vanguard Instruments), a test equipment provider serving the global electric utility market, located in Ontario, California, for a purchase price of $36.0 million in cash. Vanguard Instruments has annualized sales of approximately $14 million. Since the date of acquisition, the operating results for Vanguard Instruments have been included as a product line of Doble within the Company’s USG segment. Based on the purchase price allocation, the Company recorded approximately $1.8 million of accounts receivable, $2.1 million of inventory, $0.3 million of property, plant and equipment, $0.2 million of accounts payable and accrued expenses, $10.7 million of goodwill, $3.2 million of tradenames and $18.0 million of amortizable intangible assets consisting of customer relationships with a weighted average life of 15 years.

[0001144204-18-062244:notes:133]
On May 25, 2017, the Company acquired the assets of Morgan Schaffer Inc. (Morgan Schaffer), a global utilities provider located in Montreal, Quebec, Canada, for a purchase price of $48.8 million in cash. Morgan Schaffer has annualized sales of approximately $25 million. It designs, develops, manufactures and markets an integrated offering of dissolved gas analysis, oil testing, and data management solutions which enhance the ability of electric utilities to accurately monitor the health of critical power transformers. Since the date of acquisition, the operating results for Morgan Schaffer have been included in the Company’s USG segment. Based on the purchase price allocation, the Company recorded approximately $2.5 million of accounts receivable, $5.2 million of inventory, $1.7 million of property, plant and equipment, $0.4 million of other assets, $4.9 million of accounts payable and accrued expenses, $4.8 million of goodwill, $35.6 million of trade names and $3.6 million of amortizable intangible assets consisting of customer relationships and developed technology with a weighted average life of approximately 10 years.

[0001144204-18-062244:notes:134]
On May 8, 2017, the Company acquired NRG Systems, Inc. (NRG), located in Hinesburg, Vermont, for a purchase price of $38.6 million in cash (net of cash acquired). NRG is a global market leader in the design and manufacture of decision support tools for the renewable energy industry, primarily wind. NRG has annualized sales of approximately $45 million. Since the date of acquisition, the operating results for NRG have been included in the Company’s USG segment. Based on the purchase price allocation, the Company recorded approximately $1.5 million of cash, $4.1 million of accounts receivable, $5.1 million of inventory, $0.4 million of other assets, $9.4 million of property, plant and equipment (including a capital lease), $4.3 million of accounts payable and accrued expenses, $8.9 million of long-term lease liability, $7.5 million of goodwill, $8.1 million of trade names and $17.2 million of amortizable intangible assets consisting of customer relationships with a weighted average life of approximately 14 years.

[0001144204-18-062244:notes:135]
On November 7, 2016, the Company acquired aerospace suppliers Mayday Manufacturing Co. (Mayday) and its affiliate, Hi-Tech Metals, Inc. (Hi-Tech), which share a state-of-the-art, expandable 130,000 square foot facility in Denton, Texas, for a purchase price of approximately $75 million in cash. Mayday is a leading manufacturer of mission-critical bushings, pins, sleeves and precision-tolerance machined components for landing gear, rotor heads, engine mounts, flight controls and actuation systems for the aerospace and defense industry. Hi-Tech is a full-service metal processor offering aerospace OEM’s and Tier 1 suppliers a large portfolio of processing services including anodizing, cadmium and zinc-nickel plating, organic coatings, non-destructive testing and heat treatment. Mayday and Hi-Tech together have annual sales of approximately $40 million. Since the date of acquisition, the consolidated operating results for Mayday and Hi-Tech have been included in the Company’s Filtration segment. Based on the purchase price allocation, the Company recorded approximately $7.4 million of accounts receivable, $11.0 million of inventory, $0.3 million of other assets, $16.6 million of property, plant and equipment (including a capital lease), $2.8 million of accounts payable and accrued expenses, $9.5 million of long-term lease liability, $15.7 million of deferred tax liabilities, $30.1 million of goodwill, $4.8 million of trade names and $32.8 million of amortizable identifiable intangible assets consisting primarily of customer relationships with a weighted-average life of approximately 20 years.

[0001144204-18-062244:notes:136]
2016

[0001144204-18-062244:notes:137]
On September 2, 2016, the Company acquired the stock of Westland Technologies, Inc. (Westland), located in Modesto, California, for a purchase price of approximately $41 million in cash (net of cash acquired). Westland is a market leader in the design, development and manufacture of elastomeric-based signature reduction solutions which enhance U.S. Naval maritime platform survivability. Westland has annual sales of approximately $25 million. Since the date of acquisition, the operating results for Westland have been included within the Company’s Filtration segment. Based on the purchase price allocation, the Company recorded tangible assets, net, of $4.6 million, deferred tax liabilities of $9.5 million, goodwill of $17.3 million, and $28.3 million of identifiable intangible assets primarily consisting of customer relationships.

[0001144204-18-062244:notes:138]
On January 29, 2016, the Company acquired Plastique Limited and Plastique Sp. z o.o. (together, Plastique), headquartered in Tunbridge Wells, England with manufacturing locations in Nottingham, England and Poznan, Poland, for a purchase price of approximately $31.6 million (of which $2.7 million is due over the next two years, one payment in January 2018 and one in January 2019). Plastique is a market leader in the development and manufacture of highly-technical thermoformed plastic and precision molded pulp fiber packaging primarily serving pharmaceutical, personal care, and various specialty end markets. Since the date of acquisition, the operating results for Plastique have been included within the Company’s Technical Packaging segment. Plastique has annual sales of approximately $35 million. Based on the purchase price allocation, the Company recorded tangible assets, net, of $9.6 million, goodwill of $10.2 million, and $11.9 million of identifiable intangible assets primarily consisting of customer relationships.

[0001144204-18-062244:notes:139]
On October 16, 2015, the Company acquired the stock of Fremont Plastics, Inc. (Fremont) for a purchase price of $10.5 million in cash. The Company also purchased for $2 million Fremont’s real property located in Fremont, Indiana. Fremont was a developer, manufacturer, promoter and seller of high quality sterile-ready and non-sterile thin gauge thermoformed medical plastic packaging products. Immediately following the closing of the transaction, Fremont was merged into TEQ, and therefore since the date of acquisition the operating results for Fremont have been included as part of TEQ.

[0001144204-18-062244:notes:140]
All of the Company’s acquisitions have been accounted for using the purchase method of accounting, and accordingly, the respective purchase prices were allocated to the assets (including intangible assets) acquired and liabilities assumed based on estimated fair values at the date of acquisition. The financial results from these acquisitions have been included in the Company’s financial statements from the date of acquisition.

[0001144204-18-062244:notes:141]
The goodwill recorded for the Mayday, Westland, Plastique and Fremont acquisitions mentioned above is not expected to be deductible for U.S. Federal or state income tax purposes. The goodwill recorded for the Vanguard Instruments and NRG acquisitions mentioned above is expected to be deductible for U.S. Federal and state income tax purposes. The goodwill recorded for the Manta and Morgan Schaffer acquisitions is expected to be deductible for Canadian income tax purposes.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001144204-18-062244:notes:142]
|  | 11. | Retirement and Other Benefit Plans |

[0001144204-18-062244:notes:143]
Formerly, substantially all domestic employees were covered by a defined contribution pension plan maintained by the Company. Effective December 31, 2003, the Company’s defined benefit plan was frozen and no additional benefits have been accrued after that date. As a result, the accumulated benefit obligation and projected benefit obligation are equal. These frozen retirement income benefits are provided to employees under defined benefit pay-related and flat-dollar plans, which are noncontributory. The annual contributions to the defined benefit retirement plan equal or exceed the minimum funding requirements of the Employee Retirement Income Security Act. In addition to providing retirement income benefits, the Company provides unfunded postretirement health and life insurance benefits to certain retirees. To qualify, an employee must retire at age 55 or later and the employee’s age plus service must equal or exceed 75. Retiree contributions are defined as a percentage of medical premiums. Consequently, retiree contributions increase with increases in the medical premiums. The life insurance plans are noncontributory and provide coverage of a flat dollar amount for qualifying retired employees. Effective December 31, 2004, no new retirees were eligible for life insurance benefits.

[0001144204-18-062244:notes:144]
The Company uses a measurement date of September 30 for its pension and other postretirement benefit plans. The Company has an accrued benefit liability of $0.5 million and $0.6 million at September 30, 2018 and 2017, respectively, related to its other postretirement benefit obligations. All other information related to its postretirement benefit plans is not considered material to the Company’s results of operations or financial condition.

[0001144204-18-062244:notes:145]
The following tables provide a reconciliation of the changes in the pension plans and fair value of assets over the two-year period ended September 30, 2018, and a statement of the funded status as of September 30, 2018 and 2017:

[0001144204-18-062244:notes:146]
| (Dollars in millions) |  |  |  |  |  |  |
| Reconciliation of benefit obligation |  | 2018 |  |  | 2017 |  |
| Net benefit obligation at beginning of year |  | $ | 95.3 |  |  |  | 100.6 |  |
| Interest cost |  |  | 3.4 |  |  |  | 3.2 |  |
| Actuarial (gain) loss |  |  | (4.3 | ) |  |  | (4.1 | ) |
| Gross benefits paid |  |  | (4.6 | ) |  |  | (4.4 | ) |
| Settlements |  |  | – |  |  |  | – |  |
| Net benefit obligation at end of year |  | $ | 89.8 |  |  |  | 95.3 |  |

[0001144204-18-062244:notes:147]
| (Dollars in millions) |  |  |  |  |  |  |
| Reconciliation of fair value of plan assets |  | 2018 |  |  | 2017 |  |
| Fair value of plan assets at beginning of year |  | $ | 65.0 |  |  |  | 60.6 |  |
| Actual return on plan assets |  |  | 2.7 |  |  |  | 5.9 |  |
| Employer contributions |  |  | 10.2 |  |  |  | 2.9 |  |
| Gross benefits paid |  |  | (4.6 | ) |  |  | (4.4 | ) |
| Settlements |  |  | – |  |  |  | – |  |
| Fair value of plan assets at end of year |  | $ | 73.3 |  |  |  | 65.0 |  |

[0001144204-18-062244:notes:148]
| (Dollars in millions) |  |  |  |  |  |  |
| Funded Status |  | 2018 |  |  | 2017 |  |
| Funded status at end of year |  | $ | (16.5 | ) |  |  | (30.3 | ) |
| Accrued benefit cost |  |  | (16.5 | ) |  |  | (30.3 | ) |
| Amounts recognized in the Balance Sheet consist of: |  |  |  |  |  |  |  |  |
| Current liability |  |  | (0.2 | ) |  |  | (0.2 | ) |
| Noncurrent liability |  |  | (16.3 | ) |  |  | (30.1 | ) |
| Accumulated other comprehensive (income)/loss (before tax effect) |  |  | 41.9 |  |  |  | 47.4 |  |
| Amounts recognized in accumulated other comprehensive (income)/loss consist of: |  |  |  |  |  |  |  |  |
| Net actuarial loss |  |  | 41.9 |  |  |  | 47.4 |  |
| Accumulated other comprehensive (income)/loss (before tax effect) |  | $ | 41.9 |  |  |  | 47.4 |  |

[0001144204-18-062244:notes:149]
The estimated amount that will be amortized from accumulated other comprehensive (income) loss into net periodic benefit cost (income) in 2019 is $2.1 million.

[0001144204-18-062244:notes:150]
The following table provides the components of net periodic benefit cost for the plans for 2018, 2017 and 2016:

[0001144204-18-062244:notes:151]
| (Dollars in millions) |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Service cost |  | $ | – |  |  |  | – |  |  |  | – |  |
| Interest cost |  |  | 3.4 |  |  |  | 3.2 |  |  |  | 3.9 |  |
| Expected return on plan assets |  |  | (3.8 | ) |  |  | (3.9 | ) |  |  | (4.4 | ) |
| Net actuarial loss |  |  | 2.3 |  |  |  | 2.6 |  |  |  | 2.0 |  |
| Net periodic benefit cost |  |  | 1.9 |  |  |  | 1.9 |  |  |  | 1.5 |  |
| Defined contribution plans |  |  | 7.1 |  |  |  | 6.3 |  |  |  | 5.2 |  |
| Total |  | $ | 9.0 |  |  |  | 8.2 |  |  |  | 6.7 |  |

[0001144204-18-062244:notes:152]
The discount rate used in measuring the Company’s pension obligations was developed by matching yields of actual high-quality corporate bonds to expected future pension plan cash flows (benefit payments). Over 400 Aa-rated, non-callable bonds with a wide range of maturities were used in the analysis. After using the bond yields to determine the present value of the plan cash flows, a single representative rate that resulted in the same present value was developed. The expected long-term rate of return on plan assets assumption was determined by reviewing the actual investment return of the plans since inception and evaluating those returns in relation to expectations of various investment organizations to determine whether long-term future returns are expected to differ significantly from the past.

[0001144204-18-062244:notes:153]
The following weighted-average assumptions were used to determine the net periodic benefit cost for the pension plans:

[0001144204-18-062244:notes:154]
|  |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Discount rate |  |  | 3.65 | % |  |  | 3.25 | % |  |  | 4.25 | % |
| Rate of increase in compensation levels |  |  | N/A |  |  |  | N/A |  |  |  | N/A |  |
| Expected long-term rate of return on assets |  |  | 6.00 | % |  |  | 6.25 | % |  |  | 6.75 | % |

[0001144204-18-062244:notes:155]
The following weighted-average assumptions were used to determine the net periodic benefit obligations for the pension plans:

[0001144204-18-062244:notes:156]
|  |  | 2018 |  |  | 2017 |  |
| Discount rate |  |  | 4.15 | % |  |  | 3.65 | % |
| Rate of increase in compensation levels |  |  | N/A |  |  |  | N/A |  |

[0001144204-18-062244:notes:157]
The assumed rate of increase in compensation levels is not applicable in 2018, 2017 and 2016 as the plan was frozen in earlier years.

[0001144204-18-062244:notes:158]
The asset allocation for the Company’s pension plans at the end of 2018 and 2017, and the Company’s acceptable range and the target allocation for 2019, by asset category, are as follows:

[0001144204-18-062244:notes:159]
|  |  | Target Allocation |  |  | Acceptable |  |  | Percentage of Plan Assets at Year-end |  |
| Asset Category |  | 2019 |  |  | Range |  |  | 2018 |  |  | 2017 |  |
| Return seeking |  |  | 37 | % |  |  | 39%-47 | % |  |  | 44 | % |  |  | 62 | % |
| Liability hedging |  |  | 63 | % |  |  | 53%-61 | % |  |  | 54 | % |  |  | 35 | % |
| Cash/cash equivalents |  |  | – |  |  |  | 0%-5 | % |  |  | 2 | % |  |  | 3 | % |

[0001144204-18-062244:notes:160]
The Company’s pension plan assets are managed by outside investment managers and assets are rebalanced when the target ranges are exceeded. Pension plan assets consist principally of funds which invest in marketable securities including common stocks, bonds, and interest-bearing deposits. The Company’s investment strategy with respect to pension assets is to achieve a total rate of return (income and capital appreciation) that is sufficient to accomplish the purpose of providing retirement benefits to all eligible and future retirees of the pension plan. The Company regularly monitors performance and compliance with investment guidelines.

[0001144204-18-062244:notes:161]
Fair Value of Financial Measurements

[0001144204-18-062244:notes:162]
The fair values of the Company’s defined benefit plan investments as of September 30, 2018 and 2017, by asset category, were as follows:

[0001144204-18-062244:notes:163]
| (Dollars in millions) |  | 2018 |  |  | 2017 |  |
| Investments at fair value: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 2.1 |  |  |  | 1.9 |  |
| Common and preferred stock funds: |  |  |  |  |  |  |  |  |
| Domestic large capitalization |  |  | 8.7 |  |  |  | 10.6 |  |
| Domestic small-/mid-capitalization |  |  | 2.7 |  |  |  | 3.3 |  |
| International funds |  |  | 10.8 |  |  |  | 14.3 |  |
| Fixed income funds |  |  | 45.6 |  |  |  | 30.7 |  |
| Real estate investment funds |  |  | 3.4 |  |  |  | 4.2 |  |
| Total investments at fair value |  | $ | 73.3 |  |  |  | 65.0 |  |

[0001144204-18-062244:notes:164]
The following methods were used to estimate the fair value of each class of financial instrument:

[0001144204-18-062244:notes:165]
Cash and cash equivalents

[0001144204-18-062244:notes:166]
:
 The carrying value of cash represents fair value as it consists of actual currency.

[0001144204-18-062244:notes:167]
Investment Funds

[0001144204-18-062244:notes:168]
:
 The fair value of the investment funds, which offer daily redemptions, is determined based on the published net asset value of the funds as a practical expedient for fair value.

[0001144204-18-062244:notes:169]
Expected Cash Flows

[0001144204-18-062244:notes:170]
Information about the expected cash flows for the pension and other postretirement benefit plans follows:

[0001144204-18-062244:notes:171]
| (Dollars in millions) |  | PensionBenefits |  |  | Other Benefits |  |
| Expected Employer Contributions — 2019 |  | $ | 1.0 |  |  |  | 0.1 |  |
| Expected Benefit Payments: |  |  |  |  |  |  |  |  |
| 2019 |  |  | 5.1 |  |  |  | 0.1 |  |
| 2020 |  |  | 5.8 |  |  |  | 0.1 |  |
| 2021 |  |  | 5.5 |  |  |  | 0.1 |  |
| 2022 |  |  | 5.7 |  |  |  | 0.1 |  |
| 2023 |  |  | 5.8 |  |  |  | 0.1 |  |
| 2024-2028 |  | $ | 30.0 |  |  |  | 0.2 |  |


## us-gaap:ScheduleOfNonvestedShareActivityTableTextBlock

[0001144204-18-062244:notes:172]
The following summary presents information regarding outstanding PARS awards as of the specified dates, and changes during the specified periods:

[0001144204-18-062244:notes:173]
|  |  |  | FY 2018 |  |  | FY 2017 |  |  | FY 2016 |  |
|  |  |  | Shares |  |  | Estimated Weighted Avg. Price |  |  | Shares |  |  | Estimated Weighted Avg. Price |  |  | Shares |  |  | Estimated Weighted Avg. Price |  |
| Nonvested at October 1, |  |  |  | 335,825 |  |  |  | 40.35 |  |  |  | 427,438 |  |  | $ | 35.40 |  |  |  | 326,536 |  |  | $ | 35.29 |  |
| Granted |  |  |  | 104,320 |  |  |  | 56.06 |  |  |  | 110,422 |  |  |  | 51.16 |  |  |  | 120,902 |  |  |  | 35.75 |  |
| Vested |  |  |  | (121,301 | ) |  |  | 35.59 |  |  |  | (202,035 | ) |  |  | 35.78 |  |  |  | (8,000 | ) |  |  | 36.06 |  |
| Cancelled |  |  |  | (3,300 | ) |  |  | 53.86 |  |  |  | – |  |  |  | – |  |  |  | (12,000 | ) |  |  | 35.47 |  |
| Nonvested at September 30, |  |  |  | 315,544 |  |  |  | 47.23 |  |  |  | 335,825 |  |  | $ | 40.35 |  |  |  | 427,438 |  |  | $ | 35.40 |  |


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001144204-18-062244:notes:174]
|  | 4. | Accounts Receivable |

[0001144204-18-062244:notes:175]
Accounts receivable, net of the allowance for doubtful accounts, consist of the following at September 30, 2018 and 2017:

[0001144204-18-062244:notes:176]
| (Dollars in thousands) |  | 2018 |  |  | 2017 |  |
| Commercial |  | $ | 146,049 |  |  |  | 152,265 |  |
| U.S. Government and prime contractors |  |  | 17,691 |  |  |  | 8,315 |  |
| Total |  | $ | 163,740 |  |  |  | 160,580 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001144204-18-062244:notes:177]
Inventories consist of the following at September 30, 2018 and 2017:

[0001144204-18-062244:notes:178]
| (Dollars in thousands) |  | 2018 |  |  | 2017 |  |
| Finished goods |  | $ | 26,678 |  |  |  | 28,127 |  |
| Work in process |  |  | 47,765 |  |  |  | 43,750 |  |
| Raw materials |  |  | 60,973 |  |  |  | 52,638 |  |
| Total |  | $ | 135,416 |  |  |  | 124,515 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001144204-18-062244:notes:179]
|  | 5. | Inventories, Net |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001144204-18-062244:notes:180]
|  | 6. | Related Parties |

[0001144204-18-062244:notes:181]
One of the Company’s directors is an officer at a customer of the Company’s subsidiary Doble. Doble sells products, rents equipment and provides testing services to the customer in the ordinary course of Doble’s business. The total amount of these sales were approximately $2.1 million, $3.6 million and $1.4 million during fiscal 2018, 2017 and 2016, respectively. All transactions between Doble and the customer are intended to be and have been consistent with Doble’s normal commercial terms offered to its customers, and the Company’s Board of Directors has determined that the relationship between the Company and the customer is not material and did not impair either the Company’s or the director’s independence.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001144204-18-062244:notes:182]
|  | 3. | Goodwill and Other Intangible Assets |

[0001144204-18-062244:notes:183]
Included on the Company’s Consolidated Balance Sheets at September 30, 2018 and 2017 are the following intangible assets gross carrying amounts and accumulated amortization:

[0001144204-18-062244:notes:184]
| (Dollars in millions) |  | 2018 |  |  | 2017 |  |
| Goodwill |  | $ | 381.7 |  |  |  | 377.9 |  |
| Intangible assets with determinable lives: |  |  |  |  |  |  |  |  |
| Patents |  |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 1.8 |  |  |  | 1.0 |  |
| Less: accumulated amortization |  |  | 0.8 |  |  |  | 0.8 |  |
| Net |  | $ | 1.0 |  |  |  | 0.2 |  |
| Capitalized software |  |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 71.3 |  |  |  | 63.0 |  |
| Less: accumulated amortization |  |  | 41.6 |  |  |  | 34.4 |  |
| Net |  | $ | 29.7 |  |  |  | 28.6 |  |
| Customer Relationships |  |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 185.3 |  |  |  | 181.9 |  |
| Less: accumulated amortization |  |  | 47.8 |  |  |  | 37.4 |  |
| Net |  | $ | 137.5 |  |  |  | 144.5 |  |
| Other |  |  |  |  |  |  |  |  |
| Gross carrying amount |  | $ | 5.5 |  |  |  | 5.4 |  |
| Less: accumulated amortization |  |  | 2.0 |  |  |  | 1.4 |  |
| Net |  | $ | 3.5 |  |  |  | 4.0 |  |
| Intangible assets with indefinite lives: |  |  |  |  |  |  |  |  |
| Trade names |  | $ | 173.7 |  |  |  | 173.8 |  |

[0001144204-18-062244:notes:185]
The Company performed its annual evaluation of goodwill and intangible assets for impairment during the fourth quarter of 2018 and concluded no impairment existed at September 30, 2018 and there are no accumulated impairment losses as of September 30, 2018.

[0001144204-18-062244:notes:186]
The changes in the carrying amount of goodwill attributable to each business segment for 2018 and 2017 are as follows:

[0001144204-18-062244:notes:187]
| (Dollars in millions) |  | Filtration |  |  | Test |  |  | USG |  |  | Technical Packaging |  |  | Total |  |
| Balance as of September 30, 2016 |  | $ | 43.9 |  |  |  | 34.1 |  |  |  | 226.2 |  |  |  | 19.4 |  |  |  | 323.6 |  |
| Acquisition activity |  |  | 29.8 |  |  |  | – |  |  |  | 23.6 |  |  |  | – |  |  |  | 53.4 |  |
| Foreign currency translation and other |  |  | – |  |  |  | – |  |  |  | 0.4 |  |  |  | 0.5 |  |  |  | 0.9 |  |
| Balance as of September 30, 2017 |  |  | 73.7 |  |  |  | 34.1 |  |  |  | 250.2 |  |  |  | 19.9 |  |  |  | 377.9 |  |
| Acquisition activity |  |  | – |  |  |  | – |  |  |  | 3.9 |  |  |  | – |  |  |  | 3.9 |  |
| Foreign currency translation and other |  |  | – |  |  |  | – |  |  |  | – |  |  |  | (0.1 | ) |  |  | (0.1 | ) |
| Balance as of September 30, 2018 |  | $ | 73.7 |  |  |  | 34.1 |  |  |  | 254.1 |  |  |  | 19.8 |  |  |  | 381.7 |  |

[0001144204-18-062244:notes:188]
Amortization expense related to intangible assets with determinable lives was $18.3 million, $16.3 million and $11.6 million in 2018, 2017 and 2016, respectively. Patents are amortized over the life of the patents, generally 17 years. Capitalized software is amortized over the estimated useful life of the software, generally three to seven years. Customer relationships are generally amortized over fifteen to twenty years. Intangible asset amortization for fiscal years 2019 through 2023 is estimated at approximately $19 million per year.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001144204-18-062244:notes:189]
Debt consists of the following at September 30, 2018 and 2017:

[0001144204-18-062244:notes:190]
| (Dollars in thousands) |  | 2018 |  |  | 2017 |  |
| Revolving credit facility, including current portion |  | $ | 220,000 |  |  |  | 275,000 |  |
| Current portion of long-term debt |  |  | (20,000 | ) |  |  | (20,000 | ) |
| Total long-term debt, less current portion |  | $ | 200,000 |  |  |  | 255,000 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001144204-18-062244:notes:191]
|  | 7. | Income Tax Expense |

[0001144204-18-062244:notes:192]
The components of income before income taxes for 2018, 2017 and 2016 consisted of the following:

[0001144204-18-062244:notes:193]
| (Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| United States |  | $ | 80,994 |  |  |  | 72,353 |  |  |  | 62,353 |  |
| Foreign |  |  | 7,029 |  |  |  | 7,800 |  |  |  | 6,067 |  |
| Total income before income taxes |  | $ | 88,023 |  |  |  | 80,153 |  |  |  | 68,420 |  |

[0001144204-18-062244:notes:194]
The principal components of income tax expense (benefit) for 2018, 2017 and 2016 consist of:

[0001144204-18-062244:notes:195]
| (Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Federal: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 9,174 |  |  |  | 21,448 |  |  |  | 19,236 |  |
| Deferred |  |  | (22,943 | ) |  |  | 628 |  |  |  | (909 | ) |
| State and local: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  |  | 2,121 |  |  |  | 1,795 |  |  |  | 1,674 |  |
| Deferred |  |  | 2,972 |  |  |  | (49 | ) |  |  | (222 | ) |
| Foreign: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  |  | 2,233 |  |  |  | 4,450 |  |  |  | 1,899 |  |
| Deferred |  |  | 2,330 |  |  |  | (1,822 | ) |  |  | 860 |  |
| Total |  | $ | (4,113 | ) |  |  | 26,450 |  |  |  | 22,538 |  |

[0001144204-18-062244:notes:196]
The actual income tax expense (benefit) for 2018, 2017 and 2016 differs from the expected tax expense for those years (computed by applying the U.S. Federal corporate statutory rate) as follows:

[0001144204-18-062244:notes:197]
|  |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Federal corporate statutory rate |  |  | 24.5 | % |  |  | 35.0 | % |  |  | 35.0 | % |
| State and local, net of Federal benefits |  |  | 3.0 |  |  |  | 2.4 |  |  |  | 2.0 |  |
| Foreign |  |  | 0.6 |  |  |  | (0.1 | ) |  |  | (1.0 | ) |
| Research credit |  |  | (1.6 | ) |  |  | (1.1 | ) |  |  | (2.5 | ) |
| Domestic production deduction |  |  | (1.1 | ) |  |  | (2.7 | ) |  |  | (2.8 | ) |
| Change in uncertain tax positions |  |  | (0.1 | ) |  |  | – |  |  |  | – |  |
| Executive compensation |  |  | (0.1 | ) |  |  | (0.1 | ) |  |  | 0.9 |  |
| Valuation allowance |  |  | 3.0 |  |  |  | (0.3 | ) |  |  | 1.8 |  |
| Tax reform – impact on U.S. deferred tax assets and liabilities |  |  | (37.2 | ) |  |  | – |  |  |  | – |  |
| Tax reform – transition tax |  |  | 1.5 |  |  |  | – |  |  |  | – |  |
| Tax reform – taxes related to foreign unremitted earnings |  |  | 2.8 |  |  |  | – |  |  |  | – |  |
| Other, net |  |  | – |  |  |  | (0.1 | ) |  |  | (0.5 | ) |
| Effective income tax rate |  |  | (4.7 | )% |  |  | 33.0 | % |  |  | 32.9 | % |

[0001144204-18-062244:notes:198]
On December 22, 2017, President Trump signed into law new tax legislation commonly referred to as the Tax Cut and Jobs Act (the “TCJA”). The TCJA includes broad and complex changes to the U.S. tax code that impacted the Company’s accounting and reporting for income taxes in the current year. These impacts primarily consist of the following:

[0001144204-18-062244:notes:199]
|  |  | A reduction in the U.S. federal corporate income tax rate from 35% to 21%, effective January 1, 2018, which resulted in a fiscal 2018 U.S. blended statutory income tax rate for the Company of 24.5%. |

[0001144204-18-062244:notes:200]
|  |  | A remeasurement of U.S. deferred tax assets and liabilities. |

[0001144204-18-062244:notes:201]
|  |  | A one-time mandatory deemed repatriation tax on unremitted foreign earnings (the “Transition Tax”), which may be paid over an eight-year period. |

[0001144204-18-062244:notes:202]
Staff Accounting Bulletin No. 118 (SAB 118) was issued by the SEC effective December 22, 2017. SAB 118 allows registrants to record provisional amounts of the income tax effects of the TCJA where the information necessary to complete the accounting under ASC Topic 740 is not available but the amounts are based on reasonable estimates. SAB 118 permits registrants to record adjustments to its provisional amounts during the measurement period (which cannot exceed one year).

[0001144204-18-062244:notes:203]
The statutory tax rate reduction of the TCJA reduced U.S. net deferred tax liabilities by $30.7 million. An additional $1.0 million benefit was recorded as a result of a $7.5 million pension contribution approved during the second quarter of 2018. In addition, a tax accounting method change was filed in the third quarter of 2018 which resulted in an additional favorable deferred tax liability adjustment of $1.0 million. The remeasurement of U.S. net deferred tax liabilities is complete as of September 30, 2018.

[0001144204-18-062244:notes:204]
The Company recorded a provisional charge for the Transition Tax of $3.7 million for the year ended September 30, 2018. Certain technical aspects of the TCJA remain subject to varying degrees of uncertainty and the Company has therefore made interpretations of the enacted legislation in its provisional income tax computations based upon the best available guidance while it awaits expected technical guidance and clarification from the U.S. government. One such calculation requiring further guidance is the possible unintended benefit of the application of new Section 245A (dividend received deduction) as it relates to the Transition Tax for fiscal year companies. The Company believes there is insufficient clarity and significant uncertainty with respect to this issue as of September 30, 2018 and, therefore, has decided not to reduce its Transitional Tax provisional charge for the possible benefit at this time.

[0001144204-18-062244:notes:205]
In addition, as a result of the Transition Tax, the Company recorded a charge of $2.4 million related to foreign withholding taxes in connection with the reversal of its indefinite reinvestment assertion related to cumulative undistributed foreign earnings as of December 31, 2017. This charge is complete as of September 30, 2018.

[0001144204-18-062244:notes:206]
There are other impacts under the TCJA that are not effective for the Company until fiscal 2019. These primarily include a further reduction in the U.S. statutory rate to 21%, a new minimum tax on global intangible low-taxed income (“GILTI”) and the benefit of the deduction for Foreign-Derived Intangible Income (“FDII”). With respect to the new GILTI provision, U.S. GAAP allows companies to make an accounting policy election and record taxes as a period cost as incurred or factor such amounts in the measurement of deferred taxes. The Company has made an accounting policy election to record these taxes as a period cost.

[0001144204-18-062244:notes:207]
The tax effects of temporary differences that give rise to significant portions of the deferred tax assets and liabilities at September 30, 2018 and 2017 are presented below:

[0001144204-18-062244:notes:208]
| (Dollars in thousands) |  | 2018 |  |  | 2017 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Inventories |  | $ | 5,834 |  |  |  | 9,639 |  |
| Pension and other postretirement benefits |  |  | 3,969 |  |  |  | 11,345 |  |
| Net operating and capital loss carryforwards — domestic |  |  | 639 |  |  |  | 501 |  |
| Net operating loss carryforward — foreign |  |  | 4,603 |  |  |  | 4,486 |  |
| Foreign tax credit carryforward |  |  | 2,377 |  |  |  | – |  |
| Other compensation-related costs and other cost accruals |  |  | 7,048 |  |  |  | 12,104 |  |
| State credit carryforward |  |  | 2,103 |  |  |  | 2,098 |  |
| Total deferred tax assets |  |  | 26,573 |  |  |  | 40,173 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Goodwill |  |  | (969 | ) |  |  | (4,874 | ) |
| Acquisition assets |  |  | (62,841 | ) |  |  | (91,752 | ) |
| Depreciation, software amortization |  |  | (19,584 | ) |  |  | (24,092 | ) |
| Net deferred tax liabilities before valuation allowance |  |  | (56,821 | ) |  |  | (80,545 | ) |
| Less valuation allowance |  |  | (7,144 | ) |  |  | (4,440 | ) |
| Net deferred tax liabilities |  | $ | (63,965 | ) |  |  | (84,985 | ) |

[0001144204-18-062244:notes:209]
The Company has a foreign net operating loss (NOL) carryforward of $19.0 million at September 30, 2018, which reflects tax loss carryforwards in Germany, India, Finland, China, South Africa, Japan, Canada and the United Kingdom. $16.7 million of the tax loss carryforwards have no expiration date while the remaining $2.3 million will expire between 2019 and 2027. The Company has deferred tax assets related to state NOL carryforwards of $0.6 million at September 30, 2018 which expire between 2025 and 2038. The Company also has net state research and other credit carryforwards of $2.1 million of which $1.7 million expires between 2025 and 2037. The remaining $0.4 million does not have an expiration date.

[0001144204-18-062244:notes:210]
The valuation allowance for deferred tax assets as of September 30, 2018 and 2017 was $7.1 million and $4.4 million, respectively. The net change in the total valuation allowance for each of the years ended September 30, 2018 and 2017 was an increase of $2.7 million and a decrease of $1.3 million, respectively. In 2018 the Company established a valuation allowance for excess foreign tax credits that are not expected to be utilized in future periods of $2.4 million at September 30, 2018. The Company has established a valuation allowance against state credit carryforwards of $0.4 million at both September 30, 2018 and 2017. In addition, the Company has established a valuation allowance against state NOL carryforwards that are not expected to be realized in future periods of $0.6 million and $0.4 million at September 30, 2018 and 2017, respectively. Lastly, the Company has established a valuation allowance against certain NOL carryforwards in foreign jurisdictions which may not be realized in future periods of $3.8 million and $3.7 million at September 30, 2018 and 2017, respectively.

[0001144204-18-062244:notes:211]
The Company’s subsidiary ETS-Lindgren Oy, Finland, has recorded a deferred tax asset of $0.2 million reflecting the benefit of $2.2 million in loss carryforwards, which expires in 2027. Realization is dependent on generating sufficient taxable income prior to expiration of the loss carryforwards. Although realization is not assured, Management believes it is more likely than not that all of the deferred tax asset will be realized. The amount of the deferred tax asset considered realizable, however, could be reduced in the near term if estimates of future taxable income during the carryforward period are reduced.

[0001144204-18-062244:notes:212]
The Company’s foreign subsidiaries have accumulated unremitted earnings of $3.5 million at September 30, 2018. No deferred taxes have been provided on these accumulated unremitted earnings because these funds are not needed to meet the liquidity requirements of the Company’s U.S. operations and it is the Company’s intention to indefinitely reinvest these earnings in continuing international operations. In the event these foreign entities’ earnings were distributed, it is estimated that approximately $0.3 million of foreign tax withholding would be paid. The Company does not expect that these taxes would be creditable against U.S. income tax, so they would correspondingly reduce the Company’s net earnings. No significant portion of the Company’s foreign subsidiaries’ earnings was taxed at a very low tax rate.

[0001144204-18-062244:notes:213]
The Company had $0.1 million of unrecognized tax benefits as of both September 30, 2018 and 2017, which, if recognized, would affect the Company’s effective tax rate. The Company expects $0.1 million of unrecognized tax benefits to reverse in the next twelve months. The Company’s policy is to include interest related to unrecognized tax benefits in income tax expense and penalties in operating expense. As of September 30, 2018, 2017 and 2016, the Company had zero accrued interest related to uncertain tax positions on its Consolidated Balance Sheets. No significant penalties have been accrued.

[0001144204-18-062244:notes:214]
The principal jurisdictions for which the Company files income tax returns are U.S. Federal and the various city, state, and international locations where the Company has operations. The U.S. Federal tax years for the periods ended September 30, 2015 and forward remain subject to income tax examination. Various state tax years for the periods ended September 30, 2014 and forward remain subject to income tax examinations. The Company is subject to income tax in many jurisdictions outside the United States, none of which is individually significant.


## us-gaap:DebtDisclosureTextBlock

[0001144204-18-062244:notes:215]
|  | 8. | Debt |

[0001144204-18-062244:notes:216]
The Company’s existing credit facility (“the Credit Facility”) matures December 21, 2020. The Credit Facility includes a $450 million revolving line of credit as well as provisions allowing for the increase of the credit facility commitment amount by an additional $250 million, if necessary, with the consent of the lenders. The bank syndication supporting the facility is comprised of a diverse group of nine banks led by JP Morgan Chase Bank, N.A., as Administrative Agent.

[0001144204-18-062244:notes:217]
At September 30, 2018, the Company had approximately $204 million available to borrow under the Credit Facility, plus the $250 million increase option, in addition to $30.5 million cash on hand. The Company classified $20 million as the current portion of long-term debt as of September 30, 2018, as the Company intends to repay this amount within the next twelve months; however, the Company has no contractual obligation to repay such amount during the next twelve months.

[0001144204-18-062244:notes:218]
The Credit Facility requires, as determined by certain financial ratios, a facility fee ranging from 12.5 to 27.5 basis points per annum on the unused portion. The terms of the facility provide that interest on borrowings may be calculated at a spread over the London Interbank Offered Rate (LIBOR) or based on the prime rate, at the Company’s election. The facility is secured by the unlimited guaranty of the Company’s material domestic subsidiaries and a 65% pledge of its material foreign subsidiaries’ share equity. The financial covenants of the Credit Facility include a leverage ratio and an interest coverage ratio. As of September 30, 2018, the Company was in compliance with all bank covenants.

[0001144204-18-062244:notes:219]
During 2018 and 2017, the maximum aggregate short-term borrowings at any month-end were $271 million and $298 million, respectively, and the average aggregate short-term borrowings outstanding based on month-end balances were $258.8 million and $211.3 million, respectively. The weighted average interest rates were 3.03%, 2.09% and 1.58% for 2018, 2017 and 2016, respectively. The letters of credit issued and outstanding under the Credit Facility totaled $7.8 million and $9.7 million at September 30, 2018 and 2017, respectively.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001144204-18-062244:notes:220]
|  | 10. | Share-Based Compensation |

[0001144204-18-062244:notes:221]
The Company provides compensation benefits to certain key employees under several share-based plans providing for performance-accelerated restricted share unit (PARS) awards, and to non-employee directors under a non-employee directors compensation plan. The Company has no stock options currently outstanding. As of September 30, 2018, the Company had 947,377 shares available for future issuance under equity compensation plans.

[0001144204-18-062244:notes:222]
Performance-Accelerated Restricted Share Unit (PARS) Awards

[0001144204-18-062244:notes:223]
A PARS award represents the right to receive a specified number of shares of Company common stock if and when the award vests. A PARS award is not stock and does not give the recipient any rights as a shareholder until it vests and is paid out in shares of stock. PARS awards currently outstanding have a five-year vesting period, with accelerated vesting if certain targets based on market conditions are achieved. In these cases, if it is probable that the performance condition will be met, the Company recognizes compensation cost on a straight-line basis over the shorter performance period; otherwise, it will recognize compensation cost over the longer service period. Compensation cost for the outstanding PARS awards is being recognized over the shorter performance period, as it is probable the performance condition will be met. The PARS award grants were valued at the stock price on the date of grant. Pretax compensation expense related to the PARS awards for continuing operations was $4.1 million, $4.4 million and $3.9 million for 2018, 2017 and 2016, respectively.

[0001144204-18-062244:notes:224]
Non-Employee Directors Plan

[0001144204-18-062244:notes:225]
Through the first quarter of 2018 the non-employee directors compensation plan provided to each non-employee director a retainer of 900 common shares per quarter. Beginning in the second quarter of 2018, the quarterly retainer was replaced by an annual retainer of Company stock having a grant date market value of $180,000. Non-employee director grants were valued at the NYSE closing price of the Company’s stock on the date of grant and were issued from the Company’s treasury stock. Compensation expense related to the non-employee director grants was $1.1 million, $1.0 million and $0.8 million for 2018, 2017 and 2016, respectively.

[0001144204-18-062244:notes:226]
Total Share-Based Compensation

[0001144204-18-062244:notes:227]
The total share-based compensation cost that has been recognized in results of operations and included within SG&A from continuing operations was $5.2 million, $5.4 million and $4.7 million for 2018, 2017 and 2016, respectively. The total income tax benefit recognized in results of operations for share-based compensation arrangements was $1.3 million, $1.8 million and $1.3 million for 2018, 2017 and 2016, respectively. As of September 30, 2018, there was $7.8 million of total unrecognized compensation cost related to share-based compensation arrangements. That cost is expected to be recognized over a weighted-average period of 1.7 years.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001144204-18-062244:notes:228]
|  | 12. | Derivative Financial Instruments |

[0001144204-18-062244:notes:229]
Market risks relating to the Company’s operations result primarily from changes in interest rates and changes in foreign currency exchange rates. The Company is exposed to market risk related to changes in interest rates and selectively uses derivative financial instruments, including forward contracts and swaps, to manage these risks. During 2016, the Company entered into forward contracts to purchase pounds sterling (GBP) to hedge two deferred payments due in connection with the acquisition of Plastique. During 2018, the Company entered into three interest rate swaps with a notional amount of $150 million to hedge its exposure to variability in future LIBOR-based interest payments on variable rate debt. In addition, the Company’s Canadian subsidiary Morgan Schaffer enters into foreign exchange contracts to manage foreign currency risk as a portion of their revenue is denominated in U.S. dollars. The Company expects hedging gains or losses to be essentially offset by losses or gains on the related underlying exposures. The amounts ultimately recognized may differ for open positions, which remain subject to ongoing market price fluctuations until settlement. All derivative instruments are reported in either accrued expenses or other assets on the balance sheet at fair value. For derivative instruments designated as cash flow hedges, the gain or loss on the derivative is deferred in accumulated other comprehensive income until recognized in earnings with the underlying hedged item. The interest rate swaps entered into during 2018 were not designated as cash flow hedges and, therefore, the gain or loss on the derivative is reflected in earnings each period. The following is a summary of the notional transaction amounts and fair values for the Company’s outstanding derivative financial instruments as of September 30, 2018.

[0001144204-18-062244:notes:230]
| (In thousands) |  | Notional Amount (Currency) |  | Fair Value (US$) |  |  | Float Rate |  |  | Fix Rate |  |
| Forward contracts |  | 700 GBP |  |  | (94 | ) |  |  |  |  |  |  |  |  |
| Forward contracts |  | 9,500 USD |  |  | (17 | ) |  |  |  |  |  |  |  |  |
| Forward contracts |  | 200 EUR |  |  | 6 |  |  |  |  |  |  |  |  |  |
| Interest rate swap |  | 150,000 USD |  |  | 94 |  |  |  | 2.18 | % |  |  | 1.80 | % |
| Interest rate swap * |  | 150,000 USD |  |  | 913 |  |  |  | N/A |  |  |  | 2.09 | % |
| Interest rate swap ** |  | 150,000 USD |  |  | 1,235 |  |  |  | N/A |  |  |  | 2.24 | % |

[0001144204-18-062244:notes:231]
* This swap represents a forward contract and will be effective in November 2018.

[0001144204-18-062244:notes:232]
** This swap represents a forward contract and will be effective in November 2019.

[0001144204-18-062244:notes:233]
Fair Value of Financial Instruments

[0001144204-18-062244:notes:234]
Valuation was based on third party evidence of similarly priced derivative instruments. There are no master netting arrangements with financial parties.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001144204-18-062244:notes:235]
|  | 13. | Business Segment Information |

[0001144204-18-062244:notes:236]
The Company is organized based on the products and services it offers, and classifies its business operations in segments for financial reporting purposes. Currently, the Company has four reporting segments: Filtration/Fluid Flow (Filtration), RF Shielding and Test (Test), Utility Solutions Group (USG) and Technical Packaging.

[0001144204-18-062244:notes:237]
The Filtration segment’s operations consist of PTI Technologies Inc. (PTI), VACCO Industries (VACCO), Crissair, Inc. (Crissair), Mayday Manufacturing Co. (Mayday), Hi-Tech Metals, Inc. (Hi-Tech) and Westland Technologies, Inc. (Westland). PTI, VACCO and Crissair design and manufacture specialty filtration products, including hydraulic filter elements and fluid control devices used in commercial aerospace applications, unique filter mechanisms used in micro-propulsion devices for satellites and custom designed filters for manned aircraft and submarines. Mayday designs and manufactures mission-critical bushings, pins, sleeves and precision-tolerance machined components for landing gear, rotor heads, engine mounts, flight controls, and actuation systems for the aerospace and defense industries. Hi-Tech is a full-service metal processor offering aerospace OEM’s and Tier 1 suppliers, a large portfolio of processing services including anodizing, cadmium and zinc-nickel plating, organic coatings, non-destructive testing, and heat treatment. Westland designs, develops and manufactures elastomeric-based signature reduction solutions for U.S. naval vessels.

[0001144204-18-062244:notes:238]
The Test segment’s operations consist of ETS-Lindgren Inc. and related subsidiaries (ETS-Lindgren). ETS-Lindgren is an industry leader in providing its customers with the ability to identify, measure and contain magnetic, electromagnetic and acoustic energy. ETS-Lindgren also manufactures radio frequency shielding products and components used by manufacturers of medical equipment, communications systems, electronic products, and shielded rooms for high-security data processing and secure communication.

[0001144204-18-062244:notes:239]
The USG segment’s operations consist of Doble Engineering Company and related subsidiaries (Doble), Morgan Schaffer Ltd. (Morgan Schaffer), and NRG Systems, Inc. (NRG). Doble provides high-end, intelligent diagnostic test solutions for the electric power delivery industry and is a leading supplier of power factor and partial discharge testing instruments used to assess the integrity of high-voltage power delivery equipment. Morgan Schaffer provides an integrated offering of dissolved gas analysis, oil testing, and data management solutions which enhance the ability of electric utilities to accurately monitor the health of critical power transformers. NRG designs and manufactures decision support tools for the renewable energy industry, primarily wind.

[0001144204-18-062244:notes:240]
The Technical Packaging segment’s operations consist of Thermoform Engineered Quality LLC (TEQ) and Plastique. The companies within this segment provide innovative solutions to the medical and commercial markets for thermoformed and precision molded pulp fiber packages and specialty products using a wide variety of thin gauge plastics and pulp.

[0001144204-18-062244:notes:241]
Accounting policies of the segments are the same as those described in the summary of significant accounting policies in Note 1 to the Consolidated Financial Statements. The operating units within each reporting segment have been aggregated because of similar economic characteristics and meet the other aggregation criteria of FASB ASC 280.

[0001144204-18-062244:notes:242]
The Company evaluates the performance of its operating units based on EBIT, which is defined as earnings before interest and taxes. EBIT on a consolidated basis is a non-GAAP financial measure; see “Non-GAAP Financial Measures” in Item 7, “Management’s Discussion and Analysis of Financial Condition and Results of Operations.” Intersegment sales and transfers are not significant. Segment assets consist primarily of customer receivables, inventories, capitalized software and fixed assets directly associated with the production processes of the segment. Segment depreciation and amortization is based upon the direct assets listed above.

[0001144204-18-062244:notes:243]
Corporate assets consist primarily of goodwill, deferred taxes, acquired intangible assets and cash balances.

[0001144204-18-062244:notes:244]
In addition to the above amounts, the Company incurred expenditures for capitalized software of $9.5 million, $9.0 million and $8.7 million in 2018, 2017 and 2016, respectively.

[0001144204-18-062244:notes:245]
Depreciation expense of property, plant and equipment was $19.4 million, $15.9 million and $11.9 million for 2018, 2017 and 2016, respectively.

[0001144204-18-062244:notes:246]
Net sales are attributed to countries based on location of customer. Long-lived assets are attributed to countries based on location of the asset.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001144204-18-062244:notes:247]
|  | 14. | Commitments and Contingencies |

[0001144204-18-062244:notes:248]
The Company leases certain real property, equipment and machinery under non-cancelable operating leases. Rental expense under these operating leases was $6.9 million, $6.8 million and $6.0 million for 2018, 2017 and 2016, respectively. Future aggregate minimum lease payments under operating leases that have initial or remaining non-cancelable lease terms in excess of one year as of September 30, 2018, are:

[0001144204-18-062244:notes:249]
| (Dollars in thousands) |  |  |  |
| Years ending September 30: |  |  |  |
| 2019 |  | $ | 6,702 |  |
| 2020 |  |  | 5,428 |  |
| 2021 |  |  | 3,540 |  |
| 2022 |  |  | 2,822 |  |
| 2023 and thereafter |  |  | 3,467 |  |
| Total |  | $ | 21,959 |  |

[0001144204-18-062244:notes:250]
At September 30, 2018, the Company had $7.8 million in letters of credit outstanding as guarantees of contract performance. As a normal incident of the businesses in which the Company is engaged, various claims, charges and litigation are asserted or commenced from time to time against the Company. Additionally, the Company is currently involved in various stages of investigation and remediation relating to environmental matters. It is the opinion of Management that the aggregate costs involved in the resolution of these matters, and final judgments, if any, which might be rendered against the Company are adequately accrued, are covered by insurance or are not likely to have a material adverse effect on the Company’s results from continuing operations, capital expenditures or competitive position.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001144204-18-062244:notes:251]
|  | 9. | Capital Stock |

[0001144204-18-062244:notes:252]
The 30,534,786 and 30,468,824 common shares as presented in the accompanying Consolidated Balance Sheets at September 30, 2018 and 2017 represent the actual number of shares issued at the respective dates. The Company held 4,623,958 and 4,635,622 common shares in treasury at September 30, 2018 and 2017, respectively.

[0001144204-18-062244:notes:253]
In August 2012, the Company’s Board of Directors authorized a common stock repurchase program under which the Company may repurchase shares of its stock from time to time in its discretion, in the open market or otherwise, up to a maximum total repurchase amount of $100 million (or such lesser amount as may be permitted under the Company’s bank credit agreements). This program has been repeatedly extended by the Company’s Board of Directors and is currently scheduled to expire September 30, 2019. There were no share repurchases in 2018 or 2017. The Company repurchased approximately 120,000 shares for $4.3 million in 2016.


## us-gaap:CapitalLeasesInFinancialStatementsOfLesseeDisclosureTextBlock

[0001144204-18-062244:notes:254]
|  | 15. | Capital Leases |

[0001144204-18-062244:notes:255]
The Company leases certain real property, equipment and machinery under capital leases, primarily associated with the 2017 acquisitions of NRG and Mayday. The facility leases expire in 2029 and the machinery leases expire in 2020. As of September 30, 2018, the net carrying value and accumulated depreciation of the assets under capital leases recorded by the Company were $14.9 million and $2.0 million, respectively. Capital lease obligations are included within other long-term liabilities (long-term portion) and accrued other expenses (current portion). Remaining payments due on the Company’s capital lease obligations as of September 30, 2018, are:

[0001144204-18-062244:notes:256]
| (Dollars in thousands) |  |  |  |
| Years ending September 30: |  |  |  |
| 2019 |  | $ | 1,922 |  |
| 2020 |  |  | 1,917 |  |
| 2021 |  |  | 1,859 |  |
| 2022 |  |  | 1,900 |  |
| 2023 and thereafter |  |  | 14,077 |  |
| Total minimum lease payments |  |  | 21,675 |  |
| Less: amounts representing interest |  |  | 3,514 |  |
| Present value of net minimum lease payments |  |  | 18,161 |  |
| Current portion of capital lease obligations |  |  | 1,346 |  |
| Non-current portion of capital lease obligations |  | $ | 16,815 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001144204-18-062244:notes:257]
|  | 16. | Quarterly Financial Information (Unaudited) |

[0001144204-18-062244:notes:258]
|  |  | First |  |  | Second |  |  | Third |  |  | Fourth |  |
| (Dollars in thousands, except per share amounts) |  | Quarter |  |  | Quarter |  |  | Quarter |  |  | Quarter |  |
| 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 173,495 |  |  |  | 174,778 |  |  |  | 192,223 |  |  |  | 231,086 |  |
| Net earnings |  |  | 34,671 |  |  |  | 9,994 |  |  |  | 19,019 |  |  |  | 28,452 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.34 |  |  |  | 0.39 |  |  |  | 0.73 |  |  |  | 1.10 |  |
| Diluted |  |  | 1.33 |  |  |  | 0.38 |  |  |  | 0.73 |  |  |  | 1.09 |  |
| Dividends declared per common share |  | $ | 0.08 |  |  |  | 0.08 |  |  |  | 0.08 |  |  |  | 0.08 |  |
| Common Stock per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| High |  | $ | 65.95 |  |  |  | 66.80 |  |  |  | 60.25 |  |  |  | 70.20 |  |
| Low |  |  | 51.55 |  |  |  | 57.15 |  |  |  | 54.35 |  |  |  | 57.00 |  |
| 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 146,368 |  |  |  | 161,178 |  |  |  | 171,189 |  |  |  | 207,005 |  |
| Net earnings |  |  | 10,727 |  |  |  | 11,157 |  |  |  | 12,645 |  |  |  | 19,174 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.42 |  |  |  | 0.43 |  |  |  | 0.49 |  |  |  | 0.74 |  |
| Diluted |  |  | 0.41 |  |  |  | 0.43 |  |  |  | 0.49 |  |  |  | 0.74 |  |
| Dividends declared per common share |  | $ | 0.08 |  |  |  | 0.08 |  |  |  | 0.08 |  |  |  | 0.08 |  |
| Common Stock per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| High |  | $ | 58.75 |  |  |  | 58.95 |  |  |  | 61.40 |  |  |  | 63.80 |  |
| Low |  |  | 42.95 |  |  |  | 51.80 |  |  |  | 55.15 |  |  |  | 50.30 |  |
