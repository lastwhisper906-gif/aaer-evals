# LOGI MD&A — 0001032975-20-000005


## mdna

[0001032975-20-000005:mdna:1]
[same as prior period, unchanged from 0001032975-19-000075:mdna:1]

[0001032975-20-000005:mdna:2]
[same as prior period, unchanged from 0001032975-19-000075:mdna:2]

[0001032975-20-000005:mdna:3]
[same as prior period, unchanged from 0001032975-19-000075:mdna:3]

[0001032975-20-000005:mdna:4]
Logitech is a world leader in designing, manufacturing and marketing products that help connect people to digital and cloud experiences. More than 35 years ago, Logitech created products to improve experiences around the personal PC platform, and today it is a multi-brand, multi-category company designing products that enable better experiences consuming, sharing and creating any digital content such as music, gaming, video and computing, whether it is on a computer, mobile device or in the cloud. Logitech's brands include Logitech, Logitech G, ASTRO Gaming, Streamlabs, Ultimate Ears, Jaybird, and Blue Microphones. Our Company's website is www.logitech.com.

[0001032975-20-000005:mdna:5]
[same as prior period, unchanged from 0001032975-19-000075:mdna:5]

[0001032975-20-000005:mdna:6]
On October 31, 2019 (the "Acquisition Date"), we acquired all equity interests of General Workings, Inc. ("Streamlabs") for a total consideration of $105.7 million, which included a working capital adjustment, plus an additional earn-out of $29.0 million payable in stock only upon the achievement of certain net revenues for the period beginning on January 1, 2020 and ending on June 30, 2020 (the "Streamlabs Acquisition"). Streamlabs is a leading provider of software and tools for professional streamers. The Streamlabs Acquisition will supplement our portfolio opportunities.

[0001032975-20-000005:mdna:7]
[same as prior period, unchanged from 0001032975-19-000075:mdna:7]

[0001032975-20-000005:mdna:8]
[same as prior period, unchanged from 0001032975-19-000075:mdna:8]

[0001032975-20-000005:mdna:9]
Our sales for the three and nine months ended December 31, 2019 increased 4% and 5%, respectively, compared to the three and nine months ended December 31, 2018.

[0001032975-20-000005:mdna:10]
Our sales for the three months ended December 31, 2019 decreased 1% in the Americas and increased 15% and 2% in EMEA and Asia Pacific, respectively, compared to the same period of the prior fiscal year. Our sales for the nine months ended December 31, 2019 increased 3%, 11%, and 1% in the Americas, EMEA, and Asia Pacific, respectively, compared to the same period of the prior fiscal year.

[0001032975-20-000005:mdna:11]
Our gross margin for the three months ended December 31, 2019 decreased 40 basis points to 37.1% from 37.5% for the three months ended December 31, 2018. The decrease in gross margin was primarily driven by unfavorable currency exchange rates and an increase in U.S.-China tariffs, partially offset by the benefits from cost savings and favorable shifts in product mix.

[0001032975-20-000005:mdna:12]
Our gross margin for the nine months ended December 31, 2019 increased 10 basis points to 37.3% from 37.2% for the nine months ended December 31, 2018. Our gross margin benefited from cost savings and product mix, partially offset by unfavorable currency exchange rates and an increase in U.S.-China tariffs. We expect a negative impact in the fourth quarter of fiscal year 2020 from these tariffs, net of our ongoing mitigation efforts.

[0001032975-20-000005:mdna:13]
Operating expenses for the three months ended December 31, 2019 increased to $205.6 million, compared to $200.6 million in the same period of the prior fiscal year. Operating expenses were 22.8% of sales for the three months ended December 31, 2019, compared to 23.2% of sales in the same period of the prior fiscal year.

[0001032975-20-000005:mdna:14]
Operating expenses for the nine months ended December 31, 2019 increased to $601.2 million, compared to $583.1 million in the same period of the prior fiscal year. Operating expenses were 26.5% of sales for the nine months ended December 31, 2019, compared to 26.9% of sales in the same period of the prior fiscal year.

[0001032975-20-000005:mdna:15]
Net income for the three and nine months ended December 31, 2019 was $117.5 million and $235.8 million, respectively, compared to $112.8 million and $215.5 million for the three and nine months ended December 31, 2018, respectively.

[0001032975-20-000005:mdna:16]
[same as prior period, unchanged from 0001032975-19-000075:mdna:15]

[0001032975-20-000005:mdna:17]
[same as prior period, unchanged from 0001032975-19-000075:mdna:16]

[0001032975-20-000005:mdna:18]
[same as prior period, unchanged from 0001032975-19-000075:mdna:17]

[0001032975-20-000005:mdna:19]
[same as prior period, unchanged from 0001032975-19-000075:mdna:18]

[0001032975-20-000005:mdna:20]
Creativity & Productivity:  New PC shipments are modestly growing and, the installed base of PC users remains large. We believe that innovative PC peripherals, such as our mice and keyboards, can renew the PC usage experience, thus providing growth opportunities. Increasing adoption of various cloud-based applications has led to multiple new consumer use cases, which we are addressing with our innovative product portfolio. The increasing popularity of streaming and broadcasting provides additional growth opportunities for our Webcam products, as well as other products in our portfolio. Smaller mobile computing devices, such as tablets, have created new markets and usage models for peripherals and accessories. We offer a number of products to enhance the use of mobile devices, including a combo backlit keyboard case for the iPad Pro and keyboard folios for other iPad models. In fiscal year 2019, we saw a recovery of the iPad tablet market, and our Tablet & Other Accessories category benefited from the recovery along with our innovative products.

[0001032975-20-000005:mdna:21]
Gaming:  The PC gaming and console gaming platforms continue to show strong structural growth opportunities as online gaming, multi-platform experiences, and esports gain greater popularity and gaming content becomes increasingly more demanding and social. In the past year, the gaming headset market has declined due to challenging comparisons against the launch of Fortnite in fiscal year 2019. We believe Logitech is well positioned to benefit from the overall gaming market growth. With ASTRO Gaming, we also strengthened our portfolio in adjacent categories, such as the console controller market.

[0001032975-20-000005:mdna:22]
[same as prior period, unchanged from 0001032975-19-000075:mdna:21]

[0001032975-20-000005:mdna:23]
Music:  The mobile speaker market has remained lackluster, although the consumption of music continues to grow. The integration of personal voice assistants has become increasingly competitive in the speaker categories, but the market for third-party, voice-enabled speakers has not yet gained traction. Moreover, the market for mobile speakers appears to be maturing, which led to a decline in Ultimate Ears sales in fiscal year 2019. In fiscal year 2019, the wireless headphone industry continued to flourish with strong revenue growth. The largest growth was in true wireless headphones where the market tripled year-over-year while traditional wireless headphones have started to decline. Continued growth in the wireless headphone market is expected for the next several years as consumers increasingly adopt wireless headphones over wired headphones. With Blue Microphones, we strengthened our portfolio in adjacent categories, such as the microphones market.

[0001032975-20-000005:mdna:24]
[same as prior period, unchanged from 0001032975-19-000075:mdna:23]

[0001032975-20-000005:mdna:25]
[same as prior period, unchanged from 0001032975-19-000075:mdna:24]

[0001032975-20-000005:mdna:26]
[same as prior period, unchanged from 0001032975-19-000075:mdna:25]

[0001032975-20-000005:mdna:27]
[same as prior period, unchanged from 0001032975-19-000075:mdna:26]

[0001032975-20-000005:mdna:28]
On May 19, 2019, the Swiss electorate approved TRAF, a major reform to better align the Swiss tax system with international tax standards. The legislation was subsequently published in the federal register on August 6, 2019 to take effect on January 1, 2020. As of December 31, 2019, TRAF has not been enacted in all cantons, including the canton of Vaud, as the cantonal legislative procedures are in process. We have benefited from a longstanding tax ruling from the canton of Vaud through December 31, 2019. We continue to monitor the enactment

[0001032975-20-000005:mdna:29]
process and our transitional measures to comply with federal and cantonal tax reform provisions. We anticipate an increase in our cash tax payments in Switzerland with respect to fiscal year 2020 and future years.

[0001032975-20-000005:mdna:30]
[same as prior period, unchanged from 0001032975-19-000075:mdna:29]

[0001032975-20-000005:mdna:31]
The preparation of financial statements and related disclosures in conformity with GAAP requires us to make judgments, estimates and assumptions that affect the reported amounts of goodwill, intangible assets acquired from business acquisitions, contingent consideration for business acquisition and periodical reassessment of its fair value, operating right-of-use assets, warranty liabilities, accruals for customer incentives, cooperative marketing, and pricing programs and related breakage when appropriate, accrued sales return liability, allowance for doubtful accounts, inventory, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets.

[0001032975-20-000005:mdna:32]
[same as prior period, unchanged from 0001032975-19-000075:mdna:31]

[0001032975-20-000005:mdna:33]
[same as prior period, unchanged from 0001032975-19-000075:mdna:32]

[0001032975-20-000005:mdna:34]
Other than the recent accounting pronouncement adoptions discussed in Note 1 to the condensed consolidated financial statements, there have been no substantial changes in our significant accounting policies during the nine months ended December 31, 2019, compared with the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended March 31, 2019.

[0001032975-20-000005:mdna:35]
[same as prior period, unchanged from 0001032975-19-000075:mdna:34]

[0001032975-20-000005:mdna:36]
[same as prior period, unchanged from 0001032975-19-000075:mdna:35]

[0001032975-20-000005:mdna:37]
[same as prior period, unchanged from 0001032975-19-000075:mdna:36]

[0001032975-20-000005:mdna:38]
[same as prior period, unchanged from 0001032975-19-000075:mdna:37]

[0001032975-20-000005:mdna:39]
Given our global sales presence and the reporting of our financial results in U.S. Dollars, our financial results could be affected by shifts in currency exchange rates. See “Results of Operations” for information on the effect of currency exchange rate on our sales. If the U.S. Dollar appreciates or depreciates in comparison to other currencies in future periods, this will affect our results of operations in future periods as well.

[0001032975-20-000005:mdna:40]
[same as prior period, unchanged from 0001032975-19-000075:mdna:39]

[0001032975-20-000005:mdna:41]
[same as prior period, unchanged from 0001032975-19-000075:mdna:40]

[0001032975-20-000005:mdna:42]
[same as prior period, unchanged from 0001032975-19-000075:mdna:41]

[0001032975-20-000005:mdna:43]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Canadian Dollar, Taiwan New Dollar, British Pound and Australian Dollar. During the three months ended December 31, 2019, approximately 52% of our sales were denominated in currencies other than the U.S. Dollar.

[0001032975-20-000005:mdna:44]
[same as prior period, unchanged from 0001032975-19-000075:mdna:43]

[0001032975-20-000005:mdna:45]
[same as prior period, unchanged from 0001032975-19-000075:mdna:44]

[0001032975-20-000005:mdna:46]
Our sales in the three and nine months ended December 31, 2019 increased 4% and 5%, respectively, compared to the same periods of the prior fiscal year, driven primarily by strong sales increase in the EMEA region. For the three-month period presented, strong growth in Video Collaboration, Gaming and Keyboards & Combos was partially offset by a decline in sales for Audio & Wearables, Tablet & Other Accessories, and Smart Home. For the nine-month period presented, strong growth in the same categories was partially offset by a decline in sales for Mobile Speakers, Audio & Wearables, and Smart Home. If currency exchange rates had been constant in the three and nine months ended December 31, 2019 and 2018, our constant dollar sales growth rates would have been 5% and 7%, respectively.

[0001032975-20-000005:mdna:47]
[same as prior period, unchanged from 0001032975-19-000075:mdna:47]

[0001032975-20-000005:mdna:48]
The following table presents the change in sales by region for the three and nine months ended December 31, 2019, compared with the three and nine months ended December 31, 2018:

[0001032975-20-000005:mdna:49]
|  |  | Sales Growth Rate |  | Constant DollarSales Growth Rate |
|  |  | Three Months Ended December 31, 2019 |  | Nine Months Ended December 31, 2019 |  | Three Months Ended December 31, 2019 | Nine Months Ended December 31, 2019 |
| Americas |  | (1 | )% |  | 3 | % |  | (1 | )% | 3 | % |
| EMEA |  | 15 | % |  | 11 | % |  | 16 | % | 14 | % |
| Asia Pacific |  | 2 | % |  | 1 | % |  | 3 | % | 4 | % |

[0001032975-20-000005:mdna:50]
[same as prior period, unchanged from 0001032975-19-000075:mdna:50]

[0001032975-20-000005:mdna:51]
The decrease in sales in our Americas region for the three-month ended period presented above was primarily driven by a decline in sales in Mobile Speakers and Audio & Wearables, partially offset by growth in Video Collaboration and Gaming. The increase in sales in our Americas region for the nine-month period presented above was primarily driven by growth in Video Collaboration and Tablet & Other Accessories, partially offset by a decline in Mobile Speakers and PC Webcams.

[0001032975-20-000005:mdna:52]
[same as prior period, unchanged from 0001032975-19-000075:mdna:52]

[0001032975-20-000005:mdna:53]
The increase in sales in our EMEA region for both the three- and nine-month ended periods presented above was primarily driven by growth in sales across a majority of our product categories, partially offset by a decline in Tablet & Other Accessories and Audio & Wearables.

[0001032975-20-000005:mdna:54]
[same as prior period, unchanged from 0001032975-19-000075:mdna:54]

[0001032975-20-000005:mdna:55]
The increase in sales in our Asia Pacific region for the three-month ended period presented above was primarily driven by growth in Keyboards & Combos and Gaming, partially offset by a decline in Audio & Wearables, Pointing Devices and Tablet & Other Accessories. The increase in sales in our Asia Pacific region for the nine-month period presented above was primarily driven by growth in Video Collaboration, Gaming and Keyboards & Combos, partially offset by a decline in Mobile Speakers and Audio & Wearables.

[0001032975-20-000005:mdna:56]
[same as prior period, unchanged from 0001032975-19-000075:mdna:56]

[0001032975-20-000005:mdna:57]
Sales by product categories for the three and nine months ended December 31, 2019 and 2018 were as follows (Dollars in thousands):

[0001032975-20-000005:mdna:58]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Pointing Devices |  | $ | 154,540 |  |  | $ | 149,123 |  |  | 4 | % |  | $ | 409,293 |  |  | $ | 405,250 |  |  | 1 | % |
| Keyboards & Combos |  | 156,333 |  |  | 144,169 |  |  | 8 |  |  | 424,061 |  |  | 404,263 |  |  | 5 |  |
| PC Webcams |  | 32,165 |  |  | 33,021 |  |  | (3 | ) |  | 89,041 |  |  | 90,916 |  |  | (2 | ) |
| Tablet & Other Accessories |  | 31,256 |  |  | 35,757 |  |  | (13 | ) |  | 103,442 |  |  | 104,903 |  |  | (1 | ) |
| Video Collaboration |  | 91,964 |  |  | 74,186 |  |  | 24 |  |  | 254,941 |  |  | 190,154 |  |  | 34 |  |
| Mobile Speakers |  | 92,969 |  |  | 96,263 |  |  | (3 | ) |  | 200,617 |  |  | 207,690 |  |  | (3 | ) |
| Audio & Wearables |  | 81,934 |  |  | 98,629 |  |  | (17 | ) |  | 208,576 |  |  | 212,343 |  |  | (2 | ) |
| Gaming |  | 245,736 |  |  | 213,663 |  |  | 15 |  |  | 541,265 |  |  | 510,481 |  |  | 6 |  |
| Smart Home |  | 15,790 |  |  | 19,577 |  |  | (19 | ) |  | 35,088 |  |  | 37,829 |  |  | (7 | ) |
| Other (1) |  | — |  |  | — |  |  | — |  |  | 279 |  |  | 185 |  |  | 51 |  |
| Total sales |  | $ | 902,687 |  |  | $ | 864,388 |  |  | 4 | % |  | $ | 2,266,603 |  |  | $ | 2,164,014 |  |  | 5 | % |

[0001032975-20-000005:mdna:59]
[same as prior period, unchanged from 0001032975-19-000075:mdna:59]

[0001032975-20-000005:mdna:60]
[same as prior period, unchanged from 0001032975-19-000075:mdna:60]

[0001032975-20-000005:mdna:61]
[same as prior period, unchanged from 0001032975-19-000075:mdna:61]

[0001032975-20-000005:mdna:62]
[same as prior period, unchanged from 0001032975-19-000075:mdna:62]

[0001032975-20-000005:mdna:63]
Sales of Pointing Devices increased 4% and 1% in the three and nine months ended December 31, 2019, respectively, compared to the same periods of the prior fiscal year. The increases in both periods were primarily driven by growth in sales of our cordless mice, partially offset by a decline in sales of our corded mice.

[0001032975-20-000005:mdna:64]
[same as prior period, unchanged from 0001032975-19-000075:mdna:64]

[0001032975-20-000005:mdna:65]
[same as prior period, unchanged from 0001032975-19-000075:mdna:65]

[0001032975-20-000005:mdna:66]
Sales of Keyboards & Combos increased 8% and 5% in the three and nine months ended December 31, 2019, respectively, compared to the same periods of the prior fiscal year. The increases were across all regions for both periods and primarily driven by increases in sales of our cordless and corded keyboards and keyboard/mice combos, partially offset by a decline in sales of our living room keyboard products.

[0001032975-20-000005:mdna:67]
[same as prior period, unchanged from 0001032975-19-000075:mdna:67]

[0001032975-20-000005:mdna:68]
[same as prior period, unchanged from 0001032975-19-000075:mdna:68]

[0001032975-20-000005:mdna:69]
PC Webcams sales decreased 3% and 2% in the three and nine months ended December 31, 2019, respectively, compared to the same periods of the prior fiscal year. The decrease in sales for the three-month period was primarily driven by a decline in sales of our Webcam C170, HD PRO Webcam C920, and HD Webcam C525, partially offset by an increase in the sales of our C270i IPTV CAM. The decrease in sales for the nine-month period was primarily driven by a decline in sales of our HD PRO Webcam C920, Webcam C170 and HD Webcam C525 partially offset by an increase in sales of our Webcam C260, C270i IPTV CAM and BRIO 4K Stream Edition.

[0001032975-20-000005:mdna:70]
[same as prior period, unchanged from 0001032975-19-000075:mdna:70]

[0001032975-20-000005:mdna:71]
[same as prior period, unchanged from 0001032975-19-000075:mdna:71]

[0001032975-20-000005:mdna:72]
Sales of Tablet & Other Accessories products decreased 13% and 1% in the three and nine months ended December 31, 2019, respectively, compared to the same periods of the prior fiscal year. The decrease in sales for the three-month period was primarily driven by a decline in sales of our Slim Folio for the 2017/2018 iPad and CRAYON, partially offset by an increase in sales of our Slim Folio Pro for the 11" and 12.9" iPad Pro introduced in the first quarter of fiscal year 2020 and sales of our Rugged Folio and Slim Folio for a newer generation of iPads introduced in the third quarter of fiscal year 2020. The decrease in sales for the nine-month period was primarily driven by a decline in sales of our Slim Combo keyboard cases for iPad Pro and Slim Folio keyboard cases for 10.5" iPad, partially offset by growth in sales of our Slim Folio Pro for the 11" and 12.9" iPad Pro and Rugged Folio for the newer generation of iPads.

[0001032975-20-000005:mdna:73]
[same as prior period, unchanged from 0001032975-19-000075:mdna:73]

[0001032975-20-000005:mdna:74]
Our Gaming category comprises gaming mice, keyboards, headsets, gamepads, steering wheels, simulation controllers, console gaming headsets, console gaming controllers, and Streamlabs services.

[0001032975-20-000005:mdna:75]
Gaming sales increased 15% and 6% in the three and nine months ended December 31, 2019, respectively, compared to the same periods of the prior fiscal year. The increase in both periods was primarily driven by growth in sales of our gaming mice, gaming keyboards, gaming steering wheels, and console gaming controllers and sales from Streamlabs services as a result of our business combination (see Note 2 to the condensed consolidated financial statements). The growth was partially offset by a decline in sales of our gaming headsets and console gaming headsets.

[0001032975-20-000005:mdna:76]
[same as prior period, unchanged from 0001032975-19-000075:mdna:76]

[0001032975-20-000005:mdna:77]
[same as prior period, unchanged from 0001032975-19-000075:mdna:77]

[0001032975-20-000005:mdna:78]
[same as prior period, unchanged from 0001032975-19-000075:mdna:78]

[0001032975-20-000005:mdna:79]
Sales of Video Collaboration products increased 24% and 34% in the three and nine months ended  December 31, 2019, respectively, compared to the same periods of the prior fiscal year. The increases were across all regions for both periods. The increase for the three-month period was primarily driven by the sales of our Rally Ultra-HD PTZ Conference Camera introduced in the third quarter of fiscal year 2019 and our Tap Touch Controller introduced in the first quarter of fiscal year 2020, partially offset by a decrease in sales of Group Expansion Mic. The increase for the nine-month period was primarily driven by the sales of our Rally Ultra-HD PTZ Conference Camera introduced in the third quarter of fiscal year 2019, an increase in the sales of our MeetUp video conference camera, and sales of our Tap Touch Controller introduced in the first quarter of fiscal year 2020, partially offset by a decrease in sales of older generation products.

[0001032975-20-000005:mdna:80]
[same as prior period, unchanged from 0001032975-19-000075:mdna:80]

[0001032975-20-000005:mdna:81]
[same as prior period, unchanged from 0001032975-19-000075:mdna:81]

[0001032975-20-000005:mdna:82]
[same as prior period, unchanged from 0001032975-19-000075:mdna:82]

[0001032975-20-000005:mdna:83]
Sales of Mobile Speakers decreased 3% for both the three and nine months ended December 31, 2019, compared to the same periods of the prior fiscal year. The decrease for the three-month period was primarily due to a decline in sales of our WONDERBOOM, BOOM 2 and MEGABOOM mobile speakers, partially offset by sales of our WONDERBOOM 2 introduced in the first quarter of fiscal year 2020. The decrease for the nine-month period was primarily due to a decline in sales of our WONDERBOOM, BOOM 2, and MEGABLAST mobile speakers, partially offset by sales of WONDERBOOM 2 and an increase in sales of our BOOM 3 and MEGABOOM 3 mobile speakers.

[0001032975-20-000005:mdna:84]
[same as prior period, unchanged from 0001032975-19-000075:mdna:84]

[0001032975-20-000005:mdna:85]
[same as prior period, unchanged from 0001032975-19-000075:mdna:85]

[0001032975-20-000005:mdna:86]
Audio & Wearables sales decreased 17% and 2% for the three and nine months ended December 31, 2019, respectively, compared to the same periods of the prior fiscal year. The decrease for the three-month period was primarily driven by the decrease in sales of our PC speakers, Blue Microphone products, and Jaybird traditional wireless products, partially offset by the increase in sales of Jaybird True Wireless products. The decrease for the nine-month period was primarily driven by a decline in the sales of our PC speakers and Jaybird traditional wireless products, partially offset primarily by the growth in sales of our Blue Microphones products, as a result of our business combination in the second quarter of fiscal year 2019, and Jaybird True wireless products.

[0001032975-20-000005:mdna:87]
[same as prior period, unchanged from 0001032975-19-000075:mdna:87]

[0001032975-20-000005:mdna:88]
[same as prior period, unchanged from 0001032975-19-000075:mdna:88]

[0001032975-20-000005:mdna:89]
Smart Home sales decreased 19% and 7% during the three and nine months ended December 31, 2019, respectively, compared to the same periods of the prior fiscal year. The decrease in sales for the three-month and nine-month periods was primarily driven by an overall decline in sales in our Harmony remote products, partially offset by an increase in sales of our home security products.

[0001032975-20-000005:mdna:90]
34

[0001032975-20-000005:mdna:91]
[same as prior period, unchanged from 0001032975-19-000075:mdna:90]

[0001032975-20-000005:mdna:92]
Gross profit for the three and nine months ended December 31, 2019 and 2018 was as follows (Dollars in thousands):

[0001032975-20-000005:mdna:93]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Net sales |  | $ | 902,687 |  |  | $ | 864,388 |  |  | 4 | % |  | $ | 2,266,603 |  |  | $ | 2,164,014 |  |  | 5 | % |
| Gross profit |  | $ | 334,453 |  |  | $ | 323,982 |  |  | 3 |  |  | $ | 845,505 |  |  | $ | 804,036 |  |  | 5 |  |
| Gross margin |  | 37.1 | % |  | 37.5 | % |  |  |  | 37.3 | % |  | 37.2 | % |  |  |  |

[0001032975-20-000005:mdna:94]
[same as prior period, unchanged from 0001032975-19-000075:mdna:93]

[0001032975-20-000005:mdna:95]
[same as prior period, unchanged from 0001032975-19-000075:mdna:94]

[0001032975-20-000005:mdna:96]
Operating expenses for the three and nine months ended December 31, 2019 and 2018 were as follows (Dollars in thousands):

[0001032975-20-000005:mdna:97]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Marketing and selling |  | $ | 134,950 |  |  | $ | 132,250 |  |  | $ | 392,138 |  |  | $ | 368,635 |  |
| % of sales |  | 14.9 | % |  | 15.3 | % |  | 17.3 | % |  | 17.0 | % |
| Research and development |  | 43,292 |  |  | 40,591 |  |  | 127,499 |  |  | 119,120 |  |
| % of sales |  | 4.8 | % |  | 4.7 | % |  | 5.6 | % |  | 5.5 | % |
| General and administrative |  | 22,344 |  |  | 24,496 |  |  | 68,551 |  |  | 75,175 |  |
| % of sales |  | 2.5 | % |  | 2.8 | % |  | 3.0 | % |  | 3.5 | % |
| Amortization of intangible assets and acquisition-related costs |  | 5,084 |  |  | 3,539 |  |  | 12,898 |  |  | 10,377 |  |
| % of sales |  | 0.6 | % |  | 0.4 | % |  | 0.6 | % |  | 0.5 | % |
| Restructuring charges (credits), net |  | (45 | ) |  | (278 | ) |  | 69 |  |  | 9,762 |  |
| % of sales |  | — | % | (1) | — | % |  | — | % | (1) | 0.5 | % |
| Total operating expenses |  | $ | 205,625 |  |  | $ | 200,598 |  |  | $ | 601,155 |  |  | $ | 583,069 |  |
| % of sales |  | 22.8 | % |  | 23.2 | % |  | 26.5 | % |  | 26.9 | % |

[0001032975-20-000005:mdna:98]
[same as prior period, unchanged from 0001032975-19-000075:mdna:97]

[0001032975-20-000005:mdna:99]
[same as prior period, unchanged from 0001032975-19-000075:mdna:98]

[0001032975-20-000005:mdna:100]
[same as prior period, unchanged from 0001032975-19-000075:mdna:99]

[0001032975-20-000005:mdna:101]
During the three and nine months ended December 31, 2019, marketing and selling expenses increased $2.7 million and $23.5 million, respectively, compared to the same periods of the prior fiscal year. The increases were primarily driven by higher personnel-related costs due to increased headcount, partly resulting from the Blue Microphones and Streamlabs acquisitions, partially offset by reduced marketing expenses.

[0001032975-20-000005:mdna:102]
[same as prior period, unchanged from 0001032975-19-000075:mdna:101]

[0001032975-20-000005:mdna:103]
[same as prior period, unchanged from 0001032975-19-000075:mdna:102]

[0001032975-20-000005:mdna:104]
During the three and nine months ended December 31, 2019, research and development expenses increased $2.7 million and $8.4 million, respectively, compared to the same periods of the prior fiscal year. The increases were primarily driven by higher personnel-related costs due to increased headcount, partly resulting from the Blue Microphones and Streamlabs acquisitions, and higher investment in new product development.

[0001032975-20-000005:mdna:105]
[same as prior period, unchanged from 0001032975-19-000075:mdna:104]

[0001032975-20-000005:mdna:106]
[same as prior period, unchanged from 0001032975-19-000075:mdna:105]

[0001032975-20-000005:mdna:107]
During the three and nine months ended December 31, 2019, general and administrative expenses decreased $2.2 million and $6.6 million, respectively, compared to the same periods of the prior fiscal year. The decrease was primarily driven by lower personnel-related costs.

[0001032975-20-000005:mdna:108]
[same as prior period, unchanged from 0001032975-19-000075:mdna:107]

[0001032975-20-000005:mdna:109]
Amortization of intangible assets and acquisition-related costs during the three and nine months ended December 31, 2019 and 2018 were as follows (in thousands):

[0001032975-20-000005:mdna:110]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Amortization of intangible assets |  | $ | 4,272 |  |  | $ | 3,539 |  |  | $ | 11,465 |  |  | $ | 8,921 |  |
| Acquisition-related costs |  | 812 |  |  | — |  |  | 1,433 |  |  | 1,456 |  |
| Total |  | $ | 5,084 |  |  | $ | 3,539 |  |  | $ | 12,898 |  |  | $ | 10,377 |  |

[0001032975-20-000005:mdna:111]
[same as prior period, unchanged from 0001032975-19-000075:mdna:108]

[0001032975-20-000005:mdna:112]
During the three and nine months ended December 31, 2019, amortization of intangible assets and acquisition-related costs increased $1.5 million and $2.5 million, respectively, compared to the same period of the prior fiscal year, primarily driven by the intangible assets acquired through the Blue Microphones acquisition in the second quarter of fiscal year 2019 and the Streamlabs Acquisition in the third quarter of fiscal year 2020.

[0001032975-20-000005:mdna:113]
[same as prior period, unchanged from 0001032975-19-000075:mdna:110]

[0001032975-20-000005:mdna:114]
During the first quarter of fiscal year 2019, we implemented a restructuring plan to streamline and realign our overall organizational structure and reallocate resources to support our long-term growth opportunities. In July, 2018, our Board of Directors approved additional costs under this restructuring plan, totaling pre-tax charges of approximately $10.0 million to $15.0 million, of which $11.4 million has been recognized cumulatively as of December 31, 2019. The total charges consisted of cash severance and other personnel costs and are presented as restructuring charges (credit), net in the condensed consolidated statements of operations. As of June 30, 2019, the Company had substantially completed this restructuring plan.

[0001032975-20-000005:mdna:115]
The following table summarizes restructuring-related activities during the three and nine months ended December 31, 2019 (in thousands):

[0001032975-20-000005:mdna:116]
|  |  | TerminationBenefits |
| Accrual balance at March 31, 2019 |  | $ | 4,389 |  |
| Charges |  | 478 |  |
| Cash payments |  | (1,956 | ) |
| Accrual balance at June 30, 2019 |  | 2,911 |  |
| Charges |  | (364 | ) |
| Cash payments |  | (1,140 | ) |
| Accrual balance at September 30, 2019 |  | 1,407 |  |
| Credits, net |  | (45 | ) |
| Cash payments |  | (308 | ) |
| Accrual balance at December 31, 2019 |  | $ | 1,054 |  |

[0001032975-20-000005:mdna:117]
[same as prior period, unchanged from 0001032975-19-000075:mdna:114]

[0001032975-20-000005:mdna:118]
Other income (expense), net for the three and nine months ended December 31, 2019 and 2018 was as follows (in thousands):

[0001032975-20-000005:mdna:119]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Investment income (loss) related to a deferred compensation plan |  | $ | 1,045 |  |  | $ | (1,887 | ) |  | $ | 1,836 |  |  | $ | (1,077 | ) |
| Currency exchange gain (loss), net |  | 203 |  |  | (1,715 | ) |  | 702 |  |  | (1,801 | ) |
| Gain (loss) on investments |  | (709 | ) |  | 207 |  |  | (772 | ) |  | 589 |  |
| Other |  | 562 |  |  | 648 |  |  | 1,086 |  |  | 1,360 |  |
| Total |  | $ | 1,101 |  |  | $ | (2,747 | ) |  | $ | 2,852 |  |  | $ | (929 | ) |

[0001032975-20-000005:mdna:120]
Investment income (loss) represents earnings, gains, and losses on trading investments related to a deferred compensation plan offered by one of our subsidiaries.

[0001032975-20-000005:mdna:121]
Currency exchange gain (loss), net relates to balances denominated in currencies other than the functional currency in our subsidiaries, as well as to the sale of currencies, and gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses.

[0001032975-20-000005:mdna:122]
Gain (loss) on investments represents the unrealized gain (loss) from the fair value change from the available-for-sale securities and equity-method investments during the periods presented.

[0001032975-20-000005:mdna:123]
[same as prior period, unchanged from 0001032975-19-000075:mdna:119]

[0001032975-20-000005:mdna:124]
The provision for (benefit from) income taxes and effective tax rates for the three and nine months ended December 31, 2019 and 2018 were as follows (Dollars in thousands):

[0001032975-20-000005:mdna:125]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Provision for income taxes |  | $ | 14,467 |  |  | $ | 9,309 |  |  | $ | 18,405 |  |  | $ | 10,295 |  |
| Effective income tax rate |  | 11.0 | % |  | 7.6 | % |  | 7.2 | % |  | 4.6 | % |

[0001032975-20-000005:mdna:126]
The change in the effective income tax rate for the three and nine months ended December 31, 2019, compared to the same periods ended December 31, 2018, was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate and the transitional income tax impact in Switzerland. We have

[0001032975-20-000005:mdna:127]
benefited from a longstanding tax ruling from the canton of Vaud through December 31, 2019. The transitional income tax impact represents income tax provision at the current full statutory income tax rate of 13.67% without taking account of other elements of the tax reform yet to be enacted. Furthermore, there was a discrete tax benefit of $1.7 million from adjusting deferred tax assets and liabilities in Switzerland in the nine months ended December 31, 2019. There were discrete tax benefits of $6.0 million and $2.7 million from the recognition of net excess tax benefits in the United States and reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the nine-month period ended December 31, 2019, compared with $9.5 million and $2.3 million, respectively, in the nine-month period ended December 31, 2018.

[0001032975-20-000005:mdna:128]
As of December 31, 2019 and March 31, 2019, the total amounts of unrecognized tax benefits due to uncertain tax positions were $85.0 million and $76.5 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-20-000005:mdna:129]
[same as prior period, unchanged from 0001032975-19-000075:mdna:125]

[0001032975-20-000005:mdna:130]
[same as prior period, unchanged from 0001032975-19-000075:mdna:126]

[0001032975-20-000005:mdna:131]
As of December 31, 2019, we had cash and cash equivalents of $656.0 million, compared to $604.5 million as of March 31, 2019. As of December 31, 2019, 69% of the cash and cash equivalents were held in Switzerland and 17% held in Hong Kong and China. We do not expect to incur any material adverse tax impact except for what has been recognized, or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-20-000005:mdna:132]
The increase in cash and cash equivalents for the nine months ended December 31, 2019, was primarily due to an increase in net cash provided by operating activities, partially offset by payment of cash dividends, cash paid for the Streamlabs Acquisition (see Note 2 to the condensed consolidated financial statements), purchases of property, plant and equipment, tax withholdings related to settlements of restricted stock units and shares repurchased under our share buyback program.

[0001032975-20-000005:mdna:133]
As of December 31, 2019, our working capital was $680.4 million, compared to $632.6 million as of March 31, 2019. The increase was primarily driven by higher cash and cash equivalents, higher accounts receivables, net, higher inventories, and higher other current assets; partially offset by higher accounts payable and higher accrued and other current liabilities. Our working capital increased by $110.9 million compared to $569.5 million as of December 31, 2018, which was primarily driven by higher cash and cash equivalents, higher accounts receivable, net, and lower accrued and other current liabilities, partially offset by lower inventories and higher accounts payable.

[0001032975-20-000005:mdna:134]
We had several uncommitted, unsecured bank lines of credit aggregating $78.4 million as of December 31, 2019. There are no financial covenants under these lines of credit with which we must comply. As of December 31, 2019, we had outstanding bank guarantees of $17.1 million under these lines of credit.

[0001032975-20-000005:mdna:135]
[same as prior period, unchanged from 0001032975-19-000075:mdna:131]

[0001032975-20-000005:mdna:136]
|  |  | Nine Months EndedDecember 31, |
|  |  | 2019 |  | 2018 |
| Net cash provided by operating activities |  | $ | 324,154 |  |  | $ | 273,443 |  |
| Net cash used in investing activities |  | (119,441 | ) |  | (165,756 | ) |
| Net cash used in financing activities |  | (150,863 | ) |  | (155,401 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (2,320 | ) |  | (9,745 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | 51,530 |  |  | $ | (57,459 | ) |

[0001032975-20-000005:mdna:137]
The following tables present selected financial information and statistics as of and for the three months ended December 31, 2019 and 2018 (Dollars in thousands):

[0001032975-20-000005:mdna:138]
|  |  | As of December 31, |
|  |  | 2019 |  | 2018 |
| Accounts receivable, net |  | $ | 531,309 |  |  | $ | 484,204 |  |
| Accounts payable |  | $ | 439,035 |  |  | $ | 435,764 |  |
| Inventories |  | $ | 307,494 |  |  | $ | 342,031 |  |

[0001032975-20-000005:mdna:139]
|  |  | Three Months EndedDecember 31, |
|  |  | 2019 |  | 2018 |
| Days sales in accounts receivable (“DSO”) (Days) (1) |  | 53 |  |  | 50 |  |
| Days accounts payable outstanding (“DPO”) (Days) (2) |  | 70 |  |  | 73 |  |
| Inventory turnover (“ITO”) (x)(3) |  | 7.4 |  |  | 6.3 |  |

[0001032975-20-000005:mdna:140]
[same as prior period, unchanged from 0001032975-19-000075:mdna:136]

[0001032975-20-000005:mdna:141]
[same as prior period, unchanged from 0001032975-19-000075:mdna:137]

[0001032975-20-000005:mdna:142]
(3) ITO is determined using ending inventories as of the most recent quarter end and annualized cost of goods sold (based on the most recent quarterly cost of goods sold).

[0001032975-20-000005:mdna:143]
DSO for the three months ended December 31, 2019 increased by 3 days to 53 days, compared to 50 days for the same period of the prior fiscal year, primarily due to timing of customer payments.

[0001032975-20-000005:mdna:144]
DPO for the three months ended December 31, 2019 decreased by 3 days, compared to the same period of the prior fiscal year, primarily due to the timing of purchases and related payments and an increase in cost of goods sold due to higher sales growth.

[0001032975-20-000005:mdna:145]
ITO for the three months ended December 31, 2019 increased to 7.4 compared to 6.3 in the same period of the prior fiscal year, primarily due to higher sales growth, resulting to lower inventories at the period end.

[0001032975-20-000005:mdna:146]
If we are not successful in launching and phasing in our new products, or market competition increases, or we are not able to sell the new products at the prices planned, it could have a material adverse impact on our sales, gross profit margin, operating results including operating cash flow, and inventory turnover in the future.

[0001032975-20-000005:mdna:147]
During the nine months ended December 31, 2019, we generated $324.2 million of cash from operating activities. Our main sources of operating cash flows were from net income, after adding back non-cash expenses of depreciation, amortization and share-based compensation expense, and from changes in operating assets and liabilities. The increase in accounts receivable, net was primarily driven by sales growth and timing of customer payments. The increase in inventories was primarily driven by seasonality. The increase in accounts payable was primarily driven by the timing of purchases and related payments.

[0001032975-20-000005:mdna:148]
Net cash used in investing activities was $119.4 million, primarily due to the payment of $91.6 million for acquisitions, net of acquired cash, and $28.7 million of purchases of property, plant and equipment.

[0001032975-20-000005:mdna:149]
Net cash used in financing activities was $150.9 million, primarily due to $124.2 million payment of cash dividend, $15.1 million used for repurchases of our registered shares, and $23.1 million tax withholdings related to net share settlements of restricted stock units, partially offset by $11.5 million in proceeds received from exercises of stock options and ESPP rights.

[0001032975-20-000005:mdna:150]
During the nine months ended December 31, 2019, there was a $2.3 million loss from effect of currency exchange rate changes on cash and cash equivalents, compared to a loss of $9.7 million during the same period of the prior fiscal year. The loss from effect of currency exchange rate changes during the nine months ended

[0001032975-20-000005:mdna:151]
December 31, 2019 was primarily due to the weakening of the Euro, Chinese Renminbi and Brazilian Real against the U.S. Dollar by 1%, 4%, and 4% respectively. The loss from effect of currency exchange rate changes during the nine months ended December 31, 2018 was primarily due to the weakening of the Euro and Chinese Renminbi against the U.S. Dollar by 7% and 8%, respectively, during the period.

[0001032975-20-000005:mdna:152]
[same as prior period, unchanged from 0001032975-19-000075:mdna:147]

[0001032975-20-000005:mdna:153]
[same as prior period, unchanged from 0001032975-19-000075:mdna:148]

[0001032975-20-000005:mdna:154]
[same as prior period, unchanged from 0001032975-19-000075:mdna:150]

[0001032975-20-000005:mdna:155]
In March 2017, our Board of Directors approved our 2017 share buyback program, which authorizes us to purchase up to $250.0 million of our outstanding shares over a three-year period. The program was approved by the Swiss Takeover Board in May 2017. Although we enter into trading plans for systematic repurchases (e.g., 10b5-1 trading plans) from time to time, our share buyback program provides us with the opportunity to make repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. As of December 31, 2019, $172.4 million is still available for repurchase under the 2017 share buyback program.

[0001032975-20-000005:mdna:156]
[same as prior period, unchanged from 0001032975-19-000075:mdna:152]

[0001032975-20-000005:mdna:157]
[same as prior period, unchanged from 0001032975-19-000075:mdna:153]

[0001032975-20-000005:mdna:158]
[same as prior period, unchanged from 0001032975-19-000075:mdna:154]

[0001032975-20-000005:mdna:159]
[same as prior period, unchanged from 0001032975-19-000075:mdna:155]

[0001032975-20-000005:mdna:160]
As of December 31, 2019, we had non-cancelable purchase commitments for inventory purchases made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. Non-cancelable purchase commitments for capital expenditures primarily relate to commitments for tooling for new and existing products, computer hardware, leasehold and improvements. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-20-000005:mdna:161]
[same as prior period, unchanged from 0001032975-19-000075:mdna:157]

[0001032975-20-000005:mdna:162]
[same as prior period, unchanged from 0001032975-19-000075:mdna:158]

[0001032975-20-000005:mdna:163]
[same as prior period, unchanged from 0001032975-19-000075:mdna:159]

[0001032975-20-000005:mdna:164]
[same as prior period, unchanged from 0001032975-19-000075:mdna:160]

[0001032975-20-000005:mdna:165]
[same as prior period, unchanged from 0001032975-19-000075:mdna:161]

[0001032975-20-000005:mdna:166]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2019, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-20-000005:mdna:167]
[same as prior period, unchanged from 0001032975-19-000075:mdna:163]

[0001032975-20-000005:mdna:168]
Legal Proceedings

[0001032975-20-000005:mdna:169]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of our business. We are currently subject to several such claims and a small number of legal proceedings. We believe that these matters lack merit and we intend to vigorously defend against them. Based on currently available information, we do not believe that resolution of pending matters will have a material adverse effect on our financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that our defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on our business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against us, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary licenses or other rights, or litigation arising out of intellectual property claims, could adversely affect our business.
