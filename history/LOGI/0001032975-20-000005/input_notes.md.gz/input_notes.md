# LOGI notes — 0001032975-20-000005


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-20-000005:notes:1]
[same as prior period, unchanged from 0001032975-19-000075:notes:1]

[0001032975-20-000005:notes:2]
[same as prior period, unchanged from 0001032975-19-000075:notes:2]

[0001032975-20-000005:notes:3]
[same as prior period, unchanged from 0001032975-19-000075:notes:3]

[0001032975-20-000005:notes:4]
[same as prior period, unchanged from 0001032975-19-000075:notes:4]

[0001032975-20-000005:notes:5]
[same as prior period, unchanged from 0001032975-19-000075:notes:5]

[0001032975-20-000005:notes:6]
Business Acquisition

[0001032975-20-000005:notes:7]
On October 31, 2019, the Company acquired General Workings, Inc. See "Note 2 - Business Acquisition" for more information.

[0001032975-20-000005:notes:8]
[same as prior period, unchanged from 0001032975-19-000075:notes:6]

[0001032975-20-000005:notes:9]
[same as prior period, unchanged from 0001032975-19-000075:notes:7]

[0001032975-20-000005:notes:10]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and nine months ended December 31, 2019 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2020, or any future periods.

[0001032975-20-000005:notes:11]
[same as prior period, unchanged from 0001032975-19-000075:notes:9]

[0001032975-20-000005:notes:12]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted and Summary of Significant Accounting Policies, there have been no changes in the Company’s significant accounting policies during the nine months ended December 31, 2019 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2019.

[0001032975-20-000005:notes:13]
[same as prior period, unchanged from 0001032975-19-000075:notes:11]

[0001032975-20-000005:notes:14]
The preparation of financial statements in conformity with GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements.

[0001032975-20-000005:notes:15]
Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill, intangible assets acquired from business acquisitions, contingent consideration for a business acquisition and periodic reassessment of its fair value, valuation of operating right-of-use assets, warranty liabilities, accruals for customer incentives, cooperative marketing, and pricing programs (Customer Programs) and related breakage when appropriate, accrued sales return liability, allowance for doubtful accounts, inventory valuation, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from these estimates.

[0001032975-20-000005:notes:16]
[same as prior period, unchanged from 0001032975-19-000075:notes:14]

[0001032975-20-000005:notes:17]
In February 2016, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No. 2016-02, "Leases (Topic 842)" (ASU 2016-02 or Topic 842), which requires a lessee to recognize right-of-use (ROU) assets and lease liabilities arising from operating and financing leases with terms longer than 12 months on the consolidated balance sheets and to disclose key information about leasing arrangements.

[0001032975-20-000005:notes:18]
[same as prior period, unchanged from 0001032975-19-000075:notes:16]

[0001032975-20-000005:notes:19]
Adoption of the standard resulted in the recognition of $31.3 million of ROU assets and $37.4 million of lease liabilities related to the Company's leases on its condensed consolidated balance sheet on April 1, 2019. The difference of $6.1 million represented deferred rent for leases that existed as of the date of adoption, which decreased the opening balance of ROU assets. In addition, the prepaid rent balance as of the date of adoption increased the opening balance of ROU assets. The deferred rent and prepaid rent balances were derecognized as of the date of adoption and no adjustment was made to retained earnings. The adoption of the standard did not have an impact on the Company's condensed consolidated statement of operations, comprehensive income, changes in shareholders' equity or cash flows.

[0001032975-20-000005:notes:20]
In August 2018, the FASB issued ASU 2018-15, "Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Customer's Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract" (ASU 2018-15), which clarifies that implementation costs incurred by customers in cloud computing arrangements are deferred if they would be capitalized by customers in software licensing arrangements under the internal-use software guidance. ASU 2018-15 is effective for annual and interim periods in fiscal years beginning after December 15, 2019, with early adoption permitted. Entities have the option to apply the guidance prospectively to all implementation costs incurred after the date of adoption or retrospectively. The Company adopted this standard effective April 1, 2019 using a prospective adoption method. The adoption of ASU 2018-15 did not have a material impact on the Company's condensed consolidated financial statements.

[0001032975-20-000005:notes:21]
[same as prior period, unchanged from 0001032975-19-000075:notes:19]

[0001032975-20-000005:notes:22]
In June 2016, the FASB issued ASU 2016-13, "Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments" (ASU 2016-13), which was further updated and clarified by the FASB through issuance of additional related ASUs, replaces the incurred-loss impairment methodology and requires immediate recognition of estimated credit losses expected to occur for most financial assets, including trade receivables. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not expect the adoption of ASU 2016-13 will have a material impact on its consolidated financial statements and plans to adopt the standard effective April 1, 2020.

[0001032975-20-000005:notes:23]
In August 2018, the FASB issued ASU 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirements for Fair Value Measurements" (ASU 2018-13), which aims to improve the overall usefulness of disclosures to financial statement users and reduce unnecessary costs to companies when preparing fair value measurement disclosures. ASU 2018-13 is effective for annual and interim periods in fiscal years beginning after December 15, 2019. Early adoption is permitted. Retrospective adoption is required, except for certain disclosures which will be required to be applied prospectively for only the most recent interim or annual period presented in the initial fiscal year of adoption. The Company does not expect the adoption of ASU 2018-13 will have a material impact on its consolidated financial statements and plans to adopt the standard effective April 1, 2020.

[0001032975-20-000005:notes:24]
In August 2018, the FASB issued ASU 2018-14, "Compensation - Retirement Benefits - Defined Benefits Plans - General (Subtopic 715-20): Disclosure Framework - Changes to the Disclosure Requirements for Defined Benefit Plans" (ASU 2018-14), which aims to improve the overall usefulness of disclosures to financial statement users and reduce unnecessary costs to companies when preparing defined benefit plan disclosures. ASU 2018-14 is effective for annual periods in fiscal years ending after December 15, 2020. Retrospective adoption is required and early adoption is permitted. The Company does not expect the adoption of ASU 2018-14 will have a material impact on its consolidated financial statements and plans to adopt the standard effective April 1, 2020.

[0001032975-20-000005:notes:25]
In December 2019, the FASB issued ASU 2019-12, "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes" (ASU 2019-12), which eliminates certain exceptions for recognizing deferred taxes for investments, performing intraperiod allocation and calculating income taxes in interim periods. This ASU also includes guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. ASU 2019-12 is effective for annual and interim periods in fiscal years beginning after December 15, 2020. Early adoption is permitted. The Company is currently assessing the impact of ASU 2019-12 on its consolidated financial statements and plans to adopt the standard effective April 1, 2021.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001032975-20-000005:notes:26]
Business Acquisitions

[0001032975-20-000005:notes:27]
On October 31, 2019 (the "Acquisition Date"), the Company acquired all equity interests of General Workings, Inc. ("Streamlabs") for a total consideration of $105.7 million (as described in the table below), which included a working capital adjustment, plus additional contingent consideration of $29.0 million payable in stock only upon the achievement of certain net revenues for the period beginning on January 1, 2020 and ending on June 30, 2020 (the "Streamlabs Acquisition").

[0001032975-20-000005:notes:28]
Streamlabs is a leading provider of software and tools for professional streamers. The Streamlabs Acquisition will be complementary to the Company's existing gaming portfolio.

[0001032975-20-000005:notes:29]
Streamlabs met the definition of a business, and therefore the acquisition is accounted for using the acquisition method.

[0001032975-20-000005:notes:30]
The fair value of consideration transferred for the Streamlabs Acquisition consists of the following (in thousands):

[0001032975-20-000005:notes:31]
| Purchase price (cash) |  | $ | 105,645 |  |
| Fair value of contingent consideration (earn-out) |  | 37 |  |
| Fair value of total consideration transferred |  | $ | 105,682 |  |

[0001032975-20-000005:notes:32]
The following table summarizes the preliminary estimated fair values of the assets acquired and liabilities assumed at the Acquisition Date (in thousands):

[0001032975-20-000005:notes:33]
|  |  | Estimated Fair Value |
| Cash and cash equivalents |  | $ | 17,014 |  |
| Intangible assets |  | 37,000 |  |
| Other identifiable liabilities assumed, net |  | (3,635 | ) |
| Net identifiable assets acquired |  | 50,379 |  |
| Contingent consideration (earn-out) |  | (37 | ) |
| Goodwill |  | 55,340 |  |
| Net assets acquired |  | $ | 105,682 |  |

[0001032975-20-000005:notes:34]
Goodwill related to the acquisition is primarily attributable to opportunities and economies of scale from combining the operations and technologies of Logitech and Streamlabs, and is not deductible for tax purposes.

[0001032975-20-000005:notes:35]
The following table summarizes the preliminary estimated fair values and estimated useful lives of the components of identifiable intangible assets acquired as of the Acquisition Date (Dollars in thousands):

[0001032975-20-000005:notes:36]
|  | Preliminary Fair Value |  | Estimated Useful Life (years) |
| Developed technology | $ | 21,800 |  |  | 6.0 |
| Customer relationships | 6,000 |  |  | 2.0 |
| Trade name | 9,200 |  |  | 8.0 |
| Total identifiable intangible assets acquired | $ | 37,000 |  |  | 5.9 |

[0001032975-20-000005:notes:37]
Intangible assets acquired as a result of the Streamlabs Acquisition are being amortized over their estimated useful lives using the straight-line method of amortization, which materially approximates the distribution of the economic value of the identified intangible assets. Amortization of acquired developed technology of $0.6 million during the three months ended December 31, 2019 is included in amortization of intangible assets and purchase accounting effect of inventory in the condensed consolidated statements of operations. Amortization of the acquired customer relationships and trade name of $0.7 million during the three months ended December 31, 2019 is included in amortization of intangible assets and acquisition-related costs in the condensed consolidated statements of operations.

[0001032975-20-000005:notes:38]
Developed technology relates to the software platform which existing Streamlabs services is provided on. The economic useful life was determined based on the technology cycle related to developed technology of the software platform, as well as the cash flows anticipated over the forecasted periods.

[0001032975-20-000005:notes:39]
Customer relationships represent the fair value of future projected revenue that will be derived from sales to existing customers of Streamlabs. The economic useful life was determined based on historical customer turnover rates and industry benchmarks.

[0001032975-20-000005:notes:40]
Trade name relates to the “Streamlabs” trade name. The economic useful life was determined based on the expected life of the trade name and the cash flows anticipated over the forecasted periods.

[0001032975-20-000005:notes:41]
The fair value of developed technology was estimated using the excess earnings method, an income approach (Level 3), which converts projected revenues and costs into cash flows. To reflect the fact that certain other assets contributed to the cash flows generated, the returns for these contributory assets were removed to arrive at estimated cash flows solely attributable to the developed technology, which were discounted at a rate of 25%.

[0001032975-20-000005:notes:42]
The fair value of trade name was estimated using the relief-from-royalty method, an income approach (Level 3), which estimates the cost savings that accrue to the owner of the intangible assets that would otherwise be payable as royalties or license fees on revenues earned through the use of the asset. A royalty rate is applied to the projected revenues associated with the intangible assets to determine the amount of savings, which is then

[0001032975-20-000005:notes:43]
discounted to determine the fair value. Trade name was valued using royalty rate of 5% and was discounted at a rate of 25%.

[0001032975-20-000005:notes:44]
The fair value of customer relationships was estimated primarily using the with and without scenario, a discounted cash flow method (Level 3). Under this method, the Company calculated the present value of the after-tax cash flows expected to be generated by the business with and without the customer relationships using a discount rate of 20%. The without scenario incorporates lost revenue and lost profits over the period necessary to retain the asset.

[0001032975-20-000005:notes:45]
The Company believes the preliminary fair values of acquired intangible assets recorded above represents their fair values and approximates the amounts a market participant would pay for these intangible assets as of the Acquisition Date.

[0001032975-20-000005:notes:46]
The fair value of identifiable intangible assets acquired was based on estimates and assumptions made by management at the time of the acquisition. As additional information becomes available, such as finalization of the estimated fair value of the tangible assets acquired and liabilities assumed, and working capital adjustments that may affect the total consideration transferred, the Company may revise its preliminary estimates of fair values during the remainder of the measurement period (which will not exceed 12 months from the Acquisition Date). Any such revisions or changes may be material as the Company finalizes the fair values of the tangible and intangible assets acquired and liabilities assumed.

[0001032975-20-000005:notes:47]
The Company incurred acquisition-related costs for the Streamlabs Acquisition of approximately $0.8 million and $1.4 million during the three and nine months ended December 31, 2019, respectively. The acquisition-related costs are included in amortization of intangible assets and acquisition-related costs in the condensed consolidated statements of operations.

[0001032975-20-000005:notes:48]
The Company included Streamlabs' estimated fair value of assets acquired and liabilities assumed in its condensed consolidated financial statements beginning on the Acquisition Date. The results of operations for Streamlabs subsequent to the Acquisition Date have been included in, but are not material to, the Company's condensed consolidated statements of operations for the three and nine months ended December 31, 2019. Pro forma results of operations for the Streamlabs Acquisition have not been presented because they are not material to the condensed consolidated statements of operations for the three and nine months ended December 31, 2019. Streamlabs contributed $4.1 million to the net sales for the three and nine months ended December 31, 2019, representing less than one percent of the Company's net sales for each of the respective periods.

[0001032975-20-000005:notes:49]
On October 31, 2019, the Company also made an immaterial technology acquisition for a total cash consideration of $3.6 million, which was accounted for using the acquisition method. The Company retained 10% of the total consideration for the purpose of ensuring seller's representations and warranties.


## us-gaap:EarningsPerShareTextBlock

[0001032975-20-000005:notes:50]
[same as prior period, unchanged from 0001032975-19-000075:notes:24]

[0001032975-20-000005:notes:51]
The following table summarizes the computations of basic and diluted net income per share for the three and nine months ended December 31, 2019 and 2018 (in thousands, except per share amounts):

[0001032975-20-000005:notes:52]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net income |  | $ | 117,525 |  |  | $ | 112,810 |  |  | $ | 235,803 |  |  | $ | 215,452 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 167,063 |  |  | 165,707 |  |  | 166,678 |  |  | 165,552 |  |
| Effect of potentially dilutive equivalent shares |  | 2,622 |  |  | 3,200 |  |  | 2,495 |  |  | 3,414 |  |
| Weighted average shares outstanding - diluted |  | 169,685 |  |  | 168,907 |  |  | 169,173 |  |  | 168,966 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.70 |  |  | $ | 0.68 |  |  | $ | 1.41 |  |  | $ | 1.30 |  |
| Diluted |  | $ | 0.69 |  |  | $ | 0.67 |  |  | $ | 1.39 |  |  | $ | 1.28 |  |

[0001032975-20-000005:notes:53]
Share equivalents attributable to outstanding stock options, restricted stock units ("RSUs"), performance stock units ("PSUs") and employee share purchase plan (ESPP) rights totaling 1.8 million and 1.3 million for the three months ended  December 31, 2019 and 2018, respectively, and 1.8 million  and 1.2 million for the nine months ended December 31, 2019 and 2018, respectively, were excluded from the calculation of diluted net income per share because the combined exercise price and average unamortized grant date fair value upon exercise of these options and ESPP rights or vesting of RSUs were greater than the average market price of the Company's shares during the periods presented herein, and therefore their inclusion would have been anti-dilutive. The majority of performance-based awards were not included because all necessary conditions have not been satisfied by the end of the respective period, and those shares were not issuable if the end of the reporting period was the end of the contingency period.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-20-000005:notes:54]
[same as prior period, unchanged from 0001032975-19-000075:notes:28]

[0001032975-20-000005:notes:55]
[same as prior period, unchanged from 0001032975-19-000075:notes:29]

[0001032975-20-000005:notes:56]
As of December 31, 2019, the Company offers the 2006 Employee Share Purchase Plan (Non-U.S.), as amended and restated (2006 ESPP), the 1996 Employee Share Purchase Plan (U.S.), as amended and restated (1996 ESPP), the 2006 Stock Incentive Plan, as amended and restated (2006 Plan), and the 2012 Stock Inducement Equity Plan (2012 Plan).

[0001032975-20-000005:notes:57]
The following table summarizes the share-based compensation expense and total income tax benefit recognized for share-based awards for the three and nine months ended December 31, 2019 and 2018 (in thousands):

[0001032975-20-000005:notes:58]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Cost of goods sold |  | $ | 1,210 |  |  | $ | 953 |  |  | $ | 3,552 |  |  | $ | 2,874 |  |
| Marketing and selling |  | 6,216 |  |  | 4,600 |  |  | 20,016 |  |  | 15,250 |  |
| Research and development |  | 2,242 |  |  | 1,811 |  |  | 6,644 |  |  | 5,295 |  |
| General and administrative |  | 4,163 |  |  | 4,491 |  |  | 10,089 |  |  | 13,744 |  |
| Total share-based compensation expense |  | 13,831 |  |  | 11,855 |  |  | 40,301 |  |  | 37,163 |  |
| Income tax benefit |  | (3,135 | ) |  | (2,397 | ) |  | (12,658 | ) |  | (14,576 | ) |
| Total share-based compensation expense, net of income tax benefit |  | $ | 10,696 |  |  | $ | 9,458 |  |  | $ | 27,643 |  |  | $ | 22,587 |  |

[0001032975-20-000005:notes:59]
[same as prior period, unchanged from 0001032975-19-000075:notes:33]

[0001032975-20-000005:notes:60]
As of December 31, 2019 and 2018, the balance of capitalized share-based compensation included in inventory was $0.9 million and $0.8 million, respectively.

[0001032975-20-000005:notes:61]
[same as prior period, unchanged from 0001032975-19-000075:notes:35]

[0001032975-20-000005:notes:62]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The costs recorded of $2.3 million and $2.2 million for the three months ended December 31, 2019 and 2018, respectively, and $7.1 million and $6.7 million for the nine months ended December 31, 2019 and 2018, respectively, were primarily related to service costs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-20-000005:notes:63]
[same as prior period, unchanged from 0001032975-19-000075:notes:37]

[0001032975-20-000005:notes:64]
[same as prior period, unchanged from 0001032975-19-000075:notes:38]

[0001032975-20-000005:notes:65]
The income tax provision for the three months ended December 31, 2019 was $14.5 million based on an effective income tax rate of 11.0% of pre-tax income, compared to an income tax provision of $9.3 million based on an effective income tax rate of 7.6% of pre-tax income for the three months ended December 31, 2018. The

[0001032975-20-000005:notes:66]
income tax provision for the nine months ended December 31, 2019 was $18.4 million based on an effective income tax rate of 7.2% of pre-tax income, compared to an income tax provision of $10.3 million based on an effective income tax rate of 4.6% of pre-tax income for the nine months ended December 31, 2018.

[0001032975-20-000005:notes:67]
On May 19, 2019, the Swiss electorate approved the Federal Act on Tax Reform and AHV Financing ("TRAF"), a major reform to better align the Swiss tax system with international tax standards. The legislation was subsequently published in the federal register on August 6, 2019 to take effect on January 1, 2020. As of December 31, 2019, TRAF has not been enacted in all cantons, including the canton of Vaud, as the cantonal legislative procedures are in process. The Company anticipates TRAF to take effect as of January 1, 2020 when enactment occurs in the canton of Vaud.

[0001032975-20-000005:notes:68]
The change in the effective income tax rate for the three and nine months ended December 31, 2019, compared to the same periods ended December 31, 2018, was primarily due to the mix of income and losses in the various tax jurisdictions in which the Company operates and the transitional income tax impact in Switzerland. The Company has benefited from a longstanding tax ruling from the canton of Vaud through December 31, 2019. The transitional income tax impact represents income tax provision at the current full statutory income tax rate of 13.67% without taking account of other elements of the tax reform yet to be enacted. Furthermore, there was a discrete tax benefit of $1.7 million from adjusting deferred tax assets and liabilities in Switzerland in the nine months ended December 31, 2019. There were discrete tax benefits of $6.0 million and $2.7 million from the recognition of net excess tax benefits in the United States and reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the nine-month period ended December 31, 2019, compared with $9.5 million and $2.3 million, respectively, in the nine-month period ended December 31, 2018.

[0001032975-20-000005:notes:69]
As of December 31, 2019 and March 31, 2019, the total amount of unrecognized tax benefits due to uncertain tax positions was $85.0 million and $76.5 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-20-000005:notes:70]
As of December 31, 2019 and March 31, 2019, the Company had $38.2 million and $36.4 million, respectively, in non-current income taxes payable including interest and penalties, related to the Company's income tax liability for uncertain tax positions.

[0001032975-20-000005:notes:71]
The Company recognizes interest and penalties related to unrecognized tax positions in income tax provision. As of December 31, 2019 and March 31, 2019, the Company had $2.7 million and $2.5 million, respectively, of accrued interest and penalties related to uncertain tax positions.

[0001032975-20-000005:notes:72]
Although the Company has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During fiscal year 2020, the Company continues to review its tax positions and provide for or reverse unrecognized tax benefits as they arise. During the next twelve months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. dollar as compared to other currencies. Excluding these factors, uncertain tax positions may decrease by as much as $4.1 million from the lapse of the statutes of limitations in various jurisdictions during the next twelve months.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-20-000005:notes:73]
[same as prior period, unchanged from 0001032975-19-000075:notes:50]

[0001032975-20-000005:notes:74]
The following table presents the components of certain balance sheet asset amounts as of December 31 and March 31, 2019 (in thousands):

[0001032975-20-000005:notes:75]
|  |  | December 31, 2019 |  | March 31, 2019 |
| Accounts receivable, net: |  |  |  |  |  |  |
| Accounts receivable |  | $ | 797,562 |  |  | $ | 573,348 |  |
| Allowance for doubtful accounts |  | (2,395 | ) |  | (84 | ) |
| Allowance for sales returns |  | (8,308 | ) |  | (6,486 | ) |
| Allowance for cooperative marketing arrangements |  | (53,400 | ) |  | (35,080 | ) |
| Allowance for customer incentive programs |  | (91,906 | ) |  | (60,036 | ) |
| Allowance for pricing programs |  | (110,244 | ) |  | (88,353 | ) |
|  |  | $ | 531,309 |  |  | $ | 383,309 |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 31,103 |  |  | $ | 40,970 |  |
| Finished goods |  | 276,391 |  |  | 252,525 |  |
|  |  | $ | 307,494 |  |  | $ | 293,495 |  |
| Other current assets: |  |  |  |  |  |  |
| Value-added tax receivables |  | $ | 36,581 |  |  | $ | 34,321 |  |
| Prepaid expenses and other assets |  | 41,958 |  |  | 34,795 |  |
|  |  | $ | 78,539 |  |  | $ | 69,116 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |
| Property, plant and equipment at cost |  | $ | 356,261 |  |  | $ | 359,345 |  |
| Accumulated depreciation and amortization |  | (280,182 | ) |  | (280,793 | ) |
|  |  | $ | 76,079 |  |  | $ | 78,552 |  |
| Other assets: |  |  |  |  |  |  |
| Deferred tax assets |  | $ | 86,058 |  |  | $ | 90,808 |  |
| Right-of-use assets (1) |  | 27,670 |  |  | — |  |
| Trading investments for deferred compensation plan |  | 23,796 |  |  | 20,363 |  |
| Investments in privately held companies |  | 16,502 |  |  | 16,022 |  |
| Other assets |  | 6,215 |  |  | 5,260 |  |
|  |  | $ | 160,241 |  |  | $ | 132,453 |  |

[0001032975-20-000005:notes:76]
[same as prior period, unchanged from 0001032975-19-000075:notes:53]

[0001032975-20-000005:notes:77]
The following table presents the components of certain balance sheet liability amounts as of December 31 and March 31, 2019 (in thousands):

[0001032975-20-000005:notes:78]
|  |  | December 31, 2019 |  | March 31, 2019 |
| Accrued and other current liabilities: |  |  |  |  |  |  |
| Accrued personnel expenses |  | $ | 83,902 |  |  | $ | 103,166 |  |
| Accrued sales return liability |  | 33,242 |  |  | 37,749 |  |
| Accrued customer marketing, pricing and incentive programs |  | 165,863 |  |  | 143,888 |  |
| Operating lease liability (1) |  | 11,304 |  |  | — |  |
| Warranty accrual |  | 25,743 |  |  | 21,524 |  |
| Income taxes payable |  | 4,307 |  |  | 6,207 |  |
| Other current liabilities |  | 129,572 |  |  | 121,363 |  |
|  |  | $ | 453,933 |  |  | $ | 433,897 |  |
| Other non-current liabilities: |  |  |  |  |  |  |
| Warranty accrual |  | $ | 14,434 |  |  | $ | 12,705 |  |
| Obligation for deferred compensation plan |  | 23,796 |  |  | 20,363 |  |
| Employee benefit plan obligation |  | 52,471 |  |  | 51,448 |  |
| Operating lease liability (1) |  | 21,744 |  |  | — |  |
| Deferred tax liability |  | 2,050 |  |  | 2,050 |  |
| Other non-current liabilities |  | 2,972 |  |  | 7,016 |  |
|  |  | $ | 117,467 |  |  | $ | 93,582 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-20-000005:notes:79]
[same as prior period, unchanged from 0001032975-19-000075:notes:56]

[0001032975-20-000005:notes:80]
[same as prior period, unchanged from 0001032975-19-000075:notes:57]

[0001032975-20-000005:notes:81]
[same as prior period, unchanged from 0001032975-19-000075:notes:58]

[0001032975-20-000005:notes:82]
[same as prior period, unchanged from 0001032975-19-000075:notes:59]

[0001032975-20-000005:notes:83]
[same as prior period, unchanged from 0001032975-19-000075:notes:60]

[0001032975-20-000005:notes:84]
[same as prior period, unchanged from 0001032975-19-000075:notes:61]

[0001032975-20-000005:notes:85]
|  |  | December 31, 2019 |  | March 31, 2019 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 528,446 |  |  | $ | — |  |  | $ | — |  |  | $ | 496,434 |  |  | $ | — |  |  | $ | — |  |
| Trading investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | 4,460 |  |  | — |  |  | — |  |  | 4,080 |  |  | — |  |  | — |  |
| Mutual funds |  | 19,336 |  |  | — |  |  | — |  |  | 16,283 |  |  | — |  |  | — |  |
| Total of trading investments for deferred compensation plan |  | $ | 23,796 |  |  | $ | — |  |  | $ | — |  |  | $ | 20,363 |  |  | $ | — |  |  | $ | — |  |
| Currency exchange derivative assetsincluded in other current assets |  | $ | — |  |  | $ | 118 |  |  | $ | — |  |  | $ | — |  |  | $ | 455 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration for business acquisition included in accrued and other current liabilities (Note 2) |  | $ | — |  |  | $ | — |  |  | $ | 37 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Currency exchange derivative liabilitiesincluded in accrued and other current liabilities |  | $ | — |  |  | $ | 695 |  |  | $ | — |  |  | $ | — |  |  | $ | 36 |  |  | $ | — |  |

[0001032975-20-000005:notes:86]
[same as prior period, unchanged from 0001032975-19-000075:notes:63]

[0001032975-20-000005:notes:87]
The marketable securities for the Company's deferred compensation plan were recorded at a fair value of $23.8 million and $20.4 million as of December 31, 2019 and March 31, 2019, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized gains (losses) related to trading securities for the three and nine months ended December 31, 2019 and 2018 were not material and are included in other income (expense), net in the Company's condensed consolidated statements of operations.

[0001032975-20-000005:notes:88]
Contingent Consideration for Business Acquisition

[0001032975-20-000005:notes:89]
The contingent consideration for business acquisition arising from the Streamlabs Acquisition (see "Note 2 - Business Acquisition" to the condensed consolidated financial statements for more information) represents the future potential earn-out payments of $29.0 million payable in stock only upon the achievement of net revenues for the period beginning on January 1, 2020 and ending on June 30, 2020. The fair value of the earn-out as of the Acquisition Date was $0.04 million which was determined by using a Black-Scholes-Merton option-pricing valuation model that includes significant assumptions and unobservable inputs such as the projected revenues of Streamlabs over the earn-out period and the probability of the earn-out threshold being met.  Actual results that differ from the assumptions used and any changes to the significant assumptions and unobservable inputs used could have a material impact on future results of operations. Actual payment of contingent consideration in the future could be different from the current fair value of the contingent consideration. The fair value of the contingent consideration is remeasured at each reporting period based on the inputs on the date of remeasurement. The fair value of the earn-out was $0.04 million as of December 31, 2019.

[0001032975-20-000005:notes:90]
[same as prior period, unchanged from 0001032975-19-000075:notes:65]

[0001032975-20-000005:notes:91]
The Company has certain non-marketable investments included in other assets in the Company's condensed consolidated balance sheets that are accounted for under the equity method of accounting, with a carrying value of $7.0 million and $6.6 million as of December 31, 2019 and March 31, 2019, respectively.

[0001032975-20-000005:notes:92]
[same as prior period, unchanged from 0001032975-19-000075:notes:67]

[0001032975-20-000005:notes:93]
Financial Assets.  The Company has certain investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with a same or similar security from the same issuer. The amount of these investments included in other assets as of December 31, 2019 and March 31, 2019 was $9.5 million. There was no impairment of these assets during the three and nine months ended December 31, 2019 or 2018.

[0001032975-20-000005:notes:94]
Non-Financial Assets. The Company’s non-financial assets, such as intangible assets and property, plant and equipment, are recorded at fair value only upon initial recognition or if an impairment is recognized. There was no impairment of these assets during the three and nine months ended December 31, 2019 or 2018.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-20-000005:notes:95]
[same as prior period, unchanged from 0001032975-19-000075:notes:70]

[0001032975-20-000005:notes:96]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis on the condensed consolidated balance sheets as of December 31, 2019 and March 31, 2019.

[0001032975-20-000005:notes:97]
The fair value of the Company’s derivative instruments was not material as of December 31, 2019 or March 31, 2019. The amount of gain (loss) recognized on derivatives not designated as hedging instruments was not material in all periods presented herein. The following table presents the amounts of gains (losses) on the Company’s derivative instruments designated as hedging instruments and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income for the three and nine months ended December 31, 2019 and 2018 (in thousands):

[0001032975-20-000005:notes:98]
|  |  | Three Months EndedDecember 31, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Cash flow hedges |  | $ | (1,381 | ) |  | $ | 575 |  |  | $ | (739 | ) |  | $ | (615 | ) |

[0001032975-20-000005:notes:99]
|  |  | Nine Months EndedDecember 31, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Cash flow hedges |  | $ | 56 |  |  | $ | 1,060 |  |  | $ | (1,097 | ) |  | $ | 2,454 |  |

[0001032975-20-000005:notes:100]
[same as prior period, unchanged from 0001032975-19-000075:notes:75]

[0001032975-20-000005:notes:101]
The Company enters into cash flow hedge contracts to protect against exchange rate exposure of forecasted inventory purchases. These hedging contracts mature within four months. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Cash flows from such hedges are classified as operating activities in the condensed consolidated statements of cash flows. Hedging relationships are discontinued when the hedging contract is no longer eligible for hedge accounting, or is sold, terminated or exercised, or when the Company removes hedge designation for the contract. Gains and losses in the fair value of the effective portion of the discontinued hedges continue to be reported in accumulated other comprehensive loss until the hedged inventory purchases are sold, unless it is probable that the forecasted inventory purchases will not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. In all periods presented herein, there have been no forecasted inventory purchases that were probable to not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. The notional amounts of foreign currency exchange forward contracts outstanding related to forecasted inventory purchases were $69.5 million as of December 31, 2019 and $41.4 million as of March 31, 2019. The Company had $0.7 million of net losses related to its cash flow hedges included in accumulated other comprehensive loss as of December 31, 2019 which will be reclassified into earnings within the next 12 months.

[0001032975-20-000005:notes:102]
[same as prior period, unchanged from 0001032975-19-000075:notes:77]

[0001032975-20-000005:notes:103]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are recognized in other income (expense), net in the condensed consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of December 31, 2019 and March 31, 2019 were $71.0 million and $50.4 million, respectively. Open forward and swap contracts outstanding as of December 31, 2019 and March 31, 2019 consisted of contracts in Mexican Pesos, Japanese Yen, Canadian Dollars, Taiwan New Dollars and Australian Dollars to be settled at future dates at pre-determined exchange rates.

[0001032975-20-000005:notes:104]
[same as prior period, unchanged from 0001032975-19-000075:notes:80]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-20-000005:notes:105]
[same as prior period, unchanged from 0001032975-19-000075:notes:81]

[0001032975-20-000005:notes:106]
The Company conducts its impairment analysis of goodwill annually at December 31 and as necessary, if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s sole reporting unit may be less than its carrying amount. The Company conducted its annual impairment analysis of goodwill as of December 31, 2019 by performing a qualitative assessment and concluded that it was more likely than not that the fair value of its reporting unit exceeds its carrying amount. In assessing the qualitative factors, the Company considered the impact of change in industry and competitive environment, growth in the Company's market capitalization and budgeted-to-actual revenue performance for the last twelve months.

[0001032975-20-000005:notes:107]
The following table summarizes the activities in the Company’s goodwill balance during the nine months ended December 31, 2019 (in thousands):

[0001032975-20-000005:notes:108]
| As of March 31, 2019 |  | $ | 343,684 |  |
| Acquisitions (1) |  | 57,140 |  |
| Currency translation |  | 18 |  |
| As of December 31, 2019 |  | $ | 400,842 |  |

[0001032975-20-000005:notes:109]
(1) Includes goodwill acquired from the Streamlabs Acquisition and the immaterial technology acquisition in October 2019. See Note 2 for more information.

[0001032975-20-000005:notes:110]
[same as prior period, unchanged from 0001032975-19-000075:notes:85]

[0001032975-20-000005:notes:111]
|  |  | December 31, 2019 |  | March 31, 2019 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademark and trade names |  | $ | 45,570 |  |  | $ | (17,543 | ) |  | $ | 28,027 |  |  | $ | 36,370 |  |  | $ | (13,659 | ) |  | $ | 22,711 |  |
| Developed technology |  | 118,807 |  |  | (72,834 | ) |  | 45,973 |  |  | 95,207 |  |  | (62,341 | ) |  | 32,866 |  |
| Customer contracts/relationships |  | 90,610 |  |  | (28,769 | ) |  | 61,841 |  |  | 84,610 |  |  | (21,188 | ) |  | 63,422 |  |
| Total |  | $ | 254,987 |  |  | $ | (119,146 | ) |  | $ | 135,841 |  |  | $ | 216,187 |  |  | $ | (97,188 | ) |  | $ | 118,999 |  |


## us-gaap:DebtDisclosureTextBlock

[0001032975-20-000005:notes:112]
Financing Arrangements

[0001032975-20-000005:notes:113]
The Company had several uncommitted, unsecured bank lines of credit aggregating $78.4 million as of December 31, 2019. There are no financial covenants under these lines of credit with which the Company must comply. As of December 31, 2019, the Company had outstanding bank guarantees of $17.1 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of December 31, 2019 or March 31, 2019.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-20-000005:notes:114]
Commitments and Contingencies

[0001032975-20-000005:notes:115]
Product Warranties

[0001032975-20-000005:notes:116]
Changes in the Company’s warranty liability for the three and nine months ended December 31, 2019 and 2018 were as follows (in thousands):

[0001032975-20-000005:notes:117]
|  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Beginning of the period | $ | 37,222 |  |  | $ | 31,754 |  |  | $ | 34,229 |  |  | $ | 27,573 |  |
| Assumed from business acquisition | — |  |  | — |  |  | — |  |  | 351 |  |
| Provision | 9,608 |  |  | 11,305 |  |  | 26,652 |  |  | 30,625 |  |
| Settlements | (6,840 | ) |  | (7,523 | ) |  | (20,544 | ) |  | (22,405 | ) |
| Currency translation | 187 |  |  | (61 | ) |  | (160 | ) |  | (669 | ) |
| End of the period | $ | 40,177 |  |  | $ | 35,475 |  |  | $ | 40,177 |  |  | $ | 35,475 |  |

[0001032975-20-000005:notes:118]
Indemnifications

[0001032975-20-000005:notes:119]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2019, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-20-000005:notes:120]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-20-000005:notes:121]
Legal Proceedings

[0001032975-20-000005:notes:122]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-20-000005:notes:123]
[same as prior period, unchanged from 0001032975-19-000075:notes:101]

[0001032975-20-000005:notes:124]
[same as prior period, unchanged from 0001032975-19-000075:notes:102]

[0001032975-20-000005:notes:125]
In March 2017, the Company's Board of Directors approved the 2017 share buyback program, which authorizes the Company to use up to $250.0 million to purchase up to 17.3 million shares of its own shares. The Company's share buyback program is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. As of December 31, 2019, $172.4 million is still available for repurchase under the 2017 buyback program.

[0001032975-20-000005:notes:126]
[same as prior period, unchanged from 0001032975-19-000075:notes:104]

[0001032975-20-000005:notes:127]
During the nine months ended December 31, 2019, the Company declared and paid cash dividends of CHF 0.73 (USD equivalent of $0.74) per share, totaling $124.2 million on the Company's outstanding shares. During the nine months ended December 31, 2018, the Company declared and paid cash dividends of CHF 0.67 (USD equivalent of $0.69) per share, totaling $114.0 million on the Company's outstanding shares.

[0001032975-20-000005:notes:128]
[same as prior period, unchanged from 0001032975-19-000075:notes:106]

[0001032975-20-000005:notes:129]
[same as prior period, unchanged from 0001032975-19-000075:notes:107]

[0001032975-20-000005:notes:130]
[same as prior period, unchanged from 0001032975-19-000075:notes:108]

[0001032975-20-000005:notes:131]
|  |  | Accumulated Other Comprehensive Income (Loss) |
|  |  | CumulativeTranslationAdjustment (1) |  | DefinedBenefitPlan (1) |  | Deferred Hedging Losses (1) |  | Total |
| March 31, 2019 |  | $ | (92,148 | ) |  | $ | (13,932 | ) |  | $ | 382 |  |  | $ | (105,698 | ) |
| Other comprehensive income (loss) |  | (2,639 | ) |  | (114 | ) |  | (1,041 | ) |  | (3,794 | ) |
| December 31, 2019 |  | $ | (94,787 | ) |  | $ | (14,046 | ) |  | $ | (659 | ) |  | $ | (109,492 | ) |

[0001032975-20-000005:notes:132]
(1)        Tax effect was not significant as of December 31 or March 31, 2019.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-20-000005:notes:133]
[same as prior period, unchanged from 0001032975-19-000075:notes:111]

[0001032975-20-000005:notes:134]
[same as prior period, unchanged from 0001032975-19-000075:notes:112]

[0001032975-20-000005:notes:135]
Sales by product categories and sales channels, excluding intercompany transactions, for the three and nine months ended December 31, 2019 and 2018 were as follows (in thousands):

[0001032975-20-000005:notes:136]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Pointing Devices |  | $ | 154,540 |  |  | $ | 149,123 |  |  | $ | 409,293 |  |  | $ | 405,250 |  |
| Keyboards & Combos |  | 156,333 |  |  | 144,169 |  |  | 424,061 |  |  | 404,263 |  |
| PC Webcams |  | 32,165 |  |  | 33,021 |  |  | 89,041 |  |  | 90,916 |  |
| Tablet & Other Accessories |  | 31,256 |  |  | 35,757 |  |  | 103,442 |  |  | 104,903 |  |
| Video Collaboration |  | 91,964 |  |  | 74,186 |  |  | 254,941 |  |  | 190,154 |  |
| Mobile Speakers |  | 92,969 |  |  | 96,263 |  |  | 200,617 |  |  | 207,690 |  |
| Audio & Wearables |  | 81,934 |  |  | 98,629 |  |  | 208,576 |  |  | 212,343 |  |
| Gaming |  | 245,736 |  |  | 213,663 |  |  | 541,265 |  |  | 510,481 |  |
| Smart Home |  | 15,790 |  |  | 19,577 |  |  | 35,088 |  |  | 37,829 |  |
| Other (1) |  | — |  |  | — |  |  | 279 |  |  | 185 |  |
| Total sales |  | $ | 902,687 |  |  | $ | 864,388 |  |  | $ | 2,266,603 |  |  | $ | 2,164,014 |  |

[0001032975-20-000005:notes:137]
[same as prior period, unchanged from 0001032975-19-000075:notes:115]

[0001032975-20-000005:notes:138]
Sales by geographic region (based on the customers’ locations) for the three and nine months ended December 31, 2019 and 2018 were as follows (in thousands):

[0001032975-20-000005:notes:139]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Americas |  | $ | 380,493 |  |  | $ | 385,598 |  |  | $ | 970,775 |  |  | $ | 946,240 |  |
| EMEA |  | 308,907 |  |  | 269,082 |  |  | 719,994 |  |  | 648,014 |  |
| Asia Pacific |  | 213,287 |  |  | 209,708 |  |  | 575,834 |  |  | 569,760 |  |
| Total sales |  | $ | 902,687 |  |  | $ | 864,388 |  |  | $ | 2,266,603 |  |  | $ | 2,164,014 |  |

[0001032975-20-000005:notes:140]
[same as prior period, unchanged from 0001032975-19-000075:notes:118]

[0001032975-20-000005:notes:141]
The United States and Germany each represented more than 10% of the total consolidated sales for each of the periods presented herein. China represented more than 10% of the total consolidated sales for the nine months ended December 31, 2019 and 2018. No other countries represented 10% or more of the Company’s total consolidated sales for the periods presented herein.

[0001032975-20-000005:notes:142]
Switzerland, the Company’s home domicile, represented 4% of the Company's total consolidated sales for the three and nine months ended December 31, 2019, respectively, and represented 3% of the Company's total consolidated sales for the three and nine months ended December 31, 2018, respectively.

[0001032975-20-000005:notes:143]
[same as prior period, unchanged from 0001032975-19-000075:notes:121]

[0001032975-20-000005:notes:144]
[same as prior period, unchanged from 0001032975-19-000075:notes:122]

[0001032975-20-000005:notes:145]
|  |  | December 31, 2019 |  | March 31, 2019 |
| Americas |  | $ | 26,837 |  |  | $ | 29,813 |  |
| EMEA |  | 4,451 |  |  | 4,537 |  |
| Asia Pacific |  | 44,791 |  |  | 44,202 |  |
| Total property, plant and equipment, net |  | $ | 76,079 |  |  | $ | 78,552 |  |

[0001032975-20-000005:notes:146]
Property, plant and equipment, net in the United States and China were $26.7 million and $37.0 million, respectively, as of December 31, 2019, and $29.8 million and $36.4 million, respectively, as of March 31, 2019. No other countries represented 10% or more of the Company’s total consolidated property, plant and equipment, net as of December 31, 2019 and March 31, 2019. Property, plant and equipment, net in Switzerland, the Company’s home domicile, were $1.6 million and $1.7 million as of December 31, 2019 and March 31, 2019, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001032975-20-000005:notes:147]
[same as prior period, unchanged from 0001032975-19-000075:notes:125]

[0001032975-20-000005:notes:148]
During the first quarter of fiscal year 2019, the Company implemented a restructuring plan to streamline and realign the Company's overall organizational structure and reallocate resources to support long-term growth opportunities. In July 2018, the Company's Board of Directors approved additional costs under this restructuring plan, totaling pre-tax charges of approximately $10.0 million to $15.0 million, of which $11.4 million has been recognized cumulatively as of December 31, 2019. The total charges consisted of cash severance and other personnel costs and are presented as restructuring charges (credit), net in the condensed consolidated statements of operations, and the accrual balances are presented in accrued and other current liabilities in the condensed consolidated balance sheets. During the first quarter of fiscal year 2020, the Company had substantially completed this restructuring plan.

[0001032975-20-000005:notes:149]
The following table summarizes restructuring-related activities during the three and nine months ended December 31, 2019 (in thousands):

[0001032975-20-000005:notes:150]
|  |  | TerminationBenefits |
| Accrual balance at March 31, 2019 |  | $ | 4,389 |  |
| Charges |  | 478 |  |
| Cash payments |  | (1,956 | ) |
| Accrual balance at June 30, 2019 |  | 2,911 |  |
| Credits |  | (364 | ) |
| Cash payments |  | (1,140 | ) |
| Accrual balance at September 30, 2019 |  | 1,407 |  |
| Credits |  | (45 | ) |
| Cash payments |  | (308 | ) |
| Accrual balance at December 31, 2019 |  | $ | 1,054 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001032975-20-000005:notes:151]
[same as prior period, unchanged from 0001032975-19-000075:notes:129]

[0001032975-20-000005:notes:152]
[same as prior period, unchanged from 0001032975-19-000075:notes:130]

[0001032975-20-000005:notes:153]
[same as prior period, unchanged from 0001032975-19-000075:notes:131]

[0001032975-20-000005:notes:154]
[same as prior period, unchanged from 0001032975-19-000075:notes:132]

[0001032975-20-000005:notes:155]
[same as prior period, unchanged from 0001032975-19-000075:notes:133]

[0001032975-20-000005:notes:156]
For the three and nine months ended December 31, 2019, the total operating lease costs were $3.4 million and $10.3 million, respectively, which included short-term lease costs and sublease income. Total variable lease costs were immaterial during the three and nine months ended December 31, 2019. The total operating and variable lease costs were included in cost of goods sold, marketing and selling, research and development, and general and administrative in the Company's unaudited condensed consolidated statement of operations.

[0001032975-20-000005:notes:157]
As of December 31, 2019, the weighted-average remaining lease term was 3.9 years, and the weighted-average discount rate was 2.9%.

[0001032975-20-000005:notes:158]
For the three and nine months ended December 31, 2019, cash paid for amounts included in the measurement of operating lease liabilities was $3.5 million and $9.9 million, respectively, and right-of-use assets obtained in exchange for new operating lease liabilities was $0.1 million and $5.0 million, respectively.

[0001032975-20-000005:notes:159]
Future lease payments included in the measurement of lease liabilities as of December 31, 2019 for the following five fiscal years and thereafter are as follows (in thousands):

[0001032975-20-000005:notes:160]
|  | Operating Lease |
| Remaining 2020 | $ | 3,475 |  |
| 2021 | 11,470 |  |
| 2022 | 9,349 |  |
| 2023 | 5,688 |  |
| 2024 | 1,384 |  |
| Thereafter | 4,149 |  |
| Total lease payments | 35,515 |  |
| Less interest | (2,467 | ) |
| Present value of lease liabilities | $ | 33,048 |  |

[0001032975-20-000005:notes:161]
[same as prior period, unchanged from 0001032975-19-000075:notes:139]

[0001032975-20-000005:notes:162]
[same as prior period, unchanged from 0001032975-19-000075:notes:140]
