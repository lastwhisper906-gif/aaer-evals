# LOGI note change history — 0001032975-19-000075 → 0001032975-20-000005


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-01-23):
[0001032975-20-000005:note_history:1]
Changes in the Company’s warranty liability for the three and nine months ended December 31, 2019 and 2018 were as follows (in thousands):
  (was, 2019-10-24, similarity 0.9615):
[0001032975-19-000075:note_history:1]
Changes in the Company’s warranty liability for the three and six months ended September 30, 2019 and 2018 were as follows (in thousands):

- changed (2020-01-23):
[0001032975-20-000005:note_history:2]
|  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Beginning of the period | $ | 37,222 |  |  | $ | 31,754 |  |  | $ | 34,229 |  |  | $ | 27,573 |  |
| Assumed from business acquisition | — |  |  | — |  |  | — |  |  | 351 |  |
| Provision | 9,608 |  |  | 11,305 |  |  | 26,652 |  |  | 30,625 |  |
| Settlements | (6,840 | ) |  | (7,523 | ) |  | (20,544 | ) |  | (22,405 | ) |
| Currency translation | 187 |  |  | (61 | ) |  | (160 | ) |  | (669 | ) |
| End of the period | $ | 40,177 |  |  | $ | 35,475 |  |  | $ | 40,177 |  |  | $ | 35,475 |  |
  (was, 2019-10-24, similarity 0.966):
[0001032975-19-000075:note_history:2]
|  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Beginning of the period | $ | 35,814 |  |  | $ | 28,853 |  |  | $ | 34,229 |  |  | $ | 27,573 |  |
| Assumed from business acquisition | — |  |  | 351 |  |  | — |  |  | 351 |  |
| Provision | 8,509 |  |  | 11,020 |  |  | 17,044 |  |  | 19,320 |  |
| Settlements | (6,727 | ) |  | (8,330 | ) |  | (13,704 | ) |  | (14,882 | ) |
| Currency translation | (374 | ) |  | (140 | ) |  | (347 | ) |  | (608 | ) |
| End of the period | $ | 37,222 |  |  | $ | 31,754 |  |  | $ | 37,222 |  |  | $ | 31,754 |  |

- changed (2020-01-23):
[0001032975-20-000005:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2019, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2019-10-24, similarity 0.9946):
[0001032975-19-000075:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2019, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

- removed (2020-01-23):
[0001032975-19-000075:note_history:4]
Pending Acquisition

- removed (2020-01-23):
[0001032975-19-000075:note_history:5]
On September 26, 2019, the Company entered into an agreement to acquire all equity interests of General Workings, Inc. ("Streamlabs") for a total consideration of $89 million in cash, subject to a working capital adjustment, plus an additional earn-out of up to $29 million in stock based on the achievement of certain net revenues for the period beginning on January 1, 2020 and ending on June 30, 2020 (the "Streamlabs Acquisition"). Streamlabs is a leading provider of software and tools for professional streamers. The Streamlabs Acquisition will supplement the Company's portfolio opportunities.

- removed (2020-01-23):
[0001032975-19-000075:note_history:6]
The transaction is subject to various closing conditions and is expected to close in late October 2019.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2020-01-23):
[0001032975-20-000005:note_history:7]
Business Acquisition

- added (2020-01-23):
[0001032975-20-000005:note_history:8]
On October 31, 2019, the Company acquired General Workings, Inc. See "Note 2 - Business Acquisition" for more information.

- changed (2020-01-23):
[0001032975-20-000005:note_history:9]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and nine months ended December 31, 2019 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2020, or any future periods.
  (was, 2019-10-24, similarity 0.9623):
[0001032975-19-000075:note_history:9]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and six months ended September 30, 2019 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2020, or any future periods.

- changed (2020-01-23):
[0001032975-20-000005:note_history:10]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted and Summary of Significant Accounting Policies, there have been no changes in the Company’s significant accounting policies during the nine months ended December 31, 2019 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2019.
  (was, 2019-10-24, similarity 0.9496):
[0001032975-19-000075:note_history:10]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted and Summary of Significant Accounting Policies, there have been no changes in the Company’s significant accounting policies during the six months ended September 30, 2019 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2019.

- added (2020-01-23):
[0001032975-20-000005:note_history:11]
The preparation of financial statements in conformity with GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements.

- changed (2020-01-23):
[0001032975-20-000005:note_history:12]
Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill, intangible assets acquired from business acquisitions, contingent consideration for a business acquisition and periodic reassessment of its fair value, valuation of operating right-of-use assets, warranty liabilities, accruals for customer incentives, cooperative marketing, and pricing programs (Customer Programs) and related breakage when appropriate, accrued sales return liability, allowance for doubtful accounts, inventory valuation, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from these estimates.
  (was, 2019-10-24, similarity 0.6391):
[0001032975-19-000075:note_history:12]
The preparation of financial statements in conformity with GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill, intangible assets acquired from business acquisitions, valuation of operating right-of-use assets, warranty liabilities, accruals for customer incentives, cooperative marketing, and pricing programs (Customer Programs) and related breakage when appropriate, accrued sales return liability, allowance for doubtful accounts, inventory valuation,

- changed (2020-01-23):
[0001032975-20-000005:note_history:13]
Adoption of the standard resulted in the recognition of $31.3 million of ROU assets and $37.4 million of lease liabilities related to the Company's leases on its condensed consolidated balance sheet on April 1, 2019. The difference of $6.1 million represented deferred rent for leases that existed as of the date of adoption, which decreased the opening balance of ROU assets. In addition, the prepaid rent balance as of the date of adoption increased the opening balance of ROU assets. The deferred rent and prepaid rent balances were derecognized as of the date of adoption and no adjustment was made to retained earnings. The adoption of the standard did not have an impact on the Company's condensed consolidated statement of operations, comprehensive income, changes in shareholders' equity or cash flows.
  (was, 2019-10-24, similarity 0.9899):
[0001032975-19-000075:note_history:13]
Adoption of the standard resulted in the recognition of $31.3 million of ROU assets and $37.4 million of lease liabilities related to the Company's leases on its condensed consolidated balance sheet on April 1, 2019. The difference of $6.1 million represented deferred rent for leases that existed as of the date of adoption, which decreased the opening balance of ROU assets. In addition, the prepaid rent balance as of the date of adoption increased the opening balance of ROU assets. The deferred rent and prepaid rent balances were derecognized as of the date of adoption and no adjustment was made to retained earnings. The adoption of the standard did not have an impact on our condensed consolidated statement of operations, comprehensive income, changes in shareholders' equity or cash flows.

- changed (2020-01-23):
[0001032975-20-000005:note_history:14]
In June 2016, the FASB issued ASU 2016-13, "Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments" (ASU 2016-13), which was further updated and clarified by the FASB through issuance of additional related ASUs, replaces the incurred-loss impairment methodology and requires immediate recognition of estimated credit losses expected to occur for most financial assets, including trade receivables. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not expect the adoption of ASU 2016-13 will have a material impact on its consolidated financial statements and plans to adopt the standard effective April 1, 2020.
  (was, 2019-10-24, similarity 0.9361):
[0001032975-19-000075:note_history:14]
In June 2016, the FASB issued ASU 2016-13, "Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments" (ASU 2016-13), which replaces the incurred-loss impairment methodology and requires immediate recognition of estimated credit losses expected to occur for most financial assets, including trade receivables. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not expect the adoption of ASU 2016-13 will have a material impact on its consolidated financial statements and plans to adopt the standard effective April 1, 2020.

- changed (2020-01-23):
[0001032975-20-000005:note_history:15]
In August 2018, the FASB issued ASU 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirements for Fair Value Measurements" (ASU 2018-13), which aims to improve the overall usefulness of disclosures to financial statement users and reduce unnecessary costs to companies when preparing fair value measurement disclosures. ASU 2018-13 is effective for annual and interim periods in fiscal years beginning after December 15, 2019. Early adoption is permitted. Retrospective adoption is required, except for certain disclosures which will be required to be applied prospectively for only the most recent interim or annual period presented in the initial fiscal year of adoption. The Company does not expect the adoption of ASU 2018-13 will have a material impact on its consolidated financial statements and plans to adopt the standard effective April 1, 2020.
  (was, 2019-10-24, similarity 0.9254):
[0001032975-19-000075:note_history:15]
In August 2018, the FASB issued ASU 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirements for Fair Value Measurements" (ASU 2018-13), which aims to improve the overall usefulness of disclosures to financial statement users and reduce unnecessary costs to companies when preparing fair value measurement disclosures. ASU 2018-13 is effective for annual and interim periods in fiscal years beginning after December 15, 2019. Early adoption is permitted. Retrospective adoption is required, except for certain disclosures which will be required to be applied prospectively for only the most recent interim or annual period presented in the initial fiscal year of adoption. The Company does not expect the adoption of ASU 2018-13

- added (2020-01-23):
[0001032975-20-000005:note_history:16]
In December 2019, the FASB issued ASU 2019-12, "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes" (ASU 2019-12), which eliminates certain exceptions for recognizing deferred taxes for investments, performing intraperiod allocation and calculating income taxes in interim periods. This ASU also includes guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. ASU 2019-12 is effective for annual and interim periods in fiscal years beginning after December 15, 2020. Early adoption is permitted. The Company is currently assessing the impact of ASU 2019-12 on its consolidated financial statements and plans to adopt the standard effective April 1, 2021.

- removed (2020-01-23):
[0001032975-19-000075:note_history:17]
share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from these estimates.

- removed (2020-01-23):
[0001032975-19-000075:note_history:18]
will have a material impact on its consolidated financial statements and plans to adopt the standard effective April 1, 2020.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-01-23):
[0001032975-20-000005:note_history:19]
The Company had several uncommitted, unsecured bank lines of credit aggregating $78.4 million as of December 31, 2019. There are no financial covenants under these lines of credit with which the Company must comply. As of December 31, 2019, the Company had outstanding bank guarantees of $17.1 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of December 31, 2019 or March 31, 2019.
  (was, 2019-10-24, similarity 0.9204):
[0001032975-19-000075:note_history:19]
The Company had several uncommitted, unsecured bank lines of credit aggregating $77.5 million as of September 30, 2019. There are no financial covenants under these lines of credit with which the Company must comply. As of September 30, 2019, the Company had outstanding bank guarantees of $20.6 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of September 30, 2019 or March 31, 2019.
