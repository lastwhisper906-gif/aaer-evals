# LOGI 8-K — 0001032975-20-000002 filed 2020-01-21

## item codes, every 8-K on or before 2020-01-23

- 2020-01-21 0001032975-20-000002 — 2.02, 9.01
- 2019-10-22 0001032975-19-000071 — 9.01
- 2019-09-26 0001032975-19-000068 — 1.01, 7.01, 9.01
- 2019-09-06 0001032975-19-000063 — 5.07, 8.01
- 2019-07-23 0001032975-19-000046 — 2.02, 9.01
- 2019-07-23 0001032975-19-000045 — 5.02, 9.01
- 2019-07-02 0001032975-19-000036 — 5.02
- 2019-06-25 0001032975-19-000034 — 5.02
- 2019-05-03 0001032975-19-000021 — 5.02 — amendment, the index does not say of what
- 2019-04-30 0001032975-19-000017 — 2.02, 5.02, 9.01
- 2019-03-28 0001032975-19-000013 — 5.02
- 2019-01-22 0001032975-19-000004 — 2.02, 9.01
- 2018-10-23 0001032975-18-000044 — 2.02, 9.01
- 2018-09-07 0001032975-18-000040 — 5.07, 8.01
- 2018-07-31 0001032975-18-000035 — 1.01, 2.02, 2.05, 7.01, 9.01
- 2018-06-27 0001032975-18-000020 — 5.02
- 2018-05-03 0001032975-18-000013 — 2.02, 5.02, 9.01
- 2018-01-23 0001032975-18-000005 — 2.02, 9.01
- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2020-01-23

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-20-000002:8k_2_02:1]
EX-99.1
2
exhibit991q3fy20.htm
EXHIBIT 99.1

[0001032975-20-000002:8k_2_02:2]
Exhibit

[0001032975-20-000002:8k_2_02:3]
Exhibit 99.1

[0001032975-20-000002:8k_2_02:4]
Editorial Contacts:

[0001032975-20-000002:8k_2_02:5]
Ben Lu, CFA, Vice President, Investor Relations - USA (510) 713-5568

[0001032975-20-000002:8k_2_02:6]
Krista Todd, Vice President, Global Communications - USA (510) 713-5834

[0001032975-20-000002:8k_2_02:7]
Nicole Kenyon, Head of Global Corporate & Employee Communications - USA (510) 988-8553

[0001032975-20-000002:8k_2_02:8]
Ben Starkie, Corporate Communications - Europe +41 (0) 79-292-3499

[0001032975-20-000002:8k_2_02:9]
Logitech Delivers Record Sales and Profitability in Holiday Quarter

[0001032975-20-000002:8k_2_02:10]
Quarterly Sales Top $900M for the First Time Ever

[0001032975-20-000002:8k_2_02:11]
LAUSANNE, Switzerland - Jan. 21, 2020 and NEWARK, Calif., Jan. 20, 2020 - Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the third quarter of Fiscal Year 2020.

[0001032975-20-000002:8k_2_02:12]
| • | Q3 sales were $903 million, up 4 percent in US dollars and 5 percent in constant currency, compared to Q3 of the prior year. |

[0001032975-20-000002:8k_2_02:13]
| • | Q3 GAAP operating income grew 4 percent to $129 million, compared to $123 million in the same quarter a year ago. Q3 GAAP earnings per share (EPS) grew 3 percent to $0.69, compared to $0.67 in the same quarter a year ago. |

[0001032975-20-000002:8k_2_02:14]
| • | Q3 non-GAAP operating income grew 6 percent to $152 million, compared to $143 million in the same quarter a year ago. Q3 non-GAAP EPS grew 6 percent to $0.84, compared to $0.79 in the same quarter a year ago. |

[0001032975-20-000002:8k_2_02:15]
| • | Cash flow from operations was $181 million, compared to $176 million in the same period a year ago. |

[0001032975-20-000002:8k_2_02:16]
“We delivered our biggest quarter in sales and profit in company history, topping $900 million in quarterly sales for the first time ever,” said Bracken Darrell, Logitech president and chief executive officer. “Our three largest businesses - Gaming, PC Peripherals and Video Collaboration - all had robust growth, including double-digit growth in Gaming and Video Collaboration. And despite the impact of tariffs, we delivered strong gross margins of 37.6%. On the back of this strong performance, we are confirming our annual guidance.”

[0001032975-20-000002:8k_2_02:17]
Outlook

[0001032975-20-000002:8k_2_02:18]
Logitech confirmed its Fiscal Year 2020 outlook of mid to high single-digit sales growth in constant currency and $375 million to $385 million in non-GAAP operating income.

[0001032975-20-000002:8k_2_02:19]
Prepared Remarks Available Online

[0001032975-20-000002:8k_2_02:20]
Logitech has made its prepared written remarks for the financial results teleconference available online on the Logitech corporate website at http://ir.logitech.com.

[0001032975-20-000002:8k_2_02:21]
Financial Results Teleconference and Webcast

[0001032975-20-000002:8k_2_02:22]
Logitech will hold a financial results teleconference to discuss the results for Q3 FY 2020 on Tuesday, January 21, 2020 at 8:30 a.m. Eastern Standard Time and 2:30 p.m. Central European Time. A live webcast of the call will be available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-20-000002:8k_2_02:23]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-20-000002:8k_2_02:24]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of intangible assets, purchase accounting effect on inventory, acquisition-related costs, restructuring charges (credits), loss (gain) on investments, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below. Logitech also presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for Fiscal Year 2020.

[0001032975-20-000002:8k_2_02:25]
About Logitech

[0001032975-20-000002:8k_2_02:26]
Logitech designs products that have an everyday place in people's lives, connecting them to the digital experiences they care about. More than 35 years ago, Logitech started connecting people through computers, and now it’s a multi-brand company designing products that bring people together through music, gaming, video and computing. Brands of Logitech include Logitech, Logitech G, ASTRO Gaming, Streamlabs, Ultimate Ears, Jaybird, and Blue Microphones. Founded in 1981, and headquartered in Lausanne, Switzerland, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @Logitech.

[0001032975-20-000002:8k_2_02:27]
# # #

[0001032975-20-000002:8k_2_02:28]
Factors and elsewhere. Logitech does not undertake any obligation to update any forward-looking statements to reflect new information or events or circumstances occurring after the date of this press release.

[0001032975-20-000002:8k_2_02:29]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-20-000002:8k_2_02:30]
Logitech and other Logitech marks are trademarks or registered trademarks of Logitech Europe S.A and/or its affiliates in the U.S. and other countries.  All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-20-000002:8k_2_02:31]
(LOGIIR)

[0001032975-20-000002:8k_2_02:32]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (A) |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net sales |  | $ | 902,687 |  |  | $ | 864,388 |  |  | $ | 2,266,603 |  |  | $ | 2,164,014 |  |
| Cost of goods sold |  | 564,283 |  |  | 535,707 |  |  | 1,410,605 |  |  | 1,349,941 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 3,951 |  |  | 4,699 |  |  | 10,493 |  |  | 10,037 |  |
| Gross profit |  | 334,453 |  |  | 323,982 |  |  | 845,505 |  |  | 804,036 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 134,950 |  |  | 132,250 |  |  | 392,138 |  |  | 368,635 |  |
| Research and development |  | 43,292 |  |  | 40,591 |  |  | 127,499 |  |  | 119,120 |  |
| General and administrative |  | 22,344 |  |  | 24,496 |  |  | 68,551 |  |  | 75,175 |  |
| Amortization of intangible assets and acquisition-related costs |  | 5,084 |  |  | 3,539 |  |  | 12,898 |  |  | 10,377 |  |
| Restructuring charges (credits), net |  | (45 | ) |  | (278 | ) |  | 69 |  |  | 9,762 |  |
| Total operating expenses |  | 205,625 |  |  | 200,598 |  |  | 601,155 |  |  | 583,069 |  |
| Operating income |  | 128,828 |  |  | 123,384 |  |  | 244,350 |  |  | 220,967 |  |
| Interest income |  | 2,063 |  |  | 1,482 |  |  | 7,006 |  |  | 5,709 |  |
| Other income (expense), net |  | 1,101 |  |  | (2,747 | ) |  | 2,852 |  |  | (929 | ) |
| Income before income taxes |  | 131,992 |  |  | 122,119 |  |  | 254,208 |  |  | 225,747 |  |
| Provision for income taxes (B) |  | 14,467 |  |  | 9,309 |  |  | 18,405 |  |  | 10,295 |  |
| Net income |  | $ | 117,525 |  |  | $ | 112,810 |  |  | $ | 235,803 |  |  | $ | 215,452 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.70 |  |  | $ | 0.68 |  |  | $ | 1.41 |  |  | $ | 1.30 |  |
| Diluted |  | $ | 0.69 |  |  | $ | 0.67 |  |  | $ | 1.39 |  |  | $ | 1.28 |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 167,063 |  |  | 165,707 |  |  | 166,678 |  |  | 165,552 |  |
| Diluted |  | 169,685 |  |  | 168,907 |  |  | 169,173 |  |  | 168,966 |  |

[0001032975-20-000002:8k_2_02:33]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS * |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |
|  |  | December 31, 2019 |  | March 31, 2019 |
| CONDENSED CONSOLIDATED BALANCE SHEETS (A) |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 656,046 |  |  | $ | 604,516 |  |
| Accounts receivable, net |  | 531,309 |  |  | 383,309 |  |
| Inventories |  | 307,494 |  |  | 293,495 |  |
| Other current assets |  | 78,539 |  |  | 69,116 |  |
| Total current assets |  | 1,573,388 |  |  | 1,350,436 |  |
| Non-current assets: |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 76,079 |  |  | 78,552 |  |
| Goodwill |  | 400,842 |  |  | 343,684 |  |
| Other intangible assets, net |  | 135,841 |  |  | 118,999 |  |
| Other assets (B) |  | 160,241 |  |  | 132,453 |  |
| Total assets |  | $ | 2,346,391 |  |  | $ | 2,024,124 |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 439,035 |  |  | $ | 283,922 |  |
| Accrued and other current liabilities (C) |  | 453,933 |  |  | 433,897 |  |
| Total current liabilities |  | 892,968 |  |  | 717,819 |  |
| Non-current liabilities: |  |  |  |  |  |  |
| Income taxes payable |  | 38,163 |  |  | 36,384 |  |
| Other non-current liabilities (C) |  | 117,467 |  |  | 93,582 |  |
| Total liabilities |  | 1,048,598 |  |  | 847,785 |  |
| Shareholders’ equity: |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |
| Issued shares — 173,106 at December 31 and March 31, 2019 |  |  |  |  |
| Additional shares that may be issued out of conditional capital — 50,000 at December 31 and March 31, 2019 |  |  |  |  |
| Additional shares that may be issued out of authorized capital — 34,621 at December 31 and March 31, 2019 |  |  |  |  |
| Additional paid-in capital |  | 59,668 |  |  | 56,655 |  |
| Shares in treasury, at cost — 5,901 at December 31, 2019 and 7,244 at March 31, 2019 |  | (159,190 | ) |  | (169,802 | ) |
| Retained earnings |  | 1,476,659 |  |  | 1,365,036 |  |
| Accumulated other comprehensive loss |  | (109,492 | ) |  | (105,698 | ) |
| Total shareholders’ equity |  | 1,297,793 |  |  | 1,176,339 |  |
| Total liabilities and shareholders’ equity |  | $ | 2,346,391 |  |  | $ | 2,024,124 |  |

[0001032975-20-000002:8k_2_02:34]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (A) |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 117,525 |  |  | $ | 112,810 |  |  | $ | 235,803 |  |  | $ | 215,452 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  | 10,768 |  |  | 10,760 |  |  | 32,154 |  |  | 32,655 |  |
| Amortization of intangible assets |  | 8,223 |  |  | 6,895 |  |  | 21,958 |  |  | 17,236 |  |
| Loss (gain) on investments |  | 709 |  |  | (207 | ) |  | 772 |  |  | (589 | ) |
| Share-based compensation expense |  | 13,831 |  |  | 11,855 |  |  | 40,301 |  |  | 37,163 |  |
| Deferred income taxes |  | 9,458 |  |  | 93 |  |  | 480 |  |  | (9,722 | ) |
| Other |  | (1,010 | ) |  | (453 | ) |  | (1,012 | ) |  | (378 | ) |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | (61,337 | ) |  | (25,469 | ) |  | (147,292 | ) |  | (158,944 | ) |
| Inventories |  | 32,603 |  |  | 15,238 |  |  | (15,170 | ) |  | (69,163 | ) |
| Other assets |  | 16,949 |  |  | (42 | ) |  | 2,866 |  |  | (11,098 | ) |
| Accounts payable |  | 26,089 |  |  | (4,529 | ) |  | 155,190 |  |  | 133,657 |  |
| Accrued and other liabilities |  | 7,327 |  |  | 49,272 |  |  | (1,896 | ) |  | 87,174 |  |
| Net cash provided by operating activities |  | 181,135 |  |  | 176,223 |  |  | 324,154 |  |  | 273,443 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (10,575 | ) |  | (9,936 | ) |  | (28,667 | ) |  | (28,304 | ) |
| Investment in privately held companies |  | (140 | ) |  | (2,036 | ) |  | (310 | ) |  | (2,542 | ) |
| Acquisitions, net of cash acquired |  | (91,203 | ) |  | — |  |  | (91,569 | ) |  | (133,908 | ) |
| Proceeds from the sale of property, plant and equipment |  | 1,037 |  |  | — |  |  | 1,037 |  |  | — |  |
| Purchases of short-term investments |  | — |  |  | — |  |  | — |  |  | (1,505 | ) |
| Purchases of trading investments |  | (546 | ) |  | (613 | ) |  | (3,071 | ) |  | (4,335 | ) |
| Proceeds from sales of trading investments |  | 568 |  |  | 644 |  |  | 3,139 |  |  | 4,838 |  |
| Net cash used in investing activities |  | (100,859 | ) |  | (11,941 | ) |  | (119,441 | ) |  | (165,756 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | — |  |  | — |  |  | (124,180 | ) |  | (113,971 | ) |
| Purchases of registered shares |  | — |  |  | (2,553 | ) |  | (15,127 | ) |  | (22,454 | ) |
| Proceeds from exercises of stock options and purchase rights |  | 2,209 |  |  | 128 |  |  | 11,540 |  |  | 10,135 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (2,188 | ) |  | (1,731 | ) |  | (23,096 | ) |  | (29,111 | ) |
| Net cash provided by (used in) financing activities |  | 21 |  |  | (4,156 | ) |  | (150,863 | ) |  | (155,401 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | 1,285 |  |  | (588 | ) |  | (2,320 | ) |  | (9,745 | ) |
| Net increase (decrease) in cash and cash equivalents |  | 81,582 |  |  | 159,538 |  |  | 51,530 |  |  | (57,459 | ) |
| Cash and cash equivalents, beginning of the period |  | 574,464 |  |  | 424,950 |  |  | 604,516 |  |  | 641,947 |  |
| Cash and cash equivalents, end of the period |  | $ | 656,046 |  |  | $ | 584,488 |  |  | $ | 656,046 |  |  | $ | 584,488 |  |

[0001032975-20-000002:8k_2_02:35]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |  |  |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |  |  |
| NET SALES |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Net sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Pointing Devices |  | $ | 154,540 |  |  | $ | 149,123 |  |  | 4 | % |  | $ | 409,293 |  |  | $ | 405,250 |  |  | 1 | % |
| Keyboards & Combos |  | 156,333 |  |  | 144,169 |  |  | 8 |  |  | 424,061 |  |  | 404,263 |  |  | 5 |  |
| PC Webcams |  | 32,165 |  |  | 33,021 |  |  | (3 | ) |  | 89,041 |  |  | 90,916 |  |  | (2 | ) |
| Tablet & Other Accessories |  | 31,256 |  |  | 35,757 |  |  | (13 | ) |  | 103,442 |  |  | 104,903 |  |  | (1 | ) |
| Video Collaboration |  | 91,964 |  |  | 74,186 |  |  | 24 |  |  | 254,941 |  |  | 190,154 |  |  | 34 |  |
| Mobile Speakers |  | 92,969 |  |  | 96,263 |  |  | (3 | ) |  | 200,617 |  |  | 207,690 |  |  | (3 | ) |
| Audio & Wearables |  | 81,934 |  |  | 98,629 |  |  | (17 | ) |  | 208,576 |  |  | 212,343 |  |  | (2 | ) |
| Gaming |  | 245,736 |  |  | 213,663 |  |  | 15 |  |  | 541,265 |  |  | 510,481 |  |  | 6 |  |
| Smart Home |  | 15,790 |  |  | 19,577 |  |  | (19 | ) |  | 35,088 |  |  | 37,829 |  |  | (7 | ) |
| Other (1) |  | — |  |  | — |  |  | — |  |  | 279 |  |  | 185 |  |  | 51 |  |
| Total sales |  | $ | 902,687 |  |  | $ | 864,388 |  |  | 4 | % |  | $ | 2,266,603 |  |  | $ | 2,164,014 |  |  | 5 | % |

[0001032975-20-000002:8k_2_02:36]
(1) Other category includes products that we currently intend to phase out, or have already phased out, because they are no longer strategic to our business.

[0001032975-20-000002:8k_2_02:37]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |  |  |  |  |
| GAAP TO NON-GAAP RECONCILIATION (A)(D) |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Gross profit - GAAP |  | $ | 334,453 |  |  | $ | 323,982 |  |  | $ | 845,505 |  |  | $ | 804,036 |  |
| Share-based compensation expense |  | 1,210 |  |  | 953 |  |  | 3,552 |  |  | 2,874 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 3,951 |  |  | 4,699 |  |  | 10,493 |  |  | 10,037 |  |
| Gross profit - Non-GAAP |  | $ | 339,614 |  |  | $ | 329,634 |  |  | $ | 859,550 |  |  | $ | 816,947 |  |
| Gross margin - GAAP |  | 37.1 | % |  | 37.5 | % |  | 37.3 | % |  | 37.2 | % |
| Gross margin - Non-GAAP |  | 37.6 | % |  | 38.1 | % |  | 37.9 | % |  | 37.8 | % |
| Operating expenses - GAAP |  | $ | 205,625 |  |  | $ | 200,598 |  |  | $ | 601,155 |  |  | $ | 583,069 |  |
| Less: Share-based compensation expense |  | 12,621 |  |  | 10,902 |  |  | 36,749 |  |  | 34,289 |  |
| Less: Amortization of intangible assets and acquisition-related costs |  | 5,084 |  |  | 3,539 |  |  | 12,898 |  |  | 10,377 |  |
| Less: Restructuring charges (credits), net |  | (45 | ) |  | (278 | ) |  | 69 |  |  | 9,762 |  |
| Operating expenses - Non-GAAP |  | $ | 187,965 |  |  | $ | 186,435 |  |  | $ | 551,439 |  |  | $ | 528,641 |  |
| % of net sales - GAAP |  | 22.8 | % |  | 23.2 | % |  | 26.5 | % |  | 26.9 | % |
| % of net sales - Non - GAAP |  | 20.8 | % |  | 21.6 | % |  | 24.3 | % |  | 24.4 | % |
| Operating income - GAAP |  | $ | 128,828 |  |  | $ | 123,384 |  |  | $ | 244,350 |  |  | $ | 220,967 |  |
| Share-based compensation expense |  | 13,831 |  |  | 11,855 |  |  | 40,301 |  |  | 37,163 |  |
| Amortization of intangible assets |  | 8,223 |  |  | 6,895 |  |  | 21,958 |  |  | 17,236 |  |
| Purchase accounting effect on inventory |  | — |  |  | 1,343 |  |  | — |  |  | 1,722 |  |
| Acquisition-related costs |  | 812 |  |  | — |  |  | 1,433 |  |  | 1,456 |  |
| Restructuring charges (credits), net |  | (45 | ) |  | (278 | ) |  | 69 |  |  | 9,762 |  |
| Operating income - Non - GAAP |  | $ | 151,649 |  |  | $ | 143,199 |  |  | $ | 308,111 |  |  | $ | 288,306 |  |
| % of net sales - GAAP |  | 14.3 | % |  | 14.3 | % |  | 10.8 | % |  | 10.2 | % |
| % of net sales - Non - GAAP |  | 16.8 | % |  | 16.6 | % |  | 13.6 | % |  | 13.3 | % |
| Net income - GAAP |  | $ | 117,525 |  |  | $ | 112,810 |  |  | $ | 235,803 |  |  | $ | 215,452 |  |
| Share-based compensation expense |  | 13,831 |  |  | 11,855 |  |  | 40,301 |  |  | 37,163 |  |
| Amortization of intangible assets |  | 8,223 |  |  | 6,895 |  |  | 21,958 |  |  | 17,236 |  |
| Purchase accounting effect on inventory |  | — |  |  | 1,343 |  |  | — |  |  | 1,722 |  |
| Acquisition-related costs |  | 812 |  |  | — |  |  | 1,433 |  |  | 1,456 |  |
| Restructuring charges (credits), net |  | (45 | ) |  | (278 | ) |  | 69 |  |  | 9,762 |  |
| Loss (gain) on investments |  | 709 |  |  | (207 | ) |  | 772 |  |  | (589 | ) |
| Non-GAAP income tax adjustment |  | 2,123 |  |  | 1,443 |  |  | (6,476 | ) |  | (7,782 | ) |
| Net income - Non - GAAP |  | $ | 143,178 |  |  | $ | 133,861 |  |  | $ | 293,860 |  |  | $ | 274,420 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.69 |  |  | $ | 0.67 |  |  | $ | 1.39 |  |  | $ | 1.28 |  |
| Diluted - Non - GAAP |  | $ | 0.84 |  |  | $ | 0.79 |  |  | $ | 1.74 |  |  | $ | 1.62 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non - GAAP |  | 169,685 |  |  | 168,907 |  |  | 169,173 |  |  | 168,966 |  |

[0001032975-20-000002:8k_2_02:38]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
| SHARE-BASED COMPENSATION EXPENSE |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 1,210 |  |  | $ | 953 |  |  | $ | 3,552 |  |  | $ | 2,874 |  |
| Marketing and selling |  | 6,216 |  |  | 4,600 |  |  | 20,016 |  |  | 15,250 |  |
| Research and development |  | 2,242 |  |  | 1,811 |  |  | 6,644 |  |  | 5,295 |  |
| General and administrative |  | 4,163 |  |  | 4,491 |  |  | 10,089 |  |  | 13,744 |  |
| Total share-based compensation expense |  | 13,831 |  |  | 11,855 |  |  | 40,301 |  |  | 37,163 |  |
| Income tax benefit |  | (3,135 | ) |  | (2,397 | ) |  | (12,658 | ) |  | (14,576 | ) |
| Total share-based compensation expense, net of income tax benefit |  | $ | 10,696 |  |  | $ | 9,458 |  |  | $ | 27,643 |  |  | $ | 22,587 |  |

[0001032975-20-000002:8k_2_02:39]
*  Note: These preliminary results for the three and nine months ended December 31, 2019 are subject to adjustments, including subsequent events that may occur through the date of filing our Quarterly Report on Form 10-Q.

[0001032975-20-000002:8k_2_02:40]
(A) Preliminary valuation from the business acquisition

[0001032975-20-000002:8k_2_02:41]
The preliminary fair value of assets acquired and liabilities assumed from the business acquisition in the third quarter of fiscal year 2020 is included in the tables. The fair value of identifiable intangible assets acquired was based on estimates and assumptions made by us at the time of the acquisition. As additional information becomes available, such as the finalization of the estimated fair value of the assets acquired and liabilities assumed, we may revise our preliminary or interim estimated fair value of the assets acquired and liabilities assumed during the remainder of the measurement period (which will not exceed 12 months from the acquisition date). Any such revisions or changes may be material, and may have a material impact over our financial conditions and results of operations.

[0001032975-20-000002:8k_2_02:42]
(B) Swiss Federal Tax Reform

[0001032975-20-000002:8k_2_02:43]
On May 19, 2019, the Swiss electorate approved the Federal Act on Tax Reform and AHV Financing ("TRAF"), a major reform to better align the Swiss tax system with international tax standards. The legislation was subsequently published in the federal register on August 6, 2019 to take effect on January 1, 2020. As of December 31, 2019, TRAF has not been enacted in all cantons, including the canton of Vaud, as the cantonal legislative procedures are in process. The Company anticipates TRAF to take effect as of January 1, 2020 when enactment occurs in the canton of Vaud.

[0001032975-20-000002:8k_2_02:44]
The change in the effective income tax rate for the three and nine months ended December 31, 2019, compared to the same periods ended December 31, 2018, was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate and the transitional income tax impact in Switzerland.  We have benefited from a longstanding tax ruling from the canton of Vaud through December 31, 2019. The transitional income tax impact represents income tax provision at the current full statutory income tax rate of 13.67% without taking account of other elements of the tax reform yet to be enacted. Furthermore, there was a discrete tax benefit of $1.7 million  from adjusting deferred tax assets and liabilities in Switzerland in the nine months ended December 31, 2019. There were discrete tax benefits of $6.0 million and $2.7 million from the recognition of net excess tax benefits in the United States and reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the nine-month period ended December 31, 2019, compared with $9.5 million and $2.3 million, respectively, in the nine-month period ended December 31, 2018.

[0001032975-20-000002:8k_2_02:45]
(C)  Adoption of ASC Topic 842

[0001032975-20-000002:8k_2_02:46]
We adopted the new standards for leases under Accounting Standards Codification ("ASC") Topic 842 using the modified retrospective approach as of April 1, 2019 and did not restate the financial statements of the comparative periods as is allowed by election of the transition option under ASC 842. Adoption of the standard resulted in the recognition of $27.7 million of right-of-use assets, $11.3 million of short-term lease liabilities and $21.7 million of long-term lease liabilities related to our leases on December 31, 2019.

[0001032975-20-000002:8k_2_02:47]
(D) Non-GAAP Financial Measures

[0001032975-20-000002:8k_2_02:48]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating

[0001032975-20-000002:8k_2_02:49]
decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-20-000002:8k_2_02:50]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended December 31, 2019 and previous periods, we excluded items in the following general categories, each of which are described below:

[0001032975-20-000002:8k_2_02:51]
Share-based compensation expenses. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-20-000002:8k_2_02:52]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit, operating expenses, and financial results from period to period.

[0001032975-20-000002:8k_2_02:53]
Purchase accounting effect on inventory. Business combination accounting principles require us to measure acquired inventory at fair value. The fair value of inventory reflects the acquired company’s cost of manufacturing plus a portion of the expected profit margin. The non-GAAP adjustment excludes the expected profit margin component that is recorded under business combination accounting principles associated with our business acquisitions. We believe the adjustment is useful to investors because such charges are not reflective of our ongoing operations.

[0001032975-20-000002:8k_2_02:54]
Acquisition-related costs and change in fair value of contingent consideration for business acquisition.  We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition related costs include all incremental expenses incurred to effect a business combination. Fair value of contingent consideration is associated with our estimates of the value of earn-outs in connection with certain acquisitions. We believe that providing the non-GAAP measures excluding these costs and credits, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-20-000002:8k_2_02:55]
Restructuring charges (credits). These expenses are associated with re-aligning our business strategies based on current economic conditions. We have undertaken several restructuring plans in recent years. In connection with our restructuring initiatives, we incurred restructuring charges related to employee terminations, facility closures and early cancellation of certain contracts. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results in the current period.

[0001032975-20-000002:8k_2_02:56]
Loss (gain) on investments. We recognized loss (gain) related to our investments in various companies, which varies depending on the operational and financial performance of those companies in which we invested. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-20-000002:8k_2_02:57]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above and other events; the determination of which is based upon the nature of the underlying items, the mix of income and losses in jurisdictions and the relevant tax rates in which we operate.

[0001032975-20-000002:8k_2_02:58]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing

[0001032975-20-000002:8k_2_02:59]
specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-20-000002:8k_2_02:60]
Additional Supplemental Financial Information - Constant Currency

[0001032975-20-000002:8k_2_02:61]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.
