# LOGI notes — 0001032975-25-000080


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-25-000080:notes:1]
[same as prior period, unchanged from 0001032975-25-000059:notes:1]

[0001032975-25-000080:notes:2]
[same as prior period, unchanged from 0001032975-25-000059:notes:2]

[0001032975-25-000080:notes:3]
[same as prior period, unchanged from 0001032975-25-000059:notes:3]

[0001032975-25-000080:notes:4]
[same as prior period, unchanged from 0001032975-25-000059:notes:4]

[0001032975-25-000080:notes:5]
[same as prior period, unchanged from 0001032975-25-000059:notes:5]

[0001032975-25-000080:notes:6]
The condensed consolidated financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States ("U.S. GAAP") for interim financial information and therefore do not include all the information required by U.S. GAAP for complete financial statements. The condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2025, included in the Company's Annual Report on Form 10-K filed with the Securities and Exchange Commission ("SEC") on May 23, 2025.

[0001032975-25-000080:notes:7]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and six months ended September 30, 2025 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2026, or any future periods.

[0001032975-25-000080:notes:8]
[same as prior period, unchanged from 0001032975-25-000059:notes:8]

[0001032975-25-000080:notes:9]
There have been no material changes in the Company’s significant accounting policies during the three and six months ended September 30, 2025 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2025.

[0001032975-25-000080:notes:10]
[same as prior period, unchanged from 0001032975-25-000059:notes:10]

[0001032975-25-000080:notes:11]
[same as prior period, unchanged from 0001032975-25-000059:notes:11]

[0001032975-25-000080:notes:12]
[same as prior period, unchanged from 0001032975-25-000059:notes:12]

[0001032975-25-000080:notes:13]
[same as prior period, unchanged from 0001032975-25-000059:notes:13]

[0001032975-25-000080:notes:14]
In 2025, the United States introduced trade policy actions that have increased import tariffs across a wide range of countries at various rates, with certain exemptions. These tariff policies in the U.S. and responsive policies enacted in other countries are evolving. The incremental tariffs have had and may continue to have an adverse impact on the Company's results of operations. In addition, the Company's business has continued to be impacted by ongoing macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, uncertainty in consumer and enterprise demand, low economic growth in certain regions, changes in fiscal policies and geopolitical conflicts.

[0001032975-25-000080:notes:15]
[same as prior period, unchanged from 0001032975-25-000059:notes:15]

[0001032975-25-000080:notes:16]
[same as prior period, unchanged from 0001032975-25-000059:notes:16]

[0001032975-25-000080:notes:17]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. ASU 2023-09 requires additional disclosures related to rate reconciliation, income taxes paid, and other disclosures. Under ASU 2023-09, for each annual period presented, public entities are required to (1) disclose specific categories in the tabular rate reconciliation and (2) provide additional information for reconciling items that meet a quantitative threshold. In addition, ASU 2023-09 requires all reporting entities to disclose on an annual basis the amount of income taxes paid disaggregated by federal, state, and foreign taxes as well as the amount of income taxes paid by individual jurisdiction. ASU 2023-09 is effective for public business entities for annual periods beginning after December 15, 2024 and can be applied on a prospective basis with an option to apply the standard retrospectively. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2023-09 on its consolidated financial statements and related disclosures.

[0001032975-25-000080:notes:18]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses. ASU 2024-03 requires all public entities to disclose in the notes to the financial statements the amounts of purchases of inventory, employee compensation, depreciation, and intangible asset amortization included in each expense caption of the income statement. ASU 2024-03 is effective for fiscal years beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027. ASU 2024-03 can be applied either prospectively or retrospectively. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2024-03 on its consolidated financial statements and related disclosures.

[0001032975-25-000080:notes:19]
In July 2025, the FASB issued ASU No. 2025-05, Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets. ASU 2025-05 provides a practical expedient that permits entities to assume that current conditions as of the balance sheet date will remain unchanged over the remaining life of current accounts receivable and current contract assets when estimating the expected credit losses. ASU 2025-05 is effective for annual periods beginning after December 15, 2025, and interim periods within those annual reporting periods. Early adoption is permitted. ASU 2025-05 should be applied on a prospective basis. The Company is currently evaluating the impact of ASU 2025-05 on its consolidated financial statements and related disclosures.

[0001032975-25-000080:notes:20]
In September 2025, the FASB issued ASU No. 2025-06, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software. ASU 2025-06 updates the cost capitalization threshold for internal-use software development costs by removing all references to software project development stages and providing new guidance on how to evaluate whether the probable-to-complete recognition threshold has been met. ASU 2025-06 is effective for annual periods beginning after December 15, 2027, and interim periods within those annual reporting periods. Early adoption is permitted. ASU 2025-06 can be applied on a prospective basis, with retrospective or modified retrospective application permitted. The Company is currently evaluating the impact of ASU 2025-06 on its consolidated financial statements and related disclosures.


## us-gaap:EarningsPerShareTextBlock

[0001032975-25-000080:notes:21]
[same as prior period, unchanged from 0001032975-25-000059:notes:19]

[0001032975-25-000080:notes:22]
The following table summarizes the computations of basic and diluted net income per share for the three and six months ended September 30, 2025 and 2024 (in thousands, except per share amounts):

[0001032975-25-000080:notes:23]
|  |  | Three Months Ended September 30, |  | Six Months Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net income |  | $ | 170,670 |  |  | $ | 145,483 |  |  | $ | 316,685 |  |  | $ | 287,316 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 147,123 |  |  | 152,460 |  |  | 147,487 |  |  | 152,875 |  |
| Effect of potentially dilutive equivalent shares |  | 1,299 |  |  | 1,212 |  |  | 1,244 |  |  | 1,445 |  |
| Weighted average shares outstanding - diluted |  | 148,422 |  |  | 153,672 |  |  | 148,731 |  |  | 154,320 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.16 |  |  | $ | 0.95 |  |  | $ | 2.15 |  |  | $ | 1.88 |  |
| Diluted |  | $ | 1.15 |  |  | $ | 0.95 |  |  | $ | 2.13 |  |  | $ | 1.86 |  |

[0001032975-25-000080:notes:24]
Share equivalents attributable to outstanding stock options, restricted stock units and employee share purchase plans totaling 0.2 million and 0.9 million for the three months ended September 30, 2025 and 2024, respectively, and 0.9 million and 1.0 million for the six months ended September 30, 2025 and 2024, respectively, were excluded from the calculation of diluted net income per share because their effect would have been antidilutive. A small number of performance-based restricted stock units were not included in the diluted net income per share calculation because all necessary conditions had not been satisfied by the end of the respective period, and those shares were not issuable if the end of the reporting period were the end of the performance contingency period.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-25-000080:notes:25]
[same as prior period, unchanged from 0001032975-25-000059:notes:23]

[0001032975-25-000080:notes:26]
[same as prior period, unchanged from 0001032975-25-000059:notes:24]

[0001032975-25-000080:notes:27]
As of September 30, 2025, the Company offers the 2006 Employee Share Purchase Plan (Non-U.S.), as amended and restated, the 1996 Employee Share Purchase Plan (U.S.), as amended and restated, and the 2006 Stock Incentive Plan, as amended and restated. Shares issued to employees as a result of purchases or exercises under these plans are generally issued from shares held in treasury stock.

[0001032975-25-000080:notes:28]
The following table summarizes share-based compensation expense and total income tax benefit recognized for the three and six months ended September 30, 2025 and 2024 (in thousands):

[0001032975-25-000080:notes:29]
|  |  | Three Months Ended September 30, |  | Six Months Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Cost of goods sold |  | $ | 3,359 |  |  | $ | 3,902 |  |  | $ | 5,739 |  |  | $ | 6,500 |  |
| Marketing and selling |  | 12,141 |  |  | 10,469 |  |  | 26,071 |  |  | 22,320 |  |
| Research and development |  | 5,666 |  |  | 5,067 |  |  | 12,017 |  |  | 10,806 |  |
| General and administrative |  | 9,146 |  |  | 7,031 |  |  | 19,313 |  |  | 10,248 |  |
| Total share-based compensation expense |  | 30,312 |  |  | 26,469 |  |  | 63,140 |  |  | 49,874 |  |
| Income tax benefit |  | (6,015) |  |  | (4,776) |  |  | (10,921) |  |  | (12,378) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 24,297 |  |  | $ | 21,693 |  |  | $ | 52,219 |  |  | $ | 37,496 |  |

[0001032975-25-000080:notes:30]
[same as prior period, unchanged from 0001032975-25-000059:notes:28]

[0001032975-25-000080:notes:31]
Share-based compensation costs capitalized as part of inventory were $2.0 million and $1.8 million for the three months ended September 30, 2025 and 2024, respectively, and $4.8 million and $4.3 million for the six months ended September 30, 2025 and 2024, respectively.

[0001032975-25-000080:notes:32]
[same as prior period, unchanged from 0001032975-25-000059:notes:30]

[0001032975-25-000080:notes:33]
Certain subsidiaries of the Company sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The costs of $1.8 million recorded for each of the three months ended September 30, 2025 and 2024, and $3.5 million recorded for each of the six months ended September 30, 2025 and 2024, were primarily related to service costs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-25-000080:notes:34]
[same as prior period, unchanged from 0001032975-25-000059:notes:32]

[0001032975-25-000080:notes:35]
[same as prior period, unchanged from 0001032975-25-000059:notes:33]

[0001032975-25-000080:notes:36]
The income tax provision for the three and six months ended September 30, 2025 was $32.4 million and $60.9 million based on an effective income tax rate of 15.9% and 16.1% of pre-tax income, respectively. The income tax provision for the same periods ended September 30, 2024 was $30.6 million and $56.1 million based on an effective income tax rate of 17.4% and 16.3% of pre-tax income, respectively. The change in the effective income tax rate for the three and six months ended September 30, 2025, compared with the same periods ended September 30, 2024, was primarily due to the change in the mix of income and losses in the various tax jurisdictions in which the Company operates and less tax incentives for foreign derived intangible income and R&D as compared to prior period, offset by return to provision adjustments.

[0001032975-25-000080:notes:37]
The change in the effective income tax rate for the three and six months ended September 30, 2025, compared with the same periods ended September 30, 2024, was primarily due to the change in the mix of income and losses in the various tax jurisdictions in which the Company operates and less tax incentives for foreign derived intangible income and R&D as compared to prior period, offset with a change in uncertain tax positions.

[0001032975-25-000080:notes:38]
[same as prior period, unchanged from 0001032975-25-000059:notes:36]

[0001032975-25-000080:notes:39]
For the three months ended September 30, 2025, the Company assessed its exposure to the OECD Pillar Two global minimum tax rules. The Company has determined that, for the fiscal year 2026, most jurisdictions in which it operates should qualify for the transitional Country-by-Country Reporting ("CbCR") safe harbor, as outlined in the OECD Administrative Guidance and enacted domestic legislation. The Company's CbCR has been prepared in accordance with the requirements for a Qualified CbCR, using qualified financial statements. Based on this data, most jurisdictions continue to meet safe harbor qualifications at 16% tax rates, and therefore, the Company is only required to perform a detailed Pillar Two top-up tax calculation for limited jurisdictions. The estimated top up tax for fiscal year 2026 is not material and has been included in the calculation of the Company's annual effective tax rate. The OECD and participating countries continue to issue underlying rules and administrative guidance related to Pillar Two, and the Company continues to monitor the relevant developments.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-25-000080:notes:40]
[same as prior period, unchanged from 0001032975-25-000059:notes:38]

[0001032975-25-000080:notes:41]
[same as prior period, unchanged from 0001032975-25-000059:notes:39]

[0001032975-25-000080:notes:42]
|  |  | September 30, 2025 |  | March 31, 2025 |
| Accounts receivable, net: |  |  |  |  |
| Accounts receivable |  | $ | 1,017,821 |  |  | $ | 708,693 |  |
| Allowance for cooperative marketing arrangements |  | (56,844) |  |  | (44,457) |  |
| Allowance for customer incentive programs |  | (82,885) |  |  | (66,564) |  |
| Allowance for pricing programs |  | (135,138) |  |  | (105,876) |  |
| Other allowances |  | (39,059) |  |  | (37,250) |  |
|  |  | $ | 703,895 |  |  | $ | 454,546 |  |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 38,232 |  |  | $ | 48,699 |  |
| Finished goods |  | 479,441 |  |  | 455,048 |  |
|  |  | $ | 517,673 |  |  | $ | 503,747 |  |
| Other current assets: |  |  |  |  |
| Value-added tax ("VAT") receivables |  | $ | 50,515 |  |  | $ | 46,332 |  |
| Prepaid expenses and other assets |  | 101,861 |  |  | 84,879 |  |
|  |  | $ | 152,376 |  |  | $ | 131,211 |  |
| Property, plant and equipment, net: |  |  |  |  |
| Property, plant and equipment |  | $ | 569,591 |  |  | $ | 543,747 |  |
| Less: accumulated depreciation and amortization |  | (451,373) |  |  | (429,889) |  |
|  |  | $ | 118,218 |  |  | $ | 113,858 |  |
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 204,703 |  |  | $ | 202,180 |  |
| Right-of-use assets |  | 77,639 |  |  | 75,239 |  |
| Investments for deferred compensation plan |  | 33,183 |  |  | 29,006 |  |
| Investments in privately held companies |  | 28,466 |  |  | 27,980 |  |
| Other assets |  | 13,207 |  |  | 9,672 |  |
|  |  | $ | 357,198 |  |  | $ | 344,077 |  |

[0001032975-25-000080:notes:43]
[same as prior period, unchanged from 0001032975-25-000059:notes:41]

[0001032975-25-000080:notes:44]
|  |  | September 30, 2025 |  | March 31, 2025 |
| Accrued and other current liabilities: |  |  |  |  |
| Accrued customer marketing, pricing and incentive programs |  | $ | 229,938 |  |  | $ | 173,401 |  |
| Accrued personnel expenses |  | 118,580 |  |  | 180,763 |  |
| VAT payable |  | 36,782 |  |  | 29,648 |  |
| Warranty liabilities |  | 35,738 |  |  | 34,428 |  |
| Deferred revenue (1) |  | 34,560 |  |  | 25,798 |  |
| Accrued sales return liability |  | 26,475 |  |  | 27,913 |  |
| Accrued loss for inventory purchase commitments |  | 26,422 |  |  | 19,614 |  |
| Income taxes payable |  | 20,663 |  |  | 26,841 |  |
| Operating lease liabilities |  | 17,542 |  |  | 15,780 |  |
| Other current liabilities |  | 151,355 |  |  | 152,317 |  |
|  |  | $ | 698,055 |  |  | $ | 686,503 |  |
| Other non-current liabilities: |  |  |  |  |
| Operating lease liabilities |  | $ | 77,712 |  |  | $ | 76,622 |  |
| Employee benefit plan obligations |  | 60,441 |  |  | 57,338 |  |
| Deferred revenue (1) |  | 48,294 |  |  | 38,216 |  |
| Obligation for deferred compensation plan |  | 33,183 |  |  | 29,006 |  |
| Warranty liabilities |  | 14,453 |  |  | 14,756 |  |
| Other non-current liabilities |  | 5,560 |  |  | 5,574 |  |
|  |  | $ | 239,643 |  |  | $ | 221,512 |  |

[0001032975-25-000080:notes:45]
[same as prior period, unchanged from 0001032975-25-000059:notes:43]


## us-gaap:FairValueDisclosuresTextBlock

[0001032975-25-000080:notes:46]
[same as prior period, unchanged from 0001032975-25-000059:notes:44]

[0001032975-25-000080:notes:47]
[same as prior period, unchanged from 0001032975-25-000059:notes:45]

[0001032975-25-000080:notes:48]
[same as prior period, unchanged from 0001032975-25-000059:notes:46]

[0001032975-25-000080:notes:49]
[same as prior period, unchanged from 0001032975-25-000059:notes:47]

[0001032975-25-000080:notes:50]
[same as prior period, unchanged from 0001032975-25-000059:notes:48]

[0001032975-25-000080:notes:51]
[same as prior period, unchanged from 0001032975-25-000059:notes:49]

[0001032975-25-000080:notes:52]
|  |  | September 30, 2025 |  | March 31, 2025 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 550,128 |  |  | $ | — |  |  | $ | — |  |  | $ | 852,467 |  |  | $ | — |  |  | $ | — |  |
| Investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 78 |  |  | $ | — |  |  | $ | — |  |  | $ | 90 |  |  | $ | — |  |  | $ | — |  |
| Common stock |  | 839 |  |  | — |  |  | — |  |  | 540 |  |  | — |  |  | — |  |
| Money market funds |  | 7,863 |  |  | — |  |  | — |  |  | 7,359 |  |  | — |  |  | — |  |
| Mutual funds |  | 24,403 |  |  | — |  |  | — |  |  | 21,017 |  |  | — |  |  | — |  |
| Total investments for deferred compensation plan |  | $ | 33,183 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,006 |  |  | $ | — |  |  | $ | — |  |
| Currency derivative assetsincluded in other current assets |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 90 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Currency derivative liabilitiesincluded in accrued and other current liabilities |  | $ | — |  |  | $ | 3,857 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,849 |  |  | $ | — |  |

[0001032975-25-000080:notes:53]
[same as prior period, unchanged from 0001032975-25-000059:notes:51]

[0001032975-25-000080:notes:54]
The marketable securities for the Company's deferred compensation plan were recorded at a fair value of $33.2 million and $29.0 million, as of September 30, 2025 and March 31, 2025, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized gains (losses) related to marketable securities for the three and six months ended September 30, 2025 and 2024 were not material and are included in other income (expense), net and corresponding changes in the deferred compensation liability were included in operating expenses and cost of goods sold, in the Company's condensed consolidated statements of operations.

[0001032975-25-000080:notes:55]
[same as prior period, unchanged from 0001032975-25-000059:notes:53]

[0001032975-25-000080:notes:56]
The Company has certain non-marketable investments included in other assets that are accounted for as equity method investments, with a carrying value of $18.8 million and $18.4 million as of September 30, 2025 and March 31, 2025, respectively. Income (loss) related to equity method investments for the three and six months ended September 30, 2025 and 2024 were not material and are included in other income (expense), net in the Company's condensed consolidated statements of operations. There was no impairment of equity method investments during the three and six months ended September 30, 2025 and 2024.

[0001032975-25-000080:notes:57]
[same as prior period, unchanged from 0001032975-25-000059:notes:55]

[0001032975-25-000080:notes:58]
[same as prior period, unchanged from 0001032975-25-000059:notes:56]

[0001032975-25-000080:notes:59]
The Company has certain equity investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with the same or similar security from the same issuer. The amount of these equity investments without readily determinable fair value included in other assets was $8.8 million as of September 30, 2025 and March 31, 2025. There was no impairment of these equity investments during the three and six months ended September 30, 2025. The impairment charges related to the equity investments were not material during the three and six months ended September 30, 2024.

[0001032975-25-000080:notes:60]
Non-Financial Assets
Goodwill, intangible assets, and property, plant and equipment, are not required to be measured at fair value on a recurring basis. However, if the Company is required to evaluate these non-financial assets for impairment, whether due to certain triggering events or because of the required annual impairment test, and a resulting impairment is recorded to reduce the carrying value to the fair value, the non-financial assets are measured at fair value during such period. There was no impairment of non-financial assets during the three and six months ended September 30, 2025 and 2024.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-25-000080:notes:61]
[same as prior period, unchanged from 0001032975-25-000059:notes:59]

[0001032975-25-000080:notes:62]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis in other current assets and accrued and other current liabilities, respectively, on the condensed consolidated balance sheets as of September 30, 2025 and March 31, 2025. See Note 6 for the fair values of the Company’s derivative instruments as of September 30, 2025 and March 31, 2025.

[0001032975-25-000080:notes:63]
[same as prior period, unchanged from 0001032975-25-000059:notes:61]

[0001032975-25-000080:notes:64]
[same as prior period, unchanged from 0001032975-25-000059:notes:62]

[0001032975-25-000080:notes:65]
The notional amounts of foreign currency exchange forward contracts outstanding related to forecasted inventory purchases were $301.0 million and $74.6 million as of September 30, 2025 and March 31, 2025, respectively. The Company had $6.8 million of net loss related to its cash flow hedges included in accumulated other comprehensive loss as of September 30, 2025, which will be reclassified into earnings within the next twelve months.

[0001032975-25-000080:notes:66]
The following table presents the amounts of gain (loss) on the Company’s derivative instruments designated as hedging instruments for the three and six months ended September 30, 2025 and 2024 and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income (in thousands):

[0001032975-25-000080:notes:67]
|  |  | Three Months Ended September 30, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  |  |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |  |  |
| Cash flow hedges |  | $ | 589 |  |  | $ | (2,931) |  |  | $ | 5,961 |  |  | $ | (906) |  |  |  |  |  |
|  |  | Six Months Ended September 30, |
|  |  | Amount of LossDeferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  |  |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |  |  |
| Cash flow hedges |  | $ | (11,760) |  |  | $ | (1,349) |  |  | $ | 7,963 |  |  | $ | (1,639) |  |  |  |  |  |

[0001032975-25-000080:notes:68]
[same as prior period, unchanged from 0001032975-25-000059:notes:66]

[0001032975-25-000080:notes:69]
[same as prior period, unchanged from 0001032975-25-000059:notes:67]

[0001032975-25-000080:notes:70]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within approximately one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are not material and are included in other income (expense), net, in the condensed consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of September 30, 2025 and March 31, 2025 were $129.5 million and $131.8 million, respectively.

[0001032975-25-000080:notes:71]
[same as prior period, unchanged from 0001032975-25-000059:notes:69]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-25-000080:notes:72]
Goodwill and Other Intangible Assets
The Company conducts its impairment analysis of goodwill annually at December 31 or more frequently if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting unit may be less than its carrying amount. There have been no triggering events identified affecting the valuation of goodwill and intangible assets during the three and six months ended September 30, 2025 and 2024.

[0001032975-25-000080:notes:73]
[same as prior period, unchanged from 0001032975-25-000059:notes:71]

[0001032975-25-000080:notes:74]
| As of March 31, 2025 |  | $ | 463,230 |  |
| Effects of foreign currency translation |  | 2,522 |  |
| As of September 30, 2025 |  | $ | 465,752 |  |

[0001032975-25-000080:notes:75]
[same as prior period, unchanged from 0001032975-25-000059:notes:73]

[0001032975-25-000080:notes:76]
|  |  | September 30, 2025 |  | March 31, 2025 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademarks and trade names |  | $ | 32,390 |  |  | $ | (29,994) |  |  | $ | 2,396 |  |  | $ | 32,390 |  |  | $ | (28,675) |  |  | $ | 3,715 |  |
| Developed technology |  | 107,421 |  |  | (100,727) |  |  | 6,694 |  |  | 107,421 |  |  | (96,464) |  |  | 10,957 |  |
| Customer contracts/relationships |  | 69,087 |  |  | (61,766) |  |  | 7,321 |  |  | 69,087 |  |  | (58,646) |  |  | 10,441 |  |
| Effects of foreign currency translation |  | 669 |  |  | (774) |  |  | (105) |  |  | (620) |  |  | 137 |  |  | (483) |  |
| Total |  | $ | 209,567 |  |  | $ | (193,261) |  |  | $ | 16,306 |  |  | $ | 208,278 |  |  | $ | (183,648) |  |  | $ | 24,630 |  |


## us-gaap:DebtDisclosureTextBlock

[0001032975-25-000080:notes:77]
Financing Arrangements

[0001032975-25-000080:notes:78]
On January 27, 2025, the Company entered into an unsecured revolving credit facility with a syndicate of banks (the "Credit Agreement"). The Credit Agreement provides a revolving line of credit of up to $750.0 million to the Company including the issuance of letters of credit of up to $100.0 million. The Credit Agreement terminates on January 27, 2030 unless extended in accordance with its terms. The Credit Agreement contains (1) an increase option allowing the Company to secure up to $250.0 million of additional commitments and (2) an extension option to extend the term by one-year which may be exercised no more than two times, subject to certain requirements. Loans under the Credit Agreement are available in U.S. Dollars, Euro, Sterling, Yen, Swiss Francs, Canadian Dollars, Australian Dollars and any other currency agreed to by each lender. Proceeds of loans made under the Credit Agreement may be used for general corporate purposes.

[0001032975-25-000080:notes:79]
The Credit Agreement contains a maximum net debt to adjusted EBITDA ratio, compliance with which is a condition to the Company's ability to borrow. Borrowings under the Credit Agreement will bear interest at a rate determined by reference to benchmark rates plus an applicable spread (ranging from 0% to 1.5%) based on the Company's net leverage ratio or credit rating at the time of the borrowing. Undrawn balances available under the Credit Agreement are subject to commitment fees at the applicable rate determined by reference to the Company's net leverage ratio or credit rating. There has been no borrowing outstanding under the Credit Agreement as of September 30, 2025.
In addition, the Company had several uncommitted, unsecured bank lines of credit and letters of credit aggregating to $160.9 million and $172.2 million as of September 30, 2025 and March 31, 2025, respectively. There are no financial covenants under the lines of credit with which the Company must comply. There was no borrowing outstanding under the lines of credit as of September 30, 2025 or March 31, 2025. As of September 30, 2025 and March 31, 2025, the Company had outstanding bank guarantees of $11.7 million and $12.1 million, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-25-000080:notes:80]
Commitments and Contingencies

[0001032975-25-000080:notes:81]
Product Warranties

[0001032975-25-000080:notes:82]
Changes in the Company’s warranty liabilities for the three and six months ended September 30, 2025 and 2024 were as follows (in thousands):

[0001032975-25-000080:notes:83]
|  | Three Months Ended September 30, |  | Six Months Ended September 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Beginning of the period | $ | 50,206 |  |  | $ | 44,502 |  |  | $ | 49,184 |  |  | $ | 44,654 |  |
| Provision | 10,372 |  |  | 11,776 |  |  | 18,994 |  |  | 21,962 |  |
| Settlements | (10,392) |  |  | (9,975) |  |  | (18,641) |  |  | (20,013) |  |
| Effects of foreign currency translation | 5 |  |  | 530 |  |  | 654 |  |  | 230 |  |
| End of the period | $ | 50,191 |  |  | $ | 46,833 |  |  | $ | 50,191 |  |  | $ | 46,833 |  |

[0001032975-25-000080:notes:84]
Indemnifications

[0001032975-25-000080:notes:85]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2025, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-25-000080:notes:86]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-25-000080:notes:87]
Legal Proceedings

[0001032975-25-000080:notes:88]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and legal proceedings. The Company intends to vigorously defend against them. Management periodically assesses the Company’s liabilities and contingencies in connection with these matters based upon the latest information available. The Company follows ASC ("Accounting Standards Codification") 450, Contingencies, in determining the accounting and disclosure for these contingencies. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows, and results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity, and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-25-000080:notes:89]
[same as prior period, unchanged from 0001032975-25-000059:notes:88]

[0001032975-25-000080:notes:90]
As of September 30, 2025, the Company's nominal share capital is CHF 40.2 million, consisting of 160,784,460 issued shares with a par value of CHF 0.25 each, of which 13,889,105 were held in treasury shares.

[0001032975-25-000080:notes:91]
The capital band under Swiss law allows a company's board of directors to adjust the company's share capital within a predefined range based on a general authority granted by the company's shareholders. At the 2023 Annual General Meeting ("AGM"), the Company's shareholders approved an amendment to the Company’s Articles of Incorporation to introduce a capital band provision authorizing the Board of Directors to adjust the Company's share capital, without additional shareholder approval, within a range of 155,795,958 registered shares to 190,417,282 registered shares for a five-year period ending on September 13, 2028. At the 2025 AGM, the Company's shareholders approved a renewal of the capital band, setting a new range of 144,706,014 registered shares to 176,862,906 registered shares for a five-year period ending on September 9, 2030. The amendment became effective on October 1, 2025.

[0001032975-25-000080:notes:92]
In addition, the Company has reserved conditional capital (1) up to 25,000,000 shares for potential issuance for the exercise of rights granted under the Company's employee equity incentive plans, and (2) up to 25,000,000 shares for issuance to cover any conversion rights under any potential future convertible bond issuance.

[0001032975-25-000080:notes:93]
[same as prior period, unchanged from 0001032975-25-000059:notes:91]

[0001032975-25-000080:notes:94]
In June 2023, the Company's Board of Directors approved a three-year share repurchase program, which allows the Company to use up to $1.0 billion to repurchase its shares. The 2023 share repurchase program enables the Company to repurchase shares for cancellation, as well as to support equity incentive plans or potential acquisitions. The Swiss Takeover Board approved the 2023 share repurchase program in July 2023 and the program became effective on July 28, 2023. In March 2025, the Company's Board of Directors approved an

[0001032975-25-000080:notes:95]
increase of $600.0 million to the 2023 share repurchase program, to an aggregate amount of $1.6 billion. The Swiss Takeover Board approved this increase in April 2025 and it became effective on April 2, 2025. As of September 30, 2025, $432.7 million was available for repurchase under the 2023 share repurchase program.

[0001032975-25-000080:notes:96]
The following table summarizes the Company's share repurchase activities for the six months ended September 30, 2025 and 2024 were as follows (in thousands):

[0001032975-25-000080:notes:97]
|  | Six Months Ended September 30, |
|  | 2025 |  | 2024 |
| 2023 Share Repurchase Program: |  |  |  |
| Number of shares repurchased (1) | 2,471 |  | 2,900 |
| Aggregate cost of shares repurchased (1) (2) | $ | 215,802 |  |  | $ | 262,119 |  |

[0001032975-25-000080:notes:98]
[same as prior period, unchanged from 0001032975-25-000059:notes:95]

[0001032975-25-000080:notes:99]
(2) Includes an aggregate cost of $6.3 million and $18.4 million, respectively, that was not yet paid as of September 30, 2025 and 2024.

[0001032975-25-000080:notes:100]
Swiss law limits a company’s ability to hold or repurchase its own shares. The aggregate par value of all shares held in treasury by the Company and its subsidiaries may not exceed 10% of the share capital of the Company, which for the Company corresponds to approximately 16.1 million registered shares as of September 30, 2025. This limitation does not apply to shares repurchased for cancellation, due to the Board of Directors’ authority under the Company’s capital band set forth in the Company’s Articles of Incorporation. As of September 30, 2025, the Company had a total of 13.9 million shares held in treasury stock, which includes 0.9 million shares that have been repurchased for cancellation and 13.0 million shares that have been purchased to support equity incentive plans or potential acquisitions.

[0001032975-25-000080:notes:101]
[same as prior period, unchanged from 0001032975-25-000059:notes:98]

[0001032975-25-000080:notes:102]
[same as prior period, unchanged from 0001032975-25-000059:notes:99]

[0001032975-25-000080:notes:103]
In June 2025, the Company's Board of Directors approved the cancellation of 8.2 million treasury shares, which were repurchased under the 2023 share repurchase program in fiscal year 2025 and the first quarter of fiscal year 2026, for an aggregate cost of $712.2 million. The cancellation became effective in the second quarter of fiscal year 2026, and as a result, both the number of registered shares issued and the number of treasury shares decreased by 8.2 million shares. Upon cancellation of these shares, the Company deducted the par value from registered shares and reflected the excess of share repurchase cost over par value as a reduction to retained earnings.

[0001032975-25-000080:notes:104]
Dividends

[0001032975-25-000080:notes:105]
During the three and six months ended September 30, 2025, the Company declared cash dividends of CHF 1.26 (USD equivalent of $1.58 based on the exchange rate on the date of declaration) per share and paid a total of $233.1 million on the Company's outstanding shares. During the three and six months ended September 30, 2024, the Company declared cash dividends of CHF 1.16 (USD equivalent of $1.37 based on the exchange rate on the date of declaration) per share and paid a total of $207.9 million on the Company's outstanding shares.

[0001032975-25-000080:notes:106]
Any future dividends will be subject to approval of the Company's shareholders.

[0001032975-25-000080:notes:107]
[same as prior period, unchanged from 0001032975-25-000059:notes:101]

[0001032975-25-000080:notes:108]
[same as prior period, unchanged from 0001032975-25-000059:notes:102]

[0001032975-25-000080:notes:109]
|  |  | Currency Translation Adjustment |  | Defined Benefit Plans |  | Deferred Hedging Losses |  | Total |
| March 31, 2025 |  | $ | (118,652) |  |  | $ | (25,276) |  |  | $ | (3,024) |  |  | $ | (146,952) |  |
| Other comprehensive income (loss) |  | 24,605 |  |  | (350) |  |  | (3,797) |  |  | 20,458 |  |
| September 30, 2025 |  | $ | (94,047) |  |  | $ | (25,626) |  |  | $ | (6,821) |  |  | $ | (126,494) |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-25-000080:notes:110]
[same as prior period, unchanged from 0001032975-25-000059:notes:104]

[0001032975-25-000080:notes:111]
[same as prior period, unchanged from 0001032975-25-000059:notes:105]

[0001032975-25-000080:notes:112]
[same as prior period, unchanged from 0001032975-25-000059:notes:106]

[0001032975-25-000080:notes:113]
|  | Three Months Ended September 30, |  | Six Months Ended September 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales | $ | 1,186,056 |  |  | $ | 1,116,034 |  |  | $ | 2,333,759 |  |  | $ | 2,204,251 |  |
| Less: Significant segment expenses |  |  |  |  |  |  |  |
| Cost of goods sold (1) | 666,059 |  |  | 623,589 |  |  | 1,330,271 |  |  | 1,240,508 |  |
| Marketing and selling (1) | 186,852 |  |  | 191,394 |  |  | 368,718 |  |  | 376,448 |  |
| Research and development (1) | 70,444 |  |  | 71,138 |  |  | 138,680 |  |  | 140,706 |  |
| General and administrative (1) | 32,656 |  |  | 37,142 |  |  | 64,286 |  |  | 71,383 |  |
| Less: other segment items |  |  |  |  |  |  |  |
| Share-based compensation expense | 30,312 |  |  | 26,469 |  |  | 63,140 |  |  | 49,874 |  |
| Amortization of intangible assets and acquisition-related costs | 4,000 |  |  | 5,177 |  |  | 8,795 |  |  | 10,322 |  |
| Interest income | (11,828) |  |  | (14,637) |  |  | (23,057) |  |  | (30,427) |  |
| Other (2) | 4,506 |  |  | (304) |  |  | 5,386 |  |  | 1,980 |  |
| Provision for income taxes | 32,385 |  |  | 30,583 |  |  | 60,855 |  |  | 56,141 |  |
| Net income | $ | 170,670 |  |  | $ | 145,483 |  |  | $ | 316,685 |  |  | $ | 287,316 |  |

[0001032975-25-000080:notes:114]
[same as prior period, unchanged from 0001032975-25-000059:notes:108]

[0001032975-25-000080:notes:115]
[same as prior period, unchanged from 0001032975-25-000059:notes:109]

[0001032975-25-000080:notes:116]
Sales by product category for the three and six months ended September 30, 2025 and 2024 were as follows (in thousands):

[0001032975-25-000080:notes:117]
|  |  | Three Months Ended September 30, |  | Six Months Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Gaming (1) |  | $ | 323,305 |  |  | $ | 300,470 |  |  | $ | 639,180 |  |  | $ | 609,945 |  |
| Keyboards & Combos |  | 235,870 |  |  | 209,936 |  |  | 458,362 |  |  | 425,269 |  |
| Pointing Devices |  | 221,094 |  |  | 195,936 |  |  | 416,874 |  |  | 385,882 |  |
| Video Collaboration |  | 167,677 |  |  | 159,660 |  |  | 334,393 |  |  | 306,702 |  |
| Webcams |  | 83,301 |  |  | 80,249 |  |  | 167,676 |  |  | 153,153 |  |
| Tablet Accessories |  | 85,061 |  |  | 85,614 |  |  | 176,288 |  |  | 164,153 |  |
| Headsets |  | 43,498 |  |  | 46,916 |  |  | 89,020 |  |  | 91,152 |  |
| Other (2) |  | 26,250 |  |  | 37,253 |  |  | 51,966 |  |  | 67,995 |  |
| Total Sales |  | $ | 1,186,056 |  |  | $ | 1,116,034 |  |  | $ | 2,333,759 |  |  | $ | 2,204,251 |  |

[0001032975-25-000080:notes:118]
[same as prior period, unchanged from 0001032975-25-000059:notes:112]

[0001032975-25-000080:notes:119]
[same as prior period, unchanged from 0001032975-25-000059:notes:113]

[0001032975-25-000080:notes:120]
Sales by geographic region (based on the customers’ locations) for the three and six months ended September 30, 2025 and 2024 were as follows (in thousands):

[0001032975-25-000080:notes:121]
|  |  | Three Months Ended September 30, |  | Six Months Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Americas |  | $ | 462,736 |  |  | $ | 480,081 |  |  | $ | 924,426 |  |  | $ | 965,370 |  |
| EMEA |  | 382,377 |  |  | 351,886 |  |  | 729,217 |  |  | 661,703 |  |
| Asia Pacific |  | 340,943 |  |  | 284,067 |  |  | 680,116 |  |  | 577,178 |  |
| Total Sales |  | $ | 1,186,056 |  |  | $ | 1,116,034 |  |  | $ | 2,333,759 |  |  | $ | 2,204,251 |  |

[0001032975-25-000080:notes:122]
Revenue from sales to customers in the United States, Germany and China each represented 10% or more of the total consolidated sales for each of the three and six months ended September 30, 2025 and 2024. No other countries represented 10% or more of the Company’s total consolidated sales for the periods presented herein.

[0001032975-25-000080:notes:123]
Switzerland, the Company’s country of domicile, represented 4% of the Company's total consolidated sales for each of the three and six months ended September 30, 2025, and 3% of the Company's total consolidated sales for each of the three and six months ended September 30, 2024.

[0001032975-25-000080:notes:124]
Three customers of the Company each represented 10% or more of the total consolidated gross sales for each of the three and six months ended September 30, 2025 and 2024.

[0001032975-25-000080:notes:125]
[same as prior period, unchanged from 0001032975-25-000059:notes:119]

[0001032975-25-000080:notes:126]
|  |  | September 30, 2025 |  | March 31, 2025 |
| Americas |  | $ | 61,779 |  |  | $ | 61,521 |  |
| EMEA |  | 50,919 |  |  | 47,874 |  |
| Asia Pacific |  | 65,792 |  |  | 60,710 |  |
| Total |  | $ | 178,490 |  |  | $ | 170,105 |  |

[0001032975-25-000080:notes:127]
Property, plant and equipment, net (excluding software) and right-of-use assets in the United States and China, were $60.2 million and $48.3 million, respectively, as of September 30, 2025. Property, plant and equipment, net (excluding software) and right-of-use assets in the United States and China were $60.0 million and $43.4 million, respectively, as of March 31, 2025. 
Property, plant and equipment, net (excluding software) and right-of-use assets in Switzerland, the Company’s country of domicile, were $25.9 million and $24.1 million as of September 30, 2025 and March 31, 2025, respectively. No other countries represented more than 10% of the Company’s total property, plant and equipment, net (excluding software) and right-of-use assets as of September 30, 2025 or March 31, 2025.
