# LOGI note change history — 0001032975-25-000059 → 0001032975-25-000080


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-10-29):
[0001032975-25-000080:note_history:1]
Changes in the Company’s warranty liabilities for the three and six months ended September 30, 2025 and 2024 were as follows (in thousands):
  (was, 2025-07-30, similarity 0.9243):
[0001032975-25-000059:note_history:1]
Changes in the Company’s warranty liabilities for the three months ended June 30, 2025 and 2024 were as follows (in thousands):

- added (2025-10-29):
[0001032975-25-000080:note_history:2]
|  | Three Months Ended September 30, |  | Six Months Ended September 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Beginning of the period | $ | 50,206 |  |  | $ | 44,502 |  |  | $ | 49,184 |  |  | $ | 44,654 |  |
| Provision | 10,372 |  |  | 11,776 |  |  | 18,994 |  |  | 21,962 |  |
| Settlements | (10,392) |  |  | (9,975) |  |  | (18,641) |  |  | (20,013) |  |
| Effects of foreign currency translation | 5 |  |  | 530 |  |  | 654 |  |  | 230 |  |
| End of the period | $ | 50,191 |  |  | $ | 46,833 |  |  | $ | 50,191 |  |  | $ | 46,833 |  |

- changed (2025-10-29):
[0001032975-25-000080:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2025, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2025-07-30, similarity 0.99):
[0001032975-25-000059:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2025, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

- removed (2025-10-29):
[0001032975-25-000059:note_history:4]
|  | Three Months Ended June 30, |
|  | 2025 |  | 2024 |
| Beginning of the period | $ | 49,184 |  |  | $ | 44,654 |  |
| Provision | 8,622 |  |  | 10,186 |  |
| Settlements | (8,249) |  |  | (10,038) |  |
| Effects of foreign currency translation | 649 |  |  | (300) |  |
| End of the period | $ | 50,206 |  |  | $ | 44,502 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-10-29):
[0001032975-25-000080:note_history:5]
The condensed consolidated financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States ("U.S. GAAP") for interim financial information and therefore do not include all the information required by U.S. GAAP for complete financial statements. The condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2025, included in the Company's Annual Report on Form 10-K filed with the Securities and Exchange Commission ("SEC") on May 23, 2025.
  (was, 2025-07-30, similarity 0.9907):
[0001032975-25-000059:note_history:5]
The condensed consolidated financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States ("U.S. GAAP") for interim financial information and therefore do not include all the information required by U.S. GAAP for complete financial statements. The condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2025, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission ("SEC") on May 23, 2025.

- changed (2025-10-29):
[0001032975-25-000080:note_history:6]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and six months ended September 30, 2025 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2026, or any future periods.
  (was, 2025-07-30, similarity 0.7702):
[0001032975-25-000059:note_history:6]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three months ended June 30, 2025 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2026, or any future periods.

- changed (2025-10-29):
[0001032975-25-000080:note_history:7]
There have been no material changes in the Company’s significant accounting policies during the three and six months ended September 30, 2025 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2025.
  (was, 2025-07-30, similarity 0.9091):
[0001032975-25-000059:note_history:7]
There have been no material changes in the Company’s significant accounting policies during the three months ended June 30, 2025 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2025.

- changed (2025-10-29):
[0001032975-25-000080:note_history:8]
In 2025, the United States introduced trade policy actions that have increased import tariffs across a wide range of countries at various rates, with certain exemptions. These tariff policies in the U.S. and responsive policies enacted in other countries are evolving. The incremental tariffs have had and may continue to have an adverse impact on the Company's results of operations. In addition, the Company's business has continued to be impacted by ongoing macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, uncertainty in consumer and enterprise demand, low economic growth in certain regions, changes in fiscal policies and geopolitical conflicts.
  (was, 2025-07-30, similarity 0.9993):
[0001032975-25-000059:note_history:8]
In 2025, the United States introduced trade policy actions that have increased import tariffs across a wide range of countries at various rates, with certain exemptions. These tariff policies in the U.S. and responsive policies enacted in other countries are evolving. The incremental tariffs have had and may continue to have an adverse impact on the Company's result of operations. In addition, the Company's business has continued to be impacted by ongoing macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, uncertainty in consumer and enterprise demand, low economic growth in certain regions, changes in fiscal policies and geopolitical conflicts.

- added (2025-10-29):
[0001032975-25-000080:note_history:9]
In July 2025, the FASB issued ASU No. 2025-05, Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets. ASU 2025-05 provides a practical expedient that permits entities to assume that current conditions as of the balance sheet date will remain unchanged over the remaining life of current accounts receivable and current contract assets when estimating the expected credit losses. ASU 2025-05 is effective for annual periods beginning after December 15, 2025, and interim periods within those annual reporting periods. Early adoption is permitted. ASU 2025-05 should be applied on a prospective basis. The Company is currently evaluating the impact of ASU 2025-05 on its consolidated financial statements and related disclosures.

- added (2025-10-29):
[0001032975-25-000080:note_history:10]
In September 2025, the FASB issued ASU No. 2025-06, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software. ASU 2025-06 updates the cost capitalization threshold for internal-use software development costs by removing all references to software project development stages and providing new guidance on how to evaluate whether the probable-to-complete recognition threshold has been met. ASU 2025-06 is effective for annual periods beginning after December 15, 2027, and interim periods within those annual reporting periods. Early adoption is permitted. ASU 2025-06 can be applied on a prospective basis, with retrospective or modified retrospective application permitted. The Company is currently evaluating the impact of ASU 2025-06 on its consolidated financial statements and related disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-10-29):
[0001032975-25-000080:note_history:11]
The Credit Agreement contains a maximum net debt to adjusted EBITDA ratio, compliance with which is a condition to the Company's ability to borrow. Borrowings under the Credit Agreement will bear interest at a rate determined by reference to benchmark rates plus an applicable spread (ranging from 0% to 1.5%) based on the Company's net leverage ratio or credit rating at the time of the borrowing. Undrawn balances available under the Credit Agreement are subject to commitment fees at the applicable rate determined by reference to the Company's net leverage ratio or credit rating. There has been no borrowing outstanding under the Credit Agreement as of September 30, 2025.
In addition, the Company had several uncommitted, unsecured bank lines of credit and letters of credit aggregating to $160.9 million and $172.2 million as of September 30, 2025 and March 31, 2025, respectively. There are no financial covenants under the lines of credit with which the Company must comply. There was no borrowing outstanding under the lines of credit as of September 30, 2025 or March 31, 2025. As of September 30, 2025 and March 31, 2025, the Company had outstanding bank guarantees of $11.7 million and $12.1 million, respectively.

- removed (2025-10-29):
[0001032975-25-000059:note_history:12]
The Credit Agreement contains a maximum net debt to adjusted EBITDA ratio, compliance with which is a condition to the Company's ability to borrow. Borrowings under the Credit Agreement will bear interest at a rate determined by reference to benchmark rates plus an applicable spread (ranging from 0% to 1.5%) based on the

- removed (2025-10-29):
[0001032975-25-000059:note_history:13]
Company's net leverage ratio or credit rating at the time of the borrowing. Undrawn balances available under the Credit Agreement are subject to commitment fees at the applicable rate determined by reference to the Company's net leverage ratio or credit rating. There has been no borrowing outstanding under the Credit Agreement as of June 30, 2025.
In addition, the Company had several uncommitted, unsecured bank lines of credit and letters of credit aggregating to $174.3 million and $172.2 million as of June 30, 2025 and March 31, 2025, respectively. There are no financial covenants under the lines of credit with which the Company must comply. There was no borrowing outstanding under the lines of credit as of June 30, 2025 or March 31, 2025. As of June 30, 2025 and March 31, 2025, the Company had outstanding bank guarantees of $22.1 million and $12.1 million, respectively.
