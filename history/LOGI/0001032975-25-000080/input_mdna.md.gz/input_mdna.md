# LOGI MD&A — 0001032975-25-000080


## mdna

[0001032975-25-000080:mdna:1]
[same as prior period, unchanged from 0001032975-25-000059:mdna:1]

[0001032975-25-000080:mdna:2]
[same as prior period, unchanged from 0001032975-25-000059:mdna:2]

[0001032975-25-000080:mdna:3]
[same as prior period, unchanged from 0001032975-25-000059:mdna:3]

[0001032975-25-000080:mdna:4]
•Changes in trade regulations, policies and agreements and the imposition of tariffs or other trade restrictions that affect our products or operations, including potential new tariffs that may be imposed on U.S. imports, and our ability to mitigate;

[0001032975-25-000080:mdna:5]
[same as prior period, unchanged from 0001032975-25-000059:mdna:5]

[0001032975-25-000080:mdna:6]
[same as prior period, unchanged from 0001032975-25-000059:mdna:6]

[0001032975-25-000080:mdna:7]
[same as prior period, unchanged from 0001032975-25-000059:mdna:7]

[0001032975-25-000080:mdna:8]
[same as prior period, unchanged from 0001032975-25-000059:mdna:8]

[0001032975-25-000080:mdna:9]
[same as prior period, unchanged from 0001032975-25-000059:mdna:9]

[0001032975-25-000080:mdna:10]
[same as prior period, unchanged from 0001032975-25-000059:mdna:10]

[0001032975-25-000080:mdna:11]
•Our expectations regarding our potential indemnification obligations, and the outcome of pending or future legal proceedings and tax audits;

[0001032975-25-000080:mdna:12]
[same as prior period, unchanged from 0001032975-25-000059:mdna:12]

[0001032975-25-000080:mdna:13]
[same as prior period, unchanged from 0001032975-25-000059:mdna:13]

[0001032975-25-000080:mdna:14]
[same as prior period, unchanged from 0001032975-25-000059:mdna:14]

[0001032975-25-000080:mdna:15]
[same as prior period, unchanged from 0001032975-25-000059:mdna:15]

[0001032975-25-000080:mdna:16]
[same as prior period, unchanged from 0001032975-25-000059:mdna:16]

[0001032975-25-000080:mdna:17]
[same as prior period, unchanged from 0001032975-25-000059:mdna:17]

[0001032975-25-000080:mdna:18]
[same as prior period, unchanged from 0001032975-25-000059:mdna:18]

[0001032975-25-000080:mdna:19]
[same as prior period, unchanged from 0001032975-25-000059:mdna:19]

[0001032975-25-000080:mdna:20]
[same as prior period, unchanged from 0001032975-25-000059:mdna:20]

[0001032975-25-000080:mdna:21]
[same as prior period, unchanged from 0001032975-25-000059:mdna:21]

[0001032975-25-000080:mdna:22]
[same as prior period, unchanged from 0001032975-25-000059:mdna:22]

[0001032975-25-000080:mdna:23]
[same as prior period, unchanged from 0001032975-25-000059:mdna:23]

[0001032975-25-000080:mdna:24]
In 2025, the United States introduced trade policy actions that have increased import tariffs across a wide range of countries at various rates, with certain exemptions. These tariff policies in the U.S. and responsive policies enacted in other countries are evolving. The incremental tariffs have had and may continue to have an adverse impact on our results of operations. In addition, our business has continued to be impacted by ongoing macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, uncertainty in consumer and enterprise demand, low economic growth in certain regions, changes in fiscal policies and geopolitical conflicts.

[0001032975-25-000080:mdna:25]
[same as prior period, unchanged from 0001032975-25-000059:mdna:25]

[0001032975-25-000080:mdna:26]
[same as prior period, unchanged from 0001032975-25-000059:mdna:26]

[0001032975-25-000080:mdna:27]
[same as prior period, unchanged from 0001032975-25-000059:mdna:27]

[0001032975-25-000080:mdna:28]
[same as prior period, unchanged from 0001032975-25-000059:mdna:28]

[0001032975-25-000080:mdna:29]
[same as prior period, unchanged from 0001032975-25-000059:mdna:29]

[0001032975-25-000080:mdna:30]
[same as prior period, unchanged from 0001032975-25-000059:mdna:30]

[0001032975-25-000080:mdna:31]
[same as prior period, unchanged from 0001032975-25-000059:mdna:31]

[0001032975-25-000080:mdna:32]
While we believe we will further benefit from these secular trends, we have experienced and will continue to experience challenges that impact our business and financial results. These challenges include (i) uncertainty in tariffs on goods imported into the U.S. and responsive policies enacted by other countries, (ii) the macroeconomic environment, including inflation, interest rate and foreign currency fluctuations, low economic growth in certain regions, changes in fiscal policies and geopolitical conflicts, (iii) the uncertainty of overall consumer and enterprise demand, (iv) the uncertainty of timing of enterprise investments in infrastructure and technology, and (v) the timing of further development of our B2B go-to-market capabilities.

[0001032975-25-000080:mdna:33]
[same as prior period, unchanged from 0001032975-25-000059:mdna:34]

[0001032975-25-000080:mdna:34]
[same as prior period, unchanged from 0001032975-25-000059:mdna:35]

[0001032975-25-000080:mdna:35]
[same as prior period, unchanged from 0001032975-25-000059:mdna:36]

[0001032975-25-000080:mdna:36]
[same as prior period, unchanged from 0001032975-25-000059:mdna:37]

[0001032975-25-000080:mdna:37]
[same as prior period, unchanged from 0001032975-25-000059:mdna:38]

[0001032975-25-000080:mdna:38]
Our sales were $1,186.1 million and $2,333.8 million for the three and six months ended September 30, 2025, respectively, an increase of 6% compared to $1,116.0 million and $2,204.3 million for the three and six months ended September 30, 2024, respectively, primarily due to an increase in sales for Keyboards & Combos, Pointing Devices, and Gaming. Our sales for the three and six months ended September 30, 2025, compared to the same periods ended September 30, 2024, benefited from improved demand in the Asia Pacific and EMEA regions.

[0001032975-25-000080:mdna:39]
Sales for the three months ended September 30, 2025 increased 20% and 9% in the Asia Pacific and EMEA regions, respectively, and decreased 4% in the Americas region, compared to the three months ended September 30, 2024. Sales for the six months ended September 30, 2025 increased 18% and 10% in the Asia Pacific and EMEA regions, respectively, and decreased 4% in the Americas region, compared to the six months ended September 30, 2024.

[0001032975-25-000080:mdna:40]
Gross margin was 43.4% for the three months ended September 30, 2025 and decreased by 20 basis points, compared to the three months ended September 30, 2024. Gross margin was 42.6% for the six months ended September 30, 2025 and decreased by 60 basis points, compared to the six months ended September 30, 2024. The decrease in gross margin for both the three-month and six-month periods was primarily driven by higher promotional spend and increased tariffs, partially offset by favorable impacts from product cost reductions and price increases in North America.

[0001032975-25-000080:mdna:41]
Operating expenses for the three months ended September 30, 2025 were $323.2 million, or 27.2% of sales, compared to $325.2 million, or 29.1% of sales, for the three months ended September 30, 2024. Operating expenses for the six months ended September 30, 2025 were $640.0 million, or 27.4% of sales, compared to $638.0 million, or 28.9% of sales, for the six months ended September 30, 2024.

[0001032975-25-000080:mdna:42]
We had an income tax provision of $32.4 million and $30.6 million for the three months ended September 30, 2025 and 2024, respectively. We had an income tax provision of $60.9 million and $56.1 million for the six months ended September 30, 2025 and 2024, respectively.

[0001032975-25-000080:mdna:43]
Net income for the three and six months ended September 30, 2025 was $170.7 million and $316.7 million, respectively, compared to $145.5 million and $287.3 million, for the three and six months ended September 30, 2024, respectively.

[0001032975-25-000080:mdna:44]
[same as prior period, unchanged from 0001032975-25-000059:mdna:45]

[0001032975-25-000080:mdna:45]
[same as prior period, unchanged from 0001032975-25-000059:mdna:46]

[0001032975-25-000080:mdna:46]
[same as prior period, unchanged from 0001032975-25-000059:mdna:47]

[0001032975-25-000080:mdna:47]
[same as prior period, unchanged from 0001032975-25-000059:mdna:48]

[0001032975-25-000080:mdna:48]
We believe that the assumptions, judgments and estimates involved in the accounting for accruals for customer incentives and related breakage, accrued sales return liability, inventory valuation, and uncertain tax positions, have the greatest potential impact on our condensed consolidated financial statements. These areas are key components of our results of operations and are based on complex rules requiring us to make judgments and estimates and consequently, we consider these to be our critical accounting policies.

[0001032975-25-000080:mdna:49]
There have been no material changes in our critical accounting estimates during the six months ended September 30, 2025 compared with the critical accounting estimates disclosed in Management's Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended March 31, 2025.

[0001032975-25-000080:mdna:50]
[same as prior period, unchanged from 0001032975-25-000059:mdna:52]

[0001032975-25-000080:mdna:51]
[same as prior period, unchanged from 0001032975-25-000059:mdna:53]

[0001032975-25-000080:mdna:52]
[same as prior period, unchanged from 0001032975-25-000059:mdna:54]

[0001032975-25-000080:mdna:53]
[same as prior period, unchanged from 0001032975-25-000059:mdna:55]

[0001032975-25-000080:mdna:54]
[same as prior period, unchanged from 0001032975-25-000059:mdna:56]

[0001032975-25-000080:mdna:55]
[same as prior period, unchanged from 0001032975-25-000059:mdna:57]

[0001032975-25-000080:mdna:56]
[same as prior period, unchanged from 0001032975-25-000059:mdna:58]

[0001032975-25-000080:mdna:57]
[same as prior period, unchanged from 0001032975-25-000059:mdna:59]

[0001032975-25-000080:mdna:58]
[same as prior period, unchanged from 0001032975-25-000059:mdna:60]

[0001032975-25-000080:mdna:59]
Our sales for the three and six months ended September 30, 2025 increased 6%, compared to the three and six months ended September 30, 2024, primarily due to an increase in sales for Keyboards & Combos, Pointing Devices, and Gaming. Our sales for the three and six months ended September 30, 2025, compared to the same periods ended September 30, 2024, benefited from improved demand in the Asia Pacific and EMEA regions. If currency exchange rates had been constant in the three and six months ended September 30, 2025 and 2024, our sales growth rates in constant currency would have been 4% for both the three-month and six-month periods.

[0001032975-25-000080:mdna:60]
[same as prior period, unchanged from 0001032975-25-000059:mdna:62]

[0001032975-25-000080:mdna:61]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Australian Dollar, Canadian Dollar, Pound Sterling and Brazilian Real. During the three months ended September 30, 2025, approximately 53% of our sales were denominated in currencies other than the U.S. Dollar.

[0001032975-25-000080:mdna:62]
[same as prior period, unchanged from 0001032975-25-000059:mdna:64]

[0001032975-25-000080:mdna:63]
The following table presents the change in sales by region for the three and six months ended September 30, 2025, compared with the three and six months ended September 30, 2024:

[0001032975-25-000080:mdna:64]
|  |  | Sales Growth Rate |  | Constant DollarSales Growth Rate |
|  |  | Three Months EndedSeptember 30, 2025 |  | Six Months EndedSeptember 30, 2025 |  | Three Months EndedSeptember 30, 2025 |  | Six Months EndedSeptember 30, 2025 |
| Americas |  | (4)% |  | (4)% |  | (4)% |  | (4)% |
| EMEA |  | 9% |  | 10% |  | 3% |  | 5% |
| Asia Pacific |  | 20% |  | 18% |  | 19% |  | 17% |

[0001032975-25-000080:mdna:65]
[same as prior period, unchanged from 0001032975-25-000059:mdna:67]

[0001032975-25-000080:mdna:66]
The decrease in sales in the Americas region for the three-month period presented above was primarily driven by a decrease in sales for Gaming and Tablet Accessories, offset by an increase in sales for Pointing Devices. The decrease in sales in the Americas region for the six-month period presented above was primarily driven by a decrease in sales for Gaming. The decline in Gaming sales in both the three-month and six-month periods resulted mainly from the competitive pricing environment in North America.

[0001032975-25-000080:mdna:67]
[same as prior period, unchanged from 0001032975-25-000059:mdna:69]

[0001032975-25-000080:mdna:68]
The increase in sales in the EMEA region for the three-month period presented above was primarily driven by an increase in sales for Keyboards & Combos, Pointing Devices, and Video Collaboration. The increase in sales in the EMEA region for the six-month period presented above was primarily driven by an increase in sales for Keyboards & Combos, Video Collaboration, Pointing Devices, and Gaming.

[0001032975-25-000080:mdna:69]
[same as prior period, unchanged from 0001032975-25-000059:mdna:71]

[0001032975-25-000080:mdna:70]
The increase in sales in the Asia Pacific region for the three and six-month period presented above was primarily driven by an increase in sales for Gaming and Tablet Accessories.

[0001032975-25-000080:mdna:71]
[same as prior period, unchanged from 0001032975-25-000059:mdna:73]

[0001032975-25-000080:mdna:72]
Sales by product category for the three and six months ended September 30, 2025 and 2024 were as follows (Dollars in thousands):

[0001032975-25-000080:mdna:73]
|  |  | Three Months Ended September 30, |  | Six Months Ended September 30, |
|  |  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
| Gaming (1) |  | $ | 323,305 |  |  | $ | 300,470 |  |  | 8 | % |  | $ | 639,180 |  |  | $ | 609,945 |  |  | 5 | % |
| Keyboards & Combos |  | 235,870 |  |  | 209,936 |  |  | 12 |  |  | 458,362 |  |  | 425,269 |  |  | 8 |  |
| Pointing Devices |  | 221,094 |  |  | 195,936 |  |  | 13 |  |  | 416,874 |  |  | 385,882 |  |  | 8 |  |
| Video Collaboration |  | 167,677 |  |  | 159,660 |  |  | 5 |  |  | 334,393 |  |  | 306,702 |  |  | 9 |  |
| Webcams |  | 83,301 |  |  | 80,249 |  |  | 4 |  |  | 167,676 |  |  | 153,153 |  |  | 9 |  |
| Tablet Accessories |  | 85,061 |  |  | 85,614 |  |  | (1) |  |  | 176,288 |  |  | 164,153 |  |  | 7 |  |
| Headsets |  | 43,498 |  |  | 46,916 |  |  | (7) |  |  | 89,020 |  |  | 91,152 |  |  | (2) |  |
| Other (2) |  | 26,250 |  |  | 37,253 |  |  | (30) |  |  | 51,966 |  |  | 67,995 |  |  | (24) |  |
| Total Sales |  | $ | 1,186,056 |  |  | $ | 1,116,034 |  |  | 6 | % |  | $ | 2,333,759 |  |  | $ | 2,204,251 |  |  | 6 | % |

[0001032975-25-000080:mdna:74]
[same as prior period, unchanged from 0001032975-25-000059:mdna:76]

[0001032975-25-000080:mdna:75]
[same as prior period, unchanged from 0001032975-25-000059:mdna:77]

[0001032975-25-000080:mdna:76]
[same as prior period, unchanged from 0001032975-25-000059:mdna:78]

[0001032975-25-000080:mdna:77]
[same as prior period, unchanged from 0001032975-25-000059:mdna:79]

[0001032975-25-000080:mdna:78]
Sales of Gaming increased 8% and 5% for the three and six months ended September 30, 2025, compared to the three and six months ended September 30, 2024, respectively, primarily driven by an increase in sales of gaming mice, partially offset by decreases in other gaming products.

[0001032975-25-000080:mdna:79]
[same as prior period, unchanged from 0001032975-25-000059:mdna:81]

[0001032975-25-000080:mdna:80]
[same as prior period, unchanged from 0001032975-25-000059:mdna:82]

[0001032975-25-000080:mdna:81]
Sales of Keyboards & Combos increased 12% and 8% for the three and six months ended September 30, 2025, compared to the three and six months ended September 30, 2024, respectively, primarily driven by an increase in sales of cordless combo products.

[0001032975-25-000080:mdna:82]
[same as prior period, unchanged from 0001032975-25-000059:mdna:84]

[0001032975-25-000080:mdna:83]
[same as prior period, unchanged from 0001032975-25-000059:mdna:85]

[0001032975-25-000080:mdna:84]
Sales of Pointing Devices increased 13% and 8% for the three and six months ended September 30, 2025, compared to the three and six months ended September 30, 2024, respectively, primarily driven by an increase in sales of cordless mice.

[0001032975-25-000080:mdna:85]
[same as prior period, unchanged from 0001032975-25-000059:mdna:87]

[0001032975-25-000080:mdna:86]
[same as prior period, unchanged from 0001032975-25-000059:mdna:88]

[0001032975-25-000080:mdna:87]
Sales of Video Collaboration increased 5% and 9% for the three and six months ended September 30, 2025, compared to the three and six months ended September 30, 2024, respectively, primarily due to an increase in sales of conference room cameras.

[0001032975-25-000080:mdna:88]
[same as prior period, unchanged from 0001032975-25-000059:mdna:90]

[0001032975-25-000080:mdna:89]
Our Webcams category includes PC-based webcams including streaming cameras and VC webcams that turn any desktop into an instant collaboration space.

[0001032975-25-000080:mdna:90]
Sales of Webcams increased 4% and 9% for the three and six months ended September 30, 2025, compared to the three and six months ended September 30, 2024, respectively, primarily driven by an increase in sales of our PC-based webcams, partially offset by a decrease in sales of our VC webcams and streaming cameras.

[0001032975-25-000080:mdna:91]
[same as prior period, unchanged from 0001032975-25-000059:mdna:93]

[0001032975-25-000080:mdna:92]
[same as prior period, unchanged from 0001032975-25-000059:mdna:94]

[0001032975-25-000080:mdna:93]
Sales of Tablet Accessories remained relatively flat for the three months ended September 30, 2025, compared to the three months ended September 30, 2024. Sales of Tablet Accessories increased 7% for the six months ended September 30, 2025, compared to the six months ended September 30, 2024, primarily benefiting from strong demand from the education sector.

[0001032975-25-000080:mdna:94]
[same as prior period, unchanged from 0001032975-25-000059:mdna:96]

[0001032975-25-000080:mdna:95]
[same as prior period, unchanged from 0001032975-25-000059:mdna:97]

[0001032975-25-000080:mdna:96]
Sales of Headsets decreased 7% and 2% for the three and six months ended September 30, 2025, compared to the three and six months ended September 30, 2024, respectively, primarily driven by a decrease in sales of corded PC headsets.

[0001032975-25-000080:mdna:97]
[same as prior period, unchanged from 0001032975-25-000059:mdna:99]

[0001032975-25-000080:mdna:98]
[same as prior period, unchanged from 0001032975-25-000059:mdna:100]

[0001032975-25-000080:mdna:99]
Sales in Other category decreased 30% and 24% for the three and six months ended September 30, 2025, respectively, compared to the three and six months ended September 30, 2024, primarily driven by a decline in sales of mobile speakers.

[0001032975-25-000080:mdna:100]
[same as prior period, unchanged from 0001032975-25-000059:mdna:102]

[0001032975-25-000080:mdna:101]
Gross profit for the three and six months ended September 30, 2025 and 2024 was as follows (Dollars in thousands):

[0001032975-25-000080:mdna:102]
|  |  | Three Months Ended September 30, |  | Six Months Ended September 30, |
|  |  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
| Net sales |  | $ | 1,186,056 |  | $ | 1,116,034 |  | 6 | % |  | $ | 2,333,759 |  | $ | 2,204,251 |  | 6 | % |
| Gross profit |  | $ | 514,456 |  | $ | 486,091 |  | 6 | % |  | $ | 993,418 |  | $ | 952,349 |  | 4 | % |
| Gross margin |  | 43.4 | % |  | 43.6 | % |  |  |  | 42.6 | % |  | 43.2 | % |  |  |

[0001032975-25-000080:mdna:103]
[same as prior period, unchanged from 0001032975-25-000059:mdna:105]

[0001032975-25-000080:mdna:104]
Gross margin was 43.4% for the three months ended September 30, 2025 and decreased by 20 basis points, compared to the three months ended September 30, 2024. Gross margin was 42.6% for the six months ended September 30, 2025 and decreased by 60 basis points, compared to the six months ended September 30, 2024. The decrease in gross margin for both the three-month and six-month periods was primarily driven by higher promotional spend and increased tariffs, partially offset by favorable impacts from product cost reductions and price increases in North America.

[0001032975-25-000080:mdna:105]
[same as prior period, unchanged from 0001032975-25-000059:mdna:107]

[0001032975-25-000080:mdna:106]
Operating expenses for the three and six months ended September 30, 2025 and 2024 were as follows (Dollars in thousands):

[0001032975-25-000080:mdna:107]
|  |  | Three Months Ended September 30, |  | Six Months Ended September 30, |  |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |
| Marketing and selling |  | $ | 198,993 |  |  | $ | 201,863 |  |  | $ | 394,789 |  |  | $ | 398,768 |  |  |
| % of sales |  | 16.8 | % |  | 18.1 | % |  | 16.9 | % |  | 18.1 | % |  |
| Research and development |  | 76,110 |  |  | 76,205 |  |  | 150,697 |  |  | 151,512 |  |  |
| % of sales |  | 6.4 | % |  | 6.8 | % |  | 6.5 | % |  | 6.9 | % |  |
| General and administrative |  | 41,802 |  |  | 44,173 |  |  | 83,599 |  |  | 81,631 |  |  |
| % of sales |  | 3.5 | % |  | 4.0 | % |  | 3.6 | % |  | 3.7 | % |  |
| Amortization of intangible assets and acquisition-related costs |  | 1,818 |  |  | 2,725 |  |  | 4,464 |  |  | 5,428 |  |  |
| % of sales |  | 0.1 | % |  | 0.2 | % |  | 0.1 | % |  | 0.2 | % |  |
| Restructuring charges, net |  | 4,442 |  |  | 229 |  |  | 6,484 |  |  | 615 |  |  |
| % of sales |  | 0.4 | % |  | — | % |  | 0.3 | % |  | — | % |  |
| Total operating expenses |  | $ | 323,165 |  |  | $ | 325,195 |  |  | $ | 640,033 |  |  | $ | 637,954 |  |  |
| % of sales |  | 27.2 | % |  | 29.1 | % |  | 27.4 | % |  | 28.9 | % |  |

[0001032975-25-000080:mdna:108]
Operating expenses remained relatively flat during the three and six months ended September 30, 2025, compared to the three and six months ended September 30, 2024, reflecting our efforts to reduce operating expenses in order to offset higher tariff costs.

[0001032975-25-000080:mdna:109]
[same as prior period, unchanged from 0001032975-25-000059:mdna:111]

[0001032975-25-000080:mdna:110]
[same as prior period, unchanged from 0001032975-25-000059:mdna:112]

[0001032975-25-000080:mdna:111]
During the three and six months ended September 30, 2025, marketing and selling expenses remained relatively flat, compared to the three and six months ended September 30, 2024, respectively.

[0001032975-25-000080:mdna:112]
[same as prior period, unchanged from 0001032975-25-000059:mdna:114]

[0001032975-25-000080:mdna:113]
[same as prior period, unchanged from 0001032975-25-000059:mdna:115]

[0001032975-25-000080:mdna:114]
During the three and six months ended September 30, 2025, research and development expenses remained relatively flat, as we continued to invest in innovation at a similar level as compared to the three and six months ended September 30, 2024, respectively.

[0001032975-25-000080:mdna:115]
[same as prior period, unchanged from 0001032975-25-000059:mdna:117]

[0001032975-25-000080:mdna:116]
[same as prior period, unchanged from 0001032975-25-000059:mdna:118]

[0001032975-25-000080:mdna:117]
During the three months ended September 30, 2025, general and administrative expenses decreased $2.4 million, compared to the three months ended September 30, 2024, primarily driven by lower third-party spend resulting from our cost saving efforts. During the six months ended September 30, 2025, general and administrative expenses increased $2.0 million, compared to the six months ended September 30, 2024, primarily driven by higher performance-based stock compensation expense, partially offset by lower third-party spend.

[0001032975-25-000080:mdna:118]
[same as prior period, unchanged from 0001032975-25-000059:mdna:120]

[0001032975-25-000080:mdna:119]
[same as prior period, unchanged from 0001032975-25-000059:mdna:121]

[0001032975-25-000080:mdna:120]
During the three and six months ended September 30, 2025, amortization of intangible assets and acquisition-related costs decreased $0.9 million and $1.0 million, respectively, compared to the three and six months ended September 30, 2024, driven by full amortization of certain intangible assets.

[0001032975-25-000080:mdna:121]
[same as prior period, unchanged from 0001032975-25-000059:mdna:123]

[0001032975-25-000080:mdna:122]
The restructuring charges, net, for the three and six months ended September 30, 2025 were related to costs incurred as a result of our restructuring plan initiated during the fourth quarter of fiscal year 2025, which is expected to be substantially completed in fiscal 2026. The restructuring charges, net, for the three and six months ended September 30, 2024, were related to costs incurred as a result of our restructuring plan initiated during fiscal year 2023, which was substantially completed during fiscal year 2024.

[0001032975-25-000080:mdna:123]
[same as prior period, unchanged from 0001032975-25-000059:mdna:125]

[0001032975-25-000080:mdna:124]
Interest income for the three and six months ended September 30, 2025 and 2024 was as follows (in thousands):

[0001032975-25-000080:mdna:125]
|  |  | Three Months Ended September 30, |  | Six Months Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Interest income |  | $ | 11,828 |  |  | $ | 14,637 |  |  | $ | 23,057 |  |  | $ | 30,427 |  |

[0001032975-25-000080:mdna:126]
We invest in highly liquid instruments with an original maturity of three months or less at the date of purchase, which are classified as cash equivalents. During the three and six months ended September 30, 2025, interest income decreased $2.8 million and $7.4 million, respectively, compared to the three and six months ended September 30, 2024, primarily driven by a decrease in interest rates.

[0001032975-25-000080:mdna:127]
[same as prior period, unchanged from 0001032975-25-000059:mdna:129]

[0001032975-25-000080:mdna:128]
Other income (expense), net, for the three and six months ended September 30, 2025 and 2024 was as follows (in thousands):

[0001032975-25-000080:mdna:129]
|  |  | Three Months Ended September 30, |  | Six Months Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Investment gain related to the deferred compensation plan |  | $ | 1,890 |  |  | $ | 1,613 |  |  | $ | 3,950 |  |  | $ | 2,060 |  |
| Currency exchange loss, net |  | (3,110) |  |  | (1,473) |  |  | (5,113) |  |  | (3,791) |  |
| Loss on investments, net |  | (104) |  |  | (413) |  |  | (497) |  |  | (1,599) |  |
| Non-service cost net pension income and other |  | 1,260 |  |  | 806 |  |  | 2,758 |  |  | 1,965 |  |
| Total |  | $ | (64) |  |  | $ | 533 |  |  | $ | 1,098 |  |  | $ | (1,365) |  |

[0001032975-25-000080:mdna:130]
Investment gain related to the deferred compensation plan represents earnings, gains, and losses on marketable securities related to a deferred compensation plan offered by one of our subsidiaries. The increase in investment gain for three and six months ended September 30, 2025, compared to the three and six months ended September 30, 2024, primarily relates to the change in market performance of the underlying securities.

[0001032975-25-000080:mdna:131]
Currency exchange loss, net, relates to balances denominated in currencies other than the functional currency in our subsidiaries, as well as the sale of currencies, and gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses. The loss for the three and six months ended

[0001032975-25-000080:mdna:132]
September 30, 2025 was primarily due to fluctuations in currency exchange rates of the New Taiwan dollar and Swiss Franc against the U.S. Dollar. The loss for the three months ended September 30, 2024 was primarily due to fluctuations in the currency exchange rates of the Chinese Renminbi against the U.S. Dollar. The loss for the six months ended September 30, 2024 was primarily due to fluctuations in currency exchange rates of the Chinese Renminbi and Mexican Peso against the U.S. Dollar.

[0001032975-25-000080:mdna:133]
Loss on investments, net, includes unrealized gain (loss) from the change in fair value of investments, income (loss) on equity-method investments and impairment of investments during the periods presented, as applicable. The loss on investments, net, for the three and six months ended September 30, 2025 and 2024 were not material.

[0001032975-25-000080:mdna:134]
[same as prior period, unchanged from 0001032975-25-000059:mdna:135]

[0001032975-25-000080:mdna:135]
The provision for income taxes and effective income tax rates for the three and six months ended September 30, 2025 and 2024 were as follows (Dollars in thousands):

[0001032975-25-000080:mdna:136]
|  |  | Three Months Ended September 30, |  | Six Months Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Provision for income taxes |  | $ | 32,385 |  |  | $ | 30,583 |  |  | $ | 60,855 |  |  | $ | 56,141 |  |
| Effective income tax rate |  | 15.9 | % |  | 17.4 | % |  | 16.1 | % |  | 16.3 | % |

[0001032975-25-000080:mdna:137]
The change in the effective income tax rate for the three and six months ended September 30, 2025, compared with the three and six months ended September 30, 2024, was primarily due to the change in the mix of income and losses in the various tax jurisdictions in which we operate and less tax incentives for foreign derived intangible income and R&D as compared to prior period, offset by return to provision adjustments.

[0001032975-25-000080:mdna:138]
On July 4, 2025, the One Big Beautiful Bill Act (the "OBBBA") was enacted into law in the United States and will be generally effective for us beginning in fiscal year 2027. The OBBBA includes numerous provisions that affect corporate taxation, impacting areas such as R&D expensing, bonus depreciation, and international tax provisions. We have reviewed the provisions of the OBBBA to determine the potential impact on our financial statements. Based on this review, and considering our current tax position and operations, at this time we do not expect the OBBBA to have a material impact on our income taxes, including current and deferred tax balances and the effective tax rate. However, we are still in the process of evaluating the full impact of the OBBBA and any material changes to our assessment will be disclosed in future filings as required.

[0001032975-25-000080:mdna:139]
For the three months ended September 30, 2025, we assessed our exposure to the OECD Pillar Two global minimum tax rules. We have determined that, for the fiscal year 2026, most jurisdictions in which we operate should qualify for the transitional Country-by-Country Reporting ("CbCR") safe harbor, as outlined in the OECD Administrative Guidance and enacted domestic legislation. Our CbCR has been prepared in accordance with the requirements for a Qualified CbCR, using qualified financial statements. Based on this data, most jurisdictions continue to meet safe harbor qualifications at 16% tax rates, and therefore, we are only required to perform a detailed Pillar Two top-up tax calculation for limited jurisdictions. The estimated top up tax for fiscal year 2026 is not material and has been included in the calculation of our annual effective tax rate. The OECD and participating countries continue to issue underlying rules and administrative guidance related to Pillar Two, and we continue to monitor the relevant developments.

[0001032975-25-000080:mdna:140]
[same as prior period, unchanged from 0001032975-25-000059:mdna:142]

[0001032975-25-000080:mdna:141]
[same as prior period, unchanged from 0001032975-25-000059:mdna:143]

[0001032975-25-000080:mdna:142]
As of September 30, 2025, we had cash and cash equivalents of $1,375.8 million, compared with $1,503.2 million as of March 31, 2025. Our cash and cash equivalents consist of bank demand deposits, short-term time deposits, and U.S. Treasury securities, of which 44% was held in the United States and 31% was held in Switzerland. We do not expect to incur any material adverse tax impact except for what has already been recognized, or to be significantly inhibited by any country in which we do business, from the repatriation of funds to Switzerland, our country of domicile.

[0001032975-25-000080:mdna:143]
As of September 30, 2025, our working capital was $1,468.4 million, compared to $1,491.6 million as of March 31, 2025. The decrease was primarily driven by an increase in accounts payable and a decrease in cash and cash equivalents, partially offset by an increase in accounts receivable and other current assets.

[0001032975-25-000080:mdna:144]
On January 27, 2025, we entered into an unsecured revolving credit facility with a syndicate of banks (the "Credit Agreement"). The Credit Agreement provides a revolving line of credit of up to $750.0 million including the issuance of letters of credit of up to $100.0 million. The Credit Agreement terminates on January 27, 2030 unless extended in accordance with its terms. The Credit Agreement contains (1) an increase option allowing us to secure up to $250.0 million of additional commitments and (2) an extension option to extend the term by one-year which may be exercised no more than two times, subject to certain requirements. Loans under the Credit Agreement are available in U.S. Dollars, Euro, Sterling, Yen, Swiss Francs, Canadian Dollars, Australian Dollars and any other currency agreed to by each lender. Proceeds of loans made under the Credit Agreement may be used for general corporate purposes.

[0001032975-25-000080:mdna:145]
The Credit Agreement contains a maximum net debt to adjusted EBITDA ratio, compliance with which is a condition to our ability to borrow. Borrowings under the Credit Agreement will bear interest at a rate determined by reference to benchmark rates plus an applicable spread (ranging from 0% to 1.5%) based on our net leverage ratio or credit rating at the time of the borrowing. Undrawn balances available under the Credit Agreement are subject to commitment fees at the applicable rate determined by reference to our net leverage ratio or credit rating. There has been no borrowing outstanding under the Credit Agreement as of September 30, 2025.

[0001032975-25-000080:mdna:146]
In addition, we had several uncommitted, unsecured bank lines of credit and letters of credit aggregating to $160.9 million as of September 30, 2025. There are no financial covenants under these lines of credit with which we must comply. There was no borrowing outstanding under these lines of credit as of September 30, 2025. As of September 30, 2025, we had outstanding bank guarantees of $11.7 million.

[0001032975-25-000080:mdna:147]
The following tables present selected financial information and statistics as of and for the three months ended September 30, 2025 and 2024 (Dollars in thousands):

[0001032975-25-000080:mdna:148]
|  |  | As of September 30, |  |
|  |  | 2025 |  | 2024 |  |
| Accounts receivable, net |  | $ | 703,895 |  |  | $ | 629,278 |  |  |
| Accounts payable |  | $ | 583,308 |  |  | $ | 555,490 |  |  |
| Inventories |  | $ | 517,673 |  |  | $ | 520,493 |  |  |

[0001032975-25-000080:mdna:149]
|  |  | Three Months Ended September 30, |  |
|  |  | 2025 |  | 2024 |  |
| Days sales in accounts receivable (“DSO”) (Days)(1) |  | 53 |  |  | 51 |  |  |
| Days accounts payable outstanding (“DPO”) (Days)(2) |  | 78 |  |  | 79 |  |  |
| Inventory turnover (“ITO”) (x)(3) |  | 5.2 |  |  | 4.8 |  |  |

[0001032975-25-000080:mdna:150]
[same as prior period, unchanged from 0001032975-25-000059:mdna:152]

[0001032975-25-000080:mdna:151]
[same as prior period, unchanged from 0001032975-25-000059:mdna:153]

[0001032975-25-000080:mdna:152]
[same as prior period, unchanged from 0001032975-25-000059:mdna:154]

[0001032975-25-000080:mdna:153]
DSO for the three months ended September 30, 2025 increased by 2 days to 53 days, compared to 51 days for the three months ended September 30, 2024, primarily due to timing of sales within the quarter.

[0001032975-25-000080:mdna:154]
DPO for the three months ended September 30, 2025 decreased by 1 day to 78 days, compared to 79 days for the three months ended September 30, 2024, primarily due to improved demand which drove higher inventory purchases.

[0001032975-25-000080:mdna:155]
ITO for the three months ended September 30, 2025 increased by 0.4 to 5.2, compared to 4.8 for the three months ended September 30, 2024, primarily due to improved demand.

[0001032975-25-000080:mdna:156]
[same as prior period, unchanged from 0001032975-25-000059:mdna:158]

[0001032975-25-000080:mdna:157]
[same as prior period, unchanged from 0001032975-25-000059:mdna:159]

[0001032975-25-000080:mdna:158]
|  |  | Six Months Ended September 30, |
|  |  | 2025 |  | 2024 |
| Net cash provided by operating activities |  | $ | 353,882 |  |  | $ | 342,031 |  |
| Net cash used in investing activities |  | (34,294) |  |  | (31,326) |  |
| Net cash used in financing activities |  | (457,820) |  |  | (474,954) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | 10,834 |  |  | 6,683 |  |
| Net decrease in cash and cash equivalents |  | $ | (127,398) |  |  | $ | (157,566) |  |

[0001032975-25-000080:mdna:159]
For the six months ended September 30, 2025, net cash provided by operating activities was $353.9 million resulting from net income of $316.7 million, a favorable impact from adding back non-cash expenses totaling $125.6 million, partially offset by an unfavorable net change in operating assets and liabilities of $88.4 million. Non-cash adjustments were primarily related to share-based compensation expenses, depreciation and amortization, and deferred income taxes. The increase in accounts receivable, net, was primarily driven by higher sales as well as timing of sales within the quarter. The increase in accounts payable was driven by higher inventory purchases to align with demand as well as timing of inventory purchases.

[0001032975-25-000080:mdna:160]
For the six months ended September 30, 2025, net cash used in investing activities was $34.3 million, primarily resulting from $32.8 million of purchases of property, plant, and equipment.

[0001032975-25-000080:mdna:161]
For the six months ended September 30, 2025, net cash used in financing activities was $457.8 million, primarily resulting from payment of cash dividends of $233.1 million and payment for repurchases of our registered shares of $228.3 million.

[0001032975-25-000080:mdna:162]
For the six months ended September 30, 2025, the effect of exchange rate changes on cash and cash equivalents was primarily driven by the exchange rate fluctuations of Swiss Franc, Chinese Renminbi, and Euro, versus the U.S. Dollar.

[0001032975-25-000080:mdna:163]
[same as prior period, unchanged from 0001032975-25-000059:mdna:165]

[0001032975-25-000080:mdna:164]
[same as prior period, unchanged from 0001032975-25-000059:mdna:166]

[0001032975-25-000080:mdna:165]
In fiscal year 2026, we paid a cash dividend of CHF 185.1 million (U.S. Dollar amount of $233.1 million based on the exchange rate on the date of payment) out of fiscal year 2025 retained earnings. In fiscal year 2025, we paid a cash dividend of CHF 176.3 million (U.S. Dollar amount of $207.9 million based on the exchange rate on the date of payment) out of fiscal year 2024 retained earnings.

[0001032975-25-000080:mdna:166]
In June 2023, our Board of Directors approved a three-year share repurchase program, which allows us to use up to $1.0 billion to repurchase our shares. The 2023 share repurchase program enables us to repurchase shares for cancellation, as well as to support equity incentive plans or potential acquisitions. The Swiss Takeover Board approved the 2023 share repurchase program in July 2023 and the program became effective on July 28, 2023. In March 2025, our Board of Directors approved an increase of $600.0 million to the 2023 share repurchase program, to an aggregate amount of $1.6 billion. The Swiss Takeover Board approved this increase in April 2025 and it became effective on April 2, 2025. During the six months ended September 30, 2025, we repurchased 2.5 million

[0001032975-25-000080:mdna:167]
shares for an aggregate cost of $215.8 million for cancellation under this share repurchase program, of which $6.3 million of the aggregate cost was not paid yet as of September 30, 2025. As of September 30, 2025, $432.7 million was available for repurchase under the 2023 share repurchase program. We plan to target share repurchases of $2 billion over the three-year period ending March 31, 2028, subject to market conditions and regulatory approvals.

[0001032975-25-000080:mdna:168]
Swiss law limits a company’s ability to hold or repurchase its own shares. The aggregate par value of all shares held in treasury by us and our subsidiaries may not exceed 10% of our issued share capital, which corresponds to approximately 16.1 million registered shares as of September 30, 2025. This limitation does not apply to shares repurchased for cancellation, due to the Board of Directors' authority under the capital band set forth in the Company's Articles of Incorporation. As of September 30, 2025, we had a total of 13.9 million shares held in treasury stock, which includes 0.9 million shares that have been repurchased for cancellation and 13.0 million shares that have been purchased to support equity incentive plans or potential acquisitions.

[0001032975-25-000080:mdna:169]
[same as prior period, unchanged from 0001032975-25-000059:mdna:170]

[0001032975-25-000080:mdna:170]
[same as prior period, unchanged from 0001032975-25-000059:mdna:171]

[0001032975-25-000080:mdna:171]
[same as prior period, unchanged from 0001032975-25-000059:mdna:172]

[0001032975-25-000080:mdna:172]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. There have been no material changes to our contractual obligations as previously disclosed in our Annual Report on Form 10-K for the year ended March 31, 2025. The remaining terms of our non-cancelable operating leases expire in various years through 2036.

[0001032975-25-000080:mdna:173]
[same as prior period, unchanged from 0001032975-25-000059:mdna:174]

[0001032975-25-000080:mdna:174]
As of September 30, 2025, we had non-cancelable purchase commitments of $461.8 million for inventory purchases made in the normal course of business from original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. We recorded a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with our valuation of excess and obsolete inventory. As of September 30, 2025, the liability for these purchase commitments was $26.4 million and is recorded in accrued and other current liabilities in the condensed consolidated balance sheet.

[0001032975-25-000080:mdna:175]
As of September 30, 2025, we have firm purchase commitments of $19.7 million for capital expenditures primarily related to commitments for tooling and equipment for new and existing products. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-25-000080:mdna:176]
[same as prior period, unchanged from 0001032975-25-000059:mdna:177]

[0001032975-25-000080:mdna:177]
[same as prior period, unchanged from 0001032975-25-000059:mdna:178]

[0001032975-25-000080:mdna:178]
[same as prior period, unchanged from 0001032975-25-000059:mdna:179]

[0001032975-25-000080:mdna:179]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2025, no material amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-25-000080:mdna:180]
We also indemnify our current and former directors and certain current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. We are unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not capped, the obligations are conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-25-000080:mdna:181]
Legal Proceedings

[0001032975-25-000080:mdna:182]
From time to time, we are involved in claims and legal proceedings that arise in the ordinary course of our business. For more information about Legal Proceedings, see Part II Item 1 Legal Proceedings of this quarterly report on Form 10-Q for the period ended September 30, 2025.

[0001032975-25-000080:mdna:183]
37
