# LOGI 8-K — 0001032975-25-000076 filed 2025-10-28

## item codes, every 8-K on or before 2025-10-29

- 2025-10-28 0001032975-25-000076 — 2.02, 9.01
- 2025-10-02 0001032975-25-000071 — 3.01
- 2025-09-19 0001032975-25-000068 — 5.02
- 2025-09-09 0001032975-25-000065 — 5.07, 8.01
- 2025-08-27 0001032975-25-000062 — 5.03, 9.01
- 2025-07-29 0001032975-25-000055 — 2.02, 9.01
- 2025-06-17 0001032975-25-000034 — 7.01, 9.01
- 2025-04-29 0001032975-25-000022 — 2.02, 9.01
- 2025-04-10 0001032975-25-000018 — 2.02, 9.01
- 2025-03-03 0001032975-25-000011 — 5.02, 9.01
- 2025-01-28 0001032975-25-000005 — 1.01, 2.02, 2.03, 9.01
- 2024-10-22 0001032975-24-000072 — 2.02, 9.01
- 2024-10-11 0001032975-24-000069 — 5.03, 9.01
- 2024-09-09 0001032975-24-000065 — 5.07, 8.01
- 2024-08-06 0001032975-24-000062 — 5.02, 9.01
- 2024-07-23 0001032975-24-000042 — 2.02, 9.01
- 2024-07-01 0001032975-24-000033 — 5.02, 8.01, 9.01
- 2024-06-13 0001032975-24-000030 — 5.02, 9.01
- 2024-04-30 0001032975-24-000015 — 2.02, 9.01
- 2024-03-18 0001032975-24-000012 — 5.02, 7.01, 9.01
- 2024-01-23 0001032975-24-000004 — 2.02, 9.01
- 2023-10-30 0001032975-23-000082 — 5.02, 9.01
- 2023-10-24 0001032975-23-000075 — 2.02, 9.01
- 2023-09-15 0001032975-23-000072 — 5.07, 8.01
- 2023-07-25 0001032975-23-000050 — 2.02, 9.01
- 2023-06-30 0001032975-23-000037 — 5.02 — amendment, the index does not say of what
- 2023-06-30 0001032975-23-000036 — 5.02
- 2023-06-13 0001032975-23-000030 — 5.02, 7.01, 9.01
- 2023-05-02 0001032975-23-000015 — 2.02, 9.01
- 2023-01-30 0001032975-23-000010 — 5.02, 9.01
- 2023-01-24 0001032975-23-000004 — 2.02, 5.02, 9.01
- 2023-01-12 0001628280-23-000934 — 2.02, 9.01
- 2022-10-25 0001628280-22-026927 — 2.02, 5.02, 9.01
- 2022-09-16 0001628280-22-025080 — 5.07, 8.01
- 2022-07-26 0001032975-22-000027 — 2.02, 9.01
- 2022-06-29 0001032975-22-000018 — 5.02
- 2022-05-03 0001032975-22-000008 — 2.02, 9.01
- 2022-01-25 0001032975-22-000003 — 2.02, 9.01
- 2021-10-26 0001032975-21-000043 — 2.02, 9.01
- 2021-09-10 0001032975-21-000040 — 5.07, 8.01
- 2021-07-27 0001032975-21-000029 — 2.02, 9.01
- 2021-04-29 0001032975-21-000012 — 2.02, 9.01
- 2021-01-19 0001032975-21-000004 — 2.02, 9.01
- 2020-10-20 0001032975-20-000045 — 2.02, 9.01
- 2020-09-11 0001032975-20-000042 — 5.07, 8.01
- 2020-07-21 0001032975-20-000029 — 2.02, 9.01
- 2020-07-01 0001032975-20-000023 — 5.02, 8.01
- 2020-05-12 0001032975-20-000011 — 2.02, 9.01
- 2020-03-30 0001032975-20-000009 — 5.02
- 2020-01-21 0001032975-20-000002 — 2.02, 9.01
- 2019-10-22 0001032975-19-000071 — 9.01
- 2019-09-26 0001032975-19-000068 — 1.01, 7.01, 9.01
- 2019-09-06 0001032975-19-000063 — 5.07, 8.01
- 2019-07-23 0001032975-19-000046 — 2.02, 9.01
- 2019-07-23 0001032975-19-000045 — 5.02, 9.01
- 2019-07-02 0001032975-19-000036 — 5.02
- 2019-06-25 0001032975-19-000034 — 5.02
- 2019-05-03 0001032975-19-000021 — 5.02 — amendment, the index does not say of what
- 2019-04-30 0001032975-19-000017 — 2.02, 5.02, 9.01
- 2019-03-28 0001032975-19-000013 — 5.02
- 2019-01-22 0001032975-19-000004 — 2.02, 9.01
- 2018-10-23 0001032975-18-000044 — 2.02, 9.01
- 2018-09-07 0001032975-18-000040 — 5.07, 8.01
- 2018-07-31 0001032975-18-000035 — 1.01, 2.02, 2.05, 7.01, 9.01
- 2018-06-27 0001032975-18-000020 — 5.02
- 2018-05-03 0001032975-18-000013 — 2.02, 5.02, 9.01
- 2018-01-23 0001032975-18-000005 — 2.02, 9.01
- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2025-10-29

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-25-000076:8k_2_02:1]
EX-99.1
2
exhibit991q2fy26.htm
EX-99.1

[0001032975-25-000076:8k_2_02:2]
Document

[0001032975-25-000076:8k_2_02:3]
Exhibit 99.1

[0001032975-25-000076:8k_2_02:4]
Editorial Contacts:

[0001032975-25-000076:8k_2_02:5]
Nate Melihercik, Head of Investor Relations - ir@logitech.com

[0001032975-25-000076:8k_2_02:6]
Bruno Rodriguez, Head of Corporate Communications - mediarelations@logitech.com

[0001032975-25-000076:8k_2_02:7]
Ben Starkie, Corporate Communications - +41 (0) 79-292-3499, bstarkie1@logitech.com

[0001032975-25-000076:8k_2_02:8]
Logitech Announces Q2 Fiscal Year 2026 Results

[0001032975-25-000076:8k_2_02:9]
Operational Excellence and Strategic Priorities

[0001032975-25-000076:8k_2_02:10]
Drive Strong Second Quarter

[0001032975-25-000076:8k_2_02:11]
LAUSANNE, Switzerland, and SAN JOSE, Calif., Oct. 28, 2025 — SIX Swiss Exchange Ad hoc announcement pursuant to Art. 53 LR — Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the second quarter of Fiscal Year 2026.

[0001032975-25-000076:8k_2_02:12]
•Sales were $1.19 billion, up 6 percent in US dollars and 4 percent in constant currency compared to Q2 of the prior year.

[0001032975-25-000076:8k_2_02:13]
•GAAP gross margin was 43.4 percent, down 20 basis points compared to Q2 of the prior year. Non-GAAP gross margin was 43.8 percent, down 30 basis points compared to Q2 of the prior year.

[0001032975-25-000076:8k_2_02:14]
•GAAP operating income was $191 million, up 19 percent compared to Q2 of the prior year. Non-GAAP operating income was $230 million, up 19 percent compared to Q2 of the prior year.

[0001032975-25-000076:8k_2_02:15]
•GAAP earnings per share (EPS) was $1.15, up 21 percent compared to Q2 of the prior year. Non-GAAP EPS was $1.45, up 21 percent compared to Q2 of the prior year.

[0001032975-25-000076:8k_2_02:16]
•Cash flow from operations was $229 million. The quarter-ending cash balance was $1.4 billion.

[0001032975-25-000076:8k_2_02:17]
•The Company returned $340 million to shareholders through its annual dividend payment and share repurchases.

[0001032975-25-000076:8k_2_02:18]
“We delivered another strong quarter, driving growth and excellent profitability through our strategic priorities,” said Hanneke Faber, Logitech chief executive officer. “We continue to demonstrate resilience in a challenging environment. In the quarter, we announced 16 new products, including the much-anticipated MX Master 4 mouse and a wide array of new Gaming products. We executed well across all regions, and saw strong demand growth across both B2B and consumer channels.”

[0001032975-25-000076:8k_2_02:19]
“This quarter, our teams delivered outstanding operating income growth and continued to drive robust gross margins, thanks to disciplined operational execution and cost controls,” said Matteo Anversa, Logitech chief financial officer. “This strong performance shows our guiding principles in action, as we play offense, manage costs and remain agile in an uncertain environment.”

[0001032975-25-000076:8k_2_02:20]
Outlook

[0001032975-25-000076:8k_2_02:21]
Our financial outlook for the third quarter of FY26 reflects a pragmatic balance between the strong momentum of our business and the litany of uncertainties within the global economy:

[0001032975-25-000076:8k_2_02:22]
|  |  | Q3 FY26 outlook |
| Sales |  | $1,375 - $1,415 million |
| Sales growth (in US dollars, year over year) |  | 3% - 6% |
| Sales growth (in constant currency, year over year) |  | 1% - 4% |
| Non-GAAP operating income |  | $270 - $290 million |

[0001032975-25-000076:8k_2_02:23]
Financial Results Videoconference and Webcast

[0001032975-25-000076:8k_2_02:24]
Logitech will hold a financial results videoconference to discuss the results for Q2 Fiscal Year 2026 on Tuesday, October 28, 2025 at 1:30 p.m. Pacific Daylight Time (PDT) and 09:30 p.m. Central European Time (CET).

[0001032975-25-000076:8k_2_02:25]
A livestream of the event will be available on the Logitech corporate website at https://ir.logitech.com. This press release and the Q2 Fiscal Year 2026 Shareholder Letter are also available there.

[0001032975-25-000076:8k_2_02:26]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-25-000076:8k_2_02:27]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures in this press release, which exclude share-based compensation expense, amortization of intangible assets, acquisition-related costs, restructuring charges (credits), net, loss (gain) on investments, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below and posted to our website at https://ir.logitech.com. Logitech also presents percentage sales growth in constant currency (“cc”), a non-GAAP measure, to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance, outlook and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of the excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for the third quarter of Fiscal Year 2026 non-GAAP outlook.

[0001032975-25-000076:8k_2_02:28]
Public Dissemination of Certain Information

[0001032975-25-000076:8k_2_02:29]
Recordings of Logitech’s earnings videoconferences and certain events Logitech participates in or hosts, with members of the investment community are posted on the company’s investor relations website at https://ir.logitech.com. Additionally, Logitech provides notifications of news or announcements regarding its operations and financial performance, including its filings with the Securities and Exchange Commission (SEC), investor events, and press and earnings releases as part of its investor relations website. Logitech intends to use its investor relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. Logitech’s corporate governance information also is available on its investor relations website.

[0001032975-25-000076:8k_2_02:30]
About Logitech

[0001032975-25-000076:8k_2_02:31]
Logitech designs software-enabled hardware solutions that help businesses thrive and bring people together when working, creating and gaming. As the point of connection between people and the digital world, our mission is to extend human potential in work and play, in a way that is good for people and the planet. Founded in 1981, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech and its other brands, including Logitech G, at www.logitech.com or company blog.

[0001032975-25-000076:8k_2_02:32]
# # #

[0001032975-25-000076:8k_2_02:33]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-25-000076:8k_2_02:34]
Logitech and other Logitech marks are trademarks or registered trademarks of Logitech Europe S.A. and/or its affiliates in the U.S. and other countries. All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-25-000076:8k_2_02:35]
(LOGIIR)

[0001032975-25-000076:8k_2_02:36]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  | Six Months Ended September 30, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales |  | $ | 1,186,056 |  |  | $ | 1,116,034 |  |  | $ | 2,333,759 |  |  | $ | 2,204,251 |  |
| Cost of goods sold |  | 669,418 |  |  | 627,491 |  |  | 1,336,010 |  |  | 1,247,008 |  |
| Amortization of intangible assets |  | 2,182 |  |  | 2,452 |  |  | 4,331 |  |  | 4,894 |  |
| Gross profit |  | 514,456 |  |  | 486,091 |  |  | 993,418 |  |  | 952,349 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 198,993 |  |  | 201,863 |  |  | 394,789 |  |  | 398,768 |  |
| Research and development |  | 76,110 |  |  | 76,205 |  |  | 150,697 |  |  | 151,512 |  |
| General and administrative |  | 41,802 |  |  | 44,173 |  |  | 83,599 |  |  | 81,631 |  |
| Amortization of intangible assets and acquisition-related costs |  | 1,818 |  |  | 2,725 |  |  | 4,464 |  |  | 5,428 |  |
| Restructuring charges, net |  | 4,442 |  |  | 229 |  |  | 6,484 |  |  | 615 |  |
| Total operating expenses |  | 323,165 |  |  | 325,195 |  |  | 640,033 |  |  | 637,954 |  |
| Operating income |  | 191,291 |  |  | 160,896 |  |  | 353,385 |  |  | 314,395 |  |
| Interest income |  | 11,828 |  |  | 14,637 |  |  | 23,057 |  |  | 30,427 |  |
| Other income (expense), net |  | (64) |  |  | 533 |  |  | 1,098 |  |  | (1,365) |  |
| Income before income taxes |  | 203,055 |  |  | 176,066 |  |  | 377,540 |  |  | 343,457 |  |
| Provision for income taxes |  | 32,385 |  |  | 30,583 |  |  | 60,855 |  |  | 56,141 |  |
| Net income |  | $ | 170,670 |  |  | $ | 145,483 |  |  | $ | 316,685 |  |  | $ | 287,316 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.16 |  |  | $ | 0.95 |  |  | $ | 2.15 |  |  | $ | 1.88 |  |
| Diluted |  | $ | 1.15 |  |  | $ | 0.95 |  |  | $ | 2.13 |  |  | $ | 1.86 |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | 147,123 |  |  | 152,460 |  |  | 147,487 |  |  | 152,875 |  |
| Diluted |  | 148,422 |  |  | 153,672 |  |  | 148,731 |  |  | 154,320 |  |

[0001032975-25-000076:8k_2_02:37]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | September 30, |  | March 31, |  |  |  |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  | 2025 |  | 2025 |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,375,807 |  |  | $ | 1,503,205 |  |  |  |  |  |
| Accounts receivable, net |  | 703,895 |  |  | 454,546 |  |  |  |  |  |
| Inventories |  | 517,673 |  |  | 503,747 |  |  |  |  |  |
| Other current assets |  | 152,376 |  |  | 131,211 |  |  |  |  |  |
| Total current assets |  | 2,749,751 |  |  | 2,592,709 |  |  |  |  |  |
| Non-current assets: |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 118,218 |  |  | 113,858 |  |  |  |  |  |
| Goodwill |  | 465,752 |  |  | 463,230 |  |  |  |  |  |
| Other intangible assets, net |  | 16,306 |  |  | 24,630 |  |  |  |  |  |
| Other assets |  | 357,198 |  |  | 344,077 |  |  |  |  |  |
| Total assets |  | $ | 3,707,225 |  |  | $ | 3,538,504 |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 583,308 |  |  | $ | 414,586 |  |  |  |  |  |
| Accrued and other current liabilities |  | 698,055 |  |  | 686,503 |  |  |  |  |  |
| Total current liabilities |  | 1,281,363 |  |  | 1,101,089 |  |  |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Income taxes payable |  | 103,206 |  |  | 88,483 |  |  |  |  |  |
| Other non-current liabilities |  | 239,643 |  |  | 221,512 |  |  |  |  |  |
| Total liabilities |  | 1,624,212 |  |  | 1,411,084 |  |  |  |  |  |
| Shareholders’ equity: |  |  |  |  |  |  |  |  |
| Registered shares, CHF 0.25 par valueIssued shares: 160,784 and 168,994 at September 30, 2025 and March 31, 2025, respectively |  | 28,001 |  |  | 29,432 |  |  |  |  |  |
| Additional paid-in capital |  | 85,347 |  |  | 82,591 |  |  |  |  |  |
| Shares in treasury, at cost Treasury shares: 13,889 and 20,485 at September 30, 2025 and March 31, 2025, respectively |  | (890,617) |  |  | (1,464,912) |  |  |  |  |  |
| Retained earnings |  | 2,986,776 |  |  | 3,627,261 |  |  |  |  |  |
| Accumulated other comprehensive loss |  | (126,494) |  |  | (146,952) |  |  |  |  |  |
| Total shareholders’ equity |  | 2,083,013 |  |  | 2,127,420 |  |  |  |  |  |
| Total liabilities and shareholders’ equity |  | $ | 3,707,225 |  |  | $ | 3,538,504 |  |  |  |  |  |

[0001032975-25-000076:8k_2_02:38]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  | Six Months Ended September 30, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 170,670 |  |  | $ | 145,483 |  |  | $ | 316,685 |  |  | $ | 287,316 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  | 15,871 |  |  | 14,597 |  |  | 30,935 |  |  | 29,103 |  |
| Amortization of intangible assets |  | 4,000 |  |  | 5,092 |  |  | 8,795 |  |  | 10,171 |  |
| Loss on investments |  | 104 |  |  | 413 |  |  | 497 |  |  | 1,599 |  |
| Share-based compensation expense |  | 30,312 |  |  | 26,469 |  |  | 63,140 |  |  | 49,874 |  |
| Deferred income taxes |  | 10,083 |  |  | 4,827 |  |  | 22,196 |  |  | 16,489 |  |
| Other |  | 13 |  |  | 81 |  |  | (12) |  |  | 57 |  |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | (69,092) |  |  | (27,616) |  |  | (235,859) |  |  | (81,568) |  |
| Inventories |  | (19,084) |  |  | (54,812) |  |  | (1,780) |  |  | (93,907) |  |
| Other assets |  | 2,333 |  |  | (2,666) |  |  | (17,484) |  |  | 2,241 |  |
| Accounts payable |  | 30,416 |  |  | (652) |  |  | 165,419 |  |  | 108,376 |  |
| Accrued and other liabilities |  | 53,211 |  |  | 54,786 |  |  | 1,350 |  |  | 12,280 |  |
| Net cash provided by operating activities |  | 228,837 |  |  | 166,002 |  |  | 353,882 |  |  | 342,031 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (16,557) |  |  | (14,527) |  |  | (32,833) |  |  | (29,113) |  |
| Purchases of deferred compensation investments |  | (776) |  |  | (2,905) |  |  | (4,037) |  |  | (3,600) |  |
| Proceeds from sales of deferred compensation investments |  | 1,821 |  |  | 1,561 |  |  | 3,559 |  |  | 2,299 |  |
| Other investing activities |  | (682) |  |  | (96) |  |  | (983) |  |  | (912) |  |
| Net cash used in investing activities |  | (16,194) |  |  | (15,967) |  |  | (34,294) |  |  | (31,326) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | (233,059) |  |  | (207,853) |  |  | (233,059) |  |  | (207,853) |  |
| Purchases of registered shares |  | (106,606) |  |  | (132,286) |  |  | (228,263) |  |  | (263,185) |  |
| Proceeds from exercises of stock options and purchase rights |  | 18,451 |  |  | 15,617 |  |  | 21,713 |  |  | 20,235 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (2,173) |  |  | (2,390) |  |  | (18,211) |  |  | (21,243) |  |
| Other financing activities |  | — |  |  | (2,908) |  |  | — |  |  | (2,908) |  |
| Net cash used in financing activities |  | (323,387) |  |  | (329,820) |  |  | (457,820) |  |  | (474,954) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (1,271) |  |  | 8,681 |  |  | 10,834 |  |  | 6,683 |  |
| Net decrease in cash and cash equivalents |  | (112,015) |  |  | (171,104) |  |  | (127,398) |  |  | (157,566) |  |
| Cash and cash equivalents, beginning of the period |  | 1,487,822 |  |  | 1,534,380 |  |  | 1,503,205 |  |  | 1,520,842 |  |
| Cash and cash equivalents, end of the period |  | $ | 1,375,807 |  |  | $ | 1,363,276 |  |  | $ | 1,375,807 |  |  | $ | 1,363,276 |  |

[0001032975-25-000076:8k_2_02:39]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended September 30, |  | Six Months Ended September 30, |
| NET SALES |  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
| Net sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Gaming (1) |  | $ | 323,305 |  |  | $ | 300,470 |  |  | 8 | % |  | $ | 639,180 |  |  | $ | 609,945 |  |  | 5 | % |
| Keyboards & Combos |  | 235,870 |  |  | 209,936 |  |  | 12 |  |  | 458,362 |  |  | 425,269 |  |  | 8 |  |
| Pointing Devices |  | 221,094 |  |  | 195,936 |  |  | 13 |  |  | 416,874 |  |  | 385,882 |  |  | 8 |  |
| Video Collaboration |  | 167,677 |  |  | 159,660 |  |  | 5 |  |  | 334,393 |  |  | 306,702 |  |  | 9 |  |
| Webcams |  | 83,301 |  |  | 80,249 |  |  | 4 |  |  | 167,676 |  |  | 153,153 |  |  | 9 |  |
| Tablet Accessories |  | 85,061 |  |  | 85,614 |  |  | (1) |  |  | 176,288 |  |  | 164,153 |  |  | 7 |  |
| Headsets |  | 43,498 |  |  | 46,916 |  |  | (7) |  |  | 89,020 |  |  | 91,152 |  |  | (2) |  |
| Other (2) |  | 26,250 |  |  | 37,253 |  |  | (30) |  |  | 51,966 |  |  | 67,995 |  |  | (24) |  |
| Total Net Sales |  | $ | 1,186,056 |  |  | $ | 1,116,034 |  |  | 6 | % |  | $ | 2,333,759 |  |  | $ | 2,204,251 |  |  | 6 | % |

[0001032975-25-000076:8k_2_02:40]
(1) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-25-000076:8k_2_02:41]
(2) Other primarily consists of mobile speakers and PC speakers.

[0001032975-25-000076:8k_2_02:42]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended September 30, |  | Six Months Ended September 30, |
| GAAP TO NON-GAAP RECONCILIATION (A) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Gross profit - GAAP |  | $ | 514,456 |  | $ | 486,091 |  | $ | 993,418 |  | $ | 952,349 |
| Share-based compensation expense |  | 3,359 |  | 3,902 |  | 5,739 |  | 6,500 |
| Amortization of intangible assets |  | 2,182 |  | 2,452 |  | 4,331 |  | 4,894 |
| Gross profit - Non-GAAP |  | $ | 519,997 |  | $ | 492,445 |  | $ | 1,003,488 |  | $ | 963,743 |
| Gross margin - GAAP |  | 43.4 | % |  | 43.6 | % |  | 42.6 | % |  | 43.2 | % |
| Gross margin - Non-GAAP |  | 43.8 | % |  | 44.1 | % |  | 43.0 | % |  | 43.7 | % |
| Operating expenses - GAAP |  | $ | 323,165 |  | $ | 325,195 |  | $ | 640,033 |  | $ | 637,954 |
| Less: Share-based compensation expense |  | 26,953 |  | 22,567 |  | 57,401 |  | 43,374 |
| Less: Amortization of intangible assets and acquisition-related costs |  | 1,818 |  | 2,725 |  | 4,464 |  | 5,428 |
| Less: Restructuring charges, net |  | 4,442 |  | 229 |  | 6,484 |  | 615 |
| Operating expenses - Non-GAAP |  | $ | 289,952 |  | $ | 299,674 |  | $ | 571,684 |  | $ | 588,537 |
| % of net sales - GAAP |  | 27.2 | % |  | 29.1 | % |  | 27.4 | % |  | 28.9 | % |
| % of net sales - Non-GAAP |  | 24.4 | % |  | 26.9 | % |  | 24.5 | % |  | 26.7 | % |
| Operating income - GAAP |  | $ | 191,291 |  | $ | 160,896 |  | $ | 353,385 |  | $ | 314,395 |
| Share-based compensation expense |  | 30,312 |  | 26,469 |  | 63,140 |  | 49,874 |
| Amortization of intangible assets and acquisition-related costs |  | 4,000 |  | 5,177 |  | 8,795 |  | 10,322 |
| Restructuring charges, net |  | 4,442 |  | 229 |  | 6,484 |  | 615 |
| Operating income - Non-GAAP |  | $ | 230,045 |  | $ | 192,771 |  | $ | 431,804 |  | $ | 375,206 |
| % of net sales - GAAP |  | 16.1 | % |  | 14.4 | % |  | 15.1 | % |  | 14.3 | % |
| % of net sales - Non-GAAP |  | 19.4 | % |  | 17.3 | % |  | 18.5 | % |  | 17.0 | % |
| Net income - GAAP |  | $ | 170,670 |  | $ | 145,483 |  | $ | 316,685 |  | $ | 287,316 |
| Share-based compensation expense |  | 30,312 |  | 26,469 |  | 63,140 |  | 49,874 |
| Amortization of intangible assets and acquisition-related costs |  | 4,000 |  | 5,177 |  | 8,795 |  | 10,322 |
| Restructuring charges, net |  | 4,442 |  | 229 |  | 6,484 |  | 615 |
| Loss on investments |  | 104 |  | 413 |  | 497 |  | 1,599 |
| Non-GAAP income tax adjustment |  | 6,047 |  | 6,315 |  | 8,142 |  | 8,985 |
| Net income - Non-GAAP |  | $ | 215,575 |  | $ | 184,086 |  | $ | 403,743 |  | $ | 358,711 |
| Net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 1.15 |  | $ | 0.95 |  | $ | 2.13 |  | $ | 1.86 |
| Diluted - Non-GAAP |  | $ | 1.45 |  | $ | 1.20 |  | $ | 2.71 |  | $ | 2.32 |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non-GAAP |  | 148,422 |  | 153,672 |  | 148,731 |  | 154,320 |

[0001032975-25-000076:8k_2_02:43]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended September 30, |  | Six Months Ended September 30, |
| SHARE-BASED COMPENSATION EXPENSE |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 3,359 |  |  | $ | 3,902 |  |  | $ | 5,739 |  |  | $ | 6,500 |  |
| Marketing and selling |  | 12,141 |  |  | 10,469 |  |  | 26,071 |  |  | 22,320 |  |
| Research and development |  | 5,666 |  |  | 5,067 |  |  | 12,017 |  |  | 10,806 |  |
| General and administrative |  | 9,146 |  |  | 7,031 |  |  | 19,313 |  |  | 10,248 |  |
| Total share-based compensation expense |  | 30,312 |  |  | 26,469 |  |  | 63,140 |  |  | 49,874 |  |
| Income tax benefit |  | (6,015) |  |  | (4,776) |  |  | (10,921) |  |  | (12,378) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 24,297 |  |  | $ | 21,693 |  |  | $ | 52,219 |  |  | $ | 37,496 |  |

[0001032975-25-000076:8k_2_02:44]
*Note: These preliminary results for the three and six months ended September 30, 2025 are subject to adjustments, including subsequent events that may occur through the date of filing our Quarterly Report on Form 10-Q.

[0001032975-25-000076:8k_2_02:45]
(A) Non-GAAP Financial Measures

[0001032975-25-000076:8k_2_02:46]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-25-000076:8k_2_02:47]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enable investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended September 30, 2025 and prior periods presented, we excluded items in the following general categories, each of which are described below:

[0001032975-25-000076:8k_2_02:48]
Share-based compensation expense. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-25-000076:8k_2_02:49]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit, operating expenses, and financial results from period to period.

[0001032975-25-000076:8k_2_02:50]
Acquisition-related costs. We incurred expenses in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition-related costs include certain incremental expenses incurred to effect a business combination. We believe that providing the non-GAAP measures excluding these costs, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-25-000076:8k_2_02:51]
Restructuring charges (credits), net. These charges (credits) are associated with restructuring plans and will vary based on the initiatives in place during any given period. Restructuring charges may include costs related to employee

[0001032975-25-000076:8k_2_02:52]
terminations, facility closures and early cancellation of certain contracts as well as other costs resulting from our restructuring initiatives. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results.

[0001032975-25-000076:8k_2_02:53]
Loss (gain) on investments. We recognize losses (gains) related to our investments in various companies, which vary depending on the operational and financial performance of the companies in which we invest. These amounts include our losses (earnings) on equity method investments as well as investment impairments and losses (gains) resulting from sales or other events related to our investments. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such losses (gains) are not reflective of our ongoing operations.

[0001032975-25-000076:8k_2_02:54]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above as well as the income tax impact of non-recurring deferred taxes, tax settlements, and other non-routine tax events, the determination of which is based upon the nature of the underlying items.

[0001032975-25-000076:8k_2_02:55]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-25-000076:8k_2_02:56]
Additional Supplemental Financial Information - Constant Currency

[0001032975-25-000076:8k_2_02:57]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.
