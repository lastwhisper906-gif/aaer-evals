# LOGI 8-K — 0001032975-17-000028 filed 2017-07-25

## item codes, every 8-K on or before 2017-07-27

- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2017-07-27

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-17-000028:8k_2_02:1]
EX-99.1
2
exhibit991q1fy18.htm
EXHIBIT 99.1

[0001032975-17-000028:8k_2_02:2]
Exhibit

[0001032975-17-000028:8k_2_02:3]
Exhibit 99.1

[0001032975-17-000028:8k_2_02:4]
Editorial Contacts:

[0001032975-17-000028:8k_2_02:5]
Ben Lu, Vice President, Investor Relations - USA (510) 713-5568

[0001032975-17-000028:8k_2_02:6]
Krista Todd, Vice President, External Communications - USA (510) 713-5834

[0001032975-17-000028:8k_2_02:7]
Ben Starkie, Corporate Communications - Europe +41 (0) 79-292-3499

[0001032975-17-000028:8k_2_02:8]
Logitech Delivers Double-Digit Growth and Raises Outlook

[0001032975-17-000028:8k_2_02:9]
Gaming, Video Collaboration, Smart Home Up Over 40%

[0001032975-17-000028:8k_2_02:10]
NEWARK, Calif. - July 24, 2017 and LAUSANNE, Switzerland, July 25, 2017 - Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the first quarter of Fiscal Year 2018.

[0001032975-17-000028:8k_2_02:11]
| • | Q1 sales were $530 million, up 13 percent in constant currency compared to Q1 of the prior year. Q1 sales grew 10 percent in USD. |

[0001032975-17-000028:8k_2_02:12]
| • | Q1 GAAP operating income grew 22 percent to $31 million, compared to $26 million a year ago. Q1 GAAP earnings per share (EPS) grew 69 percent to $0.22, compared to $0.13 a year ago. |

[0001032975-17-000028:8k_2_02:13]
| • | Q1 non-GAAP operating income grew 14 percent to $43 million, compared to $38 million a year ago. Q1 non-GAAP EPS grew 20 percent to $0.24, compared to $0.20 a year ago. |

[0001032975-17-000028:8k_2_02:14]
“We’re off to a strong start,” said Bracken Darrell, Logitech president and chief executive officer. “Our innovative and diverse portfolio is delivering, with growth and profitability exceeding expectations this quarter. Our growth was broad-based - we grew double-digits in constant currency across all three regions. Looking out to the rest of the year, the strength of our innovation program combined with the expected closing of the ASTRO Gaming acquisition, give us the confidence to raise our FY 2018 outlook.”

[0001032975-17-000028:8k_2_02:15]
Vincent Pilette, Logitech chief financial officer, said, “We delivered a strong financial performance during this first quarter of the fiscal year, with sales up 13% and profitability up 14%. Q1’s healthy gross margin - up 140 basis points compared to last year - allows us to continue our investment in numerous growth opportunities to build an exciting future.”

[0001032975-17-000028:8k_2_02:16]
Outlook

[0001032975-17-000028:8k_2_02:17]
Logitech raised its Fiscal Year 2018 outlook to 10 to 12 percent sales growth in constant currency and $260 to $270 million in non-GAAP operating income. This includes the anticipated impact of the ASTRO Gaming acquisition, expected to close in August 2017.

[0001032975-17-000028:8k_2_02:18]
Prepared Remarks Available Online

[0001032975-17-000028:8k_2_02:19]
Logitech has made its prepared written remarks for the financial results teleconference available online on the Logitech corporate website at http://ir.logitech.com.

[0001032975-17-000028:8k_2_02:20]
Financial Results Teleconference and Webcast

[0001032975-17-000028:8k_2_02:21]
Logitech will hold a financial results teleconference to discuss the results for Q1 FY 2018 on

[0001032975-17-000028:8k_2_02:22]
Tuesday, Jul. 25, 2017 at 8:30 a.m. Eastern Daylight Time and 2:30 p.m. Central European Summer Time. A live webcast of the call will be available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-17-000028:8k_2_02:23]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-17-000028:8k_2_02:24]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of intangible assets, purchase accounting effect on inventory, acquisition-related costs, change in fair value of contingent consideration for business acquisition, restructuring charges (credits), gain (loss) on investments in privately held companies, investigation and related expenses, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below. Logitech also presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate

[0001032975-17-000028:8k_2_02:25]
with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for Fiscal Year 2018.

[0001032975-17-000028:8k_2_02:26]
About Logitech

[0001032975-17-000028:8k_2_02:27]
Logitech designs products that have an everyday place in people's lives, connecting them to the digital experiences they care about. More than 35 years ago, Logitech started connecting people through computers, and now it’s a multi-brand company designing products that bring people together through music, gaming, video and computing. Brands of Logitech include Logitech, Jaybird, Logitech G and Ultimate Ears. Founded in 1981, and headquartered in Lausanne, Switzerland, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @Logitech.

[0001032975-17-000028:8k_2_02:28]
# # #

[0001032975-17-000028:8k_2_02:29]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-17-000028:8k_2_02:30]
2017 Logitech, Logicool, Logi and other Logitech marks are owned by Logitech and may be registered. All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-17-000028:8k_2_02:31]
(LOGIIR)

[0001032975-17-000028:8k_2_02:32]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |
|  |  | Three Months Ended |
|  |  | June 30, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2017 |  | 2016 |
| Net sales |  | $ | 529,946 |  |  | $ | 479,864 |  |
| Cost of goods sold |  | 334,774 |  |  | 309,625 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 1,504 |  |  | 1,613 |  |
| Gross profit |  | 193,668 |  |  | 168,626 |  |
| Operating expenses: |  |  |  |  |
| Marketing and selling |  | 102,378 |  |  | 83,872 |  |
| Research and development |  | 35,099 |  |  | 31,951 |  |
| General and administrative |  | 25,354 |  |  | 25,655 |  |
| Amortization of intangible assets and acquisition-related costs |  | 1,390 |  |  | 1,293 |  |
| Change in fair value of contingent consideration for business acquisition |  | (1,978 | ) |  | — |  |
| Total operating expenses |  | 162,243 |  |  | 142,771 |  |
| Operating income |  | 31,425 |  |  | 25,855 |  |
| Interest income, net |  | 1,175 |  |  | 151 |  |
| Other expense, net |  | (1,029 | ) |  | (1,008 | ) |
| Income before income taxes |  | 31,571 |  |  | 24,998 |  |
| Provision for (benefit from) income taxes |  | (5,436 | ) |  | 3,057 |  |
| Net income |  | $ | 37,007 |  |  | $ | 21,941 |  |
| Net income per share: |  |  |  |  |  |  |
| Basic |  | $ | 0.23 |  |  | $ | 0.14 |  |
| Diluted |  | $ | 0.22 |  |  | $ | 0.13 |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |
| Basic |  | 163,407 |  |  | 162,130 |  |
| Diluted |  | 168,339 |  |  | 164,303 |  |

[0001032975-17-000028:8k_2_02:33]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS |
| (In thousands) - unaudited |  |  |  |  |
|  |  | June 30, |  | March 31, |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  | 2017 |  | 2017 |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 527,657 |  |  | $ | 547,533 |  |
| Accounts receivable, net |  | 221,340 |  |  | 185,179 |  |
| Inventories |  | 279,405 |  |  | 253,401 |  |
| Other current assets |  | 42,675 |  |  | 41,732 |  |
| Total current assets |  | 1,071,077 |  |  | 1,027,845 |  |
| Non-current assets: |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 85,135 |  |  | 85,408 |  |
| Goodwill |  | 249,780 |  |  | 249,741 |  |
| Other intangible assets, net |  | 44,971 |  |  | 47,564 |  |
| Other assets |  | 136,516 |  |  | 88,119 |  |
| Total assets |  | $ | 1,587,479 |  |  | $ | 1,498,677 |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 312,722 |  |  | $ | 274,805 |  |
| Accrued and other current liabilities |  | 205,059 |  |  | 232,273 |  |
| Total current liabilities |  | 517,781 |  |  | 507,078 |  |
| Non-current liabilities: |  |  |  |  |  |  |
| Income taxes payable |  | 32,147 |  |  | 51,797 |  |
| Other non-current liabilities |  | 87,213 |  |  | 83,691 |  |
| Total liabilities |  | 637,141 |  |  | 642,566 |  |
| Shareholders’ equity: |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |
| Issued and authorized shares —173,106 at June 30 and March 31, 2017 |  |  |  |  |
| Conditionally authorized shares — 50,000 at June 30 and March 31, 2017 |  |  |  |  |
| Additional paid-in capital |  | 14,519 |  |  | 26,596 |  |
| Shares in treasury, at cost — 9,197 at June 30, 2017 and 10,727 at March 31, 2017 |  | (157,330 | ) |  | (174,037 | ) |
| Retained earnings |  | 1,165,029 |  |  | 1,074,110 |  |
| Accumulated other comprehensive loss |  | (102,028 | ) |  | (100,706 | ) |
| Total shareholders’ equity |  | 950,338 |  |  | 856,111 |  |
| Total liabilities and shareholders’ equity |  | $ | 1,587,479 |  |  | $ | 1,498,677 |  |

[0001032975-17-000028:8k_2_02:34]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS |
| (In thousands) - unaudited |  |  |  |  |
|  |  | Three Months Ended |
|  |  | June 30, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  | 2017 |  | 2016 |
| Cash flows from operating activities: |  |  |  |  |
| Net income |  | $ | 37,007 |  |  | $ | 21,941 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities: |  |  |  |  |
| Depreciation |  | 9,148 |  |  | 13,105 |  |
| Amortization of intangible assets |  | 2,593 |  |  | 1,708 |  |
| Loss (gain) on investments in privately held companies |  | 259 |  |  | (1 | ) |
| Gain on disposal of property, plant and equipment |  | (3 | ) |  | — |  |
| Share-based compensation expense |  | 10,705 |  |  | 8,517 |  |
| Deferred income taxes |  | (9,879 | ) |  | (1,048 | ) |
| Change in fair value of contingent consideration for business acquisition |  | (1,978 | ) |  | — |  |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |
| Accounts receivable, net |  | (35,702 | ) |  | (48,661 | ) |
| Inventories |  | (20,389 | ) |  | (10,007 | ) |
| Other assets |  | (3,088 | ) |  | (1,171 | ) |
| Accounts payable |  | 38,647 |  |  | 42,769 |  |
| Accrued and other liabilities |  | (28,203 | ) |  | (10,135 | ) |
| Net cash provided by (used in) operating activities |  | (883 | ) |  | 17,017 |  |
| Cash flows from investing activities: |  |  |  |  |
| Purchases of property, plant and equipment |  | (10,035 | ) |  | (8,135 | ) |
| Investment in privately held companies |  | (360 | ) |  | (320 | ) |
| Acquisitions, net of cash acquired |  | — |  |  | (53,987 | ) |
| Changes in restricted cash |  | — |  |  | 715 |  |
| Purchases of trading investments |  | (609 | ) |  | (4,229 | ) |
| Proceeds from sales of trading investments |  | 647 |  |  | 4,231 |  |
| Net cash used in investing activities |  | (10,357 | ) |  | (61,725 | ) |
| Cash flows from financing activities: |  |  |  |  |
| Purchases of registered shares |  | (624 | ) |  | (24,422 | ) |
| Proceeds from exercises of stock options |  | 12,569 |  |  | 599 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (21,683 | ) |  | (9,185 | ) |
| Net cash used in financing activities |  | (9,738 | ) |  | (33,008 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | 1,102 |  |  | (1,368 | ) |
| Net decrease in cash and cash equivalents |  | (19,876 | ) |  | (79,084 | ) |
| Cash and cash equivalents, beginning of the period |  | 547,533 |  |  | 519,195 |  |
| Cash and cash equivalents, end of the period |  | $ | 527,657 |  |  | $ | 440,111 |  |

[0001032975-17-000028:8k_2_02:35]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |
| PRELIMINARY RESULTS |
| (In thousands) - unaudited |  |  |  |  |
| NET SALES |  | Three Months Ended |
|  |  | June 30, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2017 |  | 2016 |  | Change |
| Net sales by product category: |  |  |  |  |  |  |
| Mobile Speakers |  | $ | 62,918 |  |  | $ | 57,296 |  |  | 10 | % |
| Audio-PC & Wearables |  | 50,202 |  |  | 56,579 |  |  | (11 | ) |
| Gaming |  | 77,708 |  |  | 56,500 |  |  | 38 |  |
| Video Collaboration |  | 35,617 |  |  | 23,910 |  |  | 49 |  |
| Smart Home |  | 16,466 |  |  | 11,167 |  |  | 47 |  |
| Pointing Devices |  | 122,074 |  |  | 116,783 |  |  | 5 |  |
| Keyboards & Combos |  | 116,113 |  |  | 118,019 |  |  | (2 | ) |
| Tablet & Other Accessories |  | 23,218 |  |  | 13,885 |  |  | 67 |  |
| PC Webcams |  | 25,625 |  |  | 25,262 |  |  | 1 |  |
| Other (1) |  | 5 |  |  | 463 |  |  | (99 | ) |
| Total net sales |  | $ | 529,946 |  |  | $ | 479,864 |  |  | 10 |  |
| __________________ |  |  |  |  |  |  |

[0001032975-17-000028:8k_2_02:36]
(1) Other category includes products that we currently intend to transition out of, or have already transitioned out of, because they are no longer strategic to our business.

[0001032975-17-000028:8k_2_02:37]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |
| GAAP TO NON-GAAP RECONCILIATION (A) |  | Three Months Ended |
|  |  | June 30, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2017 |  | 2016 |
| Gross profit - GAAP |  | $ | 193,668 |  |  | $ | 168,626 |  |
| Share-based compensation expense |  | 711 |  |  | 675 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 1,504 |  |  | 1,613 |  |
| Gross profit - Non-GAAP |  | $ | 195,883 |  |  | $ | 170,914 |  |
| Gross margin - GAAP |  | 36.5 | % |  | 35.1 | % |
| Gross margin - Non-GAAP |  | 37.0 | % |  | 35.6 | % |
| Operating expenses - GAAP |  | $ | 162,243 |  |  | $ | 142,771 |  |
| Less: Share-based compensation expense |  | 9,994 |  |  | 7,842 |  |
| Less: Amortization of intangible assets and acquisition-related costs |  | 1,390 |  |  | 1,293 |  |
| Less: Change in fair value of contingent consideration for business acquisition |  | (1,978 | ) |  | — |  |
| Less: Restructuring credits, net |  | (55 | ) |  | (85 | ) |
| Less: Investigation and related expenses |  | — |  |  | 612 |  |
| Operating expenses - Non-GAAP |  | $ | 152,892 |  |  | $ | 133,109 |  |
| % of net sales - GAAP |  | 30.6 | % |  | 29.8 | % |
| % of net sales - Non - GAAP |  | 28.9 | % |  | 27.7 | % |
| Operating income - GAAP |  | $ | 31,425 |  |  | $ | 25,855 |  |
| Share-based compensation expense |  | 10,705 |  |  | 8,517 |  |
| Amortization of intangible assets |  | 2,593 |  |  | 1,708 |  |
| Purchase accounting effect on inventory |  | — |  |  | 703 |  |
| Acquisition-related costs |  | 301 |  |  | 495 |  |
| Change in fair value of contingent consideration for business acquisition |  | (1,978 | ) |  | — |  |
| Restructuring credits, net |  | (55 | ) |  | (85 | ) |
| Investigation and related expenses |  | — |  |  | 612 |  |
| Operating income - Non - GAAP |  | $ | 42,991 |  |  | $ | 37,805 |  |
| % of net sales - GAAP |  | 5.9 | % |  | 5.4 | % |
| % of net sales - Non - GAAP |  | 8.1 | % |  | 7.9 | % |
| Net income - GAAP |  | $ | 37,007 |  |  | $ | 21,941 |  |
| Share-based compensation expense |  | 10,705 |  |  | 8,517 |  |
| Amortization of intangible assets |  | 2,593 |  |  | 1,708 |  |
| Purchase accounting effect on inventory |  | — |  |  | 703 |  |
| Acquisition-related costs |  | 301 |  |  | 495 |  |
| Change in fair value of contingent consideration for business acquisition |  | (1,978 | ) |  | — |  |
| Restructuring credits, net |  | (55 | ) |  | (85 | ) |
| Investigation and related expenses |  | — |  |  | 612 |  |
| Loss (gain) on investments in privately held companies |  | 259 |  |  | (1 | ) |
| Non-GAAP income tax adjustment |  | (9,092 | ) |  | (675 | ) |
| Net income - Non - GAAP |  | $ | 39,740 |  |  | $ | 33,215 |  |
| Net income per share: |  |  |  |  |
| Diluted - GAAP |  | $ | 0.22 |  |  | $ | 0.13 |  |
| Diluted - Non - GAAP |  | $ | 0.24 |  |  | $ | 0.20 |  |
| Shares used to compute net income per share: |  |  |  |  |
| Diluted - GAAP and Non - GAAP |  | 168,339 |  |  | 164,303 |  |

[0001032975-17-000028:8k_2_02:38]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS |
| (In thousands) - unaudited |  |  |  |  |
| SHARE-BASED COMPENSATION EXPENSE |  | Three Months Ended |
|  |  | June 30, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2017 |  | 2016 |
| Share-based Compensation Expense |  |  |  |  |
| Cost of goods sold |  | $ | 711 |  |  | $ | 675 |  |
| Marketing and selling |  | 4,381 |  |  | 3,437 |  |
| Research and development |  | 1,543 |  |  | 914 |  |
| General and administrative |  | 4,070 |  |  | 3,491 |  |
| Total share-based compensation expense |  | 10,705 |  |  | 8,517 |  |
| Income tax benefit |  | (11,282 | ) |  | (1,815 | ) |
| Total share-based compensation expense (credit), net of income tax |  | $ | (577 | ) |  | $ | 6,702 |  |

[0001032975-17-000028:8k_2_02:39]
Note: These preliminary results for the three months ended June 30, 2017 are subject to adjustments, including subsequent events that may occur through the date of filing our Quarterly Report on Form 10-Q.

[0001032975-17-000028:8k_2_02:40]
(A) Non-GAAP Financial Measures

[0001032975-17-000028:8k_2_02:41]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-17-000028:8k_2_02:42]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended June 30, 2017, we excluded items in the following general categories, each of which are described below:

[0001032975-17-000028:8k_2_02:43]
Share-based compensation expenses. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-17-000028:8k_2_02:44]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit,  operating expenses, and financial results from period to period.

[0001032975-17-000028:8k_2_02:45]
Purchase accounting effect on inventory. Business combination accounting principles require us to measure acquired inventory at fair value. The fair value of inventory reflects the acquired company’s cost of manufacturing plus a portion of the expected profit margin. The non-GAAP adjustment excludes the expected profit margin component that is

[0001032975-17-000028:8k_2_02:46]
recorded under business combination accounting principles associated with our business acquisitions. We believe the adjustment is useful to investors because such charges are not reflective of our ongoing operations.

[0001032975-17-000028:8k_2_02:47]
Acquisition-related costs and change in fair value of contingent consideration for business acquisition.  We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition related costs include all incremental expenses incurred to effect a business combination. Fair value of contingent consideration is associated with our estimates of the value of earn-outs in connection with certain acquisitions. We believe that providing the non-GAAP measures excluding these costs and credits, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-17-000028:8k_2_02:48]
Restructuring charges (credits). These expenses are associated with re-aligning our business strategies based on current economic conditions. We have undertaken several restructuring plans in recent years. In connection with our restructuring initiatives, we incurred restructuring charges related to employee terminations, facility closures and early cancellation of certain contracts. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results in the current period.

[0001032975-17-000028:8k_2_02:49]
Gain (loss) on investments in privately held companies. We recognized gain (loss) related our investments in various privately-held companies, which varies depending on the operational and financial performance of the privately-held companies in which we invested. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-17-000028:8k_2_02:50]
Investigation and related expenses.  These expenses are forensic accounting, audit, consulting and legal fees related to the Audit Committee’s investigation and the formal investigation by and settlement with the Securities and Exchange Commission (SEC), together with accruals based on settlement with the SEC. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-17-000028:8k_2_02:51]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above and other events; the determination of which is based upon the nature of the underlying items, the mix of income and losses in jurisdictions and the relevant tax rates in which we operate.

[0001032975-17-000028:8k_2_02:52]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-17-000028:8k_2_02:53]
Additional Supplemental Financial Information - Constant Currency

[0001032975-17-000028:8k_2_02:54]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates.  Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.
