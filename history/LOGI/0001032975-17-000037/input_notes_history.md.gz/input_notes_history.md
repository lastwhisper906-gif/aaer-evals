# LOGI note change history — 0001032975-17-000005 → 0001032975-17-000037


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-07-27):
[0001032975-17-000037:note_history:1]
All of the Company’s peripherals products sold are covered by warranty to be free from defects in material and workmanship. For products launched prior to April 1, 2014, the standard warranty period was up to five years. Starting from April 1, 2014, the standard warranty for all new products launched was changed to two years from the date of purchase for European Countries and generally one year from date of purchase for all other countries.
  (was, 2017-02-06, similarity 0.632):
[0001032975-17-000005:note_history:1]
All of the Company’s peripherals products sold are covered by warranty to be free from defects in material and workmanship.  For products launched prior to April 1, 2014, the standard warranty period was up to five years. Starting from April 1, 2014, the standard warranty for all new products launched was changed to two years from date of purchase for European Countries and generally one year from date of purchase for all other countries.  At the time of sale, the Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. The Company’s estimate of costs to fulfill its warranty obligations is based on historical experience and expectations of future conditions. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly.

- changed (2017-07-27):
[0001032975-17-000037:note_history:2]
Changes in the Company’s warranty liability for the three months ended June 30, 2017 and 2016 were as follows (in thousands):
  (was, 2017-02-06, similarity 0.9231):
[0001032975-17-000005:note_history:2]
Changes in the Company’s warranty liability for the three and nine months ended December 31, 2016 and 2015 were as follows (in thousands):

- changed (2017-07-27):
[0001032975-17-000037:note_history:3]
|  |  | Three Months EndedJune 30, |
|  |  | 2017 |  | 2016 |
| Beginning of the period |  | $ | 21,911 |  |  | $ | 20,380 |  |
| Assumed from business acquisition |  | — |  |  | 1,813 |  |
| Provision |  | 5,124 |  |  | 3,177 |  |
| Settlements |  | (4,567 | ) |  | (3,428 | ) |
| Currency translation |  | (412 | ) |  | (190 | ) |
| End of the period |  | $ | 22,056 |  |  | $ | 21,752 |  |
  (was, 2017-02-06, similarity 0.6487):
[0001032975-17-000005:note_history:3]
|  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Beginning of the period | $ | 21,612 |  |  | $ | 20,399 |  |  | $ | 20,380 |  |  | $ | 21,710 |  |
| Assumed from business acquisition |  |  |  | — |  |  | 1,963 |  |  | — |  |
| Provision | 4,521 |  |  | 2,023 |  |  | 10,861 |  |  | 5,815 |  |
| Settlements | (3,550 | ) |  | (2,763 | ) |  | (10,430 | ) |  | (8,008 | ) |
| Currency impact | (462 | ) |  | (153 | ) |  | (653 | ) |  | (11 | ) |
| End of the period | $ | 22,121 |  |  | $ | 19,506 |  |  | $ | 22,121 |  |  | $ | 19,506 |  |

- added (2017-07-27):
[0001032975-17-000037:note_history:4]
Logitech Europe S.A., one of our wholly-owned subsidiaries, guaranteed payments of certain third-party contract manufacturers’ purchase obligations. As of June 30, 2017, the maximum amount of this guarantee was $3.8 million, of which $0.9 million of guaranteed purchase obligations were outstanding.

- changed (2017-07-27):
[0001032975-17-000037:note_history:5]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2017, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2017-02-06, similarity 0.9906):
[0001032975-17-000005:note_history:5]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2016, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

- changed (2017-07-27):
[0001032975-17-000037:note_history:6]
The stock purchase agreement entered on December 28, 2015 in connection with the investment by three venture capital firms in Lifesize contains representations, warranties and covenants of Logitech and Lifesize, Inc. to the Investors. Logitech has agreed, subject to certain limitations, to indemnify the Investors and certain persons related to the Investors for certain losses resulting from breaches of or inaccuracies in such representations, warranties and covenants as well as certain other obligations, including third-party expenses, restructuring costs and pre-closing tax obligations of Lifesize.
  (was, 2017-02-06, similarity 0.995):
[0001032975-17-000005:note_history:6]
The stock purchase agreement entered on December 28, 2015 in connection with the investment by three venture capital firms in Lifesize, Inc. contains representations, warranties and covenants of Logitech and Lifesize, Inc. to the Investors. Logitech has agreed, subject to certain limitations, to indemnify the Investors and certain persons related to the Investors for certain losses resulting from breaches of or inaccuracies in such representations, warranties and covenants as well as certain other obligations, including third-party expenses, restructuring costs and pre-closing tax obligations of Lifesize.

- changed (2017-07-27):
[0001032975-17-000037:note_history:7]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.
  (was, 2017-02-06, similarity 0.9992):
[0001032975-17-000005:note_history:7]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.

- removed (2017-07-27):
[0001032975-17-000005:note_history:8]
Other Contingencies

- removed (2017-07-27):
[0001032975-17-000005:note_history:9]
In April 2016, the Company entered into a settlement with the SEC related to the accounting for Revue inventory valuation reserves that resulted in the restatement described in the Fiscal Year 2014 Annual Report on Form 10-K, revision to its consolidated financial statements concerning warranty accruals and amortization of intangible assets presented in its Amended Annual Report on Form 10-K/A, filed on August 7, 2013, and its transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. The Company entered into the settlement without admitting or denying the findings of the SEC’s investigation and paid a civil penalty of $7.5 million in April 2016.

- removed (2017-07-27):
[0001032975-17-000005:note_history:10]
Logitech Europe S.A. guaranteed payments of certain third-party contract manufacturers’ purchase obligations. As of December 31, 2016, the maximum amount of this guarantee was $3.8 million, of which $1.7 million of guaranteed purchase obligations were outstanding.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-07-27):
[0001032975-17-000037:note_history:11]
Logitech was founded in Switzerland in 1981 and Logitech International S.A. has been the parent holding company of Logitech since 1988. Logitech International S.A. is a Swiss holding company with its registered office in Apples, Switzerland and headquarters in Lausanne, Switzerland, which conducts its business through subsidiaries in the Americas, Europe, Middle East and Africa ("EMEA") and Asia Pacific. Shares of Logitech International S.A. are listed on both the SIX Swiss Exchange under the trading symbol LOGN and the Nasdaq Global Select Market under the trading symbol LOGI.
  (was, 2017-02-06, similarity 0.9614):
[0001032975-17-000005:note_history:11]
Logitech was founded in Switzerland in 1981 and Logitech International S.A. has been the parent holding company of Logitech since 1988. Logitech International S.A. is a Swiss holding company with its registered office in Apples, Switzerland, which conducts its business through subsidiaries in the Americas, Europe, Middle East and Africa ("EMEA"), and Asia Pacific. Shares of Logitech International S.A. are listed on both the SIX Swiss Exchange under the trading symbol LOGN and the Nasdaq Global Select Market under the trading symbol LOGI.

- changed (2017-07-27):
[0001032975-17-000037:note_history:12]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three months ended June 30, 2017 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2018, or any future periods.
  (was, 2017-02-06, similarity 0.9573):
[0001032975-17-000005:note_history:12]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and nine months ended December 31, 2016 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2017, or any future periods.

- changed (2017-07-27):
[0001032975-17-000037:note_history:13]
Certain amounts from the comparative period in the accompanying unaudited condensed consolidated financial statements have been reclassified to conform to the condensed consolidated financial statement presentation as of and for the three months ended June 30, 2017.
  (was, 2017-02-06, similarity 0.9118):
[0001032975-17-000005:note_history:13]
Certain amounts from the comparative period in the accompanying unaudited condensed consolidated financial statements have been reclassified to conform to the condensed consolidated financial statement presentation as of and for the three and nine months ended December 31, 2016.

- changed (2017-07-27):
[0001032975-17-000037:note_history:14]
Other than the recent accounting pronouncements adopted, discussed below, there have been no substantial changes in the Company’s significant accounting policies during the three months ended June 30, 2017 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2017.
  (was, 2017-02-06, similarity 0.7905):
[0001032975-17-000005:note_history:14]
There have been no substantial changes in the Company’s significant accounting policies during the nine months ended December 31, 2016 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2016.

- added (2017-07-27):
[0001032975-17-000037:note_history:15]
The preparation of financial statements in conformity with GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill, intangible assets acquired from business acquisitions, warranty liabilities, accruals for customer programs and related breakage when appropriate, sales return reserves, allowance for doubtful accounts, inventory valuation, contingent consideration from business acquisitions and periodical reassessment of its fair value, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

- changed (2017-07-27):
[0001032975-17-000037:note_history:16]
Recent Accounting Pronouncements Adopted
  (was, 2017-02-06, similarity 0.8889):
[0001032975-17-000005:note_history:16]
Recent Accounting Pronouncements

- added (2017-07-27):
[0001032975-17-000037:note_history:17]
In July 2015, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2015-11, "Simplifying the Measurement of Inventory (Topic 330)" ("ASU 2015-11"). Topic 330, Inventory, previously required an entity to measure inventory at the lower of cost or market, with market value represented by replacement cost, net realizable value or net realizable value less a normal profit margin. ASU 2015-11 requires an entity to measure inventory at the lower of cost or net realizable value and is effective for fiscal years beginning after December 15, 2016, with early adoption permitted. The Company has adopted this standard effective April 1, 2017 which did not have a material impact on its condensed consolidated financial statements.

- added (2017-07-27):
[0001032975-17-000037:note_history:18]
In March 2016, the FASB issued ASU 2016-09, "Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting" ("ASU 2016-09"). ASU 2016-09 simplifies several aspects of the accounting for share-based payments, including immediate recognition of all excess tax benefits and deficiencies in the income statement, changing the threshold to qualify for equity classification up to the employees' maximum statutory tax rates, allowing an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures as they occur, and clarifying the classification on the statement of cash flows for the excess tax benefits and employee taxes paid when an employer withholds shares for tax withholding purposes. ASU 2016-09 is effective for fiscal years beginning after December 15, 2016, with early adoption permitted. The Company has adopted this standard effective April 1, 2017. Changes to the statements of cash flows related to the classification of excess tax benefits were implemented on a retroactive basis and accordingly, to conform to the current year presentation, the Company reclassified $3.3 million of excess tax benefits previously reported under financing activities to operating activities for the three months ended June 30, 2016 on its condensed consolidated statements of cash flows. Under the new standard, the Company accounts for forfeitures as they occur. The change in accounting for forfeitures resulted in a cumulative-effect adjustment to decrease retained earnings as of March 31, 2017 by $3.3 million. The Company further recognized a cumulative-effect adjustment to increase retained earnings as of March 31, 2017 by $57.2 million upon adoption of the new guidance to account for gross excess tax benefits of $75.2 million that were previously not recognized because the related tax deduction had not reduced current income taxes, offset by a valuation allowance of $18.0 million to reduce the deferred tax assets to amounts that are more likely than not to be realized.

- added (2017-07-27):
[0001032975-17-000037:note_history:19]
In January 2017, the FASB issued ASU 2017-04, "Simplifying the Test for Goodwill Impairment (Topic

- added (2017-07-27):
[0001032975-17-000037:note_history:20]
350)" ("ASU 2017-04"), which removes Step 2 from the goodwill impairment test. ASU 2017-04 is effective for annual or any interim goodwill impairments in annual periods beginning December 15, 2019, with early adoption permitted. The Company has adopted this standard effective April 1, 2017 which did not have a material impact on its condensed consolidated financial statements.

- added (2017-07-27):
[0001032975-17-000037:note_history:21]
In May 2017, the FASB issued ASU 2017-09, "Compensation-Stock Compensation (Topic 718): Scope of

- added (2017-07-27):
[0001032975-17-000037:note_history:22]
Modification Accounting" ("ASU 2017-09"), which provides guidance about which changes to the terms or conditions

- added (2017-07-27):
[0001032975-17-000037:note_history:23]
of a share-based payment award require an entity to apply modification accounting in Topic 718. ASU 2017-09 is

- added (2017-07-27):
[0001032975-17-000037:note_history:24]
effective for annual periods beginning after December 15, 2017, with early adoption permitted, including adoption in any interim period for which financial statements have not yet been issued. The Company has adopted this standard effective April 1, 2017 which did not have a material impact on its condensed consolidated financial statements.

- added (2017-07-27):
[0001032975-17-000037:note_history:25]
Recent Accounting Pronouncements To Be Adopted

- added (2017-07-27):
[0001032975-17-000037:note_history:26]
In May 2014, the FASB issued ASU No. 2014-09, "Revenue from Contracts with Customers (Topic 606)" ("ASU 2014-09") which supersedes the revenue recognition requirements under ASC 605, Revenue Recognition. ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. Under the new model, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The new standard requires reporting companies to disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The new standard will become effective for the Company on April 1, 2018. The standard allows for either a "full retrospective" adoption, meaning the standard is applied to all of the periods presented subject to practical expedients, or a "modified retrospective" adoption, meaning the standard is applied only in the initial year, or interim period in year of initial application with a cumulative adjustment to opening retained earnings for existing contracts. The Company currently expects to utilize the modified retrospective transition method. The Company continues to evaluate the impact this new standard could have on the current contracts with customers and the accruals of various sales and marketing programs the Company offers and on the related breakage estimates. The Company has not completed its analysis of the impact to its condensed consolidated financial statements and this information will not be available until the Company completes its full assessment. It is possible that during the fiscal year 2018, the Company may identify certain areas which may result in material impact on the Company’s condensed consolidated financial statements, or the Company may revise its adoption method.

- added (2017-07-27):
[0001032975-17-000037:note_history:27]
In January 2016, the FASB issued ASU 2016-01, “Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10)” ("ASU 2016-01"). ASU 2016-01 is effective for annual periods beginning after December 15, 2017, including interim periods within those annual periods, with early adoption permitted. The Company does not believe that the adoption of ASU 2016-01 will have a material impact on its condensed consolidated financial statements and will adopt this standard effective April 1, 2018.

- added (2017-07-27):
[0001032975-17-000037:note_history:28]
In February 2016, the FASB issued ASU 2016-02, "Leases (Topic 842)" ("ASU 2016-02"), which requires the recognition of lease assets and lease liabilities arising from operating leases in the statement of financial position. ASU 2016-02 is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years, with early adoption permitted. The Company is evaluating the full effect that ASU 2016-02 will have on its condensed consolidated financial statements and will adopt this standard effective April 1, 2019.

- added (2017-07-27):
[0001032975-17-000037:note_history:29]
In October 2016, the FASB issued ASU 2016-16, "Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory"  ("ASU 2016-16"), which eliminates the deferral of income tax effects of intra-entity asset transfers until the transferred asset is sold to an unrelated party or recovered through use however, this standard does not apply to intra-entity transfer of inventory.  ASU 2016-16 is effective for annual periods beginning after December 15, 2017, including interim periods within those annual periods, with early adoption permitted but only in the first interim period of an annual period.  The cumulative effect of change on equity upon adoption is to be quantified under the modified retrospective approach and recorded as of the beginning of the period of adoption.  The Company is evaluating the full effect that ASU 2016-16 will have on its condensed consolidated financial statements and will adopt this standard effective April 1, 2018.

- added (2017-07-27):
[0001032975-17-000037:note_history:30]
In December 2016, the FASB issued ASU 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash" ("ASU 2016-18"), which requires that a statement of cash flows explains the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents.  ASU 2016-18 is effective for annual periods beginning after December 15, 2017, including interim periods within those annual periods, with early adoption permitted. The adoption of this standard should be applied using a retrospective transition method to each period presented. The Company does not expect the adoption of ASU 2016-18 will have a material impact on its condensed consolidated financial statements and will adopt this standard effective April 1, 2018.

- added (2017-07-27):
[0001032975-17-000037:note_history:31]
In March 2017, the FASB issued ASU 2017-07, "Compensation-Retirement Benefit (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost" ("ASU 2017-07"), which requires that the Company disaggregate the service cost component from the other components of net benefit cost, and also provides guidance on how to present the service cost component and the other components of net benefit cost in the income statement and allow only the service cost component of net benefit cost to be eligible for capitalization. ASU 2017-07 is effective for annual periods beginning after December 15, 2017, including interim periods within those annual periods, with early adoption permitted. The Company does not expect the adoption of ASU 2017-07 will have a material impact on its condensed consolidated financial statements and will adopt this standard effective April 1, 2018.

- removed (2017-07-27):
[0001032975-17-000005:note_history:32]
The preparation of financial statements in conformity with GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Examples of significant estimates and assumptions made by management involve the fair value of goodwill, intangible assets acquired from business acquisitions, warranty liabilities, accruals for discretionary customer programs, sales return reserves, allowance for doubtful accounts, inventory valuation, restructuring charges, contingent consideration from business acquisitions and periodical reassessment of its fair value, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

- removed (2017-07-27):
[0001032975-17-000005:note_history:33]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers (Topic 606)" ("ASU 2014-09"). ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. Under the new model, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In addition, the new standard requires that reporting companies disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. ASU 2014-09 was originally to be effective for the Company on April 1, 2017. In July 2015, the FASB affirmed a one-year deferral of the effective date of the new revenue standard. The new standard will become effective for the Company on April 1, 2018. Early application is permitted but not before the original effective date of annual periods beginning after December 15, 2016. The new standard is required to be applied retrospectively to each prior reporting period presented or retrospectively with the cumulative effect of initially applying it recognized at the date of initial application. Subsequently, the FASB has issued the following standards related to ASU 2014-09: ASU No. 2016-08, "Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations" (“ASU 2016-08”); ASU No. 2016-10, "Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing" (“ASU 2016-10”); and ASU No. 2016-12, "Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients" (“ASU 2016-12”). The Company must adopt ASU 2016-08, ASU 2016-10 and ASU 2016-12 with ASU 2014-09 (collectively, the “new revenue standards”). The Company has not yet selected a transition method and is in process of assessing all potential impacts of the new standard.  The new revenue standard will be adopted effective April 1, 2018.

- removed (2017-07-27):
[0001032975-17-000005:note_history:34]
In July 2015, the FASB issued ASU No. 2015-11, "Simplifying the Measurement of Inventory (Topic 330)" ("ASU 2015-11"). Topic 330, Inventory, currently requires an entity to measure inventory at the lower of cost or market, with market value represented by replacement cost, net realizable value or net realizable value less a normal profit margin. The amendments in ASU 2015-11 require an entity to measure inventory at the lower of cost or net realizable value. ASU 2015-11 is effective in the first quarter of fiscal year 2018 for the Company, with early adoption permitted. The Company does not expect to early adopt this guidance and does not expect the adoption of this guidance to have a material impact on its condensed consolidated financial statements.

- removed (2017-07-27):
[0001032975-17-000005:note_history:35]
In January 2016, the FASB issued ASU 2016-01 “Financial Instruments- Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10)”. The guidance is effective in the first quarter of fiscal year 2018 for the Company, with early adoption permitted. The Company does not expect to early adopt this guidance and does not believe that the adoption of this guidance will have a material impact on its condensed consolidated financial statements.

- removed (2017-07-27):
[0001032975-17-000005:note_history:36]
In February 2016, the FASB issued ASU 2016-02 "Leases (Topic 842)" ("ASU 2016-02"), which requires the recognition of lease assets and lease liabilities arising from operating leases in the statement of financial position. This guidance is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. The Company is evaluating the full effect that ASU 2016-02 will have on its condensed consolidated financial statements and will adopt the standard effective April 1, 2019.

- removed (2017-07-27):
[0001032975-17-000005:note_history:37]
In March 2016, the FASB issued ASU 2016-09 "Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting" ("ASU 2016-09"). The amendment simplifies several aspects of the accounting for share-based payments, including immediate recognition of all excess tax benefits and deficiencies in the income statement, changing the threshold to qualify for equity classification up to the employees' maximum statutory tax rates, allowing an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures as they occur, and clarifying the classification on the statement of cash flows for the excess tax benefit and employee taxes paid when an employer withholds shares for tax-withholding purposes. ASU 2016-09 is effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. Early adoption is permitted in any interim or annual period. The Company will adopt this standard effective April 1, 2017 and is in the process of evaluating the effect that ASU 2016-09 will have on its condensed consolidated financial statements.

- removed (2017-07-27):
[0001032975-17-000005:note_history:38]
In August 2016, the FASB issued ASU 2016-15 "Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments" ("ASU 2016-15"), which gives guidance and reduces diversity in practice with respect to certain types of cash flows. The Company has early adopted this guidance during the second quarter of fiscal year 2017 and the adoption did not impact its condensed consolidated financial statements.

- removed (2017-07-27):
[0001032975-17-000005:note_history:39]
In October 2016, the FASB issued ASU 2016-16 "Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory"  ("ASU 2016-16"), which eliminates the deferral of income tax effects of intra-entity asset transfers until the transferred asset is sold to an unrelated party or recovered through use.  ASU 2016-16, however, does not apply to intra-entity transfer of inventory.  The guidance is effective for annual periods beginning after December 15, 2017 and interim reporting periods within those annual periods.  Early adoption is permitted but only in the first interim period of a fiscal year.  The cumulative effect of change on equity upon adoption is to be quantified under the modified retrospective approach and recorded as of the beginning of the period of adoption.  The Company is evaluating the full effect that ASU 2016-16 will have on its condensed consolidated financial statements and will adopt the standard effective April 1, 2018.

- removed (2017-07-27):
[0001032975-17-000005:note_history:40]
In December 2016, the FASB issued ASU 2016-18 "Statement of Cash Flows (Topic 230): Restricted Cash" ("ASU 2016-18"), which requires that a statement of cash flows explains the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents.  The standard is effective for annual periods beginning after December 15, 2017 and interim reporting periods within those annual periods, with early adoption permitted. The adoption of this standard should be applied using a retrospective transition method to each period presented. The Company does not expect the adoption of ASU 2016-18 will have a material impact on its condensed consolidated financial statements and is evaluating the timing of adoption of this standard.

- removed (2017-07-27):
[0001032975-17-000005:note_history:41]
In January 2017, the FASB issued ASU 2017-04, "Simplifying the Test for Goodwill Impairment (Topic 330)"("ASU 2017-04"),  which removes Step 2 from the goodwill impairment test. The standard will be effective for the Company for annual or any interim goodwill impairments in fiscal year beginning December 15, 2019, with early adoption permitted. The Company does not expect the adoption of ASU 2017-14 will have an impact on its condensed consolidated financial statements and is evaluating the timing of adoption of this standard.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-07-27):
[0001032975-17-000037:note_history:42]
The Company had several uncommitted, unsecured bank lines of credit aggregating $38.9 million as of June 30, 2017. There are no financial covenants under these lines of credit with which the Company must comply. As of June 30, 2017, the Company had outstanding bank guarantees of $23.3 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of June 30, 2017 or March 31, 2017.
  (was, 2017-02-06, similarity 0.9127):
[0001032975-17-000005:note_history:42]
The Company had several uncommitted, unsecured bank lines of credit aggregating $43.2 million as of December 31, 2016. There are no financial covenants under these lines of credit with which the Company must comply. As of December 31, 2016, the Company had outstanding bank guarantees of $18.3 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of December 31, 2016 or March 31, 2016.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2017-07-27):
[0001032975-17-000037:note_history:43]
Subsequent Event

- added (2017-07-27):
[0001032975-17-000037:note_history:44]
On July 10, 2017, the Company signed an agreement to acquire certain assets and liabilities constituting the Astro Gaming business from AG Acquisition Corporation for $85 million in cash.  Astro Gaming is a leading console gaming brand and has a history of producing award-winning headsets for professional gamers and enthusiasts. The transaction is expected to close in early August, 2017 and is subject to receipt of regulatory approvals in various jurisdictions and other closing conditions.
