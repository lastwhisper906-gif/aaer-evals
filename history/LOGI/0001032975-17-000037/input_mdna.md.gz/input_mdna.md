# LOGI MD&A — 0001032975-17-000037


## mdna

[0001032975-17-000037:mdna:1]
[same as prior period, unchanged from 0001032975-17-000005:mdna:1]

[0001032975-17-000037:mdna:2]
[same as prior period, unchanged from 0001032975-17-000005:mdna:2]

[0001032975-17-000037:mdna:3]
[same as prior period, unchanged from 0001032975-17-000005:mdna:3]

[0001032975-17-000037:mdna:4]
Logitech is a world leader in designing, manufacturing and marketing products that have an everyday place in people's lives, connecting them to the digital experiences they care about. More than 35 years ago Logitech created products to improve experiences around the PC platform, and now it is designing products that enable better experiences consuming, sharing and creating any digital content (e.g. music, gaming, video), whether it is on a computer, mobile device or in the cloud. Logitech's brands include Logitech, Jaybird, Logitech G and Ultimate Ears.

[0001032975-17-000037:mdna:5]
Our products participate in five large markets that all have growth opportunities: Music, Gaming, Video Collaboration, Smart Home and Creativity & Productivity. We sell our products to a broad network of domestic and international customers, including direct sales to retailers and e-tailers, and indirect sales through distributors. Our worldwide channel network includes consumer electronics distributors, retailers, mass merchandisers, specialty electronics stores, computer and telecommunications stores, value-added resellers and online merchants.

[0001032975-17-000037:mdna:6]
[same as prior period, unchanged from 0001032975-17-000005:mdna:15]

[0001032975-17-000037:mdna:7]
On July 10, 2017, we signed an agreement to acquire certain assets and liabilities constituting the Astro Gaming business from AG Acquisition Corporation for $85 million in cash. Astro Gaming is a leading console gaming brand and has a history of producing award-winning headsets for professional gamers and enthusiasts. The transaction is expected to close in early August, 2017 and is subject to receipt of regulatory approvals in various jurisdictions and other closing conditions.

[0001032975-17-000037:mdna:8]
[same as prior period, unchanged from 0001032975-17-000005:mdna:20]

[0001032975-17-000037:mdna:9]
Our net sales for the three months ended June 30, 2017 increased 10% compared to the three months ended June 30, 2016, due to stronger net sales across all regions. Net sales increased 10%, 5% and 17% in the Americas, EMEA and Asia Pacific, respectively.

[0001032975-17-000037:mdna:10]
Our gross margin for the three months ended June 30, 2017 increased to 36.5% from 35.1% for the three months ended June 30, 2016. The increase in gross margin was primarily driven by product cost reductions as well as greater supply chain efficiencies, partially offset by an increase of promotions and an unfavorable fluctuation in currency exchange rates.

[0001032975-17-000037:mdna:11]
Operating expenses for the three months ended June 30, 2017 were $162.2 million, or 30.6% of net sales, compared to $142.8 million, or 29.8% of net sales in the same period of the prior fiscal year. The increase was primarily driven by higher personnel-related costs due to increased headcount and higher external expenses to support the advertising and marketing efforts for our new products, partially offset by a credit from change in fair value of contingent consideration from the Jaybird Acquisition.

[0001032975-17-000037:mdna:12]
Net income from continuing operations for the three months ended June 30, 2017 was $37.0 million, compared to $21.9 million for the three months ended June 30, 2016.

[0001032975-17-000037:mdna:13]
[same as prior period, unchanged from 0001032975-17-000005:mdna:26]

[0001032975-17-000037:mdna:14]
[same as prior period, unchanged from 0001032975-17-000005:mdna:28]

[0001032975-17-000037:mdna:15]
Our strategy focuses on five large multi-category markets, including Music, Gaming, Video Collaboration, Smart Home and Creativity & Productivity. We see opportunities to deliver growth in all these markets.

[0001032975-17-000037:mdna:16]
[same as prior period, unchanged from 0001032975-17-000005:mdna:30]

[0001032975-17-000037:mdna:17]
[same as prior period, unchanged from 0001032975-17-000005:mdna:31]

[0001032975-17-000037:mdna:18]
Music:  The music market grew during the first quarter of fiscal year 2018 driven by growing consumption of music through mobile devices such as smartphones and tablets. This market growth, together with our investments in the UE brand and Jaybird brand, new channel expansion, acquisitions of new portfolios and our ability to gain market share during fiscal year 2017, has driven our growth in this market.

[0001032975-17-000037:mdna:19]
Gaming:  The PC Gaming platform continues to show strong growth as online gaming, multi-platform experiences, and eSports gain greater popularity and gaming content becomes increasingly more demanding. We

[0001032975-17-000037:mdna:20]
believe Logitech is well positioned to benefit from the gaming market growth, together with strengthening our portfolio in the console-gaming market.

[0001032975-17-000037:mdna:21]
Video Collaboration: We are continuing our efforts to create and sell innovative products, including Video Collaboration products, to accommodate the increasing demand from medium-sized meeting rooms to small-sized rooms such as huddle rooms. We will continue to invest in select business-specific products, targeted product marketing and sales channel development.

[0001032975-17-000037:mdna:22]
Smart Home:  This market increased in fiscal year 2017 and has continued growing in the first quarter of fiscal year 2018. In October 2016, we introduced a new Amazon Alexa skill that enables voice control of the living room entertainment experience using a Logitech Harmony Hub with Alexa-enabled devices such as the Amazon Echo or Echo Dot. Through Harmony, Alexa can turn on/off and control a TV and AV system. We have also seen early success with the professional installer channel through the recent introduction of the Harmony Pro. We will continue to explore other innovative experiences for the Smart Home.

[0001032975-17-000037:mdna:23]
Creativity & Productivity: Although new PC shipments continue to decline, the installed base of PC users is large.  We believe that innovative PC peripherals, such as our mice and keyboards, can renew the PC usage experience, providing growth opportunities. Smaller mobile computing devices, such as tablets, have created new markets and usage models for peripherals and accessories. We offer a number of products to enhance the use of mobile devices, including keyboard folios for the iPad and iPad mini, and keyboard covers and folios for the iPad Air. However, we have seen the market decline for the iPad platform, which might impact the sales of our tablet accessories.

[0001032975-17-000037:mdna:24]
[same as prior period, unchanged from 0001032975-17-000005:mdna:37]

[0001032975-17-000037:mdna:25]
We have historically experienced higher net sales in our third fiscal quarter ending December 31, compared to other fiscal quarters in our fiscal year, due in part to seasonal holiday demand. Additionally, new product introductions and business acquisitions can significantly impact net sales, product costs and operating expenses. Product introductions can also impact our net sales to our distribution channels as these channels are filled with new product inventory following a product introduction, and often channel inventory of an earlier model product declines as the next related major product launch approaches. Net sales can also be affected when consumers and distributors anticipate a product introduction. However, neither historical seasonal patterns nor historical patterns of product introductions should be considered reliable indicators of our future pattern of product introductions, future net sales or financial performance.

[0001032975-17-000037:mdna:26]
[same as prior period, unchanged from 0001032975-17-000005:mdna:39]

[0001032975-17-000037:mdna:27]
The preparation of financial statements and related disclosures in conformity with GAAP requires us to make judgments, estimates and assumptions that affect reported amounts of assets, liabilities, goodwill and intangible assets from business acquisitions, net sales and expenses, contingent consideration, and the disclosure of contingent assets and liabilities.

[0001032975-17-000037:mdna:28]
[same as prior period, unchanged from 0001032975-17-000005:mdna:41]

[0001032975-17-000037:mdna:29]
[same as prior period, unchanged from 0001032975-17-000005:mdna:42]

[0001032975-17-000037:mdna:30]
Other than the recent accounting pronouncement adoptions discussed below, there have been no substantial changes in the Company’s significant accounting policies during the three months ended June 30, 2017 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2017.

[0001032975-17-000037:mdna:31]
[same as prior period, unchanged from 0001032975-17-000005:mdna:54]

[0001032975-17-000037:mdna:32]
In July 2015, the FASB issued ASU No. 2015-11, "Simplifying the Measurement of Inventory (Topic 330)" ("ASU 2015-11"). Topic 330, Inventory, previously required an entity to measure inventory at the lower of cost or market, with market value represented by replacement cost, net realizable value or net realizable value less a normal profit margin. ASU 2015-11 requires an entity to measure inventory at the lower of cost or net realizable value and effective for fiscal years beginning after December 15, 2016, with early adoption permitted. We have adopted this standard effective April 1, 2017 which did not have a material impact on our condensed consolidated financial statements.

[0001032975-17-000037:mdna:33]
In March 2016, the FASB issued ASU 2016-09, "Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting" ("ASU 2016-09"). ASU 2016-09 simplifies several aspects of the accounting for share-based payments, including immediate recognition of all excess tax benefits and deficiencies in the income statement, changing the threshold to qualify for equity classification up to the employees' maximum statutory tax rates, allowing an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures as they occur, and clarifying the classification on the statement of cash flows for the excess tax benefits and employee taxes paid when an employer withholds shares for tax withholding purposes. ASU 2016-09 is effective for fiscal years beginning after December 15, 2016, with early adoption permitted. We have adopted this standard effective April 1, 2017. Changes to the statements of cash flows related to the classification of excess tax benefits were implemented on a retroactive basis and accordingly, to conform to the current year presentation, we reclassified $3.3 million of excess tax benefits previously reported under financing activities to operating activities for the three months ended June 30, 2016 on its condensed consolidated statements of cash flows. Under the new standard, we account for forfeitures as they occur. The change in accounting for forfeitures resulted in a cumulative-effect adjustment to decrease retained earnings as of March 31, 2017 by $3.3 million. We further recognized a cumulative-effect adjustment to increase retained earnings as of March 31, 2017 by $57.2 million upon adoption of the new guidance to account for gross excess tax benefits of $75.2 million that were previously not recognized because the related tax deduction had not reduced current income taxes, offset by a valuation allowance of $18.0 million to reduce the deferred tax assets to amounts that are more likely than not to be realized.

[0001032975-17-000037:mdna:34]
In January 2017, the FASB issued ASU 2017-04, "Simplifying the Test for Goodwill Impairment (Topic 350)" ("ASU 2017-04"), which removes Step 2 from the goodwill impairment test. ASU 2017-04 is effective for for annual or any interim goodwill impairments in annual periods beginning December 15, 2019, with early adoption permitted. We have adopted this standard effective April 1, 2017 which did not have a material impact on our condensed consolidated financial statements.

[0001032975-17-000037:mdna:35]
In May 2017, the FASB issued ASU 2017-09, "Compensation-Stock Compensation (Topic 718): Scope of Modification Accounting" ("ASU 2017-09"), which provides guidance about which changes to the terms or conditions of a share-based payment award require an entity to apply modification accounting in Topic 718. ASU 2017-09 is effective for annual periods beginning after December 15, 2017, with early adoption permitted, including adoption in any interim period for which financial statements have not yet been issued. We have adopted this standard effective April 1, 2017 which did not have a material impact on our condensed consolidated financial statements.

[0001032975-17-000037:mdna:36]
Refer to Note 1 to the condensed consolidated financial statements included in this Quarterly Report on Form 10-Q for recent accounting pronouncements to be adopted.

[0001032975-17-000037:mdna:37]
[same as prior period, unchanged from 0001032975-17-000005:mdna:56]

[0001032975-17-000037:mdna:38]
[same as prior period, unchanged from 0001032975-17-000005:mdna:57]

[0001032975-17-000037:mdna:39]
Given our global sales presence and the reporting of our financial results in U.S. Dollars, our financial results could be affected by significant shifts in currency exchange rates. See “Results of Operations” for information on the effect of currency exchange results on our net sales. If the U.S. Dollar appreciates in comparison to other currencies in future periods, this will affect our results of operations in future periods as well.

[0001032975-17-000037:mdna:40]
[same as prior period, unchanged from 0001032975-17-000005:mdna:58]

[0001032975-17-000037:mdna:41]
[same as prior period, unchanged from 0001032975-17-000005:mdna:59]

[0001032975-17-000037:mdna:42]
Net sales for the three months ended June 30, 2017 and 2016 were as follows (Dollars in thousands):

[0001032975-17-000037:mdna:43]
|  |  | Three Months EndedJune 30, |
|  |  | 2017 |  | 2016 |  | Change |
| Net Sales |  | $ | 529,946 |  |  | $ | 479,864 |  |  | 10 | % |

[0001032975-17-000037:mdna:44]
Our net sales in the three months ended June 30, 2017 increased 10%, compared to the same period of the prior fiscal year. Sales increased across all three regions during the three months ended June 30, 2017. If currency exchange rates had been constant in the three months ended June 30, 2017 and 2016, our constant dollar sales growth rates would have been 13%. We grew across most of our product categories, out of which Gaming, Video Collaboration, Tablet and Other Accessories, and Smart Home grew double digits.

[0001032975-17-000037:mdna:45]
[same as prior period, unchanged from 0001032975-17-000005:mdna:66]

[0001032975-17-000037:mdna:46]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Canadian Dollar, Taiwan New Dollar, British Pound and Australian Dollar. During the three months ended June 30, 2017, 47% of our net sales were denominated in currencies other than the U.S. Dollar.

[0001032975-17-000037:mdna:47]
Net Sales by Region

[0001032975-17-000037:mdna:48]
The following table presents the change in net sales by region for the three months ended June 30, 2017, compared with the three months ended June 30, 2016:

[0001032975-17-000037:mdna:49]
|  |  | Three Months EndedJune 30, 2017Change in Sales |
| Americas |  | 10 | % |
| EMEA |  | 5 |  |
| Asia Pacific |  | 17 |  |

[0001032975-17-000037:mdna:50]
[same as prior period, unchanged from 0001032975-17-000005:mdna:71]

[0001032975-17-000037:mdna:51]
Net sales in the Americas increased 10% during the three months ended June 30, 2017, compared to the same period of the prior fiscal year. If currency exchange rates had been constant in the three months ended June 30, 2017 and 2016, our constant dollar sales growth rate would have been 11% in the Americas. The increase in the period was driven by growth in Tablet and Other Accessories, Video Collaboration, Mobile Speakers, Gaming and Smart Home, partially offset by declines in sales for Audio PC & Wearables.

[0001032975-17-000037:mdna:52]
[same as prior period, unchanged from 0001032975-17-000005:mdna:73]

[0001032975-17-000037:mdna:53]
Net sales in the EMEA increased 5% during the three months ended June 30, 2017, compared to the same period of the prior fiscal year. If currency exchange rates had been constant in the three months ended June 30, 2017 and 2016, our constant dollar retail sales growth rates would have been 11%. The growth in the periods was driven by Video Collaboration and Gaming, partially offset by a decline in sales for Audio PC & Wearables.

[0001032975-17-000037:mdna:54]
[same as prior period, unchanged from 0001032975-17-000005:mdna:75]

[0001032975-17-000037:mdna:55]
Net sales in the Asia Pacific increased 17% during the three months ended June 30, 2017, compared to the same period of the prior fiscal year. If currency exchange rate had been constant in the three months ended June 30, 2017 and 2016, our constant dollar sales growth rate would have been 19%. The growth in the period was driven by Gaming, Video Collaboration, Mobile Speakers, Pointing Devices and Audio PC & Wearables, partially offset by a decline in sales for Keyboards and Combos.

[0001032975-17-000037:mdna:56]
Net Sales by Product Categories

[0001032975-17-000037:mdna:57]
Net sales by product category for the three months ended June 30, 2017 and 2016 were as follows (Dollars in thousands):

[0001032975-17-000037:mdna:58]
|  |  | Three Months EndedJune 30, |
|  |  | 2017 |  | 2016 |  | Change |
| Mobile Speakers |  | $ | 62,918 |  |  | $ | 57,296 |  |  | 10 | % |
| Audio-PC & Wearables |  | 50,202 |  |  | 56,579 |  |  | (11 | ) |
| Gaming |  | 77,708 |  |  | 56,500 |  |  | 38 |  |
| Video Collaboration |  | 35,617 |  |  | 23,910 |  |  | 49 |  |
| Smart Home |  | 16,466 |  |  | 11,167 |  |  | 47 |  |
| Pointing Devices |  | 122,074 |  |  | 116,783 |  |  | 5 |  |
| Keyboards & Combos |  | 116,113 |  |  | 118,019 |  |  | (2 | ) |
| Tablet & Other Accessories |  | 23,218 |  |  | 13,885 |  |  | 67 |  |
| PC Webcams |  | 25,625 |  |  | 25,262 |  |  | 1 |  |
| Other (1) |  | 5 |  |  | 463 |  |  | (99 | ) |
| Total net sales |  | $ | 529,946 |  |  | $ | 479,864 |  |  | 10 |  |

[0001032975-17-000037:mdna:59]
(1) Other category includes products that we currently intend to transition out of, or have already transitioned out of, because they are no longer strategic to our business.

[0001032975-17-000037:mdna:60]
Net Sales by Product Categories

[0001032975-17-000037:mdna:61]
[same as prior period, unchanged from 0001032975-17-000005:mdna:82]

[0001032975-17-000037:mdna:62]
[same as prior period, unchanged from 0001032975-17-000005:mdna:83]

[0001032975-17-000037:mdna:63]
Our Mobile Speakers category is made up entirely of bluetooth wireless speakers.

[0001032975-17-000037:mdna:64]
Net sales of Mobile Speakers increased 10% for the three months ended June 30, 2017, compared to the same period of the prior fiscal year. Mobile Speaker sales increased primarily due to the introduction of the UE WonderBoom in the first quarter of fiscal year 2018.

[0001032975-17-000037:mdna:65]
[same as prior period, unchanged from 0001032975-17-000005:mdna:86]

[0001032975-17-000037:mdna:66]
Our Audio-PC & Wearables category comprises PC speakers, PC headsets, in-ear headphones and premium wireless audio wearables.

[0001032975-17-000037:mdna:67]
Audio-PC & Wearables net sales decreased 11% for the three months ended June 30, 2017, compared to the same period of the prior fiscal year. The decrease was primarily driven by a decline in sales for Jaybird Freedom X2 wireless earbuds, which was phased out in the third quarter of fiscal year 2017, and PC speakers systems, partially offset by an increase in sales of Jaybird X3 Sport Bluetooth earbuds, which was introduced in the third quarter of fiscal year 2017.

[0001032975-17-000037:mdna:68]
[same as prior period, unchanged from 0001032975-17-000005:mdna:89]

[0001032975-17-000037:mdna:69]
[same as prior period, unchanged from 0001032975-17-000005:mdna:90]

[0001032975-17-000037:mdna:70]
Our Gaming category comprises gaming mice, keyboards, headsets, gamepads, steering wheels and Saitek simulation controllers.

[0001032975-17-000037:mdna:71]
Gaming net sales increased 38% for the three months ended June 30, 2017, compared to the same period of the prior fiscal year.  The significant increase was primarily driven by the continued success of our G502 Proteus Spectrum gaming mouse, G29 Driving Force Race Wheel, and the introductions of our G413 Prodigy Mechanical Gaming Keyboard and G203 Prodigy gaming mouse, partially offset by a decline in sales of the G430 gaming headset.

[0001032975-17-000037:mdna:72]
[same as prior period, unchanged from 0001032975-17-000005:mdna:93]

[0001032975-17-000037:mdna:73]
[same as prior period, unchanged from 0001032975-17-000005:mdna:94]

[0001032975-17-000037:mdna:74]
Our Video Collaboration category primarily includes products which combine audio and video and other products that can connect small- and medium-sized user groups.

[0001032975-17-000037:mdna:75]
Net sales of Video Collaboration increased 49% in the three months ended June 30, 2017, compared to the same period of the prior fiscal year. The increase was primarily due to the continued success of our Logitech Group conference camera, as well as the introduction of Brio 4K Pro Webcam and Logitech Smart Dock in the first quarter of fiscal year 2018.

[0001032975-17-000037:mdna:76]
[same as prior period, unchanged from 0001032975-17-000005:mdna:97]

[0001032975-17-000037:mdna:77]
Smart Home

[0001032975-17-000037:mdna:78]
Our Smart Home category includes our Harmony line of advanced home entertainment controllers and new products dedicated to controlling emerging categories of connected smart home devices such as lighting, thermostats and door locks.

[0001032975-17-000037:mdna:79]
Smart Home net sales increased 47% during the three months ended June 30, 2017, compared to the same period of the prior fiscal year. The increase was primarily due to continued success of our Harmony Elite remote and Harmony Home Hub, as well as the introduction of a new Amazon Alexa skill that enables voice control of the living room entertainment experience using a Logitech Harmony Hub with Alexa-enabled devices in the third quarter of fiscal year 2017.

[0001032975-17-000037:mdna:80]
[same as prior period, unchanged from 0001032975-17-000005:mdna:101]

[0001032975-17-000037:mdna:81]
[same as prior period, unchanged from 0001032975-17-000005:mdna:102]

[0001032975-17-000037:mdna:82]
Our Pointing Devices category comprises PC and Mac-related mice, touchpads and presenters.

[0001032975-17-000037:mdna:83]
Net sales of Pointing Devices increased 5% during the three months ended June 30, 2017, compared to the same periods of the prior fiscal year. The growth was driven by the success of our MX Master 2S wireless mouse launched in the first quarter of fiscal year 2018.

[0001032975-17-000037:mdna:84]
[same as prior period, unchanged from 0001032975-17-000005:mdna:105]

[0001032975-17-000037:mdna:85]
Our Keyboards & Combos category comprises PC keyboards and keyboard/mice combo products.

[0001032975-17-000037:mdna:86]
Net sales of Keyboards & Combos decreased 2% in the three months ended June 30, 2017, compared to the same period of the prior fiscal year. The decrease was primarily driven by a decline in sales of our K400 Plus wireless touch keyboard, and MK710 and MK320 wireless keyboard and mouse combo, partially offset by an increase in sales for the MK550 wireless keyboard and mouse combo.

[0001032975-17-000037:mdna:87]
[same as prior period, unchanged from 0001032975-17-000005:mdna:108]

[0001032975-17-000037:mdna:88]
Our Tablet & Other Accessories category comprises keyboards and covers for tablets and smartphones as well as other accessories for mobile devices.

[0001032975-17-000037:mdna:89]
Net sales of Tablet & Other Accessories increased 67% in the three months ended June 30, 2017, compared to the same period of the prior fiscal year. The significant growth is the result of the continued success of our Create tablet keyboard case and Rugged Combo case for iPad Pro, which were both introduced in the fourth quarter of fiscal year 2017.

[0001032975-17-000037:mdna:90]
[same as prior period, unchanged from 0001032975-17-000005:mdna:111]

[0001032975-17-000037:mdna:91]
Our PC Webcams category comprises PC-based webcams targeted primarily at consumers.

[0001032975-17-000037:mdna:92]
PC Webcams net sales remained relatively flat for the three months ended June 30, 2017, compared to the same period of the prior fiscal year.

[0001032975-17-000037:mdna:93]
[same as prior period, unchanged from 0001032975-17-000005:mdna:115]

[0001032975-17-000037:mdna:94]
Gross profit for the three months ended June 30, 2017 and 2016 was as follows (Dollars in thousands):

[0001032975-17-000037:mdna:95]
|  |  | Three Months EndedJune 30, |
|  |  | 2017 |  | 2016 |
| Net sales |  | $ | 529,946 |  |  | $ | 479,864 |  |
| Gross profit |  | $ | 193,668 |  |  | $ | 168,626 |  |
| Gross margin |  | 36.5 | % |  | 35.1 | % |

[0001032975-17-000037:mdna:96]
Gross profit consists of net sales, less cost of goods sold (which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, royalties, costs of purchasing components from outside suppliers, distribution costs, warranty costs, customer support, shipping and handling cost, outside processing costs and write-down of inventories), amortization of intangible assets and purchase accounting effect on inventory.

[0001032975-17-000037:mdna:97]
Gross margin increased by 140 basis points for the three months ended June 30, 2017, compared to the same period of the prior fiscal year. The increase in gross margin was primarily driven by product cost reductions as well as greater supply chain efficiencies, partially offset by an increase of promotions and an unfavorable fluctuation in currency exchange rates.

[0001032975-17-000037:mdna:98]
[same as prior period, unchanged from 0001032975-17-000005:mdna:122]

[0001032975-17-000037:mdna:99]
Operating expenses for the three months ended June 30, 2017 and 2016 were as follows (Dollars in thousands):

[0001032975-17-000037:mdna:100]
|  |  | Three Months EndedJune 30, |
|  |  | 2017 |  | 2016 |
| Marketing and selling |  | $ | 102,378 |  |  | $ | 83,872 |  |
| % of net sales |  | 19.3 | % |  | 17.5 | % |
| Research and development |  | 35,099 |  |  | 31,951 |  |
| % of net sales |  | 6.6 | % |  | 6.7 | % |
| General and administrative |  | 25,354 |  |  | 25,655 |  |
| % of net sales |  | 4.8 | % |  | 5.3 | % |
| Amortization of intangible assets and acquisition-related costs |  | 1,390 |  |  | 1,293 |  |
| % of net sales |  | 0.3 | % |  | 0.3 | % |
| Change in fair value of contingent consideration for business acquisition |  | (1,978 | ) |  | — |  |
| % of net sales |  | (0.4 | )% |  | — | % |
| Total operating expenses |  | $ | 162,243 |  |  | $ | 142,771 |  |
| % of net sales |  | 30.6 | % |  | 29.8 | % |

[0001032975-17-000037:mdna:101]
The increase in total operating expenses for the three months ended June 30, 2017, compared to the same period of the prior fiscal year, was mainly due to increases in marketing and selling expenses and research and development expenses from higher personnel-related costs due to increased headcount and higher external expenses to support the advertising and marketing efforts for our new products, partially offset by a credit from the change in fair value of contingent consideration for business acquisition.

[0001032975-17-000037:mdna:102]
[same as prior period, unchanged from 0001032975-17-000005:mdna:126]

[0001032975-17-000037:mdna:103]
Marketing and selling expenses consist of personnel and related overhead cost, corporate and product marketing, promotions, advertising, trade shows, customer and technical support, and facilities costs.

[0001032975-17-000037:mdna:104]
During the three months ended June 30, 2017, marketing and selling expenses increased $18.5 million, compared to the same period of the prior fiscal year. The increase was primarily driven by $6.1 million higher personnel-related costs due to increased headcount in addition to $8.9 million higher external expenses to support the advertising and marketing efforts for our new products, including new products introduced under the Jaybird brand.

[0001032975-17-000037:mdna:105]
[same as prior period, unchanged from 0001032975-17-000005:mdna:129]

[0001032975-17-000037:mdna:106]
Research and development expenses consist of personnel and related overhead costs for contractors and outside consultants, supplies and materials, equipment depreciation and facilities costs, all associated with the design and development of new products and enhancements of existing products.

[0001032975-17-000037:mdna:107]
During the three months ended June 30, 2017, research and development expenses increased $3.1 million, compared to the same period in the prior fiscal year. The increase was primarily driven by higher personnel-related costs due to increased headcount to support the development and launch of our new products and capabilities.

[0001032975-17-000037:mdna:108]
[same as prior period, unchanged from 0001032975-17-000005:mdna:132]

[0001032975-17-000037:mdna:109]
General and administrative expenses consist primarily of personnel and related overhead and facilities costs for the finance, information systems, executives, human resources, and legal functions.

[0001032975-17-000037:mdna:110]
During the three months ended June 30, 2017, general and administrative expenses remained relatively flat, compared to the same period in the prior fiscal year. Lower information technology cost was partially offset by higher personnel-related costs due to a slight increase in headcount.

[0001032975-17-000037:mdna:111]
[same as prior period, unchanged from 0001032975-17-000005:mdna:136]

[0001032975-17-000037:mdna:112]
Amortization of intangibles and acquisition-related costs during the three months ended June 30, 2017 and 2016 were as follows (in thousands):

[0001032975-17-000037:mdna:113]
|  |  | Three Months EndedJune 30, |
|  |  | 2017 |  | 2016 |
| Amortization of intangible assets |  | $ | 1,089 |  |  | $ | 798 |  |
| Acquisition-related costs |  | 301 |  |  | 495 |  |
| Total |  | $ | 1,390 |  |  | $ | 1,293 |  |

[0001032975-17-000037:mdna:114]
[same as prior period, unchanged from 0001032975-17-000005:mdna:139]

[0001032975-17-000037:mdna:115]
[same as prior period, unchanged from 0001032975-17-000005:mdna:140]

[0001032975-17-000037:mdna:116]
The change in fair value of contingent consideration is primarily due to lower-than-expected net sales of Jaybird products, partially offset by the change in the time value of money. (see Note 6 – Fair Value Measurement). Although these estimates are based on management’s best knowledge of current events, the estimates could change significantly from period to period. Any changes to the significant unobservable inputs used, including change in the forecast of net sales of the earn-out periods, may result in change in the fair value of contingent consideration, and could have a material impact on future results of operations. Actual payment of contingent consideration in the future could be different from the current estimated fair value of the contingent consideration.

[0001032975-17-000037:mdna:117]
Other Expense, Net

[0001032975-17-000037:mdna:118]
Other expense, net for the three months ended June 30, 2017 and 2016 was as follows (in thousands):

[0001032975-17-000037:mdna:119]
|  |  | Three Months EndedJune 30, |
|  |  | 2017 |  | 2016 |
| Investment income related to a deferred compensation plan |  | $ | 408 |  |  | $ | 192 |  |
| Currency exchange loss, net |  | (964 | ) |  | (999 | ) |
| Other |  | (473 | ) |  | (201 | ) |
| Total |  | $ | (1,029 | ) |  | $ | (1,008 | ) |

[0001032975-17-000037:mdna:120]
Investment income related to a deferred compensation plan for the three months ended June 30, 2017 and 2016 represents earnings and gains on trading investments related to a deferred compensation plan offered by one of our subsidiaries.

[0001032975-17-000037:mdna:121]
Currency exchange losses relate to balances denominated in currencies other than the functional currency in our subsidiaries, as well as to the sale of currencies, and to gains or losses recognized on foreign currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses.

[0001032975-17-000037:mdna:122]
Provision for (Benefit from) Income Taxes

[0001032975-17-000037:mdna:123]
The provision for (benefit from) income taxes and effective tax rates for the three months ended June 30, 2017 and 2016 were as follows (Dollars in thousands):

[0001032975-17-000037:mdna:124]
|  |  | Three Months EndedJune 30, |
|  |  | 2017 |  | 2016 |
| Provision for (benefit from) income taxes |  | $ | (5,436 | ) |  | $ | 3,057 |  |
| Effective income tax rate |  | (17.2 | )% |  | 12.2 | % |

[0001032975-17-000037:mdna:125]
The change in the effective income tax rate for the three months ended June 30, 2017, compared to the three months ended June 30, 2016, is primarily due to the recognition of $9.9 million of excess tax benefits, net of valuation allowance of $1.3 million for federal tax credit carryforwards after adoption of ASU 2016-09. In the three months ended June 30, 2017 and June 30, 2016, there was a discrete tax benefit of $0.7 million for both periods from the reversal of uncertain tax positions from the expiration of statutes of limitations.

[0001032975-17-000037:mdna:126]
As of June 30 and March 31, 2017, the total amount of unrecognized tax benefits due to uncertain tax positions was $65.0 million and $63.7 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-17-000037:mdna:127]
[same as prior period, unchanged from 0001032975-17-000005:mdna:157]

[0001032975-17-000037:mdna:128]
[same as prior period, unchanged from 0001032975-17-000005:mdna:158]

[0001032975-17-000037:mdna:129]
As of June 30, 2017, we had cash and cash equivalents of $527.7 million, compared to $547.5 million as of March 31, 2017. Our cash and cash equivalents consist of bank demand deposits and short-term time deposits, of which 42% is held in Switzerland, 37% is held in Germany, and 10% is held in Hong Kong and China. We do not expect to incur any material adverse tax impact except for what has been recognized, or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-17-000037:mdna:130]
As of June 30, 2017, our working capital was $553.3 million, compared to $520.8 million as of March 31, 2017. The increase was primarily due to higher accounts receivable, net, higher inventories and lower accrued and other current liabilities, partially offset by higher accounts payable.

[0001032975-17-000037:mdna:131]
We had several uncommitted, unsecured bank lines of credit aggregating $38.9 million as of June 30, 2017. There are no financial covenants under these lines of credit with which we must comply. As of June 30, 2017, we had outstanding bank guarantees of $23.3 million under these lines of credit.

[0001032975-17-000037:mdna:132]
The following table summarizes our Condensed Consolidated Statements of Cash Flows (in thousands) on a total company basis:

[0001032975-17-000037:mdna:133]
|  |  | Three Months Ended June 30, |
|  |  | 2017 |  | 2016 |
| Net cash provided by (used in) operating activities |  | $ | (883 | ) |  | $ | 17,017 |  |
| Net cash used in investing activities |  | (10,357 | ) |  | (61,725 | ) |
| Net cash used in financing activities |  | (9,738 | ) |  | (33,008 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | 1,102 |  |  | (1,368 | ) |
| Net decrease in cash and cash equivalents |  | $ | (19,876 | ) |  | $ | (79,084 | ) |

[0001032975-17-000037:mdna:134]
The following table presents selected financial information and statistics as of June 30, 2017 and 2016 (Dollars in thousands):

[0001032975-17-000037:mdna:135]
|  |  | Three Months EndedJune 30, |
|  |  | 2017 |  | 2016 |
| Accounts receivable, net |  | $ | 221,340 |  |  | $ | 192,242 |  |
| Accounts payable |  | $ | 312,722 |  |  | $ | 292,664 |  |
| Inventories |  | $ | 279,405 |  |  | $ | 247,792 |  |
| Days sales in accounts receivable (“DSO”) (Days) (1) |  | 38 |  |  | 36 |  |
| Days accounts payable outstanding (“DPO”) (Days) (2) |  | 84 |  |  | 85 |  |
| Inventory turnover (“ITO”) (x)(3) |  | 4.8 |  |  | 5.0 |  |

[0001032975-17-000037:mdna:136]
(1) DSO is determined using ending accounts receivable, net as of the most recent quarter-end and net sales for the most recent quarter.

[0001032975-17-000037:mdna:137]
(2) DPO is determined using ending accounts payable as of the most recent quarter-end and cost of goods sold for the most recent quarter.

[0001032975-17-000037:mdna:138]
(3) ITO is determined using ending inventories and annualized cost of goods sold (based on the most recent quarterly cost of goods sold).

[0001032975-17-000037:mdna:139]
DSO for the three months ended June 30, 2017 increased two days, compared to June 30, 2016, primarily due to timing of net sales and customer payments.

[0001032975-17-000037:mdna:140]
DPO for the three months ended June 30, 2017 was consistent compared to the same period of the prior fiscal year.

[0001032975-17-000037:mdna:141]
ITO for the three months ended June 30, 2017 was slightly lower, compared to the same period of the prior fiscal year. The increase in inventories compared with June 30, 2016 was primarily driven by the purchase of inventories for planned new product launches in the next three to six months.

[0001032975-17-000037:mdna:142]
If we are not successful in launching and phasing in our new products during the current fiscal year, or we are not able to sell the new products at the prices planned, it could have a material impact on our net sales, gross profit margin, operating results including operating cash flow, and inventory turnover in the future.

[0001032975-17-000037:mdna:143]
During the three months ended June 30, 2017, we used $0.9 million cash in operating activities. Our main sources of operating cash flows were from net income after adding back non-cash expenses of depreciation, amortization, and share-based compensation expense, and from the increases in accounts payable, offset by the increases in accounts receivable, net and inventories and the decrease in accrued and other liabilities. The increases in accounts receivable, net and accounts payable were primarily driven by higher business volumes and timing of payments. The increase in inventories was primarily driven by the purchase of inventories for planned new product launches. The decrease in accrued and other liabilities was primarily due to payments of annual cash bonuses for fiscal year 2017.

[0001032975-17-000037:mdna:144]
Net cash used in investing activities was $10.4 million, primarily due to $10.0 million of purchases of property, plant, and equipment, and $0.4 million of investments in privately held companies.

[0001032975-17-000037:mdna:145]
Net cash used in financing activities was $9.7 million, primarily for the $21.7 million tax withholdings related to net share settlements of restricted stock units, partially offset by $12.6 million in proceeds received from the exercises of stock options.

[0001032975-17-000037:mdna:146]
Our expenditures for property, plant and equipment during the three months ended June 30, 2017 increased, compared to the same period of the prior fiscal year, mainly due to the higher amount of tooling purchases.

[0001032975-17-000037:mdna:147]
The purchases and sales of trading investments during the three months ended June 30, 2017 and 2016 represented mutual fund and money market fund activities directed by participants in a deferred compensation plan offered by one of our subsidiaries. The mutual funds and money market funds are held in a Rabbi trust.

[0001032975-17-000037:mdna:148]
During the three months ended June 30, 2017, there was a $1.1 million gain of currency translation exchange rate effect on cash and cash equivalents, compared to a loss of $1.4 million during the same period of the prior fiscal year. The gain from currency translation exchange effect during the three months ended June 30, 2017 was primarily due to the strengthening of the Euro against the U.S. Dollar by 7% during the period while the loss during the three months ended June 30, 2016 was primarily due to weakening of the Euro against the U.S. Dollar by 2% during the period, which had an adverse impact on our cash and cash equivalents balances in subsidiaries with Euro as their functional currency.

[0001032975-17-000037:mdna:149]
[same as prior period, unchanged from 0001032975-17-000005:mdna:185]

[0001032975-17-000037:mdna:150]
[same as prior period, unchanged from 0001032975-17-000005:mdna:186]

[0001032975-17-000037:mdna:151]
In May 2017, the Board of Directors recommended that the Company pay approximately CHF 100.0 million (approximately $100.0 million based on the exchange rate on March 31, 2017) in cash dividends for fiscal year 2017. During fiscal year 2017, we paid a cash dividend of CHF 90.2 million (U.S. Dollar amount of $93.1 million) out of retained earnings.

[0001032975-17-000037:mdna:152]
In March 2017, our Board of Directors approved another share buyback program, which authorizes us to invest up to $250.0 million to purchase our own shares, following the expiration date of the 2014 buyback program. The new program was approved by the Swiss Takeover Board in May 2017. Although we enter into trading plans for systematic repurchases (e.g., 10b5-1 trading plans) from time to time, our share buyback program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. The March 2014 program expired in April 2017 and there have been no repurchases under the March 2017 program.

[0001032975-17-000037:mdna:153]
As noted in "Note 6 - Fair Value Measurements" to our condensed consolidated financial statements, we acquired all of the equity interest of Jaybird with an additional earn-out of up to $45.0 million in cash based on the achievement of certain net revenue growth targets over two years starting July 2016. If the net revenue growth targets are met, the Company will pay a maximum of $25.0 million and $20.0 million in fiscal years 2018 and 2019, respectively. The fair value of the contingent consideration was $7.9 million as of June 30, 2017. As of June 30, 2017, the first twelve month earn-out period is complete and the expected earn-out payment of $0.5 million is included in the accrued and other current liabilities.

[0001032975-17-000037:mdna:154]
We have changed the payment frequency of our employee performance bonus plan from semi-annual payment to annual payment. The full year bonus is expected to be made in the first quarter of the following fiscal year, and the operating cash flow for that period will be negatively affected as a result.

[0001032975-17-000037:mdna:155]
If we do not generate sufficient operating cash flows to support our operations and future planned cash requirements, our operations could be harmed and our access to credit could be restricted or eliminated. However,

[0001032975-17-000037:mdna:156]
we believe that the trend of our historical cash flow generation, our projections of future operations and our available cash balances will provide sufficient liquidity to fund our operations for at least the next 12 months.

[0001032975-17-000037:mdna:157]
[same as prior period, unchanged from 0001032975-17-000005:mdna:194]

[0001032975-17-000037:mdna:158]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. The remaining terms on our non-cancelable operating leases expire in various years through 2030.

[0001032975-17-000037:mdna:159]
[same as prior period, unchanged from 0001032975-17-000005:mdna:196]

[0001032975-17-000037:mdna:160]
As of June 30, 2017, we had non-cancelable purchase commitments for inventory purchases made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. Non-cancelable purchase commitments for capital expenditures primarily relate to commitments for tooling for new and existing products, computer hardware, leasehold and improvements. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-17-000037:mdna:161]
[same as prior period, unchanged from 0001032975-17-000005:mdna:198]

[0001032975-17-000037:mdna:162]
For further detail about our contractual obligations and commitments, refer to our Annual Report on Form 10-K for the fiscal year ended March 31, 2017.

[0001032975-17-000037:mdna:163]
[same as prior period, unchanged from 0001032975-17-000005:mdna:200]

[0001032975-17-000037:mdna:164]
We do not have any off-balance sheet arrangements that have, or are reasonably likely to have, a current or future effect on our financial condition, changes in financial condition, revenues or expenses, results of operations, liquidity, capital expenditures or capital resources that are material to investors.

[0001032975-17-000037:mdna:165]
[same as prior period, unchanged from 0001032975-17-000005:mdna:205]

[0001032975-17-000037:mdna:166]
Logitech Europe S.A., one of our wholly-owned subsidiaries, guaranteed payments of two third-party contract manufacturers' purchase obligations. As of June 30, 2017, the maximum amount of this guarantee was $3.8 million, of which $0.9 million of guaranteed purchase obligations were outstanding.

[0001032975-17-000037:mdna:167]
[same as prior period, unchanged from 0001032975-17-000005:mdna:207]

[0001032975-17-000037:mdna:168]
We indemnify certain of our suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2017, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-17-000037:mdna:169]
[same as prior period, unchanged from 0001032975-17-000005:mdna:209]

[0001032975-17-000037:mdna:170]
The stock purchase agreement that we entered into in connection with the investment by three venture capital firms in Lifesize contains representations, warranties and covenants of Logitech and Lifesize to the Investors. Subject to certain limitations, we have agreed to indemnify the Investors and certain persons related to the Investors for certain losses resulting from breaches of or inaccuracies in such representations, warranties and covenants as well as certain other obligations, including third party expenses, restructuring costs and pre-closing tax obligations of Lifesize.

[0001032975-17-000037:mdna:171]
36

[0001032975-17-000037:mdna:172]
Legal Proceedings

[0001032975-17-000037:mdna:173]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of our business. We are currently subject to several such claims and a small number of legal proceedings. We believe that these matters lack merit and we intend to vigorously defend against them. Based on currently available information, we do not believe that resolution of pending matters will have a material adverse effect on our financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that our defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on our business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against us, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect our business.

[0001032975-17-000037:mdna:174]
[same as prior period, unchanged from 0001032975-17-000005:mdna:114]
