# LOGI notes — 0001032975-17-000037


## logi:ScheduleOfBalanceSheetComponentsAssetsTableTextBlock

[0001032975-17-000037:notes:1]
The following table presents the components of certain balance sheet asset amounts as of June 30 and March 31, 2017 (in thousands):

[0001032975-17-000037:notes:2]
|  |  | June 30,2017 |  | March 31,2017 |
| Accounts receivable, net: |  |  |  |  |  |  |
| Accounts receivable |  | $ | 452,141 |  |  | $ | 395,754 |  |
| Allowance for doubtful accounts |  | (644 | ) |  | (607 | ) |
| Allowance for sales returns |  | (20,094 | ) |  | (18,800 | ) |
| Allowance for cooperative marketing arrangements |  | (32,761 | ) |  | (28,022 | ) |
| Allowance for customer incentive programs |  | (67,994 | ) |  | (60,857 | ) |
| Allowance for pricing programs |  | (109,308 | ) |  | (102,289 | ) |
|  |  | $ | 221,340 |  |  | $ | 185,179 |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 42,532 |  |  | $ | 30,582 |  |
| Finished goods |  | 236,873 |  |  | 222,819 |  |
|  |  | $ | 279,405 |  |  | $ | 253,401 |  |
| Other current assets: |  |  |  |  |  |  |
| Value-added tax receivables |  | $ | 22,423 |  |  | $ | 23,132 |  |
| Prepaid expenses and other assets |  | 20,252 |  |  | 18,600 |  |
|  |  | $ | 42,675 |  |  | $ | 41,732 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |
| Property, plant and equipment at cost |  | $ | 350,862 |  |  | $ | 348,760 |  |
| Less: accumulated depreciation and amortization |  | (265,727 | ) |  | (263,352 | ) |
|  |  | $ | 85,135 |  |  | $ | 85,408 |  |
| Other assets: |  |  |  |  |  |  |
| Deferred tax assets |  | $ | 103,203 |  |  | $ | 57,303 |  |
| Trading investments for deferred compensation plan |  | 16,914 |  |  | 15,043 |  |
| Investments in privately held companies |  | 10,877 |  |  | 10,776 |  |
| Other assets |  | 5,522 |  |  | 4,997 |  |
|  |  | $ | 136,516 |  |  | $ | 88,119 |  |


## logi:ScheduleOfBalanceSheetComponentsLiabilityTableTextBlock

[0001032975-17-000037:notes:3]
The following table presents the components of certain balance sheet liability amounts as of June 30 and March 31, 2017 (in thousands):

[0001032975-17-000037:notes:4]
|  |  | June 30,2017 |  | March 31,2017 |
| Accrued and other current liabilities: |  |  |  |  |  |  |
| Accrued personnel expenses |  | $ | 58,218 |  |  | $ | 88,346 |  |
| Indirect customer incentive programs |  | 40,003 |  |  | 36,409 |  |
| Warranty accrual |  | 13,478 |  |  | 13,424 |  |
| Employee benefit plan obligation |  | 1,541 |  |  | 1,266 |  |
| Income taxes payable |  | 6,767 |  |  | 6,232 |  |
| Contingent consideration for business acquisition - current portion |  | 455 |  |  | 2,889 |  |
| Other current liabilities |  | 84,597 |  |  | 83,707 |  |
|  |  | $ | 205,059 |  |  | $ | 232,273 |  |
| Other non-current liabilities: |  |  |  |  |  |  |
| Warranty accrual |  | $ | 8,578 |  |  | $ | 8,487 |  |
| Obligation for deferred compensation plan |  | 16,914 |  |  | 15,043 |  |
| Employee benefit plan obligation |  | 43,405 |  |  | 41,998 |  |
| Deferred tax liability |  | 1,789 |  |  | 1,789 |  |
| Contingent consideration for business acquisition - non-current portion |  | 7,475 |  |  | 7,019 |  |
| Other non-current liabilities |  | 9,052 |  |  | 9,355 |  |
|  |  | $ | 87,213 |  |  | $ | 83,691 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-17-000037:notes:5]
[same as prior period, unchanged from 0001032975-17-000005:notes:6]

[0001032975-17-000037:notes:6]
[same as prior period, unchanged from 0001032975-17-000005:notes:7]

[0001032975-17-000037:notes:7]
[same as prior period, unchanged from 0001032975-17-000005:notes:8]

[0001032975-17-000037:notes:8]
[same as prior period, unchanged from 0001032975-17-000005:notes:9]

[0001032975-17-000037:notes:9]
Logitech was founded in Switzerland in 1981 and Logitech International S.A. has been the parent holding company of Logitech since 1988. Logitech International S.A. is a Swiss holding company with its registered office in Apples, Switzerland and headquarters in Lausanne, Switzerland, which conducts its business through subsidiaries in the Americas, Europe, Middle East and Africa ("EMEA") and Asia Pacific. Shares of Logitech International S.A. are listed on both the SIX Swiss Exchange under the trading symbol LOGN and the Nasdaq Global Select Market under the trading symbol LOGI.

[0001032975-17-000037:notes:10]
[same as prior period, unchanged from 0001032975-17-000005:notes:11]

[0001032975-17-000037:notes:11]
The condensed consolidated interim financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (“GAAP”) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. They should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2017, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (“SEC”) on May 26, 2017.

[0001032975-17-000037:notes:12]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three months ended June 30, 2017 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2018, or any future periods.

[0001032975-17-000037:notes:13]
[same as prior period, unchanged from 0001032975-17-000005:notes:14]

[0001032975-17-000037:notes:14]
Certain amounts from the comparative period in the accompanying unaudited condensed consolidated financial statements have been reclassified to conform to the condensed consolidated financial statement presentation as of and for the three months ended June 30, 2017.

[0001032975-17-000037:notes:15]
[same as prior period, unchanged from 0001032975-17-000005:notes:16]

[0001032975-17-000037:notes:16]
Other than the recent accounting pronouncements adopted, discussed below, there have been no substantial changes in the Company’s significant accounting policies during the three months ended June 30, 2017 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2017.

[0001032975-17-000037:notes:17]
[same as prior period, unchanged from 0001032975-17-000005:notes:18]

[0001032975-17-000037:notes:18]
The preparation of financial statements in conformity with GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill, intangible assets acquired from business acquisitions, warranty liabilities, accruals for customer programs and related breakage when appropriate, sales return reserves, allowance for doubtful accounts, inventory valuation, contingent consideration from business acquisitions and periodical reassessment of its fair value, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

[0001032975-17-000037:notes:19]
Recent Accounting Pronouncements Adopted

[0001032975-17-000037:notes:20]
In July 2015, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2015-11, "Simplifying the Measurement of Inventory (Topic 330)" ("ASU 2015-11"). Topic 330, Inventory, previously required an entity to measure inventory at the lower of cost or market, with market value represented by replacement cost, net realizable value or net realizable value less a normal profit margin. ASU 2015-11 requires an entity to measure inventory at the lower of cost or net realizable value and is effective for fiscal years beginning after December 15, 2016, with early adoption permitted. The Company has adopted this standard effective April 1, 2017 which did not have a material impact on its condensed consolidated financial statements.

[0001032975-17-000037:notes:21]
In March 2016, the FASB issued ASU 2016-09, "Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting" ("ASU 2016-09"). ASU 2016-09 simplifies several aspects of the accounting for share-based payments, including immediate recognition of all excess tax benefits and deficiencies in the income statement, changing the threshold to qualify for equity classification up to the employees' maximum statutory tax rates, allowing an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures as they occur, and clarifying the classification on the statement of cash flows for the excess tax benefits and employee taxes paid when an employer withholds shares for tax withholding purposes. ASU 2016-09 is effective for fiscal years beginning after December 15, 2016, with early adoption permitted. The Company has adopted this standard effective April 1, 2017. Changes to the statements of cash flows related to the classification of excess tax benefits were implemented on a retroactive basis and accordingly, to conform to the current year presentation, the Company reclassified $3.3 million of excess tax benefits previously reported under financing activities to operating activities for the three months ended June 30, 2016 on its condensed consolidated statements of cash flows. Under the new standard, the Company accounts for forfeitures as they occur. The change in accounting for forfeitures resulted in a cumulative-effect adjustment to decrease retained earnings as of March 31, 2017 by $3.3 million. The Company further recognized a cumulative-effect adjustment to increase retained earnings as of March 31, 2017 by $57.2 million upon adoption of the new guidance to account for gross excess tax benefits of $75.2 million that were previously not recognized because the related tax deduction had not reduced current income taxes, offset by a valuation allowance of $18.0 million to reduce the deferred tax assets to amounts that are more likely than not to be realized.

[0001032975-17-000037:notes:22]
In January 2017, the FASB issued ASU 2017-04, "Simplifying the Test for Goodwill Impairment (Topic

[0001032975-17-000037:notes:23]
350)" ("ASU 2017-04"), which removes Step 2 from the goodwill impairment test. ASU 2017-04 is effective for annual or any interim goodwill impairments in annual periods beginning December 15, 2019, with early adoption permitted. The Company has adopted this standard effective April 1, 2017 which did not have a material impact on its condensed consolidated financial statements.

[0001032975-17-000037:notes:24]
In May 2017, the FASB issued ASU 2017-09, "Compensation-Stock Compensation (Topic 718): Scope of

[0001032975-17-000037:notes:25]
Modification Accounting" ("ASU 2017-09"), which provides guidance about which changes to the terms or conditions

[0001032975-17-000037:notes:26]
of a share-based payment award require an entity to apply modification accounting in Topic 718. ASU 2017-09 is

[0001032975-17-000037:notes:27]
effective for annual periods beginning after December 15, 2017, with early adoption permitted, including adoption in any interim period for which financial statements have not yet been issued. The Company has adopted this standard effective April 1, 2017 which did not have a material impact on its condensed consolidated financial statements.

[0001032975-17-000037:notes:28]
Recent Accounting Pronouncements To Be Adopted

[0001032975-17-000037:notes:29]
In May 2014, the FASB issued ASU No. 2014-09, "Revenue from Contracts with Customers (Topic 606)" ("ASU 2014-09") which supersedes the revenue recognition requirements under ASC 605, Revenue Recognition. ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. Under the new model, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The new standard requires reporting companies to disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The new standard will become effective for the Company on April 1, 2018. The standard allows for either a "full retrospective" adoption, meaning the standard is applied to all of the periods presented subject to practical expedients, or a "modified retrospective" adoption, meaning the standard is applied only in the initial year, or interim period in year of initial application with a cumulative adjustment to opening retained earnings for existing contracts. The Company currently expects to utilize the modified retrospective transition method. The Company continues to evaluate the impact this new standard could have on the current contracts with customers and the accruals of various sales and marketing programs the Company offers and on the related breakage estimates. The Company has not completed its analysis of the impact to its condensed consolidated financial statements and this information will not be available until the Company completes its full assessment. It is possible that during the fiscal year 2018, the Company may identify certain areas which may result in material impact on the Company’s condensed consolidated financial statements, or the Company may revise its adoption method.

[0001032975-17-000037:notes:30]
In January 2016, the FASB issued ASU 2016-01, “Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10)” ("ASU 2016-01"). ASU 2016-01 is effective for annual periods beginning after December 15, 2017, including interim periods within those annual periods, with early adoption permitted. The Company does not believe that the adoption of ASU 2016-01 will have a material impact on its condensed consolidated financial statements and will adopt this standard effective April 1, 2018.

[0001032975-17-000037:notes:31]
In February 2016, the FASB issued ASU 2016-02, "Leases (Topic 842)" ("ASU 2016-02"), which requires the recognition of lease assets and lease liabilities arising from operating leases in the statement of financial position. ASU 2016-02 is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years, with early adoption permitted. The Company is evaluating the full effect that ASU 2016-02 will have on its condensed consolidated financial statements and will adopt this standard effective April 1, 2019.

[0001032975-17-000037:notes:32]
In October 2016, the FASB issued ASU 2016-16, "Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory"  ("ASU 2016-16"), which eliminates the deferral of income tax effects of intra-entity asset transfers until the transferred asset is sold to an unrelated party or recovered through use however, this standard does not apply to intra-entity transfer of inventory.  ASU 2016-16 is effective for annual periods beginning after December 15, 2017, including interim periods within those annual periods, with early adoption permitted but only in the first interim period of an annual period.  The cumulative effect of change on equity upon adoption is to be quantified under the modified retrospective approach and recorded as of the beginning of the period of adoption.  The Company is evaluating the full effect that ASU 2016-16 will have on its condensed consolidated financial statements and will adopt this standard effective April 1, 2018.

[0001032975-17-000037:notes:33]
In December 2016, the FASB issued ASU 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash" ("ASU 2016-18"), which requires that a statement of cash flows explains the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents.  ASU 2016-18 is effective for annual periods beginning after December 15, 2017, including interim periods within those annual periods, with early adoption permitted. The adoption of this standard should be applied using a retrospective transition method to each period presented. The Company does not expect the adoption of ASU 2016-18 will have a material impact on its condensed consolidated financial statements and will adopt this standard effective April 1, 2018.

[0001032975-17-000037:notes:34]
In March 2017, the FASB issued ASU 2017-07, "Compensation-Retirement Benefit (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost" ("ASU 2017-07"), which requires that the Company disaggregate the service cost component from the other components of net benefit cost, and also provides guidance on how to present the service cost component and the other components of net benefit cost in the income statement and allow only the service cost component of net benefit cost to be eligible for capitalization. ASU 2017-07 is effective for annual periods beginning after December 15, 2017, including interim periods within those annual periods, with early adoption permitted. The Company does not expect the adoption of ASU 2017-07 will have a material impact on its condensed consolidated financial statements and will adopt this standard effective April 1, 2018.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-17-000037:notes:35]
Commitments and Contingencies

[0001032975-17-000037:notes:36]
Product Warranties

[0001032975-17-000037:notes:37]
All of the Company’s peripherals products sold are covered by warranty to be free from defects in material and workmanship. For products launched prior to April 1, 2014, the standard warranty period was up to five years. Starting from April 1, 2014, the standard warranty for all new products launched was changed to two years from the date of purchase for European Countries and generally one year from date of purchase for all other countries.

[0001032975-17-000037:notes:38]
Changes in the Company’s warranty liability for the three months ended June 30, 2017 and 2016 were as follows (in thousands):

[0001032975-17-000037:notes:39]
|  |  | Three Months EndedJune 30, |
|  |  | 2017 |  | 2016 |
| Beginning of the period |  | $ | 21,911 |  |  | $ | 20,380 |  |
| Assumed from business acquisition |  | — |  |  | 1,813 |  |
| Provision |  | 5,124 |  |  | 3,177 |  |
| Settlements |  | (4,567 | ) |  | (3,428 | ) |
| Currency translation |  | (412 | ) |  | (190 | ) |
| End of the period |  | $ | 22,056 |  |  | $ | 21,752 |  |

[0001032975-17-000037:notes:40]
Guarantees

[0001032975-17-000037:notes:41]
Logitech Europe S.A., one of our wholly-owned subsidiaries, guaranteed payments of certain third-party contract manufacturers’ purchase obligations. As of June 30, 2017, the maximum amount of this guarantee was $3.8 million, of which $0.9 million of guaranteed purchase obligations were outstanding.

[0001032975-17-000037:notes:42]
Indemnifications

[0001032975-17-000037:notes:43]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2017, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-17-000037:notes:44]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-17-000037:notes:45]
The stock purchase agreement entered on December 28, 2015 in connection with the investment by three venture capital firms in Lifesize contains representations, warranties and covenants of Logitech and Lifesize, Inc. to the Investors. Logitech has agreed, subject to certain limitations, to indemnify the Investors and certain persons related to the Investors for certain losses resulting from breaches of or inaccuracies in such representations, warranties and covenants as well as certain other obligations, including third-party expenses, restructuring costs and pre-closing tax obligations of Lifesize.

[0001032975-17-000037:notes:46]
Legal Proceedings

[0001032975-17-000037:notes:47]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-17-000037:notes:48]
[same as prior period, unchanged from 0001032975-17-000005:notes:72]

[0001032975-17-000037:notes:49]
[same as prior period, unchanged from 0001032975-17-000005:notes:73]

[0001032975-17-000037:notes:50]
As of June 30, 2017, the Company offers the 2006 ESPP (2006 Employee Share Purchase Plan (Non-U.S.)), the 1996 ESPP (1996 Employee Share Purchase Plan (U.S.)), the 2006 Plan (2006 Stock Incentive Plan) and the 2012 Plan (2012 Stock Inducement Equity Plan).

[0001032975-17-000037:notes:51]
The following table summarizes the share-based compensation expense and total income tax benefit recognized for share-based awards for the three months ended June 30, 2017 and 2016 (in thousands):

[0001032975-17-000037:notes:52]
|  |  | Three Months EndedJune 30, |
|  |  | 2017 |  | 2016 |
| Cost of goods sold |  | $ | 711 |  |  | $ | 675 |  |
| Marketing and selling |  | 4,381 |  |  | 3,437 |  |
| Research and development |  | 1,543 |  |  | 914 |  |
| General and administrative |  | 4,070 |  |  | 3,491 |  |
| Total share-based compensation expense |  | 10,705 |  |  | 8,517 |  |
| Income tax benefit |  | (11,282 | ) |  | (1,815 | ) |
| Total share-based compensation expense (credit), net of income tax |  | $ | (577 | ) |  | $ | 6,702 |  |

[0001032975-17-000037:notes:53]
The income tax benefit in the respective period primarily consists of tax benefit related to the share-based compensation expense for the period and direct tax benefit realized, including net excess tax benefits recognized, from stock-based awards vested or exercised during the period.

[0001032975-17-000037:notes:54]
As of June 30, 2017 and 2016, the Company capitalized $0.9 million and $0.5 million of stock-based compensation expense to inventory, respectively.

[0001032975-17-000037:notes:55]
[same as prior period, unchanged from 0001032975-17-000005:notes:78]

[0001032975-17-000037:notes:56]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The cost recorded of $2.3 million and $2.8 million for the three months ended June 30, 2017 and 2016, respectively, was primarily related to service costs.


## us-gaap:DebtDisclosureTextBlock

[0001032975-17-000037:notes:57]
Financing Arrangements

[0001032975-17-000037:notes:58]
The Company had several uncommitted, unsecured bank lines of credit aggregating $38.9 million as of June 30, 2017. There are no financial covenants under these lines of credit with which the Company must comply. As of June 30, 2017, the Company had outstanding bank guarantees of $23.3 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of June 30, 2017 or March 31, 2017.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-17-000037:notes:59]
[same as prior period, unchanged from 0001032975-17-000005:notes:82]

[0001032975-17-000037:notes:60]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis on the condensed consolidated balance sheets as of June 30, 2017 and March 31, 2017.

[0001032975-17-000037:notes:61]
The fair values of the Company’s derivative instruments not designated as hedging instruments were not material as of June 30, 2017 or March 31, 2017. The following table presents the fair values of the Company’s derivative instruments designated as hedging instruments on a gross basis in other current assets or accrued and other current liabilities on its condensed consolidated balance sheets as of June 30, 2017 and March 31, 2017 (in thousands):

[0001032975-17-000037:notes:62]
|  |  | Derivatives |
|  |  | Asset |  | Liability |
|  |  | June 30,2017 |  | March 31,2017 |  | June 30,2017 |  | March 31,2017 |
| Cash flow hedges |  | $ | 104 |  |  | $ | 48 |  |  | $ | 1,664 |  |  | $ | 402 |  |

[0001032975-17-000037:notes:63]
The amount of gain (loss) recognized on derivatives not designated as hedging instruments were not material in all periods presented herein. The following table presents the amounts of gains (losses) on the Company’s derivative instruments designated as hedging instruments and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income for the three months ended June 30, 2017 and 2016 (in thousands):

[0001032975-17-000037:notes:64]
|  |  | Three Months EndedJune 30, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of LossReclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Cash flow hedges |  | $ | (3,209 | ) |  | $ | 965 |  |  | $ | 533 |  |  | $ | 740 |  |

[0001032975-17-000037:notes:65]
[same as prior period, unchanged from 0001032975-17-000005:notes:89]

[0001032975-17-000037:notes:66]
The Company enters into cash flow hedge contracts to protect against exchange rate exposure of forecasted inventory purchases. These hedging contracts mature within four months. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Cash flows from such hedges are classified as operating activities in the condensed consolidated statements of cash flows. The notional amounts of foreign currency exchange forward contracts outstanding related to forecasted inventory purchases were $84.7 million and $59.4 million at June 30, 2017 and March 31, 2017, respectively. The Company estimates that $3.2 million of net losses related to its cash flow hedges included in accumulated other comprehensive loss as of June 30, 2017 will be reclassified into earnings within the next 12 months.

[0001032975-17-000037:notes:67]
[same as prior period, unchanged from 0001032975-17-000005:notes:91]

[0001032975-17-000037:notes:68]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are recognized in other expense, net in the condensed consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of June 30, 2017 and March 31, 2017 were $65.4 million and $56.7 million, respectively. Open forward and swap contracts outstanding as of June 30, 2017 and March 31, 2017 consisted of contracts in Mexican Pesos, Japanese Yen, British Pounds, Taiwanese Dollars, Canadian Dollars and Australian Dollars to be settled at future dates at pre-determined exchange rates.

[0001032975-17-000037:notes:69]
The fair value of all foreign currency exchange forward and swap contracts is determined based on observable market transactions of spot currency rates and forward rates. Cash flows from these contracts are classified as operating activities in the condensed consolidated statements of cash flows.


## us-gaap:EarningsPerShareTextBlock

[0001032975-17-000037:notes:70]
[same as prior period, unchanged from 0001032975-17-000005:notes:101]

[0001032975-17-000037:notes:71]
[same as prior period, unchanged from 0001032975-17-000005:notes:102]

[0001032975-17-000037:notes:72]
|  |  | Three Months EndedJune 30, |
|  |  | 2017 |  | 2016 |
| Net Income |  | $ | 37,007 |  |  | $ | 21,941 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 163,407 |  |  | 162,130 |  |
| Effect of potentially dilutive equivalent shares |  | 4,932 |  |  | 2,173 |  |
| Weighted average shares outstanding - diluted |  | 168,339 |  |  | 164,303 |  |
| Net income per share: |  |  |  |  |  |  |
| Basic |  | $ | 0.23 |  |  | $ | 0.14 |  |
| Diluted |  | $ | 0.22 |  |  | $ | 0.13 |  |

[0001032975-17-000037:notes:73]
Share equivalents attributable to outstanding stock options and restricted stock units of 1.4 million and 5.7 million for the three months ended June 30, 2017 and 2016, respectively, were anti-dilutive and excluded from the calculation of diluted net income per share.


## us-gaap:FairValueLiabilitiesMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001032975-17-000037:notes:74]
The following table summarizes the change in fair value of the Company’s contingent consideration balance during the three months ended June 30, 2017 and 2016 (in thousands):

[0001032975-17-000037:notes:75]
|  |  | Three Months EndedJune 30, |
|  |  | 2017 |  | 2016 |
| Beginning of the period |  | $ | 9,908 |  |  | $ | — |  |
| Fair value of contingent consideration upon acquisition |  | — |  |  | 18,000 |  |
| Change in fair value of contingent consideration |  | (1,978 | ) |  | — |  |
| Expected payment for first earn-out period(1) |  | (455 | ) |  | — |  |
| End of the period |  | $ | 7,475 |  |  | $ | 18,000 |  |

[0001032975-17-000037:notes:76]
(1) As of June 30, 2017, the first twelve month earn-out period is complete and the earn-out payment of $0.5 million is based on the actual net sales of Jaybird products and no longer subject to fair value measurement.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-17-000037:notes:77]
[same as prior period, unchanged from 0001032975-17-000005:notes:107]

[0001032975-17-000037:notes:78]
[same as prior period, unchanged from 0001032975-17-000005:notes:108]

[0001032975-17-000037:notes:79]
[same as prior period, unchanged from 0001032975-17-000005:notes:109]

[0001032975-17-000037:notes:80]
[same as prior period, unchanged from 0001032975-17-000005:notes:110]

[0001032975-17-000037:notes:81]
[same as prior period, unchanged from 0001032975-17-000005:notes:111]

[0001032975-17-000037:notes:82]
[same as prior period, unchanged from 0001032975-17-000005:notes:112]

[0001032975-17-000037:notes:83]
|  |  | June 30, 2017 |  | March 31, 2017 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 426,910 |  |  | $ | — |  |  | $ | — |  |  | $ | 448,742 |  |  | $ | — |  |  | $ | — |  |
| Trading investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 3,107 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,813 |  |  | $ | — |  |  | $ | — |  |
| Mutual funds |  | 13,807 |  |  | — |  |  | — |  |  | 12,230 |  |  | — |  |  | — |  |
| Total of trading investments for deferred compensation plan |  | $ | 16,914 |  |  | $ | — |  |  | $ | — |  |  | $ | 15,043 |  |  | $ | — |  |  | $ | — |  |
| Currency exchange derivative assetsincluded in other current assets |  | $ | — |  |  | $ | 104 |  |  | $ | — |  |  | $ | — |  |  | $ | 48 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related contingentconsideration included in accrued andother current liabilities and other non-current liabilities |  | $ | — |  |  | $ | — |  |  | $ | 7,475 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,908 |  |
| Currency exchange derivative liabilitiesincluded in accrued and other current liabilities |  | $ | — |  |  | $ | 1,711 |  |  | $ | — |  |  | $ | — |  |  | $ | 443 |  |  | $ | — |  |

[0001032975-17-000037:notes:84]
[same as prior period, unchanged from 0001032975-17-000005:notes:114]

[0001032975-17-000037:notes:85]
The marketable securities for the Company's deferred compensation plan are recorded at a fair value of $16.9 million and $15.0 million, respectively, as of June 30, 2017 and March 31, 2017, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized trading gains / (losses) related to trading securities for the three months ended June 30, 2017 and 2016 were not material and are included in other expense, net in the Company's condensed consolidated statements of operations.

[0001032975-17-000037:notes:86]
[same as prior period, unchanged from 0001032975-17-000005:notes:116]

[0001032975-17-000037:notes:87]
On April 20, 2016 (the "Acquisition Date"), the Company acquired all of the equity interest of JayBird, LLC (“Jaybird”). Pursuant to the purchase agreement, there is an additional earn-out of up to $45.0 million based on the achievement of certain net revenue growth targets over approximately a two-year period (the "Jaybird Acquisition"). The acquisition-related contingent consideration liability arising from the Jaybird Acquisition represents the future potential earn-out payments of up to $45.0 million based on the achievement of certain net revenue targets over approximately a two year period. If the net revenue targets are met, the Company will pay a maximum of $25.0 million and $20.0 million in fiscal years 2018 and 2019, respectively. The fair value of the earn-out as of the Acquisition Date was $18.0 million, which was determined by using a Monte Carlo Simulation that includes significant unobservable inputs such as a risk-adjusted discount rate of 16% and projected net sales of Jaybird over the earn-out period. The fair value is remeasured at each reporting period at the estimated fair value based on the inputs on the date of remeasurement, with the change in fair value recognized as "change in fair value of contingent consideration for business acquisition" in the operating expense section in the condensed consolidated statements of operations. Projected net sales are based on the Company's internal projections, including analysis of the target markets. The fair value of the contingent consideration was $7.9 million and $9.9 million as of June 30, 2017 and March 31, 2017, respectively. The decrease in fair value of contingent consideration for the three months ended June 30, 2017 results primarily from Jaybird's lower-than-expected net sales, partially offset by the change in the time value of money. As of June 30, 2017, the first twelve month earn-out period is complete and the expected earn-out payment of $0.5 million is included in the accrued and other current liabilities.

[0001032975-17-000037:notes:88]
[same as prior period, unchanged from 0001032975-17-000005:notes:118]

[0001032975-17-000037:notes:89]
[same as prior period, unchanged from 0001032975-17-000005:notes:119]

[0001032975-17-000037:notes:90]
The Company’s non-marketable cost method investments, and non-financial assets, such as goodwill, intangible assets and property, plant and equipment, are recorded at fair value only upon initial recognition or if an impairment is recognized. There were no material impairments of long-lived assets during the three months ended June 30, 2017 or 2016.

[0001032975-17-000037:notes:91]
[same as prior period, unchanged from 0001032975-17-000005:notes:121]

[0001032975-17-000037:notes:92]
The primary investment included in non-marketable investments is the Company’s investment in Series A Preferred Stock of Lifesize Inc. ("Lifesize") recorded at the fair value of $5.6 million on the date of the Lifesize divestiture.

[0001032975-17-000037:notes:93]
The aggregate recorded amount of cost method investments included in other assets as of June 30, 2017 and March 31, 2017 was $7.1 million and $7.4 million, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-17-000037:notes:94]
Goodwill and Other Intangible Assets

[0001032975-17-000037:notes:95]
The Company conducts its impairment analysis of the goodwill annually at December 31 and as necessary if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting units may be less than its carrying amount. There have been no events or circumstances during the three months ended June 30, 2017 that have required the Company to perform an interim assessment of goodwill.

[0001032975-17-000037:notes:96]
The following table summarizes the activities in the Company’s goodwill balance during the three months ended June 30, 2017 (in thousands):

[0001032975-17-000037:notes:97]
| As of March 31, 2017 |  | $ | 249,741 |  |
| Currency impact |  | 39 |  |
| As of June 30, 2017 |  | $ | 249,780 |  |

[0001032975-17-000037:notes:98]
The Company's acquired intangible assets subject to amortization were as follows (in thousands):

[0001032975-17-000037:notes:99]
|  |  | June 30, 2017 |  | March 31, 2017 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademark and tradenames |  | $ | 16,500 |  |  | $ | (7,399 | ) |  | $ | 9,101 |  |  | $ | 16,500 |  |  | $ | (6,933 | ) |  | $ | 9,567 |  |
| Technology |  | 63,285 |  |  | (44,337 | ) |  | 18,948 |  |  | 63,285 |  |  | (42,831 | ) |  | 20,454 |  |
| Customer contracts/relationships |  | 25,180 |  |  | (8,258 | ) |  | 16,922 |  |  | 25,180 |  |  | (7,637 | ) |  | 17,543 |  |
| Total |  | $ | 104,965 |  |  | $ | (59,994 | ) |  | $ | 44,971 |  |  | $ | 104,965 |  |  | $ | (57,401 | ) |  | $ | 47,564 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-17-000037:notes:100]
[same as prior period, unchanged from 0001032975-17-000005:notes:128]

[0001032975-17-000037:notes:101]
[same as prior period, unchanged from 0001032975-17-000005:notes:129]

[0001032975-17-000037:notes:102]
The income tax benefit for the three months ended June 30, 2017 was $5.4 million based on an effective income tax rate of (17.2)% of pre-tax income, compared to an income tax provision of $3.1 million based on an effective income tax rate of 12.2% of pre-tax income for the three months ended June 30, 2016.

[0001032975-17-000037:notes:103]
The change in the effective income tax rate for the three months ended June 30, 2017, compared to the three months ended June 30, 2016, is primarily due to the recognition of $9.9 million of excess tax benefits, offset by valuation allowance of $1.3 million for federal tax credit carryforwards after adoption of ASU 2016-09. In the three months ended June 30, 2017 and June 30, 2016, there was a discrete tax benefit of $0.7 million for both periods from the reversal of uncertain tax positions from the expiration of statutes of limitations.

[0001032975-17-000037:notes:104]
As of June 30 and March 31, 2017, the total amount of unrecognized tax benefits due to uncertain tax positions was $65.0 million and $63.7 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-17-000037:notes:105]
The Company had $32.1 million in non-current income taxes payable and $1.5 million in current income taxes payable, including interest and penalties, related to its income tax liability for uncertain tax positions as of June 30, 2017 compared to $51.8 million in non-current income taxes payable and $1.5 million in current income taxes payable as of March 31, 2017. The Company anticipates a settlement of approximately $1.4 million with the tax authorities in a foreign jurisdiction in the next twelve months.

[0001032975-17-000037:notes:106]
The Company recognizes interest and penalties related to unrecognized tax positions in income tax expense. As of June 30 and March 31, 2017, the Company had $3.2 million and $3.0 million, respectively, of accrued interest and penalties related to uncertain tax positions.

[0001032975-17-000037:notes:107]
Although the Company has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During fiscal year 2018, the Company will continue to review its tax positions and provide for or reverse unrecognized tax benefits as issues arise. During the next twelve months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. dollar as compared to other currencies. Excluding these factors, uncertain tax positions may decrease by as much as $8.5 million from the lapse of the statutes of limitations in various jurisdictions during the next twelve months.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001032975-17-000037:notes:108]
[same as prior period, unchanged from 0001032975-17-000005:notes:136]

[0001032975-17-000037:notes:109]
|  |  | June 30,2017 |  | March 31,2017 |
| Americas |  | $ | 36,679 |  |  | $ | 37,242 |  |
| EMEA |  | 4,130 |  |  | 4,006 |  |
| Asia Pacific |  | 44,326 |  |  | 44,160 |  |
| Total long-lived assets |  | $ | 85,135 |  |  | $ | 85,408 |  |


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001032975-17-000037:notes:110]
Net sales by geographic region (based on the customers’ locations) for the three months ended June 30, 2017 and 2016 were as follows (in thousands):

[0001032975-17-000037:notes:111]
|  |  | Three Months EndedJune 30, |
|  |  | 2017 |  | 2016 |
| Americas |  | $ | 245,400 |  |  | $ | 222,625 |  |
| EMEA |  | 150,591 |  |  | 142,922 |  |
| Asia Pacific |  | 133,955 |  |  | 114,317 |  |
| Total net sales |  | $ | 529,946 |  |  | $ | 479,864 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001032975-17-000037:notes:112]
The components of accumulated other comprehensive loss were as follows (in thousands):

[0001032975-17-000037:notes:113]
|  |  | Accumulated Other Comprehensive Income (Loss) |
|  |  | CumulativeTranslationAdjustment (1) |  | DefinedBenefitPlan (1) |  | DeferredHedgingLosses |  | Total |
| March 31, 2017 |  | $ | (89,708 | ) |  | $ | (10,480 | ) |  | $ | (518 | ) |  | $ | (100,706 | ) |
| Other comprehensive income (loss) |  | 1,456 |  |  | (102 | ) |  | (2,676 | ) |  | (1,322 | ) |
| June 30, 2017 |  | $ | (88,252 | ) |  | $ | (10,582 | ) |  | $ | (3,194 | ) |  | $ | (102,028 | ) |

[0001032975-17-000037:notes:114]
(1)        Tax effect was not significant as of June 30 or March 31, 2017.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001032975-17-000037:notes:115]
Net sales by product categories, excluding intercompany transactions, for the three months ended June 30, 2017 and 2016 were as follows (in thousands):

[0001032975-17-000037:notes:116]
|  |  | Three Months EndedJune 30, |
|  |  | 2017 |  | 2016 |
| Mobile Speakers |  | $ | 62,918 |  |  | $ | 57,296 |  |
| Audio-PC & Wearables |  | 50,202 |  |  | 56,579 |  |
| Gaming |  | 77,708 |  |  | 56,500 |  |
| Video Collaboration |  | 35,617 |  |  | 23,910 |  |
| Smart Home |  | 16,466 |  |  | 11,167 |  |
| Pointing Devices |  | 122,074 |  |  | 116,783 |  |
| Keyboards & Combos |  | 116,113 |  |  | 118,019 |  |
| Tablet & Other Accessories |  | 23,218 |  |  | 13,885 |  |
| PC Webcams |  | 25,625 |  |  | 25,262 |  |
| Other (1) |  | 5 |  |  | 463 |  |
| Total net sales |  | $ | 529,946 |  |  | $ | 479,864 |  |

[0001032975-17-000037:notes:117]
(1) Other category includes products that the Company currently intends to transition out of, or has already transitioned out of, because they are no longer strategic to the Company's business.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-17-000037:notes:118]
[same as prior period, unchanged from 0001032975-17-000005:notes:150]

[0001032975-17-000037:notes:119]
The Company has determined that it operates in a single operating segment that encompasses the design, manufacturing and marketing of peripherals for PCs, tablets and other digital platforms. Operating performance measures are provided directly to the Company's Chief Executive Officer (“CEO”), who is considered to be the Company’s Chief Operating Decision Maker (“CODM”). The CEO periodically reviews information such as net sales and operating income (loss) to make business decisions. These operating performance measures do not include restructuring charges (credits), net, share-based compensation expense, amortization of intangible assets, charges from the purchase accounting effect on inventory, acquisition-related costs, investigation and related expenses, or change in fair value of contingent consideration from business acquisition.

[0001032975-17-000037:notes:120]
[same as prior period, unchanged from 0001032975-17-000005:notes:152]

[0001032975-17-000037:notes:121]
The United States and Germany each represented more than 10% of the Company’s total consolidated net sales for the three months ended June 30, 2017. The United States represented more than 10% of the Company’s total consolidated net sales for the three months ended June 30, 2016.

[0001032975-17-000037:notes:122]
Switzerland, the Company’s home domicile, represented 1% and 2% of the Company’s total consolidated net sales for the three months ended June 30, 2017 and June 30, 2016, respectively.

[0001032975-17-000037:notes:123]
Two customer groups of the Company each represented more than 10% of the total consolidated sales for all the periods presented herein.

[0001032975-17-000037:notes:124]
Long-lived assets in the United States and China were $36.6 million and $37.3 million, respectively, as of June 30, 2017, and $37.1 million and $37.2 million, respectively, as of March 31, 2017. No other countries represented more than 10% of the Company’s total consolidated long-lived assets as of June 30 or March 31, 2017. Long-lived assets in Switzerland, the Company’s home domicile, were $2.0 million and $2.1 million as of June 30 and March 31, 2017, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-17-000037:notes:125]
[same as prior period, unchanged from 0001032975-17-000005:notes:157]

[0001032975-17-000037:notes:126]
[same as prior period, unchanged from 0001032975-17-000005:notes:158]

[0001032975-17-000037:notes:127]
In March 2014, the Company’s Board of Directors approved the 2014 share buyback program, which authorizes the Company to use up to $250.0 million to purchase its own shares. This share buyback program expired in April 2017.

[0001032975-17-000037:notes:128]
In March 2017, the Company's Board of Directors approved the 2017 share buyback program, which authorizes the Company to use up to $250.0 million to purchase its own shares following the expiration date of the 2014 buyback program. The Company's share buyback program is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.

[0001032975-17-000037:notes:129]
During the three months ended June 30, 2017 and 2016, 20 thousand and 1.6 million shares were repurchased for $0.6 million and $24.4 million, respectively.

[0001032975-17-000037:notes:130]
[same as prior period, unchanged from 0001032975-17-000005:notes:163]


## us-gaap:SubsequentEventsTextBlock

[0001032975-17-000037:notes:131]
Subsequent Event

[0001032975-17-000037:notes:132]
On July 10, 2017, the Company signed an agreement to acquire certain assets and liabilities constituting the Astro Gaming business from AG Acquisition Corporation for $85 million in cash.  Astro Gaming is a leading console gaming brand and has a history of producing award-winning headsets for professional gamers and enthusiasts. The transaction is expected to close in early August, 2017 and is subject to receipt of regulatory approvals in various jurisdictions and other closing conditions.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-17-000037:notes:133]
[same as prior period, unchanged from 0001032975-17-000005:notes:164]
