# LOGI MD&A — 0001032975-19-000075


## mdna

[0001032975-19-000075:mdna:1]
[same as prior period, unchanged from 0001032975-19-000059:mdna:1]

[0001032975-19-000075:mdna:2]
[same as prior period, unchanged from 0001032975-19-000059:mdna:2]

[0001032975-19-000075:mdna:3]
[same as prior period, unchanged from 0001032975-19-000059:mdna:3]

[0001032975-19-000075:mdna:4]
[same as prior period, unchanged from 0001032975-19-000059:mdna:4]

[0001032975-19-000075:mdna:5]
Our products participate in five large markets that all have growth opportunities: Creativity & Productivity, Gaming, Video Collaboration, Music, and Smart Home. We sell our products to a broad network of domestic and international customers, including direct sales to retailers and e-tailers, and indirect sales through distributors. Our worldwide channel network includes consumer electronics distributors, retailers, mass merchandisers, specialty stores, computer and telecommunications stores, value-added resellers and online merchants.

[0001032975-19-000075:mdna:6]
On September 26, 2019, we entered into an agreement to acquire all equity interests of General Workings, Inc. ("Streamlabs") for a total consideration of $89 million in cash, subject to a working capital adjustment, plus an additional earn-out of up to $29 million in stock based on the achievement of certain net revenues for the period beginning on January 1, 2020 and ending on June 30, 2020 (the "Streamlabs Acquisition"). Streamlabs is a leading provider of software and tools for professional streamers. The Streamlabs Acquisition will supplement our portfolio opportunities. The transaction is subject to various closing conditions and is expected to close in late October 2019.

[0001032975-19-000075:mdna:7]
[same as prior period, unchanged from 0001032975-19-000059:mdna:6]

[0001032975-19-000075:mdna:8]
[same as prior period, unchanged from 0001032975-19-000059:mdna:7]

[0001032975-19-000075:mdna:9]
Our total sales for the three and six months ended September 30, 2019 increased 4% and 5%, respectively, compared to the three and six months ended September 30, 2018, supported by stronger sales in the Americas and EMEA.

[0001032975-19-000075:mdna:10]
Our sales for the three months ended September 30, 2019 increased 5%, 6%, and 1% in the Americas, EMEA, and Asia Pacific, respectively, compared to the same period of the prior fiscal year. Our sales for the six months ended September 30, 2019 increased 5%, 8%, and 1% in the Americas, EMEA, and Asia Pacific, respectively, compared to the same period of the prior fiscal year.

[0001032975-19-000075:mdna:11]
Our gross margin for the three months ended September 30, 2019 increased 70 basis points to 37.8% from 37.1% for the three months ended September 30, 2018. Our gross margin for the six months ended September 30, 2019 increased 60 basis points to 37.5% from 36.9% for the six months ended September 30, 2018. Our gross margin for both periods benefited from cost savings, tariff mitigation efforts and product mix, partially offset by unfavorable currency exchange and an increase in U.S.-China tariffs. We expect a negative impact in the third quarter of fiscal year 2020 from these tariffs, net of our ongoing mitigation efforts.

[0001032975-19-000075:mdna:12]
Operating expenses for the three months ended September 30, 2019 increased to $204.0 million compared to $191.0 million in the same period of the prior fiscal year. Operating expenses were 28.3% of sales for the three months ended September 30, 2019, compared to 27.6% of sales in the same period of the prior fiscal year.

[0001032975-19-000075:mdna:13]
Operating expenses for the six months ended September 30, 2019 increased to $395.5 million compared to $382.5 million in the same period of the prior fiscal year. Operating expenses were 29.0% of sales for the six months ended September 30, 2019, compared to 29.4% of sales in the same period of the prior fiscal year.

[0001032975-19-000075:mdna:14]
Net income for the three and six months ended September 30, 2019 was $72.9 million and $118.3 million, respectively, compared to $64.2 million and $102.6 million for the three and six months ended September 30, 2018, respectively.

[0001032975-19-000075:mdna:15]
[same as prior period, unchanged from 0001032975-19-000059:mdna:13]

[0001032975-19-000075:mdna:16]
Our strategy focuses on five large multi-category markets, including Creativity & Productivity, Gaming, Video Collaboration, Music, and Smart Home. We see opportunities to deliver growth in all these markets.

[0001032975-19-000075:mdna:17]
[same as prior period, unchanged from 0001032975-19-000059:mdna:15]

[0001032975-19-000075:mdna:18]
[same as prior period, unchanged from 0001032975-19-000059:mdna:16]

[0001032975-19-000075:mdna:19]
Creativity & Productivity:  Although new PC shipments continue to be weak, the installed base of PC users remains large. We believe that innovative PC peripherals, such as our mice and keyboards, can renew the PC usage experience, thus providing growth opportunities. Increasing adoption of various cloud-based applications has led to multiple new consumer use cases, which we are addressing with our innovative product portfolio. The increasing popularity of streaming and broadcasting provides additional growth opportunities for our Webcam products. Smaller mobile computing devices, such as tablets, have created new markets and usage models for peripherals and accessories. We offer a number of products to enhance the use of mobile devices, including a combo backlit keyboard case for the iPad Pro and keyboard folios for the iPad and iPad mini. In fiscal year 2019, we saw a recovery of the iPad tablet market, and our Tablet & Other Accessories category benefited from the recovery along with our innovative products.

[0001032975-19-000075:mdna:20]
Gaming:  The PC gaming and console gaming platforms continue to show strong structural growth opportunities as online gaming, multi-platform experiences, and esports gain greater popularity and gaming content becomes increasingly more demanding. We believe Logitech is well positioned to benefit from the gaming market growth. With ASTRO Gaming, we also strengthened our portfolio in adjacent categories, such as the console controller market.

[0001032975-19-000075:mdna:21]
[same as prior period, unchanged from 0001032975-19-000059:mdna:19]

[0001032975-19-000075:mdna:22]
Music:  The music market grew during fiscal year 2019, driven by growing consumption of music through mobile devices such as smartphones and tablets. The integration of personal voice assistants has become increasingly competitive in the speaker categories, but the market for third-party, voice-enabled speakers has not yet gained traction. Moreover, the market for mobile speakers appears to be maturing, which led to a decline in Ultimate Ears sales in fiscal year 2019. In fiscal year 2019, the headphone industry continued to flourish with strong revenue growth. The largest growth was seen in wireless headphones where the market tripled year-over-year and where there was a substantial increase to average selling prices. Continued growth in the headphone market is expected for the next several years as consumers increasingly adopt wireless headphones over wired headphones. With Blue Microphones, we strengthened our portfolio in adjacent categories, such as the microphones market.

[0001032975-19-000075:mdna:23]
[same as prior period, unchanged from 0001032975-19-000059:mdna:21]

[0001032975-19-000075:mdna:24]
[same as prior period, unchanged from 0001032975-19-000059:mdna:22]

[0001032975-19-000075:mdna:25]
[same as prior period, unchanged from 0001032975-19-000059:mdna:23]

[0001032975-19-000075:mdna:26]
[same as prior period, unchanged from 0001032975-19-000059:mdna:24]

[0001032975-19-000075:mdna:27]
On May 19, 2019, the Swiss electorate approved TRAF, a major reform to better align the Swiss tax system with international tax standards. The legislation was subsequently published in the federal register on August 6, 2019 to take effect on January 1, 2020.   As of September 30, 2019, TRAF has not been enacted in all cantons, including the canton of Vaud, as the cantonal legislative procedures are in process.  We have benefited from a longstanding tax ruling from the canton of Vaud through March 31, 2019.  During the second quarter ended September 30, 2019, the canton of Vaud concluded the longstanding cantonal tax ruling will only continue to apply

[0001032975-19-000075:mdna:28]
through December 31, 2019.  We continue to monitor the enactment process and our transitional measures to comply with federal and cantonal tax reform provisions. We anticipate an increase in our cash tax payments in Switzerland beginning in fiscal year 2020.

[0001032975-19-000075:mdna:29]
[same as prior period, unchanged from 0001032975-19-000059:mdna:26]

[0001032975-19-000075:mdna:30]
The preparation of financial statements and related disclosures in conformity with GAAP requires us to make judgments, estimates and assumptions that affect the reported amounts of goodwill, intangible assets acquired from business acquisitions, operating right-of-use assets, warranty liabilities, accruals for customer incentives, cooperative marketing, and pricing programs and related breakage when appropriate, accrued sales return liability, allowance for doubtful accounts, inventory, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets.

[0001032975-19-000075:mdna:31]
[same as prior period, unchanged from 0001032975-19-000059:mdna:28]

[0001032975-19-000075:mdna:32]
We base our estimates on historical experience and on various other assumptions we believe to be reasonable under the circumstances. Although these estimates are based on management's best knowledge of current events and actions that may impact us in the future, actual results could differ from those estimates. Management has discussed the development, selection and disclosure of these critical accounting estimates with the Audit Committee of the Board of Directors.

[0001032975-19-000075:mdna:33]
Other than the recent accounting pronouncement adoptions and Summary of Significant Accounting Policies discussed in Note 1 to the condensed consolidated financial statements, there have been no substantial changes in our significant accounting policies during the six months ended September 30, 2019, compared with the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended March 31, 2019.

[0001032975-19-000075:mdna:34]
[same as prior period, unchanged from 0001032975-19-000059:mdna:32]

[0001032975-19-000075:mdna:35]
[same as prior period, unchanged from 0001032975-19-000059:mdna:33]

[0001032975-19-000075:mdna:36]
[same as prior period, unchanged from 0001032975-19-000059:mdna:34]

[0001032975-19-000075:mdna:37]
[same as prior period, unchanged from 0001032975-19-000059:mdna:35]

[0001032975-19-000075:mdna:38]
[same as prior period, unchanged from 0001032975-19-000059:mdna:36]

[0001032975-19-000075:mdna:39]
[same as prior period, unchanged from 0001032975-19-000059:mdna:37]

[0001032975-19-000075:mdna:40]
[same as prior period, unchanged from 0001032975-19-000059:mdna:38]

[0001032975-19-000075:mdna:41]
[same as prior period, unchanged from 0001032975-19-000059:mdna:39]

[0001032975-19-000075:mdna:42]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Canadian Dollar, Taiwan New Dollar, British Pound and Australian Dollar. During the three months ended September 30, 2019, approximately  51% of our sales were denominated in currencies other than the U.S. Dollar.

[0001032975-19-000075:mdna:43]
[same as prior period, unchanged from 0001032975-19-000059:mdna:41]

[0001032975-19-000075:mdna:44]
[same as prior period, unchanged from 0001032975-19-000059:mdna:42]

[0001032975-19-000075:mdna:45]
Our sales in the three and six months ended September 30, 2019 increased 4% and 5%, respectively, compared to the same period of the prior fiscal year, driven by sales increases in the Americas and EMEA regions. Strong growth in Video Collaboration, Keyboards & Combos and Audio & Wearables was partially offset by a decline in sales for Mobile Speakers for both periods presented. If currency exchange rates had been constant in the three and six months ended September 30, 2019 and 2018, our constant dollar sales growth rates would have been 6% and 7%, respectively.

[0001032975-19-000075:mdna:46]
26

[0001032975-19-000075:mdna:47]
[same as prior period, unchanged from 0001032975-19-000059:mdna:45]

[0001032975-19-000075:mdna:48]
The following table presents the change in sales by region for the three and six months ended September 30, 2019, compared with the three and six months ended September 30, 2018:

[0001032975-19-000075:mdna:49]
|  |  | Sales Growth Rate |  | Constant DollarSales Growth Rate |
|  |  | Three Months EndedSeptember 30, 2019 |  | Six Months EndedSeptember 30, 2019 |  | Three Months EndedSeptember 30, 2019 | Six Months EndedSeptember 30, 2019 |
| Americas |  | 5 | % |  | 5 | % |  | 5 | % | 6 | % |
| EMEA |  | 6 | % |  | 8 | % |  | 10 | % | 13 | % |
| Asia Pacific |  | 1 | % |  | 1 | % |  | 3 | % | 4 | % |

[0001032975-19-000075:mdna:50]
[same as prior period, unchanged from 0001032975-19-000059:mdna:48]

[0001032975-19-000075:mdna:51]
The increase in sales in our Americas region for the three-month ended period presented above was primarily driven by growth in Video Collaboration, Audio & Wearables, and Tablet and Other Accessories, partially offset by a decline in sales in Mobile Speakers and Gaming. The increase in sales in our Americas region for the six-month period presented above was primarily driven by the same categories, partially offset by a decline in sales for Gaming and Pointing Devices.

[0001032975-19-000075:mdna:52]
[same as prior period, unchanged from 0001032975-19-000059:mdna:50]

[0001032975-19-000075:mdna:53]
The increase in sales in our EMEA region for the three-month ended period presented above was primarily driven by growth in Video Collaboration and Pointing Devices, partially offset by a decline in sales in Tablet and Other Accessories and Mobile Speakers. The increase in sales in our EMEA region for the six-month period presented above was primarily driven by growth in Video Collaboration, Mobile Speakers, Pointing Devices and Smart Home.

[0001032975-19-000075:mdna:54]
[same as prior period, unchanged from 0001032975-19-000059:mdna:52]

[0001032975-19-000075:mdna:55]
The increase in sales in our Asia Pacific region for both the three and six -month ended periods presented above was primarily driven by growth in Video Collaboration, Gaming and Keyboards & Combos, partially offset by a decline in sales in Mobile Speakers and Audio & Wearables.

[0001032975-19-000075:mdna:56]
[same as prior period, unchanged from 0001032975-19-000059:mdna:54]

[0001032975-19-000075:mdna:57]
Sales by product categories for the three and six months ended September 30, 2019 and 2018 were as follows (Dollars in thousands):

[0001032975-19-000075:mdna:58]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Pointing Devices |  | $ | 132,770 |  |  | $ | 128,337 |  |  | 3 | % |  | $ | 254,753 |  |  | $ | 256,127 |  |  | (1 | )% |
| Keyboards & Combos |  | 139,049 |  |  | 131,872 |  |  | 5 |  |  | 267,728 |  |  | 260,094 |  |  | 3 |  |
| PC Webcams |  | 28,748 |  |  | 28,221 |  |  | 2 |  |  | 56,876 |  |  | 57,895 |  |  | (2 | ) |
| Tablet & Other Accessories |  | 33,847 |  |  | 36,710 |  |  | (8 | ) |  | 72,186 |  |  | 69,146 |  |  | 4 |  |
| Video Collaboration |  | 89,553 |  |  | 57,176 |  |  | 57 |  |  | 162,977 |  |  | 115,968 |  |  | 41 |  |
| Mobile Speakers |  | 57,232 |  |  | 77,100 |  |  | (26 | ) |  | 107,648 |  |  | 111,427 |  |  | (3 | ) |
| Audio & Wearables |  | 68,018 |  |  | 61,560 |  |  | 10 |  |  | 126,642 |  |  | 113,714 |  |  | 11 |  |
| Gaming |  | 161,014 |  |  | 160,792 |  |  | — |  |  | 295,529 |  |  | 296,818 |  |  | — |  |
| Smart Home |  | 9,434 |  |  | 9,241 |  |  | 2 |  |  | 19,298 |  |  | 18,252 |  |  | 6 |  |
| Other (1) |  | 26 |  |  | 137 |  |  | (81 | ) |  | 279 |  |  | 185 |  |  | 51 |  |
| Total sales |  | $ | 719,691 |  |  | $ | 691,146 |  |  | 4 | % |  | $ | 1,363,916 |  |  | $ | 1,299,626 |  |  | 5 | % |

[0001032975-19-000075:mdna:59]
[same as prior period, unchanged from 0001032975-19-000059:mdna:57]

[0001032975-19-000075:mdna:60]
[same as prior period, unchanged from 0001032975-19-000059:mdna:58]

[0001032975-19-000075:mdna:61]
[same as prior period, unchanged from 0001032975-19-000059:mdna:59]

[0001032975-19-000075:mdna:62]
Our Pointing Devices category comprises PC- and Mac-related mice, including trackballs, touchpads and presenters.

[0001032975-19-000075:mdna:63]
Sales of Pointing Devices increased 3% and decreased 1% in the three and six months ended September 30, 2019, respectively, compared to the same periods of the prior fiscal year. The increase in sales for the three-month period was primarily driven by growth in cordless mice, partially offset by a decline in corded mice. The decline in sales for the six-month period was primarily driven by a decrease in corded mice and presentation tools, partially offset by growth in cordless mice.

[0001032975-19-000075:mdna:64]
[same as prior period, unchanged from 0001032975-19-000059:mdna:62]

[0001032975-19-000075:mdna:65]
[same as prior period, unchanged from 0001032975-19-000059:mdna:63]

[0001032975-19-000075:mdna:66]
Sales of Keyboards & Combos increased 5% and 3% in the three and six months ended September 30, 2019, respectively, compared to the same periods of the prior fiscal year. The increases were across all regions for both periods and driven by increases in sales of cordless and corded keyboards and cordless keyboard/mice combos.

[0001032975-19-000075:mdna:67]
[same as prior period, unchanged from 0001032975-19-000059:mdna:65]

[0001032975-19-000075:mdna:68]
[same as prior period, unchanged from 0001032975-19-000059:mdna:66]

[0001032975-19-000075:mdna:69]
PC Webcams sales increased 2% and decreased 2% in the three and six months ended September 30, 2019, respectively, compared to the same periods of the prior fiscal year. The increase in sales for the three-month period was primarily driven by an increase in the sales of our Webcam C260, 1080P Pro Stream Webcam, BRIO 4K Stream Edition and C270i IPTV CAM, partially offset by a decline in sales of our HD Pro Webcam C920 and Webcam C170. The decrease in sales for the six-month period was primarily driven by a decline in sales of our HD PRO Webcam C920 and Webcam C170, partially offset by an increase in sales of our Webcam C260, 1080P Pro Stream Webcam, BRIO 4K Stream Edition and C270i IPTV CAM.

[0001032975-19-000075:mdna:70]
[same as prior period, unchanged from 0001032975-19-000059:mdna:68]

[0001032975-19-000075:mdna:71]
[same as prior period, unchanged from 0001032975-19-000059:mdna:69]

[0001032975-19-000075:mdna:72]
Sales of Tablet & Other Accessories products decreased 8% and increased 4% in the three and six months ended September 30, 2019, respectively, compared to the same periods of the prior fiscal year. The decrease in sales for the three-month period was primarily driven by a decline in sales of our Slim Combos for the iPad Pro and Slim Folio for the iPad, partially offset by sales increases of Rugged Combo 2 and sales of Slim Folio for iPad Pro introduced in the first quarter of fiscal year 2020. The increase in sales for the six-month period was primarily driven by an increase in sales of our Rugged Combo 2 and Slim Folio for iPad and Slim Folio keyboard cases for the iPad Pro, partially offset by a decline in sales of our Slim Combo keyboard cases for the iPad Pro and  Slim Folio for the iPad.

[0001032975-19-000075:mdna:73]
[same as prior period, unchanged from 0001032975-19-000059:mdna:71]

[0001032975-19-000075:mdna:74]
[same as prior period, unchanged from 0001032975-19-000059:mdna:72]

[0001032975-19-000075:mdna:75]
Gaming sales remained flat for the three and six months ended September 30, 2019, compared to the same periods of the prior fiscal year. Increases in the sales of gaming mice, PC gaming keyboard and console gaming controllers were offset by declines in the sales of our gaming headsets and console gaming headsets for both periods presented above.

[0001032975-19-000075:mdna:76]
[same as prior period, unchanged from 0001032975-19-000059:mdna:74]

[0001032975-19-000075:mdna:77]
[same as prior period, unchanged from 0001032975-19-000059:mdna:75]

[0001032975-19-000075:mdna:78]
[same as prior period, unchanged from 0001032975-19-000059:mdna:76]

[0001032975-19-000075:mdna:79]
Sales of Video Collaboration products increased 57% and 41% in the three and six months ended September 30, 2019, respectively, compared to the same periods of the prior fiscal year. The increase for both periods was primarily driven by the sales of our Rally Ultra-HD PTZ Conference Camera introduced in the third quarter of fiscal year 2019, an increase in the sales of our MeetUp video conference camera, and our Tap Touch Controller introduced in the first quarter of fiscal year 2020.

[0001032975-19-000075:mdna:80]
[same as prior period, unchanged from 0001032975-19-000059:mdna:78]

[0001032975-19-000075:mdna:81]
[same as prior period, unchanged from 0001032975-19-000059:mdna:79]

[0001032975-19-000075:mdna:82]
[same as prior period, unchanged from 0001032975-19-000059:mdna:80]

[0001032975-19-000075:mdna:83]
Sales of Mobile Speakers decreased 26% and 3% for the three and six months ended September 30, 2019, respectively, compared to the same periods of the prior fiscal year. The decrease for the three-month period was primarily due to the decline in sales of our BOOM 3, MEGABOOM 3, WONDERBOOM, and BOOM 2 mobile speakers, partially offset by sales of our WONDERBOOM 2 introduced in the first quarter of fiscal year 2020. The decrease for the six-month period is primarily due to a decline in sales of our WONDERBOOM, BOOM 2, and MEGABLAST mobile speakers, partially offset by sales of WONDERBOOM 2 and an increase in sales of our BOOM 3 and MEGABOOM mobile speakers.

[0001032975-19-000075:mdna:84]
[same as prior period, unchanged from 0001032975-19-000059:mdna:83]

[0001032975-19-000075:mdna:85]
[same as prior period, unchanged from 0001032975-19-000059:mdna:84]

[0001032975-19-000075:mdna:86]
Audio & Wearables sales increased 10% and 11% for the three and six months ended September 30, 2019, respectively, compared to the same periods of the prior fiscal year. The increase for the three-month period was primarily driven by the sales of our Blue Microphones products as a result of our business combination in the second quarter of fiscal year 2019. The increase for the six-months period was primarily driven by the sales of our Blue Microphones products, partially offset by a decline in the sales of our PC speakers and Jaybird products.

[0001032975-19-000075:mdna:87]
[same as prior period, unchanged from 0001032975-19-000059:mdna:86]

[0001032975-19-000075:mdna:88]
[same as prior period, unchanged from 0001032975-19-000059:mdna:87]

[0001032975-19-000075:mdna:89]
Smart Home sales increased 2% and 6% during the three and six months ended September 30, 2019, respectively, compared to the same periods of the prior fiscal year. The increase for both periods was primarily due to an increase in the sales of our home security products, partially offset by a decline in sales of our Harmony remote products.

[0001032975-19-000075:mdna:90]
[same as prior period, unchanged from 0001032975-19-000059:mdna:89]

[0001032975-19-000075:mdna:91]
Gross profit for the three and six months ended September 30, 2019 and 2018 was as follows (Dollars in thousands):

[0001032975-19-000075:mdna:92]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Net sales |  | $ | 719,691 |  |  | $ | 691,146 |  |  | 4 | % |  | $ | 1,363,916 |  |  | $ | 1,299,626 |  |  | 5 | % |
| Gross profit |  | $ | 272,076 |  |  | $ | 256,117 |  |  | 6 |  |  | $ | 511,052 |  |  | $ | 480,054 |  |  | 6 |  |
| Gross margin |  | 37.8 | % |  | 37.1 | % |  |  |  | 37.5 | % |  | 36.9 | % |  |  |  |

[0001032975-19-000075:mdna:93]
[same as prior period, unchanged from 0001032975-19-000059:mdna:92]

[0001032975-19-000075:mdna:94]
[same as prior period, unchanged from 0001032975-19-000059:mdna:93]

[0001032975-19-000075:mdna:95]
Operating expenses for the three and six months ended September 30, 2019 and 2018 were as follows (Dollars in thousands):

[0001032975-19-000075:mdna:96]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Marketing and selling |  | $ | 134,155 |  |  | $ | 121,801 |  |  | $ | 257,188 |  |  | $ | 236,385 |  |
| % of sales |  | 18.6 | % |  | 17.6 | % |  | 18.9 | % |  | 18.2 | % |
| Research and development |  | 41,964 |  |  | 39,542 |  |  | 84,207 |  |  | 78,529 |  |
| % of sales |  | 5.8 | % |  | 5.7 | % |  | 6.2 | % |  | 6.0 | % |
| General and administrative |  | 24,048 |  |  | 25,206 |  |  | 46,207 |  |  | 50,679 |  |
| % of sales |  | 3.3 | % |  | 3.6 | % |  | 3.4 | % |  | 3.9 | % |
| Amortization of intangible assets and acquisition-related costs |  | 4,218 |  |  | 4,317 |  |  | 7,814 |  |  | 6,838 |  |
| % of sales |  | 0.6 | % |  | 0.6 | % |  | 0.6 | % |  | 0.5 | % |
| Restructuring charges (credits), net |  | (364 | ) |  | 119 |  |  | 114 |  |  | 10,040 |  |
| % of sales |  | — | % | (1) | — | % |  | — | % | (1) | 0.8 | % |
| Total operating expenses |  | $ | 204,021 |  |  | $ | 190,985 |  |  | $ | 395,530 |  |  | $ | 382,471 |  |
| % of sales |  | 28.3 | % |  | 27.6 | % |  | 29.0 | % |  | 29.4 | % |

[0001032975-19-000075:mdna:97]
[same as prior period, unchanged from 0001032975-19-000059:mdna:96]

[0001032975-19-000075:mdna:98]
[same as prior period, unchanged from 0001032975-19-000059:mdna:97]

[0001032975-19-000075:mdna:99]
[same as prior period, unchanged from 0001032975-19-000059:mdna:98]

[0001032975-19-000075:mdna:100]
During the three and six months ended September 30, 2019, marketing and selling expenses increased $12.4 million and $20.8 million, respectively, compared to the same periods of the prior fiscal year. The increases were primarily driven by higher advertising and marketing expenses and higher personnel-related costs due to increased headcount, partly resulting from the Blue Microphones acquisition.

[0001032975-19-000075:mdna:101]
[same as prior period, unchanged from 0001032975-19-000059:mdna:100]

[0001032975-19-000075:mdna:102]
[same as prior period, unchanged from 0001032975-19-000059:mdna:101]

[0001032975-19-000075:mdna:103]
During the three and six months ended September 30, 2019, research and development expenses increased $2.4 million and $5.7 million, respectively, compared to the same periods of the prior fiscal year. The increases were primarily driven by higher personnel-related costs due to increased headcount, partly resulting from the Blue Microphones acquisition.

[0001032975-19-000075:mdna:104]
[same as prior period, unchanged from 0001032975-19-000059:mdna:103]

[0001032975-19-000075:mdna:105]
[same as prior period, unchanged from 0001032975-19-000059:mdna:104]

[0001032975-19-000075:mdna:106]
During the three and six months ended September 30, 2019, general and administrative expenses decreased $1.2 million and $4.5 million, respectively, compared to the same periods of the prior fiscal year. The decrease was primarily driven by lower personnel-related costs.

[0001032975-19-000075:mdna:107]
[same as prior period, unchanged from 0001032975-19-000059:mdna:106]

[0001032975-19-000075:mdna:108]
[same as prior period, unchanged from 0001032975-19-000059:mdna:107]

[0001032975-19-000075:mdna:109]
During the three months ended September 30, 2019, amortization of intangible assets and acquisition-related costs remained relatively flat compared to the same period of the prior fiscal year. During the six months ended September 30, 2019, amortization of intangible assets and acquisition-related costs increased $1.0 million compared to the same period of the prior fiscal year, primarily driven by the intangible assets acquired through the Blue Microphones acquisition in the second quarter of fiscal year 2019, partially offset by a decrease in acquisition-related costs.

[0001032975-19-000075:mdna:110]
[same as prior period, unchanged from 0001032975-19-000059:mdna:109]

[0001032975-19-000075:mdna:111]
During the first quarter of fiscal year 2019, we implemented a restructuring plan to streamline and realign our overall organizational structure and reallocate resources to support our long-term growth opportunities. In July, 2018, our Board of Directors approved additional costs under this restructuring plan, totaling pre-tax charges of approximately $10.0 million to $15.0 million, of which $11.4 million has been recognized cumulatively as of September 30, 2019. The total charges consisted of cash severance and other personnel costs and are presented as restructuring charges (credit), net in the condensed consolidated statements of operations. As of June 30, 2019, the Company has substantially completed this restructuring plan.

[0001032975-19-000075:mdna:112]
The following table summarizes restructuring-related activities during the three and six months ended September 30, 2019 (in thousands):

[0001032975-19-000075:mdna:113]
|  |  | TerminationBenefits |
| Accrual balance at March 31, 2019 |  | $ | 4,389 |  |
| Charges |  | 478 |  |
| Cash payments |  | (1,956 | ) |
| Accrual balance at June 30, 2019 |  | $ | 2,911 |  |
| Charges |  | (364 | ) |
| Cash payments |  | (1,140 | ) |
| Accrual balance at September 30, 2019 |  | $ | 1,407 |  |

[0001032975-19-000075:mdna:114]
[same as prior period, unchanged from 0001032975-19-000059:mdna:113]

[0001032975-19-000075:mdna:115]
Other income (expense), net for the three and six months ended September 30, 2019 and 2018 was as follows (in thousands):

[0001032975-19-000075:mdna:116]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Investment income related to a deferred compensation plan |  | $ | 202 |  |  | $ | 596 |  |  | $ | 791 |  |  | $ | 810 |  |
| Currency exchange gain (loss), net |  | (319 | ) |  | 1,788 |  |  | 499 |  |  | (86 | ) |
| Gain (loss) on investments |  | (274 | ) |  | 395 |  |  | (63 | ) |  | 382 |  |
| Other |  | 281 |  |  | 610 |  |  | 524 |  |  | 712 |  |
| Total |  | $ | (110 | ) |  | $ | 3,389 |  |  | $ | 1,751 |  |  | $ | 1,818 |  |

[0001032975-19-000075:mdna:117]
[same as prior period, unchanged from 0001032975-19-000059:mdna:116]

[0001032975-19-000075:mdna:118]
[same as prior period, unchanged from 0001032975-19-000059:mdna:117]

[0001032975-19-000075:mdna:119]
[same as prior period, unchanged from 0001032975-19-000059:mdna:118]

[0001032975-19-000075:mdna:120]
The provision for (benefit from) income taxes and effective tax rates for the three and six months ended September 30, 2019 and 2018 were as follows (Dollars in thousands):

[0001032975-19-000075:mdna:121]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Provision for (benefit from) income taxes |  | $ | (2,598 | ) |  | $ | 6,203 |  |  | $ | 3,938 |  |  | $ | 986 |  |
| Effective income tax rate |  | (3.7 | )% |  | 8.8 | % |  | 3.2 | % |  | 1.0 | % |

[0001032975-19-000075:mdna:122]
The change in the effective income tax rate for the three months ended September 30, 2019, compared to the same period ended September 30, 2018, was primarily due to the transitional income tax impact in Switzerland. We have benefited from a longstanding tax ruling from the canton of Vaud through March 31, 2019. During the second quarter, the canton of Vaud concluded the longstanding cantonal tax ruling will only continue to apply through December 31, 2019. The transitional income tax impact, which represents income tax provision at the current full statutory income tax rate of 13.63% without taking account of the tax reform yet to be enacted, resulted in a tax benefit of $5.9 million in the three-month period ended September 30, 2019. In addition, there was a discrete tax benefit of $4.0 million from adjusting deferred tax assets and liabilities in Switzerland in the three months ended September 30, 2019.

[0001032975-19-000075:mdna:123]
The change in the effective income tax rate for the six months ended September 30, 2019, compared to the same period ended September 30, 2018 was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate and the transitional income tax impact in Switzerland discussed above. In the six months ended September 30, 2019, there was a discrete tax benefit of $1.7 million from adjusting deferred tax assets and liabilities in Switzerland. Furthermore, there were discrete tax benefits of $6.7 million and $1.8 million from the recognition of excess tax benefits in the United States and reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the six-month period ended September 30, 2019, compared with $9.0 million and $1.4 million, respectively, in the six-month period ended September 30, 2018.

[0001032975-19-000075:mdna:124]
As of September 30, 2019 and March 31, 2019, the total amounts of unrecognized tax benefits due to uncertain tax positions were $78.9 million and $76.5 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-19-000075:mdna:125]
[same as prior period, unchanged from 0001032975-19-000059:mdna:123]

[0001032975-19-000075:mdna:126]
[same as prior period, unchanged from 0001032975-19-000059:mdna:124]

[0001032975-19-000075:mdna:127]
As of September 30, 2019, we had cash and cash equivalents of $574.5 million, compared to $604.5 million as of March 31, 2019. As of September 30, 2019, 48% of the cash and cash equivalents were held in Switzerland and 12% held in Hong Kong and China. We do not expect to incur any material adverse tax impact except for what has been recognized, or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-19-000075:mdna:128]
The decrease in cash and cash equivalents for the six months ended September 30, 2019, was primarily due to payment of cash dividends, purchases of property, plant and equipment, tax withholdings related to settlements of restricted stock units and shares repurchased under our share buyback program, partially offset by proceeds from exercises of stock options and purchase rights and net cash provided by operating activities.

[0001032975-19-000075:mdna:129]
As of September 30, 2019, our working capital was $622.4 million, compared to $632.6 million as of March 31, 2019. The decrease was primarily driven by  lower cash and cash equivalents and higher accounts payable, partially offset by higher accounts receivable, net, higher inventories, higher other current assets and lower accrued and other current liabilities. Our working capital increased by $183.8 million compared to $438.6 million as of September 30, 2018, which was primarily driven by higher cash and cash equivalents, higher accounts receivable, net, lower accounts payable, and lower accrued and other current liabilities, partially offset by lower inventories.

[0001032975-19-000075:mdna:130]
We had several uncommitted, unsecured bank lines of credit aggregating $77.5 million as of September 30, 2019. There are no financial covenants under these lines of credit with which we must comply. As of September 30, 2019, we had outstanding bank guarantees of $20.6 million under these lines of credit.

[0001032975-19-000075:mdna:131]
[same as prior period, unchanged from 0001032975-19-000059:mdna:129]

[0001032975-19-000075:mdna:132]
|  |  | Six Months EndedSeptember 30, |
|  |  | 2019 |  | 2018 |
| Net cash provided by operating activities |  | $ | 143,019 |  |  | $ | 97,220 |  |
| Net cash used in investing activities |  | (18,582 | ) |  | (153,815 | ) |
| Net cash used in financing activities |  | (150,884 | ) |  | (151,245 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (3,605 | ) |  | (9,157 | ) |
| Net decrease in cash and cash equivalents |  | $ | (30,052 | ) |  | $ | (216,997 | ) |

[0001032975-19-000075:mdna:133]
The following table presents selected financial information and statistics as of and for the three months ended September 30, 2019 and 2018 (Dollars in thousands):

[0001032975-19-000075:mdna:134]
|  |  | As of September 30, |
|  |  | 2019 |  | 2018 |
| Accounts receivable, net |  | $ | 465,969 |  |  | $ | 459,689 |  |
| Accounts payable |  | $ | 411,043 |  |  | $ | 440,564 |  |
| Inventories |  | $ | 338,314 |  |  | $ | 358,774 |  |

[0001032975-19-000075:mdna:135]
|  |  | Three Months EndedSeptember 30, |
|  |  | 2019 |  | 2018 |
| Days sales in accounts receivable (“DSO”) (Days) (1) |  | 58 |  |  | 60 |  |
| Days accounts payable outstanding (“DPO”) (Days) (2) |  | 83 |  |  | 91 |  |
| Inventory turnover (“ITO”) (x)(3) |  | 5.3 |  |  | 4.9 |  |

[0001032975-19-000075:mdna:136]
[same as prior period, unchanged from 0001032975-19-000059:mdna:134]

[0001032975-19-000075:mdna:137]
[same as prior period, unchanged from 0001032975-19-000059:mdna:135]

[0001032975-19-000075:mdna:138]
[same as prior period, unchanged from 0001032975-19-000059:mdna:136]

[0001032975-19-000075:mdna:139]
DSO for the three months ended September 30, 2019 decreased by 2 days to 58 days, compared to 60 days for the same period of the prior fiscal year, primarily due to timing of customer payments and claims.

[0001032975-19-000075:mdna:140]
DPO for the three months ended September 30, 2019 decreased by 8 days, compared to the same period of the prior fiscal year, primarily due to the timing of purchases and related payments.

[0001032975-19-000075:mdna:141]
ITO for the three months ended September 30, 2019 increased to 5.3 compared to 4.9 in the same period of the prior fiscal year, primarily due to higher sales growth (hence higher cost of goods sold) than inventory increase.

[0001032975-19-000075:mdna:142]
[same as prior period, unchanged from 0001032975-19-000059:mdna:140]

[0001032975-19-000075:mdna:143]
During the six months ended September 30, 2019, we generated $143.0 million of cash from operating activities. Our main sources of operating cash flows were from net income, after adding back non-cash expenses of depreciation, amortization and share-based compensation expense, and from changes in operating assets and liabilities. The increase in accounts receivable, net was primarily driven by growth and timing of customer payments and claims. The increase in inventories was primarily driven by the expectation of increased sales for the holidays in the third quarter. The increase in accounts payable was primarily driven by the timing of purchases and related payments.

[0001032975-19-000075:mdna:144]
Net cash used in investing activities was $18.6 million, primarily due to $18.1 million of purchases of property, plant and equipment.

[0001032975-19-000075:mdna:145]
Net cash used in financing activities was $150.9 million, primarily due to $124.2 million payment of cash dividend, $15.1 million used for repurchases of our registered shares, and $20.9 million tax withholdings related to net share settlements of restricted stock units, partially offset by $9.3 million in proceeds received from exercises of stock options and purchase rights.

[0001032975-19-000075:mdna:146]
During the six months ended September 30, 2019, there was a $3.6 million loss from effect of currency exchange rate changes on cash and cash equivalents, compared to a loss of $9.2 million during the same period of the prior fiscal year. The loss from effect of currency exchange rate changes during the six months ended September 30, 2019 was primarily due to the weakening of the Euro, Chinese Renminbi and Brazilian Real against the U.S.Dollar by 3%, 5%, 7% respectively. The loss from effect of currency exchange rate changes during the six months ended September 30, 2018 was primarily due to the weakening of the Euro, Chinese Renminbi, Brazilian Real, and Japanese Yen against the U.S. Dollar by 6%, 9%, 18% and 6%, respectively, during the period.

[0001032975-19-000075:mdna:147]
[same as prior period, unchanged from 0001032975-19-000059:mdna:145]

[0001032975-19-000075:mdna:148]
[same as prior period, unchanged from 0001032975-19-000059:mdna:146]

[0001032975-19-000075:mdna:149]
On September 26, 2019, we entered into an agreement to acquire all equity interests of Streamlabs for a total consideration of $89 million in cash, subject to a working capital adjustment, plus an additional earn-out of up to $29 million in stock based on the achievement of certain net revenues for the period beginning on January 1, 2020 and ending on June 30, 2020. The transaction is subject to various closing conditions and is expected to close in late October 2019.

[0001032975-19-000075:mdna:150]
In fiscal year 2020, we paid a cash dividend of CHF 121.8 million (U.S. Dollar amount of $124.2 million) out of retained earnings available at the end of fiscal year 2019. In fiscal year 2019, we paid a cash dividend of CHF 110.7 million (U.S. Dollar amount of $114.0 million) out of retained earnings available at the end of fiscal year 2018. Any future dividends will be subject to the approval of our shareholders.

[0001032975-19-000075:mdna:151]
In March 2017, our Board of Directors approved our 2017 share buyback program, which authorizes us to purchase up to $250.0 million of our outstanding shares over a three-year period. The program was approved by the Swiss Takeover Board in May 2017. Although we enter into trading plans for systematic repurchases (e.g., 10b5-1 trading plans) from time to time, our share buyback program provides us with the opportunity to make repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. As of September 30, 2019, $172.4 million is still available for repurchase under the 2017 share buyback program.

[0001032975-19-000075:mdna:152]
[same as prior period, unchanged from 0001032975-19-000059:mdna:149]

[0001032975-19-000075:mdna:153]
[same as prior period, unchanged from 0001032975-19-000059:mdna:150]

[0001032975-19-000075:mdna:154]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. The remaining terms of our non-cancelable operating leases expire in various years through 2031.

[0001032975-19-000075:mdna:155]
[same as prior period, unchanged from 0001032975-19-000059:mdna:152]

[0001032975-19-000075:mdna:156]
As of September 30, 2019, we had non-cancelable purchase commitments for inventory purchases made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. Non-cancelable purchase commitments for capital expenditures primarily relate to commitments for tooling for new and existing products, computer hardware, leasehold and improvements. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-19-000075:mdna:157]
[same as prior period, unchanged from 0001032975-19-000059:mdna:154]

[0001032975-19-000075:mdna:158]
[same as prior period, unchanged from 0001032975-19-000059:mdna:155]

[0001032975-19-000075:mdna:159]
[same as prior period, unchanged from 0001032975-19-000059:mdna:156]

[0001032975-19-000075:mdna:160]
[same as prior period, unchanged from 0001032975-19-000059:mdna:157]

[0001032975-19-000075:mdna:161]
[same as prior period, unchanged from 0001032975-19-000059:mdna:158]

[0001032975-19-000075:mdna:162]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2019, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-19-000075:mdna:163]
[same as prior period, unchanged from 0001032975-19-000059:mdna:160]

[0001032975-19-000075:mdna:164]
Legal Proceedings

[0001032975-19-000075:mdna:165]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of our business. We are currently subject to several such claims and a small number of legal proceedings. We believe that these matters lack merit and we intend to vigorously defend against them. Based on currently available information, we do not believe that resolution of pending matters will have a material adverse effect on our financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that our defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on our business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against us, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary licenses or other rights, or litigation arising out of intellectual property claims, could adversely affect our business.
