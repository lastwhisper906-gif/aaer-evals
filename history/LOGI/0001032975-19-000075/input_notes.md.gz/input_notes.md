# LOGI notes — 0001032975-19-000075


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-19-000075:notes:1]
[same as prior period, unchanged from 0001032975-19-000059:notes:1]

[0001032975-19-000075:notes:2]
[same as prior period, unchanged from 0001032975-19-000059:notes:2]

[0001032975-19-000075:notes:3]
[same as prior period, unchanged from 0001032975-19-000059:notes:3]

[0001032975-19-000075:notes:4]
[same as prior period, unchanged from 0001032975-19-000059:notes:4]

[0001032975-19-000075:notes:5]
[same as prior period, unchanged from 0001032975-19-000059:notes:5]

[0001032975-19-000075:notes:6]
[same as prior period, unchanged from 0001032975-19-000059:notes:6]

[0001032975-19-000075:notes:7]
[same as prior period, unchanged from 0001032975-19-000059:notes:7]

[0001032975-19-000075:notes:8]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and six months ended September 30, 2019 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2020, or any future periods.

[0001032975-19-000075:notes:9]
[same as prior period, unchanged from 0001032975-19-000059:notes:9]

[0001032975-19-000075:notes:10]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted and Summary of Significant Accounting Policies, there have been no changes in the Company’s significant accounting policies during the six months ended September 30, 2019 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2019.

[0001032975-19-000075:notes:11]
[same as prior period, unchanged from 0001032975-19-000059:notes:11]

[0001032975-19-000075:notes:12]
The preparation of financial statements in conformity with GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill, intangible assets acquired from business acquisitions, valuation of operating right-of-use assets, warranty liabilities, accruals for customer incentives, cooperative marketing, and pricing programs (Customer Programs) and related breakage when appropriate, accrued sales return liability, allowance for doubtful accounts, inventory valuation,

[0001032975-19-000075:notes:13]
share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from these estimates.

[0001032975-19-000075:notes:14]
[same as prior period, unchanged from 0001032975-19-000059:notes:14]

[0001032975-19-000075:notes:15]
In February 2016, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No. 2016-02, "Leases (Topic 842)" (ASU 2016-02 or Topic 842), which requires a lessee to recognize right-of-use (ROU) assets and lease liabilities arising from operating and financing leases with terms longer than 12 months on the consolidated balance sheets and to disclose key information about leasing arrangements.

[0001032975-19-000075:notes:16]
[same as prior period, unchanged from 0001032975-19-000059:notes:16]

[0001032975-19-000075:notes:17]
[same as prior period, unchanged from 0001032975-19-000059:notes:17]

[0001032975-19-000075:notes:18]
In August 2018, the FASB issued ASU 2018-15, "Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Customer's Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract" (ASU 2018-15), which clarifies that implementation costs incurred by customers in cloud computing arrangements are deferred if they would be capitalized by customers in software licensing arrangements under the internal-use software guidance. ASU 2018-15 is effective for annual and interim periods in fiscal years beginning after December 15, 2019, with early adoption permitted. Entities have the option to apply the guidance prospectively to all implementation costs incurred after the date of adoption or retrospectively. The Company adopted this standard effective April 1, 2019 using a prospective adoption method. The adoption of ASU 2018-15 did not have a material impact on the Company's condensed consolidated financial statements.

[0001032975-19-000075:notes:19]
[same as prior period, unchanged from 0001032975-19-000059:notes:19]

[0001032975-19-000075:notes:20]
In June 2016, the FASB issued ASU 2016-13, "Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments" (ASU 2016-13), which replaces the incurred-loss impairment methodology and requires immediate recognition of estimated credit losses expected to occur for most financial assets, including trade receivables. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not expect the adoption of ASU 2016-13 will have a material impact on its consolidated financial statements and plans to adopt the standard effective April 1, 2020.

[0001032975-19-000075:notes:21]
In August 2018, the FASB issued ASU 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirements for Fair Value Measurements" (ASU 2018-13), which aims to improve the overall usefulness of disclosures to financial statement users and reduce unnecessary costs to companies when preparing fair value measurement disclosures. ASU 2018-13 is effective for annual and interim periods in fiscal years beginning after December 15, 2019. Early adoption is permitted. Retrospective adoption is required, except for certain disclosures which will be required to be applied prospectively for only the most recent interim or annual period presented in the initial fiscal year of adoption. The Company does not expect the adoption of ASU 2018-13

[0001032975-19-000075:notes:22]
will have a material impact on its consolidated financial statements and plans to adopt the standard effective April 1, 2020.

[0001032975-19-000075:notes:23]
In August 2018, the FASB issued ASU 2018-14, "Compensation - Retirement Benefits - Defined Benefits Plans - General (Subtopic 715-20): Disclosure Framework - Changes to the Disclosure Requirements for Defined Benefit Plans" (ASU 2018-14), which aims to improve the overall usefulness of disclosures to financial statement users and reduce unnecessary costs to companies when preparing defined benefit plan disclosures. ASU 2018-14 is effective for annual periods in fiscal years ending after December 15, 2020. Retrospective adoption is required and early adoption is permitted. The Company does not expect the adoption of ASU 2018-14 will have a material impact on its consolidated financial statements and plans to adopt the standard effective April 1, 2020.


## us-gaap:EarningsPerShareTextBlock

[0001032975-19-000075:notes:24]
[same as prior period, unchanged from 0001032975-19-000059:notes:23]

[0001032975-19-000075:notes:25]
The following table summarizes the computations of basic and diluted net income per share for the three and six months ended September 30, 2019 and September 30, 2018 (in thousands, except per share amounts):

[0001032975-19-000075:notes:26]
|  |  | Three Months EndedSeptember 30, | Six Months EndedSeptember 30, |
|  |  | 2019 |  | 2018 | 2019 |  | 2018 |
| Net income |  | $ | 72,933 |  |  | $ | 64,176 |  | $ | 118,278 |  |  | $ | 102,642 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 166,662 |  |  | 165,630 |  | 166,484 |  |  | 165,474 |  |
| Effect of potentially dilutive equivalent shares |  | 2,365 |  |  | 3,604 |  | 2,430 |  |  | 3,522 |  |
| Weighted average shares outstanding - diluted |  | 169,027 |  |  | 169,234 |  | 168,914 |  |  | 168,996 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.44 |  |  | $ | 0.39 |  | $ | 0.71 |  |  | $ | 0.62 |  |
| Diluted |  | $ | 0.43 |  |  | $ | 0.38 |  | $ | 0.70 |  |  | $ | 0.61 |  |

[0001032975-19-000075:notes:27]
Share equivalents attributable to outstanding stock options, restricted stock units ("RSUs") and employee share purchase rights (ESPP) totaling 1.9 million and 0.8 million for the three months ended  September 30, 2019 and 2018, respectively, and 2.0 million  and 1.2 million for the six months ended September 30, 2019 and 2018, respectively, were excluded from the calculation of diluted net income per share because the combined exercise price and average unamortized grant date fair value upon exercise of these options and ESPP or vesting of RSUs were greater than the average market price of the Company's shares during the periods presented herein, and therefore their inclusion would have been anti-dilutive. Performance-based awards were not included because all necessary conditions have not been satisfied by the end of the respective period, and those shares were not issuable if the end of the reporting period was the end of the contingency period.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-19-000075:notes:28]
[same as prior period, unchanged from 0001032975-19-000059:notes:27]

[0001032975-19-000075:notes:29]
[same as prior period, unchanged from 0001032975-19-000059:notes:28]

[0001032975-19-000075:notes:30]
As of September 30, 2019, the Company offers the 2006 Employee Share Purchase Plan, as amended and restated (Non-U.S.) (2006 ESPP), the 1996 Employee Share Purchase Plan (U.S.), as amended and restated (1996 ESPP), the 2006 Stock Incentive Plan, as amended and restated (2006 Plan), and the 2012 Stock Inducement Equity Plan (2012 Plan).

[0001032975-19-000075:notes:31]
The following table summarizes the share-based compensation expense and total income tax benefit recognized for share-based awards for the three and six months ended September 30, 2019 and 2018 (in thousands):

[0001032975-19-000075:notes:32]
|  |  | Three Months EndedSeptember 30, | Six Months EndedSeptember 30, |
|  |  | 2019 |  | 2018 | 2019 |  | 2018 |
| Cost of goods sold |  | $ | 1,184 |  |  | $ | 791 |  | $ | 2,342 |  |  | $ | 1,921 |  |
| Marketing and selling |  | 6,951 |  |  | 4,864 |  | 13,800 |  |  | 10,650 |  |
| Research and development |  | 2,248 |  |  | 1,935 |  | 4,402 |  |  | 3,484 |  |
| General and administrative |  | 3,869 |  |  | 4,459 |  | 5,926 |  |  | 9,253 |  |
| Total share-based compensation expense |  | 14,252 |  |  | 12,049 |  | 26,470 |  |  | 25,308 |  |
| Income tax benefit |  | (2,723 | ) |  | (2,650 | ) | (9,523 | ) |  | (12,179 | ) |
| Total share-based compensation expense, net of income tax benefit |  | $ | 11,529 |  |  | $ | 9,399 |  | $ | 16,947 |  |  | $ | 13,129 |  |

[0001032975-19-000075:notes:33]
[same as prior period, unchanged from 0001032975-19-000059:notes:32]

[0001032975-19-000075:notes:34]
As of September 30, 2019 and 2018, the balance of capitalized share-based compensation included in inventory was $0.9 million and $0.8 million, respectively.

[0001032975-19-000075:notes:35]
[same as prior period, unchanged from 0001032975-19-000059:notes:34]

[0001032975-19-000075:notes:36]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The costs recorded of $2.4 million and $2.2 million for the three months ended September 30, 2019 and 2018, respectively, and $4.8 million and $4.5 million for the six months ended September 30, 2019 and 2018, respectively, were primarily related to service costs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-19-000075:notes:37]
[same as prior period, unchanged from 0001032975-19-000059:notes:36]

[0001032975-19-000075:notes:38]
[same as prior period, unchanged from 0001032975-19-000059:notes:37]

[0001032975-19-000075:notes:39]
The income tax benefit for the three months ended September 30, 2019 was $2.6 million based on an effective income tax rate of (3.7)% of pre-tax income, compared to an income tax provision of $6.2 million based on an effective income tax rate of 8.8% of pre-tax income for the three months ended September 30, 2018. The

[0001032975-19-000075:notes:40]
income tax provision for the six months ended September 30, 2019 was $3.9 million based on an effective income

[0001032975-19-000075:notes:41]
tax rate of 3.2% of pre-tax income, compared to an income tax provision of $1.0 million based on an effective income tax rate of 1.0% of pre-tax income for the six months ended September 30, 2018.

[0001032975-19-000075:notes:42]
On May 19, 2019, the Swiss electorate approved the Federal Act on Tax Reform and AHV Financing ("TRAF"), a major reform to better align the Swiss tax system with international tax standards. The legislation was subsequently published in the federal register on August 6, 2019 to take effect on January 1, 2020. As of September 30, 2019, TRAF has not been enacted in all cantons, including the canton of Vaud, as the cantonal legislative procedures are in process.

[0001032975-19-000075:notes:43]
The change in the effective income tax rate for the three months ended September 30, 2019, compared to the same period ended September 30, 2018, was primarily due to the transitional income tax impact in Switzerland.  The Company has benefited from a longstanding tax ruling from the canton of Vaud through March 31, 2019.  During the second quarter, the canton of Vaud concluded the longstanding cantonal tax ruling will only continue to apply through December 31, 2019. The transitional income tax impact, which represents income tax provision at the current full statutory income tax rate of 13.63% without taking account of the tax reform yet to be enacted, resulted

[0001032975-19-000075:notes:44]
in a tax benefit of $5.9 million in the three-month period ended September 30, 2019. In addition, there was a discrete tax benefit of $4.0 million from adjusting deferred tax assets and liabilities in Switzerland in the three months ended September 30, 2019.

[0001032975-19-000075:notes:45]
The change in the effective income tax rate for the six months ended September 30, 2019, compared to the same period ended September 30, 2018 was primarily due to the mix of income and losses in the various tax jurisdictions in which the Company operates and the transitional income tax impact in Switzerland discussed above. In the six months ended September 30, 2019, there was a discrete tax benefit of $1.7 million from adjusting deferred tax assets and liabilities in Switzerland. Furthermore, there were discrete tax benefits of $6.7 million and $1.8 million from the recognition of excess tax benefits in the United States and reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the six-month period ended September 30, 2019, compared with $9.0 million and $1.4 million, respectively, in the six-month period ended September 30, 2018.

[0001032975-19-000075:notes:46]
As of September 30, 2019 and March 31, 2019, the total amount of unrecognized tax benefits due to uncertain tax positions was $78.9 million and $76.5 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-19-000075:notes:47]
As of September 30, 2019 and March 31, 2019, the Company had $36.4 million in non-current income taxes payable including interest and penalties, related to the Company's income tax liability for uncertain tax positions.

[0001032975-19-000075:notes:48]
The Company recognizes interest and penalties related to unrecognized tax positions in income tax provision. As of September 30, 2019 and March 31, 2019, the Company had $2.8 million and $2.5 million, respectively, of accrued interest and penalties related to uncertain tax positions.

[0001032975-19-000075:notes:49]
Although the Company has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During fiscal year 2020, the Company continues to review its tax positions and provide for or reverse unrecognized tax benefits as they arise. During the next twelve months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. dollar as compared to other currencies. Excluding these factors, uncertain tax positions may decrease by as much as $3.7 million from the lapse of the statutes of limitations in various jurisdictions during the next twelve months.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-19-000075:notes:50]
[same as prior period, unchanged from 0001032975-19-000059:notes:46]

[0001032975-19-000075:notes:51]
The following table presents the components of certain balance sheet asset amounts as of September 30 and March 31, 2019 (in thousands):

[0001032975-19-000075:notes:52]
|  |  | September 30, 2019 |  | March 31, 2019 |
| Accounts receivable, net: |  |  |  |  |  |  |
| Accounts receivable |  | $ | 656,854 |  |  | $ | 573,348 |  |
| Allowance for doubtful accounts |  | (1,391 | ) |  | (84 | ) |
| Allowance for sales returns |  | (6,525 | ) |  | (6,486 | ) |
| Allowance for cooperative marketing arrangements |  | (37,109 | ) |  | (35,080 | ) |
| Allowance for customer incentive programs |  | (60,619 | ) |  | (60,036 | ) |
| Allowance for pricing programs |  | (85,241 | ) |  | (88,353 | ) |
|  |  | $ | 465,969 |  |  | $ | 383,309 |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 33,154 |  |  | $ | 40,970 |  |
| Finished goods |  | 305,160 |  |  | 252,525 |  |
|  |  | $ | 338,314 |  |  | $ | 293,495 |  |
| Other current assets: |  |  |  |  |  |  |
| Value-added tax receivables |  | $ | 36,146 |  |  | $ | 34,321 |  |
| Prepaid expenses and other assets |  | 43,484 |  |  | 34,795 |  |
|  |  | $ | 79,630 |  |  | $ | 69,116 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |
| Property, plant and equipment at cost |  | $ | 366,540 |  |  | $ | 359,345 |  |
| Accumulated depreciation and amortization |  | (290,972 | ) |  | (280,793 | ) |
|  |  | $ | 75,568 |  |  | $ | 78,552 |  |
| Other assets: |  |  |  |  |  |  |
| Deferred tax assets |  | $ | 98,019 |  |  | $ | 90,808 |  |
| Right-of-use assets (1) |  | 30,149 |  |  | — |  |
| Trading investments for deferred compensation plan |  | 22,862 |  |  | 20,363 |  |
| Investments in privately held companies |  | 16,674 |  |  | 16,022 |  |
| Other assets |  | 5,721 |  |  | 5,260 |  |
|  |  | $ | 173,425 |  |  | $ | 132,453 |  |

[0001032975-19-000075:notes:53]
[same as prior period, unchanged from 0001032975-19-000059:notes:49]

[0001032975-19-000075:notes:54]
The following table presents the components of certain balance sheet liability amounts as of September 30 and March 31, 2019 (in thousands):

[0001032975-19-000075:notes:55]
|  |  | September 30, 2019 |  | March 31, 2019 |
| Accrued and other current liabilities: |  |  |  |  |  |  |
| Accrued personnel expenses |  | $ | 74,219 |  |  | $ | 103,166 |  |
| Accrued sales return liability |  | 36,402 |  |  | 37,749 |  |
| Accrued customer marketing, pricing and incentive programs |  | 152,163 |  |  | 143,888 |  |
| Lease liability (1) |  | 11,887 |  |  | — |  |
| Warranty accrual |  | 23,531 |  |  | 21,524 |  |
| Income taxes payable |  | 5,602 |  |  | 6,207 |  |
| Other current liabilities |  | 121,159 |  |  | 121,363 |  |
|  |  | $ | 424,963 |  |  | $ | 433,897 |  |
| Other non-current liabilities: |  |  |  |  |  |  |
| Warranty accrual |  | $ | 13,691 |  |  | $ | 12,705 |  |
| Obligation for deferred compensation plan |  | 22,862 |  |  | 20,363 |  |
| Employee benefit plan obligation |  | 51,065 |  |  | 51,448 |  |
| Lease liability (1) |  | 24,050 |  |  | — |  |
| Deferred tax liability |  | 2,050 |  |  | 2,050 |  |
| Other non-current liabilities |  | 2,685 |  |  | 7,016 |  |
|  |  | $ | 116,403 |  |  | $ | 93,582 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-19-000075:notes:56]
[same as prior period, unchanged from 0001032975-19-000059:notes:52]

[0001032975-19-000075:notes:57]
[same as prior period, unchanged from 0001032975-19-000059:notes:53]

[0001032975-19-000075:notes:58]
[same as prior period, unchanged from 0001032975-19-000059:notes:54]

[0001032975-19-000075:notes:59]
[same as prior period, unchanged from 0001032975-19-000059:notes:55]

[0001032975-19-000075:notes:60]
[same as prior period, unchanged from 0001032975-19-000059:notes:56]

[0001032975-19-000075:notes:61]
[same as prior period, unchanged from 0001032975-19-000059:notes:57]

[0001032975-19-000075:notes:62]
|  |  | September 30, 2019 |  | March 31, 2019 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 304,783 |  |  | $ | — |  |  | $ | — |  |  | $ | 496,434 |  |  | $ | — |  |  | $ | — |  |
| Trading investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 4,563 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,080 |  |  | $ | — |  |  | $ | — |  |
| Mutual funds |  | 18,299 |  |  | — |  |  | — |  |  | 16,283 |  |  | — |  |  | — |  |
| Total of trading investments for deferred compensation plan |  | $ | 22,862 |  |  | $ | — |  |  | $ | — |  |  | $ | 20,363 |  |  | $ | — |  |  | $ | — |  |
| Currency exchange derivative assetsincluded in other current assets |  | $ | — |  |  | $ | 1,233 |  |  | $ | — |  |  | $ | — |  |  | $ | 455 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Currency exchange derivative liabilitiesincluded in accrued and other current liabilities |  | $ | — |  |  | $ | 43 |  |  | $ | — |  |  | $ | — |  |  | $ | 36 |  |  | $ | — |  |

[0001032975-19-000075:notes:63]
[same as prior period, unchanged from 0001032975-19-000059:notes:59]

[0001032975-19-000075:notes:64]
The marketable securities for the Company's deferred compensation plan were recorded at a fair value of $22.9 million and $20.4 million as of September 30, 2019 and March 31, 2019, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized gains (losses) related to trading securities for the three and six months ended September 30, 2019 and 2018 were not material and are included in other income (expense), net in the Company's condensed consolidated statements of operations.

[0001032975-19-000075:notes:65]
[same as prior period, unchanged from 0001032975-19-000059:notes:61]

[0001032975-19-000075:notes:66]
The Company has certain non-marketable investments included in other assets that are accounted for under the equity method of accounting, with a carrying value of $7.2 million and $6.6 million as of September 30, 2019 and March 31, 2019, respectively.

[0001032975-19-000075:notes:67]
[same as prior period, unchanged from 0001032975-19-000059:notes:63]

[0001032975-19-000075:notes:68]
Financial Assets.  The Company has certain investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with a same or similar security from the same issuer. The amount of these investments included in other assets as of September 30, 2019 and March 31, 2019 was $9.5 million. There was no impairment of these assets during the three and six months ended September 30, 2019 or 2018.

[0001032975-19-000075:notes:69]
Non-Financial Assets. The Company’s non-financial assets, such as intangible assets and acquisition-related property, plant and equipment, are recorded at fair value only upon initial recognition or if an impairment is recognized. There was no impairment of these assets during the three and six months ended September 30, 2019 or 2018.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-19-000075:notes:70]
[same as prior period, unchanged from 0001032975-19-000059:notes:66]

[0001032975-19-000075:notes:71]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis on the condensed consolidated balance sheets as of September 30, 2019 and March 31, 2019.

[0001032975-19-000075:notes:72]
The fair value of the Company’s derivative instruments was not material as of September 30, 2019 or March 31, 2019. The amount of gain (loss) recognized on derivatives not designated as hedging instruments was not material in all periods presented herein. The following table presents the amounts of gains (losses) on the Company’s derivative instruments designated as hedging instruments and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income for the three and six months ended September 30, 2019 and 2018 (in thousands):

[0001032975-19-000075:notes:73]
|  |  | Three Months EndedSeptember 30, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Cash flow hedges |  | $ | 2,380 |  |  | $ | 298 |  |  | $ | (132 | ) |  | $ | 218 |  |

[0001032975-19-000075:notes:74]
|  |  | Six Months EndedSeptember 30, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Cash flow hedges |  | $ | 1,437 |  |  | $ | 485 |  |  | $ | (358 | ) |  | $ | 3,069 |  |

[0001032975-19-000075:notes:75]
[same as prior period, unchanged from 0001032975-19-000059:notes:71]

[0001032975-19-000075:notes:76]
The Company enters into cash flow hedge contracts to protect against exchange rate exposure of forecasted inventory purchases. These hedging contracts mature within four months. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Cash flows from such hedges are classified as operating activities in the condensed consolidated statements of cash flows. Hedging relationships are discontinued when hedging contract is no longer eligible for hedge accounting, or is sold, terminated or exercised, or when Company removes hedge designation for the contract. Gains and losses in the fair value of the effective portion of the discontinued hedges continue to be reported in accumulated other comprehensive loss until the hedged inventory purchases are sold, unless it is probable that the forecasted inventory purchases will not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. In all periods presented herein, there have been no forecasted inventory purchases that were probable to not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. The notional amounts of foreign currency exchange forward contracts outstanding related to forecasted inventory purchases were $89.1 million as of September 30, 2019 and $41.4 million as of March 31, 2019. The Company had $1.5 million of net gains related to its cash flow hedges included in accumulated other comprehensive loss as of September 30, 2019 which will be reclassified into earnings within the next 12 months.

[0001032975-19-000075:notes:77]
[same as prior period, unchanged from 0001032975-19-000059:notes:73]

[0001032975-19-000075:notes:78]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are recognized in other income (expense), net in the condensed consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of September 30, 2019

[0001032975-19-000075:notes:79]
and March 31, 2019 were $61.7 million and $50.4 million, respectively. Open forward and swap contracts outstanding as of September 30, 2019 and March 31, 2019 consisted of contracts in Mexican Pesos, Japanese Yen, Canadian Dollars, Taiwan New Dollars and Australian Dollars to be settled at future dates at pre-determined exchange rates.

[0001032975-19-000075:notes:80]
[same as prior period, unchanged from 0001032975-19-000059:notes:75]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-19-000075:notes:81]
[same as prior period, unchanged from 0001032975-19-000059:notes:76]

[0001032975-19-000075:notes:82]
The Company conducts its impairment analysis of goodwill annually at December 31 and as necessary, if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting unit may be less than its carrying amount. There have been no events or circumstances during the six months ended September 30, 2019 that have required the Company to perform an interim assessment of goodwill.

[0001032975-19-000075:notes:83]
The following table summarizes the activities in the Company’s goodwill balance during the six months ended September 30, 2019 (in thousands):

[0001032975-19-000075:notes:84]
| As of March 31, 2019 |  | $ | 343,684 |  |
| Currency translation |  | 2 |  |
| As of September 30, 2019 |  | $ | 343,686 |  |

[0001032975-19-000075:notes:85]
[same as prior period, unchanged from 0001032975-19-000059:notes:80]

[0001032975-19-000075:notes:86]
|  |  | September 30, 2019 |  | March 31, 2019 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademark and trade names |  | $ | 36,370 |  |  | $ | (16,120 | ) |  | $ | 20,250 |  |  | $ | 36,370 |  |  | $ | (13,659 | ) |  | $ | 22,711 |  |
| Developed technology |  | 95,207 |  |  | (68,883 | ) |  | 26,324 |  |  | 95,207 |  |  | (62,341 | ) |  | 32,866 |  |
| Customer contracts/relationships |  | 84,610 |  |  | (25,920 | ) |  | 58,690 |  |  | 84,610 |  |  | (21,188 | ) |  | 63,422 |  |
| Total |  | $ | 216,187 |  |  | $ | (110,923 | ) |  | $ | 105,264 |  |  | $ | 216,187 |  |  | $ | (97,188 | ) |  | $ | 118,999 |  |


## us-gaap:DebtDisclosureTextBlock

[0001032975-19-000075:notes:87]
Financing Arrangements

[0001032975-19-000075:notes:88]
The Company had several uncommitted, unsecured bank lines of credit aggregating $77.5 million as of September 30, 2019. There are no financial covenants under these lines of credit with which the Company must comply. As of September 30, 2019, the Company had outstanding bank guarantees of $20.6 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of September 30, 2019 or March 31, 2019.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-19-000075:notes:89]
Commitments and Contingencies

[0001032975-19-000075:notes:90]
Product Warranties

[0001032975-19-000075:notes:91]
Changes in the Company’s warranty liability for the three and six months ended September 30, 2019 and 2018 were as follows (in thousands):

[0001032975-19-000075:notes:92]
|  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Beginning of the period | $ | 35,814 |  |  | $ | 28,853 |  |  | $ | 34,229 |  |  | $ | 27,573 |  |
| Assumed from business acquisition | — |  |  | 351 |  |  | — |  |  | 351 |  |
| Provision | 8,509 |  |  | 11,020 |  |  | 17,044 |  |  | 19,320 |  |
| Settlements | (6,727 | ) |  | (8,330 | ) |  | (13,704 | ) |  | (14,882 | ) |
| Currency translation | (374 | ) |  | (140 | ) |  | (347 | ) |  | (608 | ) |
| End of the period | $ | 37,222 |  |  | $ | 31,754 |  |  | $ | 37,222 |  |  | $ | 31,754 |  |

[0001032975-19-000075:notes:93]
Indemnifications

[0001032975-19-000075:notes:94]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2019, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-19-000075:notes:95]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-19-000075:notes:96]
Legal Proceedings

[0001032975-19-000075:notes:97]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.

[0001032975-19-000075:notes:98]
Pending Acquisition

[0001032975-19-000075:notes:99]
On September 26, 2019, the Company entered into an agreement to acquire all equity interests of General Workings, Inc. ("Streamlabs") for a total consideration of $89 million in cash, subject to a working capital adjustment, plus an additional earn-out of up to $29 million in stock based on the achievement of certain net revenues for the period beginning on January 1, 2020 and ending on June 30, 2020 (the "Streamlabs Acquisition"). Streamlabs is a leading provider of software and tools for professional streamers. The Streamlabs Acquisition will supplement the Company's portfolio opportunities.

[0001032975-19-000075:notes:100]
The transaction is subject to various closing conditions and is expected to close in late October 2019.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-19-000075:notes:101]
[same as prior period, unchanged from 0001032975-19-000059:notes:93]

[0001032975-19-000075:notes:102]
[same as prior period, unchanged from 0001032975-19-000059:notes:94]

[0001032975-19-000075:notes:103]
In March 2017, the Company's Board of Directors approved the 2017 share buyback program, which authorizes the Company to use up to $250.0 million to purchase up to 17.3 million shares of its own shares. The Company's share buyback program is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. As of September 30, 2019, $172.4 million is still available for repurchase under the 2017 buyback program.

[0001032975-19-000075:notes:104]
Dividends

[0001032975-19-000075:notes:105]
During the three and six months ended September 30, 2019, the Company declared and paid cash dividends of CHF 0.73 (USD equivalent of $0.74) per share, totaling $124.2 million on the Company's outstanding shares. During the three and six months ended September 30, 2018, the Company declared and paid cash dividends of CHF 0.67 (USD equivalent of $0.69) per share, totaling $114.0 million on the Company's outstanding shares.

[0001032975-19-000075:notes:106]
Any future dividends will be subject to approval of the Company's shareholders.

[0001032975-19-000075:notes:107]
[same as prior period, unchanged from 0001032975-19-000059:notes:96]

[0001032975-19-000075:notes:108]
[same as prior period, unchanged from 0001032975-19-000059:notes:97]

[0001032975-19-000075:notes:109]
|  |  | Accumulated Other Comprehensive Income (Loss) |
|  |  | CumulativeTranslationAdjustment (1) |  | DefinedBenefitPlan (1) |  | Deferred Hedging Losses (1) |  | Total |
| March 31, 2019 |  | $ | (92,148 | ) |  | $ | (13,932 | ) |  | $ | 382 |  |  | $ | (105,698 | ) |
| Other comprehensive income (loss) |  | (4,375 | ) |  | 64 |  |  | 1,079 |  |  | (3,232 | ) |
| September 30, 2019 |  | $ | (96,523 | ) |  | $ | (13,868 | ) |  | $ | 1,461 |  |  | $ | (108,930 | ) |

[0001032975-19-000075:notes:110]
(1)        Tax effect was not significant as of September 30 or March 31, 2019.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-19-000075:notes:111]
[same as prior period, unchanged from 0001032975-19-000059:notes:100]

[0001032975-19-000075:notes:112]
[same as prior period, unchanged from 0001032975-19-000059:notes:101]

[0001032975-19-000075:notes:113]
Sales by product categories and sales channels, excluding intercompany transactions, for the three and six months ended September 30, 2019 and 2018 were as follows (in thousands):

[0001032975-19-000075:notes:114]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Pointing Devices |  | $ | 132,770 |  |  | $ | 128,337 |  |  | $ | 254,753 |  |  | $ | 256,127 |  |
| Keyboards & Combos |  | 139,049 |  |  | 131,872 |  |  | 267,728 |  |  | 260,094 |  |
| PC Webcams |  | 28,748 |  |  | 28,221 |  |  | 56,876 |  |  | 57,895 |  |
| Tablet & Other Accessories |  | 33,847 |  |  | 36,710 |  |  | 72,186 |  |  | 69,146 |  |
| Video Collaboration |  | 89,553 |  |  | 57,176 |  |  | 162,977 |  |  | 115,968 |  |
| Mobile Speakers |  | 57,232 |  |  | 77,100 |  |  | 107,648 |  |  | 111,427 |  |
| Audio & Wearables |  | 68,018 |  |  | 61,560 |  |  | 126,642 |  |  | 113,714 |  |
| Gaming |  | 161,014 |  |  | 160,792 |  |  | 295,529 |  |  | 296,818 |  |
| Smart Home |  | 9,434 |  |  | 9,241 |  |  | 19,298 |  |  | 18,252 |  |
| Other (1) |  | 26 |  |  | 137 |  |  | 279 |  |  | 185 |  |
| Total sales |  | $ | 719,691 |  |  | $ | 691,146 |  |  | $ | 1,363,916 |  |  | $ | 1,299,626 |  |

[0001032975-19-000075:notes:115]
[same as prior period, unchanged from 0001032975-19-000059:notes:104]

[0001032975-19-000075:notes:116]
Sales by geographic region (based on the customers’ locations) for the three and six months ended September 30, 2019 and 2018 were as follows (in thousands):

[0001032975-19-000075:notes:117]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Americas |  | $ | 296,837 |  |  | $ | 283,714 |  |  | $ | 590,282 |  |  | $ | 560,642 |  |
| EMEA |  | 231,981 |  |  | 218,300 |  |  | 411,087 |  |  | 378,932 |  |
| Asia Pacific |  | 190,873 |  |  | 189,132 |  |  | 362,547 |  |  | 360,052 |  |
| Total sales |  | $ | 719,691 |  |  | $ | 691,146 |  |  | $ | 1,363,916 |  |  | $ | 1,299,626 |  |

[0001032975-19-000075:notes:118]
[same as prior period, unchanged from 0001032975-19-000059:notes:107]

[0001032975-19-000075:notes:119]
[same as prior period, unchanged from 0001032975-19-000059:notes:108]

[0001032975-19-000075:notes:120]
Switzerland, the Company’s home domicile, represented 4% and 3% of the Company's total consolidated sales for the three and six months ended September 30, 2019, respectively, and represented 4% and 3% of the Company's total consolidated sales for the three and six months ended September 30, 2018, respectively.

[0001032975-19-000075:notes:121]
[same as prior period, unchanged from 0001032975-19-000059:notes:110]

[0001032975-19-000075:notes:122]
[same as prior period, unchanged from 0001032975-19-000059:notes:111]

[0001032975-19-000075:notes:123]
|  |  | September 30, 2019 |  | March 31, 2019 |
| Americas |  | $ | 27,213 |  |  | $ | 29,813 |  |
| EMEA |  | 4,545 |  |  | 4,537 |  |
| Asia Pacific |  | 43,810 |  |  | 44,202 |  |
| Total property, plant and equipment, net |  | $ | 75,568 |  |  | $ | 78,552 |  |

[0001032975-19-000075:notes:124]
Property, plant and equipment, net in the United States and China were $27.1 million and $36.0 million, respectively, as of September 30, 2019, and $29.8 million and $36.4 million, respectively, as of March 31, 2019. No other countries represented 10% or more of the Company’s total consolidated property, plant and equipment, net as of September 30, 2019 or March 31, 2019. Property, plant and equipment, net in Switzerland, the Company’s home domicile, were $1.8 million and $1.7 million as of September 30, 2019 and March 31, 2019, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001032975-19-000075:notes:125]
[same as prior period, unchanged from 0001032975-19-000059:notes:115]

[0001032975-19-000075:notes:126]
During the first quarter of fiscal year 2019, the Company implemented a restructuring plan to streamline and realign the Company's overall organizational structure and reallocate resources to support long-term growth opportunities. In July 2018, the Company's Board of Directors approved additional costs under this restructuring plan, totaling pre-tax charges of approximately $10.0 million to $15.0 million, of which $11.4 million has been recognized cumulatively as of September 30, 2019. The total charges consisted of cash severance and other personnel costs and are presented as restructuring charges (credit), net in the condensed consolidated statements of operations, and the accrual balances are presented in accrued and other current liabilities in the condensed consolidated balance sheets. During the first quarter of fiscal year 2020, the Company had substantially completed this restructuring plan.

[0001032975-19-000075:notes:127]
The following table summarizes restructuring-related activities during the three and six months ended September 30, 2019 (in thousands):

[0001032975-19-000075:notes:128]
|  |  | TerminationBenefits |
| Accrual balance at March 31, 2019 |  | $ | 4,389 |  |
| Charges |  | 478 |  |
| Cash payments |  | (1,956 | ) |
| Accrual balance at June 30, 2019 |  | 2,911 |  |
| Credits |  | (364 | ) |
| Cash payments |  | (1,140 | ) |
| Accrual balance at September 30, 2019 |  | $ | 1,407 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001032975-19-000075:notes:129]
[same as prior period, unchanged from 0001032975-19-000059:notes:119]

[0001032975-19-000075:notes:130]
[same as prior period, unchanged from 0001032975-19-000059:notes:120]

[0001032975-19-000075:notes:131]
[same as prior period, unchanged from 0001032975-19-000059:notes:121]

[0001032975-19-000075:notes:132]
The Company's lease arrangements comprise of operating leases with various expiration dates through June 30, 2031. The lease term for all of the Company’s leases includes the noncancellable period of the lease. Certain lease agreements include options to renew or terminate the lease, which are not reasonably certain to be exercised and therefore are not factored into our determination of the duration of the lease arrangement.

[0001032975-19-000075:notes:133]
[same as prior period, unchanged from 0001032975-19-000059:notes:123]

[0001032975-19-000075:notes:134]
For the three and six months ended September 30, 2019, the total operating lease costs were $3.6 million and $6.9 million, respectively, which included short-term lease costs and sublease income. Total variable lease costs were immaterial during the three and six months ended September 30, 2019. The total operating and variable lease costs were included in cost of goods sold, marketing and selling, research and development, and general and administrative in the Company's unaudited condensed consolidated statement of operations.

[0001032975-19-000075:notes:135]
As of September 30, 2019, the weighted-average remaining lease term was 4 years, and the weighted-average discount rate was 2.8%.

[0001032975-19-000075:notes:136]
For the three and six months ended September 30, 2019, cash paid for amounts included in the measurement of operating lease liabilities was $3.3 million and $6.4 million, respectively, and right-of-use assets obtained in exchange for new operating lease liabilities was $1.5 million and $4.9 million, respectively.

[0001032975-19-000075:notes:137]
Future lease payments included in the measurement of lease liabilities as of September 30, 2019 for the following five fiscal years and thereafter are as follows (in thousands):

[0001032975-19-000075:notes:138]
|  | Operating Lease |
| Remaining 2020 | $ | 6,900 |  |
| 2021 | 11,204 |  |
| 2022 | 9,185 |  |
| 2023 | 5,600 |  |
| 2024 | 1,358 |  |
| Thereafter | 4,102 |  |
| Total lease payments | 38,349 |  |
| Less interest | (2,412 | ) |
| Present value of lease liabilities | $ | 35,937 |  |

[0001032975-19-000075:notes:139]
[same as prior period, unchanged from 0001032975-19-000059:notes:130]

[0001032975-19-000075:notes:140]
[same as prior period, unchanged from 0001032975-19-000059:notes:131]
