# LOGI note change history — 0001032975-16-000106 → 0001032975-17-000005


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-02-06):
[0001032975-17-000005:note_history:1]
Changes in the Company’s warranty liability for the three and nine months ended December 31, 2016 and 2015 were as follows (in thousands):
  (was, 2016-10-27, similarity 0.9615):
[0001032975-16-000106:note_history:1]
Changes in the Company’s warranty liability for the three and six months ended September 30, 2016 and 2015 were as follows (in thousands):

- changed (2017-02-06):
[0001032975-17-000005:note_history:2]
|  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Beginning of the period | $ | 21,612 |  |  | $ | 20,399 |  |  | $ | 20,380 |  |  | $ | 21,710 |  |
| Assumed from business acquisition |  |  |  | — |  |  | 1,963 |  |  | — |  |
| Provision | 4,521 |  |  | 2,023 |  |  | 10,861 |  |  | 5,815 |  |
| Settlements | (3,550 | ) |  | (2,763 | ) |  | (10,430 | ) |  | (8,008 | ) |
| Currency impact | (462 | ) |  | (153 | ) |  | (653 | ) |  | (11 | ) |
| End of the period | $ | 22,121 |  |  | $ | 19,506 |  |  | $ | 22,121 |  |  | $ | 19,506 |  |
  (was, 2016-10-27, similarity 0.9656):
[0001032975-16-000106:note_history:2]
|  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Beginning of the period | $ | 21,752 |  |  | $ | 21,284 |  |  | $ | 20,380 |  |  | $ | 21,710 |  |
| Assumed from business acquisition | 150 |  |  | — |  |  | 1,963 |  |  | — |  |
| Provision | 3,163 |  |  | 1,879 |  |  | 6,340 |  |  | 3,792 |  |
| Settlements | (3,452 | ) |  | (2,677 | ) |  | (6,880 | ) |  | (5,245 | ) |
| Currency impact | (1 | ) |  | (87 | ) |  | (191 | ) |  | 142 |  |
| End of the period | $ | 21,612 |  |  | $ | 20,399 |  |  | $ | 21,612 |  |  | $ | 20,399 |  |

- changed (2017-02-06):
[0001032975-17-000005:note_history:3]
Logitech Europe S.A. guaranteed payments of certain third-party contract manufacturers’ purchase obligations. As of December 31, 2016, the maximum amount of this guarantee was $3.8 million, of which $1.7 million of guaranteed purchase obligations were outstanding.
  (was, 2016-10-27, similarity 0.9862):
[0001032975-16-000106:note_history:3]
Logitech Europe S.A. guaranteed payments of certain third-party contract manufacturers’ purchase obligations. As of September 30, 2016, the maximum amount of this guarantee was $3.8 million, of which $1.9 million of guaranteed purchase obligations were outstanding.

- changed (2017-02-06):
[0001032975-17-000005:note_history:4]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2016, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2016-10-27, similarity 0.9946):
[0001032975-16-000106:note_history:4]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2016, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

- changed (2017-02-06):
[0001032975-17-000005:note_history:5]
The stock purchase agreement entered on December 28, 2015 in connection with the investment by three venture capital firms in Lifesize, Inc. contains representations, warranties and covenants of Logitech and Lifesize, Inc. to the Investors. Logitech has agreed, subject to certain limitations, to indemnify the Investors and certain persons related to the Investors for certain losses resulting from breaches of or inaccuracies in such representations, warranties and covenants as well as certain other obligations, including third-party expenses, restructuring costs and pre-closing tax obligations of Lifesize.
  (was, 2016-10-27, similarity 0.9798):
[0001032975-16-000106:note_history:5]
The Stock Purchase Agreement in connection with the investment by three venture capital firms in Lifesize, Inc. contains representations, warranties and covenants of Logitech and Lifesize, Inc. to the Investors. Logitech has agreed, subject to certain limitations, to indemnify the Investors and certain persons related to the Investors for certain losses resulting from breaches of or inaccuracies in such representations, warranties and covenants as well as certain other obligations, including third-party expenses, restructuring costs and pre-closing tax obligations of Lifesize.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-02-06):
[0001032975-17-000005:note_history:6]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and nine months ended December 31, 2016 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2017, or any future periods.
  (was, 2016-10-27, similarity 0.9623):
[0001032975-16-000106:note_history:6]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and six months ended September 30, 2016 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2017, or any future periods.

- changed (2017-02-06):
[0001032975-17-000005:note_history:7]
Certain amounts from the comparative period in the accompanying unaudited condensed consolidated financial statements have been reclassified to conform to the condensed consolidated financial statement presentation as of and for the three and nine months ended December 31, 2016.
  (was, 2016-10-27, similarity 0.9231):
[0001032975-16-000106:note_history:7]
Certain amounts from the comparative period in the accompanying unaudited condensed consolidated financial statements have been reclassified to conform to the condensed consolidated financial statement presentation as of and for the three and six months ended September 30, 2016.

- changed (2017-02-06):
[0001032975-17-000005:note_history:8]
There have been no substantial changes in the Company’s significant accounting policies during the nine months ended December 31, 2016 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2016.
  (was, 2016-10-27, similarity 0.9186):
[0001032975-16-000106:note_history:8]
There have been no substantial changes in the Company’s significant accounting policies during the six months ended September 30, 2016 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2016.

- changed (2017-02-06):
[0001032975-17-000005:note_history:9]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers (Topic 606)" ("ASU 2014-09"). ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. Under the new model, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In addition, the new standard requires that reporting companies disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. ASU 2014-09 was originally to be effective for the Company on April 1, 2017. In July 2015, the FASB affirmed a one-year deferral of the effective date of the new revenue standard. The new standard will become effective for the Company on April 1, 2018. Early application is permitted but not before the original effective date of annual periods beginning after December 15, 2016. The new standard is required to be applied retrospectively to each prior reporting period presented or retrospectively with the cumulative effect of initially applying it recognized at the date of initial application. Subsequently, the FASB has issued the following standards related to ASU 2014-09: ASU No. 2016-08, "Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations" (“ASU 2016-08”); ASU No. 2016-10, "Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing" (“ASU 2016-10”); and ASU No. 2016-12, "Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients" (“ASU 2016-12”). The Company must adopt ASU 2016-08, ASU 2016-10 and ASU 2016-12 with ASU 2014-09 (collectively, the “new revenue standards”). The Company has not yet selected a transition method and is in process of assessing all potential impacts of the new standard.  The new revenue standard will be adopted effective April 1, 2018.
  (was, 2016-10-27, similarity 0.7486):
[0001032975-16-000106:note_history:9]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-9, "Revenue from Contracts with Customers (Topic 606)" ("ASU 2014-9"). ASU 2014-9 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. Under the new model, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In addition, the new standard requires that reporting companies disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. ASU 2014-09 was originally to be effective for the Company on April 1, 2017. In July 2015, the FASB affirmed a one-year deferral of the effective date of the new revenue standard. The new standard will become effective for the Company on April 1, 2018. Early application is permitted but not before the original effective date of annual periods beginning after December 15, 2016. The new standard is required to be applied retrospectively to each prior reporting period presented or retrospectively with the cumulative effect of initially applying it recognized at the date of initial application. The Company has not yet selected a transition method nor has it determined whether it will early adopt this guidance or the impact of the new standard on its condensed consolidated financial statements.

- changed (2017-02-06):
[0001032975-17-000005:note_history:10]
In March 2016, the FASB issued ASU 2016-09 "Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting" ("ASU 2016-09"). The amendment simplifies several aspects of the accounting for share-based payments, including immediate recognition of all excess tax benefits and deficiencies in the income statement, changing the threshold to qualify for equity classification up to the employees' maximum statutory tax rates, allowing an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures as they occur, and clarifying the classification on the statement of cash flows for the excess tax benefit and employee taxes paid when an employer withholds shares for tax-withholding purposes. ASU 2016-09 is effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. Early adoption is permitted in any interim or annual period. The Company will adopt this standard effective April 1, 2017 and is in the process of evaluating the effect that ASU 2016-09 will have on its condensed consolidated financial statements.
  (was, 2016-10-27, similarity 0.9474):
[0001032975-16-000106:note_history:10]
In March 2016, the FASB issued ASU 2016-09 "Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting" ("ASU 2016-09"). The amendment simplifies several aspects of the accounting for share-based payments, including immediate recognition of all excess tax benefits and deficiencies in the income statement, changing the threshold to qualify for equity classification up to the employees' maximum statutory tax rates, allowing an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures as they occur, and clarifying the classification on the statement of cash flows for the excess tax benefit and employee taxes paid when an employer withholds shares for tax-withholding purposes. ASU 2016-09 is effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. Early adoption is permitted in any interim or annual period. The Company is evaluating the effect that ASU 2016-09 will have on its condensed consolidated financial statements and the timing of the adoption of this standard.

- changed (2017-02-06):
[0001032975-17-000005:note_history:11]
In August 2016, the FASB issued ASU 2016-15 "Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments" ("ASU 2016-15"), which gives guidance and reduces diversity in practice with respect to certain types of cash flows. The Company has early adopted this guidance during the second quarter of fiscal year 2017 and the adoption did not impact its condensed consolidated financial statements.
  (was, 2016-10-27, similarity 0.7252):
[0001032975-16-000106:note_history:11]
In August 2016, the FASB issued ASU 2016-15 "Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments". The amendment gives guidance and reduces diversity in practice with respect to certain types of cash flows. The Company has early adopted this guidance during the second quarter of fiscal year 2017 and the adoption did not impact its consolidated financial statements.

- added (2017-02-06):
[0001032975-17-000005:note_history:12]
In October 2016, the FASB issued ASU 2016-16 "Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory"  ("ASU 2016-16"), which eliminates the deferral of income tax effects of intra-entity asset transfers until the transferred asset is sold to an unrelated party or recovered through use.  ASU 2016-16, however, does not apply to intra-entity transfer of inventory.  The guidance is effective for annual periods beginning after December 15, 2017 and interim reporting periods within those annual periods.  Early adoption is permitted but only in the first interim period of a fiscal year.  The cumulative effect of change on equity upon adoption is to be quantified under the modified retrospective approach and recorded as of the beginning of the period of adoption.  The Company is evaluating the full effect that ASU 2016-16 will have on its condensed consolidated financial statements and will adopt the standard effective April 1, 2018.

- added (2017-02-06):
[0001032975-17-000005:note_history:13]
In December 2016, the FASB issued ASU 2016-18 "Statement of Cash Flows (Topic 230): Restricted Cash" ("ASU 2016-18"), which requires that a statement of cash flows explains the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents.  The standard is effective for annual periods beginning after December 15, 2017 and interim reporting periods within those annual periods, with early adoption permitted. The adoption of this standard should be applied using a retrospective transition method to each period presented. The Company does not expect the adoption of ASU 2016-18 will have a material impact on its condensed consolidated financial statements and is evaluating the timing of adoption of this standard.

- added (2017-02-06):
[0001032975-17-000005:note_history:14]
In January 2017, the FASB issued ASU 2017-04, "Simplifying the Test for Goodwill Impairment (Topic 330)"("ASU 2017-04"),  which removes Step 2 from the goodwill impairment test. The standard will be effective for the Company for annual or any interim goodwill impairments in fiscal year beginning December 15, 2019, with early adoption permitted. The Company does not expect the adoption of ASU 2017-14 will have an impact on its condensed consolidated financial statements and is evaluating the timing of adoption of this standard.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-02-06):
[0001032975-17-000005:note_history:15]
The Company had several uncommitted, unsecured bank lines of credit aggregating $43.2 million as of December 31, 2016. There are no financial covenants under these lines of credit with which the Company must comply. As of December 31, 2016, the Company had outstanding bank guarantees of $18.3 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of December 31, 2016 or March 31, 2016.
  (was, 2016-10-27, similarity 0.9204):
[0001032975-16-000106:note_history:15]
The Company had several uncommitted, unsecured bank lines of credit aggregating $44.6 million as of September 30, 2016. There are no financial covenants under these lines of credit with which the Company must comply. As of September 30, 2016, the Company had outstanding bank guarantees of $12.4 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of September 30, 2016 or March 31, 2016.
