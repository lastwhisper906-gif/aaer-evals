# LOGI 8-K — 0001032975-17-000002 filed 2017-01-25

## item codes, every 8-K on or before 2017-02-06

- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2017-02-06

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-17-000002:8k_2_02:1]
EX-99.1
2
exhibit991q3fy17.htm
EXHIBIT 99.1

[0001032975-17-000002:8k_2_02:2]
Exhibit

[0001032975-17-000002:8k_2_02:3]
Exhibit 99.1

[0001032975-17-000002:8k_2_02:4]
Editorial Contacts:

[0001032975-17-000002:8k_2_02:5]
Ben Lu, Vice President, Investor Relations - USA (510) 713-5568

[0001032975-17-000002:8k_2_02:6]
Krista Todd, Vice President, External Communications - USA (510) 713-5834

[0001032975-17-000002:8k_2_02:7]
Ben Starkie, Corporate Communications - Europe +41 (0) 79-292-3499

[0001032975-17-000002:8k_2_02:8]
Logitech Reports Highest Retail Revenue in Company’s History

[0001032975-17-000002:8k_2_02:9]
Q3 Retail Revenue Up 12%; Company Raises Sales and Profit Outlook

[0001032975-17-000002:8k_2_02:10]
NEWARK, Calif. - January 24, 2017 and LAUSANNE, Switzerland, January 25, 2017 - Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced better-than-expected preliminary financial results for the third quarter of Fiscal Year 2017.

[0001032975-17-000002:8k_2_02:11]
| • | Q3 retail sales grew 13 percent in constant currency, reaching the highest level ever in the Company’s history. Q3 retail sales grew 12 percent in USD. |

[0001032975-17-000002:8k_2_02:12]
| • | Q3 sales were $667 million, up 7 percent compared to Q3 of the prior year, which still included OEM sales. |

[0001032975-17-000002:8k_2_02:13]
| • | Q3 GAAP operating income grew 41% to $96 million, compared to $69 million a year ago. Q3 GAAP earnings per share (EPS) were $0.59, compared to $0.41 a year ago. |

[0001032975-17-000002:8k_2_02:14]
| • | Q3 non-GAAP operating income grew 34% to $99 million, compared to $74 million a year ago. Q3 non-GAAP EPS grew 37% to $0.56, compared to $0.41 a year ago. |

[0001032975-17-000002:8k_2_02:15]
| • | Cash flow from operations for the first nine months of Fiscal Year 2017 was $234 million, compared to $151 million for same period a year ago. |

[0001032975-17-000002:8k_2_02:16]
“This Q3, our results exceeded expectations and were outstanding, with broad-based growth across all our regions and almost all product categories,” said Bracken Darrell, Logitech president and chief executive officer. “We delivered both the highest retail revenue and the highest non-GAAP gross margin in Logitech’s 35-year history. Our strategy is working, and we are just at the beginning of our path to deliver what we’re capable of. We have significantly raised our outlook on the back of this performance.”

[0001032975-17-000002:8k_2_02:17]
Outlook

[0001032975-17-000002:8k_2_02:18]
Logitech raised its Fiscal Year 2017 outlook to 12 to 13 percent retail sales growth in constant currency, up from its previous range of 8 to 10 percent retail sales growth in constant currency. The Company also increased its non-GAAP operating income outlook for Fiscal Year 2017 to a range of $225 to $230 million, up from its prior range of $195 million to $205 million.

[0001032975-17-000002:8k_2_02:19]
Preliminary Statement

[0001032975-17-000002:8k_2_02:20]
These preliminary results for the three and nine months ended December 31, 2016 are subject to adjustments, including completion of our evaluation of the changes in the fair value of contingent consideration for our acquisition of Jaybird LLC and other subsequent events that may occur through the date of filing our Quarterly Report on Form 10-Q.

[0001032975-17-000002:8k_2_02:21]
Prepared Remarks Available Online

[0001032975-17-000002:8k_2_02:22]
Logitech has made its prepared written remarks for the financial results teleconference available online on the Logitech corporate website at http://ir.logitech.com.

[0001032975-17-000002:8k_2_02:23]
Financial Results Teleconference and Webcast

[0001032975-17-000002:8k_2_02:24]
Logitech will hold a financial results teleconference to discuss the results for Q3 FY 2017 on Weds., January 25, 2017 at 8:30 a.m. Eastern Standard Time and 2:30 p.m. Central European Time. A live webcast of the call will be available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-17-000002:8k_2_02:25]
Continued Operations

[0001032975-17-000002:8k_2_02:26]
Logitech separated its Lifesize division from the Company on Dec. 28, 2015. Except as otherwise noted, all of the results reported in this press release as well as comparisons between periods are focused on results from continuing operations and do not address the performance of Lifesize, which is now reported in the Company’s financial statements under discontinued operations, or total Logitech including discontinued operations. For more information on the impact of the Lifesize separation on Logitech’s historical results, please refer to the Financial Reporting section of Logitech’s Financial History, available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-17-000002:8k_2_02:27]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-17-000002:8k_2_02:28]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of intangible assets, purchase accounting effect on inventory, acquisition-related costs, change in fair value of contingent consideration for business acquisition, restructuring charges (credits), gain (loss) on equity-method investment, investigation and related expenses, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below. Logitech also presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for Fiscal Year 2017.

[0001032975-17-000002:8k_2_02:29]
About Logitech

[0001032975-17-000002:8k_2_02:30]
Logitech designs products that have an everyday place in people's lives, connecting them to the digital experiences they care about. Over 30 years ago Logitech started connecting people through computers, and now it’s designing products that bring people together through music, gaming, video and computing. Founded in 1981, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @Logitech.

[0001032975-17-000002:8k_2_02:31]
# # #

[0001032975-17-000002:8k_2_02:32]
opportunities are more limited than we expect; if sales of PC peripherals are less than we expect; the effect of pricing, product, marketing and other initiatives by our competitors, and our reaction to them, on our sales, gross margins and profitability; if our products and marketing strategies fail to separate our products from competitors’ products; if we do not fully realize our goals to lower our costs and improve our operating leverage; if there is a deterioration of business and economic conditions in one or more of our sales regions or product categories, or significant fluctuations in exchange rates. A detailed discussion of these and other risks and uncertainties that could cause actual results and events to differ materially from such forward-looking statements is included in Logitech’s periodic filings with the Securities and Exchange Commission, including our Annual Report on Form 10-K for the fiscal year ended March 31, 2016 and our Quarterly Report on Form 10-Q for fiscal quarter ended September 30, 2016, available at www.sec.gov, under the caption Risk Factors and elsewhere. Logitech does not undertake any obligation to update any forward-looking statements to reflect new information or events or circumstances occurring after the date of this press release.

[0001032975-17-000002:8k_2_02:33]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-17-000002:8k_2_02:34]
2017 Logitech, Logicool, Logi and other Logitech marks are owned by Logitech and may be registered. All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-17-000002:8k_2_02:35]
(LOGIIR)

[0001032975-17-000002:8k_2_02:36]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (A) |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Net sales |  | $ | 666,707 |  |  | $ | 621,079 |  |  | $ | 1,710,875 |  |  | $ | 1,587,259 |  |
| Cost of goods sold |  | 418,015 |  |  | 412,582 |  |  | 1,083,908 |  |  | 1,048,312 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 1,929 |  |  | — |  |  | 4,705 |  |  | — |  |
| Gross profit |  | 246,763 |  |  | 208,497 |  |  | 622,262 |  |  | 538,947 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 102,036 |  |  | 87,295 |  |  | 279,700 |  |  | 241,924 |  |
| Research and development |  | 32,284 |  |  | 29,161 |  |  | 96,867 |  |  | 85,889 |  |
| General and administrative |  | 24,631 |  |  | 24,080 |  |  | 75,587 |  |  | 77,966 |  |
| Amortization of intangible assets and acquisition-related costs |  | 1,494 |  |  | 112 |  |  | 4,535 |  |  | 447 |  |
| Change in fair value of contingent consideration for business acquisition |  | (9,925 | ) |  | — |  |  | (9,925 | ) |  | — |  |
| Restructuring charges (credits), net |  | (33 | ) |  | (666 | ) |  | (44 | ) |  | 14,018 |  |
| Total operating expenses |  | 150,487 |  |  | 139,982 |  |  | 446,720 |  |  | 420,244 |  |
| Operating income |  | 96,276 |  |  | 68,515 |  |  | 175,542 |  |  | 118,703 |  |
| Interest income, net |  | 202 |  |  | 105 |  |  | 263 |  |  | 549 |  |
| Other income (expense), net |  | 2,634 |  |  | 862 |  |  | 943 |  |  | (894 | ) |
| Income before income taxes |  | 99,112 |  |  | 69,482 |  |  | 176,748 |  |  | 118,358 |  |
| Provision for income taxes |  | 1,647 |  |  | 1,442 |  |  | 10,297 |  |  | 7,006 |  |
| Net income from continuing operations |  | 97,465 |  |  | 68,040 |  |  | 166,451 |  |  | 111,352 |  |
| Loss from discontinued operations, net of taxes |  | — |  |  | (2,954 | ) |  | — |  |  | (20,732 | ) |
| Net income |  | $ | 97,465 |  |  | $ | 65,086 |  |  | $ | 166,451 |  |  | $ | 90,620 |  |
| Net income (loss) per share - basic: |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.60 |  |  | $ | 0.42 |  |  | $ | 1.03 |  |  | $ | 0.68 |  |
| Discontinued operations |  | — |  |  | (0.02 | ) |  | — |  |  | (0.13 | ) |
| Net income per share - basic |  | $ | 0.60 |  |  | $ | 0.40 |  |  | $ | 1.03 |  |  | $ | 0.55 |  |
| Net income (loss) per share - diluted: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.59 |  |  | $ | 0.41 |  |  | $ | 1.01 |  |  | $ | 0.67 |  |
| Discontinued operations |  | — |  |  | (0.02 | ) |  | — |  |  | (0.12 | ) |
| Net income per share - diluted |  | $ | 0.59 |  |  | $ | 0.39 |  |  | $ | 1.01 |  |  | $ | 0.55 |  |
| Weighted average shares used to compute net income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 161,977 |  |  | 162,669 |  |  | 162,070 |  |  | 163,521 |  |
| Diluted |  | 165,901 |  |  | 165,168 |  |  | 165,211 |  |  | 165,951 |  |
| Cash dividend per share |  | $ | — |  |  | $ | — |  |  | $ | 0.57 |  |  | $ | 0.53 |  |

[0001032975-17-000002:8k_2_02:37]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS |
| (In thousands) - unaudited |  |  |  |  |
|  |  | December 31, |  | March 31, |
| CONDENSED CONSOLIDATED BALANCE SHEETS (A) |  | 2016 |  | 2016 |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 513,578 |  |  | $ | 519,195 |  |
| Accounts receivable, net |  | 277,677 |  |  | 142,778 |  |
| Inventories |  | 250,286 |  |  | 228,786 |  |
| Other current assets |  | 43,339 |  |  | 35,488 |  |
| Total current assets |  | 1,084,880 |  |  | 926,247 |  |
| Non-current assets: |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 84,194 |  |  | 92,860 |  |
| Goodwill |  | 249,721 |  |  | 218,224 |  |
| Other intangible assets, net |  | 50,313 |  |  | — |  |
| Other assets |  | 85,728 |  |  | 86,816 |  |
| Total assets |  | $ | 1,554,836 |  |  | $ | 1,324,147 |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 358,196 |  |  | $ | 241,166 |  |
| Accrued and other current liabilities |  | 247,963 |  |  | 173,764 |  |
| Total current liabilities |  | 606,159 |  |  | 414,930 |  |
| Non-current liabilities: |  |  |  |  |  |  |
| Income taxes payable |  | 55,573 |  |  | 59,734 |  |
| Other non-current liabilities |  | 91,709 |  |  | 89,535 |  |
| Total liabilities |  | 753,441 |  |  | 564,199 |  |
| Shareholders’ equity: |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |
| Issued and authorized shares —173,106 at December 31 and March 31, 2016 |  |  |  |  |
| Conditionally authorized shares — 50,000 at December 31 and March 31, 2016 |  |  |  |  |
| Additional paid-in capital |  | 16,336 |  |  | 6,616 |  |
| Less shares in treasury, at cost — 11,298 at December 31, 2016 and 10,697 at March 31, 2016 |  | (167,342 | ) |  | (128,407 | ) |
| Retained earnings |  | 1,034,685 |  |  | 963,576 |  |
| Accumulated other comprehensive loss |  | (112,432 | ) |  | (111,985 | ) |
| Total shareholders’ equity |  | 801,395 |  |  | 759,948 |  |
| Total liabilities and shareholders’ equity |  | $ | 1,554,836 |  |  | $ | 1,324,147 |  |

[0001032975-17-000002:8k_2_02:38]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (A) |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 97,465 |  |  | $ | 65,086 |  |  | $ | 166,451 |  |  | $ | 90,620 |  |
| Non-cash items included in net income: |  |  |  |  |  |  |  |  |
| Depreciation |  | 8,863 |  |  | 14,647 |  |  | 32,479 |  |  | 36,884 |  |
| Amortization of intangible assets |  | 2,751 |  |  | 310 |  |  | 6,618 |  |  | 1,536 |  |
| Loss (gain) on equity-method investment |  | (375 | ) |  | (4 | ) |  | (547 | ) |  | 176 |  |
| Share-based compensation expense |  | 9,387 |  |  | 6,618 |  |  | 26,354 |  |  | 19,875 |  |
| Excess tax benefits from share-based compensation |  | (2,227 | ) |  | (926 | ) |  | (6,357 | ) |  | (2,089 | ) |
| Deferred income taxes |  | (88 | ) |  | 1,962 |  |  | (473 | ) |  | 2,914 |  |
| Change in fair value of contingent consideration for business acquisition |  | (9,925 | ) |  | — |  |  | (9,925 | ) |  | — |  |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | (42,413 | ) |  | (20,411 | ) |  | (139,414 | ) |  | (115,814 | ) |
| Inventories |  | 13,123 |  |  | 73,508 |  |  | (15,194 | ) |  | 18,066 |  |
| Other assets |  | (1,608 | ) |  | (818 | ) |  | (6,346 | ) |  | (9,329 | ) |
| Accounts payable |  | 25,419 |  |  | 18,402 |  |  | 109,095 |  |  | 68,763 |  |
| Accrued and other liabilities |  | 46,162 |  |  | 7,334 |  |  | 71,549 |  |  | 39,244 |  |
| Net cash provided by operating activities |  | 146,534 |  |  | 165,708 |  |  | 234,290 |  |  | 150,846 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (8,614 | ) |  | (19,166 | ) |  | (23,372 | ) |  | (50,443 | ) |
| Investment in privately held companies |  | (160 | ) |  | (1,619 | ) |  | (640 | ) |  | (2,099 | ) |
| Acquisitions, net of cash acquired |  | — |  |  | — |  |  | (66,987 | ) |  | — |  |
| Release of restricted cash |  | — |  |  | — |  |  | 715 |  |  | — |  |
| Purchases of trading investments |  | (597 | ) |  | (1,746 | ) |  | (5,868 | ) |  | (4,395 | ) |
| Proceeds from sales of trading investments |  | 616 |  |  | 1,813 |  |  | 5,912 |  |  | 4,668 |  |
| Net cash used in investing activities |  | (8,755 | ) |  | (20,718 | ) |  | (90,240 | ) |  | (52,269 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | — |  |  | — |  |  | (93,093 | ) |  | (85,915 | ) |
| Purchases of treasury shares |  | (20,870 | ) |  | — |  |  | (63,764 | ) |  | (48,802 | ) |
| Proceeds from sales of shares upon exercise of options and purchase rights |  | 5,871 |  |  | 1,459 |  |  | 20,355 |  |  | 12,562 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (2,007 | ) |  | (1,855 | ) |  | (13,054 | ) |  | (5,357 | ) |
| Excess tax benefits from share-based compensation |  | 2,227 |  |  | 926 |  |  | 6,357 |  |  | 2,089 |  |
| Net cash provided by (used in) financing activities |  | (14,779 | ) |  | 530 |  |  | (143,199 | ) |  | (125,423 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (4,623 | ) |  | (2,307 | ) |  | (6,468 | ) |  | (1,205 | ) |
| Net increase (decrease) in cash and cash equivalents |  | 118,377 |  |  | 143,213 |  |  | (5,617 | ) |  | (28,051 | ) |
| Cash and cash equivalents, beginning of the period |  | 395,201 |  |  | 365,774 |  |  | 519,195 |  |  | 537,038 |  |
| Cash and cash equivalents, end of the period |  | $ | 513,578 |  |  | $ | 508,987 |  |  | $ | 513,578 |  |  | $ | 508,987 |  |
| The following amounts reflected in the statements of cash flows are included in discontinued operations: |
| Depreciation |  | $ | — |  |  | $ | 787 |  |  | $ | — |  |  | $ | 2,207 |  |
| Amortization of other intangible assets |  | $ | — |  |  | $ | 198 |  |  | $ | — |  |  | $ | 1,089 |  |
| Share-based compensation expense |  | $ | — |  |  | $ | 156 |  |  | $ | — |  |  | $ | 584 |  |
| Purchases of property, plant and equipment |  | $ | — |  |  | $ | 681 |  |  | $ | — |  |  | $ | 1,431 |  |
| Cash and cash equivalents, beginning of the period |  | $ | — |  |  | $ | 4,639 |  |  | $ | — |  |  | $ | 3,659 |  |
| Cash and cash equivalents, end of the period |  | $ | — |  |  | $ | 3,905 |  |  | $ | — |  |  | $ | 3,905 |  |

[0001032975-17-000002:8k_2_02:39]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |  |  |
| NET SALES |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2016 |  | 2015 |  | Change |  | 2016 |  | 2015 |  | Change |
| Net sales by channel: |  |  |  |  |  |  |  |  |  |  |  |  |
| Retail |  | $ | 666,707 |  |  | $ | 594,567 |  |  | 12 | % |  | $ | 1,710,875 |  |  | $ | 1,516,218 |  |  | 13 | % |
| OEM |  | — |  |  | 26,512 |  |  | (100 | ) |  | — |  |  | 71,041 |  |  | (100 | ) |
| Total net sales |  | $ | 666,707 |  |  | $ | 621,079 |  |  | 7 |  |  | $ | 1,710,875 |  |  | $ | 1,587,259 |  |  | 8 |  |
| Net retail sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Mobile Speakers |  | $ | 106,578 |  |  | $ | 85,081 |  |  | 25 | % |  | $ | 261,046 |  |  | $ | 206,175 |  |  | 27 | % |
| Audio-PC & Wearables |  | 67,225 |  |  | 57,300 |  |  | 17 |  |  | 186,058 |  |  | 149,341 |  |  | 25 |  |
| Gaming |  | 107,181 |  |  | 77,706 |  |  | 38 |  |  | 242,874 |  |  | 189,000 |  |  | 29 |  |
| Video Collaboration |  | 35,807 |  |  | 26,216 |  |  | 37 |  |  | 88,298 |  |  | 67,460 |  |  | 31 |  |
| Home Control |  | 26,942 |  |  | 25,684 |  |  | 5 |  |  | 49,916 |  |  | 48,548 |  |  | 3 |  |
| Pointing Devices |  | 142,166 |  |  | 139,711 |  |  | 2 |  |  | 382,249 |  |  | 381,364 |  |  | — |  |
| Keyboards & Combos |  | 125,289 |  |  | 116,531 |  |  | 8 |  |  | 359,824 |  |  | 324,458 |  |  | 11 |  |
| Tablet & Other Accessories |  | 24,852 |  |  | 35,873 |  |  | (31 | ) |  | 59,351 |  |  | 73,222 |  |  | (19 | ) |
| PC Webcams |  | 30,503 |  |  | 29,648 |  |  | 3 |  |  | 80,072 |  |  | 74,689 |  |  | 7 |  |
| Other (1) |  | 164 |  |  | 817 |  |  | (80 | ) |  | 1,187 |  |  | 1,961 |  |  | (39 | ) |
| Total net retail sales |  | $ | 666,707 |  |  | $ | 594,567 |  |  | 12 |  |  | $ | 1,710,875 |  |  | $ | 1,516,218 |  |  | 13 |  |
| __________________ |  |  |  |  |  |  |  |  |  |  |  |  |

[0001032975-17-000002:8k_2_02:40]
(1) Other category includes products that we currently intend to transition out of, or have already transitioned out of, because they are no longer strategic to our business.

[0001032975-17-000002:8k_2_02:41]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |  |  |  |  |
| GAAP TO NON GAAP RECONCILIATION (A)(B) |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Gross profit - GAAP |  | $ | 246,763 |  |  | $ | 208,497 |  |  | $ | 622,262 |  |  | $ | 538,947 |  |
| Share-based compensation expense |  | 617 |  |  | 464 |  |  | 1,930 |  |  | 1,648 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 1,929 |  |  | — |  |  | 4,705 |  |  | — |  |
| Gross profit - Non-GAAP |  | $ | 249,309 |  |  | $ | 208,961 |  |  | $ | 628,897 |  |  | $ | 540,595 |  |
| Gross margin - GAAP |  | 37.0 | % |  | 33.6 | % |  | 36.4 | % |  | 34.0 | % |
| Gross margin - Non-GAAP |  | 37.4 | % |  | 33.6 | % |  | 36.8 | % |  | 34.1 | % |
| Operating expenses - GAAP |  | $ | 150,487 |  |  | $ | 139,982 |  |  | $ | 446,720 |  |  | $ | 420,244 |  |
| Less: Share-based compensation expense |  | 8,770 |  |  | 5,998 |  |  | 24,424 |  |  | 17,636 |  |
| Less: Amortization of intangible assets and acquisition-related costs |  | 1,494 |  |  | 112 |  |  | 4,535 |  |  | 447 |  |
| Less: Change in fair value of contingent consideration for business acquisition |  | (9,925 | ) |  | — |  |  | (9,925 | ) |  | — |  |
| Less: Restructuring charges (credits), net |  | (33 | ) |  | (666 | ) |  | (44 | ) |  | 14,018 |  |
| Less: Investigation and related expenses |  | — |  |  | (249 | ) |  | 612 |  |  | 4,121 |  |
| Operating expenses - Non-GAAP |  | $ | 150,181 |  |  | $ | 134,787 |  |  | $ | 427,118 |  |  | $ | 384,022 |  |
| % of net sales - GAAP |  | 22.6 | % |  | 22.5 | % |  | 26.1 | % |  | 26.5 | % |
| % of net sales - Non - GAAP |  | 22.5 | % |  | 21.7 | % |  | 25.0 | % |  | 24.2 | % |
| Operating income - GAAP |  | $ | 96,276 |  |  | $ | 68,515 |  |  | $ | 175,542 |  |  | $ | 118,703 |  |
| Share-based compensation expense |  | 9,387 |  |  | 6,462 |  |  | 26,354 |  |  | 19,284 |  |
| Amortization of intangible assets |  | 2,751 |  |  | 112 |  |  | 6,618 |  |  | 447 |  |
| Purchase accounting effect on inventory |  | 457 |  |  | — |  |  | 1,160 |  |  | — |  |
| Acquisition-related costs |  | 215 |  |  | — |  |  | 1,462 |  |  | — |  |
| Change in fair value of contingent consideration for business acquisition |  | (9,925 | ) |  | — |  |  | (9,925 | ) |  | — |  |
| Restructuring charges (credits), net |  | (33 | ) |  | (666 | ) |  | (44 | ) |  | 14,018 |  |
| Investigation and related expenses |  | — |  |  | (249 | ) |  | 612 |  |  | 4,121 |  |
| Operating income - Non - GAAP |  | $ | 99,128 |  |  | $ | 74,174 |  |  | $ | 201,779 |  |  | $ | 156,573 |  |
| % of net sales - GAAP |  | 14.4 | % |  | 11.0 | % |  | 10.3 | % |  | 7.5 | % |
| % of net sales - Non - GAAP |  | 14.9 | % |  | 11.9 | % |  | 11.8 | % |  | 9.9 | % |
| Net income from continuing operations - GAAP |  | $ | 97,465 |  |  | $ | 68,040 |  |  | $ | 166,451 |  |  | $ | 111,352 |  |
| Share-based compensation expense |  | 9,387 |  |  | 6,462 |  |  | 26,354 |  |  | 19,284 |  |
| Amortization of intangible assets |  | 2,751 |  |  | 112 |  |  | 6,618 |  |  | 447 |  |
| Purchase accounting effect on inventory |  | 457 |  |  | — |  |  | 1,160 |  |  | — |  |
| Acquisition-related costs |  | 215 |  |  | — |  |  | 1,462 |  |  | — |  |
| Change in fair value of contingent consideration for business acquisition |  | (9,925 | ) |  | — |  |  | (9,925 | ) |  | — |  |
| Restructuring charges (credits), net |  | (33 | ) |  | (666 | ) |  | (44 | ) |  | 14,018 |  |
| Investigation and related expenses |  | — |  |  | (249 | ) |  | 612 |  |  | 4,121 |  |
| Loss (gain) on equity-method investment |  | (375 | ) |  | (4 | ) |  | (547 | ) |  | 176 |  |
| Non-GAAP income tax adjustment |  | (7,595 | ) |  | (6,709 | ) |  | (8,649 | ) |  | (9,961 | ) |
| Net income from continuing operations - Non - GAAP |  | $ | 92,347 |  |  | $ | 66,986 |  |  | $ | 183,492 |  |  | $ | 139,437 |  |
| Net income from continuing operations per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.59 |  |  | $ | 0.41 |  |  | $ | 1.01 |  |  | $ | 0.67 |  |
| Diluted - Non - GAAP |  | $ | 0.56 |  |  | $ | 0.41 |  |  | $ | 1.11 |  |  | $ | 0.84 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non - GAAP |  | 165,901 |  |  | 165,168 |  |  | 165,211 |  |  | 165,951 |  |

[0001032975-17-000002:8k_2_02:42]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
| SHARE-BASED COMPENSATION EXPENSE |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 617 |  |  | $ | 464 |  |  | $ | 1,930 |  |  | $ | 1,648 |  |
| Marketing and selling |  | 4,006 |  |  | 2,484 |  |  | 10,687 |  |  | 6,545 |  |
| Research and development |  | 1,176 |  |  | 846 |  |  | 3,007 |  |  | 2,174 |  |
| General and administrative |  | 3,588 |  |  | 2,668 |  |  | 10,730 |  |  | 8,917 |  |
| Restructuring |  | — |  |  | — |  |  | — |  |  | 7 |  |
| Total share-based compensation expense |  | 9,387 |  |  | 6,462 |  |  | 26,354 |  |  | 19,291 |  |
| Income tax benefit |  | (2,391 | ) |  | (1,446 | ) |  | (6,092 | ) |  | (2,479 | ) |
| Total share-based compensation expense, net of income tax |  | $ | 6,996 |  |  | $ | 5,016 |  |  | $ | 20,262 |  |  | $ | 16,812 |  |

[0001032975-17-000002:8k_2_02:43]
Note: These preliminary results for the three and nine months ended December 31, 2016 are subject to adjustments, including completion of our evaluation of the changes in the fair value of contingent consideration for our acquisition of Jaybird LLC and other subsequent events that may occur through the date of filing our Quarterly Report on Form 10-Q.

[0001032975-17-000002:8k_2_02:44]
(A) Preliminary valuation from the business acquisitions

[0001032975-17-000002:8k_2_02:45]
The preliminary purchase price allocations from the business acquisitions during the current periods are included in the tables. The fair value of identifiable intangible assets acquired was based on estimates and assumptions made by us at the time of acquisitions. As additional information becomes available, such as finalization of the estimated fair value of the assets acquired and liabilities assumed and the fair value of contingent consideration, we may revise our preliminary or interim purchase price allocations during the remainder of the measurement periods(which will not exceed 12 months from the acquisition dates). Any such revisions or changes may be material as we finalize the fair values of the tangible and intangible assets acquired and liabilities assumed, and may have a material impact over the results of operations.

[0001032975-17-000002:8k_2_02:46]
(B) Non-GAAP Financial Measures

[0001032975-17-000002:8k_2_02:47]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-17-000002:8k_2_02:48]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended June 30, 2016, we excluded items in the following general categories, each of which are described below:

[0001032975-17-000002:8k_2_02:49]
Share-based compensation expenses. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the

[0001032975-17-000002:8k_2_02:50]
impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-17-000002:8k_2_02:51]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our operating expenses and financial results from period to period.

[0001032975-17-000002:8k_2_02:52]
Purchase accounting effect on inventory. Business combination accounting principles require us to measure acquired inventory at fair value. The fair value of inventory reflects the acquired company’s cost of manufacturing plus a portion of the expected profit margin. The non-GAAP adjustment excludes the expected profit margin component that is recorded under business combination accounting principles associated with our business acquisitions. We believe the adjustment is useful to investors because such charges are not reflective of our ongoing operations.

[0001032975-17-000002:8k_2_02:53]
Acquisition-related costs and change in fair value of contingent consideration for business acquisition.  We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition related costs include all incremental expenses incurred to effect a business combination. Fair value of contingent consideration is associated with our estimates of the value of earn-outs in connection with certain acquisitions. We believe that providing the non-GAAP measures excluding these costs and credits, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-17-000002:8k_2_02:54]
Restructuring charges (credits). These expenses are associated with re-aligning our business strategies based on current economic conditions. We have undertaken several restructuring plans in recent years. In connection with our restructuring initiatives, we incurred restructuring charges related to employee terminations, facility closures and early cancellation of certain contracts. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results in the current period.

[0001032975-17-000002:8k_2_02:55]
Gain (loss) on equity-method investment. We recognized gain (loss) related our investments in various privately-held companies, which varies depending on the operational and financial performance of the privately-held companies in which we invested. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-17-000002:8k_2_02:56]
Investigation and related expenses.  These expenses are forensic accounting, audit, consulting and legal fees related to the Audit Committee’s investigation and the formal investigation by and settlement with the Securities and Exchange Commission (SEC), together with accruals based on settlement with the SEC. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-17-000002:8k_2_02:57]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above and other events; the determination of which is based upon the nature of the underlying items, the mix of income and losses in jurisdictions and the relevant tax rates in which we operate.

[0001032975-17-000002:8k_2_02:58]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-17-000002:8k_2_02:59]
Additional Supplemental Financial Information - Constant Currency

[0001032975-17-000002:8k_2_02:60]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates.  Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.
