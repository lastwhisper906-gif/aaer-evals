# LOGI MD&A — 0001032975-17-000005


## mdna

[0001032975-17-000005:mdna:1]
[same as prior period, unchanged from 0001032975-16-000106:mdna:1]

[0001032975-17-000005:mdna:2]
[same as prior period, unchanged from 0001032975-16-000106:mdna:2]

[0001032975-17-000005:mdna:3]
[same as prior period, unchanged from 0001032975-16-000106:mdna:3]

[0001032975-17-000005:mdna:4]
[same as prior period, unchanged from 0001032975-16-000106:mdna:4]

[0001032975-17-000005:mdna:5]
[same as prior period, unchanged from 0001032975-16-000106:mdna:6]

[0001032975-17-000005:mdna:6]
[same as prior period, unchanged from 0001032975-16-000106:mdna:5]

[0001032975-17-000005:mdna:7]
[same as prior period, unchanged from 0001032975-16-000106:mdna:7]

[0001032975-17-000005:mdna:8]
[same as prior period, unchanged from 0001032975-16-000106:mdna:8]

[0001032975-17-000005:mdna:9]
[same as prior period, unchanged from 0001032975-16-000106:mdna:9]

[0001032975-17-000005:mdna:10]
| • | Smart Home: The connected home is a market in its early stages of formation and growth. The push to realize the vision of the Internet-of-Things is delivering more and more connected devices that populate our homes, from the more traditionally connected devices like set-top boxes and digital entertainment devices to things like appliances, lighting, door locks and thermostats. We have a foundation for growth in this market through the entertainment control capabilities in our Harmony products. |

[0001032975-17-000005:mdna:11]
[same as prior period, unchanged from 0001032975-16-000106:mdna:11]

[0001032975-17-000005:mdna:12]
[same as prior period, unchanged from 0001032975-16-000106:mdna:12]

[0001032975-17-000005:mdna:13]
[same as prior period, unchanged from 0001032975-16-000106:mdna:13]

[0001032975-17-000005:mdna:14]
[same as prior period, unchanged from 0001032975-16-000106:mdna:14]

[0001032975-17-000005:mdna:15]
[same as prior period, unchanged from 0001032975-16-000106:mdna:15]

[0001032975-17-000005:mdna:16]
In fiscal years prior to fiscal year 2016, we had two segments: Peripherals, including retail and OEM products; and Lifesize Video Conferencing. During fiscal year 2016, we divested the Lifesize Video Conferencing segment, and exited the OEM business. Our financial results treat the Lifesize segment as discontinued operations for all the periods presented in this Quarterly Report on Form 10-Q. Unless indicated otherwise, the information included in

[0001032975-17-000005:mdna:17]
Item 2 relates to our continuing operations and historical financial information has been recast to conform to this presentation within our condensed consolidated financial statements.

[0001032975-17-000005:mdna:18]
[same as prior period, unchanged from 0001032975-16-000106:mdna:18]

[0001032975-17-000005:mdna:19]
On September 15, 2016, we completed the acquisition of the Saitek product line for a total consideration of approximately $13.0 million (the "Saitek Acquisition"). Out of the total consideration, $6.7 million was attributed to intangible assets, $4.9 million was attributed to goodwill, and $1.4 million was attributed to net tangible assets acquired. The Saitek Acquisition is expected to enhance the breadth and depth of our product offerings and expand our engineering capabilities in simulation products.

[0001032975-17-000005:mdna:20]
[same as prior period, unchanged from 0001032975-16-000106:mdna:20]

[0001032975-17-000005:mdna:21]
Our net sales for the three and nine months ended December 31, 2016 increased 7% and 8% compared to the three and nine months ended December 31, 2015, respectively, due to stronger retail sales, partially offset by our exit of the OEM business in the quarter ended December 31, 2015. The results of operations for Jaybird and Saitek have been included in our condensed consolidated statements of operations from the acquisition date. For the three and nine months ended December 31, 2016, Jaybird and Saitek contributed a total of $17.4 million and $47.3 million of net sales, respectively.

[0001032975-17-000005:mdna:22]
Our retail sales for the three months ended December 31, 2016 increased 12% compared to the three months ended December 31, 2015. Retail sales increased 7%, 18% and 14% in the Americas ("AMR"), EMEA and Asia Pacific, respectively.  Our retail sales for the nine months ended December 31, 2016 increased 13% compared to the nine months ended December 31, 2015. Retail sales increased 8%, 21% and 11% in AMR, EMEA and Asia Pacific, respectively.

[0001032975-17-000005:mdna:23]
Our gross margin for the three months ended December 31, 2016 increased to 37.0% from 33.6% for the three months ended December 31, 2015. Our gross margin for the nine months ended December 31, 2016 increased to 36.4% from 34.0% for the nine months ended December 31, 2015. The increases in gross margin for both periods were primarily driven by product cost reductions as well as greater supply chain efficiencies, partially offset by an increase of promotions, and amortization of intangible assets and purchase accounting effect on inventory from business acquisitions.

[0001032975-17-000005:mdna:24]
Operating expenses for the three months ended December 31, 2016 were 22.6% of net sales, compared to 22.5% in the same period of the prior fiscal year. Operating expenses for the nine months ended December 31, 2016 were 26.1% of net sales, compared to 26.5% in the same period of the prior fiscal year. Net operating expense increased in both periods, primarily driven by higher personnel-related costs due to increased headcount, business acquisitions completed during the first nine months of fiscal year 2017, a higher variable compensation linked to strong performance in the first nine months of the fiscal year, and amortization of intangibles from the business acquisitions, partially offset by a gain from change in fair value of contingent consideration from the Jaybird Acquisition. The increase of operating expenses for the nine months ended December 31, 2016 was also offset by a decrease in restructuring charges as we substantially completed our restructuring plan in the fourth quarter of fiscal year 2016.

[0001032975-17-000005:mdna:25]
Net income from continuing operations for the three and nine months ended December 31, 2016 was $97.5 million and $166.5 million, respectively, compared to $68.0 million and $111.4 million for the three and nine months ended December 31, 2015, respectively.

[0001032975-17-000005:mdna:26]
[same as prior period, unchanged from 0001032975-16-000106:mdna:27]

[0001032975-17-000005:mdna:27]
31

[0001032975-17-000005:mdna:28]
[same as prior period, unchanged from 0001032975-16-000106:mdna:28]

[0001032975-17-000005:mdna:29]
[same as prior period, unchanged from 0001032975-16-000106:mdna:29]

[0001032975-17-000005:mdna:30]
[same as prior period, unchanged from 0001032975-16-000106:mdna:30]

[0001032975-17-000005:mdna:31]
[same as prior period, unchanged from 0001032975-16-000106:mdna:31]

[0001032975-17-000005:mdna:32]
Music:  The music market grew during the first nine months of fiscal year 2017, driven by growing consumption of music through mobile devices such as smartphones and tablets. This market growth, together with our investments in the UE brand, our introduction of new products, acquisitions of new portfolios and our ability to gain market share, has driven our growth in this market.

[0001032975-17-000005:mdna:33]
[same as prior period, unchanged from 0001032975-16-000106:mdna:33]

[0001032975-17-000005:mdna:34]
[same as prior period, unchanged from 0001032975-16-000106:mdna:34]

[0001032975-17-000005:mdna:35]
Smart Home:  This market increased in fiscal year 2016 and has continued growing in fiscal year 2017. In October 2016, we introduced a new Amazon Alexa skill that enables voice control of the living room entertainment experience using a Logitech Harmony Hub with Alexa-enabled devices such as the Amazon Echo or Echo Dot. Through Harmony, Alexa can turn on/off and control a TV and AV system. We have also seen early success with the professional installer channel through the recent introduction of the Harmony Pro. We will continue to explore other innovative experiences for the Smart Home.

[0001032975-17-000005:mdna:36]
[same as prior period, unchanged from 0001032975-16-000106:mdna:36]

[0001032975-17-000005:mdna:37]
[same as prior period, unchanged from 0001032975-16-000106:mdna:37]

[0001032975-17-000005:mdna:38]
[same as prior period, unchanged from 0001032975-16-000106:mdna:38]

[0001032975-17-000005:mdna:39]
[same as prior period, unchanged from 0001032975-16-000106:mdna:39]

[0001032975-17-000005:mdna:40]
[same as prior period, unchanged from 0001032975-16-000106:mdna:40]

[0001032975-17-000005:mdna:41]
[same as prior period, unchanged from 0001032975-16-000106:mdna:41]

[0001032975-17-000005:mdna:42]
We base our estimates on historical experience and on various other assumptions we believe to be reasonable under the circumstances. Although these estimates are based on management's best knowledge of current events and actions that may impact us in the future, actual results could differ from those estimates. Management has discussed the development, selection and disclosure of these critical accounting estimates with the Audit Committee of the Board of Directors.

[0001032975-17-000005:mdna:43]
Accounting for business combinations requires us to make significant estimates and assumptions, especially at the acquisition date with respect to tangible and intangible assets acquired and liabilities assumed and pre-acquisition contingencies. We use our best estimates and assumptions to accurately assign fair value to the tangible and intangible assets acquired and liabilities assumed at the acquisition date.

[0001032975-17-000005:mdna:44]
[same as prior period, unchanged from 0001032975-16-000106:mdna:45]

[0001032975-17-000005:mdna:45]
[same as prior period, unchanged from 0001032975-16-000106:mdna:46]

[0001032975-17-000005:mdna:46]
[same as prior period, unchanged from 0001032975-16-000106:mdna:47]

[0001032975-17-000005:mdna:47]
[same as prior period, unchanged from 0001032975-16-000106:mdna:48]

[0001032975-17-000005:mdna:48]
[same as prior period, unchanged from 0001032975-16-000106:mdna:49]

[0001032975-17-000005:mdna:49]
[same as prior period, unchanged from 0001032975-16-000106:mdna:50]

[0001032975-17-000005:mdna:50]
[same as prior period, unchanged from 0001032975-16-000106:mdna:51]

[0001032975-17-000005:mdna:51]
The economic useful life of the trade names from the business acquisitions was determined based on the expected life of the trade names and the cash flows anticipated over the forecasted periods.

[0001032975-17-000005:mdna:52]
The fair value of acquisition-related contingent consideration liability arising from the Jaybird Acquisition (see "Note 3 - Business Acquisitions" and "Note 8 - Fair Value Measurements" to the condensed consolidated financial statements for more information) is determined by using a Monte Carlo Simulation that includes significant unobservable inputs such as a risk-adjusted discount rate and projected net sales of Jaybird over the earn-out period, and it is remeasured at each reporting period based on the inputs on the date of remeasurement. Projected net sales are based on our internal projections, including analysis of the target markets. The fair value of the contingent consideration was decreased to $8.1 million as of December 31, 2016. The change in fair value of contingent consideration results primarily from Jaybird's lower-than-expected net sales during the three months ended December 31, 2016 and revised projected net sales in the remaining earn-out period, primarily driven by supply constraints, an evolving product portfolio and changes in the competitive target market. Although these estimates are based on management’s best knowledge of current events, the estimates could change significantly from period to period. Any changes to the significant unobservable inputs used, including change in the forecast of net sales for the earn-out periods, may result in change in the fair value of contingent consideration, and could have a material impact on future results of operations. Actual payment of contingent consideration in the future could be different from the current estimated fair value of the contingent consideration.

[0001032975-17-000005:mdna:53]
[same as prior period, unchanged from 0001032975-16-000106:mdna:54]

[0001032975-17-000005:mdna:54]
[same as prior period, unchanged from 0001032975-16-000106:mdna:55]

[0001032975-17-000005:mdna:55]
In August 2016, the FASB issued ASU 2016-15 "Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments", which gives guidance and reduces diversity in practice with respect to certain types of cash flows. We have early adopted this guidance during the second quarter of fiscal year 2017 and the adoption did not impact our condensed consolidated financial statements.

[0001032975-17-000005:mdna:56]
[same as prior period, unchanged from 0001032975-16-000106:mdna:57]

[0001032975-17-000005:mdna:57]
[same as prior period, unchanged from 0001032975-16-000106:mdna:58]

[0001032975-17-000005:mdna:58]
[same as prior period, unchanged from 0001032975-16-000106:mdna:59]

[0001032975-17-000005:mdna:59]
[same as prior period, unchanged from 0001032975-16-000106:mdna:60]

[0001032975-17-000005:mdna:60]
Net sales by channel for the three and nine months ended December 31, 2016 and 2015 were as follows (Dollars in thousands):

[0001032975-17-000005:mdna:61]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2016 |  | 2015 |  | Change |  | 2016 |  | 2015 |  | Change |
| Retail |  | $ | 666,707 |  |  | $ | 594,567 |  |  | 12 | % |  | $ | 1,710,875 |  |  | $ | 1,516,218 |  |  | 13 | % |
| OEM |  | — |  |  | 26,512 |  |  | (100 | ) |  | — |  |  | 71,041 |  |  | (100 | ) |
| Total net sales |  | $ | 666,707 |  |  | $ | 621,079 |  |  | 7 |  |  | $ | 1,710,875 |  |  | $ | 1,587,259 |  |  | 8 |  |

[0001032975-17-000005:mdna:62]
[same as prior period, unchanged from 0001032975-16-000106:mdna:63]

[0001032975-17-000005:mdna:63]
Our net retail sales in the three and nine months ended December 31, 2016 increased 12% and 13%, respectively, compared to the same periods of the prior fiscal year. Sales increased across all three regions during the three and nine months ended December 31, 2016. If currency exchange rates had been constant in the three and nine months ended December 31, 2016 and 2015, our constant dollar retail sales growth rates would have been 13% for both periods. The growths for both periods include the net sales resulting from the Jaybird Acquisition completed in the first quarter of fiscal year 2017 and the Saitek Acquisition completed in the second quarter of fiscal year 2017 (see Note 3 - "Business Acquisitions" to the condensed consolidated financial statements).

[0001032975-17-000005:mdna:64]
[same as prior period, unchanged from 0001032975-16-000106:mdna:65]

[0001032975-17-000005:mdna:65]
The year-over-year decline in our OEM sales was due to our exit from the OEM business in December 2015. As a result, there was no OEM revenue during the three and nine months ended December 31, 2016.

[0001032975-17-000005:mdna:66]
[same as prior period, unchanged from 0001032975-16-000106:mdna:67]

[0001032975-17-000005:mdna:67]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Canadian Dollar, Taiwan New Dollar, British Pound and Australian Dollar. For example, during the three months ended December 31, 2016, 51% of our net sales were denominated in currencies other than the U.S. Dollar.

[0001032975-17-000005:mdna:68]
[same as prior period, unchanged from 0001032975-16-000106:mdna:69]

[0001032975-17-000005:mdna:69]
The following table presents the change in retail sales by region for the three and nine months ended December 31, 2016, compared to the three and nine months ended December 31, 2015:

[0001032975-17-000005:mdna:70]
|  | Three Months EndedDecember 31, 2016Change in Sales |  | Nine Months EndedDecember 31, 2016Change in Sales |
| Americas | 7 | % |  | 8 | % |
| EMEA | 18 |  |  | 21 |  |
| Asia Pacific | 14 |  |  | 11 |  |

[0001032975-17-000005:mdna:71]
[same as prior period, unchanged from 0001032975-16-000106:mdna:72]

[0001032975-17-000005:mdna:72]
Retail sales in the Americas region increased 7% and 8%, respectively, during the three and nine months ended December 31, 2016, compared to the same periods of the prior fiscal year. If currency exchange rates had been constant in the three and nine months ended December 31, 2016 and 2015, our constant dollar retail sales growth rates would have been 8% and 9%, respectively, in the Americas. The growths were driven by Audio PC & Wearables, Mobile Speakers and Gaming, partially offset by declines in sales for Pointing Devices and Tablet & Other Accessories.

[0001032975-17-000005:mdna:73]
[same as prior period, unchanged from 0001032975-16-000106:mdna:75]

[0001032975-17-000005:mdna:74]
Retail sales in the EMEA region increased 18% and 21%, respectively, during the three and nine months ended December 31, 2016, compared to the same periods of the prior fiscal year. If currency exchange rates had been constant in the three and nine months ended December 31, 2016 and 2015, our constant dollar retail sales growth rates would have been 20% and 22%, respectively. The growth in the periods was driven by several of our product categories, with strength in Mobile Speakers, Keyboards & Combos, Pointing Devices, Video Collaboration and Gaming.

[0001032975-17-000005:mdna:75]
[same as prior period, unchanged from 0001032975-16-000106:mdna:77]

[0001032975-17-000005:mdna:76]
Retail sales in the Asia Pacific region increased 14% and 11%, respectively, during the three and nine months ended December 31, 2016, compared to the same periods of the prior fiscal year. If currency exchange rates had been constant in the three and nine months ended December 31, 2016 and 2015, our constant dollar retail sales growth rates would have been 13% and 11%, respectively. The growth in the periods was primarily driven by sales increases in Gaming.

[0001032975-17-000005:mdna:77]
[same as prior period, unchanged from 0001032975-16-000106:mdna:79]

[0001032975-17-000005:mdna:78]
Net retail sales by product category for the three and nine months ended December 31, 2016 and 2015 were as follows (Dollars in thousands):

[0001032975-17-000005:mdna:79]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2016 |  | 2015 |  | Change |  | 2016 |  | 2015 |  | Change |
| Mobile Speakers |  | $ | 106,578 |  |  | $ | 85,081 |  |  | 25 | % |  | $ | 261,046 |  |  | $ | 206,175 |  |  | 27 | % |
| Audio-PC & Wearables |  | 67,225 |  |  | 57,300 |  |  | 17 |  |  | 186,058 |  |  | 149,341 |  |  | 25 |  |
| Gaming |  | 107,181 |  |  | 77,706 |  |  | 38 |  |  | 242,874 |  |  | 189,000 |  |  | 29 |  |
| Video Collaboration |  | 35,807 |  |  | 26,216 |  |  | 37 |  |  | 88,298 |  |  | 67,460 |  |  | 31 |  |
| Home Control |  | 26,942 |  |  | 25,684 |  |  | 5 |  |  | 49,916 |  |  | 48,548 |  |  | 3 |  |
| Pointing Devices |  | 142,166 |  |  | 139,711 |  |  | 2 |  |  | 382,249 |  |  | 381,364 |  |  | — |  |
| Keyboards & Combos |  | 125,289 |  |  | 116,531 |  |  | 8 |  |  | 359,824 |  |  | 324,458 |  |  | 11 |  |
| Tablet & Other Accessories |  | 24,852 |  |  | 35,873 |  |  | (31 | ) |  | 59,351 |  |  | 73,222 |  |  | (19 | ) |
| PC Webcams |  | 30,503 |  |  | 29,648 |  |  | 3 |  |  | 80,072 |  |  | 74,689 |  |  | 7 |  |
| Other (1) |  | 164 |  |  | 817 |  |  | (80 | ) |  | 1,187 |  |  | 1,961 |  |  | (39 | ) |
| Total net retail sales |  | $ | 666,707 |  |  | $ | 594,567 |  |  | 12 |  |  | $ | 1,710,875 |  |  | $ | 1,516,218 |  |  | 13 |  |

[0001032975-17-000005:mdna:80]
(1) Other category includes products out of which we currently intend to transition, or out of which we have already transitioned, because they are no longer strategic to our business.

[0001032975-17-000005:mdna:81]
[same as prior period, unchanged from 0001032975-16-000106:mdna:83]

[0001032975-17-000005:mdna:82]
[same as prior period, unchanged from 0001032975-16-000106:mdna:84]

[0001032975-17-000005:mdna:83]
[same as prior period, unchanged from 0001032975-16-000106:mdna:85]

[0001032975-17-000005:mdna:84]
[same as prior period, unchanged from 0001032975-16-000106:mdna:86]

[0001032975-17-000005:mdna:85]
Retail sales of Mobile Speakers increased 25% and 27%, respectively, for the three and nine months ended December 31, 2016, compared to the same periods of the prior fiscal year. Mobile Speaker sales increased for both periods primarily due to the introduction of the UE Boom 2 in the second quarter of fiscal year 2016 as well as the continued success of the UE Megaboom.

[0001032975-17-000005:mdna:86]
[same as prior period, unchanged from 0001032975-16-000106:mdna:88]

[0001032975-17-000005:mdna:87]
[same as prior period, unchanged from 0001032975-16-000106:mdna:89]

[0001032975-17-000005:mdna:88]
Audio-PC & Wearables sales increased 17% and 25%, respectively, for the three and nine months ended December 31, 2016, compared to the same periods of the prior fiscal year. The increase for the three months ended December 31, 2016 was primarily driven by the introduction of the Jaybird X3 Sport Bluetooth earbuds in the third quarter of fiscal year 2017 and the Jaybird Freedom F5 earbuds resulting from the Jaybird Acquisition in the first quarter of fiscal year 2017 (see Note 3 - "Business Acquisitions" to the condensed consolidated financial statements). The increase for the nine months ended December 31, 2016 was primarily driven by the Jaybird Freedom F5 earbuds and the Jaybird X2 and X3 Sport Bluetooth earbuds.

[0001032975-17-000005:mdna:89]
[same as prior period, unchanged from 0001032975-16-000106:mdna:92]

[0001032975-17-000005:mdna:90]
[same as prior period, unchanged from 0001032975-16-000106:mdna:93]

[0001032975-17-000005:mdna:91]
Our retail Gaming category comprises Gaming mice, keyboards, headsets, gamepads, steering wheels and Saitek simulation controllers.

[0001032975-17-000005:mdna:92]
Gaming retail sales increased 38% and 29%, respectively, for the three and nine months ended December 31, 2016, compared to the same periods of the prior fiscal year.  The significant increases for both periods were primarily driven by the continued success of our G502 Proteus Spectrum gaming mouse and new product introductions of the G900 Chaos Spectrum gaming mouse and the G910 Orion Spark gaming keyboard in the first half of fiscal year 2017.

[0001032975-17-000005:mdna:93]
[same as prior period, unchanged from 0001032975-16-000106:mdna:96]

[0001032975-17-000005:mdna:94]
[same as prior period, unchanged from 0001032975-16-000106:mdna:97]

[0001032975-17-000005:mdna:95]
Our retail Video Collaboration category primarily includes video products and certain headset products that can connect various sized user groups.

[0001032975-17-000005:mdna:96]
Retail sales of Video Collaboration increased 37% and 31%, respectively, in the three and nine months ended December 31, 2016, compared to the same periods of the prior fiscal year. The increases in both periods were primarily due to the introduction of the Logitech Group conference camera in the fourth quarter of fiscal year 2016.

[0001032975-17-000005:mdna:97]
Smart Home market:

[0001032975-17-000005:mdna:98]
[same as prior period, unchanged from 0001032975-16-000106:mdna:101]

[0001032975-17-000005:mdna:99]
[same as prior period, unchanged from 0001032975-16-000106:mdna:102]

[0001032975-17-000005:mdna:100]
Home Control retail sales increased 5% and 3%, respectively, during the three and nine months ended December 31, 2016, compared to the same periods of the prior fiscal year.

[0001032975-17-000005:mdna:101]
[same as prior period, unchanged from 0001032975-16-000106:mdna:104]

[0001032975-17-000005:mdna:102]
[same as prior period, unchanged from 0001032975-16-000106:mdna:105]

[0001032975-17-000005:mdna:103]
[same as prior period, unchanged from 0001032975-16-000106:mdna:106]

[0001032975-17-000005:mdna:104]
Retail sales of Pointing Devices increased 2% and remained flat, respectively, during the three and nine months ended December 31, 2016, compared to the same periods of the prior fiscal year.

[0001032975-17-000005:mdna:105]
[same as prior period, unchanged from 0001032975-16-000106:mdna:108]

[0001032975-17-000005:mdna:106]
[same as prior period, unchanged from 0001032975-16-000106:mdna:109]

[0001032975-17-000005:mdna:107]
Retail sales of Keyboards & Combos increased 8% and 11%, respectively, in the three and nine months ended December 31, 2016, compared to the same periods of the prior fiscal year. The sales increase for the three months ended December 31, 2016 was primarily driven by continued sales of our MK235 Combo launched in the fourth quarter of fiscal year 2016. The sales increase for the nine months ended December 31, 2016 was primarily driven by the strong sales of our wireless keyboard K400 plus, in addition to the new product launch of our MK235 Combo in the fourth quarter of fiscal year 2016.

[0001032975-17-000005:mdna:108]
[same as prior period, unchanged from 0001032975-16-000106:mdna:111]

[0001032975-17-000005:mdna:109]
Our retail Tablet & Other Accessories category consists of keyboards for tablets and covers for tablets as well as other accessories for mobile devices.

[0001032975-17-000005:mdna:110]
Retail sales of Tablet & Other Accessories decreased 31% and 19%, respectively, in the three and nine months ended December 31, 2016, compared to the same periods of the prior fiscal year. The sales decrease for both periods reflect the declining market for iPad shipments, partially offset by the new product introduction of the Create Tablet Keyboard Case for the iPad Pro launched in September of fiscal year 2016.

[0001032975-17-000005:mdna:111]
[same as prior period, unchanged from 0001032975-16-000106:mdna:114]

[0001032975-17-000005:mdna:112]
[same as prior period, unchanged from 0001032975-16-000106:mdna:115]

[0001032975-17-000005:mdna:113]
Retail PC Webcams sales increased 3% and 7%, respectively, in the three and nine months ended December 31, 2016, compared to the same periods of the prior fiscal year. The increase in the three months ended December 31, 2016 was primarily driven by the introduction of our C922 Pro Stream Webcam. The increase in the nine months ended December 31, 2016 was primarily driven by strong sales of our HD Pro Webcam C920, in addition to the introduction of the C922 Pro Stream Webcam.

[0001032975-17-000005:mdna:114]
37

[0001032975-17-000005:mdna:115]
[same as prior period, unchanged from 0001032975-16-000106:mdna:117]

[0001032975-17-000005:mdna:116]
Gross profit for the three and nine months ended December 31, 2016 and 2015 was as follows (Dollars in thousands):

[0001032975-17-000005:mdna:117]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2016 |  | 2015 |  | Change |  | 2016 |  | 2015 |  | Change |
| Net sales |  | $ | 666,707 |  |  | $ | 621,079 |  |  | 7 | % |  | $ | 1,710,875 |  |  | $ | 1,587,259 |  |  | 8 | % |
| Cost of goods sold |  | 418,015 |  |  | 412,582 |  |  | 1 |  |  | 1,083,908 |  |  | 1,048,312 |  |  | 3 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 1,929 |  |  | — |  |  | NM |  |  | 4,705 |  |  | — |  |  | NM |  |
| Gross profit |  | $ | 246,763 |  |  | $ | 208,497 |  |  | 18 |  |  | $ | 622,262 |  |  | $ | 538,947 |  |  | 15 |  |
| Gross margin |  | 37.0 | % |  | 33.6 | % |  |  |  | 36.4 | % |  | 34.0 | % |  |  |  |

[0001032975-17-000005:mdna:118]
[same as prior period, unchanged from 0001032975-16-000106:mdna:120]

[0001032975-17-000005:mdna:119]
Gross profit consists of net sales, less cost of goods sold (which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, royalties, costs of purchasing components from outside suppliers, distribution costs, warranty costs, customer support, outside processing costs and write-down of inventories) and less amortization of certain intangible assets and purchase accounting effect on inventory. Purchase accounting effect on inventory was $0.5 million and $1.2 million for the three and nine months ended December 31, 2016, respectively. Amortization of intangible assets from developed technology was $1.5 million and $3.5 million, respectively, for the three and nine months ended December 31, 2016 as a result of the business acquisitions.

[0001032975-17-000005:mdna:120]
Gross margin increased by 340 basis points and 240 basis points, respectively, for the three and nine months ended December 31, 2016, compared to the same period of the prior fiscal year. The increases in gross margin for both periods were primarily driven by product cost reductions as well as greater supply chain efficiencies, partially offset by an increase of promotions, and amortization of intangible assets and purchase accounting effect on inventory from business acquisitions.

[0001032975-17-000005:mdna:121]
[same as prior period, unchanged from 0001032975-16-000106:mdna:136]

[0001032975-17-000005:mdna:122]
[same as prior period, unchanged from 0001032975-16-000106:mdna:124]

[0001032975-17-000005:mdna:123]
Operating expenses for the three and nine months ended December 31, 2016 and 2015 were as follows (Dollars in thousands):

[0001032975-17-000005:mdna:124]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2016 |  | 2015 |  | Change |  | 2016 |  | 2015 |  | Change |
| Marketing and selling |  | $ | 102,036 |  |  | $ | 87,295 |  |  | 17 | % |  | $ | 279,700 |  |  | $ | 241,924 |  |  | 16 | % |
| % of net sales |  | 15.3 | % |  | 14.1 | % |  |  |  |  | 16.3 | % |  | 15.2 | % |  |  |  |
| Research and development |  | 32,284 |  |  | 29,161 |  |  | 11 |  |  | 96,867 |  |  | 85,889 |  |  | 13 |  |
| % of net sales |  | 4.8 | % |  | 4.7 | % |  |  |  |  | 5.7 | % |  | 5.4 | % |  |  |  |
| General and administrative |  | 24,631 |  |  | 24,080 |  |  | 2 |  |  | 75,587 |  |  | 77,966 |  |  | (3 | ) |
| % of net sales |  | 3.7 | % |  | 3.9 | % |  |  |  |  | 4.4 | % |  | 4.9 | % |  |  |  |
| Amortization of intangible assets and acquisition-related costs |  | 1,494 |  |  | 112 |  |  | 1,234 |  |  | 4,535 |  |  | 447 |  |  | 915 |  |
| % of net sales |  | 0.2 | % |  | — | % |  |  |  | 0.3 | % |  | — | % |  |  |
| Change in fair value of contingent consideration for business acquisition |  | (9,925 | ) |  | — |  |  | NM |  |  | (9,925 | ) |  | — |  |  | NM |  |
| % of net sales |  | (1.5 | )% |  | — | % |  |  |  | (0.6 | )% |  | — | % |  |  |
| Restructuring charges (credits), net |  | (33 | ) |  | (666 | ) |  | (95 | ) |  | (44 | ) |  | 14,018 |  |  | (100 | ) |
| % of net sales |  | — | % |  | (0.1 | )% |  |  |  |  | — | % |  | 0.9 | % |  |  |  |
| Total operating expenses |  | $ | 150,487 |  |  | $ | 139,982 |  |  | 8 |  |  | $ | 446,720 |  |  | $ | 420,244 |  |  | 6 |  |
| % of net sales |  | 22.6 | % |  | 22.5 | % |  |  |  |  | 26.1 | % |  | 26.5 | % |  |  |  |

[0001032975-17-000005:mdna:125]
NM=Not Meaningful.

[0001032975-17-000005:mdna:126]
[same as prior period, unchanged from 0001032975-16-000106:mdna:127]

[0001032975-17-000005:mdna:127]
[same as prior period, unchanged from 0001032975-16-000106:mdna:128]

[0001032975-17-000005:mdna:128]
During the three months ended December 31, 2016, marketing and selling expenses increased 17%, compared to the same period of the prior fiscal year. During the nine months ended December 31, 2016, marketing and selling expenses increased 16%, compared to the same period of the prior fiscal year. The increases for both periods were primarily driven by higher personnel-related costs due to increased headcount during the last twelve months to expand our marketing team to support the advertising and marketing efforts for our products, the increased headcount and amortization of intangible assets resulting from the Jaybird Acquisition and Saitek Acquisition, as well as increased variable compensation linked to stronger performance during the first nine months of fiscal year 2017.

[0001032975-17-000005:mdna:129]
[same as prior period, unchanged from 0001032975-16-000106:mdna:130]

[0001032975-17-000005:mdna:130]
[same as prior period, unchanged from 0001032975-16-000106:mdna:131]

[0001032975-17-000005:mdna:131]
During the three and nine months ended December 31, 2016, research and development expenses increased 11% and 13%, respectively, compared to the same periods in the prior fiscal year. The increases for both periods were primarily driven by higher personnel-related costs to support the launch of new products, increased headcount from business acquisitions, and increased variable compensation linked to stronger performance during the first nine months of fiscal year 2017.

[0001032975-17-000005:mdna:132]
[same as prior period, unchanged from 0001032975-16-000106:mdna:133]

[0001032975-17-000005:mdna:133]
[same as prior period, unchanged from 0001032975-16-000106:mdna:134]

[0001032975-17-000005:mdna:134]
During the three months ended December 31, 2016, general and administrative expenses increased 2%, compared to the same period in the prior fiscal year. The increase was primarily driven by higher variable compensation linked to stronger performance during the first nine months of fiscal year 2017, partially offset by decreased information technology costs.

[0001032975-17-000005:mdna:135]
During the nine months ended December 31, 2016, general and administrative expenses decreased 3%, compared to the same period in the prior fiscal year. The decrease was primarily due to a $3.5 million reduction related to the prior year's accrual for our settlement with the SEC (see "Note 12 - Commitments and Contingencies" to the condensed consolidated financial statements for more details) and a decrease in information technology costs, partially offset by an increase in variable compensation linked to stronger performance during the first nine months of fiscal year 2017.

[0001032975-17-000005:mdna:136]
[same as prior period, unchanged from 0001032975-16-000106:mdna:138]

[0001032975-17-000005:mdna:137]
Amortization of intangibles and acquisition-related costs during the three and nine months ended December 31, 2016 and 2015 were as follows (in thousands):

[0001032975-17-000005:mdna:138]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Amortization of intangible assets |  | $ | 1,279 |  |  | $ | 112 |  |  | $ | 3,074 |  |  | $ | 447 |  |
| Acquisition-related costs |  | 215 |  |  | — |  |  | 1,461 |  |  | — |  |
| Total |  | $ | 1,494 |  |  | $ | 112 |  |  | $ | 4,535 |  |  | $ | 447 |  |

[0001032975-17-000005:mdna:139]
Amortization of intangible assets consists of amortization of acquired intangible assets including customer relationships and trade names. Acquisition-related costs include legal expense, due diligence costs, and other professional costs incurred for business acquisitions.

[0001032975-17-000005:mdna:140]
Change in Fair Value of Contingent Consideration for Business Acquisition

[0001032975-17-000005:mdna:141]
The change in fair value of contingent consideration is primarily due to lower-than-expected net sales of Jaybird products during the three months ended December 31, 2016, and revised projected net sales of Jaybird products during the remaining earn-out period, primarily driven by supply constraints, an evolving product portfolio and changes in the competitive target market (see Note 8 – Fair Value Measurement). Although these estimates are based on management’s best knowledge of current events, the estimates could change significantly from period to period. Any changes to the significant unobservable inputs used, including change in the forecast of net sales of the earn-out periods, may result in change in the fair value of contingent consideration, and could have a material impact on future results of operations. Actual payment of contingent consideration in the future could be different from the current estimated fair value of the contingent consideration.

[0001032975-17-000005:mdna:142]
[same as prior period, unchanged from 0001032975-16-000106:mdna:141]

[0001032975-17-000005:mdna:143]
The following table summarizes restructuring-related activities during the three and nine months ended December 31, 2016 (in thousands):

[0001032975-17-000005:mdna:144]
|  |  | Restructuring |
|  |  | TerminationBenefits |  | Lease ExitCosts |  | Total |
| Accrual balance at March 31, 2016 |  | $ | 6,275 |  |  | $ | 125 |  |  | $ | 6,400 |  |
| Credits, net |  | (85 | ) |  | — |  |  | (85 | ) |
| Cash payments |  | (1,908 | ) |  | (125 | ) |  | (2,033 | ) |
| Accrual balance at June 30, 2016 |  | $ | 4,282 |  |  | $ | — |  |  | $ | 4,282 |  |
| Charges |  | 74 |  |  | — |  |  | 74 |  |
| Cash payments |  | (1,473 | ) |  | — |  |  | (1,473 | ) |
| Accrual balance at September 30, 2016 |  | $ | 2,883 |  |  | $ | — |  |  | $ | 2,883 |  |
| Credits, net |  | (33 | ) |  | — |  |  | (33 | ) |
| Cash payments |  | (1,200 | ) |  | — |  |  | (1,200 | ) |
| Accrual balance at December 31, 2016 |  | $ | 1,650 |  |  | $ | — |  |  | $ | 1,650 |  |

[0001032975-17-000005:mdna:145]
[same as prior period, unchanged from 0001032975-16-000106:mdna:144]

[0001032975-17-000005:mdna:146]
Other Income (Expense), Net

[0001032975-17-000005:mdna:147]
Other income (expense), net for the three and nine months ended December 31, 2016 and 2015 was as follows (in thousands):

[0001032975-17-000005:mdna:148]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Investment gain (loss) related to deferred compensation plan |  | $ | 76 |  |  | $ | 348 |  |  | $ | 672 |  |  | $ | (278 | ) |
| Currency exchange gain (loss), net |  | 2,174 |  |  | 442 |  |  | (75 | ) |  | (690 | ) |
| Other |  | 384 |  |  | 72 |  |  | 346 |  |  | 74 |  |
|  |  | $ | 2,634 |  |  | $ | 862 |  |  | $ | 943 |  |  | $ | (894 | ) |

[0001032975-17-000005:mdna:149]
[same as prior period, unchanged from 0001032975-16-000106:mdna:148]

[0001032975-17-000005:mdna:150]
[same as prior period, unchanged from 0001032975-16-000106:mdna:150]

[0001032975-17-000005:mdna:151]
The provision for income taxes and effective tax rates for the three and nine months ended December 31, 2016 and 2015 were as follows (Dollars in thousands):

[0001032975-17-000005:mdna:152]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Provision for income taxes |  | $ | 1,647 |  |  | $ | 1,442 |  |  | $ | 10,297 |  |  | $ | 7,006 |  |
| Effective income tax rate |  | 1.7 | % |  | 2.1 | % |  | 5.8 | % |  | 5.9 | % |

[0001032975-17-000005:mdna:153]
The change in the effective income tax rate for the three and nine months ended December 31, 2016, compared to the three and nine months ended December 31, 2015, is due to the mix of income and losses in the various tax jurisdictions in which we operate. In the three months ended December 31, 2016 and December 31,

[0001032975-17-000005:mdna:154]
41

[0001032975-17-000005:mdna:155]
2015, there was a discrete tax benefit of $9.4 million and $8.4 million, respectively, from the reversal of uncertain tax positions from the expiration of statutes of limitations. In the nine months ended December 31, 2015, there was an additional discrete tax benefit of $2.2 million from the preferential income tax rate reduction pursuant to the High and New Technology Enterprise Program in China.

[0001032975-17-000005:mdna:156]
As of December 31 and March 31, 2016, the total amount of unrecognized tax benefits due to uncertain tax positions was $66.6 million and $69.9 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-17-000005:mdna:157]
[same as prior period, unchanged from 0001032975-16-000106:mdna:155]

[0001032975-17-000005:mdna:158]
[same as prior period, unchanged from 0001032975-16-000106:mdna:156]

[0001032975-17-000005:mdna:159]
As of December 31, 2016, we had cash and cash equivalents of $513.6 million, compared to $519.2 million as of March 31, 2016. Our cash and cash equivalents consist of bank demand deposits and short-term time deposits, of which 58% is held in Switzerland, 15% is held in Germany, 12% is held in Hong Kong and China, 6% is held in the United Kingdom, and 9% is held in the United States and various other countries. We do not expect to incur any material adverse tax impact, except for what has been recognized, or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-17-000005:mdna:160]
As of December 31, 2016, our working capital was $478.7 million, compared to $511.3 million as of March 31, 2016. The decrease was primarily due to higher accounts payable and accrued and other current liabilities, partially offset by higher accounts receivable and net inventory balances because of seasonality.

[0001032975-17-000005:mdna:161]
During the nine months ended December 31, 2016, we generated $234.3 million in cash from operating activities. Our main cash inflows came from net income and increases in accounts payable and accrued liabilities, partially offset by increases in accounts receivable and inventories.  Net cash used in investing activities was $90.2 million, primarily due to $67.0 million of purchase price (net of cash acquired) for the business acquisitions (see "Note 3 - Business Acquisitions" to the condensed consolidated financial statements), including a working capital adjustment and payment of a line-of-credit on behalf of Jaybird, and $23.4 million of capital expenditures in computer hardware and software, tooling and equipment. Net cash used in financing activities was $143.2 million, primarily related to our dividend payment of $93.1 million, share repurchases of $63.8 million and tax withholdings related to net share settlements of restricted stock units ("RSUs") of $13.1 million, partially offset by $20.4 million of proceeds from sales of shares upon exercise of options and purchase rights.

[0001032975-17-000005:mdna:162]
We had several uncommitted, unsecured bank lines of credit aggregating $43.2 million as of December 31, 2016. We have not drawn down on these lines of credit as of December 31, 2016. There are no financial covenants under these lines of credit with which we must comply. As of December 31, 2016, we had outstanding bank guarantees of $18.3 million under these lines of credit.

[0001032975-17-000005:mdna:163]
The following table summarizes our condensed consolidated statements of cash flows on a total company basis (in thousands):

[0001032975-17-000005:mdna:164]
|  |  | Nine Months Ended December 31, |
|  |  | 2016 |  | 2015 |
| Net cash provided by operating activities |  | $ | 234,290 |  |  | $ | 150,846 |  |
| Net cash used in investing activities |  | (90,240 | ) |  | (52,269 | ) |
| Net cash used in financing activities |  | (143,199 | ) |  | (125,423 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (6,468 | ) |  | (1,205 | ) |
| Net decrease in cash and cash equivalents |  | $ | (5,617 | ) |  | $ | (28,051 | ) |

[0001032975-17-000005:mdna:165]
| The following amounts reflected in the table above are from discontinued operations: |  |  |
| Depreciation |  | $ | — |  |  | $ | 2,207 |  |
| Amortization of other intangible assets |  | $ | — |  |  | $ | 1,089 |  |
| Share-based compensation expense |  | $ | — |  |  | $ | 584 |  |
| Purchases of property, plant and equipment |  | $ | — |  |  | $ | 1,431 |  |
| Cash and cash equivalents, beginning of the period |  | $ | — |  |  | $ | 3,659 |  |
| Cash and cash equivalents, end of the period |  | $ | — |  |  | $ | 3,905 |  |

[0001032975-17-000005:mdna:166]
[same as prior period, unchanged from 0001032975-16-000106:mdna:164]

[0001032975-17-000005:mdna:167]
The following table presents selected financial information and statistics as of December 31, 2016 and 2015 (Dollars in thousands):

[0001032975-17-000005:mdna:168]
|  |  | Three Months EndedDecember 31, |
|  |  | 2016 |  | 2015 |
| Accounts receivable, net |  | $ | 277,677 |  |  | $ | 284,089 |  |
| Inventories |  | $ | 250,286 |  |  | $ | 239,962 |  |
| Days sales in accounts receivable (“DSO”) (Days) (1) |  | 37 |  |  | 41 |  |
| Inventory turnover (“ITO”) (x)(2) |  | 6.7 |  |  | 6.9 |  |

[0001032975-17-000005:mdna:169]
[same as prior period, unchanged from 0001032975-16-000106:mdna:167]

[0001032975-17-000005:mdna:170]
[same as prior period, unchanged from 0001032975-16-000106:mdna:168]

[0001032975-17-000005:mdna:171]
Days sales in accounts receivable decreased from 41 days for the three months ended December 31, 2015 to 37 days for the three months ended December 31, 2016, primarily due to improvements in the efficiency and effectiveness of collection efforts.

[0001032975-17-000005:mdna:172]
Inventory turnover for the three months ended December 31, 2016 was slightly lower compared to the same period of the prior fiscal year. The increase in inventories compared with December 31, 2015 was primarily driven by the Jaybird Acquisition and Saitek Acquisition that occurred in the nine months ended December 31, 2016, partially offset by our continuing efforts in demand planning and production planning. If we are not successful in launching and phasing in our new products, including products from acquisitions, during the current fiscal year, or we are not able to sell these products at the prices planned, it could have a material impact on our revenue, gross profit margin, operating income, operating cash flow, and inventory turnover in the future.

[0001032975-17-000005:mdna:173]
[same as prior period, unchanged from 0001032975-16-000106:mdna:171]

[0001032975-17-000005:mdna:174]
The following table presents information on our cash flows from investing activities during the nine months ended December 31, 2016 and 2015 (in thousands):

[0001032975-17-000005:mdna:175]
|  |  | Nine Months Ended December 31, |
|  |  | 2016 |  | 2015 |
| Purchases of property, plant and equipment |  | $ | (23,372 | ) |  | $ | (50,443 | ) |
| Investment in privately held companies |  | (640 | ) |  | (2,099 | ) |
| Acquisitions, net of cash acquired |  | (66,987 | ) |  | — |  |
| Release of restricted cash |  | 715 |  |  | — |  |
| Purchases of trading investments |  | (5,868 | ) |  | (4,395 | ) |
| Proceeds from sales of trading investments |  | 5,912 |  |  | 4,668 |  |
| Net cash used in investing activities |  | $ | (90,240 | ) |  | $ | (52,269 | ) |

[0001032975-17-000005:mdna:176]
Our expenditures for property, plant and equipment during the nine months ended December 31, 2016 and 2015 were primarily for computer hardware and software, tooling, equipment and leasehold improvements. The decrease in purchases of property, plant and equipment mainly arose from the building of production lines during the nine months ended December 31, 2015, to accommodate our in-house manufacturing of certain products, compared with purchase from third parties, to align with our cost-saving goal.

[0001032975-17-000005:mdna:177]
Our payments for the acquisitions, net of cash acquired, during the nine months ended December 31, 2016, were for the Jaybird Acquisition and the Saitek Acquisition during the period (refer to "Note 3 - Business Acquisitions" to the condensed consolidated financial statements).

[0001032975-17-000005:mdna:178]
The purchases and sales of trading investments in the nine months ended December 31, 2016 and 2015 represented mutual fund and money market fund activities directed by participants in a deferred compensation plan offered by one of our subsidiaries. The mutual funds and money market funds are held in a Rabbi trust.

[0001032975-17-000005:mdna:179]
[same as prior period, unchanged from 0001032975-16-000106:mdna:177]

[0001032975-17-000005:mdna:180]
The following table presents information on our cash flows from financing activities during the nine months ended December 31, 2016 and 2015 on a total company basis (in thousands):

[0001032975-17-000005:mdna:181]
|  |  | Nine Months Ended December 31, |
|  |  | 2016 |  | 2015 |
| Payment of cash dividends |  | $ | (93,093 | ) |  | $ | (85,915 | ) |
| Purchases of treasury shares |  | (63,764 | ) |  | (48,802 | ) |
| Proceeds from sales of shares upon exercise of options and purchase rights |  | 20,355 |  |  | 12,562 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (13,054 | ) |  | (5,357 | ) |
| Excess tax benefits from share-based compensation |  | 6,357 |  |  | 2,089 |  |
| Net cash used in financing activities |  | $ | (143,199 | ) |  | $ | (125,423 | ) |

[0001032975-17-000005:mdna:182]
During the nine months ended December 31, 2016, we declared and paid cash dividends of approximately CHF 0.56 (USD equivalent of approximately $0.57) per common share, totaling approximately $93.1 million in U.S. Dollars, out of retained earnings.  During the nine months ended December 31, 2015, we declared and paid cash dividends of approximately CHF 0.51 (USD equivalent of approximately $0.53) per common share, totaling approximately $85.9 million in U.S. Dollars, out of retained earnings.

[0001032975-17-000005:mdna:183]
During the nine months ended December 31, 2016 and 2015, 3.3 million and 3.5 million shares were repurchased for $63.8 million and $48.8 million, respectively.

[0001032975-17-000005:mdna:184]
During the nine months ended December 31, 2016 and 2015, $13.1 million and $5.4 million, respectively, were paid for tax withholding related to the vesting for RSUs.

[0001032975-17-000005:mdna:185]
[same as prior period, unchanged from 0001032975-16-000106:mdna:184]

[0001032975-17-000005:mdna:186]
[same as prior period, unchanged from 0001032975-16-000106:mdna:185]

[0001032975-17-000005:mdna:187]
[same as prior period, unchanged from 0001032975-16-000106:mdna:186]

[0001032975-17-000005:mdna:188]
In March 2014, our Board of Directors approved a new share buyback program, which authorizes us to purchase up to $250.0 million of our own shares. Although we enter into trading plans for systematic repurchases (e.g. 10b5-1 trading plans) from time to time, our share buyback program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a

[0001032975-17-000005:mdna:189]
period of three years. Shares may be repurchased from time to time on the open market through block trades or otherwise. Opportunistic share repurchases may be started or stopped at any time without prior notice depending on market conditions and other factors. As of December 31, 2016, the remaining amount that may be repurchased under the program is $114.6 million.

[0001032975-17-000005:mdna:190]
As noted in "Note 3 - Business Acquisitions" to our condensed consolidated financial statements, we acquired all of the equity interest of Jaybird for a purchase price of $54.2 million, including a working capital adjustment and payment of a line-of-credit on behalf of Jaybird, with an additional earn-out of up to $45 million based on the achievement of certain net revenue growth targets over two years starting July 2016. If the net revenue growth targets are met, the Company will pay a maximum of $25 million and $20 million in fiscal years 2018 and 2019, respectively.

[0001032975-17-000005:mdna:191]
[same as prior period, unchanged from 0001032975-16-000106:mdna:189]

[0001032975-17-000005:mdna:192]
We have changed the payment frequency of our employee performance bonus plan from semi-annual payment to annual payment. The full year bonus for fiscal year 2017 is expected to be made in the first quarter of fiscal year 2018, and the operating cash flow for that period could be negative as a result.

[0001032975-17-000005:mdna:193]
[same as prior period, unchanged from 0001032975-16-000106:mdna:190]

[0001032975-17-000005:mdna:194]
[same as prior period, unchanged from 0001032975-16-000106:mdna:191]

[0001032975-17-000005:mdna:195]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. The remaining terms on our non-cancelable operating leases expire in various years through 2030. Our asset retirement obligations on these leases as of December 31, 2016 were not material.

[0001032975-17-000005:mdna:196]
[same as prior period, unchanged from 0001032975-16-000106:mdna:193]

[0001032975-17-000005:mdna:197]
As of December 31, 2016, we had fixed purchase commitments for inventory purchases made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. Fixed purchase commitments for capital expenditures primarily relate to commitments for tooling for new and existing products, computer hardware, leasehold and improvements. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-17-000005:mdna:198]
[same as prior period, unchanged from 0001032975-16-000106:mdna:195]

[0001032975-17-000005:mdna:199]
[same as prior period, unchanged from 0001032975-16-000106:mdna:196]

[0001032975-17-000005:mdna:200]
[same as prior period, unchanged from 0001032975-16-000106:mdna:197]

[0001032975-17-000005:mdna:201]
[same as prior period, unchanged from 0001032975-16-000106:mdna:198]

[0001032975-17-000005:mdna:202]
[same as prior period, unchanged from 0001032975-16-000106:mdna:199]

[0001032975-17-000005:mdna:203]
In April 2016, we entered into a settlement with the SEC related to the accounting for Revue inventory valuation reserves that resulted in the restatement described in the Fiscal Year 2014 Annual Report on Form 10-K,

[0001032975-17-000005:mdna:204]
revision to our consolidated financial statements concerning warranty accruals and amortization of intangible assets presented in our Amended Annual Report on Form 10-K/A, filed on August 7, 2013, and our transactions with a distributor for fiscal year 2007 through fiscal year 2009.  We entered into the settlement without admitting or denying the findings of the SEC’s investigation and paid a civil penalty of $7.5 million. This amount was paid in April 2016.

[0001032975-17-000005:mdna:205]
[same as prior period, unchanged from 0001032975-16-000106:mdna:201]

[0001032975-17-000005:mdna:206]
Logitech Europe S.A., one of our wholly owned subsidiaries, guaranteed payments of third-party contract manufacturers' purchase obligations. As of December 31, 2016, the maximum amount of this guarantee was $3.8 million, of which $1.7 million of guaranteed purchase obligations were outstanding.

[0001032975-17-000005:mdna:207]
[same as prior period, unchanged from 0001032975-16-000106:mdna:203]

[0001032975-17-000005:mdna:208]
We indemnify certain of our suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2016, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-17-000005:mdna:209]
[same as prior period, unchanged from 0001032975-16-000106:mdna:205]

[0001032975-17-000005:mdna:210]
The stock purchase agreement that we entered into in connection with the investment by three venture capital firms in Lifesize contains representations, warranties and covenants of Logitech and Lifesize to the Investors. Subject to certain limitations, we have agreed to indemnify the Investors and certain persons related to the Investors for certain losses resulting from breaches of or inaccuracies in such representations, warranties and covenants as well as certain other obligations, including third party expenses, restructuring costs and pre-closing tax obligations of Lifesize.

[0001032975-17-000005:mdna:211]
Legal Proceedings

[0001032975-17-000005:mdna:212]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of our business. We are currently subject to several such claims and a small number of legal proceedings. We believe that these matters lack merit and we intend to vigorously defend against them. Based on currently available information, we do not believe that resolution of pending matters will have a material adverse effect on our financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that our defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on our business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against us, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect our business.
