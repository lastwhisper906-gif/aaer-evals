# LOGI notes — 0001032975-17-000005


## logi:ScheduleOfBalanceSheetComponentsAssetsTableTextBlock

[0001032975-17-000005:notes:1]
The following table presents the components of certain balance sheet asset amounts as of December 31 and March 31, 2016 (in thousands):

[0001032975-17-000005:notes:2]
|  |  | December 31,2016 |  | March 31,2016 |
| Accounts receivable, net: |  |  |  |  |  |  |
| Accounts receivable |  | $ | 528,029 |  |  | $ | 332,553 |  |
| Allowance for doubtful accounts |  | (597 | ) |  | (667 | ) |
| Allowance for sales returns |  | (22,215 | ) |  | (18,526 | ) |
| Allowance for cooperative marketing arrangements |  | (41,006 | ) |  | (28,157 | ) |
| Allowance for customer incentive programs |  | (83,141 | ) |  | (60,872 | ) |
| Allowance for pricing programs |  | (103,393 | ) |  | (81,553 | ) |
|  |  | $ | 277,677 |  |  | $ | 142,778 |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 28,484 |  |  | $ | 48,489 |  |
| Finished goods |  | 221,802 |  |  | 180,297 |  |
|  |  | $ | 250,286 |  |  | $ | 228,786 |  |
| Other current assets: |  |  |  |  |  |  |
| Income tax and value-added tax receivables |  | $ | 21,237 |  |  | $ | 22,572 |  |
| Prepaid expenses and other assets |  | 22,102 |  |  | 12,916 |  |
|  |  | $ | 43,339 |  |  | $ | 35,488 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |
| Property, plant and equipment at cost |  | $ | 373,097 |  |  | 371,212 |  |
| Less: accumulated depreciation and amortization |  | (288,903 | ) |  | (278,352 | ) |
|  |  | $ | 84,194 |  |  | $ | 92,860 |  |
| Other assets: |  |  |  |  |  |  |
| Deferred tax assets |  | $ | 55,773 |  |  | $ | 56,208 |  |
| Trading investments for deferred compensation plan |  | 14,724 |  |  | 14,836 |  |
| Investments held in privately held companies |  | 10,434 |  |  | 9,247 |  |
| Other assets |  | 4,797 |  |  | 6,525 |  |
|  |  | $ | 85,728 |  |  | $ | 86,816 |  |


## logi:ScheduleOfBalanceSheetComponentsLiabilityTableTextBlock

[0001032975-17-000005:notes:3]
The following table presents the components of certain balance sheet liability amounts as of December 31 and March 31, 2016 (in thousands):

[0001032975-17-000005:notes:4]
|  |  | December 31,2016 |  | March 31,2016 |
| Accrued and other current liabilities: |  |  |  |  |  |  |
| Accrued personnel expenses * |  | $ | 83,645 |  |  | $ | 46,025 |  |
| Indirect customer incentive programs |  | 51,224 |  |  | 28,721 |  |
| Warranty accrual |  | 13,692 |  |  | 11,880 |  |
| Employee benefit plan obligation |  | 1,899 |  |  | 1,285 |  |
| Income taxes payable |  | 7,163 |  |  | 1,553 |  |
| Contingent consideration for business acquisition - current portion |  | 1,688 |  |  | — |  |
| Other current liabilities |  | 88,652 |  |  | 84,300 |  |
|  |  | $ | 247,963 |  |  | $ | 173,764 |  |
| Non-current liabilities: |  |  |  |  |  |  |
| Warranty accrual |  | $ | 8,429 |  |  | $ | 8,500 |  |
| Obligation for deferred compensation plan |  | 14,724 |  |  | 14,836 |  |
| Employee benefit plan obligation |  | 50,843 |  |  | 53,909 |  |
| Deferred rent |  | 8,323 |  |  | 9,424 |  |
| Deferred tax liability |  | 1,665 |  |  | 1,665 |  |
| Contingent consideration for business acquisition - non-current portion |  | 6,387 |  |  | — |  |
| Other non-current liabilities |  | 1,338 |  |  | 1,201 |  |
|  |  | $ | 91,709 |  |  | $ | 89,535 |  |

[0001032975-17-000005:notes:5]
* The increase in accrued personnel expenses as of December 31, 2016 compared with March 31, 2016 was primarily due to change in the payment frequency of our cash bonus plan from semi-annual to annual, and a strong performance for the first nine months of fiscal year 2017.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-17-000005:notes:6]
[same as prior period, unchanged from 0001032975-16-000106:notes:5]

[0001032975-17-000005:notes:7]
[same as prior period, unchanged from 0001032975-16-000106:notes:6]

[0001032975-17-000005:notes:8]
[same as prior period, unchanged from 0001032975-16-000106:notes:7]

[0001032975-17-000005:notes:9]
[same as prior period, unchanged from 0001032975-16-000106:notes:8]

[0001032975-17-000005:notes:10]
[same as prior period, unchanged from 0001032975-16-000106:notes:9]

[0001032975-17-000005:notes:11]
[same as prior period, unchanged from 0001032975-16-000106:notes:10]

[0001032975-17-000005:notes:12]
[same as prior period, unchanged from 0001032975-16-000106:notes:11]

[0001032975-17-000005:notes:13]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and nine months ended December 31, 2016 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2017, or any future periods.

[0001032975-17-000005:notes:14]
[same as prior period, unchanged from 0001032975-16-000106:notes:13]

[0001032975-17-000005:notes:15]
Certain amounts from the comparative period in the accompanying unaudited condensed consolidated financial statements have been reclassified to conform to the condensed consolidated financial statement presentation as of and for the three and nine months ended December 31, 2016.

[0001032975-17-000005:notes:16]
[same as prior period, unchanged from 0001032975-16-000106:notes:15]

[0001032975-17-000005:notes:17]
There have been no substantial changes in the Company’s significant accounting policies during the nine months ended December 31, 2016 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2016.

[0001032975-17-000005:notes:18]
[same as prior period, unchanged from 0001032975-16-000106:notes:17]

[0001032975-17-000005:notes:19]
[same as prior period, unchanged from 0001032975-16-000106:notes:18]

[0001032975-17-000005:notes:20]
[same as prior period, unchanged from 0001032975-16-000106:notes:19]

[0001032975-17-000005:notes:21]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers (Topic 606)" ("ASU 2014-09"). ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. Under the new model, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In addition, the new standard requires that reporting companies disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. ASU 2014-09 was originally to be effective for the Company on April 1, 2017. In July 2015, the FASB affirmed a one-year deferral of the effective date of the new revenue standard. The new standard will become effective for the Company on April 1, 2018. Early application is permitted but not before the original effective date of annual periods beginning after December 15, 2016. The new standard is required to be applied retrospectively to each prior reporting period presented or retrospectively with the cumulative effect of initially applying it recognized at the date of initial application. Subsequently, the FASB has issued the following standards related to ASU 2014-09: ASU No. 2016-08, "Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations" (“ASU 2016-08”); ASU No. 2016-10, "Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing" (“ASU 2016-10”); and ASU No. 2016-12, "Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients" (“ASU 2016-12”). The Company must adopt ASU 2016-08, ASU 2016-10 and ASU 2016-12 with ASU 2014-09 (collectively, the “new revenue standards”). The Company has not yet selected a transition method and is in process of assessing all potential impacts of the new standard.  The new revenue standard will be adopted effective April 1, 2018.

[0001032975-17-000005:notes:22]
In July 2015, the FASB issued ASU No. 2015-11, "Simplifying the Measurement of Inventory (Topic 330)" ("ASU 2015-11"). Topic 330, Inventory, currently requires an entity to measure inventory at the lower of cost or market, with market value represented by replacement cost, net realizable value or net realizable value less a normal profit margin. The amendments in ASU 2015-11 require an entity to measure inventory at the lower of cost or net realizable value. ASU 2015-11 is effective in the first quarter of fiscal year 2018 for the Company, with early adoption permitted. The Company does not expect to early adopt this guidance and does not expect the adoption of this guidance to have a material impact on its condensed consolidated financial statements.

[0001032975-17-000005:notes:23]
In January 2016, the FASB issued ASU 2016-01 “Financial Instruments- Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10)”. The guidance is effective in the first quarter of fiscal year 2018 for the Company, with early adoption permitted. The Company does not expect to early adopt this guidance and does not believe that the adoption of this guidance will have a material impact on its condensed consolidated financial statements.

[0001032975-17-000005:notes:24]
In February 2016, the FASB issued ASU 2016-02 "Leases (Topic 842)" ("ASU 2016-02"), which requires the recognition of lease assets and lease liabilities arising from operating leases in the statement of financial position. This guidance is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. The Company is evaluating the full effect that ASU 2016-02 will have on its condensed consolidated financial statements and will adopt the standard effective April 1, 2019.

[0001032975-17-000005:notes:25]
In March 2016, the FASB issued ASU 2016-09 "Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting" ("ASU 2016-09"). The amendment simplifies several aspects of the accounting for share-based payments, including immediate recognition of all excess tax benefits and deficiencies in the income statement, changing the threshold to qualify for equity classification up to the employees' maximum statutory tax rates, allowing an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures as they occur, and clarifying the classification on the statement of cash flows for the excess tax benefit and employee taxes paid when an employer withholds shares for tax-withholding purposes. ASU 2016-09 is effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. Early adoption is permitted in any interim or annual period. The Company will adopt this standard effective April 1, 2017 and is in the process of evaluating the effect that ASU 2016-09 will have on its condensed consolidated financial statements.

[0001032975-17-000005:notes:26]
In August 2016, the FASB issued ASU 2016-15 "Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments" ("ASU 2016-15"), which gives guidance and reduces diversity in practice with respect to certain types of cash flows. The Company has early adopted this guidance during the second quarter of fiscal year 2017 and the adoption did not impact its condensed consolidated financial statements.

[0001032975-17-000005:notes:27]
In October 2016, the FASB issued ASU 2016-16 "Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory"  ("ASU 2016-16"), which eliminates the deferral of income tax effects of intra-entity asset transfers until the transferred asset is sold to an unrelated party or recovered through use.  ASU 2016-16, however, does not apply to intra-entity transfer of inventory.  The guidance is effective for annual periods beginning after December 15, 2017 and interim reporting periods within those annual periods.  Early adoption is permitted but only in the first interim period of a fiscal year.  The cumulative effect of change on equity upon adoption is to be quantified under the modified retrospective approach and recorded as of the beginning of the period of adoption.  The Company is evaluating the full effect that ASU 2016-16 will have on its condensed consolidated financial statements and will adopt the standard effective April 1, 2018.

[0001032975-17-000005:notes:28]
In December 2016, the FASB issued ASU 2016-18 "Statement of Cash Flows (Topic 230): Restricted Cash" ("ASU 2016-18"), which requires that a statement of cash flows explains the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents.  The standard is effective for annual periods beginning after December 15, 2017 and interim reporting periods within those annual periods, with early adoption permitted. The adoption of this standard should be applied using a retrospective transition method to each period presented. The Company does not expect the adoption of ASU 2016-18 will have a material impact on its condensed consolidated financial statements and is evaluating the timing of adoption of this standard.

[0001032975-17-000005:notes:29]
In January 2017, the FASB issued ASU 2017-04, "Simplifying the Test for Goodwill Impairment (Topic 330)"("ASU 2017-04"),  which removes Step 2 from the goodwill impairment test. The standard will be effective for the Company for annual or any interim goodwill impairments in fiscal year beginning December 15, 2019, with early adoption permitted. The Company does not expect the adoption of ASU 2017-14 will have an impact on its condensed consolidated financial statements and is evaluating the timing of adoption of this standard.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001032975-17-000005:notes:30]
[same as prior period, unchanged from 0001032975-16-000106:notes:26]

[0001032975-17-000005:notes:31]
[same as prior period, unchanged from 0001032975-16-000106:notes:27]

[0001032975-17-000005:notes:32]
On April 20, 2016 (the "Acquisition Date"), the Company acquired all of the equity interest of JayBird, LLC (“Jaybird”), a Utah limited liability company that develops Bluetooth earbuds, activity trackers, and accessories for sports and active lifestyles, for a purchase price of $54.2 million in cash, including a working capital adjustment and payment of a line-of-credit on behalf of Jaybird, with an additional earn-out of up to $45.0 million based on the achievement of certain net revenue growth targets over approximately a two year period (the "Jaybird Acquisition").  If the net revenue growth targets are met, the Company will pay a maximum of $25.0 million and $20.0 million in fiscal years 2018 and 2019, respectively. The Jaybird Acquisition is expected to accelerate the Company's entry into the wireless wearables space.

[0001032975-17-000005:notes:33]
[same as prior period, unchanged from 0001032975-16-000106:notes:29]

[0001032975-17-000005:notes:34]
[same as prior period, unchanged from 0001032975-16-000106:notes:30]

[0001032975-17-000005:notes:35]
The fair value of the earn-out payments at the Acquisition Date was determined by providing risk-adjusted earnings projections using a Monte Carlo Simulation, which includes inputs that are not observable in the market, and therefore representing a Level 3 measurement. The fair value of this earn-out is discussed further in "Note 8 - Fair Value Measurements" to the condensed consolidated financial statements.

[0001032975-17-000005:notes:36]
The following table summarizes the preliminary allocation of the total consideration transferred to the estimated fair values of the assets acquired and liabilities assumed at the Acquisition Date (in thousands):

[0001032975-17-000005:notes:37]
[same as prior period, unchanged from 0001032975-16-000106:notes:33]

[0001032975-17-000005:notes:38]
[same as prior period, unchanged from 0001032975-16-000106:notes:34]

[0001032975-17-000005:notes:39]
[same as prior period, unchanged from 0001032975-16-000106:notes:35]

[0001032975-17-000005:notes:40]
The Company included Jaybird's estimated fair value of assets acquired and liabilities assumed in its condensed consolidated balance sheets beginning April 20, 2016. The results of operations for Jaybird have been included in the Company's condensed consolidated statements of operations from the Acquisition Date.

[0001032975-17-000005:notes:41]
[same as prior period, unchanged from 0001032975-16-000106:notes:37]

[0001032975-17-000005:notes:42]
[same as prior period, unchanged from 0001032975-16-000106:notes:38]

[0001032975-17-000005:notes:43]
Except for IPR&D, intangible assets acquired as a result of the Jaybird Acquisition are being amortized over their estimated useful lives using the straight-line method of amortization. Amortization of acquired developed technology of $1.2 million and $3.2 million, respectively, during the three and nine months ended December 31, 2016 is included in "Amortization of intangible assets and purchase accounting effect of inventory" in the gross profit of the condensed consolidated statements of operations. Amortization of the intangible assets of customer relationship and trade name of $1.0 million and $2.8 million, respectively, during the three and nine months ended December 31, 2016 is included in "amortization of intangible assets and acquisition-related costs" in the operating expense of the condensed consolidated statements of operations.

[0001032975-17-000005:notes:44]
[same as prior period, unchanged from 0001032975-16-000106:notes:40]

[0001032975-17-000005:notes:45]
[same as prior period, unchanged from 0001032975-16-000106:notes:41]

[0001032975-17-000005:notes:46]
[same as prior period, unchanged from 0001032975-16-000106:notes:42]

[0001032975-17-000005:notes:47]
[same as prior period, unchanged from 0001032975-16-000106:notes:43]

[0001032975-17-000005:notes:48]
[same as prior period, unchanged from 0001032975-16-000106:notes:44]

[0001032975-17-000005:notes:49]
The IPR&D is accounted for as an indefinite-lived intangible asset and is not amortized until completion or abandonment of the associated research and development efforts. If the research and development efforts are completed, the IPR&D intangible asset will be amortized over the estimated useful life to be determined as of the date the efforts are completed.  IPR&D is tested for impairment annually or periodically if an indicator of impairment exists during the period until completion. The IPR&D related to the X3 earbuds was released during the third quarter of fiscal year 2017 and will be amortized over its estimated useful life of five years.

[0001032975-17-000005:notes:50]
The Company believes the preliminary value of purchased intangible assets recorded above represent the fair values of, and approximate the amounts a market participant would pay for, these intangible assets as of the Acquisition Date.

[0001032975-17-000005:notes:51]
[same as prior period, unchanged from 0001032975-16-000106:notes:47]

[0001032975-17-000005:notes:52]
On September 15, 2016, the Company completed the acquisition of the Saitek product line for a total cash consideration of approximately $13.0 million (the "Saitek Acquisition"). Out of the total consideration, $6.7 million was attributed to intangible assets, $4.9 million was attributed to goodwill, and $1.4 million was attributed to net tangible assets acquired. The Saitek Acquisition is expected to enhance the breadth and depth of the Company's product offerings and expand the Company's engineering capabilities in simulation products. The amount of goodwill generated from the Saitek Acquisition is deductible for tax purposes and is not material.

[0001032975-17-000005:notes:53]
The Company incurred acquisition-related costs for both the Jaybird Acquisition and the Saitek Acquisition of approximately $0.2 million and $1.5 million, in aggregate, for the three and nine months ended December 31, 2016, respectively. The acquisition-related costs are included in "amortization of intangible assets and acquisition-related costs" in the operating expense of the condensed consolidated statements of operations.

[0001032975-17-000005:notes:54]
For the three and nine months ended December 31, 2016, Jaybird and Saitek contributed a total of $17.4 million and $47.3 million of net sales, respectively.

[0001032975-17-000005:notes:55]
[same as prior period, unchanged from 0001032975-16-000106:notes:50]

[0001032975-17-000005:notes:56]
[same as prior period, unchanged from 0001032975-16-000106:notes:51]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-17-000005:notes:57]
Commitments and Contingencies

[0001032975-17-000005:notes:58]
Product Warranties

[0001032975-17-000005:notes:59]
All of the Company’s peripherals products sold are covered by warranty to be free from defects in material and workmanship.  For products launched prior to April 1, 2014, the standard warranty period was up to five years. Starting from April 1, 2014, the standard warranty for all new products launched was changed to two years from date of purchase for European Countries and generally one year from date of purchase for all other countries.  At the time of sale, the Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. The Company’s estimate of costs to fulfill its warranty obligations is based on historical experience and expectations of future conditions. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly.

[0001032975-17-000005:notes:60]
Changes in the Company’s warranty liability for the three and nine months ended December 31, 2016 and 2015 were as follows (in thousands):

[0001032975-17-000005:notes:61]
|  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Beginning of the period | $ | 21,612 |  |  | $ | 20,399 |  |  | $ | 20,380 |  |  | $ | 21,710 |  |
| Assumed from business acquisition |  |  |  | — |  |  | 1,963 |  |  | — |  |
| Provision | 4,521 |  |  | 2,023 |  |  | 10,861 |  |  | 5,815 |  |
| Settlements | (3,550 | ) |  | (2,763 | ) |  | (10,430 | ) |  | (8,008 | ) |
| Currency impact | (462 | ) |  | (153 | ) |  | (653 | ) |  | (11 | ) |
| End of the period | $ | 22,121 |  |  | $ | 19,506 |  |  | $ | 22,121 |  |  | $ | 19,506 |  |

[0001032975-17-000005:notes:62]
Other Contingencies

[0001032975-17-000005:notes:63]
In April 2016, the Company entered into a settlement with the SEC related to the accounting for Revue inventory valuation reserves that resulted in the restatement described in the Fiscal Year 2014 Annual Report on Form 10-K, revision to its consolidated financial statements concerning warranty accruals and amortization of intangible assets presented in its Amended Annual Report on Form 10-K/A, filed on August 7, 2013, and its transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. The Company entered into the settlement without admitting or denying the findings of the SEC’s investigation and paid a civil penalty of $7.5 million in April 2016.

[0001032975-17-000005:notes:64]
Guarantees

[0001032975-17-000005:notes:65]
Logitech Europe S.A. guaranteed payments of certain third-party contract manufacturers’ purchase obligations. As of December 31, 2016, the maximum amount of this guarantee was $3.8 million, of which $1.7 million of guaranteed purchase obligations were outstanding.

[0001032975-17-000005:notes:66]
Indemnifications

[0001032975-17-000005:notes:67]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2016, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-17-000005:notes:68]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-17-000005:notes:69]
The stock purchase agreement entered on December 28, 2015 in connection with the investment by three venture capital firms in Lifesize, Inc. contains representations, warranties and covenants of Logitech and Lifesize, Inc. to the Investors. Logitech has agreed, subject to certain limitations, to indemnify the Investors and certain persons related to the Investors for certain losses resulting from breaches of or inaccuracies in such representations, warranties and covenants as well as certain other obligations, including third-party expenses, restructuring costs and pre-closing tax obligations of Lifesize.

[0001032975-17-000005:notes:70]
Legal Proceedings

[0001032975-17-000005:notes:71]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-17-000005:notes:72]
[same as prior period, unchanged from 0001032975-16-000106:notes:67]

[0001032975-17-000005:notes:73]
[same as prior period, unchanged from 0001032975-16-000106:notes:68]

[0001032975-17-000005:notes:74]
As of December 31, 2016, the Company offers the 2006 ESPP (2006 Employee Share Purchase Plan (Non-U.S.)), the 1996 ESPP (1996 Employee Share Purchase Plan (U.S.)), the 2006 Plan (2006 Stock Incentive Plan) and the 2012 Plan (2012 Stock Inducement Equity Plan).

[0001032975-17-000005:notes:75]
The following table summarizes the share-based compensation expense and related tax benefit recognized for the three and nine months ended December 31, 2016 and 2015, excluding balances classified as discontinued operations (in thousands):

[0001032975-17-000005:notes:76]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Cost of goods sold |  | $ | 617 |  |  | $ | 464 |  |  | $ | 1,930 |  |  | $ | 1,648 |  |
| Marketing and selling |  | 4,006 |  |  | 2,484 |  |  | 10,687 |  |  | 6,545 |  |
| Research and development |  | 1,176 |  |  | 846 |  |  | 3,007 |  |  | 2,174 |  |
| General and administrative |  | 3,588 |  |  | 2,668 |  |  | 10,730 |  |  | 8,917 |  |
| Restructuring |  | — |  |  | — |  |  | — |  |  | 7 |  |
| Total share-based compensation expense |  | 9,387 |  |  | 6,462 |  |  | 26,354 |  |  | 19,291 |  |
| Income tax benefit |  | (2,391 | ) |  | (1,446 | ) |  | (6,092 | ) |  | (2,479 | ) |
| Total share-based compensation expense, net of income tax |  | $ | 6,996 |  |  | $ | 5,016 |  |  | $ | 20,262 |  |  | $ | 16,812 |  |

[0001032975-17-000005:notes:77]
As of December 31, 2016 and 2015, the Company capitalized $0.6 million and $0.5 million of stock-based compensation expenses as inventory, respectively.

[0001032975-17-000005:notes:78]
[same as prior period, unchanged from 0001032975-16-000106:notes:73]

[0001032975-17-000005:notes:79]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The cost recorded of $2.8 million and $2.8 million for the three months ended December 31, 2016 and 2015, respectively, and $8.4 million and $8.6 million for the nine months ended December 31, 2016 and 2015, respectively, was primarily related to service costs.


## us-gaap:DebtDisclosureTextBlock

[0001032975-17-000005:notes:80]
Financing Arrangements

[0001032975-17-000005:notes:81]
The Company had several uncommitted, unsecured bank lines of credit aggregating $43.2 million as of December 31, 2016. There are no financial covenants under these lines of credit with which the Company must comply. As of December 31, 2016, the Company had outstanding bank guarantees of $18.3 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of December 31, 2016 or March 31, 2016.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-17-000005:notes:82]
[same as prior period, unchanged from 0001032975-16-000106:notes:77]

[0001032975-17-000005:notes:83]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis on the condensed consolidated balance sheets as of December 31, 2016 and March 31, 2016.

[0001032975-17-000005:notes:84]
The fair values of the Company’s derivative instruments not designated as hedging instruments were not material as of December 31, 2016 or March 31, 2016. The following table presents the fair values of the Company’s derivative instruments designated as hedging instruments on a gross basis in other current assets or accrued and other current liabilities on its condensed consolidated balance sheets as of December 31, 2016 and March 31, 2016 (in thousands):

[0001032975-17-000005:notes:85]
|  |  | Derivatives |
|  |  | Asset |  | Liability |
|  |  | December 31,2016 |  | March 31,2016 |  | December 31,2016 |  | March 31,2016 |
| Cash flow hedges |  | $ | 825 |  |  | $ | 10 |  |  | $ | — |  |  | $ | 1,038 |  |

[0001032975-17-000005:notes:86]
The amount of gain (loss) recognized on derivatives not designated as hedging instruments were not material in all periods presented herein. The following table presents the amounts of gains (losses) on the Company’s derivative instruments designated as hedging instruments and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income for the three and nine months ended December 31, 2016 and 2015 (in thousands):

[0001032975-17-000005:notes:87]
|  |  | Three Months EndedDecember 31, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss After Reclassification to Costs of Goods Sold |  | Amount of Loss (Gain) Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Cash flow hedges |  | $ | 2,034 |  |  | $ | (17 | ) |  | $ | (463 | ) |  | $ | 45 |  |

[0001032975-17-000005:notes:88]
|  |  | Nine Months Ended December 31, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss After Reclassification to Costs of Goods Sold |  | Amount of Loss (Gain) Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Cash flow hedges |  | $ | 4,458 |  |  | $ | (3,679 | ) |  | $ | 432 |  |  | $ | (2,443 | ) |

[0001032975-17-000005:notes:89]
[same as prior period, unchanged from 0001032975-16-000106:notes:84]

[0001032975-17-000005:notes:90]
The Company enters into currency exchange forward contracts to hedge against exposure to changes in currency exchange rates related to its subsidiaries’ forecasted inventory purchases. The Company has one entity with a Euro functional currency that purchases inventory in U.S. Dollars. The primary risk managed by using derivative instruments is the currency exchange rate risk. However, there can be no assurance the hedges will offset more than a portion of the financial impact resulting from movements in currency exchange rates. The Company has designated these derivatives as cash flow hedges. These hedging contracts mature within four months, and are denominated in the same currency as the underlying transactions. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. The Company assesses the effectiveness of the hedges by comparing changes in the spot rate of the currency underlying the forward contract with changes in the spot rate of the currency in which the forecasted transaction will be consummated. If the underlying transaction being hedged fails to occur or if a portion of the hedge does not generate offsetting changes in the currency exposure of forecasted inventory purchases, the Company immediately recognizes the gain or loss on the associated financial instrument in other income (expense), net. Such gains and losses were not material during the three and nine months ended December 31, 2016 and 2015. Cash flows from such hedges are classified as operating activities in the condensed consolidated statements of cash flows. The notional amounts of currency exchange forward contracts outstanding related to forecasted inventory purchases were $55.7 million and $39.8 million at December 31, 2016 and March 31, 2016, respectively. The Company estimates that $2.7 million of net gains related to its cash flow hedges included in accumulated other comprehensive loss as of December 31, 2016 will be reclassified into earnings within the next 12 months.

[0001032975-17-000005:notes:91]
[same as prior period, unchanged from 0001032975-16-000106:notes:86]

[0001032975-17-000005:notes:92]
The Company also enters into currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain foreign currency receivables or payables. These contracts generally mature within one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on currency exchange contracts are recognized in other income (expense), net based on the changes in fair value.

[0001032975-17-000005:notes:93]
The notional amounts of currency exchange forward and swap contracts outstanding as of December 31 and March 31, 2016 relating to foreign currency receivables or payables were $86.6 million and $63.7 million, respectively. Open forward and swap contracts outstanding as of December 31, 2016 and March 31, 2016 consisted of contracts in Mexican Pesos, Japanese Yen, British Pounds, Taiwanese Dollars, Canadian Dollars and Australian Dollars to be settled at future dates at pre-determined exchange rates.

[0001032975-17-000005:notes:94]
[same as prior period, unchanged from 0001032975-16-000106:notes:89]


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001032975-17-000005:notes:95]
[same as prior period, unchanged from 0001032975-16-000106:notes:90]

[0001032975-17-000005:notes:96]
During the third quarter of fiscal year 2016, the Company's Board of Directors approved a plan to divest the Lifesize video conferencing business. Subsequently, on December 28, 2015 in the fourth quarter of fiscal year 2016, the Company and Lifesize, Inc.(“Lifesize”), a wholly owned subsidiary of the Company which held the assets of the Company’s video conferencing reportable segment, entered into a stock purchase agreement (the “Stock Purchase Agreement”) with entities affiliated with three venture capital firms - Redpoint Ventures, Sutter Hill Ventures and Meritech Capital Partners (the "Venture Investors").  Pursuant to the terms of the Stock Purchase Agreement, the Company sold 2.5 million shares of Series B Preferred Stock of Lifesize to the Venture Investors for cash proceeds of $2.5 million and retained 12 million non-voting shares of Series A Preferred Stock of Lifesize.  The shares of Series A Preferred Stock of Lifesize retained by the Company represent 37.5% of the total shares outstanding immediately after the closing of the transactions (the "Closing").  Lifesize also issued 17.5 million shares of Series B Preferred Stock to the Venture Investors for cash proceeds of $17.5 million. The shares of Series B Preferred Stock held by the Venture Investors represent 62.5% of the total shares outstanding immediately after the Closing.  In addition, Lifesize reserved 8 million shares of common stock for issuance pursuant to a stock plan to be adopted by Lifesize following the Closing, none of which are issued or outstanding at the Closing. The divestiture of the Lifesize video conferencing business was effective on December 28, 2015. The Stock Purchase Agreement contains representations, warranties and covenants of the parties and includes certain indemnification obligations of the Company to the Venture Investors. See “Note 12 - Commitments and Contingencies” to the condensed consolidated financial statements for more information. The Stock Purchase Agreement also contains certain post-closing working capital adjustments. The Company substantially completed its transition services for Lifesize during the third quarter of fiscal year 2017.

[0001032975-17-000005:notes:97]
[same as prior period, unchanged from 0001032975-16-000106:notes:92]

[0001032975-17-000005:notes:98]
[same as prior period, unchanged from 0001032975-16-000106:notes:93]

[0001032975-17-000005:notes:99]
The following table presents financial results of the video conferencing segment classified as total discontinued operations for the three and nine months ended December 31, 2015 (in thousands):

[0001032975-17-000005:notes:100]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2015 |  | 2015 |
| Net sales |  | $ | 21,553 |  |  | $ | 65,554 |  |
| Cost of goods sold |  | 8,240 |  |  | 24,951 |  |
| Gross profit |  | 13,313 |  |  | 40,603 |  |
| Operating expenses: |  |  |  |  |  |  |
| Marketing and selling |  | 8,877 |  |  | 31,550 |  |
| Research and development |  | 4,924 |  |  | 16,592 |  |
| General and administrative |  | 1,836 |  |  | 5,308 |  |
| Restructuring charges, net |  | 1,064 |  |  | 8,070 |  |
| Total operating expenses |  | 16,701 |  |  | 61,520 |  |
| Operating loss from discontinued operations |  | (3,388 | ) |  | (20,917 | ) |
| Interest and other expense, net |  | (47 | ) |  | (180 | ) |
| Loss from discontinued operations before income taxes |  | (3,435 | ) |  | (21,097 | ) |
| Benefit from income taxes |  | (481 | ) |  | (365 | ) |
| Net loss from discontinued operations |  | $ | (2,954 | ) |  | $ | (20,732 | ) |


## us-gaap:EarningsPerShareTextBlock

[0001032975-17-000005:notes:101]
Net Income Per Share

[0001032975-17-000005:notes:102]
[same as prior period, unchanged from 0001032975-16-000106:notes:97]

[0001032975-17-000005:notes:103]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Net Income (loss): |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 97,465 |  |  | $ | 68,040 |  |  | $ | 166,451 |  |  | $ | 111,352 |  |
| Discontinued operations |  | — |  |  | (2,954 | ) |  | — |  |  | (20,732 | ) |
| Net income |  | $ | 97,465 |  |  | $ | 65,086 |  |  | $ | 166,451 |  |  | $ | 90,620 |  |
| Shares used in net income (loss) per share computation: |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 161,977 |  |  | 162,669 |  |  | 162,070 |  |  | 163,521 |  |
| Effect of potentially dilutive equivalent shares |  | 3,924 |  |  | 2,499 |  |  | 3,141 |  |  | 2,430 |  |
| Weighted average shares outstanding - diluted |  | 165,901 |  |  | 165,168 |  |  | 165,211 |  |  | 165,951 |  |
| Net income (loss) per share - basic: |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.60 |  |  | $ | 0.42 |  |  | $ | 1.03 |  |  | $ | 0.68 |  |
| Discontinued operations |  | — |  |  | (0.02 | ) |  | — |  |  | (0.13 | ) |
| Net income per share - basic |  | $ | 0.60 |  |  | $ | 0.40 |  |  | $ | 1.03 |  |  | $ | 0.55 |  |
| Net income (loss) per share - diluted: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.59 |  |  | $ | 0.41 |  |  | $ | 1.01 |  |  | $ | 0.67 |  |
| Discontinued operations |  | — |  |  | (0.02 | ) |  | — |  |  | (0.12 | ) |
| Net income per share - diluted |  | $ | 0.59 |  |  | $ | 0.39 |  |  | $ | 1.01 |  |  | $ | 0.55 |  |

[0001032975-17-000005:notes:104]
Share equivalents attributable to outstanding stock options and restricted stock units ("RSUs") of 1.7 million and 6.3 million for the three months ended December 31, 2016 and 2015, respectively, and 2.8 million and 6.6 million for the nine months ended December 31, 2016 and 2015, respectively, were anti-dilutive and excluded from the calculation of diluted net income per share.


## us-gaap:FairValueLiabilitiesMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001032975-17-000005:notes:105]
The following table summarizes the change in fair value of the Company’s contingent consideration balance during the three and nine months ended December 31, 2016 and 2015 (in thousands):

[0001032975-17-000005:notes:106]
|  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Beginning of the period | $ | 18,000 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Fair value of contingent consideration upon acquisition | — |  |  | — |  |  | 18,000 |  |  | — |  |
| Change in fair value of contingent consideration | (9,925 | ) |  | — |  |  | (9,925 | ) |  | — |  |
| End of the period | $ | 8,075 |  |  | $ | — |  |  | $ | 8,075 |  |  | $ | — |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-17-000005:notes:107]
[same as prior period, unchanged from 0001032975-16-000106:notes:100]

[0001032975-17-000005:notes:108]
[same as prior period, unchanged from 0001032975-16-000106:notes:101]

[0001032975-17-000005:notes:109]
[same as prior period, unchanged from 0001032975-16-000106:notes:102]

[0001032975-17-000005:notes:110]
[same as prior period, unchanged from 0001032975-16-000106:notes:103]

[0001032975-17-000005:notes:111]
[same as prior period, unchanged from 0001032975-16-000106:notes:104]

[0001032975-17-000005:notes:112]
[same as prior period, unchanged from 0001032975-16-000106:notes:105]

[0001032975-17-000005:notes:113]
|  |  | December 31, 2016 |  | March 31, 2016 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 340,964 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,000 |  |  | $ | — |  |  | $ | — |  |
| Trading investments for deferred compensation plan: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 3,024 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,467 |  |  | $ | — |  |  | $ | — |  |
| Mutual funds |  | 11,700 |  |  | — |  |  | — |  |  | 11,369 |  |  | — |  |  | — |  |
| Total of trading investments for deferred compensation plan |  | $ | 14,724 |  |  | $ | — |  |  | $ | — |  |  | $ | 14,836 |  |  | $ | — |  |  | $ | — |  |
| Currency exchange derivative assets |  | $ | — |  |  | $ | 825 |  |  | $ | — |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related contingent consideration |  | $ | — |  |  | $ | — |  |  | 8,075 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Currency exchange derivative liabilities |  | $ | — |  |  | $ | 69 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,132 |  |  | $ | — |  |

[0001032975-17-000005:notes:114]
[same as prior period, unchanged from 0001032975-16-000106:notes:107]

[0001032975-17-000005:notes:115]
The marketable securities for the Company's deferred compensation plan are recorded at a fair value of $14.7 million and $14.8 million, respectively, as of December 31, 2016 and March 31, 2016, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized trading gains / (losses) related to trading securities for the three or nine months ended December 31, 2016 and 2015 were not material and are included in "other income (expense), net" in the Company's condensed consolidated statements of operations.

[0001032975-17-000005:notes:116]
[same as prior period, unchanged from 0001032975-16-000106:notes:109]

[0001032975-17-000005:notes:117]
The acquisition-related contingent consideration liability arising from the Jaybird Acquisition (see "Note 3 - Business Acquisitions" to the condensed consolidated financial statements for more information) represents the future potential earn-out payments of up to $45 million based on the achievement of certain net revenue targets over approximately a two year period. If the net revenue targets are met, the Company will pay a maximum of $25 million and $20 million in fiscal years 2018 and 2019, respectively. The fair value of the earn-out as of the Acquisition Date was $18 million, which was determined by using a Monte Carlo Simulation that includes significant unobservable inputs such as a risk-adjusted discount rate of 16% and projected net sales of Jaybird over the earn-out period. The fair value is remeasured at each reporting period at the estimated fair value based on the inputs on the date of remeasurement, with the change in fair value recognized as "change in fair value of contingent consideration for business acquisition" in the operating expense section in the condensed consolidated statements of operations. Projected net sales are based on our internal projections, including analysis of the target markets. The fair value of the contingent consideration was decreased to $8.1 million as of December 31, 2016. The change in fair value of contingent consideration results primarily from Jaybird's lower-than-expected net sales during the three months ended December 31, 2016 and revised projected net sales in the remaining earn-out period, primarily driven by supply constraints, an evolving product portfolio and changes in the competitive target market.

[0001032975-17-000005:notes:118]
Although these estimates are based on management’s best knowledge of current events, the estimates could change significantly from period to period. Any changes to the significant unobservable inputs used, including change in the forecast of net sales for the earn-out periods, may result in change in the fair value of contingent consideration, and could have a material impact on future results of operations. Actual payment of contingent consideration in the future could be different from the current estimated fair value of the contingent consideration.

[0001032975-17-000005:notes:119]
[same as prior period, unchanged from 0001032975-16-000106:notes:111]

[0001032975-17-000005:notes:120]
The Company’s non-marketable cost method investments, and non-financial assets, such as goodwill, intangible assets and property, plant and equipment, are recorded at fair value only upon initial recognition or if an impairment is recognized. There were no impairments of long-lived assets during the three and nine months ended December 31, 2016 or 2015.

[0001032975-17-000005:notes:121]
[same as prior period, unchanged from 0001032975-16-000106:notes:113]

[0001032975-17-000005:notes:122]
[same as prior period, unchanged from 0001032975-16-000106:notes:114]

[0001032975-17-000005:notes:123]
The aggregate recorded amount of cost method investments included in other assets as of December 31, 2016 and March 31, 2016 was $7.4 million.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-17-000005:notes:124]
[same as prior period, unchanged from 0001032975-16-000106:notes:116]

[0001032975-17-000005:notes:125]
The Company performed its annual impairment analysis of the goodwill as of December 31, 2016 by performing a qualitative assessment and concluded that it was more likely than not that the fair value of its peripherals reporting unit, the only reportable segment of the Company, exceeded its carrying amount. In assessing the qualitative factors, the Company considered the impact of these key factors: change in industry and competitive environment, growth in market capitalization to $4.0 billion as of December 31, 2016 from $2.5 billion a year ago, and budgeted-to-actual revenue performance from the last twelve months.

[0001032975-17-000005:notes:126]
The following table summarizes the activities in the Company’s goodwill balance during the nine months ended December 31, 2016 (in thousands):

[0001032975-17-000005:notes:127]
| As of March 31, 2016 |  | $ | 218,224 |  |
| Business acquisitions (See Note 3) |  | 31,553 |  |
| Currency impact |  | (56 | ) |
| As of December 31, 2016 |  | $ | 249,721 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-17-000005:notes:128]
[same as prior period, unchanged from 0001032975-16-000106:notes:120]

[0001032975-17-000005:notes:129]
[same as prior period, unchanged from 0001032975-16-000106:notes:121]

[0001032975-17-000005:notes:130]
The income tax provision for the three months ended December 31, 2016 was $1.6 million based on an effective income tax rate of 1.7% of pre-tax income, compared to an income tax provision of $1.4 million based on an effective income tax rate of 2.1% of pre-tax income for the three months ended December 31, 2015. The income tax provision for the nine months ended December 31, 2016 was $10.3 million based on an effective income tax rate of 5.8% of pre-tax income, compared to an income tax provision of $7.0 million based on an effective income tax rate of 5.9% for the nine months ended December 31, 2015.

[0001032975-17-000005:notes:131]
The change in the effective income tax rate for the three and nine months ended December 31, 2016, compared to the three and nine months ended December 31, 2015, is due to the mix of income and losses in the various tax jurisdictions in which the Company operates. In the three months ended December 31, 2016 and December 31, 2015, there was a discrete tax benefit of $9.4 million and $8.4 million, respectively, from the reversal of uncertain tax positions from the expiration of statutes of limitations. In the nine months ended December 31, 2015, there was an additional discrete tax benefit of $2.2 million from the preferential income tax rate reduction pursuant to the High and New Technology Enterprise Program in China.

[0001032975-17-000005:notes:132]
As of December 31 and March 31, 2016, the total amount of unrecognized tax benefits due to uncertain tax positions was $66.6 million and $69.9 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-17-000005:notes:133]
The Company had $55.6 million in non-current income taxes payable and $1.5 million in current income taxes payable, including interest and penalties, related to its income tax liability for uncertain tax positions as of December 31, 2016 compared to $59.7 million in non-current income taxes payable and $0.1 million in current income taxes payable as of March 31, 2016. The Company anticipates a settlement with the tax authorities in a foreign jurisdiction in the next twelve months and reclassed $1.4 million from non-current income taxes payable to current income taxes payable as of December 31, 2016.

[0001032975-17-000005:notes:134]
The Company recognizes interest and penalties related to unrecognized tax positions in income tax expense. As of December 31 and March 31, 2016, the Company had $3.5 million and $3.6 million, respectively, of accrued interest and penalties related to uncertain tax positions.

[0001032975-17-000005:notes:135]
Although the Company has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During fiscal year 2017, the Company will continue to review its tax positions and provide for or reverse unrecognized tax benefits as issues arise. During the next twelve months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. dollar as compared to other currencies. Excluding these factors, uncertain tax positions may decrease by as much as $12.1 million from the lapse of the statutes of limitations in various jurisdictions during the next twelve months.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001032975-17-000005:notes:136]
[same as prior period, unchanged from 0001032975-16-000106:notes:128]

[0001032975-17-000005:notes:137]
|  |  | December 31,2016 |  | March 31,2016 |
| Americas |  | $ | 37,959 |  |  | $ | 40,221 |  |
| EMEA |  | 3,358 |  |  | 3,194 |  |
| Asia Pacific |  | 42,877 |  |  | 49,445 |  |
| Total |  | $ | 84,194 |  |  | $ | 92,860 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001032975-17-000005:notes:138]
[same as prior period, unchanged from 0001032975-16-000106:notes:130]

[0001032975-17-000005:notes:139]
[same as prior period, unchanged from 0001032975-16-000106:notes:131]

[0001032975-17-000005:notes:140]
The following table summarizes restructuring related activities during the three and nine months ended December 31, 2016:

[0001032975-17-000005:notes:141]
|  |  | Restructuring |
|  |  | TerminationBenefits |  | Lease ExitCosts |  | Total |
| Accrual balance at March 31, 2016 |  | $ | 6,275 |  |  | $ | 125 |  |  | $ | 6,400 |  |
| Credits, net |  | (85 | ) |  | — |  |  | (85 | ) |
| Cash payments |  | (1,908 | ) |  | (125 | ) |  | (2,033 | ) |
| Accrual balance at June 30, 2016 |  | $ | 4,282 |  |  | $ | — |  |  | $ | 4,282 |  |
| Charges |  | 74 |  |  | — |  |  | 74 |  |
| Cash payments |  | (1,473 | ) |  | — |  |  | (1,473 | ) |
| Accrual balance at September 30, 2016 |  | $ | 2,883 |  |  | $ | — |  |  | $ | 2,883 |  |
| Credits, net |  | (33 | ) |  | — |  |  | (33 | ) |
| Cash payments |  | (1,200 | ) |  | — |  |  | (1,200 | ) |
| Accrual balance at December 31, 2016 |  | $ | 1,650 |  |  | $ | — |  |  | $ | 1,650 |  |


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001032975-17-000005:notes:142]
Net sales to unaffiliated customers by geographic region (based on the customers’ location) for the three and nine months ended December 31, 2016 and 2015 were as follows (in thousands):

[0001032975-17-000005:notes:143]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Americas |  | $ | 290,724 |  |  | $ | 279,286 |  |  | $ | 753,179 |  |  | $ | 719,735 |  |
| EMEA |  | 233,251 |  |  | 205,827 |  |  | 576,809 |  |  | 494,592 |  |
| Asia Pacific |  | 142,732 |  |  | 135,966 |  |  | 380,887 |  |  | 372,932 |  |
| Total net sales |  | $ | 666,707 |  |  | $ | 621,079 |  |  | $ | 1,710,875 |  |  | $ | 1,587,259 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001032975-17-000005:notes:144]
[same as prior period, unchanged from 0001032975-16-000106:notes:136]

[0001032975-17-000005:notes:145]
|  |  | Accumulated Other Comprehensive Income (Loss) |
|  |  | CumulativeTranslationAdjustment (1) |  | DefinedBenefitPlan (1) |  | DeferredHedgingGains (Losses) |  | Total |
| March 31, 2016 |  | $ | (84,038 | ) |  | $ | (26,171 | ) |  | $ | (1,776 | ) |  | $ | (111,985 | ) |
| Other comprehensive income |  | (7,714 | ) |  | 2,809 |  |  | 4,458 |  |  | (447 | ) |
| December 31, 2016 |  | $ | (91,752 | ) |  | $ | (23,362 | ) |  | $ | 2,682 |  |  | $ | (112,432 | ) |

[0001032975-17-000005:notes:146]
(1)        Tax effect was not significant as of December 31 or March 31, 2016.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001032975-17-000005:notes:147]
Net sales by product categories and sales channels, excluding intercompany transactions, for the three and nine months ended December 31, 2016 and 2015 were as follows (in thousands):

[0001032975-17-000005:notes:148]
|  |  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Mobile Speakers |  | $ | 106,578 |  |  | $ | 85,081 |  |  | $ | 261,046 |  |  | $ | 206,175 |  |
| Audio-PC & Wearables |  | 67,225 |  |  | 57,300 |  |  | 186,058 |  |  | 149,341 |  |
| Gaming |  | 107,181 |  |  | 77,706 |  |  | 242,874 |  |  | 189,000 |  |
| Video Collaboration |  | 35,807 |  |  | 26,216 |  |  | 88,298 |  |  | 67,460 |  |
| Home Control |  | 26,942 |  |  | 25,684 |  |  | 49,916 |  |  | 48,548 |  |
| Pointing Devices |  | 142,166 |  |  | 139,711 |  |  | 382,249 |  |  | 381,364 |  |
| Keyboards & Combos |  | 125,289 |  |  | 116,531 |  |  | 359,824 |  |  | 324,458 |  |
| Tablet & Other Accessories |  | 24,852 |  |  | 35,873 |  |  | 59,351 |  |  | 73,222 |  |
| PC Webcams |  | 30,503 |  |  | 29,648 |  |  | 80,072 |  |  | 74,689 |  |
| Other (1) |  | 164 |  |  | 817 |  |  | 1,187 |  |  | 1,961 |  |
| Total net retail sales |  | 666,707 |  |  | 594,567 |  |  | 1,710,875 |  |  | 1,516,218 |  |
| OEM |  | — |  |  | 26,512 |  |  | — |  |  | 71,041 |  |
| Total net sales |  | $ | 666,707 |  |  | $ | 621,079 |  |  | $ | 1,710,875 |  |  | $ | 1,587,259 |  |

[0001032975-17-000005:notes:149]
[same as prior period, unchanged from 0001032975-16-000106:notes:141]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-17-000005:notes:150]
[same as prior period, unchanged from 0001032975-16-000106:notes:142]

[0001032975-17-000005:notes:151]
The Company has determined that it operates in a single operating segment that encompasses the design, manufacturing and marketing of peripherals for PCs, tablets and other digital platforms. Operating performance measures are provided directly to the Company's Chief Executive Officer (“CEO”), who is considered to be the Company’s Chief Operating Decision Maker (“CODM”). The CEO periodically reviews information such as net sales and operating income (loss) to make business decisions. These operating performance measures do not include restructuring charges (credits), net, share-based compensation expense, amortization of intangible assets, charges from the purchase accounting effect on inventory, acquisition-related costs, investigation and related expenses, or change in fair value of acquisition-related contingent consideration.

[0001032975-17-000005:notes:152]
[same as prior period, unchanged from 0001032975-16-000106:notes:144]

[0001032975-17-000005:notes:153]
The United States and Germany each represented more than 10% of the Company’s total consolidated net sales from continuing operations for the three and nine months ended December 31, 2016. The United States represented more than 10% of the Company’s total consolidated net sales from continuing operations for the three and nine months ended December 31, 2015.

[0001032975-17-000005:notes:154]
Switzerland, the Company’s home domicile, represented 2% of the Company’s total consolidated net sales from continuing operations for all the periods presented herein.

[0001032975-17-000005:notes:155]
Two customer groups of the Company each represented more than 10% of total consolidated sales from continuing operations for all the periods presented herein.

[0001032975-17-000005:notes:156]
Long-lived assets in the United States and China were $37.8 million and $36.5 million, respectively, as of December 31, 2016, and $40.0 million and $44.5 million, respectively, as of March 31, 2016. No other countries represented more than 10% of the Company’s total consolidated long-lived assets as of December 31 or March 31, 2016. Long-lived assets in Switzerland, the Company’s home domicile, were $1.8 million and $1.7 million as of December 31 and March 31, 2016, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-17-000005:notes:157]
[same as prior period, unchanged from 0001032975-16-000106:notes:149]

[0001032975-17-000005:notes:158]
[same as prior period, unchanged from 0001032975-16-000106:notes:150]

[0001032975-17-000005:notes:159]
In March 2014, the Company’s Board of Directors approved the 2014 share buyback program, which authorizes the Company to use up to $250.0 million to purchase its own shares. The Company’s share buyback program is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or trading plan or otherwise. Opportunistic share repurchases may be started or stopped at any time without prior notice depending on market conditions and other factors. During the three months ended December 31, 2016, 0.9 million shares were repurchased for $20.9 million. There were no share repurchases during the three months ended December 31, 2015. During the nine months ended December 31, 2016 and 2015, 3.3 million and 3.5 million shares were repurchased for $63.8 million and $48.8 million, respectively.

[0001032975-17-000005:notes:160]
[same as prior period, unchanged from 0001032975-16-000106:notes:152]

[0001032975-17-000005:notes:161]
During the nine months ended December 31, 2016, the Company declared and paid cash dividends of CHF 0.56 (USD equivalent of $0.57) per common share, totaling $93.1 million on the Company's outstanding common stock. During the nine months ended December 31, 2015, the Company declared and paid cash dividends of CHF 0.51 (USD equivalent of $0.53) per common share, totaling $85.9 million on the Company's outstanding common stock.

[0001032975-17-000005:notes:162]
[same as prior period, unchanged from 0001032975-16-000106:notes:154]

[0001032975-17-000005:notes:163]
[same as prior period, unchanged from 0001032975-16-000106:notes:155]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-17-000005:notes:164]
[same as prior period, unchanged from 0001032975-16-000106:notes:156]
