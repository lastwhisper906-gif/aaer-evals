# LOGI 8-K — 0001032975-24-000004 filed 2024-01-23

## item codes, every 8-K on or before 2024-01-25

- 2024-01-23 0001032975-24-000004 — 2.02, 9.01
- 2023-10-30 0001032975-23-000082 — 5.02, 9.01
- 2023-10-24 0001032975-23-000075 — 2.02, 9.01
- 2023-09-15 0001032975-23-000072 — 5.07, 8.01
- 2023-07-25 0001032975-23-000050 — 2.02, 9.01
- 2023-06-30 0001032975-23-000037 — 5.02 — amendment, the index does not say of what
- 2023-06-30 0001032975-23-000036 — 5.02
- 2023-06-13 0001032975-23-000030 — 5.02, 7.01, 9.01
- 2023-05-02 0001032975-23-000015 — 2.02, 9.01
- 2023-01-30 0001032975-23-000010 — 5.02, 9.01
- 2023-01-24 0001032975-23-000004 — 2.02, 5.02, 9.01
- 2023-01-12 0001628280-23-000934 — 2.02, 9.01
- 2022-10-25 0001628280-22-026927 — 2.02, 5.02, 9.01
- 2022-09-16 0001628280-22-025080 — 5.07, 8.01
- 2022-07-26 0001032975-22-000027 — 2.02, 9.01
- 2022-06-29 0001032975-22-000018 — 5.02
- 2022-05-03 0001032975-22-000008 — 2.02, 9.01
- 2022-01-25 0001032975-22-000003 — 2.02, 9.01
- 2021-10-26 0001032975-21-000043 — 2.02, 9.01
- 2021-09-10 0001032975-21-000040 — 5.07, 8.01
- 2021-07-27 0001032975-21-000029 — 2.02, 9.01
- 2021-04-29 0001032975-21-000012 — 2.02, 9.01
- 2021-01-19 0001032975-21-000004 — 2.02, 9.01
- 2020-10-20 0001032975-20-000045 — 2.02, 9.01
- 2020-09-11 0001032975-20-000042 — 5.07, 8.01
- 2020-07-21 0001032975-20-000029 — 2.02, 9.01
- 2020-07-01 0001032975-20-000023 — 5.02, 8.01
- 2020-05-12 0001032975-20-000011 — 2.02, 9.01
- 2020-03-30 0001032975-20-000009 — 5.02
- 2020-01-21 0001032975-20-000002 — 2.02, 9.01
- 2019-10-22 0001032975-19-000071 — 9.01
- 2019-09-26 0001032975-19-000068 — 1.01, 7.01, 9.01
- 2019-09-06 0001032975-19-000063 — 5.07, 8.01
- 2019-07-23 0001032975-19-000046 — 2.02, 9.01
- 2019-07-23 0001032975-19-000045 — 5.02, 9.01
- 2019-07-02 0001032975-19-000036 — 5.02
- 2019-06-25 0001032975-19-000034 — 5.02
- 2019-05-03 0001032975-19-000021 — 5.02 — amendment, the index does not say of what
- 2019-04-30 0001032975-19-000017 — 2.02, 5.02, 9.01
- 2019-03-28 0001032975-19-000013 — 5.02
- 2019-01-22 0001032975-19-000004 — 2.02, 9.01
- 2018-10-23 0001032975-18-000044 — 2.02, 9.01
- 2018-09-07 0001032975-18-000040 — 5.07, 8.01
- 2018-07-31 0001032975-18-000035 — 1.01, 2.02, 2.05, 7.01, 9.01
- 2018-06-27 0001032975-18-000020 — 5.02
- 2018-05-03 0001032975-18-000013 — 2.02, 5.02, 9.01
- 2018-01-23 0001032975-18-000005 — 2.02, 9.01
- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2024-01-25

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-24-000004:8k_2_02:1]
EX-99.1
2
exhibit991q3fy24.htm
EX-99.1

[0001032975-24-000004:8k_2_02:2]
Document

[0001032975-24-000004:8k_2_02:3]
Exhibit 99.1

[0001032975-24-000004:8k_2_02:4]
Editorial Contacts:

[0001032975-24-000004:8k_2_02:5]
Nate Melihercik, Head of Global Investor Relations - ir@logitech.com

[0001032975-24-000004:8k_2_02:6]
Nicole Kenyon, Head of Global Corporate and Internal Communications - nkenyon@logitech.com (USA)

[0001032975-24-000004:8k_2_02:7]
Ben Starkie, Corporate Communications - +41 (0) 79-292-3499, bstarkie1@logitech.com (Europe)

[0001032975-24-000004:8k_2_02:8]
Logitech Announces Third Quarter Fiscal Year 2024 Results

[0001032975-24-000004:8k_2_02:9]
Company Raises FY 2024 Outlook

[0001032975-24-000004:8k_2_02:10]
LAUSANNE, Switzerland, Jan 23, 2024 and SAN JOSE, Calif., Jan. 22, 2024 — SIX Swiss Exchange Ad hoc announcement pursuant to Art. 53 LR — Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the third quarter of Fiscal Year 2024.

[0001032975-24-000004:8k_2_02:11]
•Sales were $1.26 billion, down 1 percent in US dollars and 3 percent in constant currency, compared to the prior year.

[0001032975-24-000004:8k_2_02:12]
•GAAP operating income was $222 million, up 26 percent compared to the prior year. Non-GAAP operating income was $248 million, up 22 percent compared to the prior year.

[0001032975-24-000004:8k_2_02:13]
•GAAP earnings per share (EPS) was $1.55, up 80 percent compared to the prior year. Non-GAAP EPS was $1.53, up 34 percent compared to the prior year.

[0001032975-24-000004:8k_2_02:14]
•Cash flow from operations was $443 million, up 58 percent compared to the prior year. The quarter-ending cash balance was $1.41 billion. In the quarter, the Company returned $188 million of cash to shareholders through share repurchases.

[0001032975-24-000004:8k_2_02:15]
“We delivered solid results in our third quarter,” said Hanneke Faber, Logitech chief executive officer. “Our teams executed well, continuing our long record of exceptional product innovation, market share gains, strong operational discipline and prudent financial management. But we will not be satisfied until we return to top line growth.”

[0001032975-24-000004:8k_2_02:16]
“Our third-quarter results show our continued focus on operational discipline,” said Chuck Boynton, Logitech chief financial officer. “While revenue declined 3% in constant currency, we delivered strong gross margins of 42.3% and grew profitability. We generated $443 million in operating cash flow in the quarter and returned a total of $188 million to our shareholders through share repurchases.”

[0001032975-24-000004:8k_2_02:17]
Outlook

[0001032975-24-000004:8k_2_02:18]
Logitech raised its full-year outlook for Fiscal Year 2024:

[0001032975-24-000004:8k_2_02:19]
|  |  | Previous FY24 outlook |  | New FY24 outlook |
| Sales |  | $4.0 - $4.15 billion |  | $4.2 - $4.25 billion |
| Sales growth/ (decline) (in US dollars, year over year) |  | (12%) - (9%) |  | (7%) - (6%) |
| Non-GAAP operating income |  | $525 - $575 million |  | $610 - $660 million |
| Non-GAAP op. inc. growth/ (decline) (year over year) |  | (11%) - (2%) |  | 4% - 12% |

[0001032975-24-000004:8k_2_02:20]
Financial Results Videoconference and Webcast

[0001032975-24-000004:8k_2_02:21]
Logitech will hold a financial results videoconference to discuss the results for Q3 Fiscal Year 2024 on Tuesday, January 23, 2024 at 8:30 a.m. Eastern Standard Time and 2:30 p.m. Central European Time. A livestream of the event will be available on the Logitech corporate website at https://ir.logitech.com. This press release and the Q3 Fiscal Year 2024 Shareholder Letter are also available there.

[0001032975-24-000004:8k_2_02:22]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-24-000004:8k_2_02:23]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures in this press release, which exclude share-based compensation expense, amortization of intangible assets, acquisition-related costs, restructuring charges, net, loss on investments, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below and posted to our website at https://ir.logitech.com. Logitech also presents percentage sales growth in constant currency (“CC”), a non-GAAP measure, to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance, outlook and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for the full Fiscal Year 2024 non-GAAP operating income outlook.

[0001032975-24-000004:8k_2_02:24]
Public Dissemination of Certain Information

[0001032975-24-000004:8k_2_02:25]
Recordings of Logitech's earnings videoconferences and certain events Logitech participates in or hosts, with members of the investment community are posted on the company's investor relations website at https://ir.logitech.com. Additionally, Logitech provides notifications of news or announcements regarding its operations and financial performance, including its filings with the Securities and Exchange Commission (SEC), investor events, and press and earnings releases as part of its investor relations website. Logitech intends to use its investor relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. Logitech’s corporate governance information also is available on its investor relations website.

[0001032975-24-000004:8k_2_02:26]
About Logitech

[0001032975-24-000004:8k_2_02:27]
Logitech helps all people pursue their passions and is committed to doing so in a way that is good for people and the planet. We design hardware and software solutions that help businesses thrive and bring people together when working, creating, gaming and streaming. Brands of Logitech include Logitech, Logitech G, Streamlabs and Ultimate Ears. Founded in 1981, and headquartered in Lausanne, Switzerland, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @logitech.

[0001032975-24-000004:8k_2_02:28]
# # #

[0001032975-24-000004:8k_2_02:29]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-24-000004:8k_2_02:30]
Logitech and other Logitech marks are trademarks or registered trademarks of Logitech Europe S.A. and/or its affiliates in the U.S. and other countries. All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-24-000004:8k_2_02:31]
(LOGIIR)

[0001032975-24-000004:8k_2_02:32]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three months ended December 31, |  | Nine months ended December 31, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net sales |  | $ | 1,255,473 |  |  | $ | 1,269,925 |  |  | $ | 3,286,980 |  |  | $ | 3,578,741 |  |
| Cost of goods sold |  | 726,252 |  |  | 789,489 |  |  | 1,937,367 |  |  | 2,193,735 |  |
| Amortization of intangible assets |  | 2,441 |  |  | 3,168 |  |  | 8,569 |  |  | 9,355 |  |
| Gross profit |  | 526,780 |  |  | 477,268 |  |  | 1,341,044 |  |  | 1,375,651 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 189,175 |  |  | 196,653 |  |  | 544,716 |  |  | 628,122 |  |
| Research and development |  | 72,704 |  |  | 65,640 |  |  | 211,822 |  |  | 210,166 |  |
| General and administrative |  | 39,711 |  |  | 29,766 |  |  | 116,546 |  |  | 92,215 |  |
| Amortization of intangible assets and acquisition-related costs |  | 2,276 |  |  | 2,810 |  |  | 8,279 |  |  | 9,052 |  |
| Restructuring charges, net |  | 839 |  |  | 5,654 |  |  | 2,562 |  |  | 16,471 |  |
| Total operating expenses |  | 304,705 |  |  | 300,523 |  |  | 883,925 |  |  | 956,026 |  |
| Operating income |  | 222,075 |  |  | 176,745 |  |  | 457,119 |  |  | 419,625 |  |
| Interest income |  | 12,826 |  |  | 4,665 |  |  | 34,508 |  |  | 9,573 |  |
| Other income (expense), net |  | 189 |  |  | 1,406 |  |  | (13,827) |  |  | (18,367) |  |
| Income before income taxes |  | 235,090 |  |  | 182,816 |  |  | 477,800 |  |  | 410,831 |  |
| Provision for (benefit from) income taxes |  | (9,594) |  |  | 42,663 |  |  | 33,272 |  |  | 87,751 |  |
| Net income |  | $ | 244,684 |  |  | $ | 140,153 |  |  | $ | 444,528 |  |  | $ | 323,080 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.57 |  |  | $ | 0.87 |  |  | $ | 2.82 |  |  | $ | 1.98 |  |
| Diluted |  | $ | 1.55 |  |  | $ | 0.86 |  |  | $ | 2.80 |  |  | $ | 1.96 |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | 155,933 |  |  | 161,244 |  |  | 157,568 |  |  | 163,042 |  |
| Diluted |  | 157,440 |  |  | 162,529 |  |  | 158,843 |  |  | 164,427 |  |

[0001032975-24-000004:8k_2_02:33]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | December 31 |  | March 31, |  |  |  |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  | 2023 |  | 2023 |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,412,650 |  |  | $ | 1,149,023 |  |  |  |  |  |
| Accounts receivable, net |  | 685,777 |  |  | 630,382 |  |  |  |  |  |
| Inventories |  | 447,262 |  |  | 682,893 |  |  |  |  |  |
| Other current assets |  | 150,754 |  |  | 142,876 |  |  |  |  |  |
| Total current assets |  | 2,696,443 |  |  | 2,605,174 |  |  |  |  |  |
| Non-current assets: |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 119,200 |  |  | 121,503 |  |  |  |  |  |
| Goodwill |  | 463,978 |  |  | 454,610 |  |  |  |  |  |
| Other intangible assets, net |  | 53,724 |  |  | 63,173 |  |  |  |  |  |
| Other assets |  | 326,594 |  |  | 316,293 |  |  |  |  |  |
| Total assets |  | $ | 3,659,939 |  |  | $ | 3,560,753 |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 527,988 |  |  | $ | 406,968 |  |  |  |  |  |
| Accrued and other current liabilities |  | 673,435 |  |  | 643,139 |  |  |  |  |  |
| Total current liabilities |  | 1,201,423 |  |  | 1,050,107 |  |  |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Income taxes payable |  | 111,924 |  |  | 106,391 |  |  |  |  |  |
| Other non-current liabilities |  | 156,491 |  |  | 146,695 |  |  |  |  |  |
| Total liabilities |  | 1,469,838 |  |  | 1,303,193 |  |  |  |  |  |
| Shareholders’ equity: |  |  |  |  |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |  |  |  |  |
| Issued shares — 173,106 at December 31, 2023 and March 31, 2023 |  |  |  |  |  |  |  |  |
| Additional shares that may be issued out of conditional capital — 50,000 at December 31, 2023 and March 31, 2023 |  |  |  |  |  |  |  |  |
| Additional shares that may be issued out of authorized capital — 17,311 at December 31, 2023 and March 31, 2023 |  |  |  |  |  |  |  |  |
| Additional paid-in capital |  | 60,892 |  |  | 127,380 |  |  |  |  |  |
| Shares in treasury, at cost — 18,108 at December 31, 2023 and 13,763 at March 31, 2023 |  | (1,251,314) |  |  | (977,266) |  |  |  |  |  |
| Retained earnings |  | 3,434,904 |  |  | 3,177,575 |  |  |  |  |  |
| Accumulated other comprehensive loss |  | (84,529) |  |  | (100,277) |  |  |  |  |  |
| Total shareholders’ equity |  | 2,190,101 |  |  | 2,257,560 |  |  |  |  |  |
| Total liabilities and shareholders’ equity |  | $ | 3,659,939 |  |  | $ | 3,560,753 |  |  |  |  |  |

[0001032975-24-000004:8k_2_02:34]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three months ended December 31, |  | Nine months ended December 31, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 244,684 |  |  | $ | 140,153 |  |  | $ | 444,528 |  |  | $ | 323,080 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  | 14,739 |  |  | 19,410 |  |  | 48,874 |  |  | 56,698 |  |
| Amortization of intangible assets |  | 5,074 |  |  | 5,929 |  |  | 16,583 |  |  | 18,173 |  |
| Loss on investments |  | 604 |  |  | 1,488 |  |  | 12,213 |  |  | 13,065 |  |
| Share-based compensation expense |  | 20,613 |  |  | 15,805 |  |  | 64,192 |  |  | 51,740 |  |
| Deferred income taxes |  | (20,623) |  |  | 21,188 |  |  | (9,515) |  |  | 24,228 |  |
| Other |  | 236 |  |  | 1,293 |  |  | 336 |  |  | 1,411 |  |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | (11,424) |  |  | (1,638) |  |  | (46,786) |  |  | (123,547) |  |
| Inventories |  | 91,600 |  |  | 104,519 |  |  | 237,969 |  |  | 126,309 |  |
| Other assets |  | (8,301) |  |  | 16,161 |  |  | 3,698 |  |  | 20,918 |  |
| Accounts payable |  | 32,361 |  |  | (56,494) |  |  | 120,383 |  |  | (134,848) |  |
| Accrued and other liabilities |  | 73,389 |  |  | 12,097 |  |  | 13,536 |  |  | (60,060) |  |
| Net cash provided by operating activities |  | 442,952 |  |  | 279,911 |  |  | 906,011 |  |  | 317,167 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (10,854) |  |  | (23,738) |  |  | (45,585) |  |  | (69,122) |  |
| Investment in privately held companies |  | (50) |  |  | (351) |  |  | (406) |  |  | (2,626) |  |
| Acquisitions, net of cash acquired |  | — |  |  | (2,688) |  |  | (14,138) |  |  | (8,527) |  |
| Purchases of deferred compensation investments |  | (5,345) |  |  | (2,687) |  |  | (7,893) |  |  | (5,186) |  |
| Proceeds from sales of deferred compensation investments |  | 5,571 |  |  | 2,314 |  |  | 8,193 |  |  | 4,750 |  |
| Net cash used in investing activities |  | (10,678) |  |  | (27,150) |  |  | (59,829) |  |  | (80,711) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | — |  |  | — |  |  | (182,305) |  |  | (158,680) |  |
| Payment of contingent consideration for business acquisition |  | — |  |  | — |  |  | (5,002) |  |  | (5,954) |  |
| Purchases of registered shares |  | (187,834) |  |  | (90,170) |  |  | (376,775) |  |  | (327,731) |  |
| Proceeds from exercises of stock options and purchase rights |  | — |  |  | 3,214 |  |  | 15,319 |  |  | 16,064 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (2,372) |  |  | (1,992) |  |  | (28,596) |  |  | (28,734) |  |
| Other financing activities |  | — |  |  | — |  |  | (1,116) |  |  | — |  |
| Net cash used in financing activities |  | (190,206) |  |  | (88,948) |  |  | (578,475) |  |  | (505,035) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | 6,678 |  |  | 3,817 |  |  | (4,080) |  |  | (24,006) |  |
| Net increase (decrease) in cash and cash equivalents |  | 248,746 |  |  | 167,630 |  |  | 263,627 |  |  | (292,585) |  |
| Cash and cash equivalents, beginning of the period |  | 1,163,904 |  |  | 868,501 |  |  | 1,149,023 |  |  | 1,328,716 |  |
| Cash and cash equivalents, end of the period |  | $ | 1,412,650 |  |  | $ | 1,036,131 |  |  | $ | 1,412,650 |  |  | $ | 1,036,131 |  |

[0001032975-24-000004:8k_2_02:35]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three months ended December 31, |  | Nine months ended December 31, |
| NET SALES |  | 2023 |  | 2022 (1) |  | Change |  | 2023 |  | 2022 (1) |  | Change |
| Net sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Gaming (2) |  | $ | 409,043 |  |  | $ | 411,927 |  |  | (1) | % |  | $ | 957,576 |  |  | $ | 1,031,876 |  |  | (7) | % |
| Keyboards & Combos |  | 229,432 |  |  | 220,059 |  |  | 4 |  |  | 605,201 |  |  | 648,632 |  |  | (7) |  |
| Pointing Devices |  | 206,180 |  |  | 199,106 |  |  | 4 |  |  | 572,310 |  |  | 567,589 |  |  | 1 |  |
| Video Collaboration |  | 169,522 |  |  | 173,516 |  |  | (2) |  |  | 461,257 |  |  | 534,347 |  |  | (14) |  |
| Webcams |  | 85,851 |  |  | 94,252 |  |  | (9) |  |  | 249,273 |  |  | 305,532 |  |  | (18) |  |
| Tablet Accessories |  | 64,239 |  |  | 65,157 |  |  | (1) |  |  | 198,252 |  |  | 185,945 |  |  | 7 |  |
| Headsets |  | 41,762 |  |  | 46,736 |  |  | (11) |  |  | 123,023 |  |  | 137,429 |  |  | (10) |  |
| Other (3) |  | 49,444 |  |  | 59,172 |  |  | (16) |  |  | 120,088 |  |  | 167,391 |  |  | (28) |  |
| Total Net Sales |  | $ | 1,255,473 |  |  | $ | 1,269,925 |  |  | (1) | % |  | $ | 3,286,980 |  |  | $ | 3,578,741 |  |  | (8) | % |

[0001032975-24-000004:8k_2_02:36]
(1) The Company has reclassified certain prior period amounts to conform to the current period presentation.

[0001032975-24-000004:8k_2_02:37]
(2) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-24-000004:8k_2_02:38]
(3) Other primarily consists of mobile speakers and PC speakers.

[0001032975-24-000004:8k_2_02:39]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three months ended December 31, |  | Nine months ended December 31, |
| GAAP TO NON-GAAP RECONCILIATION (A) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Gross profit - GAAP |  | $ | 526,780 |  | $ | 477,268 |  | $ | 1,341,044 |  | $ | 1,375,651 |
| Share-based compensation expense |  | 2,189 |  | 1,324 |  | 6,066 |  | 4,228 |
| Amortization of intangible assets |  | 2,441 |  | 3,168 |  | 8,569 |  | 9,355 |
| Gross profit - Non-GAAP |  | $ | 531,410 |  | $ | 481,760 |  | $ | 1,355,679 |  | $ | 1,389,234 |
| Gross margin - GAAP |  | 42.0 | % |  | 37.6 | % |  | 40.8 | % |  | 38.4 | % |
| Gross margin - Non-GAAP |  | 42.3 | % |  | 37.9 | % |  | 41.2 | % |  | 38.8 | % |
| Operating expenses - GAAP |  | $ | 304,705 |  | $ | 300,523 |  | $ | 883,925 |  | $ | 956,026 |
| Less: Share-based compensation expense |  | 18,424 |  | 14,481 |  | 58,126 |  | 47,512 |
| Less: Amortization of intangible assets and acquisition-related costs |  | 2,276 |  | 2,810 |  | 8,279 |  | 9,052 |
| Less: Restructuring charges, net |  | 839 |  | 5,654 |  | 2,562 |  | 16,471 |
| Operating expenses - Non-GAAP |  | $ | 283,166 |  | $ | 277,578 |  | $ | 814,958 |  | $ | 882,991 |
| % of net sales - GAAP |  | 24.3 | % |  | 23.7 | % |  | 26.9 | % |  | 26.7 | % |
| % of net sales - Non-GAAP |  | 22.6 | % |  | 21.9 | % |  | 24.8 | % |  | 24.7 | % |
| Operating income - GAAP |  | $ | 222,075 |  | $ | 176,745 |  | $ | 457,119 |  | $ | 419,625 |
| Share-based compensation expense |  | 20,613 |  | 15,805 |  | 64,192 |  | 51,740 |
| Amortization of intangible assets and acquisition-related costs |  | 4,717 |  | 5,978 |  | 16,848 |  | 18,407 |
| Restructuring charges, net |  | 839 |  | 5,654 |  | 2,562 |  | 16,471 |
| Operating income - Non-GAAP |  | $ | 248,244 |  | $ | 204,182 |  | $ | 540,721 |  | $ | 506,243 |
| % of net sales - GAAP |  | 17.7 | % |  | 13.9 | % |  | 13.9 | % |  | 11.7 | % |
| % of net sales - Non-GAAP |  | 19.8 | % |  | 16.1 | % |  | 16.5 | % |  | 14.1 | % |
| Net income - GAAP |  | $ | 244,684 |  | $ | 140,153 |  | $ | 444,528 |  | $ | 323,080 |
| Share-based compensation expense |  | 20,613 |  | 15,805 |  | 64,192 |  | 51,740 |
| Amortization of intangible assets and acquisition-related costs |  | 4,717 |  | 5,978 |  | 16,848 |  | 18,407 |
| Restructuring charges, net |  | 839 |  | 5,654 |  | 2,562 |  | 16,471 |
| Loss on investments |  | 604 |  | 1,488 |  | 12,213 |  | 13,065 |
| Non-GAAP income tax adjustment |  | (29,963) |  | 16,230 |  | (22,033) |  | 23,296 |
| Net income - Non-GAAP |  | $ | 241,494 |  | $ | 185,308 |  | $ | 518,310 |  | $ | 446,059 |
| Net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 1.55 |  | $ | 0.86 |  | $ | 2.80 |  | $ | 1.96 |
| Diluted - Non-GAAP |  | $ | 1.53 |  | $ | 1.14 |  | $ | 3.26 |  | $ | 2.71 |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non-GAAP |  | 157,440 |  | 162,529 |  | 158,843 |  | 164,427 |

[0001032975-24-000004:8k_2_02:40]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three months ended December 31, |  | Nine months ended December 31, |
| SHARE-BASED COMPENSATION EXPENSE |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 2,189 |  |  | $ | 1,324 |  |  | $ | 6,066 |  |  | $ | 4,228 |  |
| Marketing and selling |  | 8,878 |  |  | 8,014 |  |  | 28,623 |  |  | 25,240 |  |
| Research and development |  | 4,421 |  |  | 2,756 |  |  | 13,568 |  |  | 11,568 |  |
| General and administrative |  | 5,125 |  |  | 3,711 |  |  | 15,935 |  |  | 10,704 |  |
| Total share-based compensation expense |  | 20,613 |  |  | 15,805 |  |  | 64,192 |  |  | 51,740 |  |
| Income tax benefit |  | (3,391) |  |  | (3,276) |  |  | (11,257) |  |  | (7,496) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 17,222 |  |  | $ | 12,529 |  |  | $ | 52,935 |  |  | $ | 44,244 |  |

[0001032975-24-000004:8k_2_02:41]
*Note: These preliminary results for the three and nine months ended December 31, 2023 are subject to adjustments, including subsequent events that may occur through the date of filing our Quarterly Report on Form 10-Q.

[0001032975-24-000004:8k_2_02:42]
(A) Non-GAAP Financial Measures

[0001032975-24-000004:8k_2_02:43]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-24-000004:8k_2_02:44]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended December 31, 2023 and prior periods presented, we excluded items in the following general categories, each of which are described below:

[0001032975-24-000004:8k_2_02:45]
Share-based compensation expense. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-24-000004:8k_2_02:46]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit, operating expenses, and financial results from period to period.

[0001032975-24-000004:8k_2_02:47]
Acquisition-related costs. We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition-related costs include certain incremental expenses incurred to effect a business combination. We believe that providing the non-GAAP measures excluding these costs and credits, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-24-000004:8k_2_02:48]
Restructuring charges (credits), net. These expenses are associated with restructuring plans, and will vary based on the initiatives in place during any given period. Restructuring charges may include costs related to employee terminations, facility closures and early cancellation of certain contracts as well as other costs resulting from our restructuring initiatives. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results.

[0001032975-24-000004:8k_2_02:49]
Loss (gain) on investments. We recognize losses (gains) related to our investments in various companies, which vary depending on the operational and financial performance of the companies in which we invest. These amounts include our losses (earnings) on equity method investments, investment impairments and losses (gains) resulting from sales or other events related to our investments. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such losses (gains) are not reflective of our ongoing operations.

[0001032975-24-000004:8k_2_02:50]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above as well as the income tax impact of non-recurring deferred taxes, tax settlements, and other non-routine tax events, the determination of which is based upon the nature of the underlying items. For the three and nine months ended December 31, 2023, non-GAAP income tax adjustment included the tax benefit from a remeasurement of the tax basis of goodwill under the Swiss Federal Act on Tax Reform and AHV Financing (“TRAF”) based on an agreement reached with the Swiss Tax Authority during the three months ended December 31, 2023.

[0001032975-24-000004:8k_2_02:51]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-24-000004:8k_2_02:52]
Additional Supplemental Financial Information - Constant Currency

[0001032975-24-000004:8k_2_02:53]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.
