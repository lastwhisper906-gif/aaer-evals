# LOGI notes — 0001032975-24-000008


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-24-000008:notes:1]
[same as prior period, unchanged from 0001032975-23-000080:notes:1]

[0001032975-24-000008:notes:2]
[same as prior period, unchanged from 0001032975-23-000080:notes:2]

[0001032975-24-000008:notes:3]
[same as prior period, unchanged from 0001032975-23-000080:notes:3]

[0001032975-24-000008:notes:4]
[same as prior period, unchanged from 0001032975-23-000080:notes:4]

[0001032975-24-000008:notes:5]
[same as prior period, unchanged from 0001032975-23-000080:notes:5]

[0001032975-24-000008:notes:6]
[same as prior period, unchanged from 0001032975-23-000080:notes:6]

[0001032975-24-000008:notes:7]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and nine months ended December 31, 2023 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2024, or any future periods.

[0001032975-24-000008:notes:8]
[same as prior period, unchanged from 0001032975-23-000080:notes:8]

[0001032975-24-000008:notes:9]
[same as prior period, unchanged from 0001032975-23-000080:notes:9]

[0001032975-24-000008:notes:10]
[same as prior period, unchanged from 0001032975-23-000080:notes:10]

[0001032975-24-000008:notes:11]
[same as prior period, unchanged from 0001032975-23-000080:notes:11]

[0001032975-24-000008:notes:12]
[same as prior period, unchanged from 0001032975-23-000080:notes:12]

[0001032975-24-000008:notes:13]
[same as prior period, unchanged from 0001032975-23-000080:notes:13]

[0001032975-24-000008:notes:14]
As a result of these changes, certain prior-period amounts for the three and nine months ended December 31, 2022 have been reclassified to conform to the current period presentation as follows (in thousands):

[0001032975-24-000008:notes:15]
|  |  | Three months ended December 31, 2022 |
|  |  | As previously reported |  | Reclassifications |  | As adjusted |
| Gaming |  | $ | 391,975 |  |  | $ | 19,952 |  | (1) | $ | 411,927 |  |
| Keyboards & Combos |  | 220,059 |  |  | — |  |  | 220,059 |  |
| Pointing Devices |  | 199,106 |  |  | — |  |  | 199,106 |  |
| Video Collaboration |  | 226,374 |  |  | (52,858) |  | (2) (3) | 173,516 |  |
| Webcams (3) |  | 58,481 |  |  | 35,771 |  | (3) | 94,252 |  |
| Tablet Accessories |  | 65,157 |  |  | — |  |  | 65,157 |  |
| Headsets |  | — |  |  | 46,736 |  | (2) | 46,736 |  |
| Other |  | 1,348 |  |  | 57,824 |  | (4) (5) | 59,172 |  |
| Mobile Speakers |  | 38,321 |  |  | (38,321) |  | (4) | — |  |
| Audio & Wearables |  | 69,104 |  |  | (69,104) |  | (1) (2) (5) | — |  |
| Total Sales |  | $ | 1,269,925 |  |  | $ | — |  |  | $ | 1,269,925 |  |

[0001032975-24-000008:notes:16]
|  |  | Nine months ended December 31, 2022 |
|  |  | As previously reported |  | Reclassifications |  | As adjusted |
| Gaming |  | $ | 972,457 |  |  | $ | 59,419 |  | (1) | $ | 1,031,876 |  |
| Keyboards & Combos |  | 648,632 |  |  | — |  |  | 648,632 |  |
| Pointing Devices |  | 567,589 |  |  | — |  |  | 567,589 |  |
| Video Collaboration |  | 708,796 |  |  | (174,449) |  | (2) (3) | 534,347 |  |
| Webcams (3) |  | 178,033 |  |  | 127,499 |  | (3) | 305,532 |  |
| Tablet Accessories |  | 185,945 |  |  | — |  |  | 185,945 |  |
| Headsets |  | — |  |  | 137,429 |  | (2) | 137,429 |  |
| Other |  | 5,642 |  |  | 161,749 |  | (4) (5) | 167,391 |  |
| Mobile Speakers |  | 99,826 |  |  | (99,826) |  | (4) | — |  |
| Audio & Wearables |  | 211,821 |  |  | (211,821) |  | (1) (2) (5) | — |  |
| Total Sales |  | $ | 3,578,741 |  |  | $ | — |  |  | $ | 3,578,741 |  |

[0001032975-24-000008:notes:17]
[same as prior period, unchanged from 0001032975-23-000080:notes:17]

[0001032975-24-000008:notes:18]
[same as prior period, unchanged from 0001032975-23-000080:notes:18]

[0001032975-24-000008:notes:19]
[same as prior period, unchanged from 0001032975-23-000080:notes:19]

[0001032975-24-000008:notes:20]
[same as prior period, unchanged from 0001032975-23-000080:notes:20]

[0001032975-24-000008:notes:21]
[same as prior period, unchanged from 0001032975-23-000080:notes:21]

[0001032975-24-000008:notes:22]
[same as prior period, unchanged from 0001032975-23-000080:notes:22]

[0001032975-24-000008:notes:23]
There have been no material changes in the Company’s significant accounting policies during the three and nine months ended December 31, 2023 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2023.

[0001032975-24-000008:notes:24]
[same as prior period, unchanged from 0001032975-23-000080:notes:24]

[0001032975-24-000008:notes:25]
[same as prior period, unchanged from 0001032975-23-000080:notes:25]

[0001032975-24-000008:notes:26]
[same as prior period, unchanged from 0001032975-23-000080:notes:26]

[0001032975-24-000008:notes:27]
[same as prior period, unchanged from 0001032975-23-000080:notes:27]

[0001032975-24-000008:notes:28]
[same as prior period, unchanged from 0001032975-23-000080:notes:28]

[0001032975-24-000008:notes:29]
The global and regional economic and political conditions adversely affected demand for the Company's products. In addition, these conditions, including recent transportation issues in the Red Sea, have caused and may continue to cause volatility in the cost of materials and logistics, and transportation delays, and as a result may impact the pricing of the Company's products, product availability and the Company's results of operations.

[0001032975-24-000008:notes:30]
Recent Accounting Pronouncements Not Yet Adopted

[0001032975-24-000008:notes:31]
In November 2023, the Financial Accounting Standard Board ("FASB") issued Accounting Standards Update ("ASU") 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures. ASU 2023-07 improves reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses that are regularly provided to the chief operating decision maker. In addition, ASU 2023-07 requires that all existing annual disclosures about segment profit or loss must be provided on an interim basis and clarifies that single reportable segment entities are subject to the disclosure requirement under Topic 280 in its entirety. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 and interim periods within those fiscal years beginning after December 15, 2024. A public entity should apply ASU 2023-07 retrospectively to all prior periods presented in the financial statements. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2023-07 on its consolidated financial statements and related disclosures. 
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. ASU 2023-09 requires additional disclosures related to rate reconciliation, income taxes paid, and other disclosures. Under ASU 2023-09, for each annual periods presented, public entities are required to (1) disclose specific categories in the tabular rate reconciliation and (2) provide additional information for reconciling items that meet a quantitative threshold. In addition, ASU 2023-09 requires all reporting entities to disclose on an annual basis the amount of income taxes paid disaggregated by federal, state, and foreign taxes as well as the amount of income taxes paid by individual jurisdiction. ASU 2023-09 is effective for public business entities for annual periods beginning after December 15, 2024 and can be applied on a prospective basis with an option to apply the standard retrospectively. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2023-09 on its consolidated financial statements and related disclosures.


## us-gaap:EarningsPerShareTextBlock

[0001032975-24-000008:notes:32]
[same as prior period, unchanged from 0001032975-23-000080:notes:30]

[0001032975-24-000008:notes:33]
The following table summarizes the computations of basic and diluted net income per share for the three and nine months ended December 31, 2023 and 2022 (in thousands, except per share amounts):

[0001032975-24-000008:notes:34]
|  |  | Three months ended December 31, |  | Nine months ended December 31, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net income |  | $ | 244,684 |  |  | $ | 140,153 |  |  | $ | 444,528 |  |  | $ | 323,080 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 155,933 |  |  | 161,244 |  |  | 157,568 |  |  | 163,042 |  |
| Effect of potentially dilutive equivalent shares |  | 1,507 |  |  | 1,285 |  |  | 1,275 |  |  | 1,385 |  |
| Weighted average shares outstanding - diluted |  | 157,440 |  |  | 162,529 |  |  | 158,843 |  |  | 164,427 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.57 |  |  | $ | 0.87 |  |  | $ | 2.82 |  |  | $ | 1.98 |  |
| Diluted |  | $ | 1.55 |  |  | $ | 0.86 |  |  | $ | 2.80 |  |  | $ | 1.96 |  |

[0001032975-24-000008:notes:35]
Share equivalents attributable to outstanding stock options, restricted stock units and employee share purchase plans totaling 0.8 million and 1.6 million for the three months ended December 31, 2023 and 2022, respectively, and 1.3 million and 2.0 million for the nine months ended December 31, 2023 and 2022, respectively, were excluded from the calculation of diluted net income per share because their effect would have been anti-dilutive. A small number of performance-based restricted stock units were not included in the dilutive net income per share calculation because all necessary conditions had not been satisfied by the end of the respective period, and those shares were not issuable if the end of the reporting period were the end of the performance contingency period.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-24-000008:notes:36]
[same as prior period, unchanged from 0001032975-23-000080:notes:34]

[0001032975-24-000008:notes:37]
[same as prior period, unchanged from 0001032975-23-000080:notes:35]

[0001032975-24-000008:notes:38]
As of December 31, 2023, the Company offers the 2006 Employee Share Purchase Plan (Non-U.S.), as amended and restated ("2006 ESPP"), the 1996 Employee Share Purchase Plan (U.S.), as amended and restated ("1996 ESPP"), and the 2006 Stock Incentive Plan ("2006 Plan") as amended and restated. Shares issued to employees as a result of purchases or exercises under these plans are generally issued from shares held in treasury stock.

[0001032975-24-000008:notes:39]
The following table summarizes the share-based compensation expense and total income tax benefit recognized for share-based awards for the three and nine months ended December 31, 2023 and 2022 (in thousands):

[0001032975-24-000008:notes:40]
|  |  | Three months ended December 31, |  | Nine months ended December 31, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Cost of goods sold |  | $ | 2,189 |  |  | $ | 1,324 |  |  | $ | 6,066 |  |  | $ | 4,228 |  |
| Marketing and selling |  | 8,878 |  |  | 8,014 |  |  | 28,623 |  |  | 25,240 |  |
| Research and development |  | 4,421 |  |  | 2,756 |  |  | 13,568 |  |  | 11,568 |  |
| General and administrative |  | 5,125 |  |  | 3,711 |  |  | 15,935 |  |  | 10,704 |  |
| Total share-based compensation expense |  | 20,613 |  |  | 15,805 |  |  | 64,192 |  |  | 51,740 |  |
| Income tax benefit |  | (3,391) |  |  | (3,276) |  |  | (11,257) |  |  | (7,496) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 17,222 |  |  | $ | 12,529 |  |  | $ | 52,935 |  |  | $ | 44,244 |  |

[0001032975-24-000008:notes:41]
[same as prior period, unchanged from 0001032975-23-000080:notes:39]

[0001032975-24-000008:notes:42]
Share-based compensation costs capitalized as part of inventory were $1.4 million and $1.3 million for the three months ended December 31, 2023 and 2022, respectively, and $4.8 million and $4.4 million for the nine months ended December 31, 2023 and 2022, respectively.

[0001032975-24-000008:notes:43]
[same as prior period, unchanged from 0001032975-23-000080:notes:41]

[0001032975-24-000008:notes:44]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The costs of $1.9 million and $2.7 million recorded for the three months ended December 31, 2023 and 2022, respectively, and $5.7 million and $8.3 million recorded for the nine months ended December 31, 2023 and 2022, respectively, were primarily related to service costs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-24-000008:notes:45]
[same as prior period, unchanged from 0001032975-23-000080:notes:43]

[0001032975-24-000008:notes:46]
[same as prior period, unchanged from 0001032975-23-000080:notes:44]

[0001032975-24-000008:notes:47]
The income tax provision (benefit) for the three and nine months ended December 31, 2023 was a benefit of $9.6 million and a provision of $33.3 million based on an effective income tax rate of (4.1)% and 7.0% of pre-tax income, respectively. The income tax provision for the same periods ended December 31, 2022 was $42.7 million and $87.8 million based on effective income tax rate of 23.3% and 21.4% of pre-tax income, respectively.

[0001032975-24-000008:notes:48]
The change in the effective income tax rate for the three and nine months ended December 31, 2023, compared with the same periods ended December 31, 2022 was primarily due to the mix of income and losses in the various tax jurisdictions in which the Company operates as well as the favorable tax impacts from share-based compensation, an agreement to remeasure the tax basis of goodwill under the Swiss Federal Act on Tax Reform and AHV Financing (“TRAF”) with the canton of Vaud, remeasurement of the Company’s Swiss deferred tax assets due to a change in tax rate, and Foreign-Derived Intangible Income ("FDII") incentive provided by the Tax Cuts and Jobs Act.

[0001032975-24-000008:notes:49]
The canton of Vaud completed the legislative process to enact TRAF, a reform to better align the Swiss tax system to international tax standards, on March 10, 2020 to take effect as of January 1, 2020. In March 2020, the Company reached an agreement with the Vaud Tax Administration that would allow for an increase in the tax basis of goodwill, as a transition measure under TRAF, to be amortized over ten years beginning on January 1, 2020. During the three months ended December 31, 2023, the Company reached an agreement to remeasure the tax basis of goodwill under TRAF with the canton of Vaud, which resulted in an income tax benefit of $25.1 million, net of assessment of uncertain tax positions. The remeasurement of the step-up will be amortized over the remaining ten-year amortization period.

[0001032975-24-000008:notes:50]
On December 29, 2023, a change to the cantonal tax legislation was published. According to the law approved by the Vaud parliament, a progressive scale will be applicable for cantonal tax purposes resulting in an increase from the current tax rate of 13.61% to 14.28% effective fiscal year 2025. The increase in tax rate resulted in a tax benefit of $5.1 million due to a remeasurement of the Company's Swiss deferred tax assets in the fiscal quarter ended December 31, 2023.

[0001032975-24-000008:notes:51]
The Tax Cuts and Jobs Act enacted Section 250, which provides for a deduction with respect to Global Intangible Low-Taxed Income ("GILTI") and FDII in the US. The application of this tax incentive is inherently complex. During the three months ended December 31, 2023, the Company analyzed the applicability of FDII and determined that this tax incentive applies to fiscal 2021 to 2023 tax years. As a result, the Company realized a tax benefit of $17.9 million related to FDII. The Company has also concluded that any GILTI tax since the enactment of Tax Cuts and Jobs Act would be immaterial.

[0001032975-24-000008:notes:52]
Although the Company has adequately provided for uncertain tax positions, the provisions related to these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During fiscal year 2024, the Company continues to review its tax positions and to provide for or reverse unrecognized tax benefits as they arise. During the next twelve months, while it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly, it is not possible to provide a range of potential changes.

[0001032975-24-000008:notes:53]
On August 16, 2022, the “Inflation Reduction Act” (H.R. 5376) ("IRA") was signed into law in the United States. The IRA established a new corporate alternative minimum tax based on financial statement income adjusted for certain items. The new minimum tax is effective for tax years beginning after December 31, 2022. The IRA is not expected to have a material impact to the Company's financial statements for the tax year ending March 31, 2024.

[0001032975-24-000008:notes:54]
On December 22, 2023, the Federal Council enacted the relevant ordinance for implementing a (Qualified) Domestic Minimum Tax (QDMTT) in Switzerland for tax years beginning from January 1, 2024. The Company is currently evaluating the impact of this ordinance on its consolidated financial statements.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-24-000008:notes:55]
[same as prior period, unchanged from 0001032975-23-000080:notes:48]

[0001032975-24-000008:notes:56]
[same as prior period, unchanged from 0001032975-23-000080:notes:49]

[0001032975-24-000008:notes:57]
|  |  | December 31, 2023 |  | March 31, 2023 |
| Accounts receivable, net: |  |  |  |  |
| Accounts receivable |  | $ | 970,549 |  |  | $ | 851,576 |  |
| Allowance for doubtful accounts |  | — |  |  | (86) |  |
| Allowance for sales returns |  | (12,487) |  |  | (10,146) |  |
| Allowance for cooperative marketing arrangements |  | (47,165) |  |  | (40,495) |  |
| Allowance for customer incentive programs |  | (97,497) |  |  | (71,645) |  |
| Allowance for pricing programs |  | (127,623) |  |  | (98,822) |  |
|  |  | $ | 685,777 |  |  | $ | 630,382 |  |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 71,969 |  |  | $ | 171,790 |  |
| Finished goods |  | 375,293 |  |  | 511,103 |  |
|  |  | $ | 447,262 |  |  | $ | 682,893 |  |
| Other current assets: |  |  |  |  |
| Value-added tax ("VAT") receivables |  | $ | 55,920 |  |  | $ | 60,343 |  |
| Prepaid expenses and other assets |  | 94,834 |  |  | 82,533 |  |
|  |  | $ | 150,754 |  |  | $ | 142,876 |  |
| Property, plant and equipment, net: |  |  |  |  |
| Property, plant and equipment |  | $ | 497,994 |  |  | $ | 518,358 |  |
| Less: accumulated depreciation and amortization |  | (378,794) |  |  | (396,855) |  |
|  |  | $ | 119,200 |  |  | $ | 121,503 |  |
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 197,460 |  |  | $ | 171,989 |  |
| Right-of-use assets |  | 61,721 |  |  | 67,330 |  |
| Investments in privately held companies |  | 30,991 |  |  | 33,323 |  |
| Investments for deferred compensation plan |  | 29,905 |  |  | 28,213 |  |
| Other assets |  | 6,517 |  |  | 15,438 |  |
|  |  | $ | 326,594 |  |  | $ | 316,293 |  |

[0001032975-24-000008:notes:58]
[same as prior period, unchanged from 0001032975-23-000080:notes:51]

[0001032975-24-000008:notes:59]
|  |  | December 31, 2023 |  | March 31, 2023 |
| Accrued and other current liabilities: |  |  |  |  |
| Accrued customer marketing, pricing and incentive programs |  | $ | 193,216 |  |  | $ | 206,546 |  |
| Accrued personnel expenses |  | 142,936 |  |  | 103,592 |  |
| Accrued loss for inventory purchase commitments |  | 33,772 |  |  | 46,608 |  |
| Accrued sales return liability |  | 33,527 |  |  | 49,462 |  |
| Warranty liabilities |  | 28,784 |  |  | 28,861 |  |
| VAT payable |  | 37,748 |  |  | 33,328 |  |
| Income taxes payable |  | 28,136 |  |  | 18,788 |  |
| Operating lease liabilities |  | 14,915 |  |  | 12,655 |  |
| Contingent consideration |  | 1,809 |  |  | 6,629 |  |
| Other current liabilities |  | 158,592 |  |  | 136,670 |  |
|  |  | $ | 673,435 |  |  | $ | 643,139 |  |
| Other non-current liabilities: |  |  |  |  |
| Operating lease liabilities |  | $ | 62,800 |  |  | $ | 58,361 |  |
| Employee benefit plan obligations |  | 32,212 |  |  | 32,421 |  |
| Obligation for deferred compensation plan |  | 29,905 |  |  | 28,213 |  |
| Warranty liabilities |  | 12,993 |  |  | 12,025 |  |
| Deferred tax liabilities |  | 2,529 |  |  | 2,803 |  |
| Other non-current liabilities |  | 16,052 |  |  | 12,872 |  |
|  |  | $ | 156,491 |  |  | $ | 146,695 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001032975-24-000008:notes:60]
[same as prior period, unchanged from 0001032975-23-000080:notes:53]

[0001032975-24-000008:notes:61]
[same as prior period, unchanged from 0001032975-23-000080:notes:54]

[0001032975-24-000008:notes:62]
[same as prior period, unchanged from 0001032975-23-000080:notes:55]

[0001032975-24-000008:notes:63]
[same as prior period, unchanged from 0001032975-23-000080:notes:56]

[0001032975-24-000008:notes:64]
[same as prior period, unchanged from 0001032975-23-000080:notes:57]

[0001032975-24-000008:notes:65]
[same as prior period, unchanged from 0001032975-23-000080:notes:58]

[0001032975-24-000008:notes:66]
|  |  | December 31, 2023 |  | March 31, 2023 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 959,932 |  |  | $ | — |  |  | $ | — |  |  | $ | 661,884 |  |  | $ | — |  |  | $ | — |  |
| Investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 402 |  |  | $ | — |  |  | $ | — |  |  | $ | 41 |  |  | $ | — |  |  | $ | — |  |
| Common stock |  | 1,257 |  |  | — |  |  | — |  |  | 988 |  |  | — |  |  | — |  |
| Money market funds |  | 9,760 |  |  | — |  |  | — |  |  | 9,606 |  |  | — |  |  | — |  |
| Mutual funds |  | 18,486 |  |  | — |  |  | — |  |  | 17,578 |  |  | — |  |  | — |  |
| Total investments for deferred compensation plan |  | $ | 29,905 |  |  | $ | — |  |  | $ | — |  |  | $ | 28,213 |  |  | $ | — |  |  | $ | — |  |
| Currency derivative assetsincluded in other current assets |  | $ | — |  |  | $ | 118 |  |  | $ | — |  |  | $ | — |  |  | $ | 107 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration included in accrued and other current liabilities |  | $ | — |  |  | $ | — |  |  | $ | 1,809 |  |  | $ | — |  |  | $ | — |  |  | $ | 6,629 |  |
| Currency derivative liabilitiesincluded in accrued and other current liabilities |  | $ | — |  |  | $ | 1,813 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,187 |  |  | $ | — |  |

[0001032975-24-000008:notes:67]
[same as prior period, unchanged from 0001032975-23-000080:notes:60]

[0001032975-24-000008:notes:68]
The following table summarizes the change in the Company's contingent consideration balance during the nine months ended December 31, 2023 and 2022 (in thousands):

[0001032975-24-000008:notes:69]
|  |  | Nine months ended December 31, |
|  |  | 2023 |  | 2022 |
| Beginning of the period |  | $ | 6,629 |  |  | $ | 12,259 |  |
| Fair value of contingent consideration upon acquisition |  | — |  |  | 2,151 |  |
| Payments of contingent consideration |  | (5,002) |  |  | (5,954) |  |
| Effect of foreign currency exchange rate changes |  | 182 |  |  | (1,843) |  |
| End of the period |  | $ | 1,809 |  |  | $ | 6,613 |  |

[0001032975-24-000008:notes:70]
The contingent consideration arising from a technology acquisition on May 19, 2021, represented the future potential earn-out payments of up to $10.0 million payable in cash upon the achievement of three technical development milestones to be completed as of December 31, 2021, June 30, 2022, and June 30, 2023. The fair value of the contingent consideration was $10.0 million at the acquisition date, which was determined using a probability-weighted expected payment model and discounted at the estimated cost of debt. During fiscal year 2022, the Company paid $0.9 million for the contingent consideration related to the first technical development milestone. During fiscal year 2023, the Company paid $4.0 million for the contingent consideration related to the second technical development milestone. During the second quarter of fiscal year 2024, the Company paid $3.3 million for the contingent consideration related to the third technical development milestone.

[0001032975-24-000008:notes:71]
The contingent consideration arising from a technology acquisition on January 4, 2021, represented the future potential earn-out payments of up to $3.0 million payable in cash upon the achievement of two technical development milestones to be completed as of December 31, 2021 and March 31, 2022. The fair value of the contingent consideration was determined using a probability-weighted expected payment model and discounted at the estimated cost of debt. During fiscal year 2023, the Company paid $2.0 million for the contingent consideration related to the first technical development milestone. During the second quarter of fiscal year 2024, the Company paid $1.0 million for the contingent consideration related to the second technical development milestone.

[0001032975-24-000008:notes:72]
[same as prior period, unchanged from 0001032975-23-000080:notes:65]

[0001032975-24-000008:notes:73]
The marketable securities for the Company's deferred compensation plan were recorded at a fair value of $29.9 million and $28.2 million, as of December 31, 2023 and March 31, 2023, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized gains (losses) related to marketable securities for the three and nine months ended December 31, 2023 and 2022 were not material and were included in other income (expense), net, and corresponding changes in the deferred compensation liability were included in operating expenses and cost of goods sold, in the Company's condensed consolidated statements of operations.

[0001032975-24-000008:notes:74]
[same as prior period, unchanged from 0001032975-23-000080:notes:67]

[0001032975-24-000008:notes:75]
The Company has certain non-marketable investments included in other assets that are accounted for as equity method investments, with a carrying value of $18.4 million and $20.5 million as of December 31, 2023 and March 31, 2023, respectively. Gains (losses) related to equity method investments for the three and nine months ended December 31, 2023 and 2022 were not material and are included in other income (expense), net, in the Company's condensed consolidated statements of operations.

[0001032975-24-000008:notes:76]
During the second quarter of fiscal year 2023, the Company recorded an impairment charge, before tax, of $21.4 million for one of its equity method investments as it was determined that the carrying value of the investment was not recoverable. The impairment charge is included in other income (expense), net, in the Company's condensed consolidated statement of operations for the nine months ended December 31, 2022. There was no impairment of equity method investments during the three and nine months ended December 31, 2023.

[0001032975-24-000008:notes:77]
[same as prior period, unchanged from 0001032975-23-000080:notes:70]

[0001032975-24-000008:notes:78]
[same as prior period, unchanged from 0001032975-23-000080:notes:71]

[0001032975-24-000008:notes:79]
The Company has certain equity investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with the same or similar security from the same issuer. The amount of these equity investments without readily determinable fair values included in other assets was $12.1 million and $12.6 million as of December 31, 2023 and March 31, 2023, respectively. During the first quarter of fiscal year 2023, the Company recorded an unrealized gain, before tax, of $6.9 million for its investment in a private company as a result of observable price changes for similar securities issued by this company (level 2 fair value measurement). There were no impairment charges related to these financial assets during the three and nine months ended December 31, 2023 and 2022, other than immaterial impairment charges related to certain investments without readily determinable fair values.

[0001032975-24-000008:notes:80]
During the first quarter of fiscal year 2024, the Company recorded an impairment loss, before tax, of $9.6 million as a result of the write-off of a note receivable which has been deemed no longer recoverable. This note receivable was previously obtained in conjunction with an exchange transaction related to the Company's investment in a privately held company. The impairment loss is included in other income (expense), net, in the Company's condensed consolidated statement of operations for the nine months ended December 31, 2023.

[0001032975-24-000008:notes:81]
Non-Financial Assets
Goodwill, intangible assets, and property, plant and equipment, are not required to be measured at fair value on a recurring basis. However, if the Company is required to evaluate these non-financial assets for impairment, whether due to certain triggering events or because of the required annual impairment test, and a resulting impairment is recorded to reduce the carrying value to the fair value, the non-financial assets are measured at fair value during such period. There was no impairment of non-financial assets during the three and nine months ended December 31, 2023 and 2022.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-24-000008:notes:82]
[same as prior period, unchanged from 0001032975-23-000080:notes:75]

[0001032975-24-000008:notes:83]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis in other current assets and accrued and other current liabilities, respectively, on the condensed consolidated balance sheets as of December 31, 2023 and March 31, 2023. See Note 6 for the fair values of the Company’s derivative instruments as of December 31, 2023 and March 31, 2023.

[0001032975-24-000008:notes:84]
[same as prior period, unchanged from 0001032975-23-000080:notes:77]

[0001032975-24-000008:notes:85]
[same as prior period, unchanged from 0001032975-23-000080:notes:78]

[0001032975-24-000008:notes:86]
The notional amounts of foreign currency exchange forward contracts outstanding related to forecasted inventory purchases were $91.2 million and $72.6 million as of December 31, 2023 and March 31, 2023, respectively. The Company had $1.6 million of net loss related to its cash flow hedges included in accumulated other comprehensive loss as of December 31, 2023, which will be reclassified into earnings within the next twelve months.

[0001032975-24-000008:notes:87]
The following table presents the amounts of gain (loss) on the Company’s derivative instruments designated as hedging instruments for the three and nine months ended December 31, 2023 and 2022 and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income (in thousands):

[0001032975-24-000008:notes:88]
|  |  | Three months ended December 31, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of (Gain) LossReclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  |  |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |  |  |  |
| Cash flow hedges |  | $ | (2,539) |  |  | $ | (6,325) |  |  | $ | (863) |  |  | $ | (4,728) |  |  |  |  |  |
|  |  | Nine months ended December 31, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of (Gain) LossReclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  |  |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |  |  |  |
| Cash flow hedges |  | $ | (1,165) |  |  | $ | 5,239 |  |  | $ | 3,493 |  |  | $ | (11,766) |  |  |  |  |  |

[0001032975-24-000008:notes:89]
[same as prior period, unchanged from 0001032975-23-000080:notes:82]

[0001032975-24-000008:notes:90]
[same as prior period, unchanged from 0001032975-23-000080:notes:83]

[0001032975-24-000008:notes:91]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within approximately one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are not material and included in other income (expense), net, in the condensed consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of December 31, 2023 and March 31, 2023 were $78.2 million and $111.2 million, respectively. Foreign currency exchange forward and swap contracts outstanding as of December 31, 2023 primarily consisted of contracts in Canadian Dollar, Brazilian Real, and New Taiwan Dollar to be settled at future dates at predetermined exchange rates.

[0001032975-24-000008:notes:92]
[same as prior period, unchanged from 0001032975-23-000080:notes:85]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-24-000008:notes:93]
Goodwill and Other Intangible Assets
The Company conducts its impairment analysis of goodwill annually at December 31 or more frequently if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting unit may be less than its carrying amount. The Company conducted its annual impairment analysis of goodwill as of December 31, 2023 by performing a qualitative assessment and concluded that it was more likely than not that the fair value of its reporting unit exceeds its carrying amount. In assessing the qualitative factors, the Company considered the impact of change in industry and competitive environment, the Company's market capitalization and budgeted-to-actual revenue performance for the last twelve months.

[0001032975-24-000008:notes:94]
[same as prior period, unchanged from 0001032975-23-000080:notes:87]

[0001032975-24-000008:notes:95]
| As of March 31, 2023 |  | $ | 454,610 |  |
| Acquisition |  | 8,117 |  |
| Effects of foreign currency translation |  | 1,251 |  |
| As of December 31, 2023 |  | $ | 463,978 |  |

[0001032975-24-000008:notes:96]
[same as prior period, unchanged from 0001032975-23-000080:notes:89]

[0001032975-24-000008:notes:97]
|  |  | December 31, 2023 |  | March 31, 2023 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademarks and trade names |  | $ | 32,390 |  |  | $ | (25,005) |  |  | $ | 7,385 |  |  | $ | 36,790 |  |  | $ | (26,774) |  |  | $ | 10,016 |  |
| Developed technology |  | 107,421 |  |  | (84,398) |  |  | 23,023 |  |  | 121,730 |  |  | (94,792) |  |  | 26,938 |  |
| Customer contracts/relationships |  | 69,087 |  |  | (49,164) |  |  | 19,923 |  |  | 71,110 |  |  | (47,688) |  |  | 23,422 |  |
| In-process R&D |  | 3,526 |  |  | — |  |  | 3,526 |  |  | 3,526 |  |  | — |  |  | 3,526 |  |
| Effects of foreign currency translation |  | (214) |  |  | 81 |  |  | (133) |  |  | (1,021) |  |  | 292 |  |  | (729) |  |
| Total |  | $ | 212,210 |  |  | $ | (158,486) |  |  | $ | 53,724 |  |  | $ | 232,135 |  |  | $ | (168,962) |  |  | $ | 63,173 |  |


## us-gaap:DebtDisclosureTextBlock

[0001032975-24-000008:notes:98]
Financing Arrangements

[0001032975-24-000008:notes:99]
The Company had several uncommitted, unsecured bank lines of credit and letters of credit aggregating $176.1 million and $181.3 million as of December 31, 2023 and March 31, 2023, respectively. There are no financial covenants under the lines of credit with which the Company must comply. There was no borrowing outstanding under the lines of credit as of December 31, 2023 or March 31, 2023. As of December 31, 2023 and March 31, 2023, the Company had outstanding bank guarantees of $11.1 million and $13.6 million, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-24-000008:notes:100]
Commitments and Contingencies

[0001032975-24-000008:notes:101]
Product Warranties

[0001032975-24-000008:notes:102]
Changes in the Company’s warranty liabilities for the three and nine months ended December 31, 2023 and 2022 were as follows (in thousands):

[0001032975-24-000008:notes:103]
|  | Three months ended December 31, |  | Nine months ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Beginning of the period | $ | 40,265 |  |  | $ | 41,960 |  |  | $ | 40,886 |  |  | $ | 46,219 |  |
| Provision | 11,249 |  |  | 8,920 |  |  | 30,734 |  |  | 23,440 |  |
| Settlements | (10,158) |  |  | (8,979) |  |  | (29,914) |  |  | (26,358) |  |
| Effects of foreign currency translation | 421 |  |  | 730 |  |  | 71 |  |  | (670) |  |
| End of the period | $ | 41,777 |  |  | $ | 42,631 |  |  | $ | 41,777 |  |  | $ | 42,631 |  |

[0001032975-24-000008:notes:104]
Indemnifications

[0001032975-24-000008:notes:105]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2023, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-24-000008:notes:106]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-24-000008:notes:107]
Legal Proceedings

[0001032975-24-000008:notes:108]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and legal proceedings. The Company intends to vigorously defend against them. Management periodically assesses the Company’s liabilities and contingencies in connection with these matters based upon the latest information available. The Company follows ASC ("Accounting Standards Codification") 450 in determining the accounting and disclosure for these contingencies. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows and results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-24-000008:notes:109]
[same as prior period, unchanged from 0001032975-23-000080:notes:101]

[0001032975-24-000008:notes:110]
[same as prior period, unchanged from 0001032975-23-000080:notes:102]

[0001032975-24-000008:notes:111]
In May 2020, the Company's Board of Directors approved the 2020 share repurchase program, which authorized the Company to use up to $250.0 million to purchase Logitech shares to support equity incentive plans or potential acquisitions. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. In April 2021, the Company's Board of Directors approved an increase of $750.0 million to the 2020 share repurchase program, to an aggregate amount of $1.0 billion. The Swiss Takeover Board approved this increase and it became effective on May 21, 2021. In July 2022, the Company’s Board of Directors approved an increase of $500 million to the 2020 share repurchase program, to an aggregate amount of up to $1.5 billion. The Swiss Takeover Board approved this increase and it became effective on August 19, 2022. The 2020 share repurchase program expired on July 27, 2023. The Company repurchased 16.7 million shares for an aggregate cost of $1.2 billion under the 2020 share repurchase program, of which 2.6 million shares for an aggregate cost of $159.1 million were repurchased during fiscal year 2024 prior to the expiration of the program.

[0001032975-24-000008:notes:112]
[same as prior period, unchanged from 0001032975-23-000080:notes:105]

[0001032975-24-000008:notes:113]
In June 2023, the Company's Board of Directors approved a new, three-year share repurchase program, which allows the Company to use up to $1.0 billion to repurchase its shares. The 2023 share repurchase program enables the Company to repurchase shares for cancellation, as well as to support equity incentive plans or potential acquisitions. The Swiss Takeover Board approved the 2023 share repurchase program in July 2023 and the program became effective on July 28, 2023. During the nine months ended December 31, 2023, the Company repurchased 3.0 million shares for an aggregate cost of $232.5 million under the 2023 share repurchase program for cancellation, of which $14.8 million of the aggregate cost was not paid yet as of December 31, 2023. As of December 31, 2023, $767.8 million was available for repurchase under the 2023 share repurchase program.

[0001032975-24-000008:notes:114]
Swiss law limits a company’s ability to hold or repurchase its own shares. The aggregate par value of all shares held in treasury by the Company and its subsidiaries may not exceed 10% of the share capital of the Company, which for the Company corresponds to approximately 17.3 million registered shares. This limitation does not apply to shares repurchased for cancellation, due to the Board of Directors’ authority under the Company’s capital band set forth in the Company’s Articles of Incorporation to cancel shares up to a limit of 10% of the Company's current share capital. As of December 31, 2023, the Company had a total of 18.1 million shares held in treasury stock, which includes 3.0 million shares that have been repurchased for cancellation.

[0001032975-24-000008:notes:115]
[same as prior period, unchanged from 0001032975-23-000080:notes:108]

[0001032975-24-000008:notes:116]
[same as prior period, unchanged from 0001032975-23-000080:notes:109]

[0001032975-24-000008:notes:117]
During the nine months ended December 31, 2023, the Company declared and paid cash dividends of CHF 1.06 (USD equivalent of $1.19 based on the exchange rate on the date of declaration) per share, totaling $187.2 million on the Company's outstanding shares. During the nine months ended December 31, 2022, the Company declared and paid cash dividends of CHF 0.96 (USD equivalent of $1.00 based on the exchange rate on the date of declaration) per share, totaling $162.7 million on the Company's outstanding shares.

[0001032975-24-000008:notes:118]
[same as prior period, unchanged from 0001032975-23-000080:notes:111]

[0001032975-24-000008:notes:119]
[same as prior period, unchanged from 0001032975-23-000080:notes:112]

[0001032975-24-000008:notes:120]
[same as prior period, unchanged from 0001032975-23-000080:notes:113]

[0001032975-24-000008:notes:121]
|  |  | Cumulative Translation Adjustment |  | Defined Benefit Plans |  | Deferred Hedging Losses |  | Total |
| March 31, 2023 |  | $ | (100,869) |  |  | $ | 4,525 |  |  | $ | (3,933) |  |  | $ | (100,277) |  |
| Other comprehensive income |  | 13,168 |  |  | 252 |  |  | 2,328 |  |  | 15,748 |  |
| December 31, 2023 |  | $ | (87,701) |  |  | $ | 4,777 |  |  | $ | (1,605) |  |  | $ | (84,529) |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-24-000008:notes:122]
[same as prior period, unchanged from 0001032975-23-000080:notes:115]

[0001032975-24-000008:notes:123]
[same as prior period, unchanged from 0001032975-23-000080:notes:116]

[0001032975-24-000008:notes:124]
During the first quarter of fiscal year 2024, the Company changed its presentation of Sales by Product Category to provide a simpler and clearer view of the Company's business. The change in presentation did not have an impact on previously reported total sales. As a result of these changes, certain prior-period amounts for the three and nine months ended December 31, 2022 have been reclassified to conform to the current period presentation. See Note 1 for further information on the change in presentation.

[0001032975-24-000008:notes:125]
Sales by product category in the current presentation for the three and nine months ended December 31, 2023 and 2022 were as follows (in thousands):

[0001032975-24-000008:notes:126]
|  |  | Three months ended December 31, |  | Nine months ended December 31, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Gaming (1) |  | $ | 409,043 |  |  | $ | 411,927 |  |  | $ | 957,576 |  |  | $ | 1,031,876 |  |
| Keyboards & Combos |  | 229,432 |  |  | 220,059 |  |  | 605,201 |  |  | 648,632 |  |
| Pointing Devices |  | 206,180 |  |  | 199,106 |  |  | 572,310 |  |  | 567,589 |  |
| Video Collaboration |  | 169,522 |  |  | 173,516 |  |  | 461,257 |  |  | 534,347 |  |
| Webcams |  | 85,851 |  |  | 94,252 |  |  | 249,273 |  |  | 305,532 |  |
| Tablet Accessories |  | 64,239 |  |  | 65,157 |  |  | 198,252 |  |  | 185,945 |  |
| Headsets |  | 41,762 |  |  | 46,736 |  |  | 123,023 |  |  | 137,429 |  |
| Other (2) |  | 49,444 |  |  | 59,172 |  |  | 120,088 |  |  | 167,391 |  |
| Total Sales |  | $ | 1,255,473 |  |  | $ | 1,269,925 |  |  | $ | 3,286,980 |  |  | $ | 3,578,741 |  |

[0001032975-24-000008:notes:127]
[same as prior period, unchanged from 0001032975-23-000080:notes:120]

[0001032975-24-000008:notes:128]
[same as prior period, unchanged from 0001032975-23-000080:notes:121]

[0001032975-24-000008:notes:129]
Sales by geographic region (based on the customers’ locations) for the three and nine months ended December 31, 2023 and 2022 were as follows (in thousands):

[0001032975-24-000008:notes:130]
|  |  | Three months ended December 31, |  | Nine months ended December 31, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Americas |  | $ | 538,530 |  |  | $ | 513,835 |  |  | $ | 1,446,104 |  |  | $ | 1,508,318 |  |
| EMEA |  | 416,618 |  |  | 428,532 |  |  | 987,301 |  |  | 1,016,187 |  |
| Asia Pacific |  | 300,325 |  |  | 327,558 |  |  | 853,575 |  |  | 1,054,236 |  |
| Total Sales |  | $ | 1,255,473 |  |  | $ | 1,269,925 |  |  | $ | 3,286,980 |  |  | $ | 3,578,741 |  |

[0001032975-24-000008:notes:131]
[same as prior period, unchanged from 0001032975-23-000080:notes:124]

[0001032975-24-000008:notes:132]
Switzerland, the Company’s country of domicile, represented 3% and 4% of the Company's total consolidated sales for the three months ended December 31, 2023 and 2022, respectively, and 2% and 3% for the nine months ended December 31, 2023 and 2022, respectively.

[0001032975-24-000008:notes:133]
Three customers of the Company each represented 10% or more of the total consolidated gross sales for each of the three and nine months ended December 31, 2023 and 2022.

[0001032975-24-000008:notes:134]
[same as prior period, unchanged from 0001032975-23-000080:notes:127]

[0001032975-24-000008:notes:135]
|  |  | December 31, 2023 |  | March 31, 2023 |
| Americas |  | $ | 68,996 |  |  | $ | 59,183 |  |
| EMEA |  | 32,839 |  |  | 38,890 |  |
| Asia Pacific |  | 56,734 |  |  | 69,939 |  |
| Total |  | $ | 158,569 |  |  | $ | 168,012 |  |

[0001032975-24-000008:notes:136]
Property, plant and equipment, net (excluding software) and right-of-use assets in the United States, China, and Ireland were $67.8 million, $37.6 million and $16.9 million, respectively, as of December 31, 2023, and $58.7 million, $48.8 million, and $17.7 million, respectively, as of March 31, 2023. No other countries represented more than 10% of the Company’s total consolidated property, plant and equipment, net (excluding software) and right-of-use assets as of December 31, 2023 or March 31, 2023. 
Property, plant and equipment, net (excluding software) and right-of-use assets in Switzerland, the Company’s country of domicile, were $9.8 million and $13.7 million as of December 31, 2023 and March 31, 2023, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001032975-24-000008:notes:137]
[same as prior period, unchanged from 0001032975-23-000080:notes:130]

[0001032975-24-000008:notes:138]
[same as prior period, unchanged from 0001032975-23-000080:notes:131]

[0001032975-24-000008:notes:139]
The following table summarizes restructuring-related activities during the nine months ended December 31, 2023 (in thousands):

[0001032975-24-000008:notes:140]
|  |  | TerminationBenefits |  | Contract Termination and Other |  | Total |  |
| Accrued restructuring liability at March 31, 2023 (1) |  | $ | 14,177 |  |  | $ | 5,357 |  |  | $ | 19,534 |  |  |
| Charges (credits), net |  | 4,310 |  |  | (1,748) |  |  | 2,562 |  |  |
| Cash payments |  | (17,688) |  |  | (1,581) |  |  | (19,269) |  |  |
| Accrued restructuring liability at December 31, 2023 (1) |  | $ | 799 |  |  | $ | 2,028 |  |  | $ | 2,827 |  |  |

[0001032975-24-000008:notes:141]
[same as prior period, unchanged from 0001032975-23-000080:notes:134]


## ecd:MtrlTermsOfTrdArrTextBlock

[0001032975-24-000008:notes:142]
On November 3, 2023, Prakash Arunkundrum, our Chief Operating Officer, adopted a Rule 10b5-1 trading arrangement providing for the sale of an aggregate of up to 30,916 shares of our common stock acquired by Mr. Arunkundrum under our equity plans. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The first date that sales of any shares are permitted to be sold under the trading arrangement will be February 2, 2024. The trading arrangement terminates on October 2, 2024, or upon the earlier completion of all transactions thereunder.

[0001032975-24-000008:notes:143]
On November 9, 2023, Samantha Harnett, our Chief Legal Officer, adopted a Rule 10b5-1 trading arrangement providing for the sale of an aggregate of 850 shares of our common stock acquired by Ms. Harnett under our equity plans. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The first date that sales of any shares are permitted to be sold under the trading arrangement will be February 8, 2024. The trading arrangement terminates on May 9, 2024, or upon the earlier completion of all transactions thereunder.
