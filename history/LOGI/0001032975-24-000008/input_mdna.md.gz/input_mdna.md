# LOGI MD&A — 0001032975-24-000008


## mdna

[0001032975-24-000008:mdna:1]
[same as prior period, unchanged from 0001032975-23-000080:mdna:1]

[0001032975-24-000008:mdna:2]
[same as prior period, unchanged from 0001032975-23-000080:mdna:2]

[0001032975-24-000008:mdna:3]
•Our business strategy and investment priorities in relation to competitive offerings and evolving consumer demand trends affecting our products and markets, current and future worldwide geopolitical, economic and capital market conditions, including fluctuations in currency exchange rates, inflation, economic downturns, and disruptions in global transportation lines;

[0001032975-24-000008:mdna:4]
[same as prior period, unchanged from 0001032975-23-000080:mdna:4]

[0001032975-24-000008:mdna:5]
[same as prior period, unchanged from 0001032975-23-000080:mdna:5]

[0001032975-24-000008:mdna:6]
•The evolution and adoption of artificial intelligence (“AI”), its impact on our industry and related risks and opportunities for our business;

[0001032975-24-000008:mdna:7]
[same as prior period, unchanged from 0001032975-23-000080:mdna:6]

[0001032975-24-000008:mdna:8]
[same as prior period, unchanged from 0001032975-23-000080:mdna:7]

[0001032975-24-000008:mdna:9]
[same as prior period, unchanged from 0001032975-23-000080:mdna:8]

[0001032975-24-000008:mdna:10]
•Our expectations regarding our potential indemnification obligations, and the outcome of pending or future legal proceedings and tax audits;

[0001032975-24-000008:mdna:11]
[same as prior period, unchanged from 0001032975-23-000080:mdna:10]

[0001032975-24-000008:mdna:12]
[same as prior period, unchanged from 0001032975-23-000080:mdna:11]

[0001032975-24-000008:mdna:13]
[same as prior period, unchanged from 0001032975-23-000080:mdna:12]

[0001032975-24-000008:mdna:14]
[same as prior period, unchanged from 0001032975-23-000080:mdna:13]

[0001032975-24-000008:mdna:15]
[same as prior period, unchanged from 0001032975-23-000080:mdna:14]

[0001032975-24-000008:mdna:16]
[same as prior period, unchanged from 0001032975-23-000080:mdna:15]

[0001032975-24-000008:mdna:17]
[same as prior period, unchanged from 0001032975-23-000080:mdna:16]

[0001032975-24-000008:mdna:18]
[same as prior period, unchanged from 0001032975-23-000080:mdna:17]

[0001032975-24-000008:mdna:19]
Logitech’s mission is to help all people pursue their passions in a way that is good for people and the planet. We design, manufacture, and sell products that help businesses thrive and bring people together when working, creating, gaming and streaming. We sell these products through a number of brands: Logitech, Logitech G, Streamlabs and Ultimate Ears.

[0001032975-24-000008:mdna:20]
[same as prior period, unchanged from 0001032975-23-000080:mdna:19]

[0001032975-24-000008:mdna:21]
[same as prior period, unchanged from 0001032975-23-000080:mdna:20]

[0001032975-24-000008:mdna:22]
[same as prior period, unchanged from 0001032975-23-000080:mdna:21]

[0001032975-24-000008:mdna:23]
[same as prior period, unchanged from 0001032975-23-000080:mdna:22]

[0001032975-24-000008:mdna:24]
The global and regional economic and political conditions adversely affected demand for our products. In addition, these conditions, including recent transportation issues in the Red Sea, have caused and may continue to cause volatility in the cost of materials and logistics, and transportation delays, and as a result may impact the pricing of our products, product availability and our results of operations.

[0001032975-24-000008:mdna:25]
For additional information, see Part II, Item 1A "Risk Factors."

[0001032975-24-000008:mdna:26]
[same as prior period, unchanged from 0001032975-23-000080:mdna:25]

[0001032975-24-000008:mdna:27]
[same as prior period, unchanged from 0001032975-23-000080:mdna:26]

[0001032975-24-000008:mdna:28]
While we believe we will further benefit from these secular trends, we have experienced and will continue to experience challenges that impact our business and financial results. These challenges include (i) the current macroeconomic environment, including interest rate fluctuations, inflation, foreign exchange movements and low economic growth in certain regions, (ii) low consumer confidence and declines in enterprise spending leading to reduced demand for some of our products, (iii) the uncertainty with enterprise strategy for office space utilization and related timing of enterprise investments in infrastructure and technology to support future ways of working, which impacts demand for our Video Collaboration and other products, and (iv) the timing of further development of our business-to-business go-to-market capabilities.

[0001032975-24-000008:mdna:29]
[same as prior period, unchanged from 0001032975-23-000080:mdna:28]

[0001032975-24-000008:mdna:30]
The rapid evolution and adoption of generative artificial intelligence indicates that how we collaborate, communicate, play and create across industries and professions will change, perhaps dramatically, over the next few years. AI has reshaped expectations for productivity improvements, product innovation and technology ecosystem evolution. While we have used AI solutions and machine learning to enhance the features of different

[0001032975-24-000008:mdna:31]
products in our portfolio, AI offers additional growth opportunities and risks as we work to integrate our capabilities with our ecosystem partners. Ultimately our customers might begin to integrate AI into their workflows for productivity, play, learning and creativity. We believe that the shift to AI will transform the consumer electronics industry, leading to changes including more intelligent and personalized products, enhanced customer experiences, and increased competition among companies to leverage AI capabilities for innovation and growth.

[0001032975-24-000008:mdna:32]
For additional information, see Part II, Item 1A "Risk Factors."

[0001032975-24-000008:mdna:33]
[same as prior period, unchanged from 0001032975-23-000080:mdna:29]

[0001032975-24-000008:mdna:34]
[same as prior period, unchanged from 0001032975-23-000080:mdna:30]

[0001032975-24-000008:mdna:35]
[same as prior period, unchanged from 0001032975-23-000080:mdna:31]

[0001032975-24-000008:mdna:36]
Our total sales for the three and nine months ended December 31, 2023 decreased 1% and 8%, compared to the three and nine months ended December 31, 2022, respectively, driven by a decline in sales of most of our product categories, as a result of lower demand.

[0001032975-24-000008:mdna:37]
Sales for the three months ended December 31, 2023 increased 5% in the Americas region, and decreased 8% and 3% in the Asia Pacific and EMEA regions, respectively, compared to the three months ended December 31, 2022. Sales for the nine months ended December 31, 2023 decreased 19%, 4%, and 3% in the Asia Pacific, Americas, and EMEA regions, respectively, compared to the nine months ended December 31, 2022.

[0001032975-24-000008:mdna:38]
Gross margin was 42.0% and 40.8% for the three and nine months ended December 31, 2023, respectively, and increased by 440 and 240 basis points, respectively, compared to the three and nine months ended December 31, 2022, primarily driven by lower material and logistics costs, as well as lower promotions, partially offset by unfavorable product mix.

[0001032975-24-000008:mdna:39]
Operating expenses for the three months ended December 31, 2023 were $304.7 million, or 24.3% of sales, compared to $300.5 million, or 23.7% of sales, for the three months ended December 31, 2022. Operating expenses for the nine months ended December 31, 2023 were $883.9 million, or 26.9% of sales, compared to $956.0 million, or 26.7% of sales, for the nine months ended December 31, 2022. Operating expenses, for the three and nine months ended December 31, 2023, compared to the nine months ended December 31, 2022, were impacted by a reduction in marketing and advertising spend and an increase in personnel-related costs, mainly due to higher performance-based compensation.

[0001032975-24-000008:mdna:40]
We had an income tax benefit of $9.6 million and an income tax provision of $33.3 million for the three and nine months ended December 31, 2023, respectively, and an income tax provision of $42.7 million and $87.8 million for the three and nine months ended December 31, 2022, respectively. The change in the income tax provision (benefit) for the three and nine months ended December 31, 2023, compared to the three and nine months ended December 31, 2022, was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate as well as the favorable tax impacts from share-based compensation, an agreement to remeasure the tax basis of goodwill under the Swiss Federal Act on Tax Reform and AHV Financing (“TRAF”) with the canton of Vaud, remeasurement of our Swiss deferred tax assets due to a change in tax rate, and Foreign-Derived Intangible Income ("FDII") incentive provided by the Tax Cuts and Jobs Act.

[0001032975-24-000008:mdna:41]
Net income for the three and nine months ended December 31, 2023 was $244.7 million and $444.5 million, respectively, compared to $140.2 million and $323.1 million for the three and nine months ended December 31, 2022, respectively.

[0001032975-24-000008:mdna:42]
[same as prior period, unchanged from 0001032975-23-000080:mdna:37]

[0001032975-24-000008:mdna:43]
[same as prior period, unchanged from 0001032975-23-000080:mdna:38]

[0001032975-24-000008:mdna:44]
[same as prior period, unchanged from 0001032975-23-000080:mdna:39]

[0001032975-24-000008:mdna:45]
[same as prior period, unchanged from 0001032975-23-000080:mdna:40]

[0001032975-24-000008:mdna:46]
We believe that the assumptions, judgments and estimates involved in the accounting for accruals for customer incentives and related breakage when appropriate, accrued sales return liability, inventory valuation, and uncertain tax positions, have the greatest potential impact on our condensed consolidated financial statements. These areas are key components of our results of operations and are based on complex rules requiring us to make judgments and estimates and consequently, we consider these to be our critical accounting policies. Historically, our assumptions, judgments and estimates relative to our critical accounting policies have not differed materially from actual results.

[0001032975-24-000008:mdna:47]
There have been no material changes in our critical accounting estimates during the nine months ended December 31, 2023 compared with the critical accounting estimates disclosed in Management's Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended March 31, 2023.

[0001032975-24-000008:mdna:48]
New Accounting Pronouncements

[0001032975-24-000008:mdna:49]
Refer to Note 1 to the condensed consolidated financial statements included in this Quarterly Report on Form 10-Q for recent accounting pronouncements to be adopted.

[0001032975-24-000008:mdna:50]
[same as prior period, unchanged from 0001032975-23-000080:mdna:46]

[0001032975-24-000008:mdna:51]
[same as prior period, unchanged from 0001032975-23-000080:mdna:47]

[0001032975-24-000008:mdna:52]
[same as prior period, unchanged from 0001032975-23-000080:mdna:48]

[0001032975-24-000008:mdna:53]
[same as prior period, unchanged from 0001032975-23-000080:mdna:49]

[0001032975-24-000008:mdna:54]
[same as prior period, unchanged from 0001032975-23-000080:mdna:50]

[0001032975-24-000008:mdna:55]
[same as prior period, unchanged from 0001032975-23-000080:mdna:51]

[0001032975-24-000008:mdna:56]
[same as prior period, unchanged from 0001032975-23-000080:mdna:52]

[0001032975-24-000008:mdna:57]
Our sales for the three and nine months ended December 31, 2023 decreased 1% and 8%, compared to the three and nine months ended December 31, 2022, respectively, primarily due to a decline in sales of most of our product categories as a result of lower demand. If currency exchange rates had been constant in the three and nine months ended December 31, 2023 and 2022, our constant dollar sales reduction rates would have been 3% and 9%, respectively.

[0001032975-24-000008:mdna:58]
[same as prior period, unchanged from 0001032975-23-000080:mdna:54]

[0001032975-24-000008:mdna:59]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Australian Dollar, Canadian Dollar, Japanese Yen, Pound Sterling and New Taiwan Dollar. During the three months ended December 31, 2023, approximately 52% of our sales were denominated in currencies other than the U.S. Dollar.

[0001032975-24-000008:mdna:60]
[same as prior period, unchanged from 0001032975-23-000080:mdna:56]

[0001032975-24-000008:mdna:61]
The following table presents the change in sales by region for the three and nine months ended December 31, 2023, compared with the three and nine months ended December 31, 2022:

[0001032975-24-000008:mdna:62]
|  |  | Sales Growth Rate |  | Constant DollarSales Growth Rate |
|  |  | Three Months EndedDecember 31, 2023 |  | Nine Months EndedDecember 31, 2023 |  | Three Months EndedDecember 31, 2023 |  | Nine Months EndedDecember 31, 2023 |
| Americas |  | 5 | % |  | (4) | % |  | 4 | % |  | (4) | % |
| EMEA |  | (3) | % |  | (3) | % |  | (9) | % |  | (7) | % |
| Asia Pacific |  | (8) | % |  | (19) | % |  | (7) | % |  | (17) | % |

[0001032975-24-000008:mdna:63]
[same as prior period, unchanged from 0001032975-23-000080:mdna:59]

[0001032975-24-000008:mdna:64]
The increase in sales in the Americas region for the three-month period presented above was primarily driven by an increase in sales of Keyboards & Combos, Video Collaboration, and Webcams, partially offset by a decrease in sales of speakers in our Other category. The decrease in sales in the Americas region for the nine-month period presented above was primarily driven by a decrease in sales of speakers in our Other category, Video Collaboration, and Webcams, partially offset by an increase in sales of Tablet Accessories.

[0001032975-24-000008:mdna:65]
[same as prior period, unchanged from 0001032975-23-000080:mdna:61]

[0001032975-24-000008:mdna:66]
The decrease in sales in our EMEA region for the three-month period presented above was primarily driven by a decrease in sales of most of our product categories, partially offset by an increase in sales of Gaming and Pointing Devices. The decrease in EMEA region sales for the nine-month period was mainly due to a decrease in sales of Webcams and Video Collaboration, partially offset by an increase in sales of Pointing Devices and Gaming.

[0001032975-24-000008:mdna:67]
[same as prior period, unchanged from 0001032975-23-000080:mdna:63]

[0001032975-24-000008:mdna:68]
The decrease in sales in our Asia Pacific region for the three-month period presented above was primarily driven by a decrease in sales of Gaming and Video Collaboration. The decrease in sales in our Asia Pacific region for the nine-month period presented above was driven by decreases in sales of Gaming, Keyboards & Combos and Video Collaboration.

[0001032975-24-000008:mdna:69]
[same as prior period, unchanged from 0001032975-23-000080:mdna:65]

[0001032975-24-000008:mdna:70]
During the first quarter of fiscal year 2024, we changed the presentation of sales by product category to provide a simpler and clearer view of our business. The change in presentation did not have an impact on previously reported total sales. As a result of these changes, certain prior-period amounts for the three and nine months ended December 31, 2022 have been reclassified to conform to the current period presentation. See Note 1 to the condensed consolidated financial statements for further information on the change in presentation.

[0001032975-24-000008:mdna:71]
Sales by product category in the current presentation for the three and nine months ended December 31, 2023 and 2022 were as follows (dollars in thousands):

[0001032975-24-000008:mdna:72]
|  |  | Three months ended December 31, |  | Nine months ended December 31, |
|  |  | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Gaming (1) |  | $ | 409,043 |  |  | $ | 411,927 |  |  | (1) | % |  | $ | 957,576 |  |  | $ | 1,031,876 |  |  | (7) | % |
| Keyboards & Combos |  | 229,432 |  |  | 220,059 |  |  | 4 |  |  | 605,201 |  |  | 648,632 |  |  | (7) |  |
| Pointing Devices |  | 206,180 |  |  | 199,106 |  |  | 4 |  |  | 572,310 |  |  | 567,589 |  |  | 1 |  |
| Video Collaboration |  | 169,522 |  |  | 173,516 |  |  | (2) |  |  | 461,257 |  |  | 534,347 |  |  | (14) |  |
| Webcams |  | 85,851 |  |  | 94,252 |  |  | (9) |  |  | 249,273 |  |  | 305,532 |  |  | (18) |  |
| Tablet Accessories |  | 64,239 |  |  | 65,157 |  |  | (1) |  |  | 198,252 |  |  | 185,945 |  |  | 7 |  |
| Headsets |  | 41,762 |  |  | 46,736 |  |  | (11) |  |  | 123,023 |  |  | 137,429 |  |  | (10) |  |
| Other (2) |  | 49,444 |  |  | 59,172 |  |  | (16) |  |  | 120,088 |  |  | 167,391 |  |  | (28) |  |
| Total Sales |  | $ | 1,255,473 |  |  | $ | 1,269,925 |  |  | (1) | % |  | $ | 3,286,980 |  |  | $ | 3,578,741 |  |  | (8) | % |

[0001032975-24-000008:mdna:73]
[same as prior period, unchanged from 0001032975-23-000080:mdna:69]

[0001032975-24-000008:mdna:74]
[same as prior period, unchanged from 0001032975-23-000080:mdna:70]

[0001032975-24-000008:mdna:75]
[same as prior period, unchanged from 0001032975-23-000080:mdna:71]

[0001032975-24-000008:mdna:76]
Our Gaming category includes gaming mice, steering wheels, headsets, keyboards, console gaming headsets, studio-quality Blue Microphones and Streamlabs services.

[0001032975-24-000008:mdna:77]
Sales of Gaming decreased 1% for the three months ended December 31, 2023, compared to the three months ended December 31, 2022, primarily driven by a decrease in sales of gaming keyboards and gaming mice, partially offset by an increase in sales of gaming mouse pads. Sales of Gaming decreased 7% for the nine months ended December 31, 2023, compared to the nine months ended December 31, 2022, primarily driven by a decrease in sales of gaming steering wheels, gaming keyboards and gaming mice, partially offset by an increase in sales of gaming mouse pads.

[0001032975-24-000008:mdna:78]
[same as prior period, unchanged from 0001032975-23-000080:mdna:74]

[0001032975-24-000008:mdna:79]
[same as prior period, unchanged from 0001032975-23-000080:mdna:75]

[0001032975-24-000008:mdna:80]
Sales of Keyboards & Combos increased 4% for the three months ended December 31, 2023, compared to the three months ended December 31, 2022, primarily driven by an increase in sales of both cordless and corded keyboard/mice combo products, partially offset by a decrease in sales of cordless keyboards. Sales of Keyboards & Combos decreased 7% for the nine months ended December 31, 2023, compared to the nine months ended December 31, 2022, primarily driven by a decrease in sales of cordless keyboards, partially offset by an increase in sales of cordless keyboard/mice combo products.

[0001032975-24-000008:mdna:81]
[same as prior period, unchanged from 0001032975-23-000080:mdna:77]

[0001032975-24-000008:mdna:82]
[same as prior period, unchanged from 0001032975-23-000080:mdna:78]

[0001032975-24-000008:mdna:83]
Sales of Pointing Devices increased 4% for the three months ended December 31, 2023, compared to the three months ended December 31, 2022, primarily driven by an increase in sales of mouse pads and mouse cases. Sales of Pointing Devices increased 1% for the nine months ended December 31, 2023, compared to the nine months ended December 31, 2022, primarily driven by an increase in sales of mouse pads and mouse cases, partially offset by a decrease in sales of cordless mice.

[0001032975-24-000008:mdna:84]
[same as prior period, unchanged from 0001032975-23-000080:mdna:80]

[0001032975-24-000008:mdna:85]
[same as prior period, unchanged from 0001032975-23-000080:mdna:81]

[0001032975-24-000008:mdna:86]
Sales of Video Collaboration decreased 2% and 14% for the three and nine months ended December 31, 2023, compared to the three and nine months ended December 31, 2022, respectively, primarily due to a decrease in sales of many of our Video Collaboration products driven by lower enterprise spending.

[0001032975-24-000008:mdna:87]
[same as prior period, unchanged from 0001032975-23-000080:mdna:83]

[0001032975-24-000008:mdna:88]
[same as prior period, unchanged from 0001032975-23-000080:mdna:84]

[0001032975-24-000008:mdna:89]
Sales of Webcams decreased 9% and 18% for the three and nine months ended December 31, 2023, compared to the three and nine months ended December 31, 2022, respectively, primarily driven by declines in sales of our VC webcams and sales of our PC-based webcams.

[0001032975-24-000008:mdna:90]
[same as prior period, unchanged from 0001032975-23-000080:mdna:86]

[0001032975-24-000008:mdna:91]
[same as prior period, unchanged from 0001032975-23-000080:mdna:87]

[0001032975-24-000008:mdna:92]
Sales of Tablet Accessories decreased 1% for the three months ended December 31, 2023, compared to the three months ended December 31, 2022, primarily driven by a decrease in sales of Combo Touch iPad Pro 12.9-inch, partially offset by an increase in sales of Combo Touch. Sales of Tablet Accessories increased 7% for the nine months ended December 31, 2023, compared to the nine months ended December 31, 2022, primarily driven by an increase in sales of our Rugged Combo 3 Touch as well as Combo Touch, introduced in the third quarter of fiscal year 2023, partially offset by the decrease in sales of Rugged Folio. Sales of Tablet Accessories for the nine months ended December 31, 2023, compared to the nine months ended December 31, 2022, benefited from strong demand from the education sector.

[0001032975-24-000008:mdna:93]
[same as prior period, unchanged from 0001032975-23-000080:mdna:89]

[0001032975-24-000008:mdna:94]
[same as prior period, unchanged from 0001032975-23-000080:mdna:90]

[0001032975-24-000008:mdna:95]
Sales of Headsets decreased 11% and 10% for the three and nine months ended December 31, 2023, compared to the three and nine months ended December 31, 2022, respectively, primarily driven by a decrease in sales of VC headsets and corded PC headsets.

[0001032975-24-000008:mdna:96]
[same as prior period, unchanged from 0001032975-23-000080:mdna:92]

[0001032975-24-000008:mdna:97]
[same as prior period, unchanged from 0001032975-23-000080:mdna:93]

[0001032975-24-000008:mdna:98]
Sales in Other category decreased 16% and 28% for the three and nine months ended December 31, 2023, compared to the three and nine months ended December 31, 2022, respectively, primarily driven by a decrease in sales of mobile speakers.

[0001032975-24-000008:mdna:99]
[same as prior period, unchanged from 0001032975-23-000080:mdna:95]

[0001032975-24-000008:mdna:100]
Gross profit for the three and nine months ended December 31, 2023 and 2022 was as follows (dollars in thousands):

[0001032975-24-000008:mdna:101]
|  |  | Three months ended December 31, |  | Nine months ended December 31, |
|  |  | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Net sales |  | $ | 1,255,473 |  | $ | 1,269,925 |  | (1) | % |  | $ | 3,286,980 |  | $ | 3,578,741 |  | (8) | % |
| Gross profit |  | $ | 526,780 |  | $ | 477,268 |  | 10 | % |  | $ | 1,341,044 |  | $ | 1,375,651 |  | (3) | % |
| Gross margin |  | 42.0 | % |  | 37.6 | % |  |  |  | 40.8 | % |  | 38.4 | % |  |  |

[0001032975-24-000008:mdna:102]
[same as prior period, unchanged from 0001032975-23-000080:mdna:98]

[0001032975-24-000008:mdna:103]
Gross margin was 42.0% and 40.8% for the three and nine months ended December 31, 2023, respectively, and increased by 440 and 240 basis points, compared to the three and nine months ended December 31, 2022, respectively; primarily driven by lower material and logistics costs, as well as lower promotions, partially offset by unfavorable product mix.

[0001032975-24-000008:mdna:104]
[same as prior period, unchanged from 0001032975-23-000080:mdna:100]

[0001032975-24-000008:mdna:105]
Operating expenses for the three and nine months ended December 31, 2023 and 2022 were as follows (dollars in thousands):

[0001032975-24-000008:mdna:106]
|  |  | Three months ended December 31, |  | Nine months ended December 31, |  |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |
| Marketing and selling |  | $ | 189,175 |  |  | $ | 196,653 |  |  | $ | 544,716 |  |  | $ | 628,122 |  |  |
| % of sales |  | 15.1 | % |  | 15.5 | % |  | 16.6 | % |  | 17.6 | % |  |
| Research and development |  | 72,704 |  |  | 65,640 |  |  | 211,822 |  |  | 210,166 |  |  |
| % of sales |  | 5.8 | % |  | 5.2 | % |  | 6.4 | % |  | 5.9 | % |  |
| General and administrative |  | 39,711 |  |  | 29,766 |  |  | 116,546 |  |  | 92,215 |  |  |
| % of sales |  | 3.2 | % |  | 2.3 | % |  | 3.5 | % |  | 2.6 | % |  |
| Amortization of intangible assets and acquisition-related costs |  | 2,276 |  |  | 2,810 |  |  | 8,279 |  |  | 9,052 |  |  |
| % of sales |  | 0.2 | % |  | 0.2 | % |  | 0.3 | % |  | 0.3 | % |  |
| Restructuring charges, net |  | 839 |  |  | 5,654 |  |  | 2,562 |  |  | 16,471 |  |  |
| % of sales |  | 0.1 | % |  | 0.4 | % |  | 0.1 | % |  | 0.5 | % |  |
| Total operating expenses |  | $ | 304,705 |  |  | $ | 300,523 |  |  | $ | 883,925 |  |  | $ | 956,026 |  |  |
| % of sales |  | 24.3 | % |  | 23.7 | % |  | 26.9 | % |  | 26.7 | % |  |

[0001032975-24-000008:mdna:107]
The increase in total operating expenses for the three months ended December 31, 2023, compared to the three months ended December 31, 2022, was primarily driven by an increase in general and administrative expenses, partially offset by a decrease in marketing and selling expenses. The decrease in total operating expenses for the nine months ended December 31, 2023, compared to the nine months ended December 31, 2022, was primarily driven by a decrease in marketing and selling expenses, partially offset by an increase in general and administrative expenses.

[0001032975-24-000008:mdna:108]
[same as prior period, unchanged from 0001032975-23-000080:mdna:104]

[0001032975-24-000008:mdna:109]
[same as prior period, unchanged from 0001032975-23-000080:mdna:105]

[0001032975-24-000008:mdna:110]
During the three months ended December 31, 2023, marketing and selling expenses decreased $7.5 million, compared to the three months ended December 31, 2022, primarily driven by our reduction in third-party marketing and advertising spend, partially offset by higher performance-based compensation expense. During the nine months ended December 31, 2023, marketing and selling expenses decreased $83.4 million, compared to the nine months ended December 31, 2022, primarily driven by our reduction in third-party marketing and advertising spend.

[0001032975-24-000008:mdna:111]
[same as prior period, unchanged from 0001032975-23-000080:mdna:107]

[0001032975-24-000008:mdna:112]
[same as prior period, unchanged from 0001032975-23-000080:mdna:108]

[0001032975-24-000008:mdna:113]
During the three months ended December 31, 2023, research and development expenses increased $7.1 million, compared to the three months ended December 31, 2022, primarily driven by higher performance-based compensation expense. During the nine months ended December 31, 2023, research and development expenses increased $1.7 million, compared to the nine months ended December 31, 2022, primarily due to higher performance-based compensation expense, partially offset by lower outsourcing costs.

[0001032975-24-000008:mdna:114]
Research and development expenses as a percentage of sales increased from 5.2% and 5.9% in the three and nine months ended December 31, 2022, respectively, to 5.8% and 6.4% in the three and nine months ended December 31, 2023, respectively, reflecting our continued investment in innovation.

[0001032975-24-000008:mdna:115]
[same as prior period, unchanged from 0001032975-23-000080:mdna:111]

[0001032975-24-000008:mdna:116]
[same as prior period, unchanged from 0001032975-23-000080:mdna:112]

[0001032975-24-000008:mdna:117]
During the three and nine months ended December 31, 2023, general and administrative expenses increased $9.9 million and $24.3 million, respectively, compared to the three and nine months ended December 31, 2022, primarily driven by higher performance-based compensation expense.

[0001032975-24-000008:mdna:118]
[same as prior period, unchanged from 0001032975-23-000080:mdna:114]

[0001032975-24-000008:mdna:119]
[same as prior period, unchanged from 0001032975-23-000080:mdna:115]

[0001032975-24-000008:mdna:120]
During the three and nine months ended December 31, 2023, amortization of intangible assets and acquisition-related costs remained relatively flat, compared to the three and nine months ended December 31, 2022.

[0001032975-24-000008:mdna:121]
Restructuring Charges, Net

[0001032975-24-000008:mdna:122]
The restructuring charges, net for the three and nine months ended December 31, 2023 and 2022, were related to costs incurred as a result of our restructuring plan initiated during fiscal year 2023. We expect to substantially complete this restructuring plan within fiscal year 2024.

[0001032975-24-000008:mdna:123]
[same as prior period, unchanged from 0001032975-23-000080:mdna:119]

[0001032975-24-000008:mdna:124]
[same as prior period, unchanged from 0001032975-23-000080:mdna:120]

[0001032975-24-000008:mdna:125]
Interest income for the three and nine months ended December 31, 2023 and 2022 was as follows (in thousands):

[0001032975-24-000008:mdna:126]
|  |  | Three months ended December 31, |  | Nine months ended December 31, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Interest Income |  | $ | 12,826 |  |  | $ | 4,665 |  |  | $ | 34,508 |  |  | $ | 9,573 |  |

[0001032975-24-000008:mdna:127]
We invest in highly liquid instruments with an original maturity of three months or less at the date of purchase, which are classified as cash equivalents. During the three and nine months ended December 31, 2023, interest income increased $8.2 million and $24.9 million, compared to the three and nine months ended December 31, 2022, respectively, primarily driven by an increase in interest rates.

[0001032975-24-000008:mdna:128]
[same as prior period, unchanged from 0001032975-23-000080:mdna:124]

[0001032975-24-000008:mdna:129]
Other income (expense), net for the three and nine months ended December 31, 2023 and 2022 was as follows (in thousands):

[0001032975-24-000008:mdna:130]
|  |  | Three months ended December 31, |  | Nine months ended December 31, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Investment gain (loss) related to the deferred compensation plan |  | $ | 2,061 |  |  | $ | 758 |  |  | $ | 2,761 |  |  | $ | (3,390) |  |
| Currency exchange gain (loss), net |  | (1,850) |  |  | 1,734 |  |  | (6,648) |  |  | (3,278) |  |
| Loss on investments, net |  | (604) |  |  | (1,488) |  |  | (12,213) |  |  | (13,065) |  |
| Non-service cost net pension income and other |  | 582 |  |  | 402 |  |  | 2,273 |  |  | 1,366 |  |
| Total |  | $ | 189 |  |  | $ | 1,406 |  |  | $ | (13,827) |  |  | $ | (18,367) |  |

[0001032975-24-000008:mdna:131]
Investment gain (loss) related to the deferred compensation plan represents earnings, gains, and losses on marketable securities related to a deferred compensation plan offered by one of our subsidiaries. The investment gain or loss for three and nine months ended December 31, 2023, compared to the three and nine months ended December 31, 2022, primarily relates to the change in market performance of the underlying securities.

[0001032975-24-000008:mdna:132]
Currency exchange gain (loss), net, relates to balances denominated in currencies other than the functional currency in our subsidiaries, as well as to the sale of currencies, and gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses. The loss for the three months ended December 31, 2023 was primarily due to fluctuations in currency exchange rates of the Chinese Renminbi and Swedish Krona against the U.S. Dollar. The gain for the three months ended December 31, 2022 was primarily due to strengthening of the Japanese Yen against the U.S. Dollar. The loss for the nine months ended December 31, 2023 was primarily due to fluctuations in currency exchange rates of the Chinese Renminbi, Brazilian Real, and Australian Dollar against the U.S. Dollar. The loss for the nine months ended December 31, 2022 was primarily due to weakening of the Brazilian Real and the Australian Dollar.

[0001032975-24-000008:mdna:133]
Loss on investments, net, includes unrealized gain (loss) from the change in fair value of investments, gain (loss) on equity-method investments and impairment of investments during the periods presented, as applicable. The loss on investments, net, for the nine months ended December 31, 2023 was primarily due to an impairment loss, as a result of the write-off of a note receivable which has been deemed no longer recoverable. This note receivable was previously obtained in conjunction with an exchange transaction related to our investment in a privately held company. The loss on investments, net, for the nine months ended December 31, 2022 was primarily due to an impairment charge related to one of our equity method investments, partially offset by the unrealized gain related to one of our equity investments without readily determinable fair value resulting from observable price changes. See Note 6 to our condensed consolidated financial statements for additional information.

[0001032975-24-000008:mdna:134]
[same as prior period, unchanged from 0001032975-23-000080:mdna:130]

[0001032975-24-000008:mdna:135]
The provision for (benefit from) income taxes and effective income tax rates for the three and nine months ended December 31, 2023 and 2022 were as follows (dollars in thousands):

[0001032975-24-000008:mdna:136]
|  |  | Three months ended December 31, |  | Nine months ended December 31, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Provision for (benefit from) income taxes |  | $ | (9,594) |  |  | $ | 42,663 |  |  | $ | 33,272 |  |  | $ | 87,751 |  |
| Effective income tax rate |  | (4.1) | % |  | 23.3 | % |  | 7.0 | % |  | 21.4 | % |

[0001032975-24-000008:mdna:137]
The change in the effective income tax rate for the three and nine months ended December 31, 2023 compared with the three and nine months ended December 31, 2022 was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate as well as the favorable tax impacts from share-based compensation, an agreement to remeasure the tax basis of goodwill under TRAF with the canton of Vaud, remeasurement of our Swiss deferred tax assets due to a change in tax rate, and FDII incentive provided by the Tax Cuts and Jobs Act.

[0001032975-24-000008:mdna:138]
The canton of Vaud completed the legislative process to enact TRAF, a reform to better align the Swiss tax system to international tax standards, on March 10, 2020 to take effect as of January 1, 2020. In March 2020, we reached an agreement with the Vaud Tax Administration that would allow for an increase in the tax basis of goodwill, as a transition measure under TRAF, to be amortized over ten years beginning on January 1, 2020. During the three months ended December 31, 2023, we reached an agreement to remeasure the tax basis of goodwill under TRAF with the canton of Vaud, which resulted in an income tax benefit of $25.1 million, net of assessment of uncertain tax positions. The remeasurement of the step-up will be amortized over the remaining ten-year amortization period.

[0001032975-24-000008:mdna:139]
On December 29, 2023, a change to the cantonal tax legislation was published. According to the law approved by the Vaud parliament, a progressive scale will be applicable for cantonal tax purposes resulting in an increase from the current tax rate of 13.61% to 14.28% effective fiscal year 2025. The increase in tax rate resulted in a tax benefit of $5.1 million due to a remeasurement of our Swiss deferred tax assets in the fiscal quarter ended December 31, 2023.

[0001032975-24-000008:mdna:140]
The Tax Cuts and Jobs Act enacted Section 250, which provides for a deduction with respect to Global Intangible Low-Taxed Income ("GILTI") and FDII in the US. The application of this tax incentive is inherently complex. During the three months ended December 31, 2023, we analyzed the applicability of FDII and determined that this tax incentive applies to fiscal 2021 to 2023 tax years. As a result, we realized a tax benefit of $17.9 million related to FDII. We have also concluded that any GILTI tax since the enactment of Tax Cuts and Jobs Act would be immaterial.

[0001032975-24-000008:mdna:141]
[same as prior period, unchanged from 0001032975-23-000080:mdna:134]

[0001032975-24-000008:mdna:142]
[same as prior period, unchanged from 0001032975-23-000080:mdna:135]

[0001032975-24-000008:mdna:143]
As of December 31, 2023, we had cash and cash equivalents of $1,412.7 million, compared with $1,149.0 million as of March 31, 2023. Our cash and cash equivalents consist of bank demand deposits, short-term time deposits, and U.S. Treasury securities, of which 64% is held in Switzerland and 16% were held in China (including Hong Kong). We do not expect to incur any material adverse tax impact except for what has already been recognized, or to be significantly inhibited by any country in which we do business, from the repatriation of funds to Switzerland, our country of domicile.

[0001032975-24-000008:mdna:144]
As of December 31, 2023, our working capital was $1,495.0 million, compared to $1,555.1 million as of March 31, 2023. The decrease was driven by a reduction in inventories and an increase in accounts payable, partially offset by an increase in cash and cash equivalents and accounts receivable.

[0001032975-24-000008:mdna:145]
We had several uncommitted, unsecured bank lines of credit and letters of credit aggregating $176.1 million as of December 31, 2023. There are no financial covenants under these lines of credit with which we must comply. There was no borrowing outstanding under the lines of credit as of December 31, 2023. As of December 31, 2023, we had outstanding bank guarantees of $11.1 million.

[0001032975-24-000008:mdna:146]
The following tables present selected financial information and statistics as of and for the three months ended December 31, 2023 and 2022 (dollars in thousands):

[0001032975-24-000008:mdna:147]
|  |  | As of December 31, |  |
|  |  | 2023 |  | 2022 |  |
| Accounts receivable, net |  | $ | 685,777 |  |  | $ | 802,435 |  |  |
| Accounts payable |  | $ | 527,988 |  |  | $ | 491,488 |  |  |
| Inventories |  | $ | 447,262 |  |  | $ | 797,695 |  |  |

[0001032975-24-000008:mdna:148]
|  |  | Three months ended December 31, |  |
|  |  | 2023 |  | 2022 |  |
| Days sales in accounts receivable (“DSO”) (Days)(1) |  | 49 |  |  | 57 |  |  |
| Days accounts payable outstanding (“DPO”) (Days)(2) |  | 65 |  |  | 56 |  |  |
| Inventory turnover (“ITO”) (x)(3) |  | 6.5 |  |  | 4.0 |  |  |

[0001032975-24-000008:mdna:149]
(1) DSO is determined using ending accounts receivable, net, as of the most recent quarter-end and sales for the most recent quarter.

[0001032975-24-000008:mdna:150]
[same as prior period, unchanged from 0001032975-23-000080:mdna:144]

[0001032975-24-000008:mdna:151]
(3) ITO is determined using ending inventories as of the most recent quarter-end and annualized cost of goods sold (based on the most recent quarterly cost of goods sold).

[0001032975-24-000008:mdna:152]
DSO for the three months ended December 31, 2023 decreased by 8 days to 49 days, compared to 57 days for the three months ended December 31, 2022, primarily due to the timing of sales within the quarter.

[0001032975-24-000008:mdna:153]
DPO for the three months ended December 31, 2023 increased by 9 days to 65 days, compared to 56 days for the three months ended December 31, 2022, primarily due to softened demand as well as higher inventory purchases to replenish certain products.

[0001032975-24-000008:mdna:154]
ITO for the three months ended December 31, 2023 increased by 2.5 to 6.5, compared to 4.0 for the three months ended December 31, 2022, primarily due to lower inventory as of December 31, 2023 resulting from focused inventory management to align with softened demand.

[0001032975-24-000008:mdna:155]
[same as prior period, unchanged from 0001032975-23-000080:mdna:149]

[0001032975-24-000008:mdna:156]
[same as prior period, unchanged from 0001032975-23-000080:mdna:150]

[0001032975-24-000008:mdna:157]
|  |  | Nine months ended December 31, |
|  |  | 2023 |  | 2022 |
| Net cash provided by operating activities |  | $ | 906,011 |  |  | $ | 317,167 |  |
| Net cash used in investing activities |  | (59,829) |  |  | (80,711) |  |
| Net cash used in financing activities |  | (578,475) |  |  | (505,035) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (4,080) |  |  | (24,006) |  |
| Net increase (decrease) in cash and cash equivalents |  | $ | 263,627 |  |  | $ | (292,585) |  |

[0001032975-24-000008:mdna:158]
For the nine months ended December 31, 2023, net cash provided by operating activities was $906.0 million resulting from net income of $444.5 million, a favorable impact from adding back non-cash expenses totaling $132.7 million, and a favorable net change in operating assets and liabilities of $328.8 million. Non-cash expenses were primarily related to share-based compensation expenses, and depreciation and amortization. The increase in accounts receivable, net, was primarily driven by higher sales due to seasonality of our business. The decrease in inventories was primarily driven by our effort to manage inventory level. The increase in accounts payable was due to higher inventory purchases to replenish certain products. The increase in accrued and other liabilities was primarily driven by an increase in accrued personnel expenses, partially offset by a reduction in accrued liabilities related to our customer marketing, pricing and incentive programs and sales return.

[0001032975-24-000008:mdna:159]
For the nine months ended December 31, 2023, net cash used in investing activities was $59.8 million, primarily resulting from $45.6 million of purchases of property, plant, and equipment and $14.1 million payments for acquisitions, net of cash acquired.

[0001032975-24-000008:mdna:160]
For the nine months ended December 31, 2023, net cash used in financing activities was $578.5 million, primarily resulting from payment for repurchases of our registered shares of $376.8 million and payment of cash dividends of $182.3 million.

[0001032975-24-000008:mdna:161]
For the nine months ended December 31, 2023, there was a $4.1 million loss from currency exchange rate effect on cash and cash equivalents, primarily due to exchange rate fluctuations of Swiss Franc, Chinese Renminbi, and Euro versus the U.S. Dollar, and timing of our cash transactions over the period. The loss from currency translation exchange rate effect during the nine months ended December 31, 2022 was primarily due to exchange rate fluctuations of Euro, Swiss Franc, Chinese Renminbi, and Australian Dollar versus the U.S. Dollar and timing of our cash transactions over the period.

[0001032975-24-000008:mdna:162]
[same as prior period, unchanged from 0001032975-23-000080:mdna:156]

[0001032975-24-000008:mdna:163]
[same as prior period, unchanged from 0001032975-23-000080:mdna:157]

[0001032975-24-000008:mdna:164]
[same as prior period, unchanged from 0001032975-23-000080:mdna:158]

[0001032975-24-000008:mdna:165]
In May 2020, our Board of Directors approved the 2020 share repurchase program, which authorized us to invest up to $250.0 million to purchase our own shares to support equity incentive plans or potential acquisitions. In April 2021, our Board of Directors approved an increase of $750.0 million to the 2020 share repurchase program, to an aggregate amount of $1.0 billion. The Swiss Takeover Board approved this increase and it became effective on May 21, 2021. In July 2022, our Board of Directors approved an increase of $500 million to the 2020 share repurchase program to an aggregate amount of up to $1.5 billion. The Swiss Takeover Board approved this increase and it became effective on August 19, 2022. The 2020 share repurchase program expired on July 27, 2023. We repurchased 16.7 million shares for an aggregate cost of $1.2 billion under the 2020 share repurchase program, of which 2.6 million shares for an aggregate cost of $159.1 million were repurchased during fiscal year 2024 prior to the expiration of the program.

[0001032975-24-000008:mdna:166]
In June 2023, our Board of Directors approved a new, three-year share repurchase program, which allows us to use up to $1.0 billion to repurchase our shares. The 2023 share repurchase program enables us to repurchase shares for cancellation, as well as to support equity incentive plans or potential acquisitions. The Swiss Takeover Board approved the 2023 share repurchase program in July 2023 and the program became effective on July 28, 2023. During the nine months ended December 31, 2023, we repurchased 3.0 million shares for an aggregate cost of $232.5 million, under the 2023 share repurchase program for cancellation, of which $14.8 million of the aggregate cost was not paid yet as of December 31, 2023. As of December 31, 2023, $767.8 million was available for repurchase under the 2023 share repurchase program.

[0001032975-24-000008:mdna:167]
[same as prior period, unchanged from 0001032975-23-000080:mdna:161]

[0001032975-24-000008:mdna:168]
approximately 17.3 million registered shares. This limitation does not apply to shares repurchased for cancellation, due to the Board of Directors' authority under the capital band set forth in the Company's Articles of Incorporation to cancel shares up to a limit of 10% of our current share capital. As of December 31, 2023, we had a total of 18.1 million shares held in treasury stock, which includes 3.0 million shares that have been repurchased for cancellation.

[0001032975-24-000008:mdna:169]
[same as prior period, unchanged from 0001032975-23-000080:mdna:163]

[0001032975-24-000008:mdna:170]
[same as prior period, unchanged from 0001032975-23-000080:mdna:164]

[0001032975-24-000008:mdna:171]
[same as prior period, unchanged from 0001032975-23-000080:mdna:165]

[0001032975-24-000008:mdna:172]
[same as prior period, unchanged from 0001032975-23-000080:mdna:166]

[0001032975-24-000008:mdna:173]
[same as prior period, unchanged from 0001032975-23-000080:mdna:167]

[0001032975-24-000008:mdna:174]
As of December 31, 2023, we had non-cancelable purchase commitments of $344.0 million for inventory purchases made in the normal course of business from original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. We record a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with our valuation of excess and obsolete inventory. As of December 31, 2023, the liability for these purchase commitments was $33.8 million and is recorded in accrued and other current liabilities in the condensed consolidated balance sheet.

[0001032975-24-000008:mdna:175]
We have firm purchase commitments of $14.0 million for capital expenditures primarily related to commitments for tooling and equipment for new and existing products. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-24-000008:mdna:176]
[same as prior period, unchanged from 0001032975-23-000080:mdna:170]

[0001032975-24-000008:mdna:177]
[same as prior period, unchanged from 0001032975-23-000080:mdna:171]

[0001032975-24-000008:mdna:178]
[same as prior period, unchanged from 0001032975-23-000080:mdna:172]

[0001032975-24-000008:mdna:179]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2023, no material amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-24-000008:mdna:180]
We also indemnify our current and former directors and certain current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. We are unable to

[0001032975-24-000008:mdna:181]
reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not capped, the obligations are conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-24-000008:mdna:182]
Legal Proceedings

[0001032975-24-000008:mdna:183]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of our business. For more information about Legal Proceedings, see Part II Item 1 Legal Proceedings of this quarterly report on Form 10-Q for the period ended December 31, 2023.
