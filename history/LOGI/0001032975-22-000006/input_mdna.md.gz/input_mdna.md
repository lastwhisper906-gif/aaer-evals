# LOGI MD&A — 0001032975-22-000006


## mdna

[0001032975-22-000006:mdna:1]
[same as prior period, unchanged from 0001032975-21-000045:mdna:1]

[0001032975-22-000006:mdna:2]
[same as prior period, unchanged from 0001032975-21-000045:mdna:2]

[0001032975-22-000006:mdna:3]
[same as prior period, unchanged from 0001032975-21-000045:mdna:3]

[0001032975-22-000006:mdna:4]
[same as prior period, unchanged from 0001032975-21-000045:mdna:4]

[0001032975-22-000006:mdna:5]
Logitech G, ASTRO Gaming, Streamlabs, Blue Microphones, and Ultimate Ears. Our Company's website is www.logitech.com.

[0001032975-22-000006:mdna:6]
Our products participate in five large market opportunities: Creativity & Productivity, Gaming, Video Collaboration, Music and Smart Home. We sell our products to a broad network of domestic and international customers, including direct sales to retailers, e-tailers and enterprise customers, and indirect sales through distributors. Our worldwide channel network includes consumer electronics distributors, retailers, mass merchandisers, specialty stores, computer and telecommunications stores, value-added resellers and online merchants. We primarily sell our services directly to end customers.

[0001032975-22-000006:mdna:7]
[same as prior period, unchanged from 0001032975-21-000045:mdna:8]

[0001032975-22-000006:mdna:8]
[same as prior period, unchanged from 0001032975-21-000045:mdna:9]

[0001032975-22-000006:mdna:9]
In March 2020, the World Health Organization declared the outbreak of a novel coronavirus ("COVID-19") as a pandemic, which continues to spread throughout the world. The spread of COVID-19 has caused public health officials to recommend precautions to mitigate the spread of the virus and, in certain markets in which we operate, government authorities have from time to time issued orders that require the closure of or restrictions on non-essential businesses and people to be quarantined or to shelter-at-home. The COVID-19 pandemic has curtailed global economic activity, caused volatility and disruption in global financial and commercial markets, and is likely to continue to cause uncertainty for an indeterminate amount of time. While most of our offices have at least partially reopened or will be reopening in the near future, we are conducting our business with substantial modifications, such as employee remote work in many non-manufacturing facilities and travel limitations, among other changes. We are continuing to actively monitor the situation and may take further actions that alter our business operations as may be required by federal, state or local authorities in the countries in which we operate, or that we determine are in the best interest of our employees, customers, partners, suppliers or shareholders.

[0001032975-22-000006:mdna:10]
In fiscal year 2021, we experienced disruptions to our supply chain and logistics, inventory constraints, and increased logistics costs, as we attempted to address the effects of COVID-19. At the same time, due to the shelter-at-home requirements or other restrictions in many countries, there was an acceleration of work-from-anywhere, learn-from-anywhere, gaming, video collaboration and streaming trends and high demand and consumption of certain of our products that led to increased sales and operating income. While we continued to experience increased sales in the first nine months of fiscal year 2022 compared to the first nine months of fiscal year 2021, we also experienced supply and demand volatility, as the COVID-19 pandemic and related safety measures and restrictions have evolved differently across the world. Further, the demand volatility has led to, and could continue to lead to in the future, higher promotions and marketing expenses, or excess inventories, or both, which could have an adverse impact on our results of operations.

[0001032975-22-000006:mdna:11]
[same as prior period, unchanged from 0001032975-21-000045:mdna:12]

[0001032975-22-000006:mdna:12]
[same as prior period, unchanged from 0001032975-21-000045:mdna:13]

[0001032975-22-000006:mdna:13]
29

[0001032975-22-000006:mdna:14]
[same as prior period, unchanged from 0001032975-21-000045:mdna:15]

[0001032975-22-000006:mdna:15]
Our total sales for the three and nine months ended December 31, 2021 decreased 2% and increased 14%, respectively, compared to the three and nine months ended December 31, 2020. Our condensed consolidated statements of operations for the three and nine months ended December 31, 2021 include the results of operations for our first quarter acquisition from its date of acquisition.

[0001032975-22-000006:mdna:16]
Sales for the three months ended December 31, 2021 increased 1% in the EMEA region, and decreased 4% and 2% in the Americas and Asia Pacific regions, respectively, compared to the same period of the prior fiscal year. Sales for the nine months ended December 31, 2021 increased 14%, 14%, and 15% in the Americas, EMEA and Asia Pacific, respectively, compared to the same period of the prior fiscal year.

[0001032975-22-000006:mdna:17]
Gross margin for the three months ended December 31, 2021 decreased by 460 basis points to 40.3% from 44.9% for the three months ended December 31, 2020. Gross margin for the nine months ended December 31, 2021 decreased by 210 basis points to 41.6% from 43.7% for the nine months ended December 31, 2020.

[0001032975-22-000006:mdna:18]
Operating expenses for the three months ended December 31, 2021 were $395.3 million, or 24.2% of sales, compared to $300.9 million, or 18.0% of sales, in the same period of the prior fiscal year. Operating expenses for the nine months ended December 31, 2021 were $1,123.9 million, or 26.4% of sales, compared to $771.4 million, or 20.8% of sales, in the same period of the prior fiscal year.

[0001032975-22-000006:mdna:19]
Net income for the three and nine months ended December 31, 2021 was $210.0 million and $536.3 million, respectively, compared to $382.5 million and $721.5 million for the three and nine months ended December 31, 2020, respectively.

[0001032975-22-000006:mdna:20]
[same as prior period, unchanged from 0001032975-21-000045:mdna:21]

[0001032975-22-000006:mdna:21]
[same as prior period, unchanged from 0001032975-21-000045:mdna:22]

[0001032975-22-000006:mdna:22]
[same as prior period, unchanged from 0001032975-21-000045:mdna:23]

[0001032975-22-000006:mdna:23]
Creativity & Productivity: New PC shipments have continued to be strong due to work-from-home and learn-from-home trends. We believe that innovative PC peripherals, such as our mice and keyboards, can renew the PC usage experience and help improve the productivity and engagement of remote work and learning, thus providing growth opportunities. Hybrid work culture will also greatly expand the number of new workspaces to which we can attach our PC peripherals. Increasing adoption of various cloud-based applications has led to multiple unique consumer use cases, which we are addressing with our innovative product portfolio and a deep understanding of our customer base. The increasing popularity of streaming and broadcasting, as well as the continuing work-from-home trend, provides additional growth opportunities for our webcam products as well as other products in our portfolio. Smaller mobile computing devices, such as tablets, have created new markets and usage models for peripherals and accessories. We offer a number of products to enhance the use of mobile devices, including a combo backlit keyboard case with trackpad for the iPad.

[0001032975-22-000006:mdna:24]
Gaming: The PC gaming and console gaming platforms continue to show strong structural growth opportunities as online gaming, multi-platform experiences, and esports gain greater popularity and gaming becomes more social, particularly as other recreational activities have been curtailed or restricted during the COVID-19 pandemic. We expect gaming will increasingly become one of the largest participant and spectator sports in the world. We believe Logitech is well positioned to benefit from the overall gaming market growth. In addition, our acquisition of Streamlabs provides a solid platform to deliver recurring services and subscriptions to gamers and streamers.

[0001032975-22-000006:mdna:25]
Video Collaboration: The near and long-term structural growth opportunities in the video collaboration market ("VC") have never been more prevalent than in today’s environment, as commercial and consumer adoption of video has seen substantial growth since the start of the COVID-19 pandemic. Video meetings continue to be an opportunity as companies want lower-cost, cloud-based solutions that can provide their employees with the ability to work from anywhere. We are continuing our efforts to create and sell innovative products to accommodate the

[0001032975-22-000006:mdna:26]
30

[0001032975-22-000006:mdna:27]
increasing demand from home offices and small-size meeting rooms, such as huddle rooms, to medium and large-sized meeting rooms. We will continue to invest in the development of select business-specific products (both hardware and software), targeted product marketing and sales channel development. The digitization of learning and hybrid learning environments have also created demand and growth opportunities in the education market.

[0001032975-22-000006:mdna:28]
Music: Consumers are optimizing their audio experiences on their tablets and smartphones with a variety of music peripherals including wireless mobile speakers and in-ear and other headphones. However, the mobile speaker market has matured and the integration of personal voice assistants has increased competition in the speaker category. In addition, the retail footprint has decreased significantly due to the COVID-19 pandemic. These factors have led to a decline in our Mobile Speakers category sales in the past three years. In the wireless headphone industry, the largest growth in recent years has been in true wireless headphones while traditional wireless headphones have declined significantly. We will continue developing wireless audio products as growth in the wireless headphone market is expected for the next several years.

[0001032975-22-000006:mdna:29]
Smart Home: Sales of our Harmony universal remote and Circle security family of products declined substantially in the three and nine months ended December 31, 2021. In general, our sales of Harmony and Circle products are under pressure as the way people consume content is changing and as retail stores have been closed or subject to restrictions. The smart home market opportunity is broad, and we will continue to explore other innovative experiences to drive growth in the Smart Home category.

[0001032975-22-000006:mdna:30]
[same as prior period, unchanged from 0001032975-21-000045:mdna:31]

[0001032975-22-000006:mdna:31]
[same as prior period, unchanged from 0001032975-21-000045:mdna:32]

[0001032975-22-000006:mdna:32]
[same as prior period, unchanged from 0001032975-21-000045:mdna:33]

[0001032975-22-000006:mdna:33]
[same as prior period, unchanged from 0001032975-21-000045:mdna:34]

[0001032975-22-000006:mdna:34]
[same as prior period, unchanged from 0001032975-21-000045:mdna:35]

[0001032975-22-000006:mdna:35]
[same as prior period, unchanged from 0001032975-21-000045:mdna:36]

[0001032975-22-000006:mdna:36]
[same as prior period, unchanged from 0001032975-21-000045:mdna:37]

[0001032975-22-000006:mdna:37]
There have been no material changes in our critical accounting policies and estimates during the nine months ended December 31, 2021 compared with the critical accounting policies and estimates disclosed in Management's Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended March 31, 2021.

[0001032975-22-000006:mdna:38]
[same as prior period, unchanged from 0001032975-21-000045:mdna:40]

[0001032975-22-000006:mdna:39]
[same as prior period, unchanged from 0001032975-21-000045:mdna:41]

[0001032975-22-000006:mdna:40]
[same as prior period, unchanged from 0001032975-21-000045:mdna:42]

[0001032975-22-000006:mdna:41]
[same as prior period, unchanged from 0001032975-21-000045:mdna:43]

[0001032975-22-000006:mdna:42]
[same as prior period, unchanged from 0001032975-21-000045:mdna:44]

[0001032975-22-000006:mdna:43]
[same as prior period, unchanged from 0001032975-21-000045:mdna:45]

[0001032975-22-000006:mdna:44]
[same as prior period, unchanged from 0001032975-21-000045:mdna:46]

[0001032975-22-000006:mdna:45]
[same as prior period, unchanged from 0001032975-21-000045:mdna:47]

[0001032975-22-000006:mdna:46]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Canadian Dollar, Taiwan New Dollar, British Pound and Australian Dollar. During the three months ended December 31, 2021, approximately 53% of our sales were denominated in currencies other than the U.S. Dollar.

[0001032975-22-000006:mdna:47]
[same as prior period, unchanged from 0001032975-21-000045:mdna:49]

[0001032975-22-000006:mdna:48]
[same as prior period, unchanged from 0001032975-21-000045:mdna:50]

[0001032975-22-000006:mdna:49]
Our sales in the three months ended December 31, 2021, decreased 2% and increased 14% for the nine months ended December 31, 2021, compared to the same periods of the prior fiscal year. The decrease in sales for the three month period was primarily driven by a decline in sales for Tablet and Other Accessories, Audio & Wearables, Mobile Speakers and PC Webcams, partially offset by an increase in sales for Keyboards & Combos, Gaming and Pointing Devices. For the nine months ended December 31, 2021, strong sales growth in Gaming, Keyboards & Combos, and Pointing Devices was partially offset by a decline in sales of Mobile Speakers and Tablet and Other Accessories. Our sales in both the three and nine month periods were negatively impacted by higher promotions and industry-wide supply chain challenges, including supply availability and logistics delays, as compared to the same periods in the prior fiscal year. If currency exchange rates had been constant in the three and nine months ended December 31, 2021 and 2020, our constant dollar sales growth rate would have been a decrease of 2% for the three months ended and an increase of 13% for the nine months ended December 31, 2021.

[0001032975-22-000006:mdna:50]
[same as prior period, unchanged from 0001032975-21-000045:mdna:52]

[0001032975-22-000006:mdna:51]
The following table presents the change in sales by region for the three and nine months ended December 31, 2021, compared with the three and nine months ended December 31, 2020:

[0001032975-22-000006:mdna:52]
|  |  | Sales Growth Rate |  | Constant DollarSales Growth Rate |
|  |  | Three Months EndedDecember 31, 2021 |  | Nine Months EndedDecember 31, 2021 |  | Three Months EndedDecember 31, 2021 |  | Nine Months EndedDecember 31, 2021 |
| Americas |  | (4) | % |  | 14 | % |  | (5) | % |  | 13 | % |
| EMEA |  | 1 | % |  | 14 | % |  | 3 | % |  | 12 | % |
| Asia Pacific |  | (2) | % |  | 15 | % |  | (2) | % |  | 13 | % |

[0001032975-22-000006:mdna:53]
[same as prior period, unchanged from 0001032975-21-000045:mdna:55]

[0001032975-22-000006:mdna:54]
The decrease in sales in the Americas region for the three-month period presented above was primarily driven by a decrease in sales of Tablet and Other Accessories, Audio & Wearables, Mobile Speakers and PC Webcams, partially offset by an increase in sales of Keyboards & Combos and Video Collaboration. The increase in sales for the nine-month period was primarily driven by growth in sales of Video Collaboration, Keyboards & Combos and Gaming, partially offset by a decline in sales of Mobile Speakers.

[0001032975-22-000006:mdna:55]
[same as prior period, unchanged from 0001032975-21-000045:mdna:57]

[0001032975-22-000006:mdna:56]
The increase in sales in our EMEA region for the three-month period was primarily driven by growth in sales of Keyboards & Combos, Tablets and Other Accessories, Gaming and Pointing Devices, partially offset by a decline in sales of the other product categories. The increase in sales for the nine-months ended period was primarily driven by growth in sales of Tablets and Other Accessories, Keyboards & Combos, Gaming, Pointing Devices, and PC Webcams, partially offset by a decline in sales of the other product categories.

[0001032975-22-000006:mdna:57]
[same as prior period, unchanged from 0001032975-21-000045:mdna:59]

[0001032975-22-000006:mdna:58]
The decrease in sales in our Asia Pacific region for the three-month period presented above was primarily driven by a decrease in sales of Tablet and Other Accessories, Mobile Speakers, and Audio & Wearables, partially offset by an increase in sales of the other product categories.  The increase in sales for the nine-month period was primarily driven by growth in sales across a majority of our product categories, partially offset by a decline in sales of Tablet & Other Accessories.

[0001032975-22-000006:mdna:59]
[same as prior period, unchanged from 0001032975-21-000045:mdna:61]

[0001032975-22-000006:mdna:60]
Sales by product categories for the three and nine months ended December 31, 2021 and 2020 were as follows (Dollars in thousands):

[0001032975-22-000006:mdna:61]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Pointing Devices |  | $ | 231,090 |  |  | $ | 213,638 |  |  | 8 | % |  | $ | 602,982 |  |  | $ | 503,228 |  |  | 20 | % |
| Keyboards & Combos |  | 281,608 |  |  | 218,269 |  |  | 29 |  |  | 736,237 |  |  | 565,246 |  |  | 30 |  |
| PC Webcams |  | 115,115 |  |  | 131,700 |  |  | (13) |  |  | 319,504 |  |  | 295,020 |  |  | 8 |  |
| Tablet & Other Accessories |  | 82,859 |  |  | 138,052 |  |  | (40) |  |  | 242,932 |  |  | 267,186 |  |  | (9) |  |
| Gaming (1) |  | 469,282 |  |  | 436,426 |  |  | 8 |  |  | 1,135,456 |  |  | 916,040 |  |  | 24 |  |
| Video Collaboration |  | 287,187 |  |  | 292,500 |  |  | (2) |  |  | 753,725 |  |  | 659,278 |  |  | 14 |  |
| Mobile Speakers |  | 56,748 |  |  | 72,566 |  |  | (22) |  |  | 124,724 |  |  | 145,156 |  |  | (14) |  |
| Audio & Wearables |  | 104,280 |  |  | 152,952 |  |  | (32) |  |  | 318,965 |  |  | 338,592 |  |  | (6) |  |
| Smart Home |  | 4,559 |  |  | 10,593 |  |  | (57) |  |  | 16,380 |  |  | 25,976 |  |  | (37) |  |
| Other (2) |  | 54 |  |  | 606 |  |  | (91) |  |  | 202 |  |  | 632 |  |  | (68) |  |
| Total Sales |  | $ | 1,632,782 |  |  | $ | 1,667,302 |  |  | (2) | % |  | $ | 4,251,107 |  |  | $ | 3,716,354 |  |  | 14 | % |

[0001032975-22-000006:mdna:62]
[same as prior period, unchanged from 0001032975-21-000045:mdna:64]

[0001032975-22-000006:mdna:63]
[same as prior period, unchanged from 0001032975-21-000045:mdna:65]

[0001032975-22-000006:mdna:64]
[same as prior period, unchanged from 0001032975-21-000045:mdna:66]

[0001032975-22-000006:mdna:65]
[same as prior period, unchanged from 0001032975-21-000045:mdna:67]

[0001032975-22-000006:mdna:66]
[same as prior period, unchanged from 0001032975-21-000045:mdna:68]

[0001032975-22-000006:mdna:67]
Sales of Pointing Devices increased 8% and 20% in the three and nine months ended December 31, 2021, respectively, compared to the same periods of the prior fiscal year. The increases in both periods were primarily driven by the increase in sales for cordless and corded mice, and presentation tools. Trackball mice also contributed to the increase in sales for the nine-month period.

[0001032975-22-000006:mdna:68]
[same as prior period, unchanged from 0001032975-21-000045:mdna:70]

[0001032975-22-000006:mdna:69]
[same as prior period, unchanged from 0001032975-21-000045:mdna:71]

[0001032975-22-000006:mdna:70]
Sales of Keyboards & Combos increased 29% and 30% in the three and nine months ended December 31, 2021, respectively, compared to the same periods of the prior fiscal year. The increases for both periods were primarily driven by an increase in sales of our keyboard/mice combos as well as our cordless and corded PC keyboards.

[0001032975-22-000006:mdna:71]
[same as prior period, unchanged from 0001032975-21-000045:mdna:73]

[0001032975-22-000006:mdna:72]
[same as prior period, unchanged from 0001032975-21-000045:mdna:74]

[0001032975-22-000006:mdna:73]
Sales of PC Webcams decreased 13% for the three months ended and increased 8% for the nine months ended December 31, 2021, compared to the same periods of the prior fiscal year. The decrease in sales for the three-month period was primarily driven by a decline in sales of our Streamcam, HD Webcam C505, HD Pro Webcam C920, and 1080 PRO Stream Webcam, partially offset by an increase in sales of our BRIO 4K Stream Edition, and HD Webcam C615.

[0001032975-22-000006:mdna:74]
The increase for the nine-month period was driven by sales of our HD Webcam 505, BRIO 4K Stream Edition, and 1080P PRO Stream Webcam, partially offset by a decrease in sales of our Streamcam and HD Webcam C615.

[0001032975-22-000006:mdna:75]
[same as prior period, unchanged from 0001032975-21-000045:mdna:78]

[0001032975-22-000006:mdna:76]
[same as prior period, unchanged from 0001032975-21-000045:mdna:79]

[0001032975-22-000006:mdna:77]
Sales of Tablet & Other Accessories products decreased 40% and 9% for the three and nine months ended December 31, 2021, compared to the same periods of the prior fiscal year. The decrease for both periods were primarily driven by decrease in sales of our Rugged Folio and Slim Folio Products, partially offset by an increase in sales of our Combo Touch for iPad Pro 12.9-inch, introduced in the second quarter of fiscal year 2022, Combo Touch for iPad Pro 11-inch and Combo Touch for iPad Air, introduced in the first quarter of fiscal year 2022 and POWERED (a wireless 3-in-1 charging dock for Apple products).

[0001032975-22-000006:mdna:78]
[same as prior period, unchanged from 0001032975-21-000045:mdna:81]

[0001032975-22-000006:mdna:79]
[same as prior period, unchanged from 0001032975-21-000045:mdna:82]

[0001032975-22-000006:mdna:80]
[same as prior period, unchanged from 0001032975-21-000045:mdna:83]

[0001032975-22-000006:mdna:81]
Sales of Gaming increased 8% and 24% for the three and nine months ended December 31, 2021, respectively, compared to the same periods of the prior fiscal year. The increase for both periods was primarily driven by strong performance in nearly all of our Gaming sub-categories, including our gaming mice, PC gaming headsets, gaming steering wheels, gaming keyboards, and Streamlabs services, partially offset by a decline in the sales of our console gaming controllers, and console gaming headsets.

[0001032975-22-000006:mdna:82]
[same as prior period, unchanged from 0001032975-21-000045:mdna:85]

[0001032975-22-000006:mdna:83]
[same as prior period, unchanged from 0001032975-21-000045:mdna:86]

[0001032975-22-000006:mdna:84]
[same as prior period, unchanged from 0001032975-21-000045:mdna:87]

[0001032975-22-000006:mdna:85]
Sales of Video Collaboration products decreased 2% for three months ended and increased 14% for the nine months ended December 31, 2021, compared to the same periods of the prior fiscal year. The decrease for the three-month period was primarily due to a decrease in sales of our Webcam C930e, Webcam 925E, BRIO 4k Pro Webcam and Rally Bar conference camera, partially offset by an increase in sales of our MeetUp conference camera. The increase in sales for the nine-month period was primarily driven by an increase in sales of our MeetUp conference camera, Webcam 925E and our Rally Bar conference camera, partially offset by a decline in sales of our Webcam C930e, Brio 4K Pro Webcam and GROUP video conferencing solution for mid to large-sized meeting rooms.

[0001032975-22-000006:mdna:86]
[same as prior period, unchanged from 0001032975-21-000045:mdna:89]

[0001032975-22-000006:mdna:87]
[same as prior period, unchanged from 0001032975-21-000045:mdna:90]

[0001032975-22-000006:mdna:88]
[same as prior period, unchanged from 0001032975-21-000045:mdna:91]

[0001032975-22-000006:mdna:89]
Sales of Mobile Speakers decreased 22% and 14% for the three and nine months ended December 31, 2021, respectively, compared to the same periods of the prior fiscal year. The decrease for both periods was primarily due to a decrease in sales of UE WONDERBOOM, UE Megaboom, BOOM 2 and WONDERBOOM 2 mobile speakers partially offset by an increase in sales of our BOOM 3 mobile speakers.  The decrease in sales for the nine-month period was further offset by an increase in sales of our Blast mobile speakers.

[0001032975-22-000006:mdna:90]
[same as prior period, unchanged from 0001032975-21-000045:mdna:93]

[0001032975-22-000006:mdna:91]
[same as prior period, unchanged from 0001032975-21-000045:mdna:94]

[0001032975-22-000006:mdna:92]
Sales of Audio & Wearables decreased 32% and 6% for the three and nine months ended December 31, 2021, compared to the same periods of the prior fiscal year. The decrease for both periods was primarily due to a decrease in sales of our Blue Microphone products, cordless headsets and Jaybird products, partially offset by an increase in sales of our Ultimate Ears custom headsets. The decrease in sales for the nine-month period was further offset by an increase in sales of our corded headsets.

[0001032975-22-000006:mdna:93]
In the third quarter of fiscal 2022, we made a decision to cease future product launches under the Jaybird brand, but plan to continue developing wireless audio products such as Ultimate Ears.

[0001032975-22-000006:mdna:94]
[same as prior period, unchanged from 0001032975-21-000045:mdna:96]

[0001032975-22-000006:mdna:95]
[same as prior period, unchanged from 0001032975-21-000045:mdna:97]

[0001032975-22-000006:mdna:96]
[same as prior period, unchanged from 0001032975-21-000045:mdna:98]

[0001032975-22-000006:mdna:97]
Sales of Smart Home decreased 57% and 37% for the three and nine months ended December 31, 2021, respectively, compared to the same periods of the prior fiscal year. The decreases for both periods were primarily due to a decline in sales of most of our Harmony remotes and our home video products, partially offset by increases in sales of our Circle View Doorbell, introduced in the third quarter of fiscal year 2021.

[0001032975-22-000006:mdna:98]
[same as prior period, unchanged from 0001032975-21-000045:mdna:100]

[0001032975-22-000006:mdna:99]
Gross profit for the three and nine months ended December 31, 2021 and 2020 was as follows (Dollars in thousands):

[0001032975-22-000006:mdna:100]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Net sales |  | $ | 1,632,782 |  |  | $ | 1,667,302 |  |  | (2) | % |  | $ | 4,251,107 |  |  | $ | 3,716,354 |  |  | 14 | % |
| Gross profit |  | $ | 658,010 |  |  | $ | 749,010 |  |  | (12) | % |  | $ | 1,769,099 |  |  | $ | 1,624,466 |  |  | 9 | % |
| Gross margin |  | 40.3 | % |  | 44.9 | % |  |  |  | 41.6 | % |  | 43.7 | % |  |  |

[0001032975-22-000006:mdna:101]
[same as prior period, unchanged from 0001032975-21-000045:mdna:103]

[0001032975-22-000006:mdna:102]
Gross margin decreased by 460 and 210 basis points for the three and nine months ended December 31, 2021, respectively, compared to the same periods of the prior fiscal year. Our gross margin for both periods declined due to increased promotional spending, increased logistics costs, higher reserves for excess inventories including Jaybird exit costs, partially offset by favorable currency exchange rates and favorable product mix.

[0001032975-22-000006:mdna:103]
[same as prior period, unchanged from 0001032975-21-000045:mdna:105]

[0001032975-22-000006:mdna:104]
Operating expenses for the three and nine months ended December 31, 2021 and 2020 were as follows (Dollars in thousands):

[0001032975-22-000006:mdna:105]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |  |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  |
| Marketing and selling |  | $ | 269,941 |  |  | $ | 204,485 |  |  | $ | 778,882 |  |  | $ | 496,520 |  |  |
| % of sales |  | 16.5 | % |  | 12.3 | % |  | 18.3 | % |  | 13.4 | % |  |
| Research and development |  | 75,529 |  |  | 53,910 |  |  | 213,436 |  |  | 157,014 |  |  |
| % of sales |  | 4.6 | % |  | 3.2 | % |  | 5.0 | % |  | 4.2 | % |  |
| General and administrative |  | 38,478 |  |  | 37,606 |  |  | 112,291 |  |  | 98,341 |  |  |
| % of sales |  | 2.4 | % |  | 2.3 | % |  | 2.6 | % |  | 2.6 | % |  |
| Amortization of intangible assets and acquisition-related costs |  | 3,662 |  |  | 4,946 |  |  | 13,986 |  |  | 13,886 |  |  |
| % of sales |  | 0.2 | % |  | 0.3 | % |  | 0.3 | % |  | 0.4 | % |  |
| Impairment of intangible assets |  | 7,000 |  |  | — |  |  | 7,000 |  |  | — |  |  |
| % of sales |  | 0.4 | % |  | — | % |  | 0.2 | % |  | — | % |  |
| Change in fair value of contingent consideration for business acquisition |  | (1,110) |  |  | — |  |  | (3,509) |  |  | 5,716 |  |  |
| % of sales |  | (0.1) | % |  | — | % |  | (0.1) | % |  | 0.2 | % |  |
| Restructuring charges (credits), net |  | 1,759 |  |  | — |  |  | 1,770 |  |  | (54) |  |  |
| % of sales |  | 0.1 | % |  | — | % |  | — | % |  | — | % |  |
| Total operating expenses |  | $ | 395,259 |  |  | $ | 300,947 |  |  | $ | 1,123,856 |  |  | $ | 771,423 |  |  |
| % of sales |  | 24.2 | % |  | 18.0 | % |  | 26.4 | % |  | 20.8 | % |  |

[0001032975-22-000006:mdna:106]
The increase in total operating expenses during the three and nine months ended December 31, 2021, compared to the same periods of the prior fiscal year, were mainly due to increases in marketing and selling expenses, research and development expenses, and impairment of intangible assets and restructuring charges related to the Jaybird exit. The increase in the nine month period was also attributable to increased general and administrative expenses, partially offset by the change in fair value of contingent consideration for business acquisition.

[0001032975-22-000006:mdna:107]
[same as prior period, unchanged from 0001032975-21-000045:mdna:110]

[0001032975-22-000006:mdna:108]
[same as prior period, unchanged from 0001032975-21-000045:mdna:111]

[0001032975-22-000006:mdna:109]
During the three and nine months ended December 31, 2021, marketing and selling expenses increased $65.5 million and $282.4 million, respectively, compared to the same periods of the prior fiscal year. The increases for both periods were primarily driven by higher advertising and marketing expenses, including third-party costs and increased headcount, to support our investment in brand awareness and consideration.

[0001032975-22-000006:mdna:110]
[same as prior period, unchanged from 0001032975-21-000045:mdna:113]

[0001032975-22-000006:mdna:111]
[same as prior period, unchanged from 0001032975-21-000045:mdna:114]

[0001032975-22-000006:mdna:112]
During the three and nine months ended December 31, 2021, research and development expenses increased $21.6 million and $56.4 million, respectively, compared to the same periods of the prior fiscal year. The increases for both periods were primarily driven by higher personnel-related costs due to increased headcount and higher third-party costs to support innovations in both hardware and software.

[0001032975-22-000006:mdna:113]
[same as prior period, unchanged from 0001032975-21-000045:mdna:116]

[0001032975-22-000006:mdna:114]
[same as prior period, unchanged from 0001032975-21-000045:mdna:117]

[0001032975-22-000006:mdna:115]
During the three and nine months ended December 31, 2021, general and administrative expenses increased $0.9 million and $14.0 million, respectively, compared to the same periods of the prior fiscal year. The increase for both periods were primarily driven by higher personnel-related costs due to investment in additional headcount in Information Technology ("IT") and other functions to support business growth.

[0001032975-22-000006:mdna:116]
[same as prior period, unchanged from 0001032975-21-000045:mdna:119]

[0001032975-22-000006:mdna:117]
[same as prior period, unchanged from 0001032975-21-000045:mdna:120]

[0001032975-22-000006:mdna:118]
During the three months ended December 31. 2021, amortization of intangible assets and acquisition-related costs decreased $1.3 million, and increased $0.1 million for the nine months ended December 31, 2021, compared to the same periods of the prior fiscal year. The decrease for the three-month period was primarily due to the write-off of Jaybird intangible assets, partially offset by intangible assets acquired through acquisitions completed in the fourth quarter of fiscal year 2021. The increase for the nine-month period was primarily due to the intangibles acquired through acquisitions.

[0001032975-22-000006:mdna:119]
Impairment of Intangible Assets

[0001032975-22-000006:mdna:120]
During the three and nine months ended December 31, 2021, we recognized a pre-tax impairment charge of $7.0 million, related to the intangibles acquired as part of the Jaybird acquisition due to our decision to cease future product launches under the Jaybird brand.

[0001032975-22-000006:mdna:121]
Restructuring Charges (Credits), Net

[0001032975-22-000006:mdna:122]
During the three and nine months ended December 31, 2021, we recorded restructuring charges of $1.8 million, related to our decision to exit Jaybird-branded products. The total charges consisted of $1.3 million, primarily related to costs of production cancellation and $0.5 million related to cash severance and termination benefits. We expect to complete the restructuring within the next twelve months.

[0001032975-22-000006:mdna:123]
[same as prior period, unchanged from 0001032975-21-000045:mdna:122]

[0001032975-22-000006:mdna:124]
Other income, net for the three and nine months ended December 31, 2021 and 2020 was as follows (Dollars in thousands):

[0001032975-22-000006:mdna:125]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Investment income (loss) related to a deferred compensation plan |  | $ | 890 |  |  | $ | 1,049 |  |  | $ | 1,985 |  |  | $ | 4,384 |  |
| Currency exchange gain (loss), net |  | (4,562) |  |  | 7,344 |  |  | (3,824) |  |  | 9,070 |  |
| Gain (loss) on investments |  | (460) |  |  | (2,173) |  |  | (1,421) |  |  | (4,692) |  |
| Other |  | 459 |  |  | 263 |  |  | 1,319 |  |  | 899 |  |
| Total |  | $ | (3,673) |  |  | $ | 6,483 |  |  | $ | (1,941) |  |  | $ | 9,661 |  |

[0001032975-22-000006:mdna:126]
[same as prior period, unchanged from 0001032975-21-000045:mdna:125]

[0001032975-22-000006:mdna:127]
Currency exchange gain (loss), net, relates to balances denominated in currencies other than the functional currency in our subsidiaries, as well as to the sale of currencies, and to gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to

[0001032975-22-000006:mdna:128]
maximize currency exchange gains and minimize currency exchange losses. The loss for the three months ended December 31, 2021 was primarily due to the weakening of the Brazilian Real against the U.S. Dollar. The loss for the nine months ended December 31, 2021 was primarily related to the strengthening of the Chinese Renminbi against the U.S. Dollar.

[0001032975-22-000006:mdna:129]
[same as prior period, unchanged from 0001032975-21-000045:mdna:127]

[0001032975-22-000006:mdna:130]
[same as prior period, unchanged from 0001032975-21-000045:mdna:128]

[0001032975-22-000006:mdna:131]
The provision for income taxes and effective income tax rates for the three and nine months ended December 31, 2021 and 2020 were as follows (Dollars in thousands):

[0001032975-22-000006:mdna:132]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Provision for income taxes |  | $ | 49,345 |  |  | $ | 72,334 |  |  | $ | 107,789 |  |  | $ | 142,638 |  |
| Effective income tax rate |  | 19.0 | % |  | 15.9 | % |  | 16.7 | % |  | 16.5 | % |

[0001032975-22-000006:mdna:133]
The change in the effective income tax rate for the three and nine months ended December 31, 2021, compared to the same periods ended December 31, 2020 was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate.  There were discrete tax benefits of $0.8 million and $1.3 million from the recognition of excess tax benefits in the United States and reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the three-month period ended December 31, 2021, compared with $1.3 million and $1.4 million, respectively, in the three-month period ended December 31, 2020. There were discrete tax benefits of $15.2 million and $2.8 million from the recognition of excess tax benefits in the United States and reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the nine-month period ended December 31, 2021, compared with $7.2 million and $2.9 million, respectively, in the nine-month period ended December 31, 2020.

[0001032975-22-000006:mdna:134]
As of December 31, 2021 and March 31, 2021, the total amount of unrecognized tax benefits due to uncertain tax positions was $178.6 million and $160.3 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-22-000006:mdna:135]
[same as prior period, unchanged from 0001032975-21-000045:mdna:133]

[0001032975-22-000006:mdna:136]
[same as prior period, unchanged from 0001032975-21-000045:mdna:134]

[0001032975-22-000006:mdna:137]
As of December 31, 2021, we had cash and cash equivalents of $1,364.4 million, compared to $1,750.3 million as of March 31, 2021. As of December 31, 2021, 73% of the cash and cash equivalents were held in Switzerland, and 15% were held in Hong Kong and China. We do not expect to incur any material adverse tax impact except for what has already been recognized, or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-22-000006:mdna:138]
The decrease in cash and cash equivalents for the nine months ended December 31, 2021 compared to the same period in the prior year, primarily resulted from a decrease in net cash provided by operating activities, despite positive net income, and an increase in net cash used in financing activities. The decrease in net cash provided by operating activities was mainly due to a decline in accounts payable due to the timing of purchases and related payments and the timing of an annual income tax payment for fiscal year 2021, partially offset by timing of sales within the quarter. The increase in net cash used in financing activities was driven by higher shares repurchased under our share repurchase program compared to the same period of the prior fiscal year.

[0001032975-22-000006:mdna:139]
As of December 31, 2021, our working capital was $1,637.1 million, compared to $1,477.5 million as of March 31, 2021. The increase was primarily driven by higher accounts receivable, net, higher inventories and lower accounts payable, partially offset by lower cash and cash equivalents. Our working capital increased by $275.2 million compared to $1,361.9 million as of December 31, 2020, which was primarily driven by higher inventories and higher other current assets, partially offset by higher accrued and other current liabilities and lower accounts receivable, net.

[0001032975-22-000006:mdna:140]
We had several uncommitted, unsecured bank lines of credit aggregating $194.4 million as of December 31, 2021. There are no financial covenants under these lines of credit with which we must comply. As of December 31, 2021, we had outstanding bank guarantees of $11.8 million under these lines of credit.

[0001032975-22-000006:mdna:141]
[same as prior period, unchanged from 0001032975-21-000045:mdna:139]

[0001032975-22-000006:mdna:142]
|  |  | Nine Months EndedDecember 31, |
|  |  | 2021 |  | 2020 |
| Net cash provided by operating activities |  | $ | 198,728 |  |  | $ | 928,419 |  |
| Net cash used in investing activities |  | (89,006) |  |  | (46,454) |  |
| Net cash used in financing activities |  | (492,799) |  |  | (219,196) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (2,839) |  |  | 10,408 |  |
| Net increase / (decrease) in cash and cash equivalents |  | $ | (385,916) |  |  | $ | 673,177 |  |

[0001032975-22-000006:mdna:143]
The following tables present selected financial information and statistics as of and for the three months ended December 31, 2021 and 2020 (Dollars in thousands):

[0001032975-22-000006:mdna:144]
|  |  | As of December 31, |  |
|  |  | 2021 |  | 2020 |  |
| Accounts receivable, net |  | $ | 845,836 |  |  | $ | 894,937 |  |  |
| Accounts payable |  | $ | 738,992 |  |  | $ | 811,786 |  |  |
| Inventories |  | $ | 834,534 |  |  | $ | 476,802 |  |  |

[0001032975-22-000006:mdna:145]
|  |  | Three Months EndedDecember 31, |  |
|  |  | 2021 |  | 2020 |  |
| Days sales in accounts receivable (“DSO”) (Days) (1) |  | 47 |  |  | 48 |  |  |
| Days accounts payable outstanding (“DPO”) (Days) (2) |  | 68 |  |  | 80 |  |  |
| Inventory turnover (“ITO”) (x)(3) |  | 4.7 |  |  | 7.7 |  |  |

[0001032975-22-000006:mdna:146]
[same as prior period, unchanged from 0001032975-21-000045:mdna:144]

[0001032975-22-000006:mdna:147]
[same as prior period, unchanged from 0001032975-21-000045:mdna:145]

[0001032975-22-000006:mdna:148]
[same as prior period, unchanged from 0001032975-21-000045:mdna:146]

[0001032975-22-000006:mdna:149]
DSO for the three months ended December 31, 2021 decreased by 1 days to 47 days, compared to 48 days for the same period of the prior fiscal year, primarily due to timing of sales within the quarter and a continued focus on collections efficiency.

[0001032975-22-000006:mdna:150]
DPO for the three months ended December 31, 2021 decreased by 12 days, compared to 80 days for the same period of the prior fiscal year, primarily due to the timing of purchases and related payments.

[0001032975-22-000006:mdna:151]
ITO for the three months ended December 31, 2021 decreased by 3, compared to 7.7 for the same period of the prior fiscal year, primarily due to lower demand than prior year and industry wide logistic delays.

[0001032975-22-000006:mdna:152]
[same as prior period, unchanged from 0001032975-21-000045:mdna:150]

[0001032975-22-000006:mdna:153]
During the nine months ended December 31, 2021, net cash provided by operating activities was $198.7 million. The increase in accounts receivable, net was primarily driven by timing of sales. The increase in inventories was primarily driven by higher inventory levels compared to the previously constrained supply from COVID-19

[0001032975-22-000006:mdna:154]
impacts and industry wide logistic delays. The decrease in accounts payable was primarily driven by the timing of purchases and related payments. The decrease in accrued liabilities was primarily driven by payment of the fiscal year 2021 annual bonus and an annual payment for fiscal year 2021 income taxes.

[0001032975-22-000006:mdna:155]
Net cash used in investing activities was $89.0 million, primarily due to $63.7 million of purchases of property, plant and equipment, $15.9 million of the purchase price (net of cash acquired) for a business acquisition, and $10.0 million of purchase of short-term investments.

[0001032975-22-000006:mdna:156]
Net cash used in financing activities was $492.8 million, primarily due to $290.6 million used for repurchases of our registered shares, $159.4 million payment of the annual cash dividend, and $58.5 million for tax withholdings related to net share settlements of restricted stock units, partially offset by $16.6 million in proceeds received from exercises of stock options and purchase rights.

[0001032975-22-000006:mdna:157]
During the nine months ended December 31, 2021, there was a $2.8 million loss from currency exchange rate effect on cash and cash equivalents, compared to a gain of $10.4 million during the same period of the prior fiscal year. The loss from the effect of currency rate changes during the nine months ended December 31, 2021 was primarily due to the strengthening of the Chinese Renminbi against the U.S. Dollar by 3%. The gain from the effect of currency rate changes during the nine months ended December 31, 2020 was primarily due to the strengthening of the Australian Dollar, Chinese Renminbi, and Swiss Franc against the U.S. Dollar by 24%, 11%, and 8%, respectively, during the period.

[0001032975-22-000006:mdna:158]
[same as prior period, unchanged from 0001032975-21-000045:mdna:156]

[0001032975-22-000006:mdna:159]
[same as prior period, unchanged from 0001032975-21-000045:mdna:157]

[0001032975-22-000006:mdna:160]
[same as prior period, unchanged from 0001032975-21-000045:mdna:158]

[0001032975-22-000006:mdna:161]
In May 2020, our Board of Directors approved a new share repurchase program, which authorized us to invest up to $250.0 million to purchase our own shares, following the expiration date of the 2017 share repurchase program.  In April 2021, our Board of Directors approved an increase of $750.0 million of the 2020 share repurchase program, to an aggregate amount of $1.0 billion. The Swiss Takeover Board approved this increase and it became effective on May 21, 2021. As of December 31, 2021, $545.0 million is still available for repurchase under the 2020 repurchase program.

[0001032975-22-000006:mdna:162]
Although we enter into trading plans for systematic repurchases (e.g., 10b5-1 trading plans) from time to time, our share repurchase program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.

[0001032975-22-000006:mdna:163]
[same as prior period, unchanged from 0001032975-21-000045:mdna:160]

[0001032975-22-000006:mdna:164]
[same as prior period, unchanged from 0001032975-21-000045:mdna:161]

[0001032975-22-000006:mdna:165]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. During the nine months ended December 31, 2021, our operating lease obligations increased $6.6 million, which primarily was related to renewals of existing office spaces.  There have been no other material changes to our contractual obligations as previously disclosed in our Annual Report on Form 10-K for the year ended March 31, 2021. The remaining terms of our non-cancelable operating leases expire in various years through 2031.

[0001032975-22-000006:mdna:166]
[same as prior period, unchanged from 0001032975-21-000045:mdna:163]

[0001032975-22-000006:mdna:167]
As of December 31, 2021, we had non-cancelable purchase commitments of $822.1 million for inventory purchases made in the normal course of business from original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. We recorded a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with our valuation of excess and obsolete inventory. As of December 31, 2021, the liability for these purchase commitments was $40.5 million and is recorded in accrued and other current liabilities.

[0001032975-22-000006:mdna:168]
We have firm purchase commitments of $27.0 million for capital expenditures primarily related to commitments for tooling and equipment for new and existing products. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-22-000006:mdna:169]
[same as prior period, unchanged from 0001032975-21-000045:mdna:166]

[0001032975-22-000006:mdna:170]
[same as prior period, unchanged from 0001032975-21-000045:mdna:167]

[0001032975-22-000006:mdna:171]
[same as prior period, unchanged from 0001032975-21-000045:mdna:168]

[0001032975-22-000006:mdna:172]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2021, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-22-000006:mdna:173]
[same as prior period, unchanged from 0001032975-21-000045:mdna:170]

[0001032975-22-000006:mdna:174]
Legal Proceedings

[0001032975-22-000006:mdna:175]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of our business.  For more information about Legal Proceedings, see Part II Item 1 Legal Proceedings of this quarterly report on Form 10-Q for the period ended December 31, 2021.
