# LOGI notes — 0001032975-22-000006


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-22-000006:notes:1]
[same as prior period, unchanged from 0001032975-21-000045:notes:1]

[0001032975-22-000006:notes:2]
[same as prior period, unchanged from 0001032975-21-000045:notes:2]

[0001032975-22-000006:notes:3]
[same as prior period, unchanged from 0001032975-21-000045:notes:3]

[0001032975-22-000006:notes:4]
[same as prior period, unchanged from 0001032975-21-000045:notes:4]

[0001032975-22-000006:notes:5]
[same as prior period, unchanged from 0001032975-21-000045:notes:5]

[0001032975-22-000006:notes:6]
[same as prior period, unchanged from 0001032975-21-000045:notes:6]

[0001032975-22-000006:notes:7]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and nine months ended December 31, 2021 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2022, or any future periods.

[0001032975-22-000006:notes:8]
[same as prior period, unchanged from 0001032975-21-000045:notes:8]

[0001032975-22-000006:notes:9]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted, there have been no material changes in the Company’s significant accounting policies during the nine months ended December 31, 2021 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2021.

[0001032975-22-000006:notes:10]
[same as prior period, unchanged from 0001032975-21-000045:notes:10]

[0001032975-22-000006:notes:11]
[same as prior period, unchanged from 0001032975-21-000045:notes:11]

[0001032975-22-000006:notes:12]
[same as prior period, unchanged from 0001032975-21-000045:notes:12]

[0001032975-22-000006:notes:13]
We are subject to risks and uncertainties as a result of the novel coronavirus ("COVID-19"). Capital markets and economies worldwide have been negatively impacted by COVID-19 and it is still unclear how lasting and deep the economic impacts will be. During the three and nine months ended December 31, 2021, the COVID-19 pandemic had mixed effects on the Company’s results of operations. While the Company experienced increased sales for the nine months ended December 31, 2021, compared to the same period of the prior fiscal year, we also experienced supply and demand volatility, as the COVID-19 pandemic and related safety measures and restrictions have evolved differently across the world. In addition, we experienced industry-wide supply chain challenges. The ongoing and full extent of the impact of the COVID-19 pandemic on the Company's business and operational and financial performance and condition, including the sustainability of its effect on trends positive to the Company, is uncertain and will depend on many factors outside the Company's control, including but not limited to the timing, extent, duration and effects of the virus and any of its mutations and variants, the vaccination rates, the development of effective treatments, the imposition of effective public safety and other protective measures and the public's response to such measures, the impact of COVID-19 on the global economy and demand for the Company's products and services. Should the COVID-19 pandemic or global economic slowdown not improve or worsen, or if the Company's attempt to mitigate its impact on its operations and costs is not successful, the Company's business, results of operations, financial condition and prospects may be adversely affected.

[0001032975-22-000006:notes:14]
[same as prior period, unchanged from 0001032975-21-000045:notes:14]

[0001032975-22-000006:notes:15]
In December 2019, the FASB issued ASU 2019-12, "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes" (ASU 2019-12), which eliminates certain exceptions for recognizing deferred taxes for investments, performing intraperiod allocation and calculating income taxes in interim periods. This ASU also includes guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. ASU 2019-12 is effective for annual and interim periods in fiscal years beginning after December 15, 2020. Early adoption is permitted. The Company adopted this standard effective April 1, 2021. The adoption of ASU 2019-12 did not have a material impact on the Company's condensed consolidated financial statements.

[0001032975-22-000006:notes:16]
Recent Accounting Pronouncements to Be Adopted

[0001032975-22-000006:notes:17]
In October 2021, the FASB issued ASU 2021-08, "Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers" (ASU 2021-08). The standard requires an acquirer in a business combination to recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with ASC 606, Revenue from Contracts with Customers, as if it had originated the contracts. The standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2022. Early adoption is permitted. The Company does not expect the adoption of ASU 2021-08 to have a significant impact on its consolidated financial statements and plans to adopt the standard effective April 1, 2023.


## us-gaap:EarningsPerShareTextBlock

[0001032975-22-000006:notes:18]
[same as prior period, unchanged from 0001032975-21-000045:notes:16]

[0001032975-22-000006:notes:19]
The following table summarizes the computations of basic and diluted net income per share for the three and nine months ended December 31, 2021 and December 31, 2020 (in thousands, except per share amounts):

[0001032975-22-000006:notes:20]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net income |  | $ | 210,011 |  |  | $ | 382,523 |  |  | $ | 536,308 |  |  | $ | 721,510 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 167,090 |  |  | 169,050 |  |  | 167,953 |  |  | 168,448 |  |
| Effect of potentially dilutive equivalent shares |  | 2,617 |  |  | 3,537 |  |  | 3,074 |  |  | 2,930 |  |
| Weighted average shares outstanding - diluted |  | 169,707 |  |  | 172,587 |  |  | 171,027 |  |  | 171,378 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.26 |  |  | $ | 2.26 |  |  | $ | 3.19 |  |  | $ | 4.28 |  |
| Diluted |  | $ | 1.24 |  |  | $ | 2.22 |  |  | $ | 3.14 |  |  | $ | 4.21 |  |

[0001032975-22-000006:notes:21]
Share equivalents attributable to outstanding stock options, restricted stock units ("RSUs") and employee share purchase plans ("ESPP") totaling 0.8 million and 0.3 million for the three months ended December 31, 2021 and 2020, respectively, and 0.9 million and 0.4 million for the nine months ended December 31, 2021 and 2020, respectively, were excluded from the calculation of diluted net income per share because the combined exercise price and average unamortized grant date fair value upon exercise of these options and ESPP rights or vesting of RSUs were greater than the average market price of the Company's shares during the periods presented herein, and therefore their inclusion would have been anti-dilutive. A small number of performance-based awards were not included in the calculation because all necessary conditions had not been satisfied by the end of the respective period, and those shares were not issuable if the end of the reporting period were the end of the performance contingency period.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-22-000006:notes:22]
[same as prior period, unchanged from 0001032975-21-000045:notes:20]

[0001032975-22-000006:notes:23]
[same as prior period, unchanged from 0001032975-21-000045:notes:21]

[0001032975-22-000006:notes:24]
As of December 31, 2021, the Company offers the 2006 Employee Share Purchase Plan (Non-U.S.), as amended and restated, the 1996 Employee Share Purchase Plan (U.S.), as amended and restated, the 2006 Stock Incentive Plan, as amended and restated, and the 2012 Stock Inducement Equity Plan. Shares issued to employees as a result of purchases or exercises under these plans are generally issued from shares held in treasury stock.

[0001032975-22-000006:notes:25]
The following table summarizes the share-based compensation expense and total income tax benefit recognized for share-based awards for the three and nine months ended December 31, 2021 and 2020 (in thousands):

[0001032975-22-000006:notes:26]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Cost of goods sold |  | $ | 1,782 |  |  | $ | 1,747 |  |  | $ | 5,253 |  |  | $ | 4,919 |  |
| Marketing and selling |  | 10,699 |  |  | 8,390 |  |  | 28,987 |  |  | 27,559 |  |
| Research and development |  | 4,510 |  |  | 3,482 |  |  | 14,295 |  |  | 10,348 |  |
| General and administrative |  | 7,801 |  |  | 6,195 |  |  | 23,930 |  |  | 21,888 |  |
| Total share-based compensation expense |  | 24,792 |  |  | 19,814 |  |  | 72,465 |  |  | 64,714 |  |
| Income tax benefit |  | (3,581) |  |  | (3,471) |  |  | (23,460) |  |  | (15,540) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 21,211 |  |  | $ | 16,343 |  |  | $ | 49,005 |  |  | $ | 49,174 |  |

[0001032975-22-000006:notes:27]
[same as prior period, unchanged from 0001032975-21-000045:notes:25]

[0001032975-22-000006:notes:28]
As of December 31, 2021 and 2020, the balance of capitalized share-based compensation included in inventory was $1.1 million and $1.0 million, respectively.

[0001032975-22-000006:notes:29]
[same as prior period, unchanged from 0001032975-21-000045:notes:27]

[0001032975-22-000006:notes:30]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The costs recorded of $3.4 million and $2.9 million for the three months ended December 31, 2021 and 2020, respectively, and $10.0 million and $8.3 million for the nine months ended December 31, 2021 and 2020, respectively, were primarily related to service costs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-22-000006:notes:31]
[same as prior period, unchanged from 0001032975-21-000045:notes:29]

[0001032975-22-000006:notes:32]
[same as prior period, unchanged from 0001032975-21-000045:notes:30]

[0001032975-22-000006:notes:33]
The income tax provision for the three months ended December 31, 2021 was $49.3 million based on an effective income tax rate of 19.0% of pre-tax income, compared to an income tax provision of $72.3 million based on an effective income tax rate of 15.9% of pre-tax income for the three months ended December 31, 2020.  The income tax provision for the nine months ended December 31, 2021 was $107.8 million based on an effective income tax rate of 16.7% of pre-tax income, compared to an income tax provision of $142.6 million based on an effective income tax rate of 16.5% of pre-tax income for the nine months ended December 31, 2020.

[0001032975-22-000006:notes:34]
The change in the effective income tax rate for the three and nine months ended December 31, 2021, compared to the same periods ended December 31, 2020 was primarily due to the mix of income and losses in the

[0001032975-22-000006:notes:35]
various tax jurisdictions in which the Company operates. There were discrete tax benefits of $0.8 million and $1.3 million from the recognition of excess tax benefits in the United States and reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the three-month period ended December 31, 2021, compared with $1.3 million and $1.4 million, respectively, in the three-month period ended December 31, 2020.  There were discrete tax benefits of $15.2 million and $2.8 million from the recognition of excess tax benefits in the United States and the reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the nine-month period ended December 31, 2021, compared with $7.2 million and $2.9 million, respectively, in the nine-month period ended December 31, 2020.

[0001032975-22-000006:notes:36]
As of December 31, 2021 and March 31, 2021, the total amount of unrecognized tax benefits due to uncertain tax positions was $178.6 million and $160.3 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-22-000006:notes:37]
As of December 31, 2021 and March 31, 2021, the Company had $85.6 million and $59.2 million, respectively, in non-current income taxes payable including interest and penalties, related to the Company's income tax liability for uncertain tax positions.

[0001032975-22-000006:notes:38]
The Company recognizes interest and penalties related to unrecognized tax positions in the income tax provision. As of December 31, 2021 and March 31, 2021, the Company had $5.7 million and $4.9 million, respectively, of accrued interest and penalties related to uncertain tax positions in non-current income taxes payable.

[0001032975-22-000006:notes:39]
Although the Company has adequately provided for uncertain tax positions, the provisions related to these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During fiscal year 2022, the Company continues to review its tax positions and provide for or reverse unrecognized tax benefits as they arise. During the next twelve months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. dollar as compared to other currencies. Excluding these factors, uncertain tax positions may decrease by as much as $5.2 million from the lapse of the statutes of limitations in various jurisdictions during the next twelve months.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-22-000006:notes:40]
[same as prior period, unchanged from 0001032975-21-000045:notes:37]

[0001032975-22-000006:notes:41]
The following table presents the components of certain balance sheet asset amounts as of December 31 and March 31, 2021 (in thousands):

[0001032975-22-000006:notes:42]
|  |  | December 31, 2021 |  | March 31, 2021 |
| Accounts receivable, net: |  |  |  |  |
| Accounts receivable |  | $ | 1,189,206 |  |  | $ | 867,868 |  |
| Allowance for doubtful accounts |  | (75) |  |  | (1,161) |  |
| Allowance for sales returns |  | (15,128) |  |  | (14,438) |  |
| Allowance for cooperative marketing arrangements |  | (66,772) |  |  | (43,276) |  |
| Allowance for customer incentive programs |  | (125,052) |  |  | (76,200) |  |
| Allowance for pricing programs |  | (136,343) |  |  | (120,568) |  |
|  |  | $ | 845,836 |  |  | $ | 612,225 |  |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 209,647 |  |  | $ | 146,886 |  |
| Finished goods |  | 624,887 |  |  | 514,230 |  |
|  |  | $ | 834,534 |  |  | $ | 661,116 |  |
| Other current assets: |  |  |  |  |
| Value-added tax receivables |  | $ | 56,944 |  |  | $ | 67,710 |  |
| Prepaid expenses and other assets |  | 88,057 |  |  | 67,940 |  |
|  |  | $ | 145,001 |  |  | $ | 135,650 |  |
| Property, plant and equipment, net: |  |  |  |  |
| Property, plant and equipment at cost |  | $ | 451,783 |  |  | $ | 417,520 |  |
| Accumulated depreciation and amortization |  | (342,182) |  |  | (303,460) |  |
|  |  | $ | 109,601 |  |  | $ | 114,060 |  |
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 196,776 |  |  | $ | 210,888 |  |
| Right-of-use assets |  | 38,997 |  |  | 31,169 |  |
| Trading investments for deferred compensation plan |  | 29,711 |  |  | 24,809 |  |
| Investments in privately held companies |  | 43,482 |  |  | 43,402 |  |
| Other assets |  | 14,639 |  |  | 13,980 |  |
|  |  | $ | 323,605 |  |  | $ | 324,248 |  |

[0001032975-22-000006:notes:43]
The following table presents the components of certain balance sheet liability amounts as of December 31 and March 31, 2021 (in thousands):

[0001032975-22-000006:notes:44]
|  |  | December 31, 2021 |  | March 31, 2021 |
| Accrued and other current liabilities: |  |  |  |  |
| Accrued customer marketing, pricing and incentive programs |  | $ | 244,821 |  |  | $ | 185,394 |  |
| Accrued personnel expenses |  | 167,249 |  |  | 173,360 |  |
| VAT payable |  | 41,103 |  |  | 50,620 |  |
| Accrued sales return liability |  | 37,765 |  |  | 43,178 |  |
| Accrued payables - non-inventory |  | 29,632 |  |  | 52,392 |  |
| Warranty accrual |  | 34,121 |  |  | 33,228 |  |
| Income taxes payable |  | 25,889 |  |  | 131,408 |  |
| Operating lease liability |  | 13,583 |  |  | 13,101 |  |
| Contingent consideration |  | 8,580 |  |  | 6,967 |  |
| Other current liabilities |  | 210,941 |  |  | 168,969 |  |
|  |  | $ | 813,684 |  |  | $ | 858,617 |  |
| Other non-current liabilities: |  |  |  |  |
| Employee benefit plan obligations |  | $ | 74,643 |  |  | $ | 72,321 |  |
| Obligation for deferred compensation plan |  | 29,711 |  |  | 24,809 |  |
| Operating lease liability |  | 27,464 |  |  | 21,319 |  |
| Warranty accrual |  | 13,814 |  |  | 15,604 |  |
| Contingent consideration |  | 3,971 |  |  | — |  |
| Deferred tax liability |  | 1,679 |  |  | 1,679 |  |
| Other non-current liabilities |  | 4,087 |  |  | 3,770 |  |
|  |  | $ | 155,369 |  |  | $ | 139,502 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-22-000006:notes:45]
[same as prior period, unchanged from 0001032975-21-000045:notes:42]

[0001032975-22-000006:notes:46]
[same as prior period, unchanged from 0001032975-21-000045:notes:43]

[0001032975-22-000006:notes:47]
[same as prior period, unchanged from 0001032975-21-000045:notes:44]

[0001032975-22-000006:notes:48]
[same as prior period, unchanged from 0001032975-21-000045:notes:45]

[0001032975-22-000006:notes:49]
[same as prior period, unchanged from 0001032975-21-000045:notes:46]

[0001032975-22-000006:notes:50]
[same as prior period, unchanged from 0001032975-21-000045:notes:47]

[0001032975-22-000006:notes:51]
|  |  | December 31, 2021 |  | March 31, 2021 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 475,187 |  |  | $ | — |  |  | $ | — |  |  | $ | 669,759 |  |  | $ | — |  |  | $ | — |  |
| Trading investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 349 |  |  | $ | — |  |  | $ | — |  |  | $ | 31 |  |  | $ | — |  |  | $ | — |  |
| Common stock |  | 2,240 |  |  | — |  |  | — |  |  | 1,569 |  |  | — |  |  | — |  |
| Money market funds |  | 7,117 |  |  | — |  |  | — |  |  | 6,734 |  |  | — |  |  | — |  |
| Mutual funds |  | 20,005 |  |  | — |  |  | — |  |  | 16,475 |  |  | — |  |  | — |  |
| Total of trading investments for deferred compensation plan |  | $ | 29,711 |  |  | $ | — |  |  | $ | — |  |  | $ | 24,809 |  |  | $ | — |  |  | $ | — |  |
| Currency exchange derivative assetsincluded in other current assets |  | $ | — |  |  | $ | 198 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,452 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration for business acquisition included in accrued and other current liabilities |  | $ | — |  |  | $ | — |  |  | $ | 8,042 |  |  | $ | — |  |  | $ | — |  |  | $ | 6,430 |  |
| Contingent consideration for business acquisition included in other non-current liabilities |  | $ | — |  |  | $ | — |  |  | $ | 3,971 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Currency exchange derivative liabilitiesincluded in accrued and other current liabilities |  | $ | — |  |  | $ | 808 |  |  | $ | — |  |  | $ | — |  |  | $ | 100 |  |  | $ | — |  |

[0001032975-22-000006:notes:52]
The following table summarizes the change in the fair value of the Company's contingent consideration balance during the nine months ended December 31, 2021 and 2020 (in thousands):

[0001032975-22-000006:notes:53]
|  | Nine Months EndedDecember 31, |
|  | 2021 |  | 2020 |
| Beginning of the period | $ | 6,967 |  |  | $ | 23,284 |  |
| Fair value of contingent consideration upon acquisition (1) | 9,973 |  |  | — |  |
| Change in fair value of contingent consideration | (3,509) |  |  | 5,716 |  |
| Settlement of contingent consideration | (880) |  |  | (28,463) |  |
| End of the period (2) | $ | 12,551 |  |  | $ | 537 |  |

[0001032975-22-000006:notes:54]
(1) Fair value of contingent consideration includes the earn-out of the immaterial technology acquisition. See Contingent Consideration for Business Acquisitions section below for more information.

[0001032975-22-000006:notes:55]
[same as prior period, unchanged from 0001032975-21-000045:notes:52]

[0001032975-22-000006:notes:56]
[same as prior period, unchanged from 0001032975-21-000045:notes:53]

[0001032975-22-000006:notes:57]
The marketable securities for the Company's deferred compensation plan were recorded at a fair value of $29.7 million and $24.8 million, as of December 31, 2021 and March 31, 2021, respectively, based on quoted

[0001032975-22-000006:notes:58]
market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized gains (losses) related to trading securities for the three and nine months ended December 31, 2021 and 2020 were not material and are included in other income, net in the Company's condensed consolidated statements of operations.

[0001032975-22-000006:notes:59]
[same as prior period, unchanged from 0001032975-21-000045:notes:56]

[0001032975-22-000006:notes:60]
On May 19, 2021, the Company made an immaterial technology acquisition. The contingent consideration for business acquisition arising from the immaterial technology acquisition represents the future potential earn-out payments of up to $10.0 million payable in cash only upon the achievement of three technical development milestones required to be completed as of December 31, 2021, June 30, 2022, and June 30, 2023. The fair value of the contingent amount was determined using a probability-weighted expected payment model and discounted at the estimated cost of debt. During the third quarter of fiscal 2022, $0.9 million of the contingent consideration was released from other current liabilities upon cash settlement of the contingent consideration for the first technical development milestone.

[0001032975-22-000006:notes:61]
[same as prior period, unchanged from 0001032975-21-000045:notes:58]

[0001032975-22-000006:notes:62]
The fair value of the earn-out as of the Mevo Acquisition Date was $3.4 million which was determined by using a Black-Scholes-Merton valuation model to calculate the probability of the earn-out threshold being met, times the value of the earn-out payment, and discounted at the risk-free rate. The valuation included significant assumptions and unobservable inputs such as the projected sales of Mevo over the earn-out period, risk-free rate, and the net sales volatility. Projected sales were based on the Company's internal projections, including analysis of the target market and historical sales of Mevo products. As of December 31, 2021, the fair value of the contingent consideration was released from other current liabilities as the net sales milestone was not achieved upon completion of the earn-out period.  As of March 31, 2021 the fair value of the contingent consideration was $3.4 million.

[0001032975-22-000006:notes:63]
On January 4, 2021, the Company made an immaterial technology acquisition. The contingent consideration for business acquisition arising from the immaterial technology acquisition represents the future potential earn-out payments of up to $3.0 million payable in cash upon the achievement of two technical development milestones required to be completed as of December 31, 2021 and March 31, 2022. The fair value of the contingent amount was determined using a probability-weighted expected payment model and discounted at the estimated cost of debt. The contingent consideration related to the first milestone is expected to be paid in the fourth quarter of fiscal year 2022.

[0001032975-22-000006:notes:64]
On October 31, 2019, the Company acquired all of the equity interests of General Workings, Inc. (Streamlabs). In connection with the acquisition of Streamlabs, the Company agreed to pay a total earn-out payment of up to $29.0 million, payable in stock, only upon the achievement of certain net revenues for the period beginning on January 1, 2020 and ending on June 30, 2020.  The fair value was increased by $5.7 million to $29.0 million as of June 30, 2020, based on actual sales. As of June 30, 2020, the earn-out period was completed, and was no longer subject to fair value measurement. During the third quarter of fiscal 2021, $28.5 million of the contingent consideration was transferred from other current liabilities to equity upon settlement of the contingent consideration through the issuance of shares out of treasury stock. The remaining amount of $0.5 million is held back in escrow for claims made against the escrow and for the payment of taxes.

[0001032975-22-000006:notes:65]
[same as prior period, unchanged from 0001032975-21-000045:notes:62]

[0001032975-22-000006:notes:66]
[same as prior period, unchanged from 0001032975-21-000045:notes:63]

[0001032975-22-000006:notes:67]
The Company has certain non-marketable investments included in other assets that are accounted for under the equity method of accounting, with a carrying value of $40.8 million and $40.7 million as of December 31, 2021 and March 31, 2021, respectively. Unrealized gains (losses) related to equity investments for the three and nine months ended December 31, 2021 and 2020 were not material and are included in other income, net in the

[0001032975-22-000006:notes:68]
Company's condensed consolidated statements of operations. There was no impairment of these assets during the three and nine months ended December 31, 2021 or 2020.

[0001032975-22-000006:notes:69]
[same as prior period, unchanged from 0001032975-21-000045:notes:65]

[0001032975-22-000006:notes:70]
Financial Assets.  The Company has certain investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with a same or similar security from the same issuer. The amount of these investments included in other assets was immaterial as of December 31, 2021 and March 31, 2021. There was no impairment of these assets during the three and nine months ended December 31, 2021 or 2020.

[0001032975-22-000006:notes:71]
Non-Financial Assets.  Goodwill, intangible assets, and property, plant and equipment, are not required to be measured at fair value on a recurring basis. However, if certain triggering events occur (or tested at least annually for goodwill) such that a non-financial instrument is required to be evaluated for impairment and an impairment is recorded to reduce the non-financial instrument's carrying value to the fair value as a result of such triggering events, the non-financial assets and liabilities are measured at fair value for the period such triggering events occur. As further discussed in Note 8, during the three and nine months ended December 31, 2021, the Company recorded impairment charges of $7.0 million for the Jaybird intangible assets. There was no impairment of non-financial assets during the three and nine months ended December 31, 2020.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-22-000006:notes:72]
[same as prior period, unchanged from 0001032975-21-000045:notes:68]

[0001032975-22-000006:notes:73]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis on the condensed consolidated balance sheets as of December 31, 2021 and March 31, 2021.

[0001032975-22-000006:notes:74]
The fair value of the Company’s derivative instruments was not material as of December 31, 2021 or March 31, 2021. The amount of gain (loss) recognized on derivatives not designated as hedging instruments was not material in all periods presented herein. The following table presents the amounts of gains (losses) on the Company’s derivative instruments designated as hedging instruments and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income for the three and nine months ended December 31, 2021 and 2020 (in thousands):

[0001032975-22-000006:notes:75]
|  |  | Three Months EndedDecember 31, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  |  |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  |  |  |  |
| Cash flow hedges |  | $ | 1,061 |  |  | $ | (6,326) |  |  | $ | (3,200) |  |  | $ | 3,446 |  |  |  |  |  |
|  |  | Nine Months EndedDecember 31, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  |  |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  |  |  |  |
| Cash flow hedges |  | $ | 3,723 |  |  | $ | (9,752) |  |  | $ | (5,108) |  |  | $ | 5,085 |  |  |  |  |  |

[0001032975-22-000006:notes:76]
[same as prior period, unchanged from 0001032975-21-000045:notes:72]

[0001032975-22-000006:notes:77]
The Company enters into cash flow hedge contracts to protect against exchange rate exposure of forecasted inventory purchases. These hedging contracts mature within four months. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Cash flows from such hedges are classified as operating activities in the condensed consolidated statements of cash flows. Hedging relationships are discontinued when hedging contract is no longer eligible for hedge accounting, or is sold, terminated or exercised, or when Company removes hedge designation for the contract. Gains and losses in the fair value of the effective portion of the discontinued hedges continue to be reported in accumulated other comprehensive loss until the hedged inventory purchases are sold, unless it is probable that the forecasted inventory purchases will not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. In all periods presented herein, there have been no forecasted inventory purchases that were probable to not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. The notional amounts of foreign currency exchange forward contracts outstanding related to forecasted inventory purchases were $128.1 million as of December 31, 2021 and $164.5 million as of March 31, 2021. The Company had $2.4 million of net gains related to its cash flow hedges included in accumulated other comprehensive loss as of December 31, 2021, which will be reclassified into earnings within the next 12 months.

[0001032975-22-000006:notes:78]
[same as prior period, unchanged from 0001032975-21-000045:notes:74]

[0001032975-22-000006:notes:79]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are recognized in other income, net in the condensed consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of December 31, 2021 and March 31, 2021 were $251.7 million and $123.8 million, respectively. Open forward and swap contracts outstanding as of December 31, 2021 and March 31, 2021 consisted of contracts in Mexican Pesos, Japanese Yen, Canadian Dollars, Taiwanese Dollars, and Australian Dollars to be settled at future dates at pre-determined exchange rates. Open forward and swap contracts outstanding as of December 31, 2021 additionally consisted of contracts in Chinese Renminbi and Brazilian Real to be settled at future dates at pre-determined exchange rates, which were primarily attributable to the increase in the notional amounts outstanding as of December 31, 2021 compared to March 31, 2021.

[0001032975-22-000006:notes:80]
[same as prior period, unchanged from 0001032975-21-000045:notes:76]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-22-000006:notes:81]
Goodwill and Other Intangible Assets
The Company conducts its impairment analysis of goodwill and indefinite life intangible assets annually at December 31 and as necessary, if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting unit may be less than its carrying amount. The Company conducted its annual impairment analysis of goodwill and indefinite life intangible asset as of December 31, 2021 by performing a qualitative assessment and concluded that it was more likely than not that the fair value of its reporting unit exceeds its carrying amount.  In assessing the qualitative factors, the Company considered the impact of change in industry and competitive environment, growth in the Company's market capitalization and budgeted-to-actual revenue performance for the last twelve months.

[0001032975-22-000006:notes:82]
The following table summarizes the activities in the Company’s goodwill balance during the nine months ended December 31, 2021 (in thousands):

[0001032975-22-000006:notes:83]
| As of March 31, 2021 |  | $ | 429,604 |  |
| Acquisition |  | 20,721 |  |
| Effects of foreign currency translation |  | (1,594) |  |
| As of December 31, 2021 |  | $ | 448,731 |  |

[0001032975-22-000006:notes:84]
During the third quarter of fiscal 2022, the Company decided to discontinue Jaybird-branded products.  As a result of this decision, the Company performed an analysis to compare the fair value of Jaybird-related intangible assets to their carrying amount. As the fair value using estimated discounted cash flows was less than the carrying amount, the Company recognized a pre-tax impairment charge in the condensed consolidated statement of operations of $7.0 million, which was primarily related to customer contracts and relationships. See Note 13 for further information regarding the exit plan.

[0001032975-22-000006:notes:85]
On May 19, 2021, the Company made an immaterial technology acquisition for a total cash consideration of $25.6 million, including up to $10.0 million earn-out payable in cash upon the achievement of three technical development milestones required to be completed as of December 31, 2021, June 30, 2022, and June 30, 2023, which was accounted for using the acquisition method. The Company retained 6% of the total consideration for the purpose of ensuring seller's representations and warranties.

[0001032975-22-000006:notes:86]
[same as prior period, unchanged from 0001032975-21-000045:notes:82]

[0001032975-22-000006:notes:87]
|  |  | December 31, 2021 |  | March 31, 2021 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademark and trade names |  | $ | 36,790 |  |  | $ | (21,112) |  |  | $ | 15,678 |  |  | $ | 46,070 |  |  | $ | (25,153) |  |  | $ | 20,917 |  |
| Developed technology |  | 119,707 |  |  | (80,545) |  |  | 39,162 |  |  | 134,406 |  |  | (90,450) |  |  | 43,956 |  |
| Customer contracts/relationships |  | 71,110 |  |  | (39,172) |  |  | 31,938 |  |  | 91,010 |  |  | (44,261) |  |  | 46,749 |  |
| In-process R&D |  | 3,526 |  |  | — |  |  | 3,526 |  |  | 3,526 |  |  | — |  |  | 3,526 |  |
| Effects of foreign currency translation |  | (475) |  |  | 49 |  |  | (426) |  |  | — |  |  | — |  |  | — |  |
| Total |  | $ | 230,658 |  |  | $ | (140,780) |  |  | $ | 89,878 |  |  | $ | 275,012 |  |  | $ | (159,864) |  |  | $ | 115,148 |  |


## us-gaap:DebtDisclosureTextBlock

[0001032975-22-000006:notes:88]
Financing Arrangements

[0001032975-22-000006:notes:89]
The Company had several uncommitted, unsecured bank lines of credit aggregating $194.4 million as of December 31, 2021. There are no financial covenants under these lines of credit with which the Company must comply. As of December 31, 2021, the Company had outstanding bank guarantees of $11.8 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of December 31, 2021 or March 31, 2021.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-22-000006:notes:90]
Commitments and Contingencies

[0001032975-22-000006:notes:91]
Product Warranties

[0001032975-22-000006:notes:92]
Changes in the Company’s warranty liability for the three and nine months ended December 31, 2021 and 2020 were as follows (in thousands):

[0001032975-22-000006:notes:93]
|  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Beginning of the period | $ | 49,173 |  |  | $ | 41,782 |  |  | $ | 48,832 |  |  | $ | 40,039 |  |
| Provision | 6,962 |  |  | 13,692 |  |  | 23,503 |  |  | 28,575 |  |
| Settlements | (8,056) |  |  | (8,371) |  |  | (24,219) |  |  | (22,073) |  |
| Effects of foreign currency translation | (144) |  |  | 489 |  |  | (181) |  |  | 1,051 |  |
| End of the period | $ | 47,935 |  |  | $ | 47,592 |  |  | $ | 47,935 |  |  | $ | 47,592 |  |

[0001032975-22-000006:notes:94]
Indemnifications

[0001032975-22-000006:notes:95]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including

[0001032975-22-000006:notes:96]
reasonable attorneys’ fees. As of December 31, 2021, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-22-000006:notes:97]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-22-000006:notes:98]
Legal Proceedings

[0001032975-22-000006:notes:99]
From time to time the Company is involved in claims and legal proceedings which arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial position, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial position, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-22-000006:notes:100]
[same as prior period, unchanged from 0001032975-21-000045:notes:95]

[0001032975-22-000006:notes:101]
[same as prior period, unchanged from 0001032975-21-000045:notes:96]

[0001032975-22-000006:notes:102]
In May 2020, the Company's Board of Directors approved the 2020 share repurchase program, which authorized the Company to use up to $250.0 million to purchase up to 17.3 million of Logitech shares. The Company's share repurchase program is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. In April 2021, the Company's Board of Directors approved an increase of $750.0 million of the 2020 share repurchase program, to an aggregate amount of $1.0 billion. The Swiss Takeover Board approved this increase and it became effective on May 21, 2021. As of December 31, 2021, $545.0 million is still available for repurchase under the 2020 repurchase program.

[0001032975-22-000006:notes:103]
[same as prior period, unchanged from 0001032975-21-000045:notes:98]

[0001032975-22-000006:notes:104]
During the nine months ended December 31, 2021, the Company declared and paid cash dividends of CHF 0.87 (USD equivalent of $0.95) per share, totaling $159.4 million on the Company's outstanding shares. During the nine months ended December 31, 2020, the Company declared and paid cash dividends of CHF 0.79 (USD equivalent of $0.87) per share, totaling $146.7 million on the Company's outstanding shares.

[0001032975-22-000006:notes:105]
[same as prior period, unchanged from 0001032975-21-000045:notes:100]

[0001032975-22-000006:notes:106]
[same as prior period, unchanged from 0001032975-21-000045:notes:101]

[0001032975-22-000006:notes:107]
[same as prior period, unchanged from 0001032975-21-000045:notes:102]

[0001032975-22-000006:notes:108]
|  |  | Accumulated Other Comprehensive Income (Loss) |
|  |  | CumulativeTranslationAdjustment |  | DefinedBenefitPlan |  | Deferred Hedging Gains / (Losses) |  | Total |
| March 31, 2021 |  | $ | (89,461) |  |  | $ | (23,200) |  |  | $ | 3,746 |  |  | $ | (108,915) |  |
| Other comprehensive gains (losses) |  | (8,682) |  |  | (214) |  |  | (1,385) |  |  | (10,281) |  |
| December 31, 2021 |  | $ | (98,143) |  |  | $ | (23,414) |  |  | $ | 2,361 |  |  | $ | (119,196) |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-22-000006:notes:109]
[same as prior period, unchanged from 0001032975-21-000045:notes:104]

[0001032975-22-000006:notes:110]
[same as prior period, unchanged from 0001032975-21-000045:notes:105]

[0001032975-22-000006:notes:111]
Sales by product categories and sales channels, excluding intercompany transactions, for the three and nine months ended December 31, 2021 and 2020 were as follows (in thousands):

[0001032975-22-000006:notes:112]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Pointing Devices |  | $ | 231,090 |  |  | $ | 213,638 |  |  | $ | 602,982 |  |  | $ | 503,228 |  |
| Keyboards & Combos |  | 281,608 |  |  | 218,269 |  |  | 736,237 |  |  | 565,246 |  |
| PC Webcams |  | 115,115 |  |  | 131,700 |  |  | 319,504 |  |  | 295,020 |  |
| Tablet & Other Accessories |  | 82,859 |  |  | 138,052 |  |  | 242,932 |  |  | 267,186 |  |
| Gaming (1) |  | 469,282 |  |  | 436,426 |  |  | 1,135,456 |  |  | 916,040 |  |
| Video Collaboration |  | 287,187 |  |  | 292,500 |  |  | 753,725 |  |  | 659,278 |  |
| Mobile Speakers |  | 56,748 |  |  | 72,566 |  |  | 124,724 |  |  | 145,156 |  |
| Audio & Wearables |  | 104,280 |  |  | 152,952 |  |  | 318,965 |  |  | 338,592 |  |
| Smart Home |  | 4,559 |  |  | 10,593 |  |  | 16,380 |  |  | 25,976 |  |
| Other (2) |  | 54 |  |  | 606 |  |  | 202 |  |  | 632 |  |
| Total Sales |  | $ | 1,632,782 |  |  | $ | 1,667,302 |  |  | $ | 4,251,107 |  |  | $ | 3,716,354 |  |

[0001032975-22-000006:notes:113]
[same as prior period, unchanged from 0001032975-21-000045:notes:108]

[0001032975-22-000006:notes:114]
[same as prior period, unchanged from 0001032975-21-000045:notes:109]

[0001032975-22-000006:notes:115]
Sales by geographic region (based on the customers’ locations) for the three and nine months ended December 31, 2021 and 2020 were as follows (in thousands):

[0001032975-22-000006:notes:116]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Americas |  | $ | 674,393 |  |  | $ | 704,718 |  |  | $ | 1,828,474 |  |  | $ | 1,603,221 |  |
| EMEA |  | 552,133 |  |  | 547,044 |  |  | 1,309,542 |  |  | 1,147,393 |  |
| Asia Pacific |  | 406,256 |  |  | 415,540 |  |  | 1,113,091 |  |  | 965,740 |  |
| Total sales |  | $ | 1,632,782 |  |  | $ | 1,667,302 |  |  | $ | 4,251,107 |  |  | $ | 3,716,354 |  |

[0001032975-22-000006:notes:117]
[same as prior period, unchanged from 0001032975-21-000045:notes:112]

[0001032975-22-000006:notes:118]
The United States and Germany each represented 10% or more of the total consolidated sales for each of the periods presented herein. China represented more than 10% of the total consolidated sales for the three and nine months ended December 31, 2021. No other countries represented 10% or more of the Company’s total consolidated sales for the periods presented herein.

[0001032975-22-000006:notes:119]
Switzerland, the Company’s home domicile, represented 3% of the Company's total consolidated sales for each of the periods presented herein.

[0001032975-22-000006:notes:120]
[same as prior period, unchanged from 0001032975-21-000045:notes:115]

[0001032975-22-000006:notes:121]
[same as prior period, unchanged from 0001032975-21-000045:notes:116]

[0001032975-22-000006:notes:122]
|  |  | December 31, 2021 |  | March 31, 2021 |
| Americas |  | $ | 18,071 |  |  | $ | 20,810 |  |
| EMEA |  | 15,245 |  |  | 8,019 |  |
| Asia Pacific |  | 76,285 |  |  | 85,231 |  |
| Total property, plant and equipment, net |  | $ | 109,601 |  |  | $ | 114,060 |  |

[0001032975-22-000006:notes:123]
Property, plant and equipment, net in the United States and China were $17.8 million, $64.1 million, respectively, as of December 31, 2021, and  $20.5 million and $74.0 million, respectively, as of March 31, 2021. Property, plant and equipment, net in Switzerland, the Company’s home domicile, were $12.7 million and $5.7 million as of December 31, 2021 and March 31, 2021, respectively.  Switzerland represented more than 10% of the Company's total consolidated property, plant and equipment, net as of December 31, 2021. No other countries represented 10% or more of the Company’s total consolidated property, plant and equipment, net as of December 31, 2021 or March 31, 2021.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001032975-22-000006:notes:124]
Restructuring
During the third quarter of fiscal 2022, as part of the Company's strategic review, the Company decided to cease future product launches under the Jaybird brand within the Audio & Wearables product category. As a result, the Company recorded pre-tax restructuring charges of $1.8 million for the three and nine months ended December 31, 2021, which are included in the condensed consolidated statement of operations as restructuring charges (credits), net. The accrual balances are presented in accrued and other current liabilities in the condensed consolidated balance sheets.

[0001032975-22-000006:notes:125]
Total charges related to the exit of Jaybird-branded products were $16.3 million, which included restructuring charges and other costs, for the three and nine months ended December 31, 2021. The restructuring charges consisted of $1.3 million, primarily related to costs of production cancellation and $0.5 million related to cash severance and termination benefits. The Company also recorded $7.6 million in cost of goods sold related to write-offs for excess inventories. In addition, as discussed in Note 8, the Company recognized a pre-tax impairment charge of $7.0 million, related to intangible assets acquired as part of the Jaybird acquisition. The Company expects to substantially complete this restructuring within the next twelve months.

[0001032975-22-000006:notes:126]
The following table presents a rollforward of the restructuring liability for the nine months ended December 31, 2021 (in thousands):

[0001032975-22-000006:notes:127]
|  |  | TerminationBenefits |  | Other |  | Total |  |  |  |  |  |  |
| Accrual balance at March 31, 2021 |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |  |  |  |  |
| Charges |  | 472 |  |  | 1,287 |  |  | 1,759 |  |  |  |  |  |  |  |
| Cash payments |  | — |  |  | — |  |  | — |  |  |  |  |  |  |  |
| Accrual balance at December 31, 2021 |  | $ | 472 |  |  | $ | 1,287 |  |  | $ | 1,759 |  |  |  |  |  |  |  |
