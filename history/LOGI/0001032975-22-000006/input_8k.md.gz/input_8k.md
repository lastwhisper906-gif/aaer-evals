# LOGI 8-K — 0001032975-22-000003 filed 2022-01-25

## item codes, every 8-K on or before 2022-01-27

- 2022-01-25 0001032975-22-000003 — 2.02, 9.01
- 2021-10-26 0001032975-21-000043 — 2.02, 9.01
- 2021-09-10 0001032975-21-000040 — 5.07, 8.01
- 2021-07-27 0001032975-21-000029 — 2.02, 9.01
- 2021-04-29 0001032975-21-000012 — 2.02, 9.01
- 2021-01-19 0001032975-21-000004 — 2.02, 9.01
- 2020-10-20 0001032975-20-000045 — 2.02, 9.01
- 2020-09-11 0001032975-20-000042 — 5.07, 8.01
- 2020-07-21 0001032975-20-000029 — 2.02, 9.01
- 2020-07-01 0001032975-20-000023 — 5.02, 8.01
- 2020-05-12 0001032975-20-000011 — 2.02, 9.01
- 2020-03-30 0001032975-20-000009 — 5.02
- 2020-01-21 0001032975-20-000002 — 2.02, 9.01
- 2019-10-22 0001032975-19-000071 — 9.01
- 2019-09-26 0001032975-19-000068 — 1.01, 7.01, 9.01
- 2019-09-06 0001032975-19-000063 — 5.07, 8.01
- 2019-07-23 0001032975-19-000046 — 2.02, 9.01
- 2019-07-23 0001032975-19-000045 — 5.02, 9.01
- 2019-07-02 0001032975-19-000036 — 5.02
- 2019-06-25 0001032975-19-000034 — 5.02
- 2019-05-03 0001032975-19-000021 — 5.02 — amendment, the index does not say of what
- 2019-04-30 0001032975-19-000017 — 2.02, 5.02, 9.01
- 2019-03-28 0001032975-19-000013 — 5.02
- 2019-01-22 0001032975-19-000004 — 2.02, 9.01
- 2018-10-23 0001032975-18-000044 — 2.02, 9.01
- 2018-09-07 0001032975-18-000040 — 5.07, 8.01
- 2018-07-31 0001032975-18-000035 — 1.01, 2.02, 2.05, 7.01, 9.01
- 2018-06-27 0001032975-18-000020 — 5.02
- 2018-05-03 0001032975-18-000013 — 2.02, 5.02, 9.01
- 2018-01-23 0001032975-18-000005 — 2.02, 9.01
- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2022-01-27

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-22-000003:8k_2_02:1]
EX-99.1
2
exhibit991q3fy22.htm
EX-99.1

[0001032975-22-000003:8k_2_02:2]
Document

[0001032975-22-000003:8k_2_02:3]
Exhibit 99.1

[0001032975-22-000003:8k_2_02:4]
Editorial Contacts:

[0001032975-22-000003:8k_2_02:5]
Nicole Noutsios, Investor Relations - lir@logitech.com

[0001032975-22-000003:8k_2_02:6]
Nicole Kenyon, Head of Global Corporate & Employee Communications - USA +1 (510) 988-8553

[0001032975-22-000003:8k_2_02:7]
Ben Starkie, Corporate Communications - Europe +41 (0) 79-292-3499

[0001032975-22-000003:8k_2_02:8]
Logitech Announces Q3 Results

[0001032975-22-000003:8k_2_02:9]
Company Raises FY 2022 Outlook For Both Sales and Profitability

[0001032975-22-000003:8k_2_02:10]
LAUSANNE, Switzerland, Jan. 25, 2022 and NEWARK, Calif., Jan. 24, 2022 — SIX Swiss Exchange Ad hoc announcement pursuant to Art. 53 LR — Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the third quarter of Fiscal Year 2022, with strong growth in Pointing Devices, Keyboards & Combos and Gaming, and share gains in the majority of key categories. The Company raised annual guidance for both sales and profitability.

[0001032975-22-000003:8k_2_02:11]
Q3 financial highlights:

[0001032975-22-000003:8k_2_02:12]
•Sales were $1.63 billion, down 2 percent in US dollars and constant currency, compared to Q3 of the prior year. This performance nearly sustains last year’s record Q3 sales which grew 85 percent in US dollars and 80 percent in constant currency.

[0001032975-22-000003:8k_2_02:13]
•Category sales in US dollars grew 29 percent in Keyboards & Combos and 8 percent in Pointing Devices and Gaming, compared to Q3 of the prior year. Video Collaboration grew 24 percent quarter over quarter and was down 2 percent compared to Q3 of the prior year in which sales grew more than 200 percent.

[0001032975-22-000003:8k_2_02:14]
•GAAP operating income declined 41 percent to $263 million, compared to $448 million in the same quarter a year ago. Non-GAAP operating income declined 37 percent to $302 million, compared to $476 million in the same quarter a year ago. This reflects the Company’s planned, strategic investments in marketing and innovation to drive future growth. Non-GAAP operating income almost doubled versus two years ago.

[0001032975-22-000003:8k_2_02:15]
•GAAP earnings per share (EPS) declined 44 percent to $1.24, compared to $2.22 in the same quarter a year ago. Non-GAAP EPS declined 37 percent to $1.55, compared to $2.45 in the same quarter a year ago.

[0001032975-22-000003:8k_2_02:16]
•Cash flow from operations was $377 million. The Company returned $116 million of cash to shareholders through share repurchases. Year to date, the Company has returned a total of $450 million to shareholders through dividends and share repurchases, more than twice the amount over the same period last year.

[0001032975-22-000003:8k_2_02:17]
“I’m excited to now have in sight a fiscal year of growth for FY 2022, on top of last year’s remarkable performance,” said Bracken Darrell, Logitech president and chief executive officer. “Our Q3 results reflect the strength of our operational capabilities, innovation engine, and the choices we made to position ourselves in line with the long-term trends affecting work, play, and creating.”

[0001032975-22-000003:8k_2_02:18]
Outlook

[0001032975-22-000003:8k_2_02:19]
Logitech raised its Fiscal Year 2022 annual outlook to between 2 and 5 percent sales growth in constant currency, and between $850 million and $900 million in non-GAAP operating income. The Company’s previous outlook was flat sales growth in constant currency, plus or minus five percent, and $800 million to $850 million in non-GAAP operating income.

[0001032975-22-000003:8k_2_02:20]
Prepared Remarks Available Online

[0001032975-22-000003:8k_2_02:21]
Logitech has made its prepared written remarks for the financial results videoconference available online on the Logitech corporate website at http://ir.logitech.com.

[0001032975-22-000003:8k_2_02:22]
Financial Results Videoconference and Webcast

[0001032975-22-000003:8k_2_02:23]
Logitech will hold a financial results videoconference to discuss the results for Q3 Fiscal Year 2022 on Tuesday, January 25, 2022 at 8:30 a.m. Eastern Standard Time and 2:30 p.m. Central European Time. A livestream of the event will be available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-22-000003:8k_2_02:24]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-22-000003:8k_2_02:25]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of intangible assets, impairment of intangible assets, acquisition-related costs, change in fair value of contingent consideration for business acquisition, restructuring charges (credits), loss (gain) on investments, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below. Logitech also presents percentage sales growth in constant currency, a non-GAAP measure, to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for the Fiscal Year 2022 outlook.

[0001032975-22-000003:8k_2_02:26]
Public Dissemination of Certain Information

[0001032975-22-000003:8k_2_02:27]
Logitech webcasts its earnings calls, and certain events Logitech participates in or hosts, with members of the investment community on its investor relations website at https://ir.logitech.com. Additionally, Logitech provides notifications of news or announcements regarding its operations and financial performance, including its filings with the Securities and Exchange Commission (SEC), investor events, and press and earnings releases as part of its investor relations website. Logitech intends to use its investor relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. Logitech’s corporate governance information also is available on its investor relations website.

[0001032975-22-000003:8k_2_02:28]
About Logitech

[0001032975-22-000003:8k_2_02:29]
Logitech helps all people pursue their passions by designing experiences so everyone can create, achieve, and enjoy more. Logitech designs and creates products that bring people together through

[0001032975-22-000003:8k_2_02:30]
computing, gaming, video, streaming and creating, and music. Brands of Logitech include Logitech, Logitech G, ASTRO Gaming, Streamlabs, Blue Microphones and Ultimate Ears. Founded in 1981, and headquartered in Lausanne, Switzerland, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @Logitech.

[0001032975-22-000003:8k_2_02:31]
# # #

[0001032975-22-000003:8k_2_02:32]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-22-000003:8k_2_02:33]
Logitech and other Logitech marks are trademarks or registered trademarks of Logitech Europe S.A. and/or its affiliates in the U.S. and other countries. All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-22-000003:8k_2_02:34]
(LOGIIR)

[0001032975-22-000003:8k_2_02:35]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales |  | $ | 1,632,782 |  |  | $ | 1,667,302 |  |  | $ | 4,251,107 |  |  | $ | 3,716,354 |  |
| Cost of goods sold |  | 971,646 |  |  | 914,851 |  |  | 2,470,980 |  |  | 2,082,088 |  |
| Amortization of intangible assets |  | 3,126 |  |  | 3,441 |  |  | 11,028 |  |  | 9,800 |  |
| Gross profit |  | 658,010 |  |  | 749,010 |  |  | 1,769,099 |  |  | 1,624,466 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 269,941 |  |  | 204,485 |  |  | 778,882 |  |  | 496,520 |  |
| Research and development |  | 75,529 |  |  | 53,910 |  |  | 213,436 |  |  | 157,014 |  |
| General and administrative |  | 38,478 |  |  | 37,606 |  |  | 112,291 |  |  | 98,341 |  |
| Amortization of intangible assets and acquisition-related costs |  | 3,662 |  |  | 4,946 |  |  | 13,986 |  |  | 13,886 |  |
| Impairment of intangible assets |  | 7,000 |  |  | — |  |  | 7,000 |  |  | — |  |
| Change in fair value of contingent consideration for business acquisition |  | (1,110) |  |  | — |  |  | (3,509) |  |  | 5,716 |  |
| Restructuring charges (credits), net |  | 1,759 |  |  | — |  |  | 1,770 |  |  | (54) |  |
| Total operating expenses |  | 395,259 |  |  | 300,947 |  |  | 1,123,856 |  |  | 771,423 |  |
| Operating income |  | 262,751 |  |  | 448,063 |  |  | 645,243 |  |  | 853,043 |  |
| Interest income |  | 278 |  |  | 311 |  |  | 795 |  |  | 1,444 |  |
| Other income (expense), net |  | (3,673) |  |  | 6,483 |  |  | (1,941) |  |  | 9,661 |  |
| Income before income taxes |  | 259,356 |  |  | 454,857 |  |  | 644,097 |  |  | 864,148 |  |
| Provision for income taxes |  | 49,345 |  |  | 72,334 |  |  | 107,789 |  |  | 142,638 |  |
| Net income |  | $ | 210,011 |  |  | $ | 382,523 |  |  | $ | 536,308 |  |  | $ | 721,510 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.26 |  |  | $ | 2.26 |  |  | $ | 3.19 |  |  | $ | 4.28 |  |
| Diluted |  | $ | 1.24 |  |  | $ | 2.22 |  |  | $ | 3.14 |  |  | $ | 4.21 |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | 167,090 |  |  | 169,050 |  |  | 167,953 |  |  | 168,448 |  |
| Diluted |  | 169,707 |  |  | 172,587 |  |  | 171,027 |  |  | 171,378 |  |

[0001032975-22-000003:8k_2_02:36]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | December 31, |  | March 31, |  |  |  |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  | 2021 |  | 2021 |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,364,411 |  |  | $ | 1,750,327 |  |  |  |  |  |
| Accounts receivable, net |  | 845,836 |  |  | 612,225 |  |  |  |  |  |
| Inventories |  | 834,534 |  |  | 661,116 |  |  |  |  |  |
| Other current assets |  | 145,001 |  |  | 135,650 |  |  |  |  |  |
| Total current assets |  | 3,189,782 |  |  | 3,159,318 |  |  |  |  |  |
| Non-current assets: |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 109,601 |  |  | 114,060 |  |  |  |  |  |
| Goodwill |  | 448,731 |  |  | 429,604 |  |  |  |  |  |
| Other intangible assets, net |  | 89,878 |  |  | 115,148 |  |  |  |  |  |
| Other assets |  | 323,605 |  |  | 324,248 |  |  |  |  |  |
| Total assets |  | $ | 4,161,597 |  |  | $ | 4,142,378 |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 738,992 |  |  | $ | 823,233 |  |  |  |  |  |
| Accrued and other current liabilities |  | 813,684 |  |  | 858,617 |  |  |  |  |  |
| Total current liabilities |  | 1,552,676 |  |  | 1,681,850 |  |  |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Income taxes payable |  | 85,610 |  |  | 59,237 |  |  |  |  |  |
| Other non-current liabilities |  | 155,369 |  |  | 139,502 |  |  |  |  |  |
| Total liabilities |  | 1,793,655 |  |  | 1,880,589 |  |  |  |  |  |
| Shareholders’ equity: |  |  |  |  |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |  |  |  |  |
| Issued shares — 173,106 at December 31 and March 31, 2021 |  |  |  |  |  |  |  |  |
| Additional shares that may be issued out of conditional capitals — 50,000 at December 31 and March 31, 2021 |  |  |  |  |  |  |  |  |
| Additional shares that may be issued out of authorized capital — 17,311 at December 31 and March 31, 2021 |  |  |  |  |  |  |  |  |
| Additional paid-in capital |  | 115,994 |  |  | 129,519 |  |  |  |  |  |
| Shares in treasury, at cost — 6,639 at December 31, 2021 and 4,799 at March 31, 2021 |  | (526,480) |  |  | (279,541) |  |  |  |  |  |
| Retained earnings |  | 2,867,476 |  |  | 2,490,578 |  |  |  |  |  |
| Accumulated other comprehensive loss |  | (119,196) |  |  | (108,915) |  |  |  |  |  |
| Total shareholders’ equity |  | 2,367,942 |  |  | 2,261,789 |  |  |  |  |  |
| Total liabilities and shareholders’ equity |  | $ | 4,161,597 |  |  | $ | 4,142,378 |  |  |  |  |  |

[0001032975-22-000003:8k_2_02:37]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 210,011 |  |  | $ | 382,523 |  |  | $ | 536,308 |  |  | $ | 721,510 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  | 21,913 |  |  | 13,409 |  |  | 65,387 |  |  | 36,010 |  |
| Amortization of intangible assets |  | 6,755 |  |  | 8,388 |  |  | 24,223 |  |  | 23,627 |  |
| Impairment of intangible assets |  | 7,000 |  |  | — |  |  | 7,000 |  |  | — |  |
| Loss on investments |  | 460 |  |  | 2,173 |  |  | 1,421 |  |  | 4,692 |  |
| Share-based compensation expense |  | 24,792 |  |  | 19,814 |  |  | 72,465 |  |  | 64,714 |  |
| Deferred income taxes |  | 20,561 |  |  | 17,531 |  |  | 27,369 |  |  | 37,683 |  |
| Change in fair value of contingent consideration for business acquisition |  | (1,110) |  |  | — |  |  | (3,509) |  |  | 5,716 |  |
| Other |  | 9 |  |  | 207 |  |  | 1,068 |  |  | (1,670) |  |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | (123,350) |  |  | (129,966) |  |  | (236,358) |  |  | (476,804) |  |
| Inventories |  | (10,240) |  |  | (78,258) |  |  | (177,828) |  |  | (239,378) |  |
| Other assets |  | 27,871 |  |  | (21,714) |  |  | (20,569) |  |  | (53,281) |  |
| Accounts payable |  | 74,845 |  |  | 141,848 |  |  | (80,637) |  |  | 541,024 |  |
| Accrued and other liabilities |  | 117,059 |  |  | 173,945 |  |  | (17,612) |  |  | 264,576 |  |
| Net cash provided by operating activities |  | 376,576 |  |  | 529,900 |  |  | 198,728 |  |  | 928,419 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (16,494) |  |  | (18,389) |  |  | (63,726) |  |  | (46,163) |  |
| Investment in privately held companies |  | (359) |  |  | (120) |  |  | (1,260) |  |  | (3,525) |  |
| Acquisitions, net of cash acquired |  | (300) |  |  | (360) |  |  | (15,886) |  |  | (360) |  |
| Proceeds from return of strategic investments |  | — |  |  | 2,934 |  |  | — |  |  | 2,934 |  |
| Purchases of short-term investments |  | (10,000) |  |  | — |  |  | (10,000) |  |  | — |  |
| Proceeds from the sale of short-term investments |  | 1,225 |  |  | — |  |  | 1,225 |  |  | — |  |
| Purchases of trading investments |  | (1,178) |  |  | (2,473) |  |  | (3,644) |  |  | (10,672) |  |
| Proceeds from sales of trading investments |  | 1,308 |  |  | 2,493 |  |  | 4,285 |  |  | 11,332 |  |
| Net cash used in investing activities |  | (25,798) |  |  | (15,915) |  |  | (89,006) |  |  | (46,454) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | — |  |  | — |  |  | (159,410) |  |  | (146,705) |  |
| Payment of contingent consideration for business acquisition |  | (880) |  |  | — |  |  | (880) |  |  | — |  |
| Purchases of registered shares |  | (116,245) |  |  | (50,271) |  |  | (290,625) |  |  | (72,725) |  |
| Proceeds from exercises of stock options and purchase rights |  | 8 |  |  | 3,643 |  |  | 16,644 |  |  | 29,709 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (3,777) |  |  | (3,731) |  |  | (58,528) |  |  | (29,475) |  |
| Net cash used in financing activities |  | (120,894) |  |  | (50,359) |  |  | (492,799) |  |  | (219,196) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (2,769) |  |  | 7,896 |  |  | (2,839) |  |  | 10,408 |  |
| Net increase / (decrease) in cash and cash equivalents |  | 227,115 |  |  | 471,522 |  |  | (385,916) |  |  | 673,177 |  |
| Cash and cash equivalents, beginning of the period |  | 1,137,296 |  |  | 917,221 |  |  | 1,750,327 |  |  | 715,566 |  |
| Cash and cash equivalents, end of the period |  | $ | 1,364,411 |  |  | $ | 1,388,743 |  |  | $ | 1,364,411 |  |  | $ | 1,388,743 |  |

[0001032975-22-000003:8k_2_02:38]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
| NET SALES |  | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Net sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Pointing Devices |  | $ | 231,090 |  |  | $ | 213,638 |  |  | 8 | % |  | $ | 602,982 |  |  | $ | 503,228 |  |  | 20 | % |
| Keyboards & Combos |  | 281,608 |  |  | 218,269 |  |  | 29 |  |  | 736,237 |  |  | 565,246 |  |  | 30 |  |
| PC Webcams |  | 115,115 |  |  | 131,700 |  |  | (13) |  |  | 319,504 |  |  | 295,020 |  |  | 8 |  |
| Tablet & Other Accessories |  | 82,859 |  |  | 138,052 |  |  | (40) |  |  | 242,932 |  |  | 267,186 |  |  | (9) |  |
| Gaming (1) |  | 469,282 |  |  | 436,426 |  |  | 8 |  |  | 1,135,456 |  |  | 916,040 |  |  | 24 |  |
| Video Collaboration |  | 287,187 |  |  | 292,500 |  |  | (2) |  |  | 753,725 |  |  | 659,278 |  |  | 14 |  |
| Mobile Speakers |  | 56,748 |  |  | 72,566 |  |  | (22) |  |  | 124,724 |  |  | 145,156 |  |  | (14) |  |
| Audio & Wearables |  | 104,280 |  |  | 152,952 |  |  | (32) |  |  | 318,965 |  |  | 338,592 |  |  | (6) |  |
| Smart Home |  | 4,559 |  |  | 10,593 |  |  | (57) |  |  | 16,380 |  |  | 25,976 |  |  | (37) |  |
| Other (2) |  | 54 |  |  | 606 |  |  | (91) |  |  | 202 |  |  | 632 |  |  | (68) |  |
| Total Sales |  | $ | 1,632,782 |  |  | $ | 1,667,302 |  |  | (2) | % |  | $ | 4,251,107 |  |  | $ | 3,716,354 |  |  | 14 | % |

[0001032975-22-000003:8k_2_02:39]
(1) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-22-000003:8k_2_02:40]
(2) Other includes products that the Company currently intends to phase out, or has already phased out, because they are no longer strategic to the Company's business.

[0001032975-22-000003:8k_2_02:41]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
| GAAP TO NON GAAP RECONCILIATION (A) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Gross profit - GAAP |  | $ | 658,010 |  |  | $ | 749,010 |  |  | $ | 1,769,099 |  |  | $ | 1,624,466 |  |
| Share-based compensation expense |  | 1,782 |  |  | 1,747 |  |  | 5,253 |  |  | 4,919 |  |
| Amortization of intangible assets |  | 3,126 |  |  | 3,441 |  |  | 11,028 |  |  | 9,800 |  |
| Gross profit - Non-GAAP |  | $ | 662,918 |  |  | $ | 754,198 |  |  | $ | 1,785,380 |  |  | $ | 1,639,185 |  |
| Gross margin - GAAP |  | 40.3 | % |  | 44.9 | % |  | 41.6 | % |  | 43.7 | % |
| Gross margin - Non-GAAP |  | 40.6 | % |  | 45.2 | % |  | 42.0 | % |  | 44.1 | % |
| Operating expenses - GAAP |  | $ | 395,259 |  |  | $ | 300,947 |  |  | $ | 1,123,856 |  |  | $ | 771,423 |  |
| Less: Share-based compensation expense |  | 23,010 |  |  | 18,067 |  |  | 67,212 |  |  | 59,795 |  |
| Less: Amortization of intangible assets and acquisition-related costs |  | 3,662 |  |  | 4,946 |  |  | 13,986 |  |  | 13,886 |  |
| Less: Impairment of intangible assets |  | 7,000 |  |  | — |  |  | 7,000 |  |  | — |  |
| Less: Change in fair value of contingent consideration for business acquisition |  | (1,110) |  |  | — |  |  | (3,509) |  |  | 5,716 |  |
| Less: Restructuring charges (credits), net |  | 1,759 |  |  | — |  |  | 1,770 |  |  | (54) |  |
| Operating expenses - Non-GAAP |  | $ | 360,938 |  |  | $ | 277,934 |  |  | $ | 1,037,397 |  |  | $ | 692,080 |  |
| % of net sales - GAAP |  | 24.2 | % |  | 18.0 | % |  | 26.4 | % |  | 20.8 | % |
| % of net sales - Non - GAAP |  | 22.1 | % |  | 16.7 | % |  | 24.4 | % |  | 18.6 | % |
| Operating income - GAAP |  | $ | 262,751 |  |  | $ | 448,063 |  |  | $ | 645,243 |  |  | $ | 853,043 |  |
| Share-based compensation expense |  | 24,792 |  |  | 19,814 |  |  | 72,465 |  |  | 64,714 |  |
| Amortization of intangible assets and acquisition-related costs |  | 6,788 |  |  | 8,387 |  |  | 25,014 |  |  | 23,686 |  |
| Impairment of intangible assets |  | 7,000 |  |  | — |  |  | 7,000 |  |  | — |  |
| Change in fair value of contingent consideration for business acquisition |  | (1,110) |  |  | — |  |  | (3,509) |  |  | 5,716 |  |
| Restructuring charges (credits), net |  | 1,759 |  |  | — |  |  | 1,770 |  |  | (54) |  |
| Operating income - Non - GAAP |  | $ | 301,980 |  |  | $ | 476,264 |  |  | $ | 747,983 |  |  | $ | 947,105 |  |
| % of net sales - GAAP |  | 16.1 | % |  | 26.9 | % |  | 15.2 | % |  | 23.0 | % |
| % of net sales - Non - GAAP |  | 18.5 | % |  | 28.6 | % |  | 17.6 | % |  | 25.5 | % |
| Net income - GAAP |  | $ | 210,011 |  |  | $ | 382,523 |  |  | $ | 536,308 |  |  | $ | 721,510 |  |
| Share-based compensation expense |  | 24,792 |  |  | 19,814 |  |  | 72,465 |  |  | 64,714 |  |
| Amortization of intangible assets and acquisition-related costs |  | 6,788 |  |  | 8,387 |  |  | 25,014 |  |  | 23,686 |  |
| Impairment of intangible assets |  | 7,000 |  |  | — |  |  | 7,000 |  |  | — |  |
| Change in fair value of contingent consideration for business acquisition |  | (1,110) |  |  | — |  |  | (3,509) |  |  | 5,716 |  |
| Restructuring charges (credits), net |  | 1,759 |  |  | — |  |  | 1,770 |  |  | (54) |  |
| Loss on investments |  | 460 |  |  | 2,173 |  |  | 1,421 |  |  | 4,692 |  |
| Non-GAAP income tax adjustment |  | 13,054 |  |  | 10,165 |  |  | 12,463 |  |  | 31,564 |  |
| Net income - Non - GAAP |  | $ | 262,754 |  |  | $ | 423,062 |  |  | $ | 652,932 |  |  | $ | 851,828 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 1.24 |  |  | $ | 2.22 |  |  | $ | 3.14 |  |  | $ | 4.21 |  |
| Diluted - Non - GAAP |  | $ | 1.55 |  |  | $ | 2.45 |  |  | $ | 3.82 |  |  | $ | 4.97 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non - GAAP |  | 169,707 |  |  | 172,587 |  |  | 171,027 |  |  | 171,378 |  |

[0001032975-22-000003:8k_2_02:42]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
| SHARE-BASED COMPENSATION EXPENSE |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 1,782 |  |  | $ | 1,747 |  |  | $ | 5,253 |  |  | $ | 4,919 |  |
| Marketing and selling |  | 10,699 |  |  | 8,390 |  |  | 28,987 |  |  | 27,559 |  |
| Research and development |  | 4,510 |  |  | 3,482 |  |  | 14,295 |  |  | 10,348 |  |
| General and administrative |  | 7,801 |  |  | 6,195 |  |  | 23,930 |  |  | 21,888 |  |
| Total share-based compensation expense |  | 24,792 |  |  | 19,814 |  |  | 72,465 |  |  | 64,714 |  |
| Income tax benefit |  | (3,581) |  |  | (3,471) |  |  | (23,460) |  |  | (15,540) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 21,211 |  |  | $ | 16,343 |  |  | $ | 49,005 |  |  | $ | 49,174 |  |

[0001032975-22-000003:8k_2_02:43]
*Note: These preliminary results for the three and nine months ended December 31, 2021 are subject to adjustments, including subsequent events that may occur through the date of filing our Quarterly Report on Form 10-Q.

[0001032975-22-000003:8k_2_02:44]
(A) Non-GAAP Financial Measures

[0001032975-22-000003:8k_2_02:45]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-22-000003:8k_2_02:46]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended December 31, 2021 and previous periods, we excluded items in the following general categories, each of which are described below:

[0001032975-22-000003:8k_2_02:47]
Share-based compensation expense. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-22-000003:8k_2_02:48]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit, operating expenses, and financial results from period to period.

[0001032975-22-000003:8k_2_02:49]
Impairment of intangible assets. We may incur impairment of intangible assets expense, primarily in connection with our past business or asset acquisitions. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such expenses are not reflective of our ongoing operating results.

[0001032975-22-000003:8k_2_02:50]
Acquisition-related costs and change in fair value of contingent consideration for business acquisition.  We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition related costs include all incremental expenses incurred to effect a business combination. Fair value of contingent consideration is associated with our estimates of the value of earn-outs in connection with certain acquisitions. We believe that providing the non-GAAP measures excluding these costs and credits, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-22-000003:8k_2_02:51]
Restructuring charges (credits). These expenses are associated with re-aligning our business strategies based on current economic conditions. We have undertaken several restructuring plans in recent years. In connection with our restructuring initiatives, we incurred restructuring charges related to employee terminations, facility closures and early cancellation of certain contracts. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results in the current period.

[0001032975-22-000003:8k_2_02:52]
Loss (gain) on investments. We recognize losses (gains) related to our investments in various companies, which vary depending on the operational and financial performance of the companies in which we invest.  These amounts include our losses (earnings) on equity method investments, investment impairments and losses (gains) resulting from sales or other events related to our investments. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such losses (gains) are not reflective of our ongoing operations.

[0001032975-22-000003:8k_2_02:53]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above and other events; the determination of which is based upon the nature of the underlying items, the mix of income and losses in jurisdictions and the relevant tax rates in which we operate.

[0001032975-22-000003:8k_2_02:54]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-22-000003:8k_2_02:55]
Additional Supplemental Financial Information - Constant Currency

[0001032975-22-000003:8k_2_02:56]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.
