# LOGI 8-K — 0001032975-22-000008 filed 2022-05-03

## item codes, every 8-K on or before 2022-05-18

- 2022-05-03 0001032975-22-000008 — 2.02, 9.01
- 2022-01-25 0001032975-22-000003 — 2.02, 9.01
- 2021-10-26 0001032975-21-000043 — 2.02, 9.01
- 2021-09-10 0001032975-21-000040 — 5.07, 8.01
- 2021-07-27 0001032975-21-000029 — 2.02, 9.01
- 2021-04-29 0001032975-21-000012 — 2.02, 9.01
- 2021-01-19 0001032975-21-000004 — 2.02, 9.01
- 2020-10-20 0001032975-20-000045 — 2.02, 9.01
- 2020-09-11 0001032975-20-000042 — 5.07, 8.01
- 2020-07-21 0001032975-20-000029 — 2.02, 9.01
- 2020-07-01 0001032975-20-000023 — 5.02, 8.01
- 2020-05-12 0001032975-20-000011 — 2.02, 9.01
- 2020-03-30 0001032975-20-000009 — 5.02
- 2020-01-21 0001032975-20-000002 — 2.02, 9.01
- 2019-10-22 0001032975-19-000071 — 9.01
- 2019-09-26 0001032975-19-000068 — 1.01, 7.01, 9.01
- 2019-09-06 0001032975-19-000063 — 5.07, 8.01
- 2019-07-23 0001032975-19-000046 — 2.02, 9.01
- 2019-07-23 0001032975-19-000045 — 5.02, 9.01
- 2019-07-02 0001032975-19-000036 — 5.02
- 2019-06-25 0001032975-19-000034 — 5.02
- 2019-05-03 0001032975-19-000021 — 5.02 — amendment, the index does not say of what
- 2019-04-30 0001032975-19-000017 — 2.02, 5.02, 9.01
- 2019-03-28 0001032975-19-000013 — 5.02
- 2019-01-22 0001032975-19-000004 — 2.02, 9.01
- 2018-10-23 0001032975-18-000044 — 2.02, 9.01
- 2018-09-07 0001032975-18-000040 — 5.07, 8.01
- 2018-07-31 0001032975-18-000035 — 1.01, 2.02, 2.05, 7.01, 9.01
- 2018-06-27 0001032975-18-000020 — 5.02
- 2018-05-03 0001032975-18-000013 — 2.02, 5.02, 9.01
- 2018-01-23 0001032975-18-000005 — 2.02, 9.01
- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2022-05-18

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-22-000008:8k_2_02:1]
EX-99.1
2
exhibit991q4fy22ng.htm
EX-99.1

[0001032975-22-000008:8k_2_02:2]
Document

[0001032975-22-000008:8k_2_02:3]
Exhibit 99.1

[0001032975-22-000008:8k_2_02:4]
Editorial Contacts:

[0001032975-22-000008:8k_2_02:5]
Nate Melihercik, Head of Global Investor Relations - lir@logitech.com

[0001032975-22-000008:8k_2_02:6]
Nicole Kenyon, Head of Global Corporate & Employee Communications - USA +1 (510) 988-8553

[0001032975-22-000008:8k_2_02:7]
Ben Starkie, Corporate Communications - Europe +41 (0) 79-292-3499

[0001032975-22-000008:8k_2_02:8]
Logitech Delivers Record FY 2022 Sales

[0001032975-22-000008:8k_2_02:9]
Company Reports Ninth Consecutive Year of Growth;

[0001032975-22-000008:8k_2_02:10]
Profits Exceed FY22 Outlook

[0001032975-22-000008:8k_2_02:11]
LAUSANNE, Switzerland, May 3, 2022 and NEWARK, Calif., May 2, 2022 —  SIX Swiss Exchange Ad hoc announcement pursuant to Art. 53 LR — Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the fourth quarter and full Fiscal Year 2022, ended March 31, 2022.

[0001032975-22-000008:8k_2_02:12]
For Fiscal Year 2022:

[0001032975-22-000008:8k_2_02:13]
•Sales were Logitech’s highest ever at $5.48 billion, up 4 percent in US dollars and 4 percent in constant currency compared to the prior year. This growth is on top of last year’s record sales which grew 76 percent in US dollars and 74 percent in constant currency. The Company’s sales have more than doubled in the past four years.

[0001032975-22-000008:8k_2_02:14]
•GAAP operating income declined 33 percent to $774 million, compared to $1.15 billion a year ago. Non-GAAP operating income declined 29 percent to $904 million, compared to $1.27 billion a year ago. This reflects the Company’s planned, strategic investments in marketing and product development to drive future growth, and significantly exceeds its original Fiscal Year 2022      non-GAAP operating income outlook. The Company has more than doubled its non-GAAP operating income versus two years ago.

[0001032975-22-000008:8k_2_02:15]
•GAAP earnings per share (EPS) declined 31 percent to $3.78, compared to $5.51 a year ago. Non-GAAP EPS declined 28 percent to $4.63, compared to $6.42 a year ago.

[0001032975-22-000008:8k_2_02:16]
For Q4 Fiscal Year 2022:

[0001032975-22-000008:8k_2_02:17]
•Sales were $1.23 billion, down 20 percent in US dollars and 17 percent in constant currency compared to Q4 of the prior year.

[0001032975-22-000008:8k_2_02:18]
•GAAP operating income declined 56 percent to $129 million, compared to Q4 of the prior year. Non-GAAP operating income declined 52 percent to $156 million, compared to Q4 of the prior year.

[0001032975-22-000008:8k_2_02:19]
“This year, we sustained our scale, delivering record sales on top of last year’s 74% sales growth,” said Bracken Darrell, Logitech president and chief executive officer. “We grew for the ninth straight year and grew market share across the portfolio. We also beat our original profit target by over $100 million.

[0001032975-22-000008:8k_2_02:20]
Despite strong year-over-year results, our focus is the long term. We’re riding secular growth trends in hybrid work, video collaboration, esports and digital content creation. We’ll continue to deliver against those with agility, operational excellence and a diverse, innovative portfolio. I’m excited for the future.”

[0001032975-22-000008:8k_2_02:21]
Outlook

[0001032975-22-000008:8k_2_02:22]
Logitech reduced its Fiscal Year 2023 outlook, removing the estimate of annual sales and profits that would have been generated in Ukraine and Russia. This reflects the current, uncertain environment in which the war in Ukraine continues without sign of resolution in the near term.

[0001032975-22-000008:8k_2_02:23]
Sales growth in constant currency is now expected to be between 2 and 4 percent, and non-GAAP operating income is expected to be between $875 million and $925 million. Previously, sales growth in constant currency was expected to be in the mid single digits, and non-GAAP operating income was expected to be between $900 million and $950 million.

[0001032975-22-000008:8k_2_02:24]
Prepared Remarks Available Online

[0001032975-22-000008:8k_2_02:25]
Logitech has made its prepared written remarks for the financial results videoconference available online on the Logitech corporate website at http://ir.logitech.com.

[0001032975-22-000008:8k_2_02:26]
Financial Results Videoconference and Webcast

[0001032975-22-000008:8k_2_02:27]
Logitech will hold a financial results videoconference to discuss the results for Q4 and the full Fiscal Year 2022 on Tuesday, May 3, 2022 at 8:30 a.m. Eastern Daylight Time and 2:30 p.m. Central European Summer Time. A livestream of the event will be available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-22-000008:8k_2_02:28]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-22-000008:8k_2_02:29]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of intangible assets, impairment of intangible assets, acquisition-related costs, change in fair value of contingent consideration for business acquisition, restructuring charges (credits), loss (gain) on investments, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below. Logitech also presents percentage sales growth in constant currency, a non-GAAP measure, to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for the Fiscal Year 2023 outlook.

[0001032975-22-000008:8k_2_02:30]
About Logitech

[0001032975-22-000008:8k_2_02:31]
Logitech helps all people pursue their passions by designing experiences so everyone can create, achieve, and enjoy more. Logitech designs and creates products that bring people together through computing, gaming, video, streaming and creating, and music. Brands of Logitech include Logitech, Logitech G, ASTRO Gaming, Streamlabs, Blue Microphones and Ultimate Ears. Founded in 1981, and headquartered in Lausanne, Switzerland, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @Logitech.

[0001032975-22-000008:8k_2_02:32]
# # #

[0001032975-22-000008:8k_2_02:33]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-22-000008:8k_2_02:34]
Logitech and other Logitech marks are trademarks or registered trademarks of Logitech Europe S.A. and/or its affiliates in the U.S. and other countries. All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-22-000008:8k_2_02:35]
(LOGIIR)

[0001032975-22-000008:8k_2_02:36]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net sales |  | $ | 1,229,994 |  |  | $ | 1,535,925 |  |  | $ | 5,481,101 |  |  | $ | 5,252,279 |  |
| Cost of goods sold |  | 733,092 |  |  | 821,127 |  |  | 3,204,072 |  |  | 2,903,215 |  |
| Amortization of intangible assets |  | 2,995 |  |  | 3,529 |  |  | 14,023 |  |  | 13,329 |  |
| Gross profit |  | 493,907 |  |  | 711,269 |  |  | 2,263,006 |  |  | 2,335,735 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 247,017 |  |  | 273,764 |  |  | 1,025,899 |  |  | 770,284 |  |
| Research and development |  | 78,408 |  |  | 69,009 |  |  | 291,844 |  |  | 226,023 |  |
| General and administrative |  | 36,357 |  |  | 68,236 |  |  | 148,648 |  |  | 166,577 |  |
| Amortization of intangible assets and acquisition-related costs |  | 2,961 |  |  | 5,178 |  |  | 16,947 |  |  | 19,064 |  |
| Impairment of intangible assets |  | — |  |  | — |  |  | 7,000 |  |  | — |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | — |  |  | (3,509) |  |  | 5,716 |  |
| Restructuring charges (credits), net |  | 395 |  |  | — |  |  | 2,165 |  |  | (54) |  |
| Total operating expenses |  | 365,138 |  |  | 416,187 |  |  | 1,488,994 |  |  | 1,187,610 |  |
| Operating income |  | 128,769 |  |  | 295,082 |  |  | 774,012 |  |  | 1,148,125 |  |
| Interest income |  | 451 |  |  | 340 |  |  | 1,246 |  |  | 1,784 |  |
| Other income (expense), net |  | 2,501 |  |  | (11,450) |  |  | 560 |  |  | (1,789) |  |
| Income before income taxes |  | 131,721 |  |  | 283,972 |  |  | 775,818 |  |  | 1,148,120 |  |
| Provision for income taxes |  | 23,516 |  |  | 58,225 |  |  | 131,305 |  |  | 200,863 |  |
| Net income |  | $ | 108,205 |  |  | $ | 225,747 |  |  | $ | 644,513 |  |  | $ | 947,257 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.65 |  |  | $ | 1.34 |  |  | $ | 3.85 |  |  | $ | 5.62 |  |
| Diluted |  | $ | 0.64 |  |  | $ | 1.31 |  |  | $ | 3.78 |  |  | $ | 5.51 |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | 165,898 |  |  | 168,734 |  |  | 167,447 |  |  | 168,523 |  |
| Diluted |  | 168,546 |  |  | 172,954 |  |  | 170,414 |  |  | 171,775 |  |

[0001032975-22-000008:8k_2_02:37]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | March 31, |  | March 31, |  |  |  |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  | 2022 |  | 2021 |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,328,716 |  |  | $ | 1,750,327 |  |  |  |  |  |
| Accounts receivable, net |  | 675,604 |  |  | 612,225 |  |  |  |  |  |
| Inventories |  | 933,124 |  |  | 661,116 |  |  |  |  |  |
| Other current assets |  | 135,478 |  |  | 135,650 |  |  |  |  |  |
| Total current assets |  | 3,072,922 |  |  | 3,159,318 |  |  |  |  |  |
| Non-current assets: |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 109,807 |  |  | 114,060 |  |  |  |  |  |
| Goodwill |  | 448,175 |  |  | 429,604 |  |  |  |  |  |
| Other intangible assets, net |  | 83,779 |  |  | 115,148 |  |  |  |  |  |
| Other assets |  | 320,722 |  |  | 324,248 |  |  |  |  |  |
| Total assets |  | $ | 4,035,405 |  |  | $ | 4,142,378 |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 636,306 |  |  | $ | 823,233 |  |  |  |  |  |
| Accrued and other current liabilities |  | 784,848 |  |  | 858,617 |  |  |  |  |  |
| Total current liabilities |  | 1,421,154 |  |  | 1,681,850 |  |  |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Income taxes payable |  | 83,380 |  |  | 59,237 |  |  |  |  |  |
| Other non-current liabilities |  | 132,133 |  |  | 139,502 |  |  |  |  |  |
| Total liabilities |  | 1,636,667 |  |  | 1,880,589 |  |  |  |  |  |
| Shareholders' equity: |  |  |  |  |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |  |  |  |  |
| Issued shares —173,106 at March 31, 2022 and 2021 |  |  |  |  |  |  |  |  |
| Additional shares that may be issued out of conditional capitals — 50,000 at March 31, 2022 and 2021 |  |  |  |  |  |  |  |  |
| Additional shares that may be issued out of authorized capital — 17,311 at March 31, 2022 and 2021 |  |  |  |  |  |  |  |  |
| Additional paid-in capital |  | 129,925 |  |  | 129,519 |  |  |  |  |  |
| Shares in treasury, at cost — 7,855 and 4,799 shares at March 31, 2022 and 2021, respectively |  | (632,893) |  |  | (279,541) |  |  |  |  |  |
| Retained earnings |  | 2,975,681 |  |  | 2,490,578 |  |  |  |  |  |
| Accumulated other comprehensive loss |  | (104,123) |  |  | (108,915) |  |  |  |  |  |
| Total shareholders' equity |  | 2,398,738 |  |  | 2,261,789 |  |  |  |  |  |
| Total liabilities and shareholders' equity |  | $ | 4,035,405 |  |  | $ | 4,142,378 |  |  |  |  |  |

[0001032975-22-000008:8k_2_02:38]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 108,205 |  |  | $ | 225,747 |  |  | $ | 644,513 |  |  | $ | 947,257 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  | 22,974 |  |  | 14,742 |  |  | 88,361 |  |  | 50,752 |  |
| Amortization of intangible assets |  | 5,956 |  |  | 8,191 |  |  | 30,179 |  |  | 31,818 |  |
| Impairment of intangible assets |  | — |  |  | — |  |  | 7,000 |  |  | — |  |
| Investment impairment |  | — |  |  | 2,011 |  |  | — |  |  | 2,011 |  |
| Loss (gain) on investments |  | 262 |  |  | (793) |  |  | 1,683 |  |  | 3,899 |  |
| Share-based compensation expense |  | 21,014 |  |  | 21,305 |  |  | 93,479 |  |  | 86,019 |  |
| Deferred income taxes |  | (35) |  |  | (3,199) |  |  | 27,334 |  |  | 34,484 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | — |  |  | (3,509) |  |  | 5,716 |  |
| Other |  | 72 |  |  | (114) |  |  | 1,140 |  |  | (1,784) |  |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | 164,848 |  |  | 275,584 |  |  | (71,510) |  |  | (201,220) |  |
| Inventories |  | (98,812) |  |  | (188,123) |  |  | (276,640) |  |  | (427,501) |  |
| Other assets |  | 2,400 |  |  | (14,427) |  |  | (18,169) |  |  | (67,708) |  |
| Accounts payable |  | (100,666) |  |  | 12,936 |  |  | (181,303) |  |  | 553,960 |  |
| Accrued and other liabilities |  | (26,628) |  |  | 176,359 |  |  | (44,240) |  |  | 440,935 |  |
| Net cash provided by operating activities |  | 99,590 |  |  | 530,219 |  |  | 298,318 |  |  | 1,458,638 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (25,426) |  |  | (30,026) |  |  | (89,152) |  |  | (76,189) |  |
| Investment in privately held companies |  | (203) |  |  | (590) |  |  | (1,463) |  |  | (4,115) |  |
| Acquisitions, net of cash acquired |  | (350) |  |  | (43,163) |  |  | (16,236) |  |  | (43,523) |  |
| Proceeds from return of strategic investments |  | — |  |  | — |  |  | — |  |  | 2,934 |  |
| Purchases of short-term investments |  | — |  |  | — |  |  | (10,000) |  |  | — |  |
| Proceeds from the sale of short-term investments |  | 7,035 |  |  | — |  |  | 8,260 |  |  | — |  |
| Purchases of deferred compensation investments |  | (1,414) |  |  | (1,664) |  |  | (5,058) |  |  | (12,336) |  |
| Proceeds from sales of deferred compensation investments |  | 1,501 |  |  | 1,915 |  |  | 5,786 |  |  | 13,247 |  |
| Net cash used in investing activities |  | (18,857) |  |  | (73,528) |  |  | (107,863) |  |  | (119,982) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | — |  |  | — |  |  | (159,410) |  |  | (146,705) |  |
| Payment of contingent consideration for business acquisition |  | — |  |  | — |  |  | (880) |  |  | — |  |
| Purchases of registered shares |  | (121,397) |  |  | (92,227) |  |  | (412,022) |  |  | (164,952) |  |
| Proceeds from exercises of stock options and purchase rights |  | 13,005 |  |  | 14,101 |  |  | 29,649 |  |  | 43,810 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (5,628) |  |  | (2,607) |  |  | (64,156) |  |  | (32,082) |  |
| Net cash used in financing activities |  | (114,020) |  |  | (80,733) |  |  | (606,819) |  |  | (299,929) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (2,408) |  |  | (14,374) |  |  | (5,247) |  |  | (3,966) |  |
| Net increase (decrease) in cash and cash equivalents |  | (35,695) |  |  | 361,584 |  |  | (421,611) |  |  | 1,034,761 |  |
| Cash and cash equivalents at beginning of the period |  | 1,364,411 |  |  | 1,388,743 |  |  | 1,750,327 |  |  | 715,566 |  |
| Cash and cash equivalents at end of the period |  | $ | 1,328,716 |  |  | $ | 1,750,327 |  |  | $ | 1,328,716 |  |  | $ | 1,750,327 |  |

[0001032975-22-000008:8k_2_02:39]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| NET SALES |  | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Net sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Pointing Devices |  | $ | 178,126 |  |  | $ | 177,679 |  |  | — | % |  | $ | 781,108 |  |  | $ | 680,907 |  |  | 15 | % |
| Keyboards & Combos |  | 231,064 |  |  | 219,242 |  |  | 5 |  |  | 967,301 |  |  | 784,488 |  |  | 23 |  |
| PC Webcams |  | 84,147 |  |  | 144,845 |  |  | (42) |  |  | 403,651 |  |  | 439,865 |  |  | (8) |  |
| Tablet & Other Accessories |  | 67,191 |  |  | 117,115 |  |  | (43) |  |  | 310,123 |  |  | 384,301 |  |  | (19) |  |
| Gaming (1) |  | 316,427 |  |  | 322,965 |  |  | (2) |  |  | 1,451,883 |  |  | 1,239,005 |  |  | 17 |  |
| Video Collaboration |  | 243,439 |  |  | 385,657 |  |  | (37) |  |  | 997,164 |  |  | 1,044,935 |  |  | (5) |  |
| Mobile Speakers |  | 25,058 |  |  | 29,739 |  |  | (16) |  |  | 149,782 |  |  | 174,895 |  |  | (14) |  |
| Audio & Wearables |  | 82,459 |  |  | 130,184 |  |  | (37) |  |  | 401,424 |  |  | 468,776 |  |  | (14) |  |
| Smart Home |  | 2,083 |  |  | 8,418 |  |  | (75) |  |  | 18,463 |  |  | 34,394 |  |  | (46) |  |
| Other (2) |  | — |  |  | 81 |  |  | (100) |  |  | 202 |  |  | 713 |  |  | (72) |  |
| Total net retail sales |  | $ | 1,229,994 |  |  | $ | 1,535,925 |  |  | (20) | % |  | $ | 5,481,101 |  |  | $ | 5,252,279 |  |  | 4 | % |
| __________________ |  |  |  |  |  |  |  |  |  |  |  |  |

[0001032975-22-000008:8k_2_02:40]
(1) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-22-000008:8k_2_02:41]
(2) Other includes products that the Company currently intends to phase out, or has already phased out, because they are no longer strategic to the Company's business.

[0001032975-22-000008:8k_2_02:42]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| GAAP TO NON GAAP RECONCILIATION (A) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Gross profit - GAAP |  | $ | 493,907 |  |  | $ | 711,269 |  |  | $ | 2,263,006 |  |  | $ | 2,335,735 |  |
| Share-based compensation expense |  | 1,442 |  |  | 1,519 |  |  | 6,695 |  |  | 6,438 |  |
| Amortization of intangible assets |  | 2,995 |  |  | 3,529 |  |  | 14,023 |  |  | 13,329 |  |
| Gross profit - Non-GAAP |  | $ | 498,344 |  |  | $ | 716,317 |  |  | $ | 2,283,724 |  |  | $ | 2,355,502 |  |
| Gross margin - GAAP |  | 40.2 | % |  | 46.3 | % |  | 41.3 | % |  | 44.5 | % |
| Gross margin - Non-GAAP |  | 40.5 | % |  | 46.6 | % |  | 41.7 | % |  | 44.8 | % |
| Operating expenses - GAAP |  | $ | 365,138 |  |  | $ | 416,187 |  |  | $ | 1,488,994 |  |  | $ | 1,187,610 |  |
| Less: Share-based compensation expense |  | 19,572 |  |  | 19,786 |  |  | 86,784 |  |  | 79,581 |  |
| Less: Amortization of intangible assets and acquisition-related costs |  | 2,961 |  |  | 5,178 |  |  | 16,947 |  |  | 19,064 |  |
| Less: Impairment of intangible assets |  | — |  |  | — |  |  | 7,000 |  |  | — |  |
| Less: Change in fair value of contingent consideration for business acquisition |  | — |  |  | — |  |  | (3,509) |  |  | 5,716 |  |
| Less: Restructuring charges (credits), net |  | 395 |  |  | — |  |  | 2,165 |  |  | (54) |  |
| Operating expenses - Non-GAAP |  | $ | 342,210 |  |  | $ | 391,223 |  |  | $ | 1,379,607 |  |  | $ | 1,083,303 |  |
| % of net sales - GAAP |  | 29.7 | % |  | 27.1 | % |  | 27.2 | % |  | 22.6 | % |
| % of net sales - Non - GAAP |  | 27.8 | % |  | 25.5 | % |  | 25.2 | % |  | 20.6 | % |
| Operating income - GAAP |  | $ | 128,769 |  |  | $ | 295,082 |  |  | $ | 774,012 |  |  | $ | 1,148,125 |  |
| Share-based compensation expense |  | 21,014 |  |  | 21,305 |  |  | 93,479 |  |  | 86,019 |  |
| Amortization of intangible assets and acquisition-related costs |  | 5,956 |  |  | 8,707 |  |  | 30,970 |  |  | 32,393 |  |
| Impairment of intangible assets |  | — |  |  | — |  |  | 7,000 |  |  | — |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | — |  |  | (3,509) |  |  | 5,716 |  |
| Restructuring charges (credits), net |  | 395 |  |  | — |  |  | 2,165 |  |  | (54) |  |
| Operating income - Non - GAAP |  | $ | 156,134 |  |  | $ | 325,094 |  |  | $ | 904,117 |  |  | $ | 1,272,199 |  |
| % of net sales - GAAP |  | 10.5 | % |  | 19.2 | % |  | 14.1 | % |  | 21.9 | % |
| % of net sales - Non - GAAP |  | 12.7 | % |  | 21.2 | % |  | 16.5 | % |  | 24.2 | % |
| Net income - GAAP |  | $ | 108,205 |  |  | $ | 225,747 |  |  | $ | 644,513 |  |  | $ | 947,257 |  |
| Share-based compensation expense |  | 21,014 |  |  | 21,305 |  |  | 93,479 |  |  | 86,019 |  |
| Amortization of intangible assets and acquisition-related costs |  | 5,956 |  |  | 8,707 |  |  | 30,970 |  |  | 32,393 |  |
| Impairment of intangible assets |  | — |  |  | — |  |  | 7,000 |  |  | — |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | — |  |  | (3,509) |  |  | 5,716 |  |
| Restructuring charges (credits), net |  | 395 |  |  | — |  |  | 2,165 |  |  | (54) |  |
| Loss on investments |  | 262 |  |  | 1,218 |  |  | 1,683 |  |  | 5,910 |  |
| Non-GAAP income tax adjustment |  | (99) |  |  | (5,776) |  |  | 12,364 |  |  | 25,788 |  |
| Net income - Non - GAAP |  | $ | 135,733 |  |  | $ | 251,201 |  |  | $ | 788,665 |  |  | $ | 1,103,029 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.64 |  |  | $ | 1.31 |  |  | $ | 3.78 |  |  | $ | 5.51 |  |
| Diluted - Non - GAAP |  | $ | 0.81 |  |  | $ | 1.45 |  |  | $ | 4.63 |  |  | $ | 6.42 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non - GAAP |  | 168,546 |  |  | 172,954 |  |  | 170,414 |  |  | 171,775 |  |

[0001032975-22-000008:8k_2_02:43]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| SHARE-BASED COMPENSATION EXPENSE |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 1,442 |  |  | $ | 1,519 |  |  | $ | 6,695 |  |  | $ | 6,438 |  |
| Marketing and selling |  | 8,809 |  |  | 9,229 |  |  | 37,796 |  |  | 36,788 |  |
| Research and development |  | 4,061 |  |  | 3,831 |  |  | 18,356 |  |  | 14,179 |  |
| General and administrative |  | 6,702 |  |  | 6,726 |  |  | 30,632 |  |  | 28,614 |  |
| Total share-based compensation expense |  | 21,014 |  |  | 21,305 |  |  | 93,479 |  |  | 86,019 |  |
| Income tax benefit |  | (3,527) |  |  | (3,932) |  |  | (26,987) |  |  | (19,472) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 17,487 |  |  | $ | 17,373 |  |  | $ | 66,492 |  |  | $ | 66,547 |  |

[0001032975-22-000008:8k_2_02:44]
*Note: These preliminary results for the three months and fiscal year ended March 31, 2022 are subject to adjustments, including subsequent events that may occur through the date of filing our Annual Report on Form 10-K.

[0001032975-22-000008:8k_2_02:45]
(A) Non-GAAP Financial Measures

[0001032975-22-000008:8k_2_02:46]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-22-000008:8k_2_02:47]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter and fiscal year ended March 31, 2022 and previous periods, we excluded items in the following general categories, each of which are described below:

[0001032975-22-000008:8k_2_02:48]
Share-based compensation expense. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-22-000008:8k_2_02:49]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit, operating expenses, and financial results from period to period.

[0001032975-22-000008:8k_2_02:50]
Impairment of intangible assets. We may incur impairment of intangible assets expense, primarily in connection with our past business or asset acquisitions. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such expenses are not reflective of our ongoing operating results.

[0001032975-22-000008:8k_2_02:51]
Acquisition-related costs and change in fair value of contingent consideration for business acquisition.  We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition related costs include all incremental expenses incurred to effect a business combination. Fair value of contingent consideration is associated with our estimates of the value of earn-outs in connection with certain acquisitions. We believe that providing the non-GAAP measures excluding these costs and credits, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-22-000008:8k_2_02:52]
Restructuring charges (credits). These expenses are associated with re-aligning our business strategies based on current economic conditions. We have undertaken several restructuring plans in recent years. In connection with our restructuring initiatives, we incurred restructuring charges related to employee terminations, facility closures and early cancellation of certain contracts. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results in the current period.

[0001032975-22-000008:8k_2_02:53]
Loss (gain) on investments. We recognize losses (gains) related to our investments in various companies, which vary depending on the operational and financial performance of the companies in which we invest.  These amounts include our losses (earnings) on equity method investments, investment impairments and losses (gains) resulting from sales or other events related to our investments. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such losses (gains) are not reflective of our ongoing operations.

[0001032975-22-000008:8k_2_02:54]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above and other events; the determination of which is based upon the nature of the underlying items, the mix of income and losses in jurisdictions and the relevant tax rates in which we operate.

[0001032975-22-000008:8k_2_02:55]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-22-000008:8k_2_02:56]
Additional Supplemental Financial Information - Constant Currency

[0001032975-22-000008:8k_2_02:57]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.
