# LOGI MD&A — 0001032975-22-000012


## mdna

[0001032975-22-000012:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001032975-22-000012:mdna:2]
Overview of Our Company

[0001032975-22-000012:mdna:3]
Logitech is a world leader in designing, manufacturing and marketing products that help connect people to digital and cloud experiences. Forty years ago, Logitech created products to improve experiences around the personal computer ("PC") platform, and today it is a multi-brand, multi-category company designing products that enable people to pursue their passions and connect to the world. Logitech’s products align with several large secular trends including work and learn from anywhere, video everywhere, the increasing popularity of gaming as a spectator and participant sport, and the democratization of content creation. Logitech's brands include Logitech, Logitech G, ASTRO Gaming, Streamlabs, Blue Microphones, and Ultimate Ears. Our Company's website is www.logitech.com.

[0001032975-22-000012:mdna:4]
Our products participate primarily in four large market opportunities: Creativity & Productivity, Gaming, Video Collaboration and Music. We sell our products to a broad network of domestic and international customers, including direct sales to retailers, e-tailers and enterprise customers, and indirect sales through distributors. Our worldwide channel network includes consumer electronics distributors, retailers, e-tailers, mass merchandisers, specialty stores, computer and telecommunications stores, value-added resellers and online merchants. We primarily sell our services directly to end customers.

[0001032975-22-000012:mdna:5]
From time to time, we may seek to partner with or acquire, when appropriate, companies that have products, personnel, and technologies that complement our strategic direction. For example, in February 2021, we acquired Mevo Inc. ("Mevo") to complement our PC webcams portfolio and enable us to offer end-to-end solution for streaming and content creation, and in October 2019, we acquired General Workings, Inc. ("Streamlabs") to complement our Gaming portfolio (see Note 3 to the consolidated financial statements). We continually review our product offerings and our strategic direction in light of our profitability targets, competitive conditions, changing consumer trends and the evolving nature of the interface between the consumer and the digital world.

[0001032975-22-000012:mdna:6]
Impacts of COVID-19 to Our Business

[0001032975-22-000012:mdna:7]
In March 2020, the World Health Organization declared the outbreak of COVID-19 as a pandemic, which continues to spread throughout the world. The spread of COVID-19 has caused public health officials to recommend precautions to mitigate the spread of the virus and, in certain markets in which we operate, government authorities have from time to time issued orders that require the closure of or restrictions on non-essential businesses and people to be quarantined or to shelter-at-home. The ongoing COVID-19 pandemic has curtailed global economic activity, caused volatility and disruption in global financial and commercial markets, and is likely to continue to cause uncertainty for an indeterminate amount of time. While most of our offices have at least partially reopened or will be reopening in the near future, we are conducting our business with substantial modifications, such as employee remote work in many non-manufacturing facilities and travel limitations, among other changes. We are continuing to actively monitor the situation and may take further actions that alter our business operations as may be required by federal, state or local authorities in the countries in which we operate, or that we determine are in the best interest of our employees, customers, partners, suppliers or shareholders.

[0001032975-22-000012:mdna:8]
Since the outbreak of COVID-19 in early 2020 we experienced disruptions to our supply chain and logistics, inventory constraints, and increased logistics costs, as we attempted to address the effects of the COVID-19 pandemic. At the same time, due to the shelter-at-home requirements or other restrictions in many countries, there was an acceleration of work-from-anywhere, learn-from-anywhere, gaming, video collaboration and streaming trends and high demand and consumption of certain of our products that led to increased sales and operating income. While we continued to experience increased sales in fiscal year 2022 compared to fiscal year 2021, we also experienced supply and demand volatility, as the COVID-19 pandemic and related safety measures and restrictions have evolved differently across the world. Further, the demand volatility has led to, and could continue to lead to in the future, higher promotions and marketing expenses, or excess inventories, or both, which could have an adverse impact on our results of operations.

[0001032975-22-000012:mdna:9]
In addition, the COVID-19 pandemic has resulted in, and could continue to result in, industry-wide global supply chain challenges, including manufacturing, transportation and logistics. We purchase certain products and key components from a limited number of sources, and depend on the supply chain, including freight, to receive components, transport finished goods and deliver our products across the world. While we proactively manage our supply chain, we expect to continue to be impacted by higher logistics and component costs, prolonged delays, and challenges with component availability.  Most recently, Shanghai, China, began a lockdown in late March 2022 due to another outbreak of COVID-19, resulting in a lockdown of the city, closures of ports and airports, and disruption of commercial activities, further constraining our supply chain. If the Shanghai lockdown is extended, including to our Suzhou manufacturing facility, and to other places where our suppliers and partners are located, such measures, depending on their duration, could cause additional negative impact on our business and results of operations.

[0001032975-22-000012:mdna:10]
It is still difficult to predict the progression, the duration and all of the effects of COVID-19, how business restrictions and shelter-at-home guidelines will continue evolving on a global basis, how consumer demand, supply chain challenges, including inventory and logistical effects and costs, may change over time, and the impact on our future sales and results of operations. The full extent of the impact of the COVID-19 pandemic on our business and our operational and financial performance remains uncertain and will depend on many factors outside our control. For additional information, see "Liquidity and Capital Resources" below and Item 1A "Risk Factors," including under the caption "The full effect of the COVID-19 pandemic is still uncertain and cannot be predicted, and could adversely affect our business, results of operations and financial condition.", "If we do not successfully coordinate the worldwide manufacturing and distribution of our products, we could lose sales” and “We purchase key components and products from a limited number of sources, and our business and operating results could be adversely affected if supply were delayed or constrained or if there were shortages of required components.”

[0001032975-22-000012:mdna:11]
Impacts of Macroeconomic and Geopolitical Conditions on our Business

[0001032975-22-000012:mdna:12]
Adverse macroeconomic conditions, including but not limited to inflation, slower growth or recession, new or increased tariffs, changes to fiscal and monetary policy, higher interest rates and currency fluctuations could adversely affect demand for our products. In addition, in February 2022, Russia invaded Ukraine resulting in, among other things, broad economic sanctions being imposed on Russia, which has further increased existing global supply chain, logistics, and inflationary challenges. Such global or regional economic and political conditions may also have a significant impact on our suppliers, contract manufacturers, logistics providers, and distributors, causing increases in cost of materials. Furthermore, these conditions may lead to price increases in certain of our product markets. Price increases may not successfully offset cost increases or may cause us to lose market share and in turn adversely impact our operations.

[0001032975-22-000012:mdna:13]
In the fourth quarter of fiscal year 2022, we indefinitely ceased all sales and shipments to Russia. Our sales in Ukraine have also been halted due to the ongoing military operations on the Ukrainian territory. Our business in Russia and Ukraine were not material to our results and accounted for approximately 2% of total revenue for fiscal year 2022.

[0001032975-22-000012:mdna:14]
For additional information, see item 1A "Risk Factors," including under the caption “We purchase key components and products from a limited number of sources, and our business and operating results could be adversely affected if supply were delayed or constrained or if there were shortages of required components,” “Our principal manufacturing operations and third-party contract manufacturers are located in China and Southeast Asia, which exposes us to risks associated with doing business in that geographic area as well as potential tariffs, adverse tax consequences and pressure to move or diversify our manufacturing locations” and “If we do not accurately forecast market demand for our products, our business and operating results could be adversely affected.”

[0001032975-22-000012:mdna:15]
Summary of Financial Results

[0001032975-22-000012:mdna:16]
Our total sales for fiscal year 2022 increased 4% compared to fiscal year 2021, primarily driven by growth in sales in Gaming, Keyboards & Combos, and Pointing Devices, partially offset by a decline in sales of Tablet & Other Accessories, Audio & Wearables, and Video Collaboration.

[0001032975-22-000012:mdna:17]
Sales for fiscal year 2022 increased 5% and 10% in the Americas and Asia Pacific, respectively, and declined 1% in EMEA, compared to fiscal year 2021.

[0001032975-22-000012:mdna:18]
Gross margin for fiscal year 2022 decreased by 320 basis points to 41.3%, compared to fiscal year 2021, due to increased promotional spending, higher reserves for excess inventories, and higher material and logistic costs, partially offset by favorable impacts from product mix and changes in currency exchange rates.

[0001032975-22-000012:mdna:19]
Operating expenses for fiscal year 2022 were $1,489.0 million, or 27.2% of sales, compared to $1,187.6 million, or 22.6% of sales, for fiscal year 2021. The increase in operating expenses was primarily driven by $195.6 million higher third-party costs to support our long-term growth opportunities and branding development as well as $124.6 million higher personnel-related costs due to additional headcount across departments to support business growth. These increases were partially offset by a $30 million contribution into a charitable donor advised fund in fiscal year 2021 to support our social giving strategies.

[0001032975-22-000012:mdna:20]
Included in the income tax provision of $131.3 million and $200.9 million in fiscal year 2022 and 2021 was $88.7 million and $152.6 million, respectively, of tax expense from Switzerland that reflects the post enactment of the Tax Reform and AHV Financing (“TRAF") by the canton of Vaud. TRAF was enacted in the fourth quarter of fiscal year 2020 and took effect as of January 1, 2020.

[0001032975-22-000012:mdna:21]
Net income for fiscal year 2022 was $644.5 million, compared to $947.3 million for fiscal year 2021.

[0001032975-22-000012:mdna:22]
Trends in Our Business

[0001032975-22-000012:mdna:23]
Our products participate primarily in four large multi-category market opportunities, including Creativity & Productivity, Gaming, Video Collaboration and Music. The following discussion represents key trends specific to our market opportunities.

[0001032975-22-000012:mdna:24]
Trends Specific to Our Market Opportunities

[0001032975-22-000012:mdna:25]
Creativity & Productivity:  In the past few years, new PC shipments were strong due to work-from-home and learn-from-home trends. We believe that innovative PC peripherals, such as our mice and keyboards, can renew the PC usage experience and help improve the productivity and engagement of remote work and learning, thus providing growth opportunities. Hybrid work culture will also greatly expand the number of new workspaces to which we can attach our PC peripherals. Increasing adoption of various cloud-based applications has led to multiple unique consumer use cases, which we are addressing with our innovative product portfolio and a deep understanding of our customer base. The popularity of streaming coupled with work-from-home trends, provide growth opportunities for our webcam products as well as other products in our portfolio. Smaller mobile computing devices, such as tablets, have created new markets and usage models for peripherals and accessories. We offer a number of products to enhance the use of mobile devices, including a combo backlit keyboard case with trackpad for the iPad.

[0001032975-22-000012:mdna:26]
Gaming: The PC gaming and console gaming platforms continue to show strong structural growth opportunities as online gaming, multi-platform experiences, and esports gain greater popularity and gaming becomes more social. We expect gaming will increasingly become one of the largest participant and spectator sports in the world. We believe Logitech is well positioned to benefit from the overall gaming market growth. In addition, our acquisition of Streamlabs provides a solid platform to deliver recurring services and subscriptions to gamers and streamers.

[0001032975-22-000012:mdna:27]
Video Collaboration: The near and long-term structural growth opportunities in the video collaboration market continue to be strong as commercial and consumer adoption of video has seen substantial growth since the start of the COVID-19 pandemic. Video meetings continue to be an opportunity as companies want lower-cost, cloud-based solutions that can provide their employees with the ability to work from anywhere. We are continuing our efforts to create and sell innovative products to accommodate the increasing demand from home offices and small-size meeting rooms, such as huddle rooms, to medium and large-sized meeting rooms. We will continue to invest in the development of select business-specific products (both hardware and software), targeted product marketing and sales channel development. The digitization of learning and hybrid learning environments have also created demand and growth opportunities in the education market.

[0001032975-22-000012:mdna:28]
Music: Consumers are optimizing their audio experiences on their tablets and smartphones with a variety of music peripherals including wireless mobile speakers and in-ear and other headphones. However, the mobile speaker market has matured and the integration of personal voice assistants has increased competition in the speaker category. In addition, the retail footprint has decreased significantly due to the COVID-19 pandemic. These factors have led to a decline in our Mobile Speakers category sales in the past three years. In the wireless headphone industry, the largest growth in recent years has been in true wireless headphones while traditional wireless headphones have declined significantly. We will continue developing wireless audio products as growth in the wireless headphone market is expected for the next several years.

[0001032975-22-000012:mdna:29]
Business Seasonality and Product Introductions

[0001032975-22-000012:mdna:30]
We have historically experienced higher sales in our third fiscal quarter ending December 31, compared to other fiscal quarters in our fiscal year, primarily due to the increased consumer demand for our products during the year-end holiday buying season and year-end spending by enterprises. Additionally, new product introductions and business acquisitions can significantly impact sales, product costs and operating expenses. Product introductions can also impact our sales to distribution channels as these channels are filled with new product inventory following a product introduction, and often channel inventory of an earlier model product declines as the next related major product launch approaches. Sales can also be affected when consumers and distributors anticipate a product introduction or changes in business circumstances. However, neither historical seasonal patterns nor historical patterns of product introductions should be considered reliable indicators of our future pattern of product introductions, future sales or financial performance. Furthermore, cash flow is correspondingly lower in the first half of our fiscal year as we typically build inventories in advance for the third quarter and we pay an annual dividend following our Annual General Meeting, which is typically in September.

[0001032975-22-000012:mdna:31]
Swiss Federal Tax Reform

[0001032975-22-000012:mdna:32]
As we described above, the canton of Vaud in Switzerland enacted TRAF on March 10, 2020 that took effect as of January 1, 2020. Our cash tax payments have increased in Switzerland beginning in fiscal year 2020 as a result of our transition out of our longstanding tax ruling from the canton of Vaud.

[0001032975-22-000012:mdna:33]
Capitalization and amortization of research and development expenses in the U.S.

[0001032975-22-000012:mdna:34]
Pursuant to the Tax Cuts and Jobs Act of 2017, research and development expenses are required to be capitalized and amortized over five years for U.S. tax purposes if the research and development activities are performed in the U.S, effective for tax year beginning after December 31, 2021.  Absent a change in legislation, the provision is effective for us beginning in fiscal year 2023 which will delay the deductibility of research and development expenses. Cash tax payments in the U.S. are expected to increase beginning in fiscal year 2023.

[0001032975-22-000012:mdna:35]
Critical Accounting Estimates

[0001032975-22-000012:mdna:36]
The preparation of financial statements and related disclosures in conformity with U.S. GAAP requires us to make judgments, estimates, and assumptions that affect reported amounts of assets, liabilities, sales and expenses, and the disclosure of contingent assets and liabilities.

[0001032975-22-000012:mdna:37]
We consider an accounting estimate critical if it: (i) requires management to make judgments and estimates about matters that are inherently uncertain; and (ii) is important to an understanding of our financial condition and operating results.

[0001032975-22-000012:mdna:38]
We base our estimates on historical experience and various other factors that we believe to be reasonable under the circumstances. Although these estimates are based on management's best knowledge of current events and actions that may impact us in the future, actual results could differ from those estimates. Management has discussed the development, selection and disclosure of these critical accounting estimates with the Audit Committee of the Board of Directors.

[0001032975-22-000012:mdna:39]
We believe the following accounting estimates are most critical to our business operations and to an understanding of our financial condition and results of operations and reflect the more significant judgments and estimates used in the preparation of our consolidated financial statements.

[0001032975-22-000012:mdna:40]
Accruals for Customer Programs and Product Returns

[0001032975-22-000012:mdna:41]
We record accruals for cooperative marketing, customer incentive, pricing programs ("Customer Programs") and product returns. The estimated cost of these programs is usually recorded as a reduction of revenue. Significant management judgments and estimates must be used to determine the cost of these programs in any accounting period. Customer Programs require management to estimate the percentage of those programs that will not be claimed in the current period or will not be earned by customers, which is commonly referred to as "breakage." Breakage is estimated based on historical claim experience, the period in which the claims are expected to be submitted, specific terms and conditions with customers, and other factors. If we receive a separately identifiable benefit from a customer and can reasonably estimate the fair value of that benefit, the cost of the Customer Programs is recognized in operating expenses.

[0001032975-22-000012:mdna:42]
Customer Incentive Programs.    Customer incentive programs include performance-based incentives and consumer rebates. We offer performance-based incentives to our customers and indirect partners based on pre-

[0001032975-22-000012:mdna:43]
determined performance criteria. Consumer rebates are offered from time to time at our discretion for the primary benefit of end-users. Customer incentive programs are considered variable consideration, which we estimate and record as a reduction to revenue at the time of sale based on negotiated terms, historical experiences, forecasted incentives, the anticipated volume of future purchases, and inventory levels in the channel.

[0001032975-22-000012:mdna:44]
Product Returns.    We grant limited rights to return products. Return rights vary by customer and range from just the right to return the defective product to stock rotation rights limited to a percentage of sales approved by management. Estimates of expected future product returns are recognized at the time of sale based on analyses of historical return trends by the customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information. Upon recognition, we reduce sales and cost of goods sold for the estimated return. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time but are sufficiently predictable to allow us to estimate expected future product returns.

[0001032975-22-000012:mdna:45]
We apply a breakage rate to reduce our accruals of Customer Programs based on the estimated percentage of these Customer Programs that will not be claimed or earned. The breakage rate is applied at the time of sale. Assessing the period in which claims are expected to be submitted and the relevance of the historical claim experience require significant management judgment to estimate the breakage of Customer Programs in any accounting period.

[0001032975-22-000012:mdna:46]
We regularly evaluate the adequacy of our accruals for Customer Programs and product returns. Future market conditions and product transitions may require us to take action to increase such programs. In addition, when the variables used to estimate these costs change, or if actual costs differ significantly from the estimates, we would be required to record incremental increases or reductions to revenue or operating expenses.

[0001032975-22-000012:mdna:47]
Inventory Valuation

[0001032975-22-000012:mdna:48]
We must order components for our products and build inventory in advance of customer orders. Further, our industry is characterized by rapid technological change, short-term customer commitments and rapid changes in demand.

[0001032975-22-000012:mdna:49]
We record inventories at the lower of cost and net realizable value and record write-downs of inventories that are obsolete or in excess of anticipated demand or net realizable value. A review of inventory is performed each fiscal quarter that considers factors including the marketability and product lifecycle stage, product development plans, component cost trends, historical sales, and demand forecasts that consider the assumptions about future demand and market conditions. Inventory on hand that is not expected to be sold or utilized is considered excess, and we recognize the write-down in the cost of goods sold at the time of such determination. The write-down is determined by the excess of cost over net realizable value. Net realizable value is the estimated selling price in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. At the time of loss recognition, new cost basis per unit and the lower-cost basis for that inventory are established and subsequent changes in facts and circumstances would not result in an increase in the cost basis. If there is an abrupt and substantial decline in demand for Logitech's products or an unanticipated change in technological or customer requirements, we may be required to record additional write-downs that could adversely affect gross margins in the period when the write-downs are recorded. We also extend the assessment to non-cancelable purchase orders if the inventories are considered excess and record the liability that is reasonably possible to be incurred in accrued and other liabilities.

[0001032975-22-000012:mdna:50]
Accounting for Income Taxes

[0001032975-22-000012:mdna:51]
We operate in multiple jurisdictions and our profits are taxed pursuant to the tax laws of these jurisdictions. Our effective income tax rate may be affected by the changes in or interpretations of tax laws and tax agreements in any given jurisdiction, utilization of net operating loss and tax credit carryforwards, changes in geographical mix of income and expense, and changes in our assessment of matters such as the ability to realize deferred tax assets. As a result of these considerations, we must estimate income taxes in each of the jurisdictions in which we operate. This process involves estimating current tax exposure together with assessing temporary differences resulting from the different treatment of items for tax and accounting purposes. These differences result in deferred tax assets and liabilities, which are included in the consolidated balance sheet.

[0001032975-22-000012:mdna:52]
We assess the likelihood that our deferred tax assets will be recovered from future taxable income, considering all available evidence such as historical levels of income, expectations and risks associated with estimates of future

[0001032975-22-000012:mdna:53]
taxable income and ongoing prudent and feasible tax strategies. When we determine that it is not more likely than not that we will realize all or part of our deferred tax assets, an adjustment is charged to earnings in the period when such determination is made. Likewise, if we later determine that it is more likely than not that all or a part of our deferred tax assets would be realized, the previously provided valuation allowance would be reversed.

[0001032975-22-000012:mdna:54]
We make certain estimates and judgments about the application of tax laws, the expected resolution of uncertain tax positions and other matters surrounding the recognition and measurement of uncertain tax benefits. In the event that uncertain tax positions are resolved for amounts different than our estimates, or the related statutes of limitations expire without the assessment of additional income taxes, we will be required to adjust the amounts of the related assets and liabilities in the period in which such events occur. Such adjustments may have a material impact on our income tax provision and our results of operations.

[0001032975-22-000012:mdna:55]
Business Acquisitions

[0001032975-22-000012:mdna:56]
Accounting for business acquisitions requires us to make significant estimates and assumptions, especially at the acquisition date with respect to tangible and intangible assets acquired and liabilities assumed and pre-acquisition contingencies. We use our best estimates and assumptions to accurately assign fair value to the tangible and intangible assets acquired and liabilities assumed at the acquisition date.

[0001032975-22-000012:mdna:57]
Examples of critical estimates in valuing certain intangible assets and goodwill we have acquired and liabilities we have assumed include but are not limited to:

[0001032975-22-000012:mdna:58]
•assumptions regarding royalty rate range and forecasted revenue growth rate;

[0001032975-22-000012:mdna:59]
•assumptions regarding the estimated useful life of the acquired intangibles;

[0001032975-22-000012:mdna:60]
•discount rates;

[0001032975-22-000012:mdna:61]
•projected risk-based net revenues forecast; and

[0001032975-22-000012:mdna:62]
•asset volatility.

[0001032975-22-000012:mdna:63]
Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results.

[0001032975-22-000012:mdna:64]
The economic useful life of the developed technology from the business acquisitions was determined based on the technology cycle related to developed technology of existing products, as well as the cash flows over the forecasted periods.

[0001032975-22-000012:mdna:65]
The economic useful life of the customer relationships from the business acquisitions was determined based on historical customer turnover rates and the industry benchmarks.

[0001032975-22-000012:mdna:66]
The economic useful life of the trademarks and trade names from the business acquisitions was determined based on the expected life of the trade names and the cash flows anticipated over the forecasted periods.

[0001032975-22-000012:mdna:67]
For additional information about our Critical Accounting Estimates, see Note 2—Summary of Significant Accounting Policies in our Notes to our consolidated financial statements below.

[0001032975-22-000012:mdna:68]
Adoption of New Accounting Pronouncements

[0001032975-22-000012:mdna:69]
Refer to Note 2 to the consolidated financial statements included in this Annual Report on Form 10-K for recent accounting pronouncements adopted and to be adopted.

[0001032975-22-000012:mdna:70]
Constant Currency

[0001032975-22-000012:mdna:71]
We refer to our net sales growth rates excluding the impact of currency exchange rate fluctuations as "constant currency" sales growth rates. Percentage of constant currency sales growth is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.

[0001032975-22-000012:mdna:72]
Given our global sales presence and the reporting of our financial results in U.S. Dollars, our financial results could be affected by significant shifts in currency exchange rates. See “Results of Operations” for information on the effect of currency exchange results on our sales. If the U.S. Dollar appreciates or depreciates in comparison to other currencies in future periods, this will affect our results of operations in future periods as well.

[0001032975-22-000012:mdna:73]
References to Sales

[0001032975-22-000012:mdna:74]
The term “sales” means net sales, except as otherwise specified and the sales growth discussion and sales growth rate percentages are in U.S. Dollars, except as otherwise specified.

[0001032975-22-000012:mdna:75]
Results of Operations

[0001032975-22-000012:mdna:76]
In this section, we discuss the results of our operations for the year ended March 31, 2022 compared to the year ended March 31, 2021.  For a discussion of the year ended March 31, 2021 compared to the year ended March 31, 2020, please refer to Part II, Item 7, "Management's Discussion and Analysis of Financial Condition and Results of Operations" in our Annual Report on Form 10-K filed with the SEC on May 12, 2021.

[0001032975-22-000012:mdna:77]
Net Sales

[0001032975-22-000012:mdna:78]
Our sales in fiscal year 2022 increased 4%, compared to fiscal year 2021. The increase in sales was primarily driven by growth in sales in Gaming, Keyboards & Combos, and Pointing Devices, partially offset by a decline in sales of Tablet & Other Accessories, Audio & Wearables, and Video Collaboration. Our sales growth in fiscal year 2022 was driven by continued demand from hybrid work trends and popularity of esports and social gaming, partially offset by the negative impacts from higher promotions and industry-wide supply chain challenges, including supply availability and logistics delays. If currency exchange rates had been constant in 2022 and 2021, our constant currency sales growth rate would have remained at 4%.

[0001032975-22-000012:mdna:79]
Sales Denominated in Other Currencies

[0001032975-22-000012:mdna:80]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Australian Dollar, Canadian Dollar, Pound Sterling and New Taiwan Dollar. For the years ended March 31, 2022 and 2021, approximately 50% and 52%, respectively, of our sales were denominated in currencies other than the U.S. Dollar.

[0001032975-22-000012:mdna:81]
Sales by Region

[0001032975-22-000012:mdna:82]
The following table presents the change in sales by region for fiscal year 2022 compared with fiscal year 2021:

[0001032975-22-000012:mdna:83]
|  |  | 2022 vs. 2021 |  |  |
|  |  | Sales Growth Rate |  | Sales Growth Rate in Constant Currency |  |  |  |  |
| Americas |  | 5 | % |  | 4 | % |  |  |  |  |
| EMEA |  | (1) |  |  | — |  |  |  |  |  |
| Asia Pacific |  | 10 |  |  | 9 |  |  |  |  |  |

[0001032975-22-000012:mdna:84]
Americas:

[0001032975-22-000012:mdna:85]
The increase in sales in the Americas region for fiscal year 2022, compared to fiscal year 2021, was primarily driven by growth in sales of Video Collaboration, Keyboards & Combos, Gaming, and Tablet & Other Accessories, partially offset by declines in sales of Audio & Wearables and Mobile Speakers.

[0001032975-22-000012:mdna:86]
EMEA:

[0001032975-22-000012:mdna:87]
The decrease in sales in the EMEA region for fiscal year 2022, compared to fiscal year 2021, was primarily driven by decline in sales of Video Collaboration, Audio & Wearables, and PC Webcams, partially offset by growth in sales of Gaming, Keyboards & Combos, Pointing Devices, and Tablets & Other Accessories.

[0001032975-22-000012:mdna:88]
Asia Pacific:

[0001032975-22-000012:mdna:89]
The increase in sales in the Asia Pacific region for fiscal year 2022, compared to fiscal year 2021, was primarily driven by growth in sales of a majority of our product categories, partially offset by decline in sales of Tablet & Other Accessories.

[0001032975-22-000012:mdna:90]
Sales by Product Categories

[0001032975-22-000012:mdna:91]
Sales by product categories for fiscal years 2022 and 2021 were as follows (Dollars in thousands):

[0001032975-22-000012:mdna:92]
|  |  | Years Ended March 31, |  | Change |
|  |  | 2022 |  | 2021 |  | 2022 vs. 2021 |
| Pointing Devices |  | $ | 781,108 |  |  | $ | 680,907 |  |  | 15 | % |
| Keyboards & Combos |  | 967,301 |  |  | 784,488 |  |  | 23 |  |
| PC Webcams |  | 403,651 |  |  | 439,865 |  |  | (8) |  |
| Tablet & Other Accessories |  | 310,123 |  |  | 384,301 |  |  | (19) |  |
| Gaming (1) |  | 1,451,883 |  |  | 1,239,005 |  |  | 17 |  |
| Video Collaboration |  | 997,164 |  |  | 1,044,935 |  |  | (5) |  |
| Mobile Speakers |  | 149,782 |  |  | 174,895 |  |  | (14) |  |
| Audio & Wearables |  | 401,424 |  |  | 468,776 |  |  | (14) |  |
| Smart Home |  | 18,463 |  |  | 34,394 |  |  | (46) |  |
| Other (2) |  | 202 |  |  | 713 |  |  | (72) |  |
| Total Sales |  | $ | 5,481,101 |  |  | $ | 5,252,279 |  |  | 4 | % |

[0001032975-22-000012:mdna:93]
(1) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-22-000012:mdna:94]
(2) Other includes products that we phased out because they are no longer strategic to our business.

[0001032975-22-000012:mdna:95]
Sales by Product Categories:

[0001032975-22-000012:mdna:96]
Creativity & Productivity market:

[0001032975-22-000012:mdna:97]
Pointing Devices

[0001032975-22-000012:mdna:98]
Our Pointing Devices category comprises PC- and Mac-related mice including trackballs, touchpads and presentation tools.

[0001032975-22-000012:mdna:99]
During fiscal year 2022, Pointing Devices sales increased 15%, compared to fiscal year 2021, primarily driven by the increase in sales for cordless and corded mice.

[0001032975-22-000012:mdna:100]
Keyboards & Combos

[0001032975-22-000012:mdna:101]
Our Keyboards & Combos category comprises PC keyboards, keyboard/mice combo products, and living room keyboards.

[0001032975-22-000012:mdna:102]
During fiscal year 2022, Keyboards & Combos sales increased 23%, compared to fiscal year 2021, driven by increases in sales of cordless and corded keyboards and keyboard/mice combos.

[0001032975-22-000012:mdna:103]
PC Webcams

[0001032975-22-000012:mdna:104]
Our PC Webcams category comprises PC-based webcams targeted primarily at consumers, including streaming cameras.

[0001032975-22-000012:mdna:105]
During fiscal year 2022, PC Webcams sales decreased 8%, compared to fiscal year 2021, primarily driven by decline in sales of 1080P PRO Webcam, HD Pro Webcam 920, Streamcam, partially offset by an increase in sales of Mevo Video Cameras.

[0001032975-22-000012:mdna:106]
Tablet & Other Accessories

[0001032975-22-000012:mdna:107]
Our Tablet & Other Accessories category primarily comprises keyboards for tablets.

[0001032975-22-000012:mdna:108]
During fiscal year 2022, Tablet & Other Accessories sales decreased 19%, compared to fiscal year 2021, primarily driven by decline in sales of Rugged Folio and Slim Folio Products, partially offset by sales of Combo Touch for iPad Pro 12.9-inch, introduced in the second quarter of fiscal year 2022, Combo Touch for iPad Pro 11-inch and Combo Touch for iPad Air, introduced in the first quarter of fiscal year 2022.

[0001032975-22-000012:mdna:109]
Gaming market:

[0001032975-22-000012:mdna:110]
Gaming

[0001032975-22-000012:mdna:111]
Our Gaming category comprises gaming mice, keyboards, headsets, gamepads, steering wheels, simulation controllers, console gaming headsets, console gaming controllers, and Streamlabs services.

[0001032975-22-000012:mdna:112]
During fiscal year 2022, Gaming sales increased 17%, compared to fiscal year 2021, primarily driven by strong performance in nearly all of our Gaming sub-categories, including our gaming mice, gaming steering wheels, and gaming headsets, partially offset by a decline in the sales of our console gaming headsets and console gaming controllers.

[0001032975-22-000012:mdna:113]
Video Collaboration market:

[0001032975-22-000012:mdna:114]
Video Collaboration

[0001032975-22-000012:mdna:115]
Our Video Collaboration category includes Logitech’s ConferenceCams, which combine affordable enterprise-quality audio and high definition 4K video to bring video conferencing to businesses of any size, as well as webcams and headsets that turn any desktop into an instant collaboration space.

[0001032975-22-000012:mdna:116]
During fiscal year 2022, Video Collaboration sales decreased 5%, compared to fiscal year 2021, primarily driven by the decline in sales of webcams and headsets, partially offset by the increase in sales of conference peripherals.

[0001032975-22-000012:mdna:117]
Music market:

[0001032975-22-000012:mdna:118]
Mobile Speakers

[0001032975-22-000012:mdna:119]
Our Mobile Speakers category is made up entirely of Bluetooth wireless speakers.

[0001032975-22-000012:mdna:120]
During fiscal year 2022, Mobile Speakers sales decreased 14%, compared to fiscal year 2021, primarily due to a decline in sales of most of our Mobile Speaker sub-categories, partially offset by an increase in sales of our Boom 3 speakers.

[0001032975-22-000012:mdna:121]
Audio & Wearables

[0001032975-22-000012:mdna:122]
Our Audio & Wearables category comprises PC speakers, PC headsets, in-ear headphones, premium wireless audio wearables and studio-quality Blue Microphones for professionals and consumers.

[0001032975-22-000012:mdna:123]
During fiscal year 2022, Audio & Wearables sales decreased 14%, compared to fiscal year 2021, primarily due to the decrease in sales of Blue Microphone products, cordless headsets and Jaybird products, partially offset by an increase in sales of our Ultimate Ears custom and wireless headsets.

[0001032975-22-000012:mdna:124]
In the third quarter of fiscal year 2022, we made a decision to cease future product launches under the Jaybird brand, but plan to continue developing wireless audio products such as Ultimate Ears.

[0001032975-22-000012:mdna:125]
Smart Home market:

[0001032975-22-000012:mdna:126]
Smart Home

[0001032975-22-000012:mdna:127]
Our Smart Home category is mainly comprised of our Harmony line of advanced home entertainment controllers and home security cameras.

[0001032975-22-000012:mdna:128]
During fiscal year 2022, Smart Home sales decreased 46%, compared to fiscal year 2021. In the fourth quarter of fiscal year 2021, we made the decision to discontinue manufacturing and selling our Harmony line of advanced home entertainment controllers as the way people consume content has shifted to streaming services across multiple screens. Fiscal year 2022 included sales of remaining Harmony products in inventory. We continue to sell our Circle home security cameras within the Smart Home product category.

[0001032975-22-000012:mdna:129]
Gross Profit

[0001032975-22-000012:mdna:130]
Gross profit for fiscal years 2022 and 2021 was as follows (Dollars in thousands):

[0001032975-22-000012:mdna:131]
|  |  | Years Ended March 31, |
|  |  | 2022 |  | 2021 |  | Change |
| Net sales |  | $ | 5,481,101 |  |  | $ | 5,252,279 |  |  | 4.4 | % |
| Gross profit |  | $ | 2,263,006 |  |  | $ | 2,335,735 |  |  | (3.1) | % |
| Gross margin |  | 41.3 | % |  | 44.5 | % |  |  |

[0001032975-22-000012:mdna:132]
Gross profit consists of sales, less cost of goods sold (which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, royalties, costs of purchasing components from outside suppliers, distribution costs, warranty costs, customer support costs, shipping and handling costs, outside processing costs and write-down of inventories), and amortization of intangible assets.

[0001032975-22-000012:mdna:133]
Gross margin decreased by 320 basis points to 41.3% during fiscal year 2022, compared to fiscal year 2021. The decrease in gross margin was primarily due to increased promotional spending, higher reserves for excess inventories, higher material costs and logistic costs, partially offset by favorable impacts from a shift in product mix and currency exchange rates. The higher material costs were due to industry-wide supply chain challenges and supply availability.

[0001032975-22-000012:mdna:134]
Operating Expenses

[0001032975-22-000012:mdna:135]
Operating expenses for fiscal years 2022 and 2021 were as follows (Dollars in thousands):

[0001032975-22-000012:mdna:136]
|  |  | Years Ended March 31, |
|  |  | 2022 |  | 2021 |  |  |
| Marketing and selling |  | $ | 1,025,899 |  |  | $ | 770,284 |  |  |  |
| % of sales |  | 18.7 | % |  | 14.7 | % |  |  |
| Research and development |  | 291,844 |  |  | 226,023 |  |  |  |
| % of sales |  | 5.3 | % |  | 4.3 | % |  |  |
| General and administrative |  | 148,648 |  |  | 166,577 |  |  |  |
| % of sales |  | 2.7 | % |  | 3.2 | % |  |  |
| Amortization of intangible assets and acquisition-related costs |  | 16,947 |  |  | 19,064 |  |  |  |
| % of sales |  | 0.3 | % |  | 0.4 | % |  |  |
| Impairment of intangible assets |  | 7,000 |  |  | — |  |  |  |
| % of sales |  | 0.1 | % |  | — | % |  |  |
| Change in fair value of contingent consideration for business acquisition |  | (3,509) |  |  | 5,716 |  |  |  |
| % of sales |  | (0.1) | % |  | 0.1 | % |  |  |
| Restructuring charges (credits), net |  | 2,165 |  |  | (54) |  |  |  |
| % of sales |  | — | % |  | — | % |  |  |
| Total operating expenses |  | $ | 1,488,994 |  |  | $ | 1,187,610 |  |  |  |
| % of sales |  | 27.2 | % |  | 22.6 | % |  |  |

[0001032975-22-000012:mdna:137]
The increase in total operating expenses during fiscal year 2022, compared to fiscal year 2021, was mainly due to increases in marketing and selling expenses, research and development expenses, impairment of intangible assets and restructuring charges related to the Jaybird exit, partially offset by decrease in general and administrative expenses and change in fair value of contingent consideration for business acquisition.

[0001032975-22-000012:mdna:138]
Marketing and Selling

[0001032975-22-000012:mdna:139]
Marketing and selling expenses consist of personnel and related overhead costs, corporate and product marketing, promotions, advertising, trade shows, technical support for customer experiences and facilities costs.

[0001032975-22-000012:mdna:140]
During fiscal year 2022, marketing and selling expenses increased $255.6 million, compared to fiscal year 2021. The higher expenses were primarily related to increases of $172.8 million in third-party costs and

[0001032975-22-000012:mdna:141]
$73.5 million in personnel-related costs. The increase in third-party costs was primarily due to increased marketing and advertising spend to support our investment in brand awareness and consideration. The higher personnel spend was driven by increased headcount to support business growth and go-to-market expansion.

[0001032975-22-000012:mdna:142]
Research and Development

[0001032975-22-000012:mdna:143]
Research and development expenses consist of personnel and related overhead costs for contractors and outside consultants, supplies and materials, equipment depreciation and facilities costs, all associated with the design and development of new products and enhancements of existing products.

[0001032975-22-000012:mdna:144]
During fiscal year 2022, research and development expenses increased $65.8 million, compared to fiscal year 2021. The increases were primarily driven by $39.9 million of additional personnel-related costs due to increased headcount to support our investment in innovation. Higher third-party costs of $18.2 million also contributed to the growth in research and development expense and were mainly comprised of costs for contractors to support the increased research and development initiatives.

[0001032975-22-000012:mdna:145]
General and Administrative

[0001032975-22-000012:mdna:146]
General and administrative expenses consist primarily of personnel and related overhead, information technology, and facilities costs for the infrastructure functions such as finance, information systems, executives, human resources and legal.

[0001032975-22-000012:mdna:147]
During fiscal year 2022, general and administrative expenses decreased $17.9 million, compared to fiscal year 2021. The decrease was primarily driven by a $30.0 million contribution into a charitable donor advised fund in fiscal year 2021, partially offset an increase of $10.2 million in personnel-related costs due to increased headcount to support business growth.

[0001032975-22-000012:mdna:148]
Amortization of Intangible Assets and Acquisition-Related Costs

[0001032975-22-000012:mdna:149]
Amortization of intangible assets included in operating expense and acquisition-related costs during fiscal years 2022 and 2021 were as follows (in thousands):

[0001032975-22-000012:mdna:150]
|  |  | Years Ended March 31, |
|  |  | 2022 |  | 2021 |  |  |
| Amortization of intangible assets |  | $ | 16,156 |  |  | $ | 18,489 |  |  |  |
| Acquisition-related costs |  | 791 |  |  | 575 |  |  |  |
| Total |  | $ | 16,947 |  |  | $ | 19,064 |  |  |  |

[0001032975-22-000012:mdna:151]
Amortization of intangible assets consists of amortization of acquired intangible assets, including customer relationships and trademarks and trade names. Acquisition-related costs include legal expense, due diligence costs, and other professional costs incurred for business acquisitions.

[0001032975-22-000012:mdna:152]
The decrease in amortization of intangible assets and acquisition-related costs from fiscal year 2021 to 2022 was primarily driven by write-off Jaybird intangible assets in fiscal year 2022, partially offset by full year of amortization in fiscal year 2022 for intangible assets acquired through acquisitions completed in the fourth quarter of fiscal year 2021.

[0001032975-22-000012:mdna:153]
Impairment of Intangible Assets

[0001032975-22-000012:mdna:154]
During fiscal year 2022, we recognized a pre-tax impairment charge of $7.0 million, related to the intangibles acquired as part of the Jaybird acquisition due to our decision to discontinue Jaybird-branded products.

[0001032975-22-000012:mdna:155]
Change in Fair Value of Contingent Consideration for Business Acquisition

[0001032975-22-000012:mdna:156]
The change in fair value of contingent consideration was a decrease of $3.5 million for fiscal year 2022, primarily due to the release of the contingent consideration from the acquisition of Mevo as a result of not achieving the net sales milestone upon completion of the earn-out period. The change in fair value of contingent consideration was an increase of $5.7 million for fiscal year 2021, primarily due to growth in Streamlabs' net sales and the achievement of the net sales targets during the six-month earn-out period ended June 30, 2020.

[0001032975-22-000012:mdna:157]
Restructuring Charges (Credits), Net

[0001032975-22-000012:mdna:158]
During fiscal year 2022, we recorded restructuring charges of $2.1 million related to our decision to exit Jaybird-branded products. The total charges consisted of $1.3 million, primarily related to costs of production cancellation, and $0.8 million related to cash severance and termination benefits. We expect to complete the restructuring within the next nine months.

[0001032975-22-000012:mdna:159]
Interest Income

[0001032975-22-000012:mdna:160]
Interest income for fiscal years 2022 and 2021 was as follows (in thousands):

[0001032975-22-000012:mdna:161]
|  |  | Years Ended March 31, |
|  |  | 2022 |  | 2021 |  |  |
| Interest Income |  | $ | 1,246 |  |  | $ | 1,784 |  |  |  |

[0001032975-22-000012:mdna:162]
We invest in highly liquid instruments with an original maturity of three months or less at the date of purchase, which are classified as cash equivalents. The decrease in interest income for fiscal year 2022, compared to fiscal year 2021, was primarily driven by the decline in interest rates.

[0001032975-22-000012:mdna:163]
Other Income (Expense), Net

[0001032975-22-000012:mdna:164]
Other income and expense for fiscal years 2022 and 2021 was as follows (in thousands):

[0001032975-22-000012:mdna:165]
|  |  | Years Ended March 31, |
|  |  | 2022 |  | 2021 |  |  |
| Investment income related to the deferred compensation plan |  | $ | 1,231 |  |  | $ | 5,916 |  |  |  |
| Currency exchange loss, net |  | (4,604) |  |  | (2,688) |  |  |  |
| Loss on investments, net |  | (1,683) |  |  | (5,910) |  |  |  |
| Other |  | 5,616 |  |  | 893 |  |  |  |
| Total |  | $ | 560 |  |  | $ | (1,789) |  |  |  |

[0001032975-22-000012:mdna:166]
Investment income related to the deferred compensation plan for fiscal years 2022 and 2021 represents earnings, gains, and losses on marketable securities related to a deferred compensation plan offered by one of our subsidiaries. The decrease in investment income for fiscal year 2022 compared to fiscal year 2021 primarily relates to the change in market performance of the underlying securities.

[0001032975-22-000012:mdna:167]
Currency exchange loss, net, relates to balances denominated in currencies other than the functional currency in our subsidiaries, as well as the sale of currencies, and gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses. The loss for fiscal year 2022 was primarily related to the strengthening of the Chinese Renminbi against the U.S. Dollar.

[0001032975-22-000012:mdna:168]
Loss on investments, net, represents the realized gain (loss) on sales of investment, unrealized gain (loss) from the fair value change of investment and gain (loss) on equity-method investments during the periods presented.

[0001032975-22-000012:mdna:169]
Other, includes the components of net periodic benefit cost other than the service costs component. The increase in the net gains for fiscal year 2022, compared to fiscal year 2021, was related to the actuarial gains primarily resulting from change in termination rate assumption used for one of our defined benefit plans.

[0001032975-22-000012:mdna:170]
Provision for Income Taxes

[0001032975-22-000012:mdna:171]
The provision for income taxes and the effective income tax rate for fiscal years 2022 and 2021 were as follows (Dollars in thousands):

[0001032975-22-000012:mdna:172]
|  |  | Years Ended March 31, |
|  |  | 2022 |  | 2021 |  |  |
| Provision for income taxes |  | $ | 131,305 |  |  | $ | 200,863 |  |  |  |
| Effective income tax rate |  | 16.9 | % |  | 17.5 | % |  |  |

[0001032975-22-000012:mdna:173]
The change in the effective income tax rate between fiscal years 2022 and 2021 was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate.

[0001032975-22-000012:mdna:174]
We recognized excess tax benefits from share-based payments, net of shortfalls of $16.3 million and $8.7 million in the United States in fiscal years 2022 and 2021, respectively, and recognized income tax benefit from the reversal of uncertain tax positions from the expiration of statutes of limitations in the amount of $4.9 million and $4.7 million in fiscal years 2022 and 2021, respectively. In addition, we recognized income tax benefit of $3.7 million from the reversal of uncertain tax positions from an effective settlement of a foreign income tax audit in fiscal year 2022.

[0001032975-22-000012:mdna:175]
As of March 31, 2022 and 2021, the total amount of unrecognized tax benefits due to uncertain tax positions was $176.0 million and $160.3 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-22-000012:mdna:176]
As of March 31, 2022 and 2021, we had $83.4 million and $59.2 million, respectively, in non-current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions. We recognized $1.5 million and $1.1 million, in interest and penalties related to unrecognized tax positions in income tax expense during fiscal years 2022 and 2021, respectively. As of March 31, 2022 and 2021, we had $3.6 million and $4.9 million, respectively, of accrued interest and penalties related to uncertain tax positions.

[0001032975-22-000012:mdna:177]
We file Swiss and foreign tax returns. We received final tax assessments in Switzerland through fiscal year 2019. For other material foreign jurisdictions such as the United States and China, we are generally not subject to tax examinations for years prior to fiscal year 2019 and calendar year 2019, respectively. In the United States, the federal and state tax agencies have the authority to examine periods prior to fiscal year 2019, to the extent allowed by law, where tax attributes were generated, carried forward, and being utilized in subsequent years. We are under examination in foreign tax jurisdictions. If the examinations are resolved unfavorably, there is a possibility that they may have a material negative impact on our results of operations.

[0001032975-22-000012:mdna:178]
Liquidity and Capital Resources

[0001032975-22-000012:mdna:179]
Cash Balances, Available Borrowings, and Capital Resources

[0001032975-22-000012:mdna:180]
As of March 31, 2022, we had cash and cash equivalents of $1,328.7 million, compared with $1,750.3 million as of March 31, 2021. Our cash and cash equivalents consist of bank demand deposits and short-term time deposits, of which 70% is held in Switzerland, 12% is held in China (including Hong Kong), and 10% is held in Germany. We do not expect to incur any material adverse tax impact except for what has already been recognized, or to be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-22-000012:mdna:181]
As of March 31, 2022, our working capital was $1,651.8 million, compared with working capital of $1,477.5 million as of March 31, 2021. The increase was primarily driven by higher inventories, higher accounts receivable, net, lower accounts payable and lower accrued and other current liabilities, partially offset by lower cash and cash equivalents.

[0001032975-22-000012:mdna:182]
We had several uncommitted, unsecured bank lines of credit aggregating to $195.0 million as of March 31, 2022. There are no financial covenants under these lines of credit with which we must comply. As of March 31, 2022, we had outstanding bank guarantees of $25.5 million under these lines of credit.

[0001032975-22-000012:mdna:183]
The following table presents selected financial information and statistics as of March 31, 2022 and 2021 (Dollars in thousands):

[0001032975-22-000012:mdna:184]
|  |  | March 31, |
|  |  | 2022 |  | 2021 |  |  |
| Accounts receivable, net |  | $ | 675,604 |  |  | $ | 612,225 |  |  |  |
| Accounts payable |  | $ | 636,306 |  |  | $ | 823,233 |  |  |  |
| Inventories |  | $ | 933,124 |  |  | $ | 661,116 |  |  |  |
| Days sales in accounts receivable (DSO)(Days)(1) |  | 49 |  |  | 36 |  |  |  |
| Days accounts payable outstanding (DPO) (Days)(2) |  | 78 |  |  | 90 |  |  |  |
| Inventory turnover (ITO)(x)(3) |  | 3.2 |  |  | 5.0 |  |  |  |

[0001032975-22-000012:mdna:185]
(1)DSO is determined using ending accounts receivable, net as of the most recent quarter-end and sales for the most recent quarter.

[0001032975-22-000012:mdna:186]
(2)DPO is determined using ending accounts payable as of the most recent quarter-end and cost of goods sold for the most recent quarter.

[0001032975-22-000012:mdna:187]
(3)ITO is determined using ending inventories and annualized cost of goods sold (based on the most recent quarterly cost of goods sold).

[0001032975-22-000012:mdna:188]
DSO as of March 31, 2022 increased by 13 days to 49 days, as compared to 36 days as of March 31, 2021, primarily due to the timing of sales and customer payments within the quarter.

[0001032975-22-000012:mdna:189]
DPO as of March 31, 2022 decreased 12 days, compared to March 31, 2021, primarily due to lower inventory purchases than prior year as well as timing of purchases and related payments.

[0001032975-22-000012:mdna:190]
ITO as of March 31, 2022 was lower compared to March 31, 2021, primarily due to lower demand than prior year and industry wide logistic delays.

[0001032975-22-000012:mdna:191]
If we are not successful in launching and phasing in our new products, or market competition increases, or we are not able to sell the new products at the prices planned, it could have a material impact on our sales, gross profit margin, operating results including operating cash flow, and inventory turnover in the future.

[0001032975-22-000012:mdna:192]
During fiscal year 2022, we generated $298.3 million in cash from operating activities, resulting from net income of 644.5 million, a favorable impact from adding back non-cash expenses totaling $245.7 million, and an unfavorable net change in operating assets and liabilities of $591.9 million. Non-cash expenses were primarily related to share-based compensation expenses, depreciation, amortization, and deferred income taxes. The increase in accounts receivable, net was primarily driven by timing of sales. The increase in inventories was primarily driven by higher inventory levels compared to the previously constrained supply from COVID-19 impacts and industry wide logistic delays. The decrease in accounts payable was primarily driven by lower inventory purchases than prior years as well as the timing of purchases and related payments. The decrease in accrued and other liabilities was primarily driven by a higher annual bonus accrual and a higher annual income tax payment, both due to strong business performance in fiscal year 2021.

[0001032975-22-000012:mdna:193]
For fiscal year 2022, net cash used in investing activities was $107.9 million, primarily due to purchases of property, plant, and equipment of $89.2 million and payments for an acquisition, net of cash acquired, of $16.2 million. Our expenditures for property, plant and equipment during fiscal year 2022 were primarily for tooling and equipment as well as computer hardware and software.

[0001032975-22-000012:mdna:194]
For fiscal year 2022, net cash used in financing activities was $606.8 million, resulting from repurchases of our registered shares of $412.0 million, payments of cash dividends of $159.4 million, and tax withholdings related to net share settlements of restricted stock units of $64.2 million, partially offset by proceeds from exercise of stock options and purchase rights of $29.6 million.

[0001032975-22-000012:mdna:195]
During fiscal year 2022, there was a $5.2 million loss from currency exchange rate effect on cash and cash equivalents, primarily due to the weakening of the Euro and Australian dollar versus the U.S. Dollar by 3%, and 5%, respectively.

[0001032975-22-000012:mdna:196]
Cash Outlook

[0001032975-22-000012:mdna:197]
Our principal sources of liquidity are our cash and cash equivalents, cash flow generated from operations and, to a much lesser extent, capital markets and borrowings. Our future working capital requirements and capital expenditures may increase to support investments in product innovations and growth opportunities or to acquire or invest in complementary businesses, products, services, and technologies. The future impact of COVID-19 cannot be predicted with certainty and may increase our costs of capital and otherwise adversely affect our business, results of operations, financial condition and liquidity.

[0001032975-22-000012:mdna:198]
In May 2022, the Board of Directors recommended that we pay cash dividends for fiscal year 2022 of CHF 0.96 per share (approximately $1.04 per share based on the exchange rate on March 31, 2022). Based on our shares outstanding, net of treasury shares, as of March 31, 2022 (165,252,020 shares), this would result in an aggregate gross dividend of approximately CHF 159.0 million (or approximately $172.1 million based on the exchange rate on March 31, 2022). In fiscal year 2022, we paid a cash dividend of CHF 0.87 per share, or CHF 147.0 million (U.S. Dollar amount of $159.4 million) on an aggregate gross basis, out of fiscal year 2021 retained earnings. In fiscal year 2021, we paid a cash dividend of CHF 0.79 per share, or CHF 134.0 million (U.S. Dollar amount of $146.7 million) on an aggregate gross basis, out of fiscal year 2020 retained earnings. In fiscal year 2020, we paid a cash dividend of CHF 0.73 per share, or CHF 121.8 million (U.S. Dollar amount of $124.2 million) on an aggregate gross basis, out of fiscal year 2019 retained earnings.

[0001032975-22-000012:mdna:199]
In May 2020, our Board of Directors approved a new share repurchase program, which authorizes us to invest up to $250.0 million to purchase our own shares, following the expiration date of the 2017 share repurchase program. In April 2021, our Board of Directors approved an increase of $750.0 million of the 2020 share repurchase program, to an aggregate amount of $1.0 billion. The Swiss Takeover Board approved this increase and it became effective on May 21, 2021. As of March 31, 2022, $423.7 million was available for repurchase under the 2020 repurchase program.

[0001032975-22-000012:mdna:200]
Although we enter into trading plans for systematic repurchases (e.g., 10b5-1 trading plans) from time to time, our share repurchase program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years through July 27, 2023. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.

[0001032975-22-000012:mdna:201]
For over ten years, we have generated positive cash flows from our operating activities, including cash from operations of $298.3 million, and $1,458.6 million during fiscal years 2022 and 2021, respectively. If we do not generate sufficient operating cash flows to support our operations and future planned cash requirements, our operations could be harmed and our access to credit facilities could be restricted or eliminated. However, we believe that the trend of our historical cash flow generation, our projections of future operations and our available cash balances will provide sufficient liquidity to fund our operations for at least the next 12 months.

[0001032975-22-000012:mdna:202]
Our other contractual obligations and commitments that require cash are described in the following sections.

[0001032975-22-000012:mdna:203]
Contractual Obligations and Commitments

[0001032975-22-000012:mdna:204]
Purchase Commitments

[0001032975-22-000012:mdna:205]
As of March 31, 2022, we had non-cancelable purchase commitments of $736.9 million for inventory purchases made in the normal course of business from original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled during the first two quarters of fiscal year 2023. We recorded a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with our valuation of excess and obsolete inventory. As of March 31, 2022, the liability for these purchase commitments was $46.4 million and is recorded in accrued and other current liabilities in the consolidated balance sheet.

[0001032975-22-000012:mdna:206]
We have firm purchase commitments of $29.5 million for capital expenditures, primarily related to commitments for tooling and equipment for new and existing products. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations.

[0001032975-22-000012:mdna:207]
Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-22-000012:mdna:208]
Operating Leases Obligation

[0001032975-22-000012:mdna:209]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. The remaining terms of our non-cancelable operating leases expire in various years through 2031. See Note 17 - Leases in our Notes to the consolidated financial statements included in this report for more information on leases.

[0001032975-22-000012:mdna:210]
Income Taxes Payable

[0001032975-22-000012:mdna:211]
As of March 31, 2022, we had $83.4 million in non-current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions. At this time, we are unable to make a reasonably reliable estimate of the timing of payments in individual years in connection with these tax liabilities.

[0001032975-22-000012:mdna:212]
Indemnifications

[0001032975-22-000012:mdna:213]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of March 31, 2022, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-22-000012:mdna:214]
We also indemnify our current and former directors and certain current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. We are unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not capped, the obligations are conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.
