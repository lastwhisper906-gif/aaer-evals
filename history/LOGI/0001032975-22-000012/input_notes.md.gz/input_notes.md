# LOGI notes — 0001032975-22-000012


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001032975-22-000012:notes:1]
Portions of the registrant's Proxy Statement for the 2022 Annual Meeting of Shareholders are incorporated herein by reference in Part III of this Annual Report on Form 10-K to the extent stated herein.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-22-000012:notes:2]
Summary of Significant Accounting Policies
Basis of Presentation

[0001032975-22-000012:notes:3]
The consolidated financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States ("U.S. GAAP").

[0001032975-22-000012:notes:4]
Fiscal Year

[0001032975-22-000012:notes:5]
The Company's fiscal year ends on March 31. Interim quarters are generally thirteen-week periods, each ending on a Friday. For purposes of presentation, the Company has indicated its quarterly periods end on the last day of the calendar quarter.

[0001032975-22-000012:notes:6]
Reference to Sales

[0001032975-22-000012:notes:7]
References to "sales" in the Notes to the consolidated financial statements means net sales, except as otherwise specified.

[0001032975-22-000012:notes:8]
Use of Estimates

[0001032975-22-000012:notes:9]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill and intangible assets acquired from business acquisitions, contingent consideration for a business acquisition and periodic reassessment of its fair value, valuation of investment in privately held companies classified under Level 3 fair value hierarchy, pension obligations, accruals for customer incentives, cooperative marketing, and pricing programs ("Customer Programs") and related breakage when appropriate, inventory valuation, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

[0001032975-22-000012:notes:10]
Risks and Uncertainties

[0001032975-22-000012:notes:11]
The Company is subject to risks and uncertainties as a result of the coronavirus ("COVID-19"). Capital markets and economies worldwide have been negatively impacted by COVID-19 and it is still unclear how lasting and deep the economic impacts will be. During fiscal year 2022, the COVID-19 pandemic had mixed effects on the Company’s results of operations. While the Company continued to experience increased sales during fiscal year 2022, compared to fiscal year 2021, the Company also experienced supply and demand volatility, as the COVID-19 pandemic and related safety measures and restrictions have evolved differently across the world. In addition, the

[0001032975-22-000012:notes:12]
Company has experienced industry-wide supply chain challenges, including manufacturing, transportation and logistics. The ongoing and full extent of the impact of the COVID-19 pandemic on the Company's business and operational and financial performance and condition, including the sustainability of its effect on trends positive to the Company, remains uncertain and will depend on many factors outside the Company's control, including but not limited to the timing, extent, duration and effects of the virus and any of its mutations and variants, the availability and effectiveness of treatments and vaccines, the vaccination progress, the imposition of effective public safety and other protective measures and the public's response to such measures, the impact of COVID-19 on the global economy and demand for the Company's products and services. Should the COVID-19 pandemic or global economic slowdown not improve or worsen, or if the Company's attempt to mitigate its impact on its operations and costs is not successful, the Company's business, results of operations, financial condition and prospects may be adversely affected.

[0001032975-22-000012:notes:13]
Reclassifications

[0001032975-22-000012:notes:14]
The Company has reclassified certain prior-year amounts to conform to the current-year presentation.

[0001032975-22-000012:notes:15]
Currencies

[0001032975-22-000012:notes:16]
The functional currency of the Company's operations is primarily the U.S. Dollar. Certain operations use the Euro, Chinese Renminbi, Swiss Franc, or other local currencies as their functional currencies. The financial statements of the Company's subsidiaries whose functional currency is other than the U.S. Dollar are translated to U.S. Dollars using period-end rates of exchange for assets and liabilities and monthly average rates for sales, income and expenses. Cumulative translation gains and losses are included as a component of shareholders' equity in accumulated other comprehensive income (loss). Gains and losses arising from transactions denominated in currencies other than a subsidiary's functional currency are reported in other income (expense), net in the consolidated statements of operations.

[0001032975-22-000012:notes:17]
Revenue Recognition

[0001032975-22-000012:notes:18]
Revenue is recognized when a customer obtains control of promised goods or services in an amount that reflects the transaction price the Company expects to receive in exchange for those goods or services.

[0001032975-22-000012:notes:19]
Substantially all revenue recognized by the Company relates to the contracts with customers to sell products that allow people to connect through gaming, video, computing, music and other digital platforms. These products are hardware devices, which may include embedded software that function together, and are considered as one performance obligation. Hardware devices are generally plug and play, requiring no configuration and little or no installation. Revenue is recognized at a point in time when control of the products is transferred to the customer which generally occurs upon shipment. The Company’s sales contracts with its customers have a one year or shorter term. The Company elects not disclosing the value of unsatisfied performance obligations for contracts with an original expected duration of one year or less.

[0001032975-22-000012:notes:20]
The Company also provides post-contract customer support (“PCS”) for certain products and related software, which includes unspecified software updates and upgrades, bug fixes and maintenance. The transaction price is allocated to two performance obligations in such contracts, based on a relative standalone selling price. The transaction price allocated to PCS is recognized as revenue on a straight-line basis, which reflects the pattern of delivery of PCS, over the estimated term of the support that is between one to two years. Deferred revenue associated with remaining PCS performance obligation as of March 31, 2022 and March 31, 2021 was not material.

[0001032975-22-000012:notes:21]
The Company also recognizes revenue from subscription services that provide professional streamers with access to streaming software and tools that represent a single stand-ready performance obligation. Subscriptions are paid for at the time of or in advance of delivering the services. The proceeds received in advance from such arrangements is recognized as deferred revenue and then recognized as revenue ratably over the subscription period.

[0001032975-22-000012:notes:22]
The Company normally requires payment from customers within thirty to sixty days from the invoice date. However, terms may vary by customer type, by country and by selling season. Extended payment terms are sometimes offered to a limited number of customers during the second and third fiscal quarters. The Company does not modify payment terms on existing receivables. The Company's contracts with customers do not include significant financing components as the period between the satisfaction of performance obligations and timing of payment are generally within one year.

[0001032975-22-000012:notes:23]
The transaction price received by the Company from sales to its distributors, retail companies ("retailers"), and authorized resellers is calculated as selling price net of variable consideration which may include product returns and the Company’s payments for Customer Programs related to current period product revenue. The estimated impact of these programs is recorded as a reduction of transaction price or as an operating expense if the Company receives a distinct good or service from the customer and can reasonably estimate the fair value of that good or service received. Customer Programs require management to estimate the percentage of those programs which will not be claimed in the current period or will not be earned by customers, which is commonly referred to as "breakage." Breakage is estimated based on historical claim experience, the period in which customer claims are expected to be submitted, specific terms and conditions with customers and other factors. The Company accounts for breakage as part of variable consideration, subject to constraint, and records the estimated impact in the same period when revenue is recognized at the expected value. Assessing the period in which claims are expected to be submitted and the relevance of the historical claim experience require significant management judgment to estimate the breakage of Customer Programs in any accounting period.

[0001032975-22-000012:notes:24]
The Company enters into cooperative marketing arrangements with many of its customers and with certain indirect partners, allowing customers to receive a credit equal to a set percentage of their purchases of the Company's products, or a fixed dollar amount for various marketing and incentive programs. The objective of these arrangements is to encourage advertising and promotional events to increase sales of the Company's products.

[0001032975-22-000012:notes:25]
Customer incentive programs include consumer rebates and performance-based incentives. Consumer rebates are offered to the Company's customers and indirect partners at the Company's discretion for the primary benefit of end-users. In addition, the Company offers performance-based incentives to many of its customers and indirect partners based on predetermined performance criteria. At management's discretion, the Company also offers special pricing discounts to certain customers. Special pricing discounts are usually offered only for limited time periods or for sales of selected products to specific indirect partners.

[0001032975-22-000012:notes:26]
Cooperative marketing arrangements and customer incentive programs are considered variable consideration, which the Company estimates and records as a reduction to revenue at the time of sale based on negotiated terms, historical experiences, forecasted incentives, anticipated volume of future purchases, and inventory levels in the channel.

[0001032975-22-000012:notes:27]
The Company has agreements with certain customers that contain terms allowing price protection credits to be issued in the event of a subsequent price reduction. Management's decision to make price reductions is influenced by product life cycle stage, market acceptance of products, the competitive environment, new product introductions and other factors.

[0001032975-22-000012:notes:28]
Accruals for estimated expected future pricing actions and Customer Programs are recognized at the time of sale based on analyses of historical pricing actions by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information, such as stage of product life-cycle.

[0001032975-22-000012:notes:29]
Product return rights vary by customer. Estimates of expected future product returns qualify as variable consideration and are recorded as a reduction of the transaction price of the contract at the time of sale based on an analyses of historical return trends by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information. The Company assesses the estimated asset for recovery value for impairment and adjusts the value of the asset for any impairment. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time but are sufficiently predictable to allow the Company to estimate expected future product returns.

[0001032975-22-000012:notes:30]
Typically, variable consideration does not need to be constrained as estimates are based on predictive historical data or future commitments that are planned and controlled by the Company. However, the Company continues to assess variable consideration estimates such that it is probable that a significant reversal of revenue will not occur.

[0001032975-22-000012:notes:31]
The Company regularly evaluates the adequacy of its estimates for Customer Programs and product returns. Future market conditions and product transitions may require the Company to take action to change such programs and related estimates. When the variables used to estimate these costs change, or if actual costs differ significantly from the estimates, the Company would be required to increase or reduce revenue or operating expenses to reflect the impact. During the year ended March 31, 2022, changes to these estimates related to performance obligations satisfied in prior periods were not material.

[0001032975-22-000012:notes:32]
Sales taxes and value-added taxes (“VAT”) collected from customers, if applicable, which are remitted to governmental authorities are not included in revenue, and are reflected as a liability on the consolidated balance sheets.

[0001032975-22-000012:notes:33]
Shipping and Handling Costs

[0001032975-22-000012:notes:34]
The Company's shipping and handling costs are included in the cost of goods sold in the consolidated statements of operations for all periods presented.

[0001032975-22-000012:notes:35]
Contract Balances

[0001032975-22-000012:notes:36]
The Company records accounts receivable from contracts with customers when it has an unconditional right to consideration, as accounts receivable, net on the consolidated balance sheets.

[0001032975-22-000012:notes:37]
The Company records contract liabilities when cash payments are received or due in advance of performance, primarily for implied support and subscriptions. Contract liabilities are included in accrued and other current liabilities and other non-current liabilities on the consolidated balance sheets.

[0001032975-22-000012:notes:38]
As of March 31, 2022 and 2021, the Company did not have any material contract liabilities balances or changes.

[0001032975-22-000012:notes:39]
Contract Costs

[0001032975-22-000012:notes:40]
The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that otherwise would have been recognized is one year or less. These costs are included in marketing and selling expenses in the consolidated statements of operations. As of March 31, 2022 and 2021, the Company did not have any material deferred contract costs.

[0001032975-22-000012:notes:41]
Research and Development Costs

[0001032975-22-000012:notes:42]
Costs related to research, design and development of products, which consist primarily of personnel, product design and infrastructure expenses, are charged to research and development expense as they are incurred.

[0001032975-22-000012:notes:43]
Advertising Costs

[0001032975-22-000012:notes:44]
Advertising costs are recorded as either a marketing and selling expense or a deduction from revenue as they are incurred. Advertising costs paid or reimbursed by the Company to direct or indirect customers must have an identifiable benefit and an estimable fair value in order to be classified as an operating expense. If these criteria are not met, the payment is classified as a reduction of revenue. Advertising costs recorded as marketing and selling expense are expensed as incurred. Total advertising costs including those characterized as revenue deductions during fiscal years 2022, 2021 and 2020 were  $628.9 million, $450.0 million and $298.6 million, respectively, out of which $267.8 million, $168.2 million, and $64.5 million, respectively, were included as operating expense in the consolidated statements of operations.

[0001032975-22-000012:notes:45]
Cash Equivalents

[0001032975-22-000012:notes:46]
The Company classifies all highly liquid instruments purchased with an original maturity of three months or less at the date of purchase to be cash equivalents. Cash equivalents are carried at cost, which approximates their fair value.

[0001032975-22-000012:notes:47]
All of the Company's bank time deposits have an original maturity of three months or less and are classified as cash equivalents and are recorded at cost, which approximates their fair value.

[0001032975-22-000012:notes:48]
Concentration of Credit Risk

[0001032975-22-000012:notes:49]
Financial instruments that potentially subject the Company to concentrations of credit risk consist principally of cash and cash equivalents and accounts receivable. The Company maintains cash and cash equivalents with various financial institutions to limit exposure with any one financial institution, but is exposed to credit risk in the event of default by financial institutions to the extent that cash balances with individual financial institutions are in excess of amounts that are insured.

[0001032975-22-000012:notes:50]
The Company sells to large distributors, retailers, and e-tailers and, as a result, maintains individually significant receivable balances with such customers.

[0001032975-22-000012:notes:51]
The Company had the following customers that individually comprised 10% or more of its gross sales:

[0001032975-22-000012:notes:52]
|  |  | Years Ended March 31, |
|  |  | 2022 |  | 2021 |  | 2020 |
| Customer A |  | 15 | % |  | 14 | % |  | 12 | % |
| Customer B |  | 17 | % |  | 13 | % |  | 14 | % |
| Customer C (1) |  | 14 | % |  | N/A(1) |  | N/A(1) |

[0001032975-22-000012:notes:53]
(1) The Company's two customers merged during fiscal year 2022 and the percentage for fiscal year 2022 reflects the gross sales to the combined company. Percentages for fiscal year 2021 and 2020 are not disclosed as gross sales to each customer accounted for less than 10% of the Company's gross sales.

[0001032975-22-000012:notes:54]
The Company had the following customers that individually comprised 10% or more of its accounts receivable:

[0001032975-22-000012:notes:55]
|  |  | March 31, |
|  |  | 2022 |  | 2021 |
| Customer A |  | 15 | % |  | 12 | % |
| Customer B |  | 17 | % |  | 20 | % |
| Customer C (1) |  | 15 | % |  | 10 | % |

[0001032975-22-000012:notes:56]
(1) The Company's two customers merged during fiscal year 2022. The percentage as of March 31, 2022 reflects accounts receivable from the combined company. The percentage as of March 31, 2021 reflects accounts receivable from one of them only as the other customer accounted for less than 10% of the Company's accounts receivable.

[0001032975-22-000012:notes:57]
The Company manages its accounts receivable credit risk through ongoing credit evaluation of its customers' financial conditions. The Company generally does not require collateral from its customers.

[0001032975-22-000012:notes:58]
Allowances for Doubtful Accounts

[0001032975-22-000012:notes:59]
Allowances for doubtful accounts are maintained for expected credit losses resulting from the Company's customers' inability to make required payments. The allowances are based on the Company's regular assessment of various factors, including the credit-worthiness and financial condition of specific customers, historical experience with bad debts and customer deductions, receivables aging, current economic conditions, reasonable and supportable forecasts of future economic conditions, and other factors that may affect the Company's ability to collect from customers.

[0001032975-22-000012:notes:60]
Inventories

[0001032975-22-000012:notes:61]
Inventories are stated at the lower of cost and net realizable value. Costs are computed under the standard cost method, which approximates actual costs determined on the first-in, first-out basis. The Company records write-downs of inventories which are obsolete or in excess of anticipated demand or net realizable value based on a consideration of marketability and product life cycle stage, product development plans, component cost trends, historical sales and demand forecasts which consider the assumptions about future demand and market conditions. Inventory on hand which is not expected to be sold or utilized is considered excess, and the Company recognizes the write-down in cost of goods sold at the time of such determination. The write-down is determined by the excess of cost over net realizable value. Net realizable value is the estimated selling price in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. At the time of loss

[0001032975-22-000012:notes:62]
recognition, new cost basis per unit and lower-cost basis for that inventory are established and subsequent changes in facts and circumstances would not result in an increase in the cost basis.

[0001032975-22-000012:notes:63]
As of March 31, 2022 and 2021, the Company also recorded a liability of $46.4 million and $11.8 million, respectively, arising from firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with its valuation of excess and obsolete inventory. Such liability is included in accrued and other current liabilities on the consolidated balance sheets.

[0001032975-22-000012:notes:64]
Property, Plant and Equipment

[0001032975-22-000012:notes:65]
Property, plant and equipment are stated at cost. Additions and improvements are capitalized, and maintenance and repairs are expensed as incurred. The Company capitalizes the cost of software developed for internal use in connection with major projects. Costs incurred during the preliminary and post implementation stage are expensed, whereas direct costs incurred during the application development stage are capitalized.

[0001032975-22-000012:notes:66]
Depreciation expense is recognized using the straight-line method. Plant and buildings are depreciated over estimated useful lives of twenty-five years, equipment over useful lives from three to five years, internal-use software over useful lives from three to ten years, tooling over useful lives from six months to one year, and leasehold improvements over the lesser of the term of the lease or ten years.

[0001032975-22-000012:notes:67]
When property and equipment is retired or otherwise disposed of, the cost and accumulated depreciation are relieved from the accounts and the net gain or loss is included in cost of goods sold or operating expenses, depending on the nature of the property and equipment.

[0001032975-22-000012:notes:68]
Leases

[0001032975-22-000012:notes:69]
The Company determines if an arrangement is a lease or contains a lease at contract inception. The Company determines if a lease is an operating or finance lease and recognizes right-of-use ("ROU") assets and lease liabilities upon lease commencement. Operating lease ROU assets are included in other assets, short-term lease liabilities are included in accrued and other current liabilities, and long-term lease liabilities are included in other non-current liabilities on the Company's consolidated balance sheets. Leases with an initial term of 12 months or less are not recorded on the balance sheet. For the Company's operating leases, the Company accounts for the lease and non-lease components as a single lease component. Lease expense is recognized on a straight-line basis over the lease term.

[0001032975-22-000012:notes:70]
For operating leases, the lease liability is initially measured at the present value of the unpaid lease payments at lease commencement date. As most of the leases do not provide an implicit rate, the Company generally uses its incremental borrowing rate as the discount rate for the lease. The Company's incremental borrowing rate is the rate of interest it would have to pay on a collateralized basis to borrow an amount equal to the lease payments under similar terms. Because the Company does not generally borrow in a collateralized basis, it uses its understanding of what its collateralized credit rating would be as an input to deriving an appropriate incremental borrowing rate. The operating lease right-of-use asset includes prepaid lease payments and excludes lease incentives.

[0001032975-22-000012:notes:71]
Intangible Assets

[0001032975-22-000012:notes:72]
The Company's intangible assets principally include goodwill, acquired technology, trademarks, and customer contracts and related relationships. Intangible assets with finite lives, which include acquired technology, trademarks, customer contracts and related relationships, and others are carried at cost and amortized using the straight-line method over their useful lives ranging from one to ten years. Intangible assets with indefinite lives, which include only goodwill and in-process research and development ("IPR&D"), are recorded at cost and evaluated at least annually for impairment.

[0001032975-22-000012:notes:73]
Impairment of Long-Lived Assets

[0001032975-22-000012:notes:74]
The Company reviews long-lived assets, such as property and equipment, and finite-lived intangible assets, for impairment whenever events indicate that the carrying amounts might not be recoverable. Recoverability of property and equipment and finite-lived intangible assets is measured by comparing the projected undiscounted net cash flows associated with those assets to their carrying values. If an asset is considered impaired, it is written down to its fair value, which is determined based on the asset's projected discounted cash flows or appraised value, depending on the nature of the asset. For purposes of recognition of impairment for assets held for use, the Company groups assets and liabilities at the lowest level for which cash flows are separately identifiable.

[0001032975-22-000012:notes:75]
Impairment of Goodwill

[0001032975-22-000012:notes:76]
Goodwill represents the excess of the purchase price over the fair value of the net tangible and identifiable intangible assets acquired in each business combination. The Company conducts a goodwill impairment analysis annually at December 31 or more frequently if indicators of impairment exist or if a decision is made to sell or exit a business. Significant judgments are involved in determining if an indicator of impairment has occurred. Such indicators may include deterioration in general economic conditions, negative developments in equity and credit markets, adverse changes in the markets in which an entity operates, increases in input costs that have a negative effect on earnings and cash flows, or a trend of negative or declining cash flows over multiple periods, among others. The fair value that could be realized in an actual transaction may differ from that used to evaluate the impairment of goodwill.

[0001032975-22-000012:notes:77]
In reviewing goodwill for impairment, the Company has the option to first assess qualitative factors to determine whether the existence of events or circumstances leads to a determination that it is more likely than not (greater than 50%) that the estimated fair value of a reporting unit is less than its carrying amount. The Company also may elect not to perform the qualitative assessment and, instead, proceed directly to the quantitative impairment test. The ultimate outcome of the goodwill impairment review for a reporting unit should be the same whether the Company chooses to perform the qualitative assessment or proceeds directly to the quantitative impairment test. The Company operates as one reporting unit. For the year ended March 31, 2022, the Company elected to perform a qualitative assessment and determined that an impairment was not more likely than not and no further analysis was required.

[0001032975-22-000012:notes:78]
Income Taxes

[0001032975-22-000012:notes:79]
The Company provides for income taxes using the asset and liability method, which requires that deferred tax assets and liabilities be recognized for the expected future tax consequences of temporary differences resulting from differing treatment of items for tax and financial reporting purposes, and for operating losses and tax credit carryforwards. In estimating future tax consequences, expected future events are taken into consideration, with the exception of potential tax law or tax rate changes. The Company records a valuation allowance to reduce deferred tax assets to amounts management believes are more likely than not to be realized.

[0001032975-22-000012:notes:80]
The Company's assessment of uncertain tax positions requires that management makes estimates and judgments about the application of tax law, the expected resolution of uncertain tax positions and other matters. In the event that uncertain tax positions are resolved for amounts different than the Company's estimates, or the related statutes of limitations expire without the assessment of additional income taxes, the Company will be required to adjust the amounts of the related assets and liabilities in the period in which such events occur. Such adjustments may have a material impact on the Company's income tax provision and its results of operations.

[0001032975-22-000012:notes:81]
Fair Value of Financial Instruments

[0001032975-22-000012:notes:82]
The carrying value of certain of the Company's financial instruments, including cash equivalents, accounts receivable and accounts payable approximates their fair value due to their short maturities.

[0001032975-22-000012:notes:83]
The Company's investment securities portfolio consists of bank time deposits with an original maturity of three months or less and marketable securities (money market and mutual funds) related to a deferred compensation plan.

[0001032975-22-000012:notes:84]
The Company's investments related to the deferred compensation plan are reported at fair value based on quoted market prices. The marketable securities related to the deferred compensation plan are classified as non-current investments, as they are intended to fund the deferred compensation plan's long-term liability. Participants in the deferred compensation plan may select the mutual funds in which their compensation deferrals are invested within the confines of the Rabbi Trust which holds the marketable securities. These securities are recorded at fair value based on quoted market prices. Earnings, gains and losses on deferred compensation  investments are included in other income (expense), net in the consolidated statements of operations.

[0001032975-22-000012:notes:85]
The Company also holds non-marketable investments in equity and other securities that are accounted for under the equity method, which are classified as other assets. In addition, the Company has certain investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. The Company elected the measurement alternative to record these investments at cost and to adjust for impairments and observable price changes resulting from transactions with the same issuer within the statement of operations.

[0001032975-22-000012:notes:86]
Net Income per Share

[0001032975-22-000012:notes:87]
Basic net income per share is computed by dividing net income by the weighted average outstanding shares. Diluted net income per share is computed using the weighted average outstanding shares and dilutive share equivalents. Dilutive share equivalents consist of share-based awards, including stock options, purchase rights under employee share purchase plan, and restricted stock units ("RSUs").

[0001032975-22-000012:notes:88]
The dilutive effect of in-the-money share-based compensation awards is calculated based on the average share price for each fiscal period using the treasury stock method.

[0001032975-22-000012:notes:89]
Share-Based Compensation Expense

[0001032975-22-000012:notes:90]
Share-based compensation expense includes compensation expense for share-based awards granted based on the grant date fair value. The grant date fair value for stock options and stock purchase rights is estimated using the Black-Scholes-Merton option-pricing valuation model. The grant date fair value of RSUs which vest upon meeting certain market conditions is estimated using the Monte-Carlo simulation method. The grant date fair value of time-based and performance-based RSUs is calculated based on the market price on the date of grant, reduced by estimated dividend yield prior to vesting. With respect to awards with service conditions only, compensation expense is recognized ratably over the respective requisite service periods of the awards. For performance-based RSUs, the Company recognizes the estimated expense using a graded-vesting method over requisite service periods of three years when the performance condition is determined to be probable. The performance period and the service period of the market-based grants of the Company are both approximately three years and the estimated expense is recognized ratably over the service period. Forfeitures are accounted for when they occur.

[0001032975-22-000012:notes:91]
Product Warranty Accrual

[0001032975-22-000012:notes:92]
All of the Company's products are covered by warranty to be free from defects in material and workmanship for periods ranging from one year to three years. The warranty period varies by product and by region. The Company’s warranty does not provide a service beyond assuring that the product complies with agreed-upon specifications and is not sold separately. The warranty the Company provides qualifies as an assurance warranty and is not treated as a separate performance obligation. The Company estimates cost of product warranties at the time the related revenue is recognized based on historical warranty claim rates, historical costs, and knowledge of specific product failures that are outside of the Company's typical experience. The Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. Each quarter, the Company reevaluates estimates to assess the adequacy of recorded warranty liabilities. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly. If actual product failure rates or repair costs differ from estimates, revisions to the estimated warranty liabilities would be required and could materially affect the Company's results of operations.

[0001032975-22-000012:notes:93]
Comprehensive Income (Loss)

[0001032975-22-000012:notes:94]
Comprehensive income (loss) is defined as the total change in shareholders' equity during the period other than from transactions with shareholders. Comprehensive income (loss) consists of net income (loss) and other comprehensive income (loss). Other comprehensive income (loss) is comprised of currency translation adjustments from those entities not using the U.S. Dollar as their functional currency, net deferred gains and losses and prior service costs and credits for defined benefit pension plans, and net deferred gains and losses on hedging activity.

[0001032975-22-000012:notes:95]
Treasury Shares

[0001032975-22-000012:notes:96]
The Company periodically repurchases shares in the market at fair value. Shares repurchased are recorded at cost as a reduction of total shareholders' equity. Treasury shares held may be reissued to satisfy the exercise of employee stock options and purchase rights and the vesting of restricted stock units, or may be canceled with shareholder approval. Treasury shares that are reissued are accounted for using the first-in, first-out basis.

[0001032975-22-000012:notes:97]
Derivative Financial Instruments

[0001032975-22-000012:notes:98]
The Company enters into foreign exchange forward contracts to reduce the short-term effects of currency fluctuations on certain foreign currency receivables or payables and to hedge against exposure to changes in currency exchange rates related to its subsidiaries' forecasted inventory purchases.

[0001032975-22-000012:notes:99]
Gains and losses for changes in the fair value of the effective portion of the Company's forward contracts related to forecasted inventory purchases are deferred as a component of accumulated other comprehensive

[0001032975-22-000012:notes:100]
income (loss) until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. The Company presents the earnings impact from forward points in the same line item that is used to present the earnings impact of the hedged item, i.e. cost of goods sold, for hedging forecasted inventory purchases.

[0001032975-22-000012:notes:101]
Gains or losses from changes in the fair value of forward contracts that offset transaction losses or gains on foreign currency receivables or payables are recognized immediately and included in other income (expense), net in the consolidated statements of operations.

[0001032975-22-000012:notes:102]
Restructuring Charges

[0001032975-22-000012:notes:103]
The Company's restructuring charges consist of employee severance, one-time termination benefits and ongoing benefits related to the reduction of its workforce, and other costs. Liabilities for costs associated with a restructuring activity are measured at fair value and are recognized when the liability is incurred, as opposed to when management commits to a restructuring plan. One-time termination benefits are expensed at the date the entity notifies the employee, unless the employee must provide future service, in which case the benefits are expensed ratably over the future service period. Ongoing benefits are expensed when restructuring activities are probable and the benefit amounts are estimable. Other costs primarily consist of legal, consulting, and other costs related to employee terminations are expensed when incurred. Termination benefits are calculated based on regional benefit practices and local statutory requirements.

[0001032975-22-000012:notes:104]
Recent Accounting Pronouncements Adopted

[0001032975-22-000012:notes:105]
In December 2019, the Financial Accounting Standard Board ("FASB") issued ASU 2019-12, "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes" ("ASU 2019-12"), which eliminates certain exceptions for recognizing deferred taxes for investments, performing intraperiod allocation and calculating income taxes in interim periods. This ASU also includes guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. The Company adopted this standard effective April 1, 2021. The adoption of ASU 2019-12 did not have a material impact on the Company's consolidated financial statements.

[0001032975-22-000012:notes:106]
Recent Accounting Pronouncements To Be Adopted

[0001032975-22-000012:notes:107]
In October 2021, the FASB issued ASU 2021-08, "Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers" ("ASU 2021-08"). The update requires an acquirer in a business combination to recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Accounting Standards Codification ("ASC") 606, Revenue from Contracts with Customers, as if it had originated the contracts. The standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2022. The Company early adopted the standard effective April 1, 2022 and will apply the standard prospectively to business combinations that occur on or after April 1, 2022.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001032975-22-000012:notes:108]
Business Acquisitions
Fiscal Year 2022 Acquisition

[0001032975-22-000012:notes:109]
On May 19, 2021, the Company made a technology acquisition for a total cash consideration of $25.6 million, including $10.0 million earn-out payable in cash upon the achievement of three technical development milestones required to be completed as of December 31, 2021, June 30, 2022 and June 30, 2023. The acquisition was accounted for using the acquisition method. The Company retained 6% of the total consideration for the purpose of ensuring seller's representations and warranties. See Note 9 for more information on the contingent consideration liabilities related to this acquisition.

[0001032975-22-000012:notes:110]
Fiscal Year 2021 Acquisitions

[0001032975-22-000012:notes:111]
On February 17, 2021, the Company acquired all equity interests of Mevo Inc. ("Mevo") for a total upfront cash consideration of $33.2 million, which included a working capital adjustment, plus additional contingent consideration of up to $17.0 million payable in cash only upon the achievement of certain net revenues for the period beginning on December 26, 2020 and ending on December 31, 2021 (the "Mevo Acquisition"). See Note 9 for more information on the contingent consideration liabilities related to this acquisition.

[0001032975-22-000012:notes:112]
The Mevo Acquisition is complementary to the Company’s PC Webcams portfolio and will better enable the Company to offer end-to-end solutions for streaming and content creation. The acquisition is accounted for using the acquisition method.

[0001032975-22-000012:notes:113]
On January 4, 2021, the Company made a technology acquisition for a total cash consideration of $11.0 million, including $3.0 million earn-out payable in cash upon the achievement of two technical development milestones required to be completed for periods ending December 31, 2021 and March 31, 2022. The acquisition was accounted for using the acquisition method.

[0001032975-22-000012:notes:114]
On February 11, 2021, the Company made a technology acquisition for a total cash consideration of $3.5 million, which was accounted for as an asset acquisition.

[0001032975-22-000012:notes:115]
Fiscal Year 2020 Acquisitions

[0001032975-22-000012:notes:116]
Streamlabs Acquisition

[0001032975-22-000012:notes:117]
On October 31, 2019 (the "Streamlabs Acquisition Date"), the Company acquired all equity interests of Streamlabs for a total consideration of $105.7 million (as described in the table below), which included a working capital adjustment, plus additional contingent consideration of $29.0 million payable in stock only upon the achievement of certain net revenues for the period beginning on January 1, 2020 and ending on June 30, 2020 (the "Streamlabs Acquisition").

[0001032975-22-000012:notes:118]
Streamlabs is a leading provider of software and tools for professional streamers. The Streamlabs Acquisition is complementary to the Company's Gaming portfolio.

[0001032975-22-000012:notes:119]
Streamlabs met the definition of a business, and therefore the acquisition is accounted for using the acquisition method.

[0001032975-22-000012:notes:120]
The fair value of consideration transferred for the Streamlabs Acquisition consists of the following (in thousands):

[0001032975-22-000012:notes:121]
|  |  | Consideration |
| Purchase price (cash) |  | $ | 105,645 |  |
| Fair value of contingent consideration (earn-out) |  | 37 |  |
| Fair value of total consideration transferred |  | $ | 105,682 |  |

[0001032975-22-000012:notes:122]
The following table summarizes the estimated fair values of the assets acquired and liabilities assumed at the Streamlabs Acquisition Date, and the value of goodwill resulting from the measurement period adjustments in the three months ending March 31, 2020 (in thousands):

[0001032975-22-000012:notes:123]
|  |  | Estimated Fair Value |
| Cash and cash equivalents |  | $ | 17,014 |  |
| Intangible assets |  | 37,000 |  |
| Other identifiable liabilities assumed, net |  | (3,701) |  |
| Net identifiable assets acquired |  | $ | 50,313 |  |
| Contingent consideration (earn-out) |  | $ | (37) |  |
| Goodwill |  | 55,406 |  |
| Net assets acquired |  | $ | 105,682 |  |

[0001032975-22-000012:notes:124]
Goodwill related to the acquisition was primarily attributable to opportunities and economies of scale from combining the operations and technologies of Logitech and Streamlabs, and is not deductible for tax purposes.

[0001032975-22-000012:notes:125]
The following table summarizes the estimated fair values and estimated useful lives of the components of identifiable intangible assets acquired as of the Streamlabs Acquisition Date (Dollars in thousands):

[0001032975-22-000012:notes:126]
|  | Fair Value |  | Estimated Useful Life (years) |
| Developed technology | $ | 21,800 |  |  | 6.0 |
| Customer relationships | 6,000 |  |  | 2.0 |
| Trade name | 9,200 |  |  | 8.0 |
| Total identifiable intangible assets acquired | $ | 37,000 |  |  |  |

[0001032975-22-000012:notes:127]
Intangible assets acquired as a result of the Streamlabs Acquisition are being amortized over their estimated useful lives using the straight-line method of amortization, which materially approximates the distribution of the economic value of the identified intangible assets.

[0001032975-22-000012:notes:128]
Developed technology relates to the software platform which existing Streamlabs services are provided on. The economic useful life was determined based on the technology cycle related to developed technology of the software platform, as well as the cash flows anticipated over the forecasted periods.

[0001032975-22-000012:notes:129]
Customer relationships represent the fair value of future projected revenue that will be derived from sales to existing customers of Streamlabs. The economic useful life was determined based on historical customer turnover rates and industry benchmarks.

[0001032975-22-000012:notes:130]
Trade name relates to the “Streamlabs” trade name. The economic useful life was determined based on the expected life of the trade name and the cash flows anticipated over the forecasted periods.

[0001032975-22-000012:notes:131]
The fair value of developed technology was estimated using the excess earnings method, an income approach (Level 3), which converts projected revenues and costs into cash flows. To reflect the fact that certain other assets contributed to the cash flows generated, the returns for these contributory assets were removed to arrive at estimated cash flows solely attributable to the developed technology, which were discounted at a rate of 25%.

[0001032975-22-000012:notes:132]
The fair value of trade name was estimated using the relief-from-royalty method, an income approach (Level 3), which estimates the cost savings that accrue to the owner of the intangible assets that would otherwise be payable as royalties or license fees on revenues earned through the use of the asset. A royalty rate is applied to the projected revenues associated with the intangible assets to determine the amount of savings, which is then discounted to determine the fair value. Trade name was valued using royalty rate of 5% and was discounted at a rate of 25%.

[0001032975-22-000012:notes:133]
The fair value of customer relationships was estimated primarily using the with and without scenario, a discounted cash flow method (Level 3). Under this method, the Company calculated the present value of the after-tax cash flows expected to be generated by the business with and without the customer relationships using a discount rate of 20%. The without scenario incorporates lost revenue and lost profits over the period necessary to retain the asset.

[0001032975-22-000012:notes:134]
The Company believes the fair values of acquired intangible assets recorded above represents their fair values and approximates the amounts a market participant would pay for these intangible assets as of the Streamlabs Acquisition Date.

[0001032975-22-000012:notes:135]
The Company included Streamlabs' estimated fair value of assets acquired and liabilities assumed in its consolidated financial statements beginning on the Streamlabs Acquisition Date. The results of operations for Streamlabs subsequent to the Streamlabs Acquisition Date have been included in, but are not material to, the Company's consolidated statements of operations in fiscal year 2020.

[0001032975-22-000012:notes:136]
On October 31, 2019, the Company also made a technology acquisition for a total cash consideration of $3.6 million, which was accounted for using the acquisition method.

[0001032975-22-000012:notes:137]
Acquisition-related costs and pro forma results of operations

[0001032975-22-000012:notes:138]
The Company incurred acquisition-related costs of approximately $0.8 million, $0.6 million and $1.5 million, in aggregate, for the years ended March 31, 2022, 2021 and 2020, respectively. The acquisition-related costs are included in amortization of intangible assets and acquisition-related costs in the consolidated statements of operations.
Pro forma results of operations for acquisitions completed in fiscal year 2022, 2021 and 2020 have not been presented because the effects of these acquisitions, individually or in aggregate, are not material to the consolidated statements of operations for each year.


## us-gaap:EarningsPerShareTextBlock

[0001032975-22-000012:notes:139]
Net Income Per Share 
The following table summarizes the computations of basic and diluted net income per share for fiscal years 2022, 2021 and 2020 (in thousands except per share amounts):

[0001032975-22-000012:notes:140]
|  |  | Years Ended March 31, |
|  |  | 2022 |  | 2021 |  | 2020 |
| Net income |  | $ | 644,513 |  |  | $ | 947,257 |  |  | $ | 449,723 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 167,447 |  |  | 168,523 |  |  | 166,837 |  |
| Effect of potentially dilutive equivalent shares |  | 2,967 |  |  | 3,252 |  |  | 2,544 |  |
| Weighted average shares outstanding - diluted |  | 170,414 |  |  | 171,775 |  |  | 169,381 |  |
| Net income per share: |  |  |  |  |  |  |
| Basic |  | $ | 3.85 |  |  | $ | 5.62 |  |  | $ | 2.70 |  |
| Diluted |  | $ | 3.78 |  |  | $ | 5.51 |  |  | $ | 2.66 |  |

[0001032975-22-000012:notes:141]
Share equivalents attributable to outstanding stock options, RSUs and employee share purchase plans ("ESPP") totaling 2.0 million, 0.1 million, and 1.7 million shares during fiscal years 2022, 2021 and 2020, respectively, were excluded from the calculation of diluted net income per share because their effect would have been anti-dilutive. Except for fiscal year 2021, certain performance-based awards in the periods presented were excluded because all necessary conditions had not been satisfied by the end of the respective period, and those shares were not issuable if the end of the reporting period were the end of the performance contingency period.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-22-000012:notes:142]
Employee Benefit Plans
Employee Share Purchase Plans and Stock Incentive Plans

[0001032975-22-000012:notes:143]
As of March 31, 2022, the Company offers the 2006 Employee Share Purchase Plan, as amended and restated (Non-U.S.) ("2006 ESPP)", the 1996 Employee Share Purchase Plan (U.S.), as amended and restated  ("1996 ESPP"), and the 2006 Stock Incentive Plan ("2006 Plan") as amended and restated. The 2012 Stock Inducement Equity Plan ("2012 Plan") expired on March 28, 2022. Shares issued to employees as a result of purchases or exercises under these plans are generally issued from shares held in treasury stock.

[0001032975-22-000012:notes:144]
The following table summarizes share-based compensation expense and total income tax benefit recognized for fiscal years 2022, 2021 and 2020 (in thousands):

[0001032975-22-000012:notes:145]
|  |  | Years Ended March 31, |
|  |  | 2022 |  | 2021 |  | 2020 |
| Cost of goods sold |  | $ | 6,695 |  |  | $ | 6,438 |  |  | $ | 4,852 |  |
| Marketing and selling |  | 37,796 |  |  | 36,788 |  |  | 26,835 |  |
| Research and development |  | 18,356 |  |  | 14,179 |  |  | 9,273 |  |
| General and administrative |  | 30,632 |  |  | 28,614 |  |  | 13,910 |  |
| Total share-based compensation expense |  | 93,479 |  |  | 86,019 |  |  | 54,870 |  |
| Income tax benefit |  | (26,987) |  |  | (19,472) |  |  | (14,109) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 66,492 |  |  | $ | 66,547 |  |  | $ | 40,761 |  |

[0001032975-22-000012:notes:146]
As of March 31, 2022, 2021 and 2020, the balance of capitalized stock-based compensation included in inventory was $1.1 million, $1.1 million, and $0.9 million, respectively.

[0001032975-22-000012:notes:147]
The following table summarizes total unamortized share-based compensation expense and the remaining period over which such expense is expected to be recognized, on a weighted-average basis by type of grant (in thousands, except number of months):

[0001032975-22-000012:notes:148]
|  |  | March 31, 2022 |
|  |  | UnamortizedExpense |  | RemainingMonths |
| ESPP |  | $ | 2,341 |  |  | 4 |
| Stock Options |  | 19,746 |  |  | 35 |
| Time-based RSUs |  | 109,637 |  |  | 24 |
| Market-based and performance-based RSUs |  | 36,669 |  |  | 21 |
| Total unamortized share-based compensation expense |  | $ | 168,393 |  |  |  |

[0001032975-22-000012:notes:149]
Under the 1996 ESPP and 2006 ESPP plans, eligible employees may purchase shares at the lower of 85% of the fair market value at the beginning or the end of each offering period, which is generally six months. Subject to continued participation in these plans, purchase agreements are automatically executed at the end of each offering period. An aggregate of 29.0 million shares were reserved for issuance under the 1996 and 2006 ESPP plans. As of March 31, 2022, a total of 4.1 million shares were available for new awards under these plans.

[0001032975-22-000012:notes:150]
The 2006 Plan provides for the grant to eligible employees and non-employee directors of stock options, stock appreciation rights, restricted stock and RSUs. Awards under the 2006 Plan may be conditioned on continued employment, the passage of time or the satisfaction of performance and market vesting criteria. The 2006 Plan, as amended, has no expiration date. All stock options under this plan have terms not exceeding ten years and are issued at exercise prices not less than the fair market value on the date of grant. An aggregate of 30.6 million shares were reserved for issuance under the 2006 Plan. As of March 31, 2022, a total of 6.4 million shares were available for new awards under this plan.

[0001032975-22-000012:notes:151]
Time-based RSUs granted to employees under the 2006 Plan generally vest in three to four equal annual installments on the grant date anniversary. Time-based RSUs granted to non-executive board members under the 2006 Plan vest on the grant date anniversary, or if earlier and only if the non-executive board member is not re-elected as a director at such annual general meeting, the date of the next annual general meeting following the grant date.

[0001032975-22-000012:notes:152]
In fiscal years 2022, 2021 and 2020, the Company granted RSUs with both performance and market conditions, which vest at the end of the three-year performance period upon meeting predetermined financial metrics over three years, with the number of shares to be received upon vesting determined based on weighted average constant currency revenue growth rate and the Company's Total Shareholder Return ("TSR") relative to the performance of companies in the Russell 3000 Index for fiscal years 2022 and 2021 and NASDAQ-100 Index for fiscal year 2020 over the same three years period. The Company presents shares granted and vested at 100 percent of the target of the number of stock units that may potentially vest. The aggregate fair value of shares that

[0001032975-22-000012:notes:153]
actually vested during the year is based on the actual number of stock units vested during the year based on the achievement of the financial metrics over the performance period.

[0001032975-22-000012:notes:154]
Under the 2012 Plan, stock options and RSUs may be granted to eligible employees to serve as an inducement to enter into employment with the Company. Awards under the 2012 Plan may be conditioned on continued employment, the passage of time or the satisfaction of market stock performance criteria, based on individually written employment offer letter. An aggregate of 1.8 million shares were reserved for issuance under the 2012 Plan, and all of the reserved shares had been issued before the 2012 Plan expired on March 28, 2022.

[0001032975-22-000012:notes:155]
The estimates of share-based compensation expense require a number of complex and subjective assumptions including stock price volatility, employee exercise patterns, probability of achievement of the set performance condition, dividend yield, related tax effects and the selection of an appropriate fair value model.

[0001032975-22-000012:notes:156]
The grant date fair value of the awards using the Black-Scholes-Merton option-pricing valuation model and Monte-Carlo simulation method is determined with the following assumptions and values:

[0001032975-22-000012:notes:157]
|  |  | Stock Options |  | Employee Stock Purchase Plans |
|  |  | Years Ended March 31, |  | Years Ended March 31, |
|  |  | 2022 |  | 2021 |  | 2020 |  | 2022 |  | 2021 |  | 2020 |
| Dividend yield |  | 1.18 | % |  | * |  | * |  | 1.03 | % |  | 1.04 | % |  | 1.74 | % |
| Risk-free interest rate |  | 1.99 | % |  | * |  | * |  | 0.27 | % |  | 0.10 | % |  | 1.81 | % |
| Expected volatility |  | 34 | % |  | * |  | * |  | 35 | % |  | 47 | % |  | 24 | % |
| Expected life (years) |  | 6.2 |  | * |  | * |  | 0.5 |  | 0.5 |  | 0.5 |
| Weighted average grant date fair value per share |  | $ | 25.88 |  | * |  | * |  | $ | 23.55 |  | $ | 24.67 |  | $ | 9.35 |

[0001032975-22-000012:notes:158]
* Not applicable as no stock options were granted for fiscal year 2021 and 2020.

[0001032975-22-000012:notes:159]
| RSUs with Market Conditions |  | Years Ended March 31, |
|  |  | 2022 |  | 2021 |  | 2020 |
| Dividend yield |  | 0.78 | % |  | 1.24 | % |  | 1.76 | % |
| Risk-free interest rate |  | 0.31 | % |  | 0.21 | % |  | 2.11 | % |
| Expected volatility |  | 37 | % |  | 31 | % |  | 30 | % |
| Expected life (years) |  | 3.0 |  | 3.0 |  | 3.0 |

[0001032975-22-000012:notes:160]
The dividend yield assumption is based on the Company's history and future expectations of dividend payouts. The unvested RSUs or unexercised options are not eligible for these dividends. The expected life is based on the purchase offerings periods expected to remain outstanding for employee stock purchase plan, or the performance period for RSUs with market conditions. The expected life for stock options represents the estimated period of time until option exercise. Since the Company has limited historical stock option exercise experience, the Company used the simplified method in estimating the expected life, which is calculated as the average of the sum of the vesting term and the original contractual term of the stock options. Expected volatility is based on historical volatility using the Company's daily closing prices, or including the volatility of components of the NASDAQ 100 index or the Russell 3000 Index for market-based RSUs, over the expected life. The Company considers the historical price volatility of its shares as most representative of future volatility. The risk-free interest rate assumptions are based upon the implied yield of U.S. Treasury zero-coupon issues appropriate for the expected life of the Company's share-based awards.

[0001032975-22-000012:notes:161]
For RSUs with performance conditions, the Company estimates the probability and timing of the achievement of the set performance condition at the time of the grant based on the historical financial performance and the financial forecast in the remaining performance period and reassesses the probability in subsequent periods when actual results or new information become available.

[0001032975-22-000012:notes:162]
A summary of the Company's stock option activities under all stock plans for fiscal years 2022, 2021 and 2020 is as follows:

[0001032975-22-000012:notes:163]
|  |  | Number of Shares |  | Weighted-Average Exercise Price |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value |  |  |  |  |
|  |  | (In thousands) |  |  |  | (Years) |  | (In thousands) |  |  |  |  |
| Outstanding, March 31, 2019 |  | 2,607 |  |  |  |  |  |  |  |  |  |  |  |
| Exercised |  | (573) |  |  |  |  |  |  | $ | 19,339 |  |  |  |  |  |
| Canceled or expired |  | (65) |  |  |  |  |  |  |  |  |  |  |  |
| Outstanding, March 31, 2020 |  | 1,969 |  |  |  |  |  |  |  |  |  |  |  |
| Exercised |  | (1,347) |  |  |  |  |  |  | $ | 68,596 |  |  |  |  |  |
| Outstanding, March 31, 2021 |  | 622 |  |  | $ | 34 |  |  | 7.1 |  | $ | 43,625 |  |  |  |  |  |
| Granted |  | 842 |  |  | $ | 80 |  |  |  |  |  |  |  |  |  |
| Exercised |  | (71) |  |  | $ | 39 |  |  |  |  | $ | 5,573 |  |  |  |  |  |
| Outstanding, March 31, 2022 |  | 1,393 |  |  | $ | 62 |  |  | 8.3 |  | $ | 21,830 |  |  |  |  |  |
| Vested and exercisable, March 31, 2022 |  | 551 |  |  | $ | 34 |  |  | 6.0 |  | $ | 22,006 |  |  |  |  |  |

[0001032975-22-000012:notes:164]
As of March 31, 2022, the exercise price of outstanding options ranged from $8 to $80 per share option.

[0001032975-22-000012:notes:165]
The tax benefit realized for the tax deduction from options exercised during fiscal years 2022, 2021 and 2020 was $1.2 million, $0.6 million and $0.1 million, respectively.

[0001032975-22-000012:notes:166]
A summary of the Company's time-based, market-based and performance-based RSU activities for fiscal years 2022, 2021 and 2020 is as follows:

[0001032975-22-000012:notes:167]
|  |  | Number of Shares |  | Weighted-Average Grant Date Fair Value |  | Weighted-Average Remaining Vesting Period |  | Aggregate Fair Value |  |  |  |  |
|  |  | (In thousands) |  |  |  | (Years) |  | (In thousands) |  |  |  |  |
| Outstanding, March 31, 2019 |  | 4,421 |  |  | $ | 29 |  |  |  |  |  |  |  |  |  |
| Granted—time-based |  | 1,431 |  |  | $ | 38 |  |  |  |  |  |  |  |  |  |
| Granted—market and performance-based |  | 365 |  |  | $ | 40 |  |  |  |  |  |  |  |  |  |
| Vested |  | (1,705) |  |  |  |  |  |  | $ | 76,389 |  |  |  |  |  |
| Canceled or expired |  | (561) |  |  |  |  |  |  |  |  |  |  |  |
| Outstanding, March 31, 2020 |  | 3,951 |  |  | $ | 36 |  |  |  |  |  |  |  |  |  |
| Granted—time-based |  | 1,046 |  |  | $ | 60 |  |  |  |  |  |  |  |  |  |
| Granted—market and performance-based |  | 303 |  |  | $ | 67 |  |  |  |  |  |  |  |  |  |
| Vested |  | (1,444) |  |  |  |  |  |  | $ | 168,816 |  |  |  |  |  |
| Canceled or expired |  | (213) |  |  |  |  |  |  |  |  |  |  |  |
| Outstanding, March 31, 2021 |  | 3,643 |  |  | $ | 45 |  |  |  |  |  |  |  |  |  |
| Granted—time-based |  | 868 |  |  | $ | 103 |  |  |  |  |  |  |  |  |  |
| Granted—market and performance-based |  | 203 |  |  | $ | 124 |  |  |  |  |  |  |  |  |  |
| Vested |  | (1,463) |  |  | $ | 40 |  |  |  |  | $ | 133,977 |  |  |  |  |  |
| Canceled or expired |  | (205) |  |  | $ | 62 |  |  |  |  |  |  |  |  |  |
| Outstanding, March 31, 2022 |  | 3,046 |  |  | $ | 68 |  |  | 1.2 |  | $ | 233,797 |  |  |  |  |  |

[0001032975-22-000012:notes:168]
The RSUs outstanding as of March 31, 2022 above include 0.8 million shares with both market-based and performance-based vesting conditions.

[0001032975-22-000012:notes:169]
The tax benefit realized for the tax deduction from RSUs that vested during fiscal years 2022, 2021 and 2020 was $25.2 million, $16.3 million and $12.1 million, respectively.

[0001032975-22-000012:notes:170]
Defined Contribution Plans

[0001032975-22-000012:notes:171]
Certain of the Company's subsidiaries have defined contribution employee benefit plans covering all or a portion of their employees. Contributions to these plans are discretionary for certain plans and are based on specified or statutory requirements for others. The charges to expense for these plans for fiscal years 2022, 2021 and 2020, were $13.9 million, $10.6 million and $8.6 million, respectively.

[0001032975-22-000012:notes:172]
Defined Benefit Plans

[0001032975-22-000012:notes:173]
Certain of the Company's subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees' years of service and earnings, or in accordance with applicable employee benefit regulations. The Company's practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations.

[0001032975-22-000012:notes:174]
The Company recognizes the overfunded or underfunded status of defined benefit pension plans and non-retirement post-employment benefit obligations as an asset or liability in its consolidated balance sheets and recognizes changes in the funded status of defined benefit pension plans in the year in which the changes occur through accumulated other comprehensive income (loss), which is a component of shareholders' equity. Each plan's assets and benefit obligations are remeasured as of March 31 each year.

[0001032975-22-000012:notes:175]
The net periodic benefit cost of the defined benefit pension plans and the non-retirement post-employment benefit obligations for fiscal years 2022, 2021 and 2020 was as follows (in thousands):

[0001032975-22-000012:notes:176]
|  |  | Years Ended March 31, |
|  |  | 2022 |  | 2021 |  | 2020 |
| Service costs |  | $ | 14,693 |  |  | $ | 12,121 |  |  | $ | 11,008 |  |
| Interest costs |  | 920 |  |  | 1,047 |  |  | 1,055 |  |
| Expected return on plan assets |  | (2,930) |  |  | (2,535) |  |  | (2,616) |  |
| Amortization: |  |  |  |  |  |  |
| Net prior service credit recognized |  | (465) |  |  | (467) |  |  | (435) |  |
| Net actuarial loss (gain) recognized |  | (2,158) |  |  | 2,144 |  |  | 1,386 |  |
| Settlement |  | — |  |  | — |  |  | (97) |  |
| Total net periodic benefit cost |  | $ | 10,060 |  |  | $ | 12,310 |  |  | $ | 10,301 |  |

[0001032975-22-000012:notes:177]
The components of net periodic benefit cost other than the service costs component are included in other income (expense), net in the consolidated statements of operations.

[0001032975-22-000012:notes:178]
The changes in projected benefit obligations for fiscal years 2022 and 2021 were as follows (in thousands):

[0001032975-22-000012:notes:179]
|  |  | Years Ended March 31, |
|  |  | 2022 |  | 2021 |
| Projected benefit obligations, beginning of the year |  | $ | 202,348 |  |  | $ | 160,914 |  |
| Service costs |  | 14,693 |  |  | 12,121 |  |
| Interest costs |  | 920 |  |  | 1,047 |  |
| Plan participant contributions |  | 6,092 |  |  | 4,733 |  |
| Actuarial (gains) losses |  | (31,198) |  |  | 15,762 |  |
| Benefits paid |  | (3,904) |  |  | (3,947) |  |
| Transfer of prior vested benefits |  | 14,963 |  |  | 7,556 |  |
| Administrative expense paid |  | (130) |  |  | (130) |  |
| Currency exchange rate changes and other |  | 3,767 |  |  | 4,292 |  |
| Projected benefit obligations, end of the year |  | $ | 207,551 |  |  | $ | 202,348 |  |

[0001032975-22-000012:notes:180]
The accumulated benefit obligation for all defined benefit pension plans as of March 31, 2022 and 2021 was $178.5 million and $171.2 million, respectively.

[0001032975-22-000012:notes:181]
Actuarial gains related to the change in the benefit obligation for the Company's pension plans for fiscal year 2022 was primarily due to an increase in discount rate. Actuarial losses related to the change in benefit obligation for fiscal year 2021 was primarily due to the decrease in the discount rate.

[0001032975-22-000012:notes:182]
The following table presents the changes in the fair value of defined benefit pension plan assets for fiscal years 2022 and 2021 (in thousands):

[0001032975-22-000012:notes:183]
|  |  | Years Ended March 31, |
|  |  | 2022 |  | 2021 |
| Fair value of plan assets, beginning of the year |  | $ | 128,061 |  |  | $ | 98,010 |  |
| Actual return on plan assets |  | (2,156) |  |  | 11,706 |  |
| Employer contributions |  | 10,877 |  |  | 8,064 |  |
| Plan participant contributions |  | 6,092 |  |  | 4,733 |  |
| Benefits paid |  | (3,904) |  |  | (3,947) |  |
| Transfer of prior vested benefits |  | 14,963 |  |  | 7,556 |  |
| Administrative expenses paid |  | (130) |  |  | (130) |  |
| Currency exchange rate changes |  | 2,315 |  |  | 2,069 |  |
| Fair value of plan assets, end of the year |  | $ | 156,118 |  |  | $ | 128,061 |  |

[0001032975-22-000012:notes:184]
The Company's investment objectives are to ensure that the assets of its defined benefit plans are invested to provide an optimal rate of investment return on the total investment portfolio, consistent with the assumption of a reasonable risk level, and to ensure that pension funds are available to meet the plans' benefit obligations as they become due. The Company believes that a well-diversified investment portfolio will result in the highest attainable investment return with an acceptable level of overall risk. Investment strategies and allocation decisions are also governed by applicable governmental regulatory agencies. The Company's investment strategy with respect to its largest defined benefit plan, which is available only to Swiss employees, is to invest per the following allocation: 33% in equities, 28% in bonds, 28% in real estate, 4% in cash and cash equivalents and the remaining in other investments. The Company can invest in real estate funds, commodity funds, and hedge funds depending upon economic conditions.

[0001032975-22-000012:notes:185]
The following tables present the fair value of the defined benefit pension plan assets by major categories and by levels within the fair value hierarchy as of March 31, 2022 and 2021 (in thousands):

[0001032975-22-000012:notes:186]
|  |  | March 31, |
|  |  | 2022 |  | 2021 |
|  |  | Level 1 |  | Level 2 |  |  |  | Total |  | Level 1 |  | Level 2 |  |  |  | Total |
| Cash and cash equivalents |  | $ | 16,317 |  |  | $ | — |  |  |  |  | $ | 16,317 |  |  | $ | 21,715 |  |  | $ | — |  |  |  |  | $ | 21,715 |  |
| Equity securities |  | 48,591 |  |  | — |  |  |  |  | 48,591 |  |  | 38,437 |  |  | — |  |  |  |  | 38,437 |  |
| Debt securities |  | 38,513 |  |  | — |  |  |  |  | 38,513 |  |  | 31,034 |  |  | — |  |  |  |  | 31,034 |  |
| Real estate funds |  | 25,146 |  |  | 13,077 |  |  |  |  | 38,223 |  |  | 20,802 |  |  | 8,341 |  |  |  |  | 29,143 |  |
| Hedge funds |  | — |  |  | 8,076 |  |  |  |  | 8,076 |  |  | — |  |  | 2,730 |  |  |  |  | 2,730 |  |
| Other |  | 6,034 |  |  | 364 |  |  |  |  | 6,398 |  |  | 4,704 |  |  | 298 |  |  |  |  | 5,002 |  |
| Total fair value of plan assets |  | $ | 134,601 |  |  | $ | 21,517 |  |  |  |  | $ | 156,118 |  |  | $ | 116,692 |  |  | $ | 11,369 |  |  |  |  | $ | 128,061 |  |

[0001032975-22-000012:notes:187]
The funded status of the plans was as follows (in thousands):

[0001032975-22-000012:notes:188]
|  |  | Years Ended March 31, |
|  |  | 2022 |  | 2021 |
| Fair value of plan assets |  | $ | 156,118 |  |  | $ | 128,061 |  |
| Less: projected benefit obligations |  | 207,551 |  |  | 202,348 |  |
| Underfunded status |  | $ | (51,433) |  |  | $ | (74,287) |  |

[0001032975-22-000012:notes:189]
Amounts recognized on the balance sheet for the plans were as follows (in thousands):

[0001032975-22-000012:notes:190]
|  |  | March 31, |
|  |  | 2022 |  | 2021 |
| Current liabilities |  | $ | 1,677 |  |  | $ | 2,738 |  |
| Non-current liabilities |  | 49,756 |  |  | 71,549 |  |
| Total liabilities |  | $ | 51,433 |  |  | $ | 74,287 |  |

[0001032975-22-000012:notes:191]
Amounts recognized in accumulated other comprehensive loss related to defined benefit pension plans were as follows (in thousands):

[0001032975-22-000012:notes:192]
|  |  | March 31, |
|  |  | 2022 |  | 2021 |  | 2020 |
| Net prior service credits |  | $ | 2,883 |  |  | $ | 3,263 |  |  | $ | 3,647 |  |
| Net actuarial loss |  | (4,304) |  |  | (27,553) |  |  | (22,722) |  |
| Accumulated other comprehensive loss |  | (1,421) |  |  | (24,290) |  |  | (19,075) |  |
| Deferred taxes |  | (2,074) |  |  | 1,090 |  |  | (941) |  |
| Accumulated other comprehensive loss, net of tax |  | $ | (3,495) |  |  | $ | (23,200) |  |  | $ | (20,016) |  |

[0001032975-22-000012:notes:193]
The actuarial assumptions for the defined benefit plans were as follows:

[0001032975-22-000012:notes:194]
|  |  | Years Ended March 31, |
|  |  | 2022 |  | 2021 |  |
| Benefit Obligations: |  |  |  |  |  |
| Discount rate |  | 1.00% - 6.75% |  | 0.25% - 6.00% |  |
| Estimated rate of compensation increase |  | 2.00% - 10.00% |  | 2.00% - 10.00% |  |
| Cash balance interest credit rate |  | 0.00% - 1.75% |  | 0.00% - 1.75% |  |

[0001032975-22-000012:notes:195]
|  |  | Years Ended March 31, |
|  |  | 2022 |  | 2021 |  | 2020 |
| Periodic Costs: |  |  |  |  |  |  |
| Discount rate |  | 0.25% - 6.00% |  | 0.50% - 6.75% |  | 0.55% - 7.25% |
| Estimated rate of compensation increase |  | 2.00% - 10.00% |  | 2.25% - 10.00% |  | 2.50% - 10.00% |
| Expected average rate of return on plan assets |  | 1.00% - 2.25% |  | 1.00% - 2.50% |  | 0.89% - 3.00% |
| Cash balance interest credit rate |  | 0.00% - 1.75% |  | 0.00% - 1.75% |  | 1.75% - 2.00% |

[0001032975-22-000012:notes:196]
The discount rate is estimated based on corporate bond yields or securities of similar quality in the respective country, with a duration approximating the period over which the benefit obligations are expected to be paid. The Company bases the compensation increase assumptions on historical experience and future expectations. The expected average rate of return for the Company's defined benefit pension plans represents the average rate of return expected to be earned on plan assets over the period that the benefit obligations are expected to be paid, based on government bond notes in the respective country, adjusted for corporate risk premiums as appropriate.

[0001032975-22-000012:notes:197]
The following table reflects the benefit payments that the Company expects the plans to pay in the periods noted (in thousands):

[0001032975-22-000012:notes:198]
| Years Ending March 31, |  |  |
| 2023 |  | $ | 12,387 |  |
| 2024 |  | 12,700 |  |
| 2025 |  | 13,600 |  |
| 2026 |  | 12,546 |  |
| 2027 |  | 14,362 |  |
| Thereafter |  | 67,605 |  |
| Total expected benefit payments by the plan |  | $ | 133,200 |  |

[0001032975-22-000012:notes:199]
The Company expects to contribute $10.1 million to its defined benefit pension plans during fiscal year 2023.

[0001032975-22-000012:notes:200]
Deferred Compensation Plan

[0001032975-22-000012:notes:201]
One of the Company's subsidiaries offers a deferred compensation plan that permits eligible employees to make 100% vested salary and incentive compensation deferrals within established limits. The Company does not make contributions to the plan.

[0001032975-22-000012:notes:202]
The deferred compensation plan's assets consist of marketable securities and are included in other assets on the consolidated balance sheets. The marketable securities were recorded at a fair value of $28.4 million and $24.8 million  as of March 31, 2022 and 2021, respectively, based on quoted market prices. The Company also had $28.4 million and $24.8 million in deferred compensation liability as of March 31, 2022 and 2021, respectively. Earnings, gains and losses on deferred compensation investments are included in other income (expense), net and corresponding changes in deferred compensation liability are included in operating expenses and cost of goods sold.


## us-gaap:InterestAndOtherIncomeTextBlock

[0001032975-22-000012:notes:203]
Other Income (Expense), net
Other income (expense), net comprises of the following (in thousands):

[0001032975-22-000012:notes:204]
|  |  | Years Ended March 31, |
|  |  | 2022 |  | 2021 |  | 2020 |
| Investment gain (loss) related to the deferred compensation plan |  | $ | 1,231 |  |  | $ | 5,916 |  |  | $ | (831) |  |
| Currency exchange loss, net |  | (4,604) |  |  | (2,688) |  |  | (909) |  |
| Gain (loss) on investments, net (1) |  | (1,683) |  |  | (5,910) |  |  | 39,011 |  |
| Other (2) |  | 5,616 |  |  | 893 |  |  | 941 |  |
| Other income (expense), net |  | $ | 560 |  |  | $ | (1,789) |  |  | $ | 38,212 |  |

[0001032975-22-000012:notes:205]
(1) Includes realized gain (loss) on sales of investments, unrealized gain (loss) from the change in fair value of investments and gain (loss) on equity-method investments, as applicable. On March 2, 2020, the Company sold its $5.5 million investment, in a privately held company, for proceeds with a total fair value of $45.3 million consisting of cash, a subordinated note and an equity interest in another privately held company. As a result, the Company recognized a gain of $39.8 million related to the sale of this investment in fiscal year 2020.
(2) Includes the components of net periodic benefit cost of defined pension plans other than the service cost component (see Note 5).


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-22-000012:notes:206]
Income Taxes 
The Company is incorporated in Switzerland but operates in various countries with differing tax laws and rates. Further, a portion of the Company's income before taxes and the provision for (benefit from) income taxes is generated outside of Switzerland.

[0001032975-22-000012:notes:207]
Income from continuing operations before income taxes for fiscal years 2022, 2021 and 2020 is summarized as follows (in thousands):

[0001032975-22-000012:notes:208]
|  |  | Years Ended March 31, |
|  |  | 2022 |  | 2021 |  | 2020 |
| Swiss |  | $ | 579,258 |  |  | $ | 984,185 |  |  | $ | 238,303 |  |
| Non-Swiss |  | 196,560 |  |  | 163,935 |  |  | 86,023 |  |
| Income before taxes |  | $ | 775,818 |  |  | $ | 1,148,120 |  |  | $ | 324,326 |  |

[0001032975-22-000012:notes:209]
The provision for (benefit from) income taxes is summarized as follows (in thousands):

[0001032975-22-000012:notes:210]
|  |  | Years Ended March 31, |
|  |  | 2022 |  | 2021 |  | 2020 |
| Current: |  |  |  |  |  |  |
| Swiss |  | $ | 59,659 |  |  | $ | 121,199 |  |  | $ | 5,474 |  |
| Non-Swiss |  | 44,094 |  |  | 45,056 |  |  | 29,078 |  |
| Deferred: |  |  |  |  |  |  |
| Swiss |  | 29,198 |  |  | 31,558 |  |  | (153,210) |  |
| Non-Swiss |  | (1,646) |  |  | 3,050 |  |  | (6,739) |  |
| Provision for (benefit from) income taxes |  | $ | 131,305 |  |  | $ | 200,863 |  |  | $ | (125,397) |  |

[0001032975-22-000012:notes:211]
The difference between the provision for (benefit from) income taxes and the expected tax provision (tax benefit) at the statutory income tax rate of 8.5% is reconciled below (in thousands):

[0001032975-22-000012:notes:212]
|  |  | Years Ended March 31, |
|  |  | 2022 |  | 2021 |  | 2020 |
| Expected tax provision at statutory income tax rates |  | $ | 65,945 |  |  | $ | 97,590 |  |  | $ | 27,568 |  |
| Income taxes at different rates |  | 61,296 |  |  | 88,760 |  |  | (5,592) |  |
| Research and development tax credits |  | (5,957) |  |  | (3,844) |  |  | (4,692) |  |
| Executive compensation |  | 4,683 |  |  | 4,821 |  |  | 1,582 |  |
| Stock-based compensation |  | (9,141) |  |  | (3,161) |  |  | (2,735) |  |
| Deferred tax effects from TRAF |  | — |  |  | 1,944 |  |  | (206,792) |  |
| Valuation allowance |  | 887 |  |  | (247) |  |  | (538) |  |
| Restructuring charges / (credits) |  | — |  |  | (5) |  |  | 12 |  |
| Unrecognized tax benefits |  | 16,577 |  |  | 15,978 |  |  | 64,683 |  |
| Audit settlement |  | (3,655) |  |  | — |  |  | — |  |
| Other, net |  | 670 |  |  | (973) |  |  | 1,107 |  |
| Provision for (benefit from) income taxes |  | $ | 131,305 |  |  | $ | 200,863 |  |  | $ | (125,397) |  |

[0001032975-22-000012:notes:213]
Deferred income tax assets and liabilities consist of the following (in thousands):

[0001032975-22-000012:notes:214]
|  |  | March 31, |
|  |  | 2022 |  | 2021 |
| Deferred tax assets: |  |  |  |  |
| Tax attributes carryforward |  | $ | 34,736 |  |  | $ | 42,482 |  |
| Accruals |  | 88,060 |  |  | 79,884 |  |
| Depreciation and amortization |  | 585 |  |  | 1,628 |  |
| Tax step-up of goodwill from TRAF |  | 118,000 |  |  | 134,122 |  |
| Share-based compensation |  | 13,152 |  |  | 12,784 |  |
| Gross deferred tax assets |  | 254,533 |  |  | 270,900 |  |
| Valuation allowance |  | (29,858) |  |  | (28,926) |  |
| Deferred tax assets after valuation allowance |  | 224,675 |  |  | 241,974 |  |
| Deferred tax liabilities: |  |  |  |  |
| Acquired intangible assets and other |  | (33,008) |  |  | (32,789) |  |
| Deferred tax liabilities |  | (33,008) |  |  | (32,789) |  |
| Deferred tax assets, net |  | $ | 191,667 |  |  | $ | 209,185 |  |

[0001032975-22-000012:notes:215]
Included in tax attributes carryforward above are net operating loss and tax credit carryforwards.

[0001032975-22-000012:notes:216]
Management regularly assesses the ability to realize deferred tax assets recorded in the Company's entities based upon the weight of available evidence, including such factors as recent earnings history and expected future taxable income. In the event that the Company changes its determination as to the amount of deferred tax assets that can be realized, the Company will adjust its valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001032975-22-000012:notes:217]
The Company had a valuation allowance against deferred tax assets of $29.9 million at March 31, 2022, compared to $28.9 million at March 31, 2021. The Company had a valuation allowance of $29.7 million as of March 31, 2022 against deferred tax assets in the state of California, an increase from $28.5 million as of March 31, 2021 from activities during the year. The remaining valuation allowance primarily represents $0.2 million for various tax attribute carryforwards. The Company determined that it is more likely than not that the Company would not generate sufficient taxable income in the future to utilize such deferred tax assets.

[0001032975-22-000012:notes:218]
As of March 31, 2022, the Company had foreign net operating loss and tax credit carryforwards for income tax purposes of $81.9 million and $74.0 million, respectively. Unused net operating loss carryforwards will expire at various dates beginning in fiscal year 2029. Certain net operating loss carryforwards in the United States relate to acquisitions and, as a result, are limited in the amount that can be utilized in any one year. The tax credit carryforwards will begin to expire in fiscal year 2025.

[0001032975-22-000012:notes:219]
Swiss income taxes and non-Swiss withholding taxes associated with the repatriation of earnings or for other temporary differences related to investments in non-Swiss subsidiaries have not been provided for, as the Company intends to reinvest the earnings of such subsidiaries indefinitely. If these earnings were distributed to Switzerland in the form of dividends or otherwise, or if the shares of the relevant non-Swiss subsidiaries were sold or otherwise transferred, the Company may be subject to additional Swiss income taxes and non-Swiss withholding taxes. As of March 31, 2022, the cumulative amount of unremitted earnings of non-Swiss subsidiaries for which no income taxes have been provided is approximately $245.6 million. The amount of unrecognized deferred income tax liability related to these earnings is estimated to be approximately $6.0 million.

[0001032975-22-000012:notes:220]
The Company follows a two-step approach in recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon ultimate settlement.

[0001032975-22-000012:notes:221]
As of March 31, 2022 and 2021, the total amount of unrecognized tax benefits due to uncertain tax positions was $176.0 million and $160.3 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-22-000012:notes:222]
As of March 31, 2022 and 2021, the Company had $83.4 million and $59.2 million, respectively, in non-current income taxes payable, including interest and penalties, related to the Company's income tax liability for uncertain tax positions.

[0001032975-22-000012:notes:223]
The aggregate changes in gross unrecognized tax benefits in fiscal years 2022, 2021 and 2020 were as follows (in thousands).

[0001032975-22-000012:notes:224]
| March 31, 2019 |  | $ | 76,549 |  |
| Lapse of statute of limitations |  | (3,501) |  |
| Decreases in balances related to tax positions taken during prior years |  | (679) |  |
| Increases in balances related to tax positions taken during the year |  | 71,128 |  |
| March 31, 2020 |  | $ | 143,497 |  |
| Lapse of statute of limitations |  | (4,024) |  |
| Decreases in balances related to tax positions taken during prior years |  | — |  |
| Increases in balances related to tax positions taken during the year |  | 23,780 |  |
| March 31, 2021 |  | $ | 163,253 |  |
| Lapse of statute of limitations |  | (4,232) |  |
| Settlements with taxing authorities |  | (2,015) |  |
| Increases in balances related to tax positions taken during the year |  | 22,366 |  |
| March 31, 2022 |  | $ | 179,372 |  |

[0001032975-22-000012:notes:225]
Fiscal year 2020 includes gross unrecognized tax benefits recorded as a result of the enactment of the Tax Reform and AHV Financing ("TRAF") in Switzerland.

[0001032975-22-000012:notes:226]
The Company recognizes interest and penalties related to unrecognized tax positions in income tax expense. The Company recognized $1.5 million, $1.1 million, and $2.0 million in interest and penalties in income tax expense during fiscal years 2022, 2021 and 2020, respectively. As of March 31, 2022 and 2021, the Company had $3.6 million, and $4.9 million, respectively, of accrued interest and penalties related to uncertain tax positions.

[0001032975-22-000012:notes:227]
The Company files Swiss and foreign tax returns. The Company received final tax assessments in Switzerland through fiscal year 2019. For other material foreign jurisdictions such as the United States and China, the Company is generally not subject to tax examinations for years prior to fiscal year 2019 and calendar year 2019, respectively. In the United States, the federal and state tax agencies have the authority to examine periods prior to fiscal year 2019, to the extent allowed by law, where tax attributes were generated, carried forward, and being utilized in subsequent years. The Company is under examination in foreign tax jurisdictions. If the examinations are resolved unfavorably, there is a possibility they may have a material negative impact on its results of operations. In fiscal year 2022, uncertain tax positions decreased by $4.2 million from an effective settlement of an income tax audit in a foreign jurisdiction.
Although the Company has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During the next 12 months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. Dollar as compared to other currencies. Excluding these factors, uncertain tax positions may decrease by as much as $4.2 million primarily from the lapse of the statutes of limitations in various jurisdictions during the next 12 months.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-22-000012:notes:228]
Balance Sheet Components
The following table presents the components of certain balance sheet asset amounts as of March 31, 2022 and 2021 (in thousands):

[0001032975-22-000012:notes:229]
|  |  | March 31, |
|  |  | 2022 |  | 2021 |
| Accounts receivable, net: |  |  |  |  |
| Accounts receivable |  | $ | 964,766 |  |  | $ | 867,868 |  |
| Allowance for doubtful accounts |  | (2,212) |  |  | (1,161) |  |
| Allowance for sales returns |  | (12,321) |  |  | (14,438) |  |
| Allowance for cooperative marketing arrangements |  | (56,372) |  |  | (43,276) |  |
| Allowance for customer incentive programs |  | (97,460) |  |  | (76,200) |  |
| Allowance for pricing programs |  | (120,797) |  |  | (120,568) |  |
|  |  | $ | 675,604 |  |  | $ | 612,225 |  |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 226,155 |  |  | $ | 146,886 |  |
| Finished goods |  | 706,969 |  |  | 514,230 |  |
|  |  | $ | 933,124 |  |  | $ | 661,116 |  |
| Other current assets: |  |  |  |  |
| VAT receivables |  | $ | 58,850 |  |  | $ | 67,710 |  |
| Prepaid expenses and other assets |  | 76,628 |  |  | 67,940 |  |
|  |  | $ | 135,478 |  |  | $ | 135,650 |  |
| Property, plant and equipment, net: |  |  |  |  |
| Plant, buildings and improvements |  | $ | 68,477 |  |  | $ | 66,055 |  |
| Equipment and tooling |  | 268,164 |  |  | 244,962 |  |
| Computer equipment |  | 31,562 |  |  | 27,869 |  |
| Software |  | 72,391 |  |  | 56,087 |  |
|  |  | 440,594 |  |  | 394,973 |  |
| Less: accumulated depreciation and amortization |  | (349,606) |  |  | (303,460) |  |
|  |  | 90,988 |  |  | 91,513 |  |
| Construction-in-process |  | 15,915 |  |  | 19,637 |  |
| Land |  | 2,904 |  |  | 2,910 |  |
|  |  | $ | 109,807 |  |  | $ | 114,060 |  |
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 193,629 |  |  | $ | 210,888 |  |
| Right-of-use assets |  | 40,661 |  |  | 31,169 |  |
| Investments for deferred compensation plan |  | 28,431 |  |  | 24,809 |  |
| Investments in privately held companies |  | 43,068 |  |  | 43,402 |  |
| Other assets |  | 14,933 |  |  | 13,980 |  |
|  |  | $ | 320,722 |  |  | $ | 324,248 |  |

[0001032975-22-000012:notes:230]
The following table presents the components of certain balance sheet liability amounts as of March 31, 2022 and 2021 (in thousands):

[0001032975-22-000012:notes:231]
|  |  | March 31, |
|  |  | 2022 |  | 2021 |
| Accrued and other current liabilities: |  |  |  |  |
| Accrued customer marketing, pricing and incentive programs |  | $ | 232,393 |  |  | $ | 185,394 |  |
| Accrued personnel expenses |  | 165,090 |  |  | 173,360 |  |
| Accrued sales return liability |  | 40,507 |  |  | 43,178 |  |
| VAT payable |  | 39,602 |  |  | 50,620 |  |
| Income taxes payable |  | 35,355 |  |  | 131,408 |  |
| Warranty accrual |  | 32,987 |  |  | 33,228 |  |
| Accrued payables - non-inventory |  | 26,722 |  |  | 52,392 |  |
| Operating lease liabilities |  | 13,690 |  |  | 13,101 |  |
| Contingent consideration |  | 8,042 |  |  | 6,967 |  |
| Other current liabilities |  | 190,460 |  |  | 168,969 |  |
|  |  | $ | 784,848 |  |  | $ | 858,617 |  |
| Other non-current liabilities: |  |  |  |  |
| Employee benefit plan obligations |  | $ | 50,741 |  |  | $ | 72,321 |  |
| Obligation for deferred compensation plan |  | 28,431 |  |  | 24,809 |  |
| Operating lease liabilities |  | 28,207 |  |  | 21,319 |  |
| Warranty accrual |  | 13,232 |  |  | 15,604 |  |
| Contingent consideration |  | 4,217 |  |  | — |  |
| Deferred tax liabilities |  | 1,962 |  |  | 1,679 |  |
| Other non-current liabilities |  | 5,343 |  |  | 3,770 |  |
|  |  | $ | 132,133 |  |  | $ | 139,502 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-22-000012:notes:232]
Fair Value Measurements
The Company considers fair value as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants at the measurement date. The Company utilizes the following three-level fair value hierarchy to establish the priorities of the inputs used to measure fair value:

[0001032975-22-000012:notes:233]
•Level 1—Quoted prices in active markets for identical assets or liabilities.

[0001032975-22-000012:notes:234]
•Level 2—Observable inputs other than quoted market prices included in Level 1, such as quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active; or other inputs that are observable or can be corroborated by observable market data.

[0001032975-22-000012:notes:235]
•Level 3—Unobservable inputs that are supported by little or no market activity and that are significant to the fair value of the assets or liabilities. This includes certain pricing models, discounted cash flow methodologies and similar techniques that use significant unobservable inputs.

[0001032975-22-000012:notes:236]
The following table presents the Company's financial assets and liabilities that were accounted for at fair value on a recurring basis, excluding assets related to the Company's defined benefit pension plans, classified by the level within the fair value hierarchy (in thousands):

[0001032975-22-000012:notes:237]
|  |  | March 31, 2022 |  | March 31, 2021 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 762,055 |  |  | $ | — |  |  | $ | — |  |  | $ | 669,759 |  |  | $ | — |  |  | $ | — |  |
| Investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 108 |  |  | $ | — |  |  | $ | — |  |  | $ | 31 |  |  | $ | — |  |  | $ | — |  |
| Common stock |  | 2,329 |  |  | — |  |  | — |  |  | 1,569 |  |  | — |  |  | — |  |
| Money market funds |  | 6,765 |  |  | — |  |  | — |  |  | 6,734 |  |  | — |  |  | — |  |
| Mutual funds |  | 19,229 |  |  | — |  |  | — |  |  | 16,475 |  |  | — |  |  | — |  |
| Total of investments for deferred compensation plan |  | $ | 28,431 |  |  | $ | — |  |  | $ | — |  |  | $ | 24,809 |  |  | $ | — |  |  | $ | — |  |
| Currency derivative assets included in other current assets |  | $ | — |  |  | $ | 1,517 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,452 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration included in accrued and other current liabilities |  | $ | — |  |  | $ | — |  |  | $ | 8,042 |  |  | $ | — |  |  | $ | — |  |  | $ | 6,430 |  |
| Contingent consideration included in other non-current liabilities |  | $ | — |  |  | $ | — |  |  | $ | 3,971 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Currency derivative liabilities included in accrued and other current liabilities |  | $ | — |  |  | $ | 165 |  |  | $ | — |  |  | $ | — |  |  | $ | 100 |  |  | $ | — |  |

[0001032975-22-000012:notes:238]
The following table summarizes the change in the fair value of the Company's contingent consideration balance during fiscal year 2022 and 2021 (in thousands):

[0001032975-22-000012:notes:239]
|  | Year Ended March 31, |
|  | 2022 |  | 2021 |
| Contingent consideration, beginning of the year | $ | 6,967 |  |  | $ | 23,284 |  |
| Fair value of contingent consideration upon acquisition (1) | 9,973 |  | 6,430 |  |
| Change in fair value of contingent consideration | (3,509) |  |  | 5,716 |  |
| Settlements of contingent consideration (2) | (1,172) |  | (28,463) |  |
| Contingent consideration, end of the year | $ | 12,259 |  |  | $ | 6,967 |  |

[0001032975-22-000012:notes:240]
(1) The amount for fiscal year 2022 relates to the technology acquisition in fiscal year 2022. The amount for fiscal year 2021 relates to the Mevo acquisition and the other technology acquisition in fiscal year 2021. See Contingent Consideration for Business Acquisition section below for more information.

[0001032975-22-000012:notes:241]
(2) As of June 30, 2020, the earn-out period was completed in connection with the Company's acquisition of Streamlabs as disclosed below. The fair value of contingent consideration of $29.0 million as of June 30, 2020 is based on the actual net sales of Streamlabs services during the earn-out period and is no longer subject to fair value measurement and was accordingly transferred out of Level 3. During the third quarter of fiscal year 2021, $28.5 million of the contingent consideration was transferred from other current liabilities to equity upon settlement of the contingent consideration through the issuance of shares out of treasury stock. During the fourth quarter of fiscal year 2022, an additional $0.3 million of the contingent consideration was transferred from other current liabilities to equity upon settlement of the contingent consideration through the issuance of shares out of treasury stock. The remaining $0.2 million is held back in escrow for claims made against the escrow and for the payment of taxes.

[0001032975-22-000012:notes:242]
Investments for Deferred Compensation Plan

[0001032975-22-000012:notes:243]
The marketable securities for the Company's deferred compensation plan are recorded at a fair value of $28.4 million and $24.8 million as of March 31, 2022 and 2021, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized gains related to marketable securities for fiscal years 2022, 2021 and 2020 are included in other income (expense), net in the consolidated statements of operations (see Note 6).

[0001032975-22-000012:notes:244]
Contingent Consideration for Business Acquisitions

[0001032975-22-000012:notes:245]
The contingent consideration arising from the technology acquisition on May 19, 2021 (see Note 3) represents the future potential earn-out payments of up to $10.0 million payable in cash upon the achievement of three technical development milestones required to be completed as of December 31, 2021, June 30, 2022, and June 30, 2023. The fair value of the contingent consideration as of the acquisition date was $10.0 million, which was determined using a probability-weighted expected payment model and discounted at the estimated cost of debt. During the third quarter of fiscal year 2022, $0.9 million of the contingent consideration was released from other current liabilities upon cash settlement of the contingent consideration for the first technical development milestone.

[0001032975-22-000012:notes:246]
The contingent consideration arising from the Mevo Acquisition on February 17, 2021 (see Note 3) represents the future potential earn-out payments of up to $17.0 million payable in cash only upon the achievement of certain net sales for the period beginning on December 26, 2020 and ending on December 31, 2021. The fair value of the contingent consideration as of the acquisition date was $3.4 million, which was determined by using a Black-Scholes-Merton valuation model to calculate the probability of the earn-out threshold being met, times the value of the earn-out payment, and discounted at the risk-free rate. The valuation included significant assumptions and unobservable inputs such as the projected sales of Mevo over the earn-out period, risk-free rate, and the net sales volatility. Projected sales were based on the Company's internal projections, including analysis of the target market and historical sales of Mevo products. As of March 31, 2021 the fair value of the contingent consideration remained as $3.4 million. As of December 31, 2021, the fair value of the contingent consideration was released from other current liabilities as the net sales milestone was not achieved upon completion of the earn-out period.

[0001032975-22-000012:notes:247]
The contingent consideration arising from the technology acquisition on January 4, 2021 (see Note 3) represents the future potential earn-out payments of up to $3.0 million payable in cash upon the achievement of two technical development milestones required to be completed as of December 31, 2021 and March 31, 2022. The fair value of the contingent consideration was determined using a probability-weighted expected payment model and discounted at the estimated cost of debt. The contingent consideration is expected to be paid in the first two quarters of fiscal year 2023.

[0001032975-22-000012:notes:248]
In connection with the acquisition of Streamlabs on October 31, 2019 (see Note 3), the Company agreed to pay a total earn out payment of $29.0 million, payable in stock, only upon the achievement of certain net revenues for the period beginning on January 1, 2020 and ending on June 30, 2020. The fair value of the contingent consideration as of the acquisition date was $0.04 million, and increased to $23.3 million as of March 31, 2020, which was determined by using a Black-Scholes-Merton valuation model to calculate the probability of the earn-out threshold being met, times the value of the earn-out payment, and discounted at the risk-free rate. The fair value was increased by $5.7 million to $29.0 million as of June 30, 2020, based on actual sales. During the third quarter of fiscal year 2021 and the fourth quarter of fiscal year 2022, the Company issued 390,397 and 4,010 shares, respectively, out of treasury stock to former security holders of Streamlabs, in satisfaction of payment of the contingent consideration that was earned during the earn-out period. The issuances of such shares were deemed to be exempt from registration under the Securities Act of 1933 (the "Securities Act"), in reliance on Regulation D of the Securities Act as transactions by an issuer not involving a public offering.

[0001032975-22-000012:notes:249]
Although the estimate of contingent consideration is based on management’s best knowledge of current events, the estimate could change significantly from period to period. Actual results that differ from the assumptions used and any changes to the significant assumptions and unobservable inputs used could have a material impact on future results of operations.

[0001032975-22-000012:notes:250]
Equity Method Investments

[0001032975-22-000012:notes:251]
The Company has certain non-marketable investments included in other assets that are accounted for under the equity method of accounting, with a carrying value of $40.2 million and $40.7 million as of March 31, 2022 and 2021, respectively. Unrealized gains (losses) related to equity investments for fiscal years 2022, 2021 and 2020 are included in other income (expense), net in the Company's consolidated statements of operations. There was no impairment of these assets during fiscal years 2022, 2021 and 2020.

[0001032975-22-000012:notes:252]
On March 2, 2020, the Company sold its $5.5 million investment, in a privately held company, for proceeds with a total fair value of $45.3 million consisting of cash, a 6% subordinated note due in five years, and a Series A preferred units and Series B common units in Marlin-SL Topco, LP ("Marlin"). As of March 31, 2022, the investment represents an ownership interest of approximately 8.9% in Marlin.

[0001032975-22-000012:notes:253]
The Company has evaluated whether Marlin qualifies as a variable interest entity ("VIE") pursuant to the accounting guidance of ASC 810, Consolidations. On the basis that the total equity investment in Marlin may not be sufficient to absorb its expected losses, the Company concluded that Marlin is currently a VIE. However, considering the Company's minority interest and limited involvement with the Marlin business, the Company concluded it is not required to consolidate Marlin. Rather, the Company accounts for this investment under the equity method as it represents an ownership interest in a limited partnership that is more than minor. The promissory note is accounted for as a loan receivable and is included in other assets in the consolidated balance sheets.

[0001032975-22-000012:notes:254]
The Company's maximum exposure to any losses incurred by Marlin is limited to its investment. As of March 31, 2022 and 2021, the carrying value of the investment in Marlin was $21.4 million and $26.7 million, respectively. The Company's investment related to this VIE was not individually significant to the Company's consolidated financial statements.

[0001032975-22-000012:notes:255]
Assets Measured at Fair Value on a Nonrecurring Basis

[0001032975-22-000012:notes:256]
Financial Assets. The Company has certain investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with the same or similar security from the same issuer. The amount of these investments included in other assets was not material as of March 31, 2022 and 2021. There is no impairment recorded in fiscal year 2022. During fiscal year 2021, the Company recorded impairment charges of $2.0 million for its equity securities without readily determinable fair values, which had an initial cost basis of $2.0 million, as it was determined the carrying value of the investments were not recoverable.

[0001032975-22-000012:notes:257]
Non-Financial Assets. Goodwill, intangible assets, and property, plant and equipment, are not required to be measured at fair value on a recurring basis. However, if certain triggering events occur (or tested at least annually for goodwill) such that a non-financial instrument is required to be evaluated for impairment and an impairment is recorded to reduce the non-financial instrument's carrying value to the fair value as a result of such triggering events, the non-financial assets and liabilities are measured at fair value during such period. See Note 2 for additional information about how the Company tests various asset classes for impairment. During the year ended March 31, 2022, the Company recorded impairment charges of $7.0 million for the Jaybird-related intangible assets (see Note 11).


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-22-000012:notes:258]
Derivative Financial Instruments
 Under certain agreements with the respective counterparties to the Company's derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis in other current assets or accrued and other current liabilities on the consolidated balance sheets as of March 31, 2022 and 2021.

[0001032975-22-000012:notes:259]
See Note 9 for the fair values of the Company’s derivative instruments as of March 31, 2022 or 2021. The following table presents the amounts of gains and losses on the Company's derivative instruments designated as hedging instruments for fiscal years 2022, 2021 and 2020 and their locations on its consolidated statements of operations and consolidated statements of comprehensive income (in thousands):

[0001032975-22-000012:notes:260]
|  | Amount ofGain (Loss) Deferred asa Component ofAccumulated OtherComprehensive Loss |  | Amount of Loss (Gain)Reclassified fromAccumulated OtherComprehensive Lossto Costs of Goods Sold |  |  |
|  | 2022 |  | 2021 |  | 2020 |  | 2022 |  | 2021 |  | 2020 |  |  |  |  |  |  |
| Designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash flow hedges | $ | 6,308 |  | $ | (4,071) |  |  | $ | 205 |  |  | $ | (8,221) |  |  | $ | 8,043 |  |  | $ | (813) |  |  |  |  |  |  |  |

[0001032975-22-000012:notes:261]
The Company presents the earnings impact from forward points in the same line item that is used to present the earnings impact of the hedged item, i.e. cost of goods sold, for hedging forecasted inventory purchases and such amount is not material for all periods presented.

[0001032975-22-000012:notes:262]
Cash Flow Hedges: The Company enters into cash flow hedge contracts to protect against exchange rate exposure of forecasted inventory purchases. These hedging contracts mature within four months. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive income (loss) until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Cash flows from such hedges are classified as operating activities in the consolidated statements of cash flows. Hedging relationships are discontinued when hedging contract is no longer eligible for hedge accounting, or is sold, terminated or exercised, or when the Company removes hedge designation for the contract. Gains and losses in the fair value of the effective portion of the discontinued hedges continue to be reported in accumulated other comprehensive loss until the hedged inventory purchases are sold, unless it is probable that the forecasted inventory purchases will not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. As of March 31, 2022 and 2021, the notional amounts of foreign currency exchange forward contracts outstanding related to forecasted inventory purchases were $125.4 million and $164.5 million, respectively. The Company estimates that $1.8 million of net gain related to its cash flow hedges included in accumulated other comprehensive loss as of March 31, 2022 will be reclassified into earnings within the next twelve months.

[0001032975-22-000012:notes:263]
Other Derivatives: The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within a month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are recognized in other income (expense), net in the consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of March 31, 2022 and 2021 were $226.5 million and $123.8 million, respectively. Open forward and swap contracts as of March 31, 2022 and 2021 consisted of contracts in Japanese Yen, Australian Dollars, Canadian Dollars, Mexican Pesos, and Taiwanese Dollars to be settled at future dates at pre-determined exchange rates. Open forward and swap contracts outstanding as of March 31, 2022 additionally consisted of contracts in Chinese Renminbi and Brazilian Real to be settled at future dates at pre-determined exchange rates.

[0001032975-22-000012:notes:264]
The fair value of all foreign currency exchange forward and swap contracts is determined based on observable market transactions of spot currency rates and forward rates. Cash flows from these contracts are classified as operating activities in the consolidated statements of cash flows.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-22-000012:notes:265]
Goodwill and Other Intangible Assets
The Company conducts its impairment analysis of goodwill and indefinite life intangible assets annually at December 31 or more frequently if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting unit may be less than its carrying amount. The Company conducted its annual impairment analysis of goodwill and indefinite life intangible assets as of December 31, 2021 by performing a qualitative assessment and concluded that it was more likely than not that the fair value of its reporting unit exceeded its carrying amount. In assessing the qualitative factors, the Company considered the impact of these key factors: change in industry and competitive environment, growth in market capitalization, and budgeted-to-actual revenue performance for the twelve months ended December 31, 2021. There have been no triggering events identified affecting the valuation of goodwill and indefinite life intangible assets subsequent to the annual impairment test.

[0001032975-22-000012:notes:266]
The following table summarizes the activities in the Company's goodwill balance (in thousands):

[0001032975-22-000012:notes:267]
|  |  | Years Ended March 31, |
|  |  | 2022 |  | 2021 |
| Beginning of the period |  | $ | 429,604 |  |  | $ | 400,917 |  |
| Acquisitions (1) |  | 20,721 |  |  | 28,667 |  |
| Effects of foreign currency translation |  | (2,150) |  |  | 20 |  |
| End of the period |  | $ | 448,175 |  |  | $ | 429,604 |  |

[0001032975-22-000012:notes:268]
(1) See Note 3 for more information related to acquisitions.

[0001032975-22-000012:notes:269]
The Company's acquired intangible assets were as follows (in thousands):

[0001032975-22-000012:notes:270]
|  |  | March 31, |
|  |  | 2022 |  | 2021 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademarks and trade names |  | $ | 36,790 |  |  | $ | (22,295) |  |  | $ | 14,495 |  |  | $ | 46,070 |  |  | $ | (25,153) |  |  | $ | 20,917 |  |
| Developed technology |  | 119,407 |  |  | (83,540) |  |  | 35,867 |  |  | 134,406 |  |  | (90,450) |  |  | 43,956 |  |
| Customer contracts/relationships |  | 71,110 |  |  | (40,971) |  |  | 30,139 |  |  | 91,010 |  |  | (44,261) |  |  | 46,749 |  |
| In-process R&D |  | 3,826 |  |  | — |  |  | 3,826 |  |  | 3,526 |  |  | — |  |  | 3,526 |  |
| Effects of foreign currency translation (1) |  | (634) |  |  | 86 |  |  | (548) |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 230,499 |  |  | $ | (146,720) |  |  | $ | 83,779 |  |  | $ | 275,012 |  |  | $ | (159,864) |  |  | $ | 115,148 |  |

[0001032975-22-000012:notes:271]
(1) Related to a technology acquisition in May 2021. See Note 3 for more information related to the acquisition.

[0001032975-22-000012:notes:272]
During the third quarter of fiscal year 2022, the Company decided to discontinue Jaybird-branded products. As a result of this decision, the Company performed an analysis to compare the fair value of Jaybird-related intangible assets to their carrying amount. As the fair value using estimated discounted cash flows was less than the carrying amount, the Company recognized a pre-tax impairment charge in the consolidated statement of operations of $7.0 million, which was primarily related to customer contracts and relationships. See Note 16 for further information regarding the exit plan.

[0001032975-22-000012:notes:273]
For fiscal years 2022, 2021 and 2020, amortization expense for intangible assets was, $30.2 million, $31.8 million and $30.9 million, respectively. The Company expects that annual amortization expense for fiscal years 2023, 2024, 2025, 2026 and 2027 will be $23.2 million, $19.9 million, $17.7 million, $10.7 million and $4.5 million, respectively, and $4.0 million thereafter.

[0001032975-22-000012:notes:274]
The intangible assets as of March 31, 2022 and 2021 include IPR&D $3.8 million and $3.5 million, respectively, from asset acquisitions. IPR&D is capitalized at fair value and the amortization commences upon completion of the underlying projects. Once research and development efforts are completed, the corresponding amount of IPR&D is reclassified as an amortizable purchased intangible asset and is amortized over its estimated useful life. As of March 31, 2022 and 2021, there was no IPR&D amortized.


## us-gaap:DebtDisclosureTextBlock

[0001032975-22-000012:notes:275]
Financing ArrangementsThe Company had several uncommitted, unsecured bank lines of credit aggregating $195.0 million and $143.2 million as of March 31, 2022 and 2021, respectively. There are no financial covenants under these lines of credit with which the Company must comply. As of March 31, 2022 and 2021, the Company had outstanding bank guarantees of $25.5 million and $91.3 million, respectively, under these lines of credit. There was no borrowing outstanding under these lines of credit as of March 31, 2022 and 2021.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-22-000012:notes:276]
Commitments and Contingencies
Product Warranties

[0001032975-22-000012:notes:277]
Changes in the Company's warranty liability for fiscal years 2022 and 2021 were as follows (in thousands):

[0001032975-22-000012:notes:278]
|  |  | Years Ended March 31, |
|  |  | 2022 |  | 2021 |
| Beginning of the period |  | $ | 48,832 |  |  | $ | 40,039 |  |
| Assumed from business acquisition |  | — |  |  | 231 |  |
| Provision |  | 29,812 |  |  | 38,463 |  |
| Settlements |  | (32,082) |  |  | (30,621) |  |
| Effects of foreign currency translation |  | (343) |  |  | 720 |  |
| End of the period |  | $ | 46,219 |  |  | $ | 48,832 |  |

[0001032975-22-000012:notes:279]
Indemnifications

[0001032975-22-000012:notes:280]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys' fees. As of March 31, 2022, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-22-000012:notes:281]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-22-000012:notes:282]
Legal Proceedings

[0001032975-22-000012:notes:283]
From time to time the Company is involved in claims and legal proceedings which arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial position, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial position, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-22-000012:notes:284]
Shareholders' Equity
Share Capital

[0001032975-22-000012:notes:285]
The Company's nominal share capital is CHF 43.3 million, consisting of 173,106,620 issued shares with a par value of CHF 0.25 each, of which 7,854,600 were held in treasury shares as of March 31, 2022.

[0001032975-22-000012:notes:286]
The Company has reserved conditional capital of 25,000,000 shares for potential issuance on the exercise of rights granted under the Company's employee equity incentive plans and additional conditional capital for financing

[0001032975-22-000012:notes:287]
purposes, representing the issuance of up to 25,000,000 shares to cover any conversion rights under a future convertible bond issuance. At the 2020 Annual General Meeting, the shareholders of the Company authorized the Board of Directors to issue up to an additional 17,310,662 shares of the Company until September 9, 2022.

[0001032975-22-000012:notes:288]
Dividends

[0001032975-22-000012:notes:289]
Pursuant to Swiss corporate law, the payment of dividends is limited to certain amounts of unappropriated retained earnings (approximately CHF 1.7 billion, or $1.8 billion as of March 31, 2022) and is subject to shareholder approval.

[0001032975-22-000012:notes:290]
In May 2022, the Board of Directors recommended that the Company pay cash dividends for fiscal year 2022 of approximately CHF 0.96 per share (USD equivalent of approximately $1.04 per share, which would result in a gross aggregate dividend of $172.1 million, based on the exchange rate and shares outstanding, net of treasury shares, on March 31, 2022).

[0001032975-22-000012:notes:291]
In September 2021, the Company paid gross cash dividends of CHF 0.87 (USD equivalent of $0.95) per common share, totaling $159.4 million in U.S. Dollars, on the Company's outstanding common stock. In September 2020, the Company paid gross cash dividends of CHF 0.79 (USD equivalent of $0.87) per common share, totaling $146.7 million in U.S. Dollars, on the Company’s outstanding common stock. In September 2019, the Company paid gross cash dividends of CHF 0.73 (USD equivalent of $0.74) per common share, totaling $124.2 million in U.S. Dollars, on the Company's outstanding common stock.

[0001032975-22-000012:notes:292]
Any future dividends will be subject to the approval of the Company's shareholders.

[0001032975-22-000012:notes:293]
Legal Reserves

[0001032975-22-000012:notes:294]
Under Swiss corporate law, a minimum of 5% of the Company's annual net income must be retained in a legal reserve until this legal reserve equals 20% of the Company's issued and outstanding aggregate par value per share capital. These legal reserves represent an appropriation of retained earnings that are not available for distribution and totaled $10.4 million at March 31, 2022 (based on the exchange rate at March 31, 2022).

[0001032975-22-000012:notes:295]
Share Repurchases

[0001032975-22-000012:notes:296]
In March 2017, the Company's Board of Directors approved the 2017 share repurchase program, which authorizes the Company to use up to $250.0 million to purchase up to 17.3 million of Logitech shares. This share repurchase program expired in April 2020.

[0001032975-22-000012:notes:297]
In May 2020, the Company's Board of Directors approved the 2020 share repurchase program, which authorized the Company to use up to $250.0 million to purchase up to 17.3 million of Logitech shares. The Company's share repurchase program is expected to remain in effect for a period of three years through July 27, 2023. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. In April 2021, the Company's Board of Directors approved an increase of $750.0 million of the 2020 share repurchase program, to an aggregate amount of $1.0 billion. The Swiss Takeover Board approved this increase and it became effective on May 21, 2021. As of March 31, 2022, $423.7 million was available for repurchase under the 2020 repurchase program.

[0001032975-22-000012:notes:298]
A summary of the approved and active share repurchase program during fiscal year 2022 is shown in the following table (in thousands, excluding transaction costs):

[0001032975-22-000012:notes:299]
|  |  | Approved |  | Repurchased |
| Share Repurchase Program |  | Shares (1) |  | Amounts |  | Shares |  | Amounts |
| May 2020 |  | 17,311 |  |  | $ | 1,000,000 |  |  | 6,452 |  |  | $ | 576,303 |  |

[0001032975-22-000012:notes:300]
(1) The approval of each of the share repurchase programs by the Swiss Takeover Board limits the number of shares that the Company may repurchase to no more than 10% of its authorized share capital and voting rights.

[0001032975-22-000012:notes:301]
Accumulated Other Comprehensive Loss

[0001032975-22-000012:notes:302]
The components of accumulated other comprehensive loss were as follows (in thousands):

[0001032975-22-000012:notes:303]
|  |  | Accumulated Other Comprehensive Income (Loss) |
|  |  | Currency TranslationAdjustment |  | DefinedBenefitPlans |  | DeferredHedgingGains (Losses) |  | Total |
| March 31, 2021 |  | $ | (89,461) |  |  | $ | (23,200) |  |  | $ | 3,746 |  |  | $ | (108,915) |  |
| Other comprehensive income (loss) |  | (13,000) |  |  | 19,705 |  |  | (1,913) |  |  | 4,792 |  |
| March 31, 2022 |  | $ | (102,461) |  |  | $ | (3,495) |  |  | $ | 1,833 |  |  | $ | (104,123) |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-22-000012:notes:304]
Segment Information
The Company operates in a single operating segment that encompasses the design, manufacturing and marketing of peripherals for PCs, tablets and other digital platforms. Operating performance measures are provided directly to the Company's CEO, who is considered to be the Company’s Chief Operating Decision Maker. The CEO periodically reviews information such as sales and adjusted operating income (loss) to make business decisions. These operating performance measures do not include restructuring charges (credits), net, share-based compensation expense, amortization and impairment of intangible assets, acquisition-related costs and change in fair value of contingent consideration from business acquisition.

[0001032975-22-000012:notes:305]
Sales by product categories and sales channels, excluding intercompany transactions were as follows (in thousands):

[0001032975-22-000012:notes:306]
|  |  | Years Ended March 31, |
|  |  | 2022 |  | 2021 |  | 2020 |
| Pointing Devices |  | $ | 781,108 |  |  | $ | 680,907 |  |  | $ | 544,519 |  |
| Keyboards & Combos |  | 967,301 |  |  | 784,488 |  |  | 571,720 |  |
| PC Webcams |  | 403,651 |  |  | 439,865 |  |  | 129,193 |  |
| Tablet & Other Accessories |  | 310,123 |  |  | 384,301 |  |  | 135,309 |  |
| Gaming (1) |  | 1,451,883 |  |  | 1,239,005 |  |  | 690,174 |  |
| Video Collaboration |  | 997,164 |  |  | 1,044,935 |  |  | 365,616 |  |
| Mobile Speakers |  | 149,782 |  |  | 174,895 |  |  | 221,791 |  |
| Audio & Wearables |  | 401,424 |  |  | 468,776 |  |  | 273,752 |  |
| Smart Home |  | 18,463 |  |  | 34,394 |  |  | 43,404 |  |
| Other (2) |  | 202 |  |  | 713 |  |  | 373 |  |
| Total Sales |  | $ | 5,481,101 |  |  | $ | 5,252,279 |  |  | $ | 2,975,851 |  |

[0001032975-22-000012:notes:307]
(1) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-22-000012:notes:308]
(2) Other includes products that the Company phased out because they are no longer strategic to the Company's business.

[0001032975-22-000012:notes:309]
Sales by geographic region (based on the customers' locations) for fiscal years 2022, 2021 and 2020 were as follows (in thousands):

[0001032975-22-000012:notes:310]
|  |  | Years Ended March 31, |
|  |  | 2022 |  | 2021 |  | 2020 |
| Americas |  | $ | 2,317,941 |  |  | $ | 2,206,552 |  |  | $ | 1,286,527 |  |
| EMEA |  | 1,724,027 |  |  | 1,735,682 |  |  | 941,211 |  |
| Asia Pacific |  | 1,439,133 |  |  | 1,310,045 |  |  | 748,113 |  |
| Total Sales |  | $ | 5,481,101 |  |  | $ | 5,252,279 |  |  | $ | 2,975,851 |  |

[0001032975-22-000012:notes:311]
Revenues from sales to customers in the United States represented 34%, 35% and 36% of sales in fiscal years 2022, 2021 and 2020, respectively. Revenues from sales to customers in Germany represented 15%, 16% and 15% of sales in fiscal years 2022, 2021 and 2020, respectively. Revenues from sales to customers in China represented 10% of sales in fiscal year 2022. No other country represented more than 10% of sales during these periods presented herein. Revenues from sales to customers in Switzerland, the Company's home domicile, represented 3%, 3% and 4% of sales in fiscal years 2022, 2021 and 2020, respectively.

[0001032975-22-000012:notes:312]
Property, plant and equipment, net (excluding software) and right-of-use assets by geographic region were as follows (in thousands):

[0001032975-22-000012:notes:313]
|  |  | March 31, |
|  |  | 2022 |  | 2021 |
| Americas |  | $ | 22,578 |  |  | $ | 18,023 |  |
| EMEA |  | 23,830 |  |  | 18,130 |  |
| Asia Pacific |  | 87,265 |  |  | 95,642 |  |
| Total property, plant and equipment |  | $ | 133,673 |  |  | $ | 131,795 |  |

[0001032975-22-000012:notes:314]
Property, plant and equipment, net (excluding software) and right-of-use assets in the United States and China were $21.7 million and $66.8 million, respectively, as of March 31, 2022, and $17.2 million and $77.6 million, respectively, as of March 31, 2021.  Property, plant and equipment, net (excluding software) and right-of-use assets in Switzerland, the Company's home domicile, were $13.6 million and $9.5 million as of March 31, 2022 and 2021, respectively. No other countries represented more than 10% of the Company's total consolidated property, plant and equipment, net (excluding software) and right-of-use assets as of March 31, 2022 or 2021.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001032975-22-000012:notes:315]
Restructuring
During the first quarter of fiscal year 2019, the Company implemented a restructuring plan to streamline and realign the Company's overall organizational structure and reallocate resources to support long-term growth opportunities. During the first quarter of fiscal year 2020, the Company had substantially completed this restructuring plan.

[0001032975-22-000012:notes:316]
During the third quarter of fiscal year 2022, as part of the Company's strategic review, the Company decided to cease future product launches under the Jaybird-brand within the Audio & Wearables product category. As a result, the Company recorded pre-tax restructuring charges of $2.1 million during fiscal year 2022, which are included in restructuring charges (credits), net in the consolidated statement of operations.

[0001032975-22-000012:notes:317]
Total charges related to the exit of Jaybird-branded products were $16.7 million, which included restructuring charges and other costs, for fiscal year 2022. The restructuring charges consisted of $1.3 million, primarily related to costs of production cancellation, and $0.8 million related to cash severance and termination benefits. The Company also recorded $7.6 million in cost of goods sold related to write-offs for excess inventories. In addition, as disclosed in Note 11, the Company recognized a pre-tax impairment charge of $7.0 million, related to intangible assets acquired as part of the Jaybird acquisition. The Company expects to substantially complete this restructuring within the next nine months.

[0001032975-22-000012:notes:318]
The following table summarizes restructuring-related activities during fiscal years 2022, 2021 and 2020 (in thousands):

[0001032975-22-000012:notes:319]
|  |  | Restructuring - Continuing Operations |  |
|  |  | TerminationBenefits |  | Other |  | Total |  |
| Accrual balance at March 31, 2019 |  | $ | 4,389 |  |  | $ | — |  |  | $ | 4,389 |  |  |
| Charges, net |  | 144 |  |  | — |  |  | 144 |  |  |
| Cash payments |  | (3,852) |  |  | — |  |  | (3,852) |  |  |
| Accrual balance at March 31, 2020 |  | $ | 681 |  |  | $ | — |  |  | $ | 681 |  |  |
| Charges, net |  | (54) |  |  | — |  |  | (54) |  |  |
| Cash payments |  | — |  |  | — |  |  | — |  |  |
| Accrual balance at March 31, 2021 |  | $ | 627 |  |  | $ | — |  |  | $ | 627 |  |  |
| Charges, net |  | 879 |  |  | 1,286 |  |  | 2,165 |  |  |
| Cash payments |  | (945) |  |  | (390) |  |  | (1,335) |  |  |
| Accrual balance at March 31, 2022 |  | $ | 561 |  |  | $ | 896 |  |  | $ | 1,457 |  |  |

[0001032975-22-000012:notes:320]
The accrual balances are included in accrued and other current liabilities on the Company’s consolidated balance sheets.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001032975-22-000012:notes:321]
Leases
The Company is a lessee in various noncancellable operating leases, primarily real estate facilities for office space and for transportation and office equipment.

[0001032975-22-000012:notes:322]
As of March 31, 2022, the Company's lease arrangements comprise of operating leases with various expiration dates through June 30, 2031. The lease term for all of the Company’s leases includes the noncancellable period of the lease. Certain lease agreements include options to renew or terminate the lease, which are not reasonably certain to be exercised and therefore are not factored into the Company's determination of the duration of the lease arrangement.

[0001032975-22-000012:notes:323]
The Company's leases do not contain any material residual value guarantees.

[0001032975-22-000012:notes:324]
The total operating lease costs were $17.3 million, $15.0 million and $14.1 million as of March 31, 2022, 2021, and 2020, respectively, and included short-term lease costs and sublease income. Total variable lease costs were not material during the year ended March 31, 2022, 2021 and 2020. The total operating and variable lease costs were included in cost of goods sold, marketing and selling, research and development, and general and administrative in the Company's consolidated statement of operations.

[0001032975-22-000012:notes:325]
Supplemental cash flow information related to operating leases (in thousands):

[0001032975-22-000012:notes:326]
|  | Years Ended March 31, |
|  | 2022 |  | 2021 |  | 2020 |
| Cash paid for amounts included in the measurement of operating lease liabilities | $ | 15,400 |  |  | $ | 13,865 |  |  | $ | 13,554 |  |
| ROU assets obtained in the exchange for operating lease liabilities | $ | 22,174 |  |  | $ | 15,659 |  |  | $ | 6,123 |  |

[0001032975-22-000012:notes:327]
Future lease payments included in the measurement of operating lease liabilities as of March 31, 2022 for the following five fiscal years and thereafter are as follows (in thousands):

[0001032975-22-000012:notes:328]
| Years Ending March 31, |  |
| 2023 | $ | 14,489 |  |
| 2024 | 9,512 |  |
| 2025 | 6,818 |  |
| 2026 | 4,252 |  |
| 2027 | 3,577 |  |
| Thereafter | 6,056 |  |
| Total lease payments | $ | 44,704 |  |
| Less interest | (2,807) |  |
| Present value of lease liabilities | $ | 41,897 |  |

[0001032975-22-000012:notes:329]
As of March 31, 2022, the Company had entered into a lease for office space that has not yet commenced with future lease payments of $26.7 million, which are not reflected in the table above. This lease will commence in fiscal year 2023 with a lease term of 20 years and will be recorded in the financial statements upon lease commencement.

[0001032975-22-000012:notes:330]
Weighted-average lease terms and discount rates were as follows:

[0001032975-22-000012:notes:331]
|  | Years Ended March 31, |
|  | 2022 |  | 2021 |
| Weighted-average remaining lease terms (in years) | 4.6 |  | 3.8 |
| Weighted-average discount rate | 2.8 | % |  | 2.7 | % |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001032975-22-000012:notes:332]
VALUATION AND QUALIFYING ACCOUNTS

[0001032975-22-000012:notes:333]
For the Fiscal Years Ended March 31, 2022, 2021 and 2020 (in thousands)

[0001032975-22-000012:notes:334]
The Company's Schedule II includes valuation and qualifying accounts related to allowances for doubtful accounts, sales returns, cooperative marketing arrangements, customer incentive programs, and pricing programs, for direct customers and tax valuation allowances. The Company also has sales incentive programs for indirect customers with whom it does not have a direct sales and receivable relationship. These programs are recorded as accrued liabilities and are not considered valuation or qualifying accounts.

[0001032975-22-000012:notes:335]
|  |  | Balance atBeginning ofYear |  | Charged(Credited) to Statement ofOperations (1) |  | Claims andAdjustmentsApplied AgainstAllowances (1) |  | Balance atEnd ofYear |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |  |
| 2022 |  | $ | 1,161 |  |  | $ | 1,691 |  |  | $ | (640) |  |  | $ | 2,212 |  |
| 2021 |  | $ | 1,894 |  |  | $ | (533) |  |  | $ | (200) |  |  | $ | 1,161 |  |
| 2020 |  | $ | 84 |  |  | $ | 1,607 |  |  | $ | 203 |  |  | $ | 1,894 |  |
| Allowance for sales returns: |  |  |  |  |  |  |  |  |
| 2022 |  | $ | 14,438 |  |  | $ | 162,381 |  |  | $ | (164,498) |  |  | $ | 12,321 |  |
| 2021 |  | $ | 6,599 |  |  | $ | 122,803 |  |  | $ | (114,964) |  |  | $ | 14,438 |  |
| 2020 |  | $ | 6,486 |  |  | $ | 107,980 |  |  | $ | (107,868) |  |  | $ | 6,599 |  |
| Allowance for cooperative marketing arrangements: |  |  |  |  |  |  |  |  |
| 2022 |  | $ | 43,276 |  |  | $ | 286,116 |  |  | $ | (273,020) |  |  | $ | 56,372 |  |
| 2021 |  | $ | 38,794 |  |  | $ | 222,732 |  |  | $ | (218,250) |  |  | $ | 43,276 |  |
| 2020 |  | $ | 35,080 |  |  | $ | 194,730 |  |  | $ | (191,015) |  |  | $ | 38,794 |  |
| Allowance for customer incentive programs: |  |  |  |  |  |  |  |  |
| 2022 |  | $ | 76,200 |  |  | $ | 348,072 |  |  | $ | (326,812) |  |  | $ | 97,460 |  |
| 2021 |  | $ | 55,741 |  |  | $ | 256,755 |  |  | $ | (236,296) |  |  | $ | 76,200 |  |
| 2020 |  | $ | 60,036 |  |  | $ | 248,966 |  |  | $ | (253,260) |  |  | $ | 55,741 |  |
| Allowance for pricing programs: |  |  |  |  |  |  |  |  |
| 2022 |  | $ | 120,568 |  |  | $ | 885,228 |  |  | $ | (884,999) |  |  | $ | 120,797 |  |
| 2021 |  | $ | 100,168 |  |  | $ | 782,734 |  |  | $ | (762,334) |  |  | $ | 120,568 |  |
| 2020 |  | $ | 88,353 |  |  | $ | 570,409 |  |  | $ | (558,594) |  |  | $ | 100,168 |  |
| Tax valuation allowance: |  |  |  |  |  |  |  |  |
| 2022 |  | $ | 28,926 |  |  | $ | 887 |  |  | $ | 45 |  |  | $ | 29,858 |  |
| 2021 |  | $ | 29,171 |  |  | $ | (245) |  |  | $ | — |  |  | $ | 28,926 |  |
| 2020 |  | $ | 28,375 |  |  | $ | 796 |  |  | $ | — |  |  | $ | 29,171 |  |

[0001032975-22-000012:notes:336]
(1) The amounts for fiscal years 2022, 2021 and 2020 include immaterial impacts from the business acquisitions during the year. Refer to Note 3 to the consolidated financial statements.
