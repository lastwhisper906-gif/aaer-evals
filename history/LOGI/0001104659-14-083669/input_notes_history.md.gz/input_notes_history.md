# LOGI note change history — 0001104659-14-081027 → 0001104659-14-083669


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-11-26):
[0001104659-14-083669:note_history:1]
Changes in the Company’s warranty liability for the three and six months ended September 30, 2014 and 2013 were as follows (in thousands):
  (was, 2014-11-14, similarity 0.9231):
[0001104659-14-081027:note_history:1]
Changes in the Company’s warranty liability for the three months ended June 30, 2014 and 2013 were as follows (in thousands):

- added (2014-11-26):
[0001104659-14-083669:note_history:2]
|  |  | Three Months Ended |  | Six Months Ended |  |
|  |  | September 30, |  | September 30, |  |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  |
| Beginning of the period |  | $ | 23,420 |  | $ | 23,550 |  | $ | 24,380 |  | $ | 21,442 |  |
| Provision |  | 2,020 |  | 3,664 |  | 4,226 |  | 7,190 |  |
| Settlements |  | (3,236 | ) | (4,193 | ) | (6,402 | ) | (7,938 | ) |
| Adjustment (1) |  | — |  | — |  | — |  | 2,327 |  |
| End of the period |  | $ | 22,204 |  | $ | 23,021 |  | $ | 22,204 |  | $ | 23,021 |  |

- changed (2014-11-26):
[0001104659-14-083669:note_history:3]
|  | (1) |  | During the six month period September 30, 2013, the warranty liability allocated to the Company’s - Remotes product category was reclassified from liabilities held for sale. |
  (was, 2014-11-14, similarity 0.9169):
[0001104659-14-081027:note_history:3]
(1)     During the three month period June 30, 2013, the warranty liability allocated to the Company’s - Remotes product category was reclassified from liabilities held for sale.

- changed (2014-11-26):
[0001104659-14-083669:note_history:4]
Commitments for inventory purchases are made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers and are expected to be fulfilled by September 30, 2014. Operating expense commitments are for consulting services, marketing arrangements, advertising, outsourced customer services, information technology maintenance and support services, and other services. Fixed purchase commitments for capital expenditures primarily related to commitments for computer hardware and leasehold improvements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the Company the option to reschedule and adjust its requirements based on the business needs prior to delivery of goods or performance of services. As of September 30, 2014, the Company’s outstanding purchase commitments had not materially changed since March 31, 2014.
  (was, 2014-11-14, similarity 0.9928):
[0001104659-14-081027:note_history:4]
Commitments for inventory purchases are made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers and are expected to be fulfilled by September 30, 2014. Operating expense commitments are for consulting services, marketing arrangements, advertising, outsourced customer services, information technology maintenance and support services, and other services. Fixed purchase commitments for capital expenditures primarily related to commitments for computer hardware and leasehold improvements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the Company the option to reschedule and adjust its requirements based on the business needs prior to delivery of goods or performance of services. As of June 30, 2014, the Company’s outstanding purchase commitments had not materially changed since March 31, 2014.

- changed (2014-11-26):
[0001104659-14-083669:note_history:5]
The Company is subject to an ongoing formal investigation by the SEC, relating to certain issues including the accounting for Revue inventory valuation reserves that resulted in the restatement described in the Fiscal 2014 Form 10-K, revision to the Company’s financial statements concerning warranty accruals and amortization of intangible assets presented in the Company’s Form 10-K/A, filed on August 7, 2013, and the Company’s transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. The Company is cooperating with the SEC in its ongoing investigation. The Company has entered into an agreement with the SEC to extend the statute of limitations. The Company cannot predict the outcome of the investigation at this time and any potential fines or penalties, if any, that may arise from the investigation are currently not estimable.
  (was, 2014-11-14, similarity 0.994):
[0001104659-14-081027:note_history:5]
The Company is subject to an ongoing formal investigation by the SEC, relating to issues including the accounting for Revue inventory valuation reserves that resulted in the restatement described in the Fiscal 2014 Form 10-K, revision to the Company’s financial statements concerning warranty accruals and amortization of intangible assets presented in the Company's Form 10-K/A, filed on August 7, 2013, and the Company’s transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. The Company is cooperating with the SEC in its ongoing investigation. The Company has entered into an agreement with the SEC to extend the statute of limitations. The Company cannot predict the outcome of the investigation at this time and any potential fines or penalties, if any, that may arise from the investigation are currently not estimable.

- added (2014-11-26):
[0001104659-14-083669:note_history:6]
Logitech Europe S.A.  guaranteed payments of a third-party contract manufacturer’s purchase obligations. As of September 30, 2014, the maximum amount of this guarantee was $3.5 million, of which $2.7 million of guaranteed purchase obligations were outstanding.

- changed (2014-11-26):
[0001104659-14-083669:note_history:7]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2014, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2014-11-14, similarity 0.9899):
[0001104659-14-081027:note_history:7]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2014, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

- removed (2014-11-26):
[0001104659-14-081027:note_history:8]
|  |  | Three Months Ended |  |
|  |  | June 30, |  |
|  |  | 2014 |  | 2013 |  |
| Beginning of the period |  | $ | 24,380 |  | $ | 21,442 |  |
| Provision |  | 2,206 |  | 3,526 |  |
| Settlements |  | (3,166 | ) | (3,745 | ) |
| Adjustment (1) |  | — |  | 2,327 |  |
| End of the period |  | $ | 23,420 |  | $ | 23,550 |  |

- removed (2014-11-26):
[0001104659-14-081027:note_history:9]
Logitech International S.A., the parent holding company, has issued several parent guarantees on behalf of its subsidiaries. The maximum potential future payment under the guarantee arrangements is limited to $80.0 million. As of June 30, 2014, there were no purchase obligations outstanding for which the parent holding company was required to guarantee payment.

- removed (2014-11-26):
[0001104659-14-081027:note_history:10]
Logitech Europe S.A., a subsidiary of the parent holding company, has guaranteed the purchase obligations of another Logitech subsidiary under a guarantee agreement. This guarantee does not specify a maximum amount. As of June 30, 2014, the amount of purchase obligations outstanding under this guarantee was immaterial. In addition, Logitech Europe S.A. also guaranteed payments of a third-party contract manufacturer’s purchase obligations. As of June 30, 2014, the maximum amount of this guarantee was $3.5 million, of which $2.3 million of guaranteed purchase obligations were outstanding.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-11-26):
[0001104659-14-083669:note_history:11]
The consolidated interim financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (“GAAP”) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. They should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2014, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (“SEC”) on November 13, 2014.  In the opinion of management, these consolidated financial statements include all adjustments, consisting of normal recurring adjustments, necessary for a fair statement of the results for the periods presented. Operating results for the three and six months ended September 30, 2014 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2015, or any future periods.
  (was, 2014-11-14, similarity 0.8805):
[0001104659-14-081027:note_history:11]
The consolidated interim financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (“GAAP”) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. They should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2014, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (“SEC”) on November 13, 2014.  In the opinion of management, these consolidated financial statements include all adjustments, consisting of normal recurring adjustments, necessary for a fair statement of the results for the periods presented. Operating results for the three months ended June 30, 2014 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2015, or any future periods.

- changed (2014-11-26):
[0001104659-14-083669:note_history:12]
There have been no substantial changes in the Company’s significant accounting policies during the six months ended September 30, 2014 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2014.
  (was, 2014-11-14, similarity 0.9045):
[0001104659-14-081027:note_history:12]
There have been no substantial changes in the Company’s significant accounting policies during the three months ended June 30, 2014 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2014.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2014-11-26):
[0001104659-14-083669:note_history:13]
The Company had several uncommitted, unsecured bank lines of credit aggregating $39.1 million as of September 30, 2014. There are no financial covenants under these lines of credit with which the Company must comply. As of September 30, 2014, the Company had outstanding bank guarantees of $7.0 million under these lines of credit. The Company also had credit lines related to corporate credit cards totaling $6.8 million as of September 30, 2014 and $6.9 million as of March 31, 2014. There are no financial covenants under these credit lines.

- removed (2014-11-26):
[0001104659-14-081027:note_history:14]
The Company had several uncommitted, unsecured bank letters of credit aggregating $40 million as of June 30, 2014. There are no financial covenants under these letters of credit with which the Company must comply.  As of June 30, 2014, the Company had outstanding bank guarantees of $8.3 million under these letters of credit. The Company also had credit lines related to corporate credit cards totaling $6.9 million as of June 30, 2014. There are no financial covenants under these credit lines.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2014-11-26):
[0001104659-14-083669:note_history:15]
Note 14 — Subsequent Event
  (was, 2014-11-14, similarity 0.9804):
[0001104659-14-081027:note_history:15]
Note 14 — Subsequent Events

- changed (2014-11-26):
[0001104659-14-083669:note_history:16]
On November 12, 2014, the Board approved, subject to approval by the Company’s shareholders and other Swiss statutory requirements, a dividend of CHF 0.2625 per share. Based on the shares outstanding as of September 30, 2014, net of treasury shares, the aggregate amount of the dividend would be approximately CHF 42.9 million.
  (was, 2014-11-14, similarity 0.6739):
[0001104659-14-081027:note_history:16]
On November 12, 2014, the Board approved, subject to approval by the Company’s shareholders and other Swiss statutory requirements, a dividend of CHF 0.2625 per share.

- removed (2014-11-26):
[0001104659-14-081027:note_history:17]
The Company was not current with its periodic reports required to be filed with the SEC and was therefore unable to issue any shares under its Registration Statements on Form S-8 after July 31, 2014. Given the proximity of the unavailability of those registration statements and the end of the current ESPP offering period, also on July 31, 2014, the Compensation Committee authorized the termination of the current ESPP offering period and a one-time payment to each participant in an amount equal to the fifteen percent (15%) discount at which shares would otherwise have been repurchased pursuant to the current period of the ESPPs. This one-time payment, totaling $1.1 million was accounted for as a repurchase of equity awards that reduced additional paid in capital, resulting in no additional compensation cost. Given the unavailability of the Company’s Registration Statements on Form S-8, no new ESPP offering periods were initiated during the three months ended September 30, 2014.
