# LOGI MD&A — 0001104659-14-083669


## mdna

[0001104659-14-083669:mdna:1]
[same as prior period, unchanged from 0001104659-14-081027:mdna:1]

[0001104659-14-083669:mdna:2]
[same as prior period, unchanged from 0001104659-14-081027:mdna:2]

[0001104659-14-083669:mdna:3]
[same as prior period, unchanged from 0001104659-14-081027:mdna:3]

[0001104659-14-083669:mdna:4]
[same as prior period, unchanged from 0001104659-14-081027:mdna:4]

[0001104659-14-083669:mdna:5]
Our peripherals segment encompasses the design, manufacturing and marketing of peripherals for PCs, tablets and other digital platforms. Our products for home and business PCs include mice, trackballs, keyboards, interactive gaming controllers, multimedia speakers, headsets and webcams. Our tablet accessory products include keyboards, keyboard cases and covers, and smartphone accessories. Our Internet communications products include webcams, conference cams and headsets. Our digital music products include wireless speakers, earphones, and custom in-ear monitors. Our gaming products include mice, keyboards, headsets and gaming controllers. For home entertainment and home control systems, we offer the Harmony line of advanced remote controls. Since fiscal year 2013, we have been exiting other non-strategic products, such as speaker docks and headphones, and continue to evaluate non-strategic products as part of our ongoing efforts to strengthen our overall portfolio.

[0001104659-14-083669:mdna:6]
Within our peripherals segment, we classify our retail product categories as growth, profit maximization, and non-strategic. Our growth product categories are: PC Gaming, Tablet & Other Accessories, and Mobile Speakers. Our profit maximization categories are: Pointing Devices, PC Keyboards & Desktops, Audio-PC & Wearables, Video, and Remotes.

[0001104659-14-083669:mdna:7]
27

[0001104659-14-083669:mdna:8]
[same as prior period, unchanged from 0001104659-14-081027:mdna:9]

[0001104659-14-083669:mdna:9]
[same as prior period, unchanged from 0001104659-14-081027:mdna:10]

[0001104659-14-083669:mdna:10]
We sell our peripherals products to a network of retailers (direct sales to retailers, as well as indirect sales through distributors) and OEMs. Our worldwide retail network includes wholesale distributors, consumer electronics retailers, mass merchandisers, specialty electronics, computers and telecommunications stores, value-added resellers and online merchants. Sales of our retail peripherals were 89% and 87% of our net sales for the six months ended September 30, 2014 and 2013. The large majority of our revenues have historically been derived from sales of our peripherals products for use by consumers. Our OEM customers include several of the world’s largest PC manufacturers. Sales to OEM customers were 6% and 7% of our net sales for the six months ended September 30, 2014 and 2013.

[0001104659-14-083669:mdna:11]
Our video conferencing segment encompasses the design, manufacturing and marketing of Lifesize branded video conferencing products, infrastructure and services for the enterprise, public sector and other small to medium business markets. Video conferencing products include scalable high-definition, or HD, video communication endpoints, HD video conferencing systems with integrated monitors, video bridges, a cloud based video conferencing solution and other infrastructure software and hardware to support large-scale video deployments and services to support these products. The video conferencing segment maintains a separate marketing and sales organization, which sells Lifesize products and services worldwide. Video conferencing product development and product management organizations are separate, but coordinated with our peripherals business, particularly our Consumer Computing Platform group. We sell our video conferencing products and services to distributors, value-added resellers, OEMs and, occasionally, direct enterprise customers. Sales of Lifesize products were 5% and 6% of our net sales in the six months ended September 30, 2014 and 2013.

[0001104659-14-083669:mdna:12]
[same as prior period, unchanged from 0001104659-14-081027:mdna:13]

[0001104659-14-083669:mdna:13]
We believe innovation, design, and product quality are important to gaining market acceptance and maintaining market leadership.

[0001104659-14-083669:mdna:14]
[same as prior period, unchanged from 0001104659-14-081027:mdna:15]

[0001104659-14-083669:mdna:15]
[same as prior period, unchanged from 0001104659-14-081027:mdna:16]

[0001104659-14-083669:mdna:16]
From time to time, we may seek to partner with, or acquire when appropriate, companies that have products, personnel, and technologies that complement our strategic direction. We continually review our product offerings and our strategic direction in light

[0001104659-14-083669:mdna:17]
of our profitability targets, competitive conditions, changing consumer trends and the evolving nature of the interface between the consumer and the digital world.

[0001104659-14-083669:mdna:18]
[same as prior period, unchanged from 0001104659-14-081027:mdna:18]

[0001104659-14-083669:mdna:19]
The preparation of financial statements and related disclosures in conformity with U.S. GAAP (Generally Accepted Accounting Principles in the United States of America) requires us to make judgments, estimates and assumptions that affect reported amounts of assets, liabilities, net sales and expenses, and the disclosure of contingent assets and liabilities.

[0001104659-14-083669:mdna:20]
[same as prior period, unchanged from 0001104659-14-081027:mdna:20]

[0001104659-14-083669:mdna:21]
[same as prior period, unchanged from 0001104659-14-081027:mdna:21]

[0001104659-14-083669:mdna:22]
There have been no new or material changes to the critical accounting policies and estimates discussed in our Annual Report on Form 10-K for the fiscal year ended March 31, 2014 that are of significance, or potential significance to the Company.

[0001104659-14-083669:mdna:23]
Revision of Previously Issued Consolidated Financial Statements

[0001104659-14-083669:mdna:24]
As disclosed in the Company’s Annual Report on Form 10-K for the year ended March 31, 2014 and in the audited consolidated financial statements contained therein, the Company has restated and revised its financial statements for the fiscal years ended March 31, 2012 and 2013, respectively. The impact of the adjustments also immaterially impact the financial statements for the first three quarters of the fiscal year ended March 31, 2014 as previously included in the Company’s quarterly reports on Form 10-Q for Fiscal 2014. The financial statements for three and six months ended September 30, 2013 included in this Form 10-Q are revised as described below for those adjustments and should be read in conjunction with Item 8, “Financial Statements and Supplementary Data” disclosed in the Company’s Annual Report on Form 10-K for the fiscal year ended March 31, 2014, filed with the SEC on November 13, 2014.

[0001104659-14-083669:mdna:25]
The adjustments included in these financial statements for the three and six months ended September 30, 2013 primarily related to a correction to revenue that was previously recorded as an out-of-period adjustment and is now being reported in the correct period, capitalization of property, plant and equipment which was previously incorrectly expensed, other misstatements, and the tax impact of these adjustments.

[0001104659-14-083669:mdna:26]
[same as prior period, unchanged from 0001104659-14-081027:mdna:26]

[0001104659-14-083669:mdna:27]
Our total net sales for the six months ended September 30, 2014 slightly increased compared with the six months ended September 30, 2013, due to an increase in retail sales, offset by declines in OEM and video conferencing sales.

[0001104659-14-083669:mdna:28]
Retail sales and units sold during the six months ended September 30, 2014 increased 2% compared with the six months ended September 30, 2013. We experienced increase in sales of 9% in the Americas, decreases of 3% in the EMEA region and 2% in the Asia Pacific regions.

[0001104659-14-083669:mdna:29]
If foreign currency exchange rates had been the same in the six months ended September 30, 2014 and 2013, our constant dollar retail sales would have been an increase in sales of 2% for total retail sales, an increase of 10% in the Americas, a decrease of 5% in the EMEA regions, and a decrease of 1% in the Asia Pacific.

[0001104659-14-083669:mdna:30]
OEM net sales decreased 15% and units sold decreased 24% in the six months ended September 30, 2014 compared with the preceding fiscal year. The decline was primarily due to overall weaker market conditions which led to sales declines from a few OEM customers.

[0001104659-14-083669:mdna:31]
Sales of video conferencing products, which were 5% and 6% of total net sales in the six months ended September 30, 2014 and 2013, decreased by 9% in the six months ended September 30, 2014, compared with the six months ended September 30, 2013. Lifesize is in the process of transitioning its product portfolio to the recently announced Lifesize Cloud, a software-as-a-service (SaaS) offering that provides an affordable, simple and scalable video conferencing solution with little to no need for IT involvement. The

[0001104659-14-083669:mdna:32]
decline in sales reflects the combination of this short-term portfolio transition and weak market conditions for video conferencing endpoints.

[0001104659-14-083669:mdna:33]
Our gross margin for the six months ended September 30, 2014 improved to 38.2% compared with 34.9% for the six months ended September 30, 2013. The improvement in gross margin for the six months ended September 30, 2014 compared with the same period of the prior fiscal year primarily resulted from the combination of cost reductions in our Profit Maximization category, increased scale on Growth category products, offset in part by an increase in incentive spending

[0001104659-14-083669:mdna:34]
Operating expenses for the six months ended September 30, 2014 were 31.8% of net sales, compared with 33.1% in the same period of the prior fiscal year. The decrease in total operating expenses as a percentage of net sales for the six months ended September 30, 2014 compared to prior period were primarily due to savings from prior year’s restructuring actions and the ongoing rationalization of infrastructure. Operating expenses for the six months ended September 30, 2014, also included expenses related to the Audit Committee’s investigation, which were $17.0 million.

[0001104659-14-083669:mdna:35]
Net income for the six months ended September 30, 2014 was $55.8 million, compared with net income of $15.8 million in the six months ended September 30, 2013.

[0001104659-14-083669:mdna:36]
[same as prior period, unchanged from 0001104659-14-081027:mdna:35]

[0001104659-14-083669:mdna:37]
Our sales of PC peripherals for use by consumers in the Americas and Europe have historically made up the large majority of our revenues. In the last several years, the PC market has changed dramatically and there continues to be weakness in the global market for new PCs. This weakness had a negative impact on our net sales in all of our PC-related categories. We believe that this weakness reflects the growing popularity of tablets and smartphones as mobile computing devices.

[0001104659-14-083669:mdna:38]
We believe our future growth will be determined by our ability to rapidly create innovative products across multiple digital platforms, especially accessories for mobility-related products, including tablets, smartphones, PC Gaming and digital music devices to offset the decline in our PC peripherals. The following discussion represents key trends specific to each of our two operating segments: peripherals and video conferencing.

[0001104659-14-083669:mdna:39]
[same as prior period, unchanged from 0001104659-14-081027:mdna:38]

[0001104659-14-083669:mdna:40]
[same as prior period, unchanged from 0001104659-14-081027:mdna:39]

[0001104659-14-083669:mdna:41]
[same as prior period, unchanged from 0001104659-14-081027:mdna:40]

[0001104659-14-083669:mdna:42]
Tablets and Other Accessories. The increasing popularity of smaller, mobile computing devices, such as tablets with touch interfaces, has created new markets and usage models for peripherals and accessories. We have started offering products to enhance the use of mobile devices. During fiscal year 2014, we continued to expand and leverage our success in this category through the introductions of keyboard folios for the iPad and iPad mini, and keyboard covers and folios for the iPad Air. During this time, we also introduced keyboard folios for the Samsung Galaxy tablet as well as the Wired Keyboard for the iPad, designed primarily for use in the classroom.

[0001104659-14-083669:mdna:43]
Mobile Speakers. We believe that digital music, the seamless consumption of digital audio content on mobile devices, presents a growth opportunity for us. Many consumers listen to music as a popular entertainment activity, fueled by the growth in smartphones, tablets, music services and Internet radio. We believe we have a solid foundation of audio speaker solutions to satisfy consumers’ needs for music consumption, in the digital music speaker space. We continue to invest in the UE brand and introduce innovative new products in this category such as UE BOOM, a wireless speaker that offers 360-degree stereo sound.

[0001104659-14-083669:mdna:44]
OEM Business. Sales of our OEM mice and keyboards have historically made up the bulk of our OEM sales. In recent years, there has been a dramatic shift away from desktop PCs and there continues to be weakness in the global market for PCs, which has

[0001104659-14-083669:mdna:45]
adversely affected our sales of OEM mice and keyboards, all of which are sold with name-brand desktop PCs. We expect this trend to continue and for OEM sales to comprise a smaller percentage of our total sales in the future.

[0001104659-14-083669:mdna:46]
Trends in Non-Strategic Peripherals Product Categories. During the quarter ended December 31, 2012, we identified a number of product categories that no longer fit with our strategic direction at that time.  We will continue to evaluate our product offerings and will exit those which no longer support our strategic direction.

[0001104659-14-083669:mdna:47]
[same as prior period, unchanged from 0001104659-14-081027:mdna:46]

[0001104659-14-083669:mdna:48]
[same as prior period, unchanged from 0001104659-14-081027:mdna:47]

[0001104659-14-083669:mdna:49]
[same as prior period, unchanged from 0001104659-14-081027:mdna:48]

[0001104659-14-083669:mdna:50]
[same as prior period, unchanged from 0001104659-14-081027:mdna:49]

[0001104659-14-083669:mdna:51]
Net sales by channel for the three and six months ended September 30, 2014 and 2013 were as follows (in thousands):

[0001104659-14-083669:mdna:52]
|  |  | Three Months Ended |  | Six Months Ended |  |
|  |  | September 30, |  | September 30, |  |
|  |  | 2014 |  | 2013 |  | Change |  | 2014 |  | 2013 |  | Change |  |
| Retail |  | $ | 473,463 |  | $ | 464,024 |  | 2 | % | $ | 897,276 |  | $ | 877,867 |  | 2 | % |
| OEM |  | 28,394 |  | 37,526 |  | (24 | ) | 61,027 |  | 72,039 |  | (15 | ) |
| Video conferencing |  | 28,454 |  | 29,593 |  | (4 | ) | 54,211 |  | 59,767 |  | (9 | ) |
| Total net sales |  | $ | 530,311 |  | $ | 531,143 |  | (0 | ) | $ | 1,012,514 |  | $ | 1,009,673 |  | 0 |  |

[0001104659-14-083669:mdna:53]
[same as prior period, unchanged from 0001104659-14-081027:mdna:52]

[0001104659-14-083669:mdna:54]
Our net retail sales in both the three and six months ended September 30, 2014 increased by 2% with the same period of the prior fiscal year, as the sales increases in the Americas were offset in part by a decrease in both the EMEA and  Asia pacific regions. Our retail average selling price increased by 2% and 1% during the three and six months ended September 30, 2014. Products priced below $40 represented approximately 48% and 49% of retail sales in the three and six months ended September 30, 2014, compared with 49% and 51% of total retail sales in the three and six months ended September 30, 2013. Sales of products priced above $100 represented 18% and 16% of retail sales in the three and six months ended September 30, 2014, compared with 13% and 14% of total retail sales for both the three and six months ended September 30, 2013.

[0001104659-14-083669:mdna:55]
[same as prior period, unchanged from 0001104659-14-081027:mdna:54]

[0001104659-14-083669:mdna:56]
OEM net sales decreased 24% and 15% and units sold decreased 35% and 24%  in the three and six months ended September 30, 2014 compared with the preceding fiscal year. The decline was primarily due to overall weaker market conditions for pointing devices that were only partially offset by growth in Keyboards & Desktops.

[0001104659-14-083669:mdna:57]
Video Conferencing:

[0001104659-14-083669:mdna:58]
Video conferencing net sales decreased 4% and 9% during the three and six months ended September 30, 2014, compared with the same period of the prior fiscal year. Lifesize is in the process of transitioning its product portfolio to the recently announced Lifesize Cloud, a software-as-a-service (SaaS) offering that provides an affordable, simple and scalable video conferencing solution with little to no need for IT involvement. The decline in sales reflects the combination of this short-term portfolio transition and weak market conditions for video conferencing endpoints.

[0001104659-14-083669:mdna:59]
[same as prior period, unchanged from 0001104659-14-081027:mdna:59]

[0001104659-14-083669:mdna:60]
The following table presents the change in retail sales by for the three and six months ended September 30, 2014 compared with the three and six months ended September 30, 2013.

[0001104659-14-083669:mdna:61]
|  |  | Three Months Ended |  | Six Months Ended |  |
|  |  | September 30, 2014 |  | September 30, 2014 |  |
|  |  | Change in Sales |  | Change in Sales |  |
| Americas |  | 10 | % | 9 | % |
| EMEA |  | (5 | ) | (3 | ) |
| Asia Pacific |  | (1 | ) | (2 | ) |

[0001104659-14-083669:mdna:62]
[same as prior period, unchanged from 0001104659-14-081027:mdna:62]

[0001104659-14-083669:mdna:63]
The Americas region experienced a 10% increase and a 9% increase in retail sales during the three and six months ended September 30, 2014, compared with the same period of the prior fiscal year.  The sales increase was achieved in all categories except our non-strategic Other, Audio-PC & Wearables, and Pointing Devices. This increase was led by triple digit growth in Mobile Speakers from UE BOOM and PC Gaming products. Video decreased in the three months ended September 30, 2014 compared with the same period of the prior fiscal year but increased during the six months ended September 30, 2014 compared with the same period of the prior fiscal year, driven by the growth in business webcams and UC ConferenceCams.

[0001104659-14-083669:mdna:64]
[same as prior period, unchanged from 0001104659-14-081027:mdna:64]

[0001104659-14-083669:mdna:65]
Retail sales in the EMEA region experienced a 5% decrease and a 3% decrease during the three and six months ended September 30, 2014, compared with the same period of the prior fiscal year. The sales decrease was primarily due to lower demand for  Tablet & Other Accessories, Audio-PC & Wearables, Pointing Devices and decline in non-strategic Other. Sales of Mobile Speakers for the first six months of fiscal 2015 doubled and we achieved growth in Video driven by UC ConferenceCams and growth in PC Keyboards & Desktops.

[0001104659-14-083669:mdna:66]
[same as prior period, unchanged from 0001104659-14-081027:mdna:66]

[0001104659-14-083669:mdna:67]
Asia Pacific region retail sales decreased by 1% and 2% during the three and six months ended September 30, 2014, compared with the same period of the prior fiscal year. We had triple digit growth in our Mobile Speakers category. These increases were offset in part by weakness in our Tablet & Other Accessories, Audio-PC & Wearables, PC Gaming, PC Keyboards & Desktops and decline in non-strategic Other.

[0001104659-14-083669:mdna:68]
[same as prior period, unchanged from 0001104659-14-081027:mdna:68]

[0001104659-14-083669:mdna:69]
Net retail sales by product category during the three and six months ended September 30, 2014 and 2013 were as follows (in thousands):

[0001104659-14-083669:mdna:70]
|  |  | Three Months Ended |  | Six Months Ended |  |
|  |  | September 30, |  | September 30, |  |
|  |  | 2014 |  | 2013 (1) |  | Change |  | 2014 |  | 2013 (1) |  | Change |  |
| Peripherals: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PC Gaming |  | $ | 47,506 |  | $ | 43,260 |  | 10 | % | $ | 94,382 |  | $ | 83,473 |  | 13 | % |
| Tablet & Other Accessories |  | 28,158 |  | 34,695 |  | (19 | ) | 59,874 |  | 73,254 |  | (18 | ) |
| Mobile Speakers |  | 48,538 |  | 19,967 |  | 143 |  | 77,367 |  | 33,834 |  | 129 |  |
| Growth |  | 124,202 |  | 97,922 |  | 27 |  | 231,623 |  | 190,561 |  | 22 |  |
| Pointing Devices |  | 127,693 |  | 130,656 |  | (2 | ) | 240,735 |  | 245,307 |  | (2 | ) |
| PC Keyboards & Desktops |  | 105,718 |  | 105,260 |  | 0 |  | 211,241 |  | 203,273 |  | 4 |  |
| Audio-PC &Wearables |  | 58,677 |  | 70,523 |  | (17 | ) | 108,303 |  | 126,061 |  | (14 | ) |
| Video |  | 37,563 |  | 36,645 |  | 3 |  | 72,139 |  | 67,585 |  | 7 |  |
| Remotes |  | 18,776 |  | 13,327 |  | 41 |  | 31,108 |  | 27,901 |  | 11 |  |
| Profit Maximization |  | 348,427 |  | 356,411 |  | (2 | ) | 663,526 |  | 670,127 |  | (1 | ) |
| Other |  | 834 |  | 9,691 |  | (91 | ) | 2,127 |  | 17,179 |  | (88 | ) |
| Non-Strategic |  | 834 |  | 9,691 |  | (91 | ) | 2,127 |  | 17,179 |  | (88 | ) |
| Retail |  | 473,463 |  | 464,024 |  | 2 |  | 897,276 |  | 877,867 |  | 2 |  |
| OEM |  | 28,394 |  | 37,526 |  | (24 | ) | 61,027 |  | 72,039 |  | (15 | ) |
|  |  | 501,857 |  | 501,550 |  | 0 |  | 958,303 |  | 949,906 |  | 1 |  |
| Video conferencing |  | 28,454 |  | 29,593 |  | (4 | ) | 54,211 |  | 59,767 |  | (9 | ) |
|  |  | $ | 530,311 |  | $ | 531,143 |  | (0 | ) | $ | 1,012,514 |  | $ | 1,009,673 |  | 0 |  |

[0001104659-14-083669:mdna:71]
[same as prior period, unchanged from 0001104659-14-081027:mdna:71]

[0001104659-14-083669:mdna:72]
[same as prior period, unchanged from 0001104659-14-081027:mdna:72]

[0001104659-14-083669:mdna:73]
[same as prior period, unchanged from 0001104659-14-081027:mdna:73]

[0001104659-14-083669:mdna:74]
[same as prior period, unchanged from 0001104659-14-081027:mdna:74]

[0001104659-14-083669:mdna:75]
Retail sales of PC Gaming increased 10% and units sold increased 11%, in the three months ended September 30, 2014 compared to the three months ended September 30, 2013. The growth in the category was experienced in mice and headsets. The growth in mice sales was primarily driven by the G502 Tunable Gaming Mouse. New products made up 19% of total PC Gaming revenue for the three months ended September 30, 2014. Sales of our PC Gaming products grew strongly in both the Americas and EMEA, reflecting an improved product portfolio that positions us well for continued growth during the remainder of the year.

[0001104659-14-083669:mdna:76]
Retail sales of PC Gaming increased 13% and units sold increased 18%, in the six months ended September 30, 2014 compared to the six months ended September 30, 2013. New products made up 17% of total PC Gaming revenue for the six months ended September 30, 2014.

[0001104659-14-083669:mdna:77]
[same as prior period, unchanged from 0001104659-14-081027:mdna:76]

[0001104659-14-083669:mdna:78]
Our retail Tablet & Other Accessories consists of keyboards for tablets and covers for tablets and smartphones as well as other accessories for mobile devices.

[0001104659-14-083669:mdna:79]
Retail sales of Tablet & Other Accessories decreased 19% and units sold increased 15% in the three months ended September 30, 2014, compared with the same period of the prior fiscal year. This decrease in sales is due to weakened demand for the Ultrathin Tablet Keyboard Covers for iPad Air and iPad Mini. The decline in sales reflects a weak market for iPad Tablets. New products made up 69% of total Tablet & Other Accessories revenue for the three months ended September 30, 2014.

[0001104659-14-083669:mdna:80]
Retail sales of Tablet & Other Accessories decreased 18% and units sold increased 14% in the six months ended September30, 2014, compared with the same period of the prior fiscal year. New products made up 74% of total Tablet & Other Accessories revenue for the six months ended September 30, 2014.

[0001104659-14-083669:mdna:81]
[same as prior period, unchanged from 0001104659-14-081027:mdna:79]

[0001104659-14-083669:mdna:82]
[same as prior period, unchanged from 0001104659-14-081027:mdna:80]

[0001104659-14-083669:mdna:83]
Retail sales and units sold of Mobile Speakers increased 143% and 170% respectively for the three month period ended September 30, 2014, compared with the same period of the prior fiscal year.The increase in sales of our wireless speakers for smartphones and tablets was driven primarily by a strong demand for the UE BOOM, which was our best-selling product in the quarter across all product categories. Mobile Speaker sales increased significantly across our three regions due to great products and expanded distribution, with sales in the Americas nearly tripling.

[0001104659-14-083669:mdna:84]
Retail sales and units sold of Mobile Speakers increased 129% and 141% respectively for the six month period ended September 30, 2014, compared with the same period of the prior fiscal year.

[0001104659-14-083669:mdna:85]
[same as prior period, unchanged from 0001104659-14-081027:mdna:82]

[0001104659-14-083669:mdna:86]
[same as prior period, unchanged from 0001104659-14-081027:mdna:83]

[0001104659-14-083669:mdna:87]
[same as prior period, unchanged from 0001104659-14-081027:mdna:84]

[0001104659-14-083669:mdna:88]
Retail sales of Pointing Devices decreased 2% while retail units sold decreased 1% in the three months ended September 30, 2014, compared to the three month period ended September 30, 2013. Sales declined at the high end of the category, with growth in the mid-range. Sales of cordless mice decreased 1%, while units sold increased 5% while corded mice sales decreased 8%, and units sold decreased 13%.

[0001104659-14-083669:mdna:89]
Retail sales of Pointing Devices decreased 2% while retail units sold increased 1% in the six months ended September 30, 2014, compared to the six month period ended September 30, 2013. Sales declined at the high end, with growth in the mid-range. Sales of all cordless mice decreased 3%, while units sold increased 3% while corded mice sales decreased 1%, while units sold decreased 4% .

[0001104659-14-083669:mdna:90]
[same as prior period, unchanged from 0001104659-14-081027:mdna:86]

[0001104659-14-083669:mdna:91]
[same as prior period, unchanged from 0001104659-14-081027:mdna:87]

[0001104659-14-083669:mdna:92]
Retail sales of PC Keyboards & Desktops remained flat and units sold increased 2% in the three months ended September 30, 2014, compared with the same period of the prior fiscal year. The sales increase was driven by corded and cordless combo products offset by declines in living room keyboards. Sales of corded and cordless combos increased 26% and 6%, respectively and units increased 26% and 4%, respectively. Sales of corded and cordless keyboards decreased 4% and decreased 13%, respectively and units decreased 5% and decreased 14%, respectively during the three months ended September 30, 2014, compared with the same period in the prior fiscal year. Living room keyboards sales decreased 24% and units decreased 18%.

[0001104659-14-083669:mdna:93]
Retail sales of PC Keyboards & Desktops and units sold increased 4% in the six months ended September 30, 2014, compared with the same period of the prior fiscal year. The sales increase was driven by mid-range and low-end corded and cordless combo products. Sales of corded and cordless combos increased 31% and 5%, respectively and units increased 25% and 3%, respectively. Sales of corded and cordless keyboards increased 2% and decreased 12%, respectively and units remained flat and decreased 13%, respectively.

[0001104659-14-083669:mdna:94]
[same as prior period, unchanged from 0001104659-14-081027:mdna:89]

[0001104659-14-083669:mdna:95]
[same as prior period, unchanged from 0001104659-14-081027:mdna:90]

[0001104659-14-083669:mdna:96]
Audio-PC & Wearables sales decreased 17% and units sold decreased 14%, in the three months ended September 30, 2014, compared with the same period of the prior fiscal year. The decrease was primarily due to decreases in PC speaker retail sales.  These decreases reflect both a weakness in the overall market for new PCs and a market shift toward mobile audio devices. Retail sales of our headset products decreased 4% and units decreased 13%. As we have significantly reduced our wearables product portfolio, wearables products have declined significantly and only make up 2% of the category sales.

[0001104659-14-083669:mdna:97]
Audio-PC & Wearables sales decreased 14% and units sold decreased 11%, in the six months ended September 30, 2014, compared with the same period of the prior fiscal year. The decrease was primarily due to decreases in PC speaker retail sales.  These decreases reflect both a weakness in the overall market for new PCs and a market shift toward mobile audio devices. Retail sales of our headset products decreased 4% and units sold decreased 8%. With a much streamlined offering of wearable products sales have declined significantly and only make up 4% of the category sales.

[0001104659-14-083669:mdna:98]
[same as prior period, unchanged from 0001104659-14-081027:mdna:92]

[0001104659-14-083669:mdna:99]
Our retail Video category comprises retail webcams, business webcams, and Unified Communications ConferenceCams.

[0001104659-14-083669:mdna:100]
Retail Video sales increased by 3% and units sold decreased by 17% in the three months ended September 30, 2014, compared with the same period in the prior fiscal year. The sales growth in the Video category, which was achieved across EMEA and Asia Pacific, was driven by our video collaboration offerings, such as the ConferenceCam CC3000E targeted at small and midsize conference rooms, as well as growth in business webcams.

[0001104659-14-083669:mdna:101]
Retail Video sales increased by 7% and units sold decreased by 17% in the six months ended September 30, 2014, compared with the same period in the prior fiscal year. The sales growth in the Video category, which was achieved across all regions, was driven by our video collaboration offerings, such as the Conference Cam CC3000E targeted at small and midsize conference rooms, as well as growth in business webcams. The sales increase was primarily from the Logitech Conference Cam CC3000.

[0001104659-14-083669:mdna:102]
[same as prior period, unchanged from 0001104659-14-081027:mdna:96]

[0001104659-14-083669:mdna:103]
Our retail Remotes category comprises our Harmony branded remotes.

[0001104659-14-083669:mdna:104]
Remote retail sales increased 41% and units sold increased 56% in the three months ended September 30, 2014, compared with the same period of the prior fiscal year. Sales growth was driven by new Harmony Living Home products including Harmony Ultimate Home.

[0001104659-14-083669:mdna:105]
Remote retail sales increased 11% and units sold increased 33% in the six months ended September 30, 2014, compared with the same period of the prior fiscal year. Sales growth was driven by new Harmony Living Home products including Harmony Ultimate Home and the Harmony Ultimate One.

[0001104659-14-083669:mdna:106]
[same as prior period, unchanged from 0001104659-14-081027:mdna:98]

[0001104659-14-083669:mdna:107]
This category comprises a variety of products that we currently intend to transition out of, or have already transitioned out of, because they are no longer strategic to our business. Products currently included in this category include TV Camera, Digital Video Security, TV and home speakers, Google TV products, and Keyboard/ Desktop accessories.

[0001104659-14-083669:mdna:108]
Non-strategic retail sales decreased by 91% and 68% and units sold decreased by 88% and 66% during the three and six months ended September 30, 2014, compared with same period in the prior fiscal year.

[0001104659-14-083669:mdna:109]
[same as prior period, unchanged from 0001104659-14-081027:mdna:100]

[0001104659-14-083669:mdna:110]
OEM sales and units sold decreased by 24% and 35% during the three months ended, and decreased 15% and 24% during the six months ended September 30, 2014, compared with the same period of the prior fiscal year. This decrease was largely attributable the weaker market conditions for sales of new desktop PCs.

[0001104659-14-083669:mdna:111]
[same as prior period, unchanged from 0001104659-14-081027:mdna:102]

[0001104659-14-083669:mdna:112]
Video conferencing net sales decreased 4% and 9% during the three and six months ended September 30, 2014, compared with the same period of the prior fiscal year. Lifesize is in the process of transitioning its product portfolio to the recently announced Lifesize Cloud, a software-as-a-service (SaaS) offering that provides an affordable, simple and scalable video conferencing solution with little to no need for IT involvement. The decline in sales reflects the combination of this short-term portfolio transition and weak market conditions for video conferencing endpoints.

[0001104659-14-083669:mdna:113]
[same as prior period, unchanged from 0001104659-14-081027:mdna:104]

[0001104659-14-083669:mdna:114]
Gross profit for the three and six months ended September 30, 2014 and 2013 was as follows (in thousands):

[0001104659-14-083669:mdna:115]
|  |  | Three Months Ended |  | Six Months Ended |  |
|  |  | September 30, |  | September 30, |  |
|  |  | 2014 |  | 2013 |  | Change |  | 2014 |  | 2013 |  | Change |  |
| Net sales |  | $ | 530,311 |  | $ | 531,143 |  | (0 | )% | $ | 1,012,514 |  | $ | 1,009,673 |  | 0 | % |
| Cost of goods sold |  | 325,533 |  | 348,181 |  | (7 | ) | 625,984 |  | 657,449 |  | (5 | ) |
| Gross profit |  | $ | 204,778 |  | $ | 182,962 |  | 12 |  | $ | 386,530 |  | $ | 352,224 |  | 10 |  |
| Gross margin |  | 38.6 | % | 34.4 | % |  |  | 38.2 | % | 34.9 | % |  |  |

[0001104659-14-083669:mdna:116]
Gross profit consists of net sales, less cost of goods sold, which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, costs of purchasing components from outside suppliers, distribution costs, outside processing costs, write-down of inventories and amortization of intangible assets. Gross profit for the three and six months ended September 30, 2013 included $5.2 million write-off of discontinued products included in cost of goods sold in the consolidated statements of operations resulting from the restructuring of our video conferencing reporting segment.

[0001104659-14-083669:mdna:117]
The improvement in gross margin for both the three and six months ended September 30, 2014 compared with the same periods of the prior fiscal year primarily resulted from the combination of a significant improvement in our Profit Maximization category, driven by product cost reductions, improved scale for our growth categories and prior year write off of $5.2 million for discontinued products resulting from the restructuring of our Video Conferencing reporting segment.

[0001104659-14-083669:mdna:118]
[same as prior period, unchanged from 0001104659-14-081027:mdna:109]

[0001104659-14-083669:mdna:119]
Operating expenses for the three and six months ended September 30, 2014 and 2013 were as follows (in thousands):

[0001104659-14-083669:mdna:120]
|  |  | Three Months Ended |  | Six Months Ended |  |
|  |  | September 30, |  | September 30, |  |
|  |  | 2014 |  | 2013 |  | Change |  | 2014 |  | 2013 |  | Change |  |
| Marketing and selling |  | $ | 95,862 |  | $ | 93,451 |  | 3 | % | $ | 186,908 |  | $ | 194,544 |  | (4 | )% |
| % of net sales |  | 18.1 | % | 17.6 | % |  |  | 18.5 | % | 19.3 | % |  |  |
| Research and development |  | 32,325 |  | 37,485 |  | (14 | ) | 63,641 |  | 74,012 |  | (14 | ) |
| % of net sales |  | 6.1 | % | 7.1 | % |  |  | 6.3 | % | 7.3 | % |  |  |
| General and administrative |  | 34,470 |  | 29,172 |  | 18 |  | 71,149 |  | 58,249 |  | 22 |  |
| % of net sales |  | 6.5 | % | 5.5 | % |  |  | 7.0 | % | 5.8 | % |  |  |
| Restructuring charges, net |  | — |  | 5,465 |  | (100 | ) | — |  | 7,799 |  | (100 | ) |
| % of net sales |  | 0.0 | % | 1.0 | % |  |  | 0.0 | % | 0.8 | % |  |  |
| Total operating expenses |  | $ | 162,657 |  | $ | 165,573 |  | (2 | ) | $ | 321,698 |  | $ | 334,604 |  | (4 | ) |
| % of net sales |  | 30.7 | % | 31.2 | % |  |  | 31.8 | % | 33.1 | % |  |  |

[0001104659-14-083669:mdna:121]
The decrease in total operating expenses for both the three and six months ended September 30, 2014, as a percentage of net sales, compared to the three and six months ended September 30, 2013, was primarily due to continued cost control initiatives.

[0001104659-14-083669:mdna:122]
[same as prior period, unchanged from 0001104659-14-081027:mdna:113]

[0001104659-14-083669:mdna:123]
[same as prior period, unchanged from 0001104659-14-081027:mdna:114]

[0001104659-14-083669:mdna:124]
During the three months ended September 30, 2014, marketing and selling expenses increased 3%, compared to the three months ended September 30, 2013. The increase was primarily due to a $2.0 million increase in the product marketing campaign costs as well as other marketing related costs. During the six months ended September 30, 2014, marketing and selling expenses decreased 4%, compared to the six months ended September 30, 2013. The decrease was primarily due to $7 million from cost control initiatives and decrease in spending for new product launches in Music and Gaming.

[0001104659-14-083669:mdna:125]
[same as prior period, unchanged from 0001104659-14-081027:mdna:116]

[0001104659-14-083669:mdna:126]
[same as prior period, unchanged from 0001104659-14-081027:mdna:117]

[0001104659-14-083669:mdna:127]
During the three months ended September 30, 2014, research and development expense decreased 14%, compared to the three months ended September 30, 2013. The decrease was primarily due to $2.5 million lower personnel-related expenses from the reduction in worldwide workforce resulting from restructuring plans, a $1.5 million prior period write-off of in pre-production gaming components, and a $1.0 million reduced spending for product development. During the six months ended September 30, 2014, research and development expense decreased 14%, compared to the six months ended September 30, 2013. The decrease was primarily due to $4.3 million lower personnel-related expenses from the reduction in worldwide workforce resulting from our recent restructuring plans in 2013.

[0001104659-14-083669:mdna:128]
[same as prior period, unchanged from 0001104659-14-081027:mdna:119]

[0001104659-14-083669:mdna:129]
[same as prior period, unchanged from 0001104659-14-081027:mdna:120]

[0001104659-14-083669:mdna:130]
During the three months ended September 30, 2014, general and administrative expense increased 18%, compared to the three months ended September 30, 2013. The increase was primarily due to an $8.0 million increase in our legal and accounting expense in connection with the Audit Committee’s investigation, partially offset by a $2.9 million decrease in personnel-related expenses. Total expenses related to the Audit Committee’s investigation were $8.0 million and $17.0 million for the three and six months ended September 30, 2014, respectively. During the six months ended September 30, 2014, general and administrative expense increased 22%, compared to the six months ended September 30, 2013. The increase was driven by a $16.8 million increase in our legal and consulting expense primarily due to the Audit Committee investigation. This increase was partially offset by realized savings of $3.7 million from facility cost as a result of the consolidation of some of our facilities located in North America.

[0001104659-14-083669:mdna:131]
[same as prior period, unchanged from 0001104659-14-081027:mdna:122]

[0001104659-14-083669:mdna:132]
During the fourth quarter of fiscal year 2013, Logitech implemented a restructuring plan to align the organization to its strategic priorities of increasing focus on mobility products, improving profitability in PC-related products and enhancing global operational efficiencies. Restructuring charges under this plan primarily consisted of severance and other one-time termination benefits. Charges and other costs related to the workforce reduction are presented as restructuring charges in the consolidated statements of operations. During the three months ended September 30, 2013, restructuring charges under this plan included $4.6 million in termination benefits to affected employees and $0.9 million in lease exit costs.

[0001104659-14-083669:mdna:133]
The Company substantially completed the restructuring in the fourth quarter of fiscal year 2014, and did not incur any material charges during the first six months of fiscal 2015.

[0001104659-14-083669:mdna:134]
[same as prior period, unchanged from 0001104659-14-081027:mdna:125]

[0001104659-14-083669:mdna:135]
The following table summarizes restructuring-related activities during the first two quarters of fiscal years 2013 and 2014 (in thousands):

[0001104659-14-083669:mdna:136]
|  |  | Restructuring |  |
|  |  | Termination |  | Lease Exit |  |  |  |
|  |  | Benefits |  | Costs |  | Total |  |
| March 31, 2013 |  | $ | 13,383 |  | $ | 75 |  | $ | 13,458 |  |
| Charges |  | 2,004 |  | 330 |  | 2,334 |  |
| Cash payments |  | (8,422 | ) | — |  | (8,422 | ) |
| Foreign exchange impact |  | (170 | ) | — |  | (170 | ) |
| June 30, 2013 |  | 6,795 |  | 405 |  | 7,200 |  |
| Charges |  | 4,562 |  | 903 |  | 5,465 |  |
| Cash payments |  | (6,535 | ) | (564 | ) | (7,099 | ) |
| September 30, 2013 |  | $ | 4,822 |  | $ | 744 |  | $ | 5,566 |  |
| March 31, 2014 |  | $ | 142 |  | 7,419 |  | 7,561 |  |
| Cash payments |  | (56 | ) | $ | (407 | ) | $ | (463 | ) |
| June 30, 2014 |  | 86 |  | 7,012 |  | 7,098 |  |
| Cash payments |  | — |  | (420 | ) | (420 | ) |
| September 30, 2014 |  | $ | 86 |  | $ | 6,592 |  | $ | 6,678 |  |

[0001104659-14-083669:mdna:137]
Interest Income, Net

[0001104659-14-083669:mdna:138]
Interest income and expense for the three and six months ended September 30, 2014 and 2013 were as follows (in thousands):

[0001104659-14-083669:mdna:139]
|  |  | Three Months Ended |  | Six Months Ended |  |
|  |  | September 30, |  | September 30, |  |
|  |  | 2014 |  | 2013 |  | Change |  | 2014 |  | 2013 |  | Change |  |
| Interest income |  | $ | 355 |  | $ | 495 |  | (28) | % | $ | 616 |  | $ | 918 |  | (33 | )% |
| Interest expense |  | — |  | $ | (312 | ) | (100 | ) | (3 | ) | (758 | ) | (100 | ) |
|  |  | $ | 355 |  | $ | 183 |  | 94 |  | $ | 613 |  | $ | 160 |  | 283 |  |

[0001104659-14-083669:mdna:140]
Interest income was lower in the three and six months ended September 30, 2014, compared with the three and six months ended September 30, 2013, primarily due to the mix of cash balances held by country during the three and six months ended September 30, 2014 compared to the prior period.

[0001104659-14-083669:mdna:141]
Interest expense was lower in the three and six months ended September 30, 2014, compared with the three and six months ended September 30, 2013, primarily due to commitment fees and non-recurring fees related to our $250 million Senior Revolving Credit Facility entered into in December 2011 that was in place during the three and six months ended September 30, 2013. In December 2013, given the significant improvement in our financial performance and outlook, we chose to terminate this Credit Facility.

[0001104659-14-083669:mdna:142]
39

[0001104659-14-083669:mdna:143]
[same as prior period, unchanged from 0001104659-14-081027:mdna:133]

[0001104659-14-083669:mdna:144]
Other income and expense for the three and six months ended September 30, 2014 and 2013 were as follows (in thousands):

[0001104659-14-083669:mdna:145]
|  |  | Three Months Ended |  | Six Months Ended |  |
|  |  | September 30, |  | September 30, |  |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  |
| Investment income related to deferred compensation plan |  | $ | 385 |  | $ | (121 | ) | $ | 649 |  | $ | 243 |  |
| Impairment of investments |  | (105 | ) | — |  | (105 | ) | (370 | ) |
| Foreign currency exchange gain, net |  | (975 | ) | (77 | ) | (1,504 | ) | 414 |  |
| Other |  | (190 | ) | 260 |  | (123 | ) | (8 | ) |
|  |  | $ | (885 | ) | $ | 62 |  | $ | (1,083 | ) | $ | 279 |  |

[0001104659-14-083669:mdna:146]
Investment income for three and six months ended September 30, 2014 and 2013 represents earnings, gains, and losses on trading investments related to a deferred compensation plan offered by one of our subsidiaries.

[0001104659-14-083669:mdna:147]
During the three months ended September 30, 2014 we had a $0.1 million investment impairment resulting in the write-down of an investment in a privately held company. The $0.4 million investment impairment in the three months ended September 30, 2013 resulted from the write-down of an investment in a privately held company.

[0001104659-14-083669:mdna:148]
The foreign currency exchange losses were $1.0 million and $1.5 million during the three and six months ended September 30, 2014. Foreign currency exchange gains or losses relate to balances denominated in currencies other than the functional currency of a particular subsidiary, to the sale of currencies, and to gains or losses recognized on foreign exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize foreign exchange gains.

[0001104659-14-083669:mdna:149]
[same as prior period, unchanged from 0001104659-14-081027:mdna:140]

[0001104659-14-083669:mdna:150]
The provision for and (benefit from) income taxes and effective tax rates for the three and six months ended September 30, 2014 and 2013 were as follows (in thousands):

[0001104659-14-083669:mdna:151]
|  |  | Three Months Ended September 30, |  | Six Months Ended September 30, |  |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  |
| Provision for income tax |  | $ | 5,501 |  | $ | 3,058 |  | $ | 8,596 |  | $ | 2,257 |  |
| Effective income tax rate |  | 13.2 | % | 17.3 | % | 13.4 | % | 12.5 | % |

[0001104659-14-083669:mdna:152]
The change in the effective income tax rate for the three and six months ended September 30, 2014 compared with the three and six months ended September 30, 2013 is primarily due to the mix of income and losses in the various tax jurisdictions in which we operate.

[0001104659-14-083669:mdna:153]
As of September 30 and March 31, 2014, the total amount of unrecognized tax benefits due to uncertain tax positions was $90.9 million and $91.0 million, respectively, of which $88.7 million and $86.1 million, respectively, would affect the effective income tax rate if recognized.

[0001104659-14-083669:mdna:154]
As of September 30, 2014, we had $86.4 million in non-current income taxes payable and $0.1 million in current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions.  As of March 31, 2014, we had $93.1 million in non-current income taxes payable and $0.3 million in current income taxes payable.  Pursuant to ASU 2013-11 which became effective in the first quarter of fiscal year 2015, we reclassified $9.3 million of unrecognized tax benefits previously presented as non-current income taxes payable to a reduction in non-current deferred tax assets for tax credit carryforwards.

[0001104659-14-083669:mdna:155]
We continue to recognize interest and penalties related to unrecognized tax positions in income tax expense. As of September 30 and March 31, 2014, we had $5.8 million and $5.6 million of accrued interest and penalties related to uncertain tax positions, respectively

[0001104659-14-083669:mdna:156]
[same as prior period, unchanged from 0001104659-14-081027:mdna:149]

[0001104659-14-083669:mdna:157]
[same as prior period, unchanged from 0001104659-14-081027:mdna:150]

[0001104659-14-083669:mdna:158]
As of September 30, 2014, we had cash and cash equivalents of $500.2 million, compared with $469.4 million at March 31, 2014. Our cash and cash equivalents consist of bank demand deposits and short-term time deposits of which 61% is held by our Swiss-based entities, 26% is held by our subsidiaries in Hong Kong and Germany, and 13% is held by various other entities. We do not expect to incur any material adverse tax impact or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001104659-14-083669:mdna:159]
As of September 30, 2014, our working capital was $550.6 million compared with working capital of $478.2 million at March 31, 2014. The increase in working capital over the prior period was primarily due to higher cash, accounts receivable and inventory balances at September 30, 2014.

[0001104659-14-083669:mdna:160]
During the six months ended September 30, 2014, we generated $60.7 million from operating activities. Our main sources of operating cash flows were net income after adding non-cash expenses of depreciation, amortization and share-based compensation expense, and from increases in accounts payable. These sources of operating cash flows were partially offset by increases in accounts receivables and inventories. Net cash used in investing activities was $27.2 million, primarily from $25.0 million of investments in leasehold improvements, computer hardware and software, tooling and equipment. Net cash generated from financing activities was $0.3 million.

[0001104659-14-083669:mdna:161]
We had several uncommitted, unsecured bank lines of credit aggregating $39.1 million as of September 30, 2014. There are no financial covenants under these lines of credit with which we must comply. As of September 30, 2014, we had outstanding bank guarantees of $7.0 million under these lines of credit. We also had credit lines related to corporate credit cards totaling $6.8 million as of September 30, 2014. There are no financial covenants under these credit lines.

[0001104659-14-083669:mdna:162]
[same as prior period, unchanged from 0001104659-14-081027:mdna:155]

[0001104659-14-083669:mdna:163]
[same as prior period, unchanged from 0001104659-14-081027:mdna:156]

[0001104659-14-083669:mdna:164]
|  |  | Six Months Ended |  |
|  |  | September 30, |  |
|  |  | 2014 |  | 2013 |  |
| Net cash provided by operating activities |  | $ | 60,704 |  | $ | 16,309 |  |
| Net cash used in investing activities |  | (27,199 | ) | (25,380 | ) |
| Net cash used in financing activities |  | (302 | ) | (30,441 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (2,393 | ) | 484 |  |
| Net increase (decrease) in cash and cash equivalents |  | $ | 30,810 |  | $ | (39,028 | ) |

[0001104659-14-083669:mdna:165]
41

[0001104659-14-083669:mdna:166]
[same as prior period, unchanged from 0001104659-14-081027:mdna:158]

[0001104659-14-083669:mdna:167]
The following table presents selected financial information and statistics as of September 30, 2014 and 2013 (dollars in thousands):

[0001104659-14-083669:mdna:168]
|  |  | As of |  |
|  |  | September 30, |  |
|  |  | 2014 |  | 2013 |  |
| Accounts receivable, net |  | $ | 252,692 |  | $ | 257,515 |  |
| Inventories |  | 245,237 |  | 293,100 |  |
| Working capital |  | 550,601 |  | 392,470 |  |
| Days sales in accounts receivable (“DSO”)(1) |  | 43 | days | 44 | days |
| Inventory turnover (“ITO”)(2) |  | 5.3 | x | 4.8 | x |

[0001104659-14-083669:mdna:169]
[same as prior period, unchanged from 0001104659-14-081027:mdna:161]

[0001104659-14-083669:mdna:170]
[same as prior period, unchanged from 0001104659-14-081027:mdna:162]

[0001104659-14-083669:mdna:171]
During the six months ended September 30, 2014, we generated net cash of $60.7 million for operating activities, compared to $16.3 million for the same period in the prior fiscal year. The primary drivers of the increase in net cash generated from operating cash flows include an increase in net income of $40.0 million for the six months ended September 30, 2014 from the six months ended September 30, 2013.

[0001104659-14-083669:mdna:172]
DSO remained consistent for the three months ended September 30, 2014 compared to the six months ended September 30, 2013.  Typical payment terms require customers to pay for product sales generally within 30 to 60 days. However, terms may vary by customer type, by country and by selling season. Extended payment terms are sometimes offered to a limited number of customers during the second and third fiscal quarters. We do not modify payment terms on existing receivables, but may offer discounts for early payment.

[0001104659-14-083669:mdna:173]
Inventory turnover during the three months ended September 30, 2014 increased, compared with the three months ended September 30, 2013 due to our better management of inventories.

[0001104659-14-083669:mdna:174]
[same as prior period, unchanged from 0001104659-14-081027:mdna:166]

[0001104659-14-083669:mdna:175]
The following table presents information on our cash flows from investing activities during the six months ended September 30, 2014 and 2013 (in thousands):

[0001104659-14-083669:mdna:176]
|  |  | Six Months Ended |  |
|  |  | September 30, |  |
|  |  | 2014 |  | 2013 |  |
| Purchases of property, plant and equipment |  | $ | (24,964 | ) | $ | (25,186 | ) |
| Investment in privately held companies |  | (2,550 | ) | — |  |
| Acquisitions, net of cash acquired |  | — |  | (650 | ) |
| Purchase of trading investments |  | (2,230 | ) | (6,146 | ) |
| Proceeds from sales of trading investments |  | 2,545 |  | 6,602 |  |
| Net cash used in investing activities |  | $ | (27,199 | ) | $ | (25,380 | ) |

[0001104659-14-083669:mdna:177]
Our expenditures for property, plant and equipment during the six months ended September 30, 2014 and 2013 were primarily expenditures for leasehold improvements, computer hardware and software, tooling and equipment.

[0001104659-14-083669:mdna:178]
During the six months ended September 30, 2014, we made strategic investments of $2.6 million in privately held companies. During the six months ended September 30, 2013, we made a $0.7 million strategic investment.

[0001104659-14-083669:mdna:179]
The purchases and sales of trading investments in the three months ended September 30, 2014 and 2013 represent mutual fund activity directed by participants in a deferred compensation plan offered by one of our subsidiaries. The mutual funds are held by a Rabbi Trust.

[0001104659-14-083669:mdna:180]
[same as prior period, unchanged from 0001104659-14-081027:mdna:171]

[0001104659-14-083669:mdna:181]
The following table presents information on our cash flows from financing activities during the six months ended September 30, 2014 and 2013 (in thousands):

[0001104659-14-083669:mdna:182]
|  |  | Six Months Ended |  |
|  |  | September 30, |  |
|  |  | 2014 |  | 2013 |  |
| Payment of cash dividends |  | $ | — |  | $ | (36,123 | ) |
| Contingent cash payment of acquisition |  | (100 | ) | — |  |
| Repurchase of ESPP awards |  | (1,078 | ) | — |  |
| Proceeds from sales of shares upon exercise of options and purchase rights |  | 1,533 |  | 6,135 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (1,323 | ) | (453 | ) |
| Excess tax benefits from share-based compensation |  | 666 |  | — |  |
| Net cash used in financing activities |  | $ | (302 | ) | $ | (30,441 | ) |

[0001104659-14-083669:mdna:183]
For both the six months ended September 30, 2014 and 2013 no share repurchases were made.

[0001104659-14-083669:mdna:184]
Proceeds from the sale of shares upon exercise of options and purchase rights pursuant our stock plans during the six months ended September 30, 2014 and 2013 were $1.5 million and $6.1 million, respectively. The payment of tax withholdings related to net share settlements of RSUs (restricted stock units) required during the six months ended September 30, 2014 and 2013 was $1.3 million and $0.5 million, respectively. During six months ended September 30, 2013, we paid a cash dividend of CHF 33.7 million (U.S. dollar amount of $36.1 million) out of retained earnings.

[0001104659-14-083669:mdna:185]
[same as prior period, unchanged from 0001104659-14-081027:mdna:176]

[0001104659-14-083669:mdna:186]
[same as prior period, unchanged from 0001104659-14-081027:mdna:177]

[0001104659-14-083669:mdna:187]
In March 2014, our Board of Directors approved a new share buyback program, which authorizes us to invest up to $250.0 million to purchase our own shares. Our share buyback program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market with consideration given to Logitech’s stock price, market conditions and other factors.  The Company was not current on its SEC filings and lost its ability to buy back shares. The company will regain its ability, once it is current on its SEC filings.

[0001104659-14-083669:mdna:188]
[same as prior period, unchanged from 0001104659-14-081027:mdna:180]

[0001104659-14-083669:mdna:189]
During fiscal year 2014, we paid a cash dividend of CHF 33.7 million (U.S. dollar amount of $36.1 million) out of retained earnings. On November 12, 2014, the Board approved, subject to approval by the Company’s shareholders and other Swiss statutory requirements, a dividend of CHF 0.2625 per share. Based on the shares outstanding as of September 30, 2014, net of treasury shares, the aggregate amount of the dividend would be approximately CHF 42.9 million. We plan to issue an annual dividend on a recurring basis. If we do not generate sufficient operating cash flows to support our operations and future planned cash requirements, our operations could be harmed and our access to credit facilities could be restricted or eliminated. However, we believe that the trend of our historical cash flow generation, our projections of future operations and reduced expenses and our available cash balances will provide sufficient liquidity to fund our operations for at least the next 12 months.

[0001104659-14-083669:mdna:190]
[same as prior period, unchanged from 0001104659-14-081027:mdna:206]

[0001104659-14-083669:mdna:191]
[same as prior period, unchanged from 0001104659-14-081027:mdna:183]

[0001104659-14-083669:mdna:192]
[same as prior period, unchanged from 0001104659-14-081027:mdna:184]

[0001104659-14-083669:mdna:193]
We lease facilities under operating leases, certain of which require it to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. The remaining terms on our non-cancelable operating leases expire in various years through 2028. Our asset retirement obligations on these leases as of September 30, 2014 were not material.

[0001104659-14-083669:mdna:194]
[same as prior period, unchanged from 0001104659-14-081027:mdna:186]

[0001104659-14-083669:mdna:195]
As of September 30, 2014, we have fixed purchase commitments for inventory purchases made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled during the third quarter of fiscal year 2015. We also had commitments for consulting services, marketing arrangements, advertising, outsourced customer services, information technology maintenance and support services, and other services. Fixed purchase commitments for capital expenditures and primarily relate to commitments for computer hardware and leasehold improvements. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us the option to reschedule and adjust our requirements based on business needs prior to delivery of goods or performance of services. As of September 30, 2014, the Company’s outstanding purchase commitments had not materially changed since March 31, 2014.

[0001104659-14-083669:mdna:196]
[same as prior period, unchanged from 0001104659-14-081027:mdna:188]

[0001104659-14-083669:mdna:197]
At September 30, 2014, we had $17.6 million in liabilities related to a deferred compensation plan offered by one of our subsidiaries. For more information, please refer to our Annual Report on Form 10-K for the fiscal year ended March 31, 2014.

[0001104659-14-083669:mdna:198]
[same as prior period, unchanged from 0001104659-14-081027:mdna:190]

[0001104659-14-083669:mdna:199]
At September 30, 2014, we had $36.3 million in liabilities related to our defined benefit pension plans and non-retirement post-employment benefit obligations, of which $1.2 million is payable in the next 12 months. For more information, please refer to our Annual Report on Form 10-K for the fiscal year ended March 31, 2014.

[0001104659-14-083669:mdna:200]
[same as prior period, unchanged from 0001104659-14-081027:mdna:192]

[0001104659-14-083669:mdna:201]
[same as prior period, unchanged from 0001104659-14-081027:mdna:193]

[0001104659-14-083669:mdna:202]
[same as prior period, unchanged from 0001104659-14-081027:mdna:194]

[0001104659-14-083669:mdna:203]
[same as prior period, unchanged from 0001104659-14-081027:mdna:195]

[0001104659-14-083669:mdna:204]
Other Contingencies

[0001104659-14-083669:mdna:205]
We are subject to an ongoing formal investigation by the SEC, relating to certain issues including the accounting for Revue inventory valuation reserves that resulted in the restatement, described in the Fiscal 2014 Form 10-K, revision to our financial statements concerning warranty accruals and amortization of intangible assets presented in our Form 10-K/A, filed on August 7, 2013, and our transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. We are cooperating with the SEC in its ongoing investigation. We have entered into an agreement with the SEC to extend the statute of limitations. We cannot predict the outcome of

[0001104659-14-083669:mdna:206]
44

[0001104659-14-083669:mdna:207]
the investigation at this time and any potential fines or penalties, if any, that may arise from the investigation are currently not estimable.

[0001104659-14-083669:mdna:208]
[same as prior period, unchanged from 0001104659-14-081027:mdna:198]

[0001104659-14-083669:mdna:209]
Logitech Europe S.A.  guaranteed payments of a third-party contract manufacturer’s purchase obligations. As of September 30, 2014, the maximum amount of this guarantee was $3.5 million, of which $2.7 million of guaranteed purchase obligations were outstanding.

[0001104659-14-083669:mdna:210]
[same as prior period, unchanged from 0001104659-14-081027:mdna:201]

[0001104659-14-083669:mdna:211]
We indemnify certain of our suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2014, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001104659-14-083669:mdna:212]
[same as prior period, unchanged from 0001104659-14-081027:mdna:203]

[0001104659-14-083669:mdna:213]
Legal Proceedings

[0001104659-14-083669:mdna:214]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of its business. We are currently subject to several such claims and a small number of legal proceedings. We believe that these matters lack merit and we intend to vigorously defend against them. Based on currently available information, we do not believe that resolution of pending matters will have a material adverse effect on our financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that our defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on our business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against us, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect our business.
