# LOGI notes — 0001104659-14-083669


## logi:ScheduleOfBalanceSheetComponentsAssetsTableTextBlock

[0001104659-14-083669:notes:1]
The following table presents the components of certain balance sheet asset amounts as of September 30 and March 31, 2014 (in thousands):

[0001104659-14-083669:notes:2]
|  |  | September 30, |  | March 31, |  |
|  |  | 2014 |  | 2014 |  |
| Accounts receivable: |  |  |  |  |  |
| Accounts receivable |  | $ | 433,237 |  | $ | 338,194 |  |
| Allowance for doubtful accounts |  | (1,762 | ) | (1,712 | ) |
| Allowance for sales returns |  | (19,578 | ) | (19,472 | ) |
| Allowance for cooperative marketing arrangements |  | (29,607 | ) | (24,135 | ) |
| Allowance for customer incentive programs |  | (49,003 | ) | (41,400 | ) |
| Allowance for pricing programs |  | (80,595 | ) | (69,446 | ) |
|  |  | $ | 252,692 |  | $ | 182,029 |  |
| Inventories: |  |  |  |  |  |
| Raw materials |  | $ | 29,333 |  | $ | 24,031 |  |
| Work-in-process |  | — |  | 42 |  |
| Finished goods |  | 215,904 |  | 198,329 |  |
|  |  | $ | 245,237 |  | $ | 222,402 |  |
| Other current assets: |  |  |  |  |  |
| Income tax and value-added tax receivables |  | $ | 20,420 |  | $ | 18,252 |  |
| Deferred tax assets |  | 29,466 |  | 27,013 |  |
| Prepaid expenses and other assets |  | 19,283 |  | 13,892 |  |
|  |  | $ | 69,169 |  | $ | 59,157 |  |
| Property, plant and equipment, net: |  |  |  |  |  |
| Plant, buildings and improvements |  | $ | 70,691 |  | $ | 69,897 |  |
| Equipment |  | 136,379 |  | 134,975 |  |
| Computer equipment |  | 40,654 |  | 40,610 |  |
| Software |  | 82,238 |  | 81,179 |  |
|  |  | 329,962 |  | 326,661 |  |
| Less accumulated depreciation and amortization |  | (265,119 | ) | (256,424 | ) |
|  |  | 64,843 |  | 70,237 |  |
| Construction-in-process |  | 22,104 |  | 15,362 |  |
| Land |  | 2,802 |  | 2,792 |  |
|  |  | $ | 89,749 |  | $ | 88,391 |  |
| Other assets: |  |  |  |  |  |
| Deferred tax assets |  | $ | 42,325 |  | $ | 52,883 |  |
| Trading investments |  | 17,601 |  | 16,611 |  |
| Other assets |  | 7,514 |  | 4,966 |  |
|  |  | $ | 67,440 |  | $ | 74,460 |  |


## logi:ScheduleOfBalanceSheetComponentsLiabilityTableTextBlock

[0001104659-14-083669:notes:3]
The following table presents the components of certain balance sheet liability amounts as of September 30 and March 31, 2014 (in thousands):

[0001104659-14-083669:notes:4]
|  |  | September 30, |  | March 31, |  |
|  |  | 2014 |  | 2014 |  |
| Accrued and other current liabilities: |  |  |  |  |  |
| Accrued personnel expenses |  | $ | 56,224 |  | $ | 55,165 |  |
| Accrued marketing expenses |  | 10,459 |  | 12,844 |  |
| Indirect customer incentive programs |  | 29,876 |  | 31,737 |  |
| Accrued restructuring |  | 1,987 |  | 2,121 |  |
| Deferred revenue |  | 22,015 |  | 22,529 |  |
| Accrued freight and duty |  | 8,402 |  | 6,276 |  |
| Value-added taxes payable |  | 6,632 |  | 9,354 |  |
| Accrued royalties |  | 3,113 |  | 2,653 |  |
| Warranty accrual |  | 12,910 |  | 13,905 |  |
| Employee benefit plan obligation |  | 1,215 |  | 1,100 |  |
| Income taxes payable |  | 7,499 |  | 7,701 |  |
| Other current liabilities |  | 56,259 |  | 46,587 |  |
|  |  | $ | 216,591 |  | $ | 211,972 |  |
| Non-current liabilities: |  |  |  |  |  |
| Warranty accrual |  | $ | 9,294 |  | $ | 10,475 |  |
| Obligation for deferred compensation |  | 17,601 |  | 16,611 |  |
| Long term restructuring |  | 4,691 |  | 5,440 |  |
| Employee benefit plan obligation |  | 36,311 |  | 37,899 |  |
| Deferred rent |  | 14,541 |  | 15,555 |  |
| Deferred tax liability |  | 2,054 |  | 2,304 |  |
| Long term deferred revenue |  | 9,959 |  | 9,350 |  |
| Other non-current liabilities |  | 1,589 |  | 1,715 |  |
|  |  | $ | 96,040 |  | $ | 99,349 |  |


## logi:ScheduleOfErrorCorrectionsAndPriorPeriodAdjustmentsConsolidatedStatementsOfCashFlowsTableTextBlock

[0001104659-14-083669:notes:5]
The following table presents the impact of the correcting adjustments on the Company’s previously reported consolidated statement of cash flows for the six months ended September 30, 2013 (in thousands):

[0001104659-14-083669:notes:6]
|  |  | Six months ended September 30, 2013 |  |
|  |  | As Reported |  | Adjustments* |  | As Revised |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income |  | $ | 15,441 |  | 361 |  | $ | 15,802 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation |  | 19,283 |  | 2,559 |  | 21,842 |  |
| Amortization of other intangible assets |  | 10,518 |  | — |  | 10,518 |  |
| Share-based compensation expense |  | 8,499 |  | — |  | 8,499 |  |
| Impairment of investments |  | 530 |  | — |  | 530 |  |
| Loss on disposal of property, plant and equipment |  | 2,456 |  | — |  | 2,456 |  |
| Deferred income taxes |  | (3,902 | ) | 1 |  | (3,901 | ) |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |
| Accounts receivable, net |  | (77,042 | ) | 737 |  | (76,305 | ) |
| Inventories |  | (21,350 | ) | (323 | ) | (21,673 | ) |
| Other assets |  | (5,893 | ) | (1,248 | ) | (7,141 | ) |
| Accounts payable |  | 39,555 |  | (962 | ) | 38,593 |  |
| Accrued and other liabilities |  | 26,091 |  | 998 |  | 27,089 |  |
| Net cash provided by operating activities |  | 14,186 |  | 2,123 |  | 16,309 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (23,063 | ) | (2,123 | ) | (25,186 | ) |
| Acquisitions, net of cash acquired |  | (650 | ) | — |  | (650 | ) |
| Purchases of trading investments |  | (6,146 | ) | — |  | (6,146 | ) |
| Proceeds from sales of trading investments |  | 6,602 |  | — |  | 6,602 |  |
| Net cash used in investing activities |  | (23,257 | ) | (2,123 | ) | (25,380 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Payment of cash dividends |  | (36,123 | ) | — |  | (36,123 | ) |
| Proceeds from sales of shares upon exercise of options and purchase rights |  | 6,135 |  | — |  | 6,135 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (453 | ) | — |  | (453 | ) |
| Net cash used in financing activities |  | (30,441 | ) | — |  | (30,441 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | 484 |  | — |  | 484 |  |
| Net decrease in cash and cash equivalents |  | (39,028 | ) | — |  | (39,028 | ) |
| Cash and cash equivalents at beginning of period |  | 333,824 |  | — |  | 333,824 |  |
| Cash and cash equivalents at end of period |  | $ | 294,796 |  | $ | — |  | $ | 294,796 |  |
| Property, plant and equipment purchased during the period and included in period end liability accounts |  | $ | 1,935 |  | $ | — |  | $ | 1,935 |  |

[0001104659-14-083669:notes:7]
* The adjustments included in these financial statements for the six months ended September 30, 2013 primarily related to a correction to revenue that was previously recorded as an out-of-period adjustment and is now being reported in the correct period, capitalization of property, plant and equipment which was previously incorrectly expensed, pension obligation, other misstatements, and the tax impact of these adjustments.


## logi:ScheduleOfErrorCorrectionsAndPriorPeriodAdjustmentsConsolidatedStatementsOfComprehensiveIncomeLossTableTextBlock

[0001104659-14-083669:notes:8]
The following table presents the impact of the correcting adjustments on the Company’s previously reported consolidated statement of comprehensive income for the three and six months ended September 30, 2013 (in thousands):

[0001104659-14-083669:notes:9]
|  |  | Three Months Ended |  | Six Months Ended |  |
|  |  | September 30, 2013 |  | September 30, 2013 |  |
|  |  | As Reported |  | Adjustments* |  | As Revised |  | As Reported |  | Adjustments* |  | As Revised |  |
| Net income |  | $ | 14,398 |  | $ | 178 |  | $ | 14,576 |  | $ | 15,441 |  | $ | 361 |  | $ | 15,802 |  |
| Other comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation gain |  | 2,728 |  | — |  | 2,728 |  | 2,829 |  | 598 |  | 3,427 |  |
| Defined benefit pension plans: |  |  |  |  |  |  |  |  |  | — |  | — |  |
| Net loss and prior service costs, net of taxes |  | (804 | ) | — |  | (804 | ) | (1,000 | ) | 761 |  | (239 | ) |
| Reclassification of amortization included in operating expenses |  | 309 |  | — |  | 309 |  | 615 |  | 779 |  | 1,394 |  |
| Hedging gain (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrealized hedging loss |  | (1,373 | ) | — |  | (1,373 | ) | (2,286 | ) | — |  | (2,286 | ) |
| Reclassification of hedging (gain) loss included in cost of goods sold |  | (94 | ) | — |  | (94 | ) | 184 |  | — |  | 184 |  |
| Other comprehensive income: |  | 766 |  | — |  | 766 |  | 342 |  | 2,138 |  | 2,480 |  |
| Total comprehensive income |  | $ | 15,164 |  | $ | 178 |  | $ | 15,342 |  | $ | 15,783 |  | $ | 2,499 |  | $ | 18,282 |  |

[0001104659-14-083669:notes:10]
* The adjustments included in these financial statements for the three and six months ended September 30, 2013 primarily related to a correction to revenue that was previously recorded as an out-of-period adjustment and is now being reported in the correct period, capitalization of property, plant and equipment which was previously incorrectly expensed, pension obligation, other misstatements, and the tax impact of these adjustments.


## logi:ScheduleOfErrorCorrectionsAndPriorPeriodAdjustmentsConsolidatedStatementsOfOperationsTableTextBlock

[0001104659-14-083669:notes:11]
The following table presents the impact of the correcting adjustments on the Company’s previously reported consolidated statement of operations for the three and six months ended September 30, 2013 (in thousands):

[0001104659-14-083669:notes:12]
|  |  | Three Months Ended |  | Six Months Ended |  |
|  |  | September 30, 2013 |  | September 30, 2013 |  |
|  |  | As Reported |  | Adjustments* |  | As Revised |  | As Reported |  | Adjustments* |  | As Revised |  |
| Net sales |  | $ | 531,972 |  | $ | (829 | ) | $ | 531,143 |  | $ | 1,009,896 |  | $ | (223 | ) | $ | 1,009,673 |  |
| Cost of goods sold |  | 348,559 |  | (378 | ) | 348,181 |  | 658,128 |  | (679 | ) | 657,449 |  |
| Gross profit |  | 183,413 |  | (451 | ) | 182,962 |  | 351,768 |  | 456 |  | 352,224 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 93,710 |  | (259 | ) | 93,451 |  | 194,345 |  | 199 |  | 194,544 |  |
| Research and development |  | 37,633 |  | (148 | ) | 37,485 |  | 73,824 |  | 188 |  | 74,012 |  |
| General and administrative |  | 29,395 |  | (223 | ) | 29,172 |  | 58,543 |  | (294 | ) | 58,249 |  |
| Restructuring charges |  | 5,465 |  | — |  | 5,465 |  | 7,799 |  | — |  | 7,799 |  |
| Total operating expenses |  | 166,203 |  | (630 | ) | 165,573 |  | 334,511 |  | 93 |  | 334,604 |  |
| Operating income |  | 17,210 |  | 179 |  | 17,389 |  | 17,257 |  | 363 |  | 17,620 |  |
| Interest income, net |  | 183 |  | — |  | 183 |  | 160 |  | — |  | 160 |  |
| Other income, net |  | 62 |  | — |  | 62 |  | 279 |  | — |  | 279 |  |
| Income before income taxes |  | 17,455 |  | 179 |  | 17,634 |  | 17,696 |  | 363 |  | 18,059 |  |
| Provision for income taxes |  | 3,057 |  | 1 |  | 3,058 |  | 2,255 |  | 2 |  | 2,257 |  |
| Net income |  | $ | 14,398 |  | $ | 178 |  | $ | 14,576 |  | $ | 15,441 |  | $ | 361 |  | $ | 15,802 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.09 |  | $ | — |  | $ | 0.09 |  | $ | 0.10 |  | $ | — |  | $ | 0.10 |  |
| Diluted |  | $ | 0.09 |  | $ | — |  | $ | 0.09 |  | $ | 0.10 |  | $ | — |  | $ | 0.10 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 159,969 |  | — |  | 159,969 |  | 159,637 |  | — |  | 159,637 |  |
| Diluted |  | 161,183 |  | — |  | 161,183 |  | 160,875 |  | — |  | 160,875 |  |


## logi:ScheduleOfRevenueByProductFamilyExcludingInterCompanyTransactionsTableTextBlock

[0001104659-14-083669:notes:13]
Net sales by product family, excluding intercompany transactions, for the three and six months ended September 30, 2014 and 2013 were as follows (in thousands):

[0001104659-14-083669:notes:14]
|  |  | Three Months Ended |  | Six Months Ended |  |
|  |  | September 30, |  | September 30, |  |
|  |  | 2014 |  | 2013 (1) |  | 2014 |  | 2013 (1) |  |
| Peripherals: |  |  |  |  |  |  |  |  |  |
| PC Gaming |  | $ | 47,506 |  | $ | 43,260 |  | $ | 94,382 |  | $ | 83,473 |  |
| Tablet & Other Accessories |  | 28,158 |  | 34,695 |  | 59,874 |  | 73,254 |  |
| Mobile Speakers |  | 48,538 |  | 19,967 |  | 77,367 |  | 33,834 |  |
| Growth |  | 124,202 |  | 97,922 |  | 231,623 |  | 190,561 |  |
| Pointing Devices |  | 127,693 |  | 130,656 |  | 240,735 |  | 245,307 |  |
| PC Keyboards & Desktops |  | 105,718 |  | 105,260 |  | 211,241 |  | 203,273 |  |
| Audio-PC &Wearables |  | 58,677 |  | 70,523 |  | 108,303 |  | 126,061 |  |
| Video |  | 37,563 |  | 36,645 |  | 72,139 |  | 67,585 |  |
| Remotes |  | 18,776 |  | 13,327 |  | 31,108 |  | 27,901 |  |
| Profit Maximization |  | 348,427 |  | 356,411 |  | 663,526 |  | 670,127 |  |
| Other |  | 834 |  | 9,691 |  | 2,127 |  | 17,179 |  |
| Non-Strategic |  | 834 |  | 9,691 |  | 2,127 |  | 17,179 |  |
| Retail |  | 473,463 |  | 464,024 |  | 897,276 |  | 877,867 |  |
| OEM |  | 28,394 |  | 37,526 |  | 61,027 |  | 72,039 |  |
|  |  | 501,857 |  | 501,550 |  | 958,303 |  | 949,906 |  |
| Video conferencing |  | 28,454 |  | 29,593 |  | 54,211 |  | 59,767 |  |
|  |  | $ | 530,311 |  | $ | 531,143 |  | $ | 1,012,514 |  | $ | 1,009,673 |  |

[0001104659-14-083669:notes:15]
[same as prior period, unchanged from 0001104659-14-081027:notes:26]


## us-gaap:AccountingChangesAndErrorCorrectionsTextBlock

[0001104659-14-083669:notes:16]
Note 2 —Revision of Previously Issued Financial Statements

[0001104659-14-083669:notes:17]
As disclosed in the Company’s Annual Report on Form 10-K for the year ended March 31, 2014 and in the audited consolidated financial statements contained therein, the Company has restated and revised its financial statements for the fiscal years ended March 31, 2012 and 2013, respectively. The impact of the adjustments also immaterially impact the financial statements for the first three quarters of the fiscal year ended March 31, 2014 as previously included in the Company’s quarterly reports on Form 10-Q for Fiscal 2014. The financial statements for three and six months ended September 30, 2013 included in this Form 10-Q are revised as described below for those adjustments and should be read in conjunction with Item 8, “Financial Statements and Supplementary Data” disclosed in the Company’s Annual Report on Form 10-K for the fiscal year ended March 31, 2014, filed with the SEC on November 13, 2014.

[0001104659-14-083669:notes:18]
The adjustments included in these financial statements for the three and six months ended September 30, 2013 primarily related to a correction to revenue that was previously recorded as an out-of-period adjustment and is now being reported in the correct period, capitalization of property, plant and equipment which was previously incorrectly expensed, other misstatements, and the tax impact of these adjustments.

[0001104659-14-083669:notes:19]
Consolidated Statements of Operations.

[0001104659-14-083669:notes:20]
Consolidated Statements of Comprehensive Income

[0001104659-14-083669:notes:21]
Consolidated Statement of Cash Flows


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001104659-14-083669:notes:22]
[same as prior period, unchanged from 0001104659-14-081027:notes:31]

[0001104659-14-083669:notes:23]
Basis of Presentation

[0001104659-14-083669:notes:24]
The consolidated interim financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (“GAAP”) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. They should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2014, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (“SEC”) on November 13, 2014.  In the opinion of management, these consolidated financial statements include all adjustments, consisting of normal recurring adjustments, necessary for a fair statement of the results for the periods presented. Operating results for the three and six months ended September 30, 2014 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2015, or any future periods.

[0001104659-14-083669:notes:25]
[same as prior period, unchanged from 0001104659-14-081027:notes:32]

[0001104659-14-083669:notes:26]
The Company’s fiscal year ends on March 31. Interim quarters are thirteen-week periods, each ending on a Friday.  For purposes of presentation, the Company has indicated its quarterly periods as ending on the month end.

[0001104659-14-083669:notes:27]
[same as prior period, unchanged from 0001104659-14-081027:notes:34]

[0001104659-14-083669:notes:28]
There have been no substantial changes in the Company’s significant accounting policies during the six months ended September 30, 2014 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2014.

[0001104659-14-083669:notes:29]
[same as prior period, unchanged from 0001104659-14-081027:notes:36]

[0001104659-14-083669:notes:30]
[same as prior period, unchanged from 0001104659-14-081027:notes:37]

[0001104659-14-083669:notes:31]
[same as prior period, unchanged from 0001104659-14-081027:notes:38]

[0001104659-14-083669:notes:32]
In May 2014, the FASB issued Accounting Standards Update No. 2014-09, “Revenue from Contracts with Customers (Topic 606),” (“ASU 2014-09”). ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. This new revenue recognition model provides a five-step analysis in determining when and how revenue is recognized. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The new standard will be effective for the Company beginning April 1, 2017.  Early application is prohibited.  The Company is currently evaluating the impact that adopting this new guidance will have on its consolidated financial statements.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001104659-14-083669:notes:33]
Note 11 — Commitments and Contingencies

[0001104659-14-083669:notes:34]
Product Warranties

[0001104659-14-083669:notes:35]
All of the Company’s peripherals products are covered by warranty to be free from defects in material and workmanship for periods ranging from one year to five years. At the time of sale, the Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. The Company’s estimate of costs to fulfill its warranty obligations is based on historical experience and expectations of future conditions. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly.

[0001104659-14-083669:notes:36]
Changes in the Company’s warranty liability for the three and six months ended September 30, 2014 and 2013 were as follows (in thousands):

[0001104659-14-083669:notes:37]
|  |  | Three Months Ended |  | Six Months Ended |  |
|  |  | September 30, |  | September 30, |  |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  |
| Beginning of the period |  | $ | 23,420 |  | $ | 23,550 |  | $ | 24,380 |  | $ | 21,442 |  |
| Provision |  | 2,020 |  | 3,664 |  | 4,226 |  | 7,190 |  |
| Settlements |  | (3,236 | ) | (4,193 | ) | (6,402 | ) | (7,938 | ) |
| Adjustment (1) |  | — |  | — |  | — |  | 2,327 |  |
| End of the period |  | $ | 22,204 |  | $ | 23,021 |  | $ | 22,204 |  | $ | 23,021 |  |

[0001104659-14-083669:notes:38]
|  | (1) |  | During the six month period September 30, 2013, the warranty liability allocated to the Company’s - Remotes product category was reclassified from liabilities held for sale. |

[0001104659-14-083669:notes:39]
Purchase Commitments

[0001104659-14-083669:notes:40]
Commitments for inventory purchases are made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers and are expected to be fulfilled by September 30, 2014. Operating expense commitments are for consulting services, marketing arrangements, advertising, outsourced customer services, information technology maintenance and support services, and other services. Fixed purchase commitments for capital expenditures primarily related to commitments for computer hardware and leasehold improvements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the Company the option to reschedule and adjust its requirements based on the business needs prior to delivery of goods or performance of services. As of September 30, 2014, the Company’s outstanding purchase commitments had not materially changed since March 31, 2014.

[0001104659-14-083669:notes:41]
Other Contingencies

[0001104659-14-083669:notes:42]
The Company is subject to an ongoing formal investigation by the SEC, relating to certain issues including the accounting for Revue inventory valuation reserves that resulted in the restatement described in the Fiscal 2014 Form 10-K, revision to the Company’s financial statements concerning warranty accruals and amortization of intangible assets presented in the Company’s Form 10-K/A, filed on August 7, 2013, and the Company’s transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. The Company is cooperating with the SEC in its ongoing investigation. The Company has entered into an agreement with the SEC to extend the statute of limitations. The Company cannot predict the outcome of the investigation at this time and any potential fines or penalties, if any, that may arise from the investigation are currently not estimable.

[0001104659-14-083669:notes:43]
Guarantees

[0001104659-14-083669:notes:44]
Logitech Europe S.A.  guaranteed payments of a third-party contract manufacturer’s purchase obligations. As of September 30, 2014, the maximum amount of this guarantee was $3.5 million, of which $2.7 million of guaranteed purchase obligations were outstanding.

[0001104659-14-083669:notes:45]
Indemnifications

[0001104659-14-083669:notes:46]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2014, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001104659-14-083669:notes:47]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001104659-14-083669:notes:48]
Legal Proceedings

[0001104659-14-083669:notes:49]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001104659-14-083669:notes:50]
[same as prior period, unchanged from 0001104659-14-081027:notes:42]

[0001104659-14-083669:notes:51]
[same as prior period, unchanged from 0001104659-14-081027:notes:43]

[0001104659-14-083669:notes:52]
As of September 30, 2014, the Company offers the 2006 ESPP (2006 Employee Share Purchase Plan (Non-U.S.)), the 1996 ESPP (1996 Employee Share Purchase Plan (U.S.)), the 2006 Plan (2006 Stock Incentive Plan) and the 2012 Plan (2012 Stock Inducement Equity Plan). Please refer to our fiscal year 2014 Form 10-K for additional information regarding the Employee Share Purchase Plans and Stock Incentive Plans.

[0001104659-14-083669:notes:53]
The Company was not current with its periodic reports required to be filed with the SEC and was therefore unable to issue any shares under its Registration Statements on Form S-8 after July 31, 2014. Given the proximity of the unavailability of those registration statements and the end of the current ESPP offering period, also on July 31, 2014, the Compensation Committee authorized the termination of the current ESPP offering period and a one-time payment to each participant in an amount equal to the fifteen percent (15%) discount at which shares would otherwise have been repurchased pursuant to the current period of the ESPPs. This one-time payment was accounted for as a repurchase of equity awards that reduced additional paid in capital, resulting in no additional compensation cost. Given the unavailability of the Company’s Registration Statements on Form S-8, no new ESPP offering periods were initiated during the three months ended September 30, 2014.

[0001104659-14-083669:notes:54]
The following table summarizes the share-based compensation expense and related tax benefit recognized for the three and six months ended September 30, 2014 and 2013 (in thousands):

[0001104659-14-083669:notes:55]
|  |  | Three Months Ended |  | Six Months Ended |  |
|  |  | September 30, |  | September 30, |  |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  |
| Cost of goods sold |  | $ | 627 |  | $ | 594 |  | $ | 1,165 |  | $ | 1,171 |  |
| Marketing and selling |  | 1,653 |  | 1,017 |  | 4,209 |  | 2,923 |  |
| Research and development |  | 552 |  | 840 |  | 1,396 |  | 1,934 |  |
| General and administrative |  | 3,229 |  | 1,658 |  | 6,229 |  | 2,471 |  |
| Total share-based compensation expense |  | 6,061 |  | 4,109 |  | 12,999 |  | 8,499 |  |
| Income tax benefit |  | (1,913 | ) | (1,300 | ) | (3,097 | ) | (2,175 | ) |
| Total share-based compensation expense, net of income tax |  | $ | 4,148 |  | $ | 2,809 |  | $ | 9,902 |  | $ | 6,324 |  |

[0001104659-14-083669:notes:56]
During both of the three months ended September 30, 2014 and 2013, the Company capitalized $0.4 million of stock-based compensation expenses as inventory.

[0001104659-14-083669:notes:57]
[same as prior period, unchanged from 0001104659-14-081027:notes:46]

[0001104659-14-083669:notes:58]
Certain of the Company’s subsidiaries have defined contribution employee benefit plans covering all or a portion of their employees. Contributions to these plans are discretionary for certain plans and are based on specified or statutory requirements for others. The charges to expense for these plans for the three months ended September 30, 2014 and 2013 were $1.1 million and $1.6 million, and for the six months ended September 30, 2014 and 2013 were $2.7 million and $3.3 million, respectively.

[0001104659-14-083669:notes:59]
[same as prior period, unchanged from 0001104659-14-081027:notes:48]

[0001104659-14-083669:notes:60]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The cost recorded of $1.9 million and $2.2 million for the three months ended September 30, 2014 and 2013 and $3.9 million and $5.2 million for the six months ended September 30, 2014 and 2013 was primarily related to service costs.


## us-gaap:DebtDisclosureTextBlock

[0001104659-14-083669:notes:61]
Note 10— Financing Arrangements

[0001104659-14-083669:notes:62]
The Company had several uncommitted, unsecured bank lines of credit aggregating $39.1 million as of September 30, 2014. There are no financial covenants under these lines of credit with which the Company must comply. As of September 30, 2014, the Company had outstanding bank guarantees of $7.0 million under these lines of credit. The Company also had credit lines related to corporate credit cards totaling $6.8 million as of September 30, 2014 and $6.9 million as of March 31, 2014. There are no financial covenants under these credit lines.


## us-gaap:EarningsPerShareTextBlock

[0001104659-14-083669:notes:63]
[same as prior period, unchanged from 0001104659-14-081027:notes:40]

[0001104659-14-083669:notes:64]
The computations of basic and diluted net income per share for the Company were as follows (in thousands, except per share amounts):

[0001104659-14-083669:notes:65]
|  |  | Three Months Ended |  | Six Months Ended |  |
|  |  | September 30, |  | September 30, |  |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  |
| Net income |  | $ | 36,090 |  | $ | 14,576 |  | $ | 55,766 |  | $ | 15,802 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 163,230 |  | 159,969 |  | 163,121 |  | 159,637 |  |
| Effect of potentially dilutive equivalent shares |  | 2,835 |  | 1,214 |  | 2,828 |  | 1,238 |  |
| Weighted average shares outstanding - diluted |  | 166,065 |  | 161,183 |  | 165,949 |  | 160,875 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.22 |  | $ | 0.09 |  | $ | 0.34 |  | $ | 0.10 |  |
| Diluted |  | $ | 0.22 |  | $ | 0.09 |  | $ | 0.34 |  | $ | 0.10 |  |

[0001104659-14-083669:notes:66]
Share equivalents attributable to outstanding stock options and RSUs, and ESPP of 8,317,744 and 15,408,542 for the three months ended September 30, 2014 and 2013 and 8,147,312 and 16,829,424 for the six months ended September 30, 2014 and 2013 were excluded from the calculation of diluted net income per share because to do so would have been anti-dilutive for the periods indicated.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001104659-14-083669:notes:67]
Note  8— Fair Value Measurements

[0001104659-14-083669:notes:68]
[same as prior period, unchanged from 0001104659-14-081027:notes:65]

[0001104659-14-083669:notes:69]
[same as prior period, unchanged from 0001104659-14-081027:notes:66]

[0001104659-14-083669:notes:70]
|  | · |  | Level 1 — Quoted prices in active markets for identical assets or liabilities. |

[0001104659-14-083669:notes:71]
|  | · |  | Level 2 — Observable inputs other than quoted market prices included in Level 1, such as quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active; or other inputs that are observable or can be corroborated by observable market data. |

[0001104659-14-083669:notes:72]
|  | · |  | Level 3 — Unobservable inputs that are supported by little or no market activity and that are significant to the fair value of the assets or liabilities. This includes certain pricing models, discounted cash flow methodologies and similar techniques that use significant unobservable inputs. |

[0001104659-14-083669:notes:73]
The following table presents the Company’s financial assets and liabilities, that were accounted for at fair value, excluding assets related to the Company’s defined benefit pension plans, classified by the level within the fair value hierarchy (in thousands):

[0001104659-14-083669:notes:74]
|  |  | September 30, 2014 |  | March 31, 2014 |  |
|  |  | Level 1 |  | Level 2 |  | Level 1 |  | Level 2 |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | 220,565 |  | — |  | 200,641 |  | — |  |
|  |  | $ | 220,565 |  | $ | — |  | $ | 200,641 |  | $ | — |  |
| Trading investments for deferred compensation plan: |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 3,189 |  | $ | — |  | $ | 3,139 |  | $ | — |  |
| Mutual funds |  | 14,412 |  | — |  | 13,472 |  | — |  |
|  |  | $ | 17,601 |  | $ | — |  | $ | 16,611 |  | $ | — |  |
| Foreign exchange derivative assets |  | $ | — |  | $ | 2,690 |  | $ | — |  | $ | 155 |  |
| Foreign exchange derivative liabilities |  | $ | — |  | $ | 77 |  | $ | — |  | $ | 701 |  |

[0001104659-14-083669:notes:75]
There were no significant Level 3 financial assets as of September 30, 2014 and March 31, 2014.

[0001104659-14-083669:notes:76]
[same as prior period, unchanged from 0001104659-14-081027:notes:71]

[0001104659-14-083669:notes:77]
[same as prior period, unchanged from 0001104659-14-081027:notes:72]

[0001104659-14-083669:notes:78]
[same as prior period, unchanged from 0001104659-14-081027:notes:73]

[0001104659-14-083669:notes:79]
The Company’s investment securities portfolio consists of marketable securities (money market and mutual funds) related to a deferred compensation plan at September 30, 2014 and March 31, 2014.

[0001104659-14-083669:notes:80]
The marketable securities related to the deferred compensation plan are classified as non-current assets. Since participants in the deferred compensation plan may select the mutual funds in which their compensation deferrals are invested within the confines of the Rabbi Trust, which holds the marketable securities, the Company has designated these marketable securities as trading investments, although there is no intent to actively buy and sell securities within the objective of generating profits on short-term difference in market prices. Management has classified the investments as non-current assets because final sale of the investments or realization of proceeds by plan participants is not expected within the Company’s normal operating cycle of one year. The marketable securities are recorded at a fair value of $17.6 million and $16.6 million as of September 30 and March 31, 2014, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 securities. Earnings, gains and losses on trading investments are included in other income (expense), net.

[0001104659-14-083669:notes:81]
[same as prior period, unchanged from 0001104659-14-081027:notes:76]

[0001104659-14-083669:notes:82]
Under the agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company does not net settle transactions with a single net amount payable by one party to the other. In accordance with ASU 2011-11, the Company presents its derivative instruments at gross fair values in the Consolidated Balance Sheets as of September 30, 2014 and March 31, 2014.

[0001104659-14-083669:notes:83]
The following table presents the fair values of the Company’s derivative instruments and their locations on its Consolidated Balance Sheets as of September 30 and March 31, 2014 (in thousands):

[0001104659-14-083669:notes:84]
|  |  | Derivatives |  |
|  |  | Asset |  | Liability |  |
|  |  | September 30, |  | March 31, |  | September 30, |  | March 31, |  |
|  |  | 2014 |  | 2014 |  | 2014 |  | 2014 |  |
| Designed as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Cash flow hedges |  | $ | 2,689 |  | $ | 4 |  | $ | — |  | $ | 243 |  |
| Not designed as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | 1 |  | 151 |  | 77 |  | 458 |  |
|  |  | $ | 2,690 |  | $ | 155 |  | $ | 77 |  | $ | 701 |  |

[0001104659-14-083669:notes:85]
The following table presents the amounts of gains and losses on the Company’s derivative instruments for the three and six months ended September 30, 2014 and 2013 (in thousands):

[0001104659-14-083669:notes:86]
|  |  | Three Months Ended |  |
|  |  | September 30, |  |
|  |  | Amount of |  | Amount of Gain (Loss) |  |  |  |
|  |  | Gain (Loss) Deferred as a |  | Reclassified from Accumulated |  | Amount of Gain (Loss) |  |
|  |  | Component of Accumulated |  | Other Comprehensive Income to |  | Immediately Recognized in |  |
|  |  | Other Comprehensive Income |  | Costs of Goods Sold |  | Other Income (Expense), Net |  |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  |
| Designed as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash flow hedges |  | $ | 3,290 |  | $ | (1,467 | ) | $ | (215 | ) | $ | (94 | ) | $ | (1 | ) | $ | 16 |  |
| Not designed as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | — |  | — |  | — |  | — |  | 735 |  | (477 | ) |
|  |  | $ | 3,290 |  | $ | (1,467 | ) | $ | (215 | ) | $ | (94 | ) | $ | 734 |  | $ | (461 | ) |

[0001104659-14-083669:notes:87]
|  |  | Six Months Ended |  |
|  |  | September 30, |  |
|  |  | Amount of |  | Amount of Gain (Loss) |  |  |  |  |  |
|  |  | Gain (Loss) Deferred as a |  | Reclassified from Accumulated |  | Amount of Gain (Loss) |  |
|  |  | Component of Accumulated |  | Other Comprehensive Income to |  | Immediately Recognized in |  |
|  |  | Other Comprehensive Income |  | Costs of Goods Sold |  | Other Income (Expense), Net |  |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  |
| Designed as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash flow hedges |  | $ | 3,938 |  | $ | (2,102 | ) | $ | 185 |  | $ | 184 |  | $ | (56 | ) | $ | 46 |  |
| Not designed as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | — |  | — |  | — |  | — |  | 316 |  | 908 |  |
|  |  | $ | 3,938 |  | $ | (2,102 | ) | $ | 185 |  | $ | 184 |  | $ | 260 |  | $ | 954 |  |

[0001104659-14-083669:notes:88]
[same as prior period, unchanged from 0001104659-14-081027:notes:78]

[0001104659-14-083669:notes:89]
The Company enters into foreign exchange forward contracts to hedge against exposure to changes in foreign currency exchange rates related to its subsidiaries’ forecasted inventory purchases. The Company has one entity with a euro functional currency that purchases inventory in U.S. dollars. The primary risk managed by using derivative instruments is the foreign currency exchange rate risk. The Company has designated these derivatives as cash flow hedges. The Company does not use derivative financial instruments for trading or speculative purposes. These hedging contracts mature within four months, and are denominated in the same currency as the underlying transactions. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. The Company assesses the effectiveness of the hedges by comparing changes in the spot rate of the currency underlying the forward contract with changes in the spot rate of the currency in which the forecasted transaction will be consummated. If the underlying transaction being hedged fails to occur or if a portion of the hedge does not generate offsetting changes in the foreign currency exposure of forecasted inventory purchases, the Company immediately recognizes the gain or loss on the associated financial instrument in other income (expense). Such gains and losses were immaterial during the three and six months ended September 30, 2014 and 2013. Cash flows from such hedges are classified as operating activities in the consolidated statements of cash flows. The notional amounts of foreign exchange forward contracts outstanding related to forecasted inventory purchases were $63.4 million (€49.8 million) and $51.8 million (€37.6 million) at September 30, 2014 and March 31, 2014. The notional amount represents the future cash flows under contracts to purchase foreign currencies.

[0001104659-14-083669:notes:90]
[same as prior period, unchanged from 0001104659-14-081027:notes:80]

[0001104659-14-083669:notes:91]
[same as prior period, unchanged from 0001104659-14-081027:notes:81]

[0001104659-14-083669:notes:92]
The notional amounts of foreign exchange forward contracts outstanding at September 30 and March 31, 2014 relating to foreign currency receivables or payables were $11.4 million and $23.2 million, respectively. Open forward contracts as of September 30, 2014 consisted of contracts in U.S. dollars to purchase Taiwanese dollars at future dates at pre-determined exchange rates. Open forward contracts as of March 31, 2014 consisted of contracts in U.S. dollars to purchase Taiwanese dollars and contracts in euros to sell British pounds at future dates at pre-determined exchange rates. The notional amounts of foreign exchange swap contracts outstanding at September 30 and March 31, 2014 were $27.8 million and $30.5 million, respectively. Swap contracts outstanding at September 30, 2014 consisted of contracts in Mexican pesos, Japanese yen, British pounds, and Australian dollars. Swap contracts outstanding at March 31, 2014 consisted of contracts in Mexican pesos, Japanese yen and Australian dollars.

[0001104659-14-083669:notes:93]
[same as prior period, unchanged from 0001104659-14-081027:notes:83]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001104659-14-083669:notes:94]
[same as prior period, unchanged from 0001104659-14-081027:notes:84]

[0001104659-14-083669:notes:95]
[same as prior period, unchanged from 0001104659-14-081027:notes:85]

[0001104659-14-083669:notes:96]
[same as prior period, unchanged from 0001104659-14-081027:notes:86]

[0001104659-14-083669:notes:97]
[same as prior period, unchanged from 0001104659-14-081027:notes:87]

[0001104659-14-083669:notes:98]
There have been no events or circumstances during the three months ended September 30, 2014 that have required the Company to perform an interim assessment of goodwill.

[0001104659-14-083669:notes:99]
[same as prior period, unchanged from 0001104659-14-081027:notes:89]

[0001104659-14-083669:notes:100]
The following table summarizes the activity in the Company’s goodwill balance during the six months ended September 30, 2014 (in thousands):

[0001104659-14-083669:notes:101]
|  |  | September 30, 2014 |  |
|  |  |  |  | Video |  |  |  |
|  |  | Peripherals |  | Conferencing |  | Total |  |
| Beginning of the period |  | $ | 219,415 |  | $ | 125,595 |  | $ | 345,010 |  |
| Foreign currency impact |  | — |  | (1,055 | ) | (1,055 | ) |
| End of the period |  | $ | 219,415 |  | $ | 124,540 |  | $ | 343,955 |  |

[0001104659-14-083669:notes:102]
Amortization expense for other intangible assets was $2.6 million and $5.3 million for the three months ended September 30, 2014 and 2013, respectively and $5.4 million and $10.5 million for the six months ended September 30, 2014 and 2013, respectively. The Company expects that amortization expense for the remaining six months of fiscal year 2015 will be $3.0 million, and annual amortization expense for fiscal years 2016 and 2017 will be $1.8 million and $0.2 million respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001104659-14-083669:notes:103]
[same as prior period, unchanged from 0001104659-14-081027:notes:50]

[0001104659-14-083669:notes:104]
The Company is incorporated in Switzerland but operates in various countries with differing tax laws and rates. Further, a portion of the Company’s income (loss) before taxes and the provision for (benefit from) income taxes are generated outside of Switzerland.

[0001104659-14-083669:notes:105]
The income tax provision for the three months ended September 30, 2014 was $5.5 million based on an effective income tax rate of 13.2% of pre-tax income, compared to an income tax provision of $3.1 million based on an effective income tax rate of 17.3% of pre-tax income for the three months ended September 30, 2013. The income tax provision for the six months ended September 30, 2014 was $8.6 million based on an effective income tax rate of 13.4% of pre-tax income, compared to an income tax provision of $2.3 million based on an effective income tax rate of 12.5% of pre-tax income for the six months ended September 30, 2013.  The change in the effective income tax rate for the three and six months ended September 30, 2014, compared to the three and six months ended September 30, 2013, was primarily due to the mix of income and losses in the various tax jurisdictions in which the Company operates.

[0001104659-14-083669:notes:106]
As of September 30 and March 31, 2014, the total amount of unrecognized tax benefits due to uncertain tax positions was $90.9 million and $91.0 million, respectively, of which $88.7 million and $86.1 million would affect the effective income tax rate if recognized.

[0001104659-14-083669:notes:107]
As of September 30, 2014, the Company had $86.4 million in non-current income taxes payable and $0.1 million in current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions. As of March 31, 2014, the Company had $93.1 million in non-current income taxes payable and $0.3 million in current income taxes payable.  Pursuant to ASU 2013-11, which became effective in the first quarter of fiscal year 2015, the Company reclassified $9.3 million of unrecognized tax benefits previously presented as non-current income taxes payable as a reduction to non-current deferred tax assets for tax credit carryforwards.

[0001104659-14-083669:notes:108]
The Company continues to recognize interest and penalties related to unrecognized tax positions in income tax expense. As of September 30 and March 31, 2014, the Company had $5.8 million and $5.6 million, respectively, of accrued interest and penalties related to uncertain tax positions, respectively.

[0001104659-14-083669:notes:109]
Although the Company has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During fiscal year 2015, the Company will continue to review its tax positions and provide for or reverse unrecognized tax benefits as issues arise. During the next 12 months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. dollar as compared to foreign currencies. Excluding these factors, uncertain tax positions may decrease by as much as $15.0 million from the lapse of the statutes of limitations in various jurisdictions during the next 12 months.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001104659-14-083669:notes:110]
[same as prior period, unchanged from 0001104659-14-081027:notes:29]

[0001104659-14-083669:notes:111]
|  |  | September 30, |  | March 31, |  |
|  |  | 2014 |  | 2014 |  |
| Americas |  | $ | 47,686 |  | $ | 45,166 |  |
| EMEA |  | 4,318 |  | 5,154 |  |
| Asia Pacific |  | 37,745 |  | 38,071 |  |
|  |  | $ | 89,749 |  | $ | 88,391 |  |


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001104659-14-083669:notes:112]
Net sales to unaffiliated customers by geographic region (based on the customers’ location) for the three and six months ended September 30, 2014 and 2013 were as follows (in thousands):

[0001104659-14-083669:notes:113]
|  |  | Three Months Ended |  | Six Months Ended |  |
|  |  | September 30, |  | September 30, |  |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  |
| Americas |  | $ | 226,091 |  | $ | 202,381 |  | $ | 437,622 |  | $ | 403,440 |  |
| EMEA |  | 189,571 |  | 202,524 |  | 343,271 |  | 357,747 |  |
| Asia Pacific |  | 114,649 |  | 126,238 |  | 231,621 |  | 248,486 |  |
| Total net sales |  | $ | 530,311 |  | $ | 531,143 |  | $ | 1,012,514 |  | $ | 1,009,673 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001104659-14-083669:notes:114]
The components of accumulated other comprehensive income (loss) was as follows (in thousands):

[0001104659-14-083669:notes:115]
|  |  | Accumulated Other Comprehensive Income (Loss) |  |
|  |  | Cumulative |  | Defined |  | Deferred |  |  |  |
|  |  | Translation |  | Benefit |  | Hedging |  |  |  |
|  |  | Adjustment |  | Plan (1) |  | Gains (Losses) |  | Total |  |
| March 31, 2014 |  | $ | (70,999 | ) | $ | (14,288 | ) | $ | (515 | ) | $ | (85,802 | ) |
| Other comprehensive income (loss) |  | (3,651 | ) | 1,168 |  | 3,938 |  | 1,455 |  |
| September 30, 2014 |  | $ | (74,650 | ) | $ | (13,120 | ) | $ | 3,423 |  | $ | (84,347 | ) |

[0001104659-14-083669:notes:116]
|  | (1) |  | Net of tax of $192 as of both September 30, 2014 and March 31, 2014. |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001104659-14-083669:notes:117]
Net sales and operating income (loss) for the Company’s operating segments for the three and six months ended September 30, 2014 and 2013 were as follows (in thousands):

[0001104659-14-083669:notes:118]
|  |  | Three Months Ended |  | Six Months Ended |  |
|  |  | September 30, |  | September 30, |  |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  |
| Net sales: |  |  |  |  |  |  |  |  |  |
| Peripherals |  | $ | 501,857 |  | $ | 501,550 |  | $ | 958,303 |  | $ | 949,906 |  |
| Video conferencing |  | 28,454 |  | 29,593 |  | 54,211 |  | 59,767 |  |
|  |  | $ | 530,311 |  | $ | 531,143 |  | $ | 1,012,514 |  | $ | 1,009,673 |  |
| Segment operating income (loss): |  |  |  |  |  |  |  |  |  |
| Peripherals (1) |  | $ | 50,587 |  | $ | 39,725 |  | $ | 84,154 |  | $ | 52,978 |  |
| Video conferencing (1) |  | 171 |  | (12,973 | ) | (965 | ) | (16,341 | ) |
|  |  | 50,758 |  | 26,752 |  | 83,189 |  | 36,637 |  |
| Other income (expense): |  |  |  |  |  |  |  |  |  |
| Share-based compensation |  | (6,061 | ) | (4,109 | ) | (12,999 | ) | (8,499 | ) |
| Amortization of intangibles |  | (2,576 | ) | (5,254 | ) | (5,358 | ) | (10,518 | ) |
| Interest income, net |  | 355 |  | 183 |  | 613 |  | 160 |  |
| Other income (expense), net |  | (885 | ) | 62 |  | (1,083 | ) | 279 |  |
| Income before income taxes |  | $ | 41,591 |  | $ | 17,634 |  | $ | 64,362 |  | $ | 18,059 |  |

[0001104659-14-083669:notes:119]
|  | (1) |  | Peripherals operating results include $0.5 million restructuring credit during the three months ended September 30, 2013, and $1.8 million of restructuring charges during the six months ended September 30, 2013. Video conferencing operating results include $6.0 million restructuring credit during the three months ended September 30, 2013, and $6.0 million of restructuring charges during the six months ended September 30, 2013. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001104659-14-083669:notes:120]
[same as prior period, unchanged from 0001104659-14-081027:notes:112]

[0001104659-14-083669:notes:121]
[same as prior period, unchanged from 0001104659-14-081027:notes:113]

[0001104659-14-083669:notes:122]
[same as prior period, unchanged from 0001104659-14-081027:notes:114]

[0001104659-14-083669:notes:123]
Sales are attributed to countries on the basis of the customers’ locations. The United States represented 36% and 34% of the Company’s total consolidated net sales for the quarters ended September 30, 2014 and 2013, respectively. No other single country represented more than 10% of the Company’s total consolidated net sales during those periods. Revenues from sales to customers in Switzerland, the Company’s home domicile, represented 2% and 2% of the Company’s total consolidated net sales for the three and six months ended September 30, 2014 and 2013, respectively. One customer group of the Company’s peripheral operating segment represented 17% and 14% of sales for the quarters ended September 30, 2014 and 2013, respectively. The United States represented 36% and 35% of the Company’s total consolidated net sales for the six months ended September 30, 2014 and 2013, respectively. No other single country represented more than 10% of the Company’s total consolidated net sales during those periods. One customer group of the Company’s peripherals reporting segment represented 16% and 14% for the six months ended September 30, 2014 and 2013, respectively. No other customer makes up more than 10% of revenue for both the three and six months ended September 30, 2014 and 2013.

[0001104659-14-083669:notes:124]
Long-lived assets in the United States and China were $47.4 million and $32.1 million at September 30, 2014 and $44.9 million and $31.9 million at March 31, 2014. No other countries represented more than 10% of the Company’s total consolidated long-lived assets at September 30 and March 31, 2014. Long-lived assets in Switzerland, the Company’s home domicile, were $1.6 million and $1.6 million at September 30 and March 31, 2014.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001104659-14-083669:notes:125]
[same as prior period, unchanged from 0001104659-14-081027:notes:108]

[0001104659-14-083669:notes:126]
In March 2014, the Company’s Board of Directors approved the 2014 share buyback program, which authorizes the Company to use up to $250.0 million to purchase its own shares. The Company’s share buyback program is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market with consideration given to Logitech’s stock price, market conditions and other factors.

[0001104659-14-083669:notes:127]
There were no share repurchases during the three and six months ended September 30, 2014 and 2013. During the six months ended September 30, 2014, the Company was not current with its periodic reports required to be filed with the SEC and therefore lost its ability to buy back shares. The Company will regain its ability, once it is current with its SEC Filings.

[0001104659-14-083669:notes:128]
Accumulated Other Comprehensive Income (Loss)


## us-gaap:SubsequentEventsTextBlock

[0001104659-14-083669:notes:129]
Note 14 — Subsequent Event

[0001104659-14-083669:notes:130]
On November 12, 2014, the Board approved, subject to approval by the Company’s shareholders and other Swiss statutory requirements, a dividend of CHF 0.2625 per share. Based on the shares outstanding as of September 30, 2014, net of treasury shares, the aggregate amount of the dividend would be approximately CHF 42.9 million.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001104659-14-083669:notes:131]
Note  7— Balance Sheet Components
