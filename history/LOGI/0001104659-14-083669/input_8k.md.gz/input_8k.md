# LOGI 8-K — 0001104659-14-073164 filed 2014-10-23

## item codes, every 8-K on or before 2014-11-26

- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2014-11-26

- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001104659-14-073164:8k_2_02:1]
EX-99.1
2
a14-22832_1ex99d1.htm
EX-99.1

[0001104659-14-073164:8k_2_02:2]
Exhibit 99.1

[0001104659-14-073164:8k_2_02:3]
For Immediate Release

[0001104659-14-073164:8k_2_02:4]
Editorial Contacts:

[0001104659-14-073164:8k_2_02:5]
Joe Greenhalgh, Vice President, Investor Relations — USA (510) 713-4430

[0001104659-14-073164:8k_2_02:6]
Krista Todd, Sr. Director, External Communications — USA (510) 713-5834

[0001104659-14-073164:8k_2_02:7]
Ben Starkie, Corporate Communications — Europe +41-(0) 79-292-3499

[0001104659-14-073164:8k_2_02:8]
Logitech Delivers Better-Than-Expected Results in Q2 FY 2015

[0001104659-14-073164:8k_2_02:9]
Audit Committee’s Independent Investigation Now Closed, Filings to Follow

[0001104659-14-073164:8k_2_02:10]
NEWARK, Calif. — Oct. 22, 2014 and LAUSANNE, Switzerland, Oct. 23, 2014 — Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced preliminary unaudited and unreviewed financial results for the second quarter of Fiscal Year 2015.

[0001104659-14-073164:8k_2_02:11]
·      Q2 sales were $530 million, essentially flat compared to the prior year, with retail sales up 2 percent.

[0001104659-14-073164:8k_2_02:12]
·      Q2 GAAP operating income was $42 million, with GAAP earnings per share (EPS) of $0.22, compared to $0.09 in the same quarter a year ago.

[0001104659-14-073164:8k_2_02:13]
·      Q2 non-GAAP operating income was $59 million, with non-GAAP EPS of $0.31, compared to $0.20 a year ago.

[0001104659-14-073164:8k_2_02:14]
·      Q2 cash flow from operations was approximately $33 million, doubling year-over-year and the highest Q2 in the last five years.

[0001104659-14-073164:8k_2_02:15]
“Our performance in Q2 shows continued progress toward our full-year objectives, with growth in retail sales, better-than-expected profitability and improved cash generation,” said Bracken P. Darrell, Logitech president and chief executive officer. “Sales in our Growth category — PC Gaming, Mobile Speakers and Tablet and Other Accessories — grew by double digits for the sixth quarter in a row, increasing 27 percent year-over-year in Q2. It was our sixth consecutive quarter in which Mobile Speakers sales more than doubled. We’ve entered the second half of the year with a robust product portfolio and a pipeline of compelling new products set to launch in the coming quarters. This is our strategy of delivering fewer and bigger products in action.”

[0001104659-14-073164:8k_2_02:16]
Outlook

[0001104659-14-073164:8k_2_02:17]
Logitech confirmed its outlook for Fiscal Year 2015 of approximately $2.16 billion in sales, assuming relatively stable currency exchange rates, and approximately $170 million in non-GAAP operating income.

[0001104659-14-073164:8k_2_02:18]
Prepared Remarks Available Online

[0001104659-14-073164:8k_2_02:19]
Logitech has made its prepared written remarks for the financial results teleconference available online on the Logitech corporate Web site at http://ir.logitech.com.

[0001104659-14-073164:8k_2_02:20]
Financial Results Teleconference and Webcast

[0001104659-14-073164:8k_2_02:21]
Logitech will hold a financial results teleconference to discuss the preliminary results for Q2 FY 2015 on Oct. 24, 2014 at 8:30 a.m. Eastern Daylight Time and 14:30 Central European Summer Time. A live webcast of the call will be available on the Logitech corporate website at http://ir.logitech.com.

[0001104659-14-073164:8k_2_02:22]
Audit Committee Investigation Closed

[0001104659-14-073164:8k_2_02:23]
As previously disclosed, Logitech’s Audit Committee, with the assistance of independent advisors, was conducting an independent investigation of certain accounting matters related to the Company’s previously issued financial statements. The investigation is now closed.

[0001104659-14-073164:8k_2_02:24]
With the investigation closed, Logitech is performing the necessary work to complete and file its Annual Report for FY 2014, Annual Report on Form 10-K for FY 2014 and Quarterly Reports on Form 10-Q for Q1 and Q2 FY 2015. The Company intends to file these reports as soon as possible to regain compliance with Nasdaq and SIX Swiss Exchange listing requirements.

[0001104659-14-073164:8k_2_02:25]
Last month, Logitech announced the restatement of its financial statements for Fiscal Years 2011 and 2012 and for the first quarter of Fiscal Year 2012, related to inventory valuation reserves for the Company’s discontinued Revue product. In connection with the restatement, there will be other immaterial corrections to the financial statements for Fiscal Years 2010 and 2013, as well as the first and second quarters of Fiscal Year 2014. None of these other corrections are material to the respective years or to the interim period.

[0001104659-14-073164:8k_2_02:26]
Preliminary financial information for the second quarter of Fiscal Year 2015 was compiled by the Company and has not yet been reviewed by the Company’s independent registered public accounting firm. Accordingly, the preliminary results for the first and second quarters of Fiscal Year 2015 and the results for the corresponding period of Fiscal Year 2014 contained in this press release may be subject to potentially material adjustment.

[0001104659-14-073164:8k_2_02:27]
Use of Non-GAAP Financial Information

[0001104659-14-073164:8k_2_02:28]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of other intangible assets, restructuring charges (credits), other restructuring-related charges, investment impairment (recovery), benefit from (provision for) income taxes, one-time special charges and other items detailed under “Supplemental Financial Information” after the tables below. Logitech believes this information will help

[0001104659-14-073164:8k_2_02:29]
2

[0001104659-14-073164:8k_2_02:30]
investors to evaluate its current period performance and trends in its business. With respect to the Company’s outlook for Fiscal Year 2015 non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amount has been provided.

[0001104659-14-073164:8k_2_02:31]
About Logitech

[0001104659-14-073164:8k_2_02:32]
Logitech is a world leader in products that connect people to the digital experiences they care about. Spanning multiple computing, communication and entertainment platforms, Logitech’s combined hardware and software enable or enhance digital navigation, music and video entertainment, gaming, social networking, audio and video communication over the Internet, video security and home-entertainment control. Founded in 1981, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI).

[0001104659-14-073164:8k_2_02:33]
#   #   #

[0001104659-14-073164:8k_2_02:34]
Note that unless noted otherwise, comparisons are year over year.

[0001104659-14-073164:8k_2_02:35]
Logitech, the Logitech logo, and other Logitech marks are registered in Switzerland and other countries. All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s Web site at www.logitech.com.

[0001104659-14-073164:8k_2_02:36]
(LOGIIR)

[0001104659-14-073164:8k_2_02:37]
3

[0001104659-14-073164:8k_2_02:38]
LOGITECH INTERNATIONAL S.A.

[0001104659-14-073164:8k_2_02:39]
The following financial statements and supplemental information may be subject to potentially material adjustment.

[0001104659-14-073164:8k_2_02:40]
(In thousands, except per share amounts) -Unaudited

[0001104659-14-073164:8k_2_02:41]
|  |  | Three Months Ended |  | Six Months Ended |  |
|  |  | September 30, |  | September 30, |  |
| GAAP CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  |
| Net sales |  | $ | 530,311 |  | $ | 531,972 |  | $ | 1,012,514 |  | $ | 1,009,896 |  |
| Cost of goods sold |  | 325,533 |  | 348,559 |  | 625,532 |  | 658,128 |  |
| Gross profit |  | 204,778 |  | 183,413 |  | 386,982 |  | 351,768 |  |
| % of net sales |  | 38.6 | % | 34.5 | % | 38.2 | % | 34.8 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 95,862 |  | 93,710 |  | 186,908 |  | 194,345 |  |
| Research and development |  | 32,325 |  | 37,633 |  | 63,641 |  | 73,824 |  |
| General and administrative |  | 34,470 |  | 29,395 |  | 71,149 |  | 58,543 |  |
| Restructuring charges, net |  | — |  | 5,465 |  | — |  | 7,799 |  |
| Total operating expenses |  | 162,657 |  | 166,203 |  | 321,698 |  | 334,511 |  |
| Operating income |  | 42,121 |  | 17,210 |  | 65,284 |  | 17,257 |  |
| Interest income, net |  | 355 |  | 183 |  | 613 |  | 160 |  |
| Other income (expense), net |  | (885 | ) | 62 |  | (1,083 | ) | 279 |  |
| Income before income taxes |  | 41,591 |  | 17,455 |  | 64,814 |  | 17,696 |  |
| Provision for income taxes |  | 5,501 |  | 3,057 |  | 8,596 |  | 2,255 |  |
| Net income |  | $ | 36,090 |  | $ | 14,398 |  | $ | 56,218 |  | $ | 15,441 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.22 |  | $ | 0.09 |  | $ | 0.34 |  | $ | 0.10 |  |
| Diluted |  | $ | 0.22 |  | $ | 0.09 |  | $ | 0.34 |  | $ | 0.10 |  |
| Shares used to compute net income per share : |  |  |  |  |  |  |  |  |  |
| Basic |  | 163,230 |  | 159,969 |  | 163,121 |  | 159,637 |  |
| Diluted |  | 166,065 |  | 161,183 |  | 165,949 |  | 160,875 |  |

[0001104659-14-073164:8k_2_02:42]
LOGITECH INTERNATIONAL S.A.

[0001104659-14-073164:8k_2_02:43]
The following financial statements and supplemental information may be subject to potentially material adjustment.

[0001104659-14-073164:8k_2_02:44]
(In thousands, except per share amounts) - Unaudited

[0001104659-14-073164:8k_2_02:45]
NET RETAIL SALES BY PRODUCT CATEGORY

[0001104659-14-073164:8k_2_02:46]
|  |  | Three Months Ended |  | Six Months Ended |  |
|  |  | September 30, |  | September 30, |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2014 (1) (2) |  | 2013 (1) |  | 2014 (1) (2) |  | 2013 (1) |  |
| Net retail sales by product family(*): |  |  |  |  |  |  |  |  |  |
| PC Gaming |  | $ | 47,506 |  | $ | 43,260 |  | $ | 94,382 |  | $ | 83,473 |  |
| Tablet & Other Accessories |  | 28,158 |  | 34,695 |  | 59,874 |  | 73,254 |  |
| Mobile Speakers |  | 48,538 |  | 19,967 |  | 77,367 |  | 33,834 |  |
| Growth |  | 124,202 |  | 97,922 |  | 231,623 |  | 190,561 |  |
| Pointing Devices |  | 127,693 |  | 130,656 |  | 240,735 |  | 245,307 |  |
| PC Keyboards & Desktops |  | 105,718 |  | 105,260 |  | 211,241 |  | 203,273 |  |
| Audio-PC &Wearables |  | 58,677 |  | 70,523 |  | 108,303 |  | 126,061 |  |
| Video |  | 37,563 |  | 36,645 |  | 72,139 |  | 67,585 |  |
| Remotes |  | 18,776 |  | 13,327 |  | 31,108 |  | 27,901 |  |
| Profit maximization |  | 348,427 |  | 356,411 |  | 663,526 |  | 670,127 |  |
| Other |  | 834 |  | 10,520 |  | 2,127 |  | 17,401 |  |
| Non-Strategic |  | 834 |  | 10,520 |  | 2,127 |  | 17,401 |  |
| Total net retail sales |  | $ | 473,463 |  | $ | 464,853 |  | $ | 897,276 |  | $ | 878,089 |  |
| Net sales by channel: |  |  |  |  |  |  |  |  |  |
| Retail |  | $ | 473,463 |  | $ | 464,853 |  | $ | 897,276 |  | $ | 878,089 |  |
| OEM |  | 28,394 |  | 37,526 |  | 61,027 |  | 72,039 |  |
| Video conferencing |  | 28,454 |  | 29,593 |  | 54,211 |  | 59,768 |  |
| Total net sales |  | $ | 530,311 |  | $ | 531,972 |  | $ | 1,012,514 |  | $ | 1,009,896 |  |

[0001104659-14-073164:8k_2_02:47]
*           Certain products within the retail product categories as presented in prior years have been reclassified to conform to the current year presentation.

[0001104659-14-073164:8k_2_02:48]
LOGITECH INTERNATIONAL S.A.

[0001104659-14-073164:8k_2_02:49]
The following financial statements and supplemental information may be subject to potentially material adjustment. Please see notes below the tables.

[0001104659-14-073164:8k_2_02:50]
(In thousands, except per share amounts) - Unaudited

[0001104659-14-073164:8k_2_02:51]
GAAP TO NON GAAP RECONCILIATION (A)

[0001104659-14-073164:8k_2_02:52]
|  |  | Three Months Ended |  | Six Months Ended |  |
|  |  | September 30, |  | September 30, |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2014 (1) (2) |  | 2013 (1) |  | 2014 (1) (2) |  | 2013 (1) |  |
| Gross profit - GAAP |  | $ | 204,778 |  | $ | 183,413 |  | $ | 386,982 |  | $ | 351,768 |  |
| Share-based compensation expense |  | 627 |  | 594 |  | 1,165 |  | 1,171 |  |
| Amortization of other intangible assets |  | 543 |  | 2,593 |  | 1,093 |  | 5,171 |  |
| Restructuring-related charges |  | — |  | 5,194 |  | — |  | 5,194 |  |
| Gross profit - Non-GAAP |  | $ | 205,948 |  | $ | 191,794 |  | $ | 389,240 |  | $ | 363,304 |  |
| Gross margin - GAAP |  | 38.6 | % | 34.5 | % | 38.2 | % | 34.8 | % |
| Gross margin - Non-GAAP |  | 38.8 | % | 36.1 | % | 38.4 | % | 36.0 | % |
| Operating expenses - GAAP |  | $ | 162,657 |  | $ | 166,203 |  | $ | 321,698 |  | $ | 334,511 |  |
| Less: Share-based compensation expense |  | 5,434 |  | 3,515 |  | 11,834 |  | 7,328 |  |
| Amortization of other intangible assets |  | 2,033 |  | 2,661 |  | 4,265 |  | 5,347 |  |
| Restructuring charges, net |  | — |  | 5,465 |  | — |  | 7,799 |  |
| One time special charge |  | 8,020 |  | — |  | 17,000 |  | — |  |
| Operating expenses - Non-GAAP |  | $ | 147,170 |  | $ | 154,562 |  | $ | 288,599 |  | $ | 314,037 |  |
| % of net sales - GAAP |  | 30.7 | % | 31.2 | % | 31.8 | % | 33.1 | % |
| % of net sales - Non - GAAP |  | 27.8 | % | 29.1 | % | 28.5 | % | 31.1 | % |
| Operating income - GAAP |  | $ | 42,121 |  | $ | 17,210 |  | $ | 65,284 |  | $ | 17,257 |  |
| Share-based compensation expense |  | 6,061 |  | 4,109 |  | 12,999 |  | 8,499 |  |
| Amortization of other intangible assets |  | 2,576 |  | 5,254 |  | 5,358 |  | 10,518 |  |
| Restructuring charges, net |  | — |  | 5,465 |  | — |  | 7,799 |  |
| Restructuring related charges |  | — |  | 5,194 |  | — |  | 5,194 |  |
| One time special charge |  | 8,020 |  | — |  | 17,000 |  | — |  |
| Operating income - Non - GAAP |  | $ | 58,778 |  | $ | 37,232 |  | $ | 100,641 |  | $ | 49,267 |  |
| % of net sales - GAAP |  | 7.9 | % | 3.2 | % | 6.4 | % | 1.7 | % |
| % of net sales - Non - GAAP |  | 11.1 | % | 7.0 | % | 9.9 | % | 4.9 | % |
| Net income - GAAP |  | $ | 36,090 |  | $ | 14,398 |  | $ | 56,218 |  | $ | 15,441 |  |
| Share-based compensation expense |  | 6,061 |  | 4,109 |  | 12,999 |  | 8,499 |  |
| Amortization of other intangible assets |  | 2,576 |  | 5,254 |  | 5,358 |  | 10,518 |  |
| Restructuring related charges |  | — |  | 5,465 |  | — |  | 7,799 |  |
| Restructuring charges, net |  | — |  | 5,194 |  | — |  | 5,194 |  |
| One time special charge |  | 8,020 |  | — |  | 17,000 |  | — |  |
| Investment impairment, net |  | 105 |  | (261 | ) | 105 |  | 109 |  |
| Provision for income taxes |  | (1,803 | ) | (2,638 | ) | (3,964 | ) | (5,368 | ) |
| Net income - Non - GAAP |  | $ | 51,049 |  | $ | 31,521 |  | $ | 87,716 |  | $ | 42,192 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.22 |  | $ | 0.09 |  | $ | 0.34 |  | $ | 0.10 |  |
| Diluted - Non - GAAP |  | $ | 0.31 |  | $ | 0.20 |  | $ | 0.53 |  | $ | 0.26 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non GAAP |  | 166,065 |  | 161,183 |  | 165,949 |  | 160,875 |  |

[0001104659-14-073164:8k_2_02:53]
LOGITECH INTERNATIONAL S.A.

[0001104659-14-073164:8k_2_02:54]
(In thousands, except per share amounts) - Unaudited

[0001104659-14-073164:8k_2_02:55]
The following financial statements and supplemental information may be subject to potentially material adjustment.

[0001104659-14-073164:8k_2_02:56]
SHARE BASED COMPENSATION EXPENSE

[0001104659-14-073164:8k_2_02:57]
|  |  | Three Months Ended |  | Six Months Ended |  |
|  |  | September 30, |  | September 30, |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2014 (1) (2) |  | 2013 (1) |  | 2014 (1) (2) |  | 2013 (1) |  |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 627 |  | $ | 594 |  | $ | 1,165 |  | $ | 1,171 |  |
| Research and development |  | 552 |  | 840 |  | 1,396 |  | 1,934 |  |
| Marketing and selling |  | 1,653 |  | 1,017 |  | 4,209 |  | 2,923 |  |
| General and administrative |  | 3,229 |  | 1,658 |  | 6,229 |  | 2,471 |  |
| Income tax benefit |  | (1,913 | ) | (1,300 | ) | (3,097 | ) | (2,175 | ) |
| Total share-based compensation expense after income taxes |  | $ | 4,148 |  | $ | 2,809 |  | $ | 9,902 |  | $ | 6,324 |  |

[0001104659-14-073164:8k_2_02:58]
(1)  NOTE: Based on the Audit Committee’s investigation and related additional work associated with the Company’s Fiscal Year 2014 Annual Report on Form 10-K, the preliminary results for the three and six months ended September 30 of Fiscal Year 2015 and the results for the corresponding periods of Fiscal Year 2014 contained in these prepared remarks are subject to potentially material adjustment.

[0001104659-14-073164:8k_2_02:59]
(2)  NOTE: The financial information for the three and six months ended September 30 of Fiscal Year 2015 is preliminary, was compiled by the Company and has not yet been reviewed by the Company’s independent registered public accounting firm. The financial information for the first and second quarters of Fiscal Year 2015 may be subject to potentially material adjustment based on changes in reserves and estimates resulting from subsequent events and other information available through the filing date of the Company’s Quarterly Report on Form 10-Q for the quarter ended September 30, 2014.

[0001104659-14-073164:8k_2_02:60]
(A)        Non-GAAP Financial Measures

[0001104659-14-073164:8k_2_02:61]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001104659-14-073164:8k_2_02:62]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the three and six months ended September 30, 2014, we excluded items in the following general categories, each of which are described below.

[0001104659-14-073164:8k_2_02:63]
Share-based compensation expenses . We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure.

[0001104659-14-073164:8k_2_02:64]
Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001104659-14-073164:8k_2_02:65]
Amortization of other intangible assets . We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our operating expenses and financial results from period to period.

[0001104659-14-073164:8k_2_02:66]
Restructuring and restructuring-related charges . These expenses are associated with re-aligning our business strategies based on current economic conditions. We have undertaken several restructurings in recent years. In connection with our restructuring initiatives, we incurred restructuring charges related to employee terminations, facility closures and early cancellation of certain contracts. Our restructuring initiatives also resulted in other costs related to restructurings not qualifying for inclusion in restructuring charges. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operating results in the current period.

[0001104659-14-073164:8k_2_02:67]
One-time special charges:  costs related to investigations.  These expenses are forensic accounting, audit, consulting and legal fees related to the Audit Committee’s investigation and the ongoing formal investigation by the Securities and Exchange Commission.  We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are one-time in nature and not reflective of our ongoing operations.

[0001104659-14-073164:8k_2_02:68]
Other charges . We provided non-GAAP measures excluding the effect of certain charges and income that are not reflective of our ongoing operations.

[0001104659-14-073164:8k_2_02:69]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.
