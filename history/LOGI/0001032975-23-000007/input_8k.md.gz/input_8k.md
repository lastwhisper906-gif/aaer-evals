# LOGI 8-K — 0001032975-23-000004 filed 2023-01-24

## item codes, every 8-K on or before 2023-01-26

- 2023-01-24 0001032975-23-000004 — 2.02, 5.02, 9.01
- 2023-01-12 0001628280-23-000934 — 2.02, 9.01
- 2022-10-25 0001628280-22-026927 — 2.02, 5.02, 9.01
- 2022-09-16 0001628280-22-025080 — 5.07, 8.01
- 2022-07-26 0001032975-22-000027 — 2.02, 9.01
- 2022-06-29 0001032975-22-000018 — 5.02
- 2022-05-03 0001032975-22-000008 — 2.02, 9.01
- 2022-01-25 0001032975-22-000003 — 2.02, 9.01
- 2021-10-26 0001032975-21-000043 — 2.02, 9.01
- 2021-09-10 0001032975-21-000040 — 5.07, 8.01
- 2021-07-27 0001032975-21-000029 — 2.02, 9.01
- 2021-04-29 0001032975-21-000012 — 2.02, 9.01
- 2021-01-19 0001032975-21-000004 — 2.02, 9.01
- 2020-10-20 0001032975-20-000045 — 2.02, 9.01
- 2020-09-11 0001032975-20-000042 — 5.07, 8.01
- 2020-07-21 0001032975-20-000029 — 2.02, 9.01
- 2020-07-01 0001032975-20-000023 — 5.02, 8.01
- 2020-05-12 0001032975-20-000011 — 2.02, 9.01
- 2020-03-30 0001032975-20-000009 — 5.02
- 2020-01-21 0001032975-20-000002 — 2.02, 9.01
- 2019-10-22 0001032975-19-000071 — 9.01
- 2019-09-26 0001032975-19-000068 — 1.01, 7.01, 9.01
- 2019-09-06 0001032975-19-000063 — 5.07, 8.01
- 2019-07-23 0001032975-19-000046 — 2.02, 9.01
- 2019-07-23 0001032975-19-000045 — 5.02, 9.01
- 2019-07-02 0001032975-19-000036 — 5.02
- 2019-06-25 0001032975-19-000034 — 5.02
- 2019-05-03 0001032975-19-000021 — 5.02 — amendment, the index does not say of what
- 2019-04-30 0001032975-19-000017 — 2.02, 5.02, 9.01
- 2019-03-28 0001032975-19-000013 — 5.02
- 2019-01-22 0001032975-19-000004 — 2.02, 9.01
- 2018-10-23 0001032975-18-000044 — 2.02, 9.01
- 2018-09-07 0001032975-18-000040 — 5.07, 8.01
- 2018-07-31 0001032975-18-000035 — 1.01, 2.02, 2.05, 7.01, 9.01
- 2018-06-27 0001032975-18-000020 — 5.02
- 2018-05-03 0001032975-18-000013 — 2.02, 5.02, 9.01
- 2018-01-23 0001032975-18-000005 — 2.02, 9.01
- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2023-01-26

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-23-000004:8k_2_02:1]
EX-99.1
2
exhibit991q3fy23.htm
EX-99.1

[0001032975-23-000004:8k_2_02:2]
Document

[0001032975-23-000004:8k_2_02:3]
Exhibit 99.1

[0001032975-23-000004:8k_2_02:4]
Editorial Contacts:

[0001032975-23-000004:8k_2_02:5]
Nate Melihercik, Head of Global Investor Relations - ir@logitech.com

[0001032975-23-000004:8k_2_02:6]
Nicole Kenyon, Head of Global Corporate & Employee Communications - USA  (510) 988-8553

[0001032975-23-000004:8k_2_02:7]
Ben Starkie, Corporate Communications - Europe +41 (0) 79-292-3499

[0001032975-23-000004:8k_2_02:8]
Logitech Announces Q3 FY 2023 Results

[0001032975-23-000004:8k_2_02:9]
LAUSANNE, Switzerland, January 24, 2023 and NEWARK, Calif., January 23, 2023 — SIX Swiss Exchange Ad hoc announcement pursuant to Art. 53 LR — Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the third quarter of Fiscal Year 2023.

[0001032975-23-000004:8k_2_02:10]
•Sales were $1.27 billion, down 22 percent in US dollars and 17 percent in constant currency, compared to Q3 of the prior year. This performance reflects the challenging macroeconomic environment.

[0001032975-23-000004:8k_2_02:11]
•Category sales declined in both US dollars and constant currency. Compared to Q3 of the prior year, Gaming sales declined 16 percent and 10 percent respectively; Video Collaboration sales declined 21 percent and 16 percent respectively; Keyboards & Combos sales declined 22 percent and 17 percent respectively; and Pointing Devices sales declined 14 percent and 8 percent respectively. This reflects consumer purchasing concentrated in promotional weeks throughout the quarter, and lower enterprise and consumer spending.

[0001032975-23-000004:8k_2_02:12]
•GAAP operating income declined 33 percent to $177 million, compared to $263 million in the same quarter a year ago. Non-GAAP operating income declined 32 percent to $204 million, compared to $302 million in the same quarter a year ago.

[0001032975-23-000004:8k_2_02:13]
•GAAP earnings per share (EPS) declined 31 percent to $0.86, compared to $1.24 in the same quarter a year ago. Non-GAAP EPS declined 26 percent to $1.14, compared to $1.55 in the same quarter a year ago.

[0001032975-23-000004:8k_2_02:14]
•Cash flow from operations was $280 million, bringing the cash balance to $1.04 billion. Year to date, the Company has returned $486 million of cash to shareholders through its annual dividend payment and share repurchases, including $90 million this quarter.

[0001032975-23-000004:8k_2_02:15]
"These quarterly results reflect the current challenging macroeconomic conditions, including currency exchange rates and inflation, as well as lower enterprise and consumer spending,” said Bracken Darrell, Logitech president and chief executive officer. “With these external headwinds, we continued to aggressively manage our costs in the quarter, while at the same time growing market share in key categories. Our long-term strategies remain unchanged, and we remain committed to the growth trends that fuel our business."

[0001032975-23-000004:8k_2_02:16]
Outlook

[0001032975-23-000004:8k_2_02:17]
As announced earlier this month, Logitech’s Fiscal Year 2023 outlook has been adjusted to between negative 15 percent and negative 13 percent sales growth in constant currency, and between $550 million and $600 million in non-GAAP operating income.

[0001032975-23-000004:8k_2_02:18]
Prepared Remarks Available Online

[0001032975-23-000004:8k_2_02:19]
Logitech has made its prepared written remarks for the financial results videoconference available online on the Logitech corporate website at http://ir.logitech.com.

[0001032975-23-000004:8k_2_02:20]
Financial Results Videoconference and Webcast

[0001032975-23-000004:8k_2_02:21]
Logitech will hold a financial results videoconference to discuss the results for Q3 Fiscal Year 2023 on Tuesday, January 24, 2023 at 8:30 a.m. Eastern Standard Time and 2:30 p.m. Central European Time. A livestream of the event will be available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-23-000004:8k_2_02:22]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-23-000004:8k_2_02:23]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures in this press release, which exclude share-based compensation expense, amortization of intangible assets, acquisition-related costs, impairment of intangible assets, change in fair value of contingent consideration for business acquisition, restructuring charges, loss on investments, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below and posted to our website at http://ir.logitech.com. Logitech also presents percentage sales growth in constant currency (“CC”), a non-GAAP measure, to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance, outlook and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for the Fiscal Year 2023 outlook.

[0001032975-23-000004:8k_2_02:24]
Public Dissemination of Certain Information

[0001032975-23-000004:8k_2_02:25]
Logitech webcasts its earnings calls, and certain events Logitech participates in or hosts, with members of the investment community on its investor relations website at https://ir.logitech.com. Additionally, Logitech provides notifications of news or announcements regarding its operations and financial performance, including its filings with the Securities and Exchange Commission (SEC), investor events, and press and earnings releases as part of its investor relations website. Logitech intends to use its investor relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. Logitech’s corporate governance information also is available on its investor relations website.

[0001032975-23-000004:8k_2_02:26]
About Logitech

[0001032975-23-000004:8k_2_02:27]
Logitech helps all people pursue their passions and is committed to doing so in a way that is good for people and the planet. We design hardware and software solutions that help businesses thrive and bring people together when working, creating, gaming and streaming. Brands of Logitech include Logitech, Logitech G, ASTRO Gaming, Streamlabs, Blue Microphones and Ultimate Ears. Founded in 1981, and headquartered in Lausanne, Switzerland, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @logitech.

[0001032975-23-000004:8k_2_02:28]
# # #

[0001032975-23-000004:8k_2_02:29]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-23-000004:8k_2_02:30]
Logitech and other Logitech marks are trademarks or registered trademarks of Logitech Europe S.A. and/or its affiliates in the U.S. and other countries. All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-23-000004:8k_2_02:31]
(LOGIIR)

[0001032975-23-000004:8k_2_02:32]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net sales |  | $ | 1,269,925 |  |  | $ | 1,632,782 |  |  | $ | 3,578,741 |  |  | $ | 4,251,107 |  |
| Cost of goods sold |  | 789,489 |  |  | 971,646 |  |  | 2,193,735 |  |  | 2,470,980 |  |
| Amortization of intangible assets |  | 3,168 |  |  | 3,126 |  |  | 9,355 |  |  | 11,028 |  |
| Gross profit |  | 477,268 |  |  | 658,010 |  |  | 1,375,651 |  |  | 1,769,099 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 196,653 |  |  | 269,941 |  |  | 628,122 |  |  | 778,882 |  |
| Research and development |  | 65,640 |  |  | 75,529 |  |  | 210,166 |  |  | 213,436 |  |
| General and administrative |  | 29,766 |  |  | 38,478 |  |  | 92,215 |  |  | 112,291 |  |
| Amortization of intangible assets and acquisition-related costs |  | 2,810 |  |  | 3,662 |  |  | 9,052 |  |  | 13,986 |  |
| Impairment of intangible assets |  | — |  |  | 7,000 |  |  | — |  |  | 7,000 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (1,110) |  |  | — |  |  | (3,509) |  |
| Restructuring charges, net |  | 5,654 |  |  | 1,759 |  |  | 16,471 |  |  | 1,770 |  |
| Total operating expenses |  | 300,523 |  |  | 395,259 |  |  | 956,026 |  |  | 1,123,856 |  |
| Operating income |  | 176,745 |  |  | 262,751 |  |  | 419,625 |  |  | 645,243 |  |
| Interest income |  | 4,665 |  |  | 278 |  |  | 9,573 |  |  | 795 |  |
| Other income (expense), net |  | 1,406 |  |  | (3,673) |  |  | (18,367) |  |  | (1,941) |  |
| Income before income taxes |  | 182,816 |  |  | 259,356 |  |  | 410,831 |  |  | 644,097 |  |
| Provision for income taxes |  | 42,663 |  |  | 49,345 |  |  | 87,751 |  |  | 107,789 |  |
| Net income |  | $ | 140,153 |  |  | $ | 210,011 |  |  | $ | 323,080 |  |  | $ | 536,308 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.87 |  |  | $ | 1.26 |  |  | $ | 1.98 |  |  | $ | 3.19 |  |
| Diluted |  | $ | 0.86 |  |  | $ | 1.24 |  |  | $ | 1.96 |  |  | $ | 3.14 |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | 161,244 |  |  | 167,090 |  |  | 163,042 |  |  | 167,953 |  |
| Diluted |  | 162,529 |  |  | 169,707 |  |  | 164,427 |  |  | 171,027 |  |

[0001032975-23-000004:8k_2_02:33]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | December 31, |  | March 31, |  |  |  |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  | 2022 |  | 2022 |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,036,131 |  |  | $ | 1,328,716 |  |  |  |  |  |
| Accounts receivable, net |  | 802,435 |  |  | 675,604 |  |  |  |  |  |
| Inventories |  | 797,695 |  |  | 933,124 |  |  |  |  |  |
| Other current assets |  | 125,088 |  |  | 135,478 |  |  |  |  |  |
| Total current assets |  | 2,761,349 |  |  | 3,072,922 |  |  |  |  |  |
| Non-current assets: |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 118,183 |  |  | 109,807 |  |  |  |  |  |
| Goodwill |  | 454,471 |  |  | 448,175 |  |  |  |  |  |
| Other intangible assets, net |  | 69,364 |  |  | 83,779 |  |  |  |  |  |
| Other assets |  | 335,879 |  |  | 320,722 |  |  |  |  |  |
| Total assets |  | $ | 3,739,246 |  |  | $ | 4,035,405 |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 491,488 |  |  | $ | 636,306 |  |  |  |  |  |
| Accrued and other current liabilities |  | 705,569 |  |  | 784,848 |  |  |  |  |  |
| Total current liabilities |  | 1,197,057 |  |  | 1,421,154 |  |  |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Income taxes payable |  | 117,608 |  |  | 83,380 |  |  |  |  |  |
| Other non-current liabilities |  | 165,915 |  |  | 132,133 |  |  |  |  |  |
| Total liabilities |  | 1,480,580 |  |  | 1,636,667 |  |  |  |  |  |
| Shareholders’ equity: |  |  |  |  |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |  |  |  |  |
| Issued shares — 173,106 at December 31, 2022 and March 31, 2022 |  |  |  |  |  |  |  |  |
| Additional shares that may be issued out of conditional capital — 50,000 at December 31, 2022 and March 31, 2022 |  |  |  |  |  |  |  |  |
| Additional shares that may be issued out of authorized capital — 17,311 at December 31, 2022 and March 31, 2022 |  |  |  |  |  |  |  |  |
| Additional paid-in capital |  | 116,012 |  |  | 129,925 |  |  |  |  |  |
| Shares in treasury, at cost — 12,470 at December 31, 2022 and 7,855 at March 31, 2022 |  | (906,606) |  |  | (632,893) |  |  |  |  |  |
| Retained earnings |  | 3,136,080 |  |  | 2,975,681 |  |  |  |  |  |
| Accumulated other comprehensive loss |  | (116,968) |  |  | (104,123) |  |  |  |  |  |
| Total shareholders’ equity |  | 2,258,666 |  |  | 2,398,738 |  |  |  |  |  |
| Total liabilities and shareholders’ equity |  | $ | 3,739,246 |  |  | $ | 4,035,405 |  |  |  |  |  |

[0001032975-23-000004:8k_2_02:34]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 140,153 |  |  | $ | 210,011 |  |  | $ | 323,080 |  |  | $ | 536,308 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  | 19,410 |  |  | 21,913 |  |  | 56,698 |  |  | 65,387 |  |
| Amortization of intangible assets |  | 5,929 |  |  | 6,755 |  |  | 18,173 |  |  | 24,223 |  |
| Impairment of intangible assets |  | — |  |  | 7,000 |  |  | — |  |  | 7,000 |  |
| Loss on investments |  | 1,488 |  |  | 460 |  |  | 13,065 |  |  | 1,421 |  |
| Share-based compensation expense |  | 15,805 |  |  | 24,792 |  |  | 51,740 |  |  | 72,465 |  |
| Deferred income taxes |  | 21,188 |  |  | 20,561 |  |  | 24,228 |  |  | 27,369 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (1,110) |  |  | — |  |  | (3,509) |  |
| Other |  | 1,293 |  |  | 9 |  |  | 1,411 |  |  | 1,068 |  |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | (1,638) |  |  | (123,350) |  |  | (123,547) |  |  | (236,358) |  |
| Inventories |  | 104,519 |  |  | (10,240) |  |  | 126,309 |  |  | (177,828) |  |
| Other assets |  | 16,161 |  |  | 27,871 |  |  | 20,918 |  |  | (20,569) |  |
| Accounts payable |  | (56,494) |  |  | 74,845 |  |  | (134,848) |  |  | (80,637) |  |
| Accrued and other liabilities |  | 12,097 |  |  | 117,059 |  |  | (60,060) |  |  | (17,612) |  |
| Net cash provided by operating activities |  | 279,911 |  |  | 376,576 |  |  | 317,167 |  |  | 198,728 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (23,738) |  |  | (16,494) |  |  | (69,122) |  |  | (63,726) |  |
| Investment in privately held companies |  | (351) |  |  | (359) |  |  | (2,626) |  |  | (1,260) |  |
| Acquisitions, net of cash acquired |  | (2,688) |  |  | (300) |  |  | (8,527) |  |  | (15,886) |  |
| Purchases of short-term investments |  | — |  |  | (10,000) |  |  | — |  |  | (10,000) |  |
| Proceeds from the sale of short-term investments |  | — |  |  | 1,225 |  |  | — |  |  | 1,225 |  |
| Purchases of deferred compensation investments |  | (2,687) |  |  | (1,178) |  |  | (5,186) |  |  | (3,644) |  |
| Proceeds from sales of deferred compensation investments |  | 2,314 |  |  | 1,308 |  |  | 4,750 |  |  | 4,285 |  |
| Net cash used in investing activities |  | (27,150) |  |  | (25,798) |  |  | (80,711) |  |  | (89,006) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | — |  |  | — |  |  | (158,680) |  |  | (159,410) |  |
| Payment of contingent consideration for business acquisition |  | — |  |  | (880) |  |  | (5,954) |  |  | (880) |  |
| Purchases of registered shares |  | (90,170) |  |  | (116,245) |  |  | (327,731) |  |  | (290,625) |  |
| Proceeds from exercises of stock options and purchase rights |  | 3,214 |  |  | 8 |  |  | 16,064 |  |  | 16,644 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (1,992) |  |  | (3,777) |  |  | (28,734) |  |  | (58,528) |  |
| Net cash used in financing activities |  | (88,948) |  |  | (120,894) |  |  | (505,035) |  |  | (492,799) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | 3,817 |  |  | (2,769) |  |  | (24,006) |  |  | (2,839) |  |
| Net increase (decrease) in cash and cash equivalents |  | 167,630 |  |  | 227,115 |  |  | (292,585) |  |  | (385,916) |  |
| Cash and cash equivalents, beginning of the period |  | 868,501 |  |  | 1,137,296 |  |  | 1,328,716 |  |  | 1,750,327 |  |
| Cash and cash equivalents, end of the period |  | $ | 1,036,131 |  |  | $ | 1,364,411 |  |  | $ | 1,036,131 |  |  | $ | 1,364,411 |  |

[0001032975-23-000004:8k_2_02:35]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
| NET SALES |  | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Net sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Pointing Devices |  | $ | 199,106 |  |  | $ | 231,090 |  |  | (14) | % |  | $ | 567,589 |  |  | $ | 602,982 |  |  | (6) | % |
| Keyboards & Combos |  | 220,059 |  |  | 281,608 |  |  | (22) |  |  | 648,632 |  |  | 736,237 |  |  | (12) |  |
| PC Webcams |  | 58,481 |  |  | 115,115 |  |  | (49) |  |  | 178,033 |  |  | 319,504 |  |  | (44) |  |
| Tablet & Other Accessories |  | 65,157 |  |  | 82,859 |  |  | (21) |  |  | 185,945 |  |  | 242,932 |  |  | (23) |  |
| Gaming (1) |  | 391,975 |  |  | 469,282 |  |  | (16) |  |  | 972,457 |  |  | 1,135,456 |  |  | (14) |  |
| Video Collaboration |  | 226,374 |  |  | 287,187 |  |  | (21) |  |  | 708,796 |  |  | 753,725 |  |  | (6) |  |
| Mobile Speakers |  | 38,321 |  |  | 56,748 |  |  | (32) |  |  | 99,826 |  |  | 124,724 |  |  | (20) |  |
| Audio & Wearables |  | 69,104 |  |  | 104,280 |  |  | (34) |  |  | 211,821 |  |  | 318,965 |  |  | (34) |  |
| Other (2) |  | 1,348 |  |  | 4,613 |  |  | (71) |  |  | 5,642 |  |  | 16,582 |  |  | (66) |  |
| Total Sales |  | $ | 1,269,925 |  |  | $ | 1,632,782 |  |  | (22) | % |  | $ | 3,578,741 |  |  | $ | 4,251,107 |  |  | (16) | % |

[0001032975-23-000004:8k_2_02:36]
(1) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-23-000004:8k_2_02:37]
(2) Other includes Smart Home.

[0001032975-23-000004:8k_2_02:38]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
| GAAP TO NON-GAAP RECONCILIATION (A) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Gross profit - GAAP |  | $ | 477,268 |  |  | $ | 658,010 |  |  | $ | 1,375,651 |  |  | $ | 1,769,099 |  |
| Share-based compensation expense |  | 1,324 |  |  | 1,782 |  |  | 4,228 |  |  | 5,253 |  |
| Amortization of intangible assets |  | 3,168 |  |  | 3,126 |  |  | 9,355 |  |  | 11,028 |  |
| Gross profit - Non-GAAP |  | $ | 481,760 |  |  | $ | 662,918 |  |  | $ | 1,389,234 |  |  | $ | 1,785,380 |  |
| Gross margin - GAAP |  | 37.6 | % |  | 40.3 | % |  | 38.4 | % |  | 41.6 | % |
| Gross margin - Non-GAAP |  | 37.9 | % |  | 40.6 | % |  | 38.8 | % |  | 42.0 | % |
| Operating expenses - GAAP |  | $ | 300,523 |  |  | $ | 395,259 |  |  | $ | 956,026 |  |  | $ | 1,123,856 |  |
| Less: Share-based compensation expense |  | 14,481 |  |  | 23,010 |  |  | 47,512 |  |  | 67,212 |  |
| Less: Amortization of intangible assets and acquisition-related costs |  | 2,810 |  |  | 3,662 |  |  | 9,052 |  |  | 13,986 |  |
| Less: Impairment of intangible assets |  | — |  |  | 7,000 |  |  | — |  |  | 7,000 |  |
| Less: Change in fair value of contingent consideration for business acquisition |  | — |  |  | (1,110) |  |  | — |  |  | (3,509) |  |
| Less: Restructuring charges, net |  | 5,654 |  |  | 1,759 |  |  | 16,471 |  |  | 1,770 |  |
| Operating expenses - Non-GAAP |  | $ | 277,578 |  |  | $ | 360,938 |  |  | $ | 882,991 |  |  | $ | 1,037,397 |  |
| % of net sales - GAAP |  | 23.7 | % |  | 24.2 | % |  | 26.7 | % |  | 26.4 | % |
| % of net sales - Non-GAAP |  | 21.9 | % |  | 22.1 | % |  | 24.7 | % |  | 24.4 | % |
| Operating income - GAAP |  | $ | 176,745 |  |  | $ | 262,751 |  |  | $ | 419,625 |  |  | $ | 645,243 |  |
| Share-based compensation expense |  | 15,805 |  |  | 24,792 |  |  | 51,740 |  |  | 72,465 |  |
| Amortization of intangible assets and acquisition-related costs |  | 5,978 |  |  | 6,788 |  |  | 18,407 |  |  | 25,014 |  |
| Impairment of intangible assets |  | — |  |  | 7,000 |  |  | — |  |  | 7,000 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (1,110) |  |  | — |  |  | (3,509) |  |
| Restructuring charges, net |  | 5,654 |  |  | 1,759 |  |  | 16,471 |  |  | 1,770 |  |
| Operating income - Non-GAAP |  | $ | 204,182 |  |  | $ | 301,980 |  |  | $ | 506,243 |  |  | $ | 747,983 |  |
| % of net sales - GAAP |  | 13.9 | % |  | 16.1 | % |  | 11.7 | % |  | 15.2 | % |
| % of net sales - Non-GAAP |  | 16.1 | % |  | 18.5 | % |  | 14.1 | % |  | 17.6 | % |
| Net income - GAAP |  | $ | 140,153 |  |  | $ | 210,011 |  |  | $ | 323,080 |  |  | $ | 536,308 |  |
| Share-based compensation expense |  | 15,805 |  |  | 24,792 |  |  | 51,740 |  |  | 72,465 |  |
| Amortization of intangible assets and acquisition-related costs |  | 5,978 |  |  | 6,788 |  |  | 18,407 |  |  | 25,014 |  |
| Impairment of intangible assets |  | — |  |  | 7,000 |  |  | — |  |  | 7,000 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (1,110) |  |  | — |  |  | (3,509) |  |
| Restructuring charges, net |  | 5,654 |  |  | 1,759 |  |  | 16,471 |  |  | 1,770 |  |
| Loss on investments |  | 1,488 |  |  | 460 |  |  | 13,065 |  |  | 1,421 |  |
| Non-GAAP income tax adjustment |  | 16,230 |  |  | 13,054 |  |  | 23,296 |  |  | 12,463 |  |
| Net income - Non-GAAP |  | $ | 185,308 |  |  | $ | 262,754 |  |  | $ | 446,059 |  |  | $ | 652,932 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.86 |  |  | $ | 1.24 |  |  | $ | 1.96 |  |  | $ | 3.14 |  |
| Diluted - Non-GAAP |  | $ | 1.14 |  |  | $ | 1.55 |  |  | $ | 2.71 |  |  | $ | 3.82 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non-GAAP |  | 162,529 |  |  | 169,707 |  |  | 164,427 |  |  | 171,027 |  |

[0001032975-23-000004:8k_2_02:39]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
| SHARE-BASED COMPENSATION EXPENSE |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 1,324 |  |  | $ | 1,782 |  |  | $ | 4,228 |  |  | $ | 5,253 |  |
| Marketing and selling |  | 8,014 |  |  | 10,699 |  |  | 25,240 |  |  | 28,987 |  |
| Research and development |  | 2,756 |  |  | 4,510 |  |  | 11,568 |  |  | 14,295 |  |
| General and administrative |  | 3,711 |  |  | 7,801 |  |  | 10,704 |  |  | 23,930 |  |
| Total share-based compensation expense |  | 15,805 |  |  | 24,792 |  |  | 51,740 |  |  | 72,465 |  |
| Income tax benefit |  | (3,276) |  |  | (3,581) |  |  | (7,496) |  |  | (23,460) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 12,529 |  |  | $ | 21,211 |  |  | $ | 44,244 |  |  | $ | 49,005 |  |

[0001032975-23-000004:8k_2_02:40]
*Note: These preliminary results for the three and nine months ended December 31, 2022 are subject to adjustments, including subsequent events that may occur through the date of filing our Quarterly Report on Form 10-Q.

[0001032975-23-000004:8k_2_02:41]
(A) Non-GAAP Financial Measures

[0001032975-23-000004:8k_2_02:42]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-23-000004:8k_2_02:43]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended December 31, 2022 and prior periods presented, we excluded items in the following general categories, each of which are described below:

[0001032975-23-000004:8k_2_02:44]
Share-based compensation expense. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-23-000004:8k_2_02:45]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit, operating expenses, and financial results from period to period.

[0001032975-23-000004:8k_2_02:46]
Acquisition-related costs and change in fair value of contingent consideration for business acquisition.  We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition-related costs include certain incremental expenses incurred to effect a business combination. Fair value of contingent consideration is associated with our estimates of the value of earn-outs in connection with certain acquisitions. We believe that providing the non-GAAP measures excluding these costs and credits, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-23-000004:8k_2_02:47]
Impairment of intangible assets. We may incur impairment of intangible assets expense, primarily in connection with our past business or asset acquisitions. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such expenses are not reflective of our ongoing operating results.

[0001032975-23-000004:8k_2_02:48]
Restructuring charges, net. These expenses are associated with restructuring plans, and will vary based on the initiatives in place during any given period. Restructuring charges may include costs related to employee terminations, facility closures and early cancellation of certain contracts as well as other costs resulting from our restructuring initiatives. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operating results.

[0001032975-23-000004:8k_2_02:49]
Loss (gain) on investments. We recognize losses (gains) related to our investments in various companies, which vary depending on the operational and financial performance of the companies in which we invest. These amounts include our losses (earnings) on equity method investments, investment impairments and losses (gains) resulting from sales or other events related to our investments. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such losses (gains) are not reflective of our ongoing operations.

[0001032975-23-000004:8k_2_02:50]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above and other events; the determination of which is based upon the nature of the underlying items, the mix of income and losses in jurisdictions and the relevant tax rates in which we operate.

[0001032975-23-000004:8k_2_02:51]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-23-000004:8k_2_02:52]
Additional Supplemental Financial Information - Constant Currency

[0001032975-23-000004:8k_2_02:53]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.

## item 5.02 — body, verbatim

[0001032975-23-000004:8k_body:1]
ITEM 5.02. DEPARTURE OF DIRECTORS OR CERTAIN OFFICERS; ELECTION OF DIRECTORS; APPOINTMENT OF CERTAIN OFFICERS; COMPENSATORY ARRANGEMENTS OF CERTAIN OFFICERS.

[0001032975-23-000004:8k_body:2]
On January 21, 2023, the Board of Directors of Logitech appointed Prakash Arunkundrum as Chief Operating Officer, effective as of January 23, 2023.

[0001032975-23-000004:8k_body:3]
As previously disclosed, Mr. Arunkundrum served as Logitech’s Head of Global Operations & Sustainability, a position he has held since May 2018.  He joined Logitech in 2015 and held operations positions as Vice President New Product Introductions & Strategic Initiatives from August 2015 to July 2016 and Vice President Global Sourcing and New Product Introductions from July 2016 to May 2018. Prior to joining Logitech, Mr. Arunkundrum was a Principal at A.T. Kearney, a global management consulting firm, from July 2014 to August 2015. He also served as Director, Management Consulting at PricewaterhouseCoopers, a multinational professional services network of firms, from September 2011 to July 2014 and Principal at PRTM Management Consultants LLC, a management consulting firm acquired by PricewaterhouseCoopers, from March 2010 to September 2011. Prior to his management consulting roles, Mr. Arunkundrum held several management positions at i2 Technologies, a supply chain management company acquired by JDA Software, from March 2007 to February 2010. Early in his career, he held product management positions at supply chain startups and i2 Technologies. Mr. Arunkundrum holds a BTech degree in Chemical Engineering from Central ElectroChemical Research Institute (“CECRI”) in Karaikudi, India and a Master of Science in Materials Engineering from University of Maryland at College Park.

[0001032975-23-000004:8k_body:4]
Mr. Arunkundrum will remain a member of Logitech’s Group Management Team and an executive officer of the Company. There is no family relationship between Mr. Arunkundrum and any director or executive officer of Logitech. Logitech has not entered into any transactions with Mr. Arunkundrum that would require disclosure pursuant to Item 404(a) of Regulation S-K.

[0001032975-23-000004:8k_body:5]
At this time, there have been no changes to Mr. Arunkundrum’s compensation arrangements with Logitech in connection with his appointment as Chief Operating Officer. As part of its annual executive compensation review process, Logitech will consider Mr. Arunkundrum’s compensation along with that of the rest of its executive team.
