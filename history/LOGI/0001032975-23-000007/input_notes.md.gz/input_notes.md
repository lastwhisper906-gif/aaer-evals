# LOGI notes — 0001032975-23-000007


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-23-000007:notes:1]
[same as prior period, unchanged from 0001628280-22-027224:notes:1]

[0001032975-23-000007:notes:2]
[same as prior period, unchanged from 0001628280-22-027224:notes:2]

[0001032975-23-000007:notes:3]
[same as prior period, unchanged from 0001628280-22-027224:notes:3]

[0001032975-23-000007:notes:4]
[same as prior period, unchanged from 0001628280-22-027224:notes:4]

[0001032975-23-000007:notes:5]
[same as prior period, unchanged from 0001628280-22-027224:notes:5]

[0001032975-23-000007:notes:6]
[same as prior period, unchanged from 0001628280-22-027224:notes:6]

[0001032975-23-000007:notes:7]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and nine months ended December 31, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2023, or any future periods.

[0001032975-23-000007:notes:8]
[same as prior period, unchanged from 0001628280-22-027224:notes:8]

[0001032975-23-000007:notes:9]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted, there have been no material changes in the Company’s significant accounting policies during the nine months ended December 31, 2022 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2022.

[0001032975-23-000007:notes:10]
[same as prior period, unchanged from 0001628280-22-027224:notes:10]

[0001032975-23-000007:notes:11]
[same as prior period, unchanged from 0001628280-22-027224:notes:11]

[0001032975-23-000007:notes:12]
[same as prior period, unchanged from 0001628280-22-027224:notes:12]

[0001032975-23-000007:notes:13]
[same as prior period, unchanged from 0001628280-22-027224:notes:13]

[0001032975-23-000007:notes:14]
[same as prior period, unchanged from 0001628280-22-027224:notes:14]

[0001032975-23-000007:notes:15]
In March 2020, the World Health Organization declared the outbreak of COVID-19 as a pandemic, which continues to spread throughout the world. The COVID-19 pandemic resulted in industry-wide global supply chain challenges, including manufacturing, transportation and logistics. The Company purchases certain products and key components from a limited number of sources, and depends on the supply chain, including freight, to receive components, transport finished goods and deliver the Company's products across the world.

[0001032975-23-000007:notes:16]
More recently, the Company has also been impacted by adverse macroeconomic and geopolitical conditions. These conditions include but are not limited to inflation, foreign currency fluctuations, and slowdown of economic activity around the world, in part due to rising interest rates, and lower consumer and enterprise spending. In addition, the war in Ukraine increased global supply chain, logistics, and inflationary challenges. Such global or regional economic and political conditions adversely affect demand for the Company's products. These conditions also have an impact on the Company's suppliers, contract manufacturers, logistics providers, and distributors, causing volatility in cost of materials and shipping and transportation rates, and as a result impacting the pricing of the Company's products. Price increases may not successfully offset cost increases or may cause the Company to lose market share and in turn adversely impact the Company's results of operations.

[0001032975-23-000007:notes:17]
While global supply chain challenges have improved since the second quarter of fiscal year 2023, including logistics costs and shipping lead times, the increase of COVID-19 infections in China during the third quarter of fiscal year 2023 causes uncertainty in supply availability. If macroeconomic and geopolitical conditions and COVID-19 related factors do not improve or worsen, the Company's results of operations will continue to be adversely impacted.

[0001032975-23-000007:notes:18]
[same as prior period, unchanged from 0001628280-22-027224:notes:18]

[0001032975-23-000007:notes:19]
In October 2021, the Financial Accounting Standard Board issued ASU 2021-08, "Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers" (ASU 2021-08). The update requires an acquirer in a business combination to recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Accounting Standards Codification ("ASC") 606, Revenue from Contracts with Customers, as if it had originated the contracts. The standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2022. The Company early adopted the standard effective April 1, 2022 and applies the standard prospectively to business combinations that occurred on or after April 1, 2022. The adoption of ASU 2021-08 did not have a material impact on the Company's condensed consolidated financial statements.


## us-gaap:EarningsPerShareTextBlock

[0001032975-23-000007:notes:20]
[same as prior period, unchanged from 0001628280-22-027224:notes:20]

[0001032975-23-000007:notes:21]
The following table summarizes the computations of basic and diluted net income per share for the three and nine months ended December 31, 2022 and 2021 (in thousands, except per share amounts):

[0001032975-23-000007:notes:22]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net income |  | $ | 140,153 |  |  | $ | 210,011 |  |  | $ | 323,080 |  |  | $ | 536,308 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 161,244 |  |  | 167,090 |  |  | 163,042 |  |  | 167,953 |  |
| Effect of potentially dilutive equivalent shares |  | 1,285 |  |  | 2,617 |  |  | 1,385 |  |  | 3,074 |  |
| Weighted average shares outstanding - diluted |  | 162,529 |  |  | 169,707 |  |  | 164,427 |  |  | 171,027 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.87 |  |  | $ | 1.26 |  |  | $ | 1.98 |  |  | $ | 3.19 |  |
| Diluted |  | $ | 0.86 |  |  | $ | 1.24 |  |  | $ | 1.96 |  |  | $ | 3.14 |  |

[0001032975-23-000007:notes:23]
Share equivalents attributable to outstanding stock options, restricted stock units ("RSUs") and employee share purchase plans ("ESPP") totaling 1.6 million and 0.8 million for the three months ended December 31, 2022 and 2021, respectively, and 2.0 million and 0.9 million for the nine months ended December 31, 2022 and 2021, respectively, were excluded from the calculation of diluted net income per share because their effect would have been anti-dilutive. A small number of performance-based awards were not included in the calculation because all necessary conditions had not been satisfied by the end of the respective period, and those shares were not issuable if the end of the reporting period were the end of the performance contingency period.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-23-000007:notes:24]
[same as prior period, unchanged from 0001628280-22-027224:notes:24]

[0001032975-23-000007:notes:25]
[same as prior period, unchanged from 0001628280-22-027224:notes:25]

[0001032975-23-000007:notes:26]
As of December 31, 2022, the Company offers the 2006 Employee Share Purchase Plan (Non-U.S.), as amended and restated ("2006 ESPP"), the 1996 Employee Share Purchase Plan (U.S.), as amended and restated ("1996 ESPP"), and the 2006 Stock Incentive Plan ("2006 Plan") as amended and restated. Shares issued to employees as a result of purchases or exercises under these plans are generally issued from shares held in treasury stock.

[0001032975-23-000007:notes:27]
The following table summarizes the share-based compensation expense and total income tax benefit recognized for share-based awards for the three and nine months ended December 31, 2022 and 2021 (in thousands):

[0001032975-23-000007:notes:28]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Cost of goods sold |  | $ | 1,324 |  |  | $ | 1,782 |  |  | $ | 4,228 |  |  | $ | 5,253 |  |
| Marketing and selling |  | 8,014 |  |  | 10,699 |  |  | 25,240 |  |  | 28,987 |  |
| Research and development |  | 2,756 |  |  | 4,510 |  |  | 11,568 |  |  | 14,295 |  |
| General and administrative |  | 3,711 |  |  | 7,801 |  |  | 10,704 |  |  | 23,930 |  |
| Total share-based compensation expense |  | 15,805 |  |  | 24,792 |  |  | 51,740 |  |  | 72,465 |  |
| Income tax benefit |  | (3,276) |  |  | (3,581) |  |  | (7,496) |  |  | (23,460) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 12,529 |  |  | $ | 21,211 |  |  | $ | 44,244 |  |  | $ | 49,005 |  |

[0001032975-23-000007:notes:29]
[same as prior period, unchanged from 0001628280-22-027224:notes:29]

[0001032975-23-000007:notes:30]
Share-based compensation costs capitalized as part of inventory were $1.3 million and $1.1 million for the three months ended December 31, 2022 and 2021, respectively, and $4.4 million and $4.1 million for the nine months ended December 31, 2022 and 2021, respectively.

[0001032975-23-000007:notes:31]
[same as prior period, unchanged from 0001628280-22-027224:notes:31]

[0001032975-23-000007:notes:32]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The costs of $2.7 million and $3.4 million recorded for the three months ended December 31, 2022 and 2021, respectively, and $8.3 million and $10.0 million for the nine months ended December 31, 2022 and 2021, respectively, were primarily related to service costs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-23-000007:notes:33]
[same as prior period, unchanged from 0001628280-22-027224:notes:33]

[0001032975-23-000007:notes:34]
[same as prior period, unchanged from 0001628280-22-027224:notes:34]

[0001032975-23-000007:notes:35]
The income tax provision for the three and nine months ended December 31, 2022 was $42.7 million and $87.8 million, based on an effective income tax rate of 23.3% and 21.4% of pre-tax income, respectively. The income tax provision for the same periods ended December 30, 2021 was $49.3 million and $107.8 million, based on an effective income tax rate of 19.0% and 16.7% of pre-tax income, respectively.

[0001032975-23-000007:notes:36]
The change in the effective income tax rate for the three and nine months ended December 31, 2022 was primarily due to the mix of income and losses in the various tax jurisdictions in which the Company operates. There were discrete tax benefits of $0.2 million and $1.4 million from the recognition of excess tax benefits in the United States in the three and nine months ended December 31, 2022, respectively. In addition, there were discrete tax benefits of $1.7 million and $3.2 million from the reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the three and nine month period ended December 31, 2022. The change in the effective income tax rate for the three and nine months ended December 31, 2021 was primarily due to the mix of income and losses in the various tax jurisdictions in which the Company operates. There were discrete tax benefits of $0.8 million and $15.2 million from the recognition of excess tax benefits in the United States in the three and nine months ended December 31, 2021, respectively. Furthermore, there were discrete tax benefits of $1.3 million and $2.8 million from the reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the three and nine month period ended December 31, 2021.

[0001032975-23-000007:notes:37]
As of December 31, 2022 and March 31, 2022, the total amount of unrecognized tax benefits due to uncertain tax positions was $184.0 million and $176.0 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-23-000007:notes:38]
As of December 31, 2022 and March 31, 2022, the Company had $117.6 million and $83.4 million, respectively, in non-current income taxes payable including interest and penalties, related to the Company's income tax liability for uncertain tax positions.

[0001032975-23-000007:notes:39]
The Company recognizes interest and penalties related to unrecognized tax positions in the income tax provision. As of December 31, 2022 and March 31, 2022, the Company had $5.2 million and $3.6 million, respectively, of accrued interest and penalties related to uncertain tax positions in non-current income taxes payable.

[0001032975-23-000007:notes:40]
Although the Company has adequately provided for uncertain tax positions, the provisions related to these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During fiscal year 2023, the Company continues to review its tax positions and provide for or reverse unrecognized tax benefits as they arise. During the next twelve months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. dollar as compared to other currencies. Excluding these factors, uncertain tax 
positions may decrease by as much as $4.3 million from the lapse of the statutes of limitations in various jurisdictions during the next twelve months.On August 16, 2022, the “Inflation Reduction Act” (H.R. 5376) ("IRA") was signed into law in the United States. The IRA establishes a new corporate alternative minimum tax based on financial statement income adjusted for certain items. The new minimum tax is effective for tax years beginning after December 31, 2022. The Company does not expect the IRA will have a material impact to the Company's financial statements when it becomes effective.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-23-000007:notes:41]
[same as prior period, unchanged from 0001628280-22-027224:notes:41]

[0001032975-23-000007:notes:42]
[same as prior period, unchanged from 0001628280-22-027224:notes:42]

[0001032975-23-000007:notes:43]
|  |  | December 31, 2022 |  | March 31, 2022 |
| Accounts receivable, net: |  |  |  |  |
| Accounts receivable |  | $ | 1,121,377 |  |  | $ | 964,766 |  |
| Allowance for doubtful accounts |  | — |  |  | (2,212) |  |
| Allowance for sales returns |  | (14,021) |  |  | (12,321) |  |
| Allowance for cooperative marketing arrangements |  | (62,734) |  |  | (56,372) |  |
| Allowance for customer incentive programs |  | (114,160) |  |  | (97,460) |  |
| Allowance for pricing programs |  | (128,027) |  |  | (120,797) |  |
|  |  | $ | 802,435 |  |  | $ | 675,604 |  |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 202,798 |  |  | $ | 226,155 |  |
| Finished goods |  | 594,897 |  |  | 706,969 |  |
|  |  | $ | 797,695 |  |  | $ | 933,124 |  |
| Other current assets: |  |  |  |  |
| Value-added tax ("VAT") receivables |  | $ | 51,681 |  |  | $ | 58,850 |  |
| Prepaid expenses and other assets |  | 73,407 |  |  | 76,628 |  |
|  |  | $ | 125,088 |  |  | $ | 135,478 |  |
| Property, plant and equipment, net: |  |  |  |  |
| Property, plant and equipment |  | $ | 496,830 |  |  | $ | 459,413 |  |
| Less: accumulated depreciation and amortization |  | (378,647) |  |  | (349,606) |  |
|  |  | $ | 118,183 |  |  | $ | 109,807 |  |
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 190,558 |  |  | $ | 193,629 |  |
| Investments in privately held companies |  | 32,600 |  |  | 43,068 |  |
| Right-of-use assets |  | 69,953 |  |  | 40,661 |  |
| Investments for deferred compensation plan |  | 27,665 |  |  | 28,431 |  |
| Other assets |  | 15,103 |  |  | 14,933 |  |
|  |  | $ | 335,879 |  |  | $ | 320,722 |  |

[0001032975-23-000007:notes:44]
[same as prior period, unchanged from 0001628280-22-027224:notes:44]

[0001032975-23-000007:notes:45]
|  |  | December 31, 2022 |  | March 31, 2022 |
| Accrued and other current liabilities: |  |  |  |  |
| Accrued customer marketing, pricing and incentive programs |  | $ | 238,518 |  |  | $ | 232,393 |  |
| Accrued personnel expenses |  | 113,486 |  |  | 165,090 |  |
| Accrued sales return liability |  | 42,743 |  |  | 40,507 |  |
| Warranty accrual |  | 29,999 |  |  | 32,987 |  |
| VAT payable |  | 34,149 |  |  | 39,602 |  |
| Income taxes payable |  | 17,839 |  |  | 35,355 |  |
| Accrued payables - non-inventory |  | 18,398 |  |  | 26,722 |  |
| Operating lease liabilities |  | 11,577 |  |  | 13,690 |  |
| Contingent consideration |  | 6,368 |  |  | 8,042 |  |
| Other current liabilities |  | 192,492 |  |  | 190,460 |  |
|  |  | $ | 705,569 |  |  | $ | 784,848 |  |
| Other non-current liabilities: |  |  |  |  |
| Employee benefit plan obligations |  | $ | 49,082 |  |  | $ | 50,741 |  |
| Operating lease liabilities |  | 61,414 |  |  | 28,207 |  |
| Obligation for deferred compensation plan |  | 27,665 |  |  | 28,431 |  |
| Warranty accrual |  | 12,632 |  |  | 13,232 |  |
| Deferred tax liabilities |  | 3,500 |  |  | 1,962 |  |
| Contingent consideration |  | 245 |  |  | 4,217 |  |
| Other non-current liabilities |  | 11,377 |  |  | 5,343 |  |
|  |  | $ | 165,915 |  |  | $ | 132,133 |  |

[0001032975-23-000007:notes:46]
The Company recorded approximately $43.0 million right-of-use assets and operating lease liabilities during the nine months ended December 31, 2022, primarily related to newly commenced operating leases for office spaces in the Americas and EMEA regions.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-23-000007:notes:47]
[same as prior period, unchanged from 0001628280-22-027224:notes:47]

[0001032975-23-000007:notes:48]
[same as prior period, unchanged from 0001628280-22-027224:notes:48]

[0001032975-23-000007:notes:49]
[same as prior period, unchanged from 0001628280-22-027224:notes:49]

[0001032975-23-000007:notes:50]
[same as prior period, unchanged from 0001628280-22-027224:notes:50]

[0001032975-23-000007:notes:51]
[same as prior period, unchanged from 0001628280-22-027224:notes:51]

[0001032975-23-000007:notes:52]
[same as prior period, unchanged from 0001628280-22-027224:notes:52]

[0001032975-23-000007:notes:53]
|  |  | December 31, 2022 |  | March 31, 2022 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 603,163 |  |  | $ | — |  |  | $ | — |  |  | $ | 762,055 |  |  | $ | — |  |  | $ | — |  |
| Investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 10 |  |  | $ | — |  |  | $ | — |  |  | $ | 108 |  |  | $ | — |  |  | $ | — |  |
| Common stock |  | 705 |  |  | — |  |  | — |  |  | 2,329 |  |  | — |  |  | — |  |
| Money market funds |  | 9,728 |  |  | — |  |  | — |  |  | 6,765 |  |  | — |  |  | — |  |
| Mutual funds |  | 17,222 |  |  | — |  |  | — |  |  | 19,229 |  |  | — |  |  | — |  |
| Total investments for deferred compensation plan |  | $ | 27,665 |  |  | $ | — |  |  | $ | — |  |  | $ | 28,431 |  |  | $ | — |  |  | $ | — |  |
| Currency derivative assetsincluded in other current assets |  | $ | — |  |  | $ | 668 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,517 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration included in accrued and other current liabilities |  | $ | — |  |  | $ | — |  |  | $ | 6,368 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,042 |  |
| Contingent consideration included in other non-current liabilities |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 3,971 |  |
| Currency derivative liabilitiesincluded in accrued and other current liabilities |  | $ | — |  |  | $ | 3,519 |  |  | $ | — |  |  | $ | — |  |  | $ | 165 |  |  | $ | — |  |

[0001032975-23-000007:notes:54]
[same as prior period, unchanged from 0001628280-22-027224:notes:54]

[0001032975-23-000007:notes:55]
The following table summarizes the change in the fair value of the Company's contingent consideration balance during the nine months ended December 31, 2022 and 2021 (in thousands):

[0001032975-23-000007:notes:56]
|  |  | Nine Months EndedDecember 31, |
|  |  | 2022 |  | 2021 |
| Beginning of the period |  | $ | 12,259 |  |  | $ | 6,967 |  |
| Fair value of contingent consideration upon acquisition (1) |  | 2,151 |  |  | 9,973 |  |
| Change in fair value of contingent consideration |  | — |  |  | (3,509) |  |
| Settlement of contingent consideration |  | (5,954) |  |  | (880) |  |
| Effect of foreign currency exchange rate changes |  | (1,843) |  |  | — |  |
| End of the period |  | $ | 6,613 |  |  | $ | 12,551 |  |

[0001032975-23-000007:notes:57]
[same as prior period, unchanged from 0001628280-22-027224:notes:57]

[0001032975-23-000007:notes:58]
[same as prior period, unchanged from 0001628280-22-027224:notes:58]

[0001032975-23-000007:notes:59]
[same as prior period, unchanged from 0001628280-22-027224:notes:59]

[0001032975-23-000007:notes:60]
[same as prior period, unchanged from 0001628280-22-027224:notes:60]

[0001032975-23-000007:notes:61]
The contingent consideration arising from the technology acquisition on January 4, 2021, represents the future potential earn-out payments of up to $3.0 million payable in cash upon the achievement of two technical development milestones required to be completed as of December 31, 2021 and March 31, 2022. The fair value of the contingent amount was determined using a probability-weighted expected payment model and discounted at the estimated cost of debt. During the second quarter of fiscal year 2023, the Company paid $2.0 million for the contingent consideration related to the first technical development milestone. The Company expects to pay the remaining $1.0 million for the second technical development milestone within next twelve months.

[0001032975-23-000007:notes:62]
[same as prior period, unchanged from 0001628280-22-027224:notes:62]

[0001032975-23-000007:notes:63]
[same as prior period, unchanged from 0001628280-22-027224:notes:63]

[0001032975-23-000007:notes:64]
The marketable securities for the Company's deferred compensation plan were recorded at a fair value of $27.7 million and $28.4 million, as of December 31, 2022 and March 31, 2022, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized gains (losses) related to marketable securities for the three and nine months ended December 31, 2022 and 2021 were not material and were included in other income (expense), net in the Company's condensed consolidated statements of operations.

[0001032975-23-000007:notes:65]
[same as prior period, unchanged from 0001628280-22-027224:notes:65]

[0001032975-23-000007:notes:66]
The Company has certain non-marketable investments included in other assets that are accounted for as equity method investments, with a carrying value of $21.3 million and $40.2 million as of December 31, 2022 and March 31, 2022, respectively. Gains (losses) related to equity method investments for the three and nine months ended December 31, 2022 and 2021 were not material and are included in other income (expense), net in the Company's condensed consolidated statements of operations.

[0001032975-23-000007:notes:67]
During the nine months ended December 31, 2022, the Company recorded an impairment charge, before tax, of $21.4 million for one of its equity method investments as it was determined that the carrying value of the investment was not recoverable. The impairment charge is included in other income (expense), net in the Company's condensed consolidated statement of operations for the nine months ended December 31, 2022. There was no impairment of equity method investments during the three months ended December 31, 2022 and 2021 and the nine months ended December 31, 2021.

[0001032975-23-000007:notes:68]
[same as prior period, unchanged from 0001628280-22-027224:notes:68]

[0001032975-23-000007:notes:69]
Financial Assets.  The Company has certain equity investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with the same or similar security from the same issuer. The amount of these equity investments without readily determinable fair value included in other assets was $10.9 million and $2.9 million as of December 31, 2022 and March 31, 2022, respectively. During the nine months ended December 31, 2022, the Company recorded an unrealized gain, before tax, of $6.9 million for its investment in a private company as a result of observable price changes for similar securities issued by this company (level 2 fair value measurement). There was no impairment of these financial assets during the three and nine months ended December 31, 2022 and 2021, other than an immaterial impairment charge related to one of the Company’s investments without readily determinable fair value recorded during the second quarter of fiscal year 2023.

[0001032975-23-000007:notes:70]
Non-Financial Assets.  Goodwill, intangible assets, and property, plant and equipment, are not required to be measured at fair value on a recurring basis. However, if the Company is required to evaluate these non-financial 
assets for impairment, whether due to certain triggering events or because of the required annual impairment test, and a resulting impairment is recorded to reduce the carrying value to the fair value, the non-financial assets are measured at fair value during such period. There was no impairment of non-financial assets during the three and nine months ended December 31, 2022. During the three and nine months ended December 31, 2021, the Company recorded impairment charges of $7.0 million for the Jaybird-related intangible assets (see Note 8).


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-23-000007:notes:71]
[same as prior period, unchanged from 0001628280-22-027224:notes:71]

[0001032975-23-000007:notes:72]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis in other current assets and accrued and other current liabilities, respectively, on the condensed consolidated balance sheets as of December 31, 2022 and March 31, 2022. See Note 6 for the fair values of the Company’s derivative instruments as of December 31, 2022 and March 31, 2022.

[0001032975-23-000007:notes:73]
[same as prior period, unchanged from 0001628280-22-027224:notes:73]

[0001032975-23-000007:notes:74]
[same as prior period, unchanged from 0001628280-22-027224:notes:74]

[0001032975-23-000007:notes:75]
The notional amounts of foreign currency exchange forward contracts outstanding related to forecasted inventory purchases were $111.7 million and $125.4 million as of December 31, 2022 and March 31, 2022, respectively. The Company had $4.7 million of net losses related to its cash flow hedges included in accumulated other comprehensive loss as of December 31, 2022, which will be reclassified into earnings within the next twelve months.

[0001032975-23-000007:notes:76]
The following table presents the amounts of gain (loss) on the Company’s derivative instruments designated as hedging instruments for the three and nine months ended December 31, 2022 and 2021 and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income (in thousands):

[0001032975-23-000007:notes:77]
|  |  | Three Months EndedDecember 31, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of GainReclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  |  |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |  |  |  |  |
| Cash flow hedges |  | $ | (6,325) |  |  | $ | 1,061 |  |  | $ | (4,728) |  |  | $ | (3,200) |  |  |  |  |  |
|  |  | Nine Months EndedDecember 31, |
|  |  | Amount of GainDeferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of GainReclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  |  |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |  |  |  |  |
| Cash flow hedges |  | $ | 5,239 |  |  | $ | 3,723 |  |  | $ | (11,766) |  |  | $ | (5,108) |  |  |  |  |  |

[0001032975-23-000007:notes:78]
[same as prior period, unchanged from 0001628280-22-027224:notes:78]

[0001032975-23-000007:notes:79]
[same as prior period, unchanged from 0001628280-22-027224:notes:79]

[0001032975-23-000007:notes:80]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within a month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are not material and included in other income (expense), net in the condensed consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of December 31, 2022 and March 31, 2022 were $217.6 million and $226.5 million, respectively. Foreign currency exchange forward and swap contracts outstanding as of December 31, 2022 primarily consist of contracts in Japanese Yen, Brazilian Real, Canadian Dollar, and Australian Dollar to be settled at future dates at pre-determined exchange rates.

[0001032975-23-000007:notes:81]
[same as prior period, unchanged from 0001628280-22-027224:notes:81]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-23-000007:notes:82]
Goodwill and Other Intangible Assets
The Company conducts its impairment analysis of goodwill annually at December 31 and as necessary, if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting unit may be less than its carrying amount. The Company conducted its annual impairment analysis of goodwill as of December 31, 2022 by performing a qualitative assessment and concluded that it was more likely than not that the fair value of its reporting unit exceeds its carrying amount. In assessing the qualitative factors, the Company considered the impact of change in industry and competitive environment, the Company's market capitalization and budgeted-to-actual revenue performance for the last twelve months.

[0001032975-23-000007:notes:83]
[same as prior period, unchanged from 0001628280-22-027224:notes:83]

[0001032975-23-000007:notes:84]
| As of March 31, 2022 |  | $ | 448,175 |  |
| Acquisitions |  | 7,976 |  |
| Effects of foreign currency translation |  | (1,680) |  |
| As of December 31, 2022 |  | $ | 454,471 |  |

[0001032975-23-000007:notes:85]
[same as prior period, unchanged from 0001628280-22-027224:notes:85]

[0001032975-23-000007:notes:86]
|  |  | December 31, 2022 |  | March 31, 2022 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademark and trade names |  | $ | 36,790 |  |  | $ | (25,787) |  |  | $ | 11,003 |  |  | $ | 36,790 |  |  | $ | (22,295) |  |  | $ | 14,495 |  |
| Developed technology |  | 123,530 |  |  | (93,058) |  |  | 30,472 |  |  | 119,407 |  |  | (83,540) |  |  | 35,867 |  |
| Customer contracts/relationships |  | 71,110 |  |  | (46,026) |  |  | 25,084 |  |  | 71,110 |  |  | (40,971) |  |  | 30,139 |  |
| In-process R&D |  | 3,526 |  |  | — |  |  | 3,526 |  |  | 3,826 |  |  | — |  |  | 3,826 |  |
| Effects of foreign currency translation |  | (1,077) |  |  | 356 |  |  | (721) |  |  | (634) |  |  | 86 |  |  | (548) |  |
| Total |  | $ | 233,879 |  |  | $ | (164,515) |  |  | $ | 69,364 |  |  | $ | 230,499 |  |  | $ | (146,720) |  |  | $ | 83,779 |  |

[0001032975-23-000007:notes:87]
During the third quarter of fiscal year 2022, the Company recognized a pre-tax impairment charge of $7.0 million to Jaybird-related intangible assets, primarily related to customer contracts and relationships, as a result of its decision to discontinue Jaybird-branded products (see Note 13).


## us-gaap:DebtDisclosureTextBlock

[0001032975-23-000007:notes:88]
Financing Arrangements

[0001032975-23-000007:notes:89]
The Company had several uncommitted, unsecured bank lines of credit aggregating $179.2 million and $195.0 million as of December 31, 2022 and March 31, 2022, respectively. There are no financial covenants under these lines of credit with which the Company must comply. As of December 31, 2022 and March 31, 2022, the Company had outstanding bank guarantees of $11.6 million and $25.5 million, respectively, under these lines of credit. There was no borrowing outstanding under these lines of credit as of December 31, 2022 or March 31, 2022.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-23-000007:notes:90]
Commitments and Contingencies

[0001032975-23-000007:notes:91]
Product Warranties

[0001032975-23-000007:notes:92]
Changes in the Company’s warranty liability for the three and nine months ended December 31, 2022 and 2021 were as follows (in thousands):

[0001032975-23-000007:notes:93]
|  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Beginning of the period | $ | 41,960 |  |  | $ | 49,173 |  |  | $ | 46,219 |  |  | $ | 48,832 |  |
| Provision | 8,920 |  |  | 6,962 |  |  | 23,440 |  |  | 23,503 |  |
| Settlements | (8,979) |  |  | (8,056) |  |  | (26,358) |  |  | (24,219) |  |
| Effects of foreign currency translation | 730 |  |  | (144) |  |  | (670) |  |  | (181) |  |
| End of the period | $ | 42,631 |  |  | $ | 47,935 |  |  | $ | 42,631 |  |  | $ | 47,935 |  |

[0001032975-23-000007:notes:94]
Indemnifications

[0001032975-23-000007:notes:95]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2022, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-23-000007:notes:96]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-23-000007:notes:97]
Legal Proceedings

[0001032975-23-000007:notes:98]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-23-000007:notes:99]
[same as prior period, unchanged from 0001628280-22-027224:notes:98]

[0001032975-23-000007:notes:100]
In May 2020, the Company's Board of Directors approved the 2020 share repurchase program, which authorized the Company to use up to $250.0 million to purchase up to 17.3 million of Logitech shares. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. In April 2021, the Company's Board of Directors approved an increase of $750.0 million of the 2020 share repurchase program, to an aggregate amount of $1.0 billion. The Swiss Takeover Board approved this increase and it became effective on May 21, 2021.

[0001032975-23-000007:notes:101]
In July 2022, the Company’s Board of Directors approved an increase of $500 million to the 2020 share repurchase program, to an aggregate amount of up to $1.5 billion to purchase up to 17.3 million of Logitech shares. The Swiss Takeover Board approved this increase and it became effective on August 19, 2022. As of December 31, 2022, $596.3 million was available for repurchase under the 2020 repurchase program. The 2020 share repurchase program is expected to remain in effect for a period of three years through July 27, 2023.

[0001032975-23-000007:notes:102]
[same as prior period, unchanged from 0001628280-22-027224:notes:102]

[0001032975-23-000007:notes:103]
During the nine months ended December 31, 2022, the Company declared and paid cash dividends of CHF 0.96 (USD equivalent of $1.00 based on the exchange rate on the date of declaration) per share, totaling $162.7 million on the Company's outstanding shares. During the nine months ended December 31, 2021, the Company declared and paid cash dividends of CHF 0.87 (USD equivalent of $0.95 based on the exchange rate on the date of declaration) per share, totaling $159.4 million on the Company's outstanding shares.

[0001032975-23-000007:notes:104]
[same as prior period, unchanged from 0001628280-22-027224:notes:104]

[0001032975-23-000007:notes:105]
[same as prior period, unchanged from 0001628280-22-027224:notes:105]

[0001032975-23-000007:notes:106]
[same as prior period, unchanged from 0001628280-22-027224:notes:106]

[0001032975-23-000007:notes:107]
|  |  | Cumulative Translation Adjustment |  | Defined Benefit Plans |  | Deferred Hedging Gains (Losses) |  | Total |
| March 31, 2022 |  | $ | (102,461) |  |  | $ | (3,495) |  |  | $ | 1,833 |  |  | $ | (104,123) |  |
| Other comprehensive income (loss) |  | (5,988) |  |  | (330) |  |  | (6,527) |  |  | (12,845) |  |
| December 31, 2022 |  | $ | (108,449) |  |  | $ | (3,825) |  |  | $ | (4,694) |  |  | $ | (116,968) |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-23-000007:notes:108]
[same as prior period, unchanged from 0001628280-22-027224:notes:108]

[0001032975-23-000007:notes:109]
The Company operates in a single operating segment that encompasses the design, manufacturing and marketing of peripherals for PCs, tablets and other digital platforms. Operating performance measures are provided directly to the Company's CEO, who is considered to be the Company’s Chief Operating Decision Maker. The CEO periodically reviews information such as sales and adjusted operating income (loss) to make business decisions. These operating performance measures do not include restructuring charges, net, share-based compensation expense, amortization and impairment of intangible assets, acquisition-related costs and change in fair value of contingent consideration from business acquisitions.

[0001032975-23-000007:notes:110]
Sales by product categories and sales channels, excluding intercompany transactions, for the three and nine months ended December 31, 2022 and 2021 were as follows (in thousands):

[0001032975-23-000007:notes:111]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Pointing Devices |  | $ | 199,106 |  |  | $ | 231,090 |  |  | $ | 567,589 |  |  | $ | 602,982 |  |
| Keyboards & Combos |  | 220,059 |  |  | 281,608 |  |  | 648,632 |  |  | 736,237 |  |
| PC Webcams |  | 58,481 |  |  | 115,115 |  |  | 178,033 |  |  | 319,504 |  |
| Tablet & Other Accessories |  | 65,157 |  |  | 82,859 |  |  | 185,945 |  |  | 242,932 |  |
| Gaming (1) |  | 391,975 |  |  | 469,282 |  |  | 972,457 |  |  | 1,135,456 |  |
| Video Collaboration |  | 226,374 |  |  | 287,187 |  |  | 708,796 |  |  | 753,725 |  |
| Mobile Speakers |  | 38,321 |  |  | 56,748 |  |  | 99,826 |  |  | 124,724 |  |
| Audio & Wearables |  | 69,104 |  |  | 104,280 |  |  | 211,821 |  |  | 318,965 |  |
| Other (2) |  | 1,348 |  |  | 4,613 |  |  | 5,642 |  |  | 16,582 |  |
| Total Sales |  | $ | 1,269,925 |  |  | $ | 1,632,782 |  |  | $ | 3,578,741 |  |  | $ | 4,251,107 |  |

[0001032975-23-000007:notes:112]
[same as prior period, unchanged from 0001628280-22-027224:notes:112]

[0001032975-23-000007:notes:113]
[same as prior period, unchanged from 0001628280-22-027224:notes:113]

[0001032975-23-000007:notes:114]
Sales by geographic region (based on the customers’ locations) for the three and nine months ended December 31, 2022 and 2021 were as follows (in thousands):

[0001032975-23-000007:notes:115]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Americas |  | $ | 513,835 |  |  | $ | 674,393 |  |  | $ | 1,508,318 |  |  | $ | 1,828,474 |  |
| EMEA |  | 428,532 |  |  | 552,133 |  |  | 1,016,187 |  |  | 1,309,542 |  |
| Asia Pacific |  | 327,558 |  |  | 406,256 |  |  | 1,054,236 |  |  | 1,113,091 |  |
| Total sales |  | $ | 1,269,925 |  |  | $ | 1,632,782 |  |  | $ | 3,578,741 |  |  | $ | 4,251,107 |  |

[0001032975-23-000007:notes:116]
[same as prior period, unchanged from 0001628280-22-027224:notes:116]

[0001032975-23-000007:notes:117]
Switzerland, the Company’s home domicile, represented 4% and 3% of the Company's total consolidated sales for the three months ended December 31, 2022 and 2021, respectively, and 3% for each of the nine months ended December 31, 2022 and 2021.

[0001032975-23-000007:notes:118]
Three customers of the Company each represented 10% or more of the total consolidated gross sales for each of the three and nine months ended December 31, 2022. Two customers of the Company each represented 10% or more of the total consolidated sales for each of the three and nine months ended December 31, 2021.

[0001032975-23-000007:notes:119]
[same as prior period, unchanged from 0001628280-22-027224:notes:119]

[0001032975-23-000007:notes:120]
|  |  | December 31, 2022 |  | March 31, 2022 |
| Americas |  | $ | 49,447 |  |  | $ | 22,578 |  |
| EMEA |  | 38,380 |  |  | 23,830 |  |
| Asia Pacific |  | 78,458 |  |  | 87,265 |  |
| Total |  | $ | 166,285 |  |  | $ | 133,673 |  |

[0001032975-23-000007:notes:121]
Property, plant and equipment, net (excluding software) and right-of-use assets in the United States, China, and Ireland were $48.9 million, $56.8 million, and $17.6 million, respectively, as of December 31, 2022, and $21.7 million, $66.8 million, and $0.9 million respectively, as of March 31, 2022. Property, plant and equipment, net (excluding software) and right-of-use assets in Switzerland, the Company’s country of incorporation, were $12.9 million and $13.6 million as of December 31, 2022 and March 31, 2022, respectively. No other countries 
represented 10% or more of the Company’s total consolidated property, plant and equipment, net (excluding software) and right-of-use assets as of December 31, 2022 or March 31, 2022.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001032975-23-000007:notes:122]
Restructuring 
During the second quarter of fiscal year 2023, the Company initiated a restructuring plan to realign its business group and engineering structure with its go-to-market strategy to more effectively compete within the enterprise market and to better serve end-users. As a result, the Company recorded pre-tax restructuring charges of $5.7 million and $16.5 million for the three and nine months ended December 31, 2022, respectively, which are included in restructuring charges, net in the condensed consolidated statements of operations. The restructuring charges of $5.7 million for the three months ended December 31, 2022 primarily include contract termination and other costs. The restructuring charges for the nine months ended December 31, 2022 include $11.3 million employee severance and other termination benefits and $5.2 million contract termination and other costs. As of December 31, 2022, restructuring liabilities of $8.3 million related to this restructuring plan are included in accrued and other current liabilities in the condensed consolidated balance sheet, which include $3.6 million related to employee severance and other termination benefits and $4.7 million related to contract termination and other costs. The Company expects to substantially complete this restructuring plan within the next nine months.

[0001032975-23-000007:notes:123]
During the third quarter of fiscal year 2022, as part of the Company's strategic review, the Company decided to cease future product launches under the Jaybird brand within the Audio & Wearables product category. As a result, the Company recorded $7.6 million in cost of goods sold related to write-offs for excess inventories, $7.0 million impairment to the intangible assets acquired as part of the Jaybird acquisition (see Note 8), and $1.8 million in restructuring charges, net, primarily related to production cancellation costs, for the three and nine months ended December 31, 2021. This restructuring plan has been substantially completed.
