# LOGI MD&A — 0001032975-23-000007


## mdna

[0001032975-23-000007:mdna:1]
[same as prior period, unchanged from 0001628280-22-027224:mdna:1]

[0001032975-23-000007:mdna:2]
[same as prior period, unchanged from 0001628280-22-027224:mdna:2]

[0001032975-23-000007:mdna:3]
•Our business strategy and investment priorities in relation to competitive offerings and evolving consumer demand trends affecting our products and markets, worldwide economic and capital market conditions, fluctuations in currency exchange rates, and current and future general regional economic conditions for  fiscal year 2023 and beyond;

[0001032975-23-000007:mdna:4]
•The scope, nature or impact of acquisition, strategic alliance, and divestiture activities;

[0001032975-23-000007:mdna:5]
[same as prior period, unchanged from 0001628280-22-027224:mdna:5]

[0001032975-23-000007:mdna:6]
[same as prior period, unchanged from 0001628280-22-027224:mdna:6]

[0001032975-23-000007:mdna:7]
•Our expectations regarding our potential indemnification obligations, and the outcome of pending or future legal proceedings and tax audits;

[0001032975-23-000007:mdna:8]
•Our business and product development and innovation, and their impact on future operating results and anticipated operating costs for fiscal year 2023 and beyond;

[0001032975-23-000007:mdna:9]
•Opportunities for growth and our ability to execute on and take advantage of them, including our marketing initiatives and strategy and our expectations regarding the success thereof;

[0001032975-23-000007:mdna:10]
[same as prior period, unchanged from 0001628280-22-027224:mdna:10]

[0001032975-23-000007:mdna:11]
[same as prior period, unchanged from 0001628280-22-027224:mdna:11]

[0001032975-23-000007:mdna:12]
[same as prior period, unchanged from 0001628280-22-027224:mdna:12]

[0001032975-23-000007:mdna:13]
[same as prior period, unchanged from 0001628280-22-027224:mdna:13]

[0001032975-23-000007:mdna:14]
[same as prior period, unchanged from 0001628280-22-027224:mdna:14]

[0001032975-23-000007:mdna:15]
[same as prior period, unchanged from 0001628280-22-027224:mdna:15]

[0001032975-23-000007:mdna:16]
[same as prior period, unchanged from 0001628280-22-027224:mdna:16]

[0001032975-23-000007:mdna:17]
[same as prior period, unchanged from 0001628280-22-027224:mdna:17]

[0001032975-23-000007:mdna:18]
[same as prior period, unchanged from 0001628280-22-027224:mdna:18]

[0001032975-23-000007:mdna:19]
[same as prior period, unchanged from 0001628280-22-027224:mdna:19]

[0001032975-23-000007:mdna:20]
[same as prior period, unchanged from 0001628280-22-027224:mdna:20]

[0001032975-23-000007:mdna:21]
[same as prior period, unchanged from 0001628280-22-027224:mdna:21]

[0001032975-23-000007:mdna:22]
[same as prior period, unchanged from 0001628280-22-027224:mdna:22]

[0001032975-23-000007:mdna:23]
In March 2020, the World Health Organization declared the outbreak of COVID-19 as a pandemic, which continues to spread throughout the world. The COVID-19 pandemic resulted in industry-wide global supply chain challenges, including manufacturing, transportation and logistics. We purchase certain products and key components from a limited number of sources, and depend on the supply chain, including freight, to receive components, transport finished goods and deliver our products across the world.

[0001032975-23-000007:mdna:24]
More recently, we have also been impacted by adverse macroeconomic and geopolitical conditions. These conditions include but are not limited to inflation, foreign currency fluctuations, and slowdown of economic activity around the world, in part due to rising interest rates, and lower consumer and enterprise spending. In addition, the war in Ukraine increased global supply chain, logistics, and inflationary challenges. Such global or regional economic and political conditions adversely affect demand for our products. These conditions also have an impact on our suppliers, contract manufacturers, logistics providers, and distributors, causing volatility in cost of materials and shipping and transportation rates, and as a result impacting the pricing of our products. Price increases may not successfully offset cost increases or may cause us to lose market share and in turn adversely impact our results of operations.

[0001032975-23-000007:mdna:25]
While global supply chain challenges have improved since the second quarter of fiscal year 2023, including logistics costs and shipping lead times, the increase of COVID-19 infections in China during the third quarter of fiscal year 2023 causes uncertainty in supply availability. If macroeconomic and geopolitical conditions and COVID-19 related factors do not improve or worsen, our results of operations will continue to be adversely impacted.

[0001032975-23-000007:mdna:26]
For additional information, see "Liquidity and Capital Resources" below and Part II item 1A "Risk Factors," including under the caption "Adverse global and regional economic and geopolitical conditions can materially adversely affect our business, results of operations and financial condition," “We purchase key components and products from a limited number of sources, and our business and operating results could be adversely affected if supply were delayed or constrained or if there were shortages of required components,” “Our principal manufacturing operations and third-party contract manufacturers are located in China and Southeast Asia, which exposes us to risks associated with doing business in that geographic area as well as potential tariffs, adverse trade regulations, adverse tax consequences and pressure to move or diversify our manufacturing locations,” “If we do not accurately forecast market demand for our products, our business and operating results could be adversely affected,” "Future impacts of the COVID-19 pandemic are still uncertain and cannot be predicted, and could adversely affect our business, results of operations and financial condition," and "If we do not successfully coordinate the worldwide manufacturing and distribution of our products, we could lose sales.”

[0001032975-23-000007:mdna:27]
[same as prior period, unchanged from 0001628280-22-027224:mdna:27]

[0001032975-23-000007:mdna:28]
Our total sales for the three and nine months ended December 31, 2022 decreased 22% and 16%, respectively, compared to the same periods of the prior fiscal year, driven by a decline in sales of all of our product categories.

[0001032975-23-000007:mdna:29]
Sales for the three months ended December 31, 2022 decreased 24%, 22% and 19% in the Americas, EMEA,  and Asia Pacific regions, respectively, compared to the same period of the prior fiscal year. Sales for the nine months ended December 31, 2022 decreased 22%, 18%, and 5% in the EMEA, Americas and Asia Pacific regions, respectively, compared to the same period of the prior fiscal year.

[0001032975-23-000007:mdna:30]
Gross margin was 37.6% and 38.4% for the three and nine months ended December 31, 2022, respectively, and decreased by 270 basis points and 320 basis points, respectively, compared to the same periods of the prior fiscal year. The gross margin decline for the three-month period was primarily driven by unfavorable impacts from changes in currency exchange rates, higher promotional spending, and inflationary pressure on costs, partially offset by a reduction in our use of expedited shipping. The gross margin decline for the nine-month period was mainly due to unfavorable currency impacts and inflationary pressure on costs, partially offset by a reduction in our use of expedited shipping.

[0001032975-23-000007:mdna:31]
Operating expenses for the three months ended December 31, 2022 were $300.5 million, or 23.7% of sales, compared to $395.3 million, or 24.2% of sales, in the same period of the prior fiscal year. Operating expenses for the nine months ended December 31, 2022 were $956.0 million, or 26.7% of sales, compared to $1,123.9 million or 26.4% of sales, in the same period of the prior fiscal year.

[0001032975-23-000007:mdna:32]
Net income for the three and nine months ended December 31, 2022 was $140.2 million and $323.1 million, respectively, compared to the same periods of the prior fiscal year of $210.0 million, and $536.3 million, respectively.

[0001032975-23-000007:mdna:33]
[same as prior period, unchanged from 0001628280-22-027224:mdna:33]

[0001032975-23-000007:mdna:34]
[same as prior period, unchanged from 0001628280-22-027224:mdna:34]

[0001032975-23-000007:mdna:35]
[same as prior period, unchanged from 0001628280-22-027224:mdna:35]

[0001032975-23-000007:mdna:36]
Creativity & Productivity: Mice and keyboards have long-term structural growth opportunities driven largely by work-from-home, learn-from-home and hybrid work trends. We believe that innovative personal workspace peripherals, such as our mice and keyboards, can refresh the design of personal workspaces and help improve the productivity and engagement of remote work and learning, thus providing growth opportunities. Hybrid work culture has expanded the number of new workspaces to which we can attach our personal workspace peripherals. Increasing adoption of various cloud-based applications has led to multiple unique consumer use cases, which we are addressing with our innovative product portfolio and a deep understanding of our customer base. These hybrid work trends coupled with the popularity of streaming provide growth opportunities for products in our portfolio. The continued popularity of mobile computing devices, including tablets, provides attractive market opportunities for our peripherals and accessories.

[0001032975-23-000007:mdna:37]
[same as prior period, unchanged from 0001628280-22-027224:mdna:37]

[0001032975-23-000007:mdna:38]
Video Collaboration: The long-term structural growth opportunities in the video collaboration market continue to drive commercial and consumer adoption of video conferencing. Video meetings continue to be an opportunity as companies want lower-cost, cloud-based solutions that can provide their employees with the ability to work from anywhere. We are continuing our efforts to create and sell innovative products to equip home offices, small-size meeting rooms, such as huddle rooms, and medium and large-sized meeting rooms. We will continue to invest in the development of select business-oriented products, targeted product marketing and sales channel development. We believe the continued digitization of learning and hybrid learning environments is a future growth opportunity.

[0001032975-23-000007:mdna:39]
[same as prior period, unchanged from 0001628280-22-027224:mdna:39]

[0001032975-23-000007:mdna:40]
[same as prior period, unchanged from 0001628280-22-027224:mdna:40]

[0001032975-23-000007:mdna:41]
[same as prior period, unchanged from 0001628280-22-027224:mdna:41]

[0001032975-23-000007:mdna:42]
[same as prior period, unchanged from 0001628280-22-027224:mdna:42]

[0001032975-23-000007:mdna:43]
Pursuant to the Tax Cuts and Jobs Act of 2017, research and development expenses are required to be capitalized and amortized over five years for U.S. tax purposes if the research and development activities are performed in the United States, effective for tax year beginning after December 31, 2021. Absent a change in legislation, the provision was effective for us beginning in fiscal year 2023 which delays the deductibility of research and development expenses. As a result, cash tax payments in the United States have generally increased beginning in fiscal year 2023 compared to prior years.

[0001032975-23-000007:mdna:44]
[same as prior period, unchanged from 0001628280-22-027224:mdna:44]

[0001032975-23-000007:mdna:45]
[same as prior period, unchanged from 0001628280-22-027224:mdna:45]

[0001032975-23-000007:mdna:46]
[same as prior period, unchanged from 0001628280-22-027224:mdna:46]

[0001032975-23-000007:mdna:47]
[same as prior period, unchanged from 0001628280-22-027224:mdna:47]

[0001032975-23-000007:mdna:48]
There have been no material changes in our critical accounting estimates during the nine months ended December 31, 2022 compared with the critical accounting estimates disclosed in Management's Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended March 31, 2022.

[0001032975-23-000007:mdna:49]
[same as prior period, unchanged from 0001628280-22-027224:mdna:49]

[0001032975-23-000007:mdna:50]
[same as prior period, unchanged from 0001628280-22-027224:mdna:50]

[0001032975-23-000007:mdna:51]
[same as prior period, unchanged from 0001628280-22-027224:mdna:51]

[0001032975-23-000007:mdna:52]
[same as prior period, unchanged from 0001628280-22-027224:mdna:52]

[0001032975-23-000007:mdna:53]
Given our global sales presence and the reporting of our financial results in U.S. Dollars, our financial results could be affected by significant shifts in currency exchange rates. See “Results of Operations” for information on the effect of currency exchange rate fluctuations on our sales. If the U.S. Dollar appreciates or depreciates in comparison to other currencies in future periods, this will affect our results of operations in future periods as well.

[0001032975-23-000007:mdna:54]
[same as prior period, unchanged from 0001628280-22-027224:mdna:54]

[0001032975-23-000007:mdna:55]
[same as prior period, unchanged from 0001628280-22-027224:mdna:55]

[0001032975-23-000007:mdna:56]
[same as prior period, unchanged from 0001628280-22-027224:mdna:56]

[0001032975-23-000007:mdna:57]
[same as prior period, unchanged from 0001628280-22-027224:mdna:57]

[0001032975-23-000007:mdna:58]
Our sales for the three and nine months ended December 31, 2022 decreased 22% and 16%, respectively, compared to the same periods of the prior fiscal year, which was primarily driven by a decline in sales of all of our product categories. Our sales for the three- and nine- month periods were negatively impacted from lower demand, higher promotional spending, and unfavorable changes in currency exchange rates. If currency exchange rates had been constant in the three and nine months ended December 31, 2022 and 2021, our constant dollar sales reduction rates would have been 17% and 12%, respectively.

[0001032975-23-000007:mdna:59]
[same as prior period, unchanged from 0001628280-22-027224:mdna:59]

[0001032975-23-000007:mdna:60]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Australian Dollar, Canadian Dollar, Japanese Yen, Pound Sterling and New Taiwan Dollar. During the three months ended December 31, 2022, approximately 52% of our sales were denominated in currencies other than the U.S. Dollar.

[0001032975-23-000007:mdna:61]
[same as prior period, unchanged from 0001628280-22-027224:mdna:61]

[0001032975-23-000007:mdna:62]
The following table presents the change in sales by region for the three and nine months ended December 31, 2022, compared with the three and nine months ended December 31, 2021:

[0001032975-23-000007:mdna:63]
|  |  | Sales Growth Rate |  | Constant DollarSales Growth Rate |
|  |  | Three Months EndedDecember 31, 2022 |  | Nine Months EndedDecember 31, 2022 |  | Three Months EndedDecember 31, 2022 |  | Nine Months EndedDecember 31, 2022 |
| Americas |  | (24) | % |  | (18) | % |  | (23) | % |  | (17) | % |
| EMEA |  | (22) | % |  | (22) | % |  | (13) | % |  | (13) | % |
| Asia Pacific |  | (19) | % |  | (5) | % |  | (12) | % |  | 1 | % |

[0001032975-23-000007:mdna:64]
[same as prior period, unchanged from 0001628280-22-027224:mdna:64]

[0001032975-23-000007:mdna:65]
The decrease in sales in the Americas region for the three- and nine- month periods presented above was driven by a decrease in sales of all of our product categories.

[0001032975-23-000007:mdna:66]
[same as prior period, unchanged from 0001628280-22-027224:mdna:66]

[0001032975-23-000007:mdna:67]
The decrease in sales in our EMEA region for the three-month period was primarily driven by the decrease in sales of all of our product categories. The decrease in sales in our EMEA region for the nine-month period was primarily driven by the decrease in sales of all of our product categories except Video Collaboration.

[0001032975-23-000007:mdna:68]
[same as prior period, unchanged from 0001628280-22-027224:mdna:68]

[0001032975-23-000007:mdna:69]
The decrease in sales in our Asia Pacific region for the three-month period presented above was primarily driven by a decrease in sales of Keyboards & Combos, Gaming, PC Webcams, and Pointing Devices. The decrease in sales for the nine-month period was primarily driven by a decrease in sales of PC Webcams, Keyboards & Combos, Audio & Wearables, and Video Collaboration, partially offset by an increase in sales of Gaming.

[0001032975-23-000007:mdna:70]
[same as prior period, unchanged from 0001628280-22-027224:mdna:70]

[0001032975-23-000007:mdna:71]
Sales by product categories for the three and nine months ended December 31, 2022 and 2021 were as follows (Dollars in thousands):

[0001032975-23-000007:mdna:72]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Pointing Devices |  | $ | 199,106 |  |  | $ | 231,090 |  |  | (14) | % |  | $ | 567,589 |  |  | $ | 602,982 |  |  | (6) | % |
| Keyboards & Combos |  | 220,059 |  |  | 281,608 |  |  | (22) |  |  | 648,632 |  |  | 736,237 |  |  | (12) |  |
| PC Webcams |  | 58,481 |  |  | 115,115 |  |  | (49) |  |  | 178,033 |  |  | 319,504 |  |  | (44) |  |
| Tablet & Other Accessories |  | 65,157 |  |  | 82,859 |  |  | (21) |  |  | 185,945 |  |  | 242,932 |  |  | (23) |  |
| Gaming (1) |  | 391,975 |  |  | 469,282 |  |  | (16) |  |  | 972,457 |  |  | 1,135,456 |  |  | (14) |  |
| Video Collaboration |  | 226,374 |  |  | 287,187 |  |  | (21) |  |  | 708,796 |  |  | 753,725 |  |  | (6) |  |
| Mobile Speakers |  | 38,321 |  |  | 56,748 |  |  | (32) |  |  | 99,826 |  |  | 124,724 |  |  | (20) |  |
| Audio & Wearables |  | 69,104 |  |  | 104,280 |  |  | (34) |  |  | 211,821 |  |  | 318,965 |  |  | (34) |  |
| Other (2) |  | 1,348 |  |  | 4,613 |  |  | (71) |  |  | 5,642 |  |  | 16,582 |  |  | (66) |  |
| Total Sales |  | $ | 1,269,925 |  |  | $ | 1,632,782 |  |  | (22) | % |  | $ | 3,578,741 |  |  | $ | 4,251,107 |  |  | (16) | % |

[0001032975-23-000007:mdna:73]
[same as prior period, unchanged from 0001628280-22-027224:mdna:73]

[0001032975-23-000007:mdna:74]
[same as prior period, unchanged from 0001628280-22-027224:mdna:74]

[0001032975-23-000007:mdna:75]
[same as prior period, unchanged from 0001628280-22-027224:mdna:75]

[0001032975-23-000007:mdna:76]
[same as prior period, unchanged from 0001628280-22-027224:mdna:76]

[0001032975-23-000007:mdna:77]
[same as prior period, unchanged from 0001628280-22-027224:mdna:77]

[0001032975-23-000007:mdna:78]
Sales of Pointing Devices decreased 14% and 6% for the three and nine months ended December 31, 2022, respectively, compared to the same periods of the prior fiscal year, primarily driven by the decrease in sales of cordless mice.

[0001032975-23-000007:mdna:79]
[same as prior period, unchanged from 0001628280-22-027224:mdna:79]

[0001032975-23-000007:mdna:80]
[same as prior period, unchanged from 0001628280-22-027224:mdna:80]

[0001032975-23-000007:mdna:81]
Sales of Keyboards & Combos decreased 22% for the three months ended December 31, 2022, compared to the same period of the prior fiscal year, primarily driven by the decrease in sales of our cordless combos, and cordless and corded PC keyboards, particularly in our low end products. Sales of Keyboards & Combos decreased 12% for the nine months ended December 31, 2022, compared to the same period of the prior fiscal year, primarily driven by the decrease in sales of our cordless combos and corded PC keyboards, particularly in our low end products.

[0001032975-23-000007:mdna:82]
[same as prior period, unchanged from 0001628280-22-027224:mdna:82]

[0001032975-23-000007:mdna:83]
[same as prior period, unchanged from 0001628280-22-027224:mdna:83]

[0001032975-23-000007:mdna:84]
Sales of PC Webcams decreased 49% and 44% for the three and nine months ended December 31, 2022, respectively, compared to the same periods of the prior fiscal year, primarily driven by the decrease in sales of our HD Pro Webcam C920, 1080p Pro Stream Webcam, and Webcam C260.

[0001032975-23-000007:mdna:85]
[same as prior period, unchanged from 0001628280-22-027224:mdna:85]

[0001032975-23-000007:mdna:86]
[same as prior period, unchanged from 0001628280-22-027224:mdna:86]

[0001032975-23-000007:mdna:87]
Sales of Tablet & Other Accessories products decreased 21% and 23% for the three and nine months ended December 31, 2022, respectively, compared to the same periods of the prior fiscal year, primarily driven by the decrease in sales of most of our products. The decrease in sales for the nine-month period was partially offset by increases in sales of our Rugged Combo 3 Touch and Combo Touch for iPad Air.

[0001032975-23-000007:mdna:88]
[same as prior period, unchanged from 0001628280-22-027224:mdna:88]

[0001032975-23-000007:mdna:89]
[same as prior period, unchanged from 0001628280-22-027224:mdna:89]

[0001032975-23-000007:mdna:90]
[same as prior period, unchanged from 0001628280-22-027224:mdna:90]

[0001032975-23-000007:mdna:91]
Sales of Gaming decreased 16% and 14% for the three and nine months ended December 31, 2022, respectively, compared to the same periods of the prior fiscal year, primarily driven by the decrease in sales of most of the gaming sub-categories.

[0001032975-23-000007:mdna:92]
[same as prior period, unchanged from 0001628280-22-027224:mdna:92]

[0001032975-23-000007:mdna:93]
[same as prior period, unchanged from 0001628280-22-027224:mdna:93]

[0001032975-23-000007:mdna:94]
[same as prior period, unchanged from 0001628280-22-027224:mdna:94]

[0001032975-23-000007:mdna:95]
Sales of Video Collaboration products decreased 21% for the three months ended December 31, 2022,  compared to the same period of the prior fiscal year, driven by a decrease in sales of webcams and conference room cameras due primarily to a slowdown in enterprise spending. Sales of Video Collaboration products decreased 6% for the nine months ended December 31, 2022, compared to the same period of the prior fiscal year, primarily due to the decrease in sales of webcams, partially offset by an increase in sales of conference room cameras, docks and headsets.

[0001032975-23-000007:mdna:96]
[same as prior period, unchanged from 0001628280-22-027224:mdna:96]

[0001032975-23-000007:mdna:97]
[same as prior period, unchanged from 0001628280-22-027224:mdna:97]

[0001032975-23-000007:mdna:98]
[same as prior period, unchanged from 0001628280-22-027224:mdna:98]

[0001032975-23-000007:mdna:99]
Sales of Mobile Speakers decreased 32% and 20% for the three and nine months ended December 31, 2022, respectively, compared to the same periods of the prior fiscal year, primarily due to a decrease in sales of most of our Mobile Speaker sub-categories, partially offset by the sales of our Ultimate Ears Wonderboom 3 mini speakers, introduced in the second quarter of fiscal year 2023.

[0001032975-23-000007:mdna:100]
[same as prior period, unchanged from 0001628280-22-027224:mdna:100]

[0001032975-23-000007:mdna:101]
[same as prior period, unchanged from 0001628280-22-027224:mdna:101]

[0001032975-23-000007:mdna:102]
Sales of Audio & Wearables decreased 34% for each of the three and nine months ended December 31, 2022, compared to the same periods of the prior fiscal year, primarily due to a decrease in sales of almost all sub-categories.

[0001032975-23-000007:mdna:103]
[same as prior period, unchanged from 0001628280-22-027224:mdna:103]

[0001032975-23-000007:mdna:104]
Gross profit for the three and nine months ended December 31, 2022 and 2021 was as follows (Dollars in thousands):

[0001032975-23-000007:mdna:105]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Net sales |  | $ | 1,269,925 |  |  | $ | 1,632,782 |  |  | (22) | % |  | $ | 3,578,741 |  |  | $ | 4,251,107 |  |  | (16) | % |
| Gross profit |  | $ | 477,268 |  |  | $ | 658,010 |  |  | (27) | % |  | $ | 1,375,651 |  |  | $ | 1,769,099 |  |  | (22) | % |
| Gross margin |  | 37.6 | % |  | 40.3 | % |  |  |  | 38.4 | % |  | 41.6 | % |  |  |

[0001032975-23-000007:mdna:106]
[same as prior period, unchanged from 0001628280-22-027224:mdna:106]

[0001032975-23-000007:mdna:107]
Gross margin for the three and nine months ended December 31, 2022 decreased by 270 basis points and 320 basis points, respectively, compared to the same periods of the prior fiscal year. The gross margin decline for the three-month period was primarily driven by unfavorable impacts from changes in currency exchange rates, higher promotional spending, and inflationary pressure on costs, partially offset by a reduction in our use of expedited shipping. The gross margin decline for the nine-month period was mainly due to unfavorable currency impacts and inflationary pressure on costs, partially offset by a reduction in our use of expedited shipping.

[0001032975-23-000007:mdna:108]
[same as prior period, unchanged from 0001628280-22-027224:mdna:108]

[0001032975-23-000007:mdna:109]
Operating expenses for the three and nine months ended December 31, 2022 and 2021 were as follows (Dollars in thousands):

[0001032975-23-000007:mdna:110]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |  |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |  |
| Marketing and selling |  | $ | 196,653 |  |  | $ | 269,941 |  |  | $ | 628,122 |  |  | $ | 778,882 |  |  |
| % of sales |  | 15.5 | % |  | 16.5 | % |  | 17.6 | % |  | 18.3 | % |  |
| Research and development |  | 65,640 |  |  | 75,529 |  |  | 210,166 |  |  | 213,436 |  |  |
| % of sales |  | 5.2 | % |  | 4.6 | % |  | 5.9 | % |  | 5.0 | % |  |
| General and administrative |  | 29,766 |  |  | 38,478 |  |  | 92,215 |  |  | 112,291 |  |  |
| % of sales |  | 2.3 | % |  | 2.4 | % |  | 2.6 | % |  | 2.6 | % |  |
| Amortization of intangible assets and acquisition-related costs |  | 2,810 |  |  | 3,662 |  |  | 9,052 |  |  | 13,986 |  |  |
| % of sales |  | 0.2 | % |  | 0.2 | % |  | 0.3 | % |  | 0.3 | % |  |
| Impairment of intangible assets |  | — |  |  | 7,000 |  |  | — |  |  | 7,000 |  |  |
| % of sales |  | N/A |  | 0.4 | % |  | N/A |  | 0.2 | % |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (1,110) |  |  | — |  |  | (3,509) |  |  |
| % of sales |  | N/A |  | (0.1) | % |  | N/A |  | (0.1) | % |  |
| Restructuring charges, net |  | 5,654 |  |  | 1,759 |  |  | 16,471 |  |  | 1,770 |  |  |
| % of sales |  | 0.4 | % |  | 0.1 | % |  | 0.5 | % |  | — | % |  |
| Total operating expenses |  | $ | 300,523 |  |  | $ | 395,259 |  |  | $ | 956,026 |  |  | $ | 1,123,856 |  |  |
| % of sales |  | 23.7 | % |  | 24.2 | % |  | 26.7 | % |  | 26.4 | % |  |

[0001032975-23-000007:mdna:111]
The decrease in total operating expenses during the three and nine months ended December 31, 2022, compared to the same periods of the prior fiscal year, was mainly due to decreases in marketing and selling expenses.

[0001032975-23-000007:mdna:112]
[same as prior period, unchanged from 0001628280-22-027224:mdna:112]

[0001032975-23-000007:mdna:113]
[same as prior period, unchanged from 0001628280-22-027224:mdna:113]

[0001032975-23-000007:mdna:114]
During the three and nine months ended December 31, 2022, marketing and selling expenses decreased $73.3 million and $150.8 million, respectively, compared to the same periods of the prior fiscal year, primarily driven by lower third-party marketing and advertising spend.

[0001032975-23-000007:mdna:115]
[same as prior period, unchanged from 0001628280-22-027224:mdna:115]

[0001032975-23-000007:mdna:116]
[same as prior period, unchanged from 0001628280-22-027224:mdna:116]

[0001032975-23-000007:mdna:117]
During the three months ended December 31, 2022, research and development expenses decreased $9.9 million, compared to the same period of the prior fiscal year, primarily driven by lower personnel-related costs. During the nine months ended December 31, 2022, research and development expenses decreased $3.3 million, primarily driven by lower personnel-related costs, partially offset by higher outsourcing expenses and travel and entertainment expenses.

[0001032975-23-000007:mdna:118]
[same as prior period, unchanged from 0001628280-22-027224:mdna:118]

[0001032975-23-000007:mdna:119]
[same as prior period, unchanged from 0001628280-22-027224:mdna:119]

[0001032975-23-000007:mdna:120]
During the three and nine months ended December 31, 2022, general and administrative expenses decreased $8.7 million and $20.1 million, respectively, compared to the same periods of the prior fiscal year, primarily driven by lower personnel-related costs.

[0001032975-23-000007:mdna:121]
[same as prior period, unchanged from 0001628280-22-027224:mdna:121]

[0001032975-23-000007:mdna:122]
[same as prior period, unchanged from 0001628280-22-027224:mdna:122]

[0001032975-23-000007:mdna:123]
During the three months ended December 31, 2022, amortization of intangible assets and acquisition-related costs remained flat, compared to the same period of the prior fiscal year. During the nine months ended December 31, 2022, amortization of intangible assets and acquisition-related costs decreased $4.9 million, compared to the same period of the prior fiscal year, primarily due to certain acquired intangible assets becoming fully amortized and the write-off of Jaybird intangible assets in the third quarter of fiscal year 2022.

[0001032975-23-000007:mdna:124]
Impairment of Intangible Assets

[0001032975-23-000007:mdna:125]
During the three and nine months ended December 31, 2021, we recognized a pre-tax impairment charge of $7.0 million, related to the intangibles acquired as part of the Jaybird acquisition due to our decision to discontinue Jaybird-branded products.

[0001032975-23-000007:mdna:126]
[same as prior period, unchanged from 0001628280-22-027224:mdna:124]

[0001032975-23-000007:mdna:127]
The restructuring charges of $5.7 million and $16.5 million for the three and nine months ended December 31, 2022, respectively, were recorded as a result of our restructuring plan that was initiated during the second quarter of fiscal year 2023 to realign our business group and engineering structure with our go-to-market strategy to more effectively compete within the enterprise market and to better serve end-users. We expect to substantially complete this restructuring plan within the next nine months.

[0001032975-23-000007:mdna:128]
The restructuring charges of $1.8 million for each of the three and nine months ended December 31, 2021, were recorded as a result of our decision to exit Jaybird-branded products during the third quarter of fiscal year 2022. This restructuring plan has been substantially completed.

[0001032975-23-000007:mdna:129]
See Note 13 to our condensed consolidated financial statements for additional information.

[0001032975-23-000007:mdna:130]
[same as prior period, unchanged from 0001628280-22-027224:mdna:126]

[0001032975-23-000007:mdna:131]
Interest income for the three and nine months ended December 31, 2022 and 2021 was as follows (in thousands):

[0001032975-23-000007:mdna:132]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Interest income |  | $ | 4,665 |  |  | $ | 278 |  |  | $ | 9,573 |  |  | $ | 795 |  |

[0001032975-23-000007:mdna:133]
We invest in highly liquid instruments with an original maturity of three months or less at the date of purchase, which are classified as cash equivalents. During the three and nine months ended December 31, 2022 interest income increased $4.4 million and $8.8 million, respectively, compared to the same periods of the prior fiscal year, primarily driven by the increase in interest rates.

[0001032975-23-000007:mdna:134]
[same as prior period, unchanged from 0001628280-22-027224:mdna:130]

[0001032975-23-000007:mdna:135]
Other income (expense), net for the three and nine months ended December 31, 2022 and 2021 was as follows (Dollars in thousands):

[0001032975-23-000007:mdna:136]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Investment income (expense) related to the deferred compensation plan |  | $ | 758 |  |  | $ | 890 |  |  | $ | (3,390) |  |  | $ | 1,985 |  |
| Currency exchange gain (loss), net |  | 1,734 |  |  | (4,562) |  |  | (3,278) |  |  | (3,824) |  |
| Loss on investments, net |  | (1,488) |  |  | (460) |  |  | (13,065) |  |  | (1,421) |  |
| Other |  | 402 |  |  | 459 |  |  | 1,366 |  |  | 1,319 |  |
| Total |  | $ | 1,406 |  |  | $ | (3,673) |  |  | $ | (18,367) |  |  | $ | (1,941) |  |

[0001032975-23-000007:mdna:137]
Investment income related to the deferred compensation plan represents earnings, gains, and losses on marketable securities related to a deferred compensation plan offered by one of our subsidiaries. The decrease in investment income for three and nine months ended December 31, 2022, compared to the same periods of the prior fiscal year, primarily relates to the change in market performance of the underlying securities.

[0001032975-23-000007:mdna:138]
Currency exchange gain (loss), net, relates to balances denominated in currencies other than the functional currency in our subsidiaries, as well as to the sale of currencies, and gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses. The gain for the three months ended December 31, 2022 was primarily due to the strengthening of the Japanese Yen against the U.S. Dollar. The loss for the nine months ended December 31, 2022 was primarily due to the weakening of the Brazilian Real and Australian Dollar. The loss for the three months ended December 31, 2021 was primarily due to the weakening of the Brazilian Real against the U.S. Dollar. The loss for the nine months ended December 31, 2021 was primarily related to the strengthening of the Chinese Renminbi against the U.S. Dollar.

[0001032975-23-000007:mdna:139]
Loss on investments, net, includes unrealized gain (loss) from the fair value change of investment, gain (loss) on equity-method investments and impairment of investments during the periods presented, as applicable. The loss on investments, net for the nine months ended December 31, 2022 was primarily due to the impairment charge related to one of our equity method investments, partially offset by the unrealized gain related to one of our equity investments without readily determinable fair value resulting from observable price changes. See Note 6 to our condensed consolidated financial statements for additional information.

[0001032975-23-000007:mdna:140]
[same as prior period, unchanged from 0001628280-22-027224:mdna:136]

[0001032975-23-000007:mdna:141]
The provision for income taxes and effective income tax rates for the three and nine months ended December 31, 2022 and 2021 were as follows (Dollars in thousands):

[0001032975-23-000007:mdna:142]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Provision for income taxes |  | $ | 42,663 |  |  | $ | 49,345 |  |  | $ | 87,751 |  |  | $ | 107,789 |  |
| Effective income tax rate |  | 23.3 | % |  | 19.0 | % |  | 21.4 | % |  | 16.7 | % |

[0001032975-23-000007:mdna:143]
The change in the effective income tax rate for the three and nine months ended December 31, 2022 was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate. There were discrete tax benefits of $0.2 million and $1.4 million from the recognition of excess tax benefits, respectively, in the United States in the three and nine months ended December 31, 2022. In addition, there were discrete tax benefits of $1.7 million and $3.2 million from the reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the three and nine month period ended December 31, 2022. The change in the effective income tax rate for the three and nine months ended December 31, 2021 was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate. There were discrete tax benefits of $0.8 million and $15.2 million from the recognition of excess tax benefits in the United States in the three and nine months ended December 31, 2021, respectively. Furthermore, there were discrete tax benefits of $1.3 million and $2.8 million from the reversal of uncertain tax positions from the expiration of statutes of limitations, respectively, in the three and nine month period ended December, 2021.

[0001032975-23-000007:mdna:144]
As of December 31, 2022 and March 31, 2022, the total amount of unrecognized tax benefits due to uncertain tax positions was $184.0 million and $176.0 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-23-000007:mdna:145]
[same as prior period, unchanged from 0001628280-22-027224:mdna:142]

[0001032975-23-000007:mdna:146]
[same as prior period, unchanged from 0001628280-22-027224:mdna:143]

[0001032975-23-000007:mdna:147]
As of December 31, 2022, we had cash and cash equivalents of $1,036.1 million, compared with $1,328.7 million as of March 31, 2022. Our cash and cash equivalents consist of bank demand deposits and short-term time deposits, of which 59% is held in Switzerland and 19% were held in China (including Hong Kong). We do not expect to incur any material adverse tax impact except for what has already been recognized, or to be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-23-000007:mdna:148]
As of December 31, 2022, our working capital was $1,564.3 million, compared to $1,651.8 million as of March 31, 2022. The decrease was primarily driven by lower cash balances, resulting from share repurchases and payments of cash dividends, and lower inventories, partially offset by decreases in accounts payable and accrued liabilities, and an increase in accounts receivable, net.

[0001032975-23-000007:mdna:149]
We had several uncommitted, unsecured bank lines of credit aggregating $179.2 million as of December 31, 2022. There are no financial covenants under these lines of credit with which we must comply. As of December 31, 2022, we had outstanding bank guarantees of $11.6 million under these lines of credit.

[0001032975-23-000007:mdna:150]
The following tables present selected financial information and statistics as of and for the three months ended December 31, 2022 and 2021 (Dollars in thousands):

[0001032975-23-000007:mdna:151]
|  |  | As of December 31, |  |
|  |  | 2022 |  | 2021 |  |
| Accounts receivable, net |  | $ | 802,435 |  |  | $ | 845,836 |  |  |
| Accounts payable |  | $ | 491,488 |  |  | $ | 738,992 |  |  |
| Inventories |  | $ | 797,695 |  |  | $ | 834,534 |  |  |

[0001032975-23-000007:mdna:152]
|  |  | Three Months EndedDecember 31, |  |
|  |  | 2022 |  | 2021 |  |
| Days sales in accounts receivable (“DSO”) (Days)(1) |  | 57 |  |  | 47 |  |  |
| Days accounts payable outstanding (“DPO”) (Days)(2) |  | 56 |  |  | 68 |  |  |
| Inventory turnover (“ITO”) (x)(3) |  | 4.0 |  |  | 4.7 |  |  |

[0001032975-23-000007:mdna:153]
[same as prior period, unchanged from 0001628280-22-027224:mdna:150]

[0001032975-23-000007:mdna:154]
[same as prior period, unchanged from 0001628280-22-027224:mdna:151]

[0001032975-23-000007:mdna:155]
[same as prior period, unchanged from 0001628280-22-027224:mdna:152]

[0001032975-23-000007:mdna:156]
DSO for the three months ended December 31, 2022 increased by 10 days to 57 days, compared to 47 days for the same period of the prior fiscal year, primarily due to a comparatively higher percentage of sales in the last month of the current quarter.

[0001032975-23-000007:mdna:157]
DPO for the three months ended December 31, 2022 decreased by 12 days, compared to 68 days for the same period of the prior fiscal year, primarily due to lower inventory purchases than prior year resulting from softened demand and lower marketing spend.

[0001032975-23-000007:mdna:158]
ITO for the three months ended December 31, 2022 decreased by 0.7, compared to 4.7 for the same period of the prior fiscal year, primarily due to lower demand.

[0001032975-23-000007:mdna:159]
[same as prior period, unchanged from 0001628280-22-027224:mdna:156]

[0001032975-23-000007:mdna:160]
[same as prior period, unchanged from 0001628280-22-027224:mdna:157]

[0001032975-23-000007:mdna:161]
|  |  | Nine Months EndedDecember 31, |
|  |  | 2022 |  | 2021 |
| Net cash provided by operating activities |  | $ | 317,167 |  |  | $ | 198,728 |  |
| Net cash used in investing activities |  | (80,711) |  |  | (89,006) |  |
| Net cash used in financing activities |  | (505,035) |  |  | (492,799) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (24,006) |  |  | (2,839) |  |
| Net decrease in cash and cash equivalents |  | $ | (292,585) |  |  | $ | (385,916) |  |

[0001032975-23-000007:mdna:162]
For the nine months ended December 31, 2022, net cash provided by operating activities was $317.2 million  resulting from net income of $323.1 million, a favorable impact from adding back non-cash expenses totaling $165.3 million, and an unfavorable net change in operating assets and liabilities of $171.2 million. Non-cash expenses were primarily related to depreciation and amortization, share-based compensation expenses, and deferred income taxes. The increase in accounts receivable, net was primarily driven by timing of sales within the quarter. The decrease in inventories was primarily driven by lower inventory purchases. The decrease in accounts payable was primarily driven by lower inventory purchases and marketing spend. The decrease in accrued and other liabilities was primarily driven by payment of the fiscal year 2022 annual bonus.

[0001032975-23-000007:mdna:163]
For the nine months ended December 31, 2022, net cash used in investing activities was $80.7 million, primarily due to $69.1 million of purchases of property, plant, and equipment and $8.5 million payments for acquisitions, net of cash acquired.

[0001032975-23-000007:mdna:164]
For the nine months ended December 31, 2022, net cash used in financing activities was $505.0 million, primarily resulting from repurchases of our registered shares of $327.7 million, payment of cash dividends of $158.7 million, and tax withholdings related to net share settlements of restricted stock units of $28.7 million.

[0001032975-23-000007:mdna:165]
For the nine months ended December 31, 2022, there was a $24.0 million loss from currency exchange rate effect on cash and cash equivalents, primarily due to exchange rate fluctuations of Euro, Swiss Franc, Chinese Renminbi, and Australian Dollar versus the U.S. Dollar and timing of our cash transactions over the period. The loss from the effect of currency rate changes was immaterial during the nine months ended December 31, 2021.

[0001032975-23-000007:mdna:166]
[same as prior period, unchanged from 0001628280-22-027224:mdna:163]

[0001032975-23-000007:mdna:167]
Our principal sources of liquidity are our cash and cash equivalents, cash flow generated from operations and, to a much lesser extent, capital markets and borrowings. Our future working capital requirements and capital expenditures may increase to support investments in product innovations and growth opportunities or to acquire or invest in complementary businesses, products, services, and technologies. Market volatility driven by the current macroeconomic and geopolitical environment and COVID-19 related factors may increase our costs of capital and otherwise adversely affect our business, results of operations, financial condition and liquidity.

[0001032975-23-000007:mdna:168]
[same as prior period, unchanged from 0001628280-22-027224:mdna:165]

[0001032975-23-000007:mdna:169]
In May 2020, our Board of Directors approved a share repurchase program, which authorized us to invest up to $250.0 million to purchase our own shares, following the expiration date of the 2017 share repurchase program. In April 2021, our Board of Directors approved an increase of $750.0 million of the 2020 share repurchase program, to an aggregate amount of $1.0 billion. The Swiss Takeover Board approved this increase and it became effective on May 21, 2021. In July 2022, our Board of Directors approved an increase of $500 million to the 2020 share repurchase program to an aggregate amount of up to $1.5 billion. The Swiss Takeover Board approved this increase and it became effective on August 19, 2022. As of December 31, 2022, $596.3 million was available for repurchase under the 2020 repurchase program.

[0001032975-23-000007:mdna:170]
[same as prior period, unchanged from 0001628280-22-027224:mdna:168]

[0001032975-23-000007:mdna:171]
[same as prior period, unchanged from 0001628280-22-027224:mdna:169]

[0001032975-23-000007:mdna:172]
[same as prior period, unchanged from 0001628280-22-027224:mdna:170]

[0001032975-23-000007:mdna:173]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. During the nine months ended December 31, 2022, our operating lease obligations increased approximately $45.0 million, primarily related to newly commenced operating leases for office spaces in the Americas and EMEA regions. There have been no other material changes to our contractual obligations as previously disclosed in our Annual Report on Form 10-K for the year ended March 31, 2022. The remaining terms of our non-cancelable operating leases expire in various years through 2033.

[0001032975-23-000007:mdna:174]
[same as prior period, unchanged from 0001628280-22-027224:mdna:172]

[0001032975-23-000007:mdna:175]
As of December 31, 2022, we had non-cancelable purchase commitments of $421.1 million for inventory purchases made in the normal course of business from original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. We recorded a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with our valuation of excess and obsolete inventory. As of December 31, 2022, the liability for these purchase commitments was $43.2 million and is recorded in accrued and other current liabilities in the condensed consolidated balance sheet.

[0001032975-23-000007:mdna:176]
We have firm purchase commitments of $29.7 million for capital expenditures primarily related to commitments for tooling and equipment for new and existing products. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-23-000007:mdna:177]
[same as prior period, unchanged from 0001628280-22-027224:mdna:175]

[0001032975-23-000007:mdna:178]
[same as prior period, unchanged from 0001628280-22-027224:mdna:176]

[0001032975-23-000007:mdna:179]
[same as prior period, unchanged from 0001628280-22-027224:mdna:177]

[0001032975-23-000007:mdna:180]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2022, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-23-000007:mdna:181]
[same as prior period, unchanged from 0001628280-22-027224:mdna:179]

[0001032975-23-000007:mdna:182]
Legal Proceedings

[0001032975-23-000007:mdna:183]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of our business. For more information about Legal Proceedings, see Part II Item 1 Legal Proceedings of this quarterly report on Form 10-Q for the period ended December 31, 2022.
