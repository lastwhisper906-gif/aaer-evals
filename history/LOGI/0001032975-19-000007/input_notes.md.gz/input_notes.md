# LOGI notes — 0001032975-19-000007


## logi:ScheduleOfBalanceSheetComponentsAssetsTableTextBlock

[0001032975-19-000007:notes:1]
(1) Certain allowances for sales return and certain other Customer Programs were included within accounts receivable, net balance as of March 31, 2018. Upon adoption of Topic 606, such balances are presented as accrued revenue reserve from returns and accrued customer marketing, pricing and incentive programs included in accrued and other current liabilities, and as return assets included in other current assets, respectively, on the condensed consolidated balance sheet as of December 31, 2018. Refer to Note 1 to the condensed consolidated financial statements for more information.

[0001032975-19-000007:notes:2]
The following table presents the components of certain balance sheet asset amounts as of December 31 and March 31, 2018 (in thousands):

[0001032975-19-000007:notes:3]
|  |  | December 31, 2018 |  | March 31, 2018 |
| Accounts receivable, net: |  |  |  |  |  |  |
| Accounts receivable |  | $ | 712,598 |  |  | $ | 482,872 |  |
| Allowance for doubtful accounts |  | (933 | ) |  | (122 | ) |
| Allowance for sales returns (1) |  | (7,772 | ) |  | (25,515 | ) |
| Allowance for cooperative marketing arrangements (1) |  | (41,503 | ) |  | (30,389 | ) |
| Allowance for customer incentive programs (1) |  | (77,422 | ) |  | (70,592 | ) |
| Allowance for pricing programs (1) |  | (100,764 | ) |  | (141,369 | ) |
|  |  | $ | 484,204 |  |  | $ | 214,885 |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 30,882 |  |  | $ | 33,603 |  |
| Finished goods |  | 311,149 |  |  | 226,303 |  |
|  |  | $ | 342,031 |  |  | $ | 259,906 |  |
| Other current assets: |  |  |  |  |  |  |
| Value-added tax receivables |  | $ | 35,664 |  |  | $ | 29,477 |  |
| Prepaid expenses and other assets (1) |  | 37,510 |  |  | 26,885 |  |
|  |  | $ | 73,174 |  |  | $ | 56,362 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |
| Property, plant and equipment at cost |  | $ | 353,517 |  |  | $ | 346,588 |  |
| Less: accumulated depreciation and amortization |  | (271,940 | ) |  | (260,284 | ) |
|  |  | $ | 81,577 |  |  | $ | 86,304 |  |
| Other assets: |  |  |  |  |  |  |
| Deferred tax assets |  | $ | 90,398 |  |  | $ | 84,651 |  |
| Trading investments for deferred compensation plan |  | 18,683 |  |  | 17,748 |  |
| Investments in privately held companies |  | 15,526 |  |  | 12,448 |  |
| Other assets |  | 4,680 |  |  | 5,908 |  |
|  |  | $ | 129,287 |  |  | $ | 120,755 |  |


## logi:ScheduleOfBalanceSheetComponentsLiabilityTableTextBlock

[0001032975-19-000007:notes:4]
The following table presents the components of certain balance sheet liability amounts as of December 31 and March 31, 2018 (in thousands):

[0001032975-19-000007:notes:5]
|  |  | December 31, 2018 |  | March 31, 2018 |
| Accrued and other current liabilities: |  |  |  |  |  |  |
| Accrued personnel expenses |  | $ | 101,612 |  |  | $ | 82,330 |  |
| Accrued revenue reserve from returns (1) |  | 35,911 |  |  | — |  |
| Accrued customer marketing, pricing and incentive programs (1) |  | 180,319 |  |  | 71,962 |  |
| Warranty accrual |  | 21,158 |  |  | 16,279 |  |
| Employee benefit plan obligation |  | 2,531 |  |  | 1,763 |  |
| Income taxes payable |  | 5,942 |  |  | 4,354 |  |
| Other current liabilities |  | 131,159 |  |  | 105,044 |  |
|  |  | $ | 478,632 |  |  | $ | 281,732 |  |
| Other non-current liabilities: |  |  |  |  |  |  |
| Warranty accrual |  | $ | 14,317 |  |  | $ | 11,294 |  |
| Obligation for deferred compensation plan |  | 18,683 |  |  | 17,748 |  |
| Employee benefit plan obligation |  | 40,740 |  |  | 42,434 |  |
| Deferred tax liability |  | 1,980 |  |  | 1,980 |  |
| Other non-current liabilities |  | 7,324 |  |  | 8,468 |  |
|  |  | $ | 83,044 |  |  | $ | 81,924 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-19-000007:notes:6]
[same as prior period, unchanged from 0001032975-18-000048:notes:6]

[0001032975-19-000007:notes:7]
[same as prior period, unchanged from 0001032975-18-000048:notes:7]

[0001032975-19-000007:notes:8]
[same as prior period, unchanged from 0001032975-18-000048:notes:8]

[0001032975-19-000007:notes:9]
[same as prior period, unchanged from 0001032975-18-000048:notes:9]

[0001032975-19-000007:notes:10]
[same as prior period, unchanged from 0001032975-18-000048:notes:10]

[0001032975-19-000007:notes:11]
[same as prior period, unchanged from 0001032975-18-000048:notes:11]

[0001032975-19-000007:notes:12]
[same as prior period, unchanged from 0001032975-18-000048:notes:12]

[0001032975-19-000007:notes:13]
[same as prior period, unchanged from 0001032975-18-000048:notes:13]

[0001032975-19-000007:notes:14]
The condensed consolidated financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (“GAAP”) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. They should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2018, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (“SEC”) on May 21, 2018.

[0001032975-19-000007:notes:15]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and nine months ended December 31, 2018 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2019, or any future periods.

[0001032975-19-000007:notes:16]
[same as prior period, unchanged from 0001032975-18-000048:notes:16]

[0001032975-19-000007:notes:17]
Certain amounts from the comparative period in the accompanying condensed consolidated financial statements have been reclassified to conform to the condensed consolidated financial statement presentation as of and for the three and nine months ended December 31, 2018.

[0001032975-19-000007:notes:18]
[same as prior period, unchanged from 0001032975-18-000048:notes:18]

[0001032975-19-000007:notes:19]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted and Summary of Significant Accounting Policies, there have been no changes in the Company’s significant accounting policies during the nine months ended December 31, 2018 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2018.

[0001032975-19-000007:notes:20]
[same as prior period, unchanged from 0001032975-18-000048:notes:20]

[0001032975-19-000007:notes:21]
[same as prior period, unchanged from 0001032975-18-000048:notes:21]

[0001032975-19-000007:notes:22]
[same as prior period, unchanged from 0001032975-18-000048:notes:22]

[0001032975-19-000007:notes:23]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers (Topic 606)" ("ASU 2014-09" or “Topic 606”) which supersedes the revenue recognition requirements under Accounting Standards Codification ("ASC") 605 (“Topic 605”), Revenue Recognition. ASU 2014-09 outlines a new, single, comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes existing revenue recognition guidance, including industry-specific guidance. Under the new guidance, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The new standard requires reporting companies to disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. On April 1, 2018, the Company adopted the new standard and all related amendments using the modified retrospective method applied to those contracts which were not completed as of April 1, 2018. Results for reporting periods beginning after March 31, 2018 are presented under Topic 606, while prior period amounts are not adjusted and continue to be reported in accordance with historic accounting standards under Topic 605.

[0001032975-19-000007:notes:24]
As a result of the adoption of the new standard, the Company a) recorded a reduction to retained earnings as of April 1, 2018; and b) reclassified certain allowances for sales returns and certain other Customer Programs from accounts receivable, net to accrued and other current liabilities and other current assets.

[0001032975-19-000007:notes:25]
[same as prior period, unchanged from 0001032975-18-000048:notes:25]

[0001032975-19-000007:notes:26]
[same as prior period, unchanged from 0001032975-18-000048:notes:26]

[0001032975-19-000007:notes:27]
[same as prior period, unchanged from 0001032975-18-000048:notes:27]

[0001032975-19-000007:notes:28]
| • | Under Topic 605, accruals for certain Customer Programs were recognized as a reduction of revenue at the later of when the related revenue is recognized or when the program is offered to the customer. Under Topic 606, these programs qualify as variable consideration and are recorded as a reduction of the transaction price at contract inception based on the expected value method. The Company is required to estimate the accruals for these programs ahead of commitment date if customary business practice creates an implied expectation that such activities will occur in the future. |

[0001032975-19-000007:notes:29]
[same as prior period, unchanged from 0001032975-18-000048:notes:29]

[0001032975-19-000007:notes:30]
[same as prior period, unchanged from 0001032975-18-000048:notes:30]

[0001032975-19-000007:notes:31]
[same as prior period, unchanged from 0001032975-18-000048:notes:31]

[0001032975-19-000007:notes:32]
[same as prior period, unchanged from 0001032975-18-000048:notes:32]

[0001032975-19-000007:notes:33]
Certain balances of allowances for sales return and accruals for Customer Programs which were accrued based on offers made to individual customers, met the right of offset criteria in accordance with ASC 210-20, "Balance Sheet (Topic 210)", and are still included within accounts receivable, net.

[0001032975-19-000007:notes:34]
[same as prior period, unchanged from 0001032975-18-000048:notes:34]

[0001032975-19-000007:notes:35]
The following tables summarize the impacts of adopting Topic 606 on the Company’s condensed consolidated statements of operations for the three and nine months ended December 31, 2018 and condensed consolidated balance sheet as of December 31, 2018 (in thousands):

[0001032975-19-000007:notes:36]
|  | Three Months Ended December 31, 2018 |  | Nine Months Ended December 31, 2018 |
|  | As Reported Under Topic 606 | If Reported Under Topic 605 | Effect of Change |  | As Reported Under Topic 606 | If Reported Under Topic 605 | Effect of Change |
| Net sales | $ | 864,388 |  | $ | 853,563 |  | $ | 10,825 |  |  | $ | 2,164,014 |  | $ | 2,158,267 |  | $ | 5,747 |  |

[0001032975-19-000007:notes:37]
|  |  | As of December 31, 2018 |
|  |  | As Reported Under Topic 606 |  | Balance Under Topic 605 |  | Effect of Change |
| Accounts receivable, net |  | 484,204 |  |  | 345,055 |  |  | 139,149 |  |
| Other current assets |  | 73,174 |  |  | 65,758 |  |  | 7,416 |  |
| Accrued and other current liabilities |  | 478,632 |  |  | 326,932 |  |  | 151,700 |  |
| Retained earnings |  | 1,322,915 |  |  | 1,328,050 |  |  | (5,135 | ) |

[0001032975-19-000007:notes:38]
In January 2016, the FASB issued ASU 2016-01, "Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10)" ("ASU 2016-01"). ASU 2016-01 requires entities to measure equity instruments at fair value and recognize any changes in fair value within the statement of operations. The Company adopted ASU 2016-01 effective April 1, 2018 on a prospective basis for its privately held strategic equity securities without readily determinable fair values. The Company elected the measurement alternative to record these investments at cost and to adjust for impairments and observable price changes with a same or similar security from the same issuer within the statement of operations. The adoption of ASU 2016-01 did not have a material impact on the Company's condensed consolidated financial statements.

[0001032975-19-000007:notes:39]
In October 2016, the FASB issued ASU 2016-16, "Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory" ("ASU 2016-16"), which eliminates the deferral of income tax effects of intra-entity asset transfers until the transferred asset is sold to an unrelated party or recovered through use. However, this standard does not apply to intra-entity transfer of inventory. The Company adopted this standard effective April 1, 2018 on a modified retrospective basis, and the adoption of ASU 2016-16 did not have a material impact on its condensed consolidated financial statements.

[0001032975-19-000007:notes:40]
In December 2016, the FASB issued ASU 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash" ("ASU 2016-18"), which requires that a statement of cash flows explains the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. The Company adopted this standard effective April 1, 2018, utilizing the retrospective transition method to each period presented and the adoption of ASU 2016-18 did not have an impact on its condensed consolidated financial statements as the Company did not have any restricted cash for either period presented.

[0001032975-19-000007:notes:41]
In January 2017, the FASB issued ASU 2017-01, "Business Combination (Topic 805): Clarifying the Definition of a Business" ("ASU 2017-01"), which changes the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. The Company adopted this standard effective April 1, 2018, and the adoption of ASU 2017-01 did not have a material impact on its condensed consolidated financial statements.

[0001032975-19-000007:notes:42]
In March 2017, the FASB issued ASU 2017-07, "Compensation-Retirement Benefit (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost" ("ASU 2017-07"), which requires that the Company disaggregate the service cost component from the other components of net benefit cost, and also provides guidance on how to present the service cost component and the other components of net benefit cost in the income statement and allow only the service cost component of net benefit cost to be eligible for capitalization. The Company adopted this standard effective April 1, 2018 using a retrospective adoption method. Other than the revised statement of operations presentation for the periods in fiscal year 2019, the adoption of ASU 2017-07 did not have an impact on the Company’s condensed consolidated financial statements. The impact to the comparative period was immaterial and therefore the prior period statements of operations was not revised.

[0001032975-19-000007:notes:43]
In August 2017, the FASB issued ASU 2017-12, "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" ("ASU 2017-12"), which improves the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements and simplifies the application of the hedge accounting guidance. The Company adopted this standard prospectively on April 1, 2018, and the adoption of ASU 2017-12 did not have a material impact on its condensed consolidated financial statements. In accordance with ASU 2017-12, the Company has started presenting the earnings impact from forward points in the cost of goods sold line item, which is used to present the earnings impact of the hedged item.

[0001032975-19-000007:notes:44]
[same as prior period, unchanged from 0001032975-18-000048:notes:44]

[0001032975-19-000007:notes:45]
In February 2016, the FASB issued ASU 2016-02, "Leases (Topic 842)" ("ASU 2016-02" or "Topic 842"), which generally requires companies to recognize right-of-use assets and lease liabilities arising from operating and financing leases with terms longer than 12 months in the consolidated balance sheets. The Company will adopt the new guidance in the first quarter of fiscal year 2020 on a modified retrospective basis, thereby recognizing the cumulative effect of initially applying Topic 842 as an adjustment to opening retained earnings on the adoption date, without revising the balances in comparative periods. The Company plans on electing the package of transitional practical expedients upon adoption which, among other provisions, allows the Company to carry forward historical lease classification, for any expired or existing leases on the adoption date. Although the Company expects to record significant amounts of right-of-use assets and liabilities on its consolidated balance sheets, the Company is still evaluating the full impact that ASU 2016-02 will have on its consolidated financial statements.

[0001032975-19-000007:notes:46]
In August 2018, the FASB issued ASU 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirements for Fair Value Measurements" ("ASU 2018-13"), which aims to improve the overall usefulness of disclosures to financial statement users and reduce unnecessary costs to companies when preparing fair value measurement disclosures. ASU 2018-13 is effective for annual and interim periods in fiscal years beginning after December 15, 2019. Early adoption is permitted. Retrospective adoption is required, except for certain disclosures which will be required to be applied prospectively for only the most recent interim or annual period presented in the initial fiscal year of adoption. The Company does not expect the adoption of ASU 2018-13 will have a material impact on its consolidated financial statements and will adopt the standard effective April 1, 2020.

[0001032975-19-000007:notes:47]
In August 2018, the FASB issued ASU 2018-14, "Compensation - Retirement Benefits - Defined Benefits Plans - General (Subtopic 715-20): Disclosure Framework - Changes to the Disclosure Requirements for Defined Benefit Plans" ("ASU 2018-14"), which aims to improve the overall usefulness of disclosures to financial statement users and reduce unnecessary costs to companies when preparing defined benefit plan disclosures. ASU 2018-14 is effective for annual periods in fiscal years ending after December 15, 2020. Retrospective adoption is required and early adoption is permitted. The Company does not expect the adoption of ASU 2018-14 will have a material impact on its consolidated financial statements and will adopt the standard effective April 1, 2020.

[0001032975-19-000007:notes:48]
In August 2018, the FASB issued ASU 2018-15, "Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Customer's Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract" ("ASU 2018-15"), which clarifies that implementation costs incurred by customers in cloud computing arrangements are deferred if they would be capitalized by customers in software licensing arrangements under the internal-use software guidance. ASU 2018-15 is effective for annual and interim periods in fiscal years beginning after December 15, 2019, with early adoption permitted. Entities have the option to apply the guidance prospectively to all implementation costs incurred after the date of adoption or retrospectively. The Company does not expect the adoption of ASU 2018-15 will have a material impact on its consolidated financial statements and will adopt the standard effective April 1, 2020.

[0001032975-19-000007:notes:49]
[same as prior period, unchanged from 0001032975-18-000048:notes:49]

[0001032975-19-000007:notes:50]
[same as prior period, unchanged from 0001032975-18-000048:notes:50]

[0001032975-19-000007:notes:51]
[same as prior period, unchanged from 0001032975-18-000048:notes:51]

[0001032975-19-000007:notes:52]
Substantially all revenue recognized by the Company relates to the contracts with customers to sell products that allow people to connect through music, gaming, video, computing, and other digital platforms. These products are hardware devices, which may include embedded software that function together, and are considered as one performance obligation. Hardware devices are generally plug and play, requiring no configuration and little or no installation. Revenue is recognized at a point in time when control of the products is transferred to the customer which generally occurs upon shipment. The Company’s contracts with its customers generally have a one year term. The Company applies the practical expedient of not disclosing the value of unsatisfied performance obligations for contracts with an original expected length of one year or less.

[0001032975-19-000007:notes:53]
The Company also provides post-contract customer support (“PCS”) for certain products and related software, which includes unspecified software updates and upgrades, bug fixes and maintenance. The transaction price is allocated to two performance obligations in such contracts, based on a relative standalone selling price. The transaction price allocated to PCS is recognized as revenue on a straight-line basis, which reflects the pattern of delivery of PCS, over the estimated term of the support that is between one to two years. Deferred revenue associated with remaining PCS performance obligation as of December 31, 2018 and March 31, 2018 was not material .

[0001032975-19-000007:notes:54]
The Company normally requires payment from customers within thirty to sixty days from the invoice date. However, terms may vary by customer type, by country and by selling season. Extended payment terms are sometimes offered to a limited number of customers during the second and third fiscal quarters. The Company does not modify payment terms on existing receivables. The Company's contracts with customers do not include significant financing components as the period between the satisfaction of performance obligations and timing of payment are generally within one year.

[0001032975-19-000007:notes:55]
The transaction price received by the Company from sales to its distributors, retail companies ("retailers"), and authorized resellers is calculated as selling price net of variable consideration which may include product returns, price protection, and the Company’s payments for Customer Programs related to current period product revenue. The estimated impact of these programs is recorded as a reduction of sales or as an operating expense if the Company receives a distinct good or service from the customer and can reasonably estimate the fair value of that good or service received. Certain Customer Programs require management to estimate the percentage of those programs which will not be claimed or will not be earned by customers based on historical experience and on the specific terms and conditions of particular programs. The percentage of these customer programs that will not be claimed or earned is commonly referred to as "breakage". The Company accounts for breakage as part of variable consideration, subject to constraint, and records the estimated impact in the same period when revenue is recognized at the expected value. Significant management judgments and estimates are used to determine the impact of the program and breakage in any accounting period.

[0001032975-19-000007:notes:56]
The Company enters into cooperative marketing arrangements with many of its customers and with certain indirect partners, allowing customers to receive a credit equal to a set percentage of their purchases of the Company's products, or a fixed dollar amount for various marketing and incentive programs. The objective of these arrangements is to encourage advertising and promotional events to increase sales of the Company's products.

[0001032975-19-000007:notes:57]
[same as prior period, unchanged from 0001032975-18-000048:notes:57]

[0001032975-19-000007:notes:58]
Cooperative marketing arrangements and customer incentive programs are considered variable consideration, which the Company estimates and records as a reduction to revenue at the time of sale based on negotiated terms, historical experiences, forecasted incentives, anticipated volume of future purchases, and inventory levels in the channel.

[0001032975-19-000007:notes:59]
[same as prior period, unchanged from 0001032975-18-000048:notes:59]

[0001032975-19-000007:notes:60]
Product return rights vary by customer. Estimates of expected future product returns qualify as variable consideration and are recorded as a reduction of the transaction price of the contract at the time of sale based on an analyses of historical return trends by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information. The Company assesses the estimated returned asset value for impairment, and adjusts the value of the asset for any impairment. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time but are sufficiently predictable to allow the Company to estimate expected future product returns.

[0001032975-19-000007:notes:61]
[same as prior period, unchanged from 0001032975-18-000048:notes:61]

[0001032975-19-000007:notes:62]
The Company regularly evaluates the adequacy of its estimates for Customer Programs and product returns. Future market conditions and product transitions may require the Company to take action to change such programs and related estimates. When the variables used to estimate these costs change, or if actual costs differ significantly from the estimates, the Company would be required to increase or reduce revenue or operating expenses to reflect the impact.

[0001032975-19-000007:notes:63]
Sales taxes and value-added taxes (“VAT”) collected from customers, if applicable, which are remitted to governmental authorities are not included in revenue, and are reflected as a liability on the condensed consolidated balance sheets.

[0001032975-19-000007:notes:64]
[same as prior period, unchanged from 0001032975-18-000048:notes:64]

[0001032975-19-000007:notes:65]
[same as prior period, unchanged from 0001032975-18-000048:notes:65]

[0001032975-19-000007:notes:66]
[same as prior period, unchanged from 0001032975-18-000048:notes:66]

[0001032975-19-000007:notes:67]
[same as prior period, unchanged from 0001032975-18-000048:notes:67]

[0001032975-19-000007:notes:68]
The Company records contract liabilities when cash payments are received or due in advance of performance, primarily for implied support and subscriptions. Contract liabilities are included in accrued and other current liabilities on the condensed consolidated balance sheets.

[0001032975-19-000007:notes:69]
As of December 31, 2018 and for the period then ended, and as of April 1, 2018, the Company did not have any material contract liabilities balances or changes.

[0001032975-19-000007:notes:70]
[same as prior period, unchanged from 0001032975-18-000048:notes:70]

[0001032975-19-000007:notes:71]
The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that otherwise would have been recognized is one year or less. These costs are included in marketing and selling expenses in the condensed consolidated statements of operations. As of December 31, 2018 and March 31, 2018, the Company did not have any material deferred contract costs.

[0001032975-19-000007:notes:72]
[same as prior period, unchanged from 0001032975-18-000048:notes:72]

[0001032975-19-000007:notes:73]
Allowances for doubtful accounts are maintained for estimated losses resulting from the Company's customers' inability to make payments. The allowances are based on the Company's regular assessment of the financial condition of specific customers, as well as its historical experience with bad debts and customer deductions, receivables aging, current economic trends, geographic or country-specific risks and the financial condition of its distribution channels.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001032975-19-000007:notes:74]
[same as prior period, unchanged from 0001032975-18-000048:notes:74]

[0001032975-19-000007:notes:75]
On August 21, 2018 (the "Acquisition Date"), the Company acquired all equity interests in Blue Microphones Holding Corporation ("Blue Microphones") for a total consideration of $134.8 million in cash (the "Blue Microphones Acquisition"), which included a working capital adjustment and repayment of debt on behalf of Blue Microphones. The Company finalized the working capital adjustment in the third quarter of fiscal year 2019, which reduced the purchase price for Blue Microphones by a nominal amount.

[0001032975-19-000007:notes:76]
Blue Microphones is a leading audio manufacturer that designs and produces microphones, headphones, recording tools, and accessories for audio professionals, musicians and consumers. The Blue Microphones Acquisition is consistent with Logitech's merger and acquisition strategy and will supplement the Company's portfolio in the microphones market.

[0001032975-19-000007:notes:77]
Blue Microphones met the definition of a business, and therefore the acquisition is accounted for using the acquisition method. During the three months ended December 31, 2018, the Company identified and recorded an insignificant measurement period adjustment to the preliminary value assigned to goodwill.

[0001032975-19-000007:notes:78]
The Company is still in the process of finalizing the valuation of identifiable intangible assets acquired and may revise its preliminary estimates of fair values during the remainder of the measurement period (which will not exceed 12 months from the Acquisition Date).

[0001032975-19-000007:notes:79]
The following table summarizes the estimated fair values of the assets acquired and liabilities assumed at the Acquisition Date, and the value of goodwill resulting from the measurement period adjustments in the three months ended December 31, 2018 (in thousands):

[0001032975-19-000007:notes:80]
|  |  | Estimated Fair Value |
| Cash and cash equivalents |  | $ | 1,110 |  |
| Accounts receivable |  | 10,979 |  |
| Inventories |  | 19,546 |  |
| Other current assets |  | 1,034 |  |
| Property, plant and equipment |  | 452 |  |
| Intangible assets |  | 53,267 |  |
| Total identifiable assets acquired |  | $ | 86,388 |  |
| Accounts payable |  | (10,322 | ) |
| Accrued liabilities |  | (13,186 | ) |
| Other long-term liabilities |  | (45 | ) |
| Net identifiable assets acquired |  | $ | 62,835 |  |
| Goodwill |  | 71,940 |  |
| Net assets acquired |  | $ | 134,775 |  |

[0001032975-19-000007:notes:81]
[same as prior period, unchanged from 0001032975-18-000048:notes:79]

[0001032975-19-000007:notes:82]
The fair value of the inventory acquired is estimated at its net realizable value, which uses the estimated selling prices, less the cost of disposal and a reasonable profit allowance for the selling efforts. The difference between the fair value of the inventories and the amount recorded by Blue Microphones immediately before the acquisition date is $1.8 million, which has been subsequently recognized in "amortization of intangibles assets and purchase accounting effect on inventory" in the condensed consolidated statements of operations upon the sale of the acquired inventory.

[0001032975-19-000007:notes:83]
[same as prior period, unchanged from 0001032975-18-000048:notes:81]

[0001032975-19-000007:notes:84]
[same as prior period, unchanged from 0001032975-18-000048:notes:82]

[0001032975-19-000007:notes:85]
Intangible assets acquired as a result of the Blue Microphones Acquisition are being amortized over their estimated useful lives using the straight-line method of amortization, which materially approximates the distribution of the economic value of the identified intangible assets. Amortization of acquired developed technology of $1.0 million and $1.2 million, respectively, during the three and nine months ended December 31, 2018 is included in "amortization of intangible assets and purchase accounting effect of inventory" in the condensed consolidated statements of operations. Amortization of the acquired customer relationships and trade name of $1.0 million and $1.4 million during the three and nine months ended December 31, 2018 is included in "amortization of intangible assets and acquisition-related costs" in the condensed consolidated statements of operations.

[0001032975-19-000007:notes:86]
[same as prior period, unchanged from 0001032975-18-000048:notes:84]

[0001032975-19-000007:notes:87]
[same as prior period, unchanged from 0001032975-18-000048:notes:85]

[0001032975-19-000007:notes:88]
[same as prior period, unchanged from 0001032975-18-000048:notes:86]

[0001032975-19-000007:notes:89]
[same as prior period, unchanged from 0001032975-18-000048:notes:87]

[0001032975-19-000007:notes:90]
[same as prior period, unchanged from 0001032975-18-000048:notes:88]

[0001032975-19-000007:notes:91]
[same as prior period, unchanged from 0001032975-18-000048:notes:89]

[0001032975-19-000007:notes:92]
The Company incurred acquisition-related costs for the Blue Microphones Acquisition of approximately $1.5 million during the nine months ended December 31, 2018. The acquisition-related costs are included in "amortization of intangible assets and acquisition-related costs" in the condensed consolidated statements of operations.

[0001032975-19-000007:notes:93]
The Company included Blue Microphones' estimated fair value of assets acquired and liabilities assumed in its condensed consolidated balance sheet beginning on the Acquisition Date. The results of operations for Blue Microphones subsequent to the Acquisition Date have been included in, but are not material to, the Company's condensed consolidated statements of operations for the three and nine months ended December 31, 2018. Pro forma results of operations for the Blue Microphones Acquisition have not been presented because they are not material to the condensed consolidated statements of operations for the three and nine months ended December 31, 2018. Blue Microphones, the acquisition of which was closed on August 21, 2018, contributed $24.8 million and $32.5 million to net sales, representing approximately 3% and 2% of the net sales of the Company for the three and nine months ended December 31, 2018, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-19-000007:notes:94]
Commitments and Contingencies

[0001032975-19-000007:notes:95]
Product Warranties

[0001032975-19-000007:notes:96]
All of the Company's products are covered by warranty to be free from defects in material and workmanship for periods ranging from one year to five years. The Company’s warranty doesn’t provide a service beyond assuring that the product complies with agreed-upon specifications and is not sold separately. The warranty the Company provides qualifies as an assurance warranty and is not treated as a separate performance obligation. The Company estimates cost of product warranties at the time the related revenue is recognized based on historical warranty claim rates, historical costs, and knowledge of specific product failures that are outside of the Company's typical experience. The Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. Each quarter, the Company reevaluates estimates to assess the adequacy of recorded warranty liabilities. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly. If actual product failure rates or repair costs differ from estimates, revisions to the estimated warranty liabilities would be required and could materially affect the Company's results of operations.

[0001032975-19-000007:notes:97]
Changes in the Company’s warranty liability for the three and nine months ended December 31, 2018 and 2017 were as follows (in thousands):

[0001032975-19-000007:notes:98]
|  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Beginning of the period | $ | 31,754 |  |  | $ | 24,349 |  |  | $ | 27,573 |  |  | $ | 21,911 |  |
| Assumed from business acquisition | — |  |  | — |  |  | 351 |  |  | 1,230 |  |
| Provision | 11,305 |  |  | 7,820 |  |  | 30,625 |  |  | 17,535 |  |
| Settlements | (7,523 | ) |  | (6,050 | ) |  | (22,405 | ) |  | (15,229 | ) |
| Currency translation | (61 | ) |  | 145 |  |  | (669 | ) |  | 817 |  |
| End of the period | $ | 35,475 |  |  | $ | 26,264 |  |  | $ | 35,475 |  |  | $ | 26,264 |  |

[0001032975-19-000007:notes:99]
Guarantees

[0001032975-19-000007:notes:100]
Logitech Europe S.A., one of the Company's wholly-owned subsidiaries, has guaranteed payments of certain third-party contract manufacturers’ purchase obligations. As of December 31, 2018, the maximum amount of this guarantee was $3.8 million.

[0001032975-19-000007:notes:101]
Indemnifications

[0001032975-19-000007:notes:102]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2018, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-19-000007:notes:103]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-19-000007:notes:104]
Legal Proceedings

[0001032975-19-000007:notes:105]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-19-000007:notes:106]
[same as prior period, unchanged from 0001032975-18-000048:notes:105]

[0001032975-19-000007:notes:107]
[same as prior period, unchanged from 0001032975-18-000048:notes:106]

[0001032975-19-000007:notes:108]
As of December 31, 2018, the Company offers the 2006 ESPP (2006 Employee Share Purchase Plan (Non-U.S.)), the 1996 ESPP (1996 Employee Share Purchase Plan (U.S.)), the 2006 Plan (2006 Stock Incentive Plan) and the 2012 Plan (2012 Stock Inducement Equity Plan), each as amended.

[0001032975-19-000007:notes:109]
The following table summarizes the share-based compensation expense and total income tax provision (benefit) recognized for share-based awards for the three and nine months ended December 31, 2018 and 2017 (in thousands):

[0001032975-19-000007:notes:110]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Cost of goods sold |  | $ | 953 |  |  | $ | 960 |  |  | $ | 2,874 |  |  | $ | 2,762 |  |
| Marketing and selling |  | 4,600 |  |  | 4,624 |  |  | 15,250 |  |  | 13,348 |  |
| Research and development |  | 1,811 |  |  | 1,621 |  |  | 5,295 |  |  | 4,797 |  |
| General and administrative |  | 4,491 |  |  | 4,351 |  |  | 13,744 |  |  | 12,332 |  |
| Total share-based compensation expense |  | 11,855 |  |  | 11,556 |  |  | 37,163 |  |  | 33,239 |  |
| Income tax provision (benefit) |  | (2,397 | ) |  | 3,038 |  |  | (14,576 | ) |  | (11,921 | ) |
| Total share-based compensation expense, net of income tax provision (benefit) |  | $ | 9,458 |  |  | $ | 14,594 |  |  | $ | 22,587 |  |  | $ | 21,318 |  |

[0001032975-19-000007:notes:111]
The income tax benefit in the respective period primarily consists of tax benefit related to the share-based compensation expense for the period and direct tax benefit realized, including net excess tax benefits recognized from share-based awards vested or exercised during the period. The income tax benefit for the three and nine months ended December 31, 2017 was reduced by the income tax provision resulting from the remeasurement of applicable federal deferred tax assets due to the enactment of H.R.1, also known as the "Tax Cuts and Jobs Act" ("the Tax Act") in the United States on December 22, 2017. See "Note 5 - Income Taxes" for more information.

[0001032975-19-000007:notes:112]
As of December 31, 2018 and 2017, the balance of capitalized share-based compensation included in inventory was $0.8 million.

[0001032975-19-000007:notes:113]
[same as prior period, unchanged from 0001032975-18-000048:notes:112]

[0001032975-19-000007:notes:114]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The costs recorded of $2.2 million and $2.3 million for the three months ended December 31, 2018 and 2017, respectively, and $6.7 million and $6.9 million for the nine months ended December 31, 2018 and 2017, respectively, were primarily related to service costs.


## us-gaap:DebtDisclosureTextBlock

[0001032975-19-000007:notes:115]
Financing Arrangements

[0001032975-19-000007:notes:116]
The Company had several uncommitted, unsecured bank lines of credit aggregating $79.4 million as of December 31, 2018. There are no financial covenants under these lines of credit with which the Company must comply. As of December 31, 2018, the Company had outstanding bank guarantees of $30.1 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of December 31, 2018 or March 31, 2018.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-19-000007:notes:117]
[same as prior period, unchanged from 0001032975-18-000048:notes:116]

[0001032975-19-000007:notes:118]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis on the condensed consolidated balance sheets as of December 31, 2018 and March 31, 2018.

[0001032975-19-000007:notes:119]
The fair value of the Company’s derivative instruments were not material as of December 31, 2018 or March 31, 2018. The amount of gain (loss) recognized on derivatives not designated as hedging instruments was not material in all periods presented herein. The following table presents the amounts of gains (losses) on the Company’s derivative instruments designated as hedging instruments and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income for the three and nine months ended December 31, 2018 and 2017 (in thousands):

[0001032975-19-000007:notes:120]
|  |  | Three Months EndedDecember 31, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Cash flow hedges |  | $ | 575 |  |  | $ | (677 | ) |  | $ | (615 | ) |  | $ | 2,248 |  |

[0001032975-19-000007:notes:121]
|  |  | Nine Months EndedDecember 31, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Cash flow hedges |  | $ | 1,060 |  |  | $ | (6,026 | ) |  | $ | 2,454 |  |  | $ | 5,377 |  |

[0001032975-19-000007:notes:122]
Upon adoption of ASU 2017-12, the Company has started presenting the earnings impact from forward points in the same line item that is used to present the earnings impact of the hedged item, i.e. cost of goods sold, for hedging forecasted inventory purchases and such amount is not material for all periods presented.

[0001032975-19-000007:notes:123]
[same as prior period, unchanged from 0001032975-18-000048:notes:122]

[0001032975-19-000007:notes:124]
The Company enters into cash flow hedge contracts to protect against exchange rate exposure of forecasted inventory purchases. These hedging contracts mature within four months. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Cash flows from such hedges are classified as operating activities in the condensed consolidated statements of cash flows. Hedging relationships are discontinued when hedging contract is no longer eligible for hedge accounting, or is sold, terminated or exercised, or when Company removes hedge designation for the contract. Gains and losses in the fair value of the effective portion of the discontinued hedges continue to be reported in accumulated other comprehensive loss until the hedged inventory purchases are sold, unless it is probable that the forecasted inventory purchases will not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. In all periods presented herein, there have been no forecasted inventory purchases that were probable to not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. The notional amounts of foreign currency exchange forward contracts outstanding related to forecasted inventory purchases were $64.3 million as of December 31, 2018. As of March 31, 2018, there were no currency forward contracts outstanding related to forecasted inventory purchases. The Company had $0.3 million of net gains related to its cash flow hedges included in accumulated other comprehensive loss as of December 31, 2018 which will be reclassified into earnings within the next 12 months.

[0001032975-19-000007:notes:125]
[same as prior period, unchanged from 0001032975-18-000048:notes:124]

[0001032975-19-000007:notes:126]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are recognized in other expense, net in the condensed consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of December 31, 2018 and March 31, 2018 were $68.3 million and $47.2 million, respectively. Open forward and swap contracts outstanding as of December 31, 2018 and March 31, 2018 consisted of contracts in Mexican Pesos, Japanese Yen, Canadian Dollars, Taiwan New Dollars and Australian Dollars to be settled at future dates at pre-determined exchange rates.

[0001032975-19-000007:notes:127]
[same as prior period, unchanged from 0001032975-18-000048:notes:126]


## us-gaap:EarningsPerShareTextBlock

[0001032975-19-000007:notes:128]
[same as prior period, unchanged from 0001032975-18-000048:notes:127]

[0001032975-19-000007:notes:129]
[same as prior period, unchanged from 0001032975-18-000048:notes:128]

[0001032975-19-000007:notes:130]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net income |  | $ | 112,810 |  |  | $ | 80,773 |  |  | $ | 215,452 |  |  | $ | 174,138 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 165,707 |  |  | 164,248 |  |  | 165,552 |  |  | 163,924 |  |
| Effect of potentially dilutive equivalent shares |  | 3,200 |  |  | 4,831 |  |  | 3,414 |  |  | 4,908 |  |
| Weighted average shares outstanding - diluted |  | 168,907 |  |  | 169,079 |  |  | 168,966 |  |  | 168,832 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.68 |  |  | $ | 0.49 |  |  | $ | 1.30 |  |  | $ | 1.06 |  |
| Diluted |  | $ | 0.67 |  |  | $ | 0.48 |  |  | $ | 1.28 |  |  | $ | 1.03 |  |

[0001032975-19-000007:notes:131]
Share equivalents attributable to outstanding stock options, restricted stock units ("RSUs") and ESPP totaling 1.3 million and 0.5 million for the three months ended December 31, 2018 and 2017, respectively, and 1.2 million and 1.1 million for the nine months ended December 31, 2018 and 2017, respectively, were excluded from the calculation of diluted net income per share because the combined exercise price and average unamortized grant date fair value upon exercise of these options and ESPP or vesting of RSUs were greater than the average market price of the Company's shares during the periods presented herein, and therefore their inclusion would have been anti-dilutive. Performance-based awards were not included because all necessary conditions have not been satisfied by the end of the respective period, and those shares were not issuable if the end of the reporting period were the end of the contingency period.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-19-000007:notes:132]
[same as prior period, unchanged from 0001032975-18-000048:notes:131]

[0001032975-19-000007:notes:133]
[same as prior period, unchanged from 0001032975-18-000048:notes:132]

[0001032975-19-000007:notes:134]
[same as prior period, unchanged from 0001032975-18-000048:notes:133]

[0001032975-19-000007:notes:135]
[same as prior period, unchanged from 0001032975-18-000048:notes:134]

[0001032975-19-000007:notes:136]
[same as prior period, unchanged from 0001032975-18-000048:notes:135]

[0001032975-19-000007:notes:137]
[same as prior period, unchanged from 0001032975-18-000048:notes:136]

[0001032975-19-000007:notes:138]
|  |  | December 31, 2018 |  | March 31, 2018 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 425,543 |  |  | $ | — |  |  | $ | — |  |  | $ | 492,535 |  |  | $ | — |  |  | $ | — |  |
| Trading investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 4,315 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,881 |  |  | $ | — |  |  | $ | — |  |
| Mutual funds |  | 14,368 |  |  | — |  |  | — |  |  | 14,867 |  |  | — |  |  | — |  |
| Total of trading investments for deferred compensation plan |  | $ | 18,683 |  |  | $ | — |  |  | $ | — |  |  | $ | 17,748 |  |  | $ | — |  |  | $ | — |  |
| Currency exchange derivative assetsincluded in other current assets |  | $ | — |  |  | $ | 202 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Currency exchange derivative liabilitiesincluded in accrued and other current liabilities |  | $ | — |  |  | $ | 627 |  |  | $ | — |  |  | $ | — |  |  | $ | 34 |  |  | $ | — |  |

[0001032975-19-000007:notes:139]
[same as prior period, unchanged from 0001032975-18-000048:notes:138]

[0001032975-19-000007:notes:140]
The marketable securities for the Company's deferred compensation plan were recorded at a fair value of $18.7 million and $17.7 million, as of December 31, 2018 and March 31, 2018, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized gains (losses) related to trading securities for the three and nine months ended December 31, 2018 and 2017 were not material and are included in other expense, net in the Company's condensed consolidated statements of operations.

[0001032975-19-000007:notes:141]
[same as prior period, unchanged from 0001032975-18-000048:notes:140]

[0001032975-19-000007:notes:142]
The Company has certain non-marketable investments included in other assets that are accounted for under the equity method of accounting, with a carrying value of $6.0 million and $5.1 million as of December 31, 2018 and March 31, 2018, respectively.

[0001032975-19-000007:notes:143]
In addition, the Company has certain investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with a same or similar security from the same issuer. The amount of these investments included in other assets as of December 31, 2018 and March 31, 2018 was $9.5 million and $7.3 million, respectively. There was no impairment of these assets during the three and nine months ended December 31, 2018 or 2017.

[0001032975-19-000007:notes:144]
[same as prior period, unchanged from 0001032975-18-000048:notes:143]

[0001032975-19-000007:notes:145]
The Company’s non-financial assets, such as intangible assets and acquisition-related property, plant and equipment, are recorded at fair value only upon initial recognition or if an impairment is recognized. There was no impairment of these assets during the three and nine months ended December 31, 2018 or 2017.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-19-000007:notes:146]
[same as prior period, unchanged from 0001032975-18-000048:notes:145]

[0001032975-19-000007:notes:147]
The Company conducts its impairment analysis of goodwill annually at December 31 and as necessary, if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting unit may be less than its carrying amount. The Company conducted its annual impairment analysis of goodwill as of December 31, 2018 by performing a qualitative assessment and concluded that it was more likely than not that the fair value of its reporting unit exceeds its carrying amount. In assessing the qualitative factors, the Company considered the impact of: change in industry and competitive environment, growth in the Company's market capitalization and budgeted-to-actual revenue performance for the last twelve months.

[0001032975-19-000007:notes:148]
The following table summarizes the activities in the Company’s goodwill balance during the nine months ended December 31, 2018 (in thousands):

[0001032975-19-000007:notes:149]
| As of March 31, 2018 |  | $ | 275,451 |  |
| Acquisition (Note 2) |  | 71,940 |  |
| Currency translation |  | (22 | ) |
| As of December 31, 2018 |  | $ | 347,369 |  |

[0001032975-19-000007:notes:150]
[same as prior period, unchanged from 0001032975-18-000048:notes:149]

[0001032975-19-000007:notes:151]
|  |  | December 31, 2018 |  | March 31, 2018 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademark and trade names |  | $ | 36,370 |  |  | $ | (12,430 | ) |  | $ | 23,940 |  |  | $ | 23,870 |  |  | $ | (9,482 | ) |  | $ | 14,388 |  |
| Developed technology |  | 95,207 |  |  | (59,070 | ) |  | 36,137 |  |  | 77,175 |  |  | (50,755 | ) |  | 26,420 |  |
| Customer contracts/relationships |  | 82,310 |  |  | (18,744 | ) |  | 63,566 |  |  | 59,510 |  |  | (12,771 | ) |  | 46,739 |  |
| Total |  | $ | 213,887 |  |  | $ | (90,244 | ) |  | $ | 123,643 |  |  | $ | 160,555 |  |  | $ | (73,008 | ) |  | $ | 87,547 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-19-000007:notes:152]
[same as prior period, unchanged from 0001032975-18-000048:notes:151]

[0001032975-19-000007:notes:153]
[same as prior period, unchanged from 0001032975-18-000048:notes:152]

[0001032975-19-000007:notes:154]
The income tax provision for the three months ended December 31, 2018 was $9.3 million based on an effective income tax rate of 7.6% of pre-tax income, compared to an income tax provision of $20.0 million based on an effective income tax rate of 19.9% of pre-tax income for the three months ended December 31, 2017. The income tax provision for the nine months ended December 31, 2018 was $10.3 million based on an effective income tax rate of 4.6% of pre-tax income, compared to an income tax provision of $18.7 million based on an effective income tax rate of 9.7% of pre-tax income for the nine months ended December 31, 2017.

[0001032975-19-000007:notes:155]
The changes in the effective income tax rate for the three and nine months ended December 31, 2018, compared to the same periods ended December 31, 2017, were primarily due to the mix of income and losses in the various tax jurisdictions which the Company operates and the provisional income tax impact from the Tax Act as of December 31, 2017. The Company recorded a provisional income tax charge of $19.9 million from the estimated remeasurement of federal deferred tax assets and liabilities as of December 31, 2017 to reflect the effects of the enacted changes in tax rate and an income tax benefit of $4.1 million from assessment of valuation allowance against tax credits. Furthermore, in the three and nine months ended December 31, 2018, there were discrete tax benefits of $0.9 million and $2.3 million, respectively, from the reversal of uncertain tax positions from the expiration of statutes of limitations. In the same periods ended December 31, 2017, the tax benefits from reversal of uncertain tax positions from the expiration of statutes of limitations were $6.0 million and $7.9 million, respectively.

[0001032975-19-000007:notes:156]
The Company completed its review of previously recorded provisional income tax amounts related to net deferred tax assets impacted by the Tax Act and concluded that additional information, interpretation and guidance that became available during the twelve-month measurement period did not alter the Company’s application of tax law in remeasuring gross deferred tax assets and related valuation allowance. There were no adjustments deemed necessary in the three and nine months ended December 31, 2018.

[0001032975-19-000007:notes:157]
As of December 31, 2018 and March 31, 2018, the total amount of unrecognized tax benefits due to uncertain tax positions was $74.6 million and $69.1 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-19-000007:notes:158]
As of December 31, 2018 and March 31, 2018, the Company had $36.2 million and $35.0 million, respectively, in non-current income taxes payable including interest and penalties, related to the Company's income tax liability for uncertain tax positions.

[0001032975-19-000007:notes:159]
The Company recognizes interest and penalties related to unrecognized tax positions in income tax provision. As of December 31, 2018 and March 31, 2018, the Company had $2.4 million and $2.3 million, respectively, of accrued interest and penalties related to uncertain tax positions.

[0001032975-19-000007:notes:160]
Although the Company has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During fiscal year 2019, the Company continues to review its tax positions and provide for or reverse unrecognized tax benefits as issues arise. During the next twelve months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. dollar as compared to other currencies. Excluding these factors, uncertain tax positions may decrease by as much as $7.0 million from the lapse of the statutes of limitations in various jurisdictions during the next twelve months.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001032975-19-000007:notes:161]
[same as prior period, unchanged from 0001032975-18-000048:notes:160]

[0001032975-19-000007:notes:162]
|  |  | December 31, 2018 |  | March 31, 2018 |
| Americas |  | $ | 31,178 |  |  | $ | 35,404 |  |
| EMEA |  | 4,694 |  |  | 4,690 |  |
| Asia Pacific |  | 45,705 |  |  | 46,210 |  |
| Total property, plant and equipment, net |  | $ | 81,577 |  |  | $ | 86,304 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001032975-19-000007:notes:163]
In August 2018, the FASB issued ASU 2018-15, "Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Customer's Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract" ("ASU 2018-15"), which clarifies that implementation costs incurred by customers in cloud computing arrangements are deferred if they would be capitalized by customers in software licensing arrangements under the internal-use software guidance. ASU 2018-15 is effective for annual and interim periods in fiscal years beginning after December 15, 2019, with early adoption permitted. Entities have the option to apply the guidance prospectively to all implementation costs incurred after the date of adoption or retrospectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001032975-19-000007:notes:164]
[same as prior period, unchanged from 0001032975-18-000048:notes:162]

[0001032975-19-000007:notes:165]
During the first quarter of fiscal year 2019, the Company implemented a restructuring plan to streamline and realign the Company's overall organizational structure and reallocate resources to support long-term growth opportunities. In July 2018, the Company's Board of Directors approved additional costs under this restructuring plan, totaling pre-tax charges of approximately $10.0 million to $15.0 million, of which $9.8 million was recognized during the first nine months of fiscal year 2019. The total charges consisted of cash severance and other personnel costs and are presented as restructuring charges (credits), net in the condensed consolidated statements of operations, and the accrual balances are presented in accrued and other current liabilities in the condensed consolidated balance sheets. The Company expects to substantially complete this restructuring within the next six months.

[0001032975-19-000007:notes:166]
The following table summarizes restructuring related activities during the three and nine months ended December 31, 2018 (in thousands):

[0001032975-19-000007:notes:167]
|  |  | TerminationBenefits |
| Accrual balance at March 31, 2018 |  | $ | — |  |
| Charges |  | 9,921 |  |
| Cash payments |  | (2,014 | ) |
| Accrual balance at June 30, 2018 |  | 7,907 |  |
| Charges |  | 119 |  |
| Cash payments |  | (1,945 | ) |
| Accrual balance at September 30, 2018 |  | 6,081 |  |
| Credits |  | (278 | ) |
| Cash payments |  | (2,066 | ) |
| Accrual balance at December 31, 2018 |  | $ | 3,737 |  |


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001032975-19-000007:notes:168]
Net sales by geographic region (based on the customers’ locations) for the three and nine months ended December 31, 2018 and 2017 were as follows (in thousands):

[0001032975-19-000007:notes:169]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Americas |  | $ | 385,598 |  |  | $ | 380,130 |  |  | $ | 946,240 |  |  | $ | 887,523 |  |
| EMEA |  | 269,082 |  |  | 253,767 |  |  | 648,014 |  |  | 622,681 |  |
| Asia Pacific |  | 209,708 |  |  | 178,124 |  |  | 569,760 |  |  | 464,233 |  |
| Total net sales |  | $ | 864,388 |  |  | $ | 812,021 |  |  | $ | 2,164,014 |  |  | $ | 1,974,437 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001032975-19-000007:notes:170]
[same as prior period, unchanged from 0001032975-18-000048:notes:168]

[0001032975-19-000007:notes:171]
|  |  | Accumulated Other Comprehensive Income (Loss) |
|  |  | CumulativeTranslationAdjustment (1) |  | DefinedBenefitPlan (1) |  | Deferred Hedging Losses (1) |  | Total |
| March 31, 2018 |  | $ | (83,848 | ) |  | $ | (6,398 | ) |  | $ | (3,209 | ) |  | $ | (93,455 | ) |
| Other comprehensive income (loss) |  | (8,252 | ) |  | (100 | ) |  | 3,514 |  |  | (4,838 | ) |
| December 31, 2018 |  | $ | (92,100 | ) |  | $ | (6,498 | ) |  | $ | 305 |  |  | $ | (98,293 | ) |

[0001032975-19-000007:notes:172]
(1)        Tax effect was not significant as of December 31 or March 31, 2018.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001032975-19-000007:notes:173]
Net sales by product categories and sales channels, excluding intercompany transactions, for the three and nine months ended December 31, 2018 and 2017 were as follows (in thousands):

[0001032975-19-000007:notes:174]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Pointing Devices |  | $ | 149,123 |  |  | $ | 140,983 |  |  | $ | 405,250 |  |  | $ | 386,700 |  |
| Keyboards & Combos |  | 144,169 |  |  | 126,372 |  |  | 404,263 |  |  | 361,685 |  |
| PC Webcams |  | 33,021 |  |  | 27,280 |  |  | 90,916 |  |  | 80,370 |  |
| Tablet & Other Accessories |  | 35,757 |  |  | 26,648 |  |  | 104,903 |  |  | 80,650 |  |
| Video Collaboration |  | 74,186 |  |  | 46,252 |  |  | 190,154 |  |  | 128,008 |  |
| Mobile Speakers |  | 96,263 |  |  | 147,377 |  |  | 207,690 |  |  | 300,843 |  |
| Audio & Wearables |  | 98,629 |  |  | 84,435 |  |  | 212,343 |  |  | 197,083 |  |
| Gaming |  | 213,663 |  |  | 173,802 |  |  | 510,481 |  |  | 365,232 |  |
| Smart Home |  | 19,577 |  |  | 38,692 |  |  | 37,829 |  |  | 73,481 |  |
| Other (1) |  | — |  |  | 180 |  |  | 185 |  |  | 385 |  |
| Total net sales |  | $ | 864,388 |  |  | $ | 812,021 |  |  | $ | 2,164,014 |  |  | $ | 1,974,437 |  |

[0001032975-19-000007:notes:175]
[same as prior period, unchanged from 0001032975-18-000048:notes:173]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-19-000007:notes:176]
[same as prior period, unchanged from 0001032975-18-000048:notes:174]

[0001032975-19-000007:notes:177]
[same as prior period, unchanged from 0001032975-18-000048:notes:175]

[0001032975-19-000007:notes:178]
[same as prior period, unchanged from 0001032975-18-000048:notes:176]

[0001032975-19-000007:notes:179]
The United States and Germany each represented more than 10% of the total consolidated net sales for each of the periods presented herein. China represented more than 10% of the total consolidated net sales for the nine months ended December 31, 2018. No other countries represented 10% or more of the Company’s total consolidated net sales for the periods presented herein.

[0001032975-19-000007:notes:180]
Switzerland, the Company’s home domicile, represented 3% of the Company's total consolidated net sales for the three and nine months ended December 31, 2018, and represented 1% and 2% of the Company’s total consolidated net sales for the three and nine months ended December 31, 2017, respectively.

[0001032975-19-000007:notes:181]
Two customers of the Company each represented more than 10% of the total consolidated net sales for each of the periods presented herein.

[0001032975-19-000007:notes:182]
Property, plant and equipment, net in the United States and China were $31.2 million and $37.9 million, respectively, as of December 31, 2018, and $35.3 million and $37.9 million, respectively, as of March 31, 2018. No other countries represented 10% or more of the Company’s total consolidated property, plant and equipment, net as of December 31, 2018 or March 31, 2018. Property, plant and equipment, net in Switzerland, the Company’s home domicile, were $1.7 million and $1.9 million as of December 31, 2018 and March 31, 2018, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-19-000007:notes:183]
[same as prior period, unchanged from 0001032975-18-000048:notes:181]

[0001032975-19-000007:notes:184]
[same as prior period, unchanged from 0001032975-18-000048:notes:182]

[0001032975-19-000007:notes:185]
In March 2017, the Company's Board of Directors approved the 2017 share buyback program, which authorizes the Company to use up to $250.0 million to purchase up to 17.3 million shares of its own shares. The Company's share buyback program is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. As of December 31, 2018, 197.4 million is still available for repurchase under the 2017 buyback program.

[0001032975-19-000007:notes:186]
[same as prior period, unchanged from 0001032975-18-000048:notes:184]

[0001032975-19-000007:notes:187]
During the nine months ended December 31, 2018, the Company declared and paid cash dividends of CHF 0.67 (USD equivalent of $0.69) per common share, totaling $114.0 million on the Company's outstanding common stock. During the nine months ended December 31, 2017, the Company declared and paid cash dividends of CHF 0.61 (USD equivalent of $0.63) per common share, totaling $104.2 million on the Company's outstanding common stock.

[0001032975-19-000007:notes:188]
[same as prior period, unchanged from 0001032975-18-000048:notes:186]

[0001032975-19-000007:notes:189]
[same as prior period, unchanged from 0001032975-18-000048:notes:187]

[0001032975-19-000007:notes:190]
[same as prior period, unchanged from 0001032975-18-000048:notes:188]

[0001032975-19-000007:notes:191]
[same as prior period, unchanged from 0001032975-18-000048:notes:189]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-19-000007:notes:192]
[same as prior period, unchanged from 0001032975-18-000048:notes:191]
