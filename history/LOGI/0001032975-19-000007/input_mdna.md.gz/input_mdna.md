# LOGI MD&A — 0001032975-19-000007


## mdna

[0001032975-19-000007:mdna:1]
[same as prior period, unchanged from 0001032975-18-000048:mdna:1]

[0001032975-19-000007:mdna:2]
[same as prior period, unchanged from 0001032975-18-000048:mdna:2]

[0001032975-19-000007:mdna:3]
[same as prior period, unchanged from 0001032975-18-000048:mdna:3]

[0001032975-19-000007:mdna:4]
Logitech is a world leader in designing, manufacturing and marketing products that help connect people to digital and cloud experiences. More than 35 years ago, Logitech created products to improve experiences around the personal PC platform, and today it is a multi-brand, multi-category company designing products that enable better experiences consuming, sharing and creating any digital content such as music, gaming, video and computing, whether it is on a computer, mobile device or in the cloud. Logitech's brands include Logitech, Ultimate Ears, Jaybird, Blue Microphones, Logitech G and ASTRO Gaming. Our Company's website is www.logitech.com.

[0001032975-19-000007:mdna:5]
[same as prior period, unchanged from 0001032975-18-000048:mdna:5]

[0001032975-19-000007:mdna:6]
[same as prior period, unchanged from 0001032975-18-000048:mdna:6]

[0001032975-19-000007:mdna:7]
On August 21, 2018 (the "Acquisition Date"), we acquired all equity interests in Blue Microphones Holding Corporation ("Blue Microphones") for a total consideration of $134.8 million in cash (the "Blue Microphones Acquisition"), which includes a working capital adjustment and repayment of a debt on behalf of Blue Microphones. Blue Microphones is a leading audio manufacturer that designs and produces microphones, headphones, recording tools, and accessories for audio professionals, musicians and consumers. The Blue Microphones Acquisition is consistent with Logitech's merger and acquisition strategy and will supplement the Company's portfolio in the microphones market. For the three and nine months ended December 31, 2018, Blue Microphones contributed three percentage point and two percentage points, respectively, of the net sales growth rate.

[0001032975-19-000007:mdna:8]
[same as prior period, unchanged from 0001032975-18-000048:mdna:8]

[0001032975-19-000007:mdna:9]
Our net sales for the three and nine months ended December 31, 2018 increased 6% and 10%, respectively, compared to the three and nine months ended December 31, 2017, supported by stronger net sales in Asia Pacific.

[0001032975-19-000007:mdna:10]
Our net sales for the three months ended December 31, 2018 increased 1%, 6%, and 18% in the Americas, EMEA, and Asia Pacific, respectively, compared to the same period of the prior fiscal year. Our net sales for the nine months ended December 31, 2018 increased 7%, 4% and 23% in the Americas, EMEA and Asia Pacific, respectively, compared to the same period of the prior fiscal year.

[0001032975-19-000007:mdna:11]
[same as prior period, unchanged from 0001032975-18-000048:mdna:11]

[0001032975-19-000007:mdna:12]
Our gross margin for the three months ended December 31, 2018 increased 360 basis points to 37.5% from 33.9% for the three months ended December 31, 2017. Our gross margin benefited from favorable mix and cost reduction efforts, supply chain efficiencies and Topic 606 adoption, partially offset by U.S. tariffs implemented in July 2018 for certain of our products imported into the United States. In addition, an increase in logistics costs, including additional costs from the transition of the distribution center in North America in the third quarter of fiscal year 2018, negatively affected the gross margin of that prior year period by approximately 150 basis points.

[0001032975-19-000007:mdna:13]
Our gross margin for the nine months ended December 31, 2018 increased 190 basis points to 37.2% from 35.3% for the nine months ended December 31, 2017 primarily due to supply chain efficiencies, cost reduction efforts, favorable exchange rates, tariff duty refund, and Topic 606 adoption, partially offset by an increase in tariffs. In addition, additional costs from the transition of the distribution center in North America in the third quarter of fiscal year 2018 negatively affected the gross margin of the prior year period.

[0001032975-19-000007:mdna:14]
We continue to implement various initiatives to mitigate the impact of recently adopted and announced U.S. tariffs, such as imports to the U.S. earlier than usual, supply chain or production shifts, and potential pricing adjustments. As some of these mitigating initiatives take time to implement, there could be an adverse impact to our gross margin in the future periods as we adjust to tariffs and other trade restrictions.

[0001032975-19-000007:mdna:15]
Operating expenses for the three months ended December 31, 2018 were $200.6 million, or 23.2% of net sales, compared to $175.3 million, or 21.6% of net sales, in the same period of the prior fiscal year. Operating expenses for the nine months ended December 31, 2018 were $583.1 million, or 26.9% of net sales, compared to $506.4 million, or 25.6% of net sales, in the same period of the prior fiscal year. The increase in operating expenses for the three months ended December 31, 2018, was primarily driven by $13.0 million higher personnel-related cost primarily due to additional headcount from business acquisition and increased performance-based variable

[0001032975-19-000007:mdna:16]
30

[0001032975-19-000007:mdna:17]
compensation and $2.6 million higher advertising and marketing expenses to support our new product introductions.The increase in operating expenses for the nine months ended December 31, 2018 was primarily driven by $45.2 million higher personnel-related cost due to restructuring charges in the current period, increased performance-based variable compensation and additional headcount from business acquisitions, $12.3 million higher advertising and marketing expenses to support our new product introductions, and a $4.9 million non-recurring credit for change in fair value of contingent consideration from an acquisition recorded in fiscal year 2018.

[0001032975-19-000007:mdna:18]
Net income for the three and nine months ended December 31, 2018 was $112.8 million and $215.5 million, respectively, compared to $80.8 million and $174.1 million, respectively, for the three and nine months ended December 31, 2017.

[0001032975-19-000007:mdna:19]
[same as prior period, unchanged from 0001032975-18-000048:mdna:18]

[0001032975-19-000007:mdna:20]
[same as prior period, unchanged from 0001032975-18-000048:mdna:19]

[0001032975-19-000007:mdna:21]
[same as prior period, unchanged from 0001032975-18-000048:mdna:20]

[0001032975-19-000007:mdna:22]
[same as prior period, unchanged from 0001032975-18-000048:mdna:21]

[0001032975-19-000007:mdna:23]
Video Collaboration:  The near and long-term structural growth opportunities in the video collaboration market are significant and are likely to attract more competition. Video meetings are on the rise, and companies increasingly want lower-cost, cloud-based solutions. We are continuing our efforts to create and sell innovative products to accommodate the increasing demand from medium-sized meeting rooms to small-sized rooms such as huddle rooms. We will continue to invest in select business-specific products, targeted product marketing and sales channel development.

[0001032975-19-000007:mdna:24]
Gaming:  The PC gaming and console gaming platform continues to show strong growth as online gaming, multi-platform experiences, and eSports gain greater popularity and gaming content becomes increasingly more demanding. We believe Logitech is well positioned to benefit from the gaming market growth. With ASTRO Gaming, we are also strengthening our portfolio in adjacent categories, such as the console gaming market.

[0001032975-19-000007:mdna:25]
Creativity & Productivity:  New PC shipments continue to be stable and the installed base of PC users remains large. We believe that innovative PC peripherals, such as our mice and keyboards, can renew the PC usage experience, providing growth opportunities. Smaller mobile computing devices, such as tablets, have created new markets and usage models for peripherals and accessories. We offer a number of products to enhance the use of mobile devices, including keyboard folios for the iPad and iPad mini, and keyboard covers and folios for the iPad Air. The increasing popularity of streaming and broadcasting provides additional growth opportunities for our Webcam products.

[0001032975-19-000007:mdna:26]
Music:  The music market is driven by growing consumption of music through mobile devices such as smartphones and tablets. The integration of personal voice assistants has become increasingly competitive in the speaker categories and the market for third-party, voice-enabled speakers has not yet gained traction. Moreover, the market for mobile speakers appears to be maturing with slower growth. While we continue to introduce new products for improved experiences, we're adjusting our investments to match the slower market growth outlook. With Blue Microphones, we are also strengthening our portfolio in adjacent categories, such as the microphones market.

[0001032975-19-000007:mdna:27]
Smart Home:  The smart home market grew in fiscal year 2018 due to the integration of Amazon Alexa and Google Assistant voice capabilities into our Logitech Harmony Hub that enables voice control of the living room entertainment experience when used with an Amazon Echo or Google Home device. Through Harmony, Alexa can turn on/off and control a TV and AV system. While the market so far in fiscal year 2019 has slowed due to more difficult competitions, we continue to see various long-term opportunities in the broader smart home market. Accordingly, we will be prudent in how we deploy our resources in the near term.

[0001032975-19-000007:mdna:28]
[same as prior period, unchanged from 0001032975-18-000048:mdna:27]

[0001032975-19-000007:mdna:29]
[same as prior period, unchanged from 0001032975-18-000048:mdna:28]

[0001032975-19-000007:mdna:30]
[same as prior period, unchanged from 0001032975-18-000048:mdna:29]

[0001032975-19-000007:mdna:31]
[same as prior period, unchanged from 0001032975-18-000048:mdna:30]

[0001032975-19-000007:mdna:32]
The preparation of financial statements and related disclosures in conformity with GAAP requires us to make judgments, estimates and assumptions that affect reported amounts of assets, liabilities, goodwill and intangible assets from business acquisitions, contingent consideration related to business acquisitions, and net sales and expenses.

[0001032975-19-000007:mdna:33]
[same as prior period, unchanged from 0001032975-18-000048:mdna:32]

[0001032975-19-000007:mdna:34]
[same as prior period, unchanged from 0001032975-18-000048:mdna:33]

[0001032975-19-000007:mdna:35]
Other than the recent accounting pronouncement adoptions discussed below and Summary of Significant Accounting Policies discussed in Note 1 to the condensed consolidated financial statements, there have been no substantial changes in the Company’s significant accounting policies during the nine months ended December 31, 2018, compared with the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended March 31, 2018.

[0001032975-19-000007:mdna:36]
[same as prior period, unchanged from 0001032975-18-000048:mdna:35]

[0001032975-19-000007:mdna:37]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers" ("ASU 2014-09" or “Topic 606”) which supersedes the revenue recognition requirements under ASC 605 (“Topic 605”), Revenue Recognition. ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes existing revenue recognition guidance, including industry-specific guidance. Under the new guidance, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The new standard requires reporting companies to disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. On April 1, 2018, we adopted the new standard and all related amendments using the modified retrospective method applied to those contracts that were not completed as of April 1, 2018. Results for reporting periods beginning after March 31, 2018 are presented under Topic 606, while prior period amounts are not adjusted and continue to be reported in accordance with historic accounting standards under Topic 605. Refer to Note 1 to the condensed consolidated financial statements for further details of the impact of adoption of Topic 606.

[0001032975-19-000007:mdna:38]
In January 2016, the FASB issued ASU 2016-01, "Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10)" ("ASU 2016-01"). ASU 2016-01 requires entities to measure equity instruments at fair value and recognize any changes in fair value within the statement of operations. We adopted ASU 2016-01 effective April 1, 2018 on a prospective basis for our privately held strategic equity securities without readily determinable fair values. We elected the measurement alternative to record these investments at cost and to adjust for impairments and observable price changes with a same or similar security from the same issuer within the statement of operations. The adoption of ASU 2016-01 did not have a material impact on our condensed consolidated financial statements.

[0001032975-19-000007:mdna:39]
In October 2016, the FASB issued ASU 2016-16, "Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory" ("ASU 2016-16"), which eliminates the deferral of income tax effects of intra-entity asset

[0001032975-19-000007:mdna:40]
transfers until the transferred asset is sold to an unrelated party or recovered through use. However, this standard does not apply to intra-entity transfer of inventory. We adopted this standard effective April 1, 2018 on a modified retrospective basis, and the adoption of ASU 2016-16 did not have a material impact on our condensed consolidated financial statements.

[0001032975-19-000007:mdna:41]
In December 2016, the FASB issued ASU 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash" ("ASU 2016-18"), which requires that a statement of cash flows explains the change during the period in the total of cash, cash equivalents and amounts generally described as restricted cash or restricted cash equivalents. We adopted this standard effective April 1, 2018 utilizing the retrospective transition method to each period presented, and the adoption of ASU 2016-18 did not have an impact on our condensed consolidated financial statements as we did not have any restricted cash for either period presented.

[0001032975-19-000007:mdna:42]
In January 2017, the FASB issued ASU 2017-01, "Business Combination (Topic 805): Clarifying the Definition of a Business" ("ASU 2017-01"), which changes the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. We adopted this standard effective April 1, 2018, and the adoption of ASU 2017-01 did not have a material impact on our condensed consolidated financial statements.

[0001032975-19-000007:mdna:43]
In March 2017, the FASB issued ASU 2017-07, "Compensation-Retirement Benefit (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost" ("ASU 2017-07"), which requires that the Company disaggregate the service cost component from the other components of net benefit cost, and also provides guidance on how to present the service cost component and the other components of net benefit cost in the income statement and allow only the service cost component of net benefit cost to be eligible for capitalization. We adopted this standard effective April 1, 2018 using a retrospective adoption method. Other than the revised statement of operations presentation for the periods in the current year, the adoption of ASU 2017-07 did not have an impact on our condensed consolidated financial statements. The impact to the comparative period was immaterial and therefore prior period statements of operations were not revised.

[0001032975-19-000007:mdna:44]
In August 2017, the FASB issued ASU 2017-12, "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" ("ASU 2017-12"), which improves the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements and simplifies the application of the hedge accounting guidance. We adopted this standard effective April 1, 2018, and the adoption of ASU 2017-12 did not have a material impact on our condensed consolidated financial statements. In accordance with ASU 2017-12, we have started presenting the earnings impact from forward points in the cost of goods sold line item, which is used to present the earnings impact of the hedged item.

[0001032975-19-000007:mdna:45]
[same as prior period, unchanged from 0001032975-18-000048:mdna:44]

[0001032975-19-000007:mdna:46]
[same as prior period, unchanged from 0001032975-18-000048:mdna:45]

[0001032975-19-000007:mdna:47]
[same as prior period, unchanged from 0001032975-18-000048:mdna:46]

[0001032975-19-000007:mdna:48]
Given our global sales presence and the reporting of our financial results in U.S. Dollars, our financial results could be affected by shifts in currency exchange rates. See “Results of Operations” for information on the effect of currency exchange rate results on our net sales. If the U.S. Dollar appreciates or depreciates in comparison to other currencies in future periods, this will affect our results of operations in future periods as well.

[0001032975-19-000007:mdna:49]
Sales are net sales and the sales growth discussion and sales growth rate percentages are in U.S. Dollars, except as otherwise specified.

[0001032975-19-000007:mdna:50]
[same as prior period, unchanged from 0001032975-18-000048:mdna:48]

[0001032975-19-000007:mdna:51]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Canadian Dollar, Taiwan New

[0001032975-19-000007:mdna:52]
Dollar, British Pound and Australian Dollar. During the three and nine months ended December 31, 2018, approximately 50% of our net sales were denominated in currencies other than the U.S. Dollar.

[0001032975-19-000007:mdna:53]
[same as prior period, unchanged from 0001032975-18-000048:mdna:50]

[0001032975-19-000007:mdna:54]
[same as prior period, unchanged from 0001032975-18-000048:mdna:51]

[0001032975-19-000007:mdna:55]
Our net sales in the three and nine months ended December 31, 2018 increased 6% and 10%, respectively, compared to the same periods of the prior fiscal year. Sales increased in the Americas, EMEA and Asia Pacific during the three and nine months ended December 31, 2018. If currency exchange rates had been constant in the three and nine months ended December 31, 2018 and 2017, our constant dollar sales growth rates would have been 8% and 10%, respectively. For both the three-month and nine-month periods, we grew double digits in our Gaming, Video Collaboration, Keyboards & Combos, PC Webcams and Tablet & Other Accessories product categories. Sales for Mobile Speaker and Smart Home product categories declined across all three regions. The adoption of Topic 606 increased our net sales for the three and nine months ended December 31, 2018 by $10.8 million and $5.7 million, respectively.

[0001032975-19-000007:mdna:56]
[same as prior period, unchanged from 0001032975-18-000048:mdna:53]

[0001032975-19-000007:mdna:57]
The following table presents the change in net sales by region for the three and nine months ended December 31, 2018, compared with the three and nine months ended December 31, 2017:

[0001032975-19-000007:mdna:58]
|  |  | Sales Growth Rate |  | Constant DollarSales Growth Rate |
|  |  | Three Months Ended December 31, 2018 |  | Nine Months EndedDecember 31, 2018 |  | Three Months EndedDecember 31, 2018 | Nine Months EndedDecember 31, 2018 |
| Americas |  | 1 | % |  | 7 | % |  | 2 | % | 7 | % |
| EMEA |  | 6 | % |  | 4 | % |  | 9 | % | 4 | % |
| Asia Pacific |  | 18 | % |  | 23 | % |  | 21 | % | 23 | % |

[0001032975-19-000007:mdna:59]
[same as prior period, unchanged from 0001032975-18-000048:mdna:56]

[0001032975-19-000007:mdna:60]
The increase in net sales in our Americas region for the three-month and nine-month periods presented above was primarily driven by growth in Gaming, Video Collaboration, Audio & Wearables, and Keyboards and Combos, partially offset by a decline in sales for Mobile Speakers and Smart Home. In addition, Tablets and Other Accessories and PC Webcams also contributed to the increase for the nine-month period.

[0001032975-19-000007:mdna:61]
[same as prior period, unchanged from 0001032975-18-000048:mdna:58]

[0001032975-19-000007:mdna:62]
The increase in net sales in our EMEA region for the three-month and nine-month periods presented above was primarily driven by growth in Gaming, Video Collaboration, Keyboards and Combos, Pointing Devices, PC Webcams, and Tablet and Other Accessories, partially offset by a decline in sales for Mobile Speakers and Smart Home.

[0001032975-19-000007:mdna:63]
[same as prior period, unchanged from 0001032975-18-000048:mdna:60]

[0001032975-19-000007:mdna:64]
The increase in net sales in our Asia Pacific region during the three-month and nine-month periods presented above was primarily driven by growth in Gaming, Keyboards and Combos, Video Collaboration, and Pointing Devices, partially offset by a decline in sales for Mobile Speakers.

[0001032975-19-000007:mdna:65]
34

[0001032975-19-000007:mdna:66]
[same as prior period, unchanged from 0001032975-18-000048:mdna:62]

[0001032975-19-000007:mdna:67]
Net sales by product category for the three and nine months ended December 31, 2018 and 2017 were as follows (Dollars in thousands):

[0001032975-19-000007:mdna:68]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Pointing Devices |  | $ | 149,123 |  |  | $ | 140,983 |  |  | 6 | % |  | $ | 405,250 |  |  | $ | 386,700 |  |  | 5 | % |
| Keyboards & Combos |  | 144,169 |  |  | 126,372 |  |  | 14 |  |  | 404,263 |  |  | 361,685 |  |  | 12 |  |
| PC Webcams |  | 33,021 |  |  | 27,280 |  |  | 21 |  |  | 90,916 |  |  | 80,370 |  |  | 13 |  |
| Tablet & Other Accessories |  | 35,757 |  |  | 26,648 |  |  | 34 |  |  | 104,903 |  |  | 80,650 |  |  | 30 |  |
| Video Collaboration |  | 74,186 |  |  | 46,252 |  |  | 60 |  |  | 190,154 |  |  | 128,008 |  |  | 49 |  |
| Mobile Speakers |  | 96,263 |  |  | 147,377 |  |  | (35 | ) |  | 207,690 |  |  | 300,843 |  |  | (31 | ) |
| Audio & Wearables |  | 98,629 |  |  | 84,435 |  |  | 17 |  |  | 212,343 |  |  | 197,083 |  |  | 8 |  |
| Gaming |  | 213,663 |  |  | 173,802 |  |  | 23 |  |  | 510,481 |  |  | 365,232 |  |  | 40 |  |
| Smart Home |  | 19,577 |  |  | 38,692 |  |  | (49 | ) |  | 37,829 |  |  | 73,481 |  |  | (49 | ) |
| Other (1) |  | — |  |  | 180 |  |  | (100 | ) |  | 185 |  |  | 385 |  |  | (52 | ) |
| Total net sales |  | $ | 864,388 |  |  | $ | 812,021 |  |  | 6 | % |  | $ | 2,164,014 |  |  | $ | 1,974,437 |  |  | 10 | % |

[0001032975-19-000007:mdna:69]
[same as prior period, unchanged from 0001032975-18-000048:mdna:65]

[0001032975-19-000007:mdna:70]
[same as prior period, unchanged from 0001032975-18-000048:mdna:67]

[0001032975-19-000007:mdna:71]
[same as prior period, unchanged from 0001032975-18-000048:mdna:68]

[0001032975-19-000007:mdna:72]
[same as prior period, unchanged from 0001032975-18-000048:mdna:69]

[0001032975-19-000007:mdna:73]
Net sales of Pointing Devices increased 6% and 5% in the three and nine months ended December 31, 2018, respectively, compared to the same periods of the prior fiscal year. The increase for both periods was primarily driven by an increase in sales for cordless mice, led by strong contribution from MX Vertical Wireless Mouse introduced in the second quarter of fiscal year 2019. Increases in sales for MX Master 2S Wireless Mouse and B220 Silent Mouse also contributed to the sales increase for both periods.

[0001032975-19-000007:mdna:74]
[same as prior period, unchanged from 0001032975-18-000048:mdna:71]

[0001032975-19-000007:mdna:75]
[same as prior period, unchanged from 0001032975-18-000048:mdna:72]

[0001032975-19-000007:mdna:76]
Net sales of Keyboards & Combos increased 14% and 12% in the three and nine months ended December 31, 2018, respectively, compared to the same periods of the prior fiscal year. The increase in both periods was primarily driven by an increase in sales of cordless keyboards and combos, mainly from the introduction of MK540 Wireless Keyboard Mouse Combo in the fourth quarter of fiscal year 2018 and MK545 Wireless Keyboard Mouse Combo in the first quarter of fiscal year 2019, and an increase in sales of Logitech Wireless Combo MK270.

[0001032975-19-000007:mdna:77]
[same as prior period, unchanged from 0001032975-18-000048:mdna:74]

[0001032975-19-000007:mdna:78]
[same as prior period, unchanged from 0001032975-18-000048:mdna:75]

[0001032975-19-000007:mdna:79]
PC Webcams net sales increased 21% and 13% in the three and nine months ended December 31, 2018, respectively, compared to the same periods of the prior fiscal year. The increase in both periods was primarily driven by increases in sales of our HD Pro Webcam C920 and 1080P Pro Stream Webcam.

[0001032975-19-000007:mdna:80]
[same as prior period, unchanged from 0001032975-18-000048:mdna:77]

[0001032975-19-000007:mdna:81]
[same as prior period, unchanged from 0001032975-18-000048:mdna:78]

[0001032975-19-000007:mdna:82]
Net sales of Tablet & Other Accessories products increased 34% and 30% in the three and nine months ended December 31, 2018, respectively, compared to the same periods of the prior fiscal year. The increase for both periods was primarily driven by the introductions of our Slim Folio keyboard cases in the second quarter of fiscal year 2019, education-based Rugged Combo 2 in the first quarter of fiscal year 2019, Slim Combo keyboard cases in the third quarter of fiscal year 2018, Crayon (a digital pencil) and POWERED (a wireless charging dock for iPhone) in the second quarter of fiscal year 2019.

[0001032975-19-000007:mdna:83]
[same as prior period, unchanged from 0001032975-18-000048:mdna:80]

[0001032975-19-000007:mdna:84]
[same as prior period, unchanged from 0001032975-18-000048:mdna:82]

[0001032975-19-000007:mdna:85]
Net sales of Video Collaboration products increased 60% and 49% in the three and nine months ended December 31, 2018, respectively, compared to the same periods of the prior fiscal year. The increase for both periods was primarily driven by an increase in sales for our MeetUp video conference camera, BRIO 4K Pro Webcam, high end business webcams and the introduction of our Rally Ultra-HD PTZ Conference Camera in the third quarter of fiscal year 2019. PTZ Pro 2 also contributed to the sales increase for the nine months ended December 31, 2018.

[0001032975-19-000007:mdna:86]
[same as prior period, unchanged from 0001032975-18-000048:mdna:84]

[0001032975-19-000007:mdna:87]
[same as prior period, unchanged from 0001032975-18-000048:mdna:85]

[0001032975-19-000007:mdna:88]
[same as prior period, unchanged from 0001032975-18-000048:mdna:86]

[0001032975-19-000007:mdna:89]
Net sales of Mobile Speakers decreased 35% and 31% for the three and nine months ended December 31, 2018, respectively, compared to the same periods of the prior fiscal year. The decrease for both periods was primarily due to declines in sales for our existing Ultimate Ears speakers. The decrease was partially offset by sales from the introductions of our Ultimate Ears MEGABOOM 3 and BOOM 3 mobile speakers in the second quarter of fiscal year 2019.

[0001032975-19-000007:mdna:90]
[same as prior period, unchanged from 0001032975-18-000048:mdna:88]

[0001032975-19-000007:mdna:91]
[same as prior period, unchanged from 0001032975-18-000048:mdna:89]

[0001032975-19-000007:mdna:92]
Audio & Wearables net sales increased 17% and 8% for the three and nine months ended December 31, 2018, respectively, compared to the same periods of the prior fiscal year. The increase for both periods was primarily driven by an increase in sales of our corded headsets and sales from Blue Microphones products as a result of our business combination (see Note 2 to the condensed consolidated financial statements), partially offset by a decrease in sales of PC speakers and Jaybird products.

[0001032975-19-000007:mdna:93]
[same as prior period, unchanged from 0001032975-18-000048:mdna:91]

[0001032975-19-000007:mdna:94]
[same as prior period, unchanged from 0001032975-18-000048:mdna:93]

[0001032975-19-000007:mdna:95]
Gaming net sales increased 23% and 40% for the three and nine months ended December 31, 2018, respectively, compared to the same periods of the prior fiscal year. The increase for both periods was primarily driven by an increase in sales of our core PC gaming products, and ASTRO console gaming headsets, which benefited from the growing gaming market, growth in eSports, expansions in new channels and regions, and expansion in product portfolios. The increase for the nine-month period was also driven by the fact that the acquisition of ASTRO closed on August 11, 2017, in the middle of our fiscal year 2018 second quarter, resulting in a partial comparative period impact. The growth in both periods was partially offset by a slight decline in our simulation products.

[0001032975-19-000007:mdna:96]
[same as prior period, unchanged from 0001032975-18-000048:mdna:96]

[0001032975-19-000007:mdna:97]
[same as prior period, unchanged from 0001032975-18-000048:mdna:98]

[0001032975-19-000007:mdna:98]
Smart Home net sales decreased 49% during the three and nine months ended December 31, 2018, compared to the same periods of the prior fiscal year. The decrease for both periods was primarily due to declines in sales of our Harmony remotes and home video products.

[0001032975-19-000007:mdna:99]
[same as prior period, unchanged from 0001032975-18-000048:mdna:100]

[0001032975-19-000007:mdna:100]
Gross profit for the three and nine months ended December 31, 2018 and 2017 was as follows (Dollars in thousands):

[0001032975-19-000007:mdna:101]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Net sales |  | $ | 864,388 |  |  | $ | 812,021 |  |  | 6 | % |  | $ | 2,164,014 |  |  | $ | 1,974,437 |  |  | 10 | % |
| Gross profit |  | $ | 323,982 |  |  | $ | 275,601 |  |  | 18 |  |  | $ | 804,036 |  |  | $ | 697,006 |  |  | 15 |  |
| Gross margin |  | 37.5 | % |  | 33.9 | % |  |  |  | 37.2 | % |  | 35.3 | % |  |  |  |

[0001032975-19-000007:mdna:102]
[same as prior period, unchanged from 0001032975-18-000048:mdna:103]

[0001032975-19-000007:mdna:103]
[same as prior period, unchanged from 0001032975-18-000048:mdna:104]

[0001032975-19-000007:mdna:104]
Operating expenses for the three and nine months ended December 31, 2018 and 2017 were as follows (Dollars in thousands):

[0001032975-19-000007:mdna:105]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |  |
| Marketing and selling |  | $ | 132,250 |  |  | $ | 116,153 |  |  | $ | 368,635 |  |  | $ | 325,917 |  |  |
| % of net sales |  | 15.3 | % |  | 14.3 | % |  | 17.0 | % |  | 16.5 | % |  |
| Research and development |  | 40,591 |  |  | 34,398 |  |  | 119,120 |  |  | 106,144 |  |  |
| % of net sales |  | 4.7 | % |  | 4.2 | % |  | 5.5 | % |  | 5.4 | % |  |
| General and administrative |  | 24,496 |  |  | $ | 22,291 |  |  | 75,175 |  |  | 72,966 |  |  |
| % of net sales |  | 2.8 | % |  | 2.7 | % |  | 3.5 | % |  | 3.7 | % |  |
| Amortization of intangible assets and acquisition-related costs |  | 3,539 |  |  | 2,496 |  |  | 10,377 |  |  | 6,377 |  |  |
| % of net sales |  | 0.4 | % |  | 0.3 | % |  | 0.5 | % |  | 0.3 | % |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | — |  |  | — |  |  | (4,908 | ) |  |
| % of net sales |  | — | % |  | — | % |  | — | % |  | (0.2 | )% |  |
| Restructuring charges (credits), net |  | (278 | ) |  | — |  |  | 9,762 |  |  | (116 | ) |  |
| % of net sales |  | — | % | (1) | — | % |  | 0.5 | % |  | — | % | (1) |
| Total operating expenses |  | $ | 200,598 |  |  | $ | 175,338 |  |  | $ | 583,069 |  |  | $ | 506,380 |  |  |
| % of net sales |  | 23.2 | % |  | 21.6 | % |  | 26.9 | % |  | 25.6 | % |  |

[0001032975-19-000007:mdna:106]
(1) Absolute value for % of net sales is less than 0.1%.

[0001032975-19-000007:mdna:107]
[same as prior period, unchanged from 0001032975-18-000048:mdna:107]

[0001032975-19-000007:mdna:108]
[same as prior period, unchanged from 0001032975-18-000048:mdna:108]

[0001032975-19-000007:mdna:109]
During the three and nine months ended December 31, 2018, marketing and selling expenses increased $16.1 million and $42.7 million, respectively, compared to the same periods of the prior fiscal year. The increases were primarily driven by higher advertising and marketing expenses to support our new products, and higher personnel-related costs due to increased headcount and increased performance-based variable compensation.

[0001032975-19-000007:mdna:110]
[same as prior period, unchanged from 0001032975-18-000048:mdna:110]

[0001032975-19-000007:mdna:111]
Research and development expenses consist of personnel and related overhead costs, contractors and outside consultants, supplies and materials, equipment depreciation and facilities costs, all associated with the design and development of new products and enhancements of existing products.

[0001032975-19-000007:mdna:112]
During the three and nine months ended December 31, 2018, research and development expenses increased $6.2 million and $13.0 million, respectively, compared to the same periods in the prior fiscal year. The increase was primarily driven by higher personnel-related costs due to increased headcount from business acquisitions, increased performance-based variable compensation, and higher investment in new product developments.

[0001032975-19-000007:mdna:113]
[same as prior period, unchanged from 0001032975-18-000048:mdna:113]

[0001032975-19-000007:mdna:114]
General and administrative expenses consist primarily of personnel and related overhead, information technology, and facilities costs for the infrastructure functions such as finance, information systems, executives, human resources, and legal.

[0001032975-19-000007:mdna:115]
During the three and nine months ended December 31, 2018, general and administrative expenses increased $2.2 million in each period, respectively, compared to the same periods in the prior fiscal year. The increase for the three-month period was primarily driven by higher consulting cost from merger and acquisition activities. The increase for the nine-month period was primarily driven by increased performance-based variable compensation.

[0001032975-19-000007:mdna:116]
Amortization of Intangible Assets and Acquisition-Related Costs

[0001032975-19-000007:mdna:117]
Amortization of intangible assets and acquisition-related costs during the three and nine months ended December 31, 2018 and 2017 were as follows (in thousands):

[0001032975-19-000007:mdna:118]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Amortization of intangible assets |  | $ | 3,539 |  |  | $ | 2,126 |  |  | $ | 8,921 |  |  | $ | 4,965 |  |
| Acquisition-related costs |  | — |  |  | 370 |  |  | 1,456 |  |  | 1,412 |  |
| Total |  | $ | 3,539 |  |  | $ | 2,496 |  |  | $ | 10,377 |  |  | $ | 6,377 |  |

[0001032975-19-000007:mdna:119]
Amortization of intangible assets consists of amortization of acquired intangible assets, including customer relationships and trade names. The increase in amortization of intangible assets during the three and nine months ended December 31, 2018 compared with the same periods of the prior fiscal year was primarily driven by the acquisition of ASTRO in the second quarter of fiscal year 2018 and the acquisition of Blue Microphones in the second quarter of fiscal year 2019. Acquisition-related costs include legal expense, due diligence costs, and other professional costs incurred for business acquisitions.

[0001032975-19-000007:mdna:120]
[same as prior period, unchanged from 0001032975-18-000048:mdna:120]

[0001032975-19-000007:mdna:121]
There was no contingent consideration for business acquisition during the three and nine months ended December 31, 2018. During the nine months ended December 31, 2017, the fair value of the contingent consideration for business acquisition decreased $4.9 million due to the agreement we reached with the sellers of Jaybird LLC and lower-than-expected net sales of Jaybird products, partially offset by the change in the time value of money.

[0001032975-19-000007:mdna:122]
Restructuring Charges (Credits), Net

[0001032975-19-000007:mdna:123]
During the first quarter of fiscal year 2019, we implemented a restructuring plan to streamline and realign our overall organizational structure and reallocate resources to support our long-term growth opportunities. In July, 2018, our Board of Directors approved additional costs under this restructuring plan, totaling pre-tax charges of approximately $10.0 million to $15.0 million, of which $9.8 million was recognized during the first nine months of fiscal year 2019. The total charges consisted of cash severance and other personnel costs and are presented as restructuring charges (credits), net in the condensed consolidated statements of operations. We expect to substantially complete this restructuring within the next six months.

[0001032975-19-000007:mdna:124]
39

[0001032975-19-000007:mdna:125]
The following table summarizes restructuring related activities during the three and nine months ended December 31, 2018 (in thousands):

[0001032975-19-000007:mdna:126]
|  |  | TerminationBenefits |
| Accrual balance at March 31, 2018 |  | $ | — |  |
| Charges |  | 9,921 |  |
| Cash payments |  | (2,014 | ) |
| Accrual balance at June 30, 2018 |  | 7,907 |  |
| Charges |  | 119 |  |
| Cash payments |  | (1,945 | ) |
| Accrual balance at September 30, 2018 |  | $ | 6,081 |  |
| Credits |  | (278 | ) |
| Cash payments |  | (2,066 | ) |
| Accrual balance at December 31, 2018 |  | $ | 3,737 |  |

[0001032975-19-000007:mdna:127]
Other Expense, Net

[0001032975-19-000007:mdna:128]
Other expense, net for the three and nine months ended December 31, 2018 and 2017 were as follows (in thousands):

[0001032975-19-000007:mdna:129]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Investment income (loss) related to a deferred compensation plan |  | $ | (1,887 | ) |  | $ | 588 |  |  | $ | (1,077 | ) |  | $ | 1,539 |  |
| Currency exchange loss, net |  | (1,715 | ) |  | (1,127 | ) |  | (1,801 | ) |  | (2,811 | ) |
| Gain on investments in privately held companies |  | 207 |  |  | 114 |  |  | 589 |  |  | 550 |  |
| Other |  | 648 |  |  | 101 |  |  | 1,360 |  |  | (172 | ) |
| Total |  | $ | (2,747 | ) |  | $ | (324 | ) |  | $ | (929 | ) |  | $ | (894 | ) |

[0001032975-19-000007:mdna:130]
Investment income (loss) related to a deferred compensation plan represents earnings, gains, and losses on trading investments related to a deferred compensation plan offered by one of our subsidiaries.

[0001032975-19-000007:mdna:131]
Currency exchange loss, net relate to balances denominated in currencies other than the functional currency in our subsidiaries, as well as to the sale of currencies, and to gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses.

[0001032975-19-000007:mdna:132]
Provision for Income Taxes

[0001032975-19-000007:mdna:133]
The provision for income taxes and effective tax rates for the three and nine months ended December 31, 2018 and 2017 were as follows (Dollars in thousands):

[0001032975-19-000007:mdna:134]
|  |  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Provision for income taxes |  | $ | 9,309 |  |  | $ | 20,040 |  |  | $ | 10,295 |  |  | $ | 18,691 |  |
| Effective income tax rate |  | 7.6 | % |  | 19.9 | % |  | 4.6 | % |  | 9.7 | % |

[0001032975-19-000007:mdna:135]
The changes in the effective income tax rate for the three and nine months ended December 31, 2018, compared to the same periods ended December 31, 2017, were primarily due to the mix of income and losses in the various tax jurisdictions in which we operate and the provisional income tax impact from the Tax Act as of December 31, 2017.  We recorded a provisional income tax charge of $19.9 million from the estimated remeasurement of federal deferred tax assets and liabilities as of December 31, 2017 to reflect the effects of the enacted changes in tax rate and an income tax benefit of $4.1 million from assessment of valuation allowance

[0001032975-19-000007:mdna:136]
[same as prior period, unchanged from 0001032975-18-000048:mdna:138]

[0001032975-19-000007:mdna:137]
against tax credits. Furthermore, in the three and nine months ended December 31, 2018, there were discrete tax benefits of $0.9 million and $2.3 million, respectively, from the reversal of uncertain tax positions from the expiration of statutes of limitations. In the same periods ended December 31, 2017, the tax benefits from reversal of uncertain tax positions from the expiration of statutes of limitations were $6.0 million and $7.9 million, respectively.

[0001032975-19-000007:mdna:138]
We completed our review of previously recorded provisional income tax amounts related to net deferred tax assets impacted by the Tax Act and concluded that additional information, interpretation and guidance that became available during the twelve-month measurement period did not alter our application of tax law in remeasuring gross deferred tax assets and related valuation allowance. There were no adjustments deemed necessary in the three and nine months ended December 31, 2018.

[0001032975-19-000007:mdna:139]
As of December 31, 2018 and March 31, 2018, the total amounts of unrecognized tax benefits due to uncertain tax positions were $74.6 million and $69.1 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-19-000007:mdna:140]
[same as prior period, unchanged from 0001032975-18-000048:mdna:132]

[0001032975-19-000007:mdna:141]
[same as prior period, unchanged from 0001032975-18-000048:mdna:133]

[0001032975-19-000007:mdna:142]
As of December 31, 2018, we had cash and cash equivalents of $584.5 million, compared to $641.9 million as of March 31, 2018. As of December 31, 2018, 63% of the cash and cash equivalents was held in Switzerland, 15%  held in Hong Kong and China and 13% held in the United Kingdom. We do not expect to incur any material adverse tax impact except for what has been recognized, or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-19-000007:mdna:143]
The decrease in cash and cash equivalents for the nine months ended December 31, 2018, was primarily due to the cash paid for the Blue Microphones Acquisition (see Note 2 to the condensed consolidated financial statements), payment of cash dividends, purchases of property, plant and equipment, tax withholdings related to settlements of restricted stock units and the purchases of our shares, partially offset by proceeds from exercises of stock options and purchase rights and net cash provided by operating activities.

[0001032975-19-000007:mdna:144]
As of December 31, 2018, our working capital was $569.5 million, compared to $597.4 million as of March 31, 2018. The decrease was primarily driven by higher accounts payable, higher accruals and lower cash and cash equivalents offset by higher accounts receivable, net and inventories. Our working capital increased by $23.5 million compared to $546.0 million as of December 31, 2017, which was primarily driven by higher accounts receivable, net, inventories and cash and cash equivalents, partially offset by higher accruals.

[0001032975-19-000007:mdna:145]
We had several uncommitted, unsecured bank lines of credit aggregating $79.4 million as of December 31, 2018. There are no financial covenants under these lines of credit with which we must comply. As of December 31, 2018, we had outstanding bank guarantees of $30.1 million under these lines of credit.

[0001032975-19-000007:mdna:146]
The following table summarizes our condensed consolidated statements of cash flows (in thousands):

[0001032975-19-000007:mdna:147]
|  |  | Nine Months EndedDecember 31, |
|  |  | 2018 |  | 2017 |
| Net cash provided by operating activities |  | $ | 273,443 |  |  | $ | 256,084 |  |
| Net cash used in investing activities |  | (165,756 | ) |  | (116,192 | ) |
| Net cash used in financing activities |  | (155,401 | ) |  | (124,214 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (9,745 | ) |  | 1,677 |  |
| Net increase (decrease) in cash and cash equivalents |  | $ | (57,459 | ) |  | $ | 17,355 |  |

[0001032975-19-000007:mdna:148]
The following table presents selected financial information and statistics as of and for the three months ended December 31, 2018 and 2017 (Dollars in thousands):

[0001032975-19-000007:mdna:149]
|  |  | As of December 31, |
|  |  | 2018 |  | 2017 |
| Accounts receivable, net |  | $ | 484,204 |  |  | $ | 351,753 |  |
| Accounts payable |  | $ | 435,764 |  |  | $ | 429,119 |  |
| Inventories |  | $ | 342,031 |  |  | $ | 278,979 |  |

[0001032975-19-000007:mdna:150]
|  |  | Three Months EndedDecember 31, |
|  |  | 2018 |  | 2017 |
| Days sales in accounts receivable (“DSO”) (Days) (1) |  | 50 |  |  | 39 |  |
| Days accounts payable outstanding (“DPO”) (Days) (2) |  | 73 |  |  | 72 |  |
| Inventory turnover (“ITO”) (x)(3) |  | 6.3 |  |  | 7.7 |  |

[0001032975-19-000007:mdna:151]
[same as prior period, unchanged from 0001032975-18-000048:mdna:144]

[0001032975-19-000007:mdna:152]
[same as prior period, unchanged from 0001032975-18-000048:mdna:145]

[0001032975-19-000007:mdna:153]
[same as prior period, unchanged from 0001032975-18-000048:mdna:146]

[0001032975-19-000007:mdna:154]
DSO for the three months ended December 31, 2018 increased by 11 days to 50 days, as compared to 39 days for the same period of the prior fiscal year. The adoption of Topic 606 negatively impacted our DSO for the three months ended December 31, 2018 by 14 days, mainly as a result of changes in the balance sheet presentation of certain reserve balances previously shown net within accounts receivable which are now presented as liabilities. The adoption of Topic 606 did not have an impact over the total cash flows from operating, investing or financing activities. Refer to Note 1 to the condensed consolidated financial statements for the details of the adoption impact of Topic 606. Timing of customer payments and claims also decreased DSO by 3 days.

[0001032975-19-000007:mdna:155]
DPO for the three months ended December 31, 2018 remained constant compared to the same period of the prior fiscal year.

[0001032975-19-000007:mdna:156]
ITO for the three months ended December 31, 2018 was lower, compared to the same period of the prior fiscal year, mainly due to an increase in inventories in the three months ended December 31, 2018, relating to new product introductions, higher inventory balances to support tariff impact mitigation and inventory from the Blue Microphones acquisition.

[0001032975-19-000007:mdna:157]
[same as prior period, unchanged from 0001032975-18-000048:mdna:151]

[0001032975-19-000007:mdna:158]
During the nine months ended December 31, 2018, we generated $273.4 million of cash from operating activities. Our main sources of operating cash flows were net income after adding back non-cash expenses of depreciation, amortization, and share-based compensation expense, and changes in operating assets and liabilities. The increase in accounts receivable, net, excluding the impact from the adoption of Topic 606 at the adoption date was primarily due to higher business volumes, timing of sales and customer payments. The increase in inventories was primarily driven by inventories for new product introductions and higher inventory balances to support tariff impact mitigation. We strategically invested in our inventory ahead of the recent tariff implementation. The increase in accounts payable were primarily driven by the higher inventory purchases. The increase in accrued and current liabilities excluding the impact from the adoption of Topic 606 at the adoption date were primarily driven by higher sales reserve liability due to higher business volumes.

[0001032975-19-000007:mdna:159]
Net cash used in investing activities was $165.8 million, primarily due to the $133.9 million payment of the net cash purchase price for the Blue Microphones Acquisition and $28.3 million of purchases of property, plant and equipment.

[0001032975-19-000007:mdna:160]
Net cash used in financing activities was $155.4 million, primarily for the $114.0 million payment of cash dividend, $22.5 million in repurchases of our registered shares, and $29.1 million tax withholdings related to net share settlements of restricted stock units, partially offset by $10.1 million in proceeds received from exercises of stock options and purchase rights.

[0001032975-19-000007:mdna:161]
During the nine months ended December 31, 2018, there was a $9.7 million loss from currency exchange rate effect on cash and cash equivalents, compared to a gain of $1.7 million during the same period of the prior fiscal year. The loss from currency exchange rate effect during the nine months ended December 31, 2018 was primarily due to the weakening of the Euro and Chinese Renminbi against the U.S. Dollar by 7% and 8%, respectively, during the period. The gain from currency translation exchange effect during the nine months ended December 31, 2017 was primarily due to the strengthening of the Euro against the U.S. Dollar by 12% during the period.

[0001032975-19-000007:mdna:162]
[same as prior period, unchanged from 0001032975-18-000048:mdna:158]

[0001032975-19-000007:mdna:163]
[same as prior period, unchanged from 0001032975-18-000048:mdna:159]

[0001032975-19-000007:mdna:164]
[same as prior period, unchanged from 0001032975-18-000048:mdna:160]

[0001032975-19-000007:mdna:165]
In March 2017, our Board of Directors approved our 2017 share buyback program, which authorizes us to purchase up to $250.0 million of our outstanding shares over a three-year period. The new program was approved by the Swiss Takeover Board in May 2017. Although we enter into trading plans for systematic repurchases (e.g., 10b5-1 trading plans) from time to time, our share buyback program provides us with the opportunity to make repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. As of December 31, 2018, $197.4 million is still available for repurchase under the 2017 share buyback program.

[0001032975-19-000007:mdna:166]
[same as prior period, unchanged from 0001032975-18-000048:mdna:162]

[0001032975-19-000007:mdna:167]
If we do not generate sufficient operating cash flows to support our operations and future planned cash requirements, our operations could be harmed and our access to credit could be restricted or eliminated. However, we believe that the trend of our historical cash flow generation, our projections of future operations and our available cash balances will provide sufficient liquidity to fund our operations for at least the next 12 months.

[0001032975-19-000007:mdna:168]
[same as prior period, unchanged from 0001032975-18-000048:mdna:166]

[0001032975-19-000007:mdna:169]
[same as prior period, unchanged from 0001032975-18-000048:mdna:167]

[0001032975-19-000007:mdna:170]
[same as prior period, unchanged from 0001032975-18-000048:mdna:168]

[0001032975-19-000007:mdna:171]
As of December 31, 2018, we had non-cancelable purchase commitments for inventory purchases made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. Non-cancelable purchase commitments for capital expenditures primarily relate to commitments for tooling for new and existing products, computer hardware, leasehold and improvements. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-19-000007:mdna:172]
[same as prior period, unchanged from 0001032975-18-000048:mdna:170]

[0001032975-19-000007:mdna:173]
[same as prior period, unchanged from 0001032975-18-000048:mdna:171]

[0001032975-19-000007:mdna:174]
[same as prior period, unchanged from 0001032975-18-000048:mdna:172]

[0001032975-19-000007:mdna:175]
[same as prior period, unchanged from 0001032975-18-000048:mdna:173]

[0001032975-19-000007:mdna:176]
[same as prior period, unchanged from 0001032975-18-000048:mdna:174]

[0001032975-19-000007:mdna:177]
Logitech Europe S.A., one of our wholly-owned subsidiaries, guaranteed payments of certain third-party contract manufacturers' purchase obligations. As of December 31, 2018, the maximum amount of this guarantee was $3.8 million.

[0001032975-19-000007:mdna:178]
[same as prior period, unchanged from 0001032975-18-000048:mdna:176]

[0001032975-19-000007:mdna:179]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2018, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-19-000007:mdna:180]
[same as prior period, unchanged from 0001032975-18-000048:mdna:178]

[0001032975-19-000007:mdna:181]
Legal Proceedings

[0001032975-19-000007:mdna:182]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of our business. We are currently subject to several such claims and a small number of legal proceedings. We believe that these matters lack merit and we intend to vigorously defend against them. Based on currently available information, we do not believe that resolution of pending matters will have a material adverse effect on our financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that our defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on our business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against us, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary licenses or other rights, or litigation arising out of intellectual property claims, could adversely affect our business.
