# LOGI 8-K — 0001032975-19-000004 filed 2019-01-22

## item codes, every 8-K on or before 2019-01-24

- 2019-01-22 0001032975-19-000004 — 2.02, 9.01
- 2018-10-23 0001032975-18-000044 — 2.02, 9.01
- 2018-09-07 0001032975-18-000040 — 5.07, 8.01
- 2018-07-31 0001032975-18-000035 — 1.01, 2.02, 2.05, 7.01, 9.01
- 2018-06-27 0001032975-18-000020 — 5.02
- 2018-05-03 0001032975-18-000013 — 2.02, 5.02, 9.01
- 2018-01-23 0001032975-18-000005 — 2.02, 9.01
- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2019-01-24

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-19-000004:8k_2_02:1]
EX-99.1
2
exhibit991q3fy19.htm
EXHIBIT 99.1

[0001032975-19-000004:8k_2_02:2]
Exhibit

[0001032975-19-000004:8k_2_02:3]
Exhibit 99.1

[0001032975-19-000004:8k_2_02:4]
Editorial Contacts:

[0001032975-19-000004:8k_2_02:5]
Ben Lu, Vice President, Investor Relations - USA (510) 713-5568

[0001032975-19-000004:8k_2_02:6]
Krista Todd, Vice President, Global Communications - USA (510) 713-5834

[0001032975-19-000004:8k_2_02:7]
Ben Starkie, Corporate Communications - Europe +41 (0) 79-292-3499

[0001032975-19-000004:8k_2_02:8]
Logitech Delivers Record Q3 Sales, Raises Full-Year Profit Outlook

[0001032975-19-000004:8k_2_02:9]
LAUSANNE, Switzerland - Jan. 22, 2019 and NEWARK, Calif., Jan. 21, 2019 - Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the third quarter of Fiscal Year 2019.

[0001032975-19-000004:8k_2_02:10]
| • | Q3 sales were $864 million, up 6 percent in US dollars and 8 percent in constant currency, compared to Q3 of the prior year. |

[0001032975-19-000004:8k_2_02:11]
| • | Q3 GAAP operating income reached $123 million, compared to $100 million in the same quarter a year ago. Q3 GAAP earnings per share (EPS) grew 40 percent to $0.67, compared to $0.48 in the same quarter a year ago. |

[0001032975-19-000004:8k_2_02:12]
| • | Q3 non-GAAP operating income grew 22 percent to $143 million, compared to $117 million in the same quarter a year ago. Q3 non-GAAP EPS grew 22 percent to $0.79, compared to $0.65 in the same quarter a year ago. |

[0001032975-19-000004:8k_2_02:13]
| • | Year-to-date cash flow from operations was $273 million, compared to $256 million in the same period a year ago. |

[0001032975-19-000004:8k_2_02:14]
“We delivered record sales and profits in our biggest quarter of the year,” said Bracken Darrell, Logitech president and chief executive officer. “Our innovative, diverse portfolio drove double-digit growth across Gaming, Video Collaboration, and Creativity & Productivity. On the back of this powerful performance, we are raising our profit outlook for the year.”

[0001032975-19-000004:8k_2_02:15]
Outlook

[0001032975-19-000004:8k_2_02:16]
Logitech raised its Fiscal Year 2019 profit outlook to between $340 million and $345 million in non-GAAP operating income, up from between $325 million and $335 million, on an annual sales outlook of 9 to 11 percent growth in constant currency.

[0001032975-19-000004:8k_2_02:17]
Prepared Remarks Available Online

[0001032975-19-000004:8k_2_02:18]
Logitech has made its prepared written remarks for the financial results teleconference available online on the Logitech corporate website at http://ir.logitech.com.

[0001032975-19-000004:8k_2_02:19]
Financial Results Teleconference and Webcast

[0001032975-19-000004:8k_2_02:20]
Logitech will hold a financial results teleconference to discuss the results for Q3 FY 2019 on

[0001032975-19-000004:8k_2_02:21]
Tuesday, January 22, 2019 at 8:30 a.m. Eastern Standard Time and 2:30 p.m. Central European Time. A live webcast of the call will be available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-19-000004:8k_2_02:22]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-19-000004:8k_2_02:23]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of intangible assets, purchase accounting effect on inventory, acquisition-related costs, change in fair value of contingent consideration for business acquisition, restructuring charges (credits), loss (gain) on investments in privately held companies, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below. Logitech also presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for Fiscal Year 2019.

[0001032975-19-000004:8k_2_02:24]
About Logitech

[0001032975-19-000004:8k_2_02:25]
Logitech designs products that have an everyday place in people's lives, connecting them to the digital experiences they care about. More than 35 years ago, Logitech started connecting people through computers, and now it’s a multi-brand company designing products that bring people together through music, gaming, video and computing. Brands of Logitech include Logitech, Ultimate Ears, Jaybird, Blue Microphones, ASTRO Gaming and Logitech G. Founded in 1981, and headquartered in Lausanne, Switzerland, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @Logitech.

[0001032975-19-000004:8k_2_02:26]
# # #

[0001032975-19-000004:8k_2_02:27]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-19-000004:8k_2_02:28]
Logitech and other Logitech marks are trademarks or registered trademarks of Logitech Europe S.A and/or its affiliates in the U.S. and other countries.  All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-19-000004:8k_2_02:29]
(LOGIIR)

[0001032975-19-000004:8k_2_02:30]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (A) |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales (B) |  | $ | 864,388 |  |  | $ | 812,021 |  |  | $ | 2,164,014 |  |  | $ | 1,974,437 |  |
| Cost of goods sold |  | 535,707 |  |  | 533,631 |  |  | 1,349,941 |  |  | 1,271,127 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 4,699 |  |  | 2,789 |  |  | 10,037 |  |  | 6,304 |  |
| Gross profit |  | 323,982 |  |  | 275,601 |  |  | 804,036 |  |  | 697,006 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 132,250 |  |  | 116,153 |  |  | 368,635 |  |  | 325,917 |  |
| Research and development |  | 40,591 |  |  | 34,398 |  |  | 119,120 |  |  | 106,144 |  |
| General and administrative |  | 24,496 |  |  | 22,291 |  |  | 75,175 |  |  | 72,966 |  |
| Amortization of intangible assets and acquisition-related costs |  | 3,539 |  |  | 2,496 |  |  | 10,377 |  |  | 6,377 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | — |  |  | — |  |  | (4,908 | ) |
| Restructuring charges (credits), net |  | (278 | ) |  | — |  |  | 9,762 |  |  | (116 | ) |
| Total operating expenses |  | 200,598 |  |  | 175,338 |  |  | 583,069 |  |  | 506,380 |  |
| Operating income |  | 123,384 |  |  | 100,263 |  |  | 220,967 |  |  | 190,626 |  |
| Interest income |  | 1,482 |  |  | 874 |  |  | 5,709 |  |  | 3,097 |  |
| Other expense, net |  | (2,747 | ) |  | (324 | ) |  | (929 | ) |  | (894 | ) |
| Income before income taxes |  | 122,119 |  |  | 100,813 |  |  | 225,747 |  |  | 192,829 |  |
| Provision for income taxes |  | 9,309 |  |  | 20,040 |  |  | 10,295 |  |  | 18,691 |  |
| Net income |  | $ | 112,810 |  |  | $ | 80,773 |  |  | $ | 215,452 |  |  | $ | 174,138 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.68 |  |  | $ | 0.49 |  |  | $ | 1.30 |  |  | $ | 1.06 |  |
| Diluted |  | $ | 0.67 |  |  | $ | 0.48 |  |  | $ | 1.28 |  |  | $ | 1.03 |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 165,707 |  |  | 164,248 |  |  | 165,552 |  |  | 163,924 |  |
| Diluted |  | 168,907 |  |  | 169,079 |  |  | 168,966 |  |  | 168,832 |  |

[0001032975-19-000004:8k_2_02:31]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS * |
| (In thousands) - unaudited |  |  |  |  |
|  |  | December 31, 2018 |  | March 31, 2018 |
| CONDENSED CONSOLIDATED BALANCE SHEETS (A) |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 584,488 |  |  | $ | 641,947 |  |
| Accounts receivable, net (B) |  | 484,204 |  |  | 214,885 |  |
| Inventories |  | 342,031 |  |  | 259,906 |  |
| Other current assets (B) |  | 73,174 |  |  | 56,362 |  |
| Total current assets |  | 1,483,897 |  |  | 1,173,100 |  |
| Non-current assets: |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 81,577 |  |  | 86,304 |  |
| Goodwill |  | 347,369 |  |  | 275,451 |  |
| Other intangible assets, net |  | 123,643 |  |  | 87,547 |  |
| Other assets |  | 129,287 |  |  | 120,755 |  |
| Total assets |  | $ | 2,165,773 |  |  | $ | 1,743,157 |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 435,764 |  |  | $ | 293,988 |  |
| Accrued and other current liabilities (B) |  | 478,632 |  |  | 281,732 |  |
| Total current liabilities |  | 914,396 |  |  | 575,720 |  |
| Non-current liabilities: |  |  |  |  |  |  |
| Income taxes payable |  | 36,245 |  |  | 34,956 |  |
| Other non-current liabilities |  | 83,044 |  |  | 81,924 |  |
| Total liabilities |  | 1,033,685 |  |  | 692,600 |  |
| Shareholders’ equity: |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |
| Issued shares — 173,106 at December 31 and March 31, 2018 |  |  |  |  |
| Additional shares that may be issued out of conditional capitals — 50,000 at December 31 and March 31, 2018 |  |  |  |  |
| Additional shares that may be issued out of authorized capital — 34,621 at December 31, 2018 and none at March 31, 2018 |  |  |  |  |
| Additional paid-in capital |  | 42,250 |  |  | 47,234 |  |
| Shares in treasury, at cost — 7,355 at December 31, 2018 and 8,527 at March 31, 2018 |  | (164,932 | ) |  | (165,686 | ) |
| Retained earnings (B) |  | 1,322,915 |  |  | 1,232,316 |  |
| Accumulated other comprehensive loss |  | (98,293 | ) |  | (93,455 | ) |
| Total shareholders’ equity |  | 1,132,088 |  |  | 1,050,557 |  |
| Total liabilities and shareholders’ equity |  | $ | 2,165,773 |  |  | $ | 1,743,157 |  |

[0001032975-19-000004:8k_2_02:32]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (A) |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 112,810 |  |  | $ | 80,773 |  |  | $ | 215,452 |  |  | $ | 174,138 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  | 10,760 |  |  | 10,850 |  |  | 32,655 |  |  | 30,218 |  |
| Amortization of intangible assets |  | 6,895 |  |  | 4,415 |  |  | 17,236 |  |  | 10,653 |  |
| Gain on investments in privately held companies |  | (207 | ) |  | (114 | ) |  | (589 | ) |  | (550 | ) |
| Share-based compensation expense |  | 11,855 |  |  | 11,556 |  |  | 37,163 |  |  | 33,239 |  |
| Deferred income taxes |  | 93 |  |  | 18,661 |  |  | (9,722 | ) |  | 6,728 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | — |  |  | — |  |  | (4,908 | ) |
| Other |  | (453 | ) |  | (5 | ) |  | (378 | ) |  | 7 |  |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | (25,469 | ) |  | (72,310 | ) |  | (158,944 | ) |  | (164,028 | ) |
| Inventories |  | 15,238 |  |  | 52,386 |  |  | (69,163 | ) |  | (5,692 | ) |
| Other assets |  | (42 | ) |  | (10,463 | ) |  | (11,098 | ) |  | (18,953 | ) |
| Accounts payable |  | (4,529 | ) |  | 41,575 |  |  | 133,657 |  |  | 151,711 |  |
| Accrued and other liabilities |  | 49,272 |  |  | 51,260 |  |  | 87,174 |  |  | 43,521 |  |
| Net cash provided by operating activities |  | 176,223 |  |  | 188,584 |  |  | 273,443 |  |  | 256,084 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (9,936 | ) |  | (10,405 | ) |  | (28,304 | ) |  | (27,593 | ) |
| Investment in privately held companies |  | (2,036 | ) |  | (360 | ) |  | (2,542 | ) |  | (880 | ) |
| Acquisitions, net of cash acquired |  | — |  |  | (3,323 | ) |  | (133,908 | ) |  | (88,323 | ) |
| Proceeds from return of investment in privately held companies |  | — |  |  | — |  |  | — |  |  | 237 |  |
| Purchases of short-term investments |  | — |  |  | — |  |  | (1,505 | ) |  | (6,789 | ) |
| Sales of short-term investments |  | — |  |  | 6,789 |  |  | — |  |  | 6,789 |  |
| Purchases of trading investments |  | (613 | ) |  | (1,843 | ) |  | (4,335 | ) |  | (2,842 | ) |
| Proceeds from sales of trading investments |  | 644 |  |  | 2,152 |  |  | 4,838 |  |  | 3,209 |  |
| Net cash used in investing activities |  | (11,941 | ) |  | (6,990 | ) |  | (165,756 | ) |  | (116,192 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | — |  |  | — |  |  | (113,971 | ) |  | (104,248 | ) |
| Payment of contingent consideration for business acquisition |  | — |  |  | (5,000 | ) |  | — |  |  | (5,000 | ) |
| Purchases of registered shares |  | (2,553 | ) |  | (9,726 | ) |  | (22,454 | ) |  | (20,408 | ) |
| Proceeds from exercises of stock options and purchase rights |  | 128 |  |  | 947 |  |  | 10,135 |  |  | 30,947 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (1,731 | ) |  | (1,799 | ) |  | (29,111 | ) |  | (25,505 | ) |
| Net cash used in financing activities |  | (4,156 | ) |  | (15,578 | ) |  | (155,401 | ) |  | (124,214 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (588 | ) |  | 24 |  |  | (9,745 | ) |  | 1,677 |  |
| Net increase (decrease) in cash and cash equivalents |  | 159,538 |  |  | 166,040 |  |  | (57,459 | ) |  | 17,355 |  |
| Cash and cash equivalents, beginning of the period |  | 424,950 |  |  | 398,848 |  |  | 641,947 |  |  | 547,533 |  |
| Cash and cash equivalents, end of the period |  | $ | 584,488 |  |  | $ | 564,888 |  |  | $ | 584,488 |  |  | $ | 564,888 |  |

[0001032975-19-000004:8k_2_02:33]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |  |  |
| NET SALES |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Net sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Pointing Devices |  | $ | 149,123 |  |  | $ | 140,983 |  |  | 6 | % |  | 405,250 |  |  | 386,700 |  |  | 5 | % |
| Keyboards & Combos |  | 144,169 |  |  | 126,372 |  |  | 14 |  |  | 404,263 |  |  | 361,685 |  |  | 12 |  |
| PC Webcams |  | 33,021 |  |  | 27,280 |  |  | 21 |  |  | 90,916 |  |  | 80,370 |  |  | 13 |  |
| Tablet & Other Accessories |  | 35,757 |  |  | 26,648 |  |  | 34 |  |  | 104,903 |  |  | 80,650 |  |  | 30 |  |
| Video Collaboration |  | 74,186 |  |  | 46,252 |  |  | 60 |  |  | 190,154 |  |  | 128,008 |  |  | 49 |  |
| Mobile Speakers |  | 96,263 |  |  | 147,377 |  |  | (35 | ) |  | 207,690 |  |  | 300,843 |  |  | (31 | ) |
| Audio & Wearables |  | 98,629 |  |  | 84,435 |  |  | 17 |  |  | 212,343 |  |  | 197,083 |  |  | 8 |  |
| Gaming |  | 213,663 |  |  | 173,802 |  |  | 23 |  |  | 510,481 |  |  | 365,232 |  |  | 40 |  |
| Smart Home |  | 19,577 |  |  | 38,692 |  |  | (49 | ) |  | 37,829 |  |  | 73,481 |  |  | (49 | ) |
| Other (1) |  | — |  |  | 180 |  |  | (100 | ) |  | 185 |  |  | 385 |  |  | (52 | ) |
| Total net sales |  | $ | 864,388 |  |  | $ | 812,021 |  |  | 6 | % |  | $ | 2,164,014 |  |  | $ | 1,974,437 |  |  | 10 | % |

[0001032975-19-000004:8k_2_02:34]
(1) Other category includes products that we currently intend to transition out of, or have already transitioned out of, because they are no longer strategic to our business.

[0001032975-19-000004:8k_2_02:35]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |  |  |  |  |
| GAAP TO NON-GAAP RECONCILIATION (A)(C) |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Gross profit - GAAP |  | $ | 323,982 |  |  | $ | 275,601 |  |  | $ | 804,036 |  |  | $ | 697,006 |  |
| Share-based compensation expense |  | 953 |  |  | 960 |  |  | 2,874 |  |  | 2,762 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 4,699 |  |  | 2,789 |  |  | 10,037 |  |  | 6,304 |  |
| Gross profit - Non-GAAP |  | $ | 329,634 |  |  | $ | 279,350 |  |  | $ | 816,947 |  |  | $ | 706,072 |  |
| Gross margin - GAAP |  | 37.5 | % |  | 33.9 | % |  | 37.2 | % |  | 35.3 | % |
| Gross margin - Non-GAAP |  | 38.1 | % |  | 34.4 | % |  | 37.8 | % |  | 35.8 | % |
| Operating expenses - GAAP |  | $ | 200,598 |  |  | $ | 175,338 |  |  | $ | 583,069 |  |  | $ | 506,380 |  |
| Less: Share-based compensation expense |  | 10,902 |  |  | 10,596 |  |  | 34,289 |  |  | 30,477 |  |
| Less: Amortization of intangible assets and acquisition-related costs |  | 3,539 |  |  | 2,496 |  |  | 10,377 |  |  | 6,377 |  |
| Less: Change in fair value of contingent consideration for business acquisition |  | — |  |  | — |  |  | — |  |  | (4,908 | ) |
| Less: Restructuring charges (credits), net |  | (278 | ) |  | — |  |  | 9,762 |  |  | (116 | ) |
| Operating expenses - Non-GAAP |  | $ | 186,435 |  |  | $ | 162,246 |  |  | $ | 528,641 |  |  | $ | 474,550 |  |
| % of net sales - GAAP |  | 23.2 | % |  | 21.6 | % |  | 26.9 | % |  | 25.6 | % |
| % of net sales - Non - GAAP |  | 21.6 | % |  | 20.0 | % |  | 24.4 | % |  | 24.0 | % |
| Operating income - GAAP |  | $ | 123,384 |  |  | $ | 100,263 |  |  | $ | 220,967 |  |  | $ | 190,626 |  |
| Share-based compensation expense |  | 11,855 |  |  | 11,556 |  |  | 37,163 |  |  | 33,239 |  |
| Amortization of intangible assets |  | 6,895 |  |  | 4,415 |  |  | 17,236 |  |  | 10,653 |  |
| Purchase accounting effect on inventory |  | 1,343 |  |  | 500 |  |  | 1,722 |  |  | 614 |  |
| Acquisition-related costs |  | — |  |  | 370 |  |  | 1,456 |  |  | 1,412 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | — |  |  | — |  |  | (4,908 | ) |
| Restructuring charges (credits), net |  | (278 | ) |  | — |  |  | 9,762 |  |  | (116 | ) |
| Operating income - Non - GAAP |  | $ | 143,199 |  |  | $ | 117,104 |  |  | $ | 288,306 |  |  | $ | 231,520 |  |
| % of net sales - GAAP |  | 14.3 | % |  | 12.3 | % |  | 10.2 | % |  | 9.7 | % |
| % of net sales - Non - GAAP |  | 16.6 | % |  | 14.4 | % |  | 13.3 | % |  | 11.7 | % |
| Net income - GAAP |  | $ | 112,810 |  |  | $ | 80,773 |  |  | $ | 215,452 |  |  | $ | 174,138 |  |
| Share-based compensation expense |  | 11,855 |  |  | 11,556 |  |  | 37,163 |  |  | 33,239 |  |
| Amortization of intangible assets |  | 6,895 |  |  | 4,415 |  |  | 17,236 |  |  | 10,653 |  |
| Purchase accounting effect on inventory |  | 1,343 |  |  | 500 |  |  | 1,722 |  |  | 614 |  |
| Acquisition-related costs |  | — |  |  | 370 |  |  | 1,456 |  |  | 1,412 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | — |  |  | — |  |  | (4,908 | ) |
| Restructuring charges (credits), net |  | (278 | ) |  | — |  |  | 9,762 |  |  | (116 | ) |
| Loss (gain) on investments in privately held companies |  | (207 | ) |  | (114 | ) |  | (589 | ) |  | (550 | ) |
| Non-GAAP income tax adjustment |  | 1,443 |  |  | 13,015 |  |  | (7,782 | ) |  | 2,033 |  |
| Net income - Non - GAAP |  | $ | 133,861 |  |  | $ | 110,515 |  |  | $ | 274,420 |  |  | $ | 216,515 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.67 |  |  | $ | 0.48 |  |  | $ | 1.28 |  |  | $ | 1.03 |  |
| Diluted - Non - GAAP |  | $ | 0.79 |  |  | $ | 0.65 |  |  | $ | 1.62 |  |  | $ | 1.28 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non - GAAP |  | 168,907 |  |  | 169,079 |  |  | 168,966 |  |  | 168,832 |  |

[0001032975-19-000004:8k_2_02:36]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
| SHARE-BASED COMPENSATION EXPENSE |  | Three Months Ended |  | Nine Months Ended |
|  |  | December 31, |  | December 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 953 |  |  | $ | 960 |  |  | $ | 2,874 |  |  | $ | 2,762 |  |
| Marketing and selling |  | 4,600 |  |  | 4,624 |  |  | 15,250 |  |  | 13,348 |  |
| Research and development |  | 1,811 |  |  | 1,621 |  |  | 5,295 |  |  | 4,797 |  |
| General and administrative |  | 4,491 |  |  | 4,351 |  |  | 13,744 |  |  | 12,332 |  |
| Total share-based compensation expense |  | 11,855 |  |  | 11,556 |  |  | 37,163 |  |  | 33,239 |  |
| Income tax provision (benefit) |  | (2,397 | ) |  | 3,038 |  |  | (14,576 | ) |  | (11,921 | ) |
| Total share-based compensation expense, net of income tax provision (benefit) |  | $ | 9,458 |  |  | $ | 14,594 |  |  | $ | 22,587 |  |  | $ | 21,318 |  |

[0001032975-19-000004:8k_2_02:37]
*  Note: These preliminary results for the three and nine months ended December 31, 2018 are subject to adjustments, including subsequent events that may occur through the date of filing our Quarterly Report on Form 10-Q.

[0001032975-19-000004:8k_2_02:38]
(A) Preliminary valuation from the business acquisition

[0001032975-19-000004:8k_2_02:39]
The preliminary fair value of assets acquired and liabilities assumed from the business acquisition in the second quarter of fiscal year 2019 is included in the tables. The fair value of identifiable intangible assets acquired was based on estimates and assumptions made by us at the time of the acquisition. As additional information becomes available, such as the finalization of the estimated fair value of the assets acquired and liabilities assumed, we may revise our preliminary or interim estimated fair value of the assets acquired and liabilities assumed during the remainder of the measurement periods (which will not exceed 12 months from the acquisition dates). Any such revisions or changes may be material, and may have a material impact over our financial condition and results of operations.

[0001032975-19-000004:8k_2_02:40]
(B) Adoption of ASC Topic 606

[0001032975-19-000004:8k_2_02:41]
On April 1, 2018, we adopted the new revenue standards under Accounting Standards Codification ("ASC") Topic 606. The adoption of Topic 606 did not have an impact over the total cash flows from operating, investing, or financing activities. The following tables summarize the impacts of adopting Topic 606 on our condensed consolidated statements of operations for the three and nine months ended as of December 31, 2018 and condensed consolidated balance sheets as of December 31, 2018 (in thousands):

[0001032975-19-000004:8k_2_02:42]
|  | Three Months Ended December 31, 2018 |  | Nine Months Ended December 31, 2018 |
|  | As Reported Under Topic 606 | If Reported Under Topic 605 | Effect of Change |  | As Reported Under Topic 606 | If Reported Under Topic 605 | Effect of Change |
| Net sales | $ | 864,388 |  | $ | 853,563 |  | $ | 10,825 |  |  | $ | 2,164,014 |  | $ | 2,158,267 |  | $ | 5,747 |  |

[0001032975-19-000004:8k_2_02:43]
|  |  | As of December 31, 2018 |
|  |  | As Reported Under Topic 606 |  | Balance Under Topic 605 |  | Effect of Change |
| Accounts receivable, net |  | 484,204 |  |  | 345,055 |  |  | 139,149 |  |
| Other current assets |  | 73,174 |  |  | 65,758 |  |  | 7,416 |  |
| Accrued and other current liabilities |  | 478,632 |  |  | 326,932 |  |  | 151,700 |  |
| Retained earnings |  | 1,322,915 |  |  | 1,328,050 |  |  | (5,135 | ) |

[0001032975-19-000004:8k_2_02:44]
(C) Non-GAAP Financial Measures

[0001032975-19-000004:8k_2_02:45]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in

[0001032975-19-000004:8k_2_02:46]
assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-19-000004:8k_2_02:47]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended December 31, 2018 and previous periods, we excluded items in the following general categories, each of which are described below:

[0001032975-19-000004:8k_2_02:48]
Share-based compensation expenses. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-19-000004:8k_2_02:49]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit, operating expenses, and financial results from period to period.

[0001032975-19-000004:8k_2_02:50]
Purchase accounting effect on inventory. Business combination accounting principles require us to measure acquired inventory at fair value. The fair value of inventory reflects the acquired company’s cost of manufacturing plus a portion of the expected profit margin. The non-GAAP adjustment excludes the expected profit margin component that is recorded under business combination accounting principles associated with our business acquisitions. We believe the adjustment is useful to investors because such charges are not reflective of our ongoing operations.

[0001032975-19-000004:8k_2_02:51]
Acquisition-related costs and change in fair value of contingent consideration for business acquisition.  We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition related costs include all incremental expenses incurred to effect a business combination. Fair value of contingent consideration is associated with our estimates of the value of earn-outs in connection with certain acquisitions. We believe that providing the non-GAAP measures excluding these costs and credits, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-19-000004:8k_2_02:52]
Restructuring charges (credits). These expenses are associated with re-aligning our business strategies based on current economic conditions. We have undertaken several restructuring plans in recent years. In connection with our restructuring initiatives, we incurred restructuring charges related to employee terminations, facility closures and early cancellation of certain contracts. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results in the current period.

[0001032975-19-000004:8k_2_02:53]
Loss (gain) on investments in privately held companies. We recognized loss (gain) related to our investments in various privately-held companies, which varies depending on the operational and financial performance of the privately-held companies in which we invested. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-19-000004:8k_2_02:54]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above and other events; the determination of which is based upon the nature of the underlying items, the mix of income and losses in jurisdictions and the relevant tax rates in which we operate.

[0001032975-19-000004:8k_2_02:55]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-

[0001032975-19-000004:8k_2_02:56]
GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-19-000004:8k_2_02:57]
Additional Supplemental Financial Information - Constant Currency

[0001032975-19-000004:8k_2_02:58]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.
