# LOGI 8-K — 0001032975-16-000092 filed 2016-07-28

## item codes, every 8-K on or before 2016-07-29

- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2016-07-29

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-16-000092:8k_2_02:1]
EX-99.1
2
exhibit991q1fy17.htm
EXHIBIT 99.1

[0001032975-16-000092:8k_2_02:2]
Exhibit

[0001032975-16-000092:8k_2_02:3]
Exhibit 99.1

[0001032975-16-000092:8k_2_02:4]
Editorial Contacts:

[0001032975-16-000092:8k_2_02:5]
Ben Lu, Vice President, Investor Relations - USA (510) 713-5568

[0001032975-16-000092:8k_2_02:6]
Krista Todd, Vice President, External Communications - USA (510) 713-5834

[0001032975-16-000092:8k_2_02:7]
Ben Starkie, Corporate Communications - Europe +41 (0) 79-292-3499

[0001032975-16-000092:8k_2_02:8]
Logitech Accelerates with Best Retail Sales Growth in Over Five Years, Up 13%

[0001032975-16-000092:8k_2_02:9]
Company Raises Sales and Profit Outlook Following Better-Than-Expected Q1

[0001032975-16-000092:8k_2_02:10]
NEWARK, Calif. – July 27, 2016 and LAUSANNE, Switzerland, July 28, 2016 – Logitech International (SIX: LOGN) (Nasdaq: LOGI) today raised its outlook for sales and operating income following better-than-expected financial results for the first quarter of Fiscal Year 2017.

[0001032975-16-000092:8k_2_02:11]
| • | Q1 sales were $480 million, up 7 percent compared to Q1 of the prior year. Q1 retail sales grew 13 percent in constant currency, the highest quarterly growth in over five years. |

[0001032975-16-000092:8k_2_02:12]
| • | Q1 GAAP operating income almost doubled at $26 million compared to $14 million a year ago. Q1 GAAP earnings per share (EPS) from continuing operations were $0.13, compared to $0.08 in the same quarter a year ago. |

[0001032975-16-000092:8k_2_02:13]
| • | Q1 non-GAAP operating income was $38 million compared to $36 million a year ago, with non-GAAP EPS of $0.20, compared to $0.19 in the same quarter a year ago. |

[0001032975-16-000092:8k_2_02:14]
| • | Cash flow from operations in the quarter was $14 million, compared to a negative cash flow of $26 million a year ago. |

[0001032975-16-000092:8k_2_02:15]
"Our strategy is working, delivering 13 percent retail sales growth this quarter – our best in the last five years,” said Bracken Darrell, Logitech president and chief executive officer. “Our growth was better-than-expected and broad-based across regions and product categories. Virtually all our sales were in growing product categories and we grew in all our market opportunities – Creativity & Productivity, Gaming, Video Collaboration, Music, and Home – most in double digits. It’s a great start to the new year and gives us the confidence to raise our outlook."

[0001032975-16-000092:8k_2_02:16]
Outlook

[0001032975-16-000092:8k_2_02:17]
Logitech raised its FY 2017 outlook to 8 to 10 percent retail sales growth in constant currency, up from its previous forecast of growth in the mid-single digits. The Company also increased its non-GAAP operating income outlook for FY 2017 to between $195 million and $205 million, up from $185 million to $200 million.

[0001032975-16-000092:8k_2_02:18]
Prepared Remarks Available Online

[0001032975-16-000092:8k_2_02:19]
Logitech has made its prepared written remarks for the financial results teleconference available online on the Logitech corporate website at http://ir.logitech.com.

[0001032975-16-000092:8k_2_02:20]
Financial Results Teleconference and Webcast

[0001032975-16-000092:8k_2_02:21]
Logitech will hold a financial results teleconference to discuss the results for Q1 FY 2017 on Thurs., July 28, 2016 at 8:30 a.m. Eastern Daylight Time and 2:30 p.m. Central European Summer Time. A live webcast of the call will be available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-16-000092:8k_2_02:22]
Annual Report and Other Information

[0001032975-16-000092:8k_2_02:23]
Logitech has posted its Invitation, Proxy Statement and Annual Report for the 2016 Annual General Meeting (AGM) on its website at http://ir.logitech.com.

[0001032975-16-000092:8k_2_02:24]
Continued Operations

[0001032975-16-000092:8k_2_02:25]
Logitech separated its Lifesize division from the Company on Dec. 28, 2015. Except as otherwise noted, all of the results reported in this press release as well as comparisons between periods are focused on results from continuing operations and do not address the performance of Lifesize, which is now reported in the Company’s financial statements under discontinued operations or total Logitech including discontinued operations. For more information on the impact of the Lifesize separation on Logitech’s historical results, please refer to the Financial Reporting section of Logitech’s Financial History, available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-16-000092:8k_2_02:26]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-16-000092:8k_2_02:27]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of intangible assets, purchase accounting effect on inventory, acquisition-related costs, restructuring charges (credits), gain (loss) on equity-method investment, investigation and related expenses, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below. Logitech also presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance and trends in its business. With respect to the Company’s outlook for non-GAAP operating income,

[0001032975-16-000092:8k_2_02:28]
most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for Fiscal Year 2017.

[0001032975-16-000092:8k_2_02:29]
About Logitech

[0001032975-16-000092:8k_2_02:30]
Logitech designs products that have an everyday place in people's lives, connecting them to the digital experiences they care about. Over 30 years ago Logitech started connecting people through computers, and now it’s designing products that bring people together through music, gaming, video and computing. Founded in 1981, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @Logitech.

[0001032975-16-000092:8k_2_02:31]
# # #

[0001032975-16-000092:8k_2_02:32]
regarding: our strategy and our outlook for Fiscal Year 2017 operating income and sales growth. The forward-looking statements in this release involve risks and uncertainties that could cause Logitech’s actual results and events to differ materially from those anticipated in these forward-looking statements, including, without limitation: if our product offerings, marketing activities and investment prioritization decisions do not result in the sales, profitability or profitability growth we expect, or when we expect it; the demand of our customers and our consumers for our products and our ability to accurately forecast it; if we fail to innovate and develop new products in a timely and cost-effective manner for our new and existing product categories; if we do not successfully execute on our growth opportunities or our growth opportunities are more limited than we expect; if sales of PC peripherals are less than we expect; the effect of pricing, product, marketing and other initiatives by our competitors, and our reaction to them, on our sales, gross margins and profitability; if our products and marketing strategies fail to separate our products from competitors’ products; if we do not fully realize our goals to lower our costs and improve our operating leverage; if there is a deterioration of business and economic conditions in one or more of our sales regions or product categories, or significant fluctuations in exchange rates. A detailed discussion of these and other risks and uncertainties that could cause actual results and events to differ materially from such forward-looking statements is included in Logitech’s periodic filings with the Securities and Exchange Commission, including our Annual Report on Form 10-K for the fiscal year ended March 31, 2016, available at www.sec.gov, under the caption Risk Factors and elsewhere. Logitech does not undertake any obligation to update any forward-looking statements to reflect new information or events or circumstances occurring after the date of this press release.

[0001032975-16-000092:8k_2_02:33]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-16-000092:8k_2_02:34]
2016 Logitech, Logicool, Logi and other Logitech marks are owned by Logitech and may be registered. All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-16-000092:8k_2_02:35]
(LOGIIR)

[0001032975-16-000092:8k_2_02:36]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |
|  |  | Three Months Ended |
|  |  | June 30, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (A) |  | 2016 |  | 2015 |
| Net sales |  | $ | 479,864 |  |  | $ | 447,686 |  |
| Cost of goods sold |  | 309,625 |  |  | 289,753 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 1,613 |  |  | — |  |
| Gross profit |  | 168,626 |  |  | 157,933 |  |
| Operating expenses: |  |  |  |  |
| Marketing and selling |  | 83,872 |  |  | 75,796 |  |
| Research and development |  | 31,951 |  |  | 28,002 |  |
| General and administrative |  | 25,740 |  |  | 28,812 |  |
| Amortization of intangible assets and acquisition-related costs |  | 1,293 |  |  | 168 |  |
| Restructuring charges (credits), net |  | (85 | ) |  | 11,538 |  |
| Total operating expenses |  | 142,771 |  |  | 144,316 |  |
| Operating income |  | 25,855 |  |  | 13,617 |  |
| Interest income, net |  | 151 |  |  | 255 |  |
| Other expense, net |  | (1,008 | ) |  | (1,019 | ) |
| Income before income taxes |  | 24,998 |  |  | 12,853 |  |
| Provision for (benefit from) income taxes |  | 3,057 |  |  | (7 | ) |
| Net income from continuing operations |  | 21,941 |  |  | 12,860 |  |
| Loss from discontinued operations, net of taxes |  | — |  |  | (5,423 | ) |
| Net income |  | $ | 21,941 |  |  | $ | 7,437 |  |
| Net income (loss) per share - basic: |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.14 |  |  | $ | 0.08 |  |
| Discontinued operations |  | — |  |  | (0.03 | ) |
| Net income per share - basic |  | $ | 0.14 |  |  | $ | 0.05 |  |
| Net income (loss) per share - diluted: |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.13 |  |  | $ | 0.08 |  |
| Discontinued operations |  | — |  |  | (0.04 | ) |
| Net income per share - diluted |  | $ | 0.13 |  |  | $ | 0.04 |  |
| Weighted average shares used to compute net income (loss) per share: |  |  |  |  |  |  |
| Basic |  | 162,130 |  |  | 164,431 |  |
| Diluted |  | 164,303 |  |  | 166,895 |  |

[0001032975-16-000092:8k_2_02:37]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |
|  |  | June 30, |  | March 31, |
| CONDENSED CONSOLIDATED BALANCE SHEETS (A) |  | 2016 |  | 2016 |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 440,111 |  |  | $ | 519,195 |  |
| Accounts receivable, net |  | 192,242 |  |  | 142,778 |  |
| Inventories |  | 247,792 |  |  | 228,786 |  |
| Other current assets |  | 36,533 |  |  | 35,488 |  |
| Total current assets |  | 916,678 |  |  | 926,247 |  |
| Non-current assets: |  |  |  |  |
| Property, plant and equipment, net |  | 87,044 |  |  | 92,860 |  |
| Goodwill |  | 244,880 |  |  | 218,224 |  |
| Other intangible assets |  | 49,262 |  |  | — |  |
| Other assets |  | 87,090 |  |  | 86,816 |  |
| Total assets |  | $ | 1,384,954 |  |  | $ | 1,324,147 |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 292,664 |  |  | $ | 241,166 |  |
| Accrued and other current liabilities |  | 167,317 |  |  | 173,764 |  |
| Total current liabilities |  | 459,981 |  |  | 414,930 |  |
| Non-current liabilities: |  |  |  |  |  |  |
| Income taxes payable |  | 59,720 |  |  | 59,734 |  |
| Other non-current liabilities |  | 106,333 |  |  | 89,535 |  |
| Total liabilities |  | 626,034 |  |  | 564,199 |  |
| Shareholders' equity: |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |
| Issued and authorized shares—173,106 at June 30, 2016 and March 31, 2016 |  |  |  |  |
| Conditionally authorized shares—50,000 at June 30, 2016 and March 31, 2016 |  |  |  |  |
| Additional paid-in capital |  | — |  |  | 6,616 |  |
| Less shares in treasury, at cost—11,374 at June 30, 2016 and 10,697 at March 31, 2016 |  | (144,663 | ) |  | (128,407 | ) |
| Retained earnings |  | 983,268 |  |  | 963,576 |  |
| Accumulated other comprehensive loss |  | (109,833 | ) |  | (111,985 | ) |
| Total shareholders' equity |  | 758,920 |  |  | 759,948 |  |
| Total liabilities and shareholders' equity |  | $ | 1,384,954 |  |  | $ | 1,324,147 |  |

[0001032975-16-000092:8k_2_02:38]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |
|  |  | Three Months Ended |
|  |  | June 30, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (A) |  | 2016 |  | 2015 |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net income |  | $ | 21,941 |  |  | $ | 7,437 |  |
| Non-cash items included in net income: |  |  |  |  |
| Depreciation |  | 13,105 |  |  | 10,516 |  |
| Amortization of intangible assets |  | 1,708 |  |  | 732 |  |
| Loss (gain) on equity-method investment |  | (1 | ) |  | 103 |  |
| Share-based compensation expense |  | 8,517 |  |  | 6,749 |  |
| Excess tax benefits from share-based compensation |  | (3,280 | ) |  | (665 | ) |
| Deferred income taxes |  | (1,048 | ) |  | (6,732 | ) |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |
| Accounts receivable, net |  | (48,661 | ) |  | (41,208 | ) |
| Inventories |  | (10,007 | ) |  | (54,164 | ) |
| Other assets |  | (1,171 | ) |  | (2,383 | ) |
| Accounts payable |  | 42,769 |  |  | 34,541 |  |
| Accrued and other liabilities |  | (10,135 | ) |  | 19,475 |  |
| Net cash provided by (used in) operating activities |  | 13,737 |  |  | (25,599 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (7,420 | ) |  | (15,290 | ) |
| Investment in privately held companies |  | (320 | ) |  | (240 | ) |
| Acquisition, net of cash acquired |  | (53,987 | ) |  | — |  |
| Purchase of other intangible asset |  | (715 | ) |  | — |  |
| Release of restricted cash |  | 715 |  |  | — |  |
| Purchase of trading investments |  | (4,229 | ) |  | (903 | ) |
| Proceeds from sales of trading investments |  | 4,231 |  |  | 840 |  |
| Net cash used in investing activities |  | (61,725 | ) |  | (15,593 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Purchases of treasury shares |  | (24,422 | ) |  | (8,814 | ) |
| Proceeds from sales of shares upon exercise of options and purchase rights |  | 599 |  |  | 4,066 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (9,185 | ) |  | (1,296 | ) |
| Excess tax benefits from share-based compensation |  | 3,280 |  |  | 665 |  |
| Net cash used in financing activities |  | (29,728 | ) |  | (5,379 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (1,368 | ) |  | 1,761 |  |
| Net decrease in cash and cash equivalents |  | (79,084 | ) |  | (44,810 | ) |
| Cash and cash equivalents, beginning of the period |  | 519,195 |  |  | 537,038 |  |
| Cash and cash equivalents, end of the period |  | $ | 440,111 |  |  | $ | 492,228 |  |
| Non-cash investing activities: |  |  |  |  |  |  |
| Property, plant and equipment purchased during the period and included in period end liability accounts |  | $ | 3,502 |  |  | $ | 10,358 |  |
| The following amounts reflected in the statements of cash flows are included in discontinued operations: |
| Depreciation |  | $ | — |  |  | $ | 705 |  |
| Amortization of other intangible assets |  | $ | — |  |  | $ | 564 |  |
| Share-based compensation expense |  | $ | — |  |  | $ | 226 |  |
| Purchases of property, plant and equipment |  | $ | — |  |  | $ | 385 |  |
| Cash and cash equivalents, beginning of the period |  | $ | — |  |  | $ | 3,659 |  |
| Cash and cash equivalents, end of the period |  | $ | — |  |  | $ | 1,911 |  |

[0001032975-16-000092:8k_2_02:39]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |
| NET SALES |  | Three Months Ended |
|  |  | June 30, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2016 |  | 2015 |  | Change |
| Net sales by channel: |  |  |  |  |  |  |
| Retail |  | $ | 479,864 |  |  | $ | 425,388 |  |  | 13 | % |
| OEM |  | — |  |  | 22,298 |  |  | (100 | ) |
| Total net sales |  | $ | 479,864 |  |  | $ | 447,686 |  |  | 7 |  |
| Net retail sales by product category: |  |  |  |  |  |  |
| Mobile Speakers |  | $ | 57,296 |  |  | $ | 40,544 |  |  | 41 | % |
| Audio-PC & Wearables |  | 56,579 |  |  | 45,699 |  |  | 24 |  |
| Gaming |  | 56,500 |  |  | 43,670 |  |  | 29 |  |
| Video Collaboration |  | 23,910 |  |  | 21,176 |  |  | 13 |  |
| Home Control |  | 11,167 |  |  | 10,254 |  |  | 9 |  |
| Pointing Devices |  | 116,783 |  |  | 116,985 |  |  | — |  |
| Keyboards & Combos |  | 118,019 |  |  | 105,829 |  |  | 12 |  |
| Tablet & Other Accessories |  | 13,885 |  |  | 18,809 |  |  | (26 | ) |
| PC Webcams |  | 25,262 |  |  | 21,681 |  |  | 17 |  |
| Other (*) |  | 463 |  |  | 741 |  |  | (38 | ) |
| Total net retail sales |  | $ | 479,864 |  |  | $ | 425,388 |  |  | 13 |  |
| __________________ |  |  |  |  |  |  |

[0001032975-16-000092:8k_2_02:40]
* Other category includes products that we currently intend to transition out of, or have already transitioned out of, because they are no longer strategic to our business.

[0001032975-16-000092:8k_2_02:41]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |
| GAAP TO NON GAAP RECONCILIATION (A) (B) |  | Three Months Ended |
|  |  | June 30, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2016 |  | 2015 |
| Gross profit - GAAP |  | $ | 168,626 |  |  | $ | 157,933 |  |
| Share-based compensation expense |  | 675 |  |  | 605 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 1,613 |  |  | — |  |
| Gross profit - Non-GAAP |  | $ | 170,914 |  |  | $ | 158,538 |  |
| Gross margin - GAAP |  | 35.1 | % |  | 35.3 | % |
| Gross margin - Non-GAAP |  | 35.6 | % |  | 35.4 | % |
| Operating expenses - GAAP |  | $ | 142,771 |  |  | $ | 144,316 |  |
| Less: Share-based compensation expense |  | 7,842 |  |  | 5,911 |  |
| Less: Amortization of intangible assets and acquisition-related costs |  | 1,293 |  |  | 168 |  |
| Less: Restructuring charges (credits), net |  | (85 | ) |  | 11,538 |  |
| Less: Investigation and related expenses |  | 612 |  |  | 4,049 |  |
| Operating expenses - Non-GAAP |  | $ | 133,109 |  |  | $ | 122,650 |  |
| % of net sales - GAAP |  | 29.8 | % |  | 32.2 | % |
| % of net sales - Non - GAAP |  | 27.7 | % |  | 27.4 | % |
| Operating income - GAAP |  | $ | 25,855 |  |  | $ | 13,617 |  |
| Share-based compensation expense |  | 8,517 |  |  | 6,516 |  |
| Amortization of intangible assets |  | 1,708 |  |  | 168 |  |
| Purchase accounting effect on inventory |  | 703 |  |  | — |  |
| Acquisition-related costs |  | 495 |  |  | — |  |
| Restructuring charges (credits), net |  | (85 | ) |  | 11,538 |  |
| Investigation and related expenses |  | 612 |  |  | 4,049 |  |
| Operating income - Non - GAAP |  | $ | 37,805 |  |  | $ | 35,888 |  |
| % of net sales - GAAP |  | 5.4 | % |  | 3.0 | % |
| % of net sales - Non - GAAP |  | 7.9 | % |  | 8.0 | % |
| Net income from continuing operations - GAAP |  | $ | 21,941 |  |  | $ | 12,860 |  |
| Share-based compensation expense |  | 8,517 |  |  | 6,516 |  |
| Amortization of intangible assets |  | 1,708 |  |  | 168 |  |
| Purchase accounting effect on inventory |  | 703 |  |  | — |  |
| Acquisition-related costs |  | 495 |  |  | — |  |
| Restructuring charges (credits), net |  | (85 | ) |  | 11,538 |  |
| Investigation and related expenses |  | 612 |  |  | 4,049 |  |
| Loss (gain) on equity-method investment |  | (1 | ) |  | 103 |  |
| Non-GAAP income tax adjustment |  | (675 | ) |  | (3,829 | ) |
| Net income from continuing operations - Non - GAAP |  | $ | 33,215 |  |  | $ | 31,405 |  |
| Net income from continuing operations per share: |  |  |  |  |
| Diluted - GAAP |  | $ | 0.13 |  |  | $ | 0.08 |  |
| Diluted - Non - GAAP |  | $ | 0.20 |  |  | $ | 0.19 |  |
| Shares used to compute net income per share: |  |  |  |  |
| Diluted - GAAP and Non - GAAP |  | 164,303 |  |  | 166,895 |  |

[0001032975-16-000092:8k_2_02:42]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |
| SHARE-BASED COMPENSATION EXPENSE |  | Three Months Ended |
|  |  | June 30, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2016 |  | 2015 |
| Share-based Compensation Expense |  |  |  |  |
| Cost of goods sold |  | $ | 675 |  |  | $ | 605 |  |
| Marketing and selling |  | 3,437 |  |  | 2,064 |  |
| Research and development |  | 914 |  |  | 673 |  |
| General and administrative |  | 3,491 |  |  | 3,174 |  |
| Restructuring |  | — |  |  | 7 |  |
| Income tax benefit |  | (1,815 | ) |  | (1,337 | ) |
| Total share-based compensation expense, net of income taxes |  | $ | 6,702 |  |  | $ | 5,186 |  |
| __________________ |  |  |  |  |

[0001032975-16-000092:8k_2_02:43]
(A) Preliminary valuation from the business combination

[0001032975-16-000092:8k_2_02:44]
The preliminary purchase price allocation from the business combination during the current period is included in the tables. The fair value of identifiable intangible assets acquired was based on estimates and assumptions made by us at the time of acquisition. As additional information becomes available, such as finalization of the estimated fair value of the assets acquired and liabilities assumed and the fair value of contingent consideration, we may further revise our preliminary purchase price allocation during the remainder of the measurement period (which will not exceed 12 months from the acquisition date). Any such revisions or changes may be material as we finalize the fair values of the tangible and intangible assets acquired and liabilities assumed.

[0001032975-16-000092:8k_2_02:45]
(B) Non-GAAP Financial Measures

[0001032975-16-000092:8k_2_02:46]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-16-000092:8k_2_02:47]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended June 30, 2016, we excluded items in the following general categories, each of which are described below:

[0001032975-16-000092:8k_2_02:48]
Share-based compensation expenses. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-16-000092:8k_2_02:49]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the

[0001032975-16-000092:8k_2_02:50]
GAAP measures, provides additional insight when comparing our operating expenses and financial results from period to period.

[0001032975-16-000092:8k_2_02:51]
Purchase accounting effect on inventory. Business combination accounting principles require us to measure acquired inventory at fair value. The fair value of inventory reflects the acquired company’s cost of manufacturing plus a portion of the expected profit margin. The non-GAAP adjustment excludes the expected profit margin component that is recorded under business combination accounting principles associated with our acquisition of Jaybird. We believe the adjustment is useful to investors because such charges are not reflective of our ongoing operations.

[0001032975-16-000092:8k_2_02:52]
Acquisition-related costs.  We incurred expenses in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition related costs include all incremental expenses incurred to effect a business combination. We believe that providing the non-GAAP measures excluding these costs, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-16-000092:8k_2_02:53]
Restructuring charges (credits). These expenses are associated with re-aligning our business strategies based on current economic conditions. We have undertaken several restructuring plans in recent years. In connection with our restructuring initiatives, we incurred restructuring charges related to employee terminations, facility closures and early cancellation of certain contracts. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results in the current period.

[0001032975-16-000092:8k_2_02:54]
Gain (loss) on equity-method investment. We recognized gain (loss) related our investments in various privately-held companies, which varies depending on the operational and financial performance of the privately-held companies in which we invested. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-16-000092:8k_2_02:55]
Investigation and related expenses.  These expenses are forensic accounting, audit, consulting and legal fees related to the Audit Committee’s investigation and the formal investigation by and settlement with the Securities and Exchange Commission (SEC), together with accruals based on settlement with the SEC. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-16-000092:8k_2_02:56]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above and other events; the determination of which is based upon the nature of the underlying items, the mix of income and losses in jurisdictions and the relevant tax rates in which we operate.

[0001032975-16-000092:8k_2_02:57]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-16-000092:8k_2_02:58]
Additional Supplemental Financial Information - Constant Currency

[0001032975-16-000092:8k_2_02:59]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates.  Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Sales for the three months ended June 30, 2016 compared to sales for the three months ended June 30, 2015 increased 7 percent in both constant currency and U.S. Dollars. Retail sales for the three months ended June 30, 2016 compared to retail sales for the three months ended June 30, 2015 grew 13 percent in both constant currency and U.S. Dollars.
