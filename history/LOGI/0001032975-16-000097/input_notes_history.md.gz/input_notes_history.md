# LOGI note change history — 0001032975-16-000068 → 0001032975-16-000097


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2016-07-29):
[0001032975-16-000097:note_history:1]
All of the Company’s peripherals products sold are covered by warranty to be free from defects in material and workmanship.  For products launched prior to April 1, 2014, the standard warranty period was up to five years. Starting from April 1, 2014, the standard warranty for all new products launched was changed to two years from date of purchase for European Countries and generally one year from date of purchase for all other countries.  At the time of sale, the Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. The Company’s estimate of costs to fulfill its warranty obligations is based on historical experience and expectations of future conditions. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly.

- changed (2016-07-29):
[0001032975-16-000097:note_history:2]
Changes in the Company’s warranty liability for the three months ended June 30, 2016 and 2015 were as follows (in thousands):
  (was, 2016-01-22, similarity 0.9231):
[0001032975-16-000068:note_history:2]
Changes in the Company’s warranty liability for the three and nine months ended December 31, 2015 and 2014 were as follows (in thousands):

- added (2016-07-29):
[0001032975-16-000097:note_history:3]
|  | Three Months EndedJune 30, |
|  | 2016 |  | 2015 |
| Beginning of the period | $ | 20,380 |  |  | $ | 21,710 |  |
| Assumed from business acquisition | 1,813 |  |  | — |  |
| Provision | 3,177 |  |  | 1,913 |  |
| Settlements | (3,428 | ) |  | (2,568 | ) |
| Currency impact | (190 | ) |  | 229 |  |
| End of the period | $ | 21,752 |  |  | $ | 21,284 |  |

- added (2016-07-29):
[0001032975-16-000097:note_history:4]
In April 2016, the Company entered into a settlement with the Securities and Exchange Commission (“SEC”) related to the accounting for Revue inventory valuation reserves that resulted in the restatement described in the Fiscal Year 2014 Annual Report on Form 10-K, revision to its consolidated financial statements concerning warranty accruals and amortization of intangible assets presented in its Amended Annual Report on Form 10-K/A, filed on August 7, 2013, and its transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. The Company entered into the settlement without admitting or denying the findings of the SEC’s investigation and paid a civil penalty of $7.5 million. This amount was paid in April 2016.

- changed (2016-07-29):
[0001032975-16-000097:note_history:5]
Logitech Europe S.A. guaranteed payments of certain third-party contract manufacturers’ purchase obligations. As of June 30, 2016, the maximum amount of this guarantee was $3.8 million, of which $1.3 million of guaranteed purchase obligations were outstanding.
  (was, 2016-01-22, similarity 0.9762):
[0001032975-16-000068:note_history:5]
Logitech Europe S.A. guaranteed payments of certain third-party contract manufacturers’ purchase obligations. As of December 31, 2015, the maximum amount of this guarantee was $3.8 million, of which $1.3 million of guaranteed purchase obligations were outstanding.

- changed (2016-07-29):
[0001032975-16-000097:note_history:6]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2016, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2016-01-22, similarity 0.9906):
[0001032975-16-000068:note_history:6]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2015, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

- removed (2016-07-29):
[0001032975-16-000068:note_history:7]
All of the Company’s peripherals products sold are covered by warranty to be free from defects in material and workmanship. Except for the products sold prior to April 1, 2014, the standard warranty period up to five years, starting from April 1, 2014, which had the standard warranty for all new products launched was changed to two years from date of purchase for European Countries and generally one year from date of purchase for all other countries. At the time of sale, the Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. The Company’s estimate of costs to fulfill its warranty obligations is based on historical experience and expectations of future conditions. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly.

- removed (2016-07-29):
[0001032975-16-000068:note_history:8]
|  | Three Months EndedDecember 31, |  | Nine Months Ended December 31, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Beginning of the period | $ | 20,399 |  |  | $ | 22,204 |  |  | $ | 21,710 |  |  | $ | 24,380 |  |
| Provision | 1,870 |  |  | 2,381 |  |  | 5,804 |  |  | 6,607 |  |
| Settlements | (2,763 | ) |  | (2,493 | ) |  | (8,008 | ) |  | (8,895 | ) |
| End of the period | $ | 19,506 |  |  | $ | 22,092 |  |  | $ | 19,506 |  |  | $ | 22,092 |  |

- removed (2016-07-29):
[0001032975-16-000068:note_history:9]
The Company is subject to an ongoing formal investigation by the Enforcement Division of the U.S. Securities and Exchange Commission ("SEC"), relating to certain issues including the accounting for Revue inventory valuation reserves that resulted in the restatement described in the Fiscal 2014 Form 10-K, revision to the Company’s consolidated financial statements concerning warranty accruals and amortization of intangible assets presented in the Company’s Amended Annual Report on Form10-K/A, filed on August 7, 2013, and the Company’s transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. The Company has entered into an agreement with the Enforcement Staff to extend the statute of limitations. The Company is cooperating with the investigation and, after discussions with the Enforcement Staff, the Company made an offer of settlement to resolve the matter, which is subject to approval by the SEC.  The proposed settlement would be entered into by the Company without admitting or denying the SEC’s findings and would resolve alleged violations of certain provisions of the Securities Exchange Act of 1934 and related rules, including the anti-fraud provisions.  Under the terms of the proposed settlement, the Company would pay $7.5 million in a civil penalty and agree not to commit or cause any violations of certain provisions of the Securities Exchange Act of 1934 and related rules. There is no assurance that the proposal will be approved by the SEC. In accordance with U.S. GAAP, the Company has made a corresponding accrual in its financial statements.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2016-07-29):
[0001032975-16-000097:note_history:10]
Logitech International S.A, together with its consolidated subsidiaries, ("Logitech" or the "Company") designs, manufactures and markets products that allow people to connect through music, gaming, video, computing, and other digital platforms.

- added (2016-07-29):
[0001032975-16-000097:note_history:11]
The Company sells its products to a broad network of domestic and international customers, including direct sales to retailers and indirect sales through distributors.

- added (2016-07-29):
[0001032975-16-000097:note_history:12]
Logitech was founded in Switzerland in 1981 and Logitech International S.A. has been the parent holding company of Logitech since 1988. Logitech International S.A. is a Swiss holding company with its registered office in Apples, Switzerland, which conducts its business through subsidiaries in Americas, Europe, Middle East, Africa ("EMEA") and Asia Pacific. Shares of Logitech International S.A. are listed on both the SIX Swiss Exchange under the trading symbol LOGN and the Nasdaq Global Select Market under the trading symbol LOGI.

- changed (2016-07-29):
[0001032975-16-000097:note_history:13]
The condensed consolidated interim financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (“GAAP”) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. They should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2016, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (“SEC”) on May 23, 2016.
  (was, 2016-01-22, similarity 0.9951):
[0001032975-16-000068:note_history:13]
The condensed consolidated interim financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (“GAAP”) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. They should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2015, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (“SEC”) on June 5, 2015.

- changed (2016-07-29):
[0001032975-16-000097:note_history:14]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three months ended June 30, 2016 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2017, or any future periods.
  (was, 2016-01-22, similarity 0.921):
[0001032975-16-000068:note_history:14]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, financial position, comprehensive income, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and nine months ended December 31, 2015 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2016, or any future periods.

- added (2016-07-29):
[0001032975-16-000097:note_history:15]
Reclassification

- added (2016-07-29):
[0001032975-16-000097:note_history:16]
Certain amounts from the comparative period in the accompanying unaudited condensed consolidated financial statements have been reclassified to conform to the condensed consolidated financial statement presentation as of and for the three months ended June 30, 2016.

- changed (2016-07-29):
[0001032975-16-000097:note_history:17]
There have been no substantial changes in the Company’s significant accounting policies during the three months ended June 30, 2016 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2016.
  (was, 2016-01-22, similarity 0.9045):
[0001032975-16-000068:note_history:17]
There have been no substantial changes in the Company’s significant accounting policies during the nine months ended December 31, 2015 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2015.

- added (2016-07-29):
[0001032975-16-000097:note_history:18]
The preparation of financial statements in conformity with GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Examples of significant estimates and assumptions made by management involve the fair value of goodwill, intangible assets acquired from business acquisitions, warranty liabilities, accruals for discretionary customer programs, sales return reserves, allowance for doubtful accounts, inventory valuation, restructuring charges, contingent consideration from business acquisitions, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

- changed (2016-07-29):
[0001032975-16-000097:note_history:19]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-9, "Revenue from Contracts with Customers (Topic 606)," ("ASU 2014-9"). ASU 2014-9 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. Under the new model, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In addition, the new standard requires that reporting companies disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. ASU 2014-09 was originally to be effective for the Company on April 1, 2017. In July 2015, the FASB affirmed a one-year deferral of the effective date of the new revenue standard. The new standard will become effective for the Company on April 1, 2018. Early application is permitted but not before the original effective date of annual periods beginning after December 15, 2016. The new standard is required to be applied retrospectively to each prior reporting period presented or retrospectively with the cumulative effect of initially applying it recognized at the date of initial application. The Company has not yet selected a transition method nor has it determined whether it will early adopt this guidance or the impact of the new standard on its condensed consolidated financial statements.
  (was, 2016-01-22, similarity 0.9332):
[0001032975-16-000068:note_history:19]
In May 2014, the FASB issued Accounting Standards Update No. 2014-9, "Revenue from Contracts with Customers (Topic 606)," ("ASU 2014-9"). ASU 2014-9 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. Under the new model, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In addition, the new standard requires that reporting companies disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. ASU 2014-09 was originally to be effective for the Company on April 1, 2017. In July 2015, the FASB affirmed a one-year deferral of the effective date of the new revenue standard. The new standard will become effective for the Company on April 1, 2018. Early application is permitted but not before the original effective date of annual periods beginning after December 15, 2016. The new standard is required to be applied retrospectively to each prior reporting period presented or retrospectively with the cumulative effect of initially applying it recognized at the date of initial application. The Company has not yet selected a transition method nor has it determined the impact of the new standard on its condensed consolidated financial statements.

- changed (2016-07-29):
[0001032975-16-000097:note_history:20]
In July 2015, the FASB issued ASU No. 2015-11, "Simplifying the Measurement of Inventory (Topic 330)",  ("ASU 2015-11"). Topic 330, Inventory, currently requires an entity to measure inventory at the lower of cost or market, with market value represented by replacement cost, net realizable value or net realizable value less a normal profit margin. The amendments in ASU 2015-11 require an entity to measure inventory at the lower of cost or net realizable value. ASU 2015-11 is effective in the first quarter of fiscal year 2018 for the Company, with early adoption permitted. The Company does not expect to early adopt this guidance and does not expect the adoption of this guidance to have a material impact on its condensed consolidated financial statements.
  (was, 2016-01-22, similarity 0.8866):
[0001032975-16-000068:note_history:20]
In July 2015, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update No. 2015-11, "Simplifying the Measurement of Inventory (Topic 330)",  ("ASU 2015-11"). Topic 330, Inventory, currently requires an entity to measure inventory at the lower of cost or market, with market value represented by replacement cost, net realizable value or net realizable value less a normal profit margin. The amendments in ASU 2015-11 require an entity to measure inventory at the lower of cost or net realizable value. ASU 2015-11 is effective in the first quarter of fiscal year 2018 for the Company, with early adoption permitted. The Company does not expect the adoption of this guidance to have a material impact on its condensed consolidated financial statements.

- added (2016-07-29):
[0001032975-16-000097:note_history:21]
In January 2016, FASB issued ASU 2016-01 “Financial Instruments- Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10)”. The guidance is effective in the first quarter of fiscal year 2018 for the Company, with early adoption permitted. The Company does not expect to early adopt this guidance and does not believe that the adoption of this guidance will have a material impact on its condensed consolidated financial statements.

- added (2016-07-29):
[0001032975-16-000097:note_history:22]
In February 2016, the FASB issued ASU 2016-02 "Leases (Topic 842)", which requires the recognition of lease assets and lease liabilities arising from operating leases in the statement of financial position. This guidance is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. The Company is evaluating the full effect that ASU 2016-02 will have on its condensed consolidated financial statements and will adopt the standard effective April 1, 2019.

- added (2016-07-29):
[0001032975-16-000097:note_history:23]
In March 2016, the FASB issued ASU 2016-09 "Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting". The amendment simplifies several aspects of the accounting for share-based payments, including immediate recognition of all excess tax benefits and deficiencies in the income statement, changing the threshold to qualify for equity classification up to the employees' maximum statutory tax rates, allowing an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures as they occur, and clarifying the classification on the statement of cash flows for the excess tax benefit and employee taxes paid when an employer withholds shares for tax-withholding purposes. ASU 2016-09 is effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. Early adoption is permitted in any interim or annual period. The Company is evaluating the effect that ASU 2016-09 will have on its condensed consolidated financial statements and the timing of the adoption of this standard.

- removed (2016-07-29):
[0001032975-16-000068:note_history:24]
Logitech is a world leader in products that connect people to the digital experiences they care about. Spanning multiple computing, communication and entertainment platforms, the Company develops and markets innovative hardware and software products that enable or enhance digital navigation, music and video entertainment, gaming, social networking, audio and video communication over the Internet and home-entertainment control.

- removed (2016-07-29):
[0001032975-16-000068:note_history:25]
During the third quarter of fiscal year 2016, the Company's Board of Directors approved a plan to divest the Lifesize video conferencing business, and the Company met all other criteria to classify this business as held for sale. As a result, the Company has classified the results of Lifesize video conferencing business as discontinued operations in its condensed consolidated statements of operations for all periods presented. Additionally, the related assets and liabilities associated with the discontinued operations are classified as held for sale on its condensed consolidated balance sheets. On December 28, 2015, the Company and Lifesize, Inc., a wholly owned subsidiary of the Company (“Lifesize”) which holds the assets of the Company’s Lifesize video conferencing business, entered into a stock purchase agreement (the “Stock Purchase Agreement”) with three venture capital firms. Immediately following the December 28, 2015 closing of the transactions contemplated by the Stock Purchase Agreement, the venture capital firms held 62.5% of the outstanding shares of Lifesize, which resulted in a divestiture of the Lifesize video conferencing business by the Company. The disposition of the Lifesize video conferencing business represents a strategic shift that will have a major effect on the Company's operations and financial results.

- removed (2016-07-29):
[0001032975-16-000068:note_history:26]
Unless indicated otherwise, the information in the Notes to the condensed consolidated financial statements relates to our continuing operations and does not include results of Lifesize video conferencing business, which is classified as discontinued operations. See "Note 2 - Discontinued Operations" for more information.

- removed (2016-07-29):
[0001032975-16-000068:note_history:27]
Segments

- removed (2016-07-29):
[0001032975-16-000068:note_history:28]
ASC 280, Segment Reporting, establishes standards for reporting information about operating segments. Operating segments are defined as components of an enterprise about which separate financial information is available that is evaluated regularly by the chief operating decision maker, or decision making group, in deciding how to allocate resources and in assessing performance. The guidance defines reportable segments as operating segments that meet certain quantitative thresholds. As a result of the events of December 28, 2015 described above and the decision to divest the Company's video conferencing segment, the composition of the Company's previously reported segments changed significantly, such that the remaining peripheral segment is the only segment reported in continuing operations.

- removed (2016-07-29):
[0001032975-16-000068:note_history:29]
Fiscal Year

- removed (2016-07-29):
[0001032975-16-000068:note_history:30]
The Company's fiscal year ends on March 31. Interim quarters end on the last Friday of each quarter. For purposes of presentation, the Company has indicated its quarterly periods as ending on the last day of the calendar quarter.

- removed (2016-07-29):
[0001032975-16-000068:note_history:31]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Examples of significant estimates and assumptions made by management involve the fair value of goodwill, warranty liabilities, accruals for discretionary customer programs, sales return reserves, allowance for doubtful accounts, inventory valuation, restructuring charges, contingent liabilities, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

- removed (2016-07-29):
[0001032975-16-000068:note_history:32]
In April 2014, the FASB issued ASU No. 2014-08, "Presentation of Financial Statements (Topic 205) and Property, Plant and Equipment (Topic 360): Reporting Discontinued Operations and Disclosures of Disposals of Components of an Entity". This new standard raises the threshold for a disposal to qualify as a discontinued operation and requires new disclosures of both discontinued operations and certain other disposals that do not meet the definition of a discontinued operation. The standard is effective prospectively for years beginning on or after December 15, 2014, with early application permitted. The Company adopted ASU No. 2014-08 on April 1, 2015 on a prospective basis and applied the guidance to its disposal of the Lifesize video conferencing business.

- removed (2016-07-29):
[0001032975-16-000068:note_history:33]
In November 2015, the FASB issued ASU 2015-17, “Income Taxes (Topic 740), Balance Sheet Classification of Deferred Taxes.” This guidance eliminates the current requirement for an entity to separate deferred income tax liabilities and assets into current and non-current amounts in a classified balance sheet. Instead, this guidance requires deferred tax liabilities, deferred tax assets and valuation allowances be classified as non-current in a classified balance sheet. This ASU is effective for annual reporting periods beginning after December 15, 2016 and interim periods within those annual periods. Early adoption is permitted. Additionally, this guidance may be applied either prospectively or retrospectively to all periods presented. The Company is still evaluating whether to early adopt this guidance as the Company expects adoption will cause significant balance sheet reclassifications. See Note 6, “Balance Sheet Components” for details of the current and non-current deferred income taxes balances.

- removed (2016-07-29):
[0001032975-16-000068:note_history:34]
In January 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”)  2016-01 “Financial Instruments- Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10).” The amendments require all equity investments to be measured at fair value with changes in the fair value recognized through net income (other than those accounted for under the equity method of accounting or those that result in consolidation of the investee). The amendments also require an entity to present separately in other comprehensive income the portion of the total change in the fair value of a liability resulting from a change in the instrument-specific credit risk when the entity has elected to measure the liability at fair value in accordance with the fair value option for financial instruments. In addition, the amendments eliminate the requirement to disclose the fair value of financial instruments measured at amortized cost for entities that are not public business entities and the requirement to disclose the method(s) and significant assumptions used to estimate the fair value that is required to be disclosed for financial instruments measured at amortized cost on the balance sheet for public business entities. This guidance is effective for fiscal years beginning after December 15, 2017, including interim periods within those fiscal years. The Company does not expect to early adopt this guidance and does not believe that the adoption of this guidance will have a material impact on its condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-07-29):
[0001032975-16-000097:note_history:35]
The Company had several uncommitted, unsecured bank lines of credit aggregating $44.6 million as of June 30, 2016. There are no financial covenants under these lines of credit with which the Company must comply. As of June 30, 2016, the Company had outstanding bank guarantees of $15.6 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of June 30, 2016 or March 31, 2016.
  (was, 2016-01-22, similarity 0.9127):
[0001032975-16-000068:note_history:35]
The Company had several uncommitted, unsecured bank lines of credit aggregating $45.5 million as of December 31, 2015. There are no financial covenants under these lines of credit with which the Company must comply. As of December 31, 2015, the Company had outstanding bank guarantees of $21.8 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of December 31, 2015 or March 31, 2015.
