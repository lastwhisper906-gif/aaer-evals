# LOGI notes — 0001032975-16-000097


## logi:ScheduleOfBalanceSheetComponentsAssetsTableTextBlock

[0001032975-16-000097:notes:1]
The following table presents the components of certain balance sheet asset amounts as of June 30 and March 31, 2016 (in thousands):

[0001032975-16-000097:notes:2]
|  |  | June 30,2016 |  | March 31,2016 |
| Accounts receivable, net: |  |  |  |  |  |  |
| Accounts receivable |  | $ | 372,634 |  |  | $ | 332,553 |  |
| Allowance for doubtful accounts |  | (677 | ) |  | (667 | ) |
| Allowance for sales returns |  | (19,856 | ) |  | (18,526 | ) |
| Allowance for cooperative marketing arrangements |  | (26,951 | ) |  | (28,157 | ) |
| Allowance for customer incentive programs* |  | (52,576 | ) |  | (60,872 | ) |
| Allowance for pricing programs |  | (80,332 | ) |  | (81,553 | ) |
|  |  | $ | 192,242 |  |  | $ | 142,778 |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 39,881 |  |  | $ | 48,489 |  |
| Finished goods |  | 207,911 |  |  | 180,297 |  |
|  |  | $ | 247,792 |  |  | $ | 228,786 |  |
| Other current assets: |  |  |  |  |  |  |
| Income tax and value-added tax receivables |  | $ | 21,368 |  |  | $ | 22,572 |  |
| Prepaid expenses and other assets |  | 15,165 |  |  | 12,916 |  |
|  |  | $ | 36,533 |  |  | $ | 35,488 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |
| Property, plant and equipment at cost |  | $ | 374,056 |  |  | 371,212 |  |
| Less: accumulated depreciation and amortization |  | (287,012 | ) |  | (278,352 | ) |
|  |  | $ | 87,044 |  |  | $ | 92,860 |  |
| Other assets: |  |  |  |  |  |  |
| Deferred tax assets |  | $ | 56,245 |  |  | $ | 56,208 |  |
| Trading investments for deferred compensation plan |  | 14,997 |  |  | 14,836 |  |
| Investments held in privately held companies |  | 9,567 |  |  | 9,247 |  |
| Other assets |  | 6,281 |  |  | 6,525 |  |
|  |  | $ | 87,090 |  |  | $ | 86,816 |  |

[0001032975-16-000097:notes:3]
*The decrease in the allowances for customer incentive programs as of June 30, 2016 compared with March 31, 2016 was due to claim processing.


## logi:ScheduleOfBalanceSheetComponentsLiabilityTableTextBlock

[0001032975-16-000097:notes:4]
The following table presents the components of certain balance sheet liability amounts as of June 30 and March 31, 2016 (in thousands):

[0001032975-16-000097:notes:5]
|  |  | June 30,2016 |  | March 31,2016 |
| Accrued and other current liabilities: |  |  |  |  |  |  |
| Accrued personnel expenses |  | $ | 46,068 |  |  | $ | 46,025 |  |
| Indirect customer incentive programs |  | 28,937 |  |  | 28,721 |  |
| Warranty accrual |  | 13,628 |  |  | 11,880 |  |
| Employee benefit plan obligation |  | 1,461 |  |  | 1,285 |  |
| Income taxes payable |  | 1,493 |  |  | 1,553 |  |
| Other current liabilities |  | 75,730 |  |  | 84,300 |  |
|  |  | $ | 167,317 |  |  | $ | 173,764 |  |
| Non-current liabilities: |  |  |  |  |  |  |
| Warranty accrual |  | $ | 8,124 |  |  | $ | 8,500 |  |
| Obligation for deferred compensation plan |  | 14,997 |  |  | 14,836 |  |
| Employee benefit plan obligation |  | 53,218 |  |  | 53,909 |  |
| Deferred tax liability |  | 1,665 |  |  | 1,665 |  |
| Contingent consideration for business acquisition |  | 18,000 |  |  | — |  |
| Other non-current liabilities |  | 10,329 |  |  | 10,625 |  |
|  |  | $ | 106,333 |  |  | $ | 89,535 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-16-000097:notes:6]
[same as prior period, unchanged from 0001032975-16-000068:notes:6]

[0001032975-16-000097:notes:7]
[same as prior period, unchanged from 0001032975-16-000068:notes:7]

[0001032975-16-000097:notes:8]
Logitech International S.A, together with its consolidated subsidiaries, ("Logitech" or the "Company") designs, manufactures and markets products that allow people to connect through music, gaming, video, computing, and other digital platforms.

[0001032975-16-000097:notes:9]
The Company sells its products to a broad network of domestic and international customers, including direct sales to retailers and indirect sales through distributors.

[0001032975-16-000097:notes:10]
Logitech was founded in Switzerland in 1981 and Logitech International S.A. has been the parent holding company of Logitech since 1988. Logitech International S.A. is a Swiss holding company with its registered office in Apples, Switzerland, which conducts its business through subsidiaries in Americas, Europe, Middle East, Africa ("EMEA") and Asia Pacific. Shares of Logitech International S.A. are listed on both the SIX Swiss Exchange under the trading symbol LOGN and the Nasdaq Global Select Market under the trading symbol LOGI.

[0001032975-16-000097:notes:11]
[same as prior period, unchanged from 0001032975-16-000068:notes:9]

[0001032975-16-000097:notes:12]
The condensed consolidated interim financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (“GAAP”) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. They should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2016, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (“SEC”) on May 23, 2016.

[0001032975-16-000097:notes:13]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three months ended June 30, 2016 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2017, or any future periods.

[0001032975-16-000097:notes:14]
Reclassification

[0001032975-16-000097:notes:15]
Certain amounts from the comparative period in the accompanying unaudited condensed consolidated financial statements have been reclassified to conform to the condensed consolidated financial statement presentation as of and for the three months ended June 30, 2016.

[0001032975-16-000097:notes:16]
[same as prior period, unchanged from 0001032975-16-000068:notes:18]

[0001032975-16-000097:notes:17]
There have been no substantial changes in the Company’s significant accounting policies during the three months ended June 30, 2016 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2016.

[0001032975-16-000097:notes:18]
[same as prior period, unchanged from 0001032975-16-000068:notes:20]

[0001032975-16-000097:notes:19]
The preparation of financial statements in conformity with GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Examples of significant estimates and assumptions made by management involve the fair value of goodwill, intangible assets acquired from business acquisitions, warranty liabilities, accruals for discretionary customer programs, sales return reserves, allowance for doubtful accounts, inventory valuation, restructuring charges, contingent consideration from business acquisitions, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

[0001032975-16-000097:notes:20]
[same as prior period, unchanged from 0001032975-16-000068:notes:22]

[0001032975-16-000097:notes:21]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-9, "Revenue from Contracts with Customers (Topic 606)," ("ASU 2014-9"). ASU 2014-9 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. Under the new model, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In addition, the new standard requires that reporting companies disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. ASU 2014-09 was originally to be effective for the Company on April 1, 2017. In July 2015, the FASB affirmed a one-year deferral of the effective date of the new revenue standard. The new standard will become effective for the Company on April 1, 2018. Early application is permitted but not before the original effective date of annual periods beginning after December 15, 2016. The new standard is required to be applied retrospectively to each prior reporting period presented or retrospectively with the cumulative effect of initially applying it recognized at the date of initial application. The Company has not yet selected a transition method nor has it determined whether it will early adopt this guidance or the impact of the new standard on its condensed consolidated financial statements.

[0001032975-16-000097:notes:22]
In July 2015, the FASB issued ASU No. 2015-11, "Simplifying the Measurement of Inventory (Topic 330)",  ("ASU 2015-11"). Topic 330, Inventory, currently requires an entity to measure inventory at the lower of cost or market, with market value represented by replacement cost, net realizable value or net realizable value less a normal profit margin. The amendments in ASU 2015-11 require an entity to measure inventory at the lower of cost or net realizable value. ASU 2015-11 is effective in the first quarter of fiscal year 2018 for the Company, with early adoption permitted. The Company does not expect to early adopt this guidance and does not expect the adoption of this guidance to have a material impact on its condensed consolidated financial statements.

[0001032975-16-000097:notes:23]
In January 2016, FASB issued ASU 2016-01 “Financial Instruments- Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10)”. The guidance is effective in the first quarter of fiscal year 2018 for the Company, with early adoption permitted. The Company does not expect to early adopt this guidance and does not believe that the adoption of this guidance will have a material impact on its condensed consolidated financial statements.

[0001032975-16-000097:notes:24]
In February 2016, the FASB issued ASU 2016-02 "Leases (Topic 842)", which requires the recognition of lease assets and lease liabilities arising from operating leases in the statement of financial position. This guidance is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. The Company is evaluating the full effect that ASU 2016-02 will have on its condensed consolidated financial statements and will adopt the standard effective April 1, 2019.

[0001032975-16-000097:notes:25]
In March 2016, the FASB issued ASU 2016-09 "Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting". The amendment simplifies several aspects of the accounting for share-based payments, including immediate recognition of all excess tax benefits and deficiencies in the income statement, changing the threshold to qualify for equity classification up to the employees' maximum statutory tax rates, allowing an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures as they occur, and clarifying the classification on the statement of cash flows for the excess tax benefit and employee taxes paid when an employer withholds shares for tax-withholding purposes. ASU 2016-09 is effective for annual periods beginning after December 15, 2016, and interim periods within those annual periods. Early adoption is permitted in any interim or annual period. The Company is evaluating the effect that ASU 2016-09 will have on its condensed consolidated financial statements and the timing of the adoption of this standard.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001032975-16-000097:notes:26]
Business Acquisition

[0001032975-16-000097:notes:27]
On April 20, 2016 ("Acquisition Date"), the Company acquired all of the equity interest of JayBird, LLC (“Jaybird”), a Utah limited liability company that develops Bluetooth earbuds, activity trackers, and accessories for sports and active lifestyles, for a purchase price of $54.2 million, including a working capital adjustment and payment of line-of-credit on behalf of Jaybird, with an additional earn-out of up to $45.0 million based on the achievement of certain net revenue growth targets over approximately a two year period (the "Jaybird Acquisition").  If the net revenue growth targets are met, the Company will pay $25.0 million and $20.0 million in fiscal year 2018 and 2019, respectively. The acquisition is expected to accelerate Logitech’s entry into the wireless wearables space.

[0001032975-16-000097:notes:28]
The Jaybird business meets the definition of a business and is accounted for using the acquisition method. The fair value of consideration transferred for the Jaybird Acquisition consisted of the following (in thousands):

[0001032975-16-000097:notes:29]
| Purchase price |  | $ | 54,242 |  |
| Fair value of contingent consideration (earn-out) |  | 18,000 |  |
| Fair value of total consideration transferred |  | $ | 72,242 |  |

[0001032975-16-000097:notes:30]
The fair value of the earn-out payments at the acquisition date was determined by providing risk adjusted earnings projections using a Monte Carlo Simulation, using inputs not observable in the market and therefore represents a Level 3 measurement. The fair value of this earn-out is discussed further in Note 8 - "Fair Value Measurements" to the condensed consolidated financial statements.

[0001032975-16-000097:notes:31]
The following table summarizes the estimated fair values of the assets acquired and liabilities assumed at the acquisition date (in thousands):

[0001032975-16-000097:notes:32]
|  |  | Estimated Fair Value |
| Cash and cash equivalents |  | $ | 255 |  |
| Accounts receivable |  | 272 |  |
| Inventories |  | 10,214 |  |
| Other current assets |  | 611 |  |
| Property, plant, and equipment |  | 1,165 |  |
| Intangible assets |  | 50,280 |  |
| Other assets |  | 27 |  |
| Total identifiable assets acquired |  | 62,824 |  |
| Accounts payable |  | (10,513 | ) |
| Accrued liabilities |  | (1,227 | ) |
| Other current liabilities |  | (5,226 | ) |
| Other long-term liabilities |  | (283 | ) |
| Net identifiable assets acquired |  | $ | 45,575 |  |
| Goodwill |  | 26,667 |  |
| Net assets acquired |  | $ | 72,242 |  |

[0001032975-16-000097:notes:33]
The fair value of identifiable intangible assets acquired was based on estimates and assumptions made by the management at the time of acquisition. As additional information becomes available, such as finalization of the estimated fair value of the assets acquired and liabilities assumed and the fair value of contingent consideration, the Company may further revise its preliminary purchase price allocation during the remainder of the measurement period (which will not exceed 12 months from the Acquisition Date). Any such revisions or changes may be material as we finalize the fair values of the tangible and intangible assets acquired and liabilities assumed.

[0001032975-16-000097:notes:34]
Goodwill is primarily attributable to the assembled workforce, and anticipated synergies expected to arise after the acquisition. Goodwill is expected to be deductible for tax purpose.

[0001032975-16-000097:notes:35]
Inventory is estimated at net realizable value, which uses the estimated selling prices, less the cost of disposal and a reasonable profit allowance for the selling efforts. Upon sales of the inventory, the difference between the fair value of the inventories and the amount recognized by the acquiree immediately before the acquisition date, which is $0.7 million, is recognized in "Amortization of intangibles assets and purchase accounting effect on inventories" in the condensed consolidated statements of operations.

[0001032975-16-000097:notes:36]
The Company included Jaybird's estimated fair value of assets acquired and liabilities assumed in its condensed consolidated balance sheets beginning April 20, 2016. Pro forma results of operations for the Jaybird Acquisition have not been presented because they are not material to the condensed consolidated statements of operations. The results of operations for Jaybird has been included in the Company's condensed consolidated statements of operations from the acquisition date. Jaybird contributed $14.3 million net sales and $1.8 million operating loss, which includes $1.7 million amortization of intangible assets resulting from the acquisition and $0.7 million of purchase accounting effect on inventory.

[0001032975-16-000097:notes:37]
The Company incurred acquisition-related costs of approximately $0.5 million during the three months ended June 30, 2016. The acquisition-related costs are included in "Amortization of intangible assets and acquisition related costs" in the operating expense of the condensed consolidated statements of operations.

[0001032975-16-000097:notes:38]
The following table sets forth the components of identifiable intangible assets acquired at their preliminary estimated fair values and their estimated useful lives as of the date of acquisition (in thousands, except useful life):

[0001032975-16-000097:notes:39]
|  | Preliminary Fair Value | Estimated Useful Life (years) |
| Developed technology | $ | 18,450 |  | 4 |
| In-process research & development ("IPR&D") | 2,550 |  | Not Applicable |
| Customer relationships | 19,900 |  | 8 |
| Trade name | 9,380 |  | 6 |
| Total intangible assets acquired | $ | 50,280 |  |  |

[0001032975-16-000097:notes:40]
Except for IPR&D, intangible assets acquired as a result of the Jaybird acquisition are being amortized over their estimated useful lives using the straight-line method of amortization. Amortization of developed technology of $0.9 million during the three months ended June 30, 2016 is included in "Amortization of intangible assets and purchase accounting effect of inventory" in the gross profit of the condensed consolidated statements of operations. Amortization of the intangible asset of customer relationship and trade name of $0.8 million during the three months ended June 30, 2016 is included in "Amortization of intangible assets and acquisition related costs" in the operating expense of the condensed consolidated statements of operations.

[0001032975-16-000097:notes:41]
Developed technology relates to existing bluetooth wireless sports earbuds. The economic useful life was determined based on the technology cycle related to developed technology of existing products, as well as the cash flows over the forecast period.

[0001032975-16-000097:notes:42]
Customer relationships represent the fair value of future projected revenue that will be derived from sales of products to existing customers of Jaybird. The economic useful life was determined based on historical customer turnover rates and the industry benchmarks.

[0001032975-16-000097:notes:43]
Trade name relates to the “Jaybird” trade name.  The economic useful life was determined based on the expected life of the trade name and the cash flows anticipated over the forecasted periods.

[0001032975-16-000097:notes:44]
The value of developed technology and trade names were estimated using the relief-from-royalty method, an income approach (Level 3), which estimates the cost savings that accrue to the owner of the intangibles asset that would otherwise be payable as royalties or license fees on revenues earned through the use of the asset. A royalty rate is applied to the projected revenues associated with the intangible asset to determine the amount of savings, which is then discounted to determine the fair value. The developed technology and trade names were valued using royalty rates of 10% and 2.5%, respectively, and both discounted at a rate of 16%.

[0001032975-16-000097:notes:45]
The value of customer relationships was estimated using the excess earnings method, an income approach (Level 3), which converts projected revenues and costs into cash flows. To reflect the fact that certain other assets contribute to the cash flows generated, the returns for these contributory assets were removed to arrive at estimated cash flows solely attributable to the customer relationships, which was discounted at a rate of 16%.

[0001032975-16-000097:notes:46]
The IPR&D is accounted for as an indefinite-lived intangible asset and is not amortized until completion or abandonment of the associated research and development efforts.   If the research and development efforts are completed, the IPR&D intangible asset will be amortized over the estimated useful lives to be determined as of the date the efforts are completed.  IPR&D is tested for impairment annually or periodically if an indicator of impairment exists during the period until completion. The expected release date of the IPR&D is during fiscal year 2017 to fiscal year 2018.

[0001032975-16-000097:notes:47]
The Company believes the amounts of purchased intangible assets recorded above represent the fair values of, and approximate the amounts a market participant would pay for, these intangible assets as of the Acquisition Date.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-16-000097:notes:48]
Commitments and Contingencies

[0001032975-16-000097:notes:49]
Product Warranties

[0001032975-16-000097:notes:50]
All of the Company’s peripherals products sold are covered by warranty to be free from defects in material and workmanship.  For products launched prior to April 1, 2014, the standard warranty period was up to five years. Starting from April 1, 2014, the standard warranty for all new products launched was changed to two years from date of purchase for European Countries and generally one year from date of purchase for all other countries.  At the time of sale, the Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. The Company’s estimate of costs to fulfill its warranty obligations is based on historical experience and expectations of future conditions. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly.

[0001032975-16-000097:notes:51]
Changes in the Company’s warranty liability for the three months ended June 30, 2016 and 2015 were as follows (in thousands):

[0001032975-16-000097:notes:52]
|  | Three Months EndedJune 30, |
|  | 2016 |  | 2015 |
| Beginning of the period | $ | 20,380 |  |  | $ | 21,710 |  |
| Assumed from business acquisition | 1,813 |  |  | — |  |
| Provision | 3,177 |  |  | 1,913 |  |
| Settlements | (3,428 | ) |  | (2,568 | ) |
| Currency impact | (190 | ) |  | 229 |  |
| End of the period | $ | 21,752 |  |  | $ | 21,284 |  |

[0001032975-16-000097:notes:53]
Other Contingencies

[0001032975-16-000097:notes:54]
In April 2016, the Company entered into a settlement with the Securities and Exchange Commission (“SEC”) related to the accounting for Revue inventory valuation reserves that resulted in the restatement described in the Fiscal Year 2014 Annual Report on Form 10-K, revision to its consolidated financial statements concerning warranty accruals and amortization of intangible assets presented in its Amended Annual Report on Form 10-K/A, filed on August 7, 2013, and its transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. The Company entered into the settlement without admitting or denying the findings of the SEC’s investigation and paid a civil penalty of $7.5 million. This amount was paid in April 2016.

[0001032975-16-000097:notes:55]
Guarantees

[0001032975-16-000097:notes:56]
Logitech Europe S.A. guaranteed payments of certain third-party contract manufacturers’ purchase obligations. As of June 30, 2016, the maximum amount of this guarantee was $3.8 million, of which $1.3 million of guaranteed purchase obligations were outstanding.

[0001032975-16-000097:notes:57]
Indemnifications

[0001032975-16-000097:notes:58]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2016, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-16-000097:notes:59]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-16-000097:notes:60]
The Stock Purchase Agreement in connection with the investment by three venture capital firms in Lifesize, Inc. contains representations, warranties and covenants of Logitech and Lifesize, Inc. to the Investors. Logitech has agreed, subject to certain limitations, to indemnify the Investors and certain persons related to the Investors for certain losses resulting from breaches of or inaccuracies in such representations, warranties and covenants as well as certain other obligations, including third-party expenses, restructuring costs and pre-closing tax obligations of Lifesize.

[0001032975-16-000097:notes:61]
Legal Proceedings

[0001032975-16-000097:notes:62]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-16-000097:notes:63]
[same as prior period, unchanged from 0001032975-16-000068:notes:43]

[0001032975-16-000097:notes:64]
[same as prior period, unchanged from 0001032975-16-000068:notes:44]

[0001032975-16-000097:notes:65]
As of June 30, 2016, the Company offers the 2006 ESPP (2006 Employee Share Purchase Plan (Non-U.S.)), the 1996 ESPP (1996 Employee Share Purchase Plan (U.S.)), the 2006 Plan (2006 Stock Incentive Plan) and the 2012 Plan (2012 Stock Inducement Equity Plan).

[0001032975-16-000097:notes:66]
The following table summarizes the share-based compensation expense and related tax benefit recognized for the three months ended June 30, 2016 and 2015, excluding balances classified as discontinued operations (in thousands):

[0001032975-16-000097:notes:67]
|  |  |  | Three Months Ended June 30, |
|  |  |  | 2016 |  | 2015 |
| Cost of goods sold |  |  | $ | 675 |  |  | $ | 605 |  |
| Marketing and selling |  |  | 3,437 |  |  | 2,064 |  |
| Research and development |  |  | 914 |  |  | 673 |  |
| General and administrative |  |  | 3,491 |  |  | 3,174 |  |
| Restructuring |  |  | — |  |  | 7 |  |
| Total share-based compensation expense |  |  | 8,517 |  |  | 6,523 |  |
| Income tax benefit |  |  | (1,815 | ) |  | (1,337 | ) |
| Total share-based compensation expense, net of income tax |  |  | $ | 6,702 |  |  | $ | 5,186 |  |

[0001032975-16-000097:notes:68]
As of June 30, 2016 and 2015, the Company capitalized $0.5 million and $0.5 million of stock-based compensation expenses as inventory, respectively.

[0001032975-16-000097:notes:69]
[same as prior period, unchanged from 0001032975-16-000068:notes:49]

[0001032975-16-000097:notes:70]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The cost recorded of $2.8 million and $2.9 million for the three months ended June 30, 2016 and 2015, respectively, was primarily related to service costs.


## us-gaap:DebtDisclosureTextBlock

[0001032975-16-000097:notes:71]
Financing Arrangements

[0001032975-16-000097:notes:72]
The Company had several uncommitted, unsecured bank lines of credit aggregating $44.6 million as of June 30, 2016. There are no financial covenants under these lines of credit with which the Company must comply. As of June 30, 2016, the Company had outstanding bank guarantees of $15.6 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of June 30, 2016 or March 31, 2016.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-16-000097:notes:73]
Derivative Financial Instruments

[0001032975-16-000097:notes:74]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis on the condensed consolidated balance sheets as of June 30, 2016 and March 31, 2016.

[0001032975-16-000097:notes:75]
The fair values of the Company’s derivative instruments not designated as hedging instruments were not material as of June 30, 2016 or March 31, 2016. The following table presents the fair values of the Company’s derivative instruments designated as hedging instruments on a gross basis in other current assets or accrued and other current liabilities on its condensed consolidated balance sheets as of June 30, 2016 and March 31, 2016 (in thousands):

[0001032975-16-000097:notes:76]
|  |  | Derivatives |
|  |  | Asset |  | Liability |
|  |  | June 30,2016 |  | March 31,2016 |  | June 30,2016 |  | March 31,2016 |
| Cash flow hedges |  | $ | 186 |  |  | $ | 10 |  |  | $ | — |  |  | $ | 1,038 |  |

[0001032975-16-000097:notes:77]
The amount of gain (loss) recognized on derivatives not designated as hedging instruments were not material in all periods presented herein. The following table presents the amounts of gains (losses) on the Company’s derivative instruments designated as hedging instruments and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income for the three months ended June 30, 2016 and 2015 (in thousands):

[0001032975-16-000097:notes:78]
|  |  | Three Months EndedJune 30, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss After Reclassification to Costs of Goods Sold |  | Amount of Loss (Gain) Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Cash flow hedges |  | $ | 1,705 |  |  | $ | (4,722 | ) |  | $ | 740 |  |  | $ | (2,460 | ) |

[0001032975-16-000097:notes:79]
Cash Flow Hedges

[0001032975-16-000097:notes:80]
The Company enters into currency exchange forward contracts to hedge against exposure to changes in currency exchange rates related to its subsidiaries’ forecasted inventory purchases. The Company has one entity with a euro functional currency that purchases inventory in U.S. Dollars. The primary risk managed by using derivative instruments is the currency exchange rate risk. However, there can be no assurance the hedges will offset more than a portion of the financial impact resulting from movements in currency exchange rates. The Company has designated these derivatives as cash flow hedges. These hedging contracts mature within four months, and are denominated in the same currency as the underlying transactions. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. The Company assesses the effectiveness of the hedges by comparing changes in the spot rate of the currency underlying the forward contract with changes in the spot rate of the currency in which the forecasted transaction will be consummated. If the underlying transaction being hedged fails to occur or if a portion of the hedge does not generate offsetting changes in the currency exposure of forecasted inventory purchases, the Company immediately recognizes the gain or loss on the associated financial instrument in other expense, net. Such gains and losses were not material during the three months ended June 30, 2016 and 2015. Cash flows from such hedges are classified as operating activities in the condensed consolidated statements of cash flows. The notional amounts of currency exchange forward contracts outstanding related to forecasted inventory purchases were $64.6 million and $39.8 million at June 30, 2016 and March 31, 2016, respectively. The Company estimates that $0.1 million of net gains related to its cash flow hedges included in accumulated other comprehensive loss as of June 30, 2016 will be reclassified into earnings within the next 12 months.

[0001032975-16-000097:notes:81]
Other Derivatives

[0001032975-16-000097:notes:82]
The Company also enters into currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain foreign currency receivables or payables. These contracts generally mature within one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on currency exchange contracts are recognized in other expense, net based on the changes in fair value.

[0001032975-16-000097:notes:83]
The notional amounts of currency exchange forward and swap contracts outstanding as of June 30 and March 31, 2016 relating to foreign currency receivables or payables were $50.6 million and $63.7 million, respectively. Open forward and swap contracts outstanding at June 30, 2016 and March 31, 2016 consisted of contracts in Mexican Pesos, Japanese Yen, British Pounds, Taiwanese Dollars and Australian Dollars to be settled at future dates at pre-determined exchange rates.

[0001032975-16-000097:notes:84]
The fair value of all currency exchange forward and swap contracts is determined based on observable market transactions of spot currency rates and forward rates. Cash flows from these contracts are classified as operating activities in the condensed consolidated statements of cash flows.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001032975-16-000097:notes:85]
[same as prior period, unchanged from 0001032975-16-000068:notes:53]

[0001032975-16-000097:notes:86]
During the third quarter of fiscal year 2016, the Company's Board of Directors approved a plan to divest the Lifesize video conferencing business. Subsequently, on December 28, 2015 in the fourth quarter of fiscal year 2016, the Company and Lifesize, Inc.(“Lifesize”), a wholly owned subsidiary of the Company which held the assets of the Company’s video conferencing reportable segment, entered into a stock purchase agreement (the “Stock Purchase Agreement”) with entities affiliated with three venture capital firms - Redpoint Ventures, Sutter Hill Ventures and Meritech Capital Partners (the "Venture Investors").  Pursuant to the terms of the Stock Purchase Agreement, the Company sold 2.5 million shares of Series B Preferred Stock of Lifesize to the Venture Investors for cash proceeds of $2.5 million and retained 12 million non-voting shares of Series A Preferred Stock of Lifesize.  The shares of Series A Preferred Stock of Lifesize retained by the Company represent 37.5% of the total shares outstanding immediately after the closing of the transactions (the "Closing").  Lifesize also issued 17.5 million shares of Series B Preferred Stock to the Venture Investors for cash proceeds of $17.5 million. The shares of Series B Preferred Stock held by the Venture Investors represent 62.5% of the total shares outstanding immediately after the Closing.  In addition, Lifesize reserved 8 million shares of common stock for issuance pursuant to a stock plan to be adopted by Lifesize following the Closing (the “Employee Pool”), none of which are issued or outstanding at the Closing. The divestiture of the Lifesize video conferencing business was effective on December 28, 2015. The Stock Purchase Agreement contains representations, warranties and covenants of the parties and includes certain indemnification obligations of the Company to the Venture Investors. See “Note 12 - Commitments and Contingencies” for more information. The Stock Purchase Agreement also contains certain post-closing working capital adjustments. Post closing continuing involvement with the discontinued operations includes certain customary services and support which are expected to be provided to Lifesize during the transition period from December 28, 2015 until approximately the end of the third quarter of fiscal year 2017.

[0001032975-16-000097:notes:87]
The Company has classified the results of its Lifesize video conferencing business as discontinued operations in its condensed consolidated statements of operations for all periods presented since the disposition of the Lifesize video conferencing business represents a strategic shift that has a major effect on the Company's operations and financial results. The retained Series A Preferred Stock gives the Company no voting rights or any other significant influence over the disposed Lifesize video conferencing business, and therefore is accounted for as a cost method investment which is initially recognized at fair value of $5.6 million at the date of disposition of the Lifesize video conferencing business.

[0001032975-16-000097:notes:88]
Discontinued operations include results of the Lifesize video conferencing business. Discontinued operations also include other costs incurred by Logitech to effect the divestiture of the Lifesize video conferencing business. These costs include transaction charges, advisory and consulting fees and restructuring cost related to the Lifesize video conferencing business.

[0001032975-16-000097:notes:89]
The following table presents financial results of the video conferencing segment classified as discontinued operations for the three months ended June 30, 2015 (in thousands):

[0001032975-16-000097:notes:90]
|  |  | Three Months EndedJune 30, |
|  |  | 2015 |
| Net sales |  | $ | 22,634 |  |
| Cost of goods sold |  | 8,838 |  |
| Gross profit |  | 13,796 |  |
| Operating expenses: |  |  |  |
| Marketing and selling |  | 11,631 |  |
| Research and development |  | 5,663 |  |
| General and administrative |  | 1,692 |  |
| Restructuring charges, net |  | 1,457 |  |
| Total operating expenses |  | 20,443 |  |
| Operating loss from discontinued operations |  | (6,647 | ) |
| Interest expense and other expense, net |  | (93 | ) |
| Loss from discontinued operations before income taxes |  | (6,740 | ) |
| Benefit from income taxes |  | (1,317 | ) |
| Net loss from discontinued operations |  | $ | (5,423 | ) |


## us-gaap:EarningsPerShareTextBlock

[0001032975-16-000097:notes:91]
[same as prior period, unchanged from 0001032975-16-000068:notes:66]

[0001032975-16-000097:notes:92]
[same as prior period, unchanged from 0001032975-16-000068:notes:67]

[0001032975-16-000097:notes:93]
|  |  | Three Months Ended June 30, |
|  |  | 2016 |  | 2015 |
| Net Income (loss): |  |  |  |  |
| Continuing operations |  | $ | 21,941 |  |  | $ | 12,860 |  |
| Discontinued operations |  | — |  |  | (5,423 | ) |
| Net income |  | $ | 21,941 |  |  | $ | 7,437 |  |
| Shares used in net income (loss) per share computation: |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 162,130 |  |  | 164,431 |  |
| Effect of potentially dilutive equivalent shares |  | 2,173 |  |  | 2,464 |  |
| Weighted average shares outstanding - diluted |  | 164,303 |  |  | 166,895 |  |
| Net income (loss) per share - basic: |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.14 |  |  | $ | 0.08 |  |
| Discontinued operations |  | — |  |  | (0.03 | ) |
| Net income per share - basic |  | $ | 0.14 |  |  | $ | 0.05 |  |
| Net income (loss) per share - diluted: |  |  |  |  |
| Continuing operations |  | $ | 0.13 |  |  | $ | 0.08 |  |
| Discontinued operations |  | — |  |  | (0.04 | ) |
| Net income per share - diluted |  | $ | 0.13 |  |  | $ | 0.04 |  |

[0001032975-16-000097:notes:94]
Share equivalents attributable to outstanding stock options and restricted stock units ("RSUs") of 5.7 million and 7.3 million for the three months ended June 30, 2016 and 2015, respectively, were anti-dilutive and excluded from the calculation of diluted net income per share.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-16-000097:notes:95]
[same as prior period, unchanged from 0001032975-16-000068:notes:70]

[0001032975-16-000097:notes:96]
[same as prior period, unchanged from 0001032975-16-000068:notes:71]

[0001032975-16-000097:notes:97]
[same as prior period, unchanged from 0001032975-16-000068:notes:72]

[0001032975-16-000097:notes:98]
[same as prior period, unchanged from 0001032975-16-000068:notes:73]

[0001032975-16-000097:notes:99]
[same as prior period, unchanged from 0001032975-16-000068:notes:74]

[0001032975-16-000097:notes:100]
The following table presents the Company’s financial assets and liabilities, that were accounted for at fair value on a recurring basis, excluding assets related to the Company’s defined benefit pension plans, classified by the level within the fair value hierarchy (in thousands):

[0001032975-16-000097:notes:101]
|  |  | June 30, 2016 |  | March 31, 2016 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 60,000 |  |  | $ | — |  |  | $ | — |  |  | $ | 10,000 |  |  | $ | — |  |  | $ | — |  |
| Trading investments for deferred compensation plan: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 35 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,467 |  |  | $ | — |  |  | $ | — |  |
| Mutual funds |  | 14,962 |  |  | — |  |  | — |  |  | 11,369 |  |  | — |  |  | — |  |
| Total of trading investments for deferred compensation plan |  | $ | 14,997 |  |  | $ | — |  |  | $ | — |  |  | $ | 14,836 |  |  | $ | — |  |  | $ | — |  |
| Foreign exchange derivative assets |  | $ | — |  |  | $ | 186 |  |  | $ | — |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related contingent consideration |  | $ | — |  |  | $ | — |  |  | $ | 18,000 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Foreign exchange derivative liabilities |  | $ | — |  |  | $ | 231 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,132 |  |  | $ | — |  |

[0001032975-16-000097:notes:102]
[same as prior period, unchanged from 0001032975-16-000068:notes:78]

[0001032975-16-000097:notes:103]
The marketable securities for the Company's deferred compensation plan are recorded at a fair value of $15.0 million and $14.8 million as of June 30, 2016 and March 31, 2016, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized trading gains / (losses) related to trading securities for the three months ended June 30, 2016 and 2015 were not significant and are included in other expense, net.

[0001032975-16-000097:notes:104]
Acquisition-related contingent consideration

[0001032975-16-000097:notes:105]
The acquisition-related contingent consideration liability arising from the Jaybird Acquisition (see "Note 3 - Business Acquisition") represents the future potential earn-out payments of up to $45 million based on the achievement of certain net revenue growth targets over approximately a two year period. If the net revenue growth targets are met, the Company will pay $25 million and $20 million in fiscal year 2018 and 2019, respectively.  The fair value of the earn-out was determined by using a Monte Carlo Simulation that includes significant unobservable inputs such a risk adjusted discount rate of 16% and projected revenues of Jaybird over the earn-out period. The fair-value of the earn-out at the acquisition date of $18 million was recorded by the Company as of the Acquisition Date. The fair value of the contingent consideration is calculated on a quarterly basis. There was no change in the fair-value during the quarterly period ended June 30, 2016.

[0001032975-16-000097:notes:106]
Assets Measured at Fair Value on a Nonrecurring Basis

[0001032975-16-000097:notes:107]
The Company’s non-marketable cost method investments, and non-financial assets, such as goodwill, intangible assets and property, plant and equipment, are recorded at fair value only upon initial recognition or if an impairment is recognized. There were no impairments of long-lived assets during the three months ended June 30, 2016 or 2015.

[0001032975-16-000097:notes:108]
Non-marketable cost method investments. These investments are classified as Level 3 due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies.

[0001032975-16-000097:notes:109]
Included in non-marketable investments primarily is the Company’s investment in Series A Preferred Stock of Lifesize recorded at the fair value of $5.6 million on the date of the Lifesize divestiture.

[0001032975-16-000097:notes:110]
The aggregate recorded amount of cost method investments included in other assets at June 30, 2016 and March 31, 2016 was $7.4 million and $7.4 million, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-16-000097:notes:111]
[same as prior period, unchanged from 0001032975-16-000068:notes:93]

[0001032975-16-000097:notes:112]
The Company conducts its impairment analysis of the goodwill annually at December 31 and as necessary if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting units may be less than its carrying amount. There have been no events or circumstances during the three months ended June 30, 2016 that have required the Company to perform an interim assessment of goodwill.

[0001032975-16-000097:notes:113]
The following table summarizes the activity in the Company’s goodwill balance during the three months ended June 30, 2016 (in thousands):

[0001032975-16-000097:notes:114]
| As of March 31, 2016 |  | $ | 218,224 |  |
| Business acquisition (See Note 3) |  | 26,667 |  |
| Currency impact |  | (11 | ) |
| As of June 30, 2016 |  | $ | 244,880 |  |

[0001032975-16-000097:notes:115]
[same as prior period, unchanged from 0001032975-16-000068:notes:99]

[0001032975-16-000097:notes:116]
Amortization expense for other intangible assets was $1.7 million and $0.2 million for the three months ended June 30, 2016 and 2015, respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-16-000097:notes:117]
[same as prior period, unchanged from 0001032975-16-000068:notes:101]

[0001032975-16-000097:notes:118]
[same as prior period, unchanged from 0001032975-16-000068:notes:102]

[0001032975-16-000097:notes:119]
The income tax provision for the three months ended June 30, 2016 was $3.1 million based on an effective income tax rate of 12.2% of pre-tax income, compared to a nominal tax income benefit for the three months ended June 30, 2015.

[0001032975-16-000097:notes:120]
The change in the effective income tax rate for the three months ended June 30, 2016, compared to the three months ended June 30, 2015, is due to the mix of income and losses in the various tax jurisdictions in which the Company operates. In the three months ended June 30, 2015, there was a discrete tax benefit of $2.2 million from the preferential income tax rate reduction pursuant to the High and New Technology Enterprise Program in China.

[0001032975-16-000097:notes:121]
As of June 30 and March 31, 2016, the total amount of unrecognized tax benefits due to uncertain tax positions was $70.3 million and $69.9 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-16-000097:notes:122]
The Company had $59.7 million in non-current income taxes payable and $0.1 million in current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions as of June 30 and March 31, 2016.

[0001032975-16-000097:notes:123]
The Company recognizes interest and penalties related to unrecognized tax positions in income tax expense. As of June 30 and March 31, 2016, the Company had $3.8 million and $3.6 million of accrued interest and penalties related to uncertain tax positions, respectively.

[0001032975-16-000097:notes:124]
Although the Company has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During fiscal year 2017, the Company will continue to review its tax positions and provide for or reverse unrecognized tax benefits as issues arise. During the next 12 months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. dollar as compared to other currencies. Excluding these factors, uncertain tax positions may decrease by as much as $15.5 million from the lapse of the statutes of limitations in various jurisdictions during the next 12 months.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001032975-16-000097:notes:125]
[same as prior period, unchanged from 0001032975-16-000068:notes:110]

[0001032975-16-000097:notes:126]
|  |  | June 30,2016 |  | March 31,2016 |
| Americas |  | $ | 40,883 |  |  | $ | 40,221 |  |
| EMEA |  | 3,017 |  |  | 3,194 |  |
| Asia Pacific |  | 43,144 |  |  | 49,445 |  |
|  |  | $ | 87,044 |  |  | $ | 92,860 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001032975-16-000097:notes:127]
[same as prior period, unchanged from 0001032975-16-000068:notes:112]

[0001032975-16-000097:notes:128]
During the first quarter of fiscal year 2016, the Company implemented a restructuring plan to exit the OEM business, reorganize Lifesize to sharpen its focus on its cloud-based offering, and streamline the Company's overall cost structure through product, overhead and infrastructure cost reductions with a targeted resource realignment. Restructuring charges (credits) incurred during the three months ended June 30, 2016 under this plan primarily consisted of severance and other ongoing and one-time termination benefits. Charges and other costs related to the workforce reduction and structure realignment are presented as restructuring charges in the condensed consolidated statements of operations. On a total company basis, including the Lifesize video conferencing business as reported in discontinued operations, the Company has incurred approximately $25.4 million under this restructuring plan, including approximately $24.3 million for cash severance and other personnel costs. The Company substantially completed this restructuring plan by the fourth quarter of fiscal year 2016.

[0001032975-16-000097:notes:129]
The following tables summarize restructuring related activities during the three months ended June 30, 2016:

[0001032975-16-000097:notes:130]
|  |  | Restructuring |
|  |  | TerminationBenefits |  | Lease ExitCosts |  | Total |
| Accrual balance at March 31, 2016 |  | $ | 6,275 |  |  | $ | 125 |  |  | $ | 6,400 |  |
| Credits, net |  | (85 | ) |  | — |  |  | (85 | ) |
| Cash payments |  | (1,908 | ) |  | (125 | ) |  | (2,033 | ) |
| Accrual balance at June 30, 2016 |  | $ | 4,282 |  |  | $ | — |  |  | $ | 4,282 |  |


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001032975-16-000097:notes:131]
Net sales to unaffiliated customers by geographic region (based on the customers’ location) for the three months ended June 30, 2016 and 2015 were as follows (in thousands):

[0001032975-16-000097:notes:132]
|  |  | Three Months Ended June 30, |
|  |  | 2016 |  | 2015 |
| Americas |  | $ | 222,625 |  |  | $ | 215,675 |  |
| EMEA |  | 142,922 |  |  | 119,612 |  |
| Asia Pacific |  | 114,317 |  |  | 112,399 |  |
| Total net sales |  | $ | 479,864 |  |  | $ | 447,686 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001032975-16-000097:notes:133]
[same as prior period, unchanged from 0001032975-16-000068:notes:122]

[0001032975-16-000097:notes:134]
|  |  | Accumulated Other Comprehensive Income (Loss) |
|  |  | CumulativeTranslationAdjustment (1) |  | DefinedBenefitPlan (1) |  | DeferredHedgingGains (Losses) |  | Total |
| March 31, 2016 |  | $ | (84,038 | ) |  | $ | (26,171 | ) |  | $ | (1,776 | ) |  | $ | (111,985 | ) |
| Other comprehensive income (loss) |  | (296 | ) |  | 743 |  |  | 1,705 |  |  | 2,152 |  |
| June 30, 2016 |  | $ | (84,334 | ) |  | $ | (25,428 | ) |  | $ | (71 | ) |  | $ | (109,833 | ) |

[0001032975-16-000097:notes:135]
(1)        Tax effect was not significant as of June 30 or March 31, 2016.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001032975-16-000097:notes:136]
Net sales by product categories and sales channels, excluding intercompany transactions, for the three months ended June 30, 2016 and 2015 were as follows (in thousands):

[0001032975-16-000097:notes:137]
|  |  | Three Months Ended June 30, |
|  |  | 2016 |  | 2015 |
| Mobile Speakers |  | $ | 57,296 |  |  | $ | 40,544 |  |
| Audio-PC & Wearables |  | 56,579 |  |  | 45,699 |  |
| Gaming |  | 56,500 |  |  | 43,670 |  |
| Video Collaboration |  | 23,910 |  |  | 21,176 |  |
| Home Control |  | 11,167 |  |  | 10,254 |  |
| Pointing Devices |  | 116,783 |  |  | 116,985 |  |
| Keyboards & Combos |  | 118,019 |  |  | 105,829 |  |
| Tablet & Other Accessories |  | 13,885 |  |  | 18,809 |  |
| PC Webcams |  | 25,262 |  |  | 21,681 |  |
| Other (1) |  | 463 |  |  | 741 |  |
| Total net retail sales |  | 479,864 |  |  | 425,388 |  |
| OEM |  | — |  |  | 22,298 |  |
| Total net sales |  | $ | 479,864 |  |  | $ | 447,686 |  |

[0001032975-16-000097:notes:138]
| (1) | Other category includes products that the Company currently intends to transition out of, or has already transitioned out of, because they are no longer strategic to the Company's business. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-16-000097:notes:139]
[same as prior period, unchanged from 0001032975-16-000068:notes:127]

[0001032975-16-000097:notes:140]
The Company has determined that it operates in a single operating segment that encompasses the design, manufacturing and marketing of peripherals for PCs, tablets and other digital platforms.  Operating performance measures are provided directly to the Company's Chief Executive Officer (“CEO”), who is considered to be the Company’s Chief Operating Decision Maker (“CODM”). The CEO periodically reviews information such as net sales and operating income (loss) to make business decisions. These operating performance measures do not include restructuring charges, net, share-based compensation expense and amortization of intangible assets, and the charges (credits) from purchase accounting effect.

[0001032975-16-000097:notes:141]
Sales are attributed to countries on the basis of the customers’ locations. The United States represented 41% and 42% of the Company’s total consolidated net sales from continuing operations for the three months ended June 30, 2016 and 2015, respectively. No other single country represented more than 10% of the Company's total consolidated net sales during those periods. One customer group of the Company represented 13% and 14% of total consolidated net sales from continuing operations for the three months ended June 30, 2016 and 2015, respectively. Another customer group of the Company represented 12% of sales for the three months ended June 30, 2016.

[0001032975-16-000097:notes:142]
[same as prior period, unchanged from 0001032975-16-000068:notes:133]

[0001032975-16-000097:notes:143]
Long-lived assets in the United States and China were $38.1 million and $38.1 million as of June 30, 2016, respectively, and $40.0 million and $44.5 million at March 31, 2016, respectively. No other countries represented more than 10% of the Company’s total consolidated long-lived assets as of June 30 or March 31, 2016. Long-lived assets in Switzerland, the Company’s home domicile, were $1.5 million and $1.7 million at June 30 and March 31, 2016, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-16-000097:notes:144]
[same as prior period, unchanged from 0001032975-16-000068:notes:135]

[0001032975-16-000097:notes:145]
[same as prior period, unchanged from 0001032975-16-000068:notes:136]

[0001032975-16-000097:notes:146]
In March 2014, the Company’s Board of Directors approved the 2014 share buyback program, which authorizes the Company to use up to $250.0 million to purchase its own shares. The Company’s share buyback program is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or trading plan or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. During the three months ended June 30, 2016 and 2015, 1.6 million and 0.6 million shares were repurchased for $24.4 million and $8.8 million, respectively.

[0001032975-16-000097:notes:147]
Accumulated Other Comprehensive Loss


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-16-000097:notes:148]
[same as prior period, unchanged from 0001032975-16-000068:notes:142]
