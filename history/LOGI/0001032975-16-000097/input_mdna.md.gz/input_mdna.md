# LOGI MD&A — 0001032975-16-000097


## mdna

[0001032975-16-000097:mdna:1]
[same as prior period, unchanged from 0001032975-16-000068:mdna:1]

[0001032975-16-000097:mdna:2]
You should read the following discussion in conjunction with the interim unaudited condensed consolidated financial statements and related notes.

[0001032975-16-000097:mdna:3]
[same as prior period, unchanged from 0001032975-16-000068:mdna:3]

[0001032975-16-000097:mdna:4]
Logitech is a world leader in designing products that have an every day place in people's lives, connecting them to the digital experiences they care about. Over 30 years ago we started connecting people through computers, and now we are designing products that bring people together through music, gaming, video and computing.

[0001032975-16-000097:mdna:5]
We design, manufacture and market products that allow people to connect through music, gaming, video, computing, and other digital platforms. Our products participate in five large markets that all have growth potential:

[0001032975-16-000097:mdna:6]
| • | Music: This market is comprised of both wired and wireless devices that capitalize on the rapid growth of streaming music. Products in this category include mobile speakers, audio-PC & wearables, and headsets connecting to all music services used on both PCs and mobile devices. |

[0001032975-16-000097:mdna:7]
| • | Gaming: The Gaming market includes products designed for PCs and gaming consoles as well as devices designed to deliver new gaming experiences such as virtual and augmented reality. The rapid rise of eSports, and the promise of new implementations in virtual and augmented reality present growth opportunities in this market. Our products in Gaming include mice and keyboards, headsets, gamepads and steering wheels. |

[0001032975-16-000097:mdna:8]
| • | Video Collaboration: Video Collaboration is focused on delivering solutions that enable real-time video, audio and content sharing capability to businesses and individuals. With the rapid adoption of cloud-based solutions that can lower the cost of adoption, our devices and solutions enable the rapid deployment of these cloud-based services through our platform agnostic, easy-to-use end points and peripherals. |

[0001032975-16-000097:mdna:9]
| • | Home: The connected home is a market in its early stages of formation and growth. The push to realize the vision of the Internet-of-Things is delivering more and more connected devices that populate our homes, from the more traditionally connected devices like set-top boxes and digital entertainment devices to things like appliances, lighting, door locks and thermostats. We have a foundation for growth in this market through the entertainment control capabilities in our Harmony products. |

[0001032975-16-000097:mdna:10]
| • | Creativity and Productivity: This market is defined by products that enhance the users’ experiences associated with computing platforms. With ever increasing connectivity globally and the consistent growth in time spent by people on these computing platforms, we believe there are meaningful growth opportunities for our products. Our continued innovation in navigation, input and content creation on these platforms can drive growth in this market despite the secular decline of new PC sales. Pointing Devices, Keyboards & Combos, Tablet & Other Accessories, and PC Webcams comprise our product categories that address this market. |

[0001032975-16-000097:mdna:11]
We sell our products to a broad network of domestic and international customers, including direct sales to retailers, e-tailers, and indirect sales through distributors. Our worldwide retail network includes consumer electronics distributors, retailers, mass merchandisers, specialty electronics stores, computer and telecommunications stores, value-added resellers and online merchants.

[0001032975-16-000097:mdna:12]
We seek to fulfill the increasing demand for interfaces between people and the expanding digital world across multiple platforms and user environments. The interface evolves as platforms, user models and our target markets evolve. As access to digital information has expanded, we have extended our focus to mobile devices, the digital home, and the digital world. All of these platforms require interfaces that are customized according to how the devices are used. We believe that continued investment in product research and development is critical to creating the innovation required to strengthen our competitive advantage and to drive future sales growth. We are committed to identifying and meeting current and future consumer trends with new and improved product technologies, as well as leveraging the value of the Logitech brand from a competitive, channel partner, and consumer experience perspective.

[0001032975-16-000097:mdna:13]
We believe that innovation, design and product quality are important to gaining market acceptance and maintaining market leadership.

[0001032975-16-000097:mdna:14]
[same as prior period, unchanged from 0001032975-16-000068:mdna:15]

[0001032975-16-000097:mdna:15]
In fiscal years prior to fiscal year 2016, we had two segments: Peripherals, including retail and OEM products; and Lifesize Video Conferencing. During fiscal year 2016, we divested the Lifesize Video Conferencing segment, and exited the OEM business. Our financial results treat the Lifesize segment as discontinued operations for all the periods presented in this Quarterly Report on Form 10-Q. Unless indicated otherwise, the information included in Item 2 relates to our continuing operations and historical financial information has been recast to conform to this presentation within our condensed consolidated financial statements.

[0001032975-16-000097:mdna:16]
27

[0001032975-16-000097:mdna:17]
On April 20, 2016, we acquired Jaybird for a purchase price of $54.2 million, including a working capital adjustment and payment of line-of-credit on behalf of Jaybird, along with an additional earn-out of up to $45 million based on achievement of growth targets over two years. Jaybird is a leader in wireless audio wearables for sports and active lifestyles, and the acquisition of Jaybird expands our long-term growth potential in our Music market.

[0001032975-16-000097:mdna:18]
[same as prior period, unchanged from 0001032975-16-000068:mdna:24]

[0001032975-16-000097:mdna:19]
Our net sales for the three months ended June 30, 2016 increased 7% compared to the three months ended June 30 2015, due to stronger retail sales, partially offset by the exit of OEM business in the quarter ended December 31, 2015.

[0001032975-16-000097:mdna:20]
Our retail sales for the three months ended June 30, 2016 increased 13% compared to the three months ended June 30, 2015. Retail sales increased 7%, 24% and 12% in the Americas ("AMR"), EMEA and Asia Pacific, respectively.

[0001032975-16-000097:mdna:21]
Our gross margin for the three months ended June 30, 2016 decreased to 35.1% from 35.3% for the three months ended June 30, 2015. The decrease in gross margin is primarily driven by the unfavorable fluctuations in currency exchange rates, amortization of intangibles and purchase accounting effect on inventories from the Jaybird Acquisition, partially offset by the exit of the OEM business, product cost reductions, and savings from supply chain efficiency.

[0001032975-16-000097:mdna:22]
Operating expenses for the three months ended June 30, 2016 were 29.8% of net sales, compared to 32.2% in the same period of the prior fiscal year. The decrease was primarily due to decrease in restructuring charges and cost savings, partially offset by amortization of intangibles and acquisition-related costs from the business combination during the current period, and unfavorable fluctuations in currency exchange rates.

[0001032975-16-000097:mdna:23]
The results of operations for Jaybird has been included in our condensed consolidated statements of operations from the acquisition date. Jaybird contributed $14.3 million net sales and $1.8 million operating loss, which includes $1.7 million amortization of intangible assets resulting from the acquisition and $0.7 million of purchase accounting effect on inventory.

[0001032975-16-000097:mdna:24]
Net income from continuing operations for the three months ended June 30, 2016 was $21.9 million, compared to $12.9 million for the three months ended June 30, 2015.

[0001032975-16-000097:mdna:25]
Given our global sales presence and the reporting of our financial results in U.S. Dollars, our financial results in fiscal year 2017 and 2016 have been affected by significant shifts in currency exchange rates. See “Results of Operations” for information on the effect of currency exchange results on our net sales. If the U.S. Dollar remains at its current strong levels in comparison to other currencies, this will affect our results of operations in future periods as well.

[0001032975-16-000097:mdna:26]
[same as prior period, unchanged from 0001032975-16-000068:mdna:36]

[0001032975-16-000097:mdna:27]
Our strategy focuses on five large multi-category markets, including Music, Gaming, Video Collaboration, Home and Creativity & Productivity. We see opportunities to deliver growth in all these markets.

[0001032975-16-000097:mdna:28]
We believe our future growth will be determined by our ability to rapidly create innovative products across multiple digital platforms, including gaming and digital music devices. The following discussion represents key trends specific to our market opportunities.

[0001032975-16-000097:mdna:29]
Trends Specific to Our Five Market Opportunities

[0001032975-16-000097:mdna:30]
Music:  The music market grew during the first quarter of fiscal year 2017, driven by growing consumption of music through mobile devices such as smartphones and tablets. This market growth, together with our investments in the UE brand, our introduction of new products and our ability to gain market share, has driven our growth in this market.

[0001032975-16-000097:mdna:31]
Gaming:  The PC Gaming platform continues to show strong growth as online gaming and multi-platform experiences gain greater popularity and gaming content becomes increasingly more demanding. We believe Logitech is well positioned to benefit from the gaming market growth.

[0001032975-16-000097:mdna:32]
Video Collaboration:   We continue to focus our efforts on creating and selling innovative products, including Video Collaboration products, to accommodate the increasing demand from medium-sized meeting rooms to small-sized rooms such as huddle rooms. During fiscal year 2016, we launched Logitech Group, a transformation in team collaboration that provides high-quality HD video conferencing for groups of up to 20 people and works with the video conferencing applications already in use. We will continue to invest in selected business specific products, targeted product marketing and sales channel development.

[0001032975-16-000097:mdna:33]
Home:  This market increased in fiscal year 2016 and continued growing in fiscal year 2017.

[0001032975-16-000097:mdna:34]
Creativity & Productivity: Although new PC shipments continue to decline, the installed base of PC users is large.  We believe that innovative PC peripherals, such as our mice and keyboards, can renew the PC usage experience, providing growth opportunities. Smaller mobile computing devices, such as tablets with touch interfaces, have created new markets and usage models for peripherals and accessories. We offer a number of products to enhance the use of mobile devices, including keyboard folios for the iPad and iPad mini, and keyboard covers and folios for the iPad Air. However, we have seen the market decline for the iPad platform, which has impacted the sales of our tablet accessories.

[0001032975-16-000097:mdna:35]
Business Application Suite:

[0001032975-16-000097:mdna:36]
In fiscal year 2016, we upgraded our worldwide business application suite from Oracle version 11i to Oracle version R12.  As a result, during fiscal year 2016 this upgrade created delays in our processing of customer claims related to cooperative marketing arrangements, direct and indirect customer incentive programs and pricing programs that resulted in higher accruals and allowances for such programs.  We have been working to enhance the operational efficiency of the claims processing module in our worldwide business application suite which thus far has yielded positive results.

[0001032975-16-000097:mdna:37]
Business Seasonality and Product Introductions

[0001032975-16-000097:mdna:38]
We have historically experienced higher net sales in our third fiscal quarter ending December 31, compared to other fiscal quarters in our fiscal year, due in part to seasonal holiday demand. Additionally, new product introductions can significantly impact net sales, product costs and operating expenses. Product introductions can also impact our net sales to our distribution channels as these channels are filled with new product inventory following a product introduction, and often channel inventory of an earlier model product declines as the next related major product launch approaches. Net sales can also be affected when consumers and distributors anticipate a product introduction. However, neither historical seasonal patterns nor historical patterns of product introductions should be considered reliable indicators of our future pattern of product introductions, future net sales or financial performance.

[0001032975-16-000097:mdna:39]
[same as prior period, unchanged from 0001032975-16-000068:mdna:18]

[0001032975-16-000097:mdna:40]
The preparation of financial statements and related disclosures in conformity with U.S. GAAP (Generally Accepted Accounting Principles in the United States of America) requires us to make judgments, estimates and assumptions that affect reported amounts of assets, liabilities, goodwill and intangible assets from business acquisitions, net sales and expenses, contingent consideration, and the disclosure of contingent assets and liabilities.

[0001032975-16-000097:mdna:41]
We consider an accounting estimate critical if it: (i) requires management to make judgments and estimates about matters that are inherently uncertain; and (ii) is important to an understanding of our financial condition and operating results.

[0001032975-16-000097:mdna:42]
We base our estimates on historical experience and on various other assumptions we believe to be reasonable under the circumstances. Although these estimates are based on management's best knowledge of current events and actions that may impact us in the future, actual results could differ from those estimates. Management has discussed the development, selection and disclosure of these critical accounting estimates with the Audit Committee of the Board of Directors.

[0001032975-16-000097:mdna:43]
Accounting for business combinations requires us to make significant estimates and assumptions, especially at the acquisition date with respect to tangible and intangible assets acquired and liabilities assumed and pre-

[0001032975-16-000097:mdna:44]
29

[0001032975-16-000097:mdna:45]
acquisition contingencies. We use our best estimates and assumptions to accurately assign fair value to the tangible and intangible assets acquired and liabilities assumed at the acquisition date.

[0001032975-16-000097:mdna:46]
Examples of critical estimates in valuing certain intangible assets and goodwill we have acquired include but are not limited to:

[0001032975-16-000097:mdna:47]
•royalty rate range and forecasted revenue growth rate assumptions;

[0001032975-16-000097:mdna:48]
| • | assumption regarding the estimated useful life of the acquired intangible; |

[0001032975-16-000097:mdna:49]
| • | discount rates |

[0001032975-16-000097:mdna:50]
Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results.

[0001032975-16-000097:mdna:51]
The economic useful life of the developed technology from the Jaybird Acquisition was determined based on the technology cycle related to developed technology of existing products, as well as the cash flows over the forecast period.

[0001032975-16-000097:mdna:52]
The economic useful life of the customer relationships from the Jaybird Acquisition was determined based on historical customer turnover rates and the industry benchmarks.

[0001032975-16-000097:mdna:53]
The economic useful life of the trade name from the Jaybird Acquisition was determined based on the expected life of the trade name and the cash flows anticipated over the forecasted periods.

[0001032975-16-000097:mdna:54]
The acquisition-related contingent consideration liability arising from the Jaybird Acquisition (see "Note 3 - Business Acquisition) represents the future potential earn-out payments of up to $45 million based on the achievement of certain net revenue growth targets over approximately a two year period. If the net revenue growth targets are met, the Company will pay $25 million and $20 million in fiscal year 2018 and 2019, respectively.  The fair value of the earn-out was determined by using a Monte Carlo Simulation that includes significant unobservable inputs such a risk adjusted discount rate of 16% and projected revenues of Jaybird over the earn-out period. The fair-value of the earn-out at the acquisition date of $18 million was recorded by the Company as of the acquisition date. The fair value of the contingent consideration is calculated on a quarterly basis. There was no change in the fair-value during the quarterly period ended June 30, 2016.

[0001032975-16-000097:mdna:55]
There have been no other new or material changes to the critical accounting policies and estimates discussed in our Annual Report on Form 10-K for the fiscal year ended March 31, 2016 that are of significance, or potential significance to the Company.

[0001032975-16-000097:mdna:56]
Impact of Constant Currency

[0001032975-16-000097:mdna:57]
We refer to our net sales excluding the impact of currency exchange rate fluctuations as "constant dollar" sales.  Percentage of constant dollar sales growth is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.

[0001032975-16-000097:mdna:58]
[same as prior period, unchanged from 0001032975-16-000068:mdna:51]

[0001032975-16-000097:mdna:59]
[same as prior period, unchanged from 0001032975-16-000068:mdna:52]

[0001032975-16-000097:mdna:60]
Net sales by channel for the three months ended June 30, 2016 and 2015 were as follows (Dollars in thousands):

[0001032975-16-000097:mdna:61]
|  |  | Three Months EndedJune 30, |
|  |  | 2016 |  | 2015 |  | Change |
| Retail |  | $ | 479,864 |  |  | $ | 425,388 |  |  | 13 | % |
| OEM |  | — |  |  | 22,298 |  |  | (100 | ) |
| Total net sales |  | $ | 479,864 |  |  | $ | 447,686 |  |  | 7 |  |

[0001032975-16-000097:mdna:62]
[same as prior period, unchanged from 0001032975-16-000068:mdna:55]

[0001032975-16-000097:mdna:63]
Our net retail sales in the three months ended June 30, 2016 increased 13% compared to the same period of the prior fiscal year. Sales increased across all regions during the three months ended June 30, 2016. If currency exchange rates had been constant in the three months ended June 30, 2016 and 2015, our constant dollar retail sales would have increased by 13%.

[0001032975-16-000097:mdna:64]
Sales Denominated in Other Currencies

[0001032975-16-000097:mdna:65]
Although our financial results are reported in U.S. Dollars, a portion of our sales were generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Canadian Dollar, Taiwan Dollar, British Pound and Australian Dollar. During the three months ended June 30, 2016, 45% our net sales were denominated in currencies other than the U.S. Dollar.

[0001032975-16-000097:mdna:66]
[same as prior period, unchanged from 0001032975-16-000068:mdna:61]

[0001032975-16-000097:mdna:67]
The following table presents the change in retail sales by region for the three months ended June 30, 2016, compared to the three months ended June 30, 2015:

[0001032975-16-000097:mdna:68]
|  |  | Three Months EndedJune 30, 2016Change in Retail Sales |
| Americas |  | 7 | % |
| EMEA |  | 24 |  |
| Asia Pacific |  | 12 |  |

[0001032975-16-000097:mdna:69]
[same as prior period, unchanged from 0001032975-16-000068:mdna:64]

[0001032975-16-000097:mdna:70]
Retail sales in the Americas region increased 7% during the three months ended June 30, 2016, compared to the same period of the prior fiscal year. If currency exchange rates had been constant in the three months ended June 30, 2016 and 2015, our constant dollar retail sales would have increased 8% in the Americas. This increase was led by growth in Mobile Speakers and Audio-PC & Wearables.

[0001032975-16-000097:mdna:71]
[same as prior period, unchanged from 0001032975-16-000068:mdna:66]

[0001032975-16-000097:mdna:72]
Retail sales in the EMEA region increased 24% during the three months ended June 30, 2016, compared to the same period of the prior fiscal year. If currency exchange rates had been constant in the three months ended June 30, 2016 and 2015, our constant dollar retail sales would have increased 22% in EMEA. Excluding the currency impact, this increase was led by growth in Keyboards & Combos, Mobile Speakers, Video Collaboration and Gaming.

[0001032975-16-000097:mdna:73]
[same as prior period, unchanged from 0001032975-16-000068:mdna:68]

[0001032975-16-000097:mdna:74]
Retail sales in the Asia Pacific region increased 12% during the three months ended June 30, 2016, compared to the same period of the prior fiscal year. If currency exchange rates had been constant in the three months ended June 30, 2016 and 2015, our constant dollar retail sales would have increased 14% in Asia Pacific. We achieved sales increases in Video Collaboration, Keyboards & Combos, and Gaming, during the three months ended June 30, 2016.

[0001032975-16-000097:mdna:75]
Net Retail Sales by Product Categories

[0001032975-16-000097:mdna:76]
Net sales by product category for the three months ended June 30, 2016 and 2015 were as follows (Dollars in thousands):

[0001032975-16-000097:mdna:77]
|  |  | Three Months EndedJune 30, |
|  |  | 2016 |  | 2015 |  | Change |
| Mobile Speakers |  | $ | 57,296 |  |  | $ | 40,544 |  |  | 41 | % |
| Audio-PC & Wearables |  | 56,579 |  |  | 45,699 |  |  | 24 |  |
| Gaming |  | 56,500 |  |  | 43,670 |  |  | 29 |  |
| Video Collaboration |  | 23,910 |  |  | 21,176 |  |  | 13 |  |
| Home Control |  | 11,167 |  |  | 10,254 |  |  | 9 |  |
| Pointing Devices |  | 116,783 |  |  | 116,985 |  |  | — |  |
| Keyboards & Combos |  | 118,019 |  |  | 105,829 |  |  | 12 |  |
| Tablet & Other Accessories |  | 13,885 |  |  | 18,809 |  |  | (26 | ) |
| PC Webcams |  | 25,262 |  |  | 21,681 |  |  | 17 |  |
| Other (1) |  | 463 |  |  | 741 |  |  | (38 | ) |
| Total net retail sales |  | $ | 479,864 |  |  | $ | 425,388 |  |  | 13 |  |

[0001032975-16-000097:mdna:78]
(1) Other category includes products that we currently intend to transition out of, or have already transitioned out of, because they are no longer strategic to our business.

[0001032975-16-000097:mdna:79]
Retail Sales by Product Categories

[0001032975-16-000097:mdna:80]
Music market:

[0001032975-16-000097:mdna:81]
[same as prior period, unchanged from 0001032975-16-000068:mdna:78]

[0001032975-16-000097:mdna:82]
[same as prior period, unchanged from 0001032975-16-000068:mdna:79]

[0001032975-16-000097:mdna:83]
Retail sales of Mobile Speakers increased 41% for the three month period ended June 30, 2016, compared to the same period of the prior fiscal year. Mobile Speaker sales increased primarily due to the introduction of the UE BOOM 2 in the second quarter of fiscal year 2016 and the continued success of the UE Megaboom.

[0001032975-16-000097:mdna:84]
[same as prior period, unchanged from 0001032975-16-000068:mdna:102]

[0001032975-16-000097:mdna:85]
Our retail Audio-PC & Wearables category comprises PC speakers, PC headsets and earbuds.

[0001032975-16-000097:mdna:86]
Audio-PC & Wearables sales increased 24% for the three months ended June 30, 2016, compared to the same period of the prior fiscal year. The increase was driven by the new product introduction of the Jaybird X2 Sport Bluetooth and Freedom F5 earbuds, resulting from the Jaybird Acquisition in the first quarter of fiscal year 2017 (see Note 3 - "Business Acquisition" to the condensed consolidated financial statements).

[0001032975-16-000097:mdna:87]
Gaming market:

[0001032975-16-000097:mdna:88]
[same as prior period, unchanged from 0001032975-16-000068:mdna:81]

[0001032975-16-000097:mdna:89]
[same as prior period, unchanged from 0001032975-16-000068:mdna:82]

[0001032975-16-000097:mdna:90]
Retail sales of Gaming increased 29% for the three months ended June 30, 2016, compared to the same period of the prior fiscal year.  Gaming sales increased significantly primarily driven by the new product launch of our G502 Proteus Spectrum gaming mouse and increased sales from our G29 Driving Force Race Wheel.

[0001032975-16-000097:mdna:91]
Video Collaboration market:

[0001032975-16-000097:mdna:92]
[same as prior period, unchanged from 0001032975-16-000068:mdna:85]

[0001032975-16-000097:mdna:93]
Our retail Video Collaboration category primarily includes video products and certain headset products that can connect small- and medium-sized user groups.

[0001032975-16-000097:mdna:94]
Retail sales of Video Collaboration increased 13% in the three months ended June 30, 2016, compared to the same period of the prior fiscal year.  The increase was primarily due to growth in our conference cams, including the Logitech Group conference camera introduced in the fourth quarter of fiscal year 2016, in addition to strong sales from our C930e Webcam.

[0001032975-16-000097:mdna:95]
Home market:

[0001032975-16-000097:mdna:96]
[same as prior period, unchanged from 0001032975-16-000068:mdna:110]

[0001032975-16-000097:mdna:97]
[same as prior period, unchanged from 0001032975-16-000068:mdna:111]

[0001032975-16-000097:mdna:98]
Home Control retail sales increased 9% in the three months ended June 30, 2016, compared to the same period of the prior fiscal year. This increase primarily was due to successful sales from our Harmony Elite.

[0001032975-16-000097:mdna:99]
Creativity and Productivity Market:

[0001032975-16-000097:mdna:100]
[same as prior period, unchanged from 0001032975-16-000068:mdna:94]

[0001032975-16-000097:mdna:101]
[same as prior period, unchanged from 0001032975-16-000068:mdna:95]

[0001032975-16-000097:mdna:102]
Retail sales of Pointing Devices remained flat in the three months ended June 30, 2016, compared to the same period of the prior fiscal year.

[0001032975-16-000097:mdna:103]
[same as prior period, unchanged from 0001032975-16-000068:mdna:98]

[0001032975-16-000097:mdna:104]
[same as prior period, unchanged from 0001032975-16-000068:mdna:99]

[0001032975-16-000097:mdna:105]
Retail sales of Keyboards & Combos increased 12% in the three months ended June 30, 2016, compared to the same period of the prior fiscal year. The sales increase was primarily driven by strong sales in both keyboard and keyboard combination cordless product types compared to the same period of the prior fiscal year.

[0001032975-16-000097:mdna:106]
[same as prior period, unchanged from 0001032975-16-000068:mdna:88]

[0001032975-16-000097:mdna:107]
[same as prior period, unchanged from 0001032975-16-000068:mdna:89]

[0001032975-16-000097:mdna:108]
Retail sales of Tablet & Other Accessories decreased 26% in the three months ended June 30, 2016, compared to the same period of the prior fiscal year. The reduction in sales reflects the combination of a declining market for iPad shipments, partially offset by the new product introduction of the Create backlit tablet keyboard case for iPad Pro.

[0001032975-16-000097:mdna:109]
[same as prior period, unchanged from 0001032975-16-000068:mdna:106]

[0001032975-16-000097:mdna:110]
[same as prior period, unchanged from 0001032975-16-000068:mdna:107]

[0001032975-16-000097:mdna:111]
Retail PC Webcams sales increased 17% in the three months ended June 30, 2016, compared to the same period of the prior fiscal year. The increase was primarily driven by strong sales of our HD Pro Webcam C920.

[0001032975-16-000097:mdna:112]
Other

[0001032975-16-000097:mdna:113]
This category comprises a variety of products that we currently intend to transition out of, or have already transitioned out of, because they are no longer strategic to our business. Products currently included in this category include TV camera, TV and home speakers, Keyboard/Desktop accessories, and music docks.

[0001032975-16-000097:mdna:114]
[same as prior period, unchanged from 0001032975-16-000068:mdna:120]

[0001032975-16-000097:mdna:115]
Gross profit for three months ended June 30, 2016 and 2015 was as follows (Dollars in thousands):

[0001032975-16-000097:mdna:116]
|  |  | Three Months EndedJune 30, |
|  |  | 2016 |  | 2015 |  | Change |
| Net sales |  | $ | 479,864 |  |  | $ | 447,686 |  |  | 7 | % |
| Cost of goods sold |  | 309,625 |  |  | 289,753 |  |  | 7 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 1,613 |  |  | — |  |  | NM |  |
| Gross profit |  | $ | 168,626 |  |  | $ | 157,933 |  |  | 7 |  |
| Gross margin |  | 35.1 | % |  | 35.3 | % |  |  |

[0001032975-16-000097:mdna:117]
[same as prior period, unchanged from 0001032975-16-000068:mdna:128]

[0001032975-16-000097:mdna:118]
Gross profit consists of net sales, less cost of goods sold, which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, royalties, costs of purchasing components from outside suppliers, distribution costs, warranty costs, customer support, outside processing costs and write-down of inventories, and less amortization of intangible assets and purchase accounting effect on inventory, which includes $0.7 million from purchase accounting effect on inventory and $0.9 million from amortization of intangible assets from developed technology as a result of the Jaybird Acquisition.

[0001032975-16-000097:mdna:119]
Gross margin decreased for the three months ended June 30, 2016 compared to the same periods of the prior fiscal year. The decrease in gross margin is primarily driven by amortization of intangibles assets and purchase accounting effect on inventories from the Jaybird Acquisition during the current period, and the unfavorable fluctuations in currency exchange rates, partially offset by product cost reductions, and savings from supply chain efficiency.

[0001032975-16-000097:mdna:120]
[same as prior period, unchanged from 0001032975-16-000068:mdna:125]

[0001032975-16-000097:mdna:121]
Operating expenses for the three months ended June 30, 2016 and 2015 were as follows (Dollars in thousands):

[0001032975-16-000097:mdna:122]
|  |  | Three Months EndedJune 30, |  |
|  |  | 2016 |  | 2015 |  | Change |  |
| Marketing and selling |  | $ | 83,872 |  |  | $ | 75,796 |  |  | 11 | % |  |
| % of net sales |  | 17.5 | % |  | 16.9 | % |  |  |  |  |
| Research and development |  | 31,951 |  |  | 28,002 |  |  | 14 |  |  |
| % of net sales |  | 6.7 | % |  | 6.3 | % |  |  |  |  |
| General and administrative |  | 25,740 |  |  | 28,812 |  |  | (11 | ) |  |
| % of net sales |  | 5.4 | % |  | 6.4 | % |  |  |  |  |
| Amortization of intangibles and acquisition related costs |  | 1,293 |  |  | 168 |  |  | 670 |  |  |
| % of net sales |  | 0.3 | % |  | — | % |  |  |  |
| Restructuring charges (credits), net |  | (85 | ) |  | 11,538 |  |  | (101 | ) |  |
| % of net sales |  | — | % |  | 2.6 | % |  |  |  |  |
| Total operating expenses |  | $ | 142,771 |  |  | $ | 144,316 |  |  | (1 | ) |  |
| % of net sales |  | 29.8 | % |  | 32.2 | % |  |  |  |  |

[0001032975-16-000097:mdna:123]
[same as prior period, unchanged from 0001032975-16-000068:mdna:129]

[0001032975-16-000097:mdna:124]
Marketing and selling expenses consist of personnel and related overhead, corporate and product marketing, advertising, trade shows, customer and technical support and facilities costs, and amortization of intangible assets.

[0001032975-16-000097:mdna:125]
During the three months ended June 30, 2016, marketing and selling expenses increased 11% compared to the same period in the prior fiscal year. The increase is primarily driven by the increase in personnel related costs due to the increased headcount during the last twelve months to expand the marketing team to support the advertising and marketing efforts for our products, as well as the increased headcount resulting from the Jaybird Acquisition.

[0001032975-16-000097:mdna:126]
[same as prior period, unchanged from 0001032975-16-000068:mdna:134]

[0001032975-16-000097:mdna:127]
[same as prior period, unchanged from 0001032975-16-000068:mdna:135]

[0001032975-16-000097:mdna:128]
During the three months ended June 30, 2016, research and development expenses increased 14% compared to the same period in the prior fiscal year. The increase is primarily driven by the increase in personnel related costs due to the increased headcount to support the launch of new products during the current period and increased headcount from the Jaybird Acquisition.

[0001032975-16-000097:mdna:129]
[same as prior period, unchanged from 0001032975-16-000068:mdna:138]

[0001032975-16-000097:mdna:130]
[same as prior period, unchanged from 0001032975-16-000068:mdna:139]

[0001032975-16-000097:mdna:131]
During the three months ended June 30, 2016, general and administrative expenses decreased 11% compared to the same period in the prior fiscal year. The decrease was primarily due to a $3.5 million reduction related to the prior year's accrual for our settlement with the SEC (see "Note 12 - "Commitments and Contingencies" to the condensed consolidated financial statements for more details).

[0001032975-16-000097:mdna:132]
Amortization of Intangibles and Acquisition-Related Costs

[0001032975-16-000097:mdna:133]
Amortization of intangibles and acquisition-related costs consist of amortization of acquired intangible assets including customer relationships and trade names, and acquisition-related costs including legal expense, due diligence costs, and other professional costs incurred for Jaybird Acquisition.

[0001032975-16-000097:mdna:134]
The increase during the three months ended June 30, 2016 compared to the same period in the prior fiscal year was primarily due to the Jaybird Acquisition.  Amortization of intangible assets and acquisition-related costs were $0.8 million and $0.5 million, respectively, for the three months ended June 30, 2016.

[0001032975-16-000097:mdna:135]
[same as prior period, unchanged from 0001032975-16-000068:mdna:142]

[0001032975-16-000097:mdna:136]
The following table summarizes restructuring-related activities during the three months ended June 30, 2016 (in thousands).

[0001032975-16-000097:mdna:137]
|  |  | Restructuring |
|  |  | TerminationBenefits |  | Lease ExitCosts |  | Total |
| Accrual balance at March 31, 2016 |  | $ | 6,275 |  |  | $ | 125 |  |  | $ | 6,400 |  |
| Credits, net |  | (85 | ) |  | — |  |  | (85 | ) |
| Cash payments |  | (1,908 | ) |  | (125 | ) |  | (2,033 | ) |
| Accrual balance at June 30, 2016 |  | $ | 4,282 |  |  | $ | — |  |  | $ | 4,282 |  |

[0001032975-16-000097:mdna:138]
Termination benefits were calculated based on regional benefit practices and local statutory requirements. Lease exit costs primarily relate to costs associated with the closure of existing facilities.

[0001032975-16-000097:mdna:139]
Other Expense, Net

[0001032975-16-000097:mdna:140]
Other expense, net for the three months ended June 30, 2016 and 2015 was as follows (in thousands):

[0001032975-16-000097:mdna:141]
|  |  | Three Months Ended June 30, |
|  |  | 2016 |  | 2015 |
| Investment income related to deferred compensation plan |  | $ | 192 |  |  | $ | 100 |  |
| Currency exchange loss, net |  | (999 | ) |  | (1,162 | ) |
| Other |  | (201 | ) |  | 43 |  |
|  |  | $ | (1,008 | ) |  | $ | (1,019 | ) |

[0001032975-16-000097:mdna:142]
Currency exchange gains or losses relate to balances denominated in currencies other than the functional currency in our subsidiaries, as well as to the sale of currencies, and to gains or losses recognized on foreign currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize foreign exchange gains and minimize foreign currency exchange losses.

[0001032975-16-000097:mdna:143]
[same as prior period, unchanged from 0001032975-16-000068:mdna:154]

[0001032975-16-000097:mdna:144]
The provision for (benefit from) income taxes and effective tax rates for the three months ended June 30, 2016 and 2015 were as follows (in thousands):

[0001032975-16-000097:mdna:145]
|  |  | Three Months Ended June 30, |
|  |  | 2016 |  | 2015 |
| Provision for (benefit from) income taxes |  | $ | 3,057 |  |  | $ | (7 | ) |
| Effective income tax rate |  | 12.2 | % |  | (0.1 | )% |

[0001032975-16-000097:mdna:146]
The change in the effective income tax rate for the three months ended June 30, 2016, compared to the three months ended June 30, 2015, is due to the mix of income and losses in the various tax jurisdictions in which we operate. In the three months ended June 30, 2015, there was a discrete tax benefit of $2.2 million from the preferential income tax rate reduction pursuant to the High and New Technology Enterprise Program in China.

[0001032975-16-000097:mdna:147]
As of June 30 and March 31, 2016, the total amount of unrecognized tax benefits due to uncertain tax positions was $70.3 million and $69.9 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-16-000097:mdna:148]
[same as prior period, unchanged from 0001032975-16-000068:mdna:160]

[0001032975-16-000097:mdna:149]
[same as prior period, unchanged from 0001032975-16-000068:mdna:161]

[0001032975-16-000097:mdna:150]
As of June 30, 2016, we had cash and cash equivalents of $440.1 million compared to $519.2 million at March 31, 2016. Our cash and cash equivalents consist of bank demand deposits and short-term time deposits of which 63% is held by our subsidiaries in Switzerland, 19% is held by our subsidiaries in Hong Kong and China, 6% is held by our subsidiaries in the United States, and 12% is held by subsidiaries in various other countries. We do not expect to incur any material adverse tax impact except for what has been recognized or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-16-000097:mdna:151]
As of June 30, 2016, our working capital was $456.7 million compared to working capital of $511.3 million at March 31, 2016. The decrease was primarily due to lower cash and cash equivalents, primarily as a result of cash payments for the Jaybird Acquisition and share repurchases, and higher accounts payable, partially offset by higher accounts receivable and net inventory balances due to seasonality.

[0001032975-16-000097:mdna:152]
During the three months ended June 30, 2016, we generated $13.7 million in cash from operating activities. Our main cash inflows came from net income and increases in accounts payable, partially offset by increases in accounts receivable and inventories and a decrease in accrued liabilities.  Net cash used in investing activities was $61.7 million, primarily due to $54.0 million of purchase price (net of cash acquired) for the Jaybird Acquisition ("Note 3 - Business Acquisition" to the condensed consolidated financial statements), including a working capital adjustment and payment of line-of-credit on behalf of Jaybird, and $7.4 million of capital expenditure in computer

[0001032975-16-000097:mdna:153]
36

[0001032975-16-000097:mdna:154]
hardware and software, tooling and equipment. Net cash used in financing activities was $29.7 million, primarily related to share repurchases of $24.4 million and tax withholdings related to net share settlements of restricted stock units (RSUs) of $9.2 million, partially offset by $0.6 million of proceeds from sales of shares upon exercise of options and purchase rights.

[0001032975-16-000097:mdna:155]
We had several uncommitted, unsecured bank lines of credit aggregating $44.6 million as of June 30, 2016. There are no financial covenants under these lines of credit with which we must comply. As of June 30, 2016, we had outstanding bank guarantees of $15.6 million under these lines of credit.

[0001032975-16-000097:mdna:156]
The following table summarizes our condensed consolidated statements of cash flows (in thousands), on a total company basis:

[0001032975-16-000097:mdna:157]
|  |  | Three Months Ended June 30, |
|  |  | 2016 |  | 2015 |
| Net cash provided by (used in) operating activities |  | $ | 13,737 |  |  | $ | (25,599 | ) |
| Net cash used in investing activities |  | (61,725 | ) |  | (15,593 | ) |
| Net cash used in financing activities |  | (29,728 | ) |  | (5,379 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (1,368 | ) |  | 1,761 |  |
| Net decrease in cash and cash equivalents |  | $ | (79,084 | ) |  | $ | (44,810 | ) |

[0001032975-16-000097:mdna:158]
| The following amounts reflected in the table above are from discontinued operations: |  |  |
| Depreciation |  | $ | — |  |  | $ | 705 |  |
| Amortization of other intangible assets |  | $ | — |  |  | $ | 564 |  |
| Share-based compensation expense |  | $ | — |  |  | $ | 226 |  |
| Purchases of property, plant and equipment |  | $ | — |  |  | $ | 385 |  |
| Cash and cash equivalents, beginning of the period |  | $ | — |  |  | $ | 3,659 |  |
| Cash and cash equivalents, end of the period |  | $ | — |  |  | $ | 1,911 |  |

[0001032975-16-000097:mdna:159]
[same as prior period, unchanged from 0001032975-16-000068:mdna:169]

[0001032975-16-000097:mdna:160]
The following table presents selected financial information and statistics as of June 30, 2016 and 2015 (dollars in thousands):

[0001032975-16-000097:mdna:161]
|  |  | Three Months Ended June 30, |
|  |  | 2016 |  | 2015 |
| Accounts receivable, net |  | $ | 192,242 |  |  | $ | 209,258 |  |
| Inventories |  | $ | 247,792 |  |  | $ | 311,305 |  |
| Days sales in accounts receivable (“DSO”) (Days) (1) |  | 36 |  |  | 42 |  |
| Inventory turnover (“ITO”) (x)(2) |  | 5.0 |  |  | 3.7 |  |

[0001032975-16-000097:mdna:162]
(1) DSO is determined using ending accounts receivable as of the most recent quarter-end and net sales for the most recent quarter.

[0001032975-16-000097:mdna:163]
(2) ITO is determined using ending inventories and annualized cost of goods sold (based on the most recent quarterly cost of goods sold).

[0001032975-16-000097:mdna:164]
During the three months ended June 30, 2016, we achieved $13.7 million cash inflow from operating activities, compared to a cash outflow of $25.6 million for the same period in the prior fiscal year. The primary drivers of the increase in net cash generated from operating cash flows include an increase in the net income of $14.5 million for the three months ended June 30, 2016, compared to the three months ended June 30, 2015, a lower increase in inventory in the current period compared to the same period of prior year, partially offset by a decrease in accrual and other liabilities.

[0001032975-16-000097:mdna:165]
Inventory turnover as of June 30, 2016 is higher compared to that as of June 30, 2015. The decrease in inventories compared with June 30, 2015 was due to lingering effects of the port strike on the west coast of the

[0001032975-16-000097:mdna:166]
United States that resulted in a higher inventory balance as of June 30, 2015. If we are not successful in launching and phasing in our new products during the current fiscal year, or we are not able to sell the new products at the prices planned, it could have a material impact on our revenue, gross profit margin, operating results including operating cash flow, and inventory turnover in the future.

[0001032975-16-000097:mdna:167]
[same as prior period, unchanged from 0001032975-16-000068:mdna:176]

[0001032975-16-000097:mdna:168]
The following table presents information on our cash flows from investing activities during the three months ended June 30, 2016 and 2015 (in thousands):

[0001032975-16-000097:mdna:169]
|  |  | Three Months Ended June 30, |
|  |  | 2016 |  | 2015 |
| Purchases of property, plant and equipment |  | $ | (7,420 | ) |  | $ | (15,290 | ) |
| Investment in privately held companies |  | (320 | ) |  | (240 | ) |
| Acquisition, net of cash acquired |  | (53,987 | ) |  | — |  |
| Purchase of other intangible asset |  | (715 | ) |  | — |  |
| Release of restricted cash |  | 715 |  |  | — |  |
| Purchase of trading investments |  | (4,229 | ) |  | (903 | ) |
| Proceeds from sales of trading investments |  | 4,231 |  |  | 840 |  |
| Net cash used in investing activities |  | $ | (61,725 | ) |  | $ | (15,593 | ) |

[0001032975-16-000097:mdna:170]
Our expenditures for property, plant and equipment during the three months ended June 30, 2016 and 2015 were primarily for computer hardware and software, tooling, equipment and leasehold improvements. The decrease in purchases of property, plant and equipment is mainly arose from the building of production lines to accommodate the in-house manufacturing of certain products compared with purchase from third parties to align with our goal of cost saving during the three months ended June 30, 2015.

[0001032975-16-000097:mdna:171]
Our payment of the acquisitions, net of cash acquired, during the three months ended June 30, 2016, is for the Jaybird Acquisition during the period. Refer to "Note 3 - Business Acquisition" to the condensed consolidated financial statements.

[0001032975-16-000097:mdna:172]
The purchases and sales of trading investments in the three months ended June 30, 2016 and 2015 represent mutual fund and money market fund activities directed by participants in a deferred compensation plan offered by one of our subsidiaries. The mutual funds and money market funds are held by a Rabbi trust.

[0001032975-16-000097:mdna:173]
[same as prior period, unchanged from 0001032975-16-000068:mdna:181]

[0001032975-16-000097:mdna:174]
The following table presents information on our cash flows from financing activities during the three months ended June 30, 2016 and 2015 (in thousands), on a total company basis:

[0001032975-16-000097:mdna:175]
|  |  | Three Months Ended June 30, |
|  |  | 2016 |  | 2015 |
| Purchases of treasury shares |  | $ | (24,422 | ) |  | $ | (8,814 | ) |
| Proceeds from sales of shares upon exercise of options and purchase rights |  | 599 |  |  | 4,066 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (9,185 | ) |  | (1,296 | ) |
| Excess tax benefits from share-based compensation |  | 3,280 |  |  | 665 |  |
| Net cash used in financing activities |  | $ | (29,728 | ) |  | $ | (5,379 | ) |

[0001032975-16-000097:mdna:176]
During the three months ended June 30, 2016, 1.6 million shares were repurchased for $24.4 million. During the three months ended June 30, 2015, 0.6 million shares were repurchased for $8.8 million.

[0001032975-16-000097:mdna:177]
During the three months ended June 30, 2016 and 2015, $9.2 million and $1.3 million, respectively, were paid for the tax withholding related to the vesting for restricted stock units of employees.

[0001032975-16-000097:mdna:178]
[same as prior period, unchanged from 0001032975-16-000068:mdna:186]

[0001032975-16-000097:mdna:179]
[same as prior period, unchanged from 0001032975-16-000068:mdna:187]

[0001032975-16-000097:mdna:180]
In March 2015, we announced a plan to pay $250 million in cumulative dividends for fiscal year 2015 through fiscal year 2017. The Board of Directors plans to request shareholder approval of the Swiss Franc equivalent of an CHF 90.2 million (approximately $92.7 million, based on the exchange rate of 1CHF=USD1.0278 on June 30, 2016) dividend for fiscal year 2016 out of retained earnings at our next annual general meeting. Based on the number of shares outstanding as of June 30, 2016, this represents approximately CHF 0.5577 per share, compared to dividend of CHF 0.51 per share for fiscal year 2015. During fiscal year 2016, we paid a cash dividend of CHF 83.1 million (U.S. Dollar amount of $85.9 million) out of retained earnings. During fiscal year 2015, we paid a cash dividend of CHF 43.1 million (U.S. Dollar amount of $43.8 million) out of retained earnings.

[0001032975-16-000097:mdna:181]
In March 2014, our Board of Directors approved a new share buyback program, which authorizes us to purchase up to $250.0 million of our own shares. Our share buyback program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. During the three months ended June 30, 2016, 1.6 million shares were repurchased for $24.4 million. During the three months ended June 30, 2015, 0.6 million shares were repurchased for $8.8 million.

[0001032975-16-000097:mdna:182]
As noted in "Note 3 - Business Acquisition" to our condensed consolidated financial statements, we acquired all of the equity interest of Jaybird for a purchase price of $54.2 million, including a working capital adjustment and payment of line-of-credit on behalf of Jaybird, with an additional earn-out of up to $45 million based on the achievement of certain net revenue growth targets over two years starting May 2016. If the net revenue growth targets are met, the Company will pay $25 million and $20 million in fiscal years 2018 and 2019, respectively.

[0001032975-16-000097:mdna:183]
[same as prior period, unchanged from 0001032975-16-000068:mdna:192]

[0001032975-16-000097:mdna:184]
Operating Leases Obligation

[0001032975-16-000097:mdna:185]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. The remaining terms on our non-cancelable operating leases expire in various years through 2030. Our asset retirement obligations on these leases as of June 30, 2016 were not material.

[0001032975-16-000097:mdna:186]
[same as prior period, unchanged from 0001032975-16-000068:mdna:195]

[0001032975-16-000097:mdna:187]
As of June 30, 2016, we had fixed purchase commitments for inventory purchases made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. Fixed purchase commitments for capital expenditures primarily relate to commitments for tooling for new and existing products, computer hardware, leasehold and improvements. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-16-000097:mdna:188]
[same as prior period, unchanged from 0001032975-16-000068:mdna:197]

[0001032975-16-000097:mdna:189]
For further detail about our contractual obligations and commitments, please refer to our Annual Report on Form 10-K for the fiscal year ended March 31, 2016.

[0001032975-16-000097:mdna:190]
[same as prior period, unchanged from 0001032975-16-000068:mdna:199]

[0001032975-16-000097:mdna:191]
[same as prior period, unchanged from 0001032975-16-000068:mdna:200]

[0001032975-16-000097:mdna:192]
Settlement

[0001032975-16-000097:mdna:193]
In April 2016, we entered into a settlement with the SEC related to the accounting for Revue inventory valuation reserves that resulted in the restatement described in the Fiscal Year 2014 Annual Report on Form 10-K, revision to our consolidated financial statements concerning warranty accruals and amortization of intangible assets presented in our Amended Annual Report on Form 10-K/A, filed on August 7, 2013, and our transactions with a distributor for fiscal year 2007 through fiscal year 2009.  We entered into the settlement without admitting or denying the findings of the SEC’s investigation and paid a civil penalty of $7.5 million. This amount was paid in April 2016.

[0001032975-16-000097:mdna:194]
[same as prior period, unchanged from 0001032975-16-000068:mdna:203]

[0001032975-16-000097:mdna:195]
Logitech Europe S.A., one of our wholly owned subsidiaries, guaranteed payments of third-party contract manufacturers' purchase obligations. As of June 30, 2016, the maximum amount of this guarantee was $3.8 million, of which $1.3 million of guaranteed purchase obligations were outstanding.

[0001032975-16-000097:mdna:196]
[same as prior period, unchanged from 0001032975-16-000068:mdna:205]

[0001032975-16-000097:mdna:197]
We indemnify certain of our suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2016, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-16-000097:mdna:198]
[same as prior period, unchanged from 0001032975-16-000068:mdna:207]

[0001032975-16-000097:mdna:199]
The Stock Purchase Agreement that we entered into in connection with the investment by three venture capital firms in Lifesize contains representations, warranties and covenants of Logitech and Lifesize to the Investors. Subject to certain limitations, we have agreed to indemnify the Investors and certain persons related to the Investors for certain losses resulting from breaches of or inaccuracies in such representations, warranties and covenants as well as certain other obligations, including third party expenses, restructuring costs and pre-closing tax obligations of Lifesize.

[0001032975-16-000097:mdna:200]
Legal Proceedings

[0001032975-16-000097:mdna:201]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of our business. We are currently subject to several such claims and a small number of legal proceedings. We believe that these matters lack merit and we intend to vigorously defend against them. Based on currently available information, we do not believe that resolution of pending matters will have a material adverse effect on our financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that our defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on our business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against us, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect our business.
