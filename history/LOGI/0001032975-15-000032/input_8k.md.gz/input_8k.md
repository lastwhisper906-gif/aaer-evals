# LOGI 8-K — 0001032975-15-000030 filed 2015-07-23

## item codes, every 8-K on or before 2015-07-24

- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2015-07-24

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-15-000030:8k_2_02:1]
EX-99.1
2
exhibit991q1fy16.htm
EXHIBIT 99.1

[0001032975-15-000030:8k_2_02:2]
Exhibit 99.1 Q1FY16

[0001032975-15-000030:8k_2_02:3]
Exhibit 99.1

[0001032975-15-000030:8k_2_02:4]
Editorial Contacts:

[0001032975-15-000030:8k_2_02:5]
Joe Greenhalgh, Vice President, Investor Relations - USA (510) 713-4430

[0001032975-15-000030:8k_2_02:6]
Krista Todd, Vice President, External Communications - USA (510) 713-5834

[0001032975-15-000030:8k_2_02:7]
Ben Starkie, Corporate Communications - Europe +41-(0) 79-292-3499

[0001032975-15-000030:8k_2_02:8]
Logitech Confirms FY 2016 Outlook with Q1 Sales of $470 Million

[0001032975-15-000030:8k_2_02:9]
Q1 Retail Sales Grow 7 Percent in Constant Currency:

[0001032975-15-000030:8k_2_02:10]
Company Transition to Growth on Track

[0001032975-15-000030:8k_2_02:11]
NEWARK, Calif. - Jul. 22, 2015 and LAUSANNE, Switzerland, Jul. 23, 2015 - Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the first quarter of Fiscal Year 2016.

[0001032975-15-000030:8k_2_02:12]
| • | Q1 sales were $470 million, down 2 percent compared to Q1 of the prior year. Q1 retail sales were $425 million and grew 7 percent in constant currency. |

[0001032975-15-000030:8k_2_02:13]
| • | Q1 GAAP operating income was $7 million. This includes $13 million in restructuring costs. Q1 GAAP earnings per share (EPS) were $0.04, compared to $0.12 in the same quarter a year ago. |

[0001032975-15-000030:8k_2_02:14]
| • | Q1 non-GAAP operating income was $31 million, with non-GAAP EPS of $0.16, compared to $0.22 in the same quarter a year ago. |

[0001032975-15-000030:8k_2_02:15]
“Our first quarter results are encouraging and put us strongly on track for FY 2016,” said Bracken P. Darrell, Logitech president and chief executive officer. “We are on the offensive, focusing on our retail business in order to accelerate our transition to growth - Q1 retail sales grew 7 percent in constant currency. We look forward to carrying good momentum into the rest of fiscal year 2016 as we unveil another fantastic portfolio of exciting, new products. As planned, we have made excellent progress in preparing the business for the year to come - we’re on course to exit OEM by the end of calendar year 2015; we’re reorganizing Lifesize around the cloud; and we continue to optimize our costs to invest even more in growth.”

[0001032975-15-000030:8k_2_02:16]
Outlook

[0001032975-15-000030:8k_2_02:17]
Logitech confirmed its FY 2016 outlook of $150 million in non-GAAP operating income and 7% growth for retail sales in constant currency.

[0001032975-15-000030:8k_2_02:18]
Prepared Remarks Available Online

[0001032975-15-000030:8k_2_02:19]
Logitech has made its prepared written remarks for the financial results teleconference available online on the Logitech corporate Web site at http://ir.logitech.com.

[0001032975-15-000030:8k_2_02:20]
Financial Results Teleconference and Webcast

[0001032975-15-000030:8k_2_02:21]
Logitech will hold a financial results teleconference to discuss the results for Q1 FY 2016 on Jul. 23, 2015 at 8:30 a.m. Eastern Daylight Time and 2:30 p.m. Central European Summer Time. A live webcast of the call will be available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-15-000030:8k_2_02:22]
Use of Non-GAAP Financial Information

[0001032975-15-000030:8k_2_02:23]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of other intangible assets, restructuring charges (credits), other restructuring-related charges, investment impairment (recovery), benefit from (provision for) income taxes, one-time special charges and other items detailed under “Supplemental Financial Information” after the tables below. Logitech also presents percentage sales growth in constant currency, a non-GAAP measure, to show performance unaffected by fluctuations in currency exchange rates.  Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information will help investors to evaluate its current period performance and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for Fiscal Year 2016.

[0001032975-15-000030:8k_2_02:24]
About Logitech

[0001032975-15-000030:8k_2_02:25]
Logitech designs products that have an everyday place in people's lives, connecting them to the digital experiences they care about. Over 30 years ago Logitech started connecting people through computers, and now it’s designing products that bring people together through music, gaming, video and computing. Founded in 1981, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @Logitech.

[0001032975-15-000030:8k_2_02:26]
# # #

[0001032975-15-000030:8k_2_02:27]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-15-000030:8k_2_02:28]
2015 Logitech, Logicool, Logi and other Logitech marks are owned by Logitech and may be registered. All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-15-000030:8k_2_02:29]
(LOGIIR)

[0001032975-15-000030:8k_2_02:30]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| (In thousands, except per share amounts) -Unaudited |  |  |  |  |
|  |  | Three Months Ended |
|  |  | June 30, |
| GAAP CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2015 |  | 2014 |
| Net sales |  | $ | 470,320 |  |  | $ | 482,203 |  |
| Cost of goods sold |  | 298,591 |  |  | 300,450 |  |
| Gross profit |  | 171,729 |  |  | 181,753 |  |
| % of net sales |  | 36.5 | % |  | 37.7 | % |
| Operating expenses: |  |  |  |  |
| Marketing and selling |  | 87,427 |  |  | 91,045 |  |
| Research and development |  | 33,833 |  |  | 31,316 |  |
| General and administrative |  | 30,504 |  |  | 36,680 |  |
| Restructuring charges, net |  | 12,995 |  |  | — |  |
| Total operating expenses |  | 164,759 |  |  | 159,041 |  |
| Operating income |  | 6,970 |  |  | 22,712 |  |
| Interest income, net |  | 264 |  |  | 258 |  |
| Other expense, net |  | (1,121 | ) |  | (198 | ) |
| Income before income taxes |  | 6,113 |  |  | 22,772 |  |
| Provision for (benefit from) income taxes |  | (1,324 | ) |  | 3,096 |  |
| Net income |  | $ | 7,437 |  |  | $ | 19,676 |  |
| Net income per share: |  |  |  |  |
| Basic |  | $ | 0.05 |  |  | $ | 0.12 |  |
| Diluted |  | $ | 0.04 |  |  | $ | 0.12 |  |
| Shares used to compute net income per share : |  |  |  |  |
| Basic |  | 164,431 |  |  | 163,012 |  |
| Diluted |  | 166,895 |  |  | 165,833 |  |

[0001032975-15-000030:8k_2_02:31]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| (In thousands) |  |  |  |  |
|  |  | June 30, |  | March 31, |
| CONSOLIDATED BALANCE SHEETS |  | 2015 |  | 2015 |
|  |  | (Unaudited) |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 492,228 |  |  | $ | 537,038 |  |
| Accounts receivable, net |  | 221,580 |  |  | 179,823 |  |
| Inventories |  | 327,507 |  |  | 270,730 |  |
| Other current assets |  | 73,310 |  |  | 64,429 |  |
| Total current assets |  | 1,114,625 |  |  | 1,052,020 |  |
| Non-current assets: |  |  |  |  |
| Property, plant and equipment, net |  | 101,669 |  |  | 91,593 |  |
| Goodwill |  | 218,251 |  |  | 218,213 |  |
| Other intangible assets |  | 1,164 |  |  | 1,866 |  |
| Other assets |  | 62,338 |  |  | 62,988 |  |
| Total assets |  | $ | 1,498,047 |  |  | $ | 1,426,680 |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 340,330 |  |  | $ | 299,995 |  |
| Accrued and other current liabilities |  | 213,971 |  |  | 194,912 |  |
| Total current liabilities |  | 554,301 |  |  | 494,907 |  |
| Non-current liabilities: |  | 177,328 |  |  | 173,639 |  |
| Total liabilities |  | 731,629 |  |  | 668,546 |  |
| Total shareholders' equity |  | 766,418 |  |  | 758,134 |  |
| Total liabilities and shareholders' equity |  | $ | 1,498,047 |  |  | $ | 1,426,680 |  |

[0001032975-15-000030:8k_2_02:32]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| (In thousands) - Unaudited |  |  |  |  |
|  |  | Three Months Ended |
|  |  | June 30, |
| CONSOLIDATED STATEMENTS OF CASH FLOWS |  | 2015 |  | 2014 |
| Operating activities: |  |  |  |  |
| Net income |  | $ | 7,437 |  |  | $ | 19,676 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation |  | 10,516 |  |  | 9,951 |  |
| Amortization of other intangible assets |  | 732 |  |  | 2,782 |  |
| Share-based compensation expense |  | 6,749 |  |  | 6,938 |  |
| Impairment of investments |  | 103 |  |  | — |  |
| Loss (gain) on disposal of property, plant and equipment |  | — |  |  | 22 |  |
| Excess tax benefits from share-based compensation |  | (665 | ) |  | (381 | ) |
| Deferred income taxes and other |  | (6,732 | ) |  | (1,832 | ) |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |
| Accounts receivable, net |  | (41,208 | ) |  | (36,663 | ) |
| Inventories |  | (54,164 | ) |  | (18,463 | ) |
| Other assets |  | (2,383 | ) |  | (2,063 | ) |
| Accounts payable |  | 34,541 |  |  | 40,775 |  |
| Accrued and other liabilities |  | 19,475 |  |  | 7,016 |  |
| Net cash provided by (used in) operating activities |  | (25,599 | ) |  | 27,758 |  |
| Investing activities: |  |  |  |  |
| Purchases of property, plant and equipment |  | (15,290 | ) |  | (11,243 | ) |
| Investment in privately held companies |  | (240 | ) |  | (1,050 | ) |
| Purchase of trading investments |  | (903 | ) |  | (454 | ) |
| Proceeds from sales of trading investments |  | 840 |  |  | 506 |  |
| Net cash used in investing activities |  | (15,593 | ) |  | (12,241 | ) |
| Financing activities: |  |  |  |  |
| Contingent consideration related to prior acquisition |  | — |  |  | (100 | ) |
| Purchases of treasury shares |  | (8,814 | ) |  | — |  |
| Proceeds from sales of shares upon exercise of options |  | 4,066 |  |  | 574 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (1,296 | ) |  | (695 | ) |
| Excess tax benefits from share-based compensation |  | 665 |  |  | 381 |  |
| Net cash provided by (used in) financing activities |  | (5,379 | ) |  | 160 |  |
| Effect of exchange rate changes on cash and cash equivalents |  | 1,761 |  |  | (108 | ) |
| Net increase (decrease) in cash and cash equivalents |  | (44,810 | ) |  | 15,569 |  |
| Cash and cash equivalents, beginning of the period |  | 537,038 |  |  | 469,412 |  |
| Cash and cash equivalents, end of the period |  | $ | 492,228 |  |  | $ | 484,981 |  |

[0001032975-15-000030:8k_2_02:33]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |
| NET SALES |  | Three Months Ended |
|  |  | June 30, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2015 |  | 2014 |  | Change |
| Net sales by channel: |  |  |  |  |  |  |
| Retail |  | $ | 425,388 |  |  | $ | 423,814 |  |  | — | % |
| OEM |  | 22,298 |  |  | 32,632 |  |  | (32 | ) |
| Video conferencing |  | 22,634 |  |  | 25,757 |  |  | (12 | ) |
| Total net sales |  | $ | 470,320 |  |  | $ | 482,203 |  |  | (2 | ) |
| Net retail sales by product family(*): |  |  |  |  |  |  |
| Mobile Speakers |  | $ | 40,544 |  |  | $ | 28,830 |  |  | 41 |  |
| Gaming |  | 43,670 |  |  | 46,876 |  |  | (7 | ) |
| Video collaboration |  | 21,176 |  |  | 15,225 |  |  | 39 |  |
| Tablet & Other Accessories |  | 18,809 |  |  | 31,716 |  |  | (41 | ) |
| Growth |  | 124,199 |  |  | 122,647 |  |  | 1 |  |
| Pointing Devices |  | 116,985 |  |  | 113,042 |  |  | 3 |  |
| Keyboards & Combos |  | 105,829 |  |  | 105,489 |  |  | — |  |
| Audio-PC & Wearables |  | 45,699 |  |  | 48,548 |  |  | (6 | ) |
| PC Webcams |  | 21,681 |  |  | 20,463 |  |  | 6 |  |
| Home Control |  | 10,254 |  |  | 12,332 |  |  | (17 | ) |
| Profit Maximization |  | 300,448 |  |  | 299,874 |  |  | — |  |
| Retail Strategic Sales |  | 424,647 |  |  | 422,521 |  |  | 1 |  |
| Non-Strategic |  | 741 |  |  | 1,293 |  |  | (43 | ) |
| Total net retail sales |  | $ | 425,388 |  |  | $ | 423,814 |  |  | — |  |
| __________________ |  |  |  |  |  |  |

[0001032975-15-000030:8k_2_02:34]
* Certain products within the retail product families as presented in prior period have been reclassified to conform to the current period's presentation, with no impact on previously reported total net retail sales.

[0001032975-15-000030:8k_2_02:35]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |  |
| GAAP TO NON GAAP RECONCILIATION (A) |  | Three Months Ended |
|  |  | June 30, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2015 |  |  | 2014 |
| Gross profit - GAAP |  | $ | 171,729 |  |  |  | $ | 181,753 |  |
| Share-based compensation expense |  | 605 |  |  |  | 538 |  |
| Amortization of other intangible assets |  | 508 |  |  |  | 550 |  |
| Gross profit - Non-GAAP |  | $ | 172,842 |  |  |  | $ | 182,841 |  |
| Gross margin - GAAP |  | 36.5 | % |  |  | 37.7 | % |
| Gross margin - Non-GAAP |  | 36.7 | % |  |  | 37.9 | % |
| Operating expenses - GAAP |  | $ | 164,759 |  |  |  | $ | 159,041 |  |
| Less: Share-based compensation expense |  | 6,137 |  |  |  | 6,400 |  |
| Less: Amortization of other intangible assets |  | 224 |  |  |  | 2,232 |  |
| Less: Restructuring charges, net |  | 12,995 |  |  |  | — |  |
| Less: One time special charge |  | 4,049 |  | * |  | 8,976 |  |
| Operating expenses - Non-GAAP |  | $ | 141,354 |  |  |  | $ | 141,433 |  |
| % of net sales - GAAP |  | 35.0 | % |  |  | 33.0 | % |
| % of net sales - Non - GAAP |  | 30.1 | % |  |  | 29.3 | % |
| Operating income - GAAP |  | $ | 6,970 |  |  |  | $ | 22,712 |  |
| Share-based compensation expense |  | 6,742 |  |  |  | 6,938 |  |
| Amortization of other intangible assets |  | 732 |  |  |  | 2,782 |  |
| Restructuring charges, net |  | 12,995 |  |  |  | — |  |
| One time special charge |  | 4,049 |  | * |  | 8,976 |  |
| Operating income - Non - GAAP |  | $ | 31,488 |  |  |  | $ | 41,408 |  |
| % of net sales - GAAP |  | 1.5 | % |  |  | 4.7 | % |
| % of net sales - Non - GAAP |  | 6.7 | % |  |  | 8.6 | % |
| Net income - GAAP |  | $ | 7,437 |  |  |  | $ | 19,676 |  |
| Share-based compensation expense |  | 6,742 |  |  |  | 6,938 |  |
| Amortization of other intangible assets |  | 732 |  |  |  | 2,782 |  |
| Restructuring charges, net |  | 12,995 |  |  |  | — |  |
| One time special charge |  | 4,049 |  | * |  | 8,976 |  |
| Investment impairment, net |  | 103 |  |  |  | — |  |
| Provision for income taxes |  | (5,320 | ) |  |  | (2,104 | ) |
| Net income - Non - GAAP |  | $ | 26,738 |  |  |  | $ | 36,268 |  |
| Net income per share: |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.04 |  |  |  | $ | 0.12 |  |
| Diluted - Non - GAAP |  | $ | 0.16 |  |  |  | $ | 0.22 |  |
| Shares used to compute net income per share: |  |  |  |  |  |
| Diluted - GAAP and Non - GAAP |  | 166,895 |  |  |  | 165,833 |  |

[0001032975-15-000030:8k_2_02:36]
* These expenses include an increase of $3.5 million in the accrual for a proposed settlement of the SEC investigation and other expenses related to that investigation.

[0001032975-15-000030:8k_2_02:37]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |
| SHARED BASED COMPENSATION EXPENSE |  | Three Months Ended |
|  |  | June 30, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2015 |  | 2014 |
| Share-based Compensation Expense |  |  |  |  |
| Cost of goods sold |  | $ | 605 |  |  | $ | 538 |  |
| Marketing and selling |  | 2,118 |  |  | 2,556 |  |
| Research and Development |  | 787 |  |  | 844 |  |
| General and administrative |  | 3,232 |  |  | 3,000 |  |
| Restructuring |  | 7 |  |  | — |  |
| Income tax benefit |  | (1,337 | ) |  | (1,184 | ) |
| Total share-based compensation expense after income taxes |  | $ | 5,412 |  |  | $ | 5,754 |  |
| __________________ |  |  |  |  |

[0001032975-15-000030:8k_2_02:38]
(A) Non-GAAP Financial Measures

[0001032975-15-000030:8k_2_02:39]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-15-000030:8k_2_02:40]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended June 30, 2015, we excluded items in the following general categories, each of which are described below:

[0001032975-15-000030:8k_2_02:41]
Share-based compensation expenses. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-15-000030:8k_2_02:42]
Amortization of other intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our operating expenses and financial results from period to period.

[0001032975-15-000030:8k_2_02:43]
Restructuring and restructuring-related charges. These expenses are associated with re-aligning our business strategies based on current economic conditions. We have undertaken several restructurings in recent years. In connection with our restructuring initiatives, we incurred restructuring charges related to employee terminations, facility closures and early cancellation of certain contracts. Our restructuring initiatives also resulted in other costs related to restructurings not qualifying for inclusion in restructuring charges. We believe that providing the non-GAAP measures

[0001032975-15-000030:8k_2_02:44]
excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operating results in the current period.

[0001032975-15-000030:8k_2_02:45]
Investment impairment, net. We incur investment impairment, primarily related to our investments in various privately-held companies. The investment impairment varies depending on the operational and financial performance of the privately-held companies we invested in. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-15-000030:8k_2_02:46]
One-time special charges:  costs related to investigations and related expenses.  These expenses are forensic accounting, audit,

[0001032975-15-000030:8k_2_02:47]
consulting and legal fees related to the Audit Committee’s investigation and the ongoing formal investigation by and settlement discussion with the Securities and Exchange Commission (SEC), together with accruals based on settlement discussion with the SEC.  We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are one-time in nature and not reflective of our ongoing operations.

[0001032975-15-000030:8k_2_02:48]
Other charges. We provided non-GAAP measures excluding the effect of certain charges and income that are not reflective of our ongoing operations.

[0001032975-15-000030:8k_2_02:49]
In addition, Logitech presents percentage sales growth in constant currency, a non-GAAP measure, to show performance unaffected by fluctuations in currency exchange rates.  Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Sales for the three months ended June 30, 2015 compared to sales for the three months ended June 30, 2014 grew 4 percent in constant currency and declined 2 percent in U.S. Dollars. Retail sales for the three months ended June 30, 2015 compared to retail sales for the three months ended June 30, 2014 grew 7 percent in constant currency and was flat in U.S. Dollars.

[0001032975-15-000030:8k_2_02:50]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.
