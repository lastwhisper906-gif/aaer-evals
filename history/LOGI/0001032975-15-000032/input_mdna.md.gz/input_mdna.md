# LOGI MD&A — 0001032975-15-000032


## mdna

[0001032975-15-000032:mdna:1]
[same as prior period, unchanged from 0001628280-15-000267:mdna:1]

[0001032975-15-000032:mdna:2]
You should read the following discussion in conjunction with the interim unaudited Condensed Consolidated Financial Statements and related notes.

[0001032975-15-000032:mdna:3]
[same as prior period, unchanged from 0001628280-15-000267:mdna:3]

[0001032975-15-000032:mdna:4]
Logitech is a world leader in products that connect people to the digital experiences they care about. Spanning multiple computing, communication and entertainment platforms, we develop and market innovative hardware and software products that enable or enhance digital navigation, music and video entertainment, gaming, social networking, audio and video communication over the Internet and home-entertainment control. We have two reporting segments: peripherals and video conferencing.

[0001032975-15-000032:mdna:5]
Our peripherals segment encompasses the design, manufacturing and marketing of peripherals for PCs, tablets and other digital platforms. Within our peripherals segment, we classify our retail product categories as growth, profit maximization, and non-strategic. Our growth product categories are: Mobile Speakers, Gaming, Video

[0001032975-15-000032:mdna:6]
Collaboration and Tablet & Other Accessories. Our profit maximization categories are: Pointing Devices, Keyboards & Combos, Audio-PC & Wearables, PC Webcams, and Home Control.

[0001032975-15-000032:mdna:7]
[same as prior period, unchanged from 0001628280-15-000267:mdna:7]

[0001032975-15-000032:mdna:8]
Our design organization is responsible for developing and building the Logitech brand, consumer insights and digital marketing. Our regional retail sales and marketing activities are organized into three geographic areas: Americas (North and South America), EMEA (Europe, Middle East and Africa) and Asia Pacific (including, among other countries, China, Taiwan, Japan and Australia).

[0001032975-15-000032:mdna:9]
We sell our peripherals products to a network of retailers including direct sales to retailers and indirect sales through distributors. Our worldwide retail network includes wholesale distributors, consumer electronics retailers, mass merchandisers, specialty electronics, computers and telecommunications stores, value-added resellers and online merchants. Sales of our retail peripherals were 90% and 88% of our net sales for the three months ended June 30, 2015 and 2014, respectively. The large majority of our revenues have historically been derived from sales of our peripherals products for use by consumers. Our OEM customers include several of the world’s largest PC manufacturers. Sales to OEM customers were 5% and 7% of our net sales for the three months ended June 30, 2015 and 2014, respectively. In April 2015, we announced our intent to exit the OEM business. We plan to exit our OEM business by the end of December 2015.

[0001032975-15-000032:mdna:10]
Our video conferencing segment encompasses the Cloud-based video conferencing solution, design, manufacturing and marketing of Lifesize branded video conferencing products, infrastructure and services for the enterprise, public sector and other small to medium business markets. Video conferencing products include scalable high-definition, or HD, video communication endpoints, HD video conferencing systems with integrated monitors, video bridges, and other infrastructure software and hardware to support large-scale video deployments and services to support these products. The video conferencing segment maintains a separate marketing and sales organization, which sells Lifesize products and services worldwide. Video conferencing product development and product management organizations are separate, but coordinated with our peripherals business, particularly our Consumer Computing Platform group. In April 2015, we started reorganizing Lifesize with the goal of de-emphasizing Lifesize’s legacy offerings more quickly to enable maximum traction with Lifesize Cloud. We plan to shrink our Lifesize business to grow the cloud opportunity faster. We sell our video conferencing products and services to distributors, value-added resellers, OEMs and, occasionally, direct enterprise customers. Sales of video conferencing products were 5% and 5% of our net sales in the three months ended June 30, 2015 and 2014.

[0001032975-15-000032:mdna:11]
[same as prior period, unchanged from 0001628280-15-000267:mdna:11]

[0001032975-15-000032:mdna:12]
We believe that innovation, design, and product quality are important to gaining market acceptance and maintaining market leadership.

[0001032975-15-000032:mdna:13]
[same as prior period, unchanged from 0001628280-15-000267:mdna:15]

[0001032975-15-000032:mdna:14]
[same as prior period, unchanged from 0001628280-15-000267:mdna:16]

[0001032975-15-000032:mdna:15]
The preparation of financial statements and related disclosures in conformity with U.S. GAAP (Generally Accepted Accounting Principles in the United States of America) requires us to make judgments, estimates and

[0001032975-15-000032:mdna:16]
assumptions that affect reported amounts of assets, liabilities, net sales and expenses, and the disclosure of contingent assets and liabilities.

[0001032975-15-000032:mdna:17]
[same as prior period, unchanged from 0001628280-15-000267:mdna:19]

[0001032975-15-000032:mdna:18]
There have been no new or material changes to the critical accounting policies and estimates discussed in our Annual Report on Form 10-K for the fiscal year ended March 31, 2015 that are of significance, or potential significance to the Company.

[0001032975-15-000032:mdna:19]
[same as prior period, unchanged from 0001628280-15-000267:mdna:27]

[0001032975-15-000032:mdna:20]
Our total net sales for the three months ended June 30, 2015 decreased by 2% compared with the three months ended June 30, 2014, due to declines in OEM and video conferencing sales.

[0001032975-15-000032:mdna:21]
Total retail sales remained flat and units sold increased 2% during the three months ended June 30, 2015, compared with the three months ended June 30, 2014. We experienced an increase in sales of 9% in the Americas region, an increase in sales of 5% in the Asia Pacific region, and a decrease in sales of 15% in the EMEA region.

[0001032975-15-000032:mdna:22]
OEM net sales decreased 32% in the three months ended June 30, 2015 compared with the preceding fiscal year. The decline was expected as we announced our plan to exit OEM business in April 2015.

[0001032975-15-000032:mdna:23]
Sales of video conferencing products in the three months ended June 30, 2015 decreased 12% compared with three months ended June 30, 2014. Lifesize is in the process of transitioning its product portfolio to the Lifesize Cloud, a software-as-a-service (SaaS) offering launched in fiscal year 2015. While sales of the Cloud offering are growing rapidly, they are not yet large enough to offset the combination of the short-term portfolio transition and soft market conditions for video conferencing infrastructure.

[0001032975-15-000032:mdna:24]
Our gross margin for the three months ended June 30, 2015 decreased to 36.5% from 37.7% for the three months ended June 30, 2014. The decrease in gross margin primarily reflects the unfavorable currency headwind during the three months ended June 30, 2015.

[0001032975-15-000032:mdna:25]
Operating expenses for the three months ended June 30, 2015 were 35.0% of net sales, compared with 33.0% in the same period of the prior fiscal year. The increase was primarily in restructuring charges announced in April 2015, partially offset by the savings from marketing and general and administration expenses.

[0001032975-15-000032:mdna:26]
Net income for the three months ended June 30, 2015 was $7.4 million, compared with net income of $19.7 million in the three months ended June 30, 2014.

[0001032975-15-000032:mdna:27]
Given our global sales presence and the reporting of our financial results in U.S. Dollars, our financial results for the first quarter of fiscal year 2016 were affected by significant shifts in currency exchange rates compared with the first quarter of fiscal year 2015. See “Results of Operations” beginning on page 26 for information on the effect of currency exchange results on our net sales. If the U.S. Dollar remains at its current strong levels in comparison to other currencies, this will affect our results of operations in future periods as well.

[0001032975-15-000032:mdna:28]
[same as prior period, unchanged from 0001628280-15-000267:mdna:37]

[0001032975-15-000032:mdna:29]
Our sales of PC peripherals for use by consumers in Americas and Europe have historically made up the large majority of our revenues. In the last several years, the PC market has changed dramatically and there continues to be significant weakness in the global market for new PCs. This weakness had a negative impact on our net sales in all of our PC-related categories with the exception of PC Gaming.

[0001032975-15-000032:mdna:30]
We believe our future growth will be determined by our ability to rapidly create innovative products across multiple digital platforms - especially accessories for mobility-related products, including tablets and smartphones,

[0001032975-15-000032:mdna:31]
gaming and digital music devices, to offset the decline in our PC peripherals. The following discussion represents key trends specific to each of our two operating segments: peripherals and video conferencing.

[0001032975-15-000032:mdna:32]
[same as prior period, unchanged from 0001628280-15-000267:mdna:40]

[0001032975-15-000032:mdna:33]
Mobile Speakers:    The mobile speaker market grew throughout fiscal year 2015 and the first quarter of fiscal year 2016 driven by growing consumption of music through mobile devices such as smartphones and tablets.  This market growth, together with our investments in the UE brand, our introduction of new products and our ability to gain market share during fiscal year 2015 and the first quarter of fiscal year 2016, have driven our growth in Mobile Speakers.

[0001032975-15-000032:mdna:34]
PC Peripherals (Pointing Devices, Keyboards & Combos, PC Webcams, Gaming and Audio PC & Wearables):    Although the installed base of PC users is large, consumer demand for new PCs has declined in recent years, and we believe it will continue to decline in future years. As a consequence, consumer demand for PC peripherals is slowing, or in some cases declining. Our PC speakers sales are expected to decline as consumers migrate towards mobile speaker solutions such as UE Boom. The PC Gaming platform continues to show strong growth as online gaming and multi-platform experiences gain greater popularity and gaming content becomes increasingly more demanding. We believe Logitech is well positioned to benefit from the PC Gaming market growth.

[0001032975-15-000032:mdna:35]
Enterprise Market:    We are continuing our efforts to create and sell products and services to enterprises, with our Video Collaboration products. For example, we have introduced the Logitech ConferenceCam CC3000e and Conference Cam Connect video collaboration products. Growing our enterprise peripherals business will continue to require investment in selected business-specific products, targeted product marketing, and sales channel development.

[0001032975-15-000032:mdna:36]
Tablets and Other Accessories:    Smaller mobile computing devices, such as tablets with touch interfaces, have created new markets and usage models for peripherals and accessories. We offer a number of products to enhance the use of mobile devices, including keyboard folios for the iPad and iPad mini, and keyboard covers and folios for the iPad Air. We have also introduced keyboard folios for the Samsung Galaxy tablet. We have seen the market decline through fiscal year 2015 with continued declines in the first quarter of fiscal year 2016 for the iPad platform, which has impacted the sales of our tablet peripherals.

[0001032975-15-000032:mdna:37]
OEM Business:    Sales of our OEM mice and keyboards have historically made up the bulk of our OEM sales. In recent years, there has been a dramatic shift away from desktop PCs and there continues to be weakness in the global market for PCs, which has adversely affected our sales of OEM mice and keyboards, all of which are sold with name-brand desktop PCs. As announced, we plan to exit the OEM business by the end of December 2015 as we see limited opportunities for profitable growth.

[0001032975-15-000032:mdna:38]
Trends in Non-Strategic Peripherals Product Categories:    We continue to evaluate our product offerings and exit those which no longer support our strategic direction.

[0001032975-15-000032:mdna:39]
[same as prior period, unchanged from 0001628280-15-000267:mdna:47]

[0001032975-15-000032:mdna:40]
The overall video conferencing industry has experienced a slowdown in recent quarters. In addition, there has been an increase in the competitive environment. Lifesize is in the process of transitioning its product portfolio to Lifesize Cloud. While sales of this software-as-a-service offering are growing rapidly, they are not yet large enough to offset the combination of the short-term portfolio transition and soft market conditions for video conferencing infrastructure. Looking at this growth opportunity, recently, in April 2015, we decided to reorganize Lifesize with the goal of de-emphasizing Lifesize’s legacy offerings more quickly to enable maximum traction with Lifesize Cloud. We plan to shrink our legacy Lifesize business to grow the Cloud opportunity faster. We believe the growth in our video conferencing segment depends in part on our ability to increase sales of our new Cloud offering and to create a smooth transition from our legacy infrastructure business.

[0001032975-15-000032:mdna:41]
[same as prior period, unchanged from 0001628280-15-000267:mdna:49]

[0001032975-15-000032:mdna:42]
We refer to our net sales excluding the impact of currency exchange rate fluctuations as "constant dollar" sales. Constant dollar sales is a non-GAAP financial measure, which is information derived from consolidated financial information but not presented in our financial statements prepared in accordance with U.S. GAAP. Our management uses these non-GAAP measures in its financial and operational decision-making, and believes these non-GAAP measures, when considered in conjunction with the corresponding GAAP measures, facilitate a better understanding of changes in net sales. Percentage of constant dollar sales growth is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.

[0001032975-15-000032:mdna:43]
[same as prior period, unchanged from 0001628280-15-000267:mdna:51]

[0001032975-15-000032:mdna:44]
[same as prior period, unchanged from 0001628280-15-000267:mdna:52]

[0001032975-15-000032:mdna:45]
Net sales by channel for the three months ended June 30, 2015 and 2014 were as follows (in thousands):

[0001032975-15-000032:mdna:46]
|  |  | Three Months EndedJune 30, |
|  |  | 2015 |  | 2014 |  | Change |
| Retail |  | $ | 425,388 |  |  | $ | 423,814 |  |  | — | % |
| OEM |  | 22,298 |  |  | 32,632 |  |  | (32 | )% |
| Video conferencing |  | 22,634 |  |  | 25,757 |  |  | (12 | )% |
| Total net sales |  | $ | 470,320 |  |  | $ | 482,203 |  |  | (2 | )% |

[0001032975-15-000032:mdna:47]
[same as prior period, unchanged from 0001628280-15-000267:mdna:55]

[0001032975-15-000032:mdna:48]
Our net retail sales in the three months ended June 30, 2015 remained flat compared with the same period of the prior fiscal year. Sales increases in the Americas and Asia pacific regions were offset by a decrease in the EMEA region during the three months ended June 30, 2015. If currency exchange rates had been constant in the three months ended June 30, 2015 and 2014, our constant dollar retail sales would have increased by 7%.

[0001032975-15-000032:mdna:49]
[same as prior period, unchanged from 0001628280-15-000267:mdna:57]

[0001032975-15-000032:mdna:50]
OEM net sales decreased 32% in the three months ended June 30, 2015, compared with the same period of the preceding fiscal year. Given our heightened focus on our growing Retail Strategic business, we plan to exit the OEM business. If currency exchange rates had been constant in the three months ended June 30, 2015 and 2014, our constant dollar OEM net sales would have decreased by 31%.

[0001032975-15-000032:mdna:51]
[same as prior period, unchanged from 0001628280-15-000267:mdna:59]

[0001032975-15-000032:mdna:52]
Video conferencing net sales decreased 12% during the three months ended June 30, 2015, compared with the same period of the prior fiscal year. If currency exchange rates had been constant in the three months ended June 30, 2015 and 2014, our constant dollar video conferencing net sales would have decreased 12%. Lifesize is in the process of transitioning its product portfolio to the recently announced Lifesize Cloud, a software-as-a-service (SaaS) offering that provides an affordable, simple and scalable video conferencing solution with little to no need for information technology (IT) involvement. While sales of the Cloud offering are growing rapidly, they are not yet large enough to offset the combination of the short-term portfolio transition and soft market conditions for video conferencing infrastructure. The global restructuring plan we announced in April 2015 also covers Lifesize business to align our refocus on Lifesize Cloud offering and transition from Lifesize legacy business.

[0001032975-15-000032:mdna:53]
[same as prior period, unchanged from 0001628280-15-000267:mdna:61]

[0001032975-15-000032:mdna:54]
The following table presents the change in retail sales by for the three months ended June 30, 2015, compared to the three months ended June 30, 2014:

[0001032975-15-000032:mdna:55]
|  | Three Months EndedJune 30, 2015Change in Sales |
| Americas | 9 | % |
| EMEA | (15 | ) |
| Asia Pacific | 5 |  |

[0001032975-15-000032:mdna:56]
[same as prior period, unchanged from 0001628280-15-000267:mdna:64]

[0001032975-15-000032:mdna:57]
The Americas region increased by 9% in retail sales during the three months ended June 30, 2015, compared with the same period of the prior fiscal year. If currency exchange rates had been constant in the three months ended June 30, 2015 and 2014, our constant dollar retail sales would have increased by 10% in the Americas. We have achieved sales increases in all strategic categories except Gaming, Home Control, and Tablets & Other Accessories. This increase was led by over 60% growth in Mobile Speakers and Video Collaboration.

[0001032975-15-000032:mdna:58]
[same as prior period, unchanged from 0001628280-15-000267:mdna:66]

[0001032975-15-000032:mdna:59]
Retail sales in the EMEA region decreased 15% during the three months ended June 30, 2015, compared with the same period of the prior fiscal year.  If currency exchange rates had been constant in the three months ended June 30, 2015 and 2014, our constant dollar retail sales would have increased by 1% in the EMEA.

[0001032975-15-000032:mdna:60]
[same as prior period, unchanged from 0001628280-15-000267:mdna:68]

[0001032975-15-000032:mdna:61]
Asia Pacific region retail sales increased by 5% during the three months ended June 30, 2015, compared with the same period of the prior fiscal year. If currency exchange rates had been constant in the three months ended June 30, 2015 and 2014, our constant dollar retail sales in the Asia Pacific region would have increased by 10%. We had growth in Video Collaboration Gaming, Keyboards & Combos, and PC Webcams during the three months ended June 30, 2015. These increases were offset in part by weakness in our Tablet & Other accessories, Pointing Devices, and Audio-PC Wearables categories.

[0001032975-15-000032:mdna:62]
[same as prior period, unchanged from 0001628280-15-000267:mdna:70]

[0001032975-15-000032:mdna:63]
Net sales by product category for the three months ended June 30, 2015 and 2014 were as follows (in thousands):

[0001032975-15-000032:mdna:64]
|  |  | Three Months EndedJune 30, |
|  |  | 2015 |  | 2014 |  | Change |
| Peripherals: |  |  |  |  |  |  |  |  |  |
| Mobile Speakers |  | $ | 40,544 |  |  | $ | 28,830 |  |  | 41 | % |
| Gaming |  | 43,670 |  |  | 46,876 |  |  | (7 | ) |
| Video Collaboration |  | 21,176 |  |  | 15,225 |  |  | 39 |  |
| Tablet & Other Accessories |  | 18,809 |  |  | 31,716 |  |  | (41 | ) |
| Growth |  | 124,199 |  |  | 122,647 |  |  | 1 |  |
| Pointing Devices |  | 116,985 |  |  | 113,042 |  |  | 3 |  |
| Keyboards & Combos |  | 105,829 |  |  | 105,489 |  |  | — |  |
| Audio-PC & Wearables |  | 45,699 |  |  | 48,548 |  |  | (6 | ) |
| PC Webcams |  | 21,681 |  |  | 20,463 |  |  | 6 |  |
| Home Control |  | 10,254 |  |  | 12,332 |  |  | (17 | ) |
| Profit Maximization |  | 300,448 |  |  | 299,874 |  |  | — |  |
| Retail Strategic Sales |  | 424,647 |  |  | 422,521 |  |  | 1 |  |
| Non-Strategic |  | 741 |  |  | 1,293 |  |  | (43 | ) |
| Retail |  | 425,388 |  |  | 423,814 |  |  | — |  |
| OEM |  | 22,298 |  |  | 32,632 |  |  | (32 | ) |
|  |  | 447,686 |  |  | 456,446 |  |  | (2 | ) |
| Video conferencing |  | 22,634 |  |  | 25,757 |  |  | (12 | ) |
|  |  | $ | 470,320 |  |  | $ | 482,203 |  |  | (2 | ) |

[0001032975-15-000032:mdna:65]
Certain products within the retail product families presented in prior period have been reclassified to conform to the current period's presentation.

[0001032975-15-000032:mdna:66]
Retail Strategic Sales

[0001032975-15-000032:mdna:67]
During the three months ended June 30, 2015, Retail Strategic sales increased 1% compared to the same period of fiscal year 2014. If currency exchange rates had been constant for the three months ended June 30, 2015 and 2014, our constant dollar retail strategic sales would have increased 7%.

[0001032975-15-000032:mdna:68]
Retail Strategic - Growth Categories:

[0001032975-15-000032:mdna:69]
During the three months ended June 30, 2015, Retail Strategic sales - Growth categories increased 1% compared to the same period of fiscal year 2014. If currency exchange rates had been constant for the three months ended June 30, 2015 and 2014, our constant dollar Retail Strategic sales - Growth categories would have increased 9%.

[0001032975-15-000032:mdna:70]
[same as prior period, unchanged from 0001628280-15-000267:mdna:84]

[0001032975-15-000032:mdna:71]
Our retail Mobile Speakers category products are portable Bluetooth wireless speakers.

[0001032975-15-000032:mdna:72]
Retail sales and units sold of Mobile Speakers increased 41% and 23%, respectively, for the three month period ended June 30, 2015, compared with the same period of the prior fiscal year. Mobile Speaker sales increased significantly due to the introduction of the UE Megaboom.

[0001032975-15-000032:mdna:73]
Gaming

[0001032975-15-000032:mdna:74]
Our retail Gaming category comprises Gaming mice, keyboards, headsets, gamepads and steering wheels.

[0001032975-15-000032:mdna:75]
Retail sales of Gaming decreased 7% and units sold decreased 3% in the three months ended June 30, 2015 compared to the three months ended June 30, 2014. Gaming Steering Wheels sales decreased by 39% primarily

[0001032975-15-000032:mdna:76]
due to phasing out of old models in preparation for the launch of new wheels in the coming months, partially offset by a Gaming Keyboard sales increase of 13%, with our new product G910 Orion Spark Mechanical Keyboard making a strong contribution. Sales of our Gaming products declined in the Americas and EMEA regions, offset by growth in the APAC region.

[0001032975-15-000032:mdna:77]
Video Collaboration

[0001032975-15-000032:mdna:78]
Our retail Video Collaboration category primarily includes video products and certain headset products that can connect small and medium sized user groups.

[0001032975-15-000032:mdna:79]
Retail sales of Video Collaboration increased 39% and units sold increased 74% in the three months ended June 30, 2015, compared to the three months ended June 30, 2014. The sales increased significantly with the introduction of the Conference Cam Connect and strong sales of the C930 Webcam.

[0001032975-15-000032:mdna:80]
[same as prior period, unchanged from 0001628280-15-000267:mdna:79]

[0001032975-15-000032:mdna:81]
[same as prior period, unchanged from 0001628280-15-000267:mdna:80]

[0001032975-15-000032:mdna:82]
Retail sales of Tablet & Other Accessories decreased 41% and units sold decreased 21% in the three months ended June 30, 2015, compared with the same period of the prior fiscal year. The reduction in sales reflects the combination of a declining market for iPad shipments as well as phasing out end-of-life products as we phase in our new products.

[0001032975-15-000032:mdna:83]
Retail Strategic - Profit Maximization Categories:

[0001032975-15-000032:mdna:84]
During the three months ended June 30, 2015, Retail Strategic sales - Profit Maximization categories remained flat compared to the same period of fiscal year 2014. If currency exchange rates had been constant for the three months ended June 30, 2015 and 2014, our constant dollar Retail Strategic sales - Profit Maximization categories would have increased 7%.

[0001032975-15-000032:mdna:85]
[same as prior period, unchanged from 0001628280-15-000267:mdna:89]

[0001032975-15-000032:mdna:86]
[same as prior period, unchanged from 0001628280-15-000267:mdna:90]

[0001032975-15-000032:mdna:87]
Retail sales of Pointing Devices increased 3% while retail units sold increased 1% in the three months ended June 30, 2015, compared to the three month period ended June 30, 2014. Sales increased at the high end with the introduction of the MX Master Wireless Mouse. Sales of cordless mice increased 9% and units sold increasing 7%.

[0001032975-15-000032:mdna:88]
Keyboards and Combos

[0001032975-15-000032:mdna:89]
Our retail Keyboards & Combos category comprises PC keyboards and keyboard/mice combo products.

[0001032975-15-000032:mdna:90]
Retail sales of Keyboards & Combos remained flat and units sold increased 7% in the three months ended June 30, 2015, compared with the same period of the prior fiscal year. We achieved double digit sales growth in the Americas and APAC regions, offset by declines in the EMEA region. The sales increase was driven by cordless keyboards and cordless combo products, offset by a decline in living room keyboards.

[0001032975-15-000032:mdna:91]
[same as prior period, unchanged from 0001628280-15-000267:mdna:97]

[0001032975-15-000032:mdna:92]
[same as prior period, unchanged from 0001628280-15-000267:mdna:98]

[0001032975-15-000032:mdna:93]
Audio-PC & Wearables sales decreased 6% and units sold decreased 5% in the three months ended June 30, 2015, compared with the same period of the prior fiscal year. The decrease was primarily due to decreases in PC speaker retail sales, reflecting a category in structural decline as music consumption migrates to mobile platforms. This migration benefits products in our Mobile Speakers category such as our UE Bluetooth mobile speaker. Retail sales of our headsets products decreased 5%.

[0001032975-15-000032:mdna:94]
PC Webcams

[0001032975-15-000032:mdna:95]
Our retail PC Webcams category comprises retail webcams for consumer applications.

[0001032975-15-000032:mdna:96]
Retail PC Webcams sales increased 6% and units sold increased 1% in the three months ended June 30, 2015, compared with the same period in the prior fiscal year. The increase was mainly driven by sales of the Logitech HD Pro Webcam C920.

[0001032975-15-000032:mdna:97]
Home Control

[0001032975-15-000032:mdna:98]
Our retail Home Control category comprises our Harmony branded products.

[0001032975-15-000032:mdna:99]
Home Control retail sales decreased 17% and units sold decreased 2% in the three months ended June 30, 2015, compared with the same period of the prior fiscal year. The sales decline was primarily driven by declines in high end remote controls.

[0001032975-15-000032:mdna:100]
Non-Strategic

[0001032975-15-000032:mdna:101]
This category comprises a variety of products out of which we currently intend to transition, or have already transitioned, because they are no longer strategic to our business. Product categories included in this category include TV Camera, Digital Video Security, TV and home speakers, and Keyboard/ Desktop accessories.

[0001032975-15-000032:mdna:102]
Non-strategic retail sales decreased 43% and units sold decreased 31% during the three months ended June 30, 2015, compared with the same period in the prior fiscal year.

[0001032975-15-000032:mdna:103]
[same as prior period, unchanged from 0001628280-15-000267:mdna:112]

[0001032975-15-000032:mdna:104]
OEM sales decreased 32% and units sold decreased 22% during the three months ended June 30, 2015, compared with the same period of the prior fiscal year. As announced in April 2015, we plan to exit the OEM business by the end of December 2015 as we see limited opportunities for profitable growth.

[0001032975-15-000032:mdna:105]
[same as prior period, unchanged from 0001628280-15-000267:mdna:114]

[0001032975-15-000032:mdna:106]
Video conferencing net sales decreased 12% during the three months ended June 30, 2015, compared with the same period of the prior fiscal year. The decrease in net sales was due to a decrease in legacy business, offset by an increase in our Cloud offering. Lifesize is in the process of transitioning its product portfolio to the recently announced Lifesize Cloud, a software-as-a-service (SaaS) offering that provides an affordable, simple and scalable video conferencing solution with little to no need for IT involvement. While sales of the Cloud offering are growing rapidly, they are not yet large enough to offset the combination of the short-term portfolio transition and soft market conditions for video conferencing infrastructure. We recently decided to reorganize Lifesize with the goal of de-emphasizing Lifesize’s legacy offerings more quickly to enable maximum traction with Lifesize Cloud. We plan to shrink our Lifesize business to grow the Cloud opportunity faster.

[0001032975-15-000032:mdna:107]
[same as prior period, unchanged from 0001628280-15-000267:mdna:116]

[0001032975-15-000032:mdna:108]
Gross profit for three months ended June 30, 2015 and 2014 was as follows (in thousands):

[0001032975-15-000032:mdna:109]
|  |  | Three Months EndedJune 30, |
|  |  | 2015 |  | 2014 |  | Change |
| Net sales |  | $ | 470,320 |  |  | $ | 482,203 |  |  | (2 | )% |
| Cost of goods sold |  | 298,591 |  |  | 300,450 |  |  | (1 | ) |
| Gross profit |  | $ | 171,729 |  |  | $ | 181,753 |  |  | (6 | ) |
| Gross margin |  | 36.5 | % |  | 37.7 | % |  |  |  |

[0001032975-15-000032:mdna:110]
Gross profit consists of net sales, less cost of goods sold, which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, royalties, costs of purchasing components from outside suppliers,

[0001032975-15-000032:mdna:111]
distribution costs, warranty costs, customer support, outside processing costs, write-down of inventories and amortization of intangible assets.

[0001032975-15-000032:mdna:112]
The decrease in gross margin for the three months ended June 30, 2015 compared with the same period of the prior fiscal year was primarily driven by the unfavorable currency impact, partially offset by margin improvement from product cost improvement and favorable products mix.

[0001032975-15-000032:mdna:113]
[same as prior period, unchanged from 0001628280-15-000267:mdna:122]

[0001032975-15-000032:mdna:114]
Operating expenses for the three months ended June 30, 2015 and 2014 were as follows (in thousands):

[0001032975-15-000032:mdna:115]
|  |  | Three Months EndedJune 30, |
|  |  | 2015 |  | 2014 |  | Change |
| Marketing and selling |  | $ | 87,427 |  |  | $ | 91,045 |  |  | (4 | )% |
| % of net sales |  | 18.6 | % |  | 18.9 | % |  |  |  |
| Research and development |  | 33,833 |  |  | 31,316 |  |  | 8 |  |
| % of net sales |  | 7.2 | % |  | 6.5 | % |  |  |  |
| General and administrative |  | 30,504 |  |  | 36,680 |  |  | (17 | ) |
| % of net sales |  | 6.5 | % |  | 7.6 | % |  |  |  |
| Restructuring charges (credits), net |  | 12,995 |  |  | — |  |  | NM |  |
| % of net sales |  | 2.8 | % |  | — | % |  |  |  |
| Total operating expenses |  | $ | 164,759 |  |  | $ | 159,041 |  |  | 4 |  |
| % of net sales |  | 35.0 | % |  | 33.0 | % |  |  |  |

[0001032975-15-000032:mdna:116]
NM=Not Meaningful.

[0001032975-15-000032:mdna:117]
[same as prior period, unchanged from 0001628280-15-000267:mdna:125]

[0001032975-15-000032:mdna:118]
Marketing and selling expenses consist of personnel and related overhead, corporate and product marketing, advertising, trade shows, customer and technical support and facilities costs.

[0001032975-15-000032:mdna:119]
During the three months ended June 30, 2015, marketing and selling expenses decreased 4%, compared to the three months ended June 30, 2014. The decrease was primarily due to a $2.6 million savings from personnel related costs primarily for Lifesize restructuring and $2.0 million decrease in the amortization of Lifesize intangible assets, offset by $1.0 million increase in spend for Music and Gaming product categories.

[0001032975-15-000032:mdna:120]
[same as prior period, unchanged from 0001628280-15-000267:mdna:129]

[0001032975-15-000032:mdna:121]
Research and development expenses consist of personnel and related overhead, contractors and outside consultants, supplies and materials, equipment depreciation and facilities costs, all associated with the design and development of new products and enhancements of existing products.

[0001032975-15-000032:mdna:122]
During the three months ended June 30, 2015, research and development expenses increased 8%, compared to the three months ended June 30, 2014. The increase was primarily due to a $1.5 million investment increase in Seeds development (new business opportunities).

[0001032975-15-000032:mdna:123]
[same as prior period, unchanged from 0001628280-15-000267:mdna:132]

[0001032975-15-000032:mdna:124]
General and administrative expenses consist primarily of personnel and related overhead and facilities costs for the finance, information systems, executive, people & culture and legal functions.

[0001032975-15-000032:mdna:125]
During the three months ended June 30, 2015, general and administrative expenses decreased 17%, compared to the three months ended June 30, 2014. The decrease was primarily due to an $8.5 million reduction related to the prior year's independent Audit committee investigation and related expenses and a $1.5 million reduction in IT, legal and finance spend, partially offset by a $3.5 million additional accrual for our proposed settlement with the SEC (see Other Contingencies for more details).

[0001032975-15-000032:mdna:126]
[same as prior period, unchanged from 0001628280-15-000267:mdna:135]

[0001032975-15-000032:mdna:127]
During the first quarter of fiscal year 2016, we implemented a restructuring plan to exit the OEM business, reorganize Lifesize to sharpen our focus on its Cloud-based offering, and streamline our overall cost structure through product, overhead and infrastructure cost reductions with a targeted resource realignment. Restructuring charges incurred during the three months ended June 30, 2015 under this plan primarily consisted of severance and other ongoing and one-time termination benefits. Charges and other costs related to the workforce reduction and structure realignment are presented as restructuring charges in the Condensed Consolidated Statements of Operations. We expect to incur approximately $15 million to $20 million under this restructuring plan, and expect to substantially complete this restructuring within the next 12 months. We expect this restructuring will save personnel-related costs and other overhead costs and we expect to use the savings from the restructuring to offset currency headwinds and to invest in future growth.

[0001032975-15-000032:mdna:128]
The following table summarizes restructuring related activities during three months ended June 30, 2015.

[0001032975-15-000032:mdna:129]
|  |  | Restructuring |
|  |  | TerminationBenefits |  | Lease ExitCosts |  | Other |  | Total |
| Accrual balance at March 31, 2015 |  | $ | — |  |  | $ | 1,039 |  |  | — |  |  | $ | 1,039 |  |
| Charges |  | 12,794 |  |  | — |  |  | 201 |  |  | 12,995 |  |
| Cash payments |  | (4,675 | ) |  | (796 | ) |  | $ | (151 | ) |  | (5,622 | ) |
| Accrual balance at June 30, 2015 |  | 8,119 |  |  | 243 |  |  | 50 |  |  | 8,412 |  |

[0001032975-15-000032:mdna:130]
[same as prior period, unchanged from 0001628280-15-000267:mdna:138]

[0001032975-15-000032:mdna:131]
Other Expense, Net

[0001032975-15-000032:mdna:132]
Other income and expense for the three months ended June 30, 2015 and 2014 were as follows (in thousands):

[0001032975-15-000032:mdna:133]
|  |  | Three Months EndedJune 30, |  | Change |
|  |  | 2015 |  | 2014 |  |  |
| Investment income related to deferred compensation plan |  | $ | 100 |  |  | $ | 264 |  |  | $ | (164 | ) |
| Currency exchange losses |  | (1,275 | ) |  | (528 | ) |  | (747 | ) |
| Others |  | 54 |  |  | 66 |  |  | (12 | ) |
|  |  | $ | (1,121 | ) |  | $ | (198 | ) |  | $ | (923 | ) |

[0001032975-15-000032:mdna:134]
The currency exchange losses were $1.3 million and $0.5 million during the three months ended June 30, 2015 and 2014, respectively. Currency exchange losses relate to balances denominated in currencies other than the functional currency of a particular subsidiary, to the sale of currencies, and to gains or losses recognized on currency exchange forward contracts.

[0001032975-15-000032:mdna:135]
[same as prior period, unchanged from 0001628280-15-000267:mdna:150]

[0001032975-15-000032:mdna:136]
The provision for (benefit from) income taxes and effective tax rates for the three months ended June 30, 2015 and 2014 were as follows (in thousands):

[0001032975-15-000032:mdna:137]
|  |  | Three Months EndedJune 30, |
|  |  | 2015 |  | 2014 |
| Provision for (benefit from) income tax |  | $ | (1,324 | ) |  | $ | 3,096 |  |
| Effective income tax rate |  | (21.7 | )% |  | 13.6 | % |

[0001032975-15-000032:mdna:138]
The change in the effective income tax rate for the three months ended June 30, 2015 compared with the three months ended June 30, 2014 is primarily due to the mix of income and losses in the various tax jurisdictions in which we operate. There was a discrete tax benefit of $2.2 million and $0.8 million in the three months ended June 30, 2015 and 2014, respectively, resulting from the preferential income tax rate reduction pursuant to the High and New Technology Enterprise Program in China.

[0001032975-15-000032:mdna:139]
As of June 30 and March 31, 2015, the total amount of unrecognized tax benefits due to uncertain tax positions was $79.2 million and $79.0 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-15-000032:mdna:140]
[same as prior period, unchanged from 0001628280-15-000267:mdna:156]

[0001032975-15-000032:mdna:141]
[same as prior period, unchanged from 0001628280-15-000267:mdna:157]

[0001032975-15-000032:mdna:142]
As of June 30, 2015, we had cash and cash equivalents of $492.2 million, compared with $537.0 million at March 31, 2015. Our cash and cash equivalents consist of bank demand deposits and short-term time deposits of which 62% is held by our subsidiaries in Switzerland, 17% is held by our subsidiaries in the United Kingdom, 13% is held by our subsidiaries in Hong Kong and China, and 8% is held by subsidiaries in various other countries. We do not expect to incur any material adverse tax impact or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-15-000032:mdna:143]
As of June 30, 2015, our working capital was $560.3 million compared with working capital of $557.1 million at March 31, 2015.  Higher accounts receivable and inventory balances increased working capital, offset by lower cash and cash equivalents, and higher accounts payable and accrued liabilities.

[0001032975-15-000032:mdna:144]
During the three months ended June 30, 2015, we used $25.6 million cash in operating activities. Our main cash outflows of operating cash resulted from increases in accounts receivable and inventories, partially offset by increases in accounts payable and accrued liabilities. Net cash used in investing activities was $15.6 million, primarily from $15.3 million of capital expenditure in computer hardware and software, tooling and equipment. Net cash used in financing activities was $5.4 million, primarily related to share repurchases of $8.8 million and tax withholdings related to net share settlements of restricted stock units (RSUs) of $1.3 million, offset by $4.1 million proceeds from sales of shares upon exercise of options.

[0001032975-15-000032:mdna:145]
We had several uncommitted, unsecured bank lines of credit aggregating $34.6 million as of June 30, 2015. There are no financial covenants under these lines of credit with which we must comply. As of June 30, 2015, we had outstanding bank guarantees of $14.3 million under these lines of credit.

[0001032975-15-000032:mdna:146]
The following table summarizes our Condensed Consolidated Statements of Cash Flows (in thousands):

[0001032975-15-000032:mdna:147]
|  |  | Three Months Ended June 30, |
|  |  | 2015 |  | 2014 |
| Net cash provided by (used in) operating activities |  | $ | (25,599 | ) |  | $ | 27,758 |  |
| Net cash used in investing activities |  | (15,593 | ) |  | (12,241 | ) |
| Net cash provided by (used in) financing activities |  | (5,379 | ) |  | 160 |  |
| Effect of exchange rate changes on cash and cash equivalents |  | 1,761 |  |  | (108 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | (44,810 | ) |  | $ | 15,569 |  |

[0001032975-15-000032:mdna:148]
[same as prior period, unchanged from 0001628280-15-000267:mdna:165]

[0001032975-15-000032:mdna:149]
The following table presents selected financial information and statistics as of June 30, 2015 and 2014 (dollars in thousands):

[0001032975-15-000032:mdna:150]
|  |  | As of June 30 |
|  |  | 2015 |  | 2014 |
| Accounts receivable, net |  | $ | 221,580 |  |  | $ | 219,022 |  |
| Inventories |  | 327,507 |  |  | 240,357 |  |
| Working capital |  | 560,324 |  |  | 509,207 |  |
| Days sales in accounts receivable (“DSO”) (Days) (1) |  | 42 |  |  | 41 |  |
| Inventory turnover (“ITO”) (x)(2) |  | 3.6 |  |  | 5.0 |  |

[0001032975-15-000032:mdna:151]
[same as prior period, unchanged from 0001628280-15-000267:mdna:168]

[0001032975-15-000032:mdna:152]
[same as prior period, unchanged from 0001628280-15-000267:mdna:169]

[0001032975-15-000032:mdna:153]
During the three months ended June 30, 2015, we used cash of $25.6 million in operating activities, compared to cash provided by operating activities of $27.8 million for the same period in the prior fiscal year. The primary drivers of the decrease in net cash generated from operating cash flows include and inventory change of $36 million and a decrease in net income of $12 million, for the three months ended June 30, 2015 from the three months ended June 30, 2014.

[0001032975-15-000032:mdna:154]
Inventory turnover during the three months ended June 30, 2015 decreased, compared with the three months ended June 30, 2014. The increase in inventory was primarily due to several new product introductions planned for the remainder of fiscal year 2016, transition from ODM to in-house production, adjusting our inventory strategy to emphasize sea shipments rather than air delivery since the fourth quarter of fiscal year 2015, and lingering effects of the port strike on the west coast of the United States. If we are not successful in launching and phasing in our new products in the remainder of fiscal year 2016, or we are not able to sell the new products at the prices planned, it could have a material impact on our gross profit margin, operating results including operating cash flow and inventory turnover in the future.

[0001032975-15-000032:mdna:155]
[same as prior period, unchanged from 0001628280-15-000267:mdna:173]

[0001032975-15-000032:mdna:156]
The following table presents information on our cash flows from investing activities during the three months ended June 30, 2015 and 2014 (in thousands):

[0001032975-15-000032:mdna:157]
|  |  | Three Months Ended June 30, |
|  |  | 2015 |  | 2014 |
| Purchases of property, plant and equipment |  | $ | (15,290 | ) |  | $ | (11,243 | ) |
| Investment in privately held companies |  | (240 | ) |  | (1,050 | ) |
| Purchase of trading investments |  | (903 | ) |  | (454 | ) |
| Proceeds from sales of trading investments |  | 840 |  |  | 506 |  |
| Net cash used in investing activities |  | $ | (15,593 | ) |  | $ | (12,241 | ) |

[0001032975-15-000032:mdna:158]
Our expenditures for property, plant and equipment during the three months ended June 30, 2015 and 2014 were primarily for computer hardware and software, tooling, equipment and leasehold improvements. The increase in purchases of property, plant and equipment during the three months ended June 30, 2015 is mainly arising from the building of production lines to accommodate the in-house manufacturing of our certain products compared with purchase from third party in prior period to align our goal of cost saving.

[0001032975-15-000032:mdna:159]
The purchases and sales of trading investments in the three months ended June 30, 2015 and 2014 represent mutual fund activity directed by participants in a deferred compensation plan offered by one of our subsidiaries. The mutual funds are held by a Rabbi trust.

[0001032975-15-000032:mdna:160]
[same as prior period, unchanged from 0001628280-15-000267:mdna:179]

[0001032975-15-000032:mdna:161]
The following table presents information on our cash flows from financing activities during the three months ended June 30, 2015 and 2014 (in thousands):

[0001032975-15-000032:mdna:162]
|  |  | Three Months Ended June 30, |
|  |  | 2015 |  | 2014 |
| Contingent consideration related to prior acquisition |  | — |  |  | (100 | ) |
| Purchases of treasury shares |  | (8,814 | ) |  | — |  |
| Proceeds from sales of shares upon exercise of options |  | 4,066 |  |  | 574 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (1,296 | ) |  | (695 | ) |
| Excess tax benefits from share-based compensation |  | 665 |  |  | 381 |  |
| Net cash provided by (used in) financing activities |  | $ | (5,379 | ) |  | $ | 160 |  |

[0001032975-15-000032:mdna:163]
During three months ended June 30, 2015, 0.6 million shares were repurchased for $8.8 million. There were no share repurchases during the three months ended June 30, 2014.

[0001032975-15-000032:mdna:164]
Proceeds from the sale of shares upon exercise of options and purchase rights pursuant to our stock plans during the three months ended June 30, 2015 and 2014 were $4.1 million and $0.6 million, respectively. The payment of required tax withholdings related to net share settlements of RSUs during the three months ended June 30, 2015 and 2014 was $1.3 million and $0.7 million, respectively.

[0001032975-15-000032:mdna:165]
[same as prior period, unchanged from 0001628280-15-000267:mdna:184]

[0001032975-15-000032:mdna:166]
[same as prior period, unchanged from 0001628280-15-000267:mdna:185]

[0001032975-15-000032:mdna:167]
In March 2015, we announced a plan to pay $250 million in cumulative dividends for fiscal year 2015 through fiscal year 2017. The Board of Directors plans to request shareholder approval of the Swiss Franc equivalent of an $85 million dividend for fiscal year 2015 at our next annual general meeting. Based on an exchange rate of 1CHF=USD1.0283 and the number of shares outstanding as of March 31, 2015, this represents approximately CHF 0.5025 per share, compared to dividend of CHF 0.26 per share for the previous fiscal year. During fiscal year 2015, we paid a cash dividend of CHF 43.1 million (U.S. Dollar amount of $43.8 million) out of retained earnings.

[0001032975-15-000032:mdna:168]
In March 2014, our Board of Directors approved a new share buyback program, which authorizes us to purchase up to $250.0 million of our own shares. Our share buyback program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. During three months ended June 30, 2015, 0.6 million shares were repurchased for $8.8 million. There were no share repurchases during the three months ended June 30, 2014.

[0001032975-15-000032:mdna:169]
During the first quarter of fiscal year 2016, we announced that we are committing to pursue a restructuring, including exiting the OEM business, reorganizing Lifesize to sharpen its focus on its Cloud-based offering, and streamlining the Company's overall cost structure through product, overhead and infrastructure cost reductions with a targeted resource realignment.  The Company expects to incur approximately $15 million to $20 million under this restructuring plan, and expects to substantially complete this restructuring within the next 12 months. We expect this restructuring will save personnel-related costs and other overhead costs and we expect to use the savings from the restructuring to offset currency headwinds and to invest in future growth.

[0001032975-15-000032:mdna:170]
During the fourth quarter of fiscal year 2013, we implemented a restructuring plan to align the organization to its strategic priorities of increasing focus on mobility products, improving profitability in PC-related products and enhancing global operational efficiencies.

[0001032975-15-000032:mdna:171]
If we do not generate sufficient operating cash flows to support our operations and future planned cash requirements, our operations could be harmed and our access to credit facilities could be restricted or eliminated. However, we believe that the trend of our historical cash flow generation, our projections of future operations and reduced expenses and our available cash balances will provide sufficient liquidity to fund our operations for at least the next 12 months.

[0001032975-15-000032:mdna:172]
[same as prior period, unchanged from 0001628280-15-000267:mdna:190]

[0001032975-15-000032:mdna:173]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. The remaining terms on our non-cancelable operating leases expire in various years through 2030. Our asset retirement obligations on these leases as of June 30, 2015 were not material.

[0001032975-15-000032:mdna:174]
[same as prior period, unchanged from 0001628280-15-000267:mdna:192]

[0001032975-15-000032:mdna:175]
As of June 30, 2015, we had fixed purchase commitments for inventory purchases made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. Fixed purchase commitments for capital expenditures primarily relate to commitments for computer hardware, leasehold improvements, and tooling for new and existing products. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-15-000032:mdna:176]
[same as prior period, unchanged from 0001628280-15-000267:mdna:198]

[0001032975-15-000032:mdna:177]
For further detail about our contractual obligations and commitments, please refer to our Annual Report on Form 10-K for the fiscal year ended March 31, 2015.

[0001032975-15-000032:mdna:178]
[same as prior period, unchanged from 0001628280-15-000267:mdna:200]

[0001032975-15-000032:mdna:179]
[same as prior period, unchanged from 0001628280-15-000267:mdna:201]

[0001032975-15-000032:mdna:180]
Other Contingencies

[0001032975-15-000032:mdna:181]
We are subject to an ongoing formal investigation by the Enforcement Division of the U.S. Securities and Exchange Commission (SEC), relating to certain issues including the accounting for Revue inventory valuation reserves that resulted in the restatement, described in the Fiscal 2014 Form 10-K, revision to our consolidated financial statements concerning warranty accruals and amortization of intangible assets presented in our Amended Annual Report on Form 10-K/A, filed on August 7, 2013, and our transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. We have entered into an agreement with the Enforcement Staff to extend the statute of limitations. We are cooperating with the investigation and, after discussions with the Enforcement Staff, we recently made an offer of settlement to resolve the matter, which is subject to approval by the SEC.  The proposed settlement would be entered into by us without admitting or denying the SEC’s findings and would resolve alleged violations of certain provisions of the Securities Exchange Act of 1934 and related rules, including the anti-fraud provisions.  Under the terms of the proposed settlement, we would pay $7.5 million in a civil penalty and agree not to commit or cause any violations of certain provisions of the Securities Exchange Act of 1934 and related rules.  There is no assurance that the proposal will be approved by the SEC. In accordance with U.S. GAAP, we have made a corresponding accrual in our financial statements.

[0001032975-15-000032:mdna:182]
[same as prior period, unchanged from 0001628280-15-000267:mdna:204]

[0001032975-15-000032:mdna:183]
Logitech Europe S.A.  guaranteed payments of third-party contract manufacturers' purchase obligations. As of June 30, 2015, the maximum amount of this guarantee was $3.8 million, of which $1.6 million of guaranteed purchase obligations were outstanding.

[0001032975-15-000032:mdna:184]
[same as prior period, unchanged from 0001628280-15-000267:mdna:206]

[0001032975-15-000032:mdna:185]
We indemnify certain of our suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2015, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-15-000032:mdna:186]
[same as prior period, unchanged from 0001628280-15-000267:mdna:208]

[0001032975-15-000032:mdna:187]
Legal Proceedings

[0001032975-15-000032:mdna:188]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of our business. We are currently subject to several such claims and a small number of legal proceedings. We believe that these matters lack merit and we intend to vigorously defend against them. Based on currently available information, we do not believe that resolution of pending matters will have a material adverse effect on our financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that our defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on our business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against us, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect our business.

[0001032975-15-000032:mdna:189]
37
