# LOGI notes — 0001032975-15-000032


## logi:ScheduleOfBalanceSheetComponentsAssetsTableTextBlock

[0001032975-15-000032:notes:1]
The following table presents the components of certain balance sheet asset amounts as of June 30 and March 31, 2015 (in thousands):

[0001032975-15-000032:notes:2]
|  |  | June 30,2015 |  | March 31,2015 |
| Accounts receivable, net: |  |  |  |  |  |  |
| Accounts receivable |  | $ | 436,724 |  |  | $ | 344,455 |  |
| Allowance for doubtful accounts |  | (1,247 | ) |  | (1,093 | ) |
| Allowance for sales returns |  | (20,146 | ) |  | (17,901 | ) |
| Allowance for cooperative marketing arrangements |  | (39,127 | ) |  | (25,700 | ) |
| Allowance for customer incentive programs |  | (67,461 | ) |  | (48,497 | ) |
| Allowance for pricing programs |  | (87,163 | ) |  | (71,441 | ) |
|  |  | $ | 221,580 |  |  | $ | 179,823 |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 50,199 |  |  | $ | 36,376 |  |
| Finished goods |  | 277,308 |  |  | 234,354 |  |
|  |  | $ | 327,507 |  |  | $ | 270,730 |  |
| Other current assets: |  |  |  |  |  |  |
| Income tax and value-added tax receivables |  | $ | 19,548 |  |  | $ | 19,403 |  |
| Deferred tax assets |  | 36,601 |  |  | 27,790 |  |
| Prepaid expenses and other assets |  | 17,161 |  |  | 17,236 |  |
|  |  | $ | 73,310 |  |  | $ | 64,429 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |
| Property, plant and equipment |  | 364,638 |  |  | 349,235 |  |
| Less accumulated depreciation and amortization |  | (262,969 | ) |  | (257,642 | ) |
|  |  | $ | 101,669 |  |  | $ | 91,593 |  |
| Other assets: |  |  |  |  |  |  |
| Deferred tax assets |  | $ | 38,534 |  |  | $ | 39,310 |  |
| Trading investments for deferred compensation plan |  | 17,350 |  |  | 17,237 |  |
| Other assets |  | 6,454 |  |  | 6,441 |  |
|  |  | $ | 62,338 |  |  | $ | 62,988 |  |


## logi:ScheduleOfBalanceSheetComponentsLiabilityTableTextBlock

[0001032975-15-000032:notes:3]
The following table presents the components of certain balance sheet liability amounts as of June 30 and March 31, 2015 (in thousands):

[0001032975-15-000032:notes:4]
|  |  | June 30,2015 |  | March 31,2015 |
| Accrued and other current liabilities: |  |  |  |  |  |  |
| Accrued personnel expenses |  | $ | 52,188 |  |  | $ | 50,015 |  |
| Indirect customer incentive programs |  | 22,467 |  |  | 19,730 |  |
| Accrued restructuring |  | 8,341 |  |  | 966 |  |
| Deferred revenue |  | 24,850 |  |  | 24,987 |  |
| Warranty accrual |  | 12,335 |  |  | 12,630 |  |
| Employee benefit plan obligation |  | 1,478 |  |  | 1,232 |  |
| Income taxes payable |  | 2,535 |  |  | 5,794 |  |
| Other current liabilities |  | 89,777 |  |  | 79,558 |  |
|  |  | $ | 213,971 |  |  | $ | 194,912 |  |
| Non-current liabilities: |  |  |  |  |  |  |
| Warranty accrual |  | $ | 8,949 |  |  | $ | 9,080 |  |
| Obligation for deferred compensation plan |  | 17,350 |  |  | 17,237 |  |
| Long term restructuring |  | 71 |  |  | 73 |  |
| Employee benefit plan obligation |  | 52,821 |  |  | 51,181 |  |
| Deferred rent |  | 11,163 |  |  | 11,519 |  |
| Deferred tax liability |  | 1,885 |  |  | 1,936 |  |
| Long term deferred revenue |  | 8,794 |  |  | 9,109 |  |
| Other non-current liabilities |  | 1,464 |  |  | 1,397 |  |
|  |  | $ | 102,497 |  |  | $ | 101,532 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-15-000032:notes:5]
[same as prior period, unchanged from 0001628280-15-000267:notes:22]

[0001032975-15-000032:notes:6]
[same as prior period, unchanged from 0001628280-15-000267:notes:23]

[0001032975-15-000032:notes:7]
The condensed consolidated interim financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (“GAAP”) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. They should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2015, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (“SEC”) on June 5, 2015.  In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal, recurring adjustments, necessary for a fair statement of the results for the periods presented. Operating results for the three months ended June 30, 2015 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2016, or any future periods.

[0001032975-15-000032:notes:8]
[same as prior period, unchanged from 0001628280-15-000267:notes:25]

[0001032975-15-000032:notes:9]
The Company’s fiscal year ends on March 31. Interim quarter ends on last Friday of each quarter.  For purposes of presentation, the Company has indicated its quarterly periods as ending on the quarter end.

[0001032975-15-000032:notes:10]
[same as prior period, unchanged from 0001628280-15-000267:notes:27]

[0001032975-15-000032:notes:11]
There have been no substantial changes in the Company’s significant accounting policies during the three months ended June 30, 2015 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2015.

[0001032975-15-000032:notes:12]
[same as prior period, unchanged from 0001628280-15-000267:notes:29]

[0001032975-15-000032:notes:13]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect reported amounts of assets, liabilities, net sales and expenses, and the disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements. Examples of significant estimates and assumptions made by management involve the fair value of goodwill, warranty liabilities, accruals for discretionary customer programs, sales return reserves, allowance for doubtful accounts, inventory valuation, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ from those estimates.

[0001032975-15-000032:notes:14]
[same as prior period, unchanged from 0001628280-15-000267:notes:31]

[0001032975-15-000032:notes:15]
In May 2014, the FASB issued Accounting Standards Update No. 2014-9, "Revenue from Contracts with Customers (Topic 606)," ("ASU 2014-9"). ASU 2014-9 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. Under the new model, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In addition, the new standard requires that reporting companies disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. As currently issued, the new standard is effective beginning in the first quarter of fiscal year 2019; early adoption is prohibited. The new standard is required to be applied retrospectively to each prior reporting period presented or retrospectively with the cumulative effect of initially applying it recognized at the date of initial application. The Company has not yet selected a transition method nor has it determined the impact of the new standard on its condensed consolidated financial statements.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-15-000032:notes:16]
Commitments and Contingencies

[0001032975-15-000032:notes:17]
Product Warranties

[0001032975-15-000032:notes:18]
All of the Company’s peripherals products are covered by warranty to be free from defects in material and workmanship for periods ranging from one year to five years. At the time of sale, the Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. The Company’s estimate of costs to fulfill its warranty obligations is based on historical experience and expectations of future conditions. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly.

[0001032975-15-000032:notes:19]
Changes in the Company’s warranty liability for three months ended June 30, 2015 and 2014 were as follows (in thousands):

[0001032975-15-000032:notes:20]
|  |  | Three Months EndedJune 30, |
|  |  | 2015 |  | 2014 |
| Beginning of the period |  | $ | 21,710 |  |  | $ | 24,380 |  |
| Provision |  | 2,142 |  |  | 2,206 |  |
| Settlements |  | (2,568 | ) |  | (3,166 | ) |
| End of the period |  | $ | 21,284 |  |  | $ | 23,420 |  |

[0001032975-15-000032:notes:21]
Other Contingencies

[0001032975-15-000032:notes:22]
The Company is subject to an ongoing formal investigation by the Enforcement Division of the U.S. Securities and Exchange Commission ("SEC"), relating to certain issues including the accounting for Revue inventory valuation reserves that resulted in the restatement described in the Fiscal 2014 Form 10-K, revision to the Company’s consolidated financial statements concerning warranty accruals and amortization of intangible assets presented in the Company’s Amended Annual Report on Form10-K/A, filed on August 7, 2013, and the Company’s transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. The Company has entered into an agreement with the Enforcement Staff to extend the statute of limitations. The Company is cooperating with the investigation and, after discussions with the Enforcement Staff, the Company recently made an offer of settlement to resolve the matter, which is subject to approval by the SEC.  The proposed settlement would be entered into by the Company without admitting or denying the SEC’s findings and would resolve alleged violations of certain provisions of the Securities Exchange Act of 1934 and related rules, including the anti-fraud provisions.  Under the terms of the proposed settlement, the Company would pay $7.5 million in a civil penalty and agree not to commit or cause any violations of certain provisions of the Securities Exchange Act of 1934 and related rules. There is no assurance that the proposal will be approved by the SEC. In accordance with U.S. GAAP, the Company has made a corresponding accrual in its financial statements.

[0001032975-15-000032:notes:23]
Guarantees

[0001032975-15-000032:notes:24]
Logitech Europe S.A. guaranteed payments of third-party contract manufacturers’ purchase obligations. As of June 30, 2015, the maximum amount of this guarantee was $3.8 million, of which $1.6 million of guaranteed purchase obligations were outstanding.

[0001032975-15-000032:notes:25]
Indemnifications

[0001032975-15-000032:notes:26]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2015, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-15-000032:notes:27]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-15-000032:notes:28]
Legal Proceedings

[0001032975-15-000032:notes:29]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-15-000032:notes:30]
[same as prior period, unchanged from 0001628280-15-000267:notes:52]

[0001032975-15-000032:notes:31]
[same as prior period, unchanged from 0001628280-15-000267:notes:53]

[0001032975-15-000032:notes:32]
As of June 30, 2015, the Company offers the 2006 ESPP (2006 Employee Share Purchase Plan (Non-U.S.)), the 1996 ESPP (1996 Employee Share Purchase Plan (U.S.)), the 2006 Plan (2006 Stock Incentive Plan) and the 2012 Plan (2012 Stock Inducement Equity Plan).

[0001032975-15-000032:notes:33]
The following table summarizes the share-based compensation expense and related tax benefit recognized for the three months ended June 30, 2015 and 2014 (in thousands):

[0001032975-15-000032:notes:34]
|  |  | Three Months EndedJune 30, |
|  |  | 2015 |  | 2014 |
| Cost of goods sold |  | $ | 605 |  |  | $ | 538 |  |
| Marketing and selling |  | 2,118 |  |  | 2,556 |  |
| Research and development |  | 787 |  |  | 844 |  |
| General and administrative |  | 3,232 |  |  | 3,000 |  |
| Restructuring |  | 7 |  |  | — |  |
| Total share-based compensation expense |  | 6,749 |  |  | 6,938 |  |
| Income tax benefit |  | (1,337 | ) |  | (1,184 | ) |
| Total share-based compensation expense, net of income tax |  | $ | 5,412 |  |  | $ | 5,754 |  |

[0001032975-15-000032:notes:35]
During the three months ended June 30, 2015 and 2014, the Company capitalized $0.5 million of stock-based compensation expenses as inventory, respectively.

[0001032975-15-000032:notes:36]
[same as prior period, unchanged from 0001628280-15-000267:notes:61]

[0001032975-15-000032:notes:37]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The cost recorded of $2.9 million and $2.0 million for the three months ended June 30, 2015 and 2014, respectively, was primarily related to service costs.


## us-gaap:DebtDisclosureTextBlock

[0001032975-15-000032:notes:38]
Financing Arrangements

[0001032975-15-000032:notes:39]
The Company had several uncommitted, unsecured bank lines of credit aggregating $34.6 million as of June 30, 2015. There are no financial covenants under these lines of credit with which the Company must comply. As of June 30, 2015, the Company had outstanding bank guarantees of $14.3 million under these lines of credit. There was no borrowing outstanding under the line of credit as of June 30, 2015 or March 31, 2015.


## us-gaap:EarningsPerShareTextBlock

[0001032975-15-000032:notes:40]
[same as prior period, unchanged from 0001628280-15-000267:notes:65]

[0001032975-15-000032:notes:41]
[same as prior period, unchanged from 0001628280-15-000267:notes:66]

[0001032975-15-000032:notes:42]
|  |  | Three Months EndedJune 30, |
|  |  | 2015 |  | 2014 |
| Net income |  | $ | 7,437 |  |  | $ | 19,676 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 164,431 |  |  | 163,012 |  |
| Effect of potentially dilutive equivalent shares |  | 2,464 |  |  | 2,821 |  |
| Weighted average shares outstanding - diluted |  | 166,895 |  |  | 165,833 |  |
| Net income per share: |  |  |  |  |  |  |
| Basic |  | $ | 0.05 |  |  | $ | 0.12 |  |
| Diluted |  | $ | 0.04 |  |  | $ | 0.12 |  |

[0001032975-15-000032:notes:43]
Share equivalents attributable to outstanding stock options and restricted stock units (RSUs) of 7.3 million and 9.9 million for the three months ended June 30, 2015 and 2014, respectively, were anti-dilutive and excluded from the calculation of diluted net income per share.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-15-000032:notes:44]
[same as prior period, unchanged from 0001628280-15-000267:notes:69]

[0001032975-15-000032:notes:45]
The Company considers fair value as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants at the measurement date. The Company utilizes the following three-level fair value hierarchy to establish the priorities of the inputs used to measure fair value:

[0001032975-15-000032:notes:46]
[same as prior period, unchanged from 0001628280-15-000267:notes:71]

[0001032975-15-000032:notes:47]
[same as prior period, unchanged from 0001628280-15-000267:notes:72]

[0001032975-15-000032:notes:48]
[same as prior period, unchanged from 0001628280-15-000267:notes:73]

[0001032975-15-000032:notes:49]
[same as prior period, unchanged from 0001628280-15-000267:notes:74]

[0001032975-15-000032:notes:50]
|  |  | June 30, 2015 |  | March 31, 2015 |
|  |  | Level 1 |  | Level 2 |  | Level 1 |  | Level 2 |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 217,225 |  |  | $ | — |  |  | $ | 264,647 |  |  | $ | — |  |
|  |  | $ | 217,225 |  |  | — |  |  | $ | 264,647 |  |  | $ | — |  |
| Trading investments for deferred compensation plan: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 2,906 |  |  | — |  |  | $ | 2,936 |  |  | $ | — |  |
| Mutual funds |  | 14,444 |  |  | — |  |  | 14,301 |  |  | — |  |
|  |  | $ | 17,350 |  |  | — |  |  | $ | 17,237 |  |  | $ | — |  |
| Foreign exchange derivative assets |  | $ | — |  |  | $ | 63 |  |  | $ | — |  |  | $ | 2,080 |  |
| Foreign exchange derivative liabilities |  | $ | — |  |  | $ | 912 |  |  | $ | — |  |  | $ | 75 |  |

[0001032975-15-000032:notes:51]
There were no material Level 3 financial assets as of June 30, 2015 or March 31, 2015.

[0001032975-15-000032:notes:52]
[same as prior period, unchanged from 0001628280-15-000267:notes:79]

[0001032975-15-000032:notes:53]
The marketable securities for the Company's deferred compensation plan are recorded at a fair value of $17.4 million and $17.2 million as of June 30, 2015 and March 31, 2015, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized trading gains / (losses) related to trading securities for the three months ended June 30, 2015 and 2014 were not significant and are included in other expense, net.

[0001032975-15-000032:notes:54]
[same as prior period, unchanged from 0001628280-15-000267:notes:82]

[0001032975-15-000032:notes:55]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis on the Condensed Consolidated Balance Sheets as of June 30, 2015 and March 31, 2015.

[0001032975-15-000032:notes:56]
The following table presents the fair values of the Company’s derivative instruments and their accounting line presentation on its Condensed Consolidated Balance Sheets as of June 30, 2015 and March 31, 2015 (in thousands):

[0001032975-15-000032:notes:57]
|  |  | Derivatives |
|  |  | Asset |  | Liability |
|  |  | June 30,2015 |  | March 31,2015 |  | June 30,2015 |  | March 31,2015 |
| Designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash flow hedges |  | $ | 63 |  |  | $ | 2,080 |  |  | $ | 847 |  |  | $ | — |  |
| Not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Currency exchange contracts |  | — |  |  | — |  |  | 65 |  |  | 75 |  |
|  |  | $ | 63 |  |  | $ | 2,080 |  |  | $ | 912 |  |  | $ | 75 |  |

[0001032975-15-000032:notes:58]
The following table presents the amounts of gains and losses on the Company’s derivative instruments and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income for the three months ended June 30, 2015 and 2014 (in thousands):

[0001032975-15-000032:notes:59]
|  |  | Three Months Ended June 30, |
|  |  | Amount of Gain (Loss) Deferred as a Component of Accumulated Other Comprehensive Loss After Reclassification to Costs of Goods Sold |  | Amount of Loss (Gain)Reclassified from AccumulatedOther Comprehensive Loss toCosts of Goods Sold |  | Amount of Gain (Loss)Immediately Recognized inOther Expense, Net |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash flow hedges |  | $ | (4,722 | ) |  | $ | 648 |  |  | $ | (2,460 | ) |  | $ | 400 |  |  | $ | 68 |  |  | $ | (55 | ) |
| Not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Currency exchange contracts |  | — |  |  | — |  |  | — |  |  | — |  |  | (34 | ) |  | (419 | ) |
|  |  | $ | (4,722 | ) |  | $ | 648 |  |  | $ | (2,460 | ) |  | $ | 400 |  |  | $ | 34 |  |  | $ | (474 | ) |

[0001032975-15-000032:notes:60]
[same as prior period, unchanged from 0001628280-15-000267:notes:89]

[0001032975-15-000032:notes:61]
The Company enters into currency exchange forward contracts to hedge against exposure to changes in currency exchange rates related to its subsidiaries’ forecasted inventory purchases. The Company has one entity with a euro functional currency that purchases inventory in U.S. Dollars. The primary risk managed by using derivative instruments is the currency exchange rate risk. The Company has designated these derivatives as cash flow hedges. These hedging contracts mature within four months, and are denominated in the same currency as the underlying transactions. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. The Company assesses the effectiveness of the hedges by comparing changes in the spot rate of the currency underlying the forward contract with changes in the spot rate of the currency in which the forecasted transaction will be consummated. If the underlying transaction being hedged fails to occur or if a portion of the hedge does not generate offsetting changes in the currency exposure of forecasted inventory purchases, the Company immediately recognizes the gain or loss on the associated financial instrument in other expense, net. Such gains and losses were not material during the three months ended June 30, 2015 and 2014. Cash flows from such hedges are classified as operating activities in the condensed consolidated statements of cash flows. The notional amounts of currency exchange forward contracts outstanding related to forecasted inventory purchases were $79.7 million and $43.5 million at June 30, 2015 and March 31, 2015. The Company estimates that $0.8 million of net loss related to its cash flow hedges included in accumulated other comprehensive loss as of June 30, 2015 will be reclassified into earnings within the next 12 months.

[0001032975-15-000032:notes:62]
[same as prior period, unchanged from 0001628280-15-000267:notes:91]

[0001032975-15-000032:notes:63]
The Company also enters into currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain foreign currency receivables or payables. These contracts generally mature within one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on currency exchange contracts are recognized in other expense, net based on the changes in fair value.

[0001032975-15-000032:notes:64]
The notional amounts of currency exchange forward and swap contracts outstanding as of June 30 and March 31, 2015 relating to foreign currency receivables or payables were $52.0 million and $61.7 million, respectively. Open forward and swap contracts outstanding at June 30, 2015 and March 31, 2015 consisted of contracts in Mexican Pesos, Japanese Yen, British Pounds, Taiwanese Dollars and Australian Dollars to be settled at future dates at pre-determined exchange rates.

[0001032975-15-000032:notes:65]
The fair value of all currency exchange forward and swap contracts is determined based on observable market transactions of spot currency rates and forward rates. Cash flows from these contracts are classified as operating activities in the Condensed Consolidated Statements of Cash Flows.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-15-000032:notes:66]
[same as prior period, unchanged from 0001628280-15-000267:notes:95]

[0001032975-15-000032:notes:67]
In accordance with ASC Topic 350-10 (“ASC 350-10”), the Company conducts a goodwill impairment analysis annually at December 31 and as necessary if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting units may be less than its carrying amount. There have been no events or circumstances during the three months ended June 30, 2015 that have required the Company to perform an interim assessment of goodwill.

[0001032975-15-000032:notes:68]
As of June 30, 2015 and March 31, 2015, all of the Company's goodwill is related to the Peripheral reporting unit. The following table summarizes the activity in the Company’s goodwill balance during the three months ended June 30, 2015 (in thousands):

[0001032975-15-000032:notes:69]
| As of March 31, 2015 |  | $ | 218,213 |  |
| Currency impact |  | 38 |  |
| As of June 30, 2015 |  | $ | 218,251 |  |

[0001032975-15-000032:notes:70]
Other Intangible Assets

[0001032975-15-000032:notes:71]
Amortization expense for other intangible assets was $0.7 million and $2.8 million for the three months ended June 30, 2015 and 2014, respectively. The Company expects that amortization expense for the remaining nine months of fiscal year 2016 will be $1.0 million, and annual amortization expense for fiscal year 2017 will be $0.2 million.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-15-000032:notes:72]
[same as prior period, unchanged from 0001628280-15-000267:notes:117]

[0001032975-15-000032:notes:73]
The Company is incorporated in Switzerland but operates in various countries with differing tax laws and rates. Further, a portion of the Company’s income before taxes and the provision for (benefit from) income taxes are generated outside of Switzerland.

[0001032975-15-000032:notes:74]
The income tax benefit for the three months ended June 30, 2015 was $1.3 million based on an effective income tax rate of (21.7)% of pre-tax income, compared to an income tax provision of $3.1 million based on an effective income tax rate of 13.6% of pre-tax income for the three months ended June 30, 2014. The change in the effective income tax rate for the three months ended June 30, 2015, compared to the three months ended June 30, 2014 is primarily due to the mix of income and losses in the various tax jurisdictions in which the Company operates. There was a discrete tax benefit of $2.2 million and $0.8 million in the three months ended June 30, 2015 and 2014, respectively, resulting from the preferential income tax rate reduction pursuant to the High and New Technology Enterprise Program in China.

[0001032975-15-000032:notes:75]
As of June 30 and March 31, 2015, the total amount of unrecognized tax benefits due to uncertain tax positions was $79.2 million and $79.0 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-15-000032:notes:76]
The Company had $74.8 million in non-current income taxes payable and $0.1 million in current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions as of June 30, 2015, compared to $72.1 million in non-current income taxes payable and $0.1 million in current income taxes payable as of March 31, 2015.

[0001032975-15-000032:notes:77]
The Company recognizes interest and penalties related to unrecognized tax positions in income tax expense. As of June 30 and March 31, 2015, the Company had $4.6 million and $4.9 million of accrued interest and penalties related to uncertain tax positions, respectively.

[0001032975-15-000032:notes:78]
Although the Company has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During fiscal year 2016, the Company will continue to review its tax positions and provide for or reverse unrecognized tax benefits as issues arise. During the next 12 months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. dollar as compared to other currencies. Excluding these factors, uncertain tax positions may decrease by as much as $17.0 million from the lapse of the statutes of limitations in various jurisdictions during the next 12 months.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001032975-15-000032:notes:79]
[same as prior period, unchanged from 0001628280-15-000267:notes:125]

[0001032975-15-000032:notes:80]
|  |  | June 30,2015 |  | March 31,2015 |
| Americas |  | $ | 48,353 |  |  | $ | 48,527 |  |
| EMEA |  | 3,435 |  |  | 3,584 |  |
| Asia Pacific |  | 49,881 |  |  | 39,482 |  |
|  |  | $ | 101,669 |  |  | $ | 91,593 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001032975-15-000032:notes:81]
Restructuring

[0001032975-15-000032:notes:82]
Restructuring Charges

[0001032975-15-000032:notes:83]
During the first quarter of fiscal year 2016, the Company implemented a restructuring plan to exit the OEM business, reorganize Lifesize to sharpen its focus on its Cloud-based offering, and streamline the Company's overall cost structure through product, overhead and infrastructure cost reductions with a targeted resource realignment. Restructuring charges incurred during the three months ended June 30, 2015 under this plan primarily consisted of severance and other ongoing and one-time termination benefits. Charges and other costs related to the workforce reduction and structure realignment are presented as restructuring charges in the Condensed Consolidated Statements of Operations. The Company expects to incur approximately $15 million to $20 million under this restructuring plan, and expects to substantially complete this restructuring within the next 12 months.

[0001032975-15-000032:notes:84]
The following tables summarize restructuring related activities during the three months ended June 30, 2015:

[0001032975-15-000032:notes:85]
|  |  | Restructuring |
|  |  | TerminationBenefits |  | Lease ExitCosts |  | Other |  | Total |
| Accrual balance at March 31, 2015 |  | $ | — |  |  | $ | 1,039 |  |  | $ | — |  |  | $ | 1,039 |  |
| Charges |  | 12,794 |  |  | — |  |  | 201 |  |  | 12,995 |  |
| Cash payments |  | (4,675 | ) |  | (796 | ) |  | (151 | ) |  | (5,622 | ) |
| Accrual balance at June 30, 2015 |  | $ | 8,119 |  |  | $ | 243 |  |  | $ | 50 |  |  | $ | 8,412 |  |


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001032975-15-000032:notes:86]
Net sales to unaffiliated customers by geographic region (based on the customers’ location) for the three months ended June 30, 2015 and 2014 were as follows (in thousands):

[0001032975-15-000032:notes:87]
|  |  | Three Months EndedJune 30, |
|  |  | 2015 |  | 2014 |
| Americas |  | $ | 226,687 |  |  | $ | 211,531 |  |
| EMEA |  | 127,366 |  |  | 153,700 |  |
| Asia Pacific |  | 116,267 |  |  | 116,972 |  |
| Total net sales |  | $ | 470,320 |  |  | $ | 482,203 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001032975-15-000032:notes:88]
[same as prior period, unchanged from 0001628280-15-000267:notes:129]

[0001032975-15-000032:notes:89]
|  |  | Accumulated Other Comprehensive Income (Loss) |
|  |  | CumulativeTranslationAdjustment (1) |  | DefinedBenefitPlan (1) |  | DeferredHedgingGains (Losses) |  | Total |
| March 31, 2015 |  | $ | (90,224 | ) |  | $ | (26,964 | ) |  | $ | 3,951 |  |  | $ | (113,237 | ) |
| Other comprehensive income (loss) |  | 2,618 |  |  | (714 | ) |  | (4,722 | ) |  | (2,818 | ) |
| June 30, 2015 |  | $ | (87,606 | ) |  | $ | (27,678 | ) |  | $ | (771 | ) |  | $ | (116,055 | ) |

[0001032975-15-000032:notes:90]
(1)        Tax effect was not significant as of June 30 or March 31, 2015.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001032975-15-000032:notes:91]
Net sales by product categories and sales channels, excluding intercompany transactions, for the three months ended June 30, 2015 and 2014 were as follows (in thousands):

[0001032975-15-000032:notes:92]
|  |  | Three Months EndedJune 30, |
|  |  | 2015 |  | 2014 |
| Peripherals: |  |  |  |  |  |  |
| Mobile Speakers |  | $ | 40,544 |  |  | $ | 28,830 |  |
| Gaming |  | 43,670 |  |  | 46,876 |  |
| Video Collaboration |  | 21,176 |  |  | 15,225 |  |
| Tablet & Other Accessories |  | 18,809 |  |  | 31,716 |  |
| Growth |  | 124,199 |  |  | 122,647 |  |
| Pointing Devices |  | 116,985 |  |  | 113,042 |  |
| Keyboards & Combos |  | 105,829 |  |  | 105,489 |  |
| Audio-PC & Wearables |  | 45,699 |  |  | 48,548 |  |
| PC Webcams |  | 21,681 |  |  | 20,463 |  |
| Home Control |  | 10,254 |  |  | 12,332 |  |
| Profit Maximization |  | 300,448 |  |  | 299,874 |  |
| Retail Strategic Sales |  | 424,647 |  |  | 422,521 |  |
| Non-Strategic |  | 741 |  |  | 1,293 |  |
| Retail |  | 425,388 |  |  | 423,814 |  |
| OEM |  | 22,298 |  |  | 32,632 |  |
|  |  | 447,686 |  |  | 456,446 |  |
| Video conferencing |  | 22,634 |  |  | 25,757 |  |
|  |  | $ | 470,320 |  |  | $ | 482,203 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001032975-15-000032:notes:93]
Net sales and operating income (loss) for the Company’s operating segments for the three months ended June 30, 2015 and 2014 were as follows (in thousands):

[0001032975-15-000032:notes:94]
|  |  | Three Months EndedJune 30, |
|  |  | 2015 |  | 2014 |
| Net sales: |  |  |  |  |  |  |
| Peripherals |  | $ | 447,686 |  |  | $ | 456,446 |  |
| Video conferencing |  | 22,634 |  |  | 25,757 |  |
|  |  | $ | 470,320 |  |  | $ | 482,203 |  |
| Segment operating income (loss): |  |  |  |  |  |  |
| Peripherals |  | $ | 31,847 |  |  | $ | 33,567 |  |
| Video conferencing |  | (4,401 | ) |  | (1,135 | ) |
|  |  | 27,446 |  |  | 32,432 |  |
| Other income (expense): |  |  |  |  |  |  |
| Restructuring charges, net |  | (12,995 | ) |  | — |  |
| Share-based compensation |  | (6,749 | ) |  | (6,938 | ) |
| Amortization of intangibles |  | (732 | ) |  | (2,782 | ) |
| Interest income, net |  | 264 |  |  | 258 |  |
| Other expense, net |  | (1,121 | ) |  | (198 | ) |
| Income before income taxes |  | $ | 6,113 |  |  | $ | 22,772 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-15-000032:notes:95]
[same as prior period, unchanged from 0001628280-15-000267:notes:135]

[0001032975-15-000032:notes:96]
The Company has two reporting segments, peripherals and video conferencing, based on product markets and internal organizational structure. The peripherals segment encompasses the design, manufacturing and marketing of peripherals for PCs, tablets and other digital platforms. The video conferencing segment offers scalable high-definition, or HD, video communication endpoints, HD video conferencing systems with integrated monitors, video bridges, a Cloud-based video conferencing solution and other infrastructure software and hardware to support large-scale video deployments and services to support these products. The Company’s reporting segments do not record revenue on sales between segments.

[0001032975-15-000032:notes:97]
Operating performance measures for the peripherals segment and the video conferencing segment are reported separately to the Company's Chief Executive Officer (“CEO”), who is considered to be the Company’s Chief Operating Decision Maker (“CODM”). The CEO periodically reviews information such as net sales and operating income (loss) for each operating segment to make business decisions. These operating performance measures do not include restructuring charges, net, share-based compensation expense and amortization of intangible assets. Restructuring charges, net, share-based compensation expense and amortization of intangible assets are presented in the following financial information by operating segment as “other income (expense), net.” Assets by operating segment are not presented since the Company does not present such data to the CODM.

[0001032975-15-000032:notes:98]
Restructuring charges for Peripherals and Video conferencing segments were $11.5 million and $1.5 million, respectively, for the three months ended June 30, 2015. There was no restructuring charge in the three months ended June 30, 2014.

[0001032975-15-000032:notes:99]
Certain products within the retail product families presented in prior period have been reclassified to conform to the current period's presentation.

[0001032975-15-000032:notes:100]
Sales are attributed to countries on the basis of the customers’ locations. The United States represented 40% and 37% of the Company’s total consolidated net sales for the three months ended June 30, 2015 and 2014, respectively. No other single country represented more than 10% of the Company’s total consolidated net sales during those periods. Revenues from sales to customers in Switzerland, the Company’s home domicile, represented 2% and 2% of the Company’s total consolidated net sales for the three months ended June 30, 2015 and 2014, respectively. One customer group of the Company’s peripheral operating segment represented 14% and 15% of sales for the three months ended June 30, 2015 and 2014, respectively.

[0001032975-15-000032:notes:101]
Long-lived assets in the United States and China were $48.2 million and $44.9 million as of June 30, 2015, respectively, and $48.3 million and $34.0 million at March 31, 2015, respectively. No other countries represented more than 10% of the Company’s total consolidated long-lived assets as of June 30 or March 31, 2015. Long-lived assets in Switzerland, the Company’s home domicile, were $1.4 million and $1.5 million at June 30 and March 31, 2015, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-15-000032:notes:102]
[same as prior period, unchanged from 0001628280-15-000267:notes:141]

[0001032975-15-000032:notes:103]
In March 2014, the Company’s Board of Directors approved the 2014 share buyback program, which authorizes the Company to use up to $250.0 million to purchase its own shares. The Company’s share buyback program is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market with consideration given to Logitech’s stock price, market conditions and other factors. During the three months ended June 30, 2015, 0.6 million shares were repurchased for $8.8 million. There were no share repurchases during the three months ended June 30, 2014.

[0001032975-15-000032:notes:104]
[same as prior period, unchanged from 0001628280-15-000267:notes:144]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-15-000032:notes:105]
[same as prior period, unchanged from 0001628280-15-000267:notes:145]
