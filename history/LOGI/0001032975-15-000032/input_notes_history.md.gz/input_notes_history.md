# LOGI note change history — 0001628280-15-000267 → 0001032975-15-000032


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-07-24):
[0001032975-15-000032:note_history:1]
Changes in the Company’s warranty liability for three months ended June 30, 2015 and 2014 were as follows (in thousands):
  (was, 2015-01-27, similarity 0.9053):
[0001628280-15-000267:note_history:1]
Changes in the Company’s warranty liability for the three and nine months ended December 31, 2014 and 2013 were as follows (in thousands):

- added (2015-07-24):
[0001032975-15-000032:note_history:2]
|  |  | Three Months EndedJune 30, |
|  |  | 2015 |  | 2014 |
| Beginning of the period |  | $ | 21,710 |  |  | $ | 24,380 |  |
| Provision |  | 2,142 |  |  | 2,206 |  |
| Settlements |  | (2,568 | ) |  | (3,166 | ) |
| End of the period |  | $ | 21,284 |  |  | $ | 23,420 |  |

- added (2015-07-24):
[0001032975-15-000032:note_history:3]
The Company is subject to an ongoing formal investigation by the Enforcement Division of the U.S. Securities and Exchange Commission ("SEC"), relating to certain issues including the accounting for Revue inventory valuation reserves that resulted in the restatement described in the Fiscal 2014 Form 10-K, revision to the Company’s consolidated financial statements concerning warranty accruals and amortization of intangible assets presented in the Company’s Amended Annual Report on Form10-K/A, filed on August 7, 2013, and the Company’s transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. The Company has entered into an agreement with the Enforcement Staff to extend the statute of limitations. The Company is cooperating with the investigation and, after discussions with the Enforcement Staff, the Company recently made an offer of settlement to resolve the matter, which is subject to approval by the SEC.  The proposed settlement would be entered into by the Company without admitting or denying the SEC’s findings and would resolve alleged violations of certain provisions of the Securities Exchange Act of 1934 and related rules, including the anti-fraud provisions.  Under the terms of the proposed settlement, the Company would pay $7.5 million in a civil penalty and agree not to commit or cause any violations of certain provisions of the Securities Exchange Act of 1934 and related rules. There is no assurance that the proposal will be approved by the SEC. In accordance with U.S. GAAP, the Company has made a corresponding accrual in its financial statements.

- changed (2015-07-24):
[0001032975-15-000032:note_history:4]
Logitech Europe S.A. guaranteed payments of third-party contract manufacturers’ purchase obligations. As of June 30, 2015, the maximum amount of this guarantee was $3.8 million, of which $1.6 million of guaranteed purchase obligations were outstanding.
  (was, 2015-01-27, similarity 0.9673):
[0001628280-15-000267:note_history:4]
Logitech Europe S.A.  guaranteed payments of a third-party contract manufacturer’s purchase obligations. As of December 31, 2014, the maximum amount of this guarantee was $3.5 million, of which $1.4 million of guaranteed purchase obligations were outstanding.

- changed (2015-07-24):
[0001032975-15-000032:note_history:5]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2015, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2015-01-27, similarity 0.9906):
[0001628280-15-000267:note_history:5]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2014, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

- changed (2015-07-24):
[0001032975-15-000032:note_history:6]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.
  (was, 2015-01-27, similarity 0.998):
[0001628280-15-000267:note_history:6]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.

- removed (2015-07-24):
[0001628280-15-000267:note_history:7]
|  |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Beginning of the period |  | $ | 22,204 |  |  | $ | 23,021 |  |  | $ | 24,380 |  |  | $ | 21,442 |  |
| Provision |  | 2,381 |  |  | 4,343 |  |  | 6,607 |  |  | 11,532 |  |
| Settlements |  | (2,493 | ) |  | (3,842 | ) |  | (8,895 | ) |  | (11,779 | ) |
| Adjustment (1) |  | — |  |  | — |  |  | — |  |  | 2,327 |  |
| End of the period |  | $ | 22,092 |  |  | $ | 23,522 |  |  | $ | 22,092 |  |  | $ | 23,522 |  |

- removed (2015-07-24):
[0001628280-15-000267:note_history:8]
(1)   During the nine month period December 31, 2013, the warranty liability allocated to the Company’s - Remotes product category was reclassified from liabilities held for sale.

- removed (2015-07-24):
[0001628280-15-000267:note_history:9]
Purchase Commitments

- removed (2015-07-24):
[0001628280-15-000267:note_history:10]
Commitments for inventory purchases are made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers and are expected to be fulfilled by December 31, 2014. Fixed purchase commitments for capital expenditures primarily related to commitments for computer hardware and leasehold improvements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the Company the option to reschedule and adjust its requirements based on the business needs prior to delivery of goods or performance of services.

- removed (2015-07-24):
[0001628280-15-000267:note_history:11]
The Company is subject to an ongoing formal investigation by the SEC, relating to certain issues including the accounting for Revue inventory valuation reserves that resulted in the restatement described in the Fiscal 2014 Form 10-K, revision to the Company’s financial statements concerning warranty accruals and amortization of intangible assets presented in the Company’s Form 10-K/A, filed on August 7, 2013, and the Company’s transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. The Company is cooperating with the SEC in its ongoing investigation. The Company has entered into an agreement with the SEC to extend the statute of limitations. The Company cannot predict the outcome of the investigation at this time and any potential fines or penalties, if any, that may arise from the investigation are currently not estimable.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-07-24):
[0001032975-15-000032:note_history:12]
The condensed consolidated interim financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (“GAAP”) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. They should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2015, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (“SEC”) on June 5, 2015.  In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal, recurring adjustments, necessary for a fair statement of the results for the periods presented. Operating results for the three months ended June 30, 2015 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2016, or any future periods.
  (was, 2015-01-27, similarity 0.627):
[0001628280-15-000267:note_history:12]
The consolidated interim financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (“GAAP”) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. They should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2014, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (“SEC”) on November 13, 2014.  In the opinion of management, these consolidated financial statements include all adjustments, consisting of normal recurring adjustments, necessary for a fair statement of the results for the periods presented. Operating results for the three and nine months ended December 31, 2014 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2015, or any future periods.

- changed (2015-07-24):
[0001032975-15-000032:note_history:13]
The Company’s fiscal year ends on March 31. Interim quarter ends on last Friday of each quarter.  For purposes of presentation, the Company has indicated its quarterly periods as ending on the quarter end.
  (was, 2015-01-27, similarity 0.8428):
[0001628280-15-000267:note_history:13]
The Company’s fiscal year ends on March 31. Interim quarters are thirteen week periods, each ending on last Friday of the quarters.  For purposes of presentation, the Company has indicated its quarterly periods as ending on the quarter end.

- changed (2015-07-24):
[0001032975-15-000032:note_history:14]
There have been no substantial changes in the Company’s significant accounting policies during the three months ended June 30, 2015 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2015.
  (was, 2015-01-27, similarity 0.9045):
[0001628280-15-000267:note_history:14]
There have been no substantial changes in the Company’s significant accounting policies during the nine months ended December 31, 2014 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2014.

- added (2015-07-24):
[0001032975-15-000032:note_history:15]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect reported amounts of assets, liabilities, net sales and expenses, and the disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements. Examples of significant estimates and assumptions made by management involve the fair value of goodwill, warranty liabilities, accruals for discretionary customer programs, sales return reserves, allowance for doubtful accounts, inventory valuation, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ from those estimates.

- added (2015-07-24):
[0001032975-15-000032:note_history:16]
In May 2014, the FASB issued Accounting Standards Update No. 2014-9, "Revenue from Contracts with Customers (Topic 606)," ("ASU 2014-9"). ASU 2014-9 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. Under the new model, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In addition, the new standard requires that reporting companies disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. As currently issued, the new standard is effective beginning in the first quarter of fiscal year 2019; early adoption is prohibited. The new standard is required to be applied retrospectively to each prior reporting period presented or retrospectively with the cumulative effect of initially applying it recognized at the date of initial application. The Company has not yet selected a transition method nor has it determined the impact of the new standard on its condensed consolidated financial statements.

- removed (2015-07-24):
[0001628280-15-000267:note_history:17]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect reported amounts of assets, liabilities, net sales and expenses, and the disclosure of contingent assets and liabilities. Examples of significant estimates and assumptions made by management involve the fair value of goodwill, accruals for customer programs, inventory valuation, valuation allowances for deferred tax assets and warranty accruals. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ from those estimates.

- removed (2015-07-24):
[0001628280-15-000267:note_history:18]
In May 2014, the FASB issued Accounting Standards Update No. 2014-09, “Revenue from Contracts with Customers (Topic 606),” (“ASU 2014-09”). ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. This new revenue recognition model provides a five-step analysis in determining when and how revenue is recognized. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The new standard will be effective for the Company beginning April 1, 2017.  Early application is prohibited.  The Company is currently evaluating the impact that adopting this new guidance will have on its consolidated financial statements.

- removed (2015-07-24):
[0001628280-15-000267:note_history:19]
In November 2014, the FASB issued Accounting Standards Update No. 2014-17, "Business Combinations (Topic 805): Pushdown Accounting (a consensus of the FASB Emerging Issues Task Force)" ("ASU 2014-17"). ASU 2014-17 provides an acquired entity with an option to apply pushdown accounting in its separate financial statements upon occurrence of an event in which an acquirer obtains control of the acquired entity. An acquired entity may elect the option to apply pushdown accounting in the reporting period in which the change-in-control event occurs. The new standard is effective on November 18, 2014.  Early application is prohibited.  After the effective date, an acquired entity can make an election to apply the guidance to

- removed (2015-07-24):
[0001628280-15-000267:note_history:20]
future change-in-control events or to its most recent change-in-control event. However, if the financial statements for the period in which the most recent change-in-control event occurred already have been issued or made available to be issued, the application of this guidance would be a change in accounting principle. The Company has adopted this new guidance and there's no impact on its consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-07-24):
[0001032975-15-000032:note_history:21]
The Company had several uncommitted, unsecured bank lines of credit aggregating $34.6 million as of June 30, 2015. There are no financial covenants under these lines of credit with which the Company must comply. As of June 30, 2015, the Company had outstanding bank guarantees of $14.3 million under these lines of credit. There was no borrowing outstanding under the line of credit as of June 30, 2015 or March 31, 2015.
  (was, 2015-01-27, similarity 0.8409):
[0001628280-15-000267:note_history:21]
The Company had several uncommitted, unsecured bank lines of credit aggregating $38.7 million as of December 31, 2014. There are no financial covenants under these lines of credit with which the Company must comply. As of December 31, 2014, the Company had outstanding bank guarantees of $7.5 million under these lines of credit.
