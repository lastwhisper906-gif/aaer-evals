# LOGI MD&A — 0001032975-18-000048


## mdna

[0001032975-18-000048:mdna:1]
[same as prior period, unchanged from 0001032975-18-000037:mdna:1]

[0001032975-18-000048:mdna:2]
[same as prior period, unchanged from 0001032975-18-000037:mdna:2]

[0001032975-18-000048:mdna:3]
[same as prior period, unchanged from 0001032975-18-000037:mdna:3]

[0001032975-18-000048:mdna:4]
Logitech is a world leader in designing, manufacturing and marketing products that help connect people to digital and cloud experiences. More than 35 years ago, Logitech created products to improve experiences around the personal PC platform, and today it is a multi-brand, multi-category company designing products that enable better experiences consuming, sharing and creating any digital content such as music, gaming, video and computing, whether it is on a computer, mobile device or in the cloud. Logitech's brands include Logitech, Ultimate Ears, Jaybird, Blue Microphones, Logitech G and ASTRO Gaming.

[0001032975-18-000048:mdna:5]
Our products participate in five large markets that all have growth opportunities: Gaming, Video Collaboration, Smart Home, Music, and Creativity & Productivity. We sell our products to a broad network of domestic and international customers, including direct sales to retailers and e-tailers, and indirect sales through distributors. Our worldwide channel network includes consumer electronics distributors, retailers, mass merchandisers, specialty stores, computer and telecommunications stores, value-added resellers and online merchants.

[0001032975-18-000048:mdna:6]
[same as prior period, unchanged from 0001032975-18-000037:mdna:6]

[0001032975-18-000048:mdna:7]
On August 21, 2018 (the "Acquisition Date"), we acquired all equity interests in Blue Microphones Holding Corporation ("Blue Microphones") for a total consideration of $134.9 million in cash (the "Blue Microphones Acquisition"), which includes a working capital adjustment and repayment of a debt on behalf of Blue Microphones. Blue Microphones is a leading audio manufacturer that designs and produces microphones, headphones, recording tools, and accessories for audio professionals, musicians and consumers. The Blue Microphones Acquisition is consistent with Logitech's merger and acquisition strategy and will supplement the Company's portfolio opportunities. For the three months ended September 30, 2018, Blue Microphones contributed one percentage point of the net sales growth rate.

[0001032975-18-000048:mdna:8]
[same as prior period, unchanged from 0001032975-18-000037:mdna:7]

[0001032975-18-000048:mdna:9]
Our net sales for the three and six months ended September 30, 2018 increased 9% and 12%, respectively, compared to the three and six months ended September 30, 2017, mainly due to stronger net sales in the Americas and Asia Pacific.

[0001032975-18-000048:mdna:10]
Our net sales for the three months ended September 30, 2018 increased 8% and 24% in the Americas and Asia Pacific, respectively, compared to the same period of the prior fiscal year. Our net sales for the three months ended September 30, 2018 in EMEA remained flat, compared to the same period of the prior fiscal year. Our net sales for the six months ended September 30, 2018 increased 10%, 3% and 26% in the Americas, EMEA and Asia Pacific, respectively, compared to the same period of the prior fiscal year.

[0001032975-18-000048:mdna:11]
[same as prior period, unchanged from 0001032975-18-000037:mdna:9]

[0001032975-18-000048:mdna:12]
Our gross margin for the three months ended September 30, 2018 increased 110 basis points to 37.1% from 36.0% for the three months ended September 30, 2017. Our gross margin benefited from a one-time tariff duty refund of approximately $7.1 million, favorable exchange rates, cost reduction efforts and product mix, partially offset by unfavorable impact from adoption of ASC 606, increase in spending in Customer Programs to support our growth, as well as U.S. tariffs implemented in July 2018 for certain of our products imported into the United States.

[0001032975-18-000048:mdna:13]
Our gross margin for the six months ended September 30, 2018 increased 60 basis points to 36.9% from 36.3% for the six months ended September 30, 2017 as a result of a one-time tariff duty refund of approximately $7.1 million, and a one-time benefit from a legal settlement with our prior distribution center supplier in the Americas, as well as favorable exchange rates and cost reduction efforts. Those benefits were partially offset by unfavorable impact from adoption of ASC 606 and increase in spending in Customer Programs.

[0001032975-18-000048:mdna:14]
We have various initiatives being implemented to mitigate the impact of recently implemented and announced U.S. tariffs, such as product reclassifications, tactical inventory pull-ins, supply chain or production shifts, and potential pricing adjustments. As some of these mitigating initiatives take time to implement, there could be an adverse impact to our gross margin in the future periods as we adjust to tariffs and other trade restrictions.

[0001032975-18-000048:mdna:15]
Operating expenses for the three months ended September 30, 2018 were $191.0 million, or 27.6% of net sales, compared to $168.8 million, or 26.7% of net sales, in the same period of the prior fiscal year. Operating expenses for the six months ended September 30, 2018 were $382.5 million, or 29.4% of net sales, compared to $331.0 million, or 28.5% of net sales, in the same period of the prior fiscal year. The increase in operating expenses for the three months ended September 30, 2018 was primarily driven by $8.8 million higher advertising and

[0001032975-18-000048:mdna:16]
marketing expenses to support our new product introductions, $5.2 million higher personnel-related cost due to additional headcount from business acquisition and increased performance based variable compensation, and $3.0 million from the prior year's credit for change in fair value of contingent consideration from an acquisition. The increase in operating expenses for the six months ended September 30, 2018 was primarily driven by $32.2 million higher personnel-related cost due to restructuring charges in the current period, increased performance based variable compensation and additional headcount from business acquisitions, $9.6 million higher advertising and marketing expenses to support our new product introduction,and $4.9 million from the prior year's credit for change in fair value of contingent consideration from an acquisition.

[0001032975-18-000048:mdna:17]
Net income for the three and six months ended September 30, 2018 was $64.2 million and $102.6 million, compared to $56.4 million and $93.4 million for the three and six months ended September 30, 2017.

[0001032975-18-000048:mdna:18]
[same as prior period, unchanged from 0001032975-18-000037:mdna:13]

[0001032975-18-000048:mdna:19]
Our strategy focuses on five large multi-category markets, including Gaming, Video Collaboration, Music, Smart Home and Creativity & Productivity. We see opportunities to deliver growth in all these markets.

[0001032975-18-000048:mdna:20]
[same as prior period, unchanged from 0001032975-18-000037:mdna:15]

[0001032975-18-000048:mdna:21]
[same as prior period, unchanged from 0001032975-18-000037:mdna:16]

[0001032975-18-000048:mdna:22]
Gaming:  The PC gaming and console gaming platform continues to show strong growth as online gaming, multi-platform experiences, and eSports gain greater popularity and gaming content becomes increasingly more demanding. We believe Logitech is well positioned to benefit from the PC gaming market growth. With ASTRO Gaming, we are also strengthening our portfolio in adjacent categories, such as the console gaming market.

[0001032975-18-000048:mdna:23]
[same as prior period, unchanged from 0001032975-18-000037:mdna:20]

[0001032975-18-000048:mdna:24]
Music:  The music market grew during fiscal year 2018, driven by growing consumption of music through mobile devices such as smartphones and tablets. The integration of personal voice assistants has become increasingly competitive in the speaker categories and the market for third-party, voice-enabled speakers has not yet gained traction. Moreover, the market for mobile speakers appears to be maturing with slower growth. While we continue to introduce new products for improved experiences, we're adjusting our investments to match the slower market growth outlook. With Blue Microphones, we are also strengthening our portfolio in adjacent categories, such as the microphones market.

[0001032975-18-000048:mdna:25]
Smart Home:  This market grew in fiscal year 2018 due to the integration of Amazon Alexa and Google Assistant voice capabilities into our Logitech Harmony Hub that enables voice control of the living room entertainment experience when used with an Amazon Echo or Google Home device. Through Harmony, Alexa can turn on/off and control a TV and AV system. While the market so far in fiscal year 2019 has slowed due to more difficult comparisons, we continue to see various long-term opportunities in the broader smart home market. Accordingly, we will be prudent in how we deploy our resources in the near term.

[0001032975-18-000048:mdna:26]
[same as prior period, unchanged from 0001032975-18-000037:mdna:22]

[0001032975-18-000048:mdna:27]
[same as prior period, unchanged from 0001032975-18-000037:mdna:23]

[0001032975-18-000048:mdna:28]
We have historically experienced higher net sales in our third fiscal quarter ending December 31, compared to other fiscal quarters in our fiscal year, due in part to seasonal holiday demand. Additionally, new product

[0001032975-18-000048:mdna:29]
introductions and business acquisitions can significantly impact net sales, product costs and operating expenses. Product introductions can also impact our net sales to our distribution channels as these channels are filled with new product inventory following a product introduction, and often channel inventory of an earlier model product declines as the next related major product launch approaches. Net sales can also be affected when consumers and distributors anticipate a product introduction or changes in business circumstances. However, neither historical seasonal patterns nor historical patterns of product introductions should be considered reliable indicators of our future pattern of product introductions, future net sales or financial performance.

[0001032975-18-000048:mdna:30]
[same as prior period, unchanged from 0001032975-18-000037:mdna:25]

[0001032975-18-000048:mdna:31]
The preparation of financial statements and related disclosures in conformity with GAAP requires us to make judgments, estimates and assumptions that affect reported amounts of assets, liabilities, goodwill and intangible assets from business acquisitions, contingent consideration from business acquisitions, and net sales and expenses.

[0001032975-18-000048:mdna:32]
[same as prior period, unchanged from 0001032975-18-000037:mdna:27]

[0001032975-18-000048:mdna:33]
[same as prior period, unchanged from 0001032975-18-000037:mdna:28]

[0001032975-18-000048:mdna:34]
Other than the recent accounting pronouncement adoptions discussed below and Summary of Significant Accounting Policies discussed in Note 1 to the condensed consolidated financial statements, there have been no substantial changes in the Company’s significant accounting policies during the six months ended September 30, 2018, compared with the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended March 31, 2018.

[0001032975-18-000048:mdna:35]
[same as prior period, unchanged from 0001032975-18-000037:mdna:31]

[0001032975-18-000048:mdna:36]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers" ("ASU 2014-09" or “Topic 606”) which supersedes the revenue recognition requirements under ASC 605 (“Topic 605”), Revenue Recognition. ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes existing revenue recognition guidance, including industry-specific guidance. Under the new guidance, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The new standard requires reporting companies to disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. On April 1, 2018, we adopted the new standard and all related amendments using the modified retrospective method applied to those contracts which were not completed as of April 1, 2018. Results for reporting periods beginning after April 1, 2018 are presented under Topic 606, while prior period amounts are not adjusted and continue to be reported in accordance with historic accounting standards under Topic 605.

[0001032975-18-000048:mdna:37]
Refer to Note 1 to the condensed consolidated financial statements for further details of the impact of adoption of Topic 606.

[0001032975-18-000048:mdna:38]
In January 2016, the FASB issued ASU 2016-01, "Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10)" ("ASU 2016-01"). ASU 2016-01 requires entities to measure equity instruments at fair value and recognize any changes in fair value within the statement of operations. We adopted ASU 2016-01 effective April 1, 2018 on a prospective basis for our privately held strategic equity securities without readily determinable fair values. We elected the measurement alternative to record these investments at cost and to adjust for impairments and observable price changes with a same or similar security from the same issuer within the statement of operations. The adoption of ASU 2016-01 did not have a material impact on our condensed consolidated financial statements.

[0001032975-18-000048:mdna:39]
In October 2016, the FASB issued ASU 2016-16, "Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory" ("ASU 2016-16"), which eliminates the deferral of income tax effects of intra-entity asset transfers until the transferred asset is sold to an unrelated party or recovered through use. However, this standard does not apply to intra-entity transfer of inventory. We adopted this standard effective April 1, 2018 on a modified retrospective basis, and the adoption of ASU 2016-16 did not have a material impact on our condensed consolidated financial statements.

[0001032975-18-000048:mdna:40]
In December 2016, the FASB issued ASU 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash" ("ASU 2016-18"), which requires that a statement of cash flows explains the change during the period in the total of cash, cash equivalents and amounts generally described as restricted cash or restricted cash equivalents. We adopted this standard effective April 1, 2018 utilizing the retrospective transition method to each period presented, and the adoption of ASU 2016-18 did not have an impact on our condensed consolidated financial statements as we did not have restricted cash for either periods presented.

[0001032975-18-000048:mdna:41]
In January 2017, the FASB issued ASU 2017-01, "Business Combination (Topic 805): Clarifying the Definition of a Business" ("ASU 2017-01"), which changes the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. We adopted this standard effective April 1, 2018, and the adoption of ASU 2017-01 did not have a material impact on our condensed consolidated financial statements.

[0001032975-18-000048:mdna:42]
In March 2017, the FASB issued ASU 2017-07, "Compensation-Retirement Benefit (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost" ("ASU 2017-07"), which requires that the Company disaggregate the service cost component from the other components of net benefit cost, and also provides guidance on how to present the service cost component and the other components of net benefit cost in the income statement and allow only the service cost component of net benefit cost to be eligible for capitalization. We adopted this standard effective April 1, 2018 using a retrospective adoption method. Other than the revised statement of operations presentation for the periods in the current year, the adoption of ASU 2017-07 did not have an impact on our condensed consolidated financial statements. The impact to the comparative period was immaterial and therefore prior period statements of operations was not revised.

[0001032975-18-000048:mdna:43]
In August 2017, the FASB issued ASU 2017-12, "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" ("ASU 2017-12"), which improves the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements and simplifies the application of the hedge accounting guidance. We adopted this standard effective April 1, 2018, and the adoption of ASU 2017-12 did not have a material impact on our condensed consolidated financial statements. In accordance with ASU 2017-12, we have started presenting the earnings impact from forward points in cost of goods sold line item, which is used to present the earnings impact of the hedged item.

[0001032975-18-000048:mdna:44]
[same as prior period, unchanged from 0001032975-18-000037:mdna:41]

[0001032975-18-000048:mdna:45]
[same as prior period, unchanged from 0001032975-18-000037:mdna:42]

[0001032975-18-000048:mdna:46]
[same as prior period, unchanged from 0001032975-18-000037:mdna:43]

[0001032975-18-000048:mdna:47]
[same as prior period, unchanged from 0001032975-18-000037:mdna:44]

[0001032975-18-000048:mdna:48]
[same as prior period, unchanged from 0001032975-18-000037:mdna:45]

[0001032975-18-000048:mdna:49]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Canadian Dollar, Taiwan New Dollar, British Pound and Australian Dollar. During the three months ended September 30, 2018, 51% of our net sales were denominated in currencies other than the U.S. Dollar.

[0001032975-18-000048:mdna:50]
[same as prior period, unchanged from 0001032975-18-000037:mdna:47]

[0001032975-18-000048:mdna:51]
[same as prior period, unchanged from 0001032975-18-000037:mdna:48]

[0001032975-18-000048:mdna:52]
Our net sales in the three and six months ended September 30, 2018 increased 9% and 12%, respectively, compared to the same periods of the prior fiscal year. Sales increased in the Americas and Asia Pacific during the three and six months ended September 30, 2018. If currency exchange rates had been constant in the three and six months ended September 30, 2018 and 2017, our constant dollar sales growth rates would have been 10% and 11%, respectively. We grew double digits in our Gaming, Video Collaboration, Keyboards & Combos, and Tablets and Other Accessories. Sales for Mobile Speaker and Smart Home declined across the regions. The adoption of Topic 606 lowered the net sales for the three or six months ended September 30, 2018 by $4.9 million and $5.1 million, respectively.

[0001032975-18-000048:mdna:53]
[same as prior period, unchanged from 0001032975-18-000037:mdna:50]

[0001032975-18-000048:mdna:54]
The following table presents the change in net sales by region for the three and six months ended September 30, 2018, compared with the three and six months ended September 30, 2017:

[0001032975-18-000048:mdna:55]
|  |  | Sales Growth Rate |  | Constant DollarSales Growth Rate |
|  |  | Three Months EndedSeptember 30, 2018 |  | Six Months EndedSeptember 30, 2018 |  | Three Months EndedSeptember 30, 2018 | Six Months EndedSeptember 30, 2018 |
| Americas |  | 8 | % |  | 10 | % |  | 9 | % | 11 | % |
| EMEA |  | — | % |  | 3 | % |  | 1 | % | 1 | % |
| Asia Pacific |  | 24 | % |  | 26 | % |  | 26 | % | 25 | % |

[0001032975-18-000048:mdna:56]
[same as prior period, unchanged from 0001032975-18-000037:mdna:53]

[0001032975-18-000048:mdna:57]
The increases in net sales in our Americas region for the three-month period presented above was primarily driven by growth in Gaming, Keyboards and Combos, Video Collaboration and Pointing Devices, partially offset by a decline in sales for Mobile Speakers and Smart Home. The increases in net sales in our Americas region for the six-month period presented above was primarily driven by the same categories. In addition, Tablets and Other Accessories and PC Webcams also contributed to the increase for the six-month period.

[0001032975-18-000048:mdna:58]
[same as prior period, unchanged from 0001032975-18-000037:mdna:55]

[0001032975-18-000048:mdna:59]
The net sales in our EMEA region remained flat for the three-month period presented above. The net sales in our EMEA region increased 3% for the six-month period presented above, which was primarily driven by growth in Gaming, Tablets and Other Accessories and Video Collaboration, partially offset by a decline in sales for Mobile Speakers and Smart Home.

[0001032975-18-000048:mdna:60]
[same as prior period, unchanged from 0001032975-18-000037:mdna:57]

[0001032975-18-000048:mdna:61]
The growth in our Asia Pacific region during both periods presented above were primarily driven by growth in Gaming, Keyboards and Combos, Video Collaboration, Pointing Devices and Mobile Speakers.

[0001032975-18-000048:mdna:62]
[same as prior period, unchanged from 0001032975-18-000037:mdna:59]

[0001032975-18-000048:mdna:63]
Net sales by product category for the three and six months ended September 30, 2018 and 2017 were as follows (Dollars in thousands):

[0001032975-18-000048:mdna:64]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Pointing Devices |  | $ | 128,337 |  |  | $ | 123,643 |  |  | 4% |  | $ | 256,127 |  |  | $ | 245,717 |  |  | 4% |
| Keyboards & Combos |  | 131,872 |  |  | 119,200 |  |  | 11 |  | 260,094 |  |  | 235,313 |  |  | 11 |
| PC Webcams |  | 28,221 |  |  | 27,466 |  |  | 3 |  | 57,895 |  |  | 53,091 |  |  | 9 |
| Tablet & Other Accessories |  | 36,710 |  |  | 30,784 |  |  | 19 |  | 69,146 |  |  | 54,002 |  |  | 28 |
| Video Collaboration |  | 57,176 |  |  | 46,139 |  |  | 24 |  | 115,968 |  |  | 81,756 |  |  | 42 |
| Mobile Speakers |  | 77,100 |  |  | 90,548 |  |  | (15) |  | 111,427 |  |  | 153,466 |  |  | (27) |
| Audio & Wearables |  | 61,560 |  |  | 62,445 |  |  | (1) |  | 113,714 |  |  | 112,647 |  |  | 1 |
| Gaming |  | 160,792 |  |  | 113,722 |  |  | 41 |  | 296,818 |  |  | 191,430 |  |  | 55 |
| Smart Home |  | 9,241 |  |  | 18,323 |  |  | (50) |  | 18,252 |  |  | 34,789 |  |  | (48) |
| Other (1) |  | 137 |  |  | 200 |  |  | (32) |  | 185 |  |  | 205 |  |  | (10) |
| Total net sales |  | $ | 691,146 |  |  | $ | 632,470 |  |  | 9 |  | $ | 1,299,626 |  |  | $ | 1,162,416 |  |  | 12 |

[0001032975-18-000048:mdna:65]
[same as prior period, unchanged from 0001032975-18-000037:mdna:62]

[0001032975-18-000048:mdna:66]
[same as prior period, unchanged from 0001032975-18-000037:mdna:63]

[0001032975-18-000048:mdna:67]
[same as prior period, unchanged from 0001032975-18-000037:mdna:64]

[0001032975-18-000048:mdna:68]
[same as prior period, unchanged from 0001032975-18-000037:mdna:65]

[0001032975-18-000048:mdna:69]
[same as prior period, unchanged from 0001032975-18-000037:mdna:66]

[0001032975-18-000048:mdna:70]
Net sales of Pointing Devices increased 4% in the three and six months ended September 30, 2018, respectively, compared to the same periods of the prior fiscal year. The increases for both periods were primarily driven by an increase in sales for cordless mice, such as M280 Wireless Mouse, M510 Wireless Mouse, and MX Master 2S Wireless Mouse. MX Vertical Wireless Mouse introduced in the second quarter of fiscal year 2018 also contributed to the sales increase for both periods.

[0001032975-18-000048:mdna:71]
[same as prior period, unchanged from 0001032975-18-000037:mdna:68]

[0001032975-18-000048:mdna:72]
[same as prior period, unchanged from 0001032975-18-000037:mdna:69]

[0001032975-18-000048:mdna:73]
Net sales of Keyboards & Combos increased 11% in the three and six months ended September 30, 2018, respectively, compared to the same periods of the prior fiscal year. The increases in both periods were primarily driven by an increase in sales of cordless keyboards and combos, mainly from the introductions of MK540 Wireless Keyboard Mouse Combo in the fourth quarter of fiscal year 2018 and MK545 Wireless Keyboard Mouse Combo in the first quarter of fiscal year 2019, and increases in sales of MK270 Wireless Combo and MK235 Wireless Combo.

[0001032975-18-000048:mdna:74]
[same as prior period, unchanged from 0001032975-18-000037:mdna:71]

[0001032975-18-000048:mdna:75]
[same as prior period, unchanged from 0001032975-18-000037:mdna:72]

[0001032975-18-000048:mdna:76]
PC Webcams net sales increased 3% and 9% in the three and six months ended September 30, 2018, respectively, compared to the same periods of the prior fiscal year. The increases in both periods were primarily driven by increases in sales for our HD Pro Webcam C920 and 1080P Pro Stream Webcam.

[0001032975-18-000048:mdna:77]
[same as prior period, unchanged from 0001032975-18-000037:mdna:74]

[0001032975-18-000048:mdna:78]
[same as prior period, unchanged from 0001032975-18-000037:mdna:75]

[0001032975-18-000048:mdna:79]
Net sales of Tablet & Other Accessories products increased 19% and 28% in the three and six months ended September 30, 2018, respectively, compared to the same periods of the prior fiscal year. The increases for both periods were primarily driven by the introductions of our education-based Rugged Combo 2 in the first quarter of fiscal year 2019, our Slim Folio keyboard cases in the second quarter of fiscal year 2019, Slim Combo keyboard cases in the third quarter of fiscal year 2018, and Crayon (a digital pencil) and POWERED (a wireless charging dock for iPhone) in the second quarter of fiscal year 2019.

[0001032975-18-000048:mdna:80]
[same as prior period, unchanged from 0001032975-18-000037:mdna:77]

[0001032975-18-000048:mdna:81]
[same as prior period, unchanged from 0001032975-18-000037:mdna:78]

[0001032975-18-000048:mdna:82]
Our Video Collaboration category primarily includes products which combine audio and video and other products that can connect any-sized user groups.

[0001032975-18-000048:mdna:83]
Net sales of Video Collaboration products increased 24% and 42% in the three and six months ended September 30, 2018, respectively, compared to the same periods of the prior fiscal year. The increases for both periods were primarily driven by an increase in sales for our Meetup video conference camera, PTZ Pro 2 group camera, and high-end business webcams.

[0001032975-18-000048:mdna:84]
[same as prior period, unchanged from 0001032975-18-000037:mdna:81]

[0001032975-18-000048:mdna:85]
[same as prior period, unchanged from 0001032975-18-000037:mdna:82]

[0001032975-18-000048:mdna:86]
[same as prior period, unchanged from 0001032975-18-000037:mdna:83]

[0001032975-18-000048:mdna:87]
Net sales of Mobile Speakers decreased 15% and 27% for the three and six months ended September 30, 2018, respectively, compared to the same periods of the prior fiscal year. The decreases for both periods were primarily due to a decline in sales for our Ultimate Ears Megaboom, Boom 2, and Wonderboom mobile speakers. The decreases were partially offset by sales from the introduction of our Ultimate Ears Megaboom 3 and Boom 3 mobile speakers in the second quarter of fiscal year 2019.

[0001032975-18-000048:mdna:88]
[same as prior period, unchanged from 0001032975-18-000037:mdna:85]

[0001032975-18-000048:mdna:89]
Our Audio & Wearables category comprises PC speakers, PC headsets, in-ear headphones, premium wireless audio wearables and studio-quality microphones for professionals and consumers.

[0001032975-18-000048:mdna:90]
Audio & Wearables net sales decreased 1% for the three months ended and increased 1% for the six months ended September 30, 2018, respectively, compared to the same periods of the prior fiscal year. The decrease for the three-month period was primarily due to a decrease in sales of PC speakers and Jaybird products, partially offset by the sales from Blue Microphones products as a result of our business acquisition (refer to Note 2 to the condensed consolidated financial statements). The increase for the six-month period was driven by a sales increase for our corded headsets, Revol Custom Fit Earbuds, and sales from Blue Microphones products, partially offset by a decrease in sales of PC speakers and Jaybird products.

[0001032975-18-000048:mdna:91]
[same as prior period, unchanged from 0001032975-18-000037:mdna:88]

[0001032975-18-000048:mdna:92]
[same as prior period, unchanged from 0001032975-18-000037:mdna:89]

[0001032975-18-000048:mdna:93]
[same as prior period, unchanged from 0001032975-18-000037:mdna:90]

[0001032975-18-000048:mdna:94]
Gaming net sales increased 41% and 55% for the three and six months ended September 30, 2018, respectively, compared to the same periods of the prior fiscal year. The significant increases for both periods were primarily driven by the strong performance of the ASTRO console gaming headsets - which benefited from the growing gaming market, growth in eSports, expansions in new channels and regions, and expansion in product portfolios - as well as the continued success for our gaming mice and PC gaming headsets. The increases for the six-month period, and to a lesser extent for the three-month period, were also driven by the fact that the acquisition

[0001032975-18-000048:mdna:95]
of ASTRO closed on August 11, 2017, in the middle of our fiscal year 2018 second quarter, resulting in a partial comparative period impact.

[0001032975-18-000048:mdna:96]
[same as prior period, unchanged from 0001032975-18-000037:mdna:92]

[0001032975-18-000048:mdna:97]
[same as prior period, unchanged from 0001032975-18-000037:mdna:93]

[0001032975-18-000048:mdna:98]
[same as prior period, unchanged from 0001032975-18-000037:mdna:94]

[0001032975-18-000048:mdna:99]
Smart Home net sales decreased 50% and 48% during the three and six months ended September 30, 2018, respectively, compared to the same periods of the prior fiscal year. The decreases for both periods were primarily due to a decline in sales for our Harmony remotes and home video products.

[0001032975-18-000048:mdna:100]
[same as prior period, unchanged from 0001032975-18-000037:mdna:96]

[0001032975-18-000048:mdna:101]
Gross profit for the three and six months ended September 30, 2018 and 2017 was as follows (Dollars in thousands):

[0001032975-18-000048:mdna:102]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Net sales |  | $ | 691,146 |  |  | $ | 632,470 |  |  | 9 | % |  | $ | 1,299,626 |  |  | $ | 1,162,416 |  |  | 12 | % |
| Gross profit |  | $ | 256,117 |  |  | $ | 227,737 |  |  | 12 |  |  | $ | 480,054 |  |  | $ | 421,405 |  |  | 14 |  |
| Gross margin |  | 37.1 | % |  | 36.0 | % |  |  |  | 36.9 | % |  | 36.3 | % |  |  |  |

[0001032975-18-000048:mdna:103]
[same as prior period, unchanged from 0001032975-18-000037:mdna:99]

[0001032975-18-000048:mdna:104]
[same as prior period, unchanged from 0001032975-18-000037:mdna:101]

[0001032975-18-000048:mdna:105]
Operating expenses for the three and six months ended September 30, 2018 and 2017 were as follows (Dollars in thousands):

[0001032975-18-000048:mdna:106]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Marketing and selling |  | $ | 121,801 |  |  | $ | 107,386 |  |  | $ | 236,385 |  |  | $ | 209,764 |  |
| % of net sales |  | 17.6 | % |  | 17.0 | % |  | 18.2 | % |  | 18.0 | % |
| Research and development |  | 39,542 |  |  | 36,647 |  |  | 78,529 |  |  | 71,746 |  |
| % of net sales |  | 5.7 | % |  | 5.8 | % |  | 6.0 | % |  | 6.2 | % |
| General and administrative |  | 25,206 |  |  | 25,266 |  |  | 50,679 |  |  | 50,675 |  |
| % of net sales |  | 3.6 | % |  | 4.0 | % |  | 3.9 | % |  | 4.4 | % |
| Amortization of intangible assets and acquisition-related costs |  | 4,317 |  |  | 2,491 |  |  | 6,838 |  |  | 3,881 |  |
| % of net sales |  | 0.6 | % |  | 0.4 | % |  | 0.5 | % |  | 0.3 | % |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (2,930 | ) |  | — |  |  | (4,908 | ) |
| % of net sales |  | — | % |  | (0.5 | )% |  | — | % |  | (0.4 | )% |
| Restructuring charges (credits), net |  | 119 |  |  | (61 | ) |  | 10,040 |  |  | (116 | ) |
| % of net sales |  | — | % |  | — | % |  | 0.8 | % |  | — | % |
| Total operating expenses |  | $ | 190,985 |  |  | $ | 168,799 |  |  | $ | 382,471 |  |  | $ | 331,042 |  |
| % of net sales |  | 27.6 | % |  | 26.7 | % |  | 29.4 | % |  | 28.5 | % |

[0001032975-18-000048:mdna:107]
[same as prior period, unchanged from 0001032975-18-000037:mdna:104]

[0001032975-18-000048:mdna:108]
[same as prior period, unchanged from 0001032975-18-000037:mdna:105]

[0001032975-18-000048:mdna:109]
During the three and six months ended September 30, 2018, marketing and selling expenses increased $14.4 million and $26.6 million, respectively, compared to the same periods of the prior fiscal year. The increases were primarily driven by higher advertising and marketing expenses to support our new products, and higher personnel-related costs due to increased headcount and increased performance based variable compensation.

[0001032975-18-000048:mdna:110]
[same as prior period, unchanged from 0001032975-18-000037:mdna:107]

[0001032975-18-000048:mdna:111]
[same as prior period, unchanged from 0001032975-18-000037:mdna:108]

[0001032975-18-000048:mdna:112]
During the three and six months ended September 30, 2018, research and development expenses increased $2.9 million and $6.8 million, respectively, compared to the same periods in the prior fiscal year. The increases were primarily driven by higher personnel-related costs due to increased headcount from business acquisitions and increased performance based variable compensation, and higher investment in new product developments.

[0001032975-18-000048:mdna:113]
[same as prior period, unchanged from 0001032975-18-000037:mdna:110]

[0001032975-18-000048:mdna:114]
General and administrative expenses consist primarily of personnel and related overhead, information technology, and facilities costs for the infrastructure functions such as finance, information systems, executives, human resources, and legal functions.

[0001032975-18-000048:mdna:115]
During the three and six months ended September 30, 2018, general and administrative expenses remained relatively flat, compared to the same periods in the prior fiscal year.

[0001032975-18-000048:mdna:116]
[same as prior period, unchanged from 0001032975-18-000037:mdna:113]

[0001032975-18-000048:mdna:117]
Amortization of intangibles and acquisition-related costs during the three and six months ended September 30, 2018 and 2017 were as follows (in thousands):

[0001032975-18-000048:mdna:118]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Amortization of intangible assets |  | $ | 2,861 |  |  | $ | 1,750 |  |  | $ | 5,382 |  |  | $ | 2,839 |  |
| Acquisition-related costs |  | 1,456 |  |  | 741 |  |  | 1,456 |  |  | 1,042 |  |
| Total |  | $ | 4,317 |  |  | $ | 2,491 |  |  | $ | 6,838 |  |  | $ | 3,881 |  |

[0001032975-18-000048:mdna:119]
Amortization of intangible assets consists of amortization of acquired intangible assets, including customer relationships and trade names. The increases in amortization of intangible assets during the three and six months ended September 30, 2018 compared with the same periods of the prior fiscal year were primarily driven by the acquisition of ASTRO in the second quarter of fiscal year 2018 and the acquisition of Blue Microphones in the second quarter of fiscal year 2019. Acquisition-related costs include legal expense, due diligence costs, and other professional costs incurred for business acquisitions.

[0001032975-18-000048:mdna:120]
[same as prior period, unchanged from 0001032975-18-000037:mdna:117]

[0001032975-18-000048:mdna:121]
There was no contingent consideration for business acquisition during the three and six months ended September 30, 2018. The decrease in fair value of contingent consideration during the three months ended September 30, 2017 was primarily due to the agreement we reached with the sellers of Jaybird LLC, the company we acquired in April 2016. During the six months ended September 30, 2017, the fair value of the contingent consideration decreased $4.9 million due to the agreement reached with the sellers of Jaybird LLC and lower-than-expected net sales of Jaybird products, partially offset by the change in the time value of money.

[0001032975-18-000048:mdna:122]
[same as prior period, unchanged from 0001032975-18-000037:mdna:119]

[0001032975-18-000048:mdna:123]
During the first quarter of fiscal year 2019, we implemented a restructuring plan to streamline and realign our overall organizational structure and reallocate resources to support the long-term growth opportunities. In July, 2018, our Board of Directors approved to allow additional costs under this restructuring plan, totaling pre-tax charges of approximately $10.0 million to $15.0 million, of which $10.0 million was recognized during the first half of fiscal year 2019. The total charges consisted of cash severance and other personnel costs and are presented as restructuring charges (credit), net in the condensed consolidated statements of operations. We expect to substantially complete this restructuring within the next six to nine months.

[0001032975-18-000048:mdna:124]
The following table summarizes restructuring related activities during the three and six months ended September 30, 2018 (in thousands):

[0001032975-18-000048:mdna:125]
|  |  | TerminationBenefits |
| Accrual balance at March 31, 2018 |  | $ | — |  |
| Charges |  | 9,921 |  |
| Cash payments |  | (2,014 | ) |
| Accrual balance at June 30, 2018 |  | 7,907 |  |
| Charges |  | 119 |  |
| Cash payments |  | (1,945 | ) |
| Accrual balance at September 30, 2018 |  | $ | 6,081 |  |

[0001032975-18-000048:mdna:126]
Provision for (Benefit from) Income Taxes

[0001032975-18-000048:mdna:127]
The provision for (benefit from) income taxes and effective tax rates for the three and six months ended September 30, 2018 and 2017 were as follows (Dollars in thousands):

[0001032975-18-000048:mdna:128]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Provision for (benefit from) income taxes |  | $ | 6,203 |  |  | $ | 4,087 |  |  | $ | 986 |  |  | $ | (1,349 | ) |
| Effective income tax rate |  | 8.8 | % |  | 6.8 | % |  | 1.0 | % |  | (1.5 | )% |

[0001032975-18-000048:mdna:129]
We have not adjusted the net provisional charge from remeasuring deferred tax assets related to the Tax Act in the United States in fiscal year 2018. We continue to refine the estimate based on ongoing analysis and available information and interpretations through the third quarter of fiscal year 2019.

[0001032975-18-000048:mdna:130]
The changes in the effective income tax rate for the three and six months ended September 30, 2018, compared to the three and six months ended September 30, 2017, were primarily due to the mix of income and losses in the various tax jurisdictions in which we operate and less excess tax benefits recognized in the United States in the three and six months ended September 30, 2018. We recognized excess tax benefits of $0.7 million and $9.0 million, respectively, at 21% federal corporate income tax rate post the Tax Act in the three and six months ended September 30, 2018.  In the same periods in fiscal year 2018, we recognized $1.1 million and $11.0 million of excess tax benefits, respectively, at 35% federal corporate income tax rate after adoption of ASU 2016-09. In the three and six months ended September 30, 2018, there were discrete tax benefits of $0.5 million and $1.4 million, respectively, from the reversal of uncertain tax positions from the expiration of statutes of limitations. In the same periods ended September 30, 2017, the tax benefits from reversal of uncertain tax positions from the expiration of statutes of limitations were $0.7 million and $1.3 million, respectively.

[0001032975-18-000048:mdna:131]
As of September 30, 2018 and March 31, 2018, the total amounts of unrecognized tax benefits due to uncertain tax positions were $70.4 million and $69.1 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-18-000048:mdna:132]
[same as prior period, unchanged from 0001032975-18-000037:mdna:129]

[0001032975-18-000048:mdna:133]
[same as prior period, unchanged from 0001032975-18-000037:mdna:130]

[0001032975-18-000048:mdna:134]
As of September 30, 2018, we had cash and cash equivalents of $425.0 million, compared to $641.9 million as of March 31, 2018. As of September 30, 2018, 62% of the cash and cash equivalents was held in Switzerland, 18%  held in Hong Kong and China and 9% held in the United Kingdom. We do not expect to incur any material adverse tax impact except for what has been recognized, or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-18-000048:mdna:135]
The decrease in cash and cash equivalents for the six months ended September 30, 2018, was primarily due to the Blue Microphones Acquisition ("Note 2 - Business Acquisition" to the condensed consolidated financial statements), payment of cash dividends, purchases of property, plant and equipment, tax withholdings related to settlements of restricted stock units and the purchases of our shares, partially offset by proceeds from exercises of stock options and purchase rights and net cash provided by operating activities.

[0001032975-18-000048:mdna:136]
As of September 30, 2018, our working capital was $438.6 million, compared to $597.4 million as of March 31, 2018. The decrease was primarily driven by higher accounts payable, higher accruals, lower cash and cash equivalents offset by higher accounts receivable, net and inventories. Our working capital was $445.5 million as of September 30, 2017.

[0001032975-18-000048:mdna:137]
We had several uncommitted, unsecured bank lines of credit aggregating $79.3 million as of September 30, 2018. There are no financial covenants under these lines of credit with which we must comply. As of September 30, 2018, we had outstanding bank guarantees of $26.3 million under these lines of credit.

[0001032975-18-000048:mdna:138]
[same as prior period, unchanged from 0001032975-18-000037:mdna:175]

[0001032975-18-000048:mdna:139]
[same as prior period, unchanged from 0001032975-18-000037:mdna:136]

[0001032975-18-000048:mdna:140]
|  |  | Six Months EndedSeptember 30, |
|  |  | 2018 |  | 2017 |
| Net cash provided by operating activities |  | $ | 97,220 |  |  | $ | 67,500 |  |
| Net cash used in investing activities |  | (153,815 | ) |  | (109,202 | ) |
| Net cash used in financing activities |  | (151,245 | ) |  | (108,636 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (9,157 | ) |  | 1,653 |  |
| Net decrease in cash and cash equivalents |  | $ | (216,997 | ) |  | $ | (148,685 | ) |

[0001032975-18-000048:mdna:141]
The following table presents selected financial information and statistics as of and for the three months ended September 30, 2018 and 2017 (Dollars in thousands):

[0001032975-18-000048:mdna:142]
|  |  | As of September 30, |
|  |  | 2018 |  | 2017 |
| Accounts receivable, net |  | $ | 459,689 |  |  | $ | 277,839 |  |
| Accounts payable |  | $ | 440,564 |  |  | $ | 386,963 |  |
| Inventories |  | $ | 358,774 |  |  | $ | 330,422 |  |

[0001032975-18-000048:mdna:143]
|  |  | Three Months EndedSeptember 30, |
|  |  | 2018 |  | 2017 |
| Days sales in accounts receivable (“DSO”) (Days) (1) |  | 60 |  |  | 40 |  |
| Days accounts payable outstanding (“DPO”) (Days) (2) |  | 91 |  |  | 86 |  |
| Inventory turnover (“ITO”) (x)(3) |  | 4.9 |  |  | 4.9 |  |

[0001032975-18-000048:mdna:144]
[same as prior period, unchanged from 0001032975-18-000037:mdna:140]

[0001032975-18-000048:mdna:145]
[same as prior period, unchanged from 0001032975-18-000037:mdna:141]

[0001032975-18-000048:mdna:146]
[same as prior period, unchanged from 0001032975-18-000037:mdna:142]

[0001032975-18-000048:mdna:147]
DSO for the three months ended September 30, 2018 increased by 20 days to 60 days, as compared to 40 days for the same period of the prior fiscal year. The adoption of Topic 606 negatively impacted our DSO for the three months ended September 30, 2018 by 18 days, mainly as a result of changes in the balance sheet presentation of certain reserve balances previously shown net within accounts receivable which are now presented as liabilities. The adoption of Topic 606 did not have an impact over the total cash flows from operating, investing or financing activities. Refer to Note 1 to the condensed consolidated financial statements for the details of the adoption impact of Topic 606. Timing of sales and customer payments also drove the increase in DSO.

[0001032975-18-000048:mdna:148]
DPO for the three months ended September 30, 2018 increased five days, compared to the same period of the prior fiscal year, primarily due to the timing of purchases and related payments.

[0001032975-18-000048:mdna:149]
ITO for the three months ended September 30, 2018 remained constant, compared to the same period of the prior fiscal year.

[0001032975-18-000048:mdna:150]
Certain of the our products are subject to the increased tariff duty effective September 24, 2018, which did not have material impact to our condensed consolidated financial statements as of September 30, 2018 and for the period then ended.

[0001032975-18-000048:mdna:151]
[same as prior period, unchanged from 0001032975-18-000037:mdna:146]

[0001032975-18-000048:mdna:152]
41

[0001032975-18-000048:mdna:153]
During the six months ended September 30, 2018, we generated $97.2 million cash in operating activities. Our main sources of operating cash flows were from net income after adding back non-cash expenses of depreciation, amortization, and share-based compensation expense, and from changes in operating assets and liabilities. The increases in accounts receivable, net, excluding the impact from the adoption of Topic 606 at adoption date were primarily due to higher business volumes, timing of sales and customer payments. The increases in inventories were primarily driven by increased sales expectation for the holidays in the third quarter, and higher inventory balances to support tariff impact mitigation. We strategically invested in our inventory ahead of the recent tariff implementation. The increases in accounts payable were primarily driven by the higher inventory purchases and timing of payment. The increases in accrued and current liabilities were primarily driven by higher sales reserve liability due to higher business volumes.

[0001032975-18-000048:mdna:154]
Net cash used in investing activities was $153.8 million, primarily due to $133.8 million payment of the net cash purchase price for the Blue Microphones Acquisition and $18.4 million of purchases of property, plant and equipment.

[0001032975-18-000048:mdna:155]
Our expenditures for property, plant and equipment during the six months ended September 30, 2018 increased by $1.2 million, compared to the same period of the prior fiscal year, mainly due to the higher amount of tooling purchases.

[0001032975-18-000048:mdna:156]
Net cash used in financing activities was $151.2 million, primarily for the $114.0 million payment of cash dividend, $19.9 million in repurchases of our registered shares, and $27.4 million tax withholdings related to net share settlements of restricted stock units, partially offset by $10.0 million in proceeds received from exercises of stock options and purchase rights.

[0001032975-18-000048:mdna:157]
During the six months ended September 30, 2018, there was a $9.2 million loss from currency exchange rate effect on cash and cash equivalents, compared to a gain of $1.7 million during the same period of the prior fiscal year. The loss from currency exchange rate effect during the six months ended September 30, 2018 was primarily due to the weakening of the Euro, Chinese Renmibi, Brazilian Real, and Japanese Yen against the U.S. Dollar by 6%, 9%, 18% and 6%, respectively, during the period. The gain from currency translation exchange effect during the six months ended September 30, 2017 was primarily due to the strengthening of the Euro against the U.S. Dollar by 10% during the period.

[0001032975-18-000048:mdna:158]
[same as prior period, unchanged from 0001032975-18-000037:mdna:152]

[0001032975-18-000048:mdna:159]
[same as prior period, unchanged from 0001032975-18-000037:mdna:153]

[0001032975-18-000048:mdna:160]
In fiscal year 2019, we paid a cash dividend of CHF 110.7 million (U.S. Dollar amount of $114.0 million) out of retained earnings. In fiscal year 2018, we paid a cash dividend of CHF100.0 million (U.S. Dollar amount of $104.2 million) out of retained earnings. Any future dividends will be subject to the approval of our shareholders.

[0001032975-18-000048:mdna:161]
In March 2017, our Board of Directors approved 2017 share buyback program, which authorizes us to purchase up to $250.0 million of our outstanding shares. The new program was approved by the Swiss Takeover Board in May 2017. Although we enter into trading plans for systematic repurchases (e.g., 10b5-1 trading plans) from time to time, our share buyback program provides us with the opportunity to make repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. As of September 30, 2018, $200.0 million is still available for repurchase under the 2017 share buyback program.

[0001032975-18-000048:mdna:162]
[same as prior period, unchanged from 0001032975-18-000037:mdna:156]

[0001032975-18-000048:mdna:163]
If we do not generate sufficient operating cash flows to support our operations and future planned cash requirements, our operations could be harmed and our access to credit could be restricted or eliminated. However,

[0001032975-18-000048:mdna:164]
42

[0001032975-18-000048:mdna:165]
we believe that the trend of our historical cash flow generation, our projections of future operations and our available cash balances will provide sufficient liquidity to fund our operations for at least the next 12 months.

[0001032975-18-000048:mdna:166]
[same as prior period, unchanged from 0001032975-18-000037:mdna:158]

[0001032975-18-000048:mdna:167]
[same as prior period, unchanged from 0001032975-18-000037:mdna:159]

[0001032975-18-000048:mdna:168]
[same as prior period, unchanged from 0001032975-18-000037:mdna:161]

[0001032975-18-000048:mdna:169]
As of September 30, 2018, we had non-cancelable purchase commitments for inventory purchases made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. Non-cancelable purchase commitments for capital expenditures primarily relate to commitments for tooling for new and existing products, computer hardware, leasehold and improvements. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-18-000048:mdna:170]
[same as prior period, unchanged from 0001032975-18-000037:mdna:163]

[0001032975-18-000048:mdna:171]
[same as prior period, unchanged from 0001032975-18-000037:mdna:164]

[0001032975-18-000048:mdna:172]
[same as prior period, unchanged from 0001032975-18-000037:mdna:165]

[0001032975-18-000048:mdna:173]
[same as prior period, unchanged from 0001032975-18-000037:mdna:166]

[0001032975-18-000048:mdna:174]
[same as prior period, unchanged from 0001032975-18-000037:mdna:167]

[0001032975-18-000048:mdna:175]
Logitech Europe S.A., one of our wholly-owned subsidiaries, guaranteed payments of certain third-party contract manufacturers' purchase obligations. As of September 30, 2018, the maximum amount of this guarantee was $3.8 million, of which $1.5 million of guaranteed purchase obligations were outstanding.

[0001032975-18-000048:mdna:176]
[same as prior period, unchanged from 0001032975-18-000037:mdna:169]

[0001032975-18-000048:mdna:177]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2018, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-18-000048:mdna:178]
[same as prior period, unchanged from 0001032975-18-000037:mdna:171]

[0001032975-18-000048:mdna:179]
Legal Proceedings

[0001032975-18-000048:mdna:180]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of our business. We are currently subject to several such claims and a small number of legal proceedings. We believe that these matters lack merit and we intend to vigorously defend against them. Based on currently available information, we do not believe that resolution of pending matters will have a material adverse effect on our financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that our defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on our business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against us, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect our business.

[0001032975-18-000048:mdna:181]
44
