# LOGI 8-K — 0001032975-18-000044 filed 2018-10-23

## item codes, every 8-K on or before 2018-10-25

- 2018-10-23 0001032975-18-000044 — 2.02, 9.01
- 2018-09-07 0001032975-18-000040 — 5.07, 8.01
- 2018-07-31 0001032975-18-000035 — 1.01, 2.02, 2.05, 7.01, 9.01
- 2018-06-27 0001032975-18-000020 — 5.02
- 2018-05-03 0001032975-18-000013 — 2.02, 5.02, 9.01
- 2018-01-23 0001032975-18-000005 — 2.02, 9.01
- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2018-10-25

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-18-000044:8k_2_02:1]
EX-99.1
2
exhibit991q2fy19.htm
EXHIBIT 99.1

[0001032975-18-000044:8k_2_02:2]
Exhibit

[0001032975-18-000044:8k_2_02:3]
Exhibit 99.1

[0001032975-18-000044:8k_2_02:4]
Editorial Contacts:

[0001032975-18-000044:8k_2_02:5]
Ben Lu, Vice President, Investor Relations - USA (510) 713-5568

[0001032975-18-000044:8k_2_02:6]
Krista Todd, Vice President, Communications - USA (510) 713-5834

[0001032975-18-000044:8k_2_02:7]
Ben Starkie, Corporate Communications - Europe +41 (0) 79-292-3499

[0001032975-18-000044:8k_2_02:8]
Logitech Delivers Record Q2 Sales and Double-Digit Profit Growth

[0001032975-18-000044:8k_2_02:9]
LAUSANNE, Switzerland - Oct. 23, 2018 and NEWARK, Calif., Oct. 22, 2018 - Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the second quarter of Fiscal Year 2019.

[0001032975-18-000044:8k_2_02:10]
| • | Q2 sales were $691 million, up 9 percent in US dollars and 10 percent in constant currency, compared to Q2 of the prior year. |

[0001032975-18-000044:8k_2_02:11]
| • | Q2 GAAP operating income reached $65 million, compared to $59 million in the same quarter a year ago. Q2 GAAP earnings per share (EPS) grew 15 percent to $0.38, compared to $0.33 in the same quarter a year ago. |

[0001032975-18-000044:8k_2_02:12]
| • | Q2 non-GAAP operating income grew 18 percent to $85 million, compared to $71 million in the same quarter a year ago. Q2 non-GAAP EPS grew 26 percent to $0.49, compared to $0.39 in the same quarter a year ago. |

[0001032975-18-000044:8k_2_02:13]
| • | Q2 cash flow from operations was $85 million, up 24 percent compared to Q2 of the prior year. Cash flow from operations for the fiscal year to date was $97 million, compared to $67 million for the same period a year ago. |

[0001032975-18-000044:8k_2_02:14]
“Q2 showcased the power and diversity of our portfolio,” said Bracken Darrell, Logitech president and chief executive officer. “We delivered our highest ever sales for a second quarter, with double-digit growth in both Gaming and Video Collaboration and solid growth in our PC Peripherals categories. Our innovation engine is on display as we move into the holiday quarter with a line-up of new, innovative products already well-received by consumers.”

[0001032975-18-000044:8k_2_02:15]
Vincent Pilette, chief financial officer, said, “With healthy sales growth of 10 percent in constant currency, we delivered a strong gross margin, above our long-term target. Our constant and obsessive focus on operational efficiency allowed us to continue to invest for future growth while growing non-GAAP operating profit 18 percent and once again delivering strong leverage to the bottom line.”

[0001032975-18-000044:8k_2_02:16]
Outlook

[0001032975-18-000044:8k_2_02:17]
Logitech confirmed its Fiscal Year 2019 outlook of 9 to 11 percent sales growth in constant currency and $325 million to $335 million in non-GAAP operating income.

[0001032975-18-000044:8k_2_02:18]
Prepared Remarks Available Online

[0001032975-18-000044:8k_2_02:19]
Logitech has made its prepared written remarks for the financial results teleconference available online on the Logitech corporate website at http://ir.logitech.com.

[0001032975-18-000044:8k_2_02:20]
Financial Results Teleconference and Webcast

[0001032975-18-000044:8k_2_02:21]
Logitech will hold a financial results teleconference to discuss the results for Q2 FY 2019 on

[0001032975-18-000044:8k_2_02:22]
Tuesday, October 23, 2018 at 8:30 a.m. Eastern Daylight Time and 2:30 p.m. Central European Summer Time. A live webcast of the call will be available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-18-000044:8k_2_02:23]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-18-000044:8k_2_02:24]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of intangible assets, purchase accounting effect on inventory, acquisition-related costs, change in fair value of contingent consideration for business acquisition, restructuring charges (credits), loss (gain) on investments in privately held companies, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below. Logitech also presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for Fiscal Year 2019.

[0001032975-18-000044:8k_2_02:25]
About Logitech

[0001032975-18-000044:8k_2_02:26]
Logitech designs products that have an everyday place in people's lives, connecting them to the digital experiences they care about. More than 35 years ago, Logitech started connecting people through computers, and now it’s a multi-brand company designing products that bring people together through music, gaming, video and computing. Brands of Logitech include Logitech, Ultimate Ears, Jaybird, Blue Microphones, Logitech G and ASTRO Gaming. Founded in 1981, and headquartered in Lausanne, Switzerland, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @Logitech.

[0001032975-18-000044:8k_2_02:27]
# # #

[0001032975-18-000044:8k_2_02:28]
expect, or when we expect it; if we fail to innovate and develop new products in a timely and cost-effective manner for our new and existing product categories; if we do not successfully execute on our growth opportunities or our growth opportunities are more limited than we expect; the effect of pricing, product, marketing and other initiatives by our competitors, and our reaction to them, on our sales, gross margins and profitability; if our products and marketing strategies fail to separate our products from competitors’ products; if we do not fully realize our goals to lower our costs and improve our operating leverage; if there is a deterioration of business and economic conditions in one or more of our sales regions or product categories, or significant fluctuations in exchange rates; changes in trade policies and agreements and the imposition of tariffs that affect our products or operations and our ability to mitigate; risks associated with acquisitions. A detailed discussion of these and other risks and uncertainties that could cause actual results and events to differ materially from such forward-looking statements is included in Logitech’s periodic filings with the Securities and Exchange Commission, including our Annual Report on Form 10-K for the fiscal year ended March 31, 2018 and our Quarterly Report of Form 10-Q for the fiscal quarter ended June 30, 2018, available at www.sec.gov, under the caption Risk Factors and elsewhere. Logitech does not undertake any obligation to update any forward-looking statements to reflect new information or events or circumstances occurring after the date of this press release.

[0001032975-18-000044:8k_2_02:29]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-18-000044:8k_2_02:30]
Logitech and other Logitech marks are trademarks or registered trademarks of Logitech Europe S.A and/or its affiliates in the U.S. and other countries.  All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-18-000044:8k_2_02:31]
(LOGIIR)

[0001032975-18-000044:8k_2_02:32]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | September 30, |  | September 30, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (A) |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales (B) |  | $ | 691,146 |  |  | $ | 632,470 |  |  | $ | 1,299,626 |  |  | $ | 1,162,416 |  |
| Cost of goods sold |  | 432,063 |  |  | 402,722 |  |  | 814,234 |  |  | 737,496 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 2,966 |  |  | 2,011 |  |  | 5,338 |  |  | 3,515 |  |
| Gross profit |  | 256,117 |  |  | 227,737 |  |  | 480,054 |  |  | 421,405 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 121,801 |  |  | 107,386 |  |  | 236,385 |  |  | 209,764 |  |
| Research and development |  | 39,542 |  |  | 36,647 |  |  | 78,529 |  |  | 71,746 |  |
| General and administrative |  | 25,206 |  |  | 25,266 |  |  | 50,679 |  |  | 50,675 |  |
| Amortization of intangible assets and acquisition-related costs |  | 4,317 |  |  | 2,491 |  |  | 6,838 |  |  | 3,881 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (2,930 | ) |  | — |  |  | (4,908 | ) |
| Restructuring charges (credits), net |  | 119 |  |  | (61 | ) |  | 10,040 |  |  | (116 | ) |
| Total operating expenses |  | 190,985 |  |  | 168,799 |  |  | 382,471 |  |  | 331,042 |  |
| Operating income |  | 65,132 |  |  | 58,938 |  |  | 97,583 |  |  | 90,363 |  |
| Interest income |  | 1,858 |  |  | 1,048 |  |  | 4,227 |  |  | 2,223 |  |
| Other income (expense), net |  | 3,389 |  |  | 459 |  |  | 1,818 |  |  | (570 | ) |
| Income before income taxes |  | 70,379 |  |  | 60,445 |  |  | 103,628 |  |  | 92,016 |  |
| Provision for (benefit from) income taxes |  | 6,203 |  |  | 4,087 |  |  | 986 |  |  | (1,349 | ) |
| Net income |  | $ | 64,176 |  |  | $ | 56,358 |  |  | $ | 102,642 |  |  | $ | 93,365 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.39 |  |  | $ | 0.34 |  |  | $ | 0.62 |  |  | $ | 0.57 |  |
| Diluted |  | $ | 0.38 |  |  | $ | 0.33 |  |  | $ | 0.61 |  |  | $ | 0.55 |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 165,630 |  |  | 164,120 |  |  | 165,474 |  |  | 163,765 |  |
| Diluted |  | 169,234 |  |  | 169,078 |  |  | 168,996 |  |  | 168,710 |  |
| Cash dividend per share |  | $ | 0.69 |  |  | $ | 0.63 |  |  | $ | 0.69 |  |  | $ | 0.63 |  |

[0001032975-18-000044:8k_2_02:33]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS * |
| (In thousands) - unaudited |  |  |  |  |
|  |  | September 30, 2018 |  | March 31, 2018 |
| CONDENSED CONSOLIDATED BALANCE SHEETS (A) |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 424,950 |  |  | $ | 641,947 |  |
| Accounts receivable, net (B) |  | 459,689 |  |  | 214,885 |  |
| Inventories |  | 358,774 |  |  | 259,906 |  |
| Other current assets (B) |  | 70,412 |  |  | 56,362 |  |
| Total current assets |  | 1,313,825 |  |  | 1,173,100 |  |
| Non-current assets: |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 83,731 |  |  | 86,304 |  |
| Goodwill |  | 346,548 |  |  | 275,451 |  |
| Other intangible assets, net |  | 130,538 |  |  | 87,547 |  |
| Other assets |  | 131,565 |  |  | 120,755 |  |
| Total assets |  | $ | 2,006,207 |  |  | $ | 1,743,157 |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 440,564 |  |  | $ | 293,988 |  |
| Accrued and other current liabilities (B) |  | 434,615 |  |  | 281,732 |  |
| Total current liabilities |  | 875,179 |  |  | 575,720 |  |
| Non-current liabilities: |  |  |  |  |  |  |
| Income taxes payable |  | 34,456 |  |  | 34,956 |  |
| Other non-current liabilities |  | 84,408 |  |  | 81,924 |  |
| Total liabilities |  | 994,043 |  |  | 692,600 |  |
| Shareholders’ equity: |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |
| Issued shares — 173,106 at September 30 and March 31, 2018 |  |  |  |  |
| Additional shares that may be issued out of conditional capitals — 50,000 at September 30 and March 31, 2018 |  |  |  |  |
| Additional shares that may be issued out of authorized capital — 36,621 at September 30, 2018 and none at March 31, 2018 |  |  |  |  |
| Additional paid-in capital |  | 33,160 |  |  | 47,234 |  |
| Shares in treasury, at cost — 7,384 at September 30, 2018 and 8,527 at March 31, 2018 |  | (163,481 | ) |  | (165,686 | ) |
| Retained earnings (B) |  | 1,210,105 |  |  | 1,232,316 |  |
| Accumulated other comprehensive loss |  | (97,768 | ) |  | (93,455 | ) |
| Total shareholders’ equity |  | 1,012,164 |  |  | 1,050,557 |  |
| Total liabilities and shareholders’ equity |  | $ | 2,006,207 |  |  | $ | 1,743,157 |  |

[0001032975-18-000044:8k_2_02:34]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | September 30, |  | September 30, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (A) |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 64,176 |  |  | $ | 56,358 |  |  | $ | 102,642 |  |  | $ | 93,365 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  | 11,196 |  |  | 10,220 |  |  | 21,895 |  |  | 19,368 |  |
| Amortization of intangible assets |  | 5,448 |  |  | 3,645 |  |  | 10,341 |  |  | 6,238 |  |
| Gain on investments in privately held companies |  | (395 | ) |  | (695 | ) |  | (382 | ) |  | (436 | ) |
| Share-based compensation expense |  | 12,049 |  |  | 10,978 |  |  | 25,308 |  |  | 21,683 |  |
| Deferred income taxes |  | (156 | ) |  | (2,054 | ) |  | (9,815 | ) |  | (11,933 | ) |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (2,930 | ) |  | — |  |  | (4,908 | ) |
| Other |  | (49 | ) |  | 15 |  |  | 75 |  |  | 12 |  |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | (64,918 | ) |  | (56,016 | ) |  | (133,475 | ) |  | (91,718 | ) |
| Inventories |  | (66,201 | ) |  | (37,689 | ) |  | (84,401 | ) |  | (58,078 | ) |
| Other assets |  | (6,831 | ) |  | (5,402 | ) |  | (11,056 | ) |  | (8,490 | ) |
| Accounts payable |  | 86,998 |  |  | 71,489 |  |  | 138,186 |  |  | 110,136 |  |
| Accrued and other liabilities |  | 43,621 |  |  | 20,464 |  |  | 37,902 |  |  | (7,739 | ) |
| Net cash provided by operating activities |  | 84,938 |  |  | 68,383 |  |  | 97,220 |  |  | 67,500 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (9,624 | ) |  | (7,153 | ) |  | (18,368 | ) |  | (17,188 | ) |
| Investment in privately held companies |  | (281 | ) |  | (160 | ) |  | (506 | ) |  | (520 | ) |
| Acquisitions, net of cash acquired |  | (133,665 | ) |  | (85,000 | ) |  | (133,908 | ) |  | (85,000 | ) |
| Proceeds from return of investment in privately held companies |  | — |  |  | 237 |  |  | — |  |  | 237 |  |
| Purchases of short-term investments |  | (1,505 | ) |  | (6,789 | ) |  | (1,505 | ) |  | (6,789 | ) |
| Purchases of trading investments |  | (1,222 | ) |  | (390 | ) |  | (3,722 | ) |  | (999 | ) |
| Proceeds from sales of trading investments |  | 1,327 |  |  | 410 |  |  | 4,194 |  |  | 1,057 |  |
| Net cash used in investing activities |  | (144,970 | ) |  | (98,845 | ) |  | (153,815 | ) |  | (109,202 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | (113,971 | ) |  | (104,248 | ) |  | (113,971 | ) |  | (104,248 | ) |
| Purchases of registered shares |  | (9,919 | ) |  | (10,058 | ) |  | (19,901 | ) |  | (10,682 | ) |
| Proceeds from exercises of stock options |  | 8,903 |  |  | 17,431 |  |  | 10,007 |  |  | 30,000 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (2,299 | ) |  | (2,023 | ) |  | (27,380 | ) |  | (23,706 | ) |
| Net cash used in financing activities |  | (117,286 | ) |  | (98,898 | ) |  | (151,245 | ) |  | (108,636 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (1,848 | ) |  | 551 |  |  | (9,157 | ) |  | 1,653 |  |
| Net decrease in cash and cash equivalents |  | (179,166 | ) |  | (128,809 | ) |  | (216,997 | ) |  | (148,685 | ) |
| Cash and cash equivalents, beginning of the period |  | 604,116 |  |  | 527,657 |  |  | 641,947 |  |  | 547,533 |  |
| Cash and cash equivalents, end of the period |  | $ | 424,950 |  |  | $ | 398,848 |  |  | $ | 424,950 |  |  | $ | 398,848 |  |

[0001032975-18-000044:8k_2_02:35]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |  |  |
| NET SALES |  | Three Months Ended |  | Six Months Ended |
|  |  | September 30, |  | September 30, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Net sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Pointing Devices |  | $ | 128,337 |  |  | $ | 123,643 |  |  | 4 | % |  | $ | 256,127 |  |  | $ | 245,717 |  |  | 4 | % |
| Keyboards & Combos |  | 131,872 |  |  | 119,200 |  |  | 11 |  |  | 260,094 |  |  | 235,313 |  |  | 11 |  |
| PC Webcams |  | 28,221 |  |  | 27,466 |  |  | 3 |  |  | 57,895 |  |  | 53,091 |  |  | 9 |  |
| Tablet & Other Accessories |  | 36,710 |  |  | 30,784 |  |  | 19 |  |  | 69,146 |  |  | 54,002 |  |  | 28 |  |
| Video Collaboration |  | 57,176 |  |  | 46,139 |  |  | 24 |  |  | 115,968 |  |  | 81,756 |  |  | 42 |  |
| Mobile Speakers |  | 77,100 |  |  | 90,548 |  |  | (15 | ) |  | 111,427 |  |  | 153,466 |  |  | (27 | ) |
| Audio & Wearables |  | 61,560 |  |  | 62,445 |  |  | (1 | ) |  | 113,714 |  |  | 112,647 |  |  | 1 |  |
| Gaming |  | 160,792 |  |  | 113,722 |  |  | 41 |  |  | 296,818 |  |  | 191,430 |  |  | 55 |  |
| Smart Home |  | 9,241 |  |  | 18,323 |  |  | (50 | ) |  | 18,252 |  |  | 34,789 |  |  | (48 | ) |
| Other (1) |  | 137 |  |  | 200 |  |  | (32 | ) |  | 185 |  |  | 205 |  |  | (10 | ) |
| Total net sales |  | $ | 691,146 |  |  | $ | 632,470 |  |  | 9 |  |  | $ | 1,299,626 |  |  | $ | 1,162,416 |  |  | 12 |  |

[0001032975-18-000044:8k_2_02:36]
(1) Other category includes products that we currently intend to transition out of, or have already transitioned out of, because they are no longer strategic to our business.

[0001032975-18-000044:8k_2_02:37]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |  |  |  |  |
| GAAP TO NON-GAAP RECONCILIATION (A)(C) |  | Three Months Ended |  | Six Months Ended |
|  |  | September 30, |  | September 30, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Gross profit - GAAP |  | $ | 256,117 |  |  | $ | 227,737 |  |  | $ | 480,054 |  |  | $ | 421,405 |  |
| Share-based compensation expense |  | 791 |  |  | 1,091 |  |  | 1,921 |  |  | 1,802 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 2,966 |  |  | 2,011 |  |  | 5,338 |  |  | 3,515 |  |
| Gross profit - Non-GAAP |  | $ | 259,874 |  |  | $ | 230,839 |  |  | $ | 487,313 |  |  | $ | 426,722 |  |
| Gross margin - GAAP |  | 37.1 | % |  | 36.0 | % |  | 36.9 | % |  | 36.3 | % |
| Gross margin - Non-GAAP |  | 37.6 | % |  | 36.5 | % |  | 37.5 | % |  | 36.7 | % |
| Operating expenses - GAAP |  | $ | 190,985 |  |  | $ | 168,799 |  |  | $ | 382,471 |  |  | $ | 331,042 |  |
| Less: Share-based compensation expense |  | 11,258 |  |  | 9,887 |  |  | 23,387 |  |  | 19,881 |  |
| Less: Amortization of intangible assets and acquisition-related costs |  | 4,317 |  |  | 2,491 |  |  | 6,838 |  |  | 3,881 |  |
| Less: Change in fair value of contingent consideration for business acquisition |  | — |  |  | (2,930 | ) |  | — |  |  | (4,908 | ) |
| Less: Restructuring charges (credits), net |  | 119 |  |  | (61 | ) |  | 10,040 |  |  | (116 | ) |
| Operating expenses - Non-GAAP |  | $ | 175,291 |  |  | $ | 159,412 |  |  | $ | 342,206 |  |  | $ | 312,304 |  |
| % of net sales - GAAP |  | 27.6 | % |  | 26.7 | % |  | 29.4 | % |  | 28.5 | % |
| % of net sales - Non - GAAP |  | 25.4 | % |  | 25.2 | % |  | 26.3 | % |  | 26.9 | % |
| Operating income - GAAP |  | $ | 65,132 |  |  | $ | 58,938 |  |  | $ | 97,583 |  |  | $ | 90,363 |  |
| Share-based compensation expense |  | 12,049 |  |  | 10,978 |  |  | 25,308 |  |  | 21,683 |  |
| Amortization of intangible assets |  | 5,448 |  |  | 3,645 |  |  | 10,341 |  |  | 6,238 |  |
| Purchase accounting effect on inventory |  | 379 |  |  | 114 |  |  | 379 |  |  | 114 |  |
| Acquisition-related costs |  | 1,456 |  |  | 741 |  |  | 1,456 |  |  | 1,042 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (2,930 | ) |  | — |  |  | (4,908 | ) |
| Restructuring (charges) credits, net |  | 119 |  |  | (61 | ) |  | 10,040 |  |  | (116 | ) |
| Operating income - Non - GAAP |  | $ | 84,583 |  |  | $ | 71,425 |  |  | $ | 145,107 |  |  | $ | 114,416 |  |
| % of net sales - GAAP |  | 9.4 | % |  | 9.3 | % |  | 7.5 | % |  | 7.8 | % |
| % of net sales - Non - GAAP |  | 12.2 | % |  | 11.3 | % |  | 11.2 | % |  | 9.8 | % |
| Net income - GAAP |  | $ | 64,176 |  |  | $ | 56,358 |  |  | $ | 102,642 |  |  | $ | 93,365 |  |
| Share-based compensation expense |  | 12,049 |  |  | 10,978 |  |  | 25,308 |  |  | 21,683 |  |
| Amortization of intangible assets |  | 5,448 |  |  | 3,645 |  |  | 10,341 |  |  | 6,238 |  |
| Purchase accounting effect on inventory |  | 379 |  |  | 114 |  |  | 379 |  |  | 114 |  |
| Acquisition-related costs |  | 1,456 |  |  | 741 |  |  | 1,456 |  |  | 1,042 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | (2,930 | ) |  | — |  |  | (4,908 | ) |
| Restructuring (charges) credits, net |  | 119 |  |  | (61 | ) |  | 10,040 |  |  | (116 | ) |
| Loss (gain) on investments in privately held companies |  | (395 | ) |  | (695 | ) |  | (382 | ) |  | (436 | ) |
| Non-GAAP income tax adjustment |  | (116 | ) |  | (1,890 | ) |  | (9,225 | ) |  | (10,982 | ) |
| Net income - Non - GAAP |  | $ | 83,116 |  |  | $ | 66,260 |  |  | $ | 140,559 |  |  | $ | 106,000 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.38 |  |  | $ | 0.33 |  |  | $ | 0.61 |  |  | $ | 0.55 |  |
| Diluted - Non - GAAP |  | $ | 0.49 |  |  | $ | 0.39 |  |  | $ | 0.83 |  |  | $ | 0.63 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non - GAAP |  | 169,234 |  |  | 169,078 |  |  | 168,996 |  |  | 168,710 |  |

[0001032975-18-000044:8k_2_02:38]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
| SHARE-BASED COMPENSATION EXPENSE |  | Three Months Ended |  | Six Months Ended |
|  |  | September 30, |  | September 30, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 791 |  |  | $ | 1,091 |  |  | $ | 1,921 |  |  | $ | 1,802 |  |
| Marketing and selling |  | 4,864 |  |  | 4,343 |  |  | 10,650 |  |  | 8,724 |  |
| Research and development |  | 1,935 |  |  | 1,633 |  |  | 3,484 |  |  | 3,176 |  |
| General and administrative |  | 4,459 |  |  | 3,911 |  |  | 9,253 |  |  | 7,981 |  |
| Total share-based compensation expense |  | 12,049 |  |  | 10,978 |  |  | 25,308 |  |  | 21,683 |  |
| Income tax benefit |  | (2,650 | ) |  | (3,677 | ) |  | (12,179 | ) |  | (14,959 | ) |
| Total share-based compensation expense, net of income tax |  | $ | 9,399 |  |  | $ | 7,301 |  |  | $ | 13,129 |  |  | $ | 6,724 |  |

[0001032975-18-000044:8k_2_02:39]
*  Note: These preliminary results for the three and six months ended September 30, 2018 are subject to adjustments, including subsequent events that may occur through the date of filing our Quarterly Report on Form 10-Q.

[0001032975-18-000044:8k_2_02:40]
(A) The preliminary fair value of assets acquired and liabilities assumed from the business acquisition during the current period is included in the tables. The fair value of identifiable intangible assets acquired was based on estimates and assumptions made by us at the time of the acquisition. As additional information becomes available, such as finalization of purchase price adjustment and the finalization of the estimated fair value of the assets acquired and liabilities assumed, we may revise our preliminary or interim estimated fair value of the assets acquired and liabilities assumed during the remainder of the measurement periods (which will not exceed 12 months from the acquisition dates). Any such revisions or changes may be material, and may have a material impact over our financial condition and results of operations.

[0001032975-18-000044:8k_2_02:41]
(B) Adoption of ASC Topic 606

[0001032975-18-000044:8k_2_02:42]
On April 1, 2018, we adopted the new revenue standards under Accounting Standards Codification ("ASC") Topic 606. The adoption of Topic 606 did not have an impact over the total cash flows from operating, investing, or financing activities. The following tables summarize the impacts of adopting Topic 606 on our condensed consolidated statements of operations for the three and six months ended as of September 30, 2018 and condensed consolidated balance sheets as of September 30, 2018 (in thousands):

[0001032975-18-000044:8k_2_02:43]
|  | Three Months Ended September 30,2018 |  | Six Months Ended September 30, 2018 |
|  | As Reported Under ASC 606 | If Reported Under ASC 605 | Effect of Change |  | As Reported Under ASC 606 | If Reported Under ASC 605 | Effect of Change |
| Net sales | $ | 691,146 |  | $ | 696,090 |  | $ | (4,944 | ) |  | $ | 1,299,626 |  | $ | 1,304,704 |  | $ | (5,078 | ) |

[0001032975-18-000044:8k_2_02:44]
|  |  | As of September 30, 2018 |
|  |  | As Reported Under ASC 606 |  | Balance Under ASC 605 |  | Effect of Change |
| Accounts receivable, net |  | 459,689 |  |  | 327,131 |  |  | 132,558 |  |
| Other current assets |  | 70,412 |  |  | 61,092 |  |  | 9,320 |  |
| Accrued and other current liabilities |  | 434,615 |  |  | 276,777 |  |  | 157,838 |  |
| Retained earnings |  | 1,210,105 |  |  | 1,226,065 |  |  | (15,960 | ) |

[0001032975-18-000044:8k_2_02:45]
(C) Non-GAAP Financial Measures

[0001032975-18-000044:8k_2_02:46]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-18-000044:8k_2_02:47]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended September 30, 2018 and previous periods, we excluded items in the following general categories, each of which are described below:

[0001032975-18-000044:8k_2_02:48]
Share-based compensation expenses. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-18-000044:8k_2_02:49]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit, operating expenses, and financial results from period to period.

[0001032975-18-000044:8k_2_02:50]
Purchase accounting effect on inventory. Business combination accounting principles require us to measure acquired inventory at fair value. The fair value of inventory reflects the acquired company’s cost of manufacturing plus a portion of the expected profit margin. The non-GAAP adjustment excludes the expected profit margin component that is recorded under business combination accounting principles associated with our business acquisitions. We believe the adjustment is useful to investors because such charges are not reflective of our ongoing operations.

[0001032975-18-000044:8k_2_02:51]
Acquisition-related costs and change in fair value of contingent consideration for business acquisition.  We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition related costs include all incremental expenses incurred to effect a business combination. Fair value of contingent consideration is associated with our estimates of the value of earn-outs in connection with certain acquisitions. We believe that providing the non-GAAP measures excluding these costs and credits, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-18-000044:8k_2_02:52]
Restructuring charges (credits). These expenses are associated with re-aligning our business strategies based on current economic conditions. We have undertaken several restructuring plans in recent years. In connection with our restructuring initiatives, we incurred restructuring charges related to employee terminations, facility closures and early cancellation of certain contracts. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results in the current period.

[0001032975-18-000044:8k_2_02:53]
Loss (gain) on investments in privately held companies. We recognized loss (gain) related to our investments in various privately-held companies, which varies depending on the operational and financial performance of the privately-held companies in which we invested. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-18-000044:8k_2_02:54]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above and other events; the determination of which is based upon the nature of the underlying items, the mix of income and losses in jurisdictions and the relevant tax rates in which we operate.

[0001032975-18-000044:8k_2_02:55]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-18-000044:8k_2_02:56]
Additional Supplemental Financial Information - Constant Currency

[0001032975-18-000044:8k_2_02:57]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates.  Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.
