# LOGI notes — 0001032975-18-000048


## logi:ScheduleOfBalanceSheetComponentsAssetsTableTextBlock

[0001032975-18-000048:notes:1]
(1) Certain allowances for sales return and certain other Customer Programs were included within accounts receivable, net balance as of March 31, 2018. Upon adoption of Topic 606, such balances are presented as accrued revenue reserve from returns and accrued customer marketing, pricing and incentive programs included in accrued and other current liabilities, and as return assets included in other current assets, respectively, on the condensed consolidated balance sheet as of September 30, 2018. Refer to Note 1 to the condensed consolidated financial statements for more information.

[0001032975-18-000048:notes:2]
The following table presents the components of certain balance sheet asset amounts as of September 30 and March 31, 2018 (in thousands):

[0001032975-18-000048:notes:3]
|  |  | September 30, 2018 |  | March 31, 2018 |
| Accounts receivable, net: |  |  |  |  |  |  |
| Accounts receivable |  | $ | 639,479 |  |  | $ | 482,872 |  |
| Allowance for doubtful accounts |  | (645 | ) |  | (122 | ) |
| Allowance for sales returns (1) |  | (5,165 | ) |  | (25,515 | ) |
| Allowance for cooperative marketing arrangements (1) |  | (33,879 | ) |  | (30,389 | ) |
| Allowance for customer incentive programs (1) |  | (55,972 | ) |  | (70,592 | ) |
| Allowance for pricing programs (1) |  | (84,129 | ) |  | (141,369 | ) |
|  |  | $ | 459,689 |  |  | $ | 214,885 |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 31,756 |  |  | $ | 33,603 |  |
| Finished goods |  | 327,018 |  |  | 226,303 |  |
|  |  | $ | 358,774 |  |  | $ | 259,906 |  |
| Other current assets: |  |  |  |  |  |  |
| Value-added tax receivables |  | $ | 34,597 |  |  | $ | 29,477 |  |
| Prepaid expenses and other assets (1) |  | 35,815 |  |  | 26,885 |  |
|  |  | $ | 70,412 |  |  | $ | 56,362 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |
| Property, plant and equipment at cost |  | $ | 359,335 |  |  | $ | 346,588 |  |
| Less: accumulated depreciation and amortization |  | (275,604 | ) |  | (260,284 | ) |
|  |  | $ | 83,731 |  |  | $ | 86,304 |  |
| Other assets: |  |  |  |  |  |  |
| Deferred tax assets |  | $ | 92,833 |  |  | $ | 84,651 |  |
| Trading investments for deferred compensation plan |  | 20,645 |  |  | 17,748 |  |
| Investments in privately held companies |  | 13,283 |  |  | 12,448 |  |
| Other assets |  | 4,804 |  |  | 5,908 |  |
|  |  | $ | 131,565 |  |  | $ | 120,755 |  |


## logi:ScheduleOfBalanceSheetComponentsLiabilityTableTextBlock

[0001032975-18-000048:notes:4]
The following table presents the components of certain balance sheet liability amounts as of September 30 and March 31, 2018 (in thousands):

[0001032975-18-000048:notes:5]
|  |  | September 30, 2018 |  | March 31, 2018 |
| Accrued and other current liabilities: |  |  |  |  |  |  |
| Accrued personnel expenses |  | $ | 80,554 |  |  | $ | 82,330 |  |
| Accrued revenue reserve from returns (1) |  | 38,359 |  |  | — |  |
| Accrued customer marketing, pricing and incentive programs (1) |  | 173,992 |  |  | 71,962 |  |
| Warranty accrual |  | 18,470 |  |  | 16,279 |  |
| Employee benefit plan obligation |  | 2,243 |  |  | 1,763 |  |
| Income taxes payable |  | 5,741 |  |  | 4,354 |  |
| Other current liabilities |  | 115,256 |  |  | 105,044 |  |
|  |  | $ | 434,615 |  |  | $ | 281,732 |  |
| Other non-current liabilities: |  |  |  |  |  |  |
| Warranty accrual |  | $ | 13,284 |  |  | $ | 11,294 |  |
| Obligation for deferred compensation plan |  | 20,645 |  |  | 17,748 |  |
| Employee benefit plan obligation |  | 40,857 |  |  | 42,434 |  |
| Deferred tax liability |  | 1,980 |  |  | 1,980 |  |
| Other non-current liabilities |  | 7,642 |  |  | 8,468 |  |
|  |  | $ | 84,408 |  |  | $ | 81,924 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-18-000048:notes:6]
[same as prior period, unchanged from 0001032975-18-000037:notes:6]

[0001032975-18-000048:notes:7]
[same as prior period, unchanged from 0001032975-18-000037:notes:7]

[0001032975-18-000048:notes:8]
[same as prior period, unchanged from 0001032975-18-000037:notes:8]

[0001032975-18-000048:notes:9]
The Company sells its products to a broad network of domestic and international customers, including direct sales to retailers and e-tailers and indirect sales through distributors.

[0001032975-18-000048:notes:10]
[same as prior period, unchanged from 0001032975-18-000037:notes:10]

[0001032975-18-000048:notes:11]
Business Acquisition

[0001032975-18-000048:notes:12]
In August 2018, the Company acquired Blue Microphones Holding Corporation. See "Note 2 - Business Acquisition" for more information.

[0001032975-18-000048:notes:13]
[same as prior period, unchanged from 0001032975-18-000037:notes:11]

[0001032975-18-000048:notes:14]
[same as prior period, unchanged from 0001032975-18-000037:notes:12]

[0001032975-18-000048:notes:15]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and six months ended September 30, 2018 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2019, or any future periods.

[0001032975-18-000048:notes:16]
[same as prior period, unchanged from 0001032975-18-000037:notes:14]

[0001032975-18-000048:notes:17]
Certain amounts from the comparative period in the accompanying condensed consolidated financial statements have been reclassified to conform to the condensed consolidated financial statement presentation as of and for the three and six months ended September 30, 2018.

[0001032975-18-000048:notes:18]
[same as prior period, unchanged from 0001032975-18-000037:notes:16]

[0001032975-18-000048:notes:19]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted and Summary of Significant Accounting Policies, there have been no changes in the Company’s significant accounting policies during the six months ended September 30, 2018 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2018.

[0001032975-18-000048:notes:20]
[same as prior period, unchanged from 0001032975-18-000037:notes:18]

[0001032975-18-000048:notes:21]
The preparation of financial statements in conformity with GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill, intangible assets acquired from business acquisitions, warranty liabilities, accruals for customer incentives, cooperative marketing, and pricing programs ("Customer Programs") and related breakage when appropriate, accrued revenue reserve from returns, allowance for doubtful accounts, inventory valuation, contingent consideration from business acquisitions and periodical reassessment of its fair value, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from these estimates.

[0001032975-18-000048:notes:22]
[same as prior period, unchanged from 0001032975-18-000037:notes:20]

[0001032975-18-000048:notes:23]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers (Topic 606)" ("ASU 2014-09" or “Topic 606”) which supersedes the revenue recognition requirements under ASC 605 (“Topic 605”), Revenue Recognition. ASU 2014-09 outlines a new, single, comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes existing revenue recognition guidance, including industry-specific guidance. Under the new guidance, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The new standard requires reporting companies to disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. On April 1, 2018, the Company adopted the new standard and all related amendments using the modified retrospective method applied to those contracts which were not completed as of April 1, 2018. Results for reporting periods beginning after April 1, 2018 are presented under Topic 606, while prior period amounts are not adjusted and continue to be reported in accordance with historic accounting standards under Topic 605.

[0001032975-18-000048:notes:24]
As result of the adoption of the new standard, the Company recorded: a) a reduction to retained earnings as of April 1, 2018; and b) reclassifications of certain allowances for sales returns and certain other Customer Programs from accounts receivable, net to accrued and other current liabilities and other current assets.

[0001032975-18-000048:notes:25]
[same as prior period, unchanged from 0001032975-18-000037:notes:23]

[0001032975-18-000048:notes:26]
[same as prior period, unchanged from 0001032975-18-000037:notes:24]

[0001032975-18-000048:notes:27]
[same as prior period, unchanged from 0001032975-18-000037:notes:25]

[0001032975-18-000048:notes:28]
| • | Under Topic 605, accruals for certain Customer Programs were recognized as a reduction of revenue at the later of when the related revenue is recognized or when the program is offered to the customer. Under Topic 606, these programs qualify as variable consideration and are recorded as a reduction of the transaction price at the contract inception based on the expected value method. The Company is required to estimate the accruals for these programs ahead of commitment date if customary business practice creates an implied expectation that such activities will occur in the future. |

[0001032975-18-000048:notes:29]
[same as prior period, unchanged from 0001032975-18-000037:notes:27]

[0001032975-18-000048:notes:30]
Balance Sheet Reclassifications

[0001032975-18-000048:notes:31]
| • | Under Topic 605, the gross amount of accrued revenue reserves for sales returns of $31.4 million, net of expected returned inventory of $11.4 million was included within accounts receivable, net as of March 31, 2018. Expected scrap cost of $5.2 million for such expected returned inventory was included in accrued and other current liabilities as of March 31, 2018. Subsequent to the adoption of Topic 606, such balances are presented on a gross basis as accrued revenue reserve from returns of $31.4 million included in accrued and other current liabilities and as return assets of $6.2 million included in other current assets. |

[0001032975-18-000048:notes:32]
[same as prior period, unchanged from 0001032975-18-000037:notes:30]

[0001032975-18-000048:notes:33]
Certain balances of allowances for sales return and accruals for Customer Programs which were accrued based on Customer Program offers made to individual customers, met the right of offset criteria in accordance with ASC 210-20, "Balance Sheet (Topic 210)", and are still included within accounts receivable, net.

[0001032975-18-000048:notes:34]
[same as prior period, unchanged from 0001032975-18-000037:notes:32]

[0001032975-18-000048:notes:35]
The following tables summarize the impacts of adopting Topic 606 on the Company’s condensed consolidated statements of operations for the three and six months ended September 30, 2018 and condensed consolidated balance sheet as of September 30, 2018 (in thousands):

[0001032975-18-000048:notes:36]
|  | Three Months Ended September 30,2018 |  | Six Months Ended September 30, 2018 |
|  | As Reported Under ASC 606 | If Reported Under ASC 605 | Effect of Change |  | As Reported Under ASC 606 | If Reported Under ASC 605 | Effect of Change |
| Net sales | $ | 691,146 |  | $ | 696,090 |  | $ | (4,944 | ) |  | $ | 1,299,626 |  | $ | 1,304,704 |  | $ | (5,078 | ) |

[0001032975-18-000048:notes:37]
|  |  | As of September 30,2018 |
|  |  | As Reported Under ASC 606 |  | Balance Under ASC 605 |  | Effect of Change |
| Accounts receivable, net |  | 459,689 |  |  | 327,131 |  |  | 132,558 |  |
| Other current assets |  | 70,412 |  |  | 61,092 |  |  | 9,320 |  |
| Accrued and other current liabilities |  | 434,615 |  |  | 276,777 |  |  | 157,838 |  |
| Retained earnings |  | 1,210,105 |  |  | 1,226,065 |  |  | (15,960 | ) |

[0001032975-18-000048:notes:38]
In January 2016, the FASB issued ASU 2016-01, "Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10)" ("ASU 2016-01"). ASU 2016-01 requires entities to measure equity instruments at fair value and recognize any changes in fair value within the statement of operations. The Company adopted ASU 2016-01 effective April 1, 2018 on a prospective basis for its privately held strategic equity securities without readily determinable fair values. The Company elected the measurement alternative to record these investments at cost and to adjust for impairments and observable price changes with a same or similar security from the same issuer within the statement of operations. The adoption of ASU 2016-01 did not have a material impact on the Company's condensed consolidated financial statements.

[0001032975-18-000048:notes:39]
In October 2016, the FASB issued ASU 2016-16, "Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory" ("ASU 2016-16"), which eliminates the deferral of income tax effects of intra-entity asset transfers until the transferred asset is sold to an unrelated party or recovered through use. However, this standard does not apply to intra-entity transfer of inventory. The Company adopted this standard effective April 1, 2018 on a modified retrospective basis, and the adoption of ASU 2016-16 did not have a material impact on its condensed consolidated financial statements.

[0001032975-18-000048:notes:40]
In December 2016, the FASB issued ASU 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash" ("ASU 2016-18"), which requires that a statement of cash flows explains the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. The Company adopted this standard effective April 1, 2018, utilizing the retrospective transition method to each period presented and the adoption of ASU 2016-18 did not have an impact on its condensed consolidated financial statements as the Company did not have restricted cash for either periods presented.

[0001032975-18-000048:notes:41]
In January 2017, the FASB issued ASU 2017-01, "Business Combination (Topic 805): Clarifying the Definition of a Business" ("ASU 2017-01"), which changes the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. The Company adopted this standard effective April 1, 2018, and the adoption of ASU 2017-01 did not have a material impact on its condensed consolidated financial statements.

[0001032975-18-000048:notes:42]
In March 2017, the FASB issued ASU 2017-07, "Compensation-Retirement Benefit (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost" ("ASU 2017-07"), which requires that the Company disaggregate the service cost component from the other components of net benefit cost, and also provides guidance on how to present the service cost component and the other components of net benefit cost in the income statement and allow only the service cost component of net benefit cost to be eligible for capitalization. The Company adopted this standard effective April 1, 2018 using a retrospective adoption method. Other than the revised statement of operations presentation for the periods in the current year, the adoption of ASU 2017-07 did not have an impact on the Company’s condensed consolidated financial statements. The impact to the comparative period was immaterial and therefore the prior period statements of operations was not revised.

[0001032975-18-000048:notes:43]
In August 2017, the FASB issued ASU 2017-12, "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" ("ASU 2017-12"), which improves the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements and simplifies the application of the hedge accounting guidance. The Company adopted this standard prospectively on April 1, 2018, and the adoption of ASU 2017-12 did not have a material impact on its condensed consolidated financial statements. In accordance with ASU 2017-12, the Company has started presenting the earnings impact from forward points in cost of goods sold line item, which is used to present the earnings impact of the hedged item.

[0001032975-18-000048:notes:44]
[same as prior period, unchanged from 0001032975-18-000037:notes:41]

[0001032975-18-000048:notes:45]
In February 2016, the FASB issued ASU 2016-02, "Leases (Topic 842)" ("ASU 2016-02" or "Topic 842"), which generally requires companies to recognize right-of-use assets and lease liabilities arising from operating and financing leases with terms longer than 12 months in the consolidated balance sheets. The Company will adopt the new guidance in the first quarter of fiscal year 2020 on a modified retrospective basis, which recognizes the cumulative effect of initially applying Topic 842 as an adjustment to retained earnings at the adoption date. Although the Company expects to record significant amounts of right-of-use assets and liabilities on its condensed consolidated balance sheets, the Company is still evaluating the full impact that ASU 2016-02 will have on its condensed consolidated financial statements.

[0001032975-18-000048:notes:46]
In August 2018, the FASB issued ASU 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirements for Fair Value Measurements" ("ASU 2018-13"), which aims to improve the overall usefulness of disclosures to financial statement users and reduce unnecessary costs to companies when preparing fair value measurement disclosures. ASU 2018-13 is effective for annual and interim periods in fiscal years beginning after December 15, 2019. Early adoption is permitted. Retrospective adoption is required, except for certain disclosures which will be required to be applied prospectively for only the most recent interim or annual period presented in the initial fiscal year of adoption. The Company is evaluating the full effect that ASU 2018-13 will have on its condensed consolidated financial statements and the timing of adoption.

[0001032975-18-000048:notes:47]
In August 2018, the FASB issued ASU 2018-14, "Compensation - Retirement Benefits - Defined Benefits Plans - General (Subtopic 715-20): Disclosure Framework - Changes to the Disclosure Requirements for Defined Benefit Plans" ("ASU 2018-14"), which aims to improve the overall usefulness of disclosures to financial statement users and reduce unnecessary costs to companies when preparing defined benefit plan disclosures. ASU 2018-14 is effective for annual periods in fiscal years ending after December 15, 2021. Retrospective adoption is required and early adoption is permitted. The Company is evaluating the full effect that ASU 2018-14 will have on its condensed consolidated financial statements and the timing of adoption.

[0001032975-18-000048:notes:48]
In August 2018, the FASB issued ASU 2018-15, "Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Customer's Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract" ("ASU 2018-15"), which clarifies that implementation costs incurred by customers in cloud computing arrangements are deferred if they would be capitalized by customers in software licensing arrangements under the internal-use software guidance. ASU 2018-15 is effective for annual and interim periods in fiscal years beginning after December 15, 2019, with early adoption permitted. Entities have the option to apply the guidance prospectively to all implementation costs incurred after the date of adoption or retrospectively. The Company is evaluating the full effect that ASU 2018-15 will have on its condensed consolidated financial statements and the timing of adoption.

[0001032975-18-000048:notes:49]
[same as prior period, unchanged from 0001032975-18-000037:notes:43]

[0001032975-18-000048:notes:50]
[same as prior period, unchanged from 0001032975-18-000037:notes:44]

[0001032975-18-000048:notes:51]
[same as prior period, unchanged from 0001032975-18-000037:notes:45]

[0001032975-18-000048:notes:52]
Substantially all revenue recognized by the Company relates to the contracts with customers to sell products that allow people to connect through music, gaming, video, computing, and other digital platforms. These products are hardware devices, which may include embedded software, and these functions together are considered as one performance obligation. Hardware devices are generally plug and play, requiring no configuration and little or no installation. Revenue is recognized at a point in time when control of the products is transferred to the customer which generally occurs upon shipment. The Company’s contracts with its customers generally have a term of no more than one year. The Company applies the practical expedient of not disclosing the value of unsatisfied performance obligations for contracts with an original expected length of one year or less.

[0001032975-18-000048:notes:53]
The Company also provides post-contract customer support (“PCS”) for products and related software, which includes unspecified software updates and upgrades, bug fixes and maintenance. The transaction price is allocated to two performance obligations in such contracts, based on a relative standalone selling price. The transaction price allocated to PCS is recognized as revenue on a straight-line basis over the estimated term of the support, which is between one to two years, and is not material for the periods presented herein. Deferred revenue associated with remaining PCS performance obligation is not material as of September 30, 2018 and March 31, 2018.

[0001032975-18-000048:notes:54]
The Company normally requires payments from customers within thirty to sixty days from invoice date. However, terms may vary by customer type, by country and by selling season. Extended payment terms are sometimes offered to a limited number of customers during the second and third fiscal quarters. The Company does not modify payment terms on existing receivables. The Company's contracts with customers typically do not include significant financing components as the period between the satisfaction of performance obligations and timing of payment are generally within one year.

[0001032975-18-000048:notes:55]
The transaction price received by the Company from sales to its distributors, retail companies ("retailers"), and authorized resellers is calculated as selling price net of variable consideration which may include product returns, price protection, and the Company’s payments for Customer Programs related to current period product revenue. The estimated impact of these programs is recorded as a reduction of sales or as an operating expense if the Company receives a distinct good or service from the customer and can reasonably estimate the fair value of that good or service received. Significant management judgment and estimates are used to determine the impact of these programs in any accounting period. Certain Customer Programs require management to estimate the percentage of those programs which will not be claimed or will not be earned by customers based on historical experience and on the specific terms and conditions of particular programs. The percentage of these customer programs that will not be claimed or earned is commonly referred to as "breakage". The Company accounts for breakage as part of variable consideration, subject to constraint, and records the estimated impact in the same period when revenue is recognized at the expected value considering constraints. Significant management judgments and estimates are used to determine the breakage of the programs in any accounting period.

[0001032975-18-000048:notes:56]
[same as prior period, unchanged from 0001032975-18-000037:notes:50]

[0001032975-18-000048:notes:57]
[same as prior period, unchanged from 0001032975-18-000037:notes:51]

[0001032975-18-000048:notes:58]
[same as prior period, unchanged from 0001032975-18-000037:notes:52]

[0001032975-18-000048:notes:59]
[same as prior period, unchanged from 0001032975-18-000037:notes:53]

[0001032975-18-000048:notes:60]
Product return rights vary by customer. Estimates of expected future product returns qualify as variable consideration and are recorded as a reduction of the transaction price of the contract at the time of sale based on analyses of historical return trends by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information. The Company assesses the estimated returned asset value for impairment, and adjusts the value of the asset if it becomes impaired. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time but are sufficiently predictable to allow the Company to estimate expected future product returns.

[0001032975-18-000048:notes:61]
Typically, variable consideration does not need to be constrained as estimates are based on predictive historical data or future commitments that are planned and controlled by the Company. However, the Company continues to assess variable consideration estimates such that it is probable that a significant reversal of revenue will not occur.

[0001032975-18-000048:notes:62]
[same as prior period, unchanged from 0001032975-18-000037:notes:56]

[0001032975-18-000048:notes:63]
Sales taxes and value added taxes (“VAT”) collected from customers, if applicable, which are remitted to governmental authorities are not included in revenue, and are reflected as a liability on the condensed consolidated balance sheets. The Company has elected to exclude sales taxes from the revenue recognized from contracts with customers.

[0001032975-18-000048:notes:64]
[same as prior period, unchanged from 0001032975-18-000037:notes:58]

[0001032975-18-000048:notes:65]
[same as prior period, unchanged from 0001032975-18-000037:notes:59]

[0001032975-18-000048:notes:66]
[same as prior period, unchanged from 0001032975-18-000037:notes:60]

[0001032975-18-000048:notes:67]
[same as prior period, unchanged from 0001032975-18-000037:notes:61]

[0001032975-18-000048:notes:68]
[same as prior period, unchanged from 0001032975-18-000037:notes:62]

[0001032975-18-000048:notes:69]
As of September 30, 2018 and for the period then ended, and as of April 1, 2018, the Company did not have any material contract liabilities balances or changes.

[0001032975-18-000048:notes:70]
[same as prior period, unchanged from 0001032975-18-000037:notes:64]

[0001032975-18-000048:notes:71]
The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that otherwise would have been recognized is one year or less. These costs are included in marketing and selling expenses in the condensed consolidated statements of operations. As of September 30, 2018 and for the period then ended, and as of April 1, 2018, the Company did not have material deferred contract costs or changes.

[0001032975-18-000048:notes:72]
[same as prior period, unchanged from 0001032975-18-000037:notes:66]

[0001032975-18-000048:notes:73]
[same as prior period, unchanged from 0001032975-18-000037:notes:67]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001032975-18-000048:notes:74]
Blue Microphones Acquisition

[0001032975-18-000048:notes:75]
On August 21, 2018 (the "Acquisition Date"), the Company acquired all equity interests in Blue Microphones Holding Corporation ("Blue Microphones") for a total consideration of $134.9 million in cash (the "Blue Microphones Acquisition"), which includes a working capital adjustment and repayment of debt on behalf of Blue Microphones.

[0001032975-18-000048:notes:76]
Blue Microphones is a leading audio manufacturer that designs and produces microphones, headphones, recording tools, and accessories for audio professionals, musicians and consumers. The Blue Microphones Acquisition is consistent with Logitech's merger and acquisition strategy and will supplement the Company's portfolio opportunities.

[0001032975-18-000048:notes:77]
Blue Microphones meets the definition of a business, and therefore the acquisition is accounted for using the acquisition method. The following table summarizes the preliminary estimated fair values of the assets acquired and liabilities assumed at the Acquisition Date (in thousands):

[0001032975-18-000048:notes:78]
|  |  | Estimated Fair Value |
| Cash and cash equivalents |  | $ | 1,110 |  |
| Accounts receivable |  | 10,979 |  |
| Inventories |  | 20,206 |  |
| Other current assets |  | 997 |  |
| Property, plant and equipment |  | 1,103 |  |
| Intangible assets |  | 53,267 |  |
| Total identifiable assets acquired |  | $ | 87,662 |  |
| Accounts payable |  | (10,322 | ) |
| Accrued liabilities |  | (13,316 | ) |
| Other long-term liabilities |  | (271 | ) |
| Net identifiable assets acquired |  | $ | 63,753 |  |
| Goodwill |  | 71,116 |  |
| Net assets acquired |  | $ | 134,869 |  |

[0001032975-18-000048:notes:79]
Goodwill related to the acquisition is primarily attributable to opportunities and economies of scale from combining the operations and technologies of Logitech and Blue Microphones and is not deductible for tax purposes.

[0001032975-18-000048:notes:80]
The fair value of the inventory acquired is estimated at its net realizable value, which uses the estimated selling prices, less the cost of disposal and a reasonable profit allowance for the selling efforts. The difference between the fair value of the inventories and the amount recorded by Blue Microphones immediately before the acquisition date is $1.8 million, which will be recognized in "amortization of intangibles assets and purchase accounting effect on inventory" in the condensed consolidated statements of operations upon the sale of the acquired inventory.

[0001032975-18-000048:notes:81]
The following table summarizes the preliminary estimated fair values and estimated useful lives of the components of identifiable intangible assets acquired as of the Acquisition Date (Dollars in thousands):

[0001032975-18-000048:notes:82]
|  | Preliminary Fair Value |  | Estimated Useful Life (years) |
| Developed technology | $ | 17,967 |  |  | 5.0 |
| Customer relationships | 22,800 |  |  | 10.0 |
| Trade name | 12,500 |  |  | 7.0 |
| Total intangible assets acquired | $ | 53,267 |  |  | 7.6 |

[0001032975-18-000048:notes:83]
Intangible assets acquired as a result of the Blue Microphones Acquisition are being amortized over their estimated useful lives using the straight-line method of amortization, which materially approximates the distribution of the economic value of the identified intangible assets. Amortization of acquired developed technology of $0.2 million during the three months ended September 30, 2018 is included in "amortization of intangible assets and purchase accounting effect of inventory" in the condensed consolidated statements of operations. Amortization of the acquired customer relationships and trade name of $0.3 million during the three months ended September 30, 2018 is included in "amortization of intangible assets and acquisition-related costs" in the condensed consolidated statements of operations.

[0001032975-18-000048:notes:84]
Developed technology relates to existing Blue Microphones products. The economic useful life was determined based on the technology cycle related to developed technology of existing products, as well as the cash flows anticipated over the forecasted periods.

[0001032975-18-000048:notes:85]
Customer relationships represent the fair value of future projected revenue that will be derived from sales of products to existing customers of Blue Microphones. The economic useful life was determined based on historical customer turnover rates and industry benchmarks.

[0001032975-18-000048:notes:86]
Trade name relates to the “Blue Microphones” trade name. The economic useful life was determined based on the expected life of the trade name and the cash flows anticipated over the forecasted periods.

[0001032975-18-000048:notes:87]
The fair values of developed technology and trade name were estimated using the relief-from-royalty method, an income approach (Level 3), which estimates the cost savings that accrue to the owner of the intangible assets that would otherwise be payable as royalties or license fees on revenues earned through the use of the asset. A royalty rate is applied to the projected revenues associated with the intangible assets to determine the amount of savings, which is then discounted to determine the fair value. The developed technology and trade name were valued using royalty rates of 10% and 3%, respectively, and both were discounted at a rate of 11%.

[0001032975-18-000048:notes:88]
The fair value of customer relationships was estimated using the excess earnings method, an income approach (Level 3), which converts projected revenues and costs into cash flows. To reflect the fact that certain other assets contributed to the cash flows generated, the returns for these contributory assets were removed to arrive at estimated cash flows solely attributable to the customer relationships, which were discounted at a rate of 11%.

[0001032975-18-000048:notes:89]
The Company believes the preliminary fair values of purchased intangible assets recorded above represents their fair values and approximates the amounts a market participant would pay for these intangible assets as of the Acquisition Date.

[0001032975-18-000048:notes:90]
The fair value of identifiable intangible assets acquired was based on estimates and assumptions made by management at the time of the acquisition. As additional information becomes available, such as finalization of the estimated fair value of the assets acquired and liabilities assumed, and working capital adjustments that may affect the total consideration transferred, the Company may revise its preliminary estimates of fair values during the remainder of the measurement periods (which will not exceed 12 months from the Acquisition Date). Any such revisions or changes may be material as we finalize the fair values of the tangible and intangible assets acquired and liabilities assumed.

[0001032975-18-000048:notes:91]
The Company incurred acquisition-related costs for the Blue Microphones Acquisition of approximately $1.5 million for the three months ended September 30, 2018. The acquisition-related costs are included in "amortization of intangible assets and acquisition-related costs" in the condensed consolidated statements of operations.

[0001032975-18-000048:notes:92]
The Company included Blue Microphones' estimated fair value of assets acquired and liabilities assumed in its condensed consolidated balance sheet beginning on the Acquisition Date. The results of operations for Blue Microphones subsequent to the Acquisition Date have been included in, but are not material to, the Company's condensed consolidated statements of operations. Pro forma results of operations for the Blue Microphones Acquisition have not been presented because they are not material to the condensed consolidated statements of operations. For the three months ended September 30, 2018, Blue Microphones, the acquisition of which was closed on August 21, 2018, contributed $7.7 million to net sales, representing approximately 1% of the net sales of the Company for the three-month period.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-18-000048:notes:93]
Commitments and Contingencies

[0001032975-18-000048:notes:94]
Product Warranties

[0001032975-18-000048:notes:95]
All of the Company's products are covered by warranty to be free from defects in material and workmanship for periods ranging from one year to five years. The Company’s warranty doesn’t provide a service beyond assuring that the product complies with agreed-upon specifications and is not sold separately. The warranty the Company provides qualifies as an assurance warranty and is not treated as a separate performance obligation. The Company estimates cost of product warranties at the time the related revenue is recognized based on historical warranty claim rates, historical costs, and knowledge of specific product failures that are outside of the Company's typical experience. The Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. Each quarter, the Company reevaluates estimates to assess the adequacy of recorded warranty liabilities considering the size of the installed base of products subject to warranty protection and adjusts the amounts as necessary. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly. If actual product failure rates or repair costs differ from estimates, revisions to the estimated warranty liabilities would be required and could materially affect the Company's results of operations.

[0001032975-18-000048:notes:96]
Changes in the Company’s warranty liability for the three and six months ended September 30, 2018 and 2017 were as follows (in thousands):

[0001032975-18-000048:notes:97]
|  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Beginning of the period | $ | 28,853 |  |  | $ | 22,056 |  |  | $ | 27,573 |  |  | $ | 21,911 |  |
| Assumed from business acquisition | 351 |  |  | 1,230 |  |  | 351 |  |  | 1,230 |  |
| Provision | 11,020 |  |  | 5,414 |  |  | 19,320 |  |  | 9,715 |  |
| Settlements | (8,330 | ) |  | (4,611 | ) |  | (14,882 | ) |  | (9,179 | ) |
| Currency translation | (140 | ) |  | 260 |  |  | (608 | ) |  | 672 |  |
| End of the period | $ | 31,754 |  |  | $ | 24,349 |  |  | $ | 31,754 |  |  | $ | 24,349 |  |

[0001032975-18-000048:notes:98]
Guarantees

[0001032975-18-000048:notes:99]
Logitech Europe S.A., one of the Company's wholly-owned subsidiaries, guaranteed payments of certain third-party contract manufacturers’ purchase obligations. As of September 30, 2018, the maximum amount of this guarantee was $3.8 million, of which $1.5 million of guaranteed purchase obligations were outstanding.

[0001032975-18-000048:notes:100]
Indemnifications

[0001032975-18-000048:notes:101]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2018, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-18-000048:notes:102]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-18-000048:notes:103]
Legal Proceedings

[0001032975-18-000048:notes:104]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-18-000048:notes:105]
[same as prior period, unchanged from 0001032975-18-000037:notes:81]

[0001032975-18-000048:notes:106]
[same as prior period, unchanged from 0001032975-18-000037:notes:82]

[0001032975-18-000048:notes:107]
As of September 30, 2018, the Company offers the 2006 ESPP (2006 Employee Share Purchase Plan (Non-U.S.)), the 1996 ESPP (1996 Employee Share Purchase Plan (U.S.)), the 2006 Plan (2006 Stock Incentive Plan) and the 2012 Plan (2012 Stock Inducement Equity Plan), each as amended.

[0001032975-18-000048:notes:108]
The following table summarizes the share-based compensation expense and total income tax benefit recognized for share-based awards for the three and six months ended September 30, 2018 and 2017 (in thousands):

[0001032975-18-000048:notes:109]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Cost of goods sold |  | $ | 791 |  |  | $ | 1,091 |  |  | $ | 1,921 |  |  | $ | 1,802 |  |
| Marketing and selling |  | 4,864 |  |  | 4,343 |  |  | 10,650 |  |  | 8,724 |  |
| Research and development |  | 1,935 |  |  | 1,633 |  |  | 3,484 |  |  | 3,176 |  |
| General and administrative |  | 4,459 |  |  | 3,911 |  |  | 9,253 |  |  | 7,981 |  |
| Total share-based compensation expense |  | 12,049 |  |  | 10,978 |  |  | 25,308 |  |  | 21,683 |  |
| Income tax benefit |  | (2,650 | ) |  | (3,677 | ) |  | (12,179 | ) |  | (14,959 | ) |
| Total share-based compensation expense, net of income tax |  | $ | 9,399 |  |  | $ | 7,301 |  |  | $ | 13,129 |  |  | $ | 6,724 |  |

[0001032975-18-000048:notes:110]
[same as prior period, unchanged from 0001032975-18-000037:notes:86]

[0001032975-18-000048:notes:111]
As of September 30, 2018 and 2017, the balances of capitalized share-based compensation included in inventory were both $0.8 million.

[0001032975-18-000048:notes:112]
[same as prior period, unchanged from 0001032975-18-000037:notes:88]

[0001032975-18-000048:notes:113]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The cost recorded of $2.2 million and $2.3 million for the three months ended September 30, 2018 and 2017, respectively, and $4.5 million and $4.6 million for the six months ended September 30, 2018 and 2017, respectively, was primarily related to service costs.


## us-gaap:DebtDisclosureTextBlock

[0001032975-18-000048:notes:114]
Financing Arrangements

[0001032975-18-000048:notes:115]
The Company had several uncommitted, unsecured bank lines of credit aggregating $79.3 million as of September 30, 2018. There are no financial covenants under these lines of credit with which the Company must comply. As of September 30, 2018, the Company had outstanding bank guarantees of $26.3 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of September 30, 2018 or March 31, 2018.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-18-000048:notes:116]
[same as prior period, unchanged from 0001032975-18-000037:notes:92]

[0001032975-18-000048:notes:117]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis on the condensed consolidated balance sheets as of September 30, 2018 and March 31, 2018.

[0001032975-18-000048:notes:118]
The fair values of the Company’s derivative instruments were not material as of September 30, 2018 or March 31, 2018. The amount of gain (loss) recognized on derivatives not designated as hedging instruments was not material in all periods presented herein. The following table presents the amounts of gains (losses) on the Company’s derivative instruments designated as hedging instruments and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income for the three and six months ended September 30, 2018 and 2017 (in thousands):

[0001032975-18-000048:notes:119]
|  |  | Three Months EndedSeptember 30, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Cash flow hedges |  | $ | 298 |  |  | $ | (2,140 | ) |  | $ | 218 |  |  | $ | 2,596 |  |

[0001032975-18-000048:notes:120]
|  |  | Six Months EndedSeptember 30, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Cash flow hedges |  | $ | 485 |  |  | $ | (5,349 | ) |  | $ | 3,069 |  |  | $ | 3,129 |  |

[0001032975-18-000048:notes:121]
Upon adoption of ASU 2017-12, the Company has started presenting the earnings impact from forward points in the same line item that is used to present the earnings impact of the hedged item, i.e. cost of goods sold, for hedging forecasted inventory purchases and such amount is not material for all periods presented.

[0001032975-18-000048:notes:122]
[same as prior period, unchanged from 0001032975-18-000037:notes:99]

[0001032975-18-000048:notes:123]
The Company enters into cash flow hedge contracts to protect against exchange rate exposure of forecasted inventory purchases. These hedging contracts mature within four months. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Cash flows from such hedges are classified as operating activities in the condensed consolidated statements of cash flows.  Hedging relationships are discontinued when hedging contract is no longer eligible for hedge accounting, or is sold, terminated or exercised, or when Company removes hedge designation for the contract. Gains and losses in the fair value of the effective portion of the discontinued hedges continue to be reported in accumulated other comprehensive loss until the hedged inventory purchases are sold, unless it is probable that the forecasted inventory purchases will not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. In all periods presented herein, there have been no forecasted inventory purchases that were probable to not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. The notional amounts of foreign currency exchange forward contracts outstanding related to forecasted inventory purchases were $89.1 million as of September 30, 2018. As of March 31, 2018, there were no currency forward contracts outstanding related to forecasted inventory purchases. The Company had $0.3 million of net gains related to its cash flow hedges included in accumulated other comprehensive loss as of September 30, 2018 which will be reclassified into earnings within the next 12 months.

[0001032975-18-000048:notes:124]
[same as prior period, unchanged from 0001032975-18-000037:notes:101]

[0001032975-18-000048:notes:125]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are recognized in other income (expense), net in the condensed consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of September 30, 2018 and March 31, 2018 were $71.5 million and $47.2 million, respectively. Open forward and swap contracts outstanding as of September 30, 2018 and March 31, 2018 consisted of contracts in Mexican Pesos, Japanese Yen, Canadian Dollars, Taiwan New Dollars and Australian Dollars to be settled at future dates at pre-determined exchange rates.

[0001032975-18-000048:notes:126]
[same as prior period, unchanged from 0001032975-18-000037:notes:103]


## us-gaap:EarningsPerShareTextBlock

[0001032975-18-000048:notes:127]
[same as prior period, unchanged from 0001032975-18-000037:notes:104]

[0001032975-18-000048:notes:128]
[same as prior period, unchanged from 0001032975-18-000037:notes:105]

[0001032975-18-000048:notes:129]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net income |  | $ | 64,176 |  |  | $ | 56,358 |  |  | $ | 102,642 |  |  | $ | 93,365 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 165,630 |  |  | 164,120 |  |  | 165,474 |  |  | 163,765 |  |
| Effect of potentially dilutive equivalent shares |  | 3,604 |  |  | 4,958 |  |  | 3,522 |  |  | 4,945 |  |
| Weighted average shares outstanding - diluted |  | 169,234 |  |  | 169,078 |  |  | 168,996 |  |  | 168,710 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.39 |  |  | $ | 0.34 |  |  | $ | 0.62 |  |  | $ | 0.57 |  |
| Diluted |  | $ | 0.38 |  |  | $ | 0.33 |  |  | $ | 0.61 |  |  | $ | 0.55 |  |

[0001032975-18-000048:notes:130]
Share equivalents attributable to outstanding stock options, restricted stock units ("RSUs") and ESPP totaling 0.8 million and 0.6 million for the three months ended September 30, 2018 and 2017, respectively, and 1.2 million and 1.2 million for the six months ended September 30, 2018 and 2017, respectively, were excluded from the calculation of diluted net income per share because the combined exercise price and average unamortized grant date fair value upon exercise of these options and ESPP or vesting of RSUs were greater than the average market price of the Company's shares during the periods presented herein, and therefore their inclusion would have been anti-dilutive.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-18-000048:notes:131]
[same as prior period, unchanged from 0001032975-18-000037:notes:108]

[0001032975-18-000048:notes:132]
[same as prior period, unchanged from 0001032975-18-000037:notes:109]

[0001032975-18-000048:notes:133]
[same as prior period, unchanged from 0001032975-18-000037:notes:110]

[0001032975-18-000048:notes:134]
[same as prior period, unchanged from 0001032975-18-000037:notes:111]

[0001032975-18-000048:notes:135]
[same as prior period, unchanged from 0001032975-18-000037:notes:112]

[0001032975-18-000048:notes:136]
[same as prior period, unchanged from 0001032975-18-000037:notes:113]

[0001032975-18-000048:notes:137]
|  |  | September 30, 2018 |  | March 31, 2018 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 304,627 |  |  | $ | — |  |  | $ | — |  |  | $ | 492,535 |  |  | $ | — |  |  | $ | — |  |
| Trading investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 4,252 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,881 |  |  | $ | — |  |  | $ | — |  |
| Mutual funds |  | 16,393 |  |  | — |  |  | — |  |  | 14,867 |  |  | — |  |  | — |  |
| Total of trading investments for deferred compensation plan |  | $ | 20,645 |  |  | $ | — |  |  | $ | — |  |  | $ | 17,748 |  |  | $ | — |  |  | $ | — |  |
| Currency exchange derivative assetsincluded in other current assets |  | $ | — |  |  | $ | 244 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Currency exchange derivative liabilitiesincluded in accrued and other current liabilities |  | $ | — |  |  | $ | 50 |  |  | $ | — |  |  | $ | — |  |  | $ | 34 |  |  | $ | — |  |

[0001032975-18-000048:notes:138]
[same as prior period, unchanged from 0001032975-18-000037:notes:115]

[0001032975-18-000048:notes:139]
The marketable securities for the Company's deferred compensation plan were recorded at a fair value of $20.6 million and $17.7 million, as of September 30, 2018 and March 31, 2018, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized trading gains (losses) related to trading securities for the three and six months ended September 30, 2018 and 2017 were not material and are included in other income (expense), net in the Company's condensed consolidated statements of operations.

[0001032975-18-000048:notes:140]
[same as prior period, unchanged from 0001032975-18-000037:notes:117]

[0001032975-18-000048:notes:141]
The Company has certain non-marketable investments included in other assets that are accounted for under the equity method of accounting, with carrying value of $5.8 million and $5.1 million as of September 30, 2018 and March 31, 2018, respectively.

[0001032975-18-000048:notes:142]
In addition, the Company has certain investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with a same or similar security from the same issuer. The amount of these investments included in other assets as of September 30, 2018 and March 31, 2018 was $7.5 million and $7.3 million, respectively.

[0001032975-18-000048:notes:143]
[same as prior period, unchanged from 0001032975-18-000037:notes:120]

[0001032975-18-000048:notes:144]
The Company’s non-financial assets, such as intangible assets and acquisition-related property, plant and equipment, are recorded at fair value only upon initial recognition or if an impairment is recognized. There was no impairment of these assets during the three and six months ended September 30, 2018 or 2017.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-18-000048:notes:145]
[same as prior period, unchanged from 0001032975-18-000037:notes:122]

[0001032975-18-000048:notes:146]
The Company conducts its impairment analysis of goodwill annually at December 31 and as necessary, if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting units may be less than its carrying amount. There have been no events or circumstances during the six months ended September 30, 2018 that have required the Company to perform an interim assessment of goodwill.

[0001032975-18-000048:notes:147]
The following table summarizes the activities in the Company’s goodwill balance during the six months ended September 30, 2018 (in thousands):

[0001032975-18-000048:notes:148]
| As of March 31, 2018 |  | $ | 275,451 |  |
| Acquisition (Note 2) |  | 71,116 |  |
| Currency translation |  | (19 | ) |
| As of September 30, 2018 |  | $ | 346,548 |  |

[0001032975-18-000048:notes:149]
[same as prior period, unchanged from 0001032975-18-000037:notes:126]

[0001032975-18-000048:notes:150]
|  |  | September 30, 2018 |  | March 31, 2018 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademark and trade names |  | $ | 36,370 |  |  | $ | (11,199 | ) |  | $ | 25,171 |  |  | $ | 23,870 |  |  | $ | (9,482 | ) |  | $ | 14,388 |  |
| Developed technology |  | 95,207 |  |  | (55,722 | ) |  | 39,485 |  |  | 77,175 |  |  | (50,755 | ) |  | 26,420 |  |
| Customer contracts/relationships |  | 82,310 |  |  | (16,428 | ) |  | 65,882 |  |  | 59,510 |  |  | (12,771 | ) |  | 46,739 |  |
| Total |  | $ | 213,887 |  |  | $ | (83,349 | ) |  | $ | 130,538 |  |  | $ | 160,555 |  |  | $ | (73,008 | ) |  | $ | 87,547 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-18-000048:notes:151]
[same as prior period, unchanged from 0001032975-18-000037:notes:128]

[0001032975-18-000048:notes:152]
[same as prior period, unchanged from 0001032975-18-000037:notes:129]

[0001032975-18-000048:notes:153]
The Company has not adjusted the net provisional charge from remeasuring deferred tax assets related to the Tax Cuts and Jobs Act (the "Tax Act") in the United States in fiscal year 2018. The Company continues to refine the estimate based on ongoing analysis and available information and interpretations through the third quarter of fiscal year 2019.

[0001032975-18-000048:notes:154]
The income tax provision for the three months ended September 30, 2018 was $6.2 million based on an effective income tax rate of 8.8% of pre-tax income, compared to an income tax provision of $4.1 million based on an effective income tax rate of 6.8% of pre-tax income for the three months ended September 30, 2017. The income tax provision for the six months ended September 30, 2018 was $1.0 million based on an effective income tax rate of 1.0% of pre-tax income, compared to an income tax benefit of $1.3 million based on an effective income tax rate of (1.5)% of pre-tax income for the six months ended September 30, 2017.

[0001032975-18-000048:notes:155]
The changes in the effective income tax rate for the three and six months ended September 30, 2018, compared to the three and six months ended September 30, 2017, were primarily due to the mix of income and losses in the various tax jurisdictions which the Company operates and less excess tax benefits recognized in the United States in the three and six months ended September 30, 2018. The Company recognized excess tax benefits of $0.7 million and $9.0 million, respectively, at 21% federal corporate income tax rate post the Tax Act in the three and six months ended September 30, 2018. In the same periods in fiscal year 2018, the Company recognized $1.1 million and $11.0 million of excess tax benefits, respectively, at 35% federal corporate income tax rate, after adoption of ASU 2016-09. In the three and six months ended September 30, 2018, there were discrete tax benefits of $0.5 million and $1.4 million, respectively, from the reversal of uncertain tax positions from the expiration of statutes of limitations. In the same periods ended September 30, 2017, the tax benefits from reversal of uncertain tax positions from the expiration of statutes of limitations were $0.7 million and $1.3 million, respectively.

[0001032975-18-000048:notes:156]
As of September 30, 2018 and March 31, 2018, the total amount of unrecognized tax benefits due to uncertain tax positions was $70.4 million and $69.1 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-18-000048:notes:157]
As of September 30, 2018 and March 31, 2018, the Company had $34.5 million and $35.0 million, respectively, in non-current income taxes payable including interest and penalties, related to the Company's income tax liability for uncertain tax positions.

[0001032975-18-000048:notes:158]
The Company recognizes interest and penalties related to unrecognized tax positions in income tax expense. As of September 30, 2018 and March 31, 2018, the Company had $2.5 million and $2.3 million, respectively, of accrued interest and penalties related to uncertain tax positions.

[0001032975-18-000048:notes:159]
[same as prior period, unchanged from 0001032975-18-000037:notes:136]


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001032975-18-000048:notes:160]
[same as prior period, unchanged from 0001032975-18-000037:notes:137]

[0001032975-18-000048:notes:161]
|  |  | September 30, 2018 |  | March 31, 2018 |
| Americas |  | $ | 33,508 |  |  | $ | 35,404 |  |
| EMEA |  | 4,327 |  |  | 4,690 |  |
| Asia Pacific |  | 45,896 |  |  | 46,210 |  |
| Total property, plant and equipment, net |  | $ | 83,731 |  |  | $ | 86,304 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001032975-18-000048:notes:162]
[same as prior period, unchanged from 0001032975-18-000037:notes:139]

[0001032975-18-000048:notes:163]
During the first quarter of fiscal year 2019, the Company implemented a restructuring plan to streamline and realign the Company's overall organizational structure and reallocate resources to support long-term growth opportunities. In July 2018, the Company's Board of Directors approved to allow additional costs under this restructuring plan, totaling pre-tax charges of approximately $10.0 million to $15.0 million, of which $10.0 million was recognized during the first half of fiscal year 2019. The total charges consisted of cash severance and other personnel costs and are presented as restructuring charges (credit), net in the condensed consolidated statements of operations, and the accrual balances are presented in accrued and other current liabilities in the condensed consolidated balance sheets. The Company expects to substantially complete this restructuring within the next six to nine months.

[0001032975-18-000048:notes:164]
The following table summarizes restructuring related activities during the three and six months ended September 30, 2018 (in thousands):

[0001032975-18-000048:notes:165]
|  |  | TerminationBenefits |
| Accrual balance at March 31, 2018 |  | $ | — |  |
| Charges |  | 9,921 |  |
| Cash payments |  | (2,014 | ) |
| Accrual balance at June 30, 2018 |  | 7,907 |  |
| Charges |  | 119 |  |
| Cash payments |  | (1,945 | ) |
| Accrual balance at September 30, 2018 |  | $ | 6,081 |  |


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001032975-18-000048:notes:166]
Net sales by geographic region (based on the customers’ locations) for the three and six months ended September 30, 2018 and 2017 were as follows (in thousands):

[0001032975-18-000048:notes:167]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Americas |  | $ | 283,714 |  |  | $ | 261,993 |  |  | $ | 560,642 |  |  | $ | 507,393 |  |
| EMEA |  | 218,300 |  |  | 218,323 |  |  | 378,932 |  |  | 368,914 |  |
| Asia Pacific |  | 189,132 |  |  | 152,154 |  |  | 360,052 |  |  | 286,109 |  |
| Total net sales |  | $ | 691,146 |  |  | $ | 632,470 |  |  | $ | 1,299,626 |  |  | $ | 1,162,416 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001032975-18-000048:notes:168]
[same as prior period, unchanged from 0001032975-18-000037:notes:145]

[0001032975-18-000048:notes:169]
|  |  | Accumulated Other Comprehensive Income (Loss) |
|  |  | CumulativeTranslationAdjustment (1) |  | DefinedBenefitPlan (1) |  | Deferred Hedging Losses (1) |  | Total |
| March 31, 2018 |  | $ | (83,848 | ) |  | $ | (6,398 | ) |  | $ | (3,209 | ) |  | $ | (93,455 | ) |
| Other comprehensive income (loss) |  | (7,826 | ) |  | (41 | ) |  | 3,554 |  |  | (4,313 | ) |
| September 30, 2018 |  | $ | (91,674 | ) |  | $ | (6,439 | ) |  | $ | 345 |  |  | $ | (97,768 | ) |

[0001032975-18-000048:notes:170]
(1)        Tax effect was not significant as of September 30 or March 31, 2018.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001032975-18-000048:notes:171]
Net sales by product categories and sales channels, excluding intercompany transactions, for the three and six months ended September 30, 2018 and 2017 were as follows (in thousands):

[0001032975-18-000048:notes:172]
|  |  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Pointing Devices |  | $ | 128,337 |  |  | $ | 123,643 |  |  | $ | 256,127 |  |  | $ | 245,717 |  |
| Keyboards & Combos |  | 131,872 |  |  | 119,200 |  |  | 260,094 |  |  | 235,313 |  |
| PC Webcams |  | 28,221 |  |  | 27,466 |  |  | 57,895 |  |  | 53,091 |  |
| Tablet & Other Accessories |  | 36,710 |  |  | 30,784 |  |  | 69,146 |  |  | 54,002 |  |
| Video Collaboration |  | 57,176 |  |  | 46,139 |  |  | 115,968 |  |  | 81,756 |  |
| Mobile Speakers |  | 77,100 |  |  | 90,548 |  |  | 111,427 |  |  | 153,466 |  |
| Audio & Wearables |  | 61,560 |  |  | 62,445 |  |  | 113,714 |  |  | 112,647 |  |
| Gaming |  | 160,792 |  |  | 113,722 |  |  | 296,818 |  |  | 191,430 |  |
| Smart Home |  | 9,241 |  |  | 18,323 |  |  | 18,252 |  |  | 34,789 |  |
| Other (1) |  | 137 |  |  | 200 |  |  | 185 |  |  | 205 |  |
| Total net sales |  | $ | 691,146 |  |  | $ | 632,470 |  |  | $ | 1,299,626 |  |  | $ | 1,162,416 |  |

[0001032975-18-000048:notes:173]
[same as prior period, unchanged from 0001032975-18-000037:notes:150]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-18-000048:notes:174]
[same as prior period, unchanged from 0001032975-18-000037:notes:151]

[0001032975-18-000048:notes:175]
The Company has determined that it operates in a single operating segment that encompasses the design, manufacturing and marketing of peripherals for PCs, tablets and other digital platforms. Operating performance measures are provided directly to the Company's CEO, who is considered to be the Company’s Chief Operating Decision Maker. The CEO periodically reviews information such as net sales and adjusted operating income (loss) to make business decisions. These operating performance measures do not include restructuring charges (credits), net, share-based compensation expense, amortization of intangible assets, charges from the purchase accounting effect on inventory, acquisition-related costs, change in fair value of contingent consideration from business acquisition, or gain (loss) from investments in privately held companies.

[0001032975-18-000048:notes:176]
[same as prior period, unchanged from 0001032975-18-000037:notes:153]

[0001032975-18-000048:notes:177]
The United States and Germany each represented more than 10% of the total consolidated net sales for each of the periods presented herein. China represented more than 10% of the total consolidated net sales for the three and six months ended September 30, 2018. No other countries represented 10% or more of the Company’s total consolidated net sales for the periods presented herein.

[0001032975-18-000048:notes:178]
Switzerland, the Company’s home domicile, represented 4% and 3% of the Company's total consolidated net sales for the three and six months ended September 30, 2018, respectively, and 2% for each of the three and six months ended September 30, 2017.

[0001032975-18-000048:notes:179]
[same as prior period, unchanged from 0001032975-18-000037:notes:156]

[0001032975-18-000048:notes:180]
Property, plant and equipment, net in the United States and China were $33.5 million and $38.2 million, respectively, as of September 30, 2018, and $35.3 million and $37.9 million, respectively, as of March 31, 2018. No other countries represented more than 10% of the Company’s total consolidated property, plant and equipment, net as of September 30, 2018 or March 31, 2018. Property, plant and equipment, net in Switzerland, the Company’s home domicile, were $1.6 million and $1.9 million as of September 30, 2018 and March 31, 2018, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-18-000048:notes:181]
[same as prior period, unchanged from 0001032975-18-000037:notes:158]

[0001032975-18-000048:notes:182]
[same as prior period, unchanged from 0001032975-18-000037:notes:159]

[0001032975-18-000048:notes:183]
In March 2017, the Company's Board of Directors approved the 2017 share buyback program, which authorizes the Company to use up to $250.0 million to purchase up to 17.3 million shares of its own shares. The Company's share buyback program is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. As of September 30, 2018, $200.0 million is still available for repurchase under the 2017 buyback program.

[0001032975-18-000048:notes:184]
Cash Dividend on Shares of Common

[0001032975-18-000048:notes:185]
During the three and six months ended September 30, 2018, the Company declared and paid cash dividends of CHF 0.67 (USD equivalent of $0.69) per common share, totaling $114.0 million on the Company's outstanding common stock. During the three and six months ended September 30, 2017, the Company declared and paid cash dividends of CHF 0.61 (USD equivalent of $0.63) per common share, totaling $104.2 million on the Company's outstanding common stock.

[0001032975-18-000048:notes:186]
Any future dividends will be subject to the approval of the Company's shareholders.

[0001032975-18-000048:notes:187]
Additional Authorized and Conditional Shares

[0001032975-18-000048:notes:188]
The Company has reserved conditional capital of 25,000,000 shares for potential issuance on the exercise of rights granted under the Company's employee equity incentive plans and additional conditional capital for financing purposes, representing the issuance of up to 25,000,000 shares to cover any conversion rights under a future convertible bond issuance. During the 2018 Annual General Meeting, the shareholders of the Company authorized the Board of Directors to issue up to an additional 34,621,324 shares of the Company until September 5, 2020.

[0001032975-18-000048:notes:189]
[same as prior period, unchanged from 0001032975-18-000037:notes:161]


## us-gaap:SubsequentEventsTextBlock

[0001032975-18-000048:notes:190]
Subsequent Event


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-18-000048:notes:191]
[same as prior period, unchanged from 0001032975-18-000037:notes:164]
