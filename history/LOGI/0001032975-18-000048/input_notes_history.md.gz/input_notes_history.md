# LOGI note change history — 0001032975-18-000037 → 0001032975-18-000048


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-10-25):
[0001032975-18-000048:note_history:1]
All of the Company's products are covered by warranty to be free from defects in material and workmanship for periods ranging from one year to five years. The Company’s warranty doesn’t provide a service beyond assuring that the product complies with agreed-upon specifications and is not sold separately. The warranty the Company provides qualifies as an assurance warranty and is not treated as a separate performance obligation. The Company estimates cost of product warranties at the time the related revenue is recognized based on historical warranty claim rates, historical costs, and knowledge of specific product failures that are outside of the Company's typical experience. The Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. Each quarter, the Company reevaluates estimates to assess the adequacy of recorded warranty liabilities considering the size of the installed base of products subject to warranty protection and adjusts the amounts as necessary. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly. If actual product failure rates or repair costs differ from estimates, revisions to the estimated warranty liabilities would be required and could materially affect the Company's results of operations.
  (was, 2018-08-02, similarity 0.9785):
[0001032975-18-000037:note_history:1]
All of the Company's products are covered by warranty to be free from defects in material and workmanship for periods ranging from one year to five years. The Company’s warranty doesn’t provide a service beyond assuring that the product complies with agreed-upon specifications and is not sold separately. The warranty the Company provides qualify as assurance warranty and not treated as a separate performance obligation. The Company estimates cost of product warranties at the time the related revenue is recognized based on historical warranty claim rates, historical costs, and knowledge of specific product failures that are outside of the Company's typical experience. The Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. Each quarter, the Company reevaluates estimates to assess the adequacy of recorded warranty liabilities considering the size of the installed base of products subject to warranty protection and adjusts the amounts as necessary. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly. If actual product failure rates or repair costs differ from estimates, revisions to the estimated warranty liabilities would be required and could materially affect the Company's results of operations.

- changed (2018-10-25):
[0001032975-18-000048:note_history:2]
Changes in the Company’s warranty liability for the three and six months ended September 30, 2018 and 2017 were as follows (in thousands):
  (was, 2018-08-02, similarity 0.9231):
[0001032975-18-000037:note_history:2]
Changes in the Company’s warranty liability for the three months ended June 30, 2018 and 2017 were as follows (in thousands):

- added (2018-10-25):
[0001032975-18-000048:note_history:3]
|  | Three Months EndedSeptember 30, |  | Six Months EndedSeptember 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Beginning of the period | $ | 28,853 |  |  | $ | 22,056 |  |  | $ | 27,573 |  |  | $ | 21,911 |  |
| Assumed from business acquisition | 351 |  |  | 1,230 |  |  | 351 |  |  | 1,230 |  |
| Provision | 11,020 |  |  | 5,414 |  |  | 19,320 |  |  | 9,715 |  |
| Settlements | (8,330 | ) |  | (4,611 | ) |  | (14,882 | ) |  | (9,179 | ) |
| Currency translation | (140 | ) |  | 260 |  |  | (608 | ) |  | 672 |  |
| End of the period | $ | 31,754 |  |  | $ | 24,349 |  |  | $ | 31,754 |  |  | $ | 24,349 |  |

- added (2018-10-25):
[0001032975-18-000048:note_history:4]
Logitech Europe S.A., one of the Company's wholly-owned subsidiaries, guaranteed payments of certain third-party contract manufacturers’ purchase obligations. As of September 30, 2018, the maximum amount of this guarantee was $3.8 million, of which $1.5 million of guaranteed purchase obligations were outstanding.

- changed (2018-10-25):
[0001032975-18-000048:note_history:5]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2018, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2018-08-02, similarity 0.9899):
[0001032975-18-000037:note_history:5]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2018, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

- removed (2018-10-25):
[0001032975-18-000037:note_history:6]
|  |  | Three Months EndedJune 30, |
|  |  | 2018 |  | 2017 |
| Beginning of the period |  | $ | 27,573 |  |  | $ | 21,911 |  |
| Provision |  | 7,364 |  |  | 5,124 |  |
| Settlements |  | (6,552 | ) |  | (4,567 | ) |
| Currency translation |  | 468 |  |  | (412 | ) |
| End of the period |  | $ | 28,853 |  |  | $ | 22,056 |  |

- removed (2018-10-25):
[0001032975-18-000037:note_history:7]
Logitech Europe S.A., one of the Company's wholly-owned subsidiaries, guaranteed payments of certain third-party contract manufacturers’ purchase obligations. As of June 30, 2018, the maximum amount of this guarantee was $3.8 million, of which $1.2 million of guaranteed purchase obligations were outstanding.

- removed (2018-10-25):
[0001032975-18-000037:note_history:8]
The Stock Purchase Agreement that the Company entered into in connection with the investment by three venture capital firms in Lifesize, Inc. contains representations, warranties and covenants of Logitech and Lifesize, Inc. to the Venture Investors. Subject to certain limitations, the Company has agreed to indemnify the Venture Investors and certain persons related to the Venture Investors for certain losses resulting from breaches of or inaccuracies in such representations, warranties and covenants as well as certain other obligations, including third-party expenses, restructuring costs and pre-closing tax obligations of Lifesize.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-10-25):
[0001032975-18-000048:note_history:9]
The Company sells its products to a broad network of domestic and international customers, including direct sales to retailers and e-tailers and indirect sales through distributors.
  (was, 2018-08-02, similarity 0.9861):
[0001032975-18-000037:note_history:9]
The Company sells its products to a broad network of domestic and international customers, including direct sales to retailers, e-tailers and indirect sales through distributors.

- added (2018-10-25):
[0001032975-18-000048:note_history:10]
Business Acquisition

- added (2018-10-25):
[0001032975-18-000048:note_history:11]
In August 2018, the Company acquired Blue Microphones Holding Corporation. See "Note 2 - Business Acquisition" for more information.

- changed (2018-10-25):
[0001032975-18-000048:note_history:12]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and six months ended September 30, 2018 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2019, or any future periods.
  (was, 2018-08-02, similarity 0.7702):
[0001032975-18-000037:note_history:12]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three months ended June 30, 2018 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2019, or any future periods.

- changed (2018-10-25):
[0001032975-18-000048:note_history:13]
Certain amounts from the comparative period in the accompanying condensed consolidated financial statements have been reclassified to conform to the condensed consolidated financial statement presentation as of and for the three and six months ended September 30, 2018.
  (was, 2018-08-02, similarity 0.9084):
[0001032975-18-000037:note_history:13]
Certain amounts from the comparative period in the accompanying condensed consolidated financial statements have been reclassified to conform to the condensed consolidated financial statement presentation as of and for the three months ended June 30, 2018.

- changed (2018-10-25):
[0001032975-18-000048:note_history:14]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted and Summary of Significant Accounting Policies, there have been no changes in the Company’s significant accounting policies during the six months ended September 30, 2018 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2018.
  (was, 2018-08-02, similarity 0.941):
[0001032975-18-000037:note_history:14]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted and Summary of Significant Accounting Policies, there have been no changes in the Company’s significant accounting policies during the three months ended June 30, 2018 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2018.

- changed (2018-10-25):
[0001032975-18-000048:note_history:15]
The preparation of financial statements in conformity with GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill, intangible assets acquired from business acquisitions, warranty liabilities, accruals for customer incentives, cooperative marketing, and pricing programs ("Customer Programs") and related breakage when appropriate, accrued revenue reserve from returns, allowance for doubtful accounts, inventory valuation, contingent consideration from business acquisitions and periodical reassessment of its fair value, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from these estimates.
  (was, 2018-08-02, similarity 0.9987):
[0001032975-18-000037:note_history:15]
The preparation of financial statements in conformity with GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill, intangible assets acquired from business acquisitions, warranty liabilities, accruals for customer incentive, cooperative marketing, and pricing programs ("Customer Programs") and related breakage when appropriate, accrued revenue reserve from returns, allowance for doubtful accounts, inventory valuation, contingent consideration from business acquisitions and periodical reassessment of its fair value, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

- changed (2018-10-25):
[0001032975-18-000048:note_history:16]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers (Topic 606)" ("ASU 2014-09" or “Topic 606”) which supersedes the revenue recognition requirements under ASC 605 (“Topic 605”), Revenue Recognition. ASU 2014-09 outlines a new, single, comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes existing revenue recognition guidance, including industry-specific guidance. Under the new guidance, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The new standard requires reporting companies to disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. On April 1, 2018, the Company adopted the new standard and all related amendments using the modified retrospective method applied to those contracts which were not completed as of April 1, 2018. Results for reporting periods beginning after April 1, 2018 are presented under Topic 606, while prior period amounts are not adjusted and continue to be reported in accordance with historic accounting standards under Topic 605.
  (was, 2018-08-02, similarity 0.9959):
[0001032975-18-000037:note_history:16]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers (Topic 606)" ("ASU 2014-09" or “Topic 606”) which supersedes the revenue recognition requirements under ASC 605 (“Topic 605”), Revenue Recognition. ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes existing revenue recognition guidance, including industry-specific guidance. Under the new guidance, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The new standard requires reporting companies to disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. On April 1, 2018, the Company adopted the new standard and all related amendments using the modified retrospective method applied to those contracts which were not completed as of March 31, 2018. Results for reporting periods beginning after April 1, 2018 are presented under Topic 606, while prior period amounts are not adjusted and continue to be reported in accordance with historic accounting standards under Topic 605.

- changed (2018-10-25):
[0001032975-18-000048:note_history:17]
As result of the adoption of the new standard, the Company recorded: a) a reduction to retained earnings as of April 1, 2018; and b) reclassifications of certain allowances for sales returns and certain other Customer Programs from accounts receivable, net to accrued and other current liabilities and other current assets.
  (was, 2018-08-02, similarity 0.9921):
[0001032975-18-000037:note_history:17]
As result of the adoption of the new standard, the Company recorded: a) a reduction to retained earnings as of April 1, 2018; b) reclassification of certain allowances for sales returns and certain other Customer Programs from accounts receivable, net to accrued and other current liabilities and other current assets.

- changed (2018-10-25):
[0001032975-18-000048:note_history:18]
| • | Under Topic 605, accruals for certain Customer Programs were recognized as a reduction of revenue at the later of when the related revenue is recognized or when the program is offered to the customer. Under Topic 606, these programs qualify as variable consideration and are recorded as a reduction of the transaction price at the contract inception based on the expected value method. The Company is required to estimate the accruals for these programs ahead of commitment date if customary business practice creates an implied expectation that such activities will occur in the future. |
  (was, 2018-08-02, similarity 0.9888):
[0001032975-18-000037:note_history:18]
| • | Under Topic 605, accruals for certain Customer Programs were recognized as a reduction of revenue at the later of when the related revenue is recognized or when the program is offered to the customer. Under Topic 606, these programs qualify as variable consideration and are recorded as a reduction of the transaction price at the contract inception based on the expected value method. The Company is required to estimate for these programs ahead of commitment date if customary business practice creates an implied expectation that such activities will occur in the future. |

- changed (2018-10-25):
[0001032975-18-000048:note_history:19]
Balance Sheet Reclassifications
  (was, 2018-08-02, similarity 0.9836):
[0001032975-18-000037:note_history:19]
Balance Sheet Reclassification

- changed (2018-10-25):
[0001032975-18-000048:note_history:20]
| • | Under Topic 605, the gross amount of accrued revenue reserves for sales returns of $31.4 million, net of expected returned inventory of $11.4 million was included within accounts receivable, net as of March 31, 2018. Expected scrap cost of $5.2 million for such expected returned inventory was included in accrued and other current liabilities as of March 31, 2018. Subsequent to the adoption of Topic 606, such balances are presented on a gross basis as accrued revenue reserve from returns of $31.4 million included in accrued and other current liabilities and as return assets of $6.2 million included in other current assets. |
  (was, 2018-08-02, similarity 0.9967):
[0001032975-18-000037:note_history:20]
| • | Under Topic 605, gross amount of accrued revenue reserves for sales returns of $31.4 million, net of expected returned inventory of $11.4 million was included within accounts receivable, net as of March 31, 2018. Expected scrap cost of $5.2 million for such expected returned inventory was included in accrued and other current liabilities as of March 31, 2018. Subsequent to the adoption of Topic 606, such balances are presented on a gross basis as accrued revenue reserve from returns of $31.4 million included in accrued and other current liabilities and as return assets of $6.2 million included in other current assets. |

- changed (2018-10-25):
[0001032975-18-000048:note_history:21]
Certain balances of allowances for sales return and accruals for Customer Programs which were accrued based on Customer Program offers made to individual customers, met the right of offset criteria in accordance with ASC 210-20, "Balance Sheet (Topic 210)", and are still included within accounts receivable, net.
  (was, 2018-08-02, similarity 0.9984):
[0001032975-18-000037:note_history:21]
Certain balances of allowances for sales return and accruals for Customer Programs which were accrued based on Customer Program offers made to individual customer, met the right of offset criteria in accordance with ASC 210-20, "Balance Sheet (Topic 210)", and are still included within accounts receivable, net.

- changed (2018-10-25):
[0001032975-18-000048:note_history:22]
The following tables summarize the impacts of adopting Topic 606 on the Company’s condensed consolidated statements of operations for the three and six months ended September 30, 2018 and condensed consolidated balance sheet as of September 30, 2018 (in thousands):
  (was, 2018-08-02, similarity 0.6478):
[0001032975-18-000037:note_history:22]
The following tables summarize the impacts of adopting Topic 606 on the Company’s condensed consolidated statements of operations and balance sheets for the three months ended or as of June 30, 2018 (in thousands):

- added (2018-10-25):
[0001032975-18-000048:note_history:23]
|  | Three Months Ended September 30,2018 |  | Six Months Ended September 30, 2018 |
|  | As Reported Under ASC 606 | If Reported Under ASC 605 | Effect of Change |  | As Reported Under ASC 606 | If Reported Under ASC 605 | Effect of Change |
| Net sales | $ | 691,146 |  | $ | 696,090 |  | $ | (4,944 | ) |  | $ | 1,299,626 |  | $ | 1,304,704 |  | $ | (5,078 | ) |

- changed (2018-10-25):
[0001032975-18-000048:note_history:24]
|  |  | As of September 30,2018 |
|  |  | As Reported Under ASC 606 |  | Balance Under ASC 605 |  | Effect of Change |
| Accounts receivable, net |  | 459,689 |  |  | 327,131 |  |  | 132,558 |  |
| Other current assets |  | 70,412 |  |  | 61,092 |  |  | 9,320 |  |
| Accrued and other current liabilities |  | 434,615 |  |  | 276,777 |  |  | 157,838 |  |
| Retained earnings |  | 1,210,105 |  |  | 1,226,065 |  |  | (15,960 | ) |
  (was, 2018-08-02, similarity 0.6845):
[0001032975-18-000037:note_history:24]
|  |  | As Reported |  | If Reported Under Topic 605 |  | Effect of Adoption of Topic 606 |
| Net sales |  | $ | 608,480 |  |  | $ | 608,614 |  |  | $ | (134 | ) |
| Accounts receivable, net |  | 385,546 |  |  | 272,009 |  |  | 113,537 |  |
| Other current assets |  | 62,542 |  |  | 55,237 |  |  | 7,305 |  |
| Accrued and other current liabilities |  | 384,497 |  |  | 252,639 |  |  | 131,858 |  |
| Retained earnings |  | 1,259,900 |  |  | 1,270,916 |  |  | (11,016 | ) |

- changed (2018-10-25):
[0001032975-18-000048:note_history:25]
In October 2016, the FASB issued ASU 2016-16, "Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory" ("ASU 2016-16"), which eliminates the deferral of income tax effects of intra-entity asset transfers until the transferred asset is sold to an unrelated party or recovered through use. However, this standard does not apply to intra-entity transfer of inventory. The Company adopted this standard effective April 1, 2018 on a modified retrospective basis, and the adoption of ASU 2016-16 did not have a material impact on its condensed consolidated financial statements.
  (was, 2018-08-02, similarity 0.9991):
[0001032975-18-000037:note_history:25]
In October 2016, the FASB issued ASU 2016-16, "Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory" ("ASU 2016-16"), which eliminates the deferral of income tax effects of intra-entity asset transfers until the transferred asset is sold to an unrelated party or recovered through use. However, this standard does not apply to intra-entity transfer of inventory. The Company adopted this standard effective April 1, 2018 on a modified retrospective basis and the adoption of ASU 2016-10 did not have a material impact on its condensed consolidated financial statements.

- changed (2018-10-25):
[0001032975-18-000048:note_history:26]
In December 2016, the FASB issued ASU 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash" ("ASU 2016-18"), which requires that a statement of cash flows explains the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. The Company adopted this standard effective April 1, 2018, utilizing the retrospective transition method to each period presented and the adoption of ASU 2016-18 did not have an impact on its condensed consolidated financial statements as the Company did not have restricted cash for either periods presented.
  (was, 2018-08-02, similarity 0.8858):
[0001032975-18-000037:note_history:26]
In December 2016, the FASB issued ASU 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash" ("ASU 2016-18"), which requires that a statement of cash flows explains the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents. The Company adopted this standard effective April 1, 2018 utilizing the retrospective transition method to each period presented and the adoption of ASU 2016-18 did not have a material impact on its condensed consolidated financial statements. The Company did not have restricted cash for both periods presented.

- changed (2018-10-25):
[0001032975-18-000048:note_history:27]
In March 2017, the FASB issued ASU 2017-07, "Compensation-Retirement Benefit (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost" ("ASU 2017-07"), which requires that the Company disaggregate the service cost component from the other components of net benefit cost, and also provides guidance on how to present the service cost component and the other components of net benefit cost in the income statement and allow only the service cost component of net benefit cost to be eligible for capitalization. The Company adopted this standard effective April 1, 2018 using a retrospective adoption method. Other than the revised statement of operations presentation for the periods in the current year, the adoption of ASU 2017-07 did not have an impact on the Company’s condensed consolidated financial statements. The impact to the comparative period was immaterial and therefore the prior period statements of operations was not revised.
  (was, 2018-08-02, similarity 0.9627):
[0001032975-18-000037:note_history:27]
In March 2017, the FASB issued ASU 2017-07, "Compensation-Retirement Benefit (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost" ("ASU 2017-07"), which requires that the Company disaggregate the service cost component from the other components of net benefit cost, and also provides guidance on how to present the service cost component and the other components of net benefit cost in the income statement and allow only the service cost component of net benefit cost to be eligible for capitalization. The Company adopted this standard effective April 1, 2018 using a retrospective adoption method. Other than the revised statement of operations presentation for the current period, the adoption of ASU 2017-07 did not have an impact on the Company’s condensed consolidated financial statements. The impact to the comparative period was immaterial and therefore prior year statement of operations was not revised.

- added (2018-10-25):
[0001032975-18-000048:note_history:28]
In August 2017, the FASB issued ASU 2017-12, "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" ("ASU 2017-12"), which improves the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements and simplifies the application of the hedge accounting guidance. The Company adopted this standard prospectively on April 1, 2018, and the adoption of ASU 2017-12 did not have a material impact on its condensed consolidated financial statements. In accordance with ASU 2017-12, the Company has started presenting the earnings impact from forward points in cost of goods sold line item, which is used to present the earnings impact of the hedged item.

- added (2018-10-25):
[0001032975-18-000048:note_history:29]
In February 2016, the FASB issued ASU 2016-02, "Leases (Topic 842)" ("ASU 2016-02" or "Topic 842"), which generally requires companies to recognize right-of-use assets and lease liabilities arising from operating and financing leases with terms longer than 12 months in the consolidated balance sheets. The Company will adopt the new guidance in the first quarter of fiscal year 2020 on a modified retrospective basis, which recognizes the cumulative effect of initially applying Topic 842 as an adjustment to retained earnings at the adoption date. Although the Company expects to record significant amounts of right-of-use assets and liabilities on its condensed consolidated balance sheets, the Company is still evaluating the full impact that ASU 2016-02 will have on its condensed consolidated financial statements.

- added (2018-10-25):
[0001032975-18-000048:note_history:30]
In August 2018, the FASB issued ASU 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirements for Fair Value Measurements" ("ASU 2018-13"), which aims to improve the overall usefulness of disclosures to financial statement users and reduce unnecessary costs to companies when preparing fair value measurement disclosures. ASU 2018-13 is effective for annual and interim periods in fiscal years beginning after December 15, 2019. Early adoption is permitted. Retrospective adoption is required, except for certain disclosures which will be required to be applied prospectively for only the most recent interim or annual period presented in the initial fiscal year of adoption. The Company is evaluating the full effect that ASU 2018-13 will have on its condensed consolidated financial statements and the timing of adoption.

- added (2018-10-25):
[0001032975-18-000048:note_history:31]
In August 2018, the FASB issued ASU 2018-14, "Compensation - Retirement Benefits - Defined Benefits Plans - General (Subtopic 715-20): Disclosure Framework - Changes to the Disclosure Requirements for Defined Benefit Plans" ("ASU 2018-14"), which aims to improve the overall usefulness of disclosures to financial statement users and reduce unnecessary costs to companies when preparing defined benefit plan disclosures. ASU 2018-14 is effective for annual periods in fiscal years ending after December 15, 2021. Retrospective adoption is required and early adoption is permitted. The Company is evaluating the full effect that ASU 2018-14 will have on its condensed consolidated financial statements and the timing of adoption.

- added (2018-10-25):
[0001032975-18-000048:note_history:32]
In August 2018, the FASB issued ASU 2018-15, "Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Customer's Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract" ("ASU 2018-15"), which clarifies that implementation costs incurred by customers in cloud computing arrangements are deferred if they would be capitalized by customers in software licensing arrangements under the internal-use software guidance. ASU 2018-15 is effective for annual and interim periods in fiscal years beginning after December 15, 2019, with early adoption permitted. Entities have the option to apply the guidance prospectively to all implementation costs incurred after the date of adoption or retrospectively. The Company is evaluating the full effect that ASU 2018-15 will have on its condensed consolidated financial statements and the timing of adoption.

- added (2018-10-25):
[0001032975-18-000048:note_history:33]
Substantially all revenue recognized by the Company relates to the contracts with customers to sell products that allow people to connect through music, gaming, video, computing, and other digital platforms. These products are hardware devices, which may include embedded software, and these functions together are considered as one performance obligation. Hardware devices are generally plug and play, requiring no configuration and little or no installation. Revenue is recognized at a point in time when control of the products is transferred to the customer which generally occurs upon shipment. The Company’s contracts with its customers generally have a term of no more than one year. The Company applies the practical expedient of not disclosing the value of unsatisfied performance obligations for contracts with an original expected length of one year or less.

- added (2018-10-25):
[0001032975-18-000048:note_history:34]
The Company also provides post-contract customer support (“PCS”) for products and related software, which includes unspecified software updates and upgrades, bug fixes and maintenance. The transaction price is allocated to two performance obligations in such contracts, based on a relative standalone selling price. The transaction price allocated to PCS is recognized as revenue on a straight-line basis over the estimated term of the support, which is between one to two years, and is not material for the periods presented herein. Deferred revenue associated with remaining PCS performance obligation is not material as of September 30, 2018 and March 31, 2018.

- added (2018-10-25):
[0001032975-18-000048:note_history:35]
The Company normally requires payments from customers within thirty to sixty days from invoice date. However, terms may vary by customer type, by country and by selling season. Extended payment terms are sometimes offered to a limited number of customers during the second and third fiscal quarters. The Company does not modify payment terms on existing receivables. The Company's contracts with customers typically do not include significant financing components as the period between the satisfaction of performance obligations and timing of payment are generally within one year.

- changed (2018-10-25):
[0001032975-18-000048:note_history:36]
The transaction price received by the Company from sales to its distributors, retail companies ("retailers"), and authorized resellers is calculated as selling price net of variable consideration which may include product returns, price protection, and the Company’s payments for Customer Programs related to current period product revenue. The estimated impact of these programs is recorded as a reduction of sales or as an operating expense if the Company receives a distinct good or service from the customer and can reasonably estimate the fair value of that good or service received. Significant management judgment and estimates are used to determine the impact of these programs in any accounting period. Certain Customer Programs require management to estimate the percentage of those programs which will not be claimed or will not be earned by customers based on historical experience and on the specific terms and conditions of particular programs. The percentage of these customer programs that will not be claimed or earned is commonly referred to as "breakage". The Company accounts for breakage as part of variable consideration, subject to constraint, and records the estimated impact in the same period when revenue is recognized at the expected value considering constraints. Significant management judgments and estimates are used to determine the breakage of the programs in any accounting period.
  (was, 2018-08-02, similarity 0.9982):
[0001032975-18-000037:note_history:36]
The transaction price received by the Company from sales to its distributors, retail companies ("retailers"), and authorized resellers is calculated as selling price net of variable consideration which may include product returns, price protection, and Company’s payments for Customer Programs related to current period product revenue. The estimated impact of these programs is recorded as a reduction of sales or as an operating expense if the Company receives a distinct good or service from the customer and can reasonably estimate the fair value of that good or service received. Significant management judgment and estimates are used to determine the impact of these programs in any accounting period. Certain customer programs require management to estimate the percentage of those programs which will not be claimed or will not be earned by customers based on historical experience and on the specific terms and conditions of particular programs. The percentage of these customer programs that will not be claimed or earned is commonly referred to as "breakage". The Company accounts for breakage as part of variable consideration, subject to constraint and records the estimated impact in the same period when revenue is recognized at the expected value considering constraints. Significant management judgments and estimates are used to determine the breakage of the programs in any accounting period.

- changed (2018-10-25):
[0001032975-18-000048:note_history:37]
Product return rights vary by customer. Estimates of expected future product returns qualify as variable consideration and are recorded as a reduction of the transaction price of the contract at the time of sale based on analyses of historical return trends by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information. The Company assesses the estimated returned asset value for impairment, and adjusts the value of the asset if it becomes impaired. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time but are sufficiently predictable to allow the Company to estimate expected future product returns.
  (was, 2018-08-02, similarity 0.9469):
[0001032975-18-000037:note_history:37]
Product return rights vary by customer and range from the right to return defective products to stock rotation rights limited to a percentage of sales. Estimates of expected future product returns qualify as variable consideration and are recorded as a reduction of the transaction price of the contract at the time of sale based on analyses of historical return trends by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information. The Company assesses the estimated returned asset value for impairment, and adjusts the value of the asset if it becomes impaired. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time but are sufficiently predictable to allow the Company to estimate expected future product returns.

- added (2018-10-25):
[0001032975-18-000048:note_history:38]
Typically, variable consideration does not need to be constrained as estimates are based on predictive historical data or future commitments that are planned and controlled by the Company. However, the Company continues to assess variable consideration estimates such that it is probable that a significant reversal of revenue will not occur.

- added (2018-10-25):
[0001032975-18-000048:note_history:39]
Sales taxes and value added taxes (“VAT”) collected from customers, if applicable, which are remitted to governmental authorities are not included in revenue, and are reflected as a liability on the condensed consolidated balance sheets. The Company has elected to exclude sales taxes from the revenue recognized from contracts with customers.

- changed (2018-10-25):
[0001032975-18-000048:note_history:40]
As of September 30, 2018 and for the period then ended, and as of April 1, 2018, the Company did not have any material contract liabilities balances or changes.
  (was, 2018-08-02, similarity 0.814):
[0001032975-18-000037:note_history:40]
As of June 30, 2018 and April 1, 2018, the Company did not have any material contract liabilities balances or changes.

- changed (2018-10-25):
[0001032975-18-000048:note_history:41]
The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that otherwise would have been recognized is one year or less. These costs are included in marketing and selling expenses in the condensed consolidated statements of operations. As of September 30, 2018 and for the period then ended, and as of April 1, 2018, the Company did not have material deferred contract costs or changes.
  (was, 2018-08-02, similarity 0.9367):
[0001032975-18-000037:note_history:41]
The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that otherwise would have been recognized is one year or less. These costs are included in marketing and selling expenses in the condensed consolidated statements of operations. As of June 30, 2018 and April 1, 2018, the Company does not have material deferred contract costs or changes.

- removed (2018-10-25):
[0001032975-18-000037:note_history:42]
In August 2017, the FASB issued ASU 2017-12, "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" ("ASU 2017-12"), which improves the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements and simplifies the application of the hedge accounting guidance. The Company adopted this standard effective April 1, 2018 and the adoption of ASU 2017-12 did not have a material impact on its condensed consolidated financial statements. In accordance with ASC 815-20-45-1A, the Company has started presenting the earnings impact from forward points in the same line item that is used to present the earnings impact of the hedged item, i.e. Cost of goods sold for hedging forecasted inventory purchases.

- removed (2018-10-25):
[0001032975-18-000037:note_history:43]
In February 2016, the FASB issued ASU 2016-02, "Leases (Topic 842)" ("ASU 2016-02" or "Topic 842"), which generally requires companies to recognize right-of-use assets and lease liabilities arising from operating and financing leases with terms longer than 12 months in the consolidated balance sheets. This guidance will be effective for the Company in the first quarter of fiscal year 2020 on a modified retrospective basis and early adoption is permitted. The Company will adopt the new standard effective April 1, 2019. Although the Company expects to record significant amounts of right-of-use assets and liabilities on its consolidated balance sheets, the Company is still evaluating the full impact of adopting this guidance to determine the amounts and additional disclosures.

- removed (2018-10-25):
[0001032975-18-000037:note_history:44]
Substantially all revenue recognized by the Company relates to the contracts with customers to sell products that allow people to connect through music, gaming, video, computing, and other digital platforms. These products are hardware devices, which may include embedded software. Hardware devices are generally plug and play, requiring no configuration and little or no installation. Revenue is recognized at a point in time when control of the products is transferred to the customer which generally occurs upon shipment. The Company’s contracts with its customers generally have a term of no more than one year. The Company applies the practical expedient of not disclosing the value of unsatisfied performance obligations for contracts with an original expected length of one year or less.

- removed (2018-10-25):
[0001032975-18-000037:note_history:45]
The Company also provides post-contract customer support (“PCS”) for sold products and related software, which includes unspecified software updates and upgrades, bug fixes and maintenance. Revenue allocated to such PCS is recognized on a straight-line basis over the estimated term of the support, which is between 1 to 2 years, and not material for the periods presented herein. Deferred revenue associated with remaining PCS performance obligation is not material as of June 30, 2018 and March 31, 2018.

- removed (2018-10-25):
[0001032975-18-000037:note_history:46]
The Company normally requires payments from customers within 30-60 days from invoice date. However, terms may vary by customer type, by country and by selling season. Extended payment terms are sometimes offered to a limited number of customers during the second and third fiscal quarters. The Company does not modify payment terms on existing receivables. The Company's contracts with customers typically do not include significant financing components as the period between the transfer of performance obligations and timing of payment are generally within one year.

- removed (2018-10-25):
[0001032975-18-000037:note_history:47]
Typically variable consideration does not need to be constrained as estimates are based on predictive historical data or future commitments that are planned and controlled by the Company. However, the Company continues to assess variable consideration estimates such that it is probable that a significant reversal of revenue will not occur.

- removed (2018-10-25):
[0001032975-18-000037:note_history:48]
Sales taxes and value added taxes (“VAT”) collected from customers which are remitted to governmental authorities are not included in revenue, and are reflected as a liability on the condensed consolidated balance sheets. The Company has elected to exclude sales taxes from the revenue recognized from contracts with customers.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2018-10-25):
[0001032975-18-000048:note_history:49]
The Company had several uncommitted, unsecured bank lines of credit aggregating $79.3 million as of September 30, 2018. There are no financial covenants under these lines of credit with which the Company must comply. As of September 30, 2018, the Company had outstanding bank guarantees of $26.3 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of September 30, 2018 or March 31, 2018.

- removed (2018-10-25):
[0001032975-18-000037:note_history:50]
The Company had several uncommitted, unsecured bank lines of credit aggregating $81.8 million as of June 30, 2018. There are no financial covenants under these lines of credit with which the Company must comply. As of June 30, 2018, the Company had outstanding bank guarantees of $20.9 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of June 30, 2018 or March 31, 2018.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2018-10-25):
[0001032975-18-000048:note_history:51]
Substantially all revenue recognized by the Company relates to the contracts with customers to sell products that allow people to connect through music, gaming, video, computing, and other digital platforms. These products are hardware devices, which may include embedded software, and these functions together are considered as one performance obligation. Hardware devices are generally plug and play, requiring no configuration and little or no installation. Revenue is recognized at a point in time when control of the products is transferred to the customer which generally occurs upon shipment. The Company’s contracts with its customers generally have a term of no more than one year. The Company applies the practical expedient of not disclosing the value of unsatisfied performance obligations for contracts with an original expected length of one year or less.

- added (2018-10-25):
[0001032975-18-000048:note_history:52]
The Company also provides post-contract customer support (“PCS”) for products and related software, which includes unspecified software updates and upgrades, bug fixes and maintenance. The transaction price is allocated to two performance obligations in such contracts, based on a relative standalone selling price. The transaction price allocated to PCS is recognized as revenue on a straight-line basis over the estimated term of the support, which is between one to two years, and is not material for the periods presented herein. Deferred revenue associated with remaining PCS performance obligation is not material as of September 30, 2018 and March 31, 2018.

- added (2018-10-25):
[0001032975-18-000048:note_history:53]
The Company normally requires payments from customers within thirty to sixty days from invoice date. However, terms may vary by customer type, by country and by selling season. Extended payment terms are sometimes offered to a limited number of customers during the second and third fiscal quarters. The Company does not modify payment terms on existing receivables. The Company's contracts with customers typically do not include significant financing components as the period between the satisfaction of performance obligations and timing of payment are generally within one year.

- changed (2018-10-25):
[0001032975-18-000048:note_history:54]
The transaction price received by the Company from sales to its distributors, retail companies ("retailers"), and authorized resellers is calculated as selling price net of variable consideration which may include product returns, price protection, and the Company’s payments for Customer Programs related to current period product revenue. The estimated impact of these programs is recorded as a reduction of sales or as an operating expense if the Company receives a distinct good or service from the customer and can reasonably estimate the fair value of that good or service received. Significant management judgment and estimates are used to determine the impact of these programs in any accounting period. Certain Customer Programs require management to estimate the percentage of those programs which will not be claimed or will not be earned by customers based on historical experience and on the specific terms and conditions of particular programs. The percentage of these customer programs that will not be claimed or earned is commonly referred to as "breakage". The Company accounts for breakage as part of variable consideration, subject to constraint, and records the estimated impact in the same period when revenue is recognized at the expected value considering constraints. Significant management judgments and estimates are used to determine the breakage of the programs in any accounting period.
  (was, 2018-08-02, similarity 0.9982):
[0001032975-18-000037:note_history:54]
The transaction price received by the Company from sales to its distributors, retail companies ("retailers"), and authorized resellers is calculated as selling price net of variable consideration which may include product returns, price protection, and Company’s payments for Customer Programs related to current period product revenue. The estimated impact of these programs is recorded as a reduction of sales or as an operating expense if the Company receives a distinct good or service from the customer and can reasonably estimate the fair value of that good or service received. Significant management judgment and estimates are used to determine the impact of these programs in any accounting period. Certain customer programs require management to estimate the percentage of those programs which will not be claimed or will not be earned by customers based on historical experience and on the specific terms and conditions of particular programs. The percentage of these customer programs that will not be claimed or earned is commonly referred to as "breakage". The Company accounts for breakage as part of variable consideration, subject to constraint and records the estimated impact in the same period when revenue is recognized at the expected value considering constraints. Significant management judgments and estimates are used to determine the breakage of the programs in any accounting period.

- changed (2018-10-25):
[0001032975-18-000048:note_history:55]
Product return rights vary by customer. Estimates of expected future product returns qualify as variable consideration and are recorded as a reduction of the transaction price of the contract at the time of sale based on analyses of historical return trends by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information. The Company assesses the estimated returned asset value for impairment, and adjusts the value of the asset if it becomes impaired. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time but are sufficiently predictable to allow the Company to estimate expected future product returns.
  (was, 2018-08-02, similarity 0.9469):
[0001032975-18-000037:note_history:55]
Product return rights vary by customer and range from the right to return defective products to stock rotation rights limited to a percentage of sales. Estimates of expected future product returns qualify as variable consideration and are recorded as a reduction of the transaction price of the contract at the time of sale based on analyses of historical return trends by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information. The Company assesses the estimated returned asset value for impairment, and adjusts the value of the asset if it becomes impaired. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time but are sufficiently predictable to allow the Company to estimate expected future product returns.

- added (2018-10-25):
[0001032975-18-000048:note_history:56]
Typically, variable consideration does not need to be constrained as estimates are based on predictive historical data or future commitments that are planned and controlled by the Company. However, the Company continues to assess variable consideration estimates such that it is probable that a significant reversal of revenue will not occur.

- added (2018-10-25):
[0001032975-18-000048:note_history:57]
Sales taxes and value added taxes (“VAT”) collected from customers, if applicable, which are remitted to governmental authorities are not included in revenue, and are reflected as a liability on the condensed consolidated balance sheets. The Company has elected to exclude sales taxes from the revenue recognized from contracts with customers.

- changed (2018-10-25):
[0001032975-18-000048:note_history:58]
As of September 30, 2018 and for the period then ended, and as of April 1, 2018, the Company did not have any material contract liabilities balances or changes.
  (was, 2018-08-02, similarity 0.814):
[0001032975-18-000037:note_history:58]
As of June 30, 2018 and April 1, 2018, the Company did not have any material contract liabilities balances or changes.

- removed (2018-10-25):
[0001032975-18-000037:note_history:59]
Substantially all revenue recognized by the Company relates to the contracts with customers to sell products that allow people to connect through music, gaming, video, computing, and other digital platforms. These products are hardware devices, which may include embedded software. Hardware devices are generally plug and play, requiring no configuration and little or no installation. Revenue is recognized at a point in time when control of the products is transferred to the customer which generally occurs upon shipment. The Company’s contracts with its customers generally have a term of no more than one year. The Company applies the practical expedient of not disclosing the value of unsatisfied performance obligations for contracts with an original expected length of one year or less.

- removed (2018-10-25):
[0001032975-18-000037:note_history:60]
The Company also provides post-contract customer support (“PCS”) for sold products and related software, which includes unspecified software updates and upgrades, bug fixes and maintenance. Revenue allocated to such PCS is recognized on a straight-line basis over the estimated term of the support, which is between 1 to 2 years, and not material for the periods presented herein. Deferred revenue associated with remaining PCS performance obligation is not material as of June 30, 2018 and March 31, 2018.

- removed (2018-10-25):
[0001032975-18-000037:note_history:61]
The Company normally requires payments from customers within 30-60 days from invoice date. However, terms may vary by customer type, by country and by selling season. Extended payment terms are sometimes offered to a limited number of customers during the second and third fiscal quarters. The Company does not modify payment terms on existing receivables. The Company's contracts with customers typically do not include significant financing components as the period between the transfer of performance obligations and timing of payment are generally within one year.

- removed (2018-10-25):
[0001032975-18-000037:note_history:62]
Typically variable consideration does not need to be constrained as estimates are based on predictive historical data or future commitments that are planned and controlled by the Company. However, the Company continues to assess variable consideration estimates such that it is probable that a significant reversal of revenue will not occur.

- removed (2018-10-25):
[0001032975-18-000037:note_history:63]
Sales taxes and value added taxes (“VAT”) collected from customers which are remitted to governmental authorities are not included in revenue, and are reflected as a liability on the condensed consolidated balance sheets. The Company has elected to exclude sales taxes from the revenue recognized from contracts with customers.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- removed (2018-10-25):
[0001032975-18-000037:note_history:64]
On July 30, 2018, the Company signed an agreement to acquire all equity interests in Blue Microphones Holding Corporation for approximately $117 million in cash, assuming breakeven net working capital at close. Blue Microphones is a leader in studio-quality microphones for professionals and consumers. The Blue Microphones acquisition is consistent with Logitech's merger and acquisition strategy and will supplement the Company's portfolio opportunities. The transaction is expected to close in late August, 2018 and is subject to receipt of regulatory approvals in various jurisdictions and other closing conditions.
