# LOGI note change history — 0001032975-25-000008 → 0001032975-25-000059


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-07-30):
[0001032975-25-000059:note_history:1]
Changes in the Company’s warranty liabilities for the three months ended June 30, 2025 and 2024 were as follows (in thousands):
  (was, 2025-01-29, similarity 0.9243):
[0001032975-25-000008:note_history:1]
Changes in the Company’s warranty liabilities for the three and nine months ended December 31, 2024 and 2023 were as follows (in thousands):

- changed (2025-07-30):
[0001032975-25-000059:note_history:2]
|  | Three Months Ended June 30, |
|  | 2025 |  | 2024 |
| Beginning of the period | $ | 49,184 |  |  | $ | 44,654 |  |
| Provision | 8,622 |  |  | 10,186 |  |
| Settlements | (8,249) |  |  | (10,038) |  |
| Effects of foreign currency translation | 649 |  |  | (300) |  |
| End of the period | $ | 50,206 |  |  | $ | 44,502 |  |
  (was, 2025-01-29, similarity 0.6686):
[0001032975-25-000008:note_history:2]
|  | Three months ended December 31, |  | Nine months ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Beginning of the period | $ | 46,833 |  |  | $ | 40,265 |  |  | $ | 44,654 |  |  | $ | 40,886 |  |
| Provision | 12,060 |  |  | 11,249 |  |  | 34,022 |  |  | 30,734 |  |
| Settlements | (9,111) |  |  | (10,158) |  |  | (29,124) |  |  | (29,914) |  |
| Effects of foreign currency translation | (721) |  |  | 421 |  |  | (491) |  |  | 71 |  |
| End of the period | $ | 49,061 |  |  | $ | 41,777 |  |  | $ | 49,061 |  |  | $ | 41,777 |  |

- changed (2025-07-30):
[0001032975-25-000059:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2025, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2025-01-29, similarity 0.9805):
[0001032975-25-000008:note_history:3]
The Company indemnifies certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2024, no material amounts have been accrued for indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

- changed (2025-07-30):
[0001032975-25-000059:note_history:4]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.
  (was, 2025-01-29, similarity 0.984):
[0001032975-25-000008:note_history:4]
The Company also indemnifies its current and former directors and certain current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not capped, the obligations are conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-07-30):
[0001032975-25-000059:note_history:5]
Logitech International S.A., together with its consolidated subsidiaries ("Logitech" or the "Company"), designs software-enabled hardware solutions that help businesses thrive and bring people together when working, creating, and gaming. As the point of connection between people and the digital world, the Company's mission is to extend human potential in work and play, in a way that is good for people and the planet.
  (was, 2025-01-29, similarity 0.9717):
[0001032975-25-000008:note_history:5]
Logitech International S.A., together with its consolidated subsidiaries ("Logitech" or the "Company"), designs software-enabled hardware solutions that help businesses thrive and bring people together when working, creating, gaming and streaming. As a point of connection between people and the digital world, the Company's mission is to extend human potential in work and play, in a way that is good for people and the planet.

- changed (2025-07-30):
[0001032975-25-000059:note_history:6]
The Company sells its products to a broad range of international customers, including direct sales to retailers, e-tailers, businesses large and small and end consumers through the Company's e-commerce platform, and indirect sales to end customers through distributors.
  (was, 2025-01-29, similarity 0.6914):
[0001032975-25-000008:note_history:6]
The Company sells its products to a broad network of international customers, including direct sales to retailers, e-tailers and end consumers through the Company's e-commerce platform, and indirect sales to end customers through distributors.

- changed (2025-07-30):
[0001032975-25-000059:note_history:7]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three months ended June 30, 2025 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2026, or any future periods.
  (was, 2025-01-29, similarity 0.9573):
[0001032975-25-000008:note_history:7]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and nine months ended December 31, 2024 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2025, or any future periods.

- changed (2025-07-30):
[0001032975-25-000059:note_history:8]
There have been no material changes in the Company’s significant accounting policies during the three months ended June 30, 2025 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2025.
  (was, 2025-01-29, similarity 0.9091):
[0001032975-25-000008:note_history:8]
There have been no material changes in the Company’s significant accounting policies during the three and nine months ended December 31, 2024 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2024.

- changed (2025-07-30):
[0001032975-25-000059:note_history:9]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill and intangible assets acquired from business acquisitions, pension obligations, accruals for customer incentives, cooperative marketing, and pricing programs and related breakage when appropriate, inventory valuation, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.
  (was, 2025-01-29, similarity 0.9027):
[0001032975-25-000008:note_history:9]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill and intangible assets acquired from business acquisitions, valuation of investment in privately held companies classified under Level 3 fair value hierarchy, pension obligations, accruals for customer incentives, cooperative marketing, and pricing programs and related breakage when appropriate, inventory valuation, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

- added (2025-07-30):
[0001032975-25-000059:note_history:10]
In 2025, the United States introduced trade policy actions that have increased import tariffs across a wide range of countries at various rates, with certain exemptions. These tariff policies in the U.S. and responsive policies enacted in other countries are evolving. The incremental tariffs have had and may continue to have an adverse impact on the Company's result of operations. In addition, the Company's business has continued to be impacted by ongoing macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, uncertainty in consumer and enterprise demand, low economic growth in certain regions, changes in fiscal policies and geopolitical conflicts.

- added (2025-07-30):
[0001032975-25-000059:note_history:11]
The global and regional economic and political conditions, as well as changes in trade policies, have caused and may continue to cause volatility in demand for the Company's products as well as the cost of tariffs, materials and logistics, and transportation delays, and as a result have impacted and may continue to impact the pricing of the Company's products, product availability and the Company's results of operations.

- changed (2025-07-30):
[0001032975-25-000059:note_history:12]
New Accounting Pronouncements Not Yet Adopted
  (was, 2025-01-29, similarity 0.9247):
[0001032975-25-000008:note_history:12]
Recent Accounting Pronouncements Not Yet Adopted

- removed (2025-07-30):
[0001032975-25-000008:note_history:13]
The Company's business has continued to be impacted by macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, changes in fiscal policies, geopolitical conflicts, low economic growth in certain regions, and uncertainty in consumer and enterprise demand. In addition, the Company's business may be adversely impacted by the potential expansion of tariffs on goods imported into the U.S., as well as responsive or related policies enacted in other countries.

- removed (2025-07-30):
[0001032975-25-000008:note_history:14]
The global and regional economic and political conditions have caused and may continue to cause volatility in demand for the Company's products as well as the cost of materials and logistics, and transportation delays, and as a result may impact the pricing of the Company's products, product availability and the Company's results of operations.

- removed (2025-07-30):
[0001032975-25-000008:note_history:15]
In November 2023, the Financial Accounting Standard Board ("FASB") issued Accounting Standards Update ("ASU") 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures. ASU 2023-07 improves reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses that are regularly provided to the chief operating decision maker. In addition, ASU 2023-07 requires that all existing annual disclosures about segment profit or loss must be provided on an interim basis and clarifies that single reportable segment entities are subject to the disclosure requirement under Topic 280 in its entirety. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 and interim periods within those fiscal years beginning after December 15, 2024. A public entity should apply ASU 2023-07 retrospectively to all prior periods presented in the financial statements. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2023-07 on its consolidated financial statements and related disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-07-30):
[0001032975-25-000059:note_history:16]
The Credit Agreement contains a maximum net debt to adjusted EBITDA ratio, compliance with which is a condition to the Company's ability to borrow. Borrowings under the Credit Agreement will bear interest at a rate determined by reference to benchmark rates plus an applicable spread (ranging from 0% to 1.5%) based on the
  (was, 2025-01-29, similarity 0.6484):
[0001032975-25-000008:note_history:16]
The Credit Agreement contains a maximum net debt to adjusted EBITDA ratio, compliance with which is a condition to the Company's ability to borrow. Borrowings under the Credit Agreement will bear interest at a rate determined by reference to benchmark rates plus an applicable spread (ranging from 0% to 1.5%) based on the Company's net leverage ratio or credit rating at the time of the borrowing. Undrawn balances available under the Credit Agreement are subject to commitment fees at the applicable rate determined by reference to the Company's net leverage ratio or credit rating. There has been no borrowing outstanding under the Credit Agreement as of January 29, 2025.

- added (2025-07-30):
[0001032975-25-000059:note_history:17]
Company's net leverage ratio or credit rating at the time of the borrowing. Undrawn balances available under the Credit Agreement are subject to commitment fees at the applicable rate determined by reference to the Company's net leverage ratio or credit rating. There has been no borrowing outstanding under the Credit Agreement as of June 30, 2025.
In addition, the Company had several uncommitted, unsecured bank lines of credit and letters of credit aggregating to $174.3 million and $172.2 million as of June 30, 2025 and March 31, 2025, respectively. There are no financial covenants under the lines of credit with which the Company must comply. There was no borrowing outstanding under the lines of credit as of June 30, 2025 or March 31, 2025. As of June 30, 2025 and March 31, 2025, the Company had outstanding bank guarantees of $22.1 million and $12.1 million, respectively.

- removed (2025-07-30):
[0001032975-25-000008:note_history:18]
The Company had several uncommitted, unsecured bank lines of credit and letters of credit aggregating $171.3 million and $172.5 million as of December 31, 2024 and March 31, 2024, respectively. There are no financial covenants under the lines of credit with which the Company must comply. There was no borrowing outstanding under the lines of credit as of December 31, 2024 or March 31, 2024. As of December 31, 2024 and March 31, 2024, the Company had outstanding bank guarantees of $27.7 million and $14.3 million, respectively.
