# LOGI notes — 0001032975-25-000059


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-25-000059:notes:1]
[same as prior period, unchanged from 0001032975-25-000008:notes:1]

[0001032975-25-000059:notes:2]
Logitech International S.A., together with its consolidated subsidiaries ("Logitech" or the "Company"), designs software-enabled hardware solutions that help businesses thrive and bring people together when working, creating, and gaming. As the point of connection between people and the digital world, the Company's mission is to extend human potential in work and play, in a way that is good for people and the planet.

[0001032975-25-000059:notes:3]
The Company sells its products to a broad range of international customers, including direct sales to retailers, e-tailers, businesses large and small and end consumers through the Company's e-commerce platform, and indirect sales to end customers through distributors.

[0001032975-25-000059:notes:4]
[same as prior period, unchanged from 0001032975-25-000008:notes:4]

[0001032975-25-000059:notes:5]
[same as prior period, unchanged from 0001032975-25-000008:notes:5]

[0001032975-25-000059:notes:6]
The condensed consolidated financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States ("U.S. GAAP") for interim financial information and therefore do not include all the information required by U.S. GAAP for complete financial statements. The condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2025, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission ("SEC") on May 23, 2025.

[0001032975-25-000059:notes:7]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three months ended June 30, 2025 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2026, or any future periods.

[0001032975-25-000059:notes:8]
[same as prior period, unchanged from 0001032975-25-000008:notes:8]

[0001032975-25-000059:notes:9]
There have been no material changes in the Company’s significant accounting policies during the three months ended June 30, 2025 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2025.

[0001032975-25-000059:notes:10]
[same as prior period, unchanged from 0001032975-25-000008:notes:10]

[0001032975-25-000059:notes:11]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill and intangible assets acquired from business acquisitions, pension obligations, accruals for customer incentives, cooperative marketing, and pricing programs and related breakage when appropriate, inventory valuation, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

[0001032975-25-000059:notes:12]
[same as prior period, unchanged from 0001032975-25-000008:notes:12]

[0001032975-25-000059:notes:13]
[same as prior period, unchanged from 0001032975-25-000008:notes:13]

[0001032975-25-000059:notes:14]
In 2025, the United States introduced trade policy actions that have increased import tariffs across a wide range of countries at various rates, with certain exemptions. These tariff policies in the U.S. and responsive policies enacted in other countries are evolving. The incremental tariffs have had and may continue to have an adverse impact on the Company's result of operations. In addition, the Company's business has continued to be impacted by ongoing macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, uncertainty in consumer and enterprise demand, low economic growth in certain regions, changes in fiscal policies and geopolitical conflicts.

[0001032975-25-000059:notes:15]
The global and regional economic and political conditions, as well as changes in trade policies, have caused and may continue to cause volatility in demand for the Company's products as well as the cost of tariffs, materials and logistics, and transportation delays, and as a result have impacted and may continue to impact the pricing of the Company's products, product availability and the Company's results of operations.

[0001032975-25-000059:notes:16]
New Accounting Pronouncements Not Yet Adopted

[0001032975-25-000059:notes:17]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. ASU 2023-09 requires additional disclosures related to rate reconciliation, income taxes paid, and other disclosures. Under ASU 2023-09, for each annual period presented, public entities are required to (1) disclose specific categories in the tabular rate reconciliation and (2) provide additional information for reconciling items that meet a quantitative threshold. In addition, ASU 2023-09 requires all reporting entities to disclose on an annual basis the amount of income taxes paid disaggregated by federal, state, and foreign taxes as well as the amount of income taxes paid by individual jurisdiction. ASU 2023-09 is effective for public business entities for annual periods beginning after December 15, 2024 and can be applied on a prospective basis with an option to apply the standard retrospectively. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2023-09 on its consolidated financial statements and related disclosures.

[0001032975-25-000059:notes:18]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses. ASU 2024-03 requires all public entities to disclose in the notes to the financial statements the amounts of purchases of inventory, employee compensation, depreciation, and intangible asset amortization included in each expense caption of the income statement. ASU 2024-03 is effective for fiscal years beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027. ASU 2024-03 can be applied either prospectively or retrospectively. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2024-03 on its consolidated financial statements and related disclosures.


## us-gaap:EarningsPerShareTextBlock

[0001032975-25-000059:notes:19]
[same as prior period, unchanged from 0001032975-25-000008:notes:20]

[0001032975-25-000059:notes:20]
The following table summarizes the computations of basic and diluted net income per share for the three months ended June 30, 2025 and 2024 (in thousands except per share amounts):

[0001032975-25-000059:notes:21]
|  |  | Three Months Ended June 30, |
|  |  | 2025 |  | 2024 |
| Net income |  | $ | 146,015 |  |  | $ | 141,833 |  |
| Shares used in net income per share computation: |  |  |  |  |
| Weighted average shares outstanding - basic |  | 147,864 |  |  | 153,300 |  |
| Effect of potentially dilutive equivalent shares |  | 1,189 |  |  | 1,678 |  |
| Weighted average shares outstanding - diluted |  | 149,053 |  |  | 154,978 |  |
| Net income per share: |  |  |  |  |
| Basic |  | $ | 0.99 |  |  | $ | 0.93 |  |
| Diluted |  | $ | 0.98 |  |  | $ | 0.92 |  |

[0001032975-25-000059:notes:22]
Share equivalents attributable to outstanding stock options, restricted stock units, and employee share purchase plans totaling 1.6 million and 1.1 million for the three months ended June 30, 2025 and 2024, respectively, were excluded from the calculation of diluted net income per share because their effect would have been antidilutive. A small number of performance-based restricted stock units were not included in the dilutive net income per share calculation because all necessary conditions had not been satisfied by the end of the respective period, and those shares were not issuable if the end of the reporting period were the end of the performance contingency period.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-25-000059:notes:23]
[same as prior period, unchanged from 0001032975-25-000008:notes:24]

[0001032975-25-000059:notes:24]
[same as prior period, unchanged from 0001032975-25-000008:notes:25]

[0001032975-25-000059:notes:25]
As of June 30, 2025, the Company offers the 2006 Employee Share Purchase Plan (Non-U.S.), as amended and restated, the 1996 Employee Share Purchase Plan (U.S.), as amended and restated, and the 2006 Stock Incentive Plan, as amended and restated. Shares issued to employees as a result of purchases or exercises under these plans are generally issued from shares held in treasury stock.

[0001032975-25-000059:notes:26]
The following table summarizes share-based compensation expense and total income tax benefit recognized for the three months ended June 30, 2025 and 2024 (in thousands):

[0001032975-25-000059:notes:27]
|  |  | Three Months Ended June 30, |
|  |  | 2025 |  | 2024 |
| Cost of goods sold |  | $ | 2,380 |  |  | $ | 2,598 |  |
| Marketing and selling |  | 13,930 |  |  | 11,851 |  |
| Research and development |  | 6,351 |  |  | 5,739 |  |
| General and administrative |  | 10,167 |  |  | 3,217 |  |
| Total share-based compensation expense |  | 32,828 |  |  | 23,405 |  |
| Income tax benefit |  | (4,906) |  |  | (7,602) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 27,922 |  |  | $ | 15,803 |  |

[0001032975-25-000059:notes:28]
The income tax benefit in the respective periods primarily consisted of tax benefits related to the share-based compensation expense for the period and direct tax benefit realized, including net excess tax benefits recognized from share-based awards vested or exercised during the period.

[0001032975-25-000059:notes:29]
Share-based compensation costs capitalized as part of inventory were $2.8 million and $2.5 million for the three months ended June 30, 2025 and 2024, respectively.

[0001032975-25-000059:notes:30]
[same as prior period, unchanged from 0001032975-25-000008:notes:31]

[0001032975-25-000059:notes:31]
Certain subsidiaries of the Company sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The costs of $1.7 million recorded for each of the three months ended June 30, 2025 and 2024 were primarily related to service costs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-25-000059:notes:32]
[same as prior period, unchanged from 0001032975-25-000008:notes:33]

[0001032975-25-000059:notes:33]
The Company is incorporated in Switzerland but operates in various countries with differing tax laws and rates. Further, a portion of the Company’s income before taxes and the provision for income taxes is generated outside of Switzerland.

[0001032975-25-000059:notes:34]
The income tax provision for the three months ended June 30, 2025 was $28.5 million based on an effective income tax rate of 16.3% of pre-tax income. The income tax provision for the same period ended June 30, 2024 was $25.6 million based on an effective income tax rate of 15.3% of pre-tax income.

[0001032975-25-000059:notes:35]
The change in the effective income tax rate for the three months ended June 30, 2025, compared with the three months ended June 30, 2024, was primarily due to the change in the mix of income and losses in the various tax jurisdictions in which the Company operates, less tax incentives for foreign derived intangible income and R&D as compared to prior period, and less benefit on stock based compensation as compared to prior period, offset with a change in uncertain tax positions.

[0001032975-25-000059:notes:36]
On July 4, 2025, the One Big Beautiful Bill Act (the "OBBBA") was enacted into law in the United States and will be generally effective for the Company beginning in fiscal year 2027. The OBBBA includes numerous provisions that affect corporate taxation, impacting areas such as R&D expensing, bonus depreciation, and international tax provisions. The Company has reviewed the provisions of the OBBBA to determine the potential impact on the Company's financial statements. Based on this review, and considering the Company's current tax position and operations, at this time the Company does not expect the OBBBA to have a material impact on its income taxes, including current and deferred tax balances and the effective tax rate. However, the Company is still in the process of evaluating the full impact of the OBBBA and any material changes to the Company's assessment will be disclosed in future filings as required.

[0001032975-25-000059:notes:37]
For the three months ended June 30, 2025, the Company assessed its exposure to the OECD Pillar Two global minimum tax rules. The Company has determined that, for the fiscal year 2026, most jurisdictions in which it operates should qualify for the transitional Country-by-Country Reporting ("CbCR") safe harbor, as outlined in the OECD Administrative Guidance and enacted domestic legislation. The Company's CbCR has been prepared in accordance with the requirements for a Qualified CbCR, using qualified financial statements. Based on this data, most jurisdictions continue to meet safe harbor qualifications at 16% tax rates, and therefore, the Company is only required to perform a detailed Pillar Two top-up tax calculation for limited jurisdictions. The estimated top up tax for fiscal year 2026 is not material and has been included in the calculation of the Company's annual effective tax rate. The OECD and participating countries continue to issue underlying rules and administrative guidance related to Pillar Two, and the Company continues to monitor the relevant developments.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-25-000059:notes:38]
[same as prior period, unchanged from 0001032975-25-000008:notes:42]

[0001032975-25-000059:notes:39]
[same as prior period, unchanged from 0001032975-25-000008:notes:43]

[0001032975-25-000059:notes:40]
|  |  | June 30, 2025 |  | March 31, 2025 |
| Accounts receivable, net: |  |  |  |  |
| Accounts receivable |  | $ | 920,172 |  |  | $ | 708,693 |  |
| Allowance for cooperative marketing arrangements |  | (45,679) |  |  | (44,457) |  |
| Allowance for customer incentive programs |  | (77,367) |  |  | (66,564) |  |
| Allowance for pricing programs |  | (120,165) |  |  | (105,876) |  |
| Other allowances |  | (40,438) |  |  | (37,250) |  |
|  |  | $ | 636,523 |  |  | $ | 454,546 |  |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 47,123 |  |  | $ | 48,699 |  |
| Finished goods |  | 452,647 |  |  | 455,048 |  |
|  |  | $ | 499,770 |  |  | $ | 503,747 |  |
| Other current assets: |  |  |  |  |
| Value-added tax ("VAT") receivables |  | $ | 41,556 |  |  | $ | 46,332 |  |
| Prepaid expenses and other assets |  | 112,550 |  |  | 84,879 |  |
|  |  | $ | 154,106 |  |  | $ | 131,211 |  |
| Property, plant and equipment, net: |  |  |  |  |
| Property, plant and equipment |  | $ | 562,038 |  |  | $ | 543,747 |  |
| Less: accumulated depreciation and amortization |  | (445,935) |  |  | (429,889) |  |
|  |  | $ | 116,103 |  |  | $ | 113,858 |  |
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 212,516 |  |  | $ | 202,180 |  |
| Right-of-use assets |  | 76,647 |  |  | 75,239 |  |
| Investments for deferred compensation plan |  | 33,657 |  |  | 29,006 |  |
| Investments in privately held companies |  | 27,888 |  |  | 27,980 |  |
| Other assets |  | 11,817 |  |  | 9,672 |  |
|  |  | $ | 362,525 |  |  | $ | 344,077 |  |

[0001032975-25-000059:notes:41]
[same as prior period, unchanged from 0001032975-25-000008:notes:45]

[0001032975-25-000059:notes:42]
|  |  | June 30, 2025 |  | March 31, 2025 |
| Accrued and other current liabilities: |  |  |  |  |
| Accrued customer marketing, pricing and incentive programs |  | $ | 203,412 |  |  | $ | 173,401 |  |
| Accrued personnel expenses |  | 134,992 |  |  | 180,763 |  |
| Warranty liabilities |  | 35,637 |  |  | 34,428 |  |
| Deferred revenue (1) |  | 29,768 |  |  | 25,798 |  |
| VAT Payable |  | 27,406 |  |  | 29,648 |  |
| Accrued sales return liability |  | 24,576 |  |  | 27,913 |  |
| Accrued loss for inventory purchase commitments |  | 23,466 |  |  | 19,614 |  |
| Income taxes payable |  | 19,261 |  |  | 26,841 |  |
| Operating lease liabilities |  | 16,746 |  |  | 15,780 |  |
| Other current liabilities |  | 157,524 |  |  | 152,317 |  |
|  |  | $ | 672,788 |  |  | $ | 686,503 |  |
| Other non-current liabilities: |  |  |  |  |
| Operating lease liabilities |  | $ | 76,883 |  |  | $ | 76,622 |  |
| Employee benefit plan obligations |  | 61,887 |  |  | 57,338 |  |
| Deferred revenue (1) |  | 43,382 |  |  | 38,216 |  |
| Obligation for deferred compensation plan |  | 33,657 |  |  | 29,006 |  |
| Warranty liabilities |  | 14,569 |  |  | 14,756 |  |
| Other non-current liabilities |  | 5,535 |  |  | 5,574 |  |
|  |  | $ | 235,913 |  |  | $ | 221,512 |  |

[0001032975-25-000059:notes:43]
[same as prior period, unchanged from 0001032975-25-000008:notes:47]


## us-gaap:FairValueDisclosuresTextBlock

[0001032975-25-000059:notes:44]
[same as prior period, unchanged from 0001032975-25-000008:notes:48]

[0001032975-25-000059:notes:45]
The Company considers fair value as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants at the measurement date. The Company utilizes the following three-level fair value hierarchy to establish the priorities of the inputs used to measure fair value:

[0001032975-25-000059:notes:46]
[same as prior period, unchanged from 0001032975-25-000008:notes:50]

[0001032975-25-000059:notes:47]
[same as prior period, unchanged from 0001032975-25-000008:notes:51]

[0001032975-25-000059:notes:48]
[same as prior period, unchanged from 0001032975-25-000008:notes:52]

[0001032975-25-000059:notes:49]
[same as prior period, unchanged from 0001032975-25-000008:notes:53]

[0001032975-25-000059:notes:50]
|  |  | June 30, 2025 |  | March 31, 2025 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 822,300 |  |  | $ | — |  |  | $ | — |  |  | $ | 852,467 |  |  | $ | — |  |  | $ | — |  |
| Investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 108 |  |  | $ | — |  |  | $ | — |  |  | $ | 90 |  |  | $ | — |  |  | $ | — |  |
| Common stock |  | 762 |  |  | — |  |  | — |  |  | 540 |  |  | — |  |  | — |  |
| Money market funds |  | 7,906 |  |  | — |  |  | — |  |  | 7,359 |  |  | — |  |  | — |  |
| Mutual funds |  | 24,881 |  |  | — |  |  | — |  |  | 21,017 |  |  | — |  |  | — |  |
| Total investments for deferred compensation plan |  | $ | 33,657 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,006 |  |  | $ | — |  |  | $ | — |  |
| Currency derivative assetsincluded in other current assets |  | $ | — |  |  | $ | 731 |  |  | $ | — |  |  | $ | — |  |  | $ | 90 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Currency derivative liabilitiesincluded in accrued and other current liabilities |  | $ | — |  |  | $ | 10,038 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,849 |  |  | $ | — |  |

[0001032975-25-000059:notes:51]
[same as prior period, unchanged from 0001032975-25-000008:notes:55]

[0001032975-25-000059:notes:52]
The marketable securities for the Company's deferred compensation plan were recorded at a fair value of $33.7 million and $29.0 million, as of June 30, 2025 and March 31, 2025, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized gains (losses) related to marketable securities for the three months ended June 30, 2025 and 2024 were not material and were included in other income (expense), net and corresponding changes in the deferred compensation liability were included in operating expenses and cost of goods sold, in the Company's condensed consolidated statements of operations.

[0001032975-25-000059:notes:53]
[same as prior period, unchanged from 0001032975-25-000008:notes:57]

[0001032975-25-000059:notes:54]
The Company has certain non-marketable investments included in other assets that are accounted for as equity method investments, with a carrying value of $18.3 million and $18.4 million as of June 30, 2025 and March 31, 2025, respectively. Income (loss) related to equity method investments for the three months ended June 30, 2025 and 2024 was not material and is included in other income (expense), net in the Company's condensed consolidated statements of operations. There was no impairment of equity method investments during the three months ended June 30, 2025 and 2024.

[0001032975-25-000059:notes:55]
[same as prior period, unchanged from 0001032975-25-000008:notes:59]

[0001032975-25-000059:notes:56]
[same as prior period, unchanged from 0001032975-25-000008:notes:60]

[0001032975-25-000059:notes:57]
The Company has certain equity investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with the same or similar security from the same issuer. The amount of these equity investments without readily determinable fair value included in other assets was $8.8 million as of June 30, 2025 and March 31, 2025. There was no impairment of these equity investments during the three months ended June 30, 2025 and the impairment charges related to the equity investments were not material during the three months ended June 30, 2024.

[0001032975-25-000059:notes:58]
Non-Financial Assets
Goodwill, intangible assets, and property, plant and equipment, are not required to be measured at fair value on a recurring basis. However, if the Company is required to evaluate these non-financial assets for impairment, whether due to certain triggering events or because of the required annual impairment test, and a resulting impairment is recorded to reduce the carrying value to the fair value, the non-financial assets are measured at fair value during such period. There was no impairment of non-financial assets during the three months ended June 30, 2025 and 2024.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-25-000059:notes:59]
[same as prior period, unchanged from 0001032975-25-000008:notes:64]

[0001032975-25-000059:notes:60]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis in other current assets and accrued and other current liabilities, respectively, on the condensed consolidated balance sheets as of June 30, 2025 and March 31, 2025. See Note 6 for the fair values of the Company’s derivative instruments as of June 30, 2025 and March 31, 2025.

[0001032975-25-000059:notes:61]
[same as prior period, unchanged from 0001032975-25-000008:notes:66]

[0001032975-25-000059:notes:62]
The Company enters into cash flow hedge contracts to protect against exchange rate exposure of forecasted inventory purchases. Previously, the hedge contracts covered inventory purchases within four months. Beginning in the first quarter of fiscal year 2026, they cover inventory purchases up to twelve months, with reduced coverage beyond four months. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive income (loss) until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Cash flows from such hedges are classified as operating activities in the condensed consolidated statements of cash flows. Hedging relationships are discontinued when the hedging contract is no longer eligible for hedge accounting, or is sold, terminated or exercised, or when the Company removes hedge designation for the contract. Gains and losses in the fair value of the effective portion of the discontinued hedges continue to be reported in accumulated other comprehensive income (loss) until the hedged inventory purchases are sold, unless it is probable that the forecasted inventory purchases will not occur by the end of the originally specified time period or within an additional two-month period of time thereafter.

[0001032975-25-000059:notes:63]
The notional amounts of foreign currency exchange forward contracts outstanding related to forecasted inventory purchases were $314.8 million and $74.6 million as of June 30, 2025 and March 31, 2025, respectively. The Company had $13.4 million of net loss related to its cash flow hedges included in accumulated other comprehensive loss as of June 30, 2025, which will be reclassified into earnings within the next twelve months.

[0001032975-25-000059:notes:64]
The following table presents the amounts of gain (loss) on the Company’s derivative instruments designated as hedging instruments for the three months ended June 30, 2025 and 2024 and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income (in thousands):

[0001032975-25-000059:notes:65]
|  |  | Three Months Ended June 30, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  |  |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |  |  |
| Cash flow hedges |  | $ | (12,349) |  |  | $ | 1,582 |  |  | $ | 2,002 |  |  | $ | (733) |  |  |  |  |  |

[0001032975-25-000059:notes:66]
[same as prior period, unchanged from 0001032975-25-000008:notes:71]

[0001032975-25-000059:notes:67]
[same as prior period, unchanged from 0001032975-25-000008:notes:72]

[0001032975-25-000059:notes:68]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within approximately one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are not material and included in other income (expense), net, in the condensed consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of June 30, 2025 and March 31, 2025 were $156.9 million and $131.8 million, respectively.

[0001032975-25-000059:notes:69]
[same as prior period, unchanged from 0001032975-25-000008:notes:74]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-25-000059:notes:70]
Goodwill and Other Intangible Assets
The Company conducts its impairment analysis of goodwill annually at December 31 or more frequently if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting unit may be less than its carrying amount. There have been no triggering events identified affecting the valuation of goodwill and intangible assets during the three months ended June 30, 2025 and 2024.

[0001032975-25-000059:notes:71]
[same as prior period, unchanged from 0001032975-25-000008:notes:76]

[0001032975-25-000059:notes:72]
| As of March 31, 2025 |  | $ | 463,230 |  |
| Effects of foreign currency translation |  | 2,560 |  |
| As of June 30, 2025 |  | $ | 465,790 |  |

[0001032975-25-000059:notes:73]
[same as prior period, unchanged from 0001032975-25-000008:notes:78]

[0001032975-25-000059:notes:74]
|  |  | June 30, 2025 |  | March 31, 2025 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademarks and trade names |  | $ | 32,390 |  |  | $ | (29,409) |  |  | $ | 2,981 |  |  | $ | 32,390 |  |  | $ | (28,675) |  |  | $ | 3,715 |  |
| Developed technology |  | 107,421 |  |  | (98,596) |  |  | 8,825 |  |  | 107,421 |  |  | (96,464) |  |  | 10,957 |  |
| Customer contracts/relationships |  | 69,087 |  |  | (60,543) |  |  | 8,544 |  |  | 69,087 |  |  | (58,646) |  |  | 10,441 |  |
| Effects of foreign currency translation |  | 619 |  |  | (645) |  |  | (26) |  |  | (620) |  |  | 137 |  |  | (483) |  |
| Total |  | $ | 209,517 |  |  | $ | (189,193) |  |  | $ | 20,324 |  |  | $ | 208,278 |  |  | $ | (183,648) |  |  | $ | 24,630 |  |


## us-gaap:DebtDisclosureTextBlock

[0001032975-25-000059:notes:75]
Financing Arrangements

[0001032975-25-000059:notes:76]
On January 27, 2025, the Company entered into an unsecured revolving credit facility with a syndicate of banks (the "Credit Agreement"). The Credit Agreement provides a revolving line of credit of up to $750.0 million to the Company including the issuance of letters of credit of up to $100.0 million. The Credit Agreement terminates on January 27, 2030 unless extended in accordance with its terms. The Credit Agreement contains (1) an increase option allowing the Company to secure up to $250.0 million of additional commitments and (2) an extension option to extend the term by one-year which may be exercised no more than two times, subject to certain requirements. Loans under the Credit Agreement are available in U.S. Dollars, Euro, Sterling, Yen, Swiss Francs, Canadian Dollars, Australian Dollars and any other currency agreed to by each lender. Proceeds of loans made under the Credit Agreement may be used for general corporate purposes.

[0001032975-25-000059:notes:77]
The Credit Agreement contains a maximum net debt to adjusted EBITDA ratio, compliance with which is a condition to the Company's ability to borrow. Borrowings under the Credit Agreement will bear interest at a rate determined by reference to benchmark rates plus an applicable spread (ranging from 0% to 1.5%) based on the

[0001032975-25-000059:notes:78]
Company's net leverage ratio or credit rating at the time of the borrowing. Undrawn balances available under the Credit Agreement are subject to commitment fees at the applicable rate determined by reference to the Company's net leverage ratio or credit rating. There has been no borrowing outstanding under the Credit Agreement as of June 30, 2025.
In addition, the Company had several uncommitted, unsecured bank lines of credit and letters of credit aggregating to $174.3 million and $172.2 million as of June 30, 2025 and March 31, 2025, respectively. There are no financial covenants under the lines of credit with which the Company must comply. There was no borrowing outstanding under the lines of credit as of June 30, 2025 or March 31, 2025. As of June 30, 2025 and March 31, 2025, the Company had outstanding bank guarantees of $22.1 million and $12.1 million, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-25-000059:notes:79]
Commitments and Contingencies

[0001032975-25-000059:notes:80]
Product Warranties

[0001032975-25-000059:notes:81]
Changes in the Company’s warranty liabilities for the three months ended June 30, 2025 and 2024 were as follows (in thousands):

[0001032975-25-000059:notes:82]
|  | Three Months Ended June 30, |
|  | 2025 |  | 2024 |
| Beginning of the period | $ | 49,184 |  |  | $ | 44,654 |  |
| Provision | 8,622 |  |  | 10,186 |  |
| Settlements | (8,249) |  |  | (10,038) |  |
| Effects of foreign currency translation | 649 |  |  | (300) |  |
| End of the period | $ | 50,206 |  |  | $ | 44,502 |  |

[0001032975-25-000059:notes:83]
Indemnifications

[0001032975-25-000059:notes:84]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2025, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-25-000059:notes:85]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-25-000059:notes:86]
Legal Proceedings

[0001032975-25-000059:notes:87]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and legal proceedings. The Company intends to vigorously defend against them. Management periodically assesses the Company’s liabilities and contingencies in connection with these matters based upon the latest information available. The Company follows ASC ("Accounting Standards Codification") 450, Contingencies, in determining the accounting and disclosure for these contingencies. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows, and results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity, and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-25-000059:notes:88]
[same as prior period, unchanged from 0001032975-25-000008:notes:93]

[0001032975-25-000059:notes:89]
As of June 30, 2025, the Company's nominal share capital is CHF 42.2 million, consisting of 168,994,142 issued shares with a par value of CHF 0.25 each, of which 21,442,654 were held in treasury shares.

[0001032975-25-000059:notes:90]
[same as prior period, unchanged from 0001032975-25-000008:notes:95]

[0001032975-25-000059:notes:91]
[same as prior period, unchanged from 0001032975-25-000008:notes:97]

[0001032975-25-000059:notes:92]
In June 2023, the Company's Board of Directors approved a three-year share repurchase program, which allows the Company to use up to $1.0 billion to repurchase its shares. The 2023 share repurchase program enables the Company to repurchase shares for cancellation, as well as to support equity incentive plans or potential acquisitions. The Swiss Takeover Board approved the 2023 share repurchase program in July 2023 and the program became effective on July 28, 2023. In March 2025, the Company's Board of Directors approved an increase of $600.0 million to the 2023 share repurchase program, to an aggregate amount of $1.6 billion. The Swiss Takeover Board approved this increase in April 2025 and it became effective on April 2, 2025. As of June 30, 2025, $524.3 million was available for repurchase under the 2023 share repurchase program.

[0001032975-25-000059:notes:93]
The following table summarizes the Company's share repurchase activities for the three months ended June 30, 2025 and 2024 were as follows (in thousands):

[0001032975-25-000059:notes:94]
|  | Three Months Ended June 30, |
|  | 2025 |  | 2024 |
| 2023 Share Repurchase Program: |  |  |  |
| Number of shares repurchased (1) | 1,531 |  | 1,444 |
| Aggregate cost of shares repurchased (1) (2) | $ | 124,135 |  |  | $ | 132,132 |  |

[0001032975-25-000059:notes:95]
(1) All shares were repurchased for cancellation.

[0001032975-25-000059:notes:96]
(2) Includes an aggregate cost of $21.2 million and $20.8 million, respectively, that was not yet paid as of June 30, 2025 and 2024.

[0001032975-25-000059:notes:97]
Swiss law limits a company’s ability to hold or repurchase its own shares. The aggregate par value of all shares held in treasury by the Company and its subsidiaries may not exceed 10% of the share capital of the Company, which for the Company corresponds to approximately 16.9 million registered shares as of June 30, 2025. This limitation does not apply to shares repurchased for cancellation, due to the Board of Directors’ authority under the Company’s capital band set forth in the Company’s Articles of Incorporation. As of June 30, 2025, the Company had a total of 21.4 million shares held in treasury stock, which includes 8.2 million shares that have been repurchased for cancellation and 13.2 million shares that have been purchased to support equity incentive plans or potential acquisitions.

[0001032975-25-000059:notes:98]
[same as prior period, unchanged from 0001032975-25-000008:notes:102]

[0001032975-25-000059:notes:99]
Share Cancellation

[0001032975-25-000059:notes:100]
In June 2025, the Company's Board of Directors approved the cancellation of 8.2 million treasury shares, which were repurchased under the 2023 share repurchase program in fiscal year 2025 and the first quarter of fiscal year 2026, for an aggregate cost of $712.2 million. The cancellation is expected to take effect in the second quarter of fiscal year 2026. When the cancellation becomes effective, the number of registered shares issued and the number of treasury shares will both decrease by 8.2 million shares, and the Company will deduct the par value from registered shares and reflect the excess of share repurchase cost over par value as a reduction to retained earnings.

[0001032975-25-000059:notes:101]
[same as prior period, unchanged from 0001032975-25-000008:notes:106]

[0001032975-25-000059:notes:102]
The components of accumulated other comprehensive loss were as follows (in thousands):

[0001032975-25-000059:notes:103]
|  |  | Currency Translation Adjustment |  | Defined Benefit Plans |  | Deferred Hedging Losses |  | Total |
| March 31, 2025 |  | $ | (118,652) |  |  | $ | (25,276) |  |  | $ | (3,024) |  |  | $ | (146,952) |  |
| Other comprehensive income (loss) |  | 27,293 |  |  | (157) |  |  | (10,347) |  |  | 16,789 |  |
| June 30, 2025 |  | $ | (91,359) |  |  | $ | (25,433) |  |  | $ | (13,371) |  |  | $ | (130,163) |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-25-000059:notes:104]
[same as prior period, unchanged from 0001032975-25-000008:notes:109]

[0001032975-25-000059:notes:105]
The Company manages its business activities on a consolidated basis and operates as a single operating segment: Peripherals. The operating segment encompasses the design, manufacturing and sales of peripherals for gaming, PCs, tablets, video conferencing, and other digital platforms. The Company's Chief Operating Decision Maker (the “CODM”) is the Chief Executive Officer. The CODM periodically reviews information such as sales and net income to make business decisions and evaluate performance. The CODM uses net income to evaluate income generated from segment assets (return on assets) in deciding whether to reinvest profits into the Peripherals segment or into other parts of the entity, such as for acquisitions, share repurchase or to pay dividends. The CODM also monitors budget versus actual net income results.

[0001032975-25-000059:notes:106]
The following table presents segment revenue, significant segment expenses, and net income (in thousands):

[0001032975-25-000059:notes:107]
|  | Three Months Ended June 30, |
|  | 2025 |  | 2024 |
| Net sales | $ | 1,147,703 |  |  | $ | 1,088,217 |  |
| Less: Significant segment expenses |  |  |  |
| Cost of goods sold (1) | 664,212 |  |  | 616,919 |  |
| Marketing and selling (1) | 181,866 |  |  | 185,054 |  |
| Research and development (1) | 68,236 |  |  | 69,568 |  |
| General and administrative (1) | 31,630 |  |  | 34,241 |  |
| Less: other segment items |  |  |  |
| Share-based compensation expense | 32,828 |  |  | 23,405 |  |
| Amortization of intangible assets and acquisition-related costs | 4,795 |  |  | 5,145 |  |
| Interest income | (11,229) |  |  | (15,790) |  |
| Other (2) | 880 |  |  | 2,284 |  |
| Provision for income taxes | 28,470 |  |  | 25,558 |  |
| Net income | $ | 146,015 |  |  | $ | 141,833 |  |

[0001032975-25-000059:notes:108]
(1) The difference between the amounts included in the table above and the amounts included in the condensed consolidated statements of operations is related to share-based compensation expense (see Note 3).

[0001032975-25-000059:notes:109]
(2) Includes restructuring charges, net, and other income (expense), net.

[0001032975-25-000059:notes:110]
Sales by product category for the three months ended June 30, 2025 and 2024 were as follows (in thousands):

[0001032975-25-000059:notes:111]
|  |  | Three Months Ended June 30, |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |
| Gaming (1) |  | $ | 315,875 |  |  | $ | 309,475 |  |  |  |  |  |
| Keyboards & Combos |  | 222,492 |  |  | 215,333 |  |  |  |  |  |
| Pointing Devices |  | 195,780 |  |  | 189,946 |  |  |  |  |  |
| Video Collaboration |  | 166,716 |  |  | 147,042 |  |  |  |  |  |
| Webcams |  | 84,374 |  |  | 72,904 |  |  |  |  |  |
| Tablet Accessories |  | 91,227 |  |  | 78,539 |  |  |  |  |  |
| Headsets |  | 45,523 |  |  | 44,236 |  |  |  |  |  |
| Other (2) |  | 25,716 |  |  | 30,742 |  |  |  |  |  |
| Total Sales |  | $ | 1,147,703 |  |  | $ | 1,088,217 |  |  |  |  |  |

[0001032975-25-000059:notes:112]
[same as prior period, unchanged from 0001032975-25-000008:notes:113]

[0001032975-25-000059:notes:113]
[same as prior period, unchanged from 0001032975-25-000008:notes:114]

[0001032975-25-000059:notes:114]
Sales by geographic region (based on the customers’ locations) for the three months ended June 30, 2025 and 2024 were as follows (in thousands):

[0001032975-25-000059:notes:115]
|  |  | Three Months Ended June 30, |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |
| Americas |  | $ | 461,690 |  |  | $ | 485,289 |  |  |  |  |  |
| EMEA |  | 346,840 |  |  | 309,817 |  |  |  |  |  |
| Asia Pacific |  | 339,173 |  |  | 293,111 |  |  |  |  |  |
| Total Sales |  | $ | 1,147,703 |  |  | $ | 1,088,217 |  |  |  |  |  |

[0001032975-25-000059:notes:116]
Revenue from sales to customers in the United States, China and Germany each represented 10% or more of the total consolidated sales for the periods presented herein. No other countries represented 10% or more of the Company’s total consolidated sales for the periods presented herein.

[0001032975-25-000059:notes:117]
Switzerland, the Company’s country of domicile, represented 3% and 2% of the Company's total consolidated sales for the three months ended June 30, 2025 and 2024, respectively.

[0001032975-25-000059:notes:118]
Three customers of the Company each represented 10% or more of the total consolidated gross sales for each of the three months ended June 30, 2025 and 2024.

[0001032975-25-000059:notes:119]
[same as prior period, unchanged from 0001032975-25-000008:notes:120]

[0001032975-25-000059:notes:120]
|  |  | June 30, 2025 |  | March 31, 2025 |
| Americas |  | $ | 59,862 |  |  | $ | 61,521 |  |
| EMEA |  | 51,773 |  |  | 47,874 |  |
| Asia Pacific |  | 62,866 |  |  | 60,710 |  |
| Total |  | $ | 174,501 |  |  | $ | 170,105 |  |

[0001032975-25-000059:notes:121]
Property, plant and equipment, net (excluding software) and right-of-use assets in the United States and China were $58.3 million and $45.5 million, respectively, as of June 30, 2025. Property, plant and equipment, net (excluding software) and right-of-use assets in the United States and China were $60.0 million and $43.4 million, respectively, as of March 31, 2025.

[0001032975-25-000059:notes:122]
Property, plant and equipment, net (excluding software) and right-of-use assets in Switzerland, the Company’s country of domicile, were $26.9 million and $24.1 million as of June 30, 2025 and March 31, 2025, respectively. No 
other countries represented more than 10% of the Company’s total property, plant and equipment, net (excluding software) and right-of-use assets as of June 30, 2025 or March 31, 2025.
