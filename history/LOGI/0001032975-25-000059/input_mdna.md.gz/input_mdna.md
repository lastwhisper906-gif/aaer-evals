# LOGI MD&A — 0001032975-25-000059


## mdna

[0001032975-25-000059:mdna:1]
[same as prior period, unchanged from 0001032975-25-000008:mdna:1]

[0001032975-25-000059:mdna:2]
[same as prior period, unchanged from 0001032975-25-000008:mdna:2]

[0001032975-25-000059:mdna:3]
•Our business strategy and investment priorities in relation to evolving consumer and enterprise demand trends, competitive landscape and current and future worldwide geopolitical, economic and capital market conditions, including fluctuations in currency exchange rates, inflation, economic downturns, and disruptions in global logistics;

[0001032975-25-000059:mdna:4]
•Changes in trade regulations, policies and agreements and the imposition of tariffs that affect our products or operations, including potential new tariffs that may be imposed on U.S. imports, and our ability to mitigate;

[0001032975-25-000059:mdna:5]
[same as prior period, unchanged from 0001032975-25-000008:mdna:5]

[0001032975-25-000059:mdna:6]
[same as prior period, unchanged from 0001032975-25-000008:mdna:6]

[0001032975-25-000059:mdna:7]
•Our expectations regarding any restructuring efforts, including the timing or effectiveness thereof;

[0001032975-25-000059:mdna:8]
•The scope, nature or impact of any acquisition, strategic alliance, and divestiture activities;

[0001032975-25-000059:mdna:9]
•Our expectations regarding the success of any strategic acquisitions, including integration of acquired operations, products, technology, internal controls, personnel and management teams;

[0001032975-25-000059:mdna:10]
•Our expectations regarding our effective tax rate, future tax benefits, tax settlements, and the adequacy of our provisions for uncertain tax positions;

[0001032975-25-000059:mdna:11]
•Our expectations regarding our potential indemnification obligations, and the outcome of pending or future legal proceedings and tax audits;

[0001032975-25-000059:mdna:12]
•Our business development, product development and innovation, and their impact on future operating results and anticipated operating costs for fiscal year 2026 and beyond;

[0001032975-25-000059:mdna:13]
[same as prior period, unchanged from 0001032975-25-000008:mdna:12]

[0001032975-25-000059:mdna:14]
[same as prior period, unchanged from 0001032975-25-000008:mdna:14]

[0001032975-25-000059:mdna:15]
•The sufficiency of our cash and cash equivalents, cash generated from operations, and available borrowings under our Credit Agreement and our bank lines of credit to fund capital expenditures and working capital needs, and our ability to comply with our obligations under such debt agreements; and

[0001032975-25-000059:mdna:16]
[same as prior period, unchanged from 0001032975-25-000008:mdna:16]

[0001032975-25-000059:mdna:17]
[same as prior period, unchanged from 0001032975-25-000008:mdna:17]

[0001032975-25-000059:mdna:18]
[same as prior period, unchanged from 0001032975-25-000008:mdna:18]

[0001032975-25-000059:mdna:19]
Logitech designs software-enabled hardware solutions that help businesses thrive and bring people together when working, creating, and gaming. As the point of connection between people and the digital world, our mission is to extend human potential in work and play, in a way that is good for people and the planet. We sell the vast majority of our products under Logitech and Logitech G brand names.

[0001032975-25-000059:mdna:20]
Our diverse, innovative portfolio includes: Gaming, Keyboards & Combos, Pointing Devices, Video Collaboration, Webcams, Tablet Accessories, and Headsets. These products are all classified under a single operating segment: Peripherals (see Note 12 to our condensed consolidated financial statements).

[0001032975-25-000059:mdna:21]
We sell our products to a broad range of international customers, in the Americas, Europe, the Middle East and Africa (“EMEA”) and Asia Pacific. This includes direct sales to retailers, e-tailers, businesses large and small and end consumers through our e-commerce platform, and indirect sales to end customers through distributors.

[0001032975-25-000059:mdna:22]
[same as prior period, unchanged from 0001032975-25-000008:mdna:22]

[0001032975-25-000059:mdna:23]
[same as prior period, unchanged from 0001032975-25-000008:mdna:23]

[0001032975-25-000059:mdna:24]
In 2025, the United States introduced trade policy actions that have increased import tariffs across a wide range of countries at various rates, with certain exemptions. These tariff policies in the U.S. and responsive policies enacted in other countries are evolving. The incremental tariffs have had and may continue to have an adverse impact on our result of operations. In addition, our business has continued to be impacted by ongoing macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, uncertainty in consumer and enterprise demand, low economic growth in certain regions, changes in fiscal policies and geopolitical conflicts.

[0001032975-25-000059:mdna:25]
The global and regional economic and political conditions, as well as changes in trade policies, have caused and may continue to cause volatility in demand for our products as well as cost of tariffs, materials and logistics, and transportation delays, and as a result have impacted and may continue to impact the pricing of our products, product availability and our results of operations.

[0001032975-25-000059:mdna:26]
[same as prior period, unchanged from 0001032975-25-000008:mdna:26]

[0001032975-25-000059:mdna:27]
[same as prior period, unchanged from 0001032975-25-000008:mdna:27]

[0001032975-25-000059:mdna:28]
Several long-term secular trends offer long-term structural growth opportunities across Logitech’s product portfolio. We design, create and sell products that benefit from these secular trends which include the following:

[0001032975-25-000059:mdna:29]
[same as prior period, unchanged from 0001032975-25-000008:mdna:31]

[0001032975-25-000059:mdna:30]
•New ways of working: The new ways of working that have emerged after the pandemic in which people are splitting time between working in the office, from home, and from other places while on the go, provide opportunities for Logitech to equip multiple workspaces with products across our portfolio including Pointing Devices, Keyboards & Combos, Tablet Accessories, Headsets and Webcams. The new ways of working also provide an opportunity for increased adoption of video conferencing by enterprises and consumers. Our video collaboration products are compatible with a variety of video conference platforms, including Zoom, Microsoft Teams and Google Meet.

[0001032975-25-000059:mdna:31]
•Gaming growth: The ongoing growth and evolution of gaming creates an opportunity for us to provide more tools to a wider community of gamers. In particular, social gaming continues to gain popularity through online gaming, multi-platform experiences and esports.

[0001032975-25-000059:mdna:32]
While we believe we will further benefit from these secular trends, we have experienced and will continue to experience challenges that impact our business and financial results. These challenges include (i) uncertainty in tariffs on goods imported into the U.S. and responsive policies enacted by other countries, (ii) the macroeconomic environment, including inflation, interest rate and foreign currency fluctuations, low economic growth in certain

[0001032975-25-000059:mdna:33]
regions, changes in fiscal policies and geopolitical conflicts, (iii) the uncertainty of overall consumer and enterprise demand, (iv) the uncertainty of timing of enterprise investments in infrastructure and technology, and (v) the timing of further development of our B2B go-to-market capabilities.

[0001032975-25-000059:mdna:34]
We expect these challenges to continue in the near-term. We have taken steps to mitigate the impact of these challenges, including but not limited to: (i) continued diversification of our manufacturing footprint and supplier ecosystem, (ii) maintaining discipline in our operating expenses, (iii) managing inventory levels to align with demand, (iv) continued investment in our B2B capabilities, and (v) continued release of new products to increase the value proposition of our portfolio.

[0001032975-25-000059:mdna:35]
[same as prior period, unchanged from 0001032975-25-000008:mdna:37]

[0001032975-25-000059:mdna:36]
Seasonality

[0001032975-25-000059:mdna:37]
We experience seasonal trends related to our product sales. Sales are generally highest during our third fiscal quarter (October to December) primarily due to increased consumer demand during the holiday season and increased spending by enterprises in the months nearing the calendar year-end. Cash flow is correspondingly lower in the first half of our fiscal year as we typically build inventories in advance of our third fiscal quarter and we also pay an annual dividend following our Annual General Meeting typically held in September.

[0001032975-25-000059:mdna:38]
[same as prior period, unchanged from 0001032975-25-000008:mdna:40]

[0001032975-25-000059:mdna:39]
Our sales for the three months ended June 30, 2025 increased 5%, compared to the three months ended June 30, 2024, primarily due to an increase in sales of Video Collaboration, Tablet Accessories and Webcams. Our sales for the three months ended June 30, 2025, compared to three months ended June 30, 2024, benefited from improved demand in the Asia Pacific and EMEA regions.

[0001032975-25-000059:mdna:40]
Sales for the three months ended June 30, 2025 increased 16% and 12% in the Asia Pacific and EMEA regions, respectively, and decreased 5% in the Americas region, compared to the three months ended June 30, 2024.

[0001032975-25-000059:mdna:41]
Gross margin was 41.7% for the three months ended June 30, 2025 and decreased by 110 basis points, compared to the three months ended June 30, 2024, primarily driven by an unfavorable impact from increased tariffs, higher promotional spend and a prior year release in inventory reserves, partially offset by a favorable impact from price increases in North America and product cost reductions.

[0001032975-25-000059:mdna:42]
Operating expenses for the three months ended June 30, 2025 were $316.9 million, or 27.6% of sales, compared to $312.8 million, or 28.7% of sales, for the three months ended June 30, 2024.

[0001032975-25-000059:mdna:43]
We had an income tax provision of $28.5 million and $25.6 million for the three months ended June 30, 2025 and June 30, 2024, respectively.

[0001032975-25-000059:mdna:44]
Net income for the three months ended June 30, 2025 was $146.0 million, compared to $141.8 million for the three months ended June 30, 2024.

[0001032975-25-000059:mdna:45]
[same as prior period, unchanged from 0001032975-25-000008:mdna:47]

[0001032975-25-000059:mdna:46]
[same as prior period, unchanged from 0001032975-25-000008:mdna:48]

[0001032975-25-000059:mdna:47]
We consider an accounting estimate critical if it: (i) requires management to make judgments and estimates about matters that are inherently uncertain; and (ii) is important to an understanding of our financial condition and operating results.

[0001032975-25-000059:mdna:48]
We base our assumptions, judgments and estimates on historical experience and various other factors that we believe to be reasonable under the circumstances. Actual results could differ materially from these estimates under different assumptions or conditions. On a regular basis, we evaluate our assumptions, judgments and estimates. We also discuss our critical accounting policies and estimates with the Audit Committee of the Board of Directors.

[0001032975-25-000059:mdna:49]
We believe that the assumptions, judgments and estimates involved in the accounting for accruals for customer incentives and related breakage, accrued sales return liability, inventory valuation, and uncertain tax positions, have the greatest potential impact on our condensed consolidated financial statements. These areas are key components of our results of operations and are based on complex rules requiring us to make judgments and

[0001032975-25-000059:mdna:50]
estimates and consequently, we consider these to be our critical accounting policies. Historically, our assumptions, judgments and estimates relative to our critical accounting policies have not differed materially from actual results.

[0001032975-25-000059:mdna:51]
There have been no material changes in our critical accounting estimates during the three months ended June 30, 2025 compared with the critical accounting estimates disclosed in Management's Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended March 31, 2025.

[0001032975-25-000059:mdna:52]
[same as prior period, unchanged from 0001032975-25-000008:mdna:53]

[0001032975-25-000059:mdna:53]
Refer to Note 1 to the condensed consolidated financial statements included in this Quarterly Report on Form 10-Q for new accounting pronouncements to be adopted.

[0001032975-25-000059:mdna:54]
[same as prior period, unchanged from 0001032975-25-000008:mdna:55]

[0001032975-25-000059:mdna:55]
[same as prior period, unchanged from 0001032975-25-000008:mdna:56]

[0001032975-25-000059:mdna:56]
[same as prior period, unchanged from 0001032975-25-000008:mdna:57]

[0001032975-25-000059:mdna:57]
[same as prior period, unchanged from 0001032975-25-000008:mdna:58]

[0001032975-25-000059:mdna:58]
[same as prior period, unchanged from 0001032975-25-000008:mdna:59]

[0001032975-25-000059:mdna:59]
[same as prior period, unchanged from 0001032975-25-000008:mdna:60]

[0001032975-25-000059:mdna:60]
[same as prior period, unchanged from 0001032975-25-000008:mdna:61]

[0001032975-25-000059:mdna:61]
Our sales for the three months ended June 30, 2025 increased 5%, compared to the three months ended June 30, 2024, primarily due to an increase in sales of Video Collaboration, Tablet Accessories and Webcams. Our sales for the three months ended June 30, 2025, compared to three months ended June 30, 2024, benefited from improved demand in the Asia Pacific and EMEA regions. If currency exchange rates had been constant in the three months ended June 30, 2025 and 2024, our sales growth rate in constant currency would have been 5%.

[0001032975-25-000059:mdna:62]
[same as prior period, unchanged from 0001032975-25-000008:mdna:63]

[0001032975-25-000059:mdna:63]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Australian Dollar, Canadian Dollar, Pound Sterling and New Taiwan Dollar. During the three months ended June 30, 2025, approximately 53% of our sales were denominated in currencies other than the U.S. Dollar.

[0001032975-25-000059:mdna:64]
[same as prior period, unchanged from 0001032975-25-000008:mdna:65]

[0001032975-25-000059:mdna:65]
The following table presents the change in sales by region for the three months ended June 30, 2025, compared with the three months ended June 30, 2024:

[0001032975-25-000059:mdna:66]
|  |  | Sales Growth Rate |  | Constant DollarSales Growth Rate |
|  |  | Three Months Ended June 30, 2025 |  |  |  | Three Months Ended June 30, 2025 |  |  |
| Americas |  | (5) | % |  |  |  | (4) | % |  |  |
| EMEA |  | 12 | % |  |  |  | 9 | % |  |  |
| Asia Pacific |  | 16 | % |  |  |  | 15 | % |  |  |

[0001032975-25-000059:mdna:67]
[same as prior period, unchanged from 0001032975-25-000008:mdna:68]

[0001032975-25-000059:mdna:68]
The decrease in sales in the Americas region for the three-month period presented above was primarily driven by a decrease in sales of Gaming.

[0001032975-25-000059:mdna:69]
[same as prior period, unchanged from 0001032975-25-000008:mdna:70]

[0001032975-25-000059:mdna:70]
The increase in sales in the EMEA region for the three-month period presented above was primarily driven by an increase in sales of Gaming, Video Collaboration, Keyboards & Combos, and Tablet Accessories.

[0001032975-25-000059:mdna:71]
[same as prior period, unchanged from 0001032975-25-000008:mdna:72]

[0001032975-25-000059:mdna:72]
The increase in sales in the Asia Pacific region for the three-month period presented above was primarily driven by an increase in sales for Gaming and Tablet Accessories.

[0001032975-25-000059:mdna:73]
[same as prior period, unchanged from 0001032975-25-000008:mdna:74]

[0001032975-25-000059:mdna:74]
Sales by product category for the three months ended June 30, 2025 and 2024 were as follows (Dollars in thousands):

[0001032975-25-000059:mdna:75]
|  |  | Three Months Ended June 30, |  |  |
|  |  | 2025 |  | 2024 |  | Change |  |  |  |  |  |  |
| Gaming (1) |  | $ | 315,875 |  |  | $ | 309,475 |  |  | 2 | % |  |  |  |  |  |  |
| Keyboards & Combos |  | 222,492 |  |  | 215,333 |  |  | 3 |  |  |  |  |  |  |  |
| Pointing Devices |  | 195,780 |  |  | 189,946 |  |  | 3 |  |  |  |  |  |  |  |
| Video Collaboration |  | 166,716 |  |  | 147,042 |  |  | 13 |  |  |  |  |  |  |  |
| Webcams |  | 84,374 |  |  | 72,904 |  |  | 16 |  |  |  |  |  |  |  |
| Tablet Accessories |  | 91,227 |  |  | 78,539 |  |  | 16 |  |  |  |  |  |  |  |
| Headsets |  | 45,523 |  |  | 44,236 |  |  | 3 |  |  |  |  |  |  |  |
| Other (2) |  | 25,716 |  |  | 30,742 |  |  | (16) |  |  |  |  |  |  |  |
| Total Sales |  | $ | 1,147,703 |  |  | $ | 1,088,217 |  |  | 5 | % |  |  |  |  |  |  |

[0001032975-25-000059:mdna:76]
[same as prior period, unchanged from 0001032975-25-000008:mdna:77]

[0001032975-25-000059:mdna:77]
[same as prior period, unchanged from 0001032975-25-000008:mdna:78]

[0001032975-25-000059:mdna:78]
[same as prior period, unchanged from 0001032975-25-000008:mdna:79]

[0001032975-25-000059:mdna:79]
Our Gaming category includes gaming mice, steering wheels, headsets, keyboards, console gaming headsets, microphones and Streamlabs services.

[0001032975-25-000059:mdna:80]
Sales of Gaming increased 2% for the three months ended June 30, 2025, compared to the three months ended June 30, 2024, primarily driven by an increase in sales of gaming mice, partially offset by decreases in sales of other gaming products.

[0001032975-25-000059:mdna:81]
[same as prior period, unchanged from 0001032975-25-000008:mdna:82]

[0001032975-25-000059:mdna:82]
[same as prior period, unchanged from 0001032975-25-000008:mdna:83]

[0001032975-25-000059:mdna:83]
Sales of Keyboards & Combos increased 3% for the three months ended June 30, 2025, compared to the three months ended June 30, 2024, primarily driven by an increase in sales of cordless combo products.

[0001032975-25-000059:mdna:84]
[same as prior period, unchanged from 0001032975-25-000008:mdna:85]

[0001032975-25-000059:mdna:85]
[same as prior period, unchanged from 0001032975-25-000008:mdna:86]

[0001032975-25-000059:mdna:86]
Sales of Pointing Devices increased 3% for the three months ended June 30, 2025, compared to the three months ended June 30, 2024, primarily driven by an increase in sales of cordless mice.

[0001032975-25-000059:mdna:87]
[same as prior period, unchanged from 0001032975-25-000008:mdna:88]

[0001032975-25-000059:mdna:88]
[same as prior period, unchanged from 0001032975-25-000008:mdna:89]

[0001032975-25-000059:mdna:89]
Sales of Video Collaboration increased 13% for the three months ended June 30, 2025, compared to the three months ended June 30, 2024, primarily due to an increase in sales of conference room cameras.

[0001032975-25-000059:mdna:90]
[same as prior period, unchanged from 0001032975-25-000008:mdna:91]

[0001032975-25-000059:mdna:91]
Our Webcams category includes PC-based webcams including streaming cameras, and VC webcams that turn any desktop into an instant collaboration space.

[0001032975-25-000059:mdna:92]
Sales of Webcams increased 16% for the three months ended June 30, 2025, compared to the three months ended June 30, 2024, primarily driven by an increase in sales of our PC-based webcams.

[0001032975-25-000059:mdna:93]
[same as prior period, unchanged from 0001032975-25-000008:mdna:94]

[0001032975-25-000059:mdna:94]
[same as prior period, unchanged from 0001032975-25-000008:mdna:95]

[0001032975-25-000059:mdna:95]
Sales of Tablet Accessories increased 16% for the three months ended June 30, 2025, compared to the three months ended June 30, 2024, primarily benefiting from strong demand from the education sector.

[0001032975-25-000059:mdna:96]
[same as prior period, unchanged from 0001032975-25-000008:mdna:97]

[0001032975-25-000059:mdna:97]
[same as prior period, unchanged from 0001032975-25-000008:mdna:98]

[0001032975-25-000059:mdna:98]
Sales of Headsets increased 3% for the three months ended June 30, 2025, compared to the three months ended June 30, 2024, primarily driven by an increase in sales of VC headsets.

[0001032975-25-000059:mdna:99]
[same as prior period, unchanged from 0001032975-25-000008:mdna:100]

[0001032975-25-000059:mdna:100]
[same as prior period, unchanged from 0001032975-25-000008:mdna:101]

[0001032975-25-000059:mdna:101]
Sales in Other category decreased 16% for the three months ended June 30, 2025, compared to the three months ended June 30, 2024, primarily driven by a decline in sales of mobile speakers.

[0001032975-25-000059:mdna:102]
[same as prior period, unchanged from 0001032975-25-000008:mdna:103]

[0001032975-25-000059:mdna:103]
Gross profit for the three months ended June 30, 2025 and 2024 was as follows (Dollars in thousands):

[0001032975-25-000059:mdna:104]
|  |  | Three Months Ended June 30, |  |  |
|  |  | 2025 |  | 2024 |  | Change |  |  |  |  |  |  |
| Net sales |  | $ | 1,147,703 |  | $ | 1,088,217 |  | 5 | % |  |  |  |  |  |  |
| Gross profit |  | $ | 478,962 |  | $ | 466,258 |  | 3 | % |  |  |  |  |  |  |
| Gross margin |  | 41.7 | % |  | 42.8 | % |  |  |  |  |  |  |  |  |

[0001032975-25-000059:mdna:105]
[same as prior period, unchanged from 0001032975-25-000008:mdna:106]

[0001032975-25-000059:mdna:106]
Gross margin was 41.7% for the three months ended June 30, 2025 and decreased by 110 basis points, compared to the three months ended June 30, 2024, primarily driven by an unfavorable impact from increased tariffs, higher promotional spend and a prior year release in inventory reserves, partially offset by a favorable impact from price increases in North America and product cost reductions.

[0001032975-25-000059:mdna:107]
[same as prior period, unchanged from 0001032975-25-000008:mdna:108]

[0001032975-25-000059:mdna:108]
Operating expenses for the three months ended June 30, 2025 and 2024 were as follows (Dollars in thousands):

[0001032975-25-000059:mdna:109]
|  |  | Three Months Ended June 30, |  |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |  |
| Marketing and selling |  | $ | 195,796 |  |  | $ | 196,905 |  |  |  |  |  |  |
| % of sales |  | 17.1 | % |  | 18.1 | % |  |  |  |  |  |
| Research and development |  | 74,587 |  |  | 75,307 |  |  |  |  |  |  |
| % of sales |  | 6.5 | % |  | 6.9 | % |  |  |  |  |  |
| General and administrative |  | 41,797 |  |  | 37,458 |  |  |  |  |  |  |
| % of sales |  | 3.6 | % |  | 3.5 | % |  |  |  |  |  |
| Amortization of intangible assets and acquisition-related costs |  | 2,646 |  |  | 2,703 |  |  |  |  |  |  |
| % of sales |  | 0.2 | % |  | 0.2 | % |  |  |  |  |  |
| Restructuring charges, net |  | 2,042 |  |  | 386 |  |  |  |  |  |  |
| % of sales |  | 0.2 | % |  | — | % |  |  |  |  |  |
| Total operating expenses |  | $ | 316,868 |  |  | $ | 312,759 |  |  |  |  |  |  |
| % of sales |  | 27.6 | % |  | 28.7 | % |  |  |  |  |  |

[0001032975-25-000059:mdna:110]
Operating expenses remained relatively flat during the three months ended June 30, 2025, compared to the three months ended June 30, 2024, reflecting our efforts to reduce operating expenses in order to offset higher tariff costs.

[0001032975-25-000059:mdna:111]
[same as prior period, unchanged from 0001032975-25-000008:mdna:112]

[0001032975-25-000059:mdna:112]
[same as prior period, unchanged from 0001032975-25-000008:mdna:113]

[0001032975-25-000059:mdna:113]
During the three months ended June 30, 2025, marketing and selling expenses remained relatively flat, compared to the three months ended June 30, 2024.

[0001032975-25-000059:mdna:114]
[same as prior period, unchanged from 0001032975-25-000008:mdna:115]

[0001032975-25-000059:mdna:115]
[same as prior period, unchanged from 0001032975-25-000008:mdna:116]

[0001032975-25-000059:mdna:116]
During the three months ended June 30, 2025, research and development expenses remained relatively flat, as we continued to invest in innovation at a similar level as compared to the three months ended June 30, 2024.

[0001032975-25-000059:mdna:117]
[same as prior period, unchanged from 0001032975-25-000008:mdna:118]

[0001032975-25-000059:mdna:118]
[same as prior period, unchanged from 0001032975-25-000008:mdna:119]

[0001032975-25-000059:mdna:119]
During the three months ended June 30, 2025, general and administrative expenses increased $4.3 million, compared to the three months ended June 30, 2024, primarily driven by higher performance-based stock compensation expense.

[0001032975-25-000059:mdna:120]
[same as prior period, unchanged from 0001032975-25-000008:mdna:121]

[0001032975-25-000059:mdna:121]
[same as prior period, unchanged from 0001032975-25-000008:mdna:122]

[0001032975-25-000059:mdna:122]
During the three months ended June 30, 2025, amortization of intangible assets and acquisition-related costs remained flat, compared to the three months ended June 30, 2024.

[0001032975-25-000059:mdna:123]
[same as prior period, unchanged from 0001032975-25-000008:mdna:124]

[0001032975-25-000059:mdna:124]
The restructuring charges, net, for the three months ended June 30, 2025 were related to costs incurred as a result of our restructuring plan initiated during the fourth quarter of fiscal year 2025, which is expected to be substantially completed in fiscal 2026. The restructuring charges, net, for the three months ended June 30, 2024, were related to costs incurred as a result of our restructuring plan initiated during fiscal year 2023, which was substantially completed during fiscal year 2024.

[0001032975-25-000059:mdna:125]
[same as prior period, unchanged from 0001032975-25-000008:mdna:126]

[0001032975-25-000059:mdna:126]
Interest income for the three months ended June 30, 2025 and 2024 was as follows (in thousands):

[0001032975-25-000059:mdna:127]
|  |  | Three Months Ended June 30, |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |
| Interest income |  | $ | 11,229 |  |  | $ | 15,790 |  |  |  |  |  |

[0001032975-25-000059:mdna:128]
We invest in highly liquid instruments with an original maturity of three months or less at the date of purchase, which are classified as cash equivalents. During the three months ended June 30, 2025, interest income decreased $4.6 million, compared to the three months ended June 30, 2024, primarily driven by decreases in the cash equivalents balance and interest rates.

[0001032975-25-000059:mdna:129]
[same as prior period, unchanged from 0001032975-25-000008:mdna:130]

[0001032975-25-000059:mdna:130]
Other income (expense), net for the three months ended June 30, 2025 and 2024 was as follows (in thousands):

[0001032975-25-000059:mdna:131]
|  |  | Three Months Ended June 30, |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |
| Investment gain related to the deferred compensation plan |  | $ | 2,060 |  |  | $ | 447 |  |  |  |  |  |
| Currency exchange loss, net |  | (2,003) |  |  | (2,318) |  |  |  |  |  |
| Loss on investments, net |  | (393) |  |  | (1,186) |  |  |  |  |  |
| Non-service cost net pension income and other |  | 1,498 |  |  | 1,159 |  |  |  |  |  |
| Total |  | $ | 1,162 |  |  | $ | (1,898) |  |  |  |  |  |

[0001032975-25-000059:mdna:132]
Investment gain related to the deferred compensation plan represents earnings, gains, and losses on marketable securities related to a deferred compensation plan offered by one of our subsidiaries. The increase in investment gain for three months ended June 30, 2025, compared to the three months ended June 30, 2024, primarily relates to the change in market performance of the underlying securities.

[0001032975-25-000059:mdna:133]
Currency exchange loss, net, relates to balances denominated in currencies other than the functional currency in our subsidiaries, as well as the sale of currencies, and gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses. The loss for the three months ended June 30, 2025 was primarily due to fluctuations in currency exchange rates of the Swiss Franc and New Taiwan dollar against the U.S. Dollar. The loss for the three months ended June 30, 2024 was primarily due to fluctuations in the currency exchange rates of the Mexican Peso and Japanese Yen against the U.S. Dollar.

[0001032975-25-000059:mdna:134]
Loss on investments, net, includes unrealized gain (loss) from the change in fair value of investments, income (loss) on equity-method investments and impairment of investments during the periods presented, as applicable. The loss on investments, net, for the three months ended June 30, 2025 and the three months ended June 30, 2024 was not material. See Note 6 to our condensed consolidated financial statements for additional information.

[0001032975-25-000059:mdna:135]
[same as prior period, unchanged from 0001032975-25-000008:mdna:137]

[0001032975-25-000059:mdna:136]
The provision for income taxes and effective income tax rates for the three months ended June 30, 2025 and 2024 were as follows (Dollars in thousands):

[0001032975-25-000059:mdna:137]
|  |  | Three Months Ended June 30, |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |
| Provision for income taxes |  | $ | 28,470 |  |  | $ | 25,558 |  |  |  |  |  |
| Effective income tax rate |  | 16.3 | % |  | 15.3 | % |  |  |  |  |

[0001032975-25-000059:mdna:138]
The change in the effective income tax rate for the three months ended June 30, 2025, compared with the three months ended June 30, 2024, was primarily due to the change in the mix of income and losses in the various tax jurisdictions in which we operate, less tax incentives for foreign derived intangible income and R&D as compared to prior period, and less benefit on stock based compensation as compared to prior period, offset with a change in uncertain tax positions.

[0001032975-25-000059:mdna:139]
On July 4, 2025, the One Big Beautiful Bill Act (the "OBBBA") was enacted into law in the United States and will be generally effective for us beginning in fiscal year 2027. The OBBBA includes numerous provisions that affect corporate taxation, impacting areas such as R&D expensing, bonus depreciation, and international tax provisions. We have reviewed the provisions of the OBBBA to determine the potential impact on our financial statements. Based on this review, and considering our current tax position and operations, at this time we do not expect the OBBBA to have a material impact on our income taxes, including current and deferred tax balances and the

[0001032975-25-000059:mdna:140]
effective tax rate. However, we are still in the process of evaluating the full impact of the OBBBA and any material changes to our assessment will be disclosed in future filings as required.

[0001032975-25-000059:mdna:141]
For the three months ended June 30, 2025, we assessed our exposure to the OECD Pillar Two global minimum tax rules. We have determined that, for the fiscal year 2026, most jurisdictions in which we operate should qualify for the transitional Country-by-Country Reporting ("CbCR") safe harbor, as outlined in the OECD Administrative Guidance and enacted domestic legislation. Our CbCR has been prepared in accordance with the requirements for a Qualified CbCR, using qualified financial statements. Based on this data, most jurisdictions continue to meet safe harbor qualifications at 16% tax rates, and therefore, we are only required to perform a detailed Pillar Two top-up tax calculation for limited jurisdictions. The estimated top up tax for fiscal year 2026 is not material and has been included in the calculation of our annual effective tax rate. The OECD and participating countries continue to issue underlying rules and administrative guidance related to Pillar Two, and we continue to monitor the relevant developments.

[0001032975-25-000059:mdna:142]
[same as prior period, unchanged from 0001032975-25-000008:mdna:147]

[0001032975-25-000059:mdna:143]
[same as prior period, unchanged from 0001032975-25-000008:mdna:148]

[0001032975-25-000059:mdna:144]
As of June 30, 2025, we had cash and cash equivalents of $1,487.8 million, compared with $1,503.2 million as of March 31, 2025. Our cash and cash equivalents consist of bank demand deposits, short-term time deposits, and U.S. Treasury securities, of which 48% was held in Switzerland, 28% was held in the United States, and 10% was held in Germany. We do not expect to incur any material adverse tax impact except for what has already been recognized, or to be significantly inhibited by any country in which we do business, from the repatriation of funds to Switzerland, our country of domicile.

[0001032975-25-000059:mdna:145]
As of June 30, 2025, our working capital was $1,555.5 million, compared to $1,491.6 million as of March 31, 2025. The increase was primarily driven by an increase in accounts receivable, net, partially offset by an increase in accounts payable.

[0001032975-25-000059:mdna:146]
On January 27, 2025, we entered into an unsecured revolving credit facility with a syndicate of banks (the "Credit Agreement"). The Credit Agreement provides a revolving line of credit of up to $750.0 million including the issuance of letters of credit of up to $100.0 million. The Credit Agreement terminates on January 27, 2030 unless extended in accordance with its terms. The Credit Agreement contains (1) an increase option allowing us to secure up to $250.0 million of additional commitments and (2) an extension option to extend the term by one-year which may be exercised no more than two times, subject to certain requirements. Loans under the Credit Agreement are available in U.S. Dollars, Euro, Sterling, Yen, Swiss Francs, Canadian Dollars, Australian Dollars and any other currency agreed to by each lender. Proceeds of loans made under the Credit Agreement may be used for general corporate purposes.

[0001032975-25-000059:mdna:147]
The Credit Agreement contains a maximum net debt to adjusted EBITDA ratio, compliance with which is a condition to our ability to borrow. Borrowings under the Credit Agreement will bear interest at a rate determined by reference to benchmark rates plus an applicable spread (ranging from 0% to 1.5%) based on our net leverage ratio or credit rating at the time of the borrowing. Undrawn balances available under the Credit Agreement are subject to commitment fees at the applicable rate determined by reference to our net leverage ratio or credit rating. There has been no borrowing outstanding under the Credit Agreement as of June 30, 2025.

[0001032975-25-000059:mdna:148]
In addition, we had several uncommitted, unsecured bank lines of credit and letters of credit aggregating to $174.3 million as of June 30, 2025. There are no financial covenants under these lines of credit with which we must comply. There was no borrowing outstanding under these lines of credit as of June 30, 2025. As of June 30, 2025, we had outstanding bank guarantees of $22.1 million.

[0001032975-25-000059:mdna:149]
The following tables present selected financial information and statistics as of and for the three months ended June 30, 2025 and 2024 (Dollars in thousands):

[0001032975-25-000059:mdna:150]
|  |  | As of June 30, |  |
|  |  | 2025 |  | 2024 |  |
| Accounts receivable, net |  | $ | 636,523 |  |  | $ | 591,251 |  |  |
| Accounts payable |  | $ | 549,936 |  |  | $ | 554,301 |  |  |
| Inventories |  | $ | 499,770 |  |  | $ | 459,582 |  |  |

[0001032975-25-000059:mdna:151]
|  |  | Three Months Ended June 30, |  |
|  |  | 2025 |  | 2024 |  |
| Days sales in accounts receivable (“DSO”) (Days)(1) |  | 50 |  |  | 49 |  |  |
| Days accounts payable outstanding (“DPO”) (Days)(2) |  | 74 |  |  | 80 |  |  |
| Inventory turnover (“ITO”) (x)(3) |  | 5.4 |  |  | 5.4 |  |  |

[0001032975-25-000059:mdna:152]
[same as prior period, unchanged from 0001032975-25-000008:mdna:157]

[0001032975-25-000059:mdna:153]
[same as prior period, unchanged from 0001032975-25-000008:mdna:158]

[0001032975-25-000059:mdna:154]
(3) ITO is determined using ending inventories as of the most recent quarter-end and annualized cost of goods sold (based on the most recent quarterly cost of goods sold).

[0001032975-25-000059:mdna:155]
DSO for the three months ended June 30, 2025 increased by 1 day to 50 days, compared to 49 days for the three months ended June 30, 2024, primarily due to timing of sales within the quarter.

[0001032975-25-000059:mdna:156]
DPO for the three months ended June 30, 2025 decreased by 6 days to 74 days, compared to 80 days for the three months ended June 30, 2024, primarily due to timing of inventory purchases and improved demand in the Asia Pacific and EMEA regions.

[0001032975-25-000059:mdna:157]
ITO for the three months ended June 30, 2025 was 5.4, consistent with the three months ended June 30, 2024, reflecting our efforts to align inventory levels with demand.

[0001032975-25-000059:mdna:158]
If we are not successful in launching and phasing in our new products, or market competition increases, or we are not able to sell the new products at the prices planned, it could have a material impact on our sales, gross profit, operating results including operating cash flow, and inventory turnover in the future.

[0001032975-25-000059:mdna:159]
[same as prior period, unchanged from 0001032975-25-000008:mdna:164]

[0001032975-25-000059:mdna:160]
|  |  | Three Months Ended June 30, |
|  |  | 2025 |  | 2024 |
| Net cash provided by operating activities |  | $ | 125,045 |  |  | $ | 176,029 |  |
| Net cash used in investing activities |  | (18,100) |  |  | (15,359) |  |
| Net cash used in financing activities |  | (134,433) |  |  | (145,134) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | 12,105 |  |  | (1,998) |  |
| Net increase (decrease) in cash and cash equivalents |  | $ | (15,383) |  |  | $ | 13,538 |  |

[0001032975-25-000059:mdna:161]
For the three months ended June 30, 2025, net cash provided by operating activities was $125.0 million, resulting from net income of $146.0 million, a favorable impact from adding back non-cash expenses totaling $65.2 million, and an unfavorable net change in operating assets and liabilities of $86.1 million. Non-cash adjustments were primarily related to share-based compensation expenses, depreciation and amortization. The increase in accounts receivable, net, was driven by higher sales as well as timing of sales within the quarter. The increase in accounts payable was driven by higher inventory purchases to align with demand as well as timing of inventory purchases. The decrease in accrued and other liabilities was primarily driven by payment of the fiscal year 2025 annual bonus, partially offset by higher accrued liabilities for customer marketing, pricing and incentive programs.

[0001032975-25-000059:mdna:162]
For the three months ended June 30, 2025, net cash used in investing activities was $18.1 million, primarily resulting from $16.3 million of purchases of property, plant, and equipment.

[0001032975-25-000059:mdna:163]
For the three months ended June 30, 2025, net cash used in financing activities was $134.4 million, primarily resulting from payment for repurchases of our registered shares of $121.7 million.

[0001032975-25-000059:mdna:164]
For the three months ended June 30, 2025, the effect of exchange rate changes on cash and cash equivalents was primarily driven by the exchange rate fluctuations of Swiss Franc, Euro, and New Taiwan dollar versus the U.S. Dollar. For the three months ended June 30, 2024, the effect of exchange rate changes on cash and cash equivalents was not material.

[0001032975-25-000059:mdna:165]
[same as prior period, unchanged from 0001032975-25-000008:mdna:170]

[0001032975-25-000059:mdna:166]
Our principal sources of liquidity are our cash and cash equivalents, cash flow generated from operations and, to a much lesser extent, capital markets and borrowings. Our future working capital requirements and capital expenditures may increase to support investments in product innovations and growth opportunities or to acquire or invest in complementary businesses, products, services, and technologies. Our principal uses of cash, aside from operational needs and capital expenditures, include outlays for dividends and share repurchases reflecting our commitment to return value to our shareholders.

[0001032975-25-000059:mdna:167]
In May 2025, the Board of Directors recommended that we pay cash dividends for fiscal year 2025 of CHF 1.26 per share (approximately $1.43 per share based on the exchange rate on March 31, 2025). Based on our shares outstanding, net of treasury shares, as of March 31, 2025 (148,509,018 shares), this would result in an aggregate gross dividend of approximately CHF 187.1 million (approximately $212.4 million based on the exchange rate on March 31, 2025). In fiscal year 2025, we paid a cash dividend of CHF 1.16 per share, or CHF 176.3 million (U.S. Dollar amount of $207.9 million based on the exchange rate on the date of payment) out of fiscal year 2024 retained earnings.

[0001032975-25-000059:mdna:168]
In June 2023, our Board of Directors approved a three-year share repurchase program, which allows us to use up to $1.0 billion to repurchase our shares. The 2023 share repurchase program enables us to repurchase shares for cancellation, as well as to support equity incentive plans or potential acquisitions. The Swiss Takeover Board approved the 2023 share repurchase program in July 2023 and the program became effective on July 28, 2023. In March 2025, our Board of Directors approved an increase of $600.0 million to the 2023 share repurchase program, to an aggregate amount of $1.6 billion. The Swiss Takeover Board approved this increase in April 2025 and it became effective on April 2, 2025. During the three months ended June 30, 2025, we repurchased 1.5 million shares for an aggregate cost of $124.1 million for cancellation under this share repurchase program, of which $21.2 million of the aggregate cost was not paid yet as of June 30, 2025. As of June 30, 2025, $524.3 million was available for repurchase under the 2023 share repurchase program. We plan to target share repurchases of $2 billion over the three-year period ending March 31, 2028, subject to market conditions and regulatory approvals.

[0001032975-25-000059:mdna:169]
Swiss law limits a company’s ability to hold or repurchase its own shares. The aggregate par value of all shares held in treasury by us and our subsidiaries may not exceed 10% of our issued share capital, which corresponds to approximately 16.9 million registered shares as of June 30, 2025. This limitation does not apply to shares repurchased for cancellation, due to the Board of Directors' authority under the capital band set forth in the Company's Articles of Incorporation. As of June 30, 2025, we had a total of 21.4 million shares held in treasury stock, which includes 8.2 million shares that have been repurchased for cancellation and 13.2 million shares that have been purchased to support equity incentive plans or potential acquisitions.

[0001032975-25-000059:mdna:170]
Although we enter into trading plans for systematic repurchases (e.g., 10b5-1 trading plans) from time to time, our 2023 share repurchase program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years through July 27, 2026. To the extent that the shares are repurchased to support equity incentive plans or potential acquisitions, the shares are repurchased on the ordinary trading line of Swiss Exchange ("SIX") and/or the Nasdaq Global Select Market ("Nasdaq"). Shares repurchased for cancellation purposes are repurchased via a second trading line on SIX. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.

[0001032975-25-000059:mdna:171]
If we do not generate sufficient operating cash flows to support our operations and future planned cash requirements, our operations could be harmed and our access to credit facilities could be restricted or eliminated. Although we believe that the trend of our historical cash flow generation, our projections of future operations and our available cash balances will provide sufficient liquidity to fund our operations for at least the next 12 months, market volatility driven by the current macroeconomic and geopolitical environment may increase our costs of capital and otherwise adversely affect our business, results of operations, financial condition and liquidity.

[0001032975-25-000059:mdna:172]
[same as prior period, unchanged from 0001032975-25-000008:mdna:178]

[0001032975-25-000059:mdna:173]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. There have been no material changes to our contractual obligations as previously disclosed in our Annual Report on Form 10-K for the year ended March 31, 2025. The remaining terms of our non-cancelable operating leases expire in various years through 2035.

[0001032975-25-000059:mdna:174]
[same as prior period, unchanged from 0001032975-25-000008:mdna:180]

[0001032975-25-000059:mdna:175]
As of June 30, 2025, we had non-cancelable purchase commitments of $368.7 million for inventory purchases made in the normal course of business from original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. We recorded a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with our valuation of excess and obsolete inventory. As of June 30, 2025, the liability for these purchase commitments was $23.5 million and is recorded in accrued and other current liabilities in the condensed consolidated balance sheet.

[0001032975-25-000059:mdna:176]
As of June 30, 2025, we have firm purchase commitments of $19.1 million for capital expenditures primarily related to commitments for tooling and equipment for new and existing products. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-25-000059:mdna:177]
[same as prior period, unchanged from 0001032975-25-000008:mdna:183]

[0001032975-25-000059:mdna:178]
For further detail about our contractual obligations and commitments, refer to our Annual Report on Form 10-K for the fiscal year ended March 31, 2025.

[0001032975-25-000059:mdna:179]
[same as prior period, unchanged from 0001032975-25-000008:mdna:185]

[0001032975-25-000059:mdna:180]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2025, no material amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-25-000059:mdna:181]
We also indemnify our current and former directors and certain current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. We are unable to reasonably estimate the maximum amount that could be payable under these arrangements because these

[0001032975-25-000059:mdna:182]
exposures are not capped, the obligations are conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-25-000059:mdna:183]
Legal Proceedings

[0001032975-25-000059:mdna:184]
From time to time, we are involved in claims and legal proceedings that arise in the ordinary course of our business. For more information about Legal Proceedings, see Part II Item 1 Legal Proceedings of this quarterly report on Form 10-Q for the period ended June 30, 2025.
