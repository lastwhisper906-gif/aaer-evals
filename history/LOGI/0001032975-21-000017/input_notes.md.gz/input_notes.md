# LOGI notes — 0001032975-21-000017


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001032975-21-000017:notes:1]
Portions of the registrant's Proxy Statement for the 2021 Annual Meeting of Shareholders are incorporated herein by reference in Part III of this Annual Report on Form 10-K to the extent stated herein.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-21-000017:notes:2]
Summary of Significant Accounting Policies
Basis of Presentation

[0001032975-21-000017:notes:3]
The consolidated financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States ("U.S. GAAP").

[0001032975-21-000017:notes:4]
Fiscal Year

[0001032975-21-000017:notes:5]
The Company's fiscal year ends on March 31. Interim quarters are generally thirteen-week periods, each ending on a Friday. For purposes of presentation, the Company has indicated its quarterly periods end on the last day of the calendar quarter.

[0001032975-21-000017:notes:6]
Use of Estimates

[0001032975-21-000017:notes:7]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the consolidated financial statements. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill and intangible assets acquired from business acquisitions, contingent consideration for a business acquisition and periodic reassessment of its fair value, valuation of investment in privately held companies classified under Level 3 fair value hierarchy, pension obligations, accruals for customer incentives, cooperative marketing, and pricing programs ("Customer Programs") and related breakage when appropriate, inventory valuation, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

[0001032975-21-000017:notes:8]
Risks and Uncertainties

[0001032975-21-000017:notes:9]
We are subject to risks and uncertainties as a result of the novel coronavirus ("COVID-19"). Capital markets and economies worldwide have been negatively impacted by COVID-19 and it is still unclear how lasting and deep the economic impacts will be. During fiscal year 2021, the COVID-19 pandemic had mixed effects on the Company’s results of operations. While there was high demand for and consumption of certain of our products that led to increased sales and operating income during fiscal year 2021, at the same time the Company experienced disruptions to our supply chain and logistics services, inventory constraints, and increased logistics costs, as it attempted to address the effects of COVID-19. The ongoing and full extent of the impact of the COVID-19 pandemic on the Company's business and operational and financial performance and condition, including the sustainability of its effect on trends positive to the Company, is uncertain and will depend on many factors outside the Company's control, including but not limited to the timing, extent, duration and effects of the virus and any of its mutations, the availability of vaccines and their global deployment, the development of effective treatments, the imposition of effective public safety and other protective measures and the public's response to such measures, the impact of COVID-19 on the global economy and demand for the Company's products and services. Should the COVID-19 pandemic or global economic slowdown not improve or worsen, or if the Company's attempt to mitigate its impact on its operations and costs is not successful, the Company's business, results of operations, financial condition and prospects may be adversely affected.

[0001032975-21-000017:notes:10]
Currencies

[0001032975-21-000017:notes:11]
The functional currency of the Company's operations is primarily the U.S. Dollar. Certain operations use the Euro, Chinese Renminbi, Swiss Franc, or other local currencies as their functional currencies. The financial statements of the Company's subsidiaries whose functional currency is other than the U.S. Dollar are translated to U.S. Dollars using period-end rates of exchange for assets and liabilities and monthly average rates for sales, income and expenses. Cumulative translation gains and losses are included as a component of shareholders' equity in accumulated other comprehensive loss. Gains and losses arising from transactions denominated in currencies other than a subsidiary's functional currency are reported in other income (expense), net in the consolidated statements of operations.

[0001032975-21-000017:notes:12]
Revenue Recognition

[0001032975-21-000017:notes:13]
Revenue is recognized when a customer obtains control of promised goods or service in an amount that reflects the transaction price the Company expects to receive in exchange for those goods or services.

[0001032975-21-000017:notes:14]
Substantially all revenue recognized by the Company relates to the contracts with customers to sell products that allow people to connect through gaming, video, computing, music and other digital platforms. These products are hardware devices, which may include embedded software that function together, and are considered as one performance obligation. Hardware devices are generally plug and play, requiring no configuration and little or no installation. Revenue is recognized at a point in time when control of the products is transferred to the customer which generally occurs upon shipment. The Company’s sales contracts with its customers have a one year or shorter term. The Company elects not disclosing the value of unsatisfied performance obligations for contracts with an original expected duration of one year or less.

[0001032975-21-000017:notes:15]
The Company also provides post-contract customer support (“PCS”) for certain products and related software, which includes unspecified software updates and upgrades, bug fixes and maintenance. The transaction price is allocated to two performance obligations in such contracts, based on a relative standalone selling price. The transaction price allocated to PCS is recognized as revenue on a straight-line basis, which reflects the pattern of delivery of PCS, over the estimated term of the support that is between one to two years. Deferred revenue associated with remaining PCS performance obligation as of March 31, 2021 and March 31, 2020 was not material.

[0001032975-21-000017:notes:16]
The Company also recognizes revenue from subscription services that provide professional streamers with access to streaming software and tools that represent a single stand-ready performance obligation. Subscriptions are paid for at the time of or in advance of delivering the services. The proceeds received in advance from such arrangements is recognized as deferred revenue and then recognized as revenue ratably over the subscription period.

[0001032975-21-000017:notes:17]
The Company normally requires payment from customers within thirty to sixty days from the invoice date. However, terms may vary by customer type, by country and by selling season. Extended payment terms are sometimes offered to a limited number of customers during the second and third fiscal quarters. The Company does not modify payment terms on existing receivables. The Company's contracts with customers do not include significant financing components as the period between the satisfaction of performance obligations and timing of payment are generally within one year.

[0001032975-21-000017:notes:18]
The transaction price received by the Company from sales to its distributors, retail companies ("retailers"), and authorized resellers is calculated as selling price net of variable consideration which may include product returns and the Company’s payments for Customer Programs related to current period product revenue. The estimated impact of these programs is recorded as a reduction of transaction price or as an operating expense if the Company receives a distinct good or service from the customer and can reasonably estimate the fair value of that good or service received. Customer Programs require management to estimate the percentage of those programs which will not be claimed in the current period or will not be earned by customers, which is commonly referred to as "breakage." Breakage is estimated based on historical claim experience, the period in which customer claims are expected to be submitted, specific terms and conditions with customers and other factors. The Company accounts for breakage as part of variable consideration, subject to constraint, and records the estimated impact in the same period when revenue is recognized at the expected value. Assessing the period in which claims are expected to be submitted and the relevance of the historical claim experience require significant management judgment to estimate the breakage of Customer Programs in any accounting period.

[0001032975-21-000017:notes:19]
The Company enters into cooperative marketing arrangements with many of its customers and with certain indirect partners, allowing customers to receive a credit equal to a set percentage of their purchases of the Company's products, or a fixed dollar amount for various marketing and incentive programs. The objective of these arrangements is to encourage advertising and promotional events to increase sales of the Company's products.

[0001032975-21-000017:notes:20]
Customer incentive programs include consumer rebates and performance-based incentives. Consumer rebates are offered to the Company's customers and indirect partners at the Company's discretion for the primary benefit of end-users. In addition, the Company offers performance-based incentives to many of its customers and indirect partners based on predetermined performance criteria. At management's discretion, the Company also offers special pricing discounts to certain customers. Special pricing discounts are usually offered only for limited time periods or for sales of selected products to specific indirect partners.

[0001032975-21-000017:notes:21]
Cooperative marketing arrangements and customer incentive programs are considered variable consideration, which the Company estimates and records as a reduction to revenue at the time of sale based on negotiated terms, historical experiences, forecasted incentives, anticipated volume of future purchases, and inventory levels in the channel.

[0001032975-21-000017:notes:22]
The Company has agreements with certain customers that contain terms allowing price protection credits to be issued in the event of a subsequent price reduction. Management's decision to make price reductions is influenced by product life cycle stage, market acceptance of products, the competitive environment, new product introductions and other factors. Accruals for estimated expected future pricing actions are recognized at the time of sale based on analyses of historical pricing actions by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information, such as stage of product life-cycle.

[0001032975-21-000017:notes:23]
Product return rights vary by customer. Estimates of expected future product returns qualify as variable consideration and are recorded as a reduction of the transaction price of the contract at the time of sale based on an analyses of historical return trends by customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information. The Company assesses the estimated asset for recovery value for impairment and adjusts the value of the asset for any impairment. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time but are sufficiently predictable to allow the Company to estimate expected future product returns.

[0001032975-21-000017:notes:24]
Typically, variable consideration does not need to be constrained as estimates are based on predictive historical data or future commitments that are planned and controlled by the Company. However, the Company continues to assess variable consideration estimates such that it is probable that a significant reversal of revenue will not occur.

[0001032975-21-000017:notes:25]
The Company regularly evaluates the adequacy of its estimates for Customer Programs and product returns. Future market conditions and product transitions may require the Company to take action to change such programs and related estimates. When the variables used to estimate these costs change, or if actual costs differ significantly from the estimates, the Company would be required to increase or reduce revenue or operating expenses to reflect the impact. During the year ended March 31, 2021, changes to these estimates related to performance obligations satisfied in prior periods were not material.

[0001032975-21-000017:notes:26]
Sales taxes and value-added taxes (“VAT”) collected from customers, if applicable, which are remitted to governmental authorities are not included in revenue, and are reflected as a liability on the consolidated balance sheets.

[0001032975-21-000017:notes:27]
In May 2014, the FASB issued ASU 2014-09, "Revenue from Contracts with Customers (Topic 606)" (ASU 2014-09). The Company adopted this standard effective April 1, 2018 using the modified retrospective method applied to those contracts that were not completed as of April 1, 2018.  The Company recorded a net decrease to retained earnings of $10.8 million as of April 1, 2018 due to the cumulative impact of adopting ASU 2014-09.

[0001032975-21-000017:notes:28]
Shipping and Handling Costs

[0001032975-21-000017:notes:29]
The Company's shipping and handling costs are included in the cost of goods sold in the consolidated statements of operations for all periods presented.

[0001032975-21-000017:notes:30]
Contract Balances

[0001032975-21-000017:notes:31]
The Company records accounts receivable from contracts with customers when it has an unconditional right to consideration, as accounts receivable, net on the consolidated balance sheet.

[0001032975-21-000017:notes:32]
The Company records contract liabilities when cash payments are received or due in advance of performance, primarily for implied support and subscriptions. Contract liabilities are included in accrued and other current liabilities and other non-current liabilities on the consolidated balance sheets.

[0001032975-21-000017:notes:33]
As of March 31, 2021 and 2020, the Company did not have any material contract liabilities balances or changes.

[0001032975-21-000017:notes:34]
Contract Costs

[0001032975-21-000017:notes:35]
The Company recognizes the incremental costs of obtaining contracts as an expense when incurred if the amortization period of the assets that otherwise would have been recognized is one year or less. These costs are

[0001032975-21-000017:notes:36]
included in marketing and selling expenses in the consolidated statements of operations. As of March 31,2021 and March 31, 2020, the Company did not have any material deferred contract costs.

[0001032975-21-000017:notes:37]
Research and Development Costs

[0001032975-21-000017:notes:38]
Costs related to research, design and development of products, which consist primarily of personnel, product design and infrastructure expenses, are charged to research and development expense as they are incurred.

[0001032975-21-000017:notes:39]
Advertising Costs

[0001032975-21-000017:notes:40]
Advertising costs are recorded as either a marketing and selling expense or a deduction from revenue as they are incurred. Advertising costs paid or reimbursed by the Company to direct or indirect customers must have an identifiable benefit and an estimable fair value in order to be classified as an operating expense. If these criteria are not met, the payment is classified as a reduction of revenue. Advertising costs recorded as marketing and selling expense are expensed as incurred. Total advertising costs including those characterized as revenue deductions during fiscal years 2021, 2020 and 2019 were  $450.0 million, $298.6 million and $278.2 million, respectively, out of which $168.2 million, $64.5 million, and $58.8 million, respectively, were included as operating expense in the consolidated statements of operations.

[0001032975-21-000017:notes:41]
Cash Equivalents

[0001032975-21-000017:notes:42]
The Company classifies all highly liquid instruments purchased with an original maturity of three months or less at the date of purchase to be cash equivalents. Cash equivalents are carried at cost, which approximates their fair value.

[0001032975-21-000017:notes:43]
All of the Company's bank time deposits have an original maturity of three months or less and are classified as cash equivalents and are recorded at cost, which approximates their fair value.

[0001032975-21-000017:notes:44]
Concentration of Credit Risk

[0001032975-21-000017:notes:45]
Financial instruments that potentially subject the Company to concentrations of credit risk consist principally of cash and cash equivalents and accounts receivable. The Company maintains cash and cash equivalents with various financial institutions to limit exposure with any one financial institution, but is exposed to credit risk in the event of default by financial institutions to the extent that cash balances with individual financial institutions are in excess of amounts that are insured.

[0001032975-21-000017:notes:46]
The Company sells to large distributors and retailers and, as a result, maintains individually significant receivable balances with such customers.

[0001032975-21-000017:notes:47]
The Company had the following customers that individually comprised 10% or more of its gross sales:

[0001032975-21-000017:notes:48]
|  |  | Years Ended March 31, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Customer A |  | 14 | % |  | 12 | % |  | 13 | % |
| Customer B |  | 13 | % |  | 14 | % |  | 14 | % |

[0001032975-21-000017:notes:49]
The Company had the following customers that individually comprised 10% or more of accounts receivable:

[0001032975-21-000017:notes:50]
|  |  | March 31, |
|  |  | 2021 |  | 2020 |
| Customer A |  | 12 | % |  | 12 | % |
| Customer B |  | 20 | % |  | 12 | % |
| Customer C |  | 10 | % |  | — | % |

[0001032975-21-000017:notes:51]
The Company manages its accounts receivable credit risk through ongoing credit evaluation of its customers' financial conditions. The Company generally does not require collateral from its customers.

[0001032975-21-000017:notes:52]
Allowances for Doubtful Accounts

[0001032975-21-000017:notes:53]
Allowances for doubtful accounts are maintained for expected credit losses resulting from the Company's customers' inability to make required payments. The allowances are based on the Company's regular assessment of various factors, including the credit-worthiness and financial condition of specific customers, historical experience with bad debts and customer deductions, receivables aging, current economic conditions, reasonable and supportable forecasts of future economic conditions, and other factors that may affect our ability to collect from customers.

[0001032975-21-000017:notes:54]
Inventories

[0001032975-21-000017:notes:55]
Inventories are stated at the lower of cost and net realizable value. Costs are computed under the standard cost method, which approximates actual costs determined on the first-in, first-out basis. The Company records write-downs of inventories which are obsolete or in excess of anticipated demand or net realizable value based on a consideration of marketability and product life cycle stage, product development plans, component cost trends, historical sales and demand forecasts which consider the assumptions about future demand and market conditions. Inventory on hand which is not expected to be sold or utilized is considered excess, and the Company recognizes the write-down in cost of goods sold at the time of such determination. The write-down is determined by the excess of cost over net realizable value. Net realizable value is the estimated selling price in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. At the time of loss recognition, new cost basis per unit and lower-cost basis for that inventory are established and subsequent changes in facts and circumstances would not result in an increase in the cost basis.

[0001032975-21-000017:notes:56]
As of March 31, 2021 and 2020, the Company also recorded a liability of $11.8 million and $9.6 million, respectively, arising from firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with its valuation of excess and obsolete inventory. Such liability is included in accrued and other current liabilities on the consolidated balance sheets.

[0001032975-21-000017:notes:57]
Property, Plant and Equipment

[0001032975-21-000017:notes:58]
Property, plant and equipment are stated at cost. Additions and improvements are capitalized, and maintenance and repairs are expensed as incurred. The Company capitalizes the cost of software developed for internal use in connection with major projects. Costs incurred during the feasibility stage are expensed, whereas direct costs incurred during the application development stage are capitalized.

[0001032975-21-000017:notes:59]
Depreciation expense is recognized using the straight-line method. Plant and buildings are depreciated over estimated useful lives of twenty-five years, equipment over useful lives from three to five years, internal-use software over useful lives from three to ten years, tooling over useful lives from six months to one year, and leasehold improvements over the lesser of the term of the lease or ten years.

[0001032975-21-000017:notes:60]
When property and equipment is retired or otherwise disposed of, the cost and accumulated depreciation are relieved from the accounts and the net gain or loss is included in cost of goods sold or operating expenses, depending on the nature of the property and equipment.

[0001032975-21-000017:notes:61]
Leases

[0001032975-21-000017:notes:62]
In February 2016, the FASB issued ASU 2016-02, "Leases (Topic 842)" (ASU 2016-02 or Topic 842). which requires a lessee to recognize right-of-use ("ROU") assets and lease liabilities arising from operating and financing leases with terms longer than 12 months on the consolidated balance sheets and to disclose key information about leasing arrangements. The Company adopted the new standard effective April 1, 2019 and recorded a ROU asset and lease liability related to its operating leases. The Company used the modified retrospective approach with the effective date as the date of initial application. Accordingly, the Company applied the new lease standard prospectively to leases existing or commencing on or after April 1, 2019. Prior period balances and disclosures have not been restated.

[0001032975-21-000017:notes:63]
The Company determines if an arrangement is a lease or contains a lease at contract inception. Operating lease ROU assets are included in other assets, short-term lease liabilities are included in accrued and other current liabilities, and long-term lease liabilities are included in other non-current liabilities on the Company's consolidated balance sheet. Leases with an initial term of 12 months or less are not recorded on the balance sheet. For the Company's operating leases, the Company accounts for the lease and non-lease components as a single lease component. Lease expense is recognized on a straight-line basis over the lease term.

[0001032975-21-000017:notes:64]
For operating leases, the lease liability is initially and subsequently measured at the present value of the unpaid lease payments at lease commencement date.  As most of the leases do not provide an implicit rate, the Company generally uses its incremental borrowing rate as the discount rate for the lease. The Company's incremental borrowing rate is the rate of interest it would have to pay on a collateralized basis to borrow an amount equal to the lease payments under similar terms. Because the Company does not generally borrow in a collateralized basis, it uses its understanding of what its collateralized credit rating would be as an input to deriving an appropriate incremental borrowing rate. The operating lease right-of-use asset includes any lease payments made and excludes lease incentives.

[0001032975-21-000017:notes:65]
Intangible Assets

[0001032975-21-000017:notes:66]
The Company's intangible assets principally include goodwill, acquired technology, trademarks, and customer relationships and contracts. Intangible assets with finite lives, which include acquired technology, trademarks, customer relationships and contracts, and others are carried at cost and amortized using the straight-line method over their useful lives ranging from one to ten years. Intangible assets with indefinite lives, which include only goodwill and in-process research and development ("IPR&D"), are recorded at cost and evaluated at least annually for impairment.

[0001032975-21-000017:notes:67]
Impairment of Long-Lived Assets

[0001032975-21-000017:notes:68]
The Company reviews long-lived assets, such as property and equipment, and finite-lived intangible assets, for impairment whenever events indicate that the carrying amounts might not be recoverable. Recoverability of property and equipment and finite-lived intangible assets is measured by comparing the projected undiscounted net cash flows associated with those assets to their carrying values. If an asset is considered impaired, it is written down to its fair value, which is determined based on the asset's projected discounted cash flows or appraised value, depending on the nature of the asset. For purposes of recognition of impairment for assets held for use, the Company groups assets and liabilities at the lowest level for which cash flows are separately identifiable.

[0001032975-21-000017:notes:69]
Impairment of Goodwill

[0001032975-21-000017:notes:70]
Goodwill represents the excess of the purchase price over the fair value of the net tangible and identifiable intangible assets acquired in each business combination. The Company conducts a goodwill impairment analysis annually at December 31 or more frequently if indicators of impairment exist or if a decision is made to sell or exit a business. Significant judgments are involved in determining if an indicator of impairment has occurred. Such indicators may include deterioration in general economic conditions, negative developments in equity and credit markets, adverse changes in the markets in which an entity operates, increases in input costs that have a negative effect on earnings and cash flows, or a trend of negative or declining cash flows over multiple periods, among others. The fair value that could be realized in an actual transaction may differ from that used to evaluate the impairment of goodwill.

[0001032975-21-000017:notes:71]
In reviewing goodwill for impairment, the Company has the option to first assess qualitative factors to determine whether the existence of events or circumstances leads to a determination that it is more likely than not (greater than 50%) that the estimated fair value of a reporting unit is less than its carrying amount. The Company also may elect not to perform the qualitative assessment and, instead, proceed directly to the quantitative impairment test. The ultimate outcome of the goodwill impairment review for a reporting unit should be the same whether the Company chooses to perform the qualitative assessment or proceeds directly to the quantitative impairment test. The Company operates as one reporting unit. For the year ended March 31, 2021, the Company elected to perform a qualitative assessment and determined that an impairment was not more likely than not and no further analysis was required.

[0001032975-21-000017:notes:72]
Income Taxes

[0001032975-21-000017:notes:73]
The Company provides for income taxes using the asset and liability method, which requires that deferred tax assets and liabilities be recognized for the expected future tax consequences of temporary differences resulting from differing treatment of items for tax and financial reporting purposes, and for operating losses and tax credit carryforwards. In estimating future tax consequences, expected future events are taken into consideration, with the exception of potential tax law or tax rate changes. The Company records a valuation allowance to reduce deferred tax assets to amounts management believes are more likely than not to be realized.

[0001032975-21-000017:notes:74]
The Company's assessment of uncertain tax positions requires that management makes estimates and judgments about the application of tax law, the expected resolution of uncertain tax positions and other matters. In the event that uncertain tax positions are resolved for amounts different than the Company's estimates, or the

[0001032975-21-000017:notes:75]
related statutes of limitations expire without the assessment of additional income taxes, the Company will be required to adjust the amounts of the related assets and liabilities in the period in which such events occur. Such adjustments may have a material impact on the Company's income tax provision and its results of operations.

[0001032975-21-000017:notes:76]
Fair Value of Financial Instruments

[0001032975-21-000017:notes:77]
The carrying value of certain of the Company's financial instruments, including cash equivalents, accounts receivable and accounts payable approximates their fair value due to their short maturities.

[0001032975-21-000017:notes:78]
The Company's investment securities portfolio consists of bank time deposits with an original maturity of three months or less and marketable securities (money market and mutual funds) related to a deferred compensation plan.

[0001032975-21-000017:notes:79]
The Company's trading investments related to the deferred compensation plan are reported at fair value based on quoted market prices. The marketable securities related to the deferred compensation plan are classified as non-current trading investments, as they are intended to fund the deferred compensation plan's long-term liability. Since participants in the deferred compensation plan may select the mutual funds in which their compensation deferrals are invested within the confines of the Rabbi Trust which holds the marketable securities, the Company has designated these marketable securities as trading investments, although there is no intent to actively buy and sell securities with the objective of generating profits on short-term differences in market prices. These securities are recorded at fair value based on quoted market prices. Earnings, gains and losses on trading investments are included in other income (expense), net in the consolidated statements of operations.

[0001032975-21-000017:notes:80]
The Company also holds non-marketable investments in equity and other securities that are accounted for under the equity method, which are classified as other assets. In addition, the Company has certain investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. The Company elected the measurement alternative to record these investments at cost and to adjust for impairments and observable price changes resulting from transactions with the same issuer within the statement of operations.

[0001032975-21-000017:notes:81]
Net Income per Share

[0001032975-21-000017:notes:82]
Basic net income per share is computed by dividing net income by the weighted average outstanding shares. Diluted net income per share is computed using the weighted average outstanding shares and dilutive share equivalents. Dilutive share equivalents consist of share-based awards, including stock options, purchase rights under employee share purchase plan, and restricted stock units ("RSUs").

[0001032975-21-000017:notes:83]
The dilutive effect of in-the-money share-based compensation awards is calculated based on the average share price for each fiscal period using the treasury stock method.

[0001032975-21-000017:notes:84]
Share-Based Compensation Expense

[0001032975-21-000017:notes:85]
Share-based compensation expense includes compensation expense for share-based awards granted based on the grant date fair value. The grant date fair value for stock options and stock purchase rights is estimated using the Black-Scholes-Merton option-pricing valuation model. The grant date fair value of RSUs which vest upon meeting certain market conditions is estimated using the Monte-Carlo simulation method. The grant date fair value of time-based and performance-based RSUs is calculated based on the market price on the date of grant, reduced by estimated dividend yield prior to vesting. With respect to awards with service conditions only, compensation expense is recognized ratably over the vesting period of the awards. For performance-based RSUs, the Company recognizes the estimated expense using a graded-vesting method over requisite service periods of three years when the performance condition is determined to be probable. The performance period and the service period of the market-based grants of the Company are both approximately three years and the estimated expense is recognized ratably over the service period.

[0001032975-21-000017:notes:86]
Product Warranty Accrual

[0001032975-21-000017:notes:87]
All of the Company's products are covered by warranty to be free from defects in material and workmanship for periods ranging from one year to three years. The warranty period varies by product and by region. The Company’s warranty does not provide a service beyond assuring that the product complies with agreed-upon specifications and is not sold separately. The warranty the Company provides qualifies as an assurance warranty and is not treated as a separate performance obligation. The Company estimates cost of product warranties at the time the related revenue is recognized based on historical warranty claim rates, historical costs, and knowledge of specific product failures that are outside of the Company's typical experience. The Company accrues a warranty liability for

[0001032975-21-000017:notes:88]
estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. Each quarter, the Company reevaluates estimates to assess the adequacy of recorded warranty liabilities. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly. If actual product failure rates or repair costs differ from estimates, revisions to the estimated warranty liabilities would be required and could materially affect the Company's results of operations.

[0001032975-21-000017:notes:89]
Comprehensive Income (Loss)

[0001032975-21-000017:notes:90]
Comprehensive income (loss) is defined as the total change in shareholders' equity during the period other than from transactions with shareholders. Comprehensive income (loss) consists of net income (loss) and other comprehensive income (loss). Other comprehensive income (loss) is comprised of currency translation adjustments from those entities not using the U.S. Dollar as their functional currency, net deferred gains and losses and prior service costs and credits for defined benefit pension plans, and net deferred gains and losses on hedging activity.

[0001032975-21-000017:notes:91]
Treasury Shares

[0001032975-21-000017:notes:92]
The Company periodically repurchases shares in the market at fair value. Shares repurchased are recorded at cost as a reduction of total shareholders' equity. Treasury shares held may be reissued to satisfy the exercise of employee stock options and purchase rights and the vesting of restricted stock units, or may be canceled with shareholder approval. Treasury shares that are reissued are accounted for using the first-in, first-out basis.

[0001032975-21-000017:notes:93]
Derivative Financial Instruments

[0001032975-21-000017:notes:94]
The Company enters into foreign exchange forward contracts to reduce the short-term effects of currency fluctuations on certain foreign currency receivables or payables and to hedge against exposure to changes in currency exchange rates related to its subsidiaries' forecasted inventory purchases.

[0001032975-21-000017:notes:95]
Gains and losses for changes in the fair value of the effective portion of the Company's forward contracts related to forecasted inventory purchases are deferred as a component of accumulated other comprehensive income (loss) until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. The Company presents the earnings impact from forward points in the same line item that is used to present the earnings impact of the hedged item, i.e. cost of goods sold, for hedging forecasted inventory purchases.

[0001032975-21-000017:notes:96]
Gains or losses from changes in the fair value of forward contracts that offset translation losses or gains on foreign currency receivables or payables are recognized immediately and included in other income (expense), net in the consolidated statements of operations.

[0001032975-21-000017:notes:97]
Restructuring Charges

[0001032975-21-000017:notes:98]
The Company's restructuring charges consist of employee severance, one-time termination benefits and ongoing benefits related to the reduction of its workforce, and other costs. Liabilities for costs associated with a restructuring activity are measured at fair value and are recognized when the liability is incurred, as opposed to when management commits to a restructuring plan. One-time termination benefits are expensed at the date the entity notifies the employee, unless the employee must provide future service, in which case the benefits are expensed ratably over the future service period. Ongoing benefits are expensed when restructuring activities are probable and the benefit amounts are estimable. Other costs primarily consist of legal, consulting, and other costs related to employee terminations are expensed when incurred. Termination benefits are calculated based on regional benefit practices and local statutory requirements.

[0001032975-21-000017:notes:99]
Recent Accounting Pronouncements Adopted

[0001032975-21-000017:notes:100]
In June 2016, the FASB issued ASU 2016-13, "Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments" (ASU 2016-13), which was further updated and clarified by the FASB through issuance of additional related ASUs, replaces the incurred-loss impairment methodology and requires immediate recognition of estimated credit losses expected to occur for most financial assets, including trade receivables. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. The Company adopted this standard effective April 1, 2020, using a modified retrospective approach. Upon adoption, the Company updated its credit loss models to utilize a forward-looking current expected credit losses (CECL) model in place of the incurred loss methodology for financial instruments measured at amortized cost, including accounts receivable. The cumulative effect adjustment from adoption was $0.6 million to the Company's consolidated financial statements.

[0001032975-21-000017:notes:101]
In August 2018, the FASB issued ASU 2018-13, "Fair Value Measurement (Topic 820): Disclosure Framework - Changes to the Disclosure Requirements for Fair Value Measurements" (ASU 2018-13), which eliminates, adds and modifies certain disclosure requirements for fair value measurements, including eliminating the requirement to disclose the amount of and reasons for transfers between Level 1 and Level 2 of the fair value hierarchy, and requiring the range and weighted average used to develop significant unobservable inputs for Level 3 fair value measurements.  Some of these disclosure changes must be applied prospectively while others retrospectively depending on requirement. The Company adopted this standard effective April 1, 2020. The adoption of ASU 2018-13 did not have a material impact on the Company's consolidated financial statements.

[0001032975-21-000017:notes:102]
In August 2018, the FASB issued ASU 2018-14, "Compensation - Retirement Benefits - Defined Benefits Plans - General (Subtopic 715-20): Disclosure Framework - Changes to the Disclosure Requirements for Defined Benefit Plans" (ASU 2018-14), which requires that the Company remove various disclosures that no longer are considered cost-beneficial, namely amounts in accumulated other comprehensive income expected to be recognized as components of net periodic benefit cost over the next fiscal year.  Further, ASU 2018-14 requires disclosure or clarification of the reasons for significant gains or losses related to changes in the benefit obligation for the period.  The Company adopted this standard effective April 1, 2020, using a retrospective approach.  The adoption of this guidance modified the disclosures included in "Note 5—Employee Benefit Plans" but did not have a material impact on the Company's consolidated financial statements.

[0001032975-21-000017:notes:103]
Recent Accounting Pronouncements To Be Adopted

[0001032975-21-000017:notes:104]
In December 2019, the FASB issued ASU 2019-12, "Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes" (ASU 2019-12), which eliminates certain exceptions for recognizing deferred taxes for investments, performing intraperiod allocation and calculating income taxes in interim periods. This ASU also includes guidance to reduce complexity in certain areas, including recognizing deferred taxes for tax goodwill and allocating taxes to members of a consolidated group. ASU 2019-12 is effective for annual and interim periods in fiscal years beginning after December 15, 2020. Early adoption is permitted. The Company does not expect the adoption of ASU 2019-12 will have a material impact on its consolidated financial statements and plans to adopt the standard effective April 1, 2021.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001032975-21-000017:notes:105]
Business Acquisitions
Fiscal Year 2021 Acquisitions

[0001032975-21-000017:notes:106]
Mevo Acquisition

[0001032975-21-000017:notes:107]
On February 17, 2021 (the "Mevo Acquisition Date"), the Company acquired all equity interests of Mevo for a total upfront cash consideration of $33.2 million (as described in the table below), which included a working capital adjustment, plus additional contingent consideration of up to $17.0 million payable in cash only upon the achievement of certain net revenues for the period beginning on December 26, 2020 and ending on December 31, 2021 (the "Mevo Acquisition").

[0001032975-21-000017:notes:108]
The Mevo Acquisition is complementary to the Company’s PC Webcams portfolio and will better enable us to offer end-to-end solutions for streaming and content creation.

[0001032975-21-000017:notes:109]
Mevo met the definition of a business, and therefore the acquisition is accounted for using the acquisition method.

[0001032975-21-000017:notes:110]
The fair value of consideration transferred for the Mevo Acquisition consists of the following (in thousands):

[0001032975-21-000017:notes:111]
|  |  | Consideration |
| Purchase price (cash) |  | $ | 33,186 |  |
| Fair value of contingent consideration (earn-out) |  | 3,430 |  |
| Fair value of total consideration transferred |  | $ | 36,616 |  |

[0001032975-21-000017:notes:112]
The following table summarizes the estimated fair values of the assets acquired and liabilities assumed at the Mevo Acquisition Date (in thousands):

[0001032975-21-000017:notes:113]
|  |  | Estimated Fair Value |
| Cash and cash equivalents |  | $ | 418 |  |
| Accounts receivable |  | 1,125 |  |
| Inventories, net |  | 1,927 |  |
| Other current assets |  | 1,245 |  |
| Fixed assets, net |  | 156 |  |
| Other long-term assets |  | 968 |  |
| Intangible assets |  | 11,300 |  |
| Other identifiable liabilities assumed, net |  | (3,390) |  |
| Net identifiable assets acquired |  | $ | 13,749 |  |
| Goodwill |  | 22,867 |  |
| Net assets acquired |  | $ | 36,616 |  |

[0001032975-21-000017:notes:114]
Goodwill related to the acquisition is primarily attributable to opportunities and economies of scale from combining the operations and technologies of Logitech and Mevo, and is not deductible for tax purposes.

[0001032975-21-000017:notes:115]
The following table summarizes the estimated fair values and estimated useful lives of the components of identifiable intangible assets acquired as of the Mevo Acquisition Date (Dollars in thousands):

[0001032975-21-000017:notes:116]
|  | Fair Value |  | Estimated Useful Life (years) |
| Developed technology | $ | 10,400 |  |  | 5.0 |
| Customer relationships | 400 |  |  | 1.0 |
| Trade name | 500 |  |  | 2.0 |
| Total identifiable intangible assets acquired | $ | 11,300 |  |  |  |

[0001032975-21-000017:notes:117]
Intangible assets acquired as a result of the Mevo Acquisition are being amortized over their estimated useful lives using the straight-line method of amortization, which materially approximates the distribution of the economic value of the identified intangible assets. Amortization of acquired developed technology of $0.2 million during the year ended March 31, 2021 is included in "amortization of intangible assets and purchase accounting effect of inventory" in the consolidated statements of operations. Amortization of the acquired customer relationships and trade name of $0.05 million during the year ended March 31, 2021 is included in "Amortization of intangible assets and acquisition-related costs" in the consolidated statements of operations.

[0001032975-21-000017:notes:118]
Developed technology relates to Mevo’s existing camera hardware with in-app software for live streaming and video conferencing software platform. The economic useful life was determined based on the technology cycle related to developed technology of the hardware and software components, as well as the cash flows anticipated over the forecasted periods and industry benchmarks.

[0001032975-21-000017:notes:119]
Customer relationships represent the fair value of the underlying relationships with Mevo customers. The economic useful life was determined based on the estimated costs to recreate the customer relationships and industry benchmarks.

[0001032975-21-000017:notes:120]
Trade name relates to the “Mevo” trade name. The economic useful life was determined based on the expected life of the trade name and the cash flows anticipated over the forecasted periods.

[0001032975-21-000017:notes:121]
The fair value of developed technology was estimated using the relief-from-royalty method, an income approach (Level 3) which estimates the cost savings that accrue to the owner of the intangible assets that would otherwise be payable as royalties or license fees on revenues earned through the use of the asset. A royalty rate is applied to the projected revenues associated with the intangible assets to determine the amount of savings, which is then discounted to determine the fair value. Developed technology was valued using the royalty rate of 10% and was discounted at a rate of 13%.

[0001032975-21-000017:notes:122]
The Company believes the fair values of acquired intangible assets recorded above represents their fair values and approximates the amounts a market participant would pay for these intangible assets as of the Mevo Acquisition Date.

[0001032975-21-000017:notes:123]
The Company included Mevo's estimated fair value of assets acquired and liabilities assumed in its consolidated financial statements beginning on the Mevo Acquisition Date. The results of operations for Mevo subsequent to the Mevo Acquisition Date have been included in, but are not material to, the Company's consolidated statements of operations for the year ended March 31, 2021. Mevo contributed less than 1% of the Company's net sales for the year.

[0001032975-21-000017:notes:124]
On January 4, 2021, the Company made an immaterial technology acquisition for a total cash consideration of $11.0 million, including $3.0 million earn-out payable in cash upon the achievement of two technical development milestones required to be completed for periods ending December 31, 2021 and March 31, 2022, which was accounted for using the acquisition method. The Company retained 9% of the total consideration for the purpose of ensuring seller's representations and warranties.

[0001032975-21-000017:notes:125]
On February 11, 2021, the Company made an immaterial technology acquisition for a total cash consideration of $3.5 million, which was accounted for as an asset acquisition. The Company retained 10% of the total consideration for the purpose of ensuring seller's representations and warranties.

[0001032975-21-000017:notes:126]
Fiscal Year 2020 Acquisitions

[0001032975-21-000017:notes:127]
Streamlabs Acquisition

[0001032975-21-000017:notes:128]
On October 31, 2019 (the "Streamlabs Acquisition Date"), the Company acquired all equity interests of Streamlabs for a total consideration of $105.7 million (as described in the table below), which included a working capital adjustment, plus additional contingent consideration of $29.0 million payable in stock only upon the achievement of certain net revenues for the period beginning on January 1, 2020 and ending on June 30, 2020 (the "Streamlabs Acquisition").

[0001032975-21-000017:notes:129]
Streamlabs is a leading provider of software and tools for professional streamers. The Streamlabs Acquisition is complementary to the Company's Gaming portfolio.

[0001032975-21-000017:notes:130]
Streamlabs met the definition of a business, and therefore the acquisition is accounted for using the acquisition method.

[0001032975-21-000017:notes:131]
The fair value of consideration transferred for the Streamlabs Acquisition consists of the following (in thousands):

[0001032975-21-000017:notes:132]
|  |  | Consideration |
| Purchase price (cash) |  | $ | 105,645 |  |
| Fair value of contingent consideration (earn-out) |  | $ | 37 |  |
| Fair value of total consideration transferred |  | $ | 105,682 |  |

[0001032975-21-000017:notes:133]
The following table summarizes the estimated fair values of the assets acquired and liabilities assumed at the Streamlabs Acquisition Date, and the value of goodwill resulting from the measurement period adjustments in the three months ending March 31, 2020 (in thousands):

[0001032975-21-000017:notes:134]
|  |  | Estimated Fair Value |
| Cash and cash equivalents |  | $ | 17,014 |  |
| Intangible assets |  | $ | 37,000 |  |
| Other identifiable liabilities assumed, net |  | $ | (3,701) |  |
| Net identifiable assets acquired |  | 50,313 |  |
| Contingent consideration (earn-out) |  | $ | (37) |  |
| Goodwill |  | $ | 55,406 |  |
| Net assets acquired |  | $ | 105,682 |  |

[0001032975-21-000017:notes:135]
Goodwill related to the acquisition is primarily attributable to opportunities and economies of scale from combining the operations and technologies of Logitech and Streamlabs, and is not deductible for tax purposes.

[0001032975-21-000017:notes:136]
The following table summarizes the estimated fair values and estimated useful lives of the components of identifiable intangible assets acquired as of the Streamlabs Acquisition Date (Dollars in thousands):

[0001032975-21-000017:notes:137]
|  | Fair Value |  | Estimated Useful Life (years) |
| Developed technology | $ | 21,800 |  |  | 6.0 |
| Customer relationships | 6,000 |  |  | 2.0 |
| Trade name | 9,200 |  |  | 8.0 |
| Total identifiable intangible assets acquired | $ | 37,000 |  |  |  |

[0001032975-21-000017:notes:138]
Intangible assets acquired as a result of the Streamlabs Acquisition are being amortized over their estimated useful lives using the straight-line method of amortization, which materially approximates the distribution of the economic value of the identified intangible assets. Amortization of acquired developed technology of $3.6 million, and $1.5 million during the years ended March 31, 2021 and 2020, respectively, is included in "amortization of intangible assets and purchase accounting effect of inventory" in the consolidated statements of operations. Amortization of the acquired customer relationships and trade name of $4.1 million and $1.7 million during the years ended March 31, 2021  and 2020 is included in "Amortization of intangible assets and acquisition-related costs" in the consolidated statements of operations.

[0001032975-21-000017:notes:139]
Developed technology relates to the software platform which existing Streamlabs services are provided on. The economic useful life was determined based on the technology cycle related to developed technology of the software platform, as well as the cash flows anticipated over the forecasted periods.

[0001032975-21-000017:notes:140]
Customer relationships represent the fair value of future projected revenue that will be derived from sales to existing customers of Streamlabs. The economic useful life was determined based on historical customer turnover rates and industry benchmarks.

[0001032975-21-000017:notes:141]
Trade name relates to the “Streamlabs” trade name. The economic useful life was determined based on the expected life of the trade name and the cash flows anticipated over the forecasted periods.

[0001032975-21-000017:notes:142]
The fair value of developed technology was estimated using the excess earnings method, an income approach (Level 3), which converts projected revenues and costs into cash flows. To reflect the fact that certain other assets contributed to the cash flows generated, the returns for these contributory assets were removed to arrive at estimated cash flows solely attributable to the developed technology, which were discounted at a rate of 25%.

[0001032975-21-000017:notes:143]
The fair value of trade name was estimated using the relief-from-royalty method, an income approach (Level 3), which estimates the cost savings that accrue to the owner of the intangible assets that would otherwise be payable as royalties or license fees on revenues earned through the use of the asset. A royalty rate is applied to the

[0001032975-21-000017:notes:144]
projected revenues associated with the intangible assets to determine the amount of savings, which is then discounted to determine the fair value. Trade name was valued using royalty rate of 5% and was discounted at a rate of 25%.

[0001032975-21-000017:notes:145]
The fair value of customer relationships was estimated primarily using the with and without scenario, a discounted cash flow method (Level 3). Under this method, the Company calculated the present value of the after-tax cash flows expected to be generated by the business with and without the customer relationships using a discount rate of 20%. The without scenario incorporates lost revenue and lost profits over the period necessary to retain the asset.

[0001032975-21-000017:notes:146]
The Company believes the fair values of acquired intangible assets recorded above represents their fair values and approximates the amounts a market participant would pay for these intangible assets as of the Streamlabs Acquisition Date.

[0001032975-21-000017:notes:147]
The Company included Streamlabs' estimated fair value of assets acquired and liabilities assumed in its consolidated financial statements beginning on the Streamlabs Acquisition Date. The results of operations for Streamlabs subsequent to the Streamlabs Acquisition Date have been included in, but are not material to, the Company's consolidated statements of operations in fiscal year 2020.

[0001032975-21-000017:notes:148]
On October 31, 2019, the Company also made an immaterial technology acquisition for a total cash consideration of $3.6 million, which was accounted for using the acquisition method. The Company retained 10% of the total consideration for the purpose of ensuring seller's representations and warranties.

[0001032975-21-000017:notes:149]
Acquisition-related costs and pro forma results of operations

[0001032975-21-000017:notes:150]
The Company incurred acquisition-related costs of approximately $0.6 million, $1.5 million and $1.7 million, in aggregate, for the years ended March 31, 2021, 2020 and 2019, respectively. The acquisition-related costs are included in "Amortization of intangible assets and acquisition-related costs" in the consolidated statements of operations.
Pro forma results of operations for acquisitions completed in fiscal year 2021 and 2020 have not been presented because the effects of these acquisitions are not material to the consolidated statements of operations individually or in aggregate for each year.


## us-gaap:EarningsPerShareTextBlock

[0001032975-21-000017:notes:151]
Net Income per Share 
The computations of basic and diluted net income per share for the Company were as follows (in thousands except per share amounts):

[0001032975-21-000017:notes:152]
|  |  | Years Ended March 31, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Net Income |  | $ | 947,257 |  |  | $ | 449,723 |  |  | $ | 257,573 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 168,523 |  |  | 166,837 |  |  | 165,609 |  |
| Effect of potentially dilutive equivalent shares |  | 3,252 |  |  | 2,544 |  |  | 3,356 |  |
| Weighted average shares outstanding - diluted |  | 171,775 |  |  | 169,381 |  |  | 168,965 |  |
| Net income per share: |  |  |  |  |  |  |
| Basic |  | $ | 5.62 |  |  | $ | 2.70 |  |  | $ | 1.56 |  |
| Diluted |  | $ | 5.51 |  |  | $ | 2.66 |  |  | $ | 1.52 |  |

[0001032975-21-000017:notes:153]
Share equivalents attributable to outstanding stock options, RSUs and employee share purchase plan ("ESPP") totaling 0.1 million, 1.7 million, and 1.8 million shares, respectively, during fiscal years 2021, 2020 and 2019 were excluded from the calculation of diluted net income per share because the combined exercise price and average unamortized grant date fair value of these options and ESPP or vesting of RSUs were greater than the average market price of the Company's shares during the periods presented herein, and therefore their inclusion would have been anti-dilutive. Except for fiscal year 2021, performance-based awards in the periods presented were excluded because all necessary conditions have not been satisfied by the end of the respective period, and those shares were not issuable if the end of the reporting period were the end of the contingency period.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-21-000017:notes:154]
Employee Benefit Plans
Employee Share Purchase Plans and Stock Incentive Plans

[0001032975-21-000017:notes:155]
As of March 31, 2021, the Company offers the 2006 Employee Share Purchase Plan, as amended and restated (Non-U.S.) ("2006 ESPP)", the 1996 Employee Share Purchase Plan (U.S.), as amended and restated  ("1996 ESPP"), the 2006 Stock Incentive Plan ("2006 Plan") as amended and restated and the 2012 Stock Inducement Equity Plan ("2012 Plan"). Shares issued to employees as a result of purchases or exercises under these plans are generally issued from shares held in treasury stock.

[0001032975-21-000017:notes:156]
The following table summarizes share-based compensation expense and total income tax benefit recognized for fiscal years 2021, 2020 and 2019 (in thousands):

[0001032975-21-000017:notes:157]
|  |  | Years Ended March 31, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Cost of goods sold |  | $ | 6,438 |  |  | $ | 4,852 |  |  | $ | 3,812 |  |
| Marketing and selling |  | 36,788 |  |  | 26,835 |  |  | 20,630 |  |
| Research and development |  | 14,179 |  |  | 9,273 |  |  | 7,368 |  |
| General and administrative |  | 28,614 |  |  | 13,910 |  |  | 18,455 |  |
| Total share-based compensation expense |  | 86,019 |  |  | 54,870 |  |  | 50,265 |  |
| Income tax benefit |  | (19,472) |  |  | (14,109) |  |  | (17,091) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 66,547 |  |  | $ | 40,761 |  |  | $ | 33,174 |  |

[0001032975-21-000017:notes:158]
As of March 31, 2021, 2020 and 2019, the balance of capitalized stock-based compensation included in inventory was $1.1 million, $0.9 million, and $0.9 million, respectively.

[0001032975-21-000017:notes:159]
The following table summarizes total unamortized share-based compensation expense and the remaining period over which such expense is expected to be recognized, on a weighted-average basis by type of grant (in thousands, except number of months):

[0001032975-21-000017:notes:160]
|  |  | March 31, 2021 |
|  |  | UnamortizedExpense |  | RemainingMonths |
| ESPP |  | $ | 2,636 |  |  | 4 |
| Stock Options |  | 2,104 |  |  | 12 |
| Time-based RSUs |  | 84,143 |  |  | 24 |
| Market-based and performance-based RSUs |  | 34,816 |  |  | 22 |
| Total unamortized share-based compensation expense |  | $ | 123,699 |  |  |  |

[0001032975-21-000017:notes:161]
Under the 1996 ESPP and 2006 ESPP plans, eligible employees may purchase shares at the lower of 85% of the fair market value at the beginning or the end of each offering period, which is generally six months. Subject to continued participation in these plans, purchase agreements are automatically executed at the end of each offering period. An aggregate of 29.0 million shares were reserved for issuance under the 1996 and 2006 ESPP plans. As of March 31, 2021, a total of 4.7 million shares were available for new awards under these plans.

[0001032975-21-000017:notes:162]
The 2006 Plan provides for the grant to eligible employees and non-employee directors of stock options, stock appreciation rights, restricted stock and RSUs. Awards under the 2006 Plan may be conditioned on continued employment, the passage of time or the satisfaction of performance and market vesting criteria. The 2006 Plan, as amended, has no expiration date. All stock options under this plan have terms not exceeding ten years and are issued at exercise prices not less than the fair market value on the date of grant. An aggregate of 30.6 million shares were reserved for issuance under the 2006 Plan. As of March 31, 2021, a total of 7.8 million shares were available for new awards under this plan.

[0001032975-21-000017:notes:163]
Time-based RSUs granted to employees under the 2006 Plan generally vest in four equal annual installments on the grant date anniversary. Time-based RSUs granted to non-executive board members under the 2006 Plan vest on the grant date anniversary, or if earlier and only if the non-executive board member is not re-elected as a director at such annual general meeting, the date of the next annual general meeting following the grant date.

[0001032975-21-000017:notes:164]
In fiscal years 2021, 2020 and 2019, the Company granted RSUs with both performance and market conditions, which vest at the end of the three-year performance period upon meeting predetermined financial metrics over three years, with the number of shares to be received upon vesting determined based on weighted average constant currency revenue growth rate and the Company's Total Shareholder Return ("TSR") relative to the performance of companies in the Russell 3000 Index for fiscal year 2021 and NASDAQ-100 Index for fiscal years 2020 and 2019 over the same three years period. The Company presents shares granted and vested at 100 percent of the target of the number of stock units that may potentially vest. The aggregate fair value of shares that actually vested during the year is based on the actual number of stock units vested during the year based on the achievement of the financial metrics over the performance period.

[0001032975-21-000017:notes:165]
Under the 2012 Plan, stock options and RSUs may be granted to eligible employees to serve as an inducement to enter into employment with the Company. Awards under the 2012 Plan may be conditioned on continued employment, the passage of time or the satisfaction of market stock performance criteria, based on individually written employment offer letter. The 2012 Plan has an expiration date of March 28, 2022. An aggregate of 1.8 million shares were reserved for issuance under the 2012 Plan. As of March 31, 2021, no shares were available for new awards under this plan.

[0001032975-21-000017:notes:166]
The estimates of share-based compensation expense require a number of complex and subjective assumptions including stock price volatility, employee exercise patterns, probability of achievement of the set performance condition, dividend yield, related tax effects and the selection of an appropriate fair value model.

[0001032975-21-000017:notes:167]
The grant date fair value of the awards using the Black-Scholes-Merton option-pricing valuation model and Monte-Carlo simulation method is determined with the following assumptions and values:

[0001032975-21-000017:notes:168]
|  |  | Stock Options |  | Employee Stock Purchase Plans |
|  |  | Years Ended March 31, |  | Years Ended March 31, |
|  |  | 2021 |  | 2020 |  | 2019 |  | 2021 |  | 2020 |  | 2019 |
| Dividend yield |  | * |  | * |  | 1.72 | % |  | 1.04 | % |  | 1.74 | % |  | 1.73 | % |
| Risk-free interest rate |  | * |  | * |  | 2.45 | % |  | 0.10 | % |  | 1.81 | % |  | 2.35 | % |
| Expected volatility |  | * |  | * |  | 33 | % |  | 47 | % |  | 24 | % |  | 31 | % |
| Expected life (years) |  | * |  | * |  | 6.2 |  | 0.5 |  | 0.5 |  | 0.5 |
| Weighted average grant date fair value per share |  | * |  | * |  | $ | 11.55 |  | $ | 24.67 |  | $ | 9.35 |  | $ | 9.33 |

[0001032975-21-000017:notes:169]
* Not applicable as no stock options were granted in the period.

[0001032975-21-000017:notes:170]
| RSUs with Market Conditions |  | Years Ended March 31, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Dividend yield |  | 1.24 | % |  | 1.76 | % |  | 1.59 | % |
| Risk-free interest rate |  | 0.21 | % |  | 2.11 | % |  | 2.51 | % |
| Expected volatility |  | 31 | % |  | 30 | % |  | 30 | % |
| Expected life (years) |  | 3.0 |  | 3.0 |  | 3.0 |

[0001032975-21-000017:notes:171]
The dividend yield assumption is based on the Company's history and future expectations of dividend payouts. The unvested RSUs or unexercised options are not eligible for these dividends. The expected life is based on the purchase offerings periods expected to remain outstanding for employee stock purchase plan, or the performance period for RSUs with market conditions. The expected life for stock options is based on historical settlement rates, which the Company believes are most representative of future exercise and post-vesting termination behaviors. Expected volatility is based on historical volatility using the Company's daily closing prices, or including the volatility of components of the NASDAQ 100 index or the Russell 3000 Index for market-based RSUs, over the expected life. The Company considers the historical price volatility of its shares as most representative of future volatility. The risk-free interest rate assumptions are based upon the implied yield of U.S. Treasury zero-coupon issues appropriate for the expected life of the Company's share-based awards.

[0001032975-21-000017:notes:172]
For RSUs with performance conditions, the Company estimates the probability and timing of the achievement of the set performance condition at the time of the grant based on the historical financial performance and the financial forecast in the remaining performance period and reassesses the probability in subsequent periods when actual results or new information become available.

[0001032975-21-000017:notes:173]
A summary of the Company's stock option activities under all stock plans for fiscal years 2021, 2020 and 2019 is as follows:

[0001032975-21-000017:notes:174]
|  |  | Number of Shares |  | Weighted-Average Exercise Price |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value |  |  |  |  |
|  |  | (In thousands) |  |  |  | (Years) |  | (In thousands) |  |  |  |  |
| Outstanding, March 31, 2018 |  | 2,040 |  |  |  |  |  |  |  |  |  |  |  |
| Granted |  | 649 |  |  |  |  |  |  |  |  |  |  |  |
| Exercised |  | (82) |  |  |  |  |  |  | $ | 1,707 |  |  |  |  |  |
| Canceled or expired |  | — |  |  |  |  |  |  |  |  |  |  |  |
| Outstanding, March 31, 2019 |  | 2,607 |  |  |  |  |  |  |  |  |  |  |  |
| Granted |  | — |  |  |  |  |  |  |  |  |  |  |  |
| Exercised |  | (573) |  |  |  |  |  |  | $ | 19,339 |  |  |  |  |  |
| Canceled or expired |  | (65) |  |  |  |  |  |  |  |  |  |  |  |
| Outstanding, March 31, 2020 |  | 1,969 |  |  | $ | 22 |  |  |  |  |  |  |  |  |  |
| Granted |  | — |  |  |  |  |  |  |  |  |  |  |  |
| Exercised |  | (1,347) |  |  | $ | 17 |  |  |  |  | $ | 68,596 |  |  |  |  |  |
| Canceled or expired |  | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Outstanding, March 31, 2021 |  | 622 |  |  | $ | 34 |  |  | 7.1 |  | $ | 43,625 |  |  |  |  |  |
| Vested and exercisable, March 31, 2021 |  | 330 |  |  | $ | 30 |  |  | 6.3 |  | $ | 24,452 |  |  |  |  |  |

[0001032975-21-000017:notes:175]
As of March 31, 2021, the exercise price of outstanding options ranged from $8 to $41 per share option.

[0001032975-21-000017:notes:176]
The tax benefit realized for the tax deduction from options exercised during fiscal years 2021, 2020 and 2019 was $0.6 million, $0.1 million and $0.2 million, respectively.

[0001032975-21-000017:notes:177]
A summary of the Company's time-based, market-based and performance-based RSU activities for fiscal years 2021, 2020 and 2019 is as follows:

[0001032975-21-000017:notes:178]
|  |  | Number of Shares |  | Weighted-Average Grant Date Fair Value |  | Weighted-Average Remaining Vesting Period |  | Aggregate Fair Value |  |  |  |  |
|  |  | (In thousands) |  |  |  | (Years) |  | (In thousands) |  |  |  |  |
| Outstanding, March 31, 2018 |  | 5,221 |  |  | $ | 20 |  |  |  |  |  |  |  |  |  |
| Granted—time-based |  | 1,290 |  |  | $ | 40 |  |  |  |  |  |  |  |  |  |
| Granted—market and performance-based |  | 381 |  |  | $ | 39 |  |  |  |  |  |  |  |  |  |
| Vested |  | (2,148) |  |  |  |  |  |  | $ | 89,159 |  |  |  |  |  |
| Canceled or expired |  | (323) |  |  |  |  |  |  |  |  |  |  |  |
| Outstanding, March 31, 2019 |  | 4,421 |  |  | $ | 29 |  |  |  |  |  |  |  |  |  |
| Granted—time-based |  | 1,431 |  |  | $ | 38 |  |  |  |  |  |  |  |  |  |
| Granted—market and performance-based |  | 365 |  |  | $ | 40 |  |  |  |  |  |  |  |  |  |
| Vested |  | (1,705) |  |  |  |  |  |  | $ | 76,389 |  |  |  |  |  |
| Canceled or expired |  | (561) |  |  |  |  |  |  |  |  |  |  |  |
| Outstanding, March 31, 2020 |  | 3,951 |  |  | $ | 36 |  |  |  |  |  |  |  |  |  |
| Granted—time-based |  | 1,046 |  |  | $ | 60 |  |  |  |  |  |  |  |  |  |
| Granted—market and performance-based |  | 303 |  |  | $ | 67 |  |  |  |  |  |  |  |  |  |
| Vested |  | (1,444) |  |  | $ | 31 |  |  |  |  | $ | 168,816 |  |  |  |  |  |
| Canceled or expired |  | (213) |  |  | $ | 42 |  |  |  |  |  |  |  |  |  |
| Outstanding, March 31, 2021 |  | 3,643 |  |  | $ | 45 |  |  | 1.2 |  | $ | 379,031 |  |  |  |  |  |

[0001032975-21-000017:notes:179]
The RSUs outstanding as of March 31, 2021 above include 0.9 million shares with both market-based and performance-based vesting conditions.

[0001032975-21-000017:notes:180]
The tax benefit realized for the tax deduction from RSUs that vested during fiscal years 2021, 2020 and 2019 was $16.3 million, $12.1 million and $16.2 million, respectively.

[0001032975-21-000017:notes:181]
Defined Contribution Plans

[0001032975-21-000017:notes:182]
Certain of the Company's subsidiaries have defined contribution employee benefit plans covering all or a portion of their employees. Contributions to these plans are discretionary for certain plans and are based on specified or statutory requirements for others. The charges to expense for these plans for fiscal years 2021, 2020 and 2019, were $10.6 million, $8.6 million and $8.7 million, respectively.

[0001032975-21-000017:notes:183]
Defined Benefit Plans

[0001032975-21-000017:notes:184]
Certain of the Company's subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees' years of service and earnings, or in accordance with applicable employee benefit regulations. The Company's practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations.

[0001032975-21-000017:notes:185]
The Company recognizes the overfunded or underfunded status of defined benefit pension plans and non-retirement post-employment benefit obligations as an asset or liability in its consolidated balance sheets and recognizes changes in the funded status of defined benefit pension plans in the year in which the changes occur through accumulated other comprehensive income (loss), which is a component of shareholders' equity. Each plan's assets and benefit obligations are remeasured as of March 31 each year.

[0001032975-21-000017:notes:186]
The net periodic benefit cost of the defined benefit pension plans and the non-retirement post-employment benefit obligations for fiscal years 2021, 2020 and 2019 was as follows (in thousands):

[0001032975-21-000017:notes:187]
|  |  | Years Ended March 31, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Service costs |  | $ | 12,121 |  |  | $ | 11,008 |  |  | $ | 10,564 |  |
| Interest costs |  | 1,047 |  |  | 1,055 |  |  | 1,301 |  |
| Expected return on plan assets |  | (2,535) |  |  | (2,616) |  |  | (2,167) |  |
| Amortization: |  |  |  |  |  |  |
| Net prior service credit recognized |  | (467) |  |  | (435) |  |  | (443) |  |
| Net actuarial loss recognized |  | 2,144 |  |  | 1,386 |  |  | 450 |  |
| Settlement |  | — |  |  | (97) |  |  | (97) |  |
| Total net periodic benefit cost |  | $ | 12,310 |  |  | $ | 10,301 |  |  | $ | 9,608 |  |

[0001032975-21-000017:notes:188]
The components of net periodic benefit cost other than the service costs component are included in the line “other income (expense), net” in the consolidated statements of operations.

[0001032975-21-000017:notes:189]
The changes in projected benefit obligations for fiscal years 2021 and 2020 were as follows (in thousands):

[0001032975-21-000017:notes:190]
|  |  | Years Ended March 31, |
|  |  | 2021 |  | 2020 |
| Projected benefit obligations, beginning of the year |  | $ | 160,914 |  |  | $ | 143,662 |  |
| Service costs |  | 12,121 |  |  | 11,008 |  |
| Interest costs |  | 1,047 |  |  | 1,055 |  |
| Plan participant contributions |  | 4,733 |  |  | 3,733 |  |
| Actuarial gains |  | 15,762 |  |  | 2,246 |  |
| Benefits paid |  | (3,947) |  |  | (8,778) |  |
| Transfer of prior vested benefits |  | 7,556 |  |  | 5,271 |  |
| Plan amendment related to statutory change |  | — |  |  | — |  |
| Settlement |  | — |  |  | (941) |  |
| Administrative expense paid |  | (130) |  |  | (141) |  |
| Currency exchange rate changes and other |  | 4,292 |  |  | 3,799 |  |
| Projected benefit obligations, end of the year |  | $ | 202,348 |  |  | $ | 160,914 |  |

[0001032975-21-000017:notes:191]
The accumulated benefit obligation for all defined benefit pension plans as of March 31, 2021 and 2020 was $171.2 million and $135.0 million, respectively.

[0001032975-21-000017:notes:192]
The following table presents the changes in the fair value of defined benefit pension plan assets for fiscal years 2021 and 2020 (in thousands):

[0001032975-21-000017:notes:193]
|  |  | Years Ended March 31, |
|  |  | 2021 |  | 2020 |
| Fair value of plan assets, beginning of the year |  | $ | 98,010 |  |  | $ | 90,365 |  |
| Actual return on plan assets |  | 11,706 |  |  | (830) |  |
| Employer contributions |  | 8,064 |  |  | 6,531 |  |
| Plan participant contributions |  | 4,733 |  |  | 3,733 |  |
| Benefits paid |  | (3,947) |  |  | (8,778) |  |
| Transfer of prior vested benefits |  | 7,556 |  |  | 5,271 |  |
| Settlement |  | — |  |  | (941) |  |
| Administrative expenses paid |  | (130) |  |  | (141) |  |
| Currency exchange rate changes |  | 2,069 |  |  | 2,800 |  |
| Fair value of plan assets, end of the year |  | $ | 128,061 |  |  | $ | 98,010 |  |

[0001032975-21-000017:notes:194]
The Company's investment objectives are to ensure that the assets of its defined benefit plans are invested to provide an optimal rate of investment return on the total investment portfolio, consistent with the assumption of a reasonable risk level, and to ensure that pension funds are available to meet the plans' benefit obligations as they become due. The Company believes that a well-diversified investment portfolio will result in the highest attainable investment return with an acceptable level of overall risk. Investment strategies and allocation decisions are also governed by applicable governmental regulatory agencies. The Company's investment strategy with respect to its largest defined benefit plan, which is available only to Swiss employees, is to invest per the following allocation: 33% in equities, 34% in bonds, 28% in real estate, 2% in cash and cash equivalents and the remaining in other investments. The Company also can invest in real estate funds, commodity funds, and hedge funds depending upon economic conditions.

[0001032975-21-000017:notes:195]
The following tables present the fair value of the defined benefit pension plan assets by major categories and by levels within the fair value hierarchy as of March 31, 2021 and 2020 (in thousands):

[0001032975-21-000017:notes:196]
|  |  | March 31, |
|  |  | 2021 |  | 2020 |
|  |  | Level 1 |  | Level 2 |  |  |  | Total |  | Level 1 |  | Level 2 |  |  |  | Total |
| Cash and cash equivalents |  | $ | 21,715 |  |  | $ | — |  |  |  |  | $ | 21,715 |  |  | $ | 14,213 |  |  | $ | — |  |  |  |  | $ | 14,213 |  |
| Equity securities |  | 38,437 |  |  | — |  |  |  |  | 38,437 |  |  | 28,329 |  |  | — |  |  |  |  | 28,329 |  |
| Debt securities |  | 31,034 |  |  | — |  |  |  |  | 31,034 |  |  | 26,605 |  |  | — |  |  |  |  | 26,605 |  |
| Swiss real estate funds |  | 20,802 |  |  | 8,341 |  |  |  |  | 29,143 |  |  | 16,476 |  |  | 8,168 |  |  |  |  | 24,644 |  |
| Hedge funds |  | — |  |  | 2,730 |  |  |  |  | 2,730 |  |  | — |  |  | 1,882 |  |  |  |  | 1,882 |  |
| Other |  | 4,704 |  |  | 298 |  |  |  |  | 5,002 |  |  | 2,084 |  |  | 253 |  |  |  |  | 2,337 |  |
| Total fair value of plan assets |  | $ | 116,692 |  |  | $ | 11,369 |  |  |  |  | $ | 128,061 |  |  | $ | 87,707 |  |  | $ | 10,303 |  |  |  |  | $ | 98,010 |  |

[0001032975-21-000017:notes:197]
The funded status of the plans was as follows (in thousands):

[0001032975-21-000017:notes:198]
|  |  | Years Ended March 31, |
|  |  | 2021 |  | 2020 |
| Fair value of plan assets |  | $ | 128,061 |  |  | $ | 98,010 |  |
| Less: projected benefit obligations |  | 202,348 |  |  | 160,914 |  |
| Underfunded status |  | $ | (74,287) |  |  | $ | (62,904) |  |

[0001032975-21-000017:notes:199]
Amounts recognized on the balance sheet for the plans were as follows (in thousands):

[0001032975-21-000017:notes:200]
|  |  | March 31, |
|  |  | 2021 |  | 2020 |
| Current liabilities |  | $ | 2,738 |  |  | $ | 2,126 |  |
| Non-current liabilities |  | 71,549 |  |  | 60,778 |  |
| Total liabilities |  | $ | 74,287 |  |  | $ | 62,904 |  |

[0001032975-21-000017:notes:201]
Amounts recognized in accumulated other comprehensive loss related to defined benefit pension plans were as follows (in thousands):

[0001032975-21-000017:notes:202]
|  |  | March 31, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Net prior service credits |  | $ | 3,263 |  |  | $ | 3,647 |  |  | $ | 3,965 |  |
| Net actuarial loss |  | (27,553) |  |  | (22,722) |  |  | (17,630) |  |
| Accumulated other comprehensive loss |  | (24,290) |  |  | (19,075) |  |  | (13,665) |  |
| Deferred taxes |  | 1,090 |  |  | (941) |  |  | (267) |  |
| Accumulated other comprehensive loss, net of tax |  | $ | (23,200) |  |  | $ | (20,016) |  |  | $ | (13,932) |  |

[0001032975-21-000017:notes:203]
The following table presents the amounts included in accumulated other comprehensive loss as of March 31, 2021, which are expected to be recognized as a component of net periodic benefit cost in fiscal year 2022 (in thousands):

[0001032975-21-000017:notes:204]
|  |  | Year EndedMarch 31, 2021 |
| Amortization of net prior service credits |  | $ | (453) |  |
| Amortization of net actuarial loss |  | 1,277 |  |
| Total |  | $ | 824 |  |

[0001032975-21-000017:notes:205]
The actuarial assumptions for the defined benefit plans for fiscal years 2021 and 2020 were as follows:

[0001032975-21-000017:notes:206]
|  |  | Years Ended March 31, |
|  |  | 2021 |  | 2020 |
| Benefit Obligations: |  |  |  |  |
| Discount rate |  | 0.25% - 6% |  | 0.50% - 6.75% |
| Estimated rate of compensation increase |  | 2.00% - 10.00% |  | 2.25% - 10.00% |
| Cash Balance Interest Credit Rate |  | 0.00% - 1.75% |  | 0.00% - 1.75% |
| Periodic Costs: |  |  |  |  |
| Discount rate |  | 0.50% - 6.75% |  | 0.55% - 7.25% |
| Estimated rate of compensation increase |  | 2.25% - 10.00% |  | 2.50% - 10.00% |
| Expected average rate of return on plan assets |  | 1% - 2.50% |  | 0.89% - 3.00% |
| Cash Balance Interest Credit Rate |  | 0.00% - 1.75% |  | 1.75% - 2.00% |

[0001032975-21-000017:notes:207]
The discount rate is estimated based on corporate bond yields or securities of similar quality in the respective country, with a duration approximating the period over which the benefit obligations are expected to be paid. The Company bases the compensation increase assumptions on historical experience and future expectations. The expected average rate of return for the Company's defined benefit pension plans represents the average rate of return expected to be earned on plan assets over the period that the benefit obligations are expected to be paid, based on government bond notes in the respective country, adjusted for corporate risk premiums as appropriate.

[0001032975-21-000017:notes:208]
The following table reflects the benefit payments that the Company expects the plans to pay in the periods noted (in thousands):

[0001032975-21-000017:notes:209]
| Years Ending March 31, |  |  |
| 2022 |  | $ | 10,527 |  |
| 2023 |  | 10,177 |  |
| 2024 |  | 10,632 |  |
| 2025 |  | 11,157 |  |
| 2026 |  | 10,248 |  |
| 2027-2031 |  | 54,209 |  |
| Total expected benefit payments by the plan |  | $ | 106,950 |  |

[0001032975-21-000017:notes:210]
The Company expects to contribute $6.7 million to its defined benefit pension plans during fiscal year 2022.

[0001032975-21-000017:notes:211]
Deferred Compensation Plan

[0001032975-21-000017:notes:212]
One of the Company's subsidiaries offers a deferred compensation plan that permits eligible employees to make 100% vested salary and incentive compensation deferrals within established limits. The Company does not make contributions to the plan.

[0001032975-21-000017:notes:213]
The deferred compensation plan's assets consist of marketable securities and are included in other assets on the consolidated balance sheets. The marketable securities are classified as trading investments and were recorded at a fair value of $24.8 million and $20.1 million as of March 31, 2021 and 2020, respectively, based on quoted market prices. The Company also had $24.8 million and $20.1 million in deferred compensation liability as of March 31, 2021 and 2020, respectively. Earnings, gains and losses on trading investments are included in other income (expense), net and corresponding changes in deferred compensation liability are included in operating expenses and cost of goods sold.


## us-gaap:InterestAndOtherIncomeTextBlock

[0001032975-21-000017:notes:214]
Other Income (Expense), net
Other income (expense), net comprises of the following (in thousands):

[0001032975-21-000017:notes:215]
|  |  | Years Ended March 31, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Investment income (loss) related to the deferred compensation plan |  | $ | 5,916 |  |  | $ | (831) |  |  | $ | 664 |  |
| Currency exchange loss, net |  | (2,688) |  |  | (909) |  |  | (3,608) |  |
| Gain (Loss) on investments, net |  | (5,910) |  |  | 39,011 |  |  | 816 |  |
| Other |  | 893 |  |  | 941 |  |  | 1,692 |  |
| Other income (expense), net |  | $ | (1,789) |  |  | $ | 38,212 |  |  | $ | (436) |  |

[0001032975-21-000017:notes:216]
Gain (Loss) on investments, net, represents realized gain (loss) on sales of investments, unrealized gain (loss) from the change in fair value of available-for-sale securities and gain (loss) on equity-method investments during the periods presented.

[0001032975-21-000017:notes:217]
In fiscal year 2021, the loss on investments is mostly related to losses recognized from the Company's equity method investments. On March 2, 2020, the Company sold its $5.5 million investment, in a privately held company, for proceeds with a total fair value of $45.3 million consisting of cash, a subordinated note and an equity interest in another privately held company. As a result, the Company recognized a gain of $39.8 million related to the sale of this investment in fiscal year 2020.
The components of net periodic benefit cost other than the service cost component, which is included in "operating expenses" in the consolidated statements of operations, for the years ended March 31, 2021, 2020 and 2019 are included in the line “Other” above as a result of adopting ASU 2017-07, "Compensation - Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost" (ASU 2017-07), effective April 1, 2018.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-21-000017:notes:218]
Income Taxes 
The Company is incorporated in Switzerland but operates in various countries with differing tax laws and rates. Further, a portion of the Company's income (loss) before taxes and the provision for (benefit from) income taxes is generated outside of Switzerland.

[0001032975-21-000017:notes:219]
Income from continuing operations before income taxes for fiscal years 2021, 2020 and 2019 is summarized as follows (in thousands):

[0001032975-21-000017:notes:220]
|  |  | Years Ended March 31, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Swiss |  | $ | 984,185 |  |  | $ | 238,303 |  |  | $ | 212,986 |  |
| Non-Swiss |  | 163,935 |  |  | 86,023 |  |  | 58,147 |  |
| Income before taxes |  | $ | 1,148,120 |  |  | $ | 324,326 |  |  | $ | 271,133 |  |

[0001032975-21-000017:notes:221]
The provision for (benefit from) income taxes is summarized as follows (in thousands):

[0001032975-21-000017:notes:222]
|  |  | Years Ended March 31, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Current: |  |  |  |  |  |  |
| Swiss |  | $ | 121,199 |  |  | $ | 5,474 |  |  | $ | 1,364 |  |
| Non-Swiss |  | 45,056 |  |  | 29,078 |  |  | 24,334 |  |
| Deferred: |  |  |  |  |  |  |
| Swiss |  | 31,558 |  |  | (153,210) |  |  | — |  |
| Non-Swiss |  | 3,050 |  |  | (6,739) |  |  | (12,138) |  |
| Provision for (benefit from) income taxes |  | $ | 200,863 |  |  | $ | (125,397) |  |  | $ | 13,560 |  |

[0001032975-21-000017:notes:223]
The difference between the provision for (benefit from) income taxes and the expected tax provision (tax benefit) at the statutory income tax rate of 8.5% is reconciled below (in thousands):

[0001032975-21-000017:notes:224]
|  |  | Years Ended March 31, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Expected tax provision at statutory income tax rates |  | $ | 97,590 |  |  | $ | 27,568 |  |  | $ | 23,046 |  |
| Income taxes at different rates |  | 88,760 |  |  | (5,592) |  |  | (10,113) |  |
| Research and development tax credits |  | (3,844) |  |  | (4,692) |  |  | (5,432) |  |
| Executive compensation |  | 4,821 |  |  | 1,582 |  |  | 3,344 |  |
| Stock-based compensation |  | (3,161) |  |  | (2,735) |  |  | (7,288) |  |
| Deferred tax effects from TRAF |  | 1,944 |  |  | (206,792) |  |  | — |  |
| Valuation allowance |  | (247) |  |  | (538) |  |  | 1,891 |  |
| Restructuring charges / (credits) |  | (5) |  |  | 12 |  |  | 961 |  |
| Unrecognized tax benefits |  | 15,978 |  |  | 64,683 |  |  | 8,269 |  |
| Other, net |  | (973) |  |  | 1,107 |  |  | (1,118) |  |
| Provision for (benefit from) income taxes |  | $ | 200,863 |  |  | $ | (125,397) |  |  | $ | 13,560 |  |

[0001032975-21-000017:notes:225]
Deferred income tax assets and liabilities consist of the following (in thousands):

[0001032975-21-000017:notes:226]
|  |  | March 31, |
|  |  | 2021 |  | 2020 |
| Deferred tax assets: |  |  |  |  |
| Tax attributes carryforward |  | $ | 42,482 |  |  | $ | 73,975 |  |
| Accruals |  | 79,884 |  |  | 57,923 |  |
| Depreciation and amortization |  | 1,628 |  |  | 4,831 |  |
| Tax step-up of goodwill from TRAF |  | 134,122 |  |  | 151,220 |  |
| Share-based compensation |  | 12,784 |  |  | 10,947 |  |
| Gross deferred tax assets |  | 270,900 |  |  | 298,896 |  |
| Valuation allowance |  | (28,926) |  |  | (29,171) |  |
| Deferred tax assets after valuation allowance |  | 241,974 |  |  | 269,725 |  |
| Deferred tax liabilities: |  |  |  |  |
| Acquired intangible assets and other |  | (32,789) |  |  | (31,128) |  |
| Deferred tax liabilities |  | (32,789) |  |  | (31,128) |  |
| Deferred tax assets, net |  | $ | 209,185 |  |  | $ | 238,597 |  |

[0001032975-21-000017:notes:227]
Included in tax attributes carryforward above are net operating loss and tax credit carryforwards.

[0001032975-21-000017:notes:228]
The canton of Vaud enacted TRAF, a major reform to better align the Swiss tax system with international tax standards, on March 10, 2020 that took effect as of January 1, 2020.  The longstanding tax ruling from the canton of Vaud was applicable through December 31, 2019.

[0001032975-21-000017:notes:229]
Management regularly assesses the ability to realize deferred tax assets recorded in the Company's entities based upon the weight of available evidence, including such factors as recent earnings history and expected future taxable income. In the event that the Company changes its determination as to the amount of deferred tax assets that can be realized, the Company will adjust its valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0001032975-21-000017:notes:230]
The Company had a valuation allowance against deferred tax assets of $28.9 million at March 31, 2021, compared to $29.2 million at March 31, 2020. The federal valuation allowance against tax credits in the amount of $0.9 million as of March 31, 2020 was released entirely as of March 31, 2021 due to sufficient taxable income available to utilize these credits.  The Company had a valuation allowance of $28.5 million as of March 31, 2021 against deferred tax assets in the state of California, an increase from $27.7 million as of March 31, 2020 from activities during the year.  The remaining valuation allowance primarily represents $0.4 million for various tax attribute carryforwards. The Company determined that it is more likely than not that the Company would not generate sufficient taxable income in the future to utilize such deferred tax assets.

[0001032975-21-000017:notes:231]
As of March 31, 2021, the Company had foreign net operating loss and tax credit carryforwards for income tax purposes of $173.1 million and $67.5 million, respectively. Unused net operating loss carryforwards will expire at various dates in fiscal years 2021 to 2039. Certain net operating loss carryforwards in the United States relate to acquisitions and, as a result, are limited in the amount that can be utilized in any one year. The tax credit carryforwards will begin to expire in fiscal year 2022.

[0001032975-21-000017:notes:232]
Swiss income taxes and non-Swiss withholding taxes associated with the repatriation of earnings or for other temporary differences related to investments in non-Swiss subsidiaries have not been provided for, as the Company intends to reinvest the earnings of such subsidiaries indefinitely.  If these earnings were distributed to Switzerland in the form of dividends or otherwise, or if the shares of the relevant non-Swiss subsidiaries were sold or otherwise transferred, the Company may be subject to additional Swiss income taxes and non-Swiss withholding taxes. As of March 31, 2021, the cumulative amount of unremitted earnings of non-Swiss subsidiaries for which no income taxes have been provided is approximately $153.1 million. The amount of unrecognized deferred income tax liability related to these earnings is estimated to be approximately $2.1 million.

[0001032975-21-000017:notes:233]
The Company follows a two-step approach in recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon ultimate settlement.

[0001032975-21-000017:notes:234]
As of March 31, 2021 and 2020, the total amount of unrecognized tax benefits due to uncertain tax positions was $160.3 million and $140.8 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-21-000017:notes:235]
As of March 31, 2021 and 2020, the Company had $59.2 million and $40.8 million, respectively, in non-current income taxes payable, including interest and penalties, related to the Company's income tax liability for uncertain tax positions.

[0001032975-21-000017:notes:236]
The aggregate changes in gross unrecognized tax benefits in fiscal years 2021, 2020 and 2019 were as follows (in thousands).

[0001032975-21-000017:notes:237]
| March 31, 2018 |  | $ | 69,131 |  |
| Lapse of statute of limitations |  | (2,511) |  |
| Decreases in balances related to tax positions taken during prior years |  | (1,550) |  |
| Increases in balances related to tax positions taken during the year |  | 11,479 |  |
| March 31, 2019 |  | $ | 76,549 |  |
| Lapse of statute of limitations |  | (3,501) |  |
| Decreases in balances related to tax positions taken during prior years |  | (679) |  |
| Increases in balances related to tax positions taken during the year |  | 71,128 |  |
| March 31, 2020 |  | $ | 143,497 |  |
| Lapse of statute of limitations |  | (4,024) |  |
| Decreases in balances related to tax positions taken during prior years |  | — |  |
| Increases in balances related to tax positions taken during the year |  | 23,780 |  |
| March 31, 2021 |  | $ | 163,253 |  |

[0001032975-21-000017:notes:238]
Fiscal year 2020 includes gross unrecognized tax benefits recorded as a result of the enactment of TRAF in Switzerland:

[0001032975-21-000017:notes:239]
The Company recognizes interest and penalties related to unrecognized tax positions in income tax expense. The Company recognized $1.1 million, $2.0 million, and $0.6 million in interest and penalties in income tax expense during fiscal years 2021, 2020 and 2019, respectively. As of March 31, 2021 and 2020, the Company had $4.9 million, and $4.5 million, respectively, of accrued interest and penalties related to uncertain tax positions.

[0001032975-21-000017:notes:240]
The Company files Swiss and foreign tax returns. The Company received final tax assessments in Switzerland through fiscal year 2018. For other foreign jurisdictions such as the United States, the Company is generally not subject to tax examinations for years prior to fiscal year 2018. The Company is under examination and has received assessment notices in foreign tax jurisdictions. If the examinations are resolved unfavorably, there is a possibility they may have a material negative impact on its results of operations.
Although the Company has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During the next 12 months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. Dollar as compared to other currencies. Excluding these factors, uncertain tax positions may decrease by as much as $4.6 million primarily from the lapse of the statutes of limitations in various jurisdictions during the next 12 months.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-21-000017:notes:241]
Balance Sheet Components
The following table presents the components of certain balance sheet asset amounts as of March 31, 2021 and 2020 (in thousands):

[0001032975-21-000017:notes:242]
|  |  | March 31, |
|  |  | 2021 |  | 2020 |
| Accounts receivable, net: |  |  |  |  |
| Accounts receivable |  | $ | 867,868 |  |  | $ | 597,939 |  |
| Allowance for doubtful accounts |  | (1,161) |  |  | (1,894) |  |
| Allowance for sales returns |  | (14,438) |  |  | (6,599) |  |
| Allowance for cooperative marketing arrangements |  | (43,276) |  |  | (38,794) |  |
| Allowance for customer incentive programs |  | (76,200) |  |  | (55,741) |  |
| Allowance for pricing programs |  | (120,568) |  |  | (100,168) |  |
|  |  | $ | 612,225 |  |  | $ | 394,743 |  |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 146,886 |  |  | $ | 56,052 |  |
| Finished goods |  | 514,230 |  |  | 173,197 |  |
|  |  | $ | 661,116 |  |  | $ | 229,249 |  |
| Other current assets: |  |  |  |  |
| Value-added tax receivables |  | $ | 67,710 |  |  | $ | 33,616 |  |
| Prepaid expenses and other assets |  | 67,940 |  |  | 41,304 |  |
|  |  | $ | 135,650 |  |  | $ | 74,920 |  |
| Property, plant and equipment, net: |  |  |  |  |
| Plant, buildings and improvements |  | $ | 66,055 |  |  | $ | 65,261 |  |
| Equipment and tooling |  | 244,962 |  |  | 185,760 |  |
| Computer equipment |  | 27,869 |  |  | 26,148 |  |
| Software |  | 56,087 |  |  | 56,091 |  |
|  |  | 394,973 |  |  | 333,260 |  |
| Less: accumulated depreciation and amortization |  | (303,460) |  |  | (270,387) |  |
|  |  | 91,513 |  |  | 62,873 |  |
| Construction-in-process |  | 19,637 |  |  | 10,441 |  |
| Land |  | 2,910 |  |  | 2,805 |  |
|  |  | $ | 114,060 |  |  | $ | 76,119 |  |
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 210,888 |  |  | $ | 240,528 |  |
| Right-of-use assets |  | 31,169 |  |  | 25,557 |  |
| Trading investments for deferred compensation plan |  | 24,809 |  |  | 20,085 |  |
| Investment in privately held companies |  | 43,402 |  |  | 45,949 |  |
| Other assets |  | 13,980 |  |  | 12,900 |  |
|  |  | $ | 324,248 |  |  | $ | 345,019 |  |

[0001032975-21-000017:notes:243]
The following table presents the components of certain balance sheet liability amounts as of March 31, 2021 and 2020 (in thousands):

[0001032975-21-000017:notes:244]
|  |  | March 31, |
|  |  | 2021 |  | 2020 |
| Accrued and other current liabilities: |  |  |  |  |
| Accrued customer marketing, pricing and incentive programs |  | $ | 185,394 |  |  | $ | 130,220 |  |
| Accrued personnel expenses |  | 173,360 |  |  | 104,423 |  |
| Income taxes payable - current |  | 131,408 |  |  | 8,823 |  |
| Accrued payables - non-inventory |  | 52,392 |  |  | 11,548 |  |
| VAT payable |  | 50,620 |  |  | 12,757 |  |
| Accrued sales return liability |  | 43,178 |  |  | 30,267 |  |
| Warranty accrual |  | 33,228 |  |  | 25,905 |  |
| Operating lease liability |  | 13,101 |  |  | 10,945 |  |
| Contingent consideration |  | 6,967 |  |  | 23,284 |  |
| Other current liabilities |  | 168,969 |  |  | 96,852 |  |
|  |  | $ | 858,617 |  |  | $ | 455,024 |  |
| Other non-current liabilities: |  |  |  |  |
| Employee benefit plan obligation |  | $ | 72,321 |  |  | $ | 61,303 |  |
| Obligation for deferred compensation plan |  | 24,809 |  |  | 20,085 |  |
| Operating lease liability |  | 21,319 |  |  | 19,536 |  |
| Warranty accrual |  | 15,604 |  |  | 14,134 |  |
| Deferred tax liability |  | 1,679 |  |  | 1,931 |  |
| Other non-current liabilities |  | 3,770 |  |  | 2,285 |  |
|  |  | $ | 139,502 |  |  | $ | 119,274 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-21-000017:notes:245]
Fair Value Measurements
The Company considers fair value as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants at the measurement date. The Company utilizes the following three-level fair value hierarchy to establish the priorities of the inputs used to measure fair value:

[0001032975-21-000017:notes:246]
•Level 1—Quoted prices in active markets for identical assets or liabilities.

[0001032975-21-000017:notes:247]
•Level 2—Observable inputs other than quoted market prices included in Level 1, such as quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active; or other inputs that are observable or can be corroborated by observable market data.

[0001032975-21-000017:notes:248]
•Level 3—Unobservable inputs that are supported by little or no market activity and that are significant to the fair value of the assets or liabilities. This includes certain pricing models, discounted cash flow methodologies and similar techniques that use significant unobservable inputs.

[0001032975-21-000017:notes:249]
The following table presents the Company's financial assets and liabilities that were accounted for at fair value on a recurring basis, excluding assets related to the Company's defined benefit pension plans, classified by the level within the fair value hierarchy (in thousands):

[0001032975-21-000017:notes:250]
|  |  | March 31, 2021 |  | March 31, 2020 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 669,759 |  |  | $ | — |  |  | $ | — |  |  | $ | 564,952 |  |  | $ | — |  |  | $ | — |  |
| Trading investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 31 |  |  | $ | — |  |  | $ | — |  |  | $ | 846 |  |  | $ | — |  |  | $ | — |  |
| Common stock |  | 1,569 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Money market funds |  | 6,734 |  |  | — |  |  | — |  |  | 7,147 |  |  | — |  |  | — |  |
| Mutual funds |  | 16,475 |  |  | — |  |  | — |  |  | 12,092 |  |  | — |  |  | — |  |
| Total of trading investments for deferred compensation plan |  | $ | 24,809 |  |  | $ | — |  |  | $ | — |  |  | $ | 20,085 |  |  | $ | — |  |  | $ | — |  |
| Currency derivative assets included in other current assets |  | $ | — |  |  | $ | 5,452 |  |  | $ | — |  |  | $ | — |  |  | $ | 129 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration for business acquisition included in accrued and other current liabilities (Note 3) |  | $ | — |  |  | $ | — |  |  | $ | 6,430 |  |  | $ | — |  |  | $ | — |  |  | $ | 23,284 |  |
| Currency derivative liabilities included in accrued and other current liabilities |  | $ | — |  |  | $ | 100 |  |  | $ | — |  |  | $ | — |  |  | $ | 719 |  |  | $ | — |  |

[0001032975-21-000017:notes:251]
The following table summarizes the change in the fair value of the Company's contingent consideration balance during fiscal year 2021 (in thousands):

[0001032975-21-000017:notes:252]
|  | Year Ended March 31, | Year Ended March 31, |
|  | 2021 | 2020 |
| Acquisition-related contingent consideration, beginning of the year | $ | 23,284 |  | $ | — |  |
| Fair value of contingent consideration upon acquisition (1) | 6,430 | 37 |  |
| Change in fair value of contingent consideration | 5,716 |  | 23,247 |  |
| Settlement of contingent consideration (2) | (28,463) | — |  |
| Acquisition-related contingent consideration, end of the year | $ | 6,967 |  | $ | 23,284 |  |

[0001032975-21-000017:notes:253]
(1) The fair value of contingent consideration upon acquisition of  $6.4 million includes the earn-out of $3.4 million from the Mevo Acquisition and an earn-out of $3.0 million from the other immaterial technology acquisition. See Contingent Consideration for Business Acquisition section below for details.

[0001032975-21-000017:notes:254]
(2) As of June 30, 2020, the earn-out period was completed in connection with our acquisition of Streamlabs (discussed below). The earn-out payment of $29.0 million is based on the actual net sales of Streamlabs services during the earn-out period and is no longer subject to fair value measurement and was accordingly transferred out of Level 3. During the third quarter of fiscal year 2021, the fair value of $28.5 million of the contingent consideration was transferred from other current liabilities to equity upon settlement of the contingent consideration through the issuance of shares out of treasury stock. The remaining amount of $0.5 million is held back in escrow for claims made against the escrow and for the payment of taxes.

[0001032975-21-000017:notes:255]
Trading Investments

[0001032975-21-000017:notes:256]
The marketable securities for the Company's deferred compensation plan are recorded at a fair value of $24.8 million and $20.1 million as of March 31, 2021 and 2020, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized trading gains related to trading securities for fiscal years 2021, 2020 and 2019 were not material and are included in other income (expense), net in the consolidated statements of operations.

[0001032975-21-000017:notes:257]
Contingent Consideration for Business Acquisitions

[0001032975-21-000017:notes:258]
The contingent consideration for business acquisition arising from the Mevo Acquisition (see "Note 3—Business Acquisition" for more information) represents the future potential earn-out payments of up to $17.0 million payable in cash only upon the achievement of certain net sales for the period beginning on December 26, 2020 and ending on December 31, 2021. The fair value of the earn-out as of the Mevo Acquisition Date was $3.4 million which was determined by using a Black-Scholes-Merton valuation model to calculate the probability of the earn-out threshold being met, times the value of the earn-out payment, and discounted at the risk-free rate. The valuation includes significant assumptions and unobservable inputs such as the projected sales of Mevo over the earn-out period, risk-free rate, and the net sales volatility. The fair value of the contingent consideration is remeasured at each reporting period based on the inputs on the date of re-measurement, with the change in fair value recognized as "change in fair value of contingent consideration for business acquisition" in the operating expense section in the consolidated statements of operations. Projected sales are based on the Company's internal projections, including analysis of the target market and historical sales of Mevo products. For the year ended March 31, 2021, the change in fair value of the contingent consideration related to acquisition was not material.

[0001032975-21-000017:notes:259]
The contingent consideration for business acquisition arising from the other immaterial technology acquisition represents the future potential earn-out payments of $3.0 million payable in cash upon the achievement of two technical development milestones required to be completed for periods ending December 31, 2021 and March 31, 2022. The fair value of the contingent amount was determined using a probability-weighted expected payment model and discounted at the estimated cost of debt.

[0001032975-21-000017:notes:260]
On October 31, 2019, the Company acquired all of the equity interests of Streamlabs. In connection with the acquisition of Streamlabs, the Company agreed to pay a total earn out payment of $29.0 million, payable in stock, only upon the achievement of certain net revenues for the period beginning on January 1, 2020 and ending on June 30, 2020.

[0001032975-21-000017:notes:261]
The fair value of the earn-out as of the Streamlabs Acquisition Date was $0.04 million, and increased to $23.3 million as of March 31, 2020, which was determined by using a Black-Scholes-Merton valuation model to calculate the probability of the earn-out threshold being met, times the value of the earn-out payment, and discounted at the risk-free rate. The fair value was increased by $5.7 million to $29.0 million as of June 30, 2020, based on actual sales. The fair value of the contingent consideration no longer needs to be remeasured after June 30, 2020, as the earn-out period has been completed.

[0001032975-21-000017:notes:262]
During the third quarter of fiscal year 2021, Logitech issued 390,397 shares out of treasury shares to former security holders of Streamlabs, in satisfaction of payment of the contingent consideration that was earned during the earn-out period of January 1, 2020 through June 30, 2020. The issuances of such shares were deemed to be exempt from registration under the Securities Act of 1933 (the "Securities Act"), in reliance on Regulation D of the Securities Act as transactions by an issuer not involving a public offering.

[0001032975-21-000017:notes:263]
Although these estimates are based on management’s best knowledge of current events, the estimates could change significantly from period to period. Actual results that differ from the assumptions used and any changes to the significant assumptions and unobservable inputs used could have a material impact on future results of operations.

[0001032975-21-000017:notes:264]
Equity Method Investments

[0001032975-21-000017:notes:265]
The Company has certain non-marketable investments included in other assets that are accounted for under the equity method of accounting, with a carrying value of $40.7 million and $42.1 million as of March 31, 2021 and 2020, respectively.

[0001032975-21-000017:notes:266]
On March 2, 2020, the Company sold its $5.5 million investment, in a privately held company, for proceeds with a total fair value of $45.3 million consisting of cash, a 6% subordinated note due in 5 years, and a Series A preferred units and Series B common units in Marlin-SL Topco, LP ("Marlin"). As of March 31, 2021, the investment represents an ownership interest of approximately 10.8% in Marlin.

[0001032975-21-000017:notes:267]
The Company has evaluated whether Marlin qualifies as a variable interest entity ("VIE") pursuant to the accounting guidance of ASC 810, Consolidations. On the basis that the total equity investment in Marlin may not be sufficient to absorb its expected losses, the Company concluded that Marlin is currently a VIE. However, considering the Company's minority interest and limited involvement with the Marlin business, the Company concluded it is not required to consolidate Marlin. Rather, the Company accounts for this investment under the equity method as it represents an ownership interest in a limited partnership that is more than minor. The promissory note is accounted for as a loan receivable and is included in "Other assets" in the consolidated balance sheet.

[0001032975-21-000017:notes:268]
The Company's maximum exposure to any losses incurred by Marlin is limited to its investment. For fiscal year 2021, the carrying value of the investment in Marlin was $26.7 million. The Company's investment related to this VIE was not individually significant to the Company's consolidated financial statements.

[0001032975-21-000017:notes:269]
Unrealized gains (losses) related to Marlin and other equity investments for the fiscal year 2021 were not material and are included in other income (expense), net in the Company's consolidated statements of operations. There was no impairment of these assets during fiscal years 2021 and 2020.

[0001032975-21-000017:notes:270]
Assets Measured at Fair Value on a Nonrecurring Basis

[0001032975-21-000017:notes:271]
The Company’s non-financial assets, such as intangible assets and acquisition-related property, plant and equipment, are recorded at fair value only upon initial recognition or if an impairment is recognized. There was no impairment of long-lived assets during fiscal years 2021, 2020 and 2019.

[0001032975-21-000017:notes:272]
Financial Assets. The Company has certain investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with the same or similar security from the same issuer. The amount of these investments included in other assets was immaterial as of March 31, 2021 and 2020. During the fiscal year 2021, the Company recorded impairment charges of $2.0 million for its non-marketable equity securities which had an initial cost basis of $2.0 million as it was determined the carrying value of the investments were not recoverable.  There was no impairment of these assets during fiscal year 2020.

[0001032975-21-000017:notes:273]
Non-Financial Assets. Goodwill, intangible assets, and property, plant and equipment, are not required to be measured at fair value on a recurring basis. However, if certain triggering events occur (or tested at least annually for goodwill) such that a non-financial instrument is required to be evaluated for impairment and an impairment is recorded to reduce the non-financial instrument's carrying value to the fair value as a result of such triggering events, the non-financial assets and liabilities are measured at fair value for the period such triggering events occur. See Note 2 to the consolidated financial statements for additional information about how the Company tests various asset classes for impairment.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-21-000017:notes:274]
Derivative Financial Instruments
 Under certain agreements with the respective counterparties to the Company's derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis in other current assets or accrued and other current liabilities on the consolidated balance sheets as of March 31, 2021 and 2020.

[0001032975-21-000017:notes:275]
The fair values of the Company’s derivative instruments were not material as of March 31, 2021 or 2020 (refer to Note 9 to the consolidated financial statements for more information). The following table presents the amounts of gains and losses on the Company's derivative instruments designated as hedging instruments for fiscal years 2021, 2020 and 2019 and their locations on its consolidated statements of operations and consolidated statements of comprehensive income (in thousands):

[0001032975-21-000017:notes:276]
|  | Amount ofGain (Loss) Deferred asa Component ofAccumulated OtherComprehensive Loss |  | Amount of Loss (Gain)Reclassified fromAccumulated OtherComprehensive Lossto Costs of Goods Sold |  |  |
|  | 2021 |  | 2020 |  | 2019 |  | 2021 |  | 2020 |  | 2019 |  |  |  |  |  |  |
| Designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash flow hedges | $ | (4,071) |  | $ | 205 |  |  | $ | 1,781 |  |  | $ | 8,043 |  |  | $ | (813) |  |  | $ | 1,810 |  |  |  |  |  |  |  |

[0001032975-21-000017:notes:277]
Upon adoption of ASU 2017-12 "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" (ASU 2017-12), the Company has started presenting the earnings impact from forward points in the same line item that is used to present the earnings impact of the hedged item, i.e. cost of goods sold, for hedging forecasted inventory purchases and such amount is not material for all periods presented.

[0001032975-21-000017:notes:278]
Cash Flow Hedges: The Company enters into cash flow hedge contracts to protect against exchange rate exposure of forecasted inventory purchases. These hedging contracts mature within five months. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Cash flows from such hedges are classified as operating activities in the consolidated statements of cash flows. Hedging relationships are discontinued when hedging contract is no longer eligible for hedge accounting, or is sold, terminated or exercised, or when the Company removes hedge designation for the contract. Gains and losses in the fair value of the effective portion of the discontinued hedges continue to be reported in accumulated other comprehensive loss until the hedged inventory purchases are sold, unless it is probable that the forecasted inventory purchases will not occur by the end of the originally specified time period or within an additional two-month period of time thereafter. As of March 31, 2021, the notional amounts of currency forward contracts outstanding related to forecasted inventory purchases was $164.5 million. As of March 31, 2020, the notional amounts of currency forward contracts outstanding related to forecasted inventory purchases was $48.0 million. The Company estimates that $3.7 million of net loss related to its cash flow hedges included in accumulated other comprehensive loss as of March 31, 2021 will be reclassified into earnings within the next twelve months.

[0001032975-21-000017:notes:279]
Other Derivatives: The Company also enters into currency forward and swap contracts to reduce the short-term effects of currency fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These forward and swap contracts generally mature within a month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are recognized in other income (expense), net in the consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of March 31, 2021 and 2020 were $123.8 million and $64.7 million, respectively. Open forward and swap contracts as of March 31, 2021 and 2020 consisted of contracts in Taiwanese Dollars, Australian Dollars, Mexican Pesos, Japanese Yen and Canadian Dollars to be settled at future dates at pre-determined exchange rates.

[0001032975-21-000017:notes:280]
The fair value of all currency forward and swap contracts is determined based on observable market transactions of spot currency rates and forward rates. Cash flows from these contracts are classified as operating activities in the consolidated statements of cash flows.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-21-000017:notes:281]
Goodwill and Other Intangible Assets
The Company performed its annual impairment analysis of goodwill as of December 31, 2020 by performing a qualitative assessment and concluded that it was more likely than not that the fair value of its peripherals reporting unit, exceeded its carrying amount. In assessing the qualitative factors, the Company considered the impact of these key factors: change in industry and competitive environment, growth in market capitalization, and budgeted-to-actual revenue performance for the twelve months ended December 31, 2020. There have been no triggering events identified affecting the valuation of goodwill subsequent to the annual impairment test.

[0001032975-21-000017:notes:282]
The following table summarizes the activity in the Company's goodwill balance during fiscal years 2021 and 2020 (in thousands):

[0001032975-21-000017:notes:283]
|  |  | Years Ended March 31, |
|  |  | 2021 |  | 2020 |
| Beginning of the period |  | $ | 400,917 |  |  | $ | 343,684 |  |
| Acquisitions (1) |  | 28,667 |  |  | 57,206 |  |
| Currency exchange rate impact |  | 20 |  |  | 27 |  |
| End of the period |  | $ | 429,604 |  |  | $ | 400,917 |  |

[0001032975-21-000017:notes:284]
(1) Includes goodwill acquired from the Mevo Acquisition and an immaterial technology acquisition in January 2021. See Note 3 for more information.

[0001032975-21-000017:notes:285]
The Company's acquired intangible assets subject to amortization were as follows (in thousands):

[0001032975-21-000017:notes:286]
|  |  | March 31, |
|  |  | 2021 |  | 2020 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademarks and trade names |  | $ | 46,070 |  |  | $ | (25,153) |  |  | $ | 20,917 |  |  | $ | 45,570 |  |  | $ | (19,061) |  |  | $ | 26,509 |  |
| Developed technology |  | 134,406 |  |  | (90,450) |  |  | 43,956 |  |  | 118,807 |  |  | (77,126) |  |  | 41,681 |  |
| Customer contracts/relationships |  | 91,010 |  |  | (44,261) |  |  | 46,749 |  |  | 90,610 |  |  | (31,859) |  |  | 58,751 |  |
| In-process R&D |  | 3,526 |  |  | — |  |  | 3,526 |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 275,012 |  |  | $ | (159,864) |  |  | $ | 115,148 |  |  | $ | 254,987 |  |  | $ | (128,046) |  |  | $ | 126,941 |  |

[0001032975-21-000017:notes:287]
For fiscal years 2021, 2020 and 2019, amortization expense for intangible assets was, $31.8 million, $30.9 million and $24.2 million, respectively. The Company expects that annual amortization expense for fiscal years 2022, 2023, 2024, 2025 and 2026 will be $31.0 million, $24.9 million, $21.5 million, $17.0 million and $9.8 million, respectively, and $7.5 million thereafter.

[0001032975-21-000017:notes:288]
The intangible assets include $3.5 million of IPR&D from an immaterial asset acquisition in February 2021. IPR&D is capitalized at fair value and the amortization commences upon completion of the underlying projects. Once research and development efforts are completed, the corresponding amount of IPR&D is reclassified as an amortizable purchased intangible asset and is amortized over its estimated useful life. As of March 31, 2021, there was no IPR&D amortized.


## us-gaap:DebtDisclosureTextBlock

[0001032975-21-000017:notes:289]
Financing ArrangementsThe Company had several uncommitted, unsecured bank lines of credit aggregating $143.2 million as of March 31, 2021. There are no financial covenants under these lines of credit with which the Company must comply. As of March 31, 2021, the Company had outstanding bank guarantees of $91.3 million under these lines of credit. There was no borrowing outstanding under the line of credit as of March 31, 2021 or March 31, 2020.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-21-000017:notes:290]
Commitments and Contingencies
Product Warranties

[0001032975-21-000017:notes:291]
Changes in the Company's warranty liability for fiscal years 2021 and 2020 were as follows (in thousands):

[0001032975-21-000017:notes:292]
|  |  | Years Ended March 31, |
|  |  | 2021 |  | 2020 |
| Beginning of the period |  | $ | 40,039 |  |  | $ | 34,229 |  |
| Assumed from business acquisition |  | 231 |  |  | — |  |
| Provision |  | 38,463 |  |  | 34,186 |  |
| Settlements |  | (30,621) |  |  | (28,022) |  |
| Currency translation |  | 720 |  |  | (354) |  |
| End of the period |  | $ | 48,832 |  |  | $ | 40,039 |  |

[0001032975-21-000017:notes:293]
Indemnifications

[0001032975-21-000017:notes:294]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys' fees. As of March 31, 2021, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-21-000017:notes:295]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-21-000017:notes:296]
Legal Proceedings

[0001032975-21-000017:notes:297]
From time to time the Company is involved in claims and legal proceedings which arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial position, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial position, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-21-000017:notes:298]
Shareholders' Equity
Share Capital

[0001032975-21-000017:notes:299]
The Company's nominal share capital is CHF 43.3 million, consisting of 173,106,620 issued shares with a par value of CHF 0.25 each, of which 4,798,723 were held in treasury shares as of March 31, 2021.

[0001032975-21-000017:notes:300]
The Company has reserved conditional capital of 25,000,000 shares for potential issuance on the exercise of rights granted under the Company's employee equity incentive plans and additional conditional capital for financing purposes, representing the issuance of up to 25,000,000 shares to cover any conversion rights under a future convertible bond issuance. At the 2018 Annual General Meeting, the shareholders of the Company authorized the Board of Directors to issue up to an additional 34,621,324 shares of the Company until September 5, 2020, which authority expired on that date. At the 2020 Annual General Meeting, the shareholders of the Company authorized the Board of Directors to issue up to an additional 17,310,662 shares of the Company until September 9, 2022.

[0001032975-21-000017:notes:301]
Dividends

[0001032975-21-000017:notes:302]
Pursuant to Swiss corporate law, the payment of dividends is limited to certain amounts of unappropriated retained earnings (CHF 1,046.5 million, or $1,109.1 million based on the exchange rate at March 31, 2021) and is subject to shareholder approval.

[0001032975-21-000017:notes:303]
In April 2021, the Board of Directors recommended that the Company pay cash dividends for fiscal year 2021 of CHF 147.0 million ($155.8 million based on the exchange rate on March 31, 2021). In September 2020, the Company declared and paid cash dividends of CHF 0.79 (USD equivalent of $0.87) per common share, totaling $146.7 million on the Company's outstanding common stock. In September 2019, the Company declared and paid cash dividends of CHF 0.73 (USD equivalent of $0.74) per common share, totaling approximately $124.2 million in U.S. Dollars, on the Company’s outstanding common stock. In September 2018, the Company declared and paid cash dividends of CHF 0.67 (USD equivalent of $0.69) per common share, totaling approximately $114.0 million in U.S. Dollars, on the Company's outstanding common stock.

[0001032975-21-000017:notes:304]
Any future dividends will be subject to the approval of the Company's shareholders.

[0001032975-21-000017:notes:305]
Legal Reserves

[0001032975-21-000017:notes:306]
Under Swiss corporate law, a minimum of 5% of the Company's annual net income must be retained in a legal reserve until this legal reserve equals 20% of the Company's issued and outstanding aggregate par value per share capital. These legal reserves represent an appropriation of retained earnings that are not available for distribution and totaled $10.2 million at March 31, 2021 (based on the exchange rate at March 31, 2021).

[0001032975-21-000017:notes:307]
Share Repurchases

[0001032975-21-000017:notes:308]
In March 2017, the Company's Board of Directors approved the 2017 share repurchase program, which authorizes the Company to use up to $250.0 million to purchase up to 17.3 million of Logitech shares. This share repurchase program expired in April 2020.

[0001032975-21-000017:notes:309]
In May 2020, the Company's Board of Directors approved the 2020 share repurchase program, which authorized the Company to use up to $250.0 million to purchase up to 17.3 million of Logitech shares. The Company's share repurchase program is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. As of March 31, 2021, $85.4 million is still available for repurchase under the 2020 share repurchase program before the Board of Directors' approval of the increase of this program in April 2021.

[0001032975-21-000017:notes:310]
In April 2021, our Board of Directors approved an increase of $750.0 million of the 2020 share repurchase program, to an aggregate amount of $1.0 billion. This increase is subject to approval by the Swiss Takeover Board.

[0001032975-21-000017:notes:311]
A summary of the approved and active share repurchase program is shown in the following table (in thousands, excluding transaction costs):

[0001032975-21-000017:notes:312]
|  |  | Approved |  | Repurchased |
| Share Repurchase Program |  | Shares (1) |  | Amounts |  | Shares |  | Amounts |
| March 2017 |  | 17,311 |  |  | $ | 250,000 |  |  | 2,902 |  |  | $ | 112,614 |  |
| March 2020 |  | 17,311 |  |  | $ | 250,000 |  |  | 1,845 |  |  | $ | 164,618 |  |

[0001032975-21-000017:notes:313]
(1) The approval of each of the share repurchase programs by the Swiss Takeover Board limits the number of shares that the Company may repurchase to no more than 10% of its authorized share capital and voting rights.

[0001032975-21-000017:notes:314]
Accumulated Other Comprehensive Loss

[0001032975-21-000017:notes:315]
The components of accumulated other comprehensive loss were as follows (in thousands):

[0001032975-21-000017:notes:316]
|  |  | Accumulated Other Comprehensive Income (Loss) |
|  |  | CumulativeTranslationAdjustment |  | DefinedBenefitPlans |  | DeferredHedgingGains (Losses) |  | Total |
| March 31, 2020 |  | $ | (100,418) |  |  | $ | (20,016) |  |  | $ | (226) |  |  | $ | (120,660) |  |
| Other comprehensive income (loss) |  | 10,957 |  |  | (3,184) |  |  | 3,972 |  |  | 11,745 |  |
| March 31, 2021 |  | $ | (89,461) |  |  | $ | (23,200) |  |  | $ | 3,746 |  |  | $ | (108,915) |  |

[0001032975-21-000017:notes:317]
There was a $1.7 million reclassification of currency translation loss included in other income (expense), net for the year ended March 31, 2021 due to the liquidation of one of the Company's subsidiaries. There was a $0.5 million reclassification of currency translation loss included in other income (expense), net for the year ended March 31, 2019 due to the liquidation of one of the Company's subsidiaries.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-21-000017:notes:318]
Segment Information
The Company operates in a single operating segment that encompasses the design, manufacturing and marketing of peripherals for PCs, tablets and other digital platforms. Operating performance measures are provided directly to the Company's CEO, who is considered to be the Company’s Chief Operating Decision Maker. The CEO periodically reviews information such as sales and adjusted operating income (loss) to make business decisions. These operating performance measures do not include restructuring charges (credits), net, share-based compensation expense, amortization of intangible assets, charges from the purchase accounting effect on inventory, acquisition-related costs, or change in fair value of contingent consideration from business acquisition.

[0001032975-21-000017:notes:319]
Sales by product categories were as follows (in thousands):

[0001032975-21-000017:notes:320]
|  |  | Years Ended March 31, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Pointing Devices |  | $ | 680,907 |  |  | $ | 544,519 |  |  | $ | 536,890 |  |
| Keyboards & Combos |  | 784,488 |  |  | 571,720 |  |  | 536,619 |  |
| PC Webcams |  | 439,865 |  |  | 129,193 |  |  | 121,282 |  |
| Tablet & Other Accessories |  | 384,301 |  |  | 135,309 |  |  | 128,315 |  |
| Gaming (1) |  | 1,239,005 |  |  | 690,174 |  |  | 648,130 |  |
| Video Collaboration |  | 1,044,935 |  |  | 365,616 |  |  | 259,521 |  |
| Mobile Speakers |  | 174,895 |  |  | 221,791 |  |  | 230,378 |  |
| Audio & Wearables |  | 468,776 |  |  | 273,752 |  |  | 277,429 |  |
| Smart Home |  | 34,394 |  |  | 43,404 |  |  | 49,344 |  |
| Other (2) |  | 713 |  |  | 373 |  |  | 414 |  |
| Total Sales |  | $ | 5,252,279 |  |  | $ | 2,975,851 |  |  | $ | 2,788,322 |  |

[0001032975-21-000017:notes:321]
(1) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-21-000017:notes:322]
(2) Other includes products that the Company currently intends to phase out, or has already phased out, because they are no longer strategic to the Company's business.

[0001032975-21-000017:notes:323]
Sales by geographic region for fiscal years 2021, 2020 and 2019 (based on the customers' locations) were as follows (in thousands):

[0001032975-21-000017:notes:324]
|  |  | Years Ended March 31, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Americas |  | $ | 2,206,552 |  |  | $ | 1,286,527 |  |  | $ | 1,190,216 |  |
| EMEA |  | 1,735,682 |  |  | 941,211 |  |  | 861,731 |  |
| Asia Pacific |  | 1,310,045 |  |  | 748,113 |  |  | 736,375 |  |
| Total Sales |  | $ | 5,252,279 |  |  | $ | 2,975,851 |  |  | $ | 2,788,322 |  |

[0001032975-21-000017:notes:325]
Revenues from sales to customers in the United States represented 35%, 36% and 36% of sales in fiscal years 2021, 2020 and 2019, respectively. Revenues from sales to customers in Germany represented 16%, 15% and 18% of sales in fiscal years 2021, 2020 and 2019, respectively. Revenues from sales to customers in China represented 10% of sales in fiscal year 2019. No other single country represented more than 10% of sales during these periods. Revenues from sales to customers in Switzerland, the Company's home domicile, represented 3%, 4% and 3% of sales in fiscal years 2021, 2020 and 2019, respectively.

[0001032975-21-000017:notes:326]
Property, plant and equipment, net by geographic region were as follows (in thousands):

[0001032975-21-000017:notes:327]
|  |  | March 31, |
|  |  | 2021 |  | 2020 |
| Americas |  | $ | 20,810 |  |  | $ | 26,636 |  |
| EMEA |  | 8,019 |  |  | 5,052 |  |
| Asia Pacific |  | 85,231 |  |  | 44,431 |  |
| Total property, plant and equipment |  | $ | 114,060 |  |  | $ | 76,119 |  |

[0001032975-21-000017:notes:328]
Property, plant and equipment, net in the United States and China were $20.5 million and $74.0 million, respectively, as of March 31, 2021, and $26.5 million and $36.6 million, respectively, as of March 31, 2020. No other countries represented more than 10% of the Company's total consolidated property, plant and equipment, net as of March 31, 2021 or 2020. Property, plant and equipment, net in Switzerland, the Company's home domicile, were $5.7 million and $2.3 million as of March 31, 2021 and 2020, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001032975-21-000017:notes:329]
RestructuringDuring the first quarter of fiscal year 2019, the Company implemented a restructuring plan to streamline and realign the Company's overall organizational structure and reallocate resources to support long-term growth opportunities. In July 2018, the Company's Board of Directors approved additional costs under this restructuring plan, totaling pre-tax charges of approximately $10.0 million to $15.0 million, of which $11.4 million has been recognized cumulatively as of March 31, 2021. The total charges consisted of cash severance and other personnel costs and are presented as restructuring charges (credits), net in the Consolidated Statements of Operations. During the first quarter of fiscal year 2020, the Company had substantially completed this restructuring plan.
The following table summarizes restructuring-related activities during fiscal year 2021, 2020 and 2019 (in thousands):

[0001032975-21-000017:notes:330]
|  |  | Restructuring - Continuing Operations |  |
|  |  | TerminationBenefits |  | Lease ExitCosts |  | Total |  |
| Accrual balance at March 31, 2018 |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |
| Credits, net |  | 11,302 |  |  | — |  |  | 11,302 |  |  |
| Cash payments |  | (6,913) |  |  | — |  |  | (6,913) |  |  |
| Accrual balance at March 31, 2019 |  | 4,389 |  |  | — |  |  | 4,389 |  |  |
| Charges, net |  | 144 |  |  | — |  |  | 144 |  |  |
| Cash payments |  | (3,852) |  |  | — |  |  | (3,852) |  |  |
| Accrual balance at March 31, 2020 |  | 681 |  |  | — |  |  | 681 |  |  |
| Charges, net |  | (54) |  |  | — |  |  | (54) |  |  |
| Accrual balance at March 31, 2021 |  | $ | 627 |  |  | $ | — |  |  | $ | 627 |  |  |

[0001032975-21-000017:notes:331]
The accrual balances are included in accrued and other current liabilities on the Company’s consolidated balance sheets.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001032975-21-000017:notes:332]
Leases
The Company is a lessee in several noncancellable operating leases, primarily real estate facilities for office space and for transportation and office equipment.

[0001032975-21-000017:notes:333]
The Company's lease arrangements comprise of operating leases with various expiration dates through June 30, 2031. The lease term for all of the Company’s leases includes the noncancellable period of the lease. Certain lease agreements include options to renew or terminate the lease, which are not reasonably certain to be exercised and therefore are not factored into our determination of the duration of the lease arrangement.

[0001032975-21-000017:notes:334]
The Company's leases do not contain any material residual value guarantees.

[0001032975-21-000017:notes:335]
The total operating lease costs were $15.0 million and $14.1 million as of March 31, 2021 and 2020, respectively, and included short-term lease costs and sublease income. Total variable lease costs were immaterial during the year ended March 31, 2021 and 2020. The total operating and variable lease costs were included in cost of goods sold, marketing and selling, research and development, and general and administrative in the Company's consolidated statement of operations.

[0001032975-21-000017:notes:336]
Supplemental cash flow information related to operating leases (in thousands):

[0001032975-21-000017:notes:337]
|  | Years Ended March 31, |
|  | 2021 |  | 2020 |
| Cash paid for amounts included in the measurement of operating lease liabilities | $ | 13,865 |  |  | $ | 13,554 |  |
| ROU assets obtained in the exchange for operating lease liabilities | $ | 15,659 |  |  | $ | 6,123 |  |

[0001032975-21-000017:notes:338]
Future lease payments included in the measurement of lease liabilities as of March 31, 2021 for the following five fiscal years and thereafter are as follows (in thousands):

[0001032975-21-000017:notes:339]
|  | Operating Lease |
| Years Ending March 31, |  |
| 2022 | $ | 13,827 |  |
| 2023 | 9,861 |  |
| 2024 | 4,650 |  |
| 2025 | 3,415 |  |
| 2026 | 1,706 |  |
| Thereafter | 2,649 |  |
| Total lease payments | 36,108 |  |
| Less interest | (1,688) |  |
| Present value of lease liabilities | $ | 34,420 |  |

[0001032975-21-000017:notes:340]
Average lease terms and discount rates were as follows:

[0001032975-21-000017:notes:341]
|  | Years Ended March 31, |
|  | 2021 |  | 2020 |
| Weighted-average remaining lease terms (in years) | 3.8 |  | 3.8 |
| Weighted-average discount rate | 2.7 | % |  | 3.0 | % |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001032975-21-000017:notes:342]
VALUATION AND QUALIFYING ACCOUNTS

[0001032975-21-000017:notes:343]
For the Fiscal Years Ended March 31, 2021, 2020 and 2019 (in thousands)

[0001032975-21-000017:notes:344]
The Company's Schedule II includes valuation and qualifying accounts related to allowances for doubtful accounts, sales returns, cooperative marketing arrangements, customer incentive programs, and pricing programs, for direct customers and tax valuation allowances. The Company also has sales incentive programs for indirect customers with whom it does not have a direct sales and receivable relationship. These programs are recorded as accrued liabilities and are not considered valuation or qualifying accounts.

[0001032975-21-000017:notes:345]
|  |  | Balance atBeginning ofYear |  | Charged(Credited) to Statement ofOperations (1) |  | Claims andAdjustmentsApplied AgainstAllowances (1) |  | Balance atEnd ofYear |
| Allowance for doubtful accounts: |  |  |  |  |  |  |  |  |
| 2021 |  | $ | 1,894 |  |  | $ | (533) |  |  | $ | (200) |  |  | $ | 1,161 |  |
| 2020 |  | $ | 84 |  |  | $ | 1,607 |  |  | $ | 203 |  |  | $ | 1,894 |  |
| 2019 |  | $ | 122 |  |  | $ | 840 |  |  | $ | (878) |  |  | $ | 84 |  |
| Allowance for sales returns: |  |  |  |  |  |  |  |  |
| 2021 |  | $ | 6,599 |  |  | $ | 122,803 |  |  | $ | (114,964) |  |  | $ | 14,438 |  |
| 2020 |  | $ | 6,486 |  |  | $ | 107,980 |  |  | $ | (107,868) |  |  | $ | 6,599 |  |
| 2019 |  | $ | 25,515 |  |  | $ | 94,381 |  |  | $ | (113,410) |  |  | $ | 6,486 |  |
| Allowance for cooperative marketing arrangements: |  |  |  |  |  |  |  |  |
| 2021 |  | $ | 38,794 |  |  | $ | 222,732 |  |  | $ | (218,250) |  |  | $ | 43,276 |  |
| 2020 |  | $ | 35,080 |  |  | $ | 194,730 |  |  | $ | (191,015) |  |  | $ | 38,794 |  |
| 2019 |  | $ | 30,389 |  |  | $ | 176,323 |  |  | $ | (171,632) |  |  | $ | 35,080 |  |
| Allowance for customer incentive programs: |  |  |  |  |  |  |  |  |
| 2021 |  | $ | 55,741 |  |  | $ | 256,755 |  |  | $ | (236,296) |  |  | $ | 76,200 |  |
| 2020 |  | $ | 60,036 |  |  | $ | 248,966 |  |  | $ | (253,260) |  |  | $ | 55,741 |  |
| 2019 |  | $ | 70,592 |  |  | $ | 237,580 |  |  | $ | (248,136) |  |  | $ | 60,036 |  |
| Allowance for pricing programs: |  |  |  |  |  |  |  |  |
| 2021 |  | $ | 100,168 |  |  | $ | 782,734 |  |  | $ | (762,334) |  |  | $ | 120,568 |  |
| 2020 |  | $ | 88,353 |  |  | $ | 570,409 |  |  | $ | (558,594) |  |  | $ | 100,168 |  |
| 2019 |  | $ | 141,369 |  |  | $ | 444,540 |  |  | $ | (497,556) |  |  | $ | 88,353 |  |
| Tax valuation allowance: |  |  |  |  |  |  |  |  |
| 2021 |  | $ | 29,171 |  |  | $ | (245) |  |  | $ | — |  |  | $ | 28,926 |  |
| 2020 |  | $ | 28,375 |  |  | $ | 796 |  |  | $ | — |  |  | $ | 29,171 |  |
| 2019 |  | $ | 25,148 |  |  | $ | 3,244 |  |  | $ | (17) |  |  | $ | 28,375 |  |

[0001032975-21-000017:notes:346]
(1) The amounts for fiscal years 2021, 2020 and 2019 include immaterial impacts from the business acquisitions during the year. Refer to Note 3 to the consolidated financial statements.
