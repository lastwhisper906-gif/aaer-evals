# LOGI 8-K — 0001032975-21-000012 filed 2021-04-29

## item codes, every 8-K on or before 2021-05-12

- 2021-04-29 0001032975-21-000012 — 2.02, 9.01
- 2021-01-19 0001032975-21-000004 — 2.02, 9.01
- 2020-10-20 0001032975-20-000045 — 2.02, 9.01
- 2020-09-11 0001032975-20-000042 — 5.07, 8.01
- 2020-07-21 0001032975-20-000029 — 2.02, 9.01
- 2020-07-01 0001032975-20-000023 — 5.02, 8.01
- 2020-05-12 0001032975-20-000011 — 2.02, 9.01
- 2020-03-30 0001032975-20-000009 — 5.02
- 2020-01-21 0001032975-20-000002 — 2.02, 9.01
- 2019-10-22 0001032975-19-000071 — 9.01
- 2019-09-26 0001032975-19-000068 — 1.01, 7.01, 9.01
- 2019-09-06 0001032975-19-000063 — 5.07, 8.01
- 2019-07-23 0001032975-19-000046 — 2.02, 9.01
- 2019-07-23 0001032975-19-000045 — 5.02, 9.01
- 2019-07-02 0001032975-19-000036 — 5.02
- 2019-06-25 0001032975-19-000034 — 5.02
- 2019-05-03 0001032975-19-000021 — 5.02 — amendment, the index does not say of what
- 2019-04-30 0001032975-19-000017 — 2.02, 5.02, 9.01
- 2019-03-28 0001032975-19-000013 — 5.02
- 2019-01-22 0001032975-19-000004 — 2.02, 9.01
- 2018-10-23 0001032975-18-000044 — 2.02, 9.01
- 2018-09-07 0001032975-18-000040 — 5.07, 8.01
- 2018-07-31 0001032975-18-000035 — 1.01, 2.02, 2.05, 7.01, 9.01
- 2018-06-27 0001032975-18-000020 — 5.02
- 2018-05-03 0001032975-18-000013 — 2.02, 5.02, 9.01
- 2018-01-23 0001032975-18-000005 — 2.02, 9.01
- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2021-05-12

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-21-000012:8k_2_02:1]
EX-99.1
2
exhibit991q4fy21ng.htm
EX-99.1

[0001032975-21-000012:8k_2_02:2]
Document

[0001032975-21-000012:8k_2_02:3]
Exhibit 99.1

[0001032975-21-000012:8k_2_02:4]
Editorial Contacts:

[0001032975-21-000012:8k_2_02:5]
Ben Lu, CFA, Vice President, Investor Relations - USA (510) 713-5568

[0001032975-21-000012:8k_2_02:6]
Nicole Kenyon, Head of Global Corporate & Employee Communications - USA (510) 988-8553

[0001032975-21-000012:8k_2_02:7]
Ben Starkie, Corporate Communications - Europe +41 (0) 79-292-3499

[0001032975-21-000012:8k_2_02:8]
Logitech Grows 76% for Fiscal Year 2021,

[0001032975-21-000012:8k_2_02:9]
Q4 Revenue Doubles

[0001032975-21-000012:8k_2_02:10]
Company Raises FY 2022 Guidance,

[0001032975-21-000012:8k_2_02:11]
Share Buyback Authorization Raised to $1 Billion

[0001032975-21-000012:8k_2_02:12]
LAUSANNE, Switzerland, Apr. 29, 2021 and NEWARK, Calif., Apr. 28, 2021 — Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the fourth quarter and full year of Fiscal Year 2021, ended March 31, 2021.

[0001032975-21-000012:8k_2_02:13]
For Fiscal Year 2021:

[0001032975-21-000012:8k_2_02:14]
•Sales were Logitech’s highest ever at $5.25 billion, up 76 percent in US dollars and 74 percent in constant currency compared to the prior year.

[0001032975-21-000012:8k_2_02:15]
•GAAP operating income grew 315 percent to $1.15 billion, compared to $276 million a year ago. GAAP earnings per share (EPS) grew 107 percent to $5.51, compared to $2.66 a year ago.

[0001032975-21-000012:8k_2_02:16]
•Non-GAAP operating income grew 229 percent to $1.27 billion, compared to $387 million a year ago. Non-GAAP EPS grew 199 percent to $6.42, compared to $2.15 a year ago.

[0001032975-21-000012:8k_2_02:17]
•Cash flow from operations was $1.46 billion, compared to $425 million a year ago.

[0001032975-21-000012:8k_2_02:18]
For Q4 Fiscal Year 2021:

[0001032975-21-000012:8k_2_02:19]
•Sales were $1.54 billion, up 117 percent in US dollars and 108 percent in constant currency compared to Q4 of the prior year.

[0001032975-21-000012:8k_2_02:20]
•GAAP operating income grew 818 percent to $295 million, compared to Q4 of the prior year. Non-GAAP operating income grew 312 percent to $325 million, compared to Q4 of the prior year.

[0001032975-21-000012:8k_2_02:21]
“Fiscal Year 2021 was our best year ever,” said Bracken Darrell, Logitech president and chief executive officer. “It has been rewarding to see Logitech’s products play an essential role enabling work, creation, connection and entertainment as our homes became schools, offices and playgrounds. Our powerful and resilient capabilities allowed us to both deliver remarkable performance in a challenging FY 2021 and, at the same time, invest in compelling plans for the future. The world has just caught a glimpse of what Logitech will become.”

[0001032975-21-000012:8k_2_02:22]
“We delivered excellent financial performance, including record net sales, operating profit, gross margin and cash flow,” said Nate Olmstead, Logitech chief financial officer. “The trends that fueled our growth pre-pandemic - work from anywhere, video everywhere, esports and the democratization of content creation - all accelerated. As our market opportunities have expanded, and we have become a larger,

[0001032975-21-000012:8k_2_02:23]
more profitable company, we’re investing in our capabilities to accelerate our innovation, reach new customers and deliver strong financial returns over the long-term.”

[0001032975-21-000012:8k_2_02:24]
Outlook

[0001032975-21-000012:8k_2_02:25]
Logitech raised its Fiscal Year 2022 outlook for non-GAAP operating income to between $800 million and $850 million. Previously, it was expected to be between $750 million and $800 million. The outlook for sales growth in constant currency is still expected to be approximately flat, plus or minus 5 percent.

[0001032975-21-000012:8k_2_02:26]
Increased Share Buyback Program and Proposed FY21 Dividend

[0001032975-21-000012:8k_2_02:27]
Logitech’s board of directors has approved an increased share buyback authorization up to $1 billion. This expands the Company’s current $250 million, three-year share buyback authorization. To date, the Company has repurchased $165 million of shares in the current program. Following approval from the Swiss Takeover Board, the increase will give a total authorization of $835 million for repurchases over the remaining 27 months of the program through July 2023.

[0001032975-21-000012:8k_2_02:28]
Logitech’s board of directors has also approved a proposal for a Fiscal Year 2021 dividend, which would be approximately a 10 percent annual increase versus last year’s dividend. Together with the new share buyback authorization, this demonstrates the Company’s continued commitment to consistently return cash to shareholders.

[0001032975-21-000012:8k_2_02:29]
Prepared Remarks Available Online

[0001032975-21-000012:8k_2_02:30]
Logitech has made its prepared written remarks for the financial results videoconference available online on the Logitech corporate website at http://ir.logitech.com.

[0001032975-21-000012:8k_2_02:31]
Financial Results Videoconference and Webcast

[0001032975-21-000012:8k_2_02:32]
Logitech will hold a financial results videoconference to discuss the results for Q4 and the full Fiscal Year 2021 on Thursday, April 29, 2021 at 8:30 a.m. Eastern Daylight Time and 2:30 p.m. Central European Summer Time. A livestream of the event will be available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-21-000012:8k_2_02:33]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-21-000012:8k_2_02:34]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of intangible assets,  acquisition-related costs, change in fair value of contingent consideration for business acquisition, restructuring charges (credits), loss (gain) on investments, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below. Logitech also presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP

[0001032975-21-000012:8k_2_02:35]
financial information, will help investors to evaluate its current period performance and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for Fiscal Year 2022.

[0001032975-21-000012:8k_2_02:36]
About Logitech

[0001032975-21-000012:8k_2_02:37]
Logitech designs products that have an everyday place in people's lives, connecting them to the digital experiences they care about. Almost 40 years ago, Logitech started connecting people through computers, and now it’s a multi-brand company designing products that bring people together through music, gaming, video and computing. Brands of Logitech include Logitech, Logitech G, ASTRO Gaming, Streamlabs, Blue Microphones, Ultimate Ears, and Jaybird. Founded in 1981, and headquartered in Lausanne, Switzerland, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @Logitech.

[0001032975-21-000012:8k_2_02:38]
# # #

[0001032975-21-000012:8k_2_02:39]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-21-000012:8k_2_02:40]
Logitech and other Logitech marks are trademarks or registered trademarks of Logitech Europe S.A. and/or its affiliates in the U.S. and other countries.  All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-21-000012:8k_2_02:41]
(LOGIIR)

[0001032975-21-000012:8k_2_02:42]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales |  | $ | 1,535,925 |  |  | $ | 709,248 |  |  | $ | 5,252,279 |  |  | $ | 2,975,851 |  |
| Cost of goods sold |  | 821,127 |  |  | 428,080 |  |  | 2,903,215 |  |  | 1,838,685 |  |
| Amortization of intangible assets |  | 3,529 |  |  | 4,292 |  |  | 13,329 |  |  | 14,785 |  |
| Gross profit |  | 711,269 |  |  | 276,876 |  |  | 2,335,735 |  |  | 1,122,381 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 273,764 |  |  | 141,186 |  |  | 770,284 |  |  | 533,324 |  |
| Research and development |  | 69,009 |  |  | 50,094 |  |  | 226,023 |  |  | 177,593 |  |
| General and administrative |  | 68,236 |  |  | 25,465 |  |  | 166,577 |  |  | 94,015 |  |
| Amortization of intangible assets and acquisition-related costs |  | 5,178 |  |  | 4,666 |  |  | 19,064 |  |  | 17,563 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | 23,247 |  |  | 5,716 |  |  | 23,247 |  |
| Restructuring charges (credits), net |  | — |  |  | 74 |  |  | (54) |  |  | 144 |  |
| Total operating expenses |  | 416,187 |  |  | 244,732 |  |  | 1,187,610 |  |  | 845,886 |  |
| Operating income |  | 295,082 |  |  | 32,144 |  |  | 1,148,125 |  |  | 276,495 |  |
| Interest income |  | 340 |  |  | 2,614 |  |  | 1,784 |  |  | 9,619 |  |
| Other income (expense), net |  | (11,450) |  |  | 35,360 |  |  | (1,789) |  |  | 38,212 |  |
| Income before income taxes |  | 283,972 |  |  | 70,118 |  |  | 1,148,120 |  |  | 324,326 |  |
| Provision for (benefit from) income taxes |  | 58,225 |  |  | (143,802) |  |  | 200,863 |  |  | (125,397) |  |
| Net income |  | $ | 225,747 |  |  | $ | 213,920 |  |  | $ | 947,257 |  |  | $ | 449,723 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.34 |  |  | $ | 1.28 |  |  | $ | 5.62 |  |  | $ | 2.70 |  |
| Diluted |  | $ | 1.31 |  |  | $ | 1.26 |  |  | $ | 5.51 |  |  | $ | 2.66 |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | 168,734 |  |  | 167,290 |  |  | 168,523 |  |  | 166,837 |  |
| Diluted |  | 172,954 |  |  | 169,981 |  |  | 171,775 |  |  | 169,381 |  |

[0001032975-21-000012:8k_2_02:43]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | March 31, |  | March 31, |  |  |  |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  | 2021 |  | 2020 |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,750,327 |  |  | $ | 715,566 |  |  |  |  |  |
| Accounts receivable, net |  | 612,225 |  |  | 394,743 |  |  |  |  |  |
| Inventories |  | 661,116 |  |  | 229,249 |  |  |  |  |  |
| Other current assets |  | 135,650 |  |  | 74,920 |  |  |  |  |  |
| Total current assets |  | 3,159,318 |  |  | 1,414,478 |  |  |  |  |  |
| Non-current assets: |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 114,060 |  |  | 76,119 |  |  |  |  |  |
| Goodwill |  | 429,604 |  |  | 400,917 |  |  |  |  |  |
| Other intangible assets, net |  | 115,148 |  |  | 126,941 |  |  |  |  |  |
| Other assets |  | 324,248 |  |  | 345,019 |  |  |  |  |  |
| Total assets |  | $ | 4,142,378 |  |  | $ | 2,363,474 |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 823,233 |  |  | $ | 259,120 |  |  |  |  |  |
| Accrued and other current liabilities |  | 858,617 |  |  | 455,024 |  |  |  |  |  |
| Total current liabilities |  | 1,681,850 |  |  | 714,144 |  |  |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Income taxes payable |  | 59,237 |  |  | 40,788 |  |  |  |  |  |
| Other non-current liabilities |  | 139,502 |  |  | 119,274 |  |  |  |  |  |
| Total liabilities |  | 1,880,589 |  |  | 874,206 |  |  |  |  |  |
| Shareholders' equity: |  |  |  |  |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |  |  |  |  |
| Issued shares—173,106 at March 31, 2021 and 2020 |  |  |  |  |  |  |  |  |
| Additional shares that may be issued out of conditional capitals — 50,000 at March 31, 2021 and March 31, 2020 |  |  |  |  |  |  |  |  |
| Additional shares that may be issued out of authorized capital — 17,311 at March 31, 2021 and 34,621 March 31, 2020 |  |  |  |  |  |  |  |  |
| Additional paid-in capital |  | 129,519 |  |  | 75,097 |  |  |  |  |  |
| Shares in treasury, at cost— 4,799 and 6,210 shares at March 31, 2021 and 2020, respectively |  | (279,541) |  |  | (185,896) |  |  |  |  |  |
| Retained earnings |  | 2,490,578 |  |  | 1,690,579 |  |  |  |  |  |
| Accumulated other comprehensive loss |  | (108,915) |  |  | (120,660) |  |  |  |  |  |
| Total shareholders' equity |  | 2,261,789 |  |  | 1,489,268 |  |  |  |  |  |
| Total liabilities and shareholders' equity |  | $ | 4,142,378 |  |  | $ | 2,363,474 |  |  |  |  |  |

[0001032975-21-000012:8k_2_02:44]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 225,747 |  |  | $ | 213,920 |  |  | $ | 947,257 |  |  | $ | 449,723 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  | 14,742 |  |  | 10,739 |  |  | 50,752 |  |  | 42,893 |  |
| Amortization of intangible assets |  | 8,191 |  |  | 8,900 |  |  | 31,818 |  |  | 30,858 |  |
| Investment impairment |  | 2,011 |  |  | — |  |  | 2,011 |  |  | — |  |
| Share-based compensation expense |  | 21,305 |  |  | 14,569 |  |  | 86,019 |  |  | 54,870 |  |
| Loss (gain) on investments |  | (793) |  |  | (16) |  |  | 3,899 |  |  | 756 |  |
| Deferred income taxes |  | (3,199) |  |  | (160,333) |  |  | 34,484 |  |  | (159,853) |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | 23,247 |  |  | 5,716 |  |  | 23,247 |  |
| Gain on sale of investment in privately held companies |  | — |  |  | (39,767) |  |  | — |  |  | (39,767) |  |
| Other |  | (114) |  |  | 76 |  |  | (1,784) |  |  | (936) |  |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | 275,584 |  |  | 131,524 |  |  | (201,220) |  |  | (15,768) |  |
| Inventories |  | (188,123) |  |  | 75,558 |  |  | (427,501) |  |  | 60,388 |  |
| Other assets |  | (14,427) |  |  | 15,453 |  |  | (67,708) |  |  | 18,319 |  |
| Accounts payable |  | 12,936 |  |  | (179,440) |  |  | 553,960 |  |  | (24,250) |  |
| Accrued and other liabilities |  | 176,359 |  |  | (13,584) |  |  | 440,935 |  |  | (15,480) |  |
| Net cash provided by operating activities |  | 530,219 |  |  | 100,846 |  |  | 1,458,638 |  |  | 425,000 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (30,026) |  |  | (10,817) |  |  | (76,189) |  |  | (39,484) |  |
| Investment in privately held companies |  | (590) |  |  | (35) |  |  | (4,115) |  |  | (345) |  |
| Acquisitions, net of cash acquired |  | (43,163) |  |  | — |  |  | (43,523) |  |  | (91,569) |  |
| Proceeds from return of strategic investments |  | — |  |  | — |  |  | 2,934 |  |  | — |  |
| Proceeds from sale of property, plant and equipment |  | — |  |  | — |  |  | — |  |  | 1,037 |  |
| Purchases of trading investments |  | (1,664) |  |  | (8,893) |  |  | (12,336) |  |  | (11,964) |  |
| Proceeds from sales of trading investments |  | 1,915 |  |  | 8,952 |  |  | 13,247 |  |  | 12,091 |  |
| Net cash used in investing activities |  | (73,528) |  |  | (10,793) |  |  | (119,982) |  |  | (130,234) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | — |  |  | — |  |  | (146,705) |  |  | (124,180) |  |
| Purchases of registered shares |  | (92,227) |  |  | (35,310) |  |  | (164,952) |  |  | (50,437) |  |
| Proceeds from exercises of stock options and purchase rights |  | 14,101 |  |  | 10,701 |  |  | 43,810 |  |  | 22,241 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (2,607) |  |  | (1,184) |  |  | (32,082) |  |  | (24,280) |  |
| Net cash used in financing activities |  | (80,733) |  |  | (25,793) |  |  | (299,929) |  |  | (176,656) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (14,374) |  |  | (4,740) |  |  | (3,966) |  |  | (7,060) |  |
| Net increase in cash and cash equivalents |  | 361,584 |  |  | 59,520 |  |  | 1,034,761 |  |  | 111,050 |  |
| Cash and cash equivalents at beginning of the period |  | 1,388,743 |  |  | 656,046 |  |  | 715,566 |  |  | 604,516 |  |
| Cash and cash equivalents at end of the period |  | $ | 1,750,327 |  |  | $ | 715,566 |  |  | $ | 1,750,327 |  |  | $ | 715,566 |  |

[0001032975-21-000012:8k_2_02:45]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| NET SALES |  | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Net sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Pointing Devices |  | $ | 177,679 |  |  | $ | 135,226 |  |  | 31 | % |  | $ | 680,907 |  |  | $ | 544,519 |  |  | 25 | % |
| Keyboards & Combos |  | 219,242 |  |  | 147,659 |  |  | 48 |  |  | 784,488 |  |  | 571,720 |  |  | 37 |  |
| PC Webcams |  | 144,845 |  |  | 40,152 |  |  | 261 |  |  | 439,865 |  |  | 129,193 |  |  | 240 |  |
| Tablet & Other Accessories |  | 117,115 |  |  | 31,867 |  |  | 268 |  |  | 384,301 |  |  | 135,309 |  |  | 184 |  |
| Gaming (1) |  | 322,965 |  |  | 148,909 |  |  | 117 |  |  | 1,239,005 |  |  | 690,174 |  |  | 80 |  |
| Video Collaboration |  | 385,657 |  |  | 110,675 |  |  | 248 |  |  | 1,044,935 |  |  | 365,616 |  |  | 186 |  |
| Mobile Speakers |  | 29,739 |  |  | 21,174 |  |  | 40 |  |  | 174,895 |  |  | 221,791 |  |  | (21) |  |
| Audio & Wearables |  | 130,184 |  |  | 65,176 |  |  | 100 |  |  | 468,776 |  |  | 273,752 |  |  | 71 |  |
| Smart Home |  | 8,418 |  |  | 8,316 |  |  | 1 |  |  | 34,394 |  |  | 43,404 |  |  | (21) |  |
| Other (2) |  | 81 |  |  | 94 |  |  | (14) |  |  | 713 |  |  | 373 |  |  | 91 |  |
| Total net retail sales |  | $ | 1,535,925 |  |  | $ | 709,248 |  |  | 117 | % |  | $ | 5,252,279 |  |  | $ | 2,975,851 |  |  | 76 | % |
| __________________ |  |  |  |  |  |  |  |  |  |  |  |  |

[0001032975-21-000012:8k_2_02:46]
(1) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-21-000012:8k_2_02:47]
(2) Other includes products that the Company currently intends to phase out, or has already phased out, because they are no longer strategic to the Company's business.

[0001032975-21-000012:8k_2_02:48]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| GAAP TO NON GAAP RECONCILIATION (A) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Gross profit - GAAP |  | $ | 711,269 |  |  | $ | 276,876 |  |  | $ | 2,335,735 |  |  | $ | 1,122,381 |  |
| Share-based compensation expense |  | 1,519 |  |  | 1,300 |  |  | 6,438 |  |  | 4,852 |  |
| Amortization of intangible assets |  | 3,529 |  |  | 4,292 |  |  | 13,329 |  |  | 14,785 |  |
| Gross profit - Non-GAAP |  | $ | 716,317 |  |  | $ | 282,468 |  |  | $ | 2,355,502 |  |  | $ | 1,142,018 |  |
| Gross margin - GAAP |  | 46.3 | % |  | 39.0 | % |  | 44.5 | % |  | 37.7 | % |
| Gross margin - Non-GAAP |  | 46.6 | % |  | 39.8 | % |  | 44.8 | % |  | 38.4 | % |
| Operating expenses - GAAP |  | $ | 416,187 |  |  | $ | 244,732 |  |  | $ | 1,187,610 |  |  | $ | 845,886 |  |
| Less: Share-based compensation expense |  | 19,786 |  |  | 13,269 |  |  | 79,581 |  |  | 50,018 |  |
| Less: Amortization of intangible assets and acquisition-related costs |  | 5,178 |  |  | 4,666 |  |  | 19,064 |  |  | 17,563 |  |
| Less: Change in fair value of contingent consideration for business acquisition |  | — |  |  | 23,247 |  |  | 5,716 |  |  | 23,247 |  |
| Less: Restructuring charges (credits), net |  | — |  |  | 74 |  |  | (54) |  |  | 144 |  |
| Operating expenses - Non-GAAP |  | $ | 391,223 |  |  | $ | 203,476 |  |  | $ | 1,083,303 |  |  | $ | 754,914 |  |
| % of net sales - GAAP |  | 27.1 | % |  | 34.5 | % |  | 22.6 | % |  | 28.4 | % |
| % of net sales - Non - GAAP |  | 25.5 | % |  | 28.7 | % |  | 20.6 | % |  | 25.4 | % |
| Operating income - GAAP |  | $ | 295,082 |  |  | $ | 32,144 |  |  | $ | 1,148,125 |  |  | $ | 276,495 |  |
| Share-based compensation expense |  | 21,305 |  |  | 14,569 |  |  | 86,019 |  |  | 54,870 |  |
| Amortization of intangible assets and acquisition-related costs |  | 8,707 |  |  | 8,958 |  |  | 32,393 |  |  | 32,348 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | 23,247 |  |  | 5,716 |  |  | 23,247 |  |
| Restructuring charges (credits), net |  | — |  |  | 74 |  |  | (54) |  |  | 144 |  |
| Operating income - Non - GAAP |  | $ | 325,094 |  |  | $ | 78,992 |  |  | $ | 1,272,199 |  |  | $ | 387,104 |  |
| % of net sales - GAAP |  | 19.2 | % |  | 4.5 | % |  | 21.9 | % |  | 9.3 | % |
| % of net sales - Non - GAAP |  | 21.2 | % |  | 11.1 | % |  | 24.2 | % |  | 13.0 | % |
| Net income - GAAP |  | $ | 225,747 |  |  | $ | 213,920 |  |  | $ | 947,257 |  |  | $ | 449,723 |  |
| Share-based compensation expense |  | 21,305 |  |  | 14,569 |  |  | 86,019 |  |  | 54,870 |  |
| Amortization of intangible assets and acquisition-related costs |  | 8,707 |  |  | 8,958 |  |  | 32,393 |  |  | 32,348 |  |
| Change in fair value of contingent consideration for business acquisition |  | — |  |  | 23,247 |  |  | 5,716 |  |  | 23,247 |  |
| Restructuring charges (credits), net |  | — |  |  | 74 |  |  | (54) |  |  | 144 |  |
| Loss (gain) on investments |  | 1,218 |  |  | (39,783) |  |  | 5,910 |  |  | (39,011) |  |
| Non-GAAP income tax adjustment |  | (5,776) |  |  | (150,048) |  |  | 25,788 |  |  | (156,524) |  |
| Net income - Non - GAAP |  | $ | 251,201 |  |  | $ | 70,937 |  |  | $ | 1,103,029 |  |  | $ | 364,797 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 1.31 |  |  | $ | 1.26 |  |  | $ | 5.51 |  |  | $ | 2.66 |  |
| Diluted - Non - GAAP |  | $ | 1.45 |  |  | $ | 0.42 |  |  | $ | 6.42 |  |  | $ | 2.15 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non - GAAP |  | 172,954 |  |  | 169,981 |  |  | 171,775 |  |  | 169,381 |  |

[0001032975-21-000012:8k_2_02:49]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| SHARE-BASED COMPENSATION EXPENSE |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 1,519 |  |  | $ | 1,300 |  |  | $ | 6,438 |  |  | $ | 4,852 |  |
| Marketing and selling |  | 9,229 |  |  | 6,819 |  |  | 36,788 |  |  | 26,835 |  |
| Research and development |  | 3,831 |  |  | 2,629 |  |  | 14,179 |  |  | 9,273 |  |
| General and administrative |  | 6,726 |  |  | 3,821 |  |  | 28,614 |  |  | 13,910 |  |
| Total share-based compensation expense |  | 21,305 |  |  | 14,569 |  |  | 86,019 |  |  | 54,870 |  |
| Income tax benefit |  | (3,932) |  |  | (1,451) |  |  | (19,472) |  |  | (14,109) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 17,373 |  |  | $ | 13,118 |  |  | $ | 66,547 |  |  | $ | 40,761 |  |

[0001032975-21-000012:8k_2_02:50]
*Note: These preliminary results for the three months and fiscal year ended March 31, 2021 are subject to adjustments, including subsequent events that may occur through the date of filing our Annual Report on Form 10-K.

[0001032975-21-000012:8k_2_02:51]
(A) Non-GAAP Financial Measures

[0001032975-21-000012:8k_2_02:52]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-21-000012:8k_2_02:53]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended March 31, 2021 and previous periods, we excluded items in the following general categories, each of which are described below:

[0001032975-21-000012:8k_2_02:54]
Share-based compensation expense. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-21-000012:8k_2_02:55]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit, operating expenses, and financial results from period to period.

[0001032975-21-000012:8k_2_02:56]
Acquisition-related costs and change in fair value of contingent consideration for business acquisition.  We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition related costs include all incremental expenses incurred to effect a business combination. Fair value of contingent consideration is associated with our estimates of the value of earn-outs in connection with certain acquisitions. We believe that providing the non-GAAP

[0001032975-21-000012:8k_2_02:57]
measures excluding these costs and credits, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-21-000012:8k_2_02:58]
Restructuring charges (credits). These expenses are associated with re-aligning our business strategies based on current economic conditions. We have undertaken several restructuring plans in recent years. In connection with our restructuring initiatives, we incurred restructuring charges related to employee terminations, facility closures and early cancellation of certain contracts. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results in the current period.

[0001032975-21-000012:8k_2_02:59]
Loss (gain) on investments. We recognize losses (gains) related to our investments in various companies, which vary depending on the operational and financial performance of the companies in which we invest.  These amounts include our losses (earnings) on equity method investments, investment impairments and losses (gains) resulting from sales or other events related to our investments. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such losses (gains) are not reflective of our ongoing operations.

[0001032975-21-000012:8k_2_02:60]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above and other events; the determination of which is based upon the nature of the underlying items, the mix of income and losses in jurisdictions and the relevant tax rates in which we operate.

[0001032975-21-000012:8k_2_02:61]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-21-000012:8k_2_02:62]
Additional Supplemental Financial Information - Constant Currency

[0001032975-21-000012:8k_2_02:63]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.
