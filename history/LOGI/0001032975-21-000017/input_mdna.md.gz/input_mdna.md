# LOGI MD&A — 0001032975-21-000017


## mdna

[0001032975-21-000017:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001032975-21-000017:mdna:2]
Overview of Our Company

[0001032975-21-000017:mdna:3]
Logitech is a world leader in designing, manufacturing and marketing products that help connect people to digital and cloud experiences. Almost 40 years ago, Logitech created products to improve experiences around the personal computer (PC) platform, and today it is a multi-brand, multi-category company designing products that enable people to pursue their passions and connect to the world. Logitech’s products align with several large secular trends including work and learn from anywhere, video everywhere, the increasing popularity of gaming as a spectator and participant sport, and the democratization of content creation. Logitech's brands include Logitech, Logitech G, ASTRO Gaming, Streamlabs, Blue Microphones, Ultimate Ears, and Jaybird. Our Company's website is www.logitech.com.

[0001032975-21-000017:mdna:4]
Our products participate in five large market opportunities: Creativity & Productivity, Gaming, Video Collaboration, Music and Smart Home. We sell our products to a broad network of domestic and international customers, including direct sales to retailers and e-tailers, and indirect sales through distributors. Our worldwide channel network includes consumer electronics distributors, retailers, mass merchandisers, specialty stores, computer and telecommunications stores, value-added resellers and online merchants. We sell our services directly to end customers in majority.

[0001032975-21-000017:mdna:5]
From time to time, we may seek to partner with or acquire, when appropriate, companies that have products, personnel, and technologies that complement our strategic direction. We continually review our product offerings and our strategic direction in light of our profitability targets, competitive conditions, changing consumer trends and the evolving nature of the interface between the consumer and the digital world.

[0001032975-21-000017:mdna:6]
On February 17, 2021, we acquired all equity interests of Mevo Inc. (Mevo) for a total upfront cash consideration of $33.2 million, which included a working capital adjustment, plus additional contingent consideration of up to $17.0 million payable in cash only upon the achievement of certain net revenues for the period beginning on December 26, 2020 and ending on December 31, 2021 (the Mevo Acquisition). The Mevo Acquisition is complementary to the Company's PC Webcams portfolio and will better enable us to offer end-to-end solutions for streaming and content creation.

[0001032975-21-000017:mdna:7]
On October 31, 2019, the Company acquired all equity interests in General Workings, Inc. (Streamlabs) for a total consideration of $105.7 million, which included a working capital adjustment, plus additional contingent consideration of $29.0 million payable in stock only upon the achievement of certain net revenues for the period beginning on January 1, 2020 and ending on June 30, 2020 (the Streamlabs Acquisition). Streamlabs is a leading provider of software and tools for professional streamers. The Streamlabs Acquisition is complementary to the Company's Gaming portfolio.

[0001032975-21-000017:mdna:8]
Impacts of COVID-19 to Our Business

[0001032975-21-000017:mdna:9]
In March 2020, the World Health Organization declared the outbreak of a novel coronavirus (COVID-19) as a pandemic, which continues to spread throughout the world. The spread of COVID-19 has caused public health officials to recommend precautions to mitigate the spread of the virus and, in certain markets in which we operate, government authorities have from time to time issued orders that require the closure of or restrictions on non-essential businesses and people to be quarantined or to shelter-at-home. The COVID-19 pandemic has curtailed global economic activity, caused volatility and disruption in global financial and commercial markets, and is likely to continue to cause uncertainty for an indeterminate amount of time. We are conducting our business with substantial modifications, such as employee remote work in non-manufacturing facilities and travel limitations, among other changes. We are continuing to actively monitor the situation and may take further actions that alter our business operations as may be required by federal, state or local authorities in the countries in which we operate, or that we determine are in the best interest of our employees, customers, partners, suppliers or shareholders.

[0001032975-21-000017:mdna:10]
In fiscal year 2021, we experienced disruptions to our supply chain and logistics services, inventory constraints, and increased logistics costs, as we attempted to address the effects of COVID-19.  At the same time, due to the shelter-at-home requirements or other restrictions in many countries, there has been acceleration of work-from-anywhere, study-from-anywhere, gaming, video collaboration and streaming trends and high demand and consumption of certain of our products that have led to increased sales and operating income. While it is not yet clear how long the positive demand dynamics will continue, we expect the increased logistics costs to continue through fiscal year 2022. In addition, if the positive demand does not continue during fiscal year 2022, it may lead to higher promotions, or excess inventories, or both, which will have an adverse impact on our results of operations. It is difficult to predict the progression, the duration and all of the effects of COVID-19, when business restrictions and shelter-at-home guidelines may be eased or lifted on a global basis, and how consumer demand, inventory and logistical effects and costs may evolve over time, or the impact on our future sales and results of operations. The full extent of the impact of COVID-19 on our business and our operational and financial performance is currently uncertain and will depend on many factors outside our control. For additional information, see "Liquidity and Capital Resources" below and Item 1A "Risk Factors," including under the caption "The full effect of the COVID-19 pandemic is still uncertain and cannot be predicted, and it could adversely affect the Company's business, results of operations and financial condition."

[0001032975-21-000017:mdna:11]
Summary of Financial Results

[0001032975-21-000017:mdna:12]
Our total sales for fiscal year 2021 increased 76% in comparison to fiscal year 2020, due to stronger sales across all regions and most of our product categories from increased remote work and learning trends, accelerated adoption of video communications, and greater gaming viewership, creation, and participation from home, as a result of COVID-19. Our consolidated statements of operations for fiscal year 2021 include the results of operations for current year acquisitions from their respective dates of acquisition.

[0001032975-21-000017:mdna:13]
Sales for fiscal year 2021 increased 72%, 84% and 75% in the Americas, EMEA and Asia Pacific, respectively, in comparison to fiscal year 2020.

[0001032975-21-000017:mdna:14]
Gross margin increased by 680 basis points to 44.5% during fiscal year 2021, compared to fiscal year 2020. Our gross margin benefited from higher sales volume, restrained promotional spending, and favorable product mix, which more than offset higher logistics costs to meet strong demand.

[0001032975-21-000017:mdna:15]
Operating expenses for fiscal year 2021 were $1,187.6 million, or 22.6% of sales, compared to $845.9 million, or 28.4% of sales, for fiscal year 2020. The increase in operating expenses was primarily driven by $185.6 million higher personnel-related costs due to additional headcount across departments to support business growth and from business acquisitions, $135.1 million higher third-party costs to support our long-term growth opportunities and branding development, and a $30 million contribution into a charitable donor advised fund to support our social giving strategies. These increases were partially offset by a $17.5 million decrease in the change in fair value of contingent consideration due to the Streamlabs earn-out recorded in fiscal year 2020 and settled in fiscal year 2021.

[0001032975-21-000017:mdna:16]
Included in the income tax provision of $200.9 million in fiscal year 2021 was $152.6 million of tax expense from Switzerland that reflects the post enactment of TRAF in the canton of Vaud. TRAF was enacted in the fourth quarter of fiscal year 2020 and took effect as of January 1, 2020. The income tax benefit of $125.4 million in fiscal year 2020 was impacted by a tax benefit of $153.2 million related to the measurement of deferred tax assets and liabilities, net of assessment of uncertain tax positions in Switzerland as a result of the enactment of TRAF.

[0001032975-21-000017:mdna:17]
Net income for fiscal year 2021 was $947.3 million, compared to $449.7 million for fiscal year 2020.

[0001032975-21-000017:mdna:18]
Trends in Our Business

[0001032975-21-000017:mdna:19]
Our products participate in five large multi-category market opportunities, including Creativity & Productivity, Gaming, Video Collaboration, Music and Smart Home. The following discussion represents key trends specific to our market opportunities.

[0001032975-21-000017:mdna:20]
Trends Specific to Our Five Market Opportunities

[0001032975-21-000017:mdna:21]
Creativity & Productivity: New PC shipments have continued to be strong recently due to work-from-home and learn-from-home trends. We believe that innovative PC peripherals, such as our mice and keyboards, can renew the PC usage experience and help improve the productivity and engagement of remote work, and learning, thus providing growth opportunities. Hybrid work culture will also greatly expand the number of new workspaces to which we can attach our PC peripherals. Increasing adoption of various cloud-based applications has led to multiple unique consumer use cases, which we are addressing with our innovative product portfolio and a deep

[0001032975-21-000017:mdna:22]
understanding of our customer base. The increasing popularity of streaming and broadcasting, as well as the rising work-from-home trend, provides additional growth opportunities for our webcam products as well as other products in our portfolio. Smaller mobile computing devices, such as tablets, have created new markets and usage models for peripherals and accessories. We offer a number of products to enhance the use of mobile devices, including a combo backlit keyboard case with trackpad for the iPad. Hybrid and remote learning environments have also created demand and growth opportunities in the education market for tablet keyboards and accessories.

[0001032975-21-000017:mdna:23]
Gaming: The PC gaming and console gaming platforms continue to show strong structural growth opportunities as online gaming, multi-platform experiences, and esports gain greater popularity and gaming content becomes increasingly more demanding and social, particularly as other recreational activities have been curtailed or restricted during shelter-at-home mandates. We believe gaming will increasingly become one of the largest participant and spectator sports in the world. The new console refresh cycle during the holiday season of 2020 could drive subsequent growth opportunities over the coming years for our ASTRO family of headsets and controllers. We believe Logitech is well positioned to benefit from the overall gaming market growth. Our acquisition of Streamlabs provides a solid platform to deliver recurring services and subscriptions to gamers.

[0001032975-21-000017:mdna:24]
Video Collaboration: The near and long-term structural growth opportunities in the video collaboration market (VC) have never been more relevant than in today’s environment, as commercial and consumer adoption of video has seen explosive growth since the start of the COVID-19 pandemic. Video meetings continue to be on the rise, and companies increasingly want lower-cost, cloud-based solutions that can provide their employees with the ability to work from anywhere. We are continuing our efforts to create and sell innovative products to accommodate the increasing demand from home offices and small-size meeting rooms, such as huddle rooms, to medium and large-sized meeting rooms. We are also experiencing significant demand for our enterprise-grade VC webcams and headsets. We will continue to invest in select business-specific products (both hardware and software), targeted product marketing and sales channel development.

[0001032975-21-000017:mdna:25]
Music: Consumers are optimizing their audio experiences on their tablets and smartphones with a variety of music peripherals including wireless mobile speakers and in-ear and other headphones. However, the mobile speaker market has matured and the integration of personal voice assistants has increased competition in the speaker category. In addition, the retail footprint in fiscal year 2021 decreased significantly due to the COVID-19 pandemic. These factors have led to a decline in our Mobile Speakers category sales in the past three years. In the wireless headphone industry, the largest growth in recent years has been in true wireless headphones while traditional wireless headphones have declined significantly. Continued growth in the wireless headphone market is expected for the next several years as consumers increasingly adopt wireless headphones over wired headphones. In addition, Blue Microphones has experienced strong demand as musicians, performers and streamers increasingly look to entertain and engage with their fans on various online platforms like YouTube, Twitch, and Facebook.

[0001032975-21-000017:mdna:26]
Smart Home: Our Harmony universal remote and Circle security family of products declined substantially in fiscal year 2021. In general, our Harmony and Circle products are under pressure as the way people consume content is changing and as retail stores have been closed or subject to restrictions. The smart home market opportunity is broad, and we will continue to explore other innovative experiences to drive growth in the Smart Home category.

[0001032975-21-000017:mdna:27]
Business Seasonality and Product Introductions

[0001032975-21-000017:mdna:28]
We have historically experienced higher sales in our third fiscal quarter ending December 31, compared to other fiscal quarters in our fiscal year, primarily due to the increased consumer demand for our products during the year-end holiday buying season and year-end spending by enterprises. Due to the fluctuation in the number of cases from the COVID-19 pandemic across the world and related local restrictions, and shelter-at-home requirements, as applicable, we experienced an even higher demand and consumption of most of our products in the third fiscal quarter of 2021. Additionally, new product introductions and business acquisitions can significantly impact sales, product costs and operating expenses. Product introductions can also impact our sales to distribution channels as these channels are filled with new product inventory following a product introduction, and often channel inventory of an earlier model product declines as the next related major product launch approaches. Sales can also be affected when consumers and distributors anticipate a product introduction or changes in business circumstances. However, neither historical seasonal patterns nor historical patterns of product introductions should be considered reliable indicators of our future pattern of product introductions, future sales or financial performance. Furthermore, cash flow is correspondingly lower as we typically build inventories in advance for the third quarter and we pay an annual dividend following our Annual General Meeting, which is typically in September.

[0001032975-21-000017:mdna:29]
Swiss Federal Tax Reform

[0001032975-21-000017:mdna:30]
As we described above, the canton of Vaud in Switzerland enacted TRAF on March 10, 2020 that took effect as of January 1, 2020. Our cash tax payments have increased in Switzerland beginning with fiscal year 2020 tax filing as a result of our transition out of our longstanding tax ruling from the canton of Vaud.

[0001032975-21-000017:mdna:31]
Critical Accounting Estimates

[0001032975-21-000017:mdna:32]
The preparation of financial statements and related disclosures in conformity with U.S. GAAP requires us to make judgments, estimates, and assumptions that affect reported amounts of assets, liabilities, sales and expenses, and the disclosure of contingent assets and liabilities.

[0001032975-21-000017:mdna:33]
We consider an accounting estimate critical if it: (i) requires management to make judgments and estimates about matters that are inherently uncertain; and (ii) is important to an understanding of our financial condition and operating results.

[0001032975-21-000017:mdna:34]
We base our estimates on historical experience and on various other assumptions we believe to be reasonable under the circumstances. Although these estimates are based on management's best knowledge of current events and actions that may impact us in the future, actual results could differ from those estimates. Management has discussed the development, selection and disclosure of these critical accounting estimates with the Audit Committee of the Board of Directors.

[0001032975-21-000017:mdna:35]
We believe the following accounting estimates are most critical to our business operations and to an understanding of our financial condition and results of operations and reflect the more significant judgments and estimates used in the preparation of our consolidated financial statements.

[0001032975-21-000017:mdna:36]
Accruals for Customer Programs and Product Returns

[0001032975-21-000017:mdna:37]
We record accruals for cooperative marketing, customer incentive, pricing programs (Customer Programs) and product returns. The estimated cost of these programs is usually recorded as a reduction of revenue. Significant management judgments and estimates must be used to determine the cost of these programs in any accounting period. Customer Programs require management to estimate the percentage of those programs that will not be claimed in the current period or will not be earned by customers, which is commonly referred to as "breakage." Breakage is estimated based on historical claim experience, the period in which the claims are expected to be submitted, specific terms and conditions with customers, and other factors. If we receive a separately identifiable benefit from a customer and can reasonably estimate the fair value of that benefit, the cost of the Customer Programs is recognized in operating expenses.

[0001032975-21-000017:mdna:38]
Customer Incentive Programs.    Customer incentive programs include performance-based incentives and consumer rebates. We offer performance-based incentives to our customers and indirect partners based on pre-determined performance criteria. Consumer rebates are offered from time to time at our discretion for the primary benefit of end-users. Customer incentive programs are considered variable consideration, which we estimate and record as a reduction to revenue at the time of sale based on negotiated terms, historical experiences, forecasted incentives, the anticipated volume of future purchases, and inventory levels in the channel.

[0001032975-21-000017:mdna:39]
Product Returns.    We grant limited rights to return products. Return rights vary by customer and range from just the right to return the defective product to stock rotation rights limited to a percentage of sales approved by management. Estimates of expected future product returns are recognized at the time of sale based on analyses of historical return trends by the customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information. Upon recognition, we reduce sales and cost of goods sold for the estimated return. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time but are sufficiently predictable to allow us to estimate expected future product returns.

[0001032975-21-000017:mdna:40]
We apply a breakage rate to reduce our accruals of Customer Programs based on the estimated percentage of these customer programs that will not be claimed or earned. The breakage rate is applied at the time of sale. Assessing the period in which claims are expected to be submitted and the relevance of the historical claim experience require significant management judgment to estimate the breakage of Customer Programs in any accounting period.

[0001032975-21-000017:mdna:41]
We regularly evaluate the adequacy of our accruals for Customer Programs and product returns. Future market conditions and product transitions may require us to take action to increase such programs. In addition, when the variables used to estimate these costs change, or if actual costs differ significantly from the estimates, we would be required to record incremental increases or reductions to revenue or operating expenses.

[0001032975-21-000017:mdna:42]
Inventory Valuation

[0001032975-21-000017:mdna:43]
We must order components for our products and build inventory in advance of customer orders. Further, our industry is characterized by rapid technological change, short-term customer commitments and rapid changes in demand.

[0001032975-21-000017:mdna:44]
We record inventories at the lower of cost and net realizable value and record write-downs of inventories that are obsolete or in excess of anticipated demand or net realizable value. A review of inventory is performed each fiscal quarter that considers factors including the marketability and product lifecycle stage, product development plans, component cost trends, historical sales, and demand forecasts that consider the assumptions about future demand and market conditions. Inventory on hand that is not expected to be sold or utilized is considered excess, and we recognize the write-down in the cost of goods sold at the time of such determination. The write-down is determined by the excess of cost over net realizable value. Net realizable value is the estimated selling price in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. At the time of loss recognition, new cost basis per unit and the lower-cost basis for that inventory are established and subsequent changes in facts and circumstances would not result in an increase in the cost basis. If there is an abrupt and substantial decline in demand for Logitech's products or an unanticipated change in technological or customer requirements, we may be required to record additional write-downs that could adversely affect gross margins in the period when the write-downs are recorded. We also extend the assessment to non-cancelable purchase orders if the inventories are considered excess and record the liability that is reasonably possible to be incurred in accrued and other liabilities.

[0001032975-21-000017:mdna:45]
Accounting for Income Taxes

[0001032975-21-000017:mdna:46]
We operate in multiple jurisdictions and our profits are taxed pursuant to the tax laws of these jurisdictions. Our effective income tax rate may be affected by the changes in or interpretations of tax laws and tax agreements in any given jurisdiction, utilization of net operating loss and tax credit carryforwards, changes in geographical mix of income and expense, and changes in our assessment of matters such as the ability to realize deferred tax assets. As a result of these considerations, we must estimate income taxes in each of the jurisdictions in which we operate. This process involves estimating current tax exposure together with assessing temporary differences resulting from the different treatment of items for tax and accounting purposes. These differences result in deferred tax assets and liabilities, which are included in the consolidated balance sheet.

[0001032975-21-000017:mdna:47]
We assess the likelihood that our deferred tax assets will be recovered from future taxable income, considering all available evidence such as historical levels of income, expectations and risks associated with estimates of future taxable income and ongoing prudent and feasible tax strategies. When we determine that it is not more likely than not that we will realize all or part of our deferred tax assets, an adjustment is charged to earnings in the period when such determination is made. Likewise, if we later determine that it is more likely than not that all or a part of our deferred tax assets would be realized, the previously provided valuation allowance would be reversed.

[0001032975-21-000017:mdna:48]
We make certain estimates and judgments about the application of tax laws, the expected resolution of uncertain tax positions and other matters surrounding the recognition and measurement of uncertain tax benefits. In the event that uncertain tax positions are resolved for amounts different than our estimates, or the related statutes of limitations expire without the assessment of additional income taxes, we will be required to adjust the amounts of the related assets and liabilities in the period in which such events occur. Such adjustments may have a material impact on our income tax provision and our results of operations.

[0001032975-21-000017:mdna:49]
Business Acquisitions

[0001032975-21-000017:mdna:50]
Accounting for business acquisitions requires us to make significant estimates and assumptions, especially at the acquisition date with respect to tangible and intangible assets acquired and liabilities assumed and pre-acquisition contingencies. We use our best estimates and assumptions to accurately assign fair value to the tangible and intangible assets acquired and liabilities assumed at the acquisition date.

[0001032975-21-000017:mdna:51]
Examples of critical estimates in valuing certain intangible assets and goodwill we have acquired and liabilities we have assumed include but are not limited to:

[0001032975-21-000017:mdna:52]
•assumptions regarding royalty rate range and forecasted revenue growth rate;

[0001032975-21-000017:mdna:53]
•assumptions regarding the estimated useful life of the acquired intangibles;

[0001032975-21-000017:mdna:54]
•discount rates;

[0001032975-21-000017:mdna:55]
•projected risk-based net revenues forecast; and

[0001032975-21-000017:mdna:56]
•asset volatility.

[0001032975-21-000017:mdna:57]
Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results.

[0001032975-21-000017:mdna:58]
The economic useful life of the developed technology from the business acquisitions was determined based on the technology cycle related to developed technology of existing products, as well as the cash flows over the forecasted periods.

[0001032975-21-000017:mdna:59]
The economic useful life of the customer relationships from the business acquisitions was determined based on historical customer turnover rates and the industry benchmarks.

[0001032975-21-000017:mdna:60]
The economic useful life of the trademarks and trade names from the business acquisitions was determined based on the expected life of the trade names and the cash flows anticipated over the forecasted periods.

[0001032975-21-000017:mdna:61]
For additional information about our Critical Accounting Estimates, see Note 2—Summary of Significant Accounting Policies in our Notes to our consolidated financial statements below.

[0001032975-21-000017:mdna:62]
Adoption of New Accounting Pronouncements

[0001032975-21-000017:mdna:63]
Refer to Note 2 to the consolidated financial statements included in this Annual Report on Form 10-K for recent accounting pronouncements adopted and to be adopted.

[0001032975-21-000017:mdna:64]
Constant Currency

[0001032975-21-000017:mdna:65]
We refer to our net sales growth rates excluding the impact of currency exchange rate fluctuations as "constant currency" sales growth rates. Percentage of constant currency sales growth is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.

[0001032975-21-000017:mdna:66]
Given our global sales presence and the reporting of our financial results in U.S. Dollars, our financial results could be affected by significant shifts in currency exchange rates. See “Results of Operations” for information on the effect of currency exchange results on our sales. If the U.S. Dollar appreciates or depreciates in comparison to other currencies in future periods, this will affect our results of operations in future periods as well.

[0001032975-21-000017:mdna:67]
Reference to Sales

[0001032975-21-000017:mdna:68]
The term “sales” means net sales, except as otherwise specified and the sales growth discussion and sales growth rate percentages are in U.S. Dollars, except as otherwise specified.

[0001032975-21-000017:mdna:69]
Results of Operations

[0001032975-21-000017:mdna:70]
In this section, we discuss the results of our operations for the year ended March 31, 2021 compared to the year ended March 31, 2020.  For a discussion of the year ended March 31, 2020 compared to the year ended March 31, 2019, please refer to Part II, Item 7, "Management's Discussion and Analysis of Financial Condition and Results of Operations" in our Annual Report on Form 10-K filed with the SEC on May 27, 2020.

[0001032975-21-000017:mdna:71]
Net Sales

[0001032975-21-000017:mdna:72]
During fiscal year 2021, sales increased 76% in comparison to fiscal year 2020. If currency exchange rates had been constant in 2021 and 2020, our constant currency sales growth rate would have been 74%. The increase in sales was across all regions, and benefited most of our product categories due to increased work-from-home and learning-from-home trends, as a result of various shelter-at-home mandates. Strong sales growth in Video Collaboration, Gaming, PC Webcams, Tablet and Other Accessories, Keyboards & Combos, Audio & Wearables, and Pointing Devices was partially offset by a decline in sales of Mobile Speakers and Smart Home.  The decline in sales of Mobile Speakers was primarily due to limited outdoor activities and social gatherings.

[0001032975-21-000017:mdna:73]
Sales Denominated in Other Currencies

[0001032975-21-000017:mdna:74]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Yuan, Japanese Yen, Canadian Dollar, Taiwan Dollar, British Pound and Australian Dollar. For each of the fiscal years 2021, and 2020, 52% and 50% of our sales were denominated in currencies other than the U.S. Dollar.

[0001032975-21-000017:mdna:75]
Sales by Region

[0001032975-21-000017:mdna:76]
The following table presents the change in sales by region for fiscal year 2021 compared with fiscal year 2020:

[0001032975-21-000017:mdna:77]
|  |  | 2021 vs. 2020 |  |  |
|  |  | Sales Growth Rate |  | Sales Growth Rate in Constant Currency |  |  |  |  |
| Americas |  | 72 | % |  | 73 | % |  |  |  |  |
| EMEA |  | 84 |  |  | 77 |  |  |  |  |  |
| Asia Pacific |  | 75 |  |  | 72 |  |  |  |  |  |

[0001032975-21-000017:mdna:78]
The increase in sales globally in fiscal year 2021 compared with fiscal year 2020 was driven by growth in sales across a majority of our product categories, partially offset by a decline in sales of Mobile Speakers and Smart Home.

[0001032975-21-000017:mdna:79]
Sales by Product Categories

[0001032975-21-000017:mdna:80]
Sales by product categories for fiscal years 2021 and 2020 were as follows (Dollars in thousands):

[0001032975-21-000017:mdna:81]
|  |  | Years Ended March 31, |  | Change |
|  |  | 2021 |  | 2020 |  | 2021 vs. 2020 |
| Pointing Devices |  | $ | 680,907 |  |  | $ | 544,519 |  |  | 25 | % |
| Keyboards & Combos |  | 784,488 |  |  | 571,720 |  |  | 37 |  |
| PC Webcams |  | 439,865 |  |  | 129,193 |  |  | 240 |  |
| Tablet & Other Accessories |  | 384,301 |  |  | 135,309 |  |  | 184 |  |
| Gaming (1) |  | 1,239,005 |  |  | 690,174 |  |  | 80 |  |
| Video Collaboration |  | 1,044,935 |  |  | 365,616 |  |  | 186 |  |
| Mobile Speakers |  | 174,895 |  |  | 221,791 |  |  | (21) |  |
| Audio & Wearables |  | 468,776 |  |  | 273,752 |  |  | 71 |  |
| Smart Home |  | 34,394 |  |  | 43,404 |  |  | (21) |  |
| Other (2) |  | 713 |  |  | 373 |  |  | 91 |  |
| Total Sales |  | $ | 5,252,279 |  |  | $ | 2,975,851 |  |  | 76 | % |

[0001032975-21-000017:mdna:82]
(1) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-21-000017:mdna:83]
(2) Other category includes products which we currently intend to phase out, or have already phased out, because they are no longer strategic to our business.

[0001032975-21-000017:mdna:84]
Sales by Product Categories:

[0001032975-21-000017:mdna:85]
Creativity & Productivity market:

[0001032975-21-000017:mdna:86]
Pointing Devices

[0001032975-21-000017:mdna:87]
Our Pointing Devices category comprises PC- and Mac-related mice including trackballs touchpads and presentation tools.

[0001032975-21-000017:mdna:88]
During fiscal year 2021, Pointing Devices sales increased  25%, compared to fiscal year 2020. The increase was primarily driven by higher sales of cordless and trackball mice, as a result of remote working and learning trends, partially offset by a decline in sales of our presentation tools, as most conferences, events, and other large-scale presentations remained prohibited.

[0001032975-21-000017:mdna:89]
Keyboards & Combos

[0001032975-21-000017:mdna:90]
Our Keyboards & Combos category comprises PC keyboards, keyboard/mice combo products, and living room keyboards.

[0001032975-21-000017:mdna:91]
During fiscal year 2021, Keyboards & Combos sales increased 37%, compared to fiscal year 2020. The increase was primarily driven by an increase in sales of our cordless and corded PC keyboards and wireless keyboard/mice combos, partially offset by a decline in sales of our living room keyboard products.

[0001032975-21-000017:mdna:92]
PC Webcams

[0001032975-21-000017:mdna:93]
Our PC Webcams category comprises PC-based webcams targeted primarily at consumers, including streaming cameras.

[0001032975-21-000017:mdna:94]
During fiscal year 2021, PC Webcams sales increased 240%, compared to fiscal year 2020. The increase was seen across all product sub-categories, primarily driven by an increase in sales of our  HD Pro Webcam C920, 1080P PRO Stream Webcam, Webcam C260, and Logitech Streamcam, mostly due to more remote working from home and learning-from-home.

[0001032975-21-000017:mdna:95]
Tablet & Other Accessories

[0001032975-21-000017:mdna:96]
Our Tablet & Other Accessories category primarily comprises keyboards for tablets.

[0001032975-21-000017:mdna:97]
During fiscal year 2021, Tablet & Other Accessories sales increased 184%, compared to fiscal year 2020.  The increase was primarily driven by the sales of our Rugged Folio and Slim Folio Keyboards for the iPad 7th generation, both introduced in the third quarter of fiscal year 2020, and our Powered Wireless Charging 3-in-1 Dock, introduced in the fourth quarter of fiscal year 2020. We have seen strong demand for Tablet keyboards, partly due to schools embracing various technology devices to better educate students in learning-from-home environments.

[0001032975-21-000017:mdna:98]
Gaming market:

[0001032975-21-000017:mdna:99]
Gaming

[0001032975-21-000017:mdna:100]
Our Gaming category comprises gaming mice, keyboards, headsets, gamepads, steering wheels, simulation controllers, console gaming headsets, console gaming controllers, and Streamlabs services.

[0001032975-21-000017:mdna:101]
During fiscal year 2021, Gaming sales increased 80%, compared to fiscal year 2020.  The increase was primarily driven by strong performance in PC gaming, Simulation, and Console Gaming headsets.  The sales in Streamlabs services, our business acquisition in the third quarter of fiscal year 2020, doubled as the streaming industry saw an increase in the amount of hours viewed and streamed. The increase was partially offset by a decline in the sales of our console gaming controllers.

[0001032975-21-000017:mdna:102]
Video Collaboration market:

[0001032975-21-000017:mdna:103]
Video Collaboration

[0001032975-21-000017:mdna:104]
Our Video Collaboration category includes Logitech’s ConferenceCams, which combine affordable enterprise-quality audio and high definition (HD) 1080p video to bring video conferencing to businesses of any size.

[0001032975-21-000017:mdna:105]
During fiscal year 2021, Video Collaboration sales increased 186%, compared to fiscal year 2020. The increase was primarily due to increases in sales of our Rally Ultra-HD Conference Camera, our MeetUp video conference camera, BRIO 4K Pro Webcam, Webcam C930E, and Webcam C925E as video communications become more critical for a more location-flexible workforce.

[0001032975-21-000017:mdna:106]
Music market:

[0001032975-21-000017:mdna:107]
Mobile Speakers

[0001032975-21-000017:mdna:108]
Our Mobile Speakers category is made up entirely of Bluetooth wireless speakers.

[0001032975-21-000017:mdna:109]
During fiscal year 2021, Mobile Speakers sales decreased 21%, compared to fiscal year 2020. The decrease was primarily due to a decline in sales of our MEGABOOM, BOOM 3, BOOM 2, and WONDERBOOM, and MEGABLAST mobile speakers in part due to limited outdoor activities and social gatherings.  The decrease was partially offset by sales of our WONDERBOOM 2 speakers and the introduction of our HYPERBOOM speaker in the fourth quarter of fiscal year 2020.

[0001032975-21-000017:mdna:110]
Audio & Wearables

[0001032975-21-000017:mdna:111]
Our Audio & Wearables category comprises PC speakers, PC headsets, in-ear headphones, premium wireless audio wearables and studio-quality microphones for professionals and consumers.

[0001032975-21-000017:mdna:112]
During fiscal year 2021, Audio & Wearables sales increased 71%, compared to fiscal year 2020. The increase was primarily driven by increases in sales of our corded and cordless headsets and Blue Microphones products, partially offset by decline in sales of our Jaybird and UE Custom products.

[0001032975-21-000017:mdna:113]
Smart Home market:

[0001032975-21-000017:mdna:114]
Smart Home

[0001032975-21-000017:mdna:115]
Our Smart Home category mainly comprises our Harmony line of advanced home entertainment controllers and home security cameras.

[0001032975-21-000017:mdna:116]
During fiscal year 2021, Smart Home sales decreased 21%, compared to fiscal year 2020. The decrease was primarily driven by an overall decline in sales in our Harmony remote products, partially offset by an increase in sales of our Circle View camera.

[0001032975-21-000017:mdna:117]
Gross Profit

[0001032975-21-000017:mdna:118]
Gross profit for fiscal years 2021 and 2020 was as follows (Dollars in thousands):

[0001032975-21-000017:mdna:119]
|  |  | Years Ended March 31, |
|  |  | 2021 |  | 2020 |
| Net sales |  | $ | 5,252,279 |  |  | $ | 2,975,851 |  |
| Gross profit |  | $ | 2,335,735 |  |  | $ | 1,122,381 |  |
| Gross margin |  | 44.5 | % |  | 37.7 | % |

[0001032975-21-000017:mdna:120]
Gross profit consists of sales, less cost of goods sold (which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, royalties, costs of purchasing components from outside suppliers, distribution costs, warranty costs, customer support costs, shipping and handling costs, outside processing costs and write-down of inventories), and amortization of intangible assets.

[0001032975-21-000017:mdna:121]
Gross margin increased by 680 basis points to 44.5% during fiscal year 2021, compared to fiscal year 2020. The increase in gross margin was primarily driven by higher sales volume, restrained promotional spending, favorable product mix, which more than offset the higher logistics operations costs to meet strong demand.

[0001032975-21-000017:mdna:122]
Operating Expenses

[0001032975-21-000017:mdna:123]
Operating expenses for fiscal years 2021 and 2020 were as follows (Dollars in thousands):

[0001032975-21-000017:mdna:124]
|  |  | Years Ended March 31, |
|  |  | 2021 |  | 2020 |  |  |
| Marketing and selling |  | $ | 770,284 |  |  | $ | 533,324 |  |  |  |
| % of sales |  | 14.7 | % |  | 17.9 | % |  |  |
| Research and development |  | 226,023 |  |  | 177,593 |  |  |  |
| % of sales |  | 4.3 | % |  | 6.0 | % |  |  |
| General and administrative |  | 166,577 |  |  | 94,015 |  |  |  |
| % of sales |  | 3.2 | % |  | 3.2 | % |  |  |
| Amortization of intangible assets and acquisition-related costs |  | 19,064 |  |  | 17,563 |  |  |  |
| % of sales |  | 0.4 | % |  | 0.6 | % |  |  |
| Change in fair value of contingent consideration for business acquisition |  | 5,716 |  |  | 23,247 |  |  |  |
| % of sales |  | 0.1 | % |  | 0.8 | % |  |  |
| Restructuring charges (credits), net |  | (54) |  |  | 144 |  |  |  |
| % of sales |  | — | % |  | — | % |  |  |
| Total operating expenses |  | $ | 1,187,610 |  |  | $ | 845,886 |  |  |  |
| % of sales |  | 22.6 | % |  | 28.4 | % |  |  |

[0001032975-21-000017:mdna:125]
The increase in total operating expenses during fiscal year 2021, compared to fiscal year 2020, was mainly due to increases in marketing and selling expenses, research and development expenses, and general and administrative expenses, partially offset by decreases in change in fair value of contingent consideration for business acquisition.

[0001032975-21-000017:mdna:126]
Marketing and Selling

[0001032975-21-000017:mdna:127]
Marketing and selling expenses consist of personnel and related overhead costs, corporate and product marketing, promotions, advertising, trade shows, technical support for customer experiences and facilities costs.

[0001032975-21-000017:mdna:128]
During fiscal year 2021, marketing and selling expenses increased $237.0 million, compared to fiscal year 2020. The higher expenses were primarily related to increases of $120.8 million in third-party costs and $114.2 million in personnel-related costs. The increase in third-party costs is primarily due to increased marketing and advertising spend to support our investment in brand awareness and consideration. The higher personnel spend was driven by increased headcount to support business growth and go-to-market expansion, as well as increased performance-based variable compensation linked to stronger performance, and increased share-based compensation.

[0001032975-21-000017:mdna:129]
Research and Development

[0001032975-21-000017:mdna:130]
Research and development expenses consist of personnel and related overhead costs for contractors and outside consultants, supplies and materials, equipment depreciation and facilities costs, all associated with the design and development of new products and enhancements of existing products.

[0001032975-21-000017:mdna:131]
During fiscal year 2021, research and development expenses increased $48.4 million, compared to fiscal year 2020. The increases were primarily driven by $30.3 million of additional personnel-related costs due to increased headcount to support our investment in innovation and increased performance-based variable compensation linked to stronger performance. Higher third-party costs of $14.3 million also contributed to the growth in research and development expense and were mainly comprised of costs for contractors to support the increased research and development initiatives.

[0001032975-21-000017:mdna:132]
General and Administrative

[0001032975-21-000017:mdna:133]
General and administrative expenses consist primarily of personnel and related overhead, information technology, and facilities costs for the infrastructure functions such as finance, information systems, executives, human resources and legal.

[0001032975-21-000017:mdna:134]
During fiscal year 2021, general and administrative expenses increased $72.6 million, compared to fiscal year 2020. The higher spend was primarily driven by an increase of $41.3 million in personnel-related costs due to increased headcount to support business growth, increased performance-based variable compensation linked to stronger performance, and increased share-based compensation. An additional  $30.0 million of the increase in general and administrative expenses was related to our contribution into a charitable donor advised fund to support our social giving strategies.

[0001032975-21-000017:mdna:135]
Amortization of Intangibles and Acquisition-Related Costs

[0001032975-21-000017:mdna:136]
Amortization of intangibles included in operating expense and acquisition-related costs during fiscal years 2021 and 2020 were as follows (in thousands):

[0001032975-21-000017:mdna:137]
|  |  | Years Ended March 31, |
|  |  | 2021 |  | 2020 |  |  |
| Amortization of intangible assets |  | $ | 18,489 |  |  | $ | 16,073 |  |  |  |
| Acquisition-related costs |  | 575 |  |  | 1,490 |  |  |  |
| Total |  | $ | 19,064 |  |  | $ | 17,563 |  |  |  |

[0001032975-21-000017:mdna:138]
Amortization of intangible assets consists of amortization of acquired intangible assets, including customer relationships and trademarks and trade names. Acquisition-related costs include legal expense, due diligence costs, and other professional costs incurred for business acquisitions.

[0001032975-21-000017:mdna:139]
The increase in amortization of intangible assets and acquisition-related costs from fiscal year 2020 to 2021 was primarily driven by the intangible assets acquired through the Mevo acquisition in the fourth quarter of fiscal year 2021 and a full year of intangibles amortization expense for the Streamlabs Acquisition which occurred in the third quarter of fiscal year 2020.

[0001032975-21-000017:mdna:140]
Change in Fair Value of Contingent Consideration for Business Acquisition

[0001032975-21-000017:mdna:141]
The change in fair value of contingent consideration was $5.7 million for the fiscal year 2021, primarily due to growth in Streamlabs' net sales and the achievement of the net sales targets during the six-month earn-out period ended June 30, 2020.

[0001032975-21-000017:mdna:142]
Interest Income

[0001032975-21-000017:mdna:143]
Interest income for fiscal years 2021 and 2020 was as follows (in thousands):

[0001032975-21-000017:mdna:144]
|  |  | Years Ended March 31, |
|  |  | 2021 |  | 2020 |  |  |
| Interest Income |  | $ | 1,784 |  |  | $ | 9,619 |  |  |  |

[0001032975-21-000017:mdna:145]
We invest in highly liquid instruments with an original maturity of three months or less at the date of purchase, which are classified as cash equivalents. The decrease in interest income for fiscal year 2021 was primarily driven by the decline in interest rates and reduction of cash held in interest bearing accounts.

[0001032975-21-000017:mdna:146]
Other Income (Expense), Net

[0001032975-21-000017:mdna:147]
Other income and expense for fiscal years 2021 and 2020 was as follows (in thousands):

[0001032975-21-000017:mdna:148]
|  |  | Years Ended March 31, |
|  |  | 2021 |  | 2020 |  |  |
| Investment income (loss) related to the deferred compensation plan |  | $ | 5,916 |  |  | $ | (831) |  |  |  |
| Currency exchange loss, net |  | (2,688) |  |  | (909) |  |  |  |
| Gain (Loss) on investments, net |  | (5,910) |  |  | 39,011 |  |  |  |
| Other |  | 893 |  |  | 941 |  |  |  |
| Total |  | $ | (1,789) |  |  | $ | 38,212 |  |  |  |

[0001032975-21-000017:mdna:149]
Investment income (loss) related to the deferred compensation plan for fiscal years 2021 and 2020 represents earnings, gains, and losses on trading investments related to a deferred compensation plan offered by one of our subsidiaries.

[0001032975-21-000017:mdna:150]
Currency exchange loss, net relates to balances denominated in currencies other than the functional currency in our subsidiaries, as well as to the sale of currencies, and to gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses.

[0001032975-21-000017:mdna:151]
Gain (Loss) on investments, net, represents the realized gain (loss) on sales of investment, investment impairment, and unrealized gain (loss) from the fair value change on the available-for-sale securities and equity-method investments during the periods presented. The loss in fiscal year 2021 is mostly due to our portion of loss from our investments which are accounted for as an equity method investment. The increase in fiscal year 2020 was due to the sale of our $5.5 million investment in a privately held company for a gain of $39.8 million.

[0001032975-21-000017:mdna:152]
Provision for (Benefit from) Income Taxes

[0001032975-21-000017:mdna:153]
The provision for (benefit from) income taxes and the effective income tax rate for fiscal years 2021 and 2020 were as follows (Dollars in thousands):

[0001032975-21-000017:mdna:154]
|  |  | Years Ended March 31, |
|  |  | 2021 |  | 2020 |  |  |
| Provision for (benefit from) income taxes |  | $ | 200,863 |  |  | $ | (125,397) |  |  |  |
| Effective income tax rate |  | 17.5 | % |  | (38.7) | % |  |  |

[0001032975-21-000017:mdna:155]
The change in the effective income tax rate between fiscal years 2021 and 2020 was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate and the income tax accounting impact from the enactment of TRAF in the canton of Vaud in Switzerland on March 10, 2020 that took effect as of January 1, 2020.  We have benefited from a longstanding tax ruling from the canton of Vaud through December 31, 2019.      We reached an agreement with the Vaud Tax Administration in fiscal year 2020 that would allow for a tax step-up of goodwill to be amortized over ten years beginning on January 1, 2020 as a transition measure.

[0001032975-21-000017:mdna:156]
The Swiss income tax provision in fiscal year 2021 represents the income tax provision at the full statutory income tax rate of 13.60%.  In fiscal year 2020, we recorded an income tax benefit of $151.7 million, net of unrecognized tax benefits to account for the book and tax basis difference of the step-up upon enactment.  The deferred income tax benefit from other temporary differences resulting from the Swiss tax reform, net of three-month amortization of the tax step-up amounted to $1.5 million. The aggregate deferred income tax impact in fiscal year 2020 as a result of the enactment of TRAF was $153.2 million.  In addition, we recognized excess tax benefits from share-based payments, net of shortfalls of $8.7 million and $6.4 million  in the United States in fiscal years 2021 and 2020, respectively, and recognized income tax benefit from the reversal of uncertain tax positions from the expiration of statutes of limitations in the amount of $4.7 million and $4.0 million in fiscal years 2021 and 2020, respectively.

[0001032975-21-000017:mdna:157]
As of March 31, 2021 and 2020, the total amount of unrecognized tax benefits due to uncertain tax positions was $160.3 million and $140.8 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-21-000017:mdna:158]
As of March 31, 2021 and 2020, we had $59.2 million and $40.8 million, respectively, in non-current income taxes payable, including interest and penalties, related to the Company's income tax liability for uncertain tax positions. We recognized $1.1 million and $2.0 million, in interest and penalties related to unrecognized tax positions in income tax expense during fiscal years 2021 and 2020, respectively. As of March 31, 2021 and 2020, we had $4.9 million and $4.5 million, respectively, of accrued interest and penalties related to uncertain tax positions.

[0001032975-21-000017:mdna:159]
We file Swiss and foreign tax returns. We received final tax assessments in Switzerland through fiscal year 2018. For other foreign jurisdictions such as the United States, we are generally not subject to tax examinations for years prior to fiscal year 2018. We are under examination and have received assessment notices in foreign tax jurisdictions. If the examinations are resolved unfavorably, there is a possibility that they may have a material negative impact on our results of operations.

[0001032975-21-000017:mdna:160]
Liquidity and Capital Resources

[0001032975-21-000017:mdna:161]
Cash Balances, Available Borrowings, and Capital Resources

[0001032975-21-000017:mdna:162]
As of March 31, 2021, we had cash and cash equivalents of $1,750.3 million, compared with $715.6 million as of March 31, 2020. Our cash and cash equivalents consist of bank demand deposits and short-term time deposits, of which 69% is held in Switzerland, 10% is held in Germany, and 8% is held in China (including Hong Kong). We do not expect to incur any material adverse tax impact, except for what has been recognized, or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-21-000017:mdna:163]
As of March 31, 2021, our working capital was $1,477.5 million, compared with working capital of $700.3 million as of March 31, 2020. The increase in working capital over fiscal year 2020 was primarily due to higher balances of cash and cash equivalents, higher accounts receivable (net), higher inventories, and higher other current assets, partially offset by higher accounts payable and higher accrued and other liabilities.

[0001032975-21-000017:mdna:164]
We had several uncommitted, unsecured bank lines of credit aggregating to $143.2 million as of March 31, 2021. There are no financial covenants under these lines of credit with which we must comply. As of March 31, 2021, we had outstanding bank guarantees of $91.3 million under these lines of credit.

[0001032975-21-000017:mdna:165]
The following table presents selected financial information and statistics as of March 31, 2021 and 2020  (Dollars in thousands):

[0001032975-21-000017:mdna:166]
|  |  | March 31, |
|  |  | 2021 |  | 2020 |  |  |
| Accounts receivable, net |  | $ | 612,225 |  |  | $ | 394,743 |  |  |  |
| Accounts payable |  | $ | 823,233 |  |  | $ | 259,120 |  |  |  |
| Inventories |  | $ | 661,116 |  |  | $ | 229,249 |  |  |  |
| Days sales in accounts receivable (DSO)(Days)(1) |  | 36 |  |  | 50 |  |  |  |
| Days accounts payable outstanding (DPO) (Days)(2) |  | 90 |  |  | 54 |  |  |  |
| Inventory turnover (ITO)(x)(3) |  | 5.0 |  |  | 7.5 |  |  |  |

[0001032975-21-000017:mdna:167]
______________________________

[0001032975-21-000017:mdna:168]
(1)DSO is determined using ending accounts receivable, net as of the most recent quarter-end and sales for the most recent quarter.

[0001032975-21-000017:mdna:169]
(2)DPO is determined using ending accounts payable as of the most recent quarter-end and cost of goods sold for the most recent quarter.

[0001032975-21-000017:mdna:170]
(3)ITO is determined using ending inventories and the annualized cost of goods sold (based on cost of goods sold for the most recent quarter).

[0001032975-21-000017:mdna:171]
DSO as of March 31, 2021 decreased by 14 days to 36 days, as compared to 50 days as of March 31, 2020, primarily due to timing of customer payments and sales linearity.

[0001032975-21-000017:mdna:172]
DPO as of March 31, 2021 increased 36 days, compared to March 31, 2020, primarily due to timing of purchases and related payments and an increase in cost of goods sold due to higher sales growth during fiscal year 2021.

[0001032975-21-000017:mdna:173]
ITO as of March 31, 2021 was lower compared to March 31, 2020, primarily due to higher inventory levels to build inventory in anticipation of future sales growth.

[0001032975-21-000017:mdna:174]
If we are not successful in launching and phasing in our new products launched during the current fiscal year, or we are not able to sell the new products at the prices planned, it could have a material impact on our revenue, gross profit margin, operating results including operating cash flow, and inventory turnover in the future.

[0001032975-21-000017:mdna:175]
During fiscal year 2021, we generated $1,458.6 million in cash from operating activities. Our main sources of operating cash flows were from net income, after adding back non-cash expenses of depreciation, amortization, share-based compensation expense, change in fair value of contingent considerations, and from changes in operating assets and liabilities. The increase in accounts receivable, net was primarily driven by growth and timing of sales. The increase in inventories was primarily driven by an increase in inventory purchases, in anticipation of continued high demand for certain of our products. The increase in accounts payable was primarily driven by the timing of purchases and related payments. The increase in accrued and other liabilities was primarily due to higher income tax payable due to stronger performance, an increase in customer, marketing, pricing, and incentive programs, freight and duty due to higher logistic costs, and higher accrued personnel expenses.

[0001032975-21-000017:mdna:176]
Net cash used in investing activities was $120.0 million, primarily due to $43.5 million of the purchase price (net of cash acquired) for business acquisitions and $76.2 million of purchases of property, plant, and equipment.

[0001032975-21-000017:mdna:177]
Net cash used in financing activities was $299.9 million, primarily due to $146.7 million of cash dividends paid during the year, $165.0 million of repurchases of our registered shares and $32.1 million of tax withholdings related to net share settlements of restricted stock units, partially offset by $43.8 million in proceeds received from the sale of shares upon exercise of stock options and purchase rights.

[0001032975-21-000017:mdna:178]
Our expenditures for property, plant and equipment during fiscal year 2021 and 2020 were primarily for tooling and equipment and computer hardware and software. Our expenditures for property, plant and equipment increased during fiscal year 2021, compared to fiscal year 2020, primarily due to higher tooling and equipment.

[0001032975-21-000017:mdna:179]
Our payments for acquisitions, net of cash acquired, during fiscal year 2021 were primarily for the Mevo Acquisition. Our payments for acquisitions, net of cash acquired, during fiscal year 2020 were primarily for the Streamlabs Acquisition (refer to  "Note 3—Business Acquisitions" to the consolidated financial statements).

[0001032975-21-000017:mdna:180]
The purchases and sales of trading investments during fiscal years 2021 and 2020 represent mutual fund activity directed by participants in a deferred compensation plan offered by one of our subsidiaries. The mutual funds are held by a Rabbi Trust.

[0001032975-21-000017:mdna:181]
During fiscal year 2021, there was a $4.0 million loss from currency exchange rate effect on cash and cash equivalents, compared to a loss of $7.1 million from currency exchange rate effect during fiscal year 2020. The loss from the effect of currency rate changes during fiscal year 2021 were primarily due to the weakening of the Japanese yen, Brazilian real, partially offset by the strengthening of the Chinese yuan and Australian dollar versus the U.S. Dollar by 2%, 10%, 8% and 25%, respectively. The loss from the effect of currency exchange rate changes during fiscal year 2020 were primarily due to the weakening of Euro, Brazilian real and Australian dollar versus the U.S. Dollar by 3%, 25%, and 14%, respectively.

[0001032975-21-000017:mdna:182]
Cash Outlook

[0001032975-21-000017:mdna:183]
Our principal sources of liquidity are our cash and cash equivalents, cash flow generated from operations and, to a much lesser extent, capital markets and borrowings. Our future working capital requirements and capital expenditures may increase to support investments in product innovations and growth opportunities or to acquire or invest in complementary businesses, products, services, and technologies. The future impact of COVID-19 cannot be predicted with certainty and may increase our costs of capital and otherwise adversely affect our business, results of operations, financial conditions and liquidity.

[0001032975-21-000017:mdna:184]
In April 2021, the Board of Directors recommended that we pay cash dividends for fiscal year 2021 of CHF 147.0 million ($155.8 million based on the exchange rate on March 31, 2021). In fiscal year 2021, we paid a cash dividend of CHF 134.0 million (U.S. Dollar amount of $146.7 million) out of fiscal year 2020 retained earnings. In fiscal year 2020, we paid a cash dividend of CHF 121.8 million (U.S. Dollar amount of $124.2 million) out of fiscal year 2019 retained earnings. In fiscal year 2019, we paid a cash dividend of CHF 110.7 million (U.S. Dollar amount of $114.0 million) out of fiscal year 2018 retained earnings.

[0001032975-21-000017:mdna:185]
In May 2020, our Board of Directors approved a new share repurchase program, which authorizes us to invest up to $250.0 million to purchase our own shares, following the expiration date of the 2017 share repurchase program. Although we enter into trading plans for systematic repurchases (e.g. 10b5-1 trading plans) from time to time, our share repurchase program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect until July 2023. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.

[0001032975-21-000017:mdna:186]
In April 2021, our Board of Directors approved an increase of $750.0 million of the 2020 share repurchase program, to an aggregate amount of $1.0 billion. This increase is subject to approval by the Swiss Takeover Board.

[0001032975-21-000017:mdna:187]
For over ten years, we have generated positive cash flows from our operating activities, including cash from operations of $1,458.6 million, and $425.0 million during fiscal years 2021 and 2020, respectively. If we do not generate sufficient operating cash flows to support our operations and future planned cash requirements, our operations could be harmed and our access to credit facilities could be restricted or eliminated. However, we believe that the trend of our historical cash flow generation, our projections of future operations and our available cash balances will provide sufficient liquidity to fund our operations for at least the next 12 months.

[0001032975-21-000017:mdna:188]
Our other contractual obligations and commitments that require cash are described in the following sections.

[0001032975-21-000017:mdna:189]
Contractual Obligations and Commitments

[0001032975-21-000017:mdna:190]
Purchase Commitments

[0001032975-21-000017:mdna:191]
As of March 31, 2021, we have non-cancelable purchase commitments of $865.6 million for inventory purchases made in the normal course of business from original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled during the first two quarters of fiscal year 2022. We recorded a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with our valuation of excess and obsolete inventory. As of March 31, 2021, the liability for these purchase commitments was $11.8 million and is recorded in accrued and other current liabilities. We have firm purchase commitments of $24.9 million for capital expenditures, primarily related to commitments for tooling, equipment, and computer hardware. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us the option to reschedule and adjust our requirements based on business needs prior to delivery of goods.

[0001032975-21-000017:mdna:192]
Operating Leases Obligation

[0001032975-21-000017:mdna:193]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. The remaining terms of our non-cancelable operating leases expire in various years through 2031. See "Note 17—Leases" to the consolidated financial statements included in this report for more information on leases.

[0001032975-21-000017:mdna:194]
Income Taxes Payable

[0001032975-21-000017:mdna:195]
As of March 31, 2021, we had $59.2 million in non-current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions. At this time, we are unable to make a reasonably reliable estimate of the timing of payments in individual years in connection with these tax liabilities; therefore, such amounts are not included in the contractual obligation table above.

[0001032975-21-000017:mdna:196]
Indemnifications

[0001032975-21-000017:mdna:197]
We indemnify certain of our suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys' fees. As of March 31, 2021, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-21-000017:mdna:198]
We also indemnify our current and former directors and certain of our current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. We are unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not capped, the obligations are conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.
