# LOGI note change history — 0001032975-23-000007 → 0001032975-23-000066


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-07-27):
[0001032975-23-000066:note_history:1]
Changes in the Company’s warranty liabilities for the three months ended June 30, 2023 and 2022 were as follows (in thousands):
  (was, 2023-01-26, similarity 0.9076):
[0001032975-23-000007:note_history:1]
Changes in the Company’s warranty liability for the three and nine months ended December 31, 2022 and 2021 were as follows (in thousands):

- changed (2023-07-27):
[0001032975-23-000066:note_history:2]
|  |  |  | Three months ended June 30, |
|  |  |  |  |  | 2023 |  | 2022 |
| Beginning of the period |  |  |  |  | $ | 40,886 |  |  | $ | 46,219 |  |
| Provision |  |  |  |  | 9,092 |  |  | 6,623 |  |
| Settlements |  |  |  |  | (9,918) |  |  | (8,281) |  |
| Effects of foreign currency translation |  |  |  |  | (175) |  |  | (720) |  |
| End of the period |  |  |  |  | $ | 39,885 |  |  | $ | 43,841 |  |
  (was, 2023-01-26, similarity 0.6713):
[0001032975-23-000007:note_history:2]
|  | Three Months EndedDecember 31, |  | Nine Months EndedDecember 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Beginning of the period | $ | 41,960 |  |  | $ | 49,173 |  |  | $ | 46,219 |  |  | $ | 48,832 |  |
| Provision | 8,920 |  |  | 6,962 |  |  | 23,440 |  |  | 23,503 |  |
| Settlements | (8,979) |  |  | (8,056) |  |  | (26,358) |  |  | (24,219) |  |
| Effects of foreign currency translation | 730 |  |  | (144) |  |  | (670) |  |  | (181) |  |
| End of the period | $ | 42,631 |  |  | $ | 47,935 |  |  | $ | 42,631 |  |  | $ | 47,935 |  |

- changed (2023-07-27):
[0001032975-23-000066:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2023, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2023-01-26, similarity 0.9908):
[0001032975-23-000007:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2022, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

- changed (2023-07-27):
[0001032975-23-000066:note_history:4]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows and results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.
  (was, 2023-01-26, similarity 0.998):
[0001032975-23-000007:note_history:4]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2023-07-27):
[0001032975-23-000066:note_history:5]
Logitech International S.A, together with its consolidated subsidiaries ("Logitech" or the "Company"), designs, manufactures and sells products that help businesses thrive and bring people together when working, creating, gaming and streaming.

- changed (2023-07-27):
[0001032975-23-000066:note_history:6]
The Company sells its products to a broad network of international customers, including direct sales to retailers, e-tailers and end consumers through the Company's e-commerce platform, and indirect sales to end customers through distributors.
  (was, 2023-01-26, similarity 0.689):
[0001032975-23-000007:note_history:6]
The Company sells its products to a broad network of domestic and international customers, including direct sales to retailers, e-tailers and enterprise customers, and indirect sales through distributors.

- changed (2023-07-27):
[0001032975-23-000066:note_history:7]
The condensed consolidated financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States ("U.S. GAAP") for interim financial information and therefore do not include all the information required by U.S. GAAP for complete financial statements. The condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2023, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission ("SEC") on May 17, 2023.
  (was, 2023-01-26, similarity 0.9927):
[0001032975-23-000007:note_history:7]
The condensed consolidated financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") for interim financial information and therefore do not include all the information required by U.S. GAAP for complete financial statements. The condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2022, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission ("SEC") on May 18, 2022.

- changed (2023-07-27):
[0001032975-23-000066:note_history:8]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three months ended June 30, 2023 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2024, or any future periods.
  (was, 2023-01-26, similarity 0.9573):
[0001032975-23-000007:note_history:8]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and nine months ended December 31, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2023, or any future periods.

- added (2023-07-27):
[0001032975-23-000066:note_history:9]
Change in Presentation of Sales by Product Category

- added (2023-07-27):
[0001032975-23-000066:note_history:10]
During the first quarter of fiscal year 2024, the Company changed its presentation of Sales by Product Category, included in Note 12, to provide a simpler and clearer view of the Company's business. The change in presentation did not have an impact on previously reported total sales. These changes included reclassifications of sales between certain product categories resulting in the following:

- added (2023-07-27):
[0001032975-23-000066:note_history:11]
•The Webcams category (previously PC Webcams) now includes PC webcams and VC webcams;

- added (2023-07-27):
[0001032975-23-000066:note_history:12]
•Headsets is a new category which includes PC headsets and VC headsets;

- added (2023-07-27):
[0001032975-23-000066:note_history:13]
•The Mobile Speakers category is no longer a separate category as sales have been reclassified into the Other category;

- added (2023-07-27):
[0001032975-23-000066:note_history:14]
•The Audio & Wearables category is no longer a separate category as sales have been reclassified into other categories as discussed below.

- added (2023-07-27):
[0001032975-23-000066:note_history:15]
As a result of these changes, certain prior-period amounts for the three months ended June 30, 2022 have been reclassified to conform to the current period presentation as follows (in thousands):

- added (2023-07-27):
[0001032975-23-000066:note_history:16]
|  |  | As previously reported |  | Reclassifications |  | As adjusted |
| Gaming |  | $ | 282,806 |  |  | $ | 15,115 |  | (1) | $ | 297,921 |  |
| Keyboards & Combos |  | 227,720 |  |  | — |  |  | 227,720 |  |
| Pointing Devices |  | 183,283 |  |  | — |  |  | 183,283 |  |
| Video Collaboration |  | 246,242 |  |  | (64,610) |  | (2) (3) | 181,632 |  |
| Webcams (3) |  | 59,386 |  |  | 49,876 |  | (3) | 109,262 |  |
| Tablet Accessories |  | 66,585 |  |  | — |  |  | 66,585 |  |
| Headsets |  | — |  |  | 45,943 |  | (2) | 45,943 |  |
| Other |  | 2,087 |  |  | 45,432 |  | (4) (5) | 47,519 |  |
| Mobile Speakers |  | 22,310 |  |  | (22,310) |  | (4) | — |  |
| Audio & Wearables |  | 69,446 |  |  | (69,446) |  | (1) (2) (5) | — |  |
| Total Sales |  | $ | 1,159,865 |  |  | $ | — |  |  | $ | 1,159,865 |  |

- added (2023-07-27):
[0001032975-23-000066:note_history:17]
(1) Reclassification of Blue Microphones from "Audio & Wearables" to the Gaming category.

- added (2023-07-27):
[0001032975-23-000066:note_history:18]
(2) Reclassification of VC headsets and PC headsets to the new Headsets category from "Video Collaboration" and "Audio & Wearables," respectively.

- added (2023-07-27):
[0001032975-23-000066:note_history:19]
(3) The Webcams category includes amounts previously reported as "PC Webcams" as well as amounts from VC webcams reclassified from "Video Collaboration."

- added (2023-07-27):
[0001032975-23-000066:note_history:20]
(4) Reclassification of all amounts previously reported in "Mobile Speakers" to the Other category.

- added (2023-07-27):
[0001032975-23-000066:note_history:21]
(5) Reclassification of PC speakers previously reported in "Audio & Wearables" to the Other category.

- changed (2023-07-27):
[0001032975-23-000066:note_history:22]
There have been no material changes in the Company’s significant accounting policies during the three months ended June 30, 2023 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2023.
  (was, 2023-01-26, similarity 0.7258):
[0001032975-23-000007:note_history:22]
Other than the recent accounting pronouncements adopted and discussed below under Recent Accounting Pronouncements Adopted, there have been no material changes in the Company’s significant accounting policies during the nine months ended December 31, 2022 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2022.

- changed (2023-07-27):
[0001032975-23-000066:note_history:23]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill and intangible assets acquired from business acquisitions, contingent consideration for a business acquisition and periodic reassessment of its fair value, valuation of investment in privately held companies classified under Level 3 fair value hierarchy, pension obligations, accruals for customer incentives, cooperative marketing, and pricing programs and related breakage when appropriate, inventory valuation, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.
  (was, 2023-01-26, similarity 0.9141):
[0001032975-23-000007:note_history:23]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill and intangible assets acquired from business acquisitions, contingent consideration for a business acquisition and periodic reassessment of its fair value, valuation of investment in privately held companies classified under Level 3 fair value hierarchy, pension obligations, accruals for customer incentives, cooperative marketing, and pricing programs and related breakage when appropriate, inventory valuation, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these

- changed (2023-07-27):
[0001032975-23-000066:note_history:24]
Impacts of Macroeconomic and Geopolitical Conditions on the Company's Business
  (was, 2023-01-26, similarity 0.8966):
[0001032975-23-000007:note_history:24]
Impacts of Macroeconomic and Geopolitical Conditions and Other Factors on the Company's Business

- added (2023-07-27):
[0001032975-23-000066:note_history:25]
The Company's business has been impacted by adverse macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, slowdown of economic activity around the world, and lower consumer and enterprise spending. In addition, the war in Ukraine resulted in global supply chain, logistics, and inflationary challenges. The Company has had no revenue in Russia and Ukraine since fiscal year

- added (2023-07-27):
[0001032975-23-000066:note_history:26]
2023 as it has indefinitely ceased all sales and shipments to Russia and sales in Ukraine have also been halted due to the ongoing military operations on the Ukrainian territory.

- added (2023-07-27):
[0001032975-23-000066:note_history:27]
The global and regional economic and political conditions adversely affect demand for the Company's products. These conditions also had an impact on the Company's suppliers, contract manufacturers, logistics providers, and distributors, causing volatility in cost of materials and shipping and transportation rates, and as a result impacting the pricing of the Company's products.

- removed (2023-07-27):
[0001032975-23-000007:note_history:28]
Logitech International S.A, together with its consolidated subsidiaries ("Logitech" or the "Company"), designs, manufactures and markets products that help connect people to digital and cloud experiences. Over forty years ago, Logitech created products to improve experiences around the personal computer ("PC") platform, and today it is a multi-brand, multi-category company designing products that enable better experiences consuming, sharing and creating any digital content such as computing, gaming, video, and music, whether it is on a computer, mobile device or in the cloud.

- removed (2023-07-27):
[0001032975-23-000007:note_history:29]
estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

- removed (2023-07-27):
[0001032975-23-000007:note_history:30]
In March 2020, the World Health Organization declared the outbreak of COVID-19 as a pandemic, which continues to spread throughout the world. The COVID-19 pandemic resulted in industry-wide global supply chain challenges, including manufacturing, transportation and logistics. The Company purchases certain products and key components from a limited number of sources, and depends on the supply chain, including freight, to receive components, transport finished goods and deliver the Company's products across the world.

- removed (2023-07-27):
[0001032975-23-000007:note_history:31]
More recently, the Company has also been impacted by adverse macroeconomic and geopolitical conditions. These conditions include but are not limited to inflation, foreign currency fluctuations, and slowdown of economic activity around the world, in part due to rising interest rates, and lower consumer and enterprise spending. In addition, the war in Ukraine increased global supply chain, logistics, and inflationary challenges. Such global or regional economic and political conditions adversely affect demand for the Company's products. These conditions also have an impact on the Company's suppliers, contract manufacturers, logistics providers, and distributors, causing volatility in cost of materials and shipping and transportation rates, and as a result impacting the pricing of the Company's products. Price increases may not successfully offset cost increases or may cause the Company to lose market share and in turn adversely impact the Company's results of operations.

- removed (2023-07-27):
[0001032975-23-000007:note_history:32]
While global supply chain challenges have improved since the second quarter of fiscal year 2023, including logistics costs and shipping lead times, the increase of COVID-19 infections in China during the third quarter of fiscal year 2023 causes uncertainty in supply availability. If macroeconomic and geopolitical conditions and COVID-19 related factors do not improve or worsen, the Company's results of operations will continue to be adversely impacted.

- removed (2023-07-27):
[0001032975-23-000007:note_history:33]
Recent Accounting Pronouncements Adopted

- removed (2023-07-27):
[0001032975-23-000007:note_history:34]
In October 2021, the Financial Accounting Standard Board issued ASU 2021-08, "Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers" (ASU 2021-08). The update requires an acquirer in a business combination to recognize and measure contract assets and contract liabilities acquired in a business combination in accordance with Accounting Standards Codification ("ASC") 606, Revenue from Contracts with Customers, as if it had originated the contracts. The standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2022. The Company early adopted the standard effective April 1, 2022 and applies the standard prospectively to business combinations that occurred on or after April 1, 2022. The adoption of ASU 2021-08 did not have a material impact on the Company's condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-07-27):
[0001032975-23-000066:note_history:35]
Financing Arrangements The Company had several uncommitted, unsecured bank lines of credit and letters of credit aggregating $172.0 million and $181.3 million as of June 30, 2023 and March 31, 2023, respectively. There are no financial covenants under the lines of credit with which the Company must comply. There was no borrowing outstanding under the lines of credit as of June 30, 2023 or March 31, 2023. As of June 30, 2023 and March 31, 2023, the Company had outstanding bank guarantees of $9.2 million and $13.6 million, respectively.

- removed (2023-07-27):
[0001032975-23-000007:note_history:36]
Financing Arrangements

- removed (2023-07-27):
[0001032975-23-000007:note_history:37]
The Company had several uncommitted, unsecured bank lines of credit aggregating $179.2 million and $195.0 million as of December 31, 2022 and March 31, 2022, respectively. There are no financial covenants under these lines of credit with which the Company must comply. As of December 31, 2022 and March 31, 2022, the Company had outstanding bank guarantees of $11.6 million and $25.5 million, respectively, under these lines of credit. There was no borrowing outstanding under these lines of credit as of December 31, 2022 or March 31, 2022.
