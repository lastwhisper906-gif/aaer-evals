# LOGI notes — 0001032975-23-000066


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-23-000066:notes:1]
[same as prior period, unchanged from 0001032975-23-000007:notes:1]

[0001032975-23-000066:notes:2]
Logitech International S.A, together with its consolidated subsidiaries ("Logitech" or the "Company"), designs, manufactures and sells products that help businesses thrive and bring people together when working, creating, gaming and streaming.

[0001032975-23-000066:notes:3]
The Company sells its products to a broad network of international customers, including direct sales to retailers, e-tailers and end consumers through the Company's e-commerce platform, and indirect sales to end customers through distributors.

[0001032975-23-000066:notes:4]
[same as prior period, unchanged from 0001032975-23-000007:notes:4]

[0001032975-23-000066:notes:5]
[same as prior period, unchanged from 0001032975-23-000007:notes:5]

[0001032975-23-000066:notes:6]
The condensed consolidated financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States ("U.S. GAAP") for interim financial information and therefore do not include all the information required by U.S. GAAP for complete financial statements. The condensed consolidated financial statements should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2023, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission ("SEC") on May 17, 2023.

[0001032975-23-000066:notes:7]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three months ended June 30, 2023 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2024, or any future periods.

[0001032975-23-000066:notes:8]
Change in Presentation of Sales by Product Category

[0001032975-23-000066:notes:9]
During the first quarter of fiscal year 2024, the Company changed its presentation of Sales by Product Category, included in Note 12, to provide a simpler and clearer view of the Company's business. The change in presentation did not have an impact on previously reported total sales. These changes included reclassifications of sales between certain product categories resulting in the following:

[0001032975-23-000066:notes:10]
•The Webcams category (previously PC Webcams) now includes PC webcams and VC webcams;

[0001032975-23-000066:notes:11]
•Headsets is a new category which includes PC headsets and VC headsets;

[0001032975-23-000066:notes:12]
•The Mobile Speakers category is no longer a separate category as sales have been reclassified into the Other category;

[0001032975-23-000066:notes:13]
•The Audio & Wearables category is no longer a separate category as sales have been reclassified into other categories as discussed below.

[0001032975-23-000066:notes:14]
As a result of these changes, certain prior-period amounts for the three months ended June 30, 2022 have been reclassified to conform to the current period presentation as follows (in thousands):

[0001032975-23-000066:notes:15]
|  |  | As previously reported |  | Reclassifications |  | As adjusted |
| Gaming |  | $ | 282,806 |  |  | $ | 15,115 |  | (1) | $ | 297,921 |  |
| Keyboards & Combos |  | 227,720 |  |  | — |  |  | 227,720 |  |
| Pointing Devices |  | 183,283 |  |  | — |  |  | 183,283 |  |
| Video Collaboration |  | 246,242 |  |  | (64,610) |  | (2) (3) | 181,632 |  |
| Webcams (3) |  | 59,386 |  |  | 49,876 |  | (3) | 109,262 |  |
| Tablet Accessories |  | 66,585 |  |  | — |  |  | 66,585 |  |
| Headsets |  | — |  |  | 45,943 |  | (2) | 45,943 |  |
| Other |  | 2,087 |  |  | 45,432 |  | (4) (5) | 47,519 |  |
| Mobile Speakers |  | 22,310 |  |  | (22,310) |  | (4) | — |  |
| Audio & Wearables |  | 69,446 |  |  | (69,446) |  | (1) (2) (5) | — |  |
| Total Sales |  | $ | 1,159,865 |  |  | $ | — |  |  | $ | 1,159,865 |  |

[0001032975-23-000066:notes:16]
(1) Reclassification of Blue Microphones from "Audio & Wearables" to the Gaming category.

[0001032975-23-000066:notes:17]
(2) Reclassification of VC headsets and PC headsets to the new Headsets category from "Video Collaboration" and "Audio & Wearables," respectively.

[0001032975-23-000066:notes:18]
(3) The Webcams category includes amounts previously reported as "PC Webcams" as well as amounts from VC webcams reclassified from "Video Collaboration."

[0001032975-23-000066:notes:19]
(4) Reclassification of all amounts previously reported in "Mobile Speakers" to the Other category.

[0001032975-23-000066:notes:20]
(5) Reclassification of PC speakers previously reported in "Audio & Wearables" to the Other category.

[0001032975-23-000066:notes:21]
[same as prior period, unchanged from 0001032975-23-000007:notes:8]

[0001032975-23-000066:notes:22]
There have been no material changes in the Company’s significant accounting policies during the three months ended June 30, 2023 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2023.

[0001032975-23-000066:notes:23]
[same as prior period, unchanged from 0001032975-23-000007:notes:10]

[0001032975-23-000066:notes:24]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Significant estimates and assumptions made by management involve the fair value of goodwill and intangible assets acquired from business acquisitions, contingent consideration for a business acquisition and periodic reassessment of its fair value, valuation of investment in privately held companies classified under Level 3 fair value hierarchy, pension obligations, accruals for customer incentives, cooperative marketing, and pricing programs and related breakage when appropriate, inventory valuation, share-based compensation expense, uncertain tax positions, and valuation allowances for deferred tax assets. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ materially from those estimates.

[0001032975-23-000066:notes:25]
[same as prior period, unchanged from 0001032975-23-000007:notes:13]

[0001032975-23-000066:notes:26]
Impacts of Macroeconomic and Geopolitical Conditions on the Company's Business

[0001032975-23-000066:notes:27]
The Company's business has been impacted by adverse macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, slowdown of economic activity around the world, and lower consumer and enterprise spending. In addition, the war in Ukraine resulted in global supply chain, logistics, and inflationary challenges. The Company has had no revenue in Russia and Ukraine since fiscal year

[0001032975-23-000066:notes:28]
2023 as it has indefinitely ceased all sales and shipments to Russia and sales in Ukraine have also been halted due to the ongoing military operations on the Ukrainian territory.

[0001032975-23-000066:notes:29]
The global and regional economic and political conditions adversely affect demand for the Company's products. These conditions also had an impact on the Company's suppliers, contract manufacturers, logistics providers, and distributors, causing volatility in cost of materials and shipping and transportation rates, and as a result impacting the pricing of the Company's products.


## us-gaap:EarningsPerShareTextBlock

[0001032975-23-000066:notes:30]
[same as prior period, unchanged from 0001032975-23-000007:notes:20]

[0001032975-23-000066:notes:31]
The following table summarizes the computations of basic and diluted net income per share for the three months ended June 30, 2023 and 2022 (in thousands, except per share amounts):

[0001032975-23-000066:notes:32]
|  |  |  |  | Three months ended June 30, |
|  |  |  |  |  |  | 2023 |  | 2022 |
| Net income |  |  |  |  |  | $ | 62,727 |  |  | $ | 100,836 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  |  |  |  |  | 158,859 |  |  | 164,679 |  |
| Effect of potentially dilutive equivalent shares |  |  |  |  |  | 1,296 |  |  | 1,727 |  |
| Weighted average shares outstanding - diluted |  |  |  |  |  | 160,155 |  |  | 166,406 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  |  |  |  |  | $ | 0.39 |  |  | $ | 0.61 |  |
| Diluted |  |  |  |  |  | $ | 0.39 |  |  | $ | 0.61 |  |

[0001032975-23-000066:notes:33]
Share equivalents attributable to outstanding stock options, restricted stock units and employee share purchase plans totaling 2.0 million and 3.4 million for the three months ended June 30, 2023 and 2022, respectively, were excluded from the calculation of diluted net income per share because their effect would have been anti-dilutive. A small number of performance-based restricted stock units were not included in the dilutive net income per share calculation because all necessary conditions had not been satisfied by the end of the respective period, and those shares were not issuable if the end of the reporting period were the end of the performance contingency period.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-23-000066:notes:34]
[same as prior period, unchanged from 0001032975-23-000007:notes:24]

[0001032975-23-000066:notes:35]
[same as prior period, unchanged from 0001032975-23-000007:notes:25]

[0001032975-23-000066:notes:36]
As of June 30, 2023, the Company offers the 2006 Employee Share Purchase Plan (Non-U.S.), as amended and restated ("2006 ESPP"), the 1996 Employee Share Purchase Plan (U.S.), as amended and restated ("1996 ESPP"), and the 2006 Stock Incentive Plan ("2006 Plan") as amended and restated. Shares issued to employees as a result of purchases or exercises under these plans are generally issued from shares held in treasury stock.

[0001032975-23-000066:notes:37]
The following table summarizes the share-based compensation expense and total income tax benefit recognized for share-based awards for the three months ended June 30, 2023 and 2022 (in thousands):

[0001032975-23-000066:notes:38]
|  |  |  |  | Three months ended June 30, |
|  |  |  |  |  |  | 2023 |  | 2022 |
| Cost of goods sold |  |  |  |  |  | $ | 1,415 |  |  | $ | 1,461 |  |
| Marketing and selling |  |  |  |  |  | 10,483 |  |  | 9,797 |  |
| Research and development |  |  |  |  |  | 4,453 |  |  | 5,532 |  |
| General and administrative |  |  |  |  |  | 5,160 |  |  | 6,900 |  |
| Total share-based compensation expense |  |  |  |  |  | 21,511 |  |  | 23,690 |  |
| Income tax benefit |  |  |  |  |  | (5,318) |  |  | (4,322) |  |
| Total share-based compensation expense, net of income tax benefit |  |  |  |  |  | $ | 16,193 |  |  | $ | 19,368 |  |

[0001032975-23-000066:notes:39]
[same as prior period, unchanged from 0001032975-23-000007:notes:29]

[0001032975-23-000066:notes:40]
Share-based compensation costs capitalized as part of inventory were $1.9 million and $1.8 million for the three months ended June 30, 2023 and 2022, respectively.

[0001032975-23-000066:notes:41]
[same as prior period, unchanged from 0001032975-23-000007:notes:31]

[0001032975-23-000066:notes:42]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The costs of $1.9 million and $2.8 million for the three months ended June 30, 2023 and 2022, respectively, were primarily related to service costs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-23-000066:notes:43]
[same as prior period, unchanged from 0001032975-23-000007:notes:33]

[0001032975-23-000066:notes:44]
[same as prior period, unchanged from 0001032975-23-000007:notes:34]

[0001032975-23-000066:notes:45]
The income tax provision for the three months ended June 30, 2023 was $12.5 million based on an effective income tax rate of 16.7% of pre-tax income, compared to an income tax provision of $21.7 million based on an effective income tax rate of 17.7% of pre-tax income for the three months ended June 30, 2022.

[0001032975-23-000066:notes:46]
The change in the effective income tax rate for the three months ended June 30, 2023, compared with the same period ended June 30, 2022 was primarily due to the mix of income and losses in the various tax jurisdictions in which the Company operates and the tax impact from share-based compensation for the three months ended June 30, 2023.

[0001032975-23-000066:notes:47]
Although the Company has adequately provided for uncertain tax positions, the provisions related to these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During fiscal year 2024, the Company continues to review its tax positions and provide for or reverse unrecognized tax benefits as they arise. During the next twelve months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. dollar as compared to other currencies. 
On August 16, 2022, the “Inflation Reduction Act” (H.R. 5376) ("IRA") was signed into law in the United States. The IRA establishes a new corporate alternative minimum tax based on financial statement income adjusted for certain items. The new minimum tax is effective for tax years beginning after December 31, 2022. The IRA does not have a material impact to the Company's financial statements for tax year ending March 31, 2024.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-23-000066:notes:48]
[same as prior period, unchanged from 0001032975-23-000007:notes:41]

[0001032975-23-000066:notes:49]
[same as prior period, unchanged from 0001032975-23-000007:notes:42]

[0001032975-23-000066:notes:50]
|  |  | June 30, 2023 |  | March 31, 2023 |
| Accounts receivable, net: |  |  |  |  |
| Accounts receivable |  | $ | 784,489 |  |  | $ | 851,576 |  |
| Allowance for doubtful accounts |  | (48) |  |  | (86) |  |
| Allowance for sales returns |  | (10,522) |  |  | (10,146) |  |
| Allowance for cooperative marketing arrangements |  | (39,249) |  |  | (40,495) |  |
| Allowance for customer incentive programs |  | (71,033) |  |  | (71,645) |  |
| Allowance for pricing programs |  | (101,035) |  |  | (98,822) |  |
|  |  | $ | 562,602 |  |  | $ | 630,382 |  |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 136,921 |  |  | $ | 171,790 |  |
| Finished goods |  | 435,423 |  |  | 511,103 |  |
|  |  | $ | 572,344 |  |  | $ | 682,893 |  |
| Other current assets: |  |  |  |  |
| Value-added tax ("VAT") receivables |  | $ | 41,932 |  |  | $ | 60,343 |  |
| Prepaid expenses and other assets |  | 69,640 |  |  | 82,533 |  |
|  |  | $ | 111,572 |  |  | $ | 142,876 |  |
| Property, plant and equipment, net: |  |  |  |  |
| Property, plant and equipment |  | $ | 511,130 |  |  | $ | 518,358 |  |
| Less: accumulated depreciation and amortization |  | (384,165) |  |  | (396,855) |  |
|  |  | $ | 126,965 |  |  | $ | 121,503 |  |
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 172,925 |  |  | $ | 171,989 |  |
| Right-of-use assets |  | 64,304 |  |  | 67,330 |  |
| Investments in privately held companies |  | 31,272 |  |  | 33,323 |  |
| Investments for deferred compensation plan |  | 29,884 |  |  | 28,213 |  |
| Other assets |  | 5,775 |  |  | 15,438 |  |
|  |  | $ | 304,160 |  |  | $ | 316,293 |  |

[0001032975-23-000066:notes:51]
[same as prior period, unchanged from 0001032975-23-000007:notes:44]

[0001032975-23-000066:notes:52]
|  |  | June 30, 2023 |  | March 31, 2023 |
| Accrued and other current liabilities: |  |  |  |  |
| Accrued customer marketing, pricing and incentive programs |  | $ | 184,503 |  |  | $ | 206,546 |  |
| Accrued personnel expenses |  | 92,109 |  |  | 103,592 |  |
| Accrued loss for inventory purchase commitments |  | 39,547 |  |  | 46,608 |  |
| Accrued sales return liability |  | 37,661 |  |  | 49,462 |  |
| Warranty liabilities |  | 28,076 |  |  | 28,861 |  |
| VAT payable |  | 19,066 |  |  | 33,328 |  |
| Income taxes payable |  | 18,901 |  |  | 18,788 |  |
| Operating lease liabilities |  | 12,900 |  |  | 12,655 |  |
| Contingent consideration |  | 6,500 |  |  | 6,629 |  |
| Other current liabilities |  | 131,281 |  |  | 136,670 |  |
|  |  | $ | 570,544 |  |  | $ | 643,139 |  |
| Other non-current liabilities: |  |  |  |  |
| Operating lease liabilities |  | $ | 60,074 |  |  | $ | 58,361 |  |
| Employee benefit plan obligations |  | 31,974 |  |  | 32,421 |  |
| Obligation for deferred compensation plan |  | 29,884 |  |  | 28,213 |  |
| Warranty liabilities |  | 11,809 |  |  | 12,025 |  |
| Deferred tax liabilities |  | 2,533 |  |  | 2,803 |  |
| Other non-current liabilities |  | 12,464 |  |  | 12,872 |  |
|  |  | $ | 148,738 |  |  | $ | 146,695 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001032975-23-000066:notes:53]
Fair Value Measurements

[0001032975-23-000066:notes:54]
The Company considers fair value as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants at the measurement date. The Company utilizes the following three-level fair value hierarchy to establish the priorities of the inputs used to measure fair value:

[0001032975-23-000066:notes:55]
•Level 1 — Quoted prices in active markets for identical assets or liabilities.

[0001032975-23-000066:notes:56]
•Level 2 — Observable inputs other than quoted market prices included in Level 1, such as quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active; or other inputs that are observable or can be corroborated by observable market data.

[0001032975-23-000066:notes:57]
•Level 3 — Unobservable inputs that are supported by little or no market activity and that are significant to the fair value of the assets or liabilities. This includes certain pricing models, discounted cash flow methodologies and similar techniques that use significant unobservable inputs.

[0001032975-23-000066:notes:58]
The following table presents the Company’s financial assets and liabilities that were accounted for at fair value on a recurring basis, excluding assets related to the Company’s defined benefit pension plans, classified by the level within the fair value hierarchy (in thousands):

[0001032975-23-000066:notes:59]
|  |  | June 30, 2023 |  | March 31, 2023 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 745,255 |  |  | $ | — |  |  | $ | — |  |  | $ | 661,884 |  |  | $ | — |  |  | $ | — |  |
| Investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 68 |  |  | $ | — |  |  | $ | — |  |  | $ | 41 |  |  | $ | — |  |  | $ | — |  |
| Common stock |  | 1,193 |  |  | — |  |  | — |  |  | 988 |  |  | — |  |  | — |  |
| Money market funds |  | 10,592 |  |  | — |  |  | — |  |  | 9,606 |  |  | — |  |  | — |  |
| Mutual funds |  | 18,031 |  |  | — |  |  | — |  |  | 17,578 |  |  | — |  |  | — |  |
| Total investments for deferred compensation plan |  | $ | 29,884 |  |  | $ | — |  |  | $ | — |  |  | $ | 28,213 |  |  | $ | — |  |  | $ | — |  |
| Currency derivative assetsincluded in other current assets |  | $ | — |  |  | $ | 141 |  |  | $ | — |  |  | $ | — |  |  | $ | 107 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration included in accrued and other current liabilities |  | $ | — |  |  | $ | — |  |  | $ | 6,500 |  |  | $ | — |  |  | $ | — |  |  | $ | 6,629 |  |
| Currency derivative liabilitiesincluded in accrued and other current liabilities |  | $ | — |  |  | $ | 893 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,187 |  |  | $ | — |  |

[0001032975-23-000066:notes:60]
Contingent Consideration for Business Acquisitions

[0001032975-23-000066:notes:61]
The following table summarizes the change in the Company's contingent consideration balance during the three months ended June 30, 2023 and 2022 (in thousands):

[0001032975-23-000066:notes:62]
|  |  | Three months ended June 30, |
|  |  | 2023 |  | 2022 |
| Beginning of the period |  | $ | 6,629 |  |  | $ | 12,259 |  |
| Fair value of contingent consideration upon acquisition |  | — |  |  | 1,142 |  |
| Effect of foreign currency exchange rate changes |  | (129) |  |  | — |  |
| End of the period |  | $ | 6,500 |  |  | $ | 13,401 |  |

[0001032975-23-000066:notes:63]
The contingent consideration arising from the technology acquisition on May 19, 2021, represents the future potential earn-out payments of up to $10.0 million payable in cash upon the achievement of three technical development milestones to be completed as of December 31, 2021, June 30, 2022, and June 30, 2023. The fair value of the contingent consideration was $10.0 million at the acquisition date, which was determined using a probability-weighted expected payment model and discounted at the estimated cost of debt. During fiscal year 2022, the Company paid $0.9 million for the contingent consideration related to the first technical development milestone. During fiscal year 2023, the Company paid $4.0 million for the contingent consideration related to the second technical development milestone. The Company expects to pay the contingent consideration for the third technical development milestone within the next twelve months.

[0001032975-23-000066:notes:64]
The contingent consideration arising from the technology acquisition on January 4, 2021, represents the future potential earn-out payments of up to $3.0 million payable in cash upon the achievement of two technical development milestones to be completed as of December 31, 2021 and March 31, 2022. The fair value of the contingent consideration was determined using a probability-weighted expected payment model and discounted at the estimated cost of debt. During fiscal year 2023, the Company paid $2.0 million for the contingent consideration related to the first technical development milestone. The Company expects to pay the remaining $1.0 million for the second technical development milestone within the next twelve months.

[0001032975-23-000066:notes:65]
Although the estimate of contingent consideration is based on management’s best knowledge of current events, the estimate could change significantly from period to period. Actual results that differ from the assumptions

[0001032975-23-000066:notes:66]
used and any changes to the significant assumptions and unobservable inputs used could have an impact on future results of operations.

[0001032975-23-000066:notes:67]
Investments for Deferred Compensation Plan

[0001032975-23-000066:notes:68]
The marketable securities for the Company's deferred compensation plan were recorded at a fair value of $29.9 million and $28.2 million, as of June 30, 2023 and March 31, 2023, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized gains (losses) related to marketable securities for the three months ended June 30, 2023 and 2022 were not material and were included in other income (expense), net in the Company's condensed consolidated statements of operations.

[0001032975-23-000066:notes:69]
Equity Method Investments

[0001032975-23-000066:notes:70]
The Company has certain non-marketable investments included in other assets that are accounted for as equity method investments, with a carrying value of $18.4 million and $20.5 million as of June 30, 2023 and March 31, 2023, respectively. Gains (losses) related to equity method investments for the three months ended June 30, 2023 and 2022 were not material and are included in other income (expense), net in the Company's condensed consolidated statements of operations. There was no impairment of equity method investments during the three months ended June 30, 2023 and 2022.

[0001032975-23-000066:notes:71]
Assets Measured at Fair Value on a Nonrecurring Basis

[0001032975-23-000066:notes:72]
Financial Assets

[0001032975-23-000066:notes:73]
The Company has certain equity investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with the same or similar security from the same issuer. The amount of these equity investments without readily determinable fair values included in other assets was $12.6 million as of June 30, 2023 and March 31, 2023. During the three months ended June 30, 2022, the Company recorded an unrealized gain, before tax, of $6.9 million for its investment in a private company as a result of observable price changes for similar securities issued by this company (level 2 fair value measurement). There was no impairment of these financial assets during the three months ended June 30, 2023 and 2022.

[0001032975-23-000066:notes:74]
During the three months ended June 30, 2023, the Company recorded an impairment loss, before tax, of $9.6 million as a result of the write-off of a note receivable which has been deemed no longer recoverable. This note receivable was previously obtained in conjunction with an exchange transaction related to the Company's investment in a privately held company. The impairment loss is included in other income (expense), net in the Company's condensed consolidated statement of operations for the three months ended June 30, 2023.

[0001032975-23-000066:notes:75]
Non-Financial Assets
Goodwill, intangible assets, and property, plant and equipment, are not required to be measured at fair value on a recurring basis. However, if the Company is required to evaluate these non-financial assets for impairment, whether due to certain triggering events or because of the required annual impairment test, and a resulting impairment is recorded to reduce the carrying value to the fair value, the non-financial assets are measured at fair value during such period. There was no impairment of non-financial assets during the three months ended June 30, 2023 and 2022.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-23-000066:notes:76]
[same as prior period, unchanged from 0001032975-23-000007:notes:71]

[0001032975-23-000066:notes:77]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis in other current assets and accrued and other current liabilities, respectively, on the condensed consolidated balance sheets as of June 30, 2023 and March 31, 2023. See Note 6 for the fair values of the Company’s derivative instruments as of June 30, 2023 and March 31, 2023.

[0001032975-23-000066:notes:78]
[same as prior period, unchanged from 0001032975-23-000007:notes:73]

[0001032975-23-000066:notes:79]
The Company enters into cash flow hedge contracts to protect against exchange rate exposure of forecasted inventory purchases. These hedging contracts mature within approximately four months. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Cash flows from such hedges are classified as operating activities in the condensed consolidated statements of cash flows. Hedging relationships are discontinued when the hedging contract is no longer eligible for hedge accounting, or is sold, terminated or exercised, or when the Company removes hedge designation for the contract. Gains and losses in the fair value of the effective portion of the discontinued hedges continue to be reported in accumulated other comprehensive loss until the hedged inventory purchases are sold, unless it is probable that the forecasted inventory purchases will not occur by the end of the originally specified time period or within an additional two-month period of time thereafter.

[0001032975-23-000066:notes:80]
The notional amounts of foreign currency exchange forward contracts outstanding related to forecasted inventory purchases were $84.2 million and $72.6 million as of June 30, 2023 and March 31, 2023, respectively. The Company had $1.7 million of net losses related to its cash flow hedges included in accumulated other comprehensive loss as of June 30, 2023, which will be reclassified into earnings within the next twelve months.

[0001032975-23-000066:notes:81]
The following table presents the amounts of gain (loss) on the Company’s derivative instruments designated as hedging instruments for the three months ended June 30, 2023 and 2022 and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income (in thousands):

[0001032975-23-000066:notes:82]
|  |  | Three months ended June 30, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Gain (Loss)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  |  |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |  |  |  |
| Cash flow hedges |  | $ | (704) |  |  | $ | 6,629 |  |  | $ | 2,986 |  |  | $ | (2,091) |  |  |  |  |  |

[0001032975-23-000066:notes:83]
[same as prior period, unchanged from 0001032975-23-000007:notes:78]

[0001032975-23-000066:notes:84]
[same as prior period, unchanged from 0001032975-23-000007:notes:79]

[0001032975-23-000066:notes:85]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within approximately one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are not material and included in other income (expense), net in the condensed consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of June 30, 2023 and March 31, 2023 were $98.3 million and $111.2 million, respectively. Foreign currency exchange forward and swap contracts outstanding as of June 30, 2023 primarily consisted of contracts in Brazilian Real, Japanese Yen, and Canadian Dollar to be settled at future dates at predetermined exchange rates.

[0001032975-23-000066:notes:86]
[same as prior period, unchanged from 0001032975-23-000007:notes:81]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-23-000066:notes:87]
Goodwill and Other Intangible AssetsThe Company conducts its impairment analysis of goodwill annually at December 31 or more frequently if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s 
reporting unit may be less than its carrying amount. There have been no triggering events identified affecting the valuation of goodwill and intangible assets during the three months ended June 30, 2023 and 2022.

[0001032975-23-000066:notes:88]
[same as prior period, unchanged from 0001032975-23-000007:notes:83]

[0001032975-23-000066:notes:89]
| As of March 31, 2023 |  | $ | 454,610 |  |
| Effects of foreign currency translation |  | (688) |  |
| As of June 30, 2023 |  | $ | 453,922 |  |

[0001032975-23-000066:notes:90]
[same as prior period, unchanged from 0001032975-23-000007:notes:85]

[0001032975-23-000066:notes:91]
|  |  | June 30, 2023 |  | March 31, 2023 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademarks and trade names |  | $ | 36,790 |  |  | $ | (27,794) |  |  | $ | 8,996 |  |  | $ | 36,790 |  |  | $ | (26,774) |  |  | $ | 10,016 |  |
| Developed technology |  | 121,730 |  |  | (97,952) |  |  | 23,778 |  |  | 121,730 |  |  | (94,792) |  |  | 26,938 |  |
| Customer contracts/relationships |  | 71,110 |  |  | (49,349) |  |  | 21,761 |  |  | 71,110 |  |  | (47,688) |  |  | 23,422 |  |
| In-process R&D |  | 3,526 |  |  | — |  |  | 3,526 |  |  | 3,526 |  |  | — |  |  | 3,526 |  |
| Effects of foreign currency translation |  | (1,211) |  |  | 380 |  |  | (831) |  |  | (1,021) |  |  | 292 |  |  | (729) |  |
| Total |  | $ | 231,945 |  |  | $ | (174,715) |  |  | $ | 57,230 |  |  | $ | 232,135 |  |  | $ | (168,962) |  |  | $ | 63,173 |  |


## us-gaap:DebtDisclosureTextBlock

[0001032975-23-000066:notes:92]
Financing Arrangements The Company had several uncommitted, unsecured bank lines of credit and letters of credit aggregating $172.0 million and $181.3 million as of June 30, 2023 and March 31, 2023, respectively. There are no financial covenants under the lines of credit with which the Company must comply. There was no borrowing outstanding under the lines of credit as of June 30, 2023 or March 31, 2023. As of June 30, 2023 and March 31, 2023, the Company had outstanding bank guarantees of $9.2 million and $13.6 million, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-23-000066:notes:93]
Commitments and Contingencies

[0001032975-23-000066:notes:94]
Product Warranties

[0001032975-23-000066:notes:95]
Changes in the Company’s warranty liabilities for the three months ended June 30, 2023 and 2022 were as follows (in thousands):

[0001032975-23-000066:notes:96]
|  |  |  | Three months ended June 30, |
|  |  |  |  |  | 2023 |  | 2022 |
| Beginning of the period |  |  |  |  | $ | 40,886 |  |  | $ | 46,219 |  |
| Provision |  |  |  |  | 9,092 |  |  | 6,623 |  |
| Settlements |  |  |  |  | (9,918) |  |  | (8,281) |  |
| Effects of foreign currency translation |  |  |  |  | (175) |  |  | (720) |  |
| End of the period |  |  |  |  | $ | 39,885 |  |  | $ | 43,841 |  |

[0001032975-23-000066:notes:97]
Indemnifications

[0001032975-23-000066:notes:98]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2023, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-23-000066:notes:99]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-23-000066:notes:100]
Legal Proceedings

[0001032975-23-000066:notes:101]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows and results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-23-000066:notes:102]
[same as prior period, unchanged from 0001032975-23-000007:notes:99]

[0001032975-23-000066:notes:103]
2020 Share Repurchase Program

[0001032975-23-000066:notes:104]
In May 2020, the Company's Board of Directors approved the 2020 share repurchase program, which authorized the Company to use up to $250.0 million to purchase Logitech shares. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. In April 2021, the Company's Board of Directors approved an increase of $750.0 million of the 2020 share repurchase program, to an aggregate amount of $1.0 billion. The Swiss Takeover Board approved this increase and it became effective on May 21, 2021. In July 2022, the Company’s Board of Directors approved an increase of $500 million to the 2020 share repurchase program, to an aggregate amount of up to $1.5 billion. The Swiss Takeover Board approved this increase and it became effective on August 19, 2022. As of June 30, 2023, $411.0 million was available for repurchase under the 2020 share repurchase program. The 2020 share repurchase program expired on July 27, 2023.

[0001032975-23-000066:notes:105]
2023 Share Repurchase Program

[0001032975-23-000066:notes:106]
In June 2023, the Company's Board of Directors approved a new, three-year share repurchase program, which allows the Company to use up to $1.0 billion to repurchase its shares. The Swiss Takeover Board approved the 2023 share repurchase program in July 2023 and the program will become effective on July 28, 2023. Swiss law limits a company’s ability to hold or repurchase its own shares. Generally, the aggregate par value of all shares held by the company and its subsidiaries may not exceed 10% of the registered share capital of the company, which for Logitech corresponds to 17.3 million shares. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.

[0001032975-23-000066:notes:107]
[same as prior period, unchanged from 0001032975-23-000007:notes:105]

[0001032975-23-000066:notes:108]
[same as prior period, unchanged from 0001032975-23-000007:notes:106]

[0001032975-23-000066:notes:109]
|  |  | Cumulative Translation Adjustment |  | Defined Benefit Plans |  | Deferred Hedging Gains (Losses) |  | Total |
| March 31, 2023 |  | $ | (100,869) |  |  | $ | 4,525 |  |  | $ | (3,933) |  |  | $ | (100,277) |  |
| Other comprehensive income (loss) |  | (1,529) |  |  | (4) |  |  | 2,282 |  |  | 749 |  |
| June 30, 2023 |  | $ | (102,398) |  |  | $ | 4,521 |  |  | $ | (1,651) |  |  | $ | (99,528) |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-23-000066:notes:110]
[same as prior period, unchanged from 0001032975-23-000007:notes:108]

[0001032975-23-000066:notes:111]
The Company operates in a single operating segment that encompasses the design, manufacturing and marketing of peripherals for gaming, PCs, tablets, video conferencing, and other digital platforms. Operating performance measures are provided directly to the Company's CEO, who is considered to be the Company’s Chief Operating Decision Maker. The CEO periodically reviews information such as sales and adjusted operating income (loss) to make business decisions. These operating performance measures do not include restructuring charges (credits), net, share-based compensation expense, amortization and impairment of intangible assets, acquisition-related costs, and change in fair value of contingent consideration from business acquisitions.

[0001032975-23-000066:notes:112]
During the first quarter of fiscal year 2024, the Company changed its presentation of Sales by Product Category to provide a simpler and clearer view of the Company's business. The change in presentation did not have an impact on previously reported total sales. As a result of these changes, certain prior-period amounts for the three months ended June 30, 2022 have been reclassified to conform to the current period presentation. See Note 1 for further information on the change in presentation.

[0001032975-23-000066:notes:113]
Sales by product category in the current presentation for the three months ended June 30, 2023 and 2022 were as follows (in thousands):

[0001032975-23-000066:notes:114]
|  |  |  |  | Three months ended June 30, |
|  |  |  |  |  |  | 2023 |  | 2022 |
| Gaming (1) |  |  |  |  |  | $ | 266,429 |  |  | $ | 297,921 |  |
| Keyboards & Combos |  |  |  |  |  | 180,855 |  |  | 227,720 |  |
| Pointing Devices |  |  |  |  |  | 174,454 |  |  | 183,283 |  |
| Video Collaboration |  |  |  |  |  | 139,346 |  |  | 181,632 |  |
| Webcams |  |  |  |  |  | 75,200 |  |  | 109,262 |  |
| Tablet Accessories |  |  |  |  |  | 70,336 |  |  | 66,585 |  |
| Headsets |  |  |  |  |  | 36,850 |  |  | 45,943 |  |
| Other (2) |  |  |  |  |  | 31,029 |  |  | 47,519 |  |
| Total Sales |  |  |  |  |  | $ | 974,499 |  |  | $ | 1,159,865 |  |

[0001032975-23-000066:notes:115]
[same as prior period, unchanged from 0001032975-23-000007:notes:112]

[0001032975-23-000066:notes:116]
(2) Other primarily consists of mobile speakers and PC speakers.

[0001032975-23-000066:notes:117]
Sales by geographic region (based on the customers’ locations) for the three months ended June 30, 2023 and 2022 were as follows (in thousands):

[0001032975-23-000066:notes:118]
|  |  |  |  | Three months ended June 30, |
|  |  |  |  |  |  | 2023 |  | 2022 |
| Americas |  |  |  |  |  | $ | 445,168 |  |  | $ | 502,307 |  |
| EMEA |  |  |  |  |  | 258,878 |  |  | 290,479 |  |
| Asia Pacific |  |  |  |  |  | 270,453 |  |  | 367,079 |  |
| Total Sales |  |  |  |  |  | $ | 974,499 |  |  | $ | 1,159,865 |  |

[0001032975-23-000066:notes:119]
[same as prior period, unchanged from 0001032975-23-000007:notes:116]

[0001032975-23-000066:notes:120]
Switzerland, the Company’s country of domicile, represented 2% of the Company's total consolidated sales for each of the three months ended June 30, 2023 and 2022.

[0001032975-23-000066:notes:121]
Three customers of the Company each represented 10% or more of the total consolidated gross sales for each of the three months ended June 30, 2023 and 2022.

[0001032975-23-000066:notes:122]
[same as prior period, unchanged from 0001032975-23-000007:notes:119]

[0001032975-23-000066:notes:123]
|  |  | June 30, 2023 |  | March 31, 2023 |
| Americas |  | $ | 69,509 |  |  | $ | 59,183 |  |
| EMEA |  | 35,583 |  |  | 38,890 |  |
| Asia Pacific |  | 63,207 |  |  | 69,939 |  |
| Total |  | $ | 168,299 |  |  | $ | 168,012 |  |

[0001032975-23-000066:notes:124]
Property, plant and equipment, net (excluding software) and right-of-use assets in the United States, China, and Ireland were $69.1 million, $43.7 million and $17.2 million, respectively, as of June 30, 2023, and $58.7 million, $48.8 million, and $17.7 million respectively, as of March 31, 2023. No other countries represented more than 10% of the Company’s total consolidated property, plant and equipment, net (excluding software) and right-of-use assets as of June 30, 2023 or March 31, 2023. 
Property, plant and equipment, net (excluding software) and right-of-use assets in Switzerland, the Company’s country of domicile, were $11.3 million and $13.7 million as of June 30, 2023 and March 31, 2023, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001032975-23-000066:notes:125]
Restructuring 
During the second quarter of fiscal year 2023, the Company initiated a restructuring plan to realign its business group and engineering structure with its go-to-market strategy to more effectively compete within the enterprise market and to better serve end-users. During the fourth quarter of fiscal year 2023, the Company undertook further

[0001032975-23-000066:notes:126]
actions to remove organization layers as well as streamline its marketing organization to increase efficiency. These actions resulted in charges related to employee severance and other termination benefits as well as contract termination and other costs. The Company expects to substantially complete these restructuring activities within the next nine months.

[0001032975-23-000066:notes:127]
The following table summarizes restructuring-related activities during the three months ended June 30, 2023 (in thousands):

[0001032975-23-000066:notes:128]
|  |  | TerminationBenefits |  | Contract Termination and Other |  | Total |  |
| Accrued restructuring liability at March 31, 2023 (1) |  | $ | 14,177 |  |  | $ | 5,357 |  |  | $ | 19,534 |  |  |
| Charges, net |  | 3,475 |  |  | 36 |  |  | 3,511 |  |  |
| Cash payments |  | (14,941) |  |  | (205) |  |  | (15,146) |  |  |
| Accrued restructuring liability at June 30, 2023 (1) |  | $ | 2,711 |  |  | $ | 5,188 |  |  | $ | 7,899 |  |  |

[0001032975-23-000066:notes:129]
(1) The accrual balances are included in accrued and other current liabilities on the Company’s condensed consolidated balance sheets.
