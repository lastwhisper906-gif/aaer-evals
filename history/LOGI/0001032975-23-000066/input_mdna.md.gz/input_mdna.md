# LOGI MD&A — 0001032975-23-000066


## mdna

[0001032975-23-000066:mdna:1]
[same as prior period, unchanged from 0001032975-23-000007:mdna:1]

[0001032975-23-000066:mdna:2]
[same as prior period, unchanged from 0001032975-23-000007:mdna:2]

[0001032975-23-000066:mdna:3]
•Our business strategy and investment priorities in relation to competitive offerings and evolving consumer demand trends affecting our products and markets, current and future worldwide geopolitical, economic and capital market conditions, including fluctuations in currency exchange rates, inflation, and economic downturns;

[0001032975-23-000066:mdna:4]
[same as prior period, unchanged from 0001032975-23-000007:mdna:13]

[0001032975-23-000066:mdna:5]
•Long-term, secular trends that impact our product categories;

[0001032975-23-000066:mdna:6]
•The scope, nature or impact of acquisition, strategic alliance, and divestiture activities

[0001032975-23-000066:mdna:7]
[same as prior period, unchanged from 0001032975-23-000007:mdna:5]

[0001032975-23-000066:mdna:8]
[same as prior period, unchanged from 0001032975-23-000007:mdna:6]

[0001032975-23-000066:mdna:9]
•Our expectations regarding our potential indemnification obligations, and the outcome of pending or future legal proceedings and tax audits;

[0001032975-23-000066:mdna:10]
•Our business development, product development and innovation, and their impact on future operating results and anticipated operating costs for fiscal year 2024 and beyond;

[0001032975-23-000066:mdna:11]
[same as prior period, unchanged from 0001032975-23-000007:mdna:9]

[0001032975-23-000066:mdna:12]
[same as prior period, unchanged from 0001032975-23-000007:mdna:10]

[0001032975-23-000066:mdna:13]
[same as prior period, unchanged from 0001032975-23-000007:mdna:12]

[0001032975-23-000066:mdna:14]
•The sufficiency of our cash and cash equivalents, cash generated from operations, and available borrowings under our bank lines of credit to fund capital expenditures and working capital needs; and

[0001032975-23-000066:mdna:15]
•The effects of environmental and other laws and regulations in the United States and other countries in which we operate.

[0001032975-23-000066:mdna:16]
[same as prior period, unchanged from 0001032975-23-000007:mdna:17]

[0001032975-23-000066:mdna:17]
[same as prior period, unchanged from 0001032975-23-000007:mdna:18]

[0001032975-23-000066:mdna:18]
Logitech’s mission is to help all people pursue their passions in a way that is good for people and the planet. We design, manufacture, and sell products that help businesses thrive and bring people together when working, creating, gaming and streaming. We sell these products through a number of brands: Logitech, Logitech G (including ASTRO Gaming, Streamlabs, and Blue Microphones) and Ultimate Ears.

[0001032975-23-000066:mdna:19]
Our diverse portfolio includes Gaming, Keyboards & Combos, Pointing Devices, Video Collaboration, Webcams, Tablet Accessories, and Headsets. We sell our products to a broad network of international customers, including direct sales to retailers, e-tailers, and end consumers through our e-commerce platform, and indirect sales to end customers through distributors.

[0001032975-23-000066:mdna:20]
[same as prior period, unchanged from 0001032975-23-000007:mdna:21]

[0001032975-23-000066:mdna:21]
Impacts of Macroeconomic and Geopolitical Conditions on our Business

[0001032975-23-000066:mdna:22]
Our business has been impacted by adverse macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, slowdown of economic activity around the world, and lower consumer and enterprise spending. In addition, the war in Ukraine resulted in global supply chain, logistics, and inflationary challenges. We have had no revenue in Russia and Ukraine since fiscal year 2023 as we have indefinitely ceased all sales and shipments to Russia and sales in Ukraine have also been halted due to the ongoing military operations on the Ukrainian territory.

[0001032975-23-000066:mdna:23]
The global and regional economic and political conditions adversely affect demand for our products. These conditions also had an impact on our suppliers, contract manufacturers, logistics providers, and distributors, causing volatility in cost of materials and shipping and transportation rates, and as a result, impacting the pricing of our products.

[0001032975-23-000066:mdna:24]
For additional information, see "Liquidity and Capital Resources" below and Part II, Item 1A "Risk Factors".

[0001032975-23-000066:mdna:25]
Trends and Uncertainties

[0001032975-23-000066:mdna:26]
Several long-term secular-trends offer long-term structural growth opportunities across Logitech’s product portfolio, including work and learn from anywhere (hybrid work), video everywhere, the rise of social gaming for participants and spectators, and the democratization of digital content creation. We design, create and sell products that benefit from these secular trends. The culture of hybrid work and learn provides an opportunity to equip meeting rooms, classrooms and personal workspaces, at home or in the office. It also provides an opportunity for increased commercial and consumer adoption of video conferencing. Our video collaboration products are compatible with a variety of video conference platforms, including Zoom, Microsoft Teams, Google Meet, etc. Moving from work to play, Logitech gaming and streaming products benefit from social gaming which continues to gain popularity through online gaming, multi-platform experiences and esports. In addition, the democratization of digital content creation presents an opportunity for anyone to be a content creator because of the accessibility of the tools necessary to code, design, create, make music, game or broadcast to professional standards.

[0001032975-23-000066:mdna:27]
While we believe we will further benefit from these secular trends, we have experienced and will continue to experience challenges that impact our business and financial results. These challenges include (i) the current macroeconomic environment, including interest rate fluctuations, inflation, foreign exchange movements and low economic growth in certain regions, (ii) low consumer confidence and recent declines in enterprise spending leading to reduced demand for some of our products, (iii) the uncertainty in strategy and timing of enterprises’ “return-to-office” impacting demand for our Video Collaboration and other products, and (iv) the timing of further development of our business-to-business go-to-market capabilities.

[0001032975-23-000066:mdna:28]
We expect these challenges to continue in the near-term. We have taken steps to mitigate the impact of these challenges, including but not limited to: (i) reduction in our operating expenses in order to maintain margins and size the business for the current market, (ii) reduction in inventories to more appropriately align with demand, (iii) continued investment in our business-to-business direct sales channel in order to improve performance, and (iv) release of new products to increase the value proposition of our portfolio.

[0001032975-23-000066:mdna:29]
[same as prior period, unchanged from 0001032975-23-000007:mdna:40]

[0001032975-23-000066:mdna:30]
[same as prior period, unchanged from 0001032975-23-000007:mdna:41]

[0001032975-23-000066:mdna:31]
[same as prior period, unchanged from 0001032975-23-000007:mdna:27]

[0001032975-23-000066:mdna:32]
Our total sales for the three months ended June 30, 2023 decreased 16% compared to the three months ended June 30, 2022, driven by a decline in sales of most of our product categories, as a result of lower demand.

[0001032975-23-000066:mdna:33]
Sales for the three months ended June 30, 2023 decreased 11%, 11% and 26% in the Americas, EMEA, and Asia Pacific regions, respectively, compared to the three months ended June 30, 2022.

[0001032975-23-000066:mdna:34]
Gross margin was 38.5% for the three months ended June 30, 2023 and decreased by 110 basis points compared to the three months ended June 30, 2022, primarily due to unfavorable impacts from changes in currency exchange rates and unfavorable product mix, partially offset by lower material costs and a reduction in our use of expedited shipping.

[0001032975-23-000066:mdna:35]
Operating expenses for the three months ended June 30, 2023 were $297.2 million, or 30.5% of sales, compared to $344.1 million, or 29.7% of sales, for the three months ended June 30, 2022. The decrease in operating expense was primarily driven by a reduction in marketing and advertising spend.

[0001032975-23-000066:mdna:36]
Net income for the three months ended June 30, 2023 was $62.7 million compared to $100.8 million for the  three months ended June 30, 2022.

[0001032975-23-000066:mdna:37]
[same as prior period, unchanged from 0001032975-23-000007:mdna:44]

[0001032975-23-000066:mdna:38]
[same as prior period, unchanged from 0001032975-23-000007:mdna:45]

[0001032975-23-000066:mdna:39]
We consider an accounting estimate critical if it: (i) requires management to make judgments and estimates about matters that are inherently uncertain; and (ii) is important to an understanding of our financial condition and operating results.

[0001032975-23-000066:mdna:40]
[same as prior period, unchanged from 0001032975-23-000007:mdna:46]

[0001032975-23-000066:mdna:41]
We believe that the assumptions, judgments and estimates involved in the accounting for accruals for customer incentives and related breakage when appropriate, accrued sales return liability, inventory valuation, and uncertain tax positions, have the greatest potential impact on our condensed consolidated financial statements. These areas are key components of our results of operations and are based on complex rules requiring us to make judgments and estimates and consequently, we consider these to be our critical accounting policies. Historically, our assumptions, judgments and estimates relative to our critical accounting policies have not differed materially from actual results.

[0001032975-23-000066:mdna:42]
There have been no material changes in our critical accounting estimates during the three months ended June 30, 2023 compared with the critical accounting estimates disclosed in Management's Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended March 31, 2023.

[0001032975-23-000066:mdna:43]
Inflation Reduction Act in the U.S.

[0001032975-23-000066:mdna:44]
On August 16, 2022, the “Inflation Reduction Act” (H.R. 5376) ("IRA") was signed into law in the U.S. The IRA establishes a new corporate alternative minimum tax based on financial statement income adjusted for certain items. The new minimum tax is effective for tax years beginning after December 31, 2022. The IRA does not have a material impact on our financial statements for tax year ending March 31, 2024.

[0001032975-23-000066:mdna:45]
[same as prior period, unchanged from 0001032975-23-000007:mdna:51]

[0001032975-23-000066:mdna:46]
[same as prior period, unchanged from 0001032975-23-000007:mdna:52]

[0001032975-23-000066:mdna:47]
[same as prior period, unchanged from 0001032975-23-000007:mdna:53]

[0001032975-23-000066:mdna:48]
[same as prior period, unchanged from 0001032975-23-000007:mdna:54]

[0001032975-23-000066:mdna:49]
[same as prior period, unchanged from 0001032975-23-000007:mdna:55]

[0001032975-23-000066:mdna:50]
[same as prior period, unchanged from 0001032975-23-000007:mdna:56]

[0001032975-23-000066:mdna:51]
[same as prior period, unchanged from 0001032975-23-000007:mdna:57]

[0001032975-23-000066:mdna:52]
Our sales for the three months ended June 30, 2023 decreased 16% compared to the three months ended June 30, 2022, primarily due to a decline in sales of most of our product categories as a result of lower demand. If currency exchange rates had been constant in the three months ended June 30, 2023 and 2022, our constant dollar sales reduction rate would have been 15%.

[0001032975-23-000066:mdna:53]
[same as prior period, unchanged from 0001032975-23-000007:mdna:59]

[0001032975-23-000066:mdna:54]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Australian Dollar, Canadian Dollar, Japanese Yen, Pound Sterling and New Taiwan Dollar. During the three months ended June 30, 2023, approximately 48% of our sales were denominated in currencies other than the U.S. Dollar.

[0001032975-23-000066:mdna:55]
[same as prior period, unchanged from 0001032975-23-000007:mdna:61]

[0001032975-23-000066:mdna:56]
The following table presents the change in sales by region for the three months ended June 30, 2023, compared with the three months ended June 30, 2022:

[0001032975-23-000066:mdna:57]
|  |  |  |  | Sales Growth Rate |  |  |  | Constant DollarSales Growth Rate |
| Americas |  |  |  | (11) | % |  |  |  | (11) | % |
| EMEA |  |  |  | (11) | % |  |  |  | (11) | % |
| Asia Pacific |  |  |  | (26) | % |  |  |  | (24) | % |

[0001032975-23-000066:mdna:58]
[same as prior period, unchanged from 0001032975-23-000007:mdna:64]

[0001032975-23-000066:mdna:59]
The decrease in sales in the Americas region for the three-month period presented above was primarily driven by a decrease in sales of Video Collaboration, Webcams, and Keyboards & Combos.

[0001032975-23-000066:mdna:60]
[same as prior period, unchanged from 0001032975-23-000007:mdna:66]

[0001032975-23-000066:mdna:61]
The decrease in sales in our EMEA region for the three-month period presented above was primarily driven by the decrease in sales of all of our product categories other than Pointing Devices.

[0001032975-23-000066:mdna:62]
[same as prior period, unchanged from 0001032975-23-000007:mdna:68]

[0001032975-23-000066:mdna:63]
The decrease in sales in our Asia Pacific region for the three-month period presented above was primarily driven by the decrease in sales of Gaming, Keyboards & Combos, Webcams, and Pointing Devices.

[0001032975-23-000066:mdna:64]
Sales by Product Category

[0001032975-23-000066:mdna:65]
During the first quarter of fiscal year 2024, we changed the presentation of sales by product category to provide a simpler and clearer view of our business. The change in presentation did not have an impact on previously reported total sales. As a result of these changes, certain prior-period amounts for the three months ended June 30, 2022 have been reclassified to conform to the current period presentation. See Note 1 to the condensed consolidated financial statements for further information on the change in presentation.

[0001032975-23-000066:mdna:66]
Sales by product category in the current presentation for the three months ended June 30, 2023 and 2022 were as follows (dollars in thousands):

[0001032975-23-000066:mdna:67]
|  |  |  |  | Three months ended June 30, |
|  |  |  |  |  |  |  |  | 2023 |  | 2022 |  | Change |
| Gaming (1) |  |  |  |  |  |  |  | $ | 266,429 |  |  | $ | 297,921 |  |  | (11) | % |
| Keyboards & Combos |  |  |  |  |  |  |  | 180,855 |  |  | 227,720 |  |  | (21) |  |
| Pointing Devices |  |  |  |  |  |  |  | 174,454 |  |  | 183,283 |  |  | (5) |  |
| Video Collaboration |  |  |  |  |  |  |  | 139,346 |  |  | 181,632 |  |  | (23) |  |
| Webcams |  |  |  |  |  |  |  | 75,200 |  |  | 109,262 |  |  | (31) |  |
| Tablet Accessories |  |  |  |  |  |  |  | 70,336 |  |  | 66,585 |  |  | 6 |  |
| Headsets |  |  |  |  |  |  |  | 36,850 |  |  | 45,943 |  |  | (20) |  |
| Other (2) |  |  |  |  |  |  |  | 31,029 |  |  | 47,519 |  |  | (35) |  |
| Total Sales |  |  |  |  |  |  |  | $ | 974,499 |  |  | $ | 1,159,865 |  |  | (16) | % |

[0001032975-23-000066:mdna:68]
[same as prior period, unchanged from 0001032975-23-000007:mdna:73]

[0001032975-23-000066:mdna:69]
(2) Other primarily consists of mobile speakers and PC speakers.

[0001032975-23-000066:mdna:70]
[same as prior period, unchanged from 0001032975-23-000007:mdna:89]

[0001032975-23-000066:mdna:71]
Our Gaming category includes gaming mice, keyboards, headsets, gamepads, steering wheels, simulation controllers, console gaming headsets, studio-quality Blue Microphones and Streamlabs services.

[0001032975-23-000066:mdna:72]
Sales of Gaming decreased 11% for the three months ended June 30, 2023, compared to the three months ended June 30, 2022, primarily driven by the decrease in sales of gaming steering wheels and gaming keyboards.

[0001032975-23-000066:mdna:73]
[same as prior period, unchanged from 0001032975-23-000007:mdna:79]

[0001032975-23-000066:mdna:74]
Our Keyboards & Combos category includes PC keyboards and keyboard/mice combo products.

[0001032975-23-000066:mdna:75]
Sales of Keyboards & Combos decreased 21% for the three months ended June 30, 2023, compared to the three months ended June 30, 2022, primarily driven by the decrease in sales of our cordless keyboards and combos.

[0001032975-23-000066:mdna:76]
[same as prior period, unchanged from 0001032975-23-000007:mdna:76]

[0001032975-23-000066:mdna:77]
Our Pointing Devices category includes PC- and Mac-related mice including trackballs, touchpads, and presentation tools.

[0001032975-23-000066:mdna:78]
Sales of Pointing Devices decreased 5% for the three months ended June 30, 2023, compared to the three months ended June 30, 2022, primarily driven by the decrease in sales of cordless mice.

[0001032975-23-000066:mdna:79]
[same as prior period, unchanged from 0001032975-23-000007:mdna:93]

[0001032975-23-000066:mdna:80]
Our Video Collaboration category includes Logitech’s conference room cameras, which combine affordable enterprise-quality audio and high definition 4K video to bring video conferencing to businesses of any size.

[0001032975-23-000066:mdna:81]
Sales of Video Collaboration decreased 23% for the three months ended June 30, 2023, compared to the three months ended June 30, 2022, driven by a decrease in sales of most of our Video Collaboration products due primarily to a slowdown in enterprise spending.

[0001032975-23-000066:mdna:82]
Webcams

[0001032975-23-000066:mdna:83]
Our Webcams category includes PC-based webcams that are targeted primarily at consumers, including streaming cameras, and VC webcams that turn any desktop into an instant collaboration space.

[0001032975-23-000066:mdna:84]
Sales of Webcams decreased 31% for the three months ended June 30, 2023, compared to the three months ended June 30, 2022, primarily driven by the decrease in sales of our VC webcams as well as our PC-based webcams such as HD Pro Webcam C920 and 1080p Pro Stream Webcam.

[0001032975-23-000066:mdna:85]
Tablet Accessories

[0001032975-23-000066:mdna:86]
Our Tablet Accessories category primarily includes tablet keyboards and styluses.

[0001032975-23-000066:mdna:87]
Sales of Tablet Accessories increased 6% for the three months ended June 30, 2023, compared to the three months ended June 30, 2022, primarily driven by the increase in sales of our Rugged Combo 3 Touch as well as Combo Touch and Rugged Combo 4 Touch, introduced in the third quarter of fiscal year 2023, partially offset by the decrease in sales of our Rugged Folio.

[0001032975-23-000066:mdna:88]
Headsets

[0001032975-23-000066:mdna:89]
Our Headsets category includes PC and VC headsets, in-ear headphones, and premium wireless earbuds.

[0001032975-23-000066:mdna:90]
Sales of Headsets decreased 20% for the three months ended June 30, 2023, compared to the three months ended June 30, 2022, primarily driven by a decrease in sales of corded PC headsets and VC headsets.

[0001032975-23-000066:mdna:91]
Other

[0001032975-23-000066:mdna:92]
Our Other category primarily consists of mobile speakers and PC speakers.

[0001032975-23-000066:mdna:93]
Sales in Other category decreased 35% for the three months ended June 30, 2023, compared to the three months ended June 30, 2022, primarily driven by a decrease in mobile speakers and certain other products that have been discontinued.

[0001032975-23-000066:mdna:94]
[same as prior period, unchanged from 0001032975-23-000007:mdna:103]

[0001032975-23-000066:mdna:95]
Gross profit for the three months ended June 30, 2023 and 2022 was as follows (Dollars in thousands):

[0001032975-23-000066:mdna:96]
|  |  |  |  | Three months ended June 30, |
|  |  |  |  |  |  |  |  | 2023 |  | 2022 |  | Change |
| Net sales |  |  |  |  |  |  |  | $ | 974,499 |  |  | $ | 1,159,865 |  |  | (16) | % |
| Gross profit |  |  |  |  |  |  |  | $ | 375,642 |  |  | $ | 459,603 |  |  | (18) | % |
| Gross margin |  |  |  |  |  |  |  | 38.5 | % |  | 39.6 | % |  |  |

[0001032975-23-000066:mdna:97]
[same as prior period, unchanged from 0001032975-23-000007:mdna:106]

[0001032975-23-000066:mdna:98]
Gross margin was 38.5% for the three months ended June 30, 2023 and decreased by 110 basis points compared to the three months ended June 30, 2022. The gross margin decline was primarily driven by unfavorable impacts from changes in currency exchange rates and unfavorable product mix, partially offset by lower material cost and a reduction in our use of expedited shipping.

[0001032975-23-000066:mdna:99]
[same as prior period, unchanged from 0001032975-23-000007:mdna:108]

[0001032975-23-000066:mdna:100]
Operating expenses for the three months ended June 30, 2023 and 2022 were as follows (Dollars in thousands):

[0001032975-23-000066:mdna:101]
|  |  |  |  | Three months ended June 30, |  |
|  |  |  |  |  |  | 2023 |  | 2022 |  |
| Marketing and selling |  |  |  |  |  | $ | 179,185 |  |  | $ | 229,378 |  |  |
| % of sales |  |  |  |  |  | 18.4 | % |  | 19.8 | % |  |
| Research and development |  |  |  |  |  | 70,559 |  |  | 75,517 |  |  |
| % of sales |  |  |  |  |  | 7.2 | % |  | 6.5 | % |  |
| General and administrative |  |  |  |  |  | 41,297 |  |  | 35,860 |  |  |
| % of sales |  |  |  |  |  | 4.2 | % |  | 3.1 | % |  |
| Amortization of intangible assets and acquisition-related costs |  |  |  |  |  | 2,685 |  |  | 3,369 |  |  |
| % of sales |  |  |  |  |  | 0.3 | % |  | 0.3 | % |  |
| Restructuring charges, net |  |  |  |  |  | 3,511 |  |  | — |  |  |
| % of sales |  |  |  |  |  | 0.4 | % |  | N/A |  |
| Total operating expenses |  |  |  |  |  | $ | 297,237 |  |  | $ | 344,124 |  |  |
| % of sales |  |  |  |  |  | 30.5 | % |  | 29.7 | % |  |

[0001032975-23-000066:mdna:102]
The decrease in total operating expenses during the three months ended June 30, 2023, compared to the three months ended June 30, 2022, was mainly due to decreases in marketing and selling expenses.

[0001032975-23-000066:mdna:103]
[same as prior period, unchanged from 0001032975-23-000007:mdna:112]

[0001032975-23-000066:mdna:104]
[same as prior period, unchanged from 0001032975-23-000007:mdna:113]

[0001032975-23-000066:mdna:105]
During the three months ended June 30, 2023, marketing and selling expenses decreased $50.2 million, compared to the three months ended June 30, 2022, primarily driven by our reduction in third-party marketing and advertising spend as well as decreases in personnel-related costs as a result of headcount reduction.

[0001032975-23-000066:mdna:106]
[same as prior period, unchanged from 0001032975-23-000007:mdna:115]

[0001032975-23-000066:mdna:107]
[same as prior period, unchanged from 0001032975-23-000007:mdna:116]

[0001032975-23-000066:mdna:108]
During the three months ended June 30, 2023, research and development expenses decreased $5.0 million, compared to the three months ended June 30, 2022, primarily driven by lower personnel-related costs and outsourcing expenses. Research and development expenses as a percentage of sales increased from 6.5% in the three months ended June 30, 2022 to 7.2% in the three months ended June 30, 2023, reflecting our continued investment in innovation.

[0001032975-23-000066:mdna:109]
[same as prior period, unchanged from 0001032975-23-000007:mdna:118]

[0001032975-23-000066:mdna:110]
General and administrative expenses primarily consist of personnel and related overhead, information technology, and facilities costs for the infrastructure functions such as finance, information systems, executives, human resources and legal.

[0001032975-23-000066:mdna:111]
During the three months ended June 30, 2023, general and administrative expenses increased $5.4 million, compared to the three months ended June 30, 2022, primarily driven by higher accrued litigation costs.

[0001032975-23-000066:mdna:112]
[same as prior period, unchanged from 0001032975-23-000007:mdna:121]

[0001032975-23-000066:mdna:113]
[same as prior period, unchanged from 0001032975-23-000007:mdna:122]

[0001032975-23-000066:mdna:114]
During the three months ended June 30, 2023, amortization of intangible assets and acquisition-related costs decreased $0.7 million, compared to the three months ended June 30, 2022, primarily due to certain acquired intangible assets becoming fully amortized.

[0001032975-23-000066:mdna:115]
[same as prior period, unchanged from 0001032975-23-000007:mdna:126]

[0001032975-23-000066:mdna:116]
The restructuring charges of $3.5 million for the three months ended June 30, 2023 was primarily related to employee severance and other termination benefits, incurred as a result of our restructuring plan initiated during fiscal year 2023. We expect to substantially complete this restructuring plan within the next nine months.

[0001032975-23-000066:mdna:117]
[same as prior period, unchanged from 0001032975-23-000007:mdna:129]

[0001032975-23-000066:mdna:118]
[same as prior period, unchanged from 0001032975-23-000007:mdna:130]

[0001032975-23-000066:mdna:119]
Interest income for the three months ended June 30, 2023 and 2022 was as follows (in thousands):

[0001032975-23-000066:mdna:120]
|  |  |  |  | Three months ended June 30, |
|  |  |  |  |  |  | 2023 |  | 2022 |
| Interest Income |  |  |  |  |  | $ | 9,826 |  |  | $ | 1,449 |  |

[0001032975-23-000066:mdna:121]
We invest in highly liquid instruments with an original maturity of three months or less at the date of purchase, which are classified as cash equivalents. During the three months ended June 30, 2023 interest income increased $8.4 million compared to the three months ended June 30, 2022, primarily driven by the increase in interest rates.

[0001032975-23-000066:mdna:122]
[same as prior period, unchanged from 0001032975-23-000007:mdna:134]

[0001032975-23-000066:mdna:123]
Other income (expense), net for the three months ended June 30, 2023 and 2022 was as follows (Dollars in thousands):

[0001032975-23-000066:mdna:124]
|  |  |  |  | Three months ended June 30, |
|  |  |  |  |  |  | 2023 |  | 2022 |
| Investment gain (loss) related to the deferred compensation plan |  |  |  |  |  | $ | 1,024 |  |  | $ | (3,386) |  |
| Currency exchange loss, net |  |  |  |  |  | (3,086) |  |  | (2,960) |  |
| Gain (loss) on investments, net |  |  |  |  |  | (11,823) |  |  | 11,357 |  |
| Non-service cost net pension income and other |  |  |  |  |  | 913 |  |  | 613 |  |
| Total |  |  |  |  |  | $ | (12,972) |  |  | $ | 5,624 |  |

[0001032975-23-000066:mdna:125]
Investment gain (loss) related to the deferred compensation plan represents earnings, gains, and losses on marketable securities related to a deferred compensation plan offered by one of our subsidiaries. The increase in investment income for three months ended June 30, 2023, compared to the three months ended June 30, 2022, primarily relates to the change in market performance of the underlying securities.

[0001032975-23-000066:mdna:126]
Currency exchange loss, net, relates to balances denominated in currencies other than the functional currency in our subsidiaries, as well as to the sale of currencies, and gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses. The loss for the three months ended June 30, 2023 was primarily due to the weakening of the Japanese Yen against the U.S. Dollar. The loss for the three months ended June 30, 2022 was primarily due to the weakening of the Brazilian Real, Australian Dollar and Japanese Yen against the U.S. Dollar.

[0001032975-23-000066:mdna:127]
Gain (loss) on investments, net, includes unrealized gain (loss) from the fair value change of investment, gain (loss) on equity-method investments and impairment of investments during the periods presented, as applicable. The loss on investments, net for the three months ended June 30, 2023 was primarily due to an impairment loss, as a result of the write-off of a note receivable which has been deemed no longer recoverable. This note receivable was previously obtained in conjunction with an exchange transaction related to our investment in a privately held company. The gain for the three months ended June 30, 2022 was primarily due to the unrealized gain resulting from observable price changes on equity investments without a readily determinable fair value and gains on equity-method investments. See Note 6 to our condensed consolidated financial statements for additional information.

[0001032975-23-000066:mdna:128]
[same as prior period, unchanged from 0001032975-23-000007:mdna:140]

[0001032975-23-000066:mdna:129]
The provision for income taxes and effective income tax rates for the three months ended June 30, 2023 and 2022 were as follows (Dollars in thousands):

[0001032975-23-000066:mdna:130]
|  |  |  |  | Three months ended June 30, |
|  |  |  |  |  |  | 2023 |  | 2022 |
| Provision for income taxes |  |  |  |  |  | $ | 12,532 |  |  | $ | 21,716 |  |
| Effective income tax rate |  |  |  |  |  | 16.7 | % |  | 17.7 | % |

[0001032975-23-000066:mdna:131]
The change in the effective income tax rate for the three months ended June 30, 2023 was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate and the tax impact from share-based compensation in the period ended June 30, 2023.

[0001032975-23-000066:mdna:132]
[same as prior period, unchanged from 0001032975-23-000007:mdna:145]

[0001032975-23-000066:mdna:133]
[same as prior period, unchanged from 0001032975-23-000007:mdna:146]

[0001032975-23-000066:mdna:134]
As of June 30, 2023, we had cash and cash equivalents of $1,251.1 million, compared with $1,149.0 million as of March 31, 2023. Our cash and cash equivalents consist of bank demand deposits and short-term time deposits, of which 68% is held in Switzerland and 15% were held in China (including Hong Kong). We do not expect to incur any material adverse tax impact except for what has already been recognized, or to be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our country of domicile.

[0001032975-23-000066:mdna:135]
As of June 30, 2023, our working capital was $1,540.5 million, compared to $1,555.1 million as of March 31, 2023. The decrease was driven by the decreases in inventories, accounts receivable, net, and other current assets, partially offset by an increase in cash balances as well as decreases in accrued and other current liabilities and accounts payable.

[0001032975-23-000066:mdna:136]
We had several uncommitted, unsecured bank lines of credit and letters of credit aggregating $172.0 million as of June 30, 2023. There are no financial covenants under these lines of credit with which we must comply. As of June 30, 2023, we had outstanding bank guarantees of $9.2 million under these lines of credit.

[0001032975-23-000066:mdna:137]
The following tables present selected financial information and statistics as of and for the three months ended June 30, 2023 and 2022 (Dollars in thousands):

[0001032975-23-000066:mdna:138]
|  |  | As of June 30, |  |
|  |  | 2023 |  | 2022 |  |
| Accounts receivable, net |  | $ | 562,602 |  |  | $ | 706,886 |  |  |
| Accounts payable |  | $ | 386,599 |  |  | $ | 558,983 |  |  |
| Inventories |  | $ | 572,344 |  |  | $ | 917,356 |  |  |

[0001032975-23-000066:mdna:139]
|  |  | Three months ended June 30, |  |
|  |  | 2023 |  | 2022 |  |
| Days sales in accounts receivable (“DSO”) (Days)(1) |  | 52 |  |  | 55 |  |  |
| Days accounts payable outstanding (“DPO”) (Days)(2) |  | 58 |  |  | 72 |  |  |
| Inventory turnover (“ITO”) (x)(3) |  | 4.2 |  |  | 3.1 |  |  |

[0001032975-23-000066:mdna:140]
[same as prior period, unchanged from 0001032975-23-000007:mdna:153]

[0001032975-23-000066:mdna:141]
[same as prior period, unchanged from 0001032975-23-000007:mdna:154]

[0001032975-23-000066:mdna:142]
[same as prior period, unchanged from 0001032975-23-000007:mdna:155]

[0001032975-23-000066:mdna:143]
DSO for the three months ended June 30, 2023 decreased by 3 days to 52 days, compared to 55 days for the three months ended June 30, 2022, primarily due to the timing of sales within the quarter.

[0001032975-23-000066:mdna:144]
DPO for the three months ended June 30, 2023 decreased by 14 days, compared to 72 days for the three months ended June 30, 2022, primarily due to lower inventory purchases resulting from softened demand as well as lower marketing spend.

[0001032975-23-000066:mdna:145]
ITO for the three months ended June 30, 2023 increased by 1.1, compared to 3.1 for the three months ended June 30, 2022, primarily due to lower inventory balance as of June 30, 2023, partially offset by softened demand.

[0001032975-23-000066:mdna:146]
[same as prior period, unchanged from 0001032975-23-000007:mdna:159]

[0001032975-23-000066:mdna:147]
[same as prior period, unchanged from 0001032975-23-000007:mdna:160]

[0001032975-23-000066:mdna:148]
|  |  | Three months ended June 30, |
|  |  | 2023 |  | 2022 |
| Net cash provided by (used in) operating activities |  | $ | 239,795 |  |  | $ | (35,668) |  |
| Net cash used in investing activities |  | (17,530) |  |  | (27,469) |  |
| Net cash used in financing activities |  | (117,159) |  |  | (144,763) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (3,043) |  |  | (14,159) |  |
| Net increase (decrease) in cash and cash equivalents |  | $ | 102,063 |  |  | $ | (222,059) |  |

[0001032975-23-000066:mdna:149]
For the three months ended June 30, 2023, net cash provided by operating activities was $239.8 million resulting from net income of $62.7 million, a favorable impact from adding back non-cash expenses totaling $59.6 million, and a favorable net change in operating assets and liabilities of $117.4 million. Non-cash expenses were primarily related to depreciation and amortization and share-based compensation expenses. The decrease in accounts receivable, net was primarily driven by lower sales and the timing of sales within the quarter. The decrease in inventories was primarily driven by a reduction in inventory purchases to align with lower demand. The decrease in accrued and other liabilities was primarily driven by reduction in accrued Customer Program liabilities and payment of personnel related liabilities.

[0001032975-23-000066:mdna:150]
For the three months ended June 30, 2023, net cash used in investing activities was $17.5 million, primarily resulting from $16.2 million of purchases of property, plant, and equipment.

[0001032975-23-000066:mdna:151]
For the three months ended June 30, 2023, net cash used in financing activities was $117.2 million, primarily resulting from repurchases of our registered shares of $95.1 million and tax withholdings related to net share settlements of restricted stock units of $24.2 million.

[0001032975-23-000066:mdna:152]
For the three months ended June 30, 2023, there was a $3.0 million loss from currency exchange rate effect on cash and cash equivalents, primarily due to exchange rate fluctuations of Chinese Renminbi and Euro versus the U.S. Dollar and timing of our cash transactions over the period. The loss from currency translation exchange rate effect during the three months ended June 30, 2022 was primarily due to the weakening of the Euro, Chinese Renminbi, Swiss Franc, Australian Dollar versus the U.S. Dollar by 6%, 5%, 4%, and 10%, respectively.

[0001032975-23-000066:mdna:153]
[same as prior period, unchanged from 0001032975-23-000007:mdna:166]

[0001032975-23-000066:mdna:154]
Our principal sources of liquidity are our cash and cash equivalents, cash flow generated from operations and, to a much lesser extent, capital markets and borrowings. Our future working capital requirements and capital expenditures may increase to support investments in product innovations and growth opportunities or to acquire or invest in complementary businesses, products, services, and technologies. Market volatility driven by the current macroeconomic and geopolitical environment may increase our costs of capital and otherwise adversely affect our business, results of operations, financial condition and liquidity.

[0001032975-23-000066:mdna:155]
In May 2023, our Board of Directors recommended that we pay cash dividends for fiscal year 2023 of CHF 1.06 per share (approximately $1.16 per share based on the exchange rate on March 31, 2023). Based on our shares outstanding, net of treasury shares, as of March 31, 2023 (159,343,273 shares), this would result in an aggregate gross dividend of approximately CHF 168.9 million (approximately $184.2 million based on the exchange rate on March 31, 2023). In fiscal year 2023, we paid a cash dividend of CHF 156.1 million (U.S. Dollar amount of $158.7 million based on the exchange rate on the date of payment) out of fiscal year 2022 retained earnings. In fiscal year 2022, we paid a cash dividend of CHF 147.0 million (U.S. Dollar amount of $159.4 million) out of fiscal year 2021 retained earnings.

[0001032975-23-000066:mdna:156]
In May 2020, our Board of Directors approved a share repurchase program, which authorized us to invest up to $250.0 million to purchase our own shares. In April 2021, our Board of Directors approved an increase of $750.0 million to the 2020 share repurchase program, to an aggregate amount of $1.0 billion. The Swiss Takeover Board approved this increase and it became effective on May 21, 2021. In July 2022, our Board of Directors approved an increase of $500 million to the 2020 share repurchase program to an aggregate amount of up to $1.5 billion. The Swiss Takeover Board approved this increase and it became effective on August 19, 2022. As of June 30, 2023, $411.0 million was available for repurchase under the 2020 repurchase program. The 2020 share repurchase program expired on July 27, 2023.

[0001032975-23-000066:mdna:157]
In June 2023, our Board of Directors approved a new, three-year share repurchase program, which allows us to use up to $1.0 billion to repurchase our shares. The Swiss Takeover Board approved the 2023 share repurchase program in July 2023 and the program will become effective on July 28, 2023. Swiss law limits a company’s ability to hold or repurchase its own shares. Generally, the aggregate par value of all shares held by the company and its subsidiaries may not exceed 10% of the registered share capital of the company, which for Logitech corresponds to 17.3 million shares.

[0001032975-23-000066:mdna:158]
Although we enter into trading plans for systematic repurchases (e.g., 10b5-1 trading plans) from time to time, our 2023 share repurchase program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years through July 27, 2026. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.

[0001032975-23-000066:mdna:159]
[same as prior period, unchanged from 0001032975-23-000007:mdna:171]

[0001032975-23-000066:mdna:160]
[same as prior period, unchanged from 0001032975-23-000007:mdna:172]

[0001032975-23-000066:mdna:161]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. There have been no material changes to our contractual obligations as previously disclosed in our Annual Report on Form 10-K for the year ended March 31, 2023. The remaining terms of our non-cancelable operating leases expire in various years through 2033.

[0001032975-23-000066:mdna:162]
[same as prior period, unchanged from 0001032975-23-000007:mdna:174]

[0001032975-23-000066:mdna:163]
As of June 30, 2023, we had non-cancelable purchase commitments of $357.3 million for inventory purchases made in the normal course of business from original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. We recorded a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with our valuation of excess and obsolete inventory. As of June 30, 2023, the liability for these purchase commitments was $39.5 million and is recorded in accrued and other current liabilities in the condensed consolidated balance sheet.

[0001032975-23-000066:mdna:164]
We have firm purchase commitments of $11.8 million for capital expenditures primarily related to commitments for tooling and equipment for new and existing products and commitments to vendors to fit out and furnish office facilities. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-23-000066:mdna:165]
[same as prior period, unchanged from 0001032975-23-000007:mdna:177]

[0001032975-23-000066:mdna:166]
For further detail about our contractual obligations and commitments, refer to our Annual Report on Form 10-K for the fiscal year ended March 31, 2023.

[0001032975-23-000066:mdna:167]
[same as prior period, unchanged from 0001032975-23-000007:mdna:179]

[0001032975-23-000066:mdna:168]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2023, no material amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-23-000066:mdna:169]
We also indemnify our current and former directors and certain current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. We are unable to

[0001032975-23-000066:mdna:170]
reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not capped, the obligations are conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-23-000066:mdna:171]
Legal Proceedings

[0001032975-23-000066:mdna:172]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of our business. For more information about Legal Proceedings, see Part II Item 1 Legal Proceedings of this quarterly report on Form 10-Q for the period ended June 30, 2023.

[0001032975-23-000066:mdna:173]
33
