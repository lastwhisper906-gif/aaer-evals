# LOGI notes — 0001104659-14-081027


## us-gaap:ConsolidationPolicyTextBlock

[0001104659-14-081027:notes:1]
Basis of Presentation

[0001104659-14-081027:notes:2]
The consolidated interim financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (“GAAP”) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. They should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2014, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (“SEC”) on November 13, 2014.  In the opinion of management, these consolidated financial statements include all adjustments, consisting of normal recurring adjustments, necessary for a fair statement of the results for the periods presented. Operating results for the three months ended June 30, 2014 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2015, or any future periods.


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001104659-14-081027:notes:3]
The computations of basic and diluted net income per share for the Company were as follows (in thousands, except per share amounts):

[0001104659-14-081027:notes:4]
|  |  | Three Months Ended |  |
|  |  | June 30, |  |
|  |  | 2014 |  | 2013 |  |
| Net income |  | $ | 19,676 |  | $ | 1,226 |  |
| Shares used in net income per share computation: |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 163,012 |  | 159,298 |  |
| Effect of potentially dilutive equivalent shares |  | 2,821 |  | 983 |  |
| Weighted average shares outstanding - diluted |  | 165,833 |  | 160,281 |  |
| Net income per share: |  |  |  |  |  |
| Basic |  | $ | 0.12 |  | $ | 0.01 |  |
| Diluted |  | $ | 0.12 |  | $ | 0.01 |  |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0001104659-14-081027:notes:5]
The following table summarizes the share-based compensation expense and related tax benefit recognized for the three months ended June 30, 2014 and 2013 (in thousands):

[0001104659-14-081027:notes:6]
|  |  | Three Months Ended |  |
|  |  | June 30, |  |
|  |  | 2014 |  | 2013 |  |
| Cost of goods sold |  | $ | 538 |  | $ | 577 |  |
| Marketing and selling |  | 2,556 |  | 1,906 |  |
| Research and development |  | 844 |  | 1,094 |  |
| General and administrative |  | 3,000 |  | 813 |  |
| Total share-based compensation expense |  | 6,938 |  | 4,390 |  |
| Income tax benefit |  | (1,184 | ) | (875 | ) |
| Total share-based compensation expense, net of income tax |  | $ | 5,754 |  | $ | 3,515 |  |


## us-gaap:ScheduleOfFairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0001104659-14-081027:notes:7]
The following table presents the Company’s financial assets and liabilities, that were accounted for at fair value, excluding assets related to the Company’s defined benefit pension plans, classified by the level within the fair value hierarchy (in thousands):

[0001104659-14-081027:notes:8]
|  |  | June 30, 2014 |  | March 31, 2014 |  |
|  |  | Level 1 |  | Level 2 |  | Level 1 |  | Level 2 |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | 194,962 |  | — |  | 200,641 |  | — |  |
|  |  | $ | 194,962 |  | $ | — |  | $ | 200,641 |  | $ | — |  |
| Trading investments for deferred compensation plan: |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 3,237 |  | $ | — |  | $ | 3,139 |  | $ | — |  |
| Mutual funds |  | 14,322 |  | — |  | 13,472 |  | — |  |
|  |  | $ | 17,559 |  | $ | — |  | $ | 16,611 |  | $ | — |  |
| Foreign exchange derivative assets |  | $ | — |  | $ | 179 |  | $ | — |  | $ | 155 |  |
| Foreign exchange derivative liabilities |  | $ | — |  | $ | 287 |  | $ | — |  | $ | 701 |  |


## us-gaap:ScheduleOfDerivativeInstrumentsInStatementOfFinancialPositionFairValueTextBlock

[0001104659-14-081027:notes:9]
The following table presents the fair values of the Company’s derivative instruments and their locations on its Consolidated Balance Sheets as of June 30, 2014 and March 31, 2014 (in thousands):

[0001104659-14-081027:notes:10]
|  |  | Derivatives |  |
|  |  | Asset |  | Liability |  |
|  |  | June 30, |  | March 31, |  | June 30, |  | March 31, |  |
|  |  | 2014 |  | 2014 |  | 2014 |  | 2014 |  |
| Designed as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Cash flow hedges |  | $ | 40 |  | $ | 4 |  | $ | 3 |  | $ | 243 |  |
| Not designed as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | 139 |  | 151 |  | 284 |  | 458 |  |
|  |  | $ | 179 |  | $ | 155 |  | $ | 287 |  | $ | 701 |  |


## us-gaap:ScheduleOfDerivativeInstrumentsGainLossInStatementOfFinancialPerformanceTextBlock

[0001104659-14-081027:notes:11]
The following table presents the amounts of gains and losses on the Company’s derivative instruments for the three months ended June 30, 2014 and 2013 (in thousands):

[0001104659-14-081027:notes:12]
|  |  | Three Months Ended |  |
|  |  | June 30, |  |
|  |  | Amount of |  | Amount of Loss |  |  |  |  |  |
|  |  | Gain (Loss) Deferred as a |  | Reclassified from Accumulated |  | Amount of Gain (Loss) |  |
|  |  | Component of Accumulated |  | Other Comprehensive Income to |  | Immediately Recognized in |  |
|  |  | Other Comprehensive Income |  | Costs of Goods Sold |  | Other Income (Expense), Net |  |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  |
| Designed as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash flow hedges |  | $ | 648 |  | $ | (635 | ) | $ | 400 |  | $ | 278 |  | $ | (55 | ) | $ | 30 |  |
| Not designed as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | — |  | — |  | — |  | — |  | (419 | ) | 1,385 |  |
|  |  | $ | 648 |  | $ | (635 | ) | $ | 400 |  | $ | 278 |  | $ | (474 | ) | $ | 1,415 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001104659-14-081027:notes:13]
Changes in the Company’s warranty liability for the three months ended June 30, 2014 and 2013 were as follows (in thousands):

[0001104659-14-081027:notes:14]
|  |  | Three Months Ended |  |
|  |  | June 30, |  |
|  |  | 2014 |  | 2013 |  |
| Beginning of the period |  | $ | 24,380 |  | $ | 21,442 |  |
| Provision |  | 2,206 |  | 3,526 |  |
| Settlements |  | (3,166 | ) | (3,745 | ) |
| Adjustment (1) |  | — |  | 2,327 |  |
| End of the period |  | $ | 23,420 |  | $ | 23,550 |  |

[0001104659-14-081027:notes:15]
(1)     During the three month period June 30, 2013, the warranty liability allocated to the Company’s - Remotes product category was reclassified from liabilities held for sale.


## us-gaap:ScheduleOfGoodwillTextBlock

[0001104659-14-081027:notes:16]
The following table summarizes the activity in the Company’s goodwill balance during the three month ended June 30, 2014 (in thousands):

[0001104659-14-081027:notes:17]
|  |  | June 30, 2014 |  |
|  |  |  |  | Video |  |  |  |
|  |  | Peripherals |  | Conferencing |  | Total |  |
| Beginning of the period |  | $ | 219,415 |  | $ | 125,595 |  | $ | 345,010 |  |
| Foreign currency impact |  | — |  | (168 | ) | (168 | ) |
| End of the period |  | $ | 219,415 |  | $ | 125,427 |  | $ | 344,842 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001104659-14-081027:notes:18]
The components of accumulated other comprehensive loss was as follows (in thousands):

[0001104659-14-081027:notes:19]
|  |  | Accumulated Other Comprehensive Loss |  |
|  |  | Cumulative |  | Defined |  | Deferred |  |  |  |
|  |  | Translation |  | Benefit |  | Hedging |  |  |  |
|  |  | Adjustment |  | Plan (1) |  | Gains (Losses) |  | Total |  |
| March 31, 2014 |  | $ | (70,999 | ) | $ | (14,288 | ) | $ | (515 | ) | $ | (85,802 | ) |
| Other comprehensive income |  | 201 |  | 252 |  | 648 |  | 1,101 |  |
| June 30, 2014 |  | $ | (70,798 | ) | $ | (14,036 | ) | $ | 133 |  | $ | (84,701 | ) |

[0001104659-14-081027:notes:20]
(1)     Net of tax of $192 as of both June 30, 2014 and March 31, 2014.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001104659-14-081027:notes:21]
Net sales and operating income (loss) for the Company’s operating segments were as follows (in thousands):

[0001104659-14-081027:notes:22]
|  |  | Three Months Ended |  |
|  |  | June 30, |  |
|  |  | 2014 |  | 2013 |  |
| Net sales: |  |  |  |  |  |
| Peripherals |  | $ | 456,446 |  | $ | 448,355 |  |
| Video conferencing |  | 25,757 |  | 30,175 |  |
|  |  | $ | 482,203 |  | $ | 478,530 |  |
| Segment operating income (loss): |  |  |  |  |  |
| Peripherals (1) |  | $ | 33,567 |  | $ | 13,253 |  |
| Video conferencing (1) |  | (1,135 | ) | (3,368 | ) |
|  |  | 32,432 |  | 9,885 |  |
| Other income (expense): |  |  |  |  |  |
| Share-based compensation |  | (6,938 | ) | (4,390 | ) |
| Amortization of intangibles |  | (2,782 | ) | (5,264 | ) |
| Interest income (expense), net |  | 258 |  | (23 | ) |
| Other income (expense), net |  | (198 | ) | 217 |  |
| Income before income taxes |  | $ | 22,772 |  | $ | 425 |  |

[0001104659-14-081027:notes:23]
(1)     Peripherals operating results include $0 million and $2.3 million of restructuring charges during the three months ended June 30, 2014 and 2013, respectively. Video conferencing operating results did not include restructuring charges during the three months ended June 30, 2014 and 2013, respectively.


## logi:ScheduleOfRevenueByProductFamilyExcludingInterCompanyTransactionsTableTextBlock

[0001104659-14-081027:notes:24]
Net sales by product family, excluding intercompany transactions, were as follows (in thousands):

[0001104659-14-081027:notes:25]
|  |  | Three Months Ended |  |
|  |  | June 30, |  |
|  |  | 2014 |  | 2013 (1) |  |
| Peripherals: |  |  |  |  |  |
| PC Gaming |  | $ | 46,876 |  | $ | 40,213 |  |
| Tablet & Other Accessories |  | 31,716 |  | 38,559 |  |
| Mobile Speakers |  | 28,830 |  | 13,867 |  |
| Growth: |  | 107,422 |  | 92,639 |  |
| Pointing Devices |  | 113,042 |  | 114,651 |  |
| PC Keyboards & Desktops |  | 105,523 |  | 98,013 |  |
| Audio-PC &Wearables |  | 49,626 |  | 55,538 |  |
| Video |  | 34,576 |  | 30,940 |  |
| Remotes |  | 12,332 |  | 14,574 |  |
| Profit Maximization: |  | 315,099 |  | 313,716 |  |
| Other |  | 1,293 |  | 7,487 |  |
| Non-Strategic: |  | 1,293 |  | 7,487 |  |
| OEM |  | 32,632 |  | 34,513 |  |
|  |  | 456,446 |  | 448,355 |  |
| Video conferencing |  | 25,757 |  | 30,175 |  |
|  |  | $ | 482,203 |  | $ | 478,530 |  |

[0001104659-14-081027:notes:26]
(1)  Certain products within the retail product families presented in prior years have been reclassified to conform to the current year presentation.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001104659-14-081027:notes:27]
Net sales to unaffiliated customers by geographic region (based on the customers’ location) were as follows (in thousands):

[0001104659-14-081027:notes:28]
|  |  | Three Months Ended |  |
|  |  | June 30, |  |
|  |  | 2014 |  | 2013 |  |
| Americas |  | $ | 211,531 |  | $ | 201,059 |  |
| EMEA |  | 153,700 |  | 155,223 |  |
| Asia Pacific |  | 116,972 |  | 122,248 |  |
|  |  | $ | 482,203 |  | $ | 478,530 |  |


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001104659-14-081027:notes:29]
Long-lived assets by geographic region were as follows (in thousands):

[0001104659-14-081027:notes:30]
|  |  | June 30, |  | March 31, |  |
|  |  | 2014 |  | 2014 |  |
| Americas |  | $ | 47,343 |  | $ | 45,166 |  |
| EMEA |  | 4,753 |  | 5,154 |  |
| Asia Pacific |  | 37,870 |  | 38,071 |  |
|  |  | $ | 89,966 |  | $ | 88,391 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001104659-14-081027:notes:31]
[same as prior period, unchanged from 0001104659-14-005272:notes:33]

[0001104659-14-081027:notes:32]
Fiscal Year

[0001104659-14-081027:notes:33]
The Company’s fiscal year ends on March 31. Interim quarters are thirteen-week periods, each ending on a Friday.  For purposes of presentation, the Company has indicated its quarterly periods as ending on the month end.

[0001104659-14-081027:notes:34]
[same as prior period, unchanged from 0001104659-14-005272:notes:39]

[0001104659-14-081027:notes:35]
There have been no substantial changes in the Company’s significant accounting policies during the three months ended June 30, 2014 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2014.

[0001104659-14-081027:notes:36]
[same as prior period, unchanged from 0001104659-14-005272:notes:41]

[0001104659-14-081027:notes:37]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect reported amounts of assets, liabilities, net sales and expenses, and the disclosure of contingent assets and liabilities. Examples of significant estimates and assumptions made by management involve the fair value of goodwill, accruals for customer programs, inventory valuation, valuation allowances for deferred tax assets and warranty accruals. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ from those estimates.

[0001104659-14-081027:notes:38]
[same as prior period, unchanged from 0001104659-14-005272:notes:43]

[0001104659-14-081027:notes:39]
In May 2014, the FASB issued Accounting Standards Update No. 2014-09, “Revenue from Contracts with Customers (Topic 606),” (“ASU 2014-09”). ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. This new revenue recognition model provides a five-step analysis in determining when and how revenue is recognized. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The new standard will be effective for the Company beginning April 1, 2017.  Early application is prohibited.  The Company is currently evaluating the impact that adopting this new guidance will have on its consolidated financial statements.


## us-gaap:EarningsPerShareTextBlock

[0001104659-14-081027:notes:40]
Note 4 — Net Income per Share

[0001104659-14-081027:notes:41]
As of June 30, 2014 and 2013, 9,947,880 and 19,455,154 share equivalents attributable to outstanding stock options, RSUs, and ESPP were excluded from the calculation of diluted net income per share because to do so would have been anti-dilutive for the periods indicated.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001104659-14-081027:notes:42]
[same as prior period, unchanged from 0001104659-14-005272:notes:48]

[0001104659-14-081027:notes:43]
[same as prior period, unchanged from 0001104659-14-005272:notes:49]

[0001104659-14-081027:notes:44]
As of June 30, 2014, the Company offers the 2006 ESPP (2006 Employee Share Purchase Plan (Non-U.S.)), the 1996 ESPP (1996 Employee Share Purchase Plan (U.S.)), the 2006 Plan (2006 Stock Incentive Plan) and the 2012 Plan (2012 Stock Inducement Equity Plan). Please refer to our fiscal year 2014 Form 10-K for additional information regarding the Employee Share Purchase Plans and Stock Incentive Plans.

[0001104659-14-081027:notes:45]
During the three months ended June 30, 2014 and 2013, the Company capitalized $0.5 million and $0.4 million, respectively, of stock-based compensation expenses as inventory.

[0001104659-14-081027:notes:46]
[same as prior period, unchanged from 0001104659-14-005272:notes:54]

[0001104659-14-081027:notes:47]
Certain of the Company’s subsidiaries have defined contribution employee benefit plans covering all or a portion of their employees. Contributions to these plans are discretionary for certain plans and are based on specified or statutory requirements for others. The charges to expense for these plans for the three months ended June 30, 2014 and 2013 were $1.6 million and $1.7 million, respectively.

[0001104659-14-081027:notes:48]
[same as prior period, unchanged from 0001104659-14-005272:notes:56]

[0001104659-14-081027:notes:49]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations.  The cost recorded of $2.0 million and $3.0 million for the three months ended June 30, 2014 and 2013, respectively, was primarily related to service costs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001104659-14-081027:notes:50]
[same as prior period, unchanged from 0001104659-14-005272:notes:61]

[0001104659-14-081027:notes:51]
The Company is incorporated in Switzerland but operates in various countries with differing tax laws and rates. Further, a portion of the Company’s income (loss) before taxes and the provision for and (benefit from) income taxes are generated outside of Switzerland.

[0001104659-14-081027:notes:52]
The income tax provision for the three months ended June 30, 2014 was $3.1 million based on an effective income tax rate of 13.6% of pre-tax income, compared to an income tax benefit of $0.8 million based on an effective income tax rate of (188.5%) of pre-tax income for the three months ended June 30, 2013.  The change in the effective income tax rate for the three months ended June 30, 2014, compared to the three months ended June 30, 2013, was primarily due to the mix of income and losses in the various tax jurisdictions in which the Company operates.

[0001104659-14-081027:notes:53]
As of June 30 and March 31, 2014, the total amount of unrecognized tax benefits due to uncertain tax positions was $91.8 million and $91.0 million, respectively, of which $86.8 million and $86.1 million, respectively, would affect the effective income tax rate if recognized.

[0001104659-14-081027:notes:54]
As of June 30, 2014, the Company had $84.3 million in non-current income taxes payable and $0.3 million in current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions.  As of March 31, 2014, the Company had $93.1 million in non-current income taxes payable and $0.3 million in current income taxes payable.

[0001104659-14-081027:notes:55]
During the quarter ended June 30, 2014, the Company adopted ASU No. 2013-11 “Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists.”  ASU No. 2013-11 requires an unrecognized tax benefit, or a portion of an unrecognized tax benefit, to be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward, except to the extent a net operating loss carryforward, a similar tax loss, or a tax credit carryforward is not available at the reporting date under the tax law of the applicable jurisdiction to settle any additional income taxes that would result from the disallowance of a tax position or the tax law of the applicable jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose.  In that case, the unrecognized tax benefit should be presented in the financial statements as a liability instead and should not be netted with the deferred tax asset.  This accounting standard became effective for the Company on April 1, 2014 and was applied prospectively to unrecognized tax benefits that existed as of the effective date.  Upon adoption of this guidance, the Company netted $9.8 million of unrecognized tax benefits previously presented as non-current income taxes payable as a reduction to non-current deferred tax assets for tax credit carryforwards.

[0001104659-14-081027:notes:56]
The Company continues to recognize interest and penalties related to unrecognized tax positions in income tax expense. As of June 30 and March 31, 2014, the Company had $5.7 million and $5.6 million, respectively, of accrued interest and penalties related to uncertain tax positions, respectively.

[0001104659-14-081027:notes:57]
The Company files Swiss and foreign tax returns. For all these tax returns, the Company is generally not subject to tax examinations for years prior to fiscal year 2001. The Company is under examination and has received assessment notices in other tax jurisdictions. At this time, the Company is not able to estimate the potential impact that these examinations may have on its income tax expense. If the examinations are resolved unfavorably, there is a possibility they may have a material negative impact on the Company’s results of operations.

[0001104659-14-081027:notes:58]
Although the Company has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During fiscal year 2015, the Company will continue to review its tax positions and provide for or reverse unrecognized tax benefits as issues arise. During the next 12 months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. dollar as compared to foreign currencies. Excluding these factors, uncertain tax positions may decrease by as much as $15.0 million to $17.3 million primarily from the lapse of the statutes of limitations in various jurisdictions during the next 12 months.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001104659-14-081027:notes:59]
Note 7— Balance Sheet Components

[0001104659-14-081027:notes:60]
The following table presents the components of certain balance sheet asset amounts as of June 30, 2014 and March 31, 2014 (in thousands):

[0001104659-14-081027:notes:61]
|  |  | June 30, |  | March 31, |  |
|  |  | 2014 |  | 2014 |  |
| Accounts receivable: |  |  |  |  |  |
| Accounts receivable |  | $ | 387,502 |  | $ | 338,194 |  |
| Allowance for doubtful accounts |  | (1,657 | ) | (1,712 | ) |
| Allowance for sales returns |  | (17,301 | ) | (19,472 | ) |
| Allowance for cooperative marketing arrangements |  | (31,928 | ) | (24,135 | ) |
| Allowance for customer incentive programs |  | (45,116 | ) | (41,400 | ) |
| Allowance for pricing programs |  | (72,478 | ) | (69,446 | ) |
|  |  | $ | 219,022 |  | $ | 182,029 |  |
| Inventories: |  |  |  |  |  |
| Raw materials |  | $ | 22,194 |  | $ | 24,031 |  |
| Work-in-process |  | 31 |  | 42 |  |
| Finished goods |  | 218,132 |  | 198,329 |  |
|  |  | $ | 240,357 |  | $ | 222,402 |  |
| Other current assets: |  |  |  |  |  |
| Income tax and value-added tax receivables |  | $ | 16,908 |  | $ | 18,252 |  |
| Deferred tax assets |  | 29,410 |  | 27,013 |  |
| Prepaid expenses and other assets |  | 17,100 |  | 13,892 |  |
|  |  | $ | 63,418 |  | $ | 59,157 |  |
| Property, plant and equipment, net: |  |  |  |  |  |
| Plant, buildings and improvements |  | $ | 71,039 |  | $ | 69,897 |  |
| Equipment |  | 138,396 |  | 134,975 |  |
| Computer equipment |  | 40,182 |  | 40,610 |  |
| Software |  | 81,210 |  | 81,179 |  |
|  |  | 330,827 |  | 326,661 |  |
| Less accumulated depreciation and amortization |  | (263,116 | ) | (256,424 | ) |
|  |  | 67,711 |  | 70,237 |  |
| Construction-in-process |  | 19,430 |  | 15,362 |  |
| Land |  | 2,825 |  | 2,792 |  |
|  |  | $ | 89,966 |  | $ | 88,391 |  |
| Other assets: |  |  |  |  |  |
| Deferred tax assets |  | $ | 41,648 |  | $ | 52,883 |  |
| Trading investments |  | 17,559 |  | 16,611 |  |
| Other assets |  | 5,960 |  | 4,966 |  |
|  |  | $ | 65,167 |  | $ | 74,460 |  |

[0001104659-14-081027:notes:62]
The following table presents the components of certain balance sheet liability amounts as of June 30, 2014 and March 31, 2014 (in thousands):

[0001104659-14-081027:notes:63]
|  |  | June 30, |  | March 31, |  |
|  |  | 2014 |  | 2014 |  |
| Accrued and other current liabilities: |  |  |  |  |  |
| Accrued personnel expenses |  | $ | 55,386 |  | $ | 55,165 |  |
| Accrued marketing expenses |  | 13,456 |  | 12,844 |  |
| Indirect customer incentive programs |  | 30,592 |  | 31,737 |  |
| Accrued restructuring |  | 2,033 |  | 2,121 |  |
| Deferred revenue |  | 21,500 |  | 22,529 |  |
| Accrued freight and duty |  | 6,845 |  | 6,276 |  |
| Value-added taxes payable |  | 7,289 |  | 9,354 |  |
| Accrued royalties |  | 2,266 |  | 2,653 |  |
| Warranty accrual |  | 13,338 |  | 13,905 |  |
| Employee benefit plan obligation |  | 1,129 |  | 1,100 |  |
| Income taxes payable |  | 5,556 |  | 7,701 |  |
| Other current liabilities |  | 53,697 |  | 46,587 |  |
|  |  | $ | 213,087 |  | $ | 211,972 |  |
| Non-current liabilities: |  |  |  |  |  |
| Warranty accrual |  | $ | 10,082 |  | $ | 10,475 |  |
| Obligation for deferred compensation |  | 17,559 |  | 16,611 |  |
| Long term restructuring |  | 5,065 |  | 5,440 |  |
| Employee benefit plan obligation |  | 37,859 |  | 37,899 |  |
| Deferred rent |  | 15,239 |  | 15,555 |  |
| Deferred tax liability |  | 2,174 |  | 2,304 |  |
| Long term deferred revenue |  | 10,211 |  | 9,350 |  |
| Other non-current liabilities |  | 1,727 |  | 1,715 |  |
|  |  | $ | 99,916 |  | $ | 99,349 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001104659-14-081027:notes:64]
Note 8— Fair Value Measurements

[0001104659-14-081027:notes:65]
[same as prior period, unchanged from 0001104659-14-005272:notes:79]

[0001104659-14-081027:notes:66]
The Company considers fair value as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants at the measurement date. The Company uses the following three-level fair value hierarchy to establish the priorities of the inputs used to measure fair value:

[0001104659-14-081027:notes:67]
·          Level 1 — Quoted prices in active markets for identical assets or liabilities.

[0001104659-14-081027:notes:68]
·          Level 2 — Observable inputs other than quoted market prices included in Level 1, such as quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active; or other inputs that are observable or can be corroborated by observable market data.

[0001104659-14-081027:notes:69]
·          Level 3 — Unobservable inputs that are supported by little or no market activity and that are significant to the fair value of the assets or liabilities. This includes certain pricing models, discounted cash flow methodologies and similar techniques that use significant unobservable inputs.

[0001104659-14-081027:notes:70]
There were no significant Level 3 financial assets during the three months ended June 30, 2014 and March 31, 2014.

[0001104659-14-081027:notes:71]
Cash and Cash Equivalents

[0001104659-14-081027:notes:72]
[same as prior period, unchanged from 0001104659-14-005272:notes:85]

[0001104659-14-081027:notes:73]
[same as prior period, unchanged from 0001104659-14-005272:notes:86]

[0001104659-14-081027:notes:74]
The Company’s investment securities portfolio consists of marketable securities (money market and mutual funds) related to a deferred compensation plan at June 30, 2014 and March 31, 2014.

[0001104659-14-081027:notes:75]
The marketable securities related to the deferred compensation plan are classified as non-current other assets. Since participants in the deferred compensation plan may select the mutual funds in which their compensation deferrals are invested within the confines of the Rabbi Trust, which holds the marketable securities, the Company has designated these marketable securities as trading investments, although there is no intent to actively buy and sell securities within the objective of generating profits on short-term difference in market prices. Management has classified the investments as non-current assets because final sale of the investments or realization of proceeds by plan participants is not expected within the Company’s normal operating cycle of one year. The marketable securities are recorded at a fair value of $17.6 million and $16.6 million as of June 30 and March 31, 2014, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Earnings, gains and losses on trading investments are included in other income (expense), net.

[0001104659-14-081027:notes:76]
[same as prior period, unchanged from 0001104659-14-005272:notes:89]

[0001104659-14-081027:notes:77]
Under the agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company does not net settle transactions with a single net amount payable by one party to the other. In accordance with ASU 2011-11, the Company presents its derivative instruments at gross fair values in the Consolidated Balance Sheets as of June 30, 2014 and March 31, 2014.

[0001104659-14-081027:notes:78]
[same as prior period, unchanged from 0001104659-14-005272:notes:90]

[0001104659-14-081027:notes:79]
The Company enters into foreign exchange forward contracts to hedge against exposure to changes in foreign currency exchange rates related to its subsidiaries’ forecasted inventory purchases. The Company has one entity with a euro functional currency that purchases inventory in U.S. dollars. The primary risk managed by using derivative instruments is the foreign currency exchange rate risk. The Company has designated these derivatives as cash flow hedges. The Company does not use derivative financial instruments for trading or speculative purposes. These hedging contracts mature within four months, and are denominated in the same currency as the underlying transactions. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. The Company assesses the effectiveness of the hedges by comparing changes in the spot rate of the currency underlying the forward contract with changes in the spot rate of the currency in which the forecasted transaction will be consummated. If the underlying transaction being hedged fails to occur or if a portion of the hedge does not generate offsetting changes in the foreign currency exposure of forecasted inventory purchases, the Company immediately recognizes the gain or loss on the associated financial instrument in other income (expense), net. Such gains and losses were immaterial during the three months ended June 30, 2014 and 2013. Cash flows from such hedges are classified as operating activities in the consolidated statements of cash flows. The notional amounts of foreign exchange forward contracts outstanding related to forecasted inventory purchases were $57.9 million (€42.5 million) and $51.8 million (€37.6 million) at June 30, 2014 and March 31, 2014. The notional amount represents the future cash flows under contracts to purchase foreign currencies.

[0001104659-14-081027:notes:80]
[same as prior period, unchanged from 0001104659-14-005272:notes:92]

[0001104659-14-081027:notes:81]
[same as prior period, unchanged from 0001104659-14-005272:notes:93]

[0001104659-14-081027:notes:82]
The notional amounts of foreign exchange forward contracts outstanding at June 30, 2014 and March 31, 2014 relating to foreign currency receivables or payables were $16.9 million and $23.2 million. Open forward contracts as of June 30, 2014 consisted of contracts in U.S. dollars to purchase Taiwanese dollars and contracts in euros to sell British pounds at future dates at pre-determined exchange rates. Open forward contracts as of March 31, 2014 consisted of contracts in U.S. dollars to purchase Taiwanese Dollars and contracts in euros to sell British pounds at future dates at pre-determined exchange rates. The notional amounts of foreign exchange swap contracts outstanding at June 30, 2014 and March 31, 2014 were $26.9 million and $30.5 million. Swap contracts outstanding at June 30, 2014 consisted of contracts in Mexican pesos, Japanese yen and Australian dollars. Swap contracts outstanding at March 31, 2014 consisted of contracts in Mexican pesos, Japanese yen and Australian dollars.

[0001104659-14-081027:notes:83]
The fair value of all foreign exchange forward contracts and foreign exchange swap contracts is determined based on observable market transactions of spot currency rates and forward rates. Cash flows from these contracts are classified as operating activities in the Consolidated Statements of Cash Flows.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001104659-14-081027:notes:84]
[same as prior period, unchanged from 0001104659-14-005272:notes:96]

[0001104659-14-081027:notes:85]
[same as prior period, unchanged from 0001104659-14-005272:notes:97]

[0001104659-14-081027:notes:86]
[same as prior period, unchanged from 0001104659-14-005272:notes:98]

[0001104659-14-081027:notes:87]
FASB ASC 350-20 permits an entity to make a qualitative assessment of whether it is more likely than not that a reporting unit’s fair value is less than its carrying amount before applying the two-step goodwill impairment test. If an entity concludes that it is not more likely than not that the fair value of a reporting unit is less than its carrying amount, it would not be required to perform the two-step impairment test for that reporting unit.

[0001104659-14-081027:notes:88]
There have been no events or circumstances during the three months ended June 30, 2014 that have required the Company to perform an interim assessment of goodwill.

[0001104659-14-081027:notes:89]
Determining the fair value of a reporting unit is judgmental in nature and requires the use of significant estimates and assumptions, including revenue growth rates, operating margins, discount rates and future market conditions, among others. It is reasonably possible that changes in the judgments, assumptions and estimates that the Company used in assessing the fair value of the video conferencing reporting unit result in the goodwill to become impaired. A goodwill impairment charge would have the effect of decreasing the Company’s earnings or increasing its losses in such period.

[0001104659-14-081027:notes:90]
For the three months ended June 30, 2014 and 2013, amortization expense for other intangible assets was $2.8 million and $5.3 million, respectively. The Company expects that amortization expense for the remaining nine months of fiscal year 2015 will be $5.6 million, and annual amortization expense for fiscal years 2016 and 2017 will be $1.9 million and $0.2 million, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001104659-14-081027:notes:91]
Note 10— Financing Arrangements

[0001104659-14-081027:notes:92]
The Company had several uncommitted, unsecured bank letters of credit aggregating $40 million as of June 30, 2014. There are no financial covenants under these letters of credit with which the Company must comply.  As of June 30, 2014, the Company had outstanding bank guarantees of $8.3 million under these letters of credit. The Company also had credit lines related to corporate credit cards totaling $6.9 million as of June 30, 2014. There are no financial covenants under these credit lines.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001104659-14-081027:notes:93]
Note 11 — Commitments and Contingencies

[0001104659-14-081027:notes:94]
Product Warranties

[0001104659-14-081027:notes:95]
All of the Company’s peripherals products are covered by warranty to be free from defects in material and workmanship for periods ranging from one year to five years. At the time of sale, the Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. The Company’s estimate of costs to fulfill its warranty obligations is based on historical experience and expectations of future conditions. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly.

[0001104659-14-081027:notes:96]
Purchase Commitments

[0001104659-14-081027:notes:97]
Commitments for inventory purchases are made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers and are expected to be fulfilled by September 30, 2014. Operating expense commitments are for consulting services, marketing arrangements, advertising, outsourced customer services, information technology maintenance and support services, and other services. Fixed purchase commitments for capital expenditures primarily related to commitments for computer hardware and leasehold improvements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the Company the option to reschedule and adjust its requirements based on the business needs prior to delivery of goods or performance of services. As of June 30, 2014, the Company’s outstanding purchase commitments had not materially changed since March 31, 2014.

[0001104659-14-081027:notes:98]
Other Contingencies

[0001104659-14-081027:notes:99]
The Company is subject to an ongoing formal investigation by the SEC, relating to issues including the accounting for Revue inventory valuation reserves that resulted in the restatement described in the Fiscal 2014 Form 10-K, revision to the Company’s financial statements concerning warranty accruals and amortization of intangible assets presented in the Company's Form 10-K/A, filed on August 7, 2013, and the Company’s transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. The Company is cooperating with the SEC in its ongoing investigation. The Company has entered into an agreement with the SEC to extend the statute of limitations. The Company cannot predict the outcome of the investigation at this time and any potential fines or penalties, if any, that may arise from the investigation are currently not estimable.

[0001104659-14-081027:notes:100]
Guarantees

[0001104659-14-081027:notes:101]
Logitech International S.A., the parent holding company, has issued several parent guarantees on behalf of its subsidiaries. The maximum potential future payment under the guarantee arrangements is limited to $80.0 million. As of June 30, 2014, there were no purchase obligations outstanding for which the parent holding company was required to guarantee payment.

[0001104659-14-081027:notes:102]
Logitech Europe S.A., a subsidiary of the parent holding company, has guaranteed the purchase obligations of another Logitech subsidiary under a guarantee agreement. This guarantee does not specify a maximum amount. As of June 30, 2014, the amount of purchase obligations outstanding under this guarantee was immaterial. In addition, Logitech Europe S.A. also guaranteed payments of a third-party contract manufacturer’s purchase obligations. As of June 30, 2014, the maximum amount of this guarantee was $3.5 million, of which $2.3 million of guaranteed purchase obligations were outstanding.

[0001104659-14-081027:notes:103]
Indemnifications

[0001104659-14-081027:notes:104]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2014, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001104659-14-081027:notes:105]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001104659-14-081027:notes:106]
Legal Proceedings

[0001104659-14-081027:notes:107]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001104659-14-081027:notes:108]
Note 12— Shareholders’ Equity

[0001104659-14-081027:notes:109]
In March 2014, the Company’s Board of Directors approved a new share buyback program, which authorizes the Company to use up to $250.0 million to purchase its own shares. The Company’s share buyback program is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.

[0001104659-14-081027:notes:110]
There were no share repurchases during the three months ended June 30, 2014 and 2013.  During the three months ended June 30, 2014, the Company was not current with its periodic reports required to be filed with the SEC and therefore lost its ability to buy back shares. The Company will regain its ability, once it is current with its SEC filings.

[0001104659-14-081027:notes:111]
[same as prior period, unchanged from 0001104659-14-005272:notes:157]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001104659-14-081027:notes:112]
[same as prior period, unchanged from 0001104659-14-005272:notes:158]

[0001104659-14-081027:notes:113]
The Company has two reporting segments, peripherals and video conferencing, based on product markets and internal organizational structure. The peripherals segment encompasses the design, manufacturing and marketing of peripherals for PCs, tablets and other digital platforms. The video conferencing segment encompasses the design, manufacturing and marketing of Lifesize video conferencing products, infrastructure and services for the enterprise, public sector and other business markets. The Company’s reporting segments do not record revenue on sales between segments as such sales are not material.

[0001104659-14-081027:notes:114]
Operating performance measures for the peripherals segment and the video conferencing segment are reported separately to Logitech’s Chief Executive Officer (“CEO”), who is considered to be the Company’s Chief Operating Decision Maker (“CODM”). The CEO periodically reviews information such as net sales and operating income (loss) for each operating segment to make business decisions. These operating performance measures do not include share-based compensation expense and amortization of intangible assets. Share-based compensation expense and amortization of intangible assets are presented in the following financial information by operating segment as “other income (expense), net.” Assets by operating segment are not presented since the Company does not present such data to the CODM.

[0001104659-14-081027:notes:115]
(1)     Peripherals operating results include $0 million and $2.3 million of restructuring charges during the three months ended June 30, 2014 and 2013, respectively. Video conferencing operating results include $0 million and $0 million of restructuring charges during the three months ended June 30, 2014 and 2013, respectively.

[0001104659-14-081027:notes:116]
Sales are attributed to countries on the basis of the customers’ locations. The United States represented 37% and 36% of the Company’s total consolidated net sales for the three months ended June 30, 2014 and 2013, respectively. China represented 11% of the Company’s total consolidated net sales for the three months ended June 30, 2013. No other single country represented more than 10% of the Company’s total consolidated net sales during those periods. Revenues from sales to customers in Switzerland, the Company’s home domicile, represented 2% and 1% of the Company’s total consolidated net sales for the three months ended June 30, 2014 and 2013, respectively.  One customer group of the Company’s peripheral operating segment represented 15% and 13% of sales for the three months ended June 30, 2014 and 2013, respectively.  No other customers represented greater than 10% of sales for the three months ended June 30, 2014 and 2013.

[0001104659-14-081027:notes:117]
Long-lived assets in the United States and China were $47.1 million and $32.0 million, respectively at June 30, 2014 and $44.9 million and $31.9 million, respectively at March 31, 2014. No other countries represented more than 10% of the Company’s total consolidated long-lived assets at June 30, 2014 and March 31, 2014. Long-lived assets in Switzerland, the Company’s home domicile, were $1.7 million and $1.6 million at June 30, 2014 and March 31, 2014, respectively.


## us-gaap:AccountingChangesAndErrorCorrectionsTextBlock

[0001104659-14-081027:notes:118]
Note 2 — Revision of Previously-Issued Financial Statements

[0001104659-14-081027:notes:119]
As disclosed in the Company’s Annual Report on Form 10-K for the year ended March 31, 2014 and in the audited consolidated financial statements contained therein, the Company has restated and revised its financial statements for the fiscal years ended March 31, 2012 and 2013, respectively. The impact of the adjustments also immaterially impact the financial statements for the first three quarters of the fiscal year ended March 31, 2014 as previously included in the Company’s quarterly reports on Form 10-Q for Fiscal 2014. The financial statements for three months ended June 30, 2013 included in this Form 10-Q are revised as described below for those adjustments and should be read in conjunction with Item 8, “Financial Statements and Supplementary Data” disclosed in the Company’s Annual Report on Form 10-K for the fiscal year ended March 31, 2014, filed with the SEC on November 13, 2014.

[0001104659-14-081027:notes:120]
The adjustments included in these financial statements for the three months ended June 30, 2013 primarily related to a correction to revenue that was previously recorded as an out-of-period adjustment and is now being reported in the correct period, capitalization of property, plant and equipment which was previously incorrectly expensed, other misstatements, and the tax impact of these adjustments.

[0001104659-14-081027:notes:121]
Consolidated Statement of Operations.

[0001104659-14-081027:notes:122]
The following table presents the impact of the correcting adjustments on the Company’s previously-reported consolidated statement of operations for the three months ended June 30, 2013, (in thousands, except per share amounts):

[0001104659-14-081027:notes:123]
|  |  | Three months ended June 30, 2013 |  |
|  |  | As Reported |  | Adjustments * |  | As Revised |  |
| Net sales |  | $ | 477,924 |  | $ | 606 |  | $ | 478,530 |  |
| Cost of goods sold |  | 309,569 |  | (301 | ) | 309,268 |  |
| Gross profit |  | 168,355 |  | 907 |  | 169,262 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Marketing and selling |  | 100,635 |  | 458 |  | 101,093 |  |
| Research and development |  | 36,191 |  | 336 |  | 36,527 |  |
| General and administrative |  | 29,148 |  | (71 | ) | 29,077 |  |
| Restructuring charges |  | 2,334 |  | — |  | 2,334 |  |
| Total operating expenses |  | 168,308 |  | 723 |  | 169,031 |  |
| Operating income |  | 47 |  | 184 |  | 231 |  |
| Interest expense |  | (23 | ) | — |  | (23 | ) |
| Other income |  | 217 |  | — |  | 217 |  |
| Income before income taxes |  | 241 |  | 184 |  | 425 |  |
| Benefit from income taxes |  | (802 | ) | 1 |  | (801 | ) |
| Net income |  | $ | 1,043 |  | $ | 183 |  | $ | 1,226 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic |  | $ | 0.01 |  | $ | — |  | $ | 0.01 |  |
| Diluted |  | $ | 0.01 |  | $ | — |  | $ | 0.01 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |
| Basic |  | 159,298 |  | — |  | 159,298 |  |
| Diluted |  | 160,281 |  | — |  | 160,281 |  |

[0001104659-14-081027:notes:124]
* The adjustments included in these financial statements for the three months ended June 30, 2013 primarily related to a correction to revenue that was previously recorded as an out-of-period adjustment and is now being reported in the correct period, capitalization of property, plant and equipment which was previously incorrectly expensed, other misstatements, and the tax impact of these adjustments.

[0001104659-14-081027:notes:125]
Consolidated Statement of Comprehensive Income

[0001104659-14-081027:notes:126]
The following table presents the impact of the correcting adjustments on the Company’s previously-reported consolidated statement of comprehensive income for the three months ended June 30, 2013, (in thousands):

[0001104659-14-081027:notes:127]
|  |  | Three Months Ended |  |
|  |  | June 30, 2013 |  |
|  |  | As Reported |  | Adjustments * |  | As Revised |  |
| Net income |  | $ | 1,043 |  | $ | 183 |  | $ | 1,226 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |
| Foreign currency translation gain |  | 101 |  | 598 |  | 699 |  |
| Defined benefit pension plans: |  |  |  |  |  |  |  |
| Net (loss) gain and prior service costs, net of taxes |  | (196 | ) | 761 |  | 565 |  |
| Reclass of amortization included in operating expenses |  | 306 |  | 779 |  | 1,085 |  |
| Hedging gain (loss): |  |  |  |  |  |  |  |
| Unrealized hedging loss |  | (913 | ) | — |  | (913 | ) |
| Reclass of hedging gain included in cost of goods sold |  | 278 |  | — |  | 278 |  |
| Other comprehensive income (loss): |  | (424 | ) | 2,138 |  | 1,714 |  |
| Total comprehensive income |  | $ | 619 |  | $ | 2,321 |  | $ | 2,940 |  |

[0001104659-14-081027:notes:128]
Consolidated Statement of Cash Flows

[0001104659-14-081027:notes:129]
The following table presents the impact of the correcting adjustments on the Company’s previously-reported consolidated statement of cash flows for the three months ended June 30, 2013, (in thousands):

[0001104659-14-081027:notes:130]
|  |  | Three months ended June 30, 2013 |  |
|  |  | As Reported |  | Adjustments * |  | As Revised |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income |  | $ | 1,043 |  | $ | 183 |  | $ | 1,226 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation |  | 10,139 |  | 992 |  | 11,131 |  |
| Amortization of other intangible assets |  | 5,264 |  | — |  | 5,264 |  |
| Share-based compensation expense |  | 4,390 |  | — |  | 4,390 |  |
| Impairment of investments |  | 370 |  | — |  | 370 |  |
| Loss on disposal of property,plant and equipment |  | 2,311 |  | — |  | 2,311 |  |
| Deferred income taxes and other |  | (3,416 | ) | — |  | (3,416 | ) |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |
| Accounts receivable |  | (38,899 | ) | (606 | ) | (39,505 | ) |
| Inventories |  | (28,052 | ) | (234 | ) | (28,286 | ) |
| Other assets |  | (1,770 | ) | — |  | (1,770 | ) |
| Accounts payable |  | 33,580 |  | (610 | ) | 32,970 |  |
| Accrued and other liabilities |  | 13,733 |  | 1,423 |  | 15,156 |  |
| Net cash used in operating activities |  | (1,307 | ) | 1,148 |  | (159 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (13,208 | ) | (1,148 | ) | (14,356 | ) |
| Acquisitions, net of cash acquired |  | (650 | ) | — |  | (650 | ) |
| Purchases of trading investments |  | (4,406 | ) | — |  | (4,406 | ) |
| Proceeds from sales of trading investments |  | 4,748 |  | — |  | 4,748 |  |
| Net cash used in investing activities |  | (13,516 | ) | (1,148 | ) | (14,664 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from sales of shares upon exercise of options and purchase rights |  | 12 |  | — |  | 12 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (215 | ) | — |  | (215 | ) |
| Net cash used in financing activities |  | (203 | ) | — |  | (203 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | 59 |  | — |  | 59 |  |
| Net decrease in cash and cash equivalents |  | (14,967 | ) | — |  | (14,967 | ) |
| Cash and cash equivalents at beginning of period |  | 333,824 |  | — |  | 333,824 |  |
| Cash and cash equivalents at end of period |  | $ | 318,857 |  | $ | — |  | $ | 318,857 |  |
| Non-cash investing activities: |  |  |  |  |  |  |  |
| Property, plant and equipment purchased during the period and included in period end liability accounts |  | $ | 1,422 |  | — |  | $ | 1,422 |  |


## us-gaap:SubsequentEventsTextBlock

[0001104659-14-081027:notes:131]
Note 14 — Subsequent Events

[0001104659-14-081027:notes:132]
The Company was not current with its periodic reports required to be filed with the SEC and was therefore unable to issue any shares under its Registration Statements on Form S-8 after July 31, 2014. Given the proximity of the unavailability of those registration statements and the end of the current ESPP offering period, also on July 31, 2014, the Compensation Committee authorized the termination of the current ESPP offering period and a one-time payment to each participant in an amount equal to the fifteen percent (15%) discount at which shares would otherwise have been repurchased pursuant to the current period of the ESPPs. This one-time payment, totaling $1.1 million was accounted for as a repurchase of equity awards that reduced additional paid in capital, resulting in no additional compensation cost. Given the unavailability of the Company’s Registration Statements on Form S-8, no new ESPP offering periods were initiated during the three months ended September 30, 2014.

[0001104659-14-081027:notes:133]
On November 12, 2014, the Board approved, subject to approval by the Company’s shareholders and other Swiss statutory requirements, a dividend of CHF 0.2625 per share.
