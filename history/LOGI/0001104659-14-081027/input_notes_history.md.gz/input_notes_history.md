# LOGI note change history — 0001104659-14-005272 → 0001104659-14-081027


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2014-11-14):
[0001104659-14-081027:note_history:1]
All of the Company’s peripherals products are covered by warranty to be free from defects in material and workmanship for periods ranging from one year to five years. At the time of sale, the Company accrues a warranty liability for estimated costs to provide products, parts or services to repair or replace products in satisfaction of the warranty obligation. The Company’s estimate of costs to fulfill its warranty obligations is based on historical experience and expectations of future conditions. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly.

- changed (2014-11-14):
[0001104659-14-081027:note_history:2]
Changes in the Company’s warranty liability for the three months ended June 30, 2014 and 2013 were as follows (in thousands):
  (was, 2014-01-30, similarity 0.7549):
[0001104659-14-005272:note_history:2]
Changes in the Company’s deferred services revenue during the three and nine months ended December 31, 2013 and 2012 were as follows (in thousands):

- added (2014-11-14):
[0001104659-14-081027:note_history:3]
|  |  | Three Months Ended |  |
|  |  | June 30, |  |
|  |  | 2014 |  | 2013 |  |
| Beginning of the period |  | $ | 24,380 |  | $ | 21,442 |  |
| Provision |  | 2,206 |  | 3,526 |  |
| Settlements |  | (3,166 | ) | (3,745 | ) |
| Adjustment (1) |  | — |  | 2,327 |  |
| End of the period |  | $ | 23,420 |  | $ | 23,550 |  |

- changed (2014-11-14):
[0001104659-14-081027:note_history:4]
(1)     During the three month period June 30, 2013, the warranty liability allocated to the Company’s - Remotes product category was reclassified from liabilities held for sale.
  (was, 2014-01-30, similarity 0.8902):
[0001104659-14-005272:note_history:4]
(1)         During the nine months ended December 31, 2013, the warranty liability allocated to the Company’s Retail — Remotes product category was reclassified from liabilities held for sale.

- added (2014-11-14):
[0001104659-14-081027:note_history:5]
Commitments for inventory purchases are made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers and are expected to be fulfilled by September 30, 2014. Operating expense commitments are for consulting services, marketing arrangements, advertising, outsourced customer services, information technology maintenance and support services, and other services. Fixed purchase commitments for capital expenditures primarily related to commitments for computer hardware and leasehold improvements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the Company the option to reschedule and adjust its requirements based on the business needs prior to delivery of goods or performance of services. As of June 30, 2014, the Company’s outstanding purchase commitments had not materially changed since March 31, 2014.

- added (2014-11-14):
[0001104659-14-081027:note_history:6]
Other Contingencies

- added (2014-11-14):
[0001104659-14-081027:note_history:7]
The Company is subject to an ongoing formal investigation by the SEC, relating to issues including the accounting for Revue inventory valuation reserves that resulted in the restatement described in the Fiscal 2014 Form 10-K, revision to the Company’s financial statements concerning warranty accruals and amortization of intangible assets presented in the Company's Form 10-K/A, filed on August 7, 2013, and the Company’s transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. The Company is cooperating with the SEC in its ongoing investigation. The Company has entered into an agreement with the SEC to extend the statute of limitations. The Company cannot predict the outcome of the investigation at this time and any potential fines or penalties, if any, that may arise from the investigation are currently not estimable.

- changed (2014-11-14):
[0001104659-14-081027:note_history:8]
Logitech International S.A., the parent holding company, has issued several parent guarantees on behalf of its subsidiaries. The maximum potential future payment under the guarantee arrangements is limited to $80.0 million. As of June 30, 2014, there were no purchase obligations outstanding for which the parent holding company was required to guarantee payment.
  (was, 2014-01-30, similarity 0.7729):
[0001104659-14-005272:note_history:8]
Logitech International S.A., the parent holding company, has guaranteed payment of the purchase obligations of various subsidiaries from certain component suppliers. The maximum potential future payment under the guarantee arrangements is limited to $30.0 million. As of December 31, 2013, there were no purchase obligations outstanding for which the parent holding company was required to guarantee payment.

- changed (2014-11-14):
[0001104659-14-081027:note_history:9]
Logitech Europe S.A., a subsidiary of the parent holding company, has guaranteed the purchase obligations of another Logitech subsidiary under a guarantee agreement. This guarantee does not specify a maximum amount. As of June 30, 2014, the amount of purchase obligations outstanding under this guarantee was immaterial. In addition, Logitech Europe S.A. also guaranteed payments of a third-party contract manufacturer’s purchase obligations. As of June 30, 2014, the maximum amount of this guarantee was $3.5 million, of which $2.3 million of guaranteed purchase obligations were outstanding.
  (was, 2014-01-30, similarity 0.8236):
[0001104659-14-005272:note_history:9]
Logitech Europe S.A., a subsidiary of the parent holding company, has guaranteed the purchase obligations of another Logitech subsidiary under a guarantee agreement. This guarantee does not specify a maximum amount. As of December 31, 2013, there was no amount of purchase obligations outstanding under this guarantee. In addition, Logitech Europe S.A. also guaranteed payments of a third-party contract manufacturer’s purchase obligations as it relates to the Company. As of December 31, 2013, the maximum amount of this guarantee was $3.5 million, of which $1.6 million of guaranteed purchase obligations were outstanding.

- changed (2014-11-14):
[0001104659-14-081027:note_history:10]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2014, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2014-01-30, similarity 0.9906):
[0001104659-14-005272:note_history:10]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2013, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

- changed (2014-11-14):
[0001104659-14-081027:note_history:11]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.
  (was, 2014-01-30, similarity 0.9963):
[0001104659-14-005272:note_history:11]
From time to time the Company is involved in claims and legal proceedings which arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.

- removed (2014-11-14):
[0001104659-14-005272:note_history:12]
Operating Leases

- removed (2014-11-14):
[0001104659-14-005272:note_history:13]
The Company leases facilities under operating leases, certain of which require it to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at the Company’s option and usually include escalation clauses linked to inflation. Future minimum annual rentals under non-cancelable operating leases as of December 31, 2013 amounted to $80.0 million.

- removed (2014-11-14):
[0001104659-14-005272:note_history:14]
In connection with its leased facilities, the Company has recognized a liability for asset retirement obligations representing the present value of estimated remediation costs to be incurred at lease expiration.

- removed (2014-11-14):
[0001104659-14-005272:note_history:15]
The following table describes changes to the Company’s asset retirement obligation liability for the three and nine months ended December 31, 2013 and 2012 (in thousands):

- removed (2014-11-14):
[0001104659-14-005272:note_history:16]
|  |  | Three Months Ended |  | Nine Months Ended |  |
|  |  | December 31, |  | December 31, |  |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |  |
| Beginning of the period |  | $ | 1,178 |  | $ | 1,870 |  | $ | 1,750 |  | $ | 1,918 |  |
| Accrued expenses |  | — |  | 63 |  | — |  | 63 |  |
| Expenses settled |  | — |  | (200 | ) | (596 | ) | (200 | ) |
| Accretion |  | 4 |  | 5 |  | 15 |  | 21 |  |
| Foreign currency translation |  | 4 |  | 32 |  | 17 |  | (32 | ) |
| End of the period |  | $ | 1,186 |  | $ | 1,770 |  | $ | 1,186 |  | $ | 1,770 |  |

- removed (2014-11-14):
[0001104659-14-005272:note_history:17]
All of the Company’s products are covered by warranty to be free from defects in material and workmanship for periods ranging from one to five years. At the time of sale, the Company accrues a warranty liability for estimated costs to provide replacement products and parts or services to repair products under the warranty obligation. The Company’s estimate of costs to fulfill its warranty obligations is based on historical experience and expectations of future requirements. When the Company experiences changes in warranty claim activity or costs associated with fulfilling those claims, the warranty liability is adjusted accordingly. Changes in the Company’s warranty liability for the three and nine months ended December 31, 2013 and 2012 were as follows (in thousands):

- removed (2014-11-14):
[0001104659-14-005272:note_history:18]
|  |  | Three Months Ended |  | Nine Months Ended |  |
|  |  | December 31, |  | December 31, |  |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |  |
|  |  |  |  | (revised) |  |  |  | (revised) |  |
| Beginning of the period |  | $ | 22,085 |  | $ | 23,537 |  | $ | 20,538 |  | $ | 25,494 |  |
| Provision |  | 4,143 |  | 4,169 |  | 10,788 |  | 10,149 |  |
| Settlements |  | (3,568 | ) | (3,955 | ) | (10,993 | ) | (11,892 | ) |
| Adjustment (1) |  | — |  | — |  | 2,327 |  | — |  |
| End of the period |  | $ | 22,660 |  | $ | 23,751 |  | $ | 22,660 |  | $ | 23,751 |  |

- removed (2014-11-14):
[0001104659-14-005272:note_history:19]
Deferred Services Revenue

- removed (2014-11-14):
[0001104659-14-005272:note_history:20]
The Company’s video conferencing reporting unit offers maintenance contracts for sale of the majority of its products which allow for customers to receive service and support in addition to the expiration of the product warranty contractual term. The Company also provides installation services to its customers under contractual arrangements. The Company recognizes these contracts over the life of the service period.

- removed (2014-11-14):
[0001104659-14-005272:note_history:21]
|  |  | Three Months Ended |  | Nine Months Ended |  |
|  |  | December 31, |  | December 31, |  |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |  |
| Beginning of the period |  | $ | 29,068 |  | $ | 27,119 |  | $ | 29,328 |  | $ | 24,568 |  |
| Extended warranties issued |  | 8,800 |  | 8,690 |  | 24,630 |  | 25,084 |  |
| Amortization |  | (8,120 | ) | (7,672 | ) | (24,210 | ) | (21,515 | ) |
| End of the period |  | $ | 29,748 |  | $ | 28,137 |  | $ | 29,748 |  | $ | 28,137 |  |

- removed (2014-11-14):
[0001104659-14-005272:note_history:22]
The cost of providing these services for the three and nine months ended December 31, 2013 was $1.5 million and $5.7 million, respectively, compared to $2.6 million and $6.9 million for the three and nine months ended December 31, 2012, respectively.

- removed (2014-11-14):
[0001104659-14-005272:note_history:23]
At December 31, 2013, the Company had the following outstanding purchase commitments:

- removed (2014-11-14):
[0001104659-14-005272:note_history:24]
|  |  | December 31, |  |
|  |  | 2013 |  |
| Inventory commitments |  | $ | 97,020 |  |
| Operating expenses |  | 56,305 |  |
| Capital commitments |  | 16,892 |  |
|  |  | $ | 170,217 |  |

- removed (2014-11-14):
[0001104659-14-005272:note_history:25]
Commitments for inventory purchases are made in the normal course of business to original design manufacturers and to other suppliers for the Company’s internal manufacturing, the majority of the contract manufacturers and other suppliers and are expected to be fulfilled by March 2014. Operating expense commitments are for consulting services, marketing arrangements, advertising, outsourced customer services, information technology maintenance and support services and other services. Fixed purchase commitments for capital expenditures primarily related to commitments for computer hardware and leasehold improvements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the Company the option to reschedule and adjust its requirements based on the business needs prior to delivery of goods or performance of services.

- removed (2014-11-14):
[0001104659-14-005272:note_history:26]
Logitech International S.A. and Logitech Europe S.A. have guaranteed certain contingent liabilities of various subsidiaries related to transactions occurring in the normal course of business. As of December 31, 2013, the maximum amount of the guarantees was $28.4 million, of which $5.2 million of guaranteed obligations were outstanding.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-11-14):
[0001104659-14-081027:note_history:27]
The consolidated interim financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (“GAAP”) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. They should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2014, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (“SEC”) on November 13, 2014.  In the opinion of management, these consolidated financial statements include all adjustments, consisting of normal recurring adjustments, necessary for a fair statement of the results for the periods presented. Operating results for the three months ended June 30, 2014 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2015, or any future periods.
  (was, 2014-01-30, similarity 0.6022):
[0001104659-14-005272:note_history:27]
The condensed consolidated interim financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The condensed consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (“GAAP”) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. They should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2013, included in its Annual Report on Form 10-K/A filed with the SEC on August 7, 2013. In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of normal recurring adjustments, necessary for a fair statement of the results for the periods presented. Operating results for the three and nine months ended December 31, 2013 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2014, or any future periods.

- changed (2014-11-14):
[0001104659-14-081027:note_history:28]
Fiscal Year
  (was, 2014-01-30, similarity 0.9565):
[0001104659-14-005272:note_history:28]
Fiscal Years

- changed (2014-11-14):
[0001104659-14-081027:note_history:29]
The Company’s fiscal year ends on March 31. Interim quarters are thirteen-week periods, each ending on a Friday.  For purposes of presentation, the Company has indicated its quarterly periods as ending on the month end.
  (was, 2014-01-30, similarity 0.9569):
[0001104659-14-005272:note_history:29]
The Company’s fiscal years end on March 31. Interim quarters are thirteen-week periods, each ending on a Friday. For purposes of presentation, the Company has indicated its quarterly periods as ending on the calendar month end.

- changed (2014-11-14):
[0001104659-14-081027:note_history:30]
There have been no substantial changes in the Company’s significant accounting policies during the three months ended June 30, 2014 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2014.
  (was, 2014-01-30, similarity 0.853):
[0001104659-14-005272:note_history:30]
There have been no substantial changes in the Company’s significant accounting policies during the three and nine months ended December 31, 2013, compared with the significant accounting policies described in its Annual Report on Form 10-K/A for the fiscal year ended March 31, 2013 filed with the SEC on August 7, 2013.

- changed (2014-11-14):
[0001104659-14-081027:note_history:31]
The preparation of financial statements in conformity with U.S. GAAP requires management to make judgments, estimates and assumptions that affect reported amounts of assets, liabilities, net sales and expenses, and the disclosure of contingent assets and liabilities. Examples of significant estimates and assumptions made by management involve the fair value of goodwill, accruals for customer programs, inventory valuation, valuation allowances for deferred tax assets and warranty accruals. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ from those estimates.
  (was, 2014-01-30, similarity 0.9956):
[0001104659-14-005272:note_history:31]
The preparation of financial statements in conformity with GAAP requires management to make judgments, estimates and assumptions that affect reported amounts of assets, liabilities, net sales and expenses and the disclosure of contingent assets and liabilities. Examples of significant estimates and assumptions made by management involve the fair value of goodwill, accruals for customer programs, inventory valuation, valuation allowances for deferred tax assets and warranty accruals. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results could differ from those estimates.

- added (2014-11-14):
[0001104659-14-081027:note_history:32]
In May 2014, the FASB issued Accounting Standards Update No. 2014-09, “Revenue from Contracts with Customers (Topic 606),” (“ASU 2014-09”). ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. This new revenue recognition model provides a five-step analysis in determining when and how revenue is recognized. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The new standard will be effective for the Company beginning April 1, 2017.  Early application is prohibited.  The Company is currently evaluating the impact that adopting this new guidance will have on its consolidated financial statements.

- removed (2014-11-14):
[0001104659-14-005272:note_history:33]
Certain prior period financial statement amounts have been reclassified to conform to the current period presentation with no impact on previously reported net income.

- removed (2014-11-14):
[0001104659-14-005272:note_history:34]
In July 2013, the FASB issued Accounting Standards Update (“ASU”) No. 2013-11, Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists. This ASU provides explicit guidance on the financial statement presentation of an unrecognized tax benefit when a net operating loss carryforward, a similar tax loss, or a tax credit carryforward exists. ASU No. 2013-11 is effective for interim and annual periods beginning after December 15, 2013. The Company does not expect the adoption of this guidance to have a material impact on its financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-14):
[0001104659-14-081027:note_history:35]
Note 10— Financing Arrangements
  (was, 2014-01-30, similarity 0.9836):
[0001104659-14-005272:note_history:35]
Note 10 — Financing Arrangements

- added (2014-11-14):
[0001104659-14-081027:note_history:36]
The Company had several uncommitted, unsecured bank letters of credit aggregating $40 million as of June 30, 2014. There are no financial covenants under these letters of credit with which the Company must comply.  As of June 30, 2014, the Company had outstanding bank guarantees of $8.3 million under these letters of credit. The Company also had credit lines related to corporate credit cards totaling $6.9 million as of June 30, 2014. There are no financial covenants under these credit lines.

- removed (2014-11-14):
[0001104659-14-005272:note_history:37]
In December 2011, the Company entered into a Senior Revolving Credit Facility Agreement (“Credit Facility”) with a group of primarily Swiss banks that provided for a revolving multicurrency unsecured credit facility in an amount of up to $250.0 million and subject to certain requirements, permitted the Company to arrange with existing or new lenders to provide up to an aggregate of $150.0 million in additional commitments, for a total of $400.0 million. The Company also paid a quarterly commitment fee of 40% of the applicable margin on the available commitment. In December 2013, the Company on its own volition, terminated this Credit Facility and wrote-off $1.0 million of capitalized deferred loan fees. There were no outstanding borrowings at the time of termination.

- removed (2014-11-14):
[0001104659-14-005272:note_history:38]
The Company had several uncommitted, unsecured bank lines of credit aggregating $62.0 million at December 31, 2013. There are no financial covenants under these lines of credit with which the Company must comply. As of December 31, 2013, the Company had no outstanding borrowings under these lines of credit. The Company also had credit lines related to corporate credit cards totaling $7.0 million as of December 31, 2013. The outstanding borrowings under these credit lines are recorded in other current liabilities. There are no financial covenants under these credit lines.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2014-11-14):
[0001104659-14-081027:note_history:39]
Note 14 — Subsequent Events

- added (2014-11-14):
[0001104659-14-081027:note_history:40]
The Company was not current with its periodic reports required to be filed with the SEC and was therefore unable to issue any shares under its Registration Statements on Form S-8 after July 31, 2014. Given the proximity of the unavailability of those registration statements and the end of the current ESPP offering period, also on July 31, 2014, the Compensation Committee authorized the termination of the current ESPP offering period and a one-time payment to each participant in an amount equal to the fifteen percent (15%) discount at which shares would otherwise have been repurchased pursuant to the current period of the ESPPs. This one-time payment, totaling $1.1 million was accounted for as a repurchase of equity awards that reduced additional paid in capital, resulting in no additional compensation cost. Given the unavailability of the Company’s Registration Statements on Form S-8, no new ESPP offering periods were initiated during the three months ended September 30, 2014.

- added (2014-11-14):
[0001104659-14-081027:note_history:41]
On November 12, 2014, the Board approved, subject to approval by the Company’s shareholders and other Swiss statutory requirements, a dividend of CHF 0.2625 per share.
