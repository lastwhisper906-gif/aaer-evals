# LOGI MD&A — 0001104659-14-081027


## mdna

[0001104659-14-081027:mdna:1]
ITEM 2.   MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001104659-14-081027:mdna:2]
You should read the following discussion in conjunction with the interim unaudited Consolidated Financial Statements and related notes.

[0001104659-14-081027:mdna:3]
[same as prior period, unchanged from 0001104659-14-005272:mdna:3]

[0001104659-14-081027:mdna:4]
[same as prior period, unchanged from 0001104659-14-005272:mdna:4]

[0001104659-14-081027:mdna:5]
Our peripherals segment encompasses the design, manufacturing and marketing of peripherals for PCs, tablets and other digital platforms. Our products for home and business PCs include mice, trackballs, keyboards, interactive gaming controllers, multimedia speakers, headsets and webcams. Our tablet accessory products include keyboards, keyboard cases and covers, and smartphone accessories. Our Internet communications products include webcams, conference cams and headsets. Our digital music products include wireless speakers, earphones, and custom in-ear monitors. Our gaming products include mice, keyboards, headsets and gaming controllers. For home entertainment and home control systems, we offer the Harmony line of advanced remote controls. Since

[0001104659-14-081027:mdna:6]
26

[0001104659-14-081027:mdna:7]
fiscal year 2013, we have been exiting other non-strategic products, such as speaker docks and headphones, and continue to evaluate non-strategic products as part of our ongoing efforts to strengthen our overall portfolio.

[0001104659-14-081027:mdna:8]
Within our peripherals segment, we classify our retail product categories as growth, profit maximization and non-strategic. Our growth product categories are: PC Gaming, Tablet & Other Accessories, and Mobile Speakers. Our profit maximization categories are: Pointing Devices, PC Keyboards & Desktops, Audio-PC & Wearables, Video, and Remotes.

[0001104659-14-081027:mdna:9]
Our brand, portfolio management, product development and engineering teams in our peripherals segment are responsible for product strategy, technological innovation, product design and development and to bring our products to market.

[0001104659-14-081027:mdna:10]
Our global marketing organization is responsible for developing and building the Logitech brand, consumer insights, public relations, social media and digital marketing. Our regional retail sales and marketing activities are organized into three geographic areas: Americas (North and South America), EMEA (Europe, Middle East and Africa) and Asia Pacific (including, among other countries, China, Taiwan, Japan and Australia).

[0001104659-14-081027:mdna:11]
We sell our peripherals products to a network of retailers (direct sales to retailers, as well as indirect sales through distributors) and OEMs. Our worldwide retail network includes wholesale distributors, consumer electronics retailers, mass merchandisers, specialty electronics, computers and telecommunications stores, value-added resellers and online merchants. Sales of our retail peripherals were 88% and 86% of our net sales for the three months ended June 30, 2014 and 2013. The large majority of our revenues have historically been derived from sales of our peripherals products for use by consumers. Our OEM customers include several of the world’s largest PC manufacturers. Sales to OEM customers were 7% of our net sales for the three months ended June 30, 2014 and 2013.

[0001104659-14-081027:mdna:12]
Our video conferencing segment encompasses the design, manufacturing and marketing of Lifesize branded video conferencing products, infrastructure and services for the enterprise, public sector and other small to medium business markets. Video conferencing products include scalable high-definition, or HD, video communication endpoints, HD video conferencing systems with integrated monitors, video bridges, a cloud based video conferencing solution and other infrastructure software and hardware to support large-scale video deployments and services to support these products. The video conferencing segment maintains a separate marketing and sales organization, which sells Lifesize products and services worldwide. Video conferencing product development and product management organizations are separate, but coordinated with our peripherals business, particularly our Consumer Computing Platform group. We sell our video conferencing products and services to distributors, value-added resellers, OEMs and, occasionally, direct enterprise customers. Sales of Lifesize products were 5% and 6% of our net sales in the three months ended June 30, 2014 and 2013.

[0001104659-14-081027:mdna:13]
We seek to fulfill the increasing demand for interfaces between people and the expanding digital world across multiple platforms and user environments. The interface evolves as platforms, user models and our target markets evolve. As access to digital information has expanded, we have extended our focus to mobile devices, the digital home, and the enterprise as access points to the Internet and the digital world. All of these platforms require interfaces that are customized according to how the devices are used. We believe that continued investment in product research and development is critical to creating the innovation required to strengthen our competitive advantage and to drive future sales growth. We are committed to identifying and meeting current and future consumer trends with new and improved product technologies, partnering with others where our strengths are complementary, as well as leveraging the value of the Logitech and Lifesize brands from a competitive, channel partner and consumer experience perspective.

[0001104659-14-081027:mdna:14]
[same as prior period, unchanged from 0001104659-14-005272:mdna:10]

[0001104659-14-081027:mdna:15]
[same as prior period, unchanged from 0001104659-14-005272:mdna:11]

[0001104659-14-081027:mdna:16]
[same as prior period, unchanged from 0001104659-14-005272:mdna:12]

[0001104659-14-081027:mdna:17]
[same as prior period, unchanged from 0001104659-14-005272:mdna:13]

[0001104659-14-081027:mdna:18]
[same as prior period, unchanged from 0001104659-14-005272:mdna:42]

[0001104659-14-081027:mdna:19]
The preparation of financial statements and related disclosures in conformity with U.S. GAAP (generally accepted accounting principles in the United States of America) requires us to make judgments, estimates and assumptions that affect reported amounts of assets, liabilities, net sales and expenses, and the disclosure of contingent assets and liabilities.

[0001104659-14-081027:mdna:20]
[same as prior period, unchanged from 0001104659-14-005272:mdna:44]

[0001104659-14-081027:mdna:21]
[same as prior period, unchanged from 0001104659-14-005272:mdna:45]

[0001104659-14-081027:mdna:22]
There have been no new or material changes to the critical accounting policies and estimates discussed in our Annual Report on Form 10-K for the fiscal year ended March 31, 2014 that are of significance, or potential significance to the Company.

[0001104659-14-081027:mdna:23]
Revision of Previously Issued Financial Statements

[0001104659-14-081027:mdna:24]
As disclosed in the Company’s Annual Report on Form 10-K for the year ended March 31, 2014 and in the audited consolidated financial statements contained therein, the Company has restated and revised its financial statements for the fiscal years ended March 31, 2012 and 2013, respectively. The impact of the adjustments also immaterially impact the financial statements for the first three quarters of the fiscal year ended March 31, 2014 as previously included in the Company’s quarterly reports on Form 10-Q for Fiscal 2014. The financial statements for three months ended June 30, 2013 included in this Form 10-Q are revised as described below for those adjustments and should be read in conjunction with Item 8, “Financial Statements and Supplementary Data” disclosed in the Company’s Annual Report on Form 10-K for the fiscal year ended March 31, 2014, filed with the SEC on November 13, 2014.

[0001104659-14-081027:mdna:25]
The adjustments included in these financial statements for the three months ended June 30, 2013 primarily related to a correction to revenue that was previously recorded as an out-of-period adjustment and is now being reported in the correct period, capitalization of property, plant and equipment which was previously incorrectly expensed, other misstatements, and the tax impact of these adjustments.

[0001104659-14-081027:mdna:26]
[same as prior period, unchanged from 0001104659-14-005272:mdna:22]

[0001104659-14-081027:mdna:27]
Our total net sales for the three months ended June 30, 2014 increased 1% compared with the three months ended June 30, 2013, due to an increase in retail sales, offset by declines in OEM and video conferencing sales.

[0001104659-14-081027:mdna:28]
Retail sales during the three months ended June 30, 2014 increased 2% and retail units sold increased 4% compared with the three months ended June 30, 2013. We experienced increases of 8% in the Americas and a decrease of 3% in the Asia Pacific regions, and a decrease of 1% in the EMEA region.

[0001104659-14-081027:mdna:29]
OEM net sales decreased 5% and units sold decreased 12% in the three months ended June 30, 2014 compared with the preceding fiscal year. The decline was primarily due to overall weaker market conditions for pointing devices that were only partially offset by growth in Keyboards & Desktops.

[0001104659-14-081027:mdna:30]
Sales of video conferencing products, which were 5% and 6% of total net sales in the three months ended June 30, 2014 and 2013, decreased by 15% in the three months ended June 30, 2014, compared with the three months ended June 30, 2013.

[0001104659-14-081027:mdna:31]
Lifesize is in the process of transitioning its product portfolio to the recently announced Lifesize Cloud, a software-as-a-service (SaaS) offering that provides an affordable, simple and scalable video conferencing solution with little to no need for IT involvement. The decline in sales reflects the combination of this short-term portfolio transition and weak market conditions for video conferencing endpoints.

[0001104659-14-081027:mdna:32]
Our gross margin for the three months ended June 30, 2014 improved to 37.7% compared with 35.4% for the three months ended June 30, 2013. The improvement in gross margin for the three months ended June 30, 2014 compared with the same period of the prior fiscal year primarily resulted from the combination of cost reductions in our Profit Maximization category, scale on some Growth category products, offset in part by an increase in incentive spending.

[0001104659-14-081027:mdna:33]
Operating expenses for the three months ended June 30, 2014 were 33.0% of net sales, compared with 35.3% in the same period of the prior fiscal year. The decrease in total operating expenses as a percentage of net sales for the three months ended June 30, 2014 compared to prior period were primarily due to savings from prior year’s restructuring actions and the ongoing rationalization of infrastructure.

[0001104659-14-081027:mdna:34]
Net income for the three months ended June 30, 2014 was $19.7 compared with net income of $1.2 million in the three months ended June 30, 2013.

[0001104659-14-081027:mdna:35]
[same as prior period, unchanged from 0001104659-14-005272:mdna:30]

[0001104659-14-081027:mdna:36]
[same as prior period, unchanged from 0001104659-14-005272:mdna:31]

[0001104659-14-081027:mdna:37]
We believe our future growth will be determined by our ability to rapidly create innovative products across multiple digital platforms, especially accessories for mobility-related products, including tablets, smartphones, PC Gaming and digital music devices to offset the decline in our PC peripherals. The following discussion represents key trends specific to each of our two operating segments, peripherals and video conferencing.

[0001104659-14-081027:mdna:38]
[same as prior period, unchanged from 0001104659-14-005272:mdna:33]

[0001104659-14-081027:mdna:39]
PC Peripherals: Although the installed base of PC users is large, consumer demand for new PCs has declined in recent years, and we believe it will continue to decline in future years. As a consequence, consumer demand for PC peripherals is slowing, or in some cases declining. As the quality of PC-embedded webcams improves along with the increasing popularity of tablets and smartphones with embedded webcams, we expect future sales of our PC-connected webcams will continue to be weak (or continue to decline on a year over year basis).

[0001104659-14-081027:mdna:40]
Enterprise Market. We are continuing our efforts to create and sell products and services to enterprises. For example, we have introduced the Logitech ConferenceCam CC3000e video conference solution designed for small to medium conference rooms. Growing our enterprise peripherals business will continue to require investment in selected business-specific products, targeted product marketing, and sales channel development.

[0001104659-14-081027:mdna:41]
Tablets and Other Accessories. The increasing popularity of smaller, mobile computing devices, such as tablets with touch interfaces, have created new markets and usage models for peripherals and accessories. We have started offering products to enhance the use of mobile devices. During fiscal year 2014, we continued to expand and leverage our success in this category through the introductions of keyboard folios for the iPad and iPad mini, and keyboard covers and folios for the iPad Air. During this time, we also introduced keyboard folios for the Samsung Galaxy tablet as well as the Wired Keyboard for the iPad, designed primarily for use in the classroom.

[0001104659-14-081027:mdna:42]
Mobile Speakers. We believe that digital music, the seamless consumption of digital audio content on mobile devices, presents a growth opportunity for us. Many consumers listen to music as a popular entertainment activity, fueled by the growth in smartphones,

[0001104659-14-081027:mdna:43]
tablets, music services and Internet radio. We believe we have a solid foundation of audio speaker solutions to satisfy consumers’ needs for music consumption, in the digital music speaker space. We continue to invest in the UE brand and introduce innovative new products in this category such as UE BOOM, a wireless speaker that offers 360-degree stereo sound.

[0001104659-14-081027:mdna:44]
OEM Business. Sales of our OEM mice and keyboards have historically made up the bulk of our OEM sales. In recent years, there has been a dramatic shift away from desktop PCs and there continues to be weakness in the global market for PCs, which has adversely affected our sales of OEM mice and keyboards, all of which are sold with name-brand desktop PCs. We expect this trend to continue and for OEM sales to comprise a smaller percentage of our total sales in the future.

[0001104659-14-081027:mdna:45]
Trends in Non-Strategic Peripherals Product Categories.  During the quarter ended December 31, 2012, we identified a number of product categories that no longer fit with our strategic direction at that time.  We will continue to evaluate our product offerings and will exit those which no longer support our strategic direction.

[0001104659-14-081027:mdna:46]
[same as prior period, unchanged from 0001104659-14-005272:mdna:40]

[0001104659-14-081027:mdna:47]
The trend among businesses and institutions to use video conferencing offers a long-term growth opportunity for us. However, the overall video conferencing industry has experienced a slowdown in recent quarters. In addition, there has been an increase in the competitive environment. We believe the growth in our video conferencing segment depends in part on our ability to increase sales to enterprises with existing installed bases of equipment supplied by our competitors and to enterprises that may purchase such competitor equipment in the future. We believe the ability of our Lifesize products to interoperate with the equipment of other telecommunications, video conferencing or telepresence equipment suppliers to be a key factor in purchasing decisions by current or prospective Lifesize customers. In addition, Lifesize has broadened its product portfolio to include infrastructure, cloud services and other offerings which require different approaches to developing customer solutions. We are also seeking to offer Lifesize products designed to enhance the use of mobile devices in video conferencing applications.

[0001104659-14-081027:mdna:48]
[same as prior period, unchanged from 0001104659-14-005272:mdna:56]

[0001104659-14-081027:mdna:49]
[same as prior period, unchanged from 0001104659-14-005272:mdna:57]

[0001104659-14-081027:mdna:50]
Net sales by channel for the three months ended June 30, 2014 and 2013 were as follows (in thousands):

[0001104659-14-081027:mdna:51]
|  |  | Three Months Ended |  |  |  |
|  |  | June 30, |  |  |  |
|  |  | 2014 |  | 2013 |  | Change |  |
| Retail |  | $ | 423,814 |  | $ | 413,842 |  | 2 | % |
| OEM |  | 32,632 |  | 34,513 |  | (5 | ) |
| Video conferencing |  | 25,757 |  | 30,175 |  | (15 | ) |
| Total net sales |  | $ | 482,203 |  | $ | 478,530 |  | 1 |  |

[0001104659-14-081027:mdna:52]
Retail:

[0001104659-14-081027:mdna:53]
Our net retail sales in the three months ended June 30, 2014 increased by 2%, compared with the same period of the prior fiscal year, as the sales increases in the Americas were offset by a decrease in Asia Pacific and EMEA regions. The EMEA region decreased by 1% and Asia Pacific decreased 3%.  Our overall average selling price decreased by 2% during this period. Products priced below $40 represented approximately 51% of retail sales in the three months ended June 30, 2014 and 2013, while products priced above $100 represented 15% and 14% of retail sales during these same periods.

[0001104659-14-081027:mdna:54]
OEM:

[0001104659-14-081027:mdna:55]
OEM net sales decreased 5% and units sold decreased 12% in the three months ended June 30, 2014 compared with the preceding fiscal year. The decline was primarily due to overall weaker market conditions for pointing devices that were only partially offset by growth in Keyboards & Desktops.

[0001104659-14-081027:mdna:56]
Lifesize:

[0001104659-14-081027:mdna:57]
Video conferencing net sales decreased 15% during the three months ended June 30, 2014, compared with the same period of the prior fiscal year.

[0001104659-14-081027:mdna:58]
Lifesize is in the process of transitioning its product portfolio to the recently announced Lifesize Cloud, a software-as-a-service (SaaS) offering that provides an affordable, simple and scalable video conferencing solution with little to no need for IT involvement. The decline in sales reflects the combination of this short-term portfolio transition and weak market conditions for video conferencing endpoints.

[0001104659-14-081027:mdna:59]
[same as prior period, unchanged from 0001104659-14-005272:mdna:66]

[0001104659-14-081027:mdna:60]
The following table presents the change in retail sales by for the three months ended June 30, 2014 compared with the three months ended June 30, 2013.

[0001104659-14-081027:mdna:61]
|  |  | Three Months Ended |  |
|  |  | June 30, 2014 |  |
|  |  | Change in Sales |  |
| Americas |  | 8 | % |
| EMEA |  | (1 | ) |
| Asia Pacific |  | (3 | ) |

[0001104659-14-081027:mdna:62]
[same as prior period, unchanged from 0001104659-14-005272:mdna:70]

[0001104659-14-081027:mdna:63]
The Americas region experienced an 8% increase in retail sales during the three months ended June 30, 2014, compared with the same period of the prior fiscal year.  The sales increase was achieved in all categories except our non-strategic Other, Remotes and Pointing Devices.  This increase was led by strong performance in Mobile Speakers from UE BOOM and PC Gaming products. Retail sell-through in the Americas region increased 9% in the three months ended June 30, 2014 compared with the same period of the prior fiscal year.

[0001104659-14-081027:mdna:64]
[same as prior period, unchanged from 0001104659-14-005272:mdna:73]

[0001104659-14-081027:mdna:65]
Retail sales in the EMEA region experienced a 1% decrease during the three months ended June 30, 2014, compared with the same period of the prior fiscal year. Sales of Mobile Speakers were particularly strong in the quarter and we achieved double-digit growth in Video due to the success of our Video conferencing products and PC Keyboards & Desktops.

[0001104659-14-081027:mdna:66]
[same as prior period, unchanged from 0001104659-14-005272:mdna:76]

[0001104659-14-081027:mdna:67]
Asia Pacific region retail sales decreased by 3% during the three months ended June 30, 2014, compared with the same period of the prior fiscal year.  We had strong sales growth in our Mobile Speakers. These increases were offset in part by weakness in our Tablet & Other Accessories, and decline in non-strategic Other.

[0001104659-14-081027:mdna:68]
Net Retail Sales by Product Category

[0001104659-14-081027:mdna:69]
Net retail sales by product category during the three months ended June 30, 2014 and 2013 were as follows (in thousands):

[0001104659-14-081027:mdna:70]
|  |  | Three Months Ended |  |  |  |
|  |  | June 30, |  |  |  |
|  |  | 2014 |  | 2013 (1) |  |  |  |
| Peripherals: |  |  |  |  |  |  |  |
| PC Gaming |  | $ | 46,876 |  | $ | 40,213 |  | 17 | % |
| Tablet & Other Accessories |  | 31,716 |  | 38,559 |  | -18 | % |
| Mobile Speakers |  | 28,830 |  | 13,867 |  | 108 | % |
| Growth: |  | 107,422 |  | 92,639 |  |  |  |
| Pointing Devices |  | 113,042 |  | 114,651 |  | -1 | % |
| PC Keyboards & Desktops |  | 105,523 |  | 98,013 |  | 8 | % |
| Audio-PC &Wearables |  | 49,626 |  | 55,538 |  | -11 | % |
| Video |  | 34,576 |  | 30,940 |  | 12 | % |
| Remotes |  | 12,332 |  | 14,574 |  | -15 | % |
| Profit Maximization: |  | 315,099 |  | 313,716 |  |  |  |
| Other |  | 1,293 |  | 7,487 |  | -83 | % |
| Non-Strategic: |  | 1,293 |  | 7,487 |  | -83 | % |
| OEM |  | 32,632 |  | 34,513 |  | -5 | % |
|  |  | 456,446 |  | 448,355 |  |  |  |
| Video conferencing |  | 25,757 |  | 30,175 |  | -15 | % |
|  |  | $ | 482,203 |  | $ | 478,530 |  |  |  |

[0001104659-14-081027:mdna:71]
(1)  Certain products within the retail product families presented in prior years have been reclassified to conform to the current year presentation.

[0001104659-14-081027:mdna:72]
Growth Categories:

[0001104659-14-081027:mdna:73]
PC Gaming

[0001104659-14-081027:mdna:74]
Our retail PC Gaming category comprises PC Gaming mice, keyboards, headsets, gamepads and steering wheels.

[0001104659-14-081027:mdna:75]
Retail sales of PC Gaming increased 17% and units sold increased 26%, in the three months ended June 30, 2014 compared to the three months ended June 30, 2013. The growth in the category was experienced in mice, steering wheels, headsets and gamepads. The growth in mice sales was primarily driven by the G502 Tunable Gaming Mouse. Strong sales of our G27 Racing Wheel, which supports both the PC and Playstation 3 platforms, led to the overall growth in steering wheels. New products made up 18% of total PC Gaming revenue for the three months ended June 30, 2014.

[0001104659-14-081027:mdna:76]
Tablet & Other Accessories

[0001104659-14-081027:mdna:77]
Our retail Tablet & Other Accessories consists of keyboards and covers for tablets and smartphones as well as other accessories for mobile devices.

[0001104659-14-081027:mdna:78]
Retail sales of Tablet & Other Accessories decreased 18% and units sold increased 12% in the three months ended June 2014, compared with the same period of the prior fiscal year. This decrease in sales is due to weakened demand for the Ultrathin Tablet Keyboard Covers for iPad Air and iPad Mini. The decline in sales reflects the combination of a weak market for iPad shipments as well as inventory balancing actions taken across our supply chain to better align with the fast changing dynamics in the tablet market. New products made up 98% of total Tablet & Other Accessories revenue for the three months ended June 30, 2014.

[0001104659-14-081027:mdna:79]
Mobile Speakers

[0001104659-14-081027:mdna:80]
Our retail Mobile Speakers category is made up entirely of wireless speakers.

[0001104659-14-081027:mdna:81]
Retail sales and units sold of Mobile Speakers increased 108% and 105%, respectively, for the three month period ended June 30, 2014, compared with the same period of the prior fiscal year.  The increase in sales of our wireless speakers for smartphones and tablets was driven by a strong demand primarily for the UE BOOM, which was our best-selling product in the quarter across all product categories. Our top revenue-generating wireless speaker products during the three months ended June 30, 2014 included the UE BOOM and the UE Mini BOOM. Mobile Speaker sales increased significantly across our three regions due to strong demand and an expanded retail placement.

[0001104659-14-081027:mdna:82]
Profit Maximization:

[0001104659-14-081027:mdna:83]
Pointing Devices

[0001104659-14-081027:mdna:84]
Our retail Pointing Devices category comprises PC and Mac-related mice, touchpads and presenters.

[0001104659-14-081027:mdna:85]
Retail sales of Pointing Devices decreased 1% while retail units sold increased 4% in the three months ended June 30, 2014, compared to the three month period ended June 30, 2013. Sales were down slightly at the low-end and mid-range of the category, with growth at the high-end. Unit shipments increased across all price ranges. Sales of all cordless mice decreased 4%, while units sold increased 1% in the three months ended June 30, 2014, compared with the same period of the prior fiscal year.  Corded mice sales increased 7%, while units sold increased 7% in the three months ended June 30, 2014, compared with the same period of the prior fiscal year.

[0001104659-14-081027:mdna:86]
PC Keyboards and Desktops

[0001104659-14-081027:mdna:87]
Our retail PC Keyboard & Desktop category comprises PC keyboards and keyboard/mice combo products.

[0001104659-14-081027:mdna:88]
Retail sales of PC Keyboards & Desktops increased 8% and units sold increased 7% in the three months ended June 30, 2014, compared with the same period of the prior fiscal year. Sales increase was driven by corded and cordless combo products and living room keyboards. Growth was achieved across all price bands, with double-digit improvement in the high-end. Sales of corded and cordless combos increased 37% and 4%, respectively, and increased 24% and 3%, respectively, in units sold during the three months ended June 30, 2014, compared with the same period in the prior fiscal year.  Sales of corded and cordless keyboards increased 10% and decreased 12%, respectively, and increased 6% and decreased 12%, respectively, in units sold during the three months ended June 30, 2014, compared with the same period in the prior fiscal year.

[0001104659-14-081027:mdna:89]
Audio-PC & Wearables

[0001104659-14-081027:mdna:90]
Our retail Audio-PC & Wearables category comprises PC speakers, PC headsets and in-ear earphones.

[0001104659-14-081027:mdna:91]
Audio-PC & Wearables sales decreased 11% and units sold decreased 7%, in the three months ended June 30, 2014, compared with the same period of the prior fiscal year.  The decrease was primarily due to decreases in PC speaker retail sales.  These decreases reflect both a weakness in the overall market for new PCs and a market shift toward mobile audio devices. Retail sales of our Wearables products decreased 28% and units sold decreased 85%, as we reduce our product offerings.

[0001104659-14-081027:mdna:92]
Video

[0001104659-14-081027:mdna:93]
Our retail Video category comprises retail webcams and Unified Communications webcams.

[0001104659-14-081027:mdna:94]
Retail Video sales increased by 12% and units sold decreased by 17% in the three months ended June 30, 2014, compared with the same period in the prior fiscal year. The sales growth in the Video category, which was achieved across all regions, was driven by

[0001104659-14-081027:mdna:95]
our video collaboration offerings targeted at small and midsize conference rooms. The sales increase was primarily from the Logitech Conference Cam CC3000.

[0001104659-14-081027:mdna:96]
Remotes

[0001104659-14-081027:mdna:97]
Our retail Remotes category comprises our Harmony remotes.  Remote retail sales decreased 15% and units sold increased 11% in the three months ended June 30, 2014, compared with the same period of the prior fiscal year.  The decline in sales was experienced in all regions.

[0001104659-14-081027:mdna:98]
Non Strategic

[0001104659-14-081027:mdna:99]
This category comprises a variety of products that we currently intend to transition out of, or have already transitioned out of, because they are no longer strategic to our business. Products currently included in this category include TV camera, Digital Video Security, Google TV products, and Keyboard and Desktop accessories.  Non-strategic retail sales decreased by 83% and units sold decreased by 63% during the three months ended June 30, 2014, compared with same period in the prior fiscal year.

[0001104659-14-081027:mdna:100]
[same as prior period, unchanged from 0001104659-14-005272:mdna:111]

[0001104659-14-081027:mdna:101]
OEM sales and units sold decreased by 5% and 12% during the three months ended June 30, 2014, compared with the same period of the prior fiscal year. This decrease was largely attributable to the weaker market conditions for sales of new desktop PCs.  This decrease was only partially offset by growth in Keyboards and Desktops.

[0001104659-14-081027:mdna:102]
[same as prior period, unchanged from 0001104659-14-005272:mdna:114]

[0001104659-14-081027:mdna:103]
Video conferencing net sales decreased 15% during the three months ended June 30, 2014, compared with the same period of the prior fiscal year. This decrease reflects a combination of weak market conditions for endpoints and the transition towards the recently announced Lifesize Cloud, a software-as-a-service (SaaS) offering.

[0001104659-14-081027:mdna:104]
[same as prior period, unchanged from 0001104659-14-005272:mdna:116]

[0001104659-14-081027:mdna:105]
Gross profit for the three months ended June 30, 2014 and 2013 was as follows (in thousands):

[0001104659-14-081027:mdna:106]
|  |  | Three Months Ended |  |
|  |  | June 30, |  |
|  |  | 2014 |  | 2013 |  | Change |  |
| Net sales |  | $ | 482,203 |  | $ | 478,530 |  | 1 | % |
| Cost of goods sold |  | 300,450 |  | 309,268 |  | (3 | ) |
| Gross profit |  | $ | 181,753 |  | $ | 169,262 |  | 7 |  |
| Gross margin |  | 37.7 | % | 35.4 | % |  |  |

[0001104659-14-081027:mdna:107]
Gross profit consists of net sales, less cost of goods sold, which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, costs of purchasing components from outside suppliers, distribution costs, outside processing costs, write-down of inventories and amortization of intangible assets.

[0001104659-14-081027:mdna:108]
The improvement in gross margin for the three months ended June 30, 2014 compared with the same period of the prior fiscal year primarily resulted from the combination of a significant improvement in our Profit Maximization category, driven by product cost reductions, and margin improvements in our growth category driven by increased scale.

[0001104659-14-081027:mdna:109]
[same as prior period, unchanged from 0001104659-14-005272:mdna:121]

[0001104659-14-081027:mdna:110]
Operating expenses for the three months ended June 30, 2014 and 2013 were as follows (in thousands):

[0001104659-14-081027:mdna:111]
|  |  | Three Months Ended |  |
|  |  | June 30, |  |
|  |  | 2014 |  | 2013 |  | Change |  |
| Marketing and selling |  | $ | 91,045 |  | $ | 101,093 |  | (10 | )% |
| % of net sales |  | 18.9 | % | 21.1 | % |  |  |
| Research and development |  | 31,316 |  | 36,527 |  | (14 | ) |
| % of net sales |  | 6.5 | % | 7.6 | % |  |  |
| General and administrative |  | 36,680 |  | 29,077 |  | 26 |  |
| % of net sales |  | 7.6 | % | 6.1 | % |  |  |
| Restructuring charges, net |  | — |  | 2,334 |  | (100 | ) |
| % of net sales |  | 0.0 | % | 0.5 | % |  |  |
| Total operating expenses |  | $ | 159,041 |  | $ | 169,031 |  | (6 | ) |
| % of net sales |  | 33.0 | % | 35.4 | % |  |  |

[0001104659-14-081027:mdna:112]
The decrease in total operating expenses as a percentage of net sales for the three months ended June 30, 2014 compared to prior period were primarily due to savings from prior year’s restructuring actions and the ongoing rationalization of infrastructure and marketing activities.

[0001104659-14-081027:mdna:113]
[same as prior period, unchanged from 0001104659-14-005272:mdna:125]

[0001104659-14-081027:mdna:114]
[same as prior period, unchanged from 0001104659-14-005272:mdna:126]

[0001104659-14-081027:mdna:115]
Marketing and selling expense decreased 10% during the three months ended June 30, 2014, compared with the same period of the prior fiscal year due to $7.4 million of savings from cost control initiatives surrounding outsourcing expenses and a decrease in spending on new product launches in mobile speakers and PC Gaming, lower personnel-related expenses of $0.7 million and a reduction of infrastructure expenses of $1.9 million.

[0001104659-14-081027:mdna:116]
[same as prior period, unchanged from 0001104659-14-005272:mdna:129]

[0001104659-14-081027:mdna:117]
[same as prior period, unchanged from 0001104659-14-005272:mdna:130]

[0001104659-14-081027:mdna:118]
Although we continued to make investments in product development, we experienced a 14% decrease in research and development expense during the three months ended June 30, 2014, compared with the same period of the prior fiscal year, primarily from prior year Digital Home launch activity which reduced external third-party expenses by $1.2 million, a decrease in personnel-related expenses of $3.2 million due to the reduction in worldwide workforce resulting from our restructuring plans and a reduction of infrastructure expenses of approximately $0.8 million.

[0001104659-14-081027:mdna:119]
[same as prior period, unchanged from 0001104659-14-005272:mdna:133]

[0001104659-14-081027:mdna:120]
[same as prior period, unchanged from 0001104659-14-005272:mdna:134]

[0001104659-14-081027:mdna:121]
General and administrative expense increased 26% in the three months ended June 30, 2014, compared with the three months ended June 30, 2013, primarily from the increase in legal and consulting expenses of $9.0 million related to the independent Audit committee investigation, personnel-related expenses including share-based compensation expense of $2.2 million, partially offset by realized savings of $2.2 million in infrastructure expenses from the consolidation of some of our facilities located in North America.

[0001104659-14-081027:mdna:122]
[same as prior period, unchanged from 0001104659-14-005272:mdna:139]

[0001104659-14-081027:mdna:123]
During the fourth quarter of fiscal year 2013, Logitech implemented a restructuring plan to align the organization to its strategic priorities of increasing focus on mobility products, improving profitability in PC-related products and enhancing global operational efficiencies. Restructuring charges under this plan primarily consisted of severance and other one-time termination benefits. Charges and other costs related to the workforce reduction are presented as restructuring charges in the consolidated statements of operations. During the three months ended June 30, 2013, restructuring charges under this plan included $2.0 million in termination benefits to affected employees and $0.3 million in lease exit costs.

[0001104659-14-081027:mdna:124]
The Company substantially completed all existing restructuring plans in the fourth quarter of fiscal year 2014, and did not incur any material charges during the first quarter of fiscal 2015.

[0001104659-14-081027:mdna:125]
Termination benefits were calculated based on regional benefit practices and local statutory requirements. Lease exit costs primarily relate to costs associated with the closure of existing facilities. Other charges primarily consist of legal, consulting and other costs related to employee terminations.

[0001104659-14-081027:mdna:126]
The following table summarizes restructuring-related activities during the three months ended June 30, 2014 and 2013 (in thousands):

[0001104659-14-081027:mdna:127]
|  |  | Restructuring |  |
|  |  | Termination |  | Lease Exit |  |  |  |
|  |  | Benefits |  | Costs |  | Total |  |
| March 31, 2013 |  | $ | 13,383 |  | $ | 75 |  | $ | 13,458 |  |
| Charges |  | 2,004 |  | 330 |  | 2,334 |  |
| Cash payments |  | (8,422 | ) | — |  | (8,422 | ) |
| Foreign exchange impact |  | (170 | ) | — |  | (170 | ) |
| June 30, 2013 |  | $ | 6,795 |  | $ | 405 |  | $ | 7,200 |  |
| March 31, 2014 |  | $ | 142 |  | $ | 7,419 |  | $ | 7,561 |  |
| Cash payments |  | (56 | ) | (407 | ) | (463 | ) |
| June 30, 2014 |  | $ | 86 |  | $ | 7,012 |  | $ | 7,098 |  |

[0001104659-14-081027:mdna:128]
Interest Income (Expense), Net

[0001104659-14-081027:mdna:129]
Interest income and expense for the three months ended June 30, 2014 and 2013 were as follows (in thousands):

[0001104659-14-081027:mdna:130]
|  |  | Three Months Ended |  |  |  |
|  |  | June 30, |  |  |  |
|  |  | 2014 |  | 2013 |  | Change |  |
| Interest income |  | $ | 261 |  | $ | 422 |  | (38 | )% |
| Interest expense |  | (3 | ) | (445 | ) | (99 | ) |
|  |  | $ | 258 |  | $ | (23 | ) |  |  |

[0001104659-14-081027:mdna:131]
Interest income was lower in the three months ended June 30, 2014, compared with the three months ended June 30, 2013, primarily due to the mix of cash balances held by country during the three months ended June 30, 2014 compared to the prior period.

[0001104659-14-081027:mdna:132]
Interest expense was lower in the three months ended June 30, 2014, compared with the three months ended June 30, 2013, primarily due to commitment fees and non-recurring fees related to our $250.0 million Senior Revolving Credit Facility entered into in December 2011 that was in place during the three months ended June 30, 2013. In December 2013, given the significant improvement in our financial performance and outlook, we chose to terminate this Credit Facility.

[0001104659-14-081027:mdna:133]
[same as prior period, unchanged from 0001104659-14-005272:mdna:151]

[0001104659-14-081027:mdna:134]
Other income and expense for the three months ended June 30, 2014 and 2013 were as follows (in thousands):

[0001104659-14-081027:mdna:135]
|  |  | Three Months Ended |  |  |  |
|  |  | June 30, |  |  |  |
|  |  | 2014 |  | 2013 |  | Change |  |
| Investment income related to deferred compensation plan |  | $ | 264 |  | $ | 364 |  | (27 | )% |
| Impairment of investments |  | — |  | (370 | ) | (100 | ) |
| Foreign currency exchange gain (loss), net |  | (528 | ) | 491 |  | (208 | ) |
| Other |  | 66 |  | (268 | ) | (125 | ) |
|  |  | $ | (198 | ) | $ | 217 |  | (191 | ) |

[0001104659-14-081027:mdna:136]
Investment income for three months ended June 30, 2014 and 2013 represents earnings, gains, and losses on trading investments related to a deferred compensation plan offered by one of our subsidiaries.

[0001104659-14-081027:mdna:137]
There was no investment impairment during the three months ended June 30, 2014. The $0.4 million investment impairment in the three months ended June 30, 2013 resulted from the write-down of an investment in a privately-held company.

[0001104659-14-081027:mdna:138]
The foreign currency exchange loss of $0.5 million during the three months ended June 30, 2014 was due to the weakening of the U.S. dollar relative to other currencies.

[0001104659-14-081027:mdna:139]
[same as prior period, unchanged from 0001104659-14-005272:mdna:155]

[0001104659-14-081027:mdna:140]
Provision for Income Taxes

[0001104659-14-081027:mdna:141]
The provision for and (benefit from) income taxes and effective tax rates for the three months ended June 30, 2014 and 2013 were as follows (in thousands):

[0001104659-14-081027:mdna:142]
|  |  | Three Months Ended June 30, |  |
|  |  | 2014 |  | 2013 |  |
| Provision for (benefit from) income taxes |  | $ | 3,096 |  | $ | (801 | ) |
| Effective income tax rate |  | 13.6 | % | (188.5 | )% |

[0001104659-14-081027:mdna:143]
The change in the effective income tax rate for the three months ended June 30, 2014 compared with the three months ended June 30, 2013 is primarily due to the mix of income and losses in the various tax jurisdictions in which we operate.

[0001104659-14-081027:mdna:144]
As of June 30, 2014 and March 31, 2014, the total amount of unrecognized tax benefits due to uncertain tax positions was $91.8 million and $91.0 million, respectively, of which $86.8 million and $86.1 million, respectively, would affect the effective income tax rate if recognized.

[0001104659-14-081027:mdna:145]
As of June 30, 2014, we had $84.3 million in non-current income taxes payable and $0.3 million in current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions.  As of March 31, 2014, we had $93.1 million in non-current income taxes payable and $0.3 million in current income taxes payable.

[0001104659-14-081027:mdna:146]
During the quarter ended June 30, 2014, we adopted ASU No. 2013-11 “Presentation of an Unrecognized Tax Benefit When a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward Exists.”  ASU No. 2013-11 requires an unrecognized tax benefit, or a portion of an unrecognized tax benefit, to be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carryforward, a similar tax loss, or a tax credit carryforward, except to the extent a net operating loss carryforward, a similar tax loss, or a tax credit carryforward is not available at the reporting date under the tax law of the applicable jurisdiction to settle any additional income taxes that would result from the disallowance of a tax position or the tax law of the applicable jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose.  In that case, the unrecognized tax benefit should be presented in the financial statements as a liability instead and should not be netted with the deferred tax asset.  This accounting standard became effective for us on April 1, 2014 and was applied prospectively to unrecognized tax benefits that existed as of the effective date.  Upon adoption of this guidance, we netted $9.8 million of unrecognized tax benefits previously presented as non-current income taxes payable as a reduction to non-current deferred tax assets for tax credit carryforwards.

[0001104659-14-081027:mdna:147]
We continue to recognize interest and penalties related to unrecognized tax positions in income tax expense. As of June 30 and March 31, 2014, we had $5.7 million and $5.6 million of accrued interest and penalties related to uncertain tax positions, respectively.

[0001104659-14-081027:mdna:148]
[same as prior period, unchanged from 0001104659-14-005272:mdna:168]

[0001104659-14-081027:mdna:149]
[same as prior period, unchanged from 0001104659-14-005272:mdna:170]

[0001104659-14-081027:mdna:150]
[same as prior period, unchanged from 0001104659-14-005272:mdna:171]

[0001104659-14-081027:mdna:151]
As of June 30, 2014, we had cash and cash equivalents of $485.0 million, compared with $469.4 million at March 31, 2014. Our cash and cash equivalents consist of bank demand deposits and short-term time deposits of which 68% is held by our Swiss-based entities and 13% is held by our subsidiaries in Hong Kong and China. We do not expect to incur any material adverse tax impact or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001104659-14-081027:mdna:152]
As of June 30, 2014, our working capital was $509.2 million compared with working capital of $478.2 million at March 31, 2014. The increase in working capital over the prior period was primarily due to higher cash, accounts receivable and inventory balances at June 30, 2014.

[0001104659-14-081027:mdna:153]
During the three months ended June 30, 2014, we generated net cash of $27.8 million from operating activities. Our main sources of operating cash flows were net income of $19.7 after adding non-cash expenses of depreciation, amortization and share-based compensation expense, and from increases in accounts payables and accrued liabilities. These sources of operating cash flows were partially offset by increases in accounts receivables and inventories.  Net cash used in investing activities was $12.2 million, primarily from $11.2 million of investments in leasehold improvements, computer hardware and software, tooling and equipment.  Net cash generated from financing activities was $0.2 million.

[0001104659-14-081027:mdna:154]
The Company had several uncommitted, unsecured bank letters of credit aggregating $40 million as of June 30, 2014. There are no financial covenants under these letters of credit with which the Company must comply.  As of June 30, 2014, the Company had outstanding bank guarantees of $8.3 million under these letters of credit. The Company also had credit lines related to corporate credit cards totaling $6.9 million as of June 30, 2014. There are no financial covenants under these corporate credit card lines of credit.

[0001104659-14-081027:mdna:155]
We have financed our operating and capital requirements primarily through cash flow from operations and, to a much lesser extent, from capital markets and bank borrowings. Our liquidity for the next 12 months and our longer-term capital resource requirements are provided from three sources: cash flow generated from operations, cash and cash equivalents on hand, and borrowings, as needed. We believe that, based on the trend of our historical cash flow generation, and our projections of future operations and reduced expenses, our available cash balances will provide sufficient liquidity to fund our operations for at least the next 12 months.

[0001104659-14-081027:mdna:156]
The following table summarizes our Consolidated Statements of Cash Flows (in thousands):

[0001104659-14-081027:mdna:157]
|  |  | Three Months Ended |  |
|  |  | June 30, |  |
|  |  | 2014 |  | 2013 |  |
| Net cash provided by (used in) operating activities |  | $ | 27,758 |  | $ | (159 | ) |
| Net cash used in investing activities |  | (12,241 | ) | (14,664 | ) |
| Net cash provided by (used in) financing activities |  | 160 |  | (203 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (108 | ) | 59 |  |
| Net increase (decrease) in cash and cash equivalents |  | $ | 15,569 |  | $ | (14,967 | ) |

[0001104659-14-081027:mdna:158]
[same as prior period, unchanged from 0001104659-14-005272:mdna:177]

[0001104659-14-081027:mdna:159]
The following table presents selected financial information and statistics as of June 30, 2014 and 2013 (dollars in thousands):

[0001104659-14-081027:mdna:160]
|  |  | Three Months Ended |  |
|  |  | June 30, |  |
|  |  | 2014 |  | 2013 |  |
| Accounts receivable, net |  | $ | 219,022 |  | $ | 218,599 |  |
| Inventories |  | 240,357 |  | 296,246 |  |
| Working capital |  | 509,207 |  | 397,208 |  |
| Days sales in accounts receivable (“DSO”)(1) |  | 41 days |  | 41 days |  |
| Inventory turnover (“ITO”)(2) |  | 5.0x |  | 4.2x |  |

[0001104659-14-081027:mdna:161]
(1)                                 DSO is determined using ending accounts receivable as of the most recent quarter-end and net sales for the most recent quarter.

[0001104659-14-081027:mdna:162]
(2)                                 ITO is determined using ending inventories and annualized cost of goods sold (based on the most recent quarterly cost of goods sold).

[0001104659-14-081027:mdna:163]
During the three months ended June 30, 2014, we generated net cash of $27.8 million for operating activities, compared with net cash used of $0.2 million for the same period in the prior fiscal year. The primary drivers of the increase in net cash generated from operating cash flows include an increase in net income of $18.5 million in the three months ended June 30, 2014 from the three months ended June 30, 2013, a $9.4 million decrease in inventories, a $8 million increase in accounts payable, which was offset by a decrease in accrued liabilities of $8 million.

[0001104659-14-081027:mdna:164]
DSO remained relatively constant between the three months ended June 30, 2014 and the three months ended June 30, 2013. Typical payment terms require customers to pay for product sales generally within 30 to 60 days. However, terms may vary by customer type, by country and by selling season. Extended payment terms are sometimes offered to a limited number of customers during the second and third fiscal quarters. We do not modify payment terms on existing receivables, but may offer discounts for early payment.

[0001104659-14-081027:mdna:165]
Inventory turnover between the three months ended June 30, 2014 and 2013 increased due to higher net inventory balance and lower annualized cost of goods sold between the two periods.

[0001104659-14-081027:mdna:166]
[same as prior period, unchanged from 0001104659-14-005272:mdna:185]

[0001104659-14-081027:mdna:167]
The following table presents information on our cash flows from investing activities during the three months ended June 30, 2014 and 2013 (in thousands):

[0001104659-14-081027:mdna:168]
|  |  | Three Months Ended |  |
|  |  | June 30, |  |
|  |  | 2014 |  | 2013 |  |
| Purchases of property, plant and equipment |  | (11,243 | ) | (14,356 | ) |
| Investments in privately held companies |  | (1,050 | ) | — |  |
| Acquisitions, net of cash acquired |  | — |  | (650 | ) |
| Purchase of trading investments |  | (454 | ) | (4,406 | ) |
| Proceeds from sales of trading investments |  | 506 |  | 4,748 |  |
|  |  | (12,241 | ) | (14,664 | ) |

[0001104659-14-081027:mdna:169]
Our expenditures for property, plant and equipment during the three months ended June 30, 2014 and 2013 were expenditures for leasehold improvements, computer hardware and software, tooling and equipment. During the three months ended June 30, 2014, purchases of property, plant and equipment decreased, compared with three months ended June 30, 2013, primarily due to leasehold improvements related to our Silicon Valley campus during the first quarter of fiscal 2014, partially offset by increased investment in tooling and computer software during the three months ended June 30, 2014.

[0001104659-14-081027:mdna:170]
The purchases and sales of trading investments in the three months ended June 30, 2014 and 2013 represent mutual fund activity directed by participants in a deferred compensation plan offered by one of our subsidiaries. The mutual funds are held by a Rabbi Trust.

[0001104659-14-081027:mdna:171]
[same as prior period, unchanged from 0001104659-14-005272:mdna:191]

[0001104659-14-081027:mdna:172]
The following table presents information on our cash flows from financing activities during the three months ended June 30, 2014 and 2013 (in thousands):

[0001104659-14-081027:mdna:173]
|  |  | Three Months Ended |  |
|  |  | June 30, |  |
|  |  | 2014 |  | 2013 |  |
| Contingent cash payment for acquisition |  | (100 | ) | — |  |
| Proceeds from sales of shares upon exercise of options and purchase rights |  | 574 |  | 12 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (695 | ) | (215 | ) |
| Excess tax benefits from share-based compensation |  | 381 |  | — |  |
|  |  | 160 |  | (203 | ) |

[0001104659-14-081027:mdna:174]
For both the three months ended June 30, 2014 and 2013 no share repurchases were made.

[0001104659-14-081027:mdna:175]
Proceeds from the sale of shares upon exercise of options and purchase rights pursuant our stock plans during the three months ended June 30, 2014 and 2013 were $0.6 million and an immaterial amount, respectively. The payment of tax withholdings related to net share settlements of RSUs (restricted stock units) required during the three months ended June 30, 2014 and 2013 was $0.7 million and $0.2 million, respectively.

[0001104659-14-081027:mdna:176]
[same as prior period, unchanged from 0001104659-14-005272:mdna:195]

[0001104659-14-081027:mdna:177]
Our principal sources of liquidity are our cash and cash equivalents, cash flow generated from operations and, to a much lesser extent, capital markets and borrowings. Our future working capital requirements and capital expenditures may increase to support investment in product innovations and growth opportunities, or to acquire or invest in complementary businesses, products, services, and technologies.

[0001104659-14-081027:mdna:178]
In March 2014, our Board of Directors approved a new share buyback program, which authorizes us to invest up to $250.0 million to purchase our own shares. Our share buyback program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.  The Company was not current on its SEC filings and lost its ability to buy back shares. The company will regain its ability, once it is current on its SEC filings.

[0001104659-14-081027:mdna:179]
[same as prior period, unchanged from 0001104659-14-005272:mdna:197]

[0001104659-14-081027:mdna:180]
During the second quarter of fiscal year 2014, we implemented a restructuring plan solely affecting our video conferencing operating segment to align our organization to our strategic priorities of increasing focus on a tighter range of products, expanding cloud-based video conferencing services and improving profitability.

[0001104659-14-081027:mdna:181]
For over ten years, we have generated annual positive cash flows from our operating activities, including cash from operations of $27.8 million during the three months ended June 30, 2014.

[0001104659-14-081027:mdna:182]
During fiscal year 2014, we paid a cash dividend of CHF 33.7 million (U.S. dollar amount of $36.1 million) out of retained earnings. We plan to issue an annual dividend on a recurring basis. If we do not generate sufficient operating cash flows to support our operations and future planned cash requirements, our operations could be harmed and our access to credit facilities could be restricted or eliminated. However, we believe that the trend of our historical cash flow generation, our projections of future operations and reduced expenses and our available cash balances will provide sufficient liquidity to fund our operations for at least the next 12 months.

[0001104659-14-081027:mdna:183]
[same as prior period, unchanged from 0001104659-14-005272:mdna:203]

[0001104659-14-081027:mdna:184]
[same as prior period, unchanged from 0001104659-14-005272:mdna:207]

[0001104659-14-081027:mdna:185]
We lease facilities under operating leases, certain of which require it to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. The remaining terms on our non-cancelable operating leases expire in various years through 2030. Our asset retirement obligations on these leases as of June 30, 2014 were not material.

[0001104659-14-081027:mdna:186]
[same as prior period, unchanged from 0001104659-14-005272:mdna:209]

[0001104659-14-081027:mdna:187]
As of June 30, 2014, we have fixed purchase commitments for inventory purchases made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled during the second quarter of fiscal year 2015. We also had commitments for consulting services, marketing arrangements, advertising, outsourced customer services, information technology maintenance and support services, and other services. Fixed purchase commitments for capital expenditures and primarily relate to commitments for computer hardware and leasehold improvements. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us the option to reschedule and adjust our requirements based on business needs prior to delivery of goods or performance of services. As of June 30, 2014, the Company’s outstanding purchase commitments had not materially changed since March 31, 2014.

[0001104659-14-081027:mdna:188]
[same as prior period, unchanged from 0001104659-14-005272:mdna:215]

[0001104659-14-081027:mdna:189]
At June 30, 2014, we had $17.6 million in liabilities related to a deferred compensation plan offered by one of our subsidiaries. For more information, please refer to our Annual Report on Form 10-K for the fiscal year ended March 31, 2014.

[0001104659-14-081027:mdna:190]
[same as prior period, unchanged from 0001104659-14-005272:mdna:217]

[0001104659-14-081027:mdna:191]
At June 30, 2014, we had $39.0 million in liabilities related to our defined benefit pension plans and non-retirement post-employment benefit obligations, of which $1.1 million is payable in the next 12 months. For more information, please refer to our Annual Report on Form 10-K for the fiscal year ended March 31, 2014.

[0001104659-14-081027:mdna:192]
[same as prior period, unchanged from 0001104659-14-005272:mdna:219]

[0001104659-14-081027:mdna:193]
For further detail about our contractual obligations and commitments, please refer to our Annual Report on Form 10-K for the fiscal year ended March 31, 2014.

[0001104659-14-081027:mdna:194]
[same as prior period, unchanged from 0001104659-14-005272:mdna:221]

[0001104659-14-081027:mdna:195]
[same as prior period, unchanged from 0001104659-14-005272:mdna:222]

[0001104659-14-081027:mdna:196]
Other Contingencies

[0001104659-14-081027:mdna:197]
We are subject to an ongoing formal investigation by the SEC, relating to issues including the accounting for Revue inventory valuation reserves that resulted in the restatement, described in the Fiscal 2014 Form 10-K, revision to our financial statements concerning warranty accruals and amortization of intangible assets presented in our Form 10-K/A, filed on August 7, 2013, and our transactions with a distributor for Fiscal Year 2007 through Fiscal Year 2009. We are cooperating with the SEC in its ongoing investigation. We have entered into an agreement with the SEC to extend the statute of limitations. We  cannot predict the outcome of the investigation at this time and any potential fines or penalties, if any, that may arise from the investigation are currently not estimable.

[0001104659-14-081027:mdna:198]
[same as prior period, unchanged from 0001104659-14-005272:mdna:223]

[0001104659-14-081027:mdna:199]
Logitech International S.A., the parent holding company, has issued several parent guarantees on behalf of its subsidiaries. The maximum potential future payment under the guarantee arrangements is limited to $80.0 million. As of June 30, 2014, there were no purchase obligations outstanding for which the parent holding company was required to guarantee payment.

[0001104659-14-081027:mdna:200]
Logitech Europe S.A., a subsidiary of the parent holding company, has guaranteed the purchase obligations of another Logitech subsidiary under a guarantee agreement. This guarantee does not specify a maximum amount. As of June 30, 2014, the amount of purchase obligations outstanding under this guarantee was immaterial. In addition, Logitech Europe S.A. also guaranteed payments of a third-party contract manufacturer’s purchase obligations. As of June 30, 2014, the maximum amount of this guarantee was $3.5 million, of which $2.3 million of guaranteed purchase obligations were outstanding.

[0001104659-14-081027:mdna:201]
[same as prior period, unchanged from 0001104659-14-005272:mdna:227]

[0001104659-14-081027:mdna:202]
We indemnify certain of our suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2014, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001104659-14-081027:mdna:203]
[same as prior period, unchanged from 0001104659-14-005272:mdna:229]

[0001104659-14-081027:mdna:204]
Legal Proceedings

[0001104659-14-081027:mdna:205]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of its business. We are currently subject to several such claims and a small number of legal proceedings. We believe that these matters lack merit and we intend to vigorously defend against them. Based on currently available information, we do not believe that resolution of pending matters will have a material adverse effect on our financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that our defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on our business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against us, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect our business.

[0001104659-14-081027:mdna:206]
43
