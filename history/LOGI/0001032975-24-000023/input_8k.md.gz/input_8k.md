# LOGI 8-K — 0001032975-24-000015 filed 2024-04-30

## item codes, every 8-K on or before 2024-05-16

- 2024-04-30 0001032975-24-000015 — 2.02, 9.01
- 2024-03-18 0001032975-24-000012 — 5.02, 7.01, 9.01
- 2024-01-23 0001032975-24-000004 — 2.02, 9.01
- 2023-10-30 0001032975-23-000082 — 5.02, 9.01
- 2023-10-24 0001032975-23-000075 — 2.02, 9.01
- 2023-09-15 0001032975-23-000072 — 5.07, 8.01
- 2023-07-25 0001032975-23-000050 — 2.02, 9.01
- 2023-06-30 0001032975-23-000037 — 5.02 — amendment, the index does not say of what
- 2023-06-30 0001032975-23-000036 — 5.02
- 2023-06-13 0001032975-23-000030 — 5.02, 7.01, 9.01
- 2023-05-02 0001032975-23-000015 — 2.02, 9.01
- 2023-01-30 0001032975-23-000010 — 5.02, 9.01
- 2023-01-24 0001032975-23-000004 — 2.02, 5.02, 9.01
- 2023-01-12 0001628280-23-000934 — 2.02, 9.01
- 2022-10-25 0001628280-22-026927 — 2.02, 5.02, 9.01
- 2022-09-16 0001628280-22-025080 — 5.07, 8.01
- 2022-07-26 0001032975-22-000027 — 2.02, 9.01
- 2022-06-29 0001032975-22-000018 — 5.02
- 2022-05-03 0001032975-22-000008 — 2.02, 9.01
- 2022-01-25 0001032975-22-000003 — 2.02, 9.01
- 2021-10-26 0001032975-21-000043 — 2.02, 9.01
- 2021-09-10 0001032975-21-000040 — 5.07, 8.01
- 2021-07-27 0001032975-21-000029 — 2.02, 9.01
- 2021-04-29 0001032975-21-000012 — 2.02, 9.01
- 2021-01-19 0001032975-21-000004 — 2.02, 9.01
- 2020-10-20 0001032975-20-000045 — 2.02, 9.01
- 2020-09-11 0001032975-20-000042 — 5.07, 8.01
- 2020-07-21 0001032975-20-000029 — 2.02, 9.01
- 2020-07-01 0001032975-20-000023 — 5.02, 8.01
- 2020-05-12 0001032975-20-000011 — 2.02, 9.01
- 2020-03-30 0001032975-20-000009 — 5.02
- 2020-01-21 0001032975-20-000002 — 2.02, 9.01
- 2019-10-22 0001032975-19-000071 — 9.01
- 2019-09-26 0001032975-19-000068 — 1.01, 7.01, 9.01
- 2019-09-06 0001032975-19-000063 — 5.07, 8.01
- 2019-07-23 0001032975-19-000046 — 2.02, 9.01
- 2019-07-23 0001032975-19-000045 — 5.02, 9.01
- 2019-07-02 0001032975-19-000036 — 5.02
- 2019-06-25 0001032975-19-000034 — 5.02
- 2019-05-03 0001032975-19-000021 — 5.02 — amendment, the index does not say of what
- 2019-04-30 0001032975-19-000017 — 2.02, 5.02, 9.01
- 2019-03-28 0001032975-19-000013 — 5.02
- 2019-01-22 0001032975-19-000004 — 2.02, 9.01
- 2018-10-23 0001032975-18-000044 — 2.02, 9.01
- 2018-09-07 0001032975-18-000040 — 5.07, 8.01
- 2018-07-31 0001032975-18-000035 — 1.01, 2.02, 2.05, 7.01, 9.01
- 2018-06-27 0001032975-18-000020 — 5.02
- 2018-05-03 0001032975-18-000013 — 2.02, 5.02, 9.01
- 2018-01-23 0001032975-18-000005 — 2.02, 9.01
- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2024-05-16

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-24-000015:8k_2_02:1]
EX-99.1
2
exhibit991q4fy24.htm
EX-99.1

[0001032975-24-000015:8k_2_02:2]
Document

[0001032975-24-000015:8k_2_02:3]
Exhibit 99.1

[0001032975-24-000015:8k_2_02:4]
Editorial Contacts:

[0001032975-24-000015:8k_2_02:5]
Nate Melihercik, Head of Global Investor Relations - ir@logitech.com

[0001032975-24-000015:8k_2_02:6]
Nicole Kenyon, Head of Global Corporate and Internal Communications - nkenyon@logitech.com (USA)

[0001032975-24-000015:8k_2_02:7]
Ben Starkie, Corporate Communications - +41 (0) 79-292-3499, bstarkie1@logitech.com (Europe)

[0001032975-24-000015:8k_2_02:8]
Logitech Announces Q4 and Full Fiscal Year 2024 Results

[0001032975-24-000015:8k_2_02:9]
Logitech Returns To Growth With Strong Fourth Quarter;

[0001032975-24-000015:8k_2_02:10]
Company Announces FY 2025 Outlook

[0001032975-24-000015:8k_2_02:11]
LAUSANNE, Switzerland, Apr. 30, 2024 and SAN JOSE, Calif., Apr. 29, 2024 — SIX Swiss Exchange Ad hoc announcement pursuant to Art. 53 LR — Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the fourth quarter and full Fiscal Year 2024 ended March 31, 2024.

[0001032975-24-000015:8k_2_02:12]
For Q4 Fiscal Year 2024:

[0001032975-24-000015:8k_2_02:13]
•Sales were $1.01 billion, up 5 percent in US dollars and 5 percent in constant currency, compared to Q4 of the prior year.

[0001032975-24-000015:8k_2_02:14]
•GAAP operating income was $130 million, up 235 percent, compared to Q4 of the prior year. Non-GAAP operating income was $159 million, up 93 percent, compared to Q4 of the prior year.

[0001032975-24-000015:8k_2_02:15]
•GAAP earnings per share (EPS) was $1.07, up 312 percent compared to Q4 prior year. Non-GAAP EPS was $0.99, up 98 percent compared to the prior year.

[0001032975-24-000015:8k_2_02:16]
•Cash flow from operations was $239 million, up 10 percent compared to Q4 of the prior year.

[0001032975-24-000015:8k_2_02:17]
For Fiscal Year 2024:

[0001032975-24-000015:8k_2_02:18]
•Sales were $4.30 billion, down 5 percent in US dollars and 6 percent in constant currency, compared to the prior year.

[0001032975-24-000015:8k_2_02:19]
•GAAP operating income was $587 million, up 28 percent compared to the prior year. Non-GAAP operating income was $699 million, up 19 percent compared to the prior year.

[0001032975-24-000015:8k_2_02:20]
•GAAP earnings per share (EPS) was $3.87, up 74 percent compared to the prior year. Non-GAAP EPS was $4.25, up 32 percent compared to the prior year.

[0001032975-24-000015:8k_2_02:21]
•Cash flow from operations was $1.1 billion, up 114 percent compared to the prior year. The year-ending cash balance was more than $1.5 billion. The Company returned $686 million of cash to shareholders through its annual dividend payment and share repurchases.

[0001032975-24-000015:8k_2_02:22]
“We delivered a strong fourth quarter, with a return to growth and expanded gross margins,” said Hanneke Faber, Logitech chief executive officer. “Growth was broad-based across all regions and key categories."

[0001032975-24-000015:8k_2_02:23]
“We start Fiscal Year 2025 with a focus on sustainable, profitable growth supported by several long-term trends that present opportunities for our business: new ways of working, gaming, and transformational AI. Our new, ambitious mission of extending human potential in work and play expands our addressable market and our innovation opportunities. We’re excited for the journey to come.”

[0001032975-24-000015:8k_2_02:24]
Outlook

[0001032975-24-000015:8k_2_02:25]
Logitech announced its full-year outlook for Fiscal Year 2025:

[0001032975-24-000015:8k_2_02:26]
| Sales |  | $4.3 - $4.4 billion |
| Sales growth (in US dollars, year over year) |  | 0% - 2% |
| Non-GAAP operating income |  | $685 - $715 million |
| Non-GAAP op. inc. growth / (decline) (year over year) |  | (2)% - 2% |

[0001032975-24-000015:8k_2_02:27]
Financial Results Videoconference and Webcast

[0001032975-24-000015:8k_2_02:28]
Logitech will hold a financial results videoconference to discuss the results for Q4 and the full Fiscal Year 2024 on Tuesday, April 30, 2024 at 8:30 a.m. Eastern Daylight Time and 2:30 p.m. Central European Summer Time. This will also be an opportunity to hear strategic insights from Logitech chief executive officer, Hanneke Faber, on her first 100 days.

[0001032975-24-000015:8k_2_02:29]
A livestream of the event will be available on the Logitech corporate website at https://ir.logitech.com. This press release and the Q4 Fiscal Year 2024 Shareholder Letter are also available there.

[0001032975-24-000015:8k_2_02:30]
CFO Search and Annual Investor Day

[0001032975-24-000015:8k_2_02:31]
Last month, Logitech announced that Charles ‘Chuck’ Boynton, chief financial officer (CFO), will be departing the Company to pursue another career opportunity. Boynton will remain with the Company as CFO through mid-May to ensure a seamless transition for the end of the 2024 fiscal year. His successor will be named at a later date.

[0001032975-24-000015:8k_2_02:32]
Logitech plans to hold its Annual Investor Day (AID) later this year.

[0001032975-24-000015:8k_2_02:33]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-24-000015:8k_2_02:34]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures in this press release, which exclude share-based compensation expense, amortization and impairment of intangible assets, acquisition-related costs and change in fair value of contingent consideration for business acquisition, restructuring charges, net, loss on investments, pension curtailment gains, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below and posted to our website at https://ir.logitech.com. Logitech also presents percentage sales growth in constant currency (“cc”), a non-GAAP measure, to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance, outlook and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no

[0001032975-24-000015:8k_2_02:35]
reconciliation to the GAAP amounts has been provided for the full Fiscal Year 2025 non-GAAP operating income outlook.

[0001032975-24-000015:8k_2_02:36]
Public Dissemination of Certain Information

[0001032975-24-000015:8k_2_02:37]
Recordings of Logitech’s earnings videoconferences and certain events Logitech participates in or hosts, with members of the investment community are posted on the company’s investor relations website at https://ir.logitech.com. Additionally, Logitech provides notifications of news or announcements regarding its operations and financial performance, including its filings with the Securities and Exchange Commission (SEC), investor events, and press and earnings releases as part of its investor relations website. Logitech intends to use its investor relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. Logitech’s corporate governance information also is available on its investor relations website.

[0001032975-24-000015:8k_2_02:38]
About Logitech

[0001032975-24-000015:8k_2_02:39]
Logitech designs software-enabled hardware solutions that help businesses thrive and bring people together when working, creating, gaming and streaming. As the point of connection between people and the digital world, our purpose is to extend human potential in work and play, in a way that is good for people and the planet. Founded in 1981, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech and its other brands, including Logitech G, at www.logitech.com or company blog.

[0001032975-24-000015:8k_2_02:40]
# # #

[0001032975-24-000015:8k_2_02:41]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-24-000015:8k_2_02:42]
Logitech and other Logitech marks are trademarks or registered trademarks of Logitech Europe S.A. and/or its affiliates in the U.S. and other countries. All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-24-000015:8k_2_02:43]
(LOGIIR)

[0001032975-24-000015:8k_2_02:44]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net sales |  | $ | 1,011,487 |  |  | $ | 960,077 |  |  | $ | 4,298,467 |  |  | $ | 4,538,818 |  |
| Cost of goods sold |  | 572,051 |  |  | 612,703 |  |  | 2,509,418 |  |  | 2,806,438 |  |
| Amortization of intangible assets |  | 2,459 |  |  | 3,510 |  |  | 11,028 |  |  | 12,865 |  |
| Gross profit |  | 436,977 |  |  | 343,864 |  |  | 1,778,021 |  |  | 1,719,515 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 185,594 |  |  | 181,060 |  |  | 730,310 |  |  | 809,182 |  |
| Research and development |  | 75,421 |  |  | 70,630 |  |  | 287,243 |  |  | 280,796 |  |
| General and administrative |  | 38,510 |  |  | 32,437 |  |  | 155,056 |  |  | 124,652 |  |
| Amortization of intangible assets and acquisition-related costs |  | 2,655 |  |  | 2,791 |  |  | 10,934 |  |  | 11,843 |  |
| Impairment of intangible assets |  | 3,526 |  |  | — |  |  | 3,526 |  |  | — |  |
| Change in fair value of contingent consideration for business acquisition |  | (250) |  |  | — |  |  | (250) |  |  | — |  |
| Restructuring charges, net |  | 1,304 |  |  | 18,102 |  |  | 3,866 |  |  | 34,573 |  |
| Total operating expenses |  | 306,760 |  |  | 305,020 |  |  | 1,190,685 |  |  | 1,261,046 |  |
| Operating income |  | 130,217 |  |  | 38,844 |  |  | 587,336 |  |  | 458,469 |  |
| Interest income |  | 16,128 |  |  | 8,758 |  |  | 50,636 |  |  | 18,331 |  |
| Other income (expense), net |  | (2,549) |  |  | 5,089 |  |  | (16,376) |  |  | (13,278) |  |
| Income before income taxes |  | 143,796 |  |  | 52,691 |  |  | 621,596 |  |  | 463,522 |  |
| Provision for (benefit from) income taxes |  | (23,819) |  |  | 11,196 |  |  | 9,453 |  |  | 98,947 |  |
| Net income |  | $ | 167,615 |  |  | $ | 41,495 |  |  | $ | 612,143 |  |  | $ | 364,575 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.09 |  |  | $ | 0.26 |  |  | $ | 3.90 |  |  | $ | 2.25 |  |
| Diluted |  | $ | 1.07 |  |  | $ | 0.26 |  |  | $ | 3.87 |  |  | $ | 2.23 |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | 154,452 |  |  | 160,073 |  |  | 156,776 |  |  | 162,302 |  |
| Diluted |  | 156,204 |  |  | 161,524 |  |  | 158,171 |  |  | 163,704 |  |

[0001032975-24-000015:8k_2_02:45]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | March 31, |  | March 31, |  |  |  |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  | 2024 |  | 2023 |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,520,842 |  |  | $ | 1,149,023 |  |  |  |  |  |
| Accounts receivable, net |  | 541,715 |  |  | 630,382 |  |  |  |  |  |
| Inventories |  | 422,513 |  |  | 682,893 |  |  |  |  |  |
| Other current assets |  | 146,270 |  |  | 142,876 |  |  |  |  |  |
| Total current assets |  | 2,631,340 |  |  | 2,605,174 |  |  |  |  |  |
| Non-current assets: |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 116,589 |  |  | 121,503 |  |  |  |  |  |
| Goodwill |  | 461,978 |  |  | 454,610 |  |  |  |  |  |
| Other intangible assets, net |  | 44,603 |  |  | 63,173 |  |  |  |  |  |
| Other assets |  | 350,194 |  |  | 316,293 |  |  |  |  |  |
| Total assets |  | $ | 3,604,704 |  |  | $ | 3,560,753 |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 448,627 |  |  | $ | 406,968 |  |  |  |  |  |
| Accrued and other current liabilities |  | 637,262 |  |  | 643,139 |  |  |  |  |  |
| Total current liabilities |  | 1,085,889 |  |  | 1,050,107 |  |  |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Income taxes payable |  | 112,572 |  |  | 106,391 |  |  |  |  |  |
| Other non-current liabilities |  | 172,590 |  |  | 146,695 |  |  |  |  |  |
| Total liabilities |  | 1,371,051 |  |  | 1,303,193 |  |  |  |  |  |
| Shareholders' equity: |  |  |  |  |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |  |  |  |  |
| Issued shares —173,106 at March 31, 2024 and 2023 |  |  |  |  |  |  |  |  |
| Additional shares that may be issued out of conditional capital — 50,000 at March 31, 2024 and 2023 |  |  |  |  |  |  |  |  |
| Additional shares that may be issued out of authorized capital — 17,311 at March 31, 2024 and 2023 |  |  |  |  |  |  |  |  |
| Additional paid-in capital |  | 63,524 |  |  | 127,380 |  |  |  |  |  |
| Shares in treasury, at cost — 19,243 and 13,763 shares at March 31, 2024 and 2023, respectively |  | (1,351,336) |  |  | (977,266) |  |  |  |  |  |
| Retained earnings |  | 3,602,519 |  |  | 3,177,575 |  |  |  |  |  |
| Accumulated other comprehensive loss |  | (111,202) |  |  | (100,277) |  |  |  |  |  |
| Total shareholders' equity |  | 2,233,653 |  |  | 2,257,560 |  |  |  |  |  |
| Total liabilities and shareholders' equity |  | $ | 3,604,704 |  |  | $ | 3,560,753 |  |  |  |  |  |

[0001032975-24-000015:8k_2_02:46]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 167,615 |  |  | $ | 41,495 |  |  | $ | 612,143 |  |  | $ | 364,575 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  | 14,191 |  |  | 19,611 |  |  | 63,065 |  |  | 76,309 |  |
| Amortization of intangible assets |  | 5,098 |  |  | 6,234 |  |  | 21,681 |  |  | 24,407 |  |
| Impairment of intangible assets |  | 3,526 |  |  | — |  |  | 3,526 |  |  | — |  |
| Loss on investments |  | 2,461 |  |  | 1,008 |  |  | 14,674 |  |  | 14,073 |  |
| Share-based compensation expense |  | 18,697 |  |  | 19,042 |  |  | 82,889 |  |  | 70,782 |  |
| Deferred income taxes |  | (32,909) |  |  | 6,486 |  |  | (42,424) |  |  | 30,714 |  |
| Change in fair value of contingent consideration for business acquisition |  | (250) |  |  | — |  |  | (250) |  |  | — |  |
| Pension curtailment gains |  | — |  |  | (4,225) |  |  | — |  |  | (4,225) |  |
| Other |  | 43 |  |  | (406) |  |  | 379 |  |  | 1,005 |  |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | 138,305 |  |  | 174,732 |  |  | 91,519 |  |  | 51,185 |  |
| Inventories |  | 21,827 |  |  | 121,000 |  |  | 259,796 |  |  | 247,309 |  |
| Other assets |  | 7,062 |  |  | (15,284) |  |  | 10,760 |  |  | 5,634 |  |
| Accounts payable |  | (81,047) |  |  | (84,203) |  |  | 39,336 |  |  | (219,051) |  |
| Accrued and other liabilities |  | (25,514) |  |  | (68,647) |  |  | (11,978) |  |  | (128,707) |  |
| Net cash provided by operating activities |  | 239,105 |  |  | 216,843 |  |  | 1,145,116 |  |  | 534,010 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (10,312) |  |  | (23,231) |  |  | (55,897) |  |  | (92,353) |  |
| Investment in privately held companies |  | (211) |  |  | (1,731) |  |  | (617) |  |  | (4,357) |  |
| Acquisitions, net of cash acquired |  | (286) |  |  | — |  |  | (14,424) |  |  | (8,527) |  |
| Purchases of deferred compensation investments |  | (3,678) |  |  | (1,516) |  |  | (11,571) |  |  | (6,702) |  |
| Proceeds from sales of deferred compensation investments |  | 3,981 |  |  | 1,459 |  |  | 12,174 |  |  | 6,209 |  |
| Net cash used in investing activities |  | (10,506) |  |  | (25,019) |  |  | (70,335) |  |  | (105,730) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | — |  |  | — |  |  | (182,305) |  |  | (158,680) |  |
| Payment of contingent consideration for business acquisition |  | — |  |  | — |  |  | (5,002) |  |  | (5,954) |  |
| Purchases of registered shares |  | (127,428) |  |  | (90,615) |  |  | (504,203) |  |  | (418,346) |  |
| Proceeds from exercises of stock options and purchase rights |  | 16,878 |  |  | 12,726 |  |  | 32,197 |  |  | 28,790 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (1,148) |  |  | (429) |  |  | (29,744) |  |  | (29,163) |  |
| Other financing activities |  | — |  |  | — |  |  | (1,116) |  |  | — |  |
| Net cash used in financing activities |  | (111,698) |  |  | (78,318) |  |  | (690,173) |  |  | (583,353) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (8,709) |  |  | (614) |  |  | (12,789) |  |  | (24,620) |  |
| Net increase (decrease) in cash and cash equivalents |  | 108,192 |  |  | 112,892 |  |  | 371,819 |  |  | (179,693) |  |
| Cash and cash equivalents at beginning of the period |  | 1,412,650 |  |  | 1,036,131 |  |  | 1,149,023 |  |  | 1,328,716 |  |
| Cash and cash equivalents at end of the period |  | $ | 1,520,842 |  |  | $ | 1,149,023 |  |  | $ | 1,520,842 |  |  | $ | 1,149,023 |  |

[0001032975-24-000015:8k_2_02:47]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| NET SALES |  | 2024 |  | 2023 (1) |  | Change |  | 2024 |  | 2023 (1) |  | Change |
| Net sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Gaming (2) |  | $ | 273,487 |  |  | $ | 256,437 |  |  | 7 | % |  | $ | 1,231,063 |  |  | $ | 1,288,313 |  |  | (4) | % |
| Keyboards & Combos |  | 216,240 |  |  | 187,800 |  |  | 15 |  |  | 821,441 |  |  | 836,432 |  |  | (2) |  |
| Pointing Devices |  | 170,677 |  |  | 160,768 |  |  | 6 |  |  | 742,987 |  |  | 728,357 |  |  | 2 |  |
| Video Collaboration |  | 148,104 |  |  | 143,576 |  |  | 3 |  |  | 609,361 |  |  | 677,923 |  |  | (10) |  |
| Webcams |  | 75,952 |  |  | 73,156 |  |  | 4 |  |  | 325,225 |  |  | 378,688 |  |  | (14) |  |
| Tablet Accessories |  | 55,808 |  |  | 68,429 |  |  | (18) |  |  | 254,060 |  |  | 254,374 |  |  | — |  |
| Headsets |  | 45,455 |  |  | 39,147 |  |  | 16 |  |  | 168,478 |  |  | 176,576 |  |  | (5) |  |
| Other (3) |  | 25,764 |  |  | 30,764 |  |  | (16) |  |  | 145,852 |  |  | 198,155 |  |  | (26) |  |
| Total Net Sales |  | $ | 1,011,487 |  |  | $ | 960,077 |  |  | 5 | % |  | $ | 4,298,467 |  |  | $ | 4,538,818 |  |  | (5) | % |

[0001032975-24-000015:8k_2_02:48]
(1) The Company has reclassified certain prior period amounts to conform to the current period presentation.

[0001032975-24-000015:8k_2_02:49]
(2) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-24-000015:8k_2_02:50]
(3) Other primarily consists of mobile speakers and PC speakers.

[0001032975-24-000015:8k_2_02:51]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| GAAP TO NON-GAAP RECONCILIATION (A) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Gross profit - GAAP |  | $ | 436,977 |  | $ | 343,864 |  | $ | 1,778,021 |  | $ | 1,719,515 |
| Share-based compensation expense |  | 1,938 |  | 1,407 |  | 8,004 |  | 5,635 |
| Amortization of intangible assets |  | 2,459 |  | 3,510 |  | 11,028 |  | 12,865 |
| Gross profit - Non-GAAP |  | $ | 441,374 |  | $ | 348,781 |  | $ | 1,797,053 |  | $ | 1,738,015 |
| Gross margin - GAAP |  | 43.2% |  | 35.8% |  | 41.4% |  | 37.9% |
| Gross margin - Non-GAAP |  | 43.6% |  | 36.3% |  | 41.8% |  | 38.3% |
| Operating expenses - GAAP |  | $ | 306,760 |  | $ | 305,020 |  | $ | 1,190,685 |  | $ | 1,261,046 |
| Less: Share-based compensation expense |  | 16,759 |  | 17,635 |  | 74,885 |  | 65,147 |
| Less: Amortization of intangible assets and acquisition-related costs |  | 2,655 |  | 2,791 |  | 10,934 |  | 11,843 |
| Less: Impairment of intangible assets |  | 3,526 |  | — |  | 3,526 |  | — |
| Less: Change in fair value of contingent consideration for business acquisition |  | (250) |  | — |  | (250) |  | — |
| Less: Restructuring charges, net |  | 1,304 |  | 18,102 |  | 3,866 |  | 34,573 |
| Operating expenses - Non-GAAP |  | $ | 282,766 |  | $ | 266,492 |  | $ | 1,097,724 |  | $ | 1,149,483 |
| % of net sales - GAAP |  | 30.3% |  | 31.8% |  | 27.7% |  | 27.8% |
| % of net sales - Non-GAAP |  | 28.0% |  | 27.8% |  | 25.5% |  | 25.3% |
| Operating income - GAAP |  | $ | 130,217 |  | $ | 38,844 |  | $ | 587,336 |  | $ | 458,469 |
| Share-based compensation expense |  | 18,697 |  | 19,042 |  | 82,889 |  | 70,782 |
| Amortization of intangible assets and acquisition-related costs |  | 5,114 |  | 6,301 |  | 21,962 |  | 24,708 |
| Impairment of intangible assets |  | 3,526 |  | — |  | 3,526 |  | — |
| Change in fair value of contingent consideration for business acquisition |  | (250) |  | — |  | (250) |  | — |
| Restructuring charges, net |  | 1,304 |  | 18,102 |  | 3,866 |  | 34,573 |
| Operating income - Non-GAAP |  | $ | 158,608 |  | $ | 82,289 |  | $ | 699,329 |  | $ | 588,532 |
| % of net sales - GAAP |  | 12.9% |  | 4.0% |  | 13.7% |  | 10.1% |
| % of net sales - Non-GAAP |  | 15.7% |  | 8.6% |  | 16.3% |  | 13.0% |
| Net income - GAAP |  | $ | 167,615 |  | $ | 41,495 |  | $ | 612,143 |  | $ | 364,575 |
| Share-based compensation expense |  | 18,697 |  | 19,042 |  | 82,889 |  | 70,782 |
| Amortization of intangible assets and acquisition-related costs |  | 5,114 |  | 6,301 |  | 21,962 |  | 24,708 |
| Impairment of intangible assets |  | 3,526 |  | — |  | 3,526 |  | — |
| Change in fair value of contingent consideration for business acquisition |  | (250) |  | — |  | (250) |  | — |
| Restructuring charges, net |  | 1,304 |  | 18,102 |  | 3,866 |  | 34,573 |
| Loss on investments |  | 2,461 |  | 1,008 |  | 14,674 |  | 14,073 |
| Pension curtailment gains |  | — |  | (4,225) |  | — |  | (4,225) |
| Non-GAAP income tax adjustment |  | (44,039) |  | (1,167) |  | (66,073) |  | 22,129 |
| Net income - Non-GAAP |  | $ | 154,428 |  | $ | 80,556 |  | $ | 672,737 |  | $ | 526,615 |
| Net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 1.07 |  | $ | 0.26 |  | $ | 3.87 |  | $ | 2.23 |
| Diluted - Non-GAAP |  | $ | 0.99 |  | $ | 0.50 |  | $ | 4.25 |  | $ | 3.22 |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non-GAAP |  | 156,204 |  | 161,524 |  | 158,171 |  | 163,704 |

[0001032975-24-000015:8k_2_02:52]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| SHARE-BASED COMPENSATION EXPENSE |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 1,938 |  |  | $ | 1,407 |  |  | $ | 8,004 |  |  | $ | 5,635 |  |
| Marketing and selling |  | 7,157 |  |  | 9,467 |  |  | 35,780 |  |  | 34,707 |  |
| Research and development |  | 4,268 |  |  | 3,724 |  |  | 17,836 |  |  | 15,292 |  |
| General and administrative |  | 5,334 |  |  | 4,444 |  |  | 21,269 |  |  | 15,148 |  |
| Total share-based compensation expense |  | 18,697 |  |  | 19,042 |  |  | 82,889 |  |  | 70,782 |  |
| Income tax benefit |  | (4,048) |  |  | (2,254) |  |  | (15,305) |  |  | (9,750) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 14,649 |  |  | $ | 16,788 |  |  | $ | 67,584 |  |  | $ | 61,032 |  |

[0001032975-24-000015:8k_2_02:53]
*Note: These preliminary results for the three months and fiscal year ended March 31, 2024 are subject to adjustments, including subsequent events that may occur through the date of filing our Annual Report on Form 10-K.

[0001032975-24-000015:8k_2_02:54]
(A) Non-GAAP Financial Measures

[0001032975-24-000015:8k_2_02:55]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-24-000015:8k_2_02:56]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter and fiscal year ended March 31, 2024 and prior periods presented, we excluded items in the following general categories, each of which are described below:

[0001032975-24-000015:8k_2_02:57]
Share-based compensation expense. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-24-000015:8k_2_02:58]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit, operating expenses, and financial results from period to period.

[0001032975-24-000015:8k_2_02:59]
Impairment of intangible assets. We may incur impairment of intangible assets expense, primarily in connection with our past business or asset acquisitions. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such expenses are not reflective of our ongoing operating results.

[0001032975-24-000015:8k_2_02:60]
Acquisition-related costs and change in fair value of contingent consideration for business acquisition. We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition-related costs include certain incremental expenses incurred to effect a business combination. Fair value of contingent consideration is associated with our estimates of the value of earn-outs in connection with certain acquisitions. We believe that providing the non-GAAP measures excluding these costs and credits, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-24-000015:8k_2_02:61]
Restructuring charges (credits), net. These expenses are associated with restructuring plans, and will vary based on the initiatives in place during any given period. Restructuring charges may include costs related to employee terminations, facility closures and early cancellation of certain contracts as well as other costs resulting from our restructuring initiatives. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results.

[0001032975-24-000015:8k_2_02:62]
Loss (gain) on investments. We recognize losses (gains) related to our investments in various companies, which vary depending on the operational and financial performance of the companies in which we invest. These amounts include our losses (earnings) on equity method investments, investment impairments and losses (gains) resulting from sales or other events related to our investments. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such losses (gains) are not reflective of our ongoing operations.

[0001032975-24-000015:8k_2_02:63]
Pension curtailment losses (gains). Pension curtailment losses (gains) are associated with our restructuring initiatives as a result of a reduction in the number of participants in our defined benefit pension plans. We believe that providing the non-GAAP measures excluding these losses (gains), as applicable, as well as the GAAP measures, assists our investors because such losses (gains) are not reflective of our ongoing operating results.

[0001032975-24-000015:8k_2_02:64]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above as well as the income tax impact of non-recurring deferred taxes, tax settlements, and other non-routine tax events, the determination of which is based upon the nature of the underlying items. For the fiscal year ended March 31, 2024, non-GAAP income tax adjustment includes a Swiss Tax Ruling with the canton of Vaud that provides future tax benefit for ten years and the tax benefit from a remeasurement of the tax basis of goodwill under the Swiss Federal Act on Tax Reform and AHV Financing (“TRAF”) based on an agreement reached with the Swiss Tax Authority during the fiscal year ended March 31, 2024.

[0001032975-24-000015:8k_2_02:65]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-24-000015:8k_2_02:66]
Additional Supplemental Financial Information - Constant Currency

[0001032975-24-000015:8k_2_02:67]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.
