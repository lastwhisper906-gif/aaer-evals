# LOGI note change history — 0001032975-23-000080 → 0001032975-24-000008


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-01-25):
[0001032975-24-000008:note_history:1]
Changes in the Company’s warranty liabilities for the three and nine months ended December 31, 2023 and 2022 were as follows (in thousands):
  (was, 2023-10-26, similarity 0.9621):
[0001032975-23-000080:note_history:1]
Changes in the Company’s warranty liabilities for the three and six months ended September 30, 2023 and 2022 were as follows (in thousands):

- changed (2024-01-25):
[0001032975-24-000008:note_history:2]
|  | Three months ended December 31, |  | Nine months ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Beginning of the period | $ | 40,265 |  |  | $ | 41,960 |  |  | $ | 40,886 |  |  | $ | 46,219 |  |
| Provision | 11,249 |  |  | 8,920 |  |  | 30,734 |  |  | 23,440 |  |
| Settlements | (10,158) |  |  | (8,979) |  |  | (29,914) |  |  | (26,358) |  |
| Effects of foreign currency translation | 421 |  |  | 730 |  |  | 71 |  |  | (670) |  |
| End of the period | $ | 41,777 |  |  | $ | 42,631 |  |  | $ | 41,777 |  |  | $ | 42,631 |  |
  (was, 2023-10-26, similarity 0.9262):
[0001032975-23-000080:note_history:2]
|  | Three months ended September 30, |  | Six months ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Beginning of the period | $ | 39,885 |  |  | $ | 43,841 |  |  | $ | 40,886 |  |  | $ | 46,219 |  |
| Provision | 10,393 |  |  | 7,897 |  |  | 19,485 |  |  | 14,520 |  |
| Settlements | (9,838) |  |  | (9,098) |  |  | (19,756) |  |  | (17,379) |  |
| Effects of foreign currency translation | (175) |  |  | (680) |  |  | (350) |  |  | (1,400) |  |
| End of the period | $ | 40,265 |  |  | $ | 41,960 |  |  | $ | 40,265 |  |  | $ | 41,960 |  |

- changed (2024-01-25):
[0001032975-24-000008:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2023, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2023-10-26, similarity 0.9946):
[0001032975-23-000080:note_history:3]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2023, no material amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-01-25):
[0001032975-24-000008:note_history:4]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and nine months ended December 31, 2023 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2024, or any future periods.
  (was, 2023-10-26, similarity 0.9623):
[0001032975-23-000080:note_history:4]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and six months ended September 30, 2023 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2024, or any future periods.

- changed (2024-01-25):
[0001032975-24-000008:note_history:5]
As a result of these changes, certain prior-period amounts for the three and nine months ended December 31, 2022 have been reclassified to conform to the current period presentation as follows (in thousands):
  (was, 2023-10-26, similarity 0.8966):
[0001032975-23-000080:note_history:5]
As a result of these changes, certain prior-period amounts for the three and six months ended September 30, 2022 have been reclassified to conform to the current period presentation as follows (in thousands):

- changed (2024-01-25):
[0001032975-24-000008:note_history:6]
|  |  | Three months ended December 31, 2022 |
|  |  | As previously reported |  | Reclassifications |  | As adjusted |
| Gaming |  | $ | 391,975 |  |  | $ | 19,952 |  | (1) | $ | 411,927 |  |
| Keyboards & Combos |  | 220,059 |  |  | — |  |  | 220,059 |  |
| Pointing Devices |  | 199,106 |  |  | — |  |  | 199,106 |  |
| Video Collaboration |  | 226,374 |  |  | (52,858) |  | (2) (3) | 173,516 |  |
| Webcams (3) |  | 58,481 |  |  | 35,771 |  | (3) | 94,252 |  |
| Tablet Accessories |  | 65,157 |  |  | — |  |  | 65,157 |  |
| Headsets |  | — |  |  | 46,736 |  | (2) | 46,736 |  |
| Other |  | 1,348 |  |  | 57,824 |  | (4) (5) | 59,172 |  |
| Mobile Speakers |  | 38,321 |  |  | (38,321) |  | (4) | — |  |
| Audio & Wearables |  | 69,104 |  |  | (69,104) |  | (1) (2) (5) | — |  |
| Total Sales |  | $ | 1,269,925 |  |  | $ | — |  |  | $ | 1,269,925 |  |
  (was, 2023-10-26, similarity 0.9946):
[0001032975-23-000080:note_history:6]
|  |  | Three months ended September 30, 2022 |
|  |  | As previously reported |  | Reclassifications |  | As adjusted |
| Gaming |  | $ | 297,676 |  |  | $ | 24,352 |  | (1) | $ | 322,028 |  |
| Keyboards & Combos |  | 200,853 |  |  | — |  |  | 200,853 |  |
| Pointing Devices |  | 185,200 |  |  | — |  |  | 185,200 |  |
| Video Collaboration |  | 236,180 |  |  | (56,981) |  | (2) (3) | 179,199 |  |
| Webcams (3) |  | 60,166 |  |  | 41,852 |  | (3) | 102,018 |  |
| Tablet Accessories |  | 54,203 |  |  | — |  |  | 54,203 |  |
| Headsets |  | — |  |  | 44,750 |  | (2) | 44,750 |  |
| Other |  | 2,207 |  |  | 58,493 |  | (4) (5) | 60,700 |  |
| Mobile Speakers |  | 39,195 |  |  | (39,195) |  | (4) | — |  |
| Audio & Wearables |  | 73,271 |  |  | (73,271) |  | (1) (2) (5) | — |  |
| Total Sales |  | $ | 1,148,951 |  |  | $ | — |  |  | $ | 1,148,951 |  |

- changed (2024-01-25):
[0001032975-24-000008:note_history:7]
|  |  | Nine months ended December 31, 2022 |
|  |  | As previously reported |  | Reclassifications |  | As adjusted |
| Gaming |  | $ | 972,457 |  |  | $ | 59,419 |  | (1) | $ | 1,031,876 |  |
| Keyboards & Combos |  | 648,632 |  |  | — |  |  | 648,632 |  |
| Pointing Devices |  | 567,589 |  |  | — |  |  | 567,589 |  |
| Video Collaboration |  | 708,796 |  |  | (174,449) |  | (2) (3) | 534,347 |  |
| Webcams (3) |  | 178,033 |  |  | 127,499 |  | (3) | 305,532 |  |
| Tablet Accessories |  | 185,945 |  |  | — |  |  | 185,945 |  |
| Headsets |  | — |  |  | 137,429 |  | (2) | 137,429 |  |
| Other |  | 5,642 |  |  | 161,749 |  | (4) (5) | 167,391 |  |
| Mobile Speakers |  | 99,826 |  |  | (99,826) |  | (4) | — |  |
| Audio & Wearables |  | 211,821 |  |  | (211,821) |  | (1) (2) (5) | — |  |
| Total Sales |  | $ | 3,578,741 |  |  | $ | — |  |  | $ | 3,578,741 |  |
  (was, 2023-10-26, similarity 0.9705):
[0001032975-23-000080:note_history:7]
|  |  | Six months ended September 30, 2022 |
|  |  | As previously reported |  | Reclassifications |  | As adjusted |
| Gaming |  | $ | 580,482 |  |  | $ | 39,467 |  | (1) | $ | 619,949 |  |
| Keyboards & Combos |  | 428,573 |  |  | — |  |  | 428,573 |  |
| Pointing Devices |  | 368,483 |  |  | — |  |  | 368,483 |  |
| Video Collaboration |  | 482,422 |  |  | (121,591) |  | (2) (3) | 360,831 |  |
| Webcams (3) |  | 119,552 |  |  | 91,728 |  | (3) | 211,280 |  |
| Tablet Accessories |  | 120,788 |  |  | — |  |  | 120,788 |  |
| Headsets |  | — |  |  | 90,693 |  | (2) | 90,693 |  |
| Other |  | 4,294 |  |  | 103,925 |  | (4) (5) | 108,219 |  |
| Mobile Speakers |  | 61,505 |  |  | (61,505) |  | (4) | — |  |
| Audio & Wearables |  | 142,717 |  |  | (142,717) |  | (1) (2) (5) | — |  |
| Total Sales |  | $ | 2,308,816 |  |  | $ | — |  |  | $ | 2,308,816 |  |

- changed (2024-01-25):
[0001032975-24-000008:note_history:8]
There have been no material changes in the Company’s significant accounting policies during the three and nine months ended December 31, 2023 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2023.
  (was, 2023-10-26, similarity 0.9208):
[0001032975-23-000080:note_history:8]
There have been no material changes in the Company’s significant accounting policies during the three and six months ended September 30, 2023 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2023.

- added (2024-01-25):
[0001032975-24-000008:note_history:9]
The global and regional economic and political conditions adversely affected demand for the Company's products. In addition, these conditions, including recent transportation issues in the Red Sea, have caused and may continue to cause volatility in the cost of materials and logistics, and transportation delays, and as a result may impact the pricing of the Company's products, product availability and the Company's results of operations.

- added (2024-01-25):
[0001032975-24-000008:note_history:10]
Recent Accounting Pronouncements Not Yet Adopted

- added (2024-01-25):
[0001032975-24-000008:note_history:11]
In November 2023, the Financial Accounting Standard Board ("FASB") issued Accounting Standards Update ("ASU") 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures. ASU 2023-07 improves reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses that are regularly provided to the chief operating decision maker. In addition, ASU 2023-07 requires that all existing annual disclosures about segment profit or loss must be provided on an interim basis and clarifies that single reportable segment entities are subject to the disclosure requirement under Topic 280 in its entirety. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 and interim periods within those fiscal years beginning after December 15, 2024. A public entity should apply ASU 2023-07 retrospectively to all prior periods presented in the financial statements. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2023-07 on its consolidated financial statements and related disclosures. 
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. ASU 2023-09 requires additional disclosures related to rate reconciliation, income taxes paid, and other disclosures. Under ASU 2023-09, for each annual periods presented, public entities are required to (1) disclose specific categories in the tabular rate reconciliation and (2) provide additional information for reconciling items that meet a quantitative threshold. In addition, ASU 2023-09 requires all reporting entities to disclose on an annual basis the amount of income taxes paid disaggregated by federal, state, and foreign taxes as well as the amount of income taxes paid by individual jurisdiction. ASU 2023-09 is effective for public business entities for annual periods beginning after December 15, 2024 and can be applied on a prospective basis with an option to apply the standard retrospectively. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2023-09 on its consolidated financial statements and related disclosures.

- removed (2024-01-25):
[0001032975-23-000080:note_history:12]
The global and regional economic and political conditions adversely affect demand for the Company's products. These conditions also had an impact on the Company's suppliers, contract manufacturers, logistics providers, and distributors, causing volatility in cost of materials and shipping and transportation rates, and as a result, impacting the pricing of the Company's products.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-01-25):
[0001032975-24-000008:note_history:13]
Financing Arrangements

- changed (2024-01-25):
[0001032975-24-000008:note_history:14]
The Company had several uncommitted, unsecured bank lines of credit and letters of credit aggregating $176.1 million and $181.3 million as of December 31, 2023 and March 31, 2023, respectively. There are no financial covenants under the lines of credit with which the Company must comply. There was no borrowing outstanding under the lines of credit as of December 31, 2023 or March 31, 2023. As of December 31, 2023 and March 31, 2023, the Company had outstanding bank guarantees of $11.1 million and $13.6 million, respectively.
  (was, 2023-10-26, similarity 0.9556):
[0001032975-23-000080:note_history:14]
Financing Arrangements The Company had several uncommitted, unsecured bank lines of credit and letters of credit aggregating $171.5 million and $181.3 million as of September 30, 2023 and March 31, 2023, respectively. There are no financial covenants under the lines of credit with which the Company must comply. There was no borrowing outstanding under the lines of credit as of September 30, 2023 or March 31, 2023. As of September 30, 2023 and March 31, 2023, the Company had outstanding bank guarantees of $12.2 million and $13.6 million, respectively.
