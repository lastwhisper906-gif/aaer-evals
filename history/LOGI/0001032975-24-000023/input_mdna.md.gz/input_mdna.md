# LOGI MD&A — 0001032975-24-000023


## mdna

[0001032975-24-000023:mdna:1]
ITEM 7.    MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001032975-24-000023:mdna:2]
Company Overview

[0001032975-24-000023:mdna:3]
Logitech designs software-enabled hardware solutions that help businesses thrive and bring people together when working, creating, gaming and streaming. As a point of connection between people and the digital world, our mission is to extend human potential in work and play, in a way that is good for people and the planet. We sell these products through a number of brands, including Logitech, Logitech G and others.

[0001032975-24-000023:mdna:4]
Our diverse portfolio includes: Gaming, Keyboards & Combos, Pointing Devices, Video Collaboration, Webcams, Tablet Accessories, and Headsets. These products are all classified under a single operating segment: Peripherals (see Note 15 to our consolidated financial statements).

[0001032975-24-000023:mdna:5]
We sell our products to a broad network of international customers, in the Americas, Europe, the Middle East and Africa (“EMEA”) and Asia Pacific. This includes direct sales to retailers, e-tailers, and end consumers through our e-commerce platform, and indirect sales to end customers through distributors.

[0001032975-24-000023:mdna:6]
From time to time, we may seek to partner with or acquire, when appropriate, companies that have products, personnel, and technologies that complement our strategic direction. We continually review our product offerings and our strategic direction in light of our profitability targets, competitive conditions, changing consumer trends and the evolving nature of the interface between the consumer and the digital world.

[0001032975-24-000023:mdna:7]
Impacts of Macroeconomic and Geopolitical Conditions on our Business

[0001032975-24-000023:mdna:8]
Our business has been impacted by adverse macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, changes in fiscal policies, slowdown of economic activity around the world, and lower consumer and enterprise spending.

[0001032975-24-000023:mdna:9]
The global and regional economic and political conditions adversely affected demand for our products. In addition, these conditions have caused and may continue to cause volatility in the cost of materials and logistics, and transportation delays, and as a result may impact the pricing of our products, product availability and our results of operations.

[0001032975-24-000023:mdna:10]
For additional information, see Item 1A "Risk Factors," including under the captions "Adverse global and regional economic and geopolitical conditions can materially adversely affect our business, results of operations and financial condition," “We purchase key components and products from a limited number of sources, and our business and operating results could be adversely affected if supply were delayed or constrained or if there were shortages of required components,” “Our principal manufacturing operations and third-party contract manufacturers are located in China and Southeast Asia, which exposes us to risks associated with doing business in that geographic area as well as potential tariffs, adverse trade regulations, adverse tax consequences and pressure to move or diversify our manufacturing locations,” “If we do not accurately forecast market demand for our products, our business and operating results could be adversely affected,” and "If we do not successfully coordinate the worldwide manufacturing and distribution of our products, we could lose sales and our business and operating results could be adversely affected.”

[0001032975-24-000023:mdna:11]
Trends and Uncertainties

[0001032975-24-000023:mdna:12]
Several long-term secular-trends offer long-term structural growth opportunities across Logitech’s product portfolio. We design, create and sell products that benefit from these secular trends which include the following:

[0001032975-24-000023:mdna:13]
•Hybrid work: Hybrid work provides an opportunity to equip multiple workspaces including in the office and other places of work, as well as at home and away from home. Hybrid work also provides an opportunity for increased enterprise and consumer adoption of video conferencing. Our video collaboration products are compatible with a variety of video conference platforms, including Zoom, Microsoft Teams and Google Meet

[0001032975-24-000023:mdna:14]
•Gaming: The ongoing growth and evolution of gaming creates an opportunity for us to provide more tools to a wider community of gamers. In particular, social gaming continues to gain popularity through online gaming, multi-platform experiences and esports.

[0001032975-24-000023:mdna:15]
•AI: AI has reshaped expectations for productivity improvements, product innovation and technology ecosystem evolution. While we have used AI solutions and machine learning to enhance the features of different products in our portfolio, AI offers additional growth opportunities and risks as we work to integrate our capabilities with our ecosystem partners.

[0001032975-24-000023:mdna:16]
•Climate change: Climate change affects everyone. We already consider sustainability as part of our product design and in other areas and intend to continue to do so in the future.

[0001032975-24-000023:mdna:17]
•The importance of trust: With our well-established Logitech brand, consumer-centric design philosophy, and commitment to high privacy and security standards, we strive to deliver trusted user experiences.

[0001032975-24-000023:mdna:18]
While we believe we will further benefit from these secular trends, we have experienced and will continue to experience challenges that impact our business and financial results. These challenges include (i) the current macroeconomic environment, including interest rate fluctuations, inflation, foreign exchange movements, changes in fiscal policies and low economic growth in certain regions, (ii) the uncertainty with overall consumer and enterprise demand, (iii) the uncertainty with enterprise strategy for office space utilization and related timing of enterprise investments in infrastructure and technology, and (iv) the timing of further development of our B2B go-to-market capabilities.

[0001032975-24-000023:mdna:19]
We expect these challenges to continue in the near-term. We have taken steps to mitigate the impact of these challenges, including but not limited to: (i) reduction in our operating expenses in order to maintain margins and size the business for the current market, (ii) reduction in inventories to more appropriately align with demand, (iii) continued investment in our B2B capabilities, and (iv) release of new products to increase the value proposition of our portfolio.

[0001032975-24-000023:mdna:20]
For additional information, see Part I, Item 1A “Risk Factors.”

[0001032975-24-000023:mdna:21]
Business Seasonality and Product Introductions

[0001032975-24-000023:mdna:22]
We have historically experienced higher sales in our third fiscal quarter ending December 31, compared to other fiscal quarters in our fiscal year, primarily due to the increased consumer demand for our products during the year-end holiday buying season and year-end spending by enterprises. Additionally, new product introductions and business acquisitions can significantly impact sales, product costs and operating expenses. Product introductions can also impact our sales to distribution channels as these channels are filled with new product inventory following a product introduction, and often channel inventory of an earlier model product declines as the next related major product launch approaches. Sales can also be affected when consumers and distributors anticipate a product introduction or changes in business circumstances. However, neither historical seasonal patterns nor historical patterns of product introductions should be considered reliable indicators of our future pattern of product introductions, future sales or financial performance. Furthermore, cash flow is correspondingly lower in the first half of our fiscal year as we typically build inventories in advance for the third quarter and we pay an annual dividend following our Annual General Meeting, which is typically in September.

[0001032975-24-000023:mdna:23]
Summary of Financial Results

[0001032975-24-000023:mdna:24]
Our total sales for fiscal year 2024 decreased 5%, compared to fiscal year 2023, primarily driven by a decline in sales of most of our product categories as a result of lower demand.

[0001032975-24-000023:mdna:25]
Sales for fiscal year 2024 decreased 16% and 2% in the Asia Pacific and Americas regions, respectively, and were flat in EMEA, compared to fiscal year 2023.

[0001032975-24-000023:mdna:26]
Gross margin for fiscal year 2024 increased by 350 basis points to 41.4%, compared to 37.9% for fiscal year 2023, primarily due to lower material and logistics costs as well as lower promotional spend, partially offset by unfavorable product mix.

[0001032975-24-000023:mdna:27]
Operating expenses for fiscal year 2024 were $1,190.7 million, or 27.7% of sales, compared to $1,261.0 million, or 27.8% of sales, for fiscal year 2023. The decrease in operating expenses was primarily driven by a reduction in marketing spend.

[0001032975-24-000023:mdna:28]
Included in the income tax provision of $9.5 million and $98.9 million in fiscal year 2024 and 2023 was $20.7 million of tax benefit and $46.0 million of tax expense, respectively, from Switzerland.

[0001032975-24-000023:mdna:29]
Net income for fiscal year 2024 was $612.1 million, compared to $364.6 million for fiscal year 2023, reflecting higher gross margin as well as lower operating expenses and income tax provision.

[0001032975-24-000023:mdna:30]
Critical Accounting Estimates

[0001032975-24-000023:mdna:31]
The preparation of financial statements and related disclosures in conformity with U.S. GAAP requires us to make assumptions, judgments, and estimates that affect reported amounts of assets, liabilities, sales and expenses, and the disclosure of contingent assets and liabilities.

[0001032975-24-000023:mdna:32]
We consider an accounting estimate critical if it: (i) requires management to make judgments and estimates about matters that are inherently uncertain; and (ii) is important to an understanding of our financial condition and operating results.

[0001032975-24-000023:mdna:33]
We base our assumptions, judgments and estimates on historical experience and various other factors that we believe to be reasonable under the circumstances. Although these assumptions, judgments, and estimates are based on management's best knowledge of current events and actions that may impact us in the future, actual results could differ. Management has discussed the development, selection and disclosure of these critical accounting estimates with the Audit Committee of the Board of Directors.

[0001032975-24-000023:mdna:34]
We believe the following accounting estimates are most critical to our business operations and to an understanding of our financial condition and results of operations and reflect the more significant judgments and estimates used in the preparation of our consolidated financial statements.

[0001032975-24-000023:mdna:35]
Accruals for Customer Programs and Product Returns

[0001032975-24-000023:mdna:36]
We record accruals for cooperative marketing, customer incentive, pricing programs ("Customer Programs") and product returns. The estimated cost of these programs is usually recorded as a reduction of revenue. Significant management judgments and estimates must be used to determine the cost of these programs in any accounting period. Customer Programs require management to estimate the percentage of those programs that will not be claimed in the current period or will not be earned by customers, which is commonly referred to as "breakage." Breakage is estimated based on historical claim experience, the period in which the claims are expected to be submitted, specific terms and conditions with customers, and other factors. If we receive a separately identifiable benefit from a customer and can reasonably estimate the fair value of that benefit, the cost of the Customer Programs is recognized in operating expenses.

[0001032975-24-000023:mdna:37]
Customer Incentive Programs. Customer incentive programs include performance-based incentives and consumer rebates. We offer performance-based incentives to our customers and indirect partners based on predetermined performance criteria. Consumer rebates are offered from time to time at our discretion for the primary benefit of end-users. Customer incentive programs are considered variable consideration, which we estimate and record as a reduction to revenue at the time of sale based on negotiated terms, historical experiences, forecasted incentives, the anticipated volume of future purchases, and inventory levels in the channel.

[0001032975-24-000023:mdna:38]
Product Returns. We grant limited rights to return products. Return rights vary by customer and range from just the right to return the defective product to stock rotation rights limited to a percentage of sales approved by management. Estimates of expected future product returns are recognized at the time of sale based on analyses of historical return trends by the customer and by product, inventories owned by and located at customers, current customer demand, current operating conditions, and other relevant customer and product information. Upon recognition, we reduce sales and cost of goods sold for the estimated return. Return trends are influenced by product life cycle status, new product introductions, market acceptance of products, sales levels, product sell-through, the type of customer, seasonality, product quality issues, competitive pressures, operational policies and procedures, and other factors. Return rates can fluctuate over time but are sufficiently predictable to allow us to estimate expected future product returns.

[0001032975-24-000023:mdna:39]
We apply a breakage rate to reduce our accruals of Customer Programs based on the estimated percentage of these Customer Programs that will not be claimed or earned. The breakage rate is applied at the time of sale. Assessing the period in which claims are expected to be submitted and the relevance of the historical claim experience require significant management judgment to estimate the breakage of Customer Programs in any accounting period.

[0001032975-24-000023:mdna:40]
We regularly evaluate the adequacy of our accruals for Customer Programs and product returns. Future market conditions and product transitions may require us to take action to increase such programs. In addition, when the variables used to estimate these costs change, or if actual costs differ significantly from the estimates, we would be required to record incremental increases or reductions to revenue or operating expenses.

[0001032975-24-000023:mdna:41]
Inventory Valuation

[0001032975-24-000023:mdna:42]
We must order components for our products and build inventory in advance of customer orders. Further, our industry is characterized by rapid technological change, short-term customer commitments and rapid changes in demand.

[0001032975-24-000023:mdna:43]
We record inventories at the lower of cost and net realizable value and record write-downs of inventories that are obsolete or in excess of anticipated demand or net realizable value. A review of inventory is performed each fiscal quarter that considers factors including the marketability and product lifecycle stage, product development plans, component cost trends, historical sales, and demand forecasts that consider the assumptions about future demand and market conditions. Inventory on hand that is not expected to be sold or utilized is considered excess, and we recognize the write-down in the cost of goods sold at the time of such determination. The write-down is determined by the excess of cost over net realizable value. Net realizable value is the estimated selling price in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. At the time of loss recognition, new cost basis per unit and the lower-cost basis for that inventory are established and subsequent changes in facts and circumstances would not result in an increase in the cost basis. If there is an abrupt and substantial decline in demand for Logitech's products or an unanticipated change in technological or customer requirements, we may be required to record additional write-downs that could adversely affect gross margins in the period when the write-downs are recorded. We also extend the assessment to non-cancelable purchase orders if the inventories are considered excess and record the liability that is reasonably possible to be incurred in accrued and other liabilities.

[0001032975-24-000023:mdna:44]
Accounting for Income Taxes

[0001032975-24-000023:mdna:45]
We operate in multiple jurisdictions and our profits are taxed pursuant to the tax laws of these jurisdictions. Our effective income tax rate may be affected by the changes in or interpretations of tax laws and tax agreements in any given jurisdiction, utilization of net operating loss and tax credit carryforwards, changes in geographical mix of income and expense, and changes in our assessment of matters such as the ability to realize deferred tax assets. As a result of these considerations, we must estimate income taxes in each of the jurisdictions in which we operate. This process involves estimating current tax exposure together with assessing temporary differences resulting from the different treatment of items for tax and accounting purposes. These differences result in deferred tax assets and liabilities, which are included in the consolidated balance sheet.

[0001032975-24-000023:mdna:46]
We make certain estimates and judgments about the application of tax laws, the expected resolution of uncertain tax positions and other matters surrounding the recognition and measurement of uncertain tax benefits. In the event that uncertain tax positions are resolved for amounts different than our estimates, or the related statutes of limitations expire without the assessment of additional income taxes, we will be required to adjust the amounts of the related assets and liabilities in the period in which such events occur. Such adjustments may have a material impact on our income tax provision and our results of operations.

[0001032975-24-000023:mdna:47]
For additional information about our Critical Accounting Estimates, see Note 2—Summary of Significant Accounting Policies in our Notes to our consolidated financial statements below.

[0001032975-24-000023:mdna:48]
New Accounting Pronouncements

[0001032975-24-000023:mdna:49]
Refer to Note 2 to the consolidated financial statements included in this Annual Report on Form 10-K for recent accounting pronouncements to be adopted.

[0001032975-24-000023:mdna:50]
Constant Currency

[0001032975-24-000023:mdna:51]
We refer to our net sales growth rates excluding the impact of currency exchange rate fluctuations as "constant currency" sales growth rates. Percentage of constant currency sales growth is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.

[0001032975-24-000023:mdna:52]
Given our global sales presence and the reporting of our financial results in U.S. Dollars, our financial results could be affected by significant shifts in currency exchange rates. See “Results of Operations” for information on the effect of currency exchange rate fluctuations on our sales. If the U.S. Dollar appreciates or depreciates in comparison to other currencies in future periods, this will affect our results of operations in future periods as well.

[0001032975-24-000023:mdna:53]
References to Sales

[0001032975-24-000023:mdna:54]
The term “sales” means net sales, except as otherwise specified and the sales growth discussion and sales growth rate percentages are in U.S. Dollars, except as otherwise specified.

[0001032975-24-000023:mdna:55]
Results of Operations

[0001032975-24-000023:mdna:56]
In this section, we discuss the results of our operations for the year ended March 31, 2024 compared to the year ended March 31, 2023. For a discussion of the year ended March 31, 2023 compared to the year ended March 31, 2022, please refer to Part II, Item 7, "Management's Discussion and Analysis of Financial Condition and Results of Operations" in our Annual Report on Form 10-K filed with the SEC on May 17, 2023.

[0001032975-24-000023:mdna:57]
Net Sales

[0001032975-24-000023:mdna:58]
Our sales in fiscal year 2024 decreased 5%, compared to fiscal year 2023, primarily driven by a decline in sales of most of our product categories as a result of lower demand. If currency exchange rates had been constant in fiscal years 2024 and 2023, our sales decline in constant currency would have been 6%.

[0001032975-24-000023:mdna:59]
Sales Denominated in Other Currencies

[0001032975-24-000023:mdna:60]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Australian Dollar, Canadian Dollar, Pound Sterling and New Taiwan Dollar. For the years ended March 31, 2024 and 2023, approximately 50% and 51%, respectively, of our sales were denominated in currencies other than the U.S. Dollar.

[0001032975-24-000023:mdna:61]
Sales by Region

[0001032975-24-000023:mdna:62]
The following table presents the change in sales by region for fiscal year 2024 compared with fiscal year 2023:

[0001032975-24-000023:mdna:63]
|  |  | 2024 vs. 2023 |  |  |
|  |  | Sales Growth Rate |  | Sales Growth Rate in Constant Currency |  |  |  |  |
| Americas |  | (2) | % |  | (2) | % |  |  |  |  |
| EMEA |  | — |  |  | (4) |  |  |  |  |  |
| Asia Pacific |  | (16) |  |  | (13) |  |  |  |  |  |

[0001032975-24-000023:mdna:64]
Americas:

[0001032975-24-000023:mdna:65]
The decrease in sales in the Americas region for fiscal year 2024, compared to fiscal year 2023, was primarily driven by decreases in sales for mobile speakers and PC speakers in our Other category.

[0001032975-24-000023:mdna:66]
EMEA:

[0001032975-24-000023:mdna:67]
Sales in the EMEA region for fiscal year 2024, compared to fiscal year 2023, remained flat. Increases in sales for Gaming and Pointing Devices were offset by decreases in sales for Webcams and Video Collaboration.

[0001032975-24-000023:mdna:68]
Asia Pacific:

[0001032975-24-000023:mdna:69]
The decrease in sales in the Asia Pacific region for fiscal year 2024, compared to fiscal year 2023, was primarily driven by decreases in sales of Gaming, Keyboards & Combos and Video Collaboration.

[0001032975-24-000023:mdna:70]
Sales by Product Category

[0001032975-24-000023:mdna:71]
During the first quarter of fiscal year 2024, we changed the presentation of sales by product category to provide a simpler and clearer view of our business. The change in presentation did not have an impact on previously reported total sales. As a result of these changes, certain prior-period amounts for the fiscal year 2023 have been reclassified to conform to the current period presentation. See Note 2 to the consolidated financial statements for further information on the change in presentation.

[0001032975-24-000023:mdna:72]
Sales by product category in the current presentation for fiscal years 2024 and 2023 were as follows (Dollars in thousands):

[0001032975-24-000023:mdna:73]
|  |  | Years Ended March 31, |  | Change |
|  |  | 2024 |  | 2023 |  | 2024 vs. 2023 |
| Gaming (1) |  | $ | 1,231,063 |  |  | $ | 1,288,313 |  |  | (4) | % |
| Keyboards & Combos |  | 821,441 |  |  | 836,432 |  |  | (2) |  |
| Pointing Devices |  | 742,987 |  |  | 728,357 |  |  | 2 |  |
| Video Collaboration |  | 609,361 |  |  | 677,923 |  |  | (10) |  |
| Webcams |  | 325,225 |  |  | 378,688 |  |  | (14) |  |
| Tablet Accessories |  | 254,060 |  |  | 254,374 |  |  | — |  |
| Headsets |  | 168,478 |  |  | 176,576 |  |  | (5) |  |
| Other (2) |  | 145,852 |  |  | 198,155 |  |  | (26) |  |
| Total Sales |  | 4,298,467 |  |  | 4,538,818 |  |  | (5) | % |

[0001032975-24-000023:mdna:74]
(1) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-24-000023:mdna:75]
(2) Other primarily consists of mobile speakers and PC speakers.

[0001032975-24-000023:mdna:76]
Gaming

[0001032975-24-000023:mdna:77]
Our Gaming category includes gaming mice, steering wheels, headsets, keyboards, console gaming headsets, studio-quality Blue Microphones and Streamlabs services.

[0001032975-24-000023:mdna:78]
During fiscal year 2024, Gaming sales decreased 4%, compared to fiscal year 2023, primarily driven by decreases in sales of gaming keyboards, Blue Microphones, and Streamlabs services.

[0001032975-24-000023:mdna:79]
Keyboards & Combos

[0001032975-24-000023:mdna:80]
Our Keyboards & Combos category includes PC keyboards and keyboard/mice combo products.

[0001032975-24-000023:mdna:81]
During fiscal year 2024, Keyboards & Combos sales decreased 2%, compared to fiscal year 2023, primarily driven by a decrease in sales of our cordless keyboards, partially offset by an increase in sales of our cordless combos.

[0001032975-24-000023:mdna:82]
Pointing Devices

[0001032975-24-000023:mdna:83]
Our Pointing Devices category includes PC- and Mac-related mice including trackballs and presentation tools.

[0001032975-24-000023:mdna:84]
During fiscal year 2024, Pointing Devices sales increased 2%, compared to fiscal year 2023, primarily driven by increases in sales of cordless mice and presentation tools.

[0001032975-24-000023:mdna:85]
Video Collaboration

[0001032975-24-000023:mdna:86]
Our Video Collaboration category includes Logitech’s conference room cameras, which combine affordable enterprise-quality audio and high definition 4K video to bring video conferencing to a variety of room sizes.

[0001032975-24-000023:mdna:87]
During fiscal year 2024, Video Collaboration sales decreased 10%, compared to fiscal year 2023, primarily due to decreases in sales of many Video Collaboration products driven by lower enterprise spending.

[0001032975-24-000023:mdna:88]
Webcams

[0001032975-24-000023:mdna:89]
Our Webcams category includes PC-based webcams that are targeted primarily at consumers, including streaming cameras, and VC webcams that turn any desktop into an instant collaboration space.

[0001032975-24-000023:mdna:90]
During fiscal year 2024, Webcams sales decreased 14%, compared to fiscal year 2023, primarily driven by decreases in sales of most of our VC webcams and PC-based webcams.

[0001032975-24-000023:mdna:91]
Tablet Accessories

[0001032975-24-000023:mdna:92]
Our Tablet Accessories category primarily includes tablet keyboards.

[0001032975-24-000023:mdna:93]
During fiscal year 2024, Tablet Accessories sales remained flat, compared to fiscal year 2023.

[0001032975-24-000023:mdna:94]
Headsets

[0001032975-24-000023:mdna:95]
Our Headsets category includes PC and VC headsets, in-ear headphones, and premium wireless earbuds.

[0001032975-24-000023:mdna:96]
During fiscal year 2024, Headsets sales decreased 5%, compared to 2023, primarily driven by decreases in sales of VC headsets and corded PC headsets.

[0001032975-24-000023:mdna:97]
Other

[0001032975-24-000023:mdna:98]
Our Other category primarily consists of mobile speakers and PC speakers.

[0001032975-24-000023:mdna:99]
During fiscal year 2024, Other sales decreased 26% compared to 2023, primarily driven by a decline in sales of mobile speakers.

[0001032975-24-000023:mdna:100]
Gross Profit

[0001032975-24-000023:mdna:101]
Gross profit for fiscal years 2024 and 2023 was as follows (Dollars in thousands):

[0001032975-24-000023:mdna:102]
|  |  | Years Ended March 31, |
|  |  | 2024 |  | 2023 |  | Change |
| Net sales |  | $ | 4,298,467 |  |  | $ | 4,538,818 |  |  | (5.3) | % |
| Gross profit |  | $ | 1,778,021 |  |  | $ | 1,719,515 |  |  | 3.4 | % |
| Gross margin |  | 41.4 | % |  | 37.9 | % |  |  |

[0001032975-24-000023:mdna:103]
Gross profit consists of sales, less cost of goods sold (which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, royalties, costs of purchasing components from outside suppliers, distribution costs, warranty costs, customer support costs, shipping and handling costs, outside processing costs and write-down of inventories), and amortization of intangible assets.

[0001032975-24-000023:mdna:104]
Gross margin increased by 350 basis points to 41.4% during fiscal year 2024, compared to 37.9% during fiscal year 2023. The increase in gross margin was primarily due to lower material and logistics costs as well as lower promotional spend, partially offset by unfavorable product mix.

[0001032975-24-000023:mdna:105]
Operating Expenses

[0001032975-24-000023:mdna:106]
Operating expenses for fiscal years 2024 and 2023 were as follows (Dollars in thousands):

[0001032975-24-000023:mdna:107]
|  |  | Years Ended March 31, |
|  |  | 2024 |  | 2023 |  |  |
| Marketing and selling |  | $ | 730,310 |  |  | $ | 809,182 |  |  |  |
| % of sales |  | 17.0 | % |  | 17.8 | % |  |  |
| Research and development |  | 287,243 |  |  | 280,796 |  |  |  |
| % of sales |  | 6.7 | % |  | 6.2 | % |  |  |
| General and administrative |  | 155,056 |  |  | 124,652 |  |  |  |
| % of sales |  | 3.6 | % |  | 2.7 | % |  |  |
| Amortization of intangible assets and acquisition-related costs |  | 10,934 |  |  | 11,843 |  |  |  |
| % of sales |  | 0.2 | % |  | 0.3 | % |  |  |
| Impairment of intangible assets |  | 3,526 |  |  | — |  |  |  |
| % of sales |  | 0.1 | % |  | N/A |  |  |
| Change in fair value of contingent consideration for business acquisition |  | (250) |  |  | — |  |  |  |
| % of sales |  | — | % |  | N/A |  |  |
| Restructuring charges, net |  | 3,866 |  |  | 34,573 |  |  |  |
| % of sales |  | 0.1 | % |  | 0.8 | % |  |  |
| Total operating expenses |  | $ | 1,190,685 |  |  | $ | 1,261,046 |  |  |  |
| % of sales |  | 27.7 | % |  | 27.8 | % |  |  |

[0001032975-24-000023:mdna:108]
The decrease in total operating expenses during fiscal year 2024, compared to fiscal year 2023, was primarily due to decreases in marketing and selling expenses and restructuring charges, net, partially offset by an increase in general and administrative expenses.

[0001032975-24-000023:mdna:109]
Marketing and Selling

[0001032975-24-000023:mdna:110]
Marketing and selling expenses consist of personnel and related overhead costs, corporate and product marketing, promotions, advertising, trade shows, technical support for customer experiences and facilities costs.

[0001032975-24-000023:mdna:111]
During fiscal year 2024, marketing and selling expenses decreased $78.9 million, compared to fiscal year 2023, primarily driven by our reduction in third-party marketing spend.

[0001032975-24-000023:mdna:112]
Research and Development

[0001032975-24-000023:mdna:113]
Research and development expenses consist of personnel and related overhead costs for contractors and outside consultants, supplies and materials, equipment depreciation and facilities costs, all associated with the design and development of new products and enhancements of existing products.

[0001032975-24-000023:mdna:114]
During fiscal year 2024, research and development expenses increased $6.4 million, compared to fiscal year 2023, primarily driven by higher performance-based compensation expense. Research and development expenses as a percentage of sales increased from 6.2% in fiscal year 2023 to 6.7% in fiscal year 2024 reflecting our continued investment in innovation.

[0001032975-24-000023:mdna:115]
General and Administrative

[0001032975-24-000023:mdna:116]
General and administrative expenses primarily consist of personnel and related overhead, information technology, and facilities costs for the infrastructure functions such as finance, information systems, executives, human resources and legal.

[0001032975-24-000023:mdna:117]
During fiscal year 2024, general and administrative expenses increased $30.4 million, compared to fiscal year 2023, primarily driven by higher performance-based compensation expense.

[0001032975-24-000023:mdna:118]
Amortization of Intangible Assets and Acquisition-Related Costs

[0001032975-24-000023:mdna:119]
Amortization of intangible assets consists of amortization of acquired intangible assets, including customer relationships and trademarks and trade names. Acquisition-related costs include legal expenses, due diligence costs, and other professional costs incurred for business acquisitions.

[0001032975-24-000023:mdna:120]
During fiscal year 2024, amortization of intangible assets and acquisition-related costs decreased $0.9 million, compared to fiscal year 2023, primarily due to certain acquired intangible assets becoming fully amortized.

[0001032975-24-000023:mdna:121]
Impairment of Intangible Assets

[0001032975-24-000023:mdna:122]
During fiscal year 2024, we recognized a pre-tax impairment charge of $3.5 million, related to our in-process Research and Development intangible asset.

[0001032975-24-000023:mdna:123]
Restructuring Charges, Net

[0001032975-24-000023:mdna:124]
During the second quarter of fiscal year 2023, we initiated a restructuring plan to realign our business group and engineering structure with our go-to-market strategy to more effectively compete within the enterprise market and to better serve end-users. During the fourth quarter of fiscal year 2023, we undertook further actions to remove organization layers as well as streamline our marketing organization to increase efficiency. As a result, we recorded pre-tax restructuring charges totaling $3.9 million and $34.6 million during fiscal years 2024 and 2023, respectively, primarily related to employee severance and other termination benefits. These restructuring activities were substantially completed during fiscal year 2024.

[0001032975-24-000023:mdna:125]
See Note 16 to our consolidated financial statements for additional information.

[0001032975-24-000023:mdna:126]
Interest Income

[0001032975-24-000023:mdna:127]
Interest income for fiscal years 2024 and 2023 was as follows (in thousands):

[0001032975-24-000023:mdna:128]
|  |  | Years Ended March 31, |
|  |  | 2024 |  | 2023 |  |  |
| Interest income |  | $ | 50,636 |  |  | $ | 18,331 |  |  |  |

[0001032975-24-000023:mdna:129]
We invest in highly liquid instruments with an original maturity of three months or less at the date of purchase, which are classified as cash equivalents. The increase in interest income for fiscal year 2024, compared to fiscal year 2023, was primarily driven by an increase in interest rates and increased cash equivalents balance.

[0001032975-24-000023:mdna:130]
Other Income (Expense), Net

[0001032975-24-000023:mdna:131]
Other income (expense), net for fiscal years 2024 and 2023 was as follows (in thousands):

[0001032975-24-000023:mdna:132]
|  |  | Years Ended March 31, |
|  |  | 2024 |  | 2023 |  |  |
| Investment gain (loss) related to the deferred compensation plan |  | $ | 4,320 |  |  | $ | (1,961) |  |  |  |
| Currency exchange loss, net |  | (8,770) |  |  | (7,337) |  |  |  |
| Loss on investments, net |  | (14,674) |  |  | (14,073) |  |  |  |
| Non-service cost net pension income and other |  | 2,748 |  |  | 10,093 |  |  |  |
| Total |  | $ | (16,376) |  |  | $ | (13,278) |  |  |  |

[0001032975-24-000023:mdna:133]
Investment gain (loss) related to the deferred compensation plan for fiscal years 2024 and 2023 represents earnings, gains, and losses on marketable securities related to a deferred compensation plan offered by one of our subsidiaries. The increase in investment gain for fiscal year 2024, compared to fiscal year 2023, primarily relates to the change in market performance of the underlying securities.

[0001032975-24-000023:mdna:134]
Currency exchange loss, net, relates to balances denominated in currencies other than the functional currency in our subsidiaries, as well as the sale of currencies, and gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses. The loss for fiscal year 2024 was related to the exchange rate fluctuations of the Chinese Renminbi, Australian Dollar, Brazilian Real, and Japanese Yen versus the U.S.

[0001032975-24-000023:mdna:135]
Dollar. The loss for fiscal year 2023 was primarily related to the weakening of the Brazilian Real and Australian Dollar against U.S. Dollar.

[0001032975-24-000023:mdna:136]
Loss on investments, net, includes unrealized gain (loss) from the change in fair value of investments, gain (loss) on equity-method investments and impairment of investments during the periods presented, as applicable. The loss on investments, net, for fiscal year 2024 was primarily due to an impairment loss, as a result of the write-off of a note receivable which has been deemed no longer recoverable. This note receivable was previously obtained in conjunction with an exchange transaction related to our investment in a privately held company. The loss on investments, net for fiscal year 2023 was primarily due to the impairment charge related to one of our equity method investments, partially offset by the unrealized gain related to one of our equity investments without readily determinable fair value resulting from observable price changes. See Note 9 to our consolidated financial statements for additional information.

[0001032975-24-000023:mdna:137]
Non-service cost net pension income and other decreased in fiscal year 2024, compared to fiscal year 2023, primarily due to the curtailment gain recognized in fiscal year 2023 for one of our defined benefit plans as a result of the restructuring actions undertaken by the Company (see Notes 5 and 16 to our consolidated financial statements).

[0001032975-24-000023:mdna:138]
Provision for Income Taxes

[0001032975-24-000023:mdna:139]
The provision for income taxes and effective income tax rates for fiscal years 2024 and 2023 were as follows (Dollars in thousands):

[0001032975-24-000023:mdna:140]
|  |  | Years Ended March 31, |
|  |  | 2024 |  | 2023 |  |  |
| Provision for income taxes |  | $ | 9,453 |  |  | $ | 98,947 |  |  |  |
| Effective income tax rate |  | 1.5 | % |  | 21.3 | % |  |  |

[0001032975-24-000023:mdna:141]
The change in the effective income tax rate between fiscal years 2024 and 2023 was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate as well as the favorable tax impacts from share-based compensation, an agreement to remeasure the tax basis of goodwill under the Swiss Federal Act on Tax Reform and AHV Financing (“TRAF”) with the canton of Vaud, remeasurement of our Swiss deferred tax assets due to a change in tax rate, a Swiss Tax Ruling that provides future tax benefits as discussed below, and Foreign-Derived Intangible Income ("FDII") incentive in the U.S.

[0001032975-24-000023:mdna:142]
The canton of Vaud completed the legislative process to enact TRAF, a reform to better align the Swiss tax system to international tax standards, on March 10, 2020, that took effect as of January 1, 2020. In March 2020, we reached an agreement with the Vaud Tax Administration that would allow for an increase in the tax basis of goodwill, as a transition measure under TRAF, to be amortized over ten years beginning on January 1, 2020. During the fiscal year ended March 31, 2024, we reached an agreement to remeasure the tax basis of goodwill under TRAF with the canton of Vaud, which resulted in an income tax benefit of $25.1 million, net of assessment for uncertain tax positions. The remeasurement of the step-up will be amortized over the remaining ten-year amortization period.

[0001032975-24-000023:mdna:143]
On December 29, 2023, a change to the cantonal tax legislation was published. According to the law approved by the Vaud parliament, a progressive scale will be applicable for cantonal tax purposes resulting in an increase from the current tax rate of 13.61% to 14.28% effective fiscal year 2025. The increase in tax rate resulted in a tax benefit of $5.1 million due to a remeasurement of our Swiss deferred tax assets in the fiscal year ended March 31, 2024.

[0001032975-24-000023:mdna:144]
On March 28, 2024, we executed a Swiss Tax Ruling with the canton of Vaud that provides future tax benefit for ten years. The Swiss Tax Ruling resulted in an income tax benefit of $50.1 million, which will be utilized over a ten-year period.

[0001032975-24-000023:mdna:145]
The Tax Cuts and Jobs Act enacted Section 250, which provides for a deduction with respect to Global Intangible Low-Taxed Income ("GILTI") and FDII in the US. The application of this tax incentive is inherently complex. During the fiscal year ended March 31, 2024, we analyzed the applicability of FDII and determined that this tax incentive applies in fiscal 2021 to 2023 tax years. As a result, we realized a tax benefit of $18.7 million related to FDII. We have also concluded that any GILTI tax since the enactment of Tax Cuts and Jobs Act is immaterial.

[0001032975-24-000023:mdna:146]
The BEPS Project undertaken by the OECD recommended changes to numerous long-standing tax principles, including a proposal to reallocate profits among tax jurisdictions in which companies do business (“Pillar One”) and

[0001032975-24-000023:mdna:147]
establishing a minimum tax on global income (“Pillar Two”). Some jurisdictions where we operate are implementing Pillar Two laws to effectuate a 15% minimum tax, which will be effective for the Company starting fiscal year 2025.

[0001032975-24-000023:mdna:148]
More specifically, the Federal Council enacted the relevant ordinance for implementing a (Qualified) Domestic Minimum Tax (QDMTT) in Switzerland for tax years beginning from January 1, 2024. As many countries have proposed or enacted Pillar Two legislation in jurisdictions in which we operate, we continue to monitor the relevant developments.

[0001032975-24-000023:mdna:149]
As of March 31, 2024 and 2023, the total amount of unrecognized tax benefits due to uncertain tax positions was $192.7 million and $186.8 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-24-000023:mdna:150]
As of March 31, 2024 and 2023, we had $112.6 million and $106.4 million, respectively, in non-current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions. As of March 31, 2024 and 2023, we had $7.8 million and $6.1 million, respectively, of accrued interest and penalties related to uncertain tax positions.

[0001032975-24-000023:mdna:151]
We file Swiss and foreign tax returns. We received final tax assessments in Switzerland through fiscal year 2019. For other material foreign jurisdictions such as the United States and China, we are generally not subject to tax examinations for years prior to fiscal year 2020 and calendar year 2020, respectively. In the United States, the federal and state tax agencies have the authority to examine periods prior to fiscal year 2020, to the extent allowed by law, where tax attributes were generated, carried forward, and being utilized in subsequent years. We are under examination in foreign tax jurisdictions. If the examinations are resolved unfavorably, there is a possibility that they may have a material negative impact on our results of operations.

[0001032975-24-000023:mdna:152]
Liquidity and Capital Resources

[0001032975-24-000023:mdna:153]
Cash Balances, Available Borrowings, and Capital Resources

[0001032975-24-000023:mdna:154]
As of March 31, 2024, we had cash and cash equivalents of $1,520.8 million, compared with $1,149.0 million as of March 31, 2023. Our cash and cash equivalents consist of bank demand deposits, short-term time deposits, and U.S. Treasury securities, of which 71% was held in Switzerland and 11% was held in China (including Hong Kong). We do not expect to incur any material adverse tax impact except for what has already been recognized, or to be significantly inhibited by any country in which we do business, from the repatriation of funds to Switzerland, our country of domicile.

[0001032975-24-000023:mdna:155]
As of March 31, 2024, our working capital was $1,545.5 million, compared to $1,555.1 million as of March 31, 2023. The decrease was primarily driven by decreases in inventories and accounts receivable, net, and an increase in accounts payable, partially offset by an increase in cash and cash equivalents.

[0001032975-24-000023:mdna:156]
We had several uncommitted, unsecured bank lines of credit and letters of credit aggregating $172.5 million as of March 31, 2024. There are no financial covenants under the lines of credit with which we must comply. There was no borrowing outstanding under the lines of credit as of March 31, 2024. As of March 31, 2024, we had outstanding bank guarantees of $14.3 million.

[0001032975-24-000023:mdna:157]
The following table presents selected financial information and statistics as of March 31, 2024 and 2023 (Dollars in thousands):

[0001032975-24-000023:mdna:158]
|  |  | March 31, |
|  |  | 2024 |  | 2023 |  |  |
| Accounts receivable, net |  | $ | 541,715 |  |  | $ | 630,382 |  |  |  |
| Accounts payable |  | $ | 448,627 |  |  | $ | 406,968 |  |  |  |
| Inventories |  | $ | 422,513 |  |  | $ | 682,893 |  |  |  |
| Days sales in accounts receivable (DSO)(Days)(1) |  | 48 |  |  | 59 |  |  |  |
| Days accounts payable outstanding (DPO) (Days)(2) |  | 70 |  |  | 59 |  |  |  |
| Inventory turnover (ITO)(x)(3) |  | 5.4 |  |  | 3.6 |  |  |  |

[0001032975-24-000023:mdna:159]
(1) DSO is determined using ending accounts receivable, net, as of the most recent quarter-end and sales for the most recent quarter.

[0001032975-24-000023:mdna:160]
(2) DPO is determined using ending accounts payable as of the most recent quarter-end and cost of goods sold for the most recent quarter.

[0001032975-24-000023:mdna:161]
(3) ITO is determined using ending inventories as of the most recent quarter-end and annualized cost of goods sold (based on the most recent quarterly cost of goods sold).

[0001032975-24-000023:mdna:162]
DSO as of March 31, 2024 decreased by 11 days to 48 days, compared to 59 days as of March 31, 2023, primarily due to the timing of sales within the fourth quarter of the fiscal years 2024 and 2023.

[0001032975-24-000023:mdna:163]
DPO as of March 31, 2024 increased by 11 days to 70 days, compared to 59 days as of March 31, 2023, primarily due to an increase in inventory purchases to replenish certain products during the fourth quarter of fiscal year 2024 as well as softened demand.

[0001032975-24-000023:mdna:164]
ITO as of March 31, 2024 increased by 1.8 to 5.4, compared to 3.6 as of March 31, 2023, primarily due to lower inventory balance as of March 31, 2024 resulting from focused inventory management to align with softened demand.

[0001032975-24-000023:mdna:165]
If we are not successful in launching and phasing in our new products, or market competition increases, or we are not able to sell the new products at the prices planned, it could have a material impact on our sales, gross profit, operating results including operating cash flow, and inventory turnover in the future.

[0001032975-24-000023:mdna:166]
The following table summarizes our consolidated statement of cash flows for the year ended March 31, 2024 (in thousands):

[0001032975-24-000023:mdna:167]
|  |  | Year ended March 31, 2024 |  |  |
| Net cash provided by operating activities |  | $ | 1,145,116 |  |  |  |
| Net cash used in investing activities |  | (70,335) |  |  |  |
| Net cash used in financing activities |  | (690,173) |  |  |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (12,789) |  |  |  |
| Net increase in cash and cash equivalents |  | $ | 371,819 |  |  |  |

[0001032975-24-000023:mdna:168]
For fiscal year 2024, net cash provided by operating activities was $1,145.1 million resulting from net income of $612.1 million, a favorable impact from adding back non-cash adjustments totaling $143.5 million, and a favorable net change in operating assets and liabilities of $389.4 million. Non-cash adjustments were primarily related to depreciation and amortization, share-based compensation expense, and deferred income taxes. The decrease in accounts receivable, net, was primarily driven by the timing of sales within the fourth quarter of fiscal years 2024 and 2023. The decrease in inventories was primarily driven by our effort to manage inventory level to align with softened demand. The increase in accounts payable was primarily driven by an increase in inventory purchases to replenish certain products during the fourth quarter of fiscal year 2024.

[0001032975-24-000023:mdna:169]
For fiscal year 2024, net cash used in investing activities was $70.3 million, primarily due to $55.9 million purchases of property, plant, and equipment. Our expenditures for property, plant and equipment during fiscal year 2024 were primarily for building improvements, tooling and equipment, and computer hardware and software.

[0001032975-24-000023:mdna:170]
For fiscal year 2024, net cash used in financing activities was $690.2 million, primarily resulting from repurchases of our registered shares of $504.2 million, payments of cash dividends of $182.3 million, and tax withholdings related to net share settlements of restricted stock units of $29.7 million, partially offset by proceeds from exercise of stock options and purchase rights of $32.2 million.

[0001032975-24-000023:mdna:171]
During fiscal year 2024, there was a $12.8 million loss from currency exchange rate effect on cash and cash equivalents, primarily due to exchange rate fluctuations of Euro, Chinese Renminbi, Australian Dollar and Swiss Franc versus the U.S. Dollar and timing of our cash transactions over the period.

[0001032975-24-000023:mdna:172]
Cash Outlook

[0001032975-24-000023:mdna:173]
Our principal sources of liquidity are our cash and cash equivalents, cash flow generated from operations and, to a much lesser extent, capital markets and borrowings. Our future working capital requirements and capital expenditures may increase to support investments in product innovations and growth opportunities or to acquire or invest in complementary businesses, products, services, and technologies. Market volatility driven by the current macroeconomic and geopolitical environment may increase our costs of capital and otherwise adversely affect our business, results of operations, financial condition and liquidity.

[0001032975-24-000023:mdna:174]
In May 2024, the Board of Directors recommended that we pay cash dividends for fiscal year 2024 of CHF 1.16 per share (approximately $1.28 per share based on the exchange rate on March 31, 2024). Based on our shares outstanding, net of treasury shares, as of March 31, 2024 (153,863,262 shares), this would result in an aggregate gross dividend of approximately CHF 178.5 million (approximately $197.2 million based on the exchange rate on March 31, 2024). In fiscal year 2024, we paid a cash dividend of CHF 1.06 per share, or CHF 169.1 million (U.S. Dollar amount of $182.3 million based on the exchange rate on the date of payment) out of fiscal year 2023 retained earnings. In fiscal year 2023, we paid a cash dividend of CHF 0.96 per share, or CHF 156.1 million (U.S. Dollar amount of $158.7 million based on the exchange rate on the date of payment) out of fiscal year 2022 retained earnings. In fiscal year 2022, we paid a cash dividend of CHF 0.87 per share, or CHF 147.0 million (U.S. Dollar amount of $159.4 million) out of fiscal year 2021 retained earnings.

[0001032975-24-000023:mdna:175]
In May 2020, our Board of Directors approved the 2020 share repurchase program, which authorized us to invest up to $250.0 million to purchase our own shares to support equity incentive plans or potential acquisitions. In April 2021, our Board of Directors approved an increase of $750.0 million to the 2020 share repurchase program, to an aggregate amount of $1.0 billion. The Swiss Takeover Board approved this increase and it became effective on May 21, 2021. In July 2022, our Board of Directors approved an increase of $500 million to the 2020 share repurchase program, to an aggregate amount of up to $1.5 billion. The Swiss Takeover Board approved this increase and it became effective on August 19, 2022. The 2020 share repurchase program expired on July 27, 2023. We repurchased 16.7 million shares for an aggregate cost of $1.2 billion under the 2020 share repurchase program, of which 2.6 million shares for an aggregate cost of $159.1 million were repurchased during fiscal year 2024 prior to the expiration of the program.

[0001032975-24-000023:mdna:176]
In June 2023, our Board of Directors approved a new, three-year share repurchase program, which allows us to use up to $1.0 billion to repurchase our shares. The 2023 share repurchase program enables us to repurchase shares for cancellation, as well as to support equity incentive plans or potential acquisitions. The Swiss Takeover Board approved the 2023 share repurchase program in July 2023 and the program became effective on July 28, 2023. During the fiscal year ended March 31, 2024, we repurchased 4.5 million shares for an aggregate cost of $364.7 million, under the 2023 share repurchase program, of which $19.5 million of the aggregate cost was not paid yet as of March 31, 2024. 4.1 million shares for an aggregate cost of $332.1 million were repurchased for cancellation and the remaining shares were repurchased to support equity incentive plans. As of March 31, 2024, $635.8 million was available for repurchase under the 2023 share repurchase program.

[0001032975-24-000023:mdna:177]
Swiss law limits a company’s ability to hold or repurchase its own shares. The aggregate par value of all shares held in treasury by us and our subsidiaries may not exceed 10% of our share capital, which corresponds to approximately 17.3 million registered shares. This limitation does not apply to shares repurchased for cancellation, due to the Board of Directors' authority under the capital band set forth in the Company's Articles of Incorporation to cancel shares up to a limit of 10% of our current share capital. As of March 31 2024, we had a total of 19.2 million shares held in treasury stock, which includes 4.1 million shares that have been repurchased for cancellation.

[0001032975-24-000023:mdna:178]
Although we enter into trading plans for systematic repurchases (e.g., 10b5-1 trading plans) from time to time, our 2023 share repurchase program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years through July 27, 2026. To the extent that the shares are repurchased to support equity incentive plans or potential acquisitions, the shares are repurchased on the ordinary trading line of Swiss Exchange ("SIX") and/or the Nasdaq Global Select Market ("Nasdaq"). Shares repurchased for cancellation purposes are repurchased via a second trading line on SIX. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.

[0001032975-24-000023:mdna:179]
For over ten years, we have generated positive cash flows from our operating activities, including cash from operations of $1,145.1 million and $534.0 million during fiscal years 2024 and 2023, respectively. If we do not generate sufficient operating cash flows to support our operations and future planned cash requirements, our operations could be harmed and our access to credit facilities could be restricted or eliminated. However, we believe that the trend of our historical cash flow generation, our projections of future operations and our available cash balances will provide sufficient liquidity to fund our operations for at least the next 12 months.

[0001032975-24-000023:mdna:180]
Our other contractual obligations and commitments that require cash are described in the following sections.

[0001032975-24-000023:mdna:181]
Contractual Obligations and Commitments

[0001032975-24-000023:mdna:182]
Purchase Commitments

[0001032975-24-000023:mdna:183]
As of March 31, 2024, we had non-cancelable purchase commitments of $396.8 million for inventory purchases made in the normal course of business from original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. We recorded a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with our valuation of excess and obsolete inventory. As of March 31, 2024, the liability for these purchase commitments was $29.3 million and is recorded in accrued and other current liabilities in the consolidated balance sheet.

[0001032975-24-000023:mdna:184]
We have firm purchase commitments of $13.4 million for capital expenditures primarily related to commitments for tooling and equipment for new and existing products. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-24-000023:mdna:185]
Operating Leases Obligation

[0001032975-24-000023:mdna:186]
We lease facilities under operating leases, certain of which require us to pay property taxes, insurance and maintenance costs. Operating leases for facilities are generally renewable at our option and usually include escalation clauses linked to inflation. The remaining terms of our non-cancelable operating leases expire in various years through 2033. See Note 17 - Leases in our Notes to the consolidated financial statements included in this report for more information on leases.

[0001032975-24-000023:mdna:187]
Income Taxes Payable

[0001032975-24-000023:mdna:188]
As of March 31, 2024, we had $112.6 million in non-current income taxes payable, including interest and penalties, related to our income tax liability for uncertain tax positions. At this time, we are unable to make a reasonably reliable estimate of the timing of payments in individual years in connection with these tax liabilities.

[0001032975-24-000023:mdna:189]
Indemnifications

[0001032975-24-000023:mdna:190]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of March 31, 2024, no material amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-24-000023:mdna:191]
We also indemnify our current and former directors and certain current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. We are unable to reasonably estimate the maximum amount that could be payable under these arrangements because these

[0001032975-24-000023:mdna:192]
exposures are not capped, the obligations are conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.
