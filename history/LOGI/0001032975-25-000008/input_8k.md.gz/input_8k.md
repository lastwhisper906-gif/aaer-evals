# LOGI 8-K — 0001032975-25-000005 filed 2025-01-28

## item codes, every 8-K on or before 2025-01-29

- 2025-01-28 0001032975-25-000005 — 1.01, 2.02, 2.03, 9.01
- 2024-10-22 0001032975-24-000072 — 2.02, 9.01
- 2024-10-11 0001032975-24-000069 — 5.03, 9.01
- 2024-09-09 0001032975-24-000065 — 5.07, 8.01
- 2024-08-06 0001032975-24-000062 — 5.02, 9.01
- 2024-07-23 0001032975-24-000042 — 2.02, 9.01
- 2024-07-01 0001032975-24-000033 — 5.02, 8.01, 9.01
- 2024-06-13 0001032975-24-000030 — 5.02, 9.01
- 2024-04-30 0001032975-24-000015 — 2.02, 9.01
- 2024-03-18 0001032975-24-000012 — 5.02, 7.01, 9.01
- 2024-01-23 0001032975-24-000004 — 2.02, 9.01
- 2023-10-30 0001032975-23-000082 — 5.02, 9.01
- 2023-10-24 0001032975-23-000075 — 2.02, 9.01
- 2023-09-15 0001032975-23-000072 — 5.07, 8.01
- 2023-07-25 0001032975-23-000050 — 2.02, 9.01
- 2023-06-30 0001032975-23-000037 — 5.02 — amendment, the index does not say of what
- 2023-06-30 0001032975-23-000036 — 5.02
- 2023-06-13 0001032975-23-000030 — 5.02, 7.01, 9.01
- 2023-05-02 0001032975-23-000015 — 2.02, 9.01
- 2023-01-30 0001032975-23-000010 — 5.02, 9.01
- 2023-01-24 0001032975-23-000004 — 2.02, 5.02, 9.01
- 2023-01-12 0001628280-23-000934 — 2.02, 9.01
- 2022-10-25 0001628280-22-026927 — 2.02, 5.02, 9.01
- 2022-09-16 0001628280-22-025080 — 5.07, 8.01
- 2022-07-26 0001032975-22-000027 — 2.02, 9.01
- 2022-06-29 0001032975-22-000018 — 5.02
- 2022-05-03 0001032975-22-000008 — 2.02, 9.01
- 2022-01-25 0001032975-22-000003 — 2.02, 9.01
- 2021-10-26 0001032975-21-000043 — 2.02, 9.01
- 2021-09-10 0001032975-21-000040 — 5.07, 8.01
- 2021-07-27 0001032975-21-000029 — 2.02, 9.01
- 2021-04-29 0001032975-21-000012 — 2.02, 9.01
- 2021-01-19 0001032975-21-000004 — 2.02, 9.01
- 2020-10-20 0001032975-20-000045 — 2.02, 9.01
- 2020-09-11 0001032975-20-000042 — 5.07, 8.01
- 2020-07-21 0001032975-20-000029 — 2.02, 9.01
- 2020-07-01 0001032975-20-000023 — 5.02, 8.01
- 2020-05-12 0001032975-20-000011 — 2.02, 9.01
- 2020-03-30 0001032975-20-000009 — 5.02
- 2020-01-21 0001032975-20-000002 — 2.02, 9.01
- 2019-10-22 0001032975-19-000071 — 9.01
- 2019-09-26 0001032975-19-000068 — 1.01, 7.01, 9.01
- 2019-09-06 0001032975-19-000063 — 5.07, 8.01
- 2019-07-23 0001032975-19-000046 — 2.02, 9.01
- 2019-07-23 0001032975-19-000045 — 5.02, 9.01
- 2019-07-02 0001032975-19-000036 — 5.02
- 2019-06-25 0001032975-19-000034 — 5.02
- 2019-05-03 0001032975-19-000021 — 5.02 — amendment, the index does not say of what
- 2019-04-30 0001032975-19-000017 — 2.02, 5.02, 9.01
- 2019-03-28 0001032975-19-000013 — 5.02
- 2019-01-22 0001032975-19-000004 — 2.02, 9.01
- 2018-10-23 0001032975-18-000044 — 2.02, 9.01
- 2018-09-07 0001032975-18-000040 — 5.07, 8.01
- 2018-07-31 0001032975-18-000035 — 1.01, 2.02, 2.05, 7.01, 9.01
- 2018-06-27 0001032975-18-000020 — 5.02
- 2018-05-03 0001032975-18-000013 — 2.02, 5.02, 9.01
- 2018-01-23 0001032975-18-000005 — 2.02, 9.01
- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2025-01-29

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-25-000005:8k_2_02:1]
EX-99.1
4
exhibit991q3fy25.htm
EX-99.1

[0001032975-25-000005:8k_2_02:2]
Document

[0001032975-25-000005:8k_2_02:3]
Exhibit 99.1

[0001032975-25-000005:8k_2_02:4]
Editorial Contacts:

[0001032975-25-000005:8k_2_02:5]
Kate Beerkens, Director of Investor Relations - ir@logitech.com

[0001032975-25-000005:8k_2_02:6]
Nicole Kenyon, Head of Global Communications - nkenyon@logitech.com (USA)

[0001032975-25-000005:8k_2_02:7]
Ben Starkie, Corporate Communications - +41 (0) 79-292-3499, bstarkie1@logitech.com (Europe/Asia)

[0001032975-25-000005:8k_2_02:8]
Logitech Announces Fourth Consecutive Quarter of Sales Growth

[0001032975-25-000005:8k_2_02:9]
Gaming Sales Near Pandemic High Levels;

[0001032975-25-000005:8k_2_02:10]
Company Raises FY 2025 Outlook

[0001032975-25-000005:8k_2_02:11]
LAUSANNE, Switzerland and SAN JOSE, Calif., Jan. 28, 2025 — SIX Swiss Exchange Ad hoc announcement pursuant to Art. 53 LR — Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the third quarter of Fiscal Year 2025.

[0001032975-25-000005:8k_2_02:12]
•Sales were $1.34 billion, up 7 percent in US dollars and 6 percent in constant currency compared to Q3 of the prior year.

[0001032975-25-000005:8k_2_02:13]
•GAAP gross margin was 42.9 percent, up 90 basis points compared to Q3 of the prior year.     Non-GAAP gross margin was 43.2 percent, up 90 basis points compared to Q3 of the prior year.

[0001032975-25-000005:8k_2_02:14]
•GAAP operating income was $235 million, up 6 percent compared to Q3 of the prior year.       Non-GAAP operating income was $266 million, up 7 percent compared to Q3 of the prior year.

[0001032975-25-000005:8k_2_02:15]
•GAAP earnings per share (EPS) was $1.32, down 15 percent compared to Q3 of the prior year. Non-GAAP EPS was $1.59, up 4 percent compared to Q3 of the prior year.

[0001032975-25-000005:8k_2_02:16]
•Cash flow from operations was $371 million. The quarter-ending cash balance was $1.5 billion.

[0001032975-25-000005:8k_2_02:17]
•The Company returned $200 million of cash to shareholders through share repurchases.

[0001032975-25-000005:8k_2_02:18]
“We’re excited to deliver strong, profitable growth once again, in our biggest quarter of the year,” said Hanneke Faber, Logitech chief executive officer. “Our growth was driven by our strategic priorities. We delivered superior innovation. Gaming sales were near pandemic-high levels, thanks to an outstanding set of innovations launched ahead of the holidays. We delivered near record sales in our premium Pro Gaming and MX portfolios. Logitech for Business made excellent progress. And our teams fielded effective marketing campaigns and excellent holiday retail execution to drive broad-based geographic progress.”

[0001032975-25-000005:8k_2_02:19]
“Q3 marks another disciplined quarter,” said Matteo Anversa, Logitech chief financial officer. “Thanks to our strong operational performance, we again delivered year-over-year expansion of gross margin. While we expect fourth quarter currency headwinds, the strong demand in the third quarter and the continued promotional and operational discipline of our teams give us confidence about the trajectory of our business, and we are increasing our full-year outlook.”

[0001032975-25-000005:8k_2_02:20]
Outlook

[0001032975-25-000005:8k_2_02:21]
Logitech raised its full-year outlook for Fiscal Year 2025:

[0001032975-25-000005:8k_2_02:22]
|  |  | Previous FY25 outlook |  | New FY25 outlook |
| Sales |  | $4.39 - $4.47 billion |  | $4.54 - $4.57 billion |
| Sales growth (in US dollars, year over year) |  | 2% - 4% |  | 5.4% - 6.4% |
| Sales growth (in constant currency, year over year) |  | 2% - 4% |  | 6.2% - 7.1% |
| Non-GAAP operating income |  | $720 - $750 million |  | $755 - $770 million |
| Non-GAAP op. inc. growth (year over year) |  | 3% - 7% |  | 8% - 10% |

[0001032975-25-000005:8k_2_02:23]
Financial Results Videoconference and Webcast

[0001032975-25-000005:8k_2_02:24]
Logitech will hold a financial results videoconference to discuss the results for Q3 Fiscal Year 2025 on Tuesday, January 28, 2025 at 1:30 p.m. Pacific Standard Time (PST) and 10:30 p.m. Central European Time (CET). A livestream of the event will be available on the Logitech corporate website at https://ir.logitech.com. This press release and the Q3 Fiscal Year 2025 Shareholder Letter are also available there.

[0001032975-25-000005:8k_2_02:25]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-25-000005:8k_2_02:26]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures in this press release, which exclude share-based compensation expense, amortization of intangible assets, acquisition-related costs, restructuring charges (credits), net, loss (gain) on investments, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below and posted to our website at https://ir.logitech.com. Logitech also presents percentage sales growth in constant currency (“cc”), a non-GAAP measure, to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance, outlook and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for the Fiscal Year 2025 non-GAAP operating income outlook.

[0001032975-25-000005:8k_2_02:27]
Public Dissemination of Certain Information

[0001032975-25-000005:8k_2_02:28]
Recordings of Logitech’s earnings videoconferences and certain events Logitech participates in or hosts, with members of the investment community are posted on the company’s investor relations website at https://ir.logitech.com. Additionally, Logitech provides notifications of news or announcements regarding its operations and financial performance, including its filings with the Securities and Exchange Commission (SEC), investor events, and press and earnings releases as part of its investor relations website. Logitech intends to use its investor relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. Logitech’s corporate governance information also is available on its investor relations website.

[0001032975-25-000005:8k_2_02:29]
About Logitech

[0001032975-25-000005:8k_2_02:30]
Logitech designs software-enabled hardware solutions that help businesses thrive and bring people together when working, creating, gaming and streaming. As the point of connection between people and the digital world, our mission is to extend human potential in work and play, in a way that is good for people and the planet. Founded in 1981, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech and its other brands, including Logitech G, at www.logitech.com or company blog.

[0001032975-25-000005:8k_2_02:31]
# # #

[0001032975-25-000005:8k_2_02:32]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-25-000005:8k_2_02:33]
Logitech and other Logitech marks are trademarks or registered trademarks of Logitech Europe S.A. and/or its affiliates in the U.S. and other countries. All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-25-000005:8k_2_02:34]
(LOGIIR)

[0001032975-25-000005:8k_2_02:35]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three months ended December 31, |  | Nine months ended December 31, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net sales |  | $ | 1,340,294 |  |  | $ | 1,255,473 |  |  | $ | 3,544,545 |  |  | $ | 3,286,980 |  |
| Cost of goods sold |  | 763,403 |  |  | 726,252 |  |  | 2,010,411 |  |  | 1,937,367 |  |
| Amortization of intangible assets |  | 2,450 |  |  | 2,441 |  |  | 7,344 |  |  | 8,569 |  |
| Gross profit |  | 574,441 |  |  | 526,780 |  |  | 1,526,790 |  |  | 1,341,044 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 217,048 |  |  | 189,175 |  |  | 615,816 |  |  | 544,716 |  |
| Research and development |  | 77,973 |  |  | 72,704 |  |  | 229,485 |  |  | 211,822 |  |
| General and administrative |  | 42,117 |  |  | 39,711 |  |  | 123,748 |  |  | 116,546 |  |
| Amortization of intangible assets and acquisition-related costs |  | 2,637 |  |  | 2,276 |  |  | 8,065 |  |  | 8,279 |  |
| Restructuring charges, net |  | 110 |  |  | 839 |  |  | 725 |  |  | 2,562 |  |
| Total operating expenses |  | 339,885 |  |  | 304,705 |  |  | 977,839 |  |  | 883,925 |  |
| Operating income |  | 234,556 |  |  | 222,075 |  |  | 548,951 |  |  | 457,119 |  |
| Interest income |  | 12,176 |  |  | 12,826 |  |  | 42,603 |  |  | 34,508 |  |
| Other income (expense), net |  | (1,524) |  |  | 189 |  |  | (2,889) |  |  | (13,827) |  |
| Income before income taxes |  | 245,208 |  |  | 235,090 |  |  | 588,665 |  |  | 477,800 |  |
| Provision for (benefit from) income taxes |  | 45,061 |  |  | (9,594) |  |  | 101,202 |  |  | 33,272 |  |
| Net income |  | $ | 200,147 |  |  | $ | 244,684 |  |  | $ | 487,463 |  |  | $ | 444,528 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.33 |  |  | $ | 1.57 |  |  | $ | 3.20 |  |  | $ | 2.82 |  |
| Diluted |  | $ | 1.32 |  |  | $ | 1.55 |  |  | $ | 3.18 |  |  | $ | 2.80 |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | 150,647 |  |  | 155,933 |  |  | 152,127 |  |  | 157,568 |  |
| Diluted |  | 151,895 |  |  | 157,440 |  |  | 153,506 |  |  | 158,843 |  |

[0001032975-25-000005:8k_2_02:36]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | December 31, |  | March 31, |  |  |  |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  | 2024 |  | 2024 |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,502,832 |  |  | $ | 1,520,842 |  |  |  |  |  |
| Accounts receivable, net |  | 648,230 |  |  | 541,715 |  |  |  |  |  |
| Inventories |  | 483,569 |  |  | 422,513 |  |  |  |  |  |
| Other current assets |  | 139,523 |  |  | 146,270 |  |  |  |  |  |
| Total current assets |  | 2,774,154 |  |  | 2,631,340 |  |  |  |  |  |
| Non-current assets: |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 109,547 |  |  | 116,589 |  |  |  |  |  |
| Goodwill |  | 461,183 |  |  | 461,978 |  |  |  |  |  |
| Other intangible assets, net |  | 29,161 |  |  | 44,603 |  |  |  |  |  |
| Other assets |  | 357,515 |  |  | 350,194 |  |  |  |  |  |
| Total assets |  | $ | 3,731,560 |  |  | $ | 3,604,704 |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 578,951 |  |  | $ | 448,627 |  |  |  |  |  |
| Accrued and other current liabilities |  | 715,267 |  |  | 637,262 |  |  |  |  |  |
| Total current liabilities |  | 1,294,218 |  |  | 1,085,889 |  |  |  |  |  |
| Non-current liabilities: |  |  |  |  |  |  |  |  |
| Income taxes payable |  | 129,497 |  |  | 112,572 |  |  |  |  |  |
| Other non-current liabilities |  | 205,027 |  |  | 172,590 |  |  |  |  |  |
| Total liabilities |  | 1,628,742 |  |  | 1,371,051 |  |  |  |  |  |
| Shareholders’ equity: |  |  |  |  |  |  |  |  |
| Registered shares, CHF 0.25 par valueIssued shares: 168,994 and 173,106 at December 31, 2024 and March 31, 2024, respectively |  | 29,432 |  |  | 30,148 |  |  |  |  |  |
| Additional paid-in capital |  | 95,162 |  |  | 63,524 |  |  |  |  |  |
| Shares in treasury, at cost — 19,555 and 19,243 at December 31, 2024 and March 31, 2024, respectively |  | (1,381,949) |  |  | (1,351,336) |  |  |  |  |  |
| Retained earnings |  | 3,494,495 |  |  | 3,602,519 |  |  |  |  |  |
| Accumulated other comprehensive loss |  | (134,322) |  |  | (111,202) |  |  |  |  |  |
| Total shareholders’ equity |  | 2,102,818 |  |  | 2,233,653 |  |  |  |  |  |
| Total liabilities and shareholders’ equity |  | $ | 3,731,560 |  |  | $ | 3,604,704 |  |  |  |  |  |

[0001032975-25-000005:8k_2_02:37]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three months ended December 31, |  | Nine months ended December 31, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 200,147 |  |  | $ | 244,684 |  |  | $ | 487,463 |  |  | $ | 444,528 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  | 15,075 |  |  | 14,739 |  |  | 44,178 |  |  | 48,874 |  |
| Amortization of intangible assets |  | 5,087 |  |  | 5,074 |  |  | 15,258 |  |  | 16,583 |  |
| Loss on investments |  | 119 |  |  | 604 |  |  | 1,718 |  |  | 12,213 |  |
| Share-based compensation expense |  | 26,193 |  |  | 20,613 |  |  | 76,067 |  |  | 64,192 |  |
| Deferred income taxes |  | 2,163 |  |  | (20,623) |  |  | 18,652 |  |  | (9,515) |  |
| Other |  | 73 |  |  | 236 |  |  | 130 |  |  | 336 |  |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | (46,366) |  |  | (11,424) |  |  | (127,934) |  |  | (46,786) |  |
| Inventories |  | 26,353 |  |  | 91,600 |  |  | (67,554) |  |  | 237,969 |  |
| Other assets |  | 7,175 |  |  | (8,301) |  |  | 9,416 |  |  | 3,698 |  |
| Accounts payable |  | 28,472 |  |  | 32,361 |  |  | 136,848 |  |  | 120,383 |  |
| Accrued and other liabilities |  | 106,379 |  |  | 73,389 |  |  | 118,659 |  |  | 13,536 |  |
| Net cash provided by operating activities |  | 370,870 |  |  | 442,952 |  |  | 712,901 |  |  | 906,011 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (14,227) |  |  | (10,854) |  |  | (43,340) |  |  | (45,585) |  |
| Acquisitions, net of cash acquired |  | — |  |  | — |  |  | — |  |  | (14,138) |  |
| Purchases of deferred compensation investments |  | (2,202) |  |  | (5,345) |  |  | (5,802) |  |  | (7,893) |  |
| Proceeds from sales of deferred compensation investments |  | 2,659 |  |  | 5,571 |  |  | 4,958 |  |  | 8,193 |  |
| Other investing activities |  | (261) |  |  | (50) |  |  | (1,173) |  |  | (406) |  |
| Net cash used in investing activities |  | (14,031) |  |  | (10,678) |  |  | (45,357) |  |  | (59,829) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | — |  |  | — |  |  | (207,853) |  |  | (182,305) |  |
| Payment of contingent consideration for business acquisition |  | — |  |  | — |  |  | (1,245) |  |  | (5,002) |  |
| Purchases of registered shares |  | (200,137) |  |  | (187,834) |  |  | (463,322) |  |  | (376,775) |  |
| Proceeds from exercises of stock options and purchase rights |  | — |  |  | — |  |  | 20,235 |  |  | 15,319 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (1,008) |  |  | (2,372) |  |  | (22,251) |  |  | (28,596) |  |
| Other financing activities |  | — |  |  | — |  |  | (1,663) |  |  | (1,116) |  |
| Net cash used in financing activities |  | (201,145) |  |  | (190,206) |  |  | (676,099) |  |  | (578,475) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (16,138) |  |  | 6,678 |  |  | (9,455) |  |  | (4,080) |  |
| Net increase (decrease) in cash and cash equivalents |  | 139,556 |  |  | 248,746 |  |  | (18,010) |  |  | 263,627 |  |
| Cash and cash equivalents, beginning of the period |  | 1,363,276 |  |  | 1,163,904 |  |  | 1,520,842 |  |  | 1,149,023 |  |
| Cash and cash equivalents, end of the period |  | $ | 1,502,832 |  |  | $ | 1,412,650 |  |  | $ | 1,502,832 |  |  | $ | 1,412,650 |  |

[0001032975-25-000005:8k_2_02:38]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three months ended December 31, |  | Nine months ended December 31, |
| NET SALES |  | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
| Net sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Gaming (1) |  | $ | 466,715 |  |  | $ | 409,043 |  |  | 14 | % |  | $ | 1,076,660 |  |  | $ | 957,576 |  |  | 12 | % |
| Keyboards & Combos |  | 236,748 |  |  | 229,432 |  |  | 3 |  |  | 662,017 |  |  | 605,201 |  |  | 9 |  |
| Pointing Devices |  | 217,045 |  |  | 206,180 |  |  | 5 |  |  | 602,927 |  |  | 572,310 |  |  | 5 |  |
| Video Collaboration |  | 176,053 |  |  | 169,522 |  |  | 4 |  |  | 482,755 |  |  | 461,257 |  |  | 5 |  |
| Webcams |  | 84,419 |  |  | 85,851 |  |  | (2) |  |  | 237,572 |  |  | 249,273 |  |  | (5) |  |
| Tablet Accessories |  | 77,433 |  |  | 64,239 |  |  | 21 |  |  | 241,586 |  |  | 198,252 |  |  | 22 |  |
| Headsets |  | 45,886 |  |  | 41,762 |  |  | 10 |  |  | 137,038 |  |  | 123,023 |  |  | 11 |  |
| Other (2) |  | 35,995 |  |  | 49,444 |  |  | (27) |  |  | 103,990 |  |  | 120,088 |  |  | (13) |  |
| Total Net Sales |  | $ | 1,340,294 |  |  | $ | 1,255,473 |  |  | 7 | % |  | $ | 3,544,545 |  |  | $ | 3,286,980 |  |  | 8 | % |

[0001032975-25-000005:8k_2_02:39]
(1) Gaming includes streaming services revenue generated by Streamlabs.

[0001032975-25-000005:8k_2_02:40]
(2) Other primarily consists of mobile speakers and PC speakers.

[0001032975-25-000005:8k_2_02:41]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three months ended December 31, |  | Nine months ended December 31, |
| GAAP TO NON-GAAP RECONCILIATION (A) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Gross profit - GAAP |  | $ | 574,441 |  | $ | 526,780 |  | $ | 1,526,790 |  | $ | 1,341,044 |
| Share-based compensation expense |  | 2,173 |  | 2,189 |  | 8,673 |  | 6,066 |
| Amortization of intangible assets |  | 2,450 |  | 2,441 |  | 7,344 |  | 8,569 |
| Gross profit - Non-GAAP |  | $ | 579,064 |  | $ | 531,410 |  | $ | 1,542,807 |  | $ | 1,355,679 |
| Gross margin - GAAP |  | 42.9 | % |  | 42.0 | % |  | 43.1 | % |  | 40.8 | % |
| Gross margin - Non-GAAP |  | 43.2 | % |  | 42.3 | % |  | 43.5 | % |  | 41.2 | % |
| Operating expenses - GAAP |  | $ | 339,885 |  | $ | 304,705 |  | $ | 977,839 |  | $ | 883,925 |
| Less: Share-based compensation expense |  | 24,020 |  | 18,424 |  | 67,394 |  | 58,126 |
| Less: Amortization of intangible assets and acquisition-related costs |  | 2,637 |  | 2,276 |  | 8,065 |  | 8,279 |
| Less: Restructuring charges, net |  | 110 |  | 839 |  | 725 |  | 2,562 |
| Operating expenses - Non-GAAP |  | $ | 313,118 |  | $ | 283,166 |  | $ | 901,655 |  | $ | 814,958 |
| % of net sales - GAAP |  | 25.4 | % |  | 24.3 | % |  | 27.6 | % |  | 26.9 | % |
| % of net sales - Non-GAAP |  | 23.4 | % |  | 22.6 | % |  | 25.4 | % |  | 24.8 | % |
| Operating income - GAAP |  | $ | 234,556 |  | $ | 222,075 |  | $ | 548,951 |  | $ | 457,119 |
| Share-based compensation expense |  | 26,193 |  | 20,613 |  | 76,067 |  | 64,192 |
| Amortization of intangible assets and acquisition-related costs |  | 5,087 |  | 4,717 |  | 15,409 |  | 16,848 |
| Restructuring charges, net |  | 110 |  | 839 |  | 725 |  | 2,562 |
| Operating income - Non-GAAP |  | $ | 265,946 |  | $ | 248,244 |  | $ | 641,152 |  | $ | 540,721 |
| % of net sales - GAAP |  | 17.5 | % |  | 17.7 | % |  | 15.5 | % |  | 13.9 | % |
| % of net sales - Non-GAAP |  | 19.8 | % |  | 19.8 | % |  | 18.1 | % |  | 16.5 | % |
| Net income - GAAP |  | $ | 200,147 |  | $ | 244,684 |  | $ | 487,463 |  | $ | 444,528 |
| Share-based compensation expense |  | 26,193 |  | 20,613 |  | 76,067 |  | 64,192 |
| Amortization of intangible assets and acquisition-related costs |  | 5,087 |  | 4,717 |  | 15,409 |  | 16,848 |
| Restructuring charges, net |  | 110 |  | 839 |  | 725 |  | 2,562 |
| Loss on investments |  | 119 |  | 604 |  | 1,718 |  | 12,213 |
| Non-GAAP income tax adjustment |  | 9,834 |  | (29,963) |  | 18,820 |  | (22,033) |
| Net income - Non-GAAP |  | $ | 241,490 |  | $ | 241,494 |  | $ | 600,202 |  | $ | 518,310 |
| Net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 1.32 |  | $ | 1.55 |  | $ | 3.18 |  | $ | 2.80 |
| Diluted - Non-GAAP |  | $ | 1.59 |  | $ | 1.53 |  | $ | 3.91 |  | $ | 3.26 |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non-GAAP |  | 151,895 |  | 157,440 |  | 153,506 |  | 158,843 |

[0001032975-25-000005:8k_2_02:42]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS* |  |  |  |  |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | Three months ended December 31, |  | Nine months ended December 31, |
| SHARE-BASED COMPENSATION EXPENSE |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 2,173 |  |  | $ | 2,189 |  |  | $ | 8,673 |  |  | $ | 6,066 |  |
| Marketing and selling |  | 11,813 |  |  | 8,878 |  |  | 34,133 |  |  | 28,623 |  |
| Research and development |  | 5,043 |  |  | 4,421 |  |  | 15,849 |  |  | 13,568 |  |
| General and administrative |  | 7,164 |  |  | 5,125 |  |  | 17,412 |  |  | 15,935 |  |
| Total share-based compensation expense |  | 26,193 |  |  | 20,613 |  |  | 76,067 |  |  | 64,192 |  |
| Income tax benefit |  | (4,523) |  |  | (3,391) |  |  | (16,901) |  |  | (11,257) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 21,670 |  |  | $ | 17,222 |  |  | $ | 59,166 |  |  | $ | 52,935 |  |

[0001032975-25-000005:8k_2_02:43]
*Note: These preliminary results for the three and nine months ended December 31, 2024 are subject to adjustments, including subsequent events that may occur through the date of filing our Quarterly Report on Form 10-Q.

[0001032975-25-000005:8k_2_02:44]
(A) Non-GAAP Financial Measures

[0001032975-25-000005:8k_2_02:45]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-25-000005:8k_2_02:46]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended December 31, 2024 and prior periods presented, we excluded items in the following general categories, each of which are described below:

[0001032975-25-000005:8k_2_02:47]
Share-based compensation expense. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-25-000005:8k_2_02:48]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit, operating expenses, and financial results from period to period.

[0001032975-25-000005:8k_2_02:49]
Acquisition-related costs. We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition-related costs include certain incremental expenses incurred to effect a business combination. We believe that providing the non-GAAP measures excluding these costs, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-25-000005:8k_2_02:50]
Restructuring charges (credits), net. These charges (credits) are associated with restructuring plans, and will vary based on the initiatives in place during any given period. Restructuring charges may include costs related to employee

[0001032975-25-000005:8k_2_02:51]
terminations, facility closures and early cancellation of certain contracts as well as other costs resulting from our restructuring initiatives. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results.

[0001032975-25-000005:8k_2_02:52]
Loss (gain) on investments. We recognize losses (gains) related to our investments in various companies, which vary depending on the operational and financial performance of the companies in which we invest. These amounts include our losses (earnings) on equity method investments, investment impairments and losses (gains) resulting from sales or other events related to our investments. We believe that providing the non-GAAP measures excluding these items, as well as the GAAP measures, assists our investors because such losses (gains) are not reflective of our ongoing operations.

[0001032975-25-000005:8k_2_02:53]
Non-GAAP income tax adjustment. Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above as well as the income tax impact of non-recurring deferred taxes, tax settlements, and other non-routine tax events, the determination of which is based upon the nature of the underlying items. For the three and nine months ended December 31, 2023, non-GAAP income tax adjustment included the tax benefit from a remeasurement of the tax basis of goodwill under the Swiss Federal Act on Tax Reform and AHV Financing (“TRAF”) during the three months ended December 31, 2023.

[0001032975-25-000005:8k_2_02:54]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-25-000005:8k_2_02:55]
Additional Supplemental Financial Information - Constant Currency

[0001032975-25-000005:8k_2_02:56]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.

## item 1.01 — body, verbatim

[0001032975-25-000005:8k_body:1]
ITEM 1.01 ENTRY INTO A MATERIAL DEFINITIVE AGREEMENT

[0001032975-25-000005:8k_body:2]
On January 27, 2025, (the “Closing Date”), Logitech International S.A., (the “Company”), together with its direct subsidiary, Logitech Europe S.A., as the borrower (the “Borrower”) entered into an unsecured committed $750 million revolving credit facility (the “Revolving Credit Facility”), pursuant to a Credit Agreement (the “Credit Agreement”), by and among the Company, the Borrower, the lenders from time to time party thereto and PNC Bank, National Association, as administrative agent (the “Administrative Agent”).

[0001032975-25-000005:8k_body:3]
The Revolving Credit Facility terminates on January 27, 2030 (the “Expiration Date”) unless the maturity is extended in accordance with the Credit Agreement. The Credit Agreement contains (1) an increase option permitting the Borrower, subject to certain requirements, to arrange with existing lenders and/or new lenders for them to provide up to an aggregate of $250 million in additional commitments for revolving loans, and (2) an extension option permitting the Borrower, subject to certain requirements, to arrange with existing lenders and/or new lenders to extend the Revolving Credit Facility for an additional one-year term (the “Extension Option”). The Extension Option may be exercised no more than two times under the Credit Agreement. Proceeds of loans made under the Credit Agreement may be used for general corporate purposes. No loans were made under the Credit Agreement on the Closing Date.

[0001032975-25-000005:8k_body:4]
Loans under the Revolving Credit Facility are available in U.S. Dollars, Euro, Sterling, Yen, Swiss Francs, Canadian Dollars, Australian Dollars and any other currency agreed to by each lender. U.S. Dollar-dominated loans bear interest, at the Borrower’s option, at (a) the base rate (“Base Rate”) or a term rate based upon the secured overnight financing rate (“Term SOFR Rate”), plus (b) a spread that is either based on the consolidated net leverage ratio of the Company and its subsidiaries or based on the Company’s or the Borrower’s debt credit ratings. Loans denominated in a currency other than U.S. Dollars bear interest at the rates specified in the Credit Agreement. The Company is also obligated to pay other customary fees for a credit facility of this size and type. For loans bearing interests at the Base Rate, interest is due and payable in arrears quarterly and for loans bearing interest at the Term SOFR Rate at the end of an interest period (or at each three-month interval in the case of loans with interest periods greater than three months). For loans denominated in a currency other than U.S. Dollars, interest is due and payable at the times specified in the Credit Agreement. Principal, together with all accrued and unpaid interest, is due and payable on the Expiration Date, as such date may be extended in connection with the Extension Option. The Company may prepay the loans and terminate the commitments, in whole or in part, at any time without premium or penalty, subject to certain conditions.

[0001032975-25-000005:8k_body:5]
The Credit Agreement contains customary affirmative and negative covenants, including covenants that limit or restrict the Company and its subsidiaries’ ability to, among other things, incur subsidiary indebtedness, grant liens, and dispose of all or substantially all assets, in each case subject to customary exceptions for a credit facility of this size and type. The Company is also required to maintain compliance with a net debt to adjusted EBITDA ratio.

[0001032975-25-000005:8k_body:6]
The Credit Agreement contains customary events of default, including, among others, non-payment defaults, representations and warranty defaults, covenant defaults, cross-defaults to agreements involving borrowed money or indebtedness, final judgment defaults, bankruptcy and insolvency defaults and a change of control default, in each case subject to customary exceptions for a credit facility of this size and type. The occurrence of an event of default could result in the acceleration of the obligations under the Credit Agreement.

[0001032975-25-000005:8k_body:7]
On the Closing Date, pursuant to a Guaranty Agreement (the “Guaranty Agreement”), by and among the Company and the Borrower in favor of the Administrative Agent, the Company and the Borrower also provided an unsecured guaranty of all amounts owing of the other under the Credit Agreement and related documents as well as specified cash management and hedging obligations.

[0001032975-25-000005:8k_body:8]
PNC Capital Markets LLC and BOFA Securities, Inc. acted as joint lead arrangers and joint bookrunners for the Revolving Credit Facility.

[0001032975-25-000005:8k_body:9]
The preceding description of the Credit Agreement and the Guaranty Agreement are a summary only and are qualified in their entirety by the full text of such agreements, copies of which are filed as Exhibit 10.1 and Exhibit 10.2 hereto and are incorporated herein by reference.

[0001032975-25-000005:8k_body:10]
Certain of the lenders under the Credit Agreement and their affiliates have engaged in, or may in the future engage in other commercial dealings in the ordinary course of business with the Company or its affiliates, including the provision of financial,

[0001032975-25-000005:8k_body:11]
banking and related services. These parties have received, and in the future may receive, compensation from the Company for these services.
