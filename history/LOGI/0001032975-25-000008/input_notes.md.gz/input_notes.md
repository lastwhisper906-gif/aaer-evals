# LOGI notes — 0001032975-25-000008


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-25-000008:notes:1]
[same as prior period, unchanged from 0001032975-24-000075:notes:1]

[0001032975-25-000008:notes:2]
Logitech International S.A., together with its consolidated subsidiaries ("Logitech" or the "Company"), designs software-enabled hardware solutions that help businesses thrive and bring people together when working, creating, gaming and streaming. As a point of connection between people and the digital world, the Company's mission is to extend human potential in work and play, in a way that is good for people and the planet.

[0001032975-25-000008:notes:3]
[same as prior period, unchanged from 0001032975-24-000075:notes:4]

[0001032975-25-000008:notes:4]
[same as prior period, unchanged from 0001032975-24-000075:notes:5]

[0001032975-25-000008:notes:5]
[same as prior period, unchanged from 0001032975-24-000075:notes:6]

[0001032975-25-000008:notes:6]
[same as prior period, unchanged from 0001032975-24-000075:notes:7]

[0001032975-25-000008:notes:7]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and nine months ended December 31, 2024 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2025, or any future periods.

[0001032975-25-000008:notes:8]
[same as prior period, unchanged from 0001032975-24-000075:notes:9]

[0001032975-25-000008:notes:9]
There have been no material changes in the Company’s significant accounting policies during the three and nine months ended December 31, 2024 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2024.

[0001032975-25-000008:notes:10]
[same as prior period, unchanged from 0001032975-24-000075:notes:11]

[0001032975-25-000008:notes:11]
[same as prior period, unchanged from 0001032975-24-000075:notes:12]

[0001032975-25-000008:notes:12]
[same as prior period, unchanged from 0001032975-24-000075:notes:13]

[0001032975-25-000008:notes:13]
[same as prior period, unchanged from 0001032975-24-000075:notes:14]

[0001032975-25-000008:notes:14]
The Company's business has continued to be impacted by macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, changes in fiscal policies, geopolitical conflicts, low economic growth in certain regions, and uncertainty in consumer and enterprise demand. In addition, the Company's business may be adversely impacted by the potential expansion of tariffs on goods imported into the U.S., as well as responsive or related policies enacted in other countries.

[0001032975-25-000008:notes:15]
[same as prior period, unchanged from 0001032975-24-000075:notes:16]

[0001032975-25-000008:notes:16]
[same as prior period, unchanged from 0001032975-24-000075:notes:17]

[0001032975-25-000008:notes:17]
In November 2023, the Financial Accounting Standard Board ("FASB") issued Accounting Standards Update ("ASU") 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures. ASU 2023-07 improves reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses that are regularly provided to the chief operating decision maker. In addition, ASU 2023-07 requires that all existing annual disclosures about segment profit or loss must be provided on an interim basis and clarifies that single reportable segment entities are subject to the disclosure requirement under Topic 280 in its entirety. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 and interim periods within those fiscal years beginning after December 15, 2024. A public entity should apply ASU 2023-07 retrospectively to all prior periods presented in the financial statements. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2023-07 on its consolidated financial statements and related disclosures.

[0001032975-25-000008:notes:18]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. ASU 2023-09 requires additional disclosures related to rate reconciliation, income taxes paid, and other disclosures. Under ASU 2023-09, for each annual period presented, public entities are required to (1) disclose specific categories in the tabular rate reconciliation and (2) provide additional information for reconciling items that meet a quantitative threshold. In addition, ASU 2023-09 requires all reporting entities to disclose on an annual basis the amount of income taxes paid disaggregated by federal, state, and foreign taxes as well as the amount of income taxes paid by individual jurisdiction. ASU 2023-09 is effective for public business entities for annual periods beginning after December 15, 2024 and can be applied on a prospective basis with an option to apply the standard retrospectively. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2023-09 on its consolidated financial statements and related disclosures.

[0001032975-25-000008:notes:19]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses. ASU 2024-03 requires all public entities to disclose in the notes to the financial statements the amounts of purchases of inventory, employee compensation, depreciation, and intangible asset amortization included in each expense caption of the income statement. ASU 2024-03 is effective for fiscal years beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027. ASU 2024-03 can be applied either prospectively or retrospectively. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2024-03 on its consolidated financial statements and related disclosures.


## us-gaap:EarningsPerShareTextBlock

[0001032975-25-000008:notes:20]
[same as prior period, unchanged from 0001032975-24-000075:notes:19]

[0001032975-25-000008:notes:21]
The following table summarizes the computations of basic and diluted net income per share for the three and nine months ended December 31, 2024 and 2023 (in thousands, except per share amounts):

[0001032975-25-000008:notes:22]
|  |  | Three months ended December 31, |  | Nine months ended December 31, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net income |  | $ | 200,147 |  |  | $ | 244,684 |  |  | $ | 487,463 |  |  | $ | 444,528 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 150,647 |  |  | 155,933 |  |  | 152,127 |  |  | 157,568 |  |
| Effect of potentially dilutive equivalent shares |  | 1,248 |  |  | 1,507 |  |  | 1,379 |  |  | 1,275 |  |
| Weighted average shares outstanding - diluted |  | 151,895 |  |  | 157,440 |  |  | 153,506 |  |  | 158,843 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.33 |  |  | $ | 1.57 |  |  | $ | 3.20 |  |  | $ | 2.82 |  |
| Diluted |  | $ | 1.32 |  |  | $ | 1.55 |  |  | $ | 3.18 |  |  | $ | 2.80 |  |

[0001032975-25-000008:notes:23]
Share equivalents attributable to outstanding stock options, restricted stock units and employee share purchase plans totaling 0.8 million for each of the three months ended December 31, 2024 and 2023, and 0.9 million and 1.3 million for the nine months ended December 31, 2024 and 2023, respectively, were excluded from the calculation of diluted net income per share because their effect would have been antidilutive. A small number of performance-based restricted stock units were not included in the dilutive net income per share calculation because all necessary conditions had not been satisfied by the end of the respective period, and those shares were not issuable if the end of the reporting period were the end of the performance contingency period.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-25-000008:notes:24]
[same as prior period, unchanged from 0001032975-24-000075:notes:24]

[0001032975-25-000008:notes:25]
[same as prior period, unchanged from 0001032975-24-000075:notes:25]

[0001032975-25-000008:notes:26]
As of December 31, 2024, the Company offers the 2006 Employee Share Purchase Plan (Non-U.S.), as amended and restated, the 1996 Employee Share Purchase Plan (U.S.), as amended and restated, and the 2006 Stock Incentive Plan, as amended and restated. Shares issued to employees as a result of purchases or exercises under these plans are generally issued from shares held in treasury stock.

[0001032975-25-000008:notes:27]
The following table summarizes the share-based compensation expense and total income tax benefit recognized for share-based awards for the three and nine months ended December 31, 2024 and 2023 (in thousands):

[0001032975-25-000008:notes:28]
|  |  | Three months ended December 31, |  | Nine months ended December 31, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Cost of goods sold |  | $ | 2,173 |  |  | $ | 2,189 |  |  | $ | 8,673 |  |  | $ | 6,066 |  |
| Marketing and selling |  | 11,813 |  |  | 8,878 |  |  | 34,133 |  |  | 28,623 |  |
| Research and development |  | 5,043 |  |  | 4,421 |  |  | 15,849 |  |  | 13,568 |  |
| General and administrative |  | 7,164 |  |  | 5,125 |  |  | 17,412 |  |  | 15,935 |  |
| Total share-based compensation expense |  | 26,193 |  |  | 20,613 |  |  | 76,067 |  |  | 64,192 |  |
| Income tax benefit |  | (4,523) |  |  | (3,391) |  |  | (16,901) |  |  | (11,257) |  |
| Total share-based compensation expense, net of income tax benefit |  | $ | 21,670 |  |  | $ | 17,222 |  |  | $ | 59,166 |  |  | $ | 52,935 |  |

[0001032975-25-000008:notes:29]
[same as prior period, unchanged from 0001032975-24-000075:notes:29]

[0001032975-25-000008:notes:30]
Share-based compensation costs capitalized as part of inventory were $1.6 million and $1.4 million for the three months ended December 31, 2024 and 2023, respectively, and $5.9 million and $4.8 million for the nine months ended December 31, 2024 and 2023, respectively.

[0001032975-25-000008:notes:31]
[same as prior period, unchanged from 0001032975-24-000075:notes:31]

[0001032975-25-000008:notes:32]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The costs of $1.8 million and $1.9 million recorded for the three months ended December 31, 2024 and 2023, respectively, and $5.3 million and $5.7 million recorded for the nine months ended December 31, 2024 and 2023, respectively, were primarily related to service costs.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-25-000008:notes:33]
[same as prior period, unchanged from 0001032975-24-000075:notes:33]

[0001032975-25-000008:notes:34]
[same as prior period, unchanged from 0001032975-24-000075:notes:34]

[0001032975-25-000008:notes:35]
The income tax provision for the three and nine months ended December 31, 2024 was $45.1 million and $101.2 million based on an effective income tax rate of 18.4% and 17.2% of pre-tax income, respectively. The income tax provision (benefit) for the same periods ended December 31, 2023 was a benefit of $9.6 million and a provision of $33.3 million based on an effective income tax rate of (4.1)% and 7.0% of pre-tax income, respectively.

[0001032975-25-000008:notes:36]
The change in the effective income tax rate for the three and nine months ended December 31, 2024, compared with the same periods ended December 31, 2023, was primarily due to the change in the mix of income and losses in the various tax jurisdictions in which the Company operates and unrecognized tax benefits due to uncertain tax positions compared with the discrete tax benefits recognized in the prior period for the remeasurement of the tax basis of goodwill under the Swiss Federal Act on Tax Reform and AHV Financing ("TRAF"), remeasurement of the Company's Swiss deferred tax assets due to a change in tax rate, and Foreign Derived Intangible Income ("FDII") incentive provided by the Tax Cuts and Jobs Act.

[0001032975-25-000008:notes:37]
The canton of Vaud completed the legislative process to enact TRAF, a reform to better align the Swiss tax system to international tax standards, on March 10, 2020 to take effect as of January 1, 2020. In March 2020, the Company increased the tax basis of goodwill, as a transition measure under TRAF, to be amortized over ten years beginning on January 1, 2020. During the three months ended December 31, 2023, the Company remeasured the tax basis of goodwill under TRAF, which resulted in an income tax benefit of $25.1 million, net of assessment of uncertain tax positions. The remeasurement of the step-up will be amortized over the remaining ten-year amortization period.

[0001032975-25-000008:notes:38]
On December 29, 2023, a change to the cantonal tax legislation was published. According to the law approved by the Vaud parliament, a progressive scale will be applicable for cantonal tax purposes resulting in an increase from the then current tax rate of 13.61% to 14.28% effective fiscal year 2025. The increase in tax rate resulted in a tax benefit of $5.1 million due to a remeasurement of the Company's Swiss deferred tax assets in the fiscal quarter ended December 31, 2023.

[0001032975-25-000008:notes:39]
The Tax Cuts and Jobs Act enacted Section 250, which provides for a deduction with respect to Global Intangible Low-Taxed Income ("GILTI") and FDII in the U.S. The application of this tax incentive is inherently complex. During the three months ended December 31, 2023, the Company analyzed the applicability of FDII and determined that this tax incentive applies to fiscal years 2021, 2022 and 2023. As a result, the Company realized a tax benefit of $17.9 million related to FDII. The Company has also concluded that any GILTI tax since the enactment of Tax Cuts and Jobs Act is immaterial.

[0001032975-25-000008:notes:40]
The Base Erosion and Profit Shifting Project (the “BEPS Project”) undertaken by the Organization for Economic Co-operation and Development (the "OECD") recommended changes to numerous long-standing tax principles, including a proposal to reallocate profits among tax jurisdictions in which companies do business (“Pillar One”) and establishing a minimum tax on global income (“Pillar Two”). Some jurisdictions, including Switzerland, where the Company operates are implementing Pillar Two laws to effectuate a 15% minimum tax. The minimum tax

[0001032975-25-000008:notes:41]
effective beginning in fiscal year 2025 for the Company is treated as a current cost and does not have a material impact on the Company's effective tax rate. The OECD and participating countries continue to issue underlying rules and administrative guidance related to Pillar Two, and the Company continues to monitor the relevant developments.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-25-000008:notes:42]
[same as prior period, unchanged from 0001032975-24-000075:notes:39]

[0001032975-25-000008:notes:43]
[same as prior period, unchanged from 0001032975-24-000075:notes:40]

[0001032975-25-000008:notes:44]
|  |  | December 31, 2024 |  | March 31, 2024 |
| Accounts receivable, net: |  |  |  |  |
| Accounts receivable |  | $ | 966,878 |  |  | $ | 744,836 |  |
| Allowance for cooperative marketing arrangements |  | (52,861) |  |  | (41,634) |  |
| Allowance for customer incentive programs |  | (109,599) |  |  | (60,027) |  |
| Allowance for pricing programs |  | (125,627) |  |  | (91,280) |  |
| Other allowances |  | (30,561) |  |  | (10,180) |  |
|  |  | $ | 648,230 |  |  | $ | 541,715 |  |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 43,106 |  |  | $ | 65,209 |  |
| Finished goods |  | 440,463 |  |  | 357,304 |  |
|  |  | $ | 483,569 |  |  | $ | 422,513 |  |
| Other current assets: |  |  |  |  |
| Value-added tax ("VAT") receivables |  | $ | 55,625 |  |  | $ | 41,172 |  |
| Prepaid expenses and other assets |  | 83,898 |  |  | 105,098 |  |
|  |  | $ | 139,523 |  |  | $ | 146,270 |  |
| Property, plant and equipment, net: |  |  |  |  |
| Property, plant and equipment |  | $ | 524,347 |  |  | $ | 503,882 |  |
| Less: accumulated depreciation and amortization |  | (414,800) |  |  | (387,293) |  |
|  |  | $ | 109,547 |  |  | $ | 116,589 |  |
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 213,986 |  |  | $ | 224,831 |  |
| Right-of-use assets |  | 77,044 |  |  | 61,163 |  |
| Investments for deferred compensation plan |  | 31,037 |  |  | 29,174 |  |
| Investments in privately held companies |  | 28,092 |  |  | 28,662 |  |
| Other assets |  | 7,356 |  |  | 6,364 |  |
|  |  | $ | 357,515 |  |  | $ | 350,194 |  |

[0001032975-25-000008:notes:45]
[same as prior period, unchanged from 0001032975-24-000075:notes:42]

[0001032975-25-000008:notes:46]
|  |  | December 31, 2024 |  | March 31, 2024 |
| Accrued and other current liabilities: |  |  |  |  |
| Accrued customer marketing, pricing and incentive programs |  | $ | 186,803 |  |  | $ | 170,371 |  |
| Accrued personnel expenses |  | 163,688 |  |  | 145,473 |  |
| Income taxes payable |  | 63,264 |  |  | 24,196 |  |
| VAT payable |  | 35,625 |  |  | 28,253 |  |
| Warranty liabilities |  | 33,755 |  |  | 30,270 |  |
| Accrued sales return liability |  | 28,397 |  |  | 30,098 |  |
| Deferred revenue (1) |  | 25,911 |  |  | 19,262 |  |
| Accrued loss for inventory purchase commitments |  | 18,783 |  |  | 29,349 |  |
| Operating lease liabilities |  | 16,044 |  |  | 15,107 |  |
| Other current liabilities |  | 142,997 |  |  | 144,883 |  |
|  |  | $ | 715,267 |  |  | $ | 637,262 |  |
| Other non-current liabilities: |  |  |  |  |
| Operating lease liabilities |  | $ | 78,829 |  |  | $ | 61,920 |  |
| Employee benefit plan obligations |  | 40,834 |  |  | 42,707 |  |
| Deferred revenue (1) |  | 35,492 |  |  | 21,097 |  |
| Obligation for deferred compensation plan |  | 31,037 |  |  | 29,174 |  |
| Warranty liabilities |  | 15,306 |  |  | 14,384 |  |
| Deferred tax liabilities |  | 682 |  |  | 705 |  |
| Other non-current liabilities |  | 2,847 |  |  | 2,603 |  |
|  |  | $ | 205,027 |  |  | $ | 172,590 |  |

[0001032975-25-000008:notes:47]
[same as prior period, unchanged from 0001032975-24-000075:notes:44]


## us-gaap:FairValueDisclosuresTextBlock

[0001032975-25-000008:notes:48]
[same as prior period, unchanged from 0001032975-24-000075:notes:45]

[0001032975-25-000008:notes:49]
The Company considers fair value as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants at the measurement date. The Company utilizes the following three-level fair value hierarchy to establish the priority of the inputs used to measure fair value:

[0001032975-25-000008:notes:50]
[same as prior period, unchanged from 0001032975-24-000075:notes:47]

[0001032975-25-000008:notes:51]
[same as prior period, unchanged from 0001032975-24-000075:notes:48]

[0001032975-25-000008:notes:52]
[same as prior period, unchanged from 0001032975-24-000075:notes:49]

[0001032975-25-000008:notes:53]
[same as prior period, unchanged from 0001032975-24-000075:notes:50]

[0001032975-25-000008:notes:54]
|  |  | December 31, 2024 |  | March 31, 2024 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 1,069,986 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,042,604 |  |  | $ | — |  |  | $ | — |  |
| Investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 142 |  |  | $ | — |  |  | $ | — |  |  | $ | 312 |  |  | $ | — |  |  | $ | — |  |
| Common stock |  | 773 |  |  | — |  |  | — |  |  | 573 |  |  | — |  |  | — |  |
| Money market funds |  | 7,847 |  |  | — |  |  | — |  |  | 8,129 |  |  | — |  |  | — |  |
| Mutual funds |  | 22,275 |  |  | — |  |  | — |  |  | 20,160 |  |  | — |  |  | — |  |
| Total investments for deferred compensation plan |  | $ | 31,037 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,174 |  |  | $ | — |  |  | $ | — |  |
| Currency derivative assetsincluded in other current assets |  | $ | — |  |  | $ | 148 |  |  | $ | — |  |  | $ | — |  |  | $ | 913 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Contingent consideration included in accrued and other current liabilities |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,215 |  |
| Currency derivative liabilitiesincluded in accrued and other current liabilities |  | $ | — |  |  | $ | 470 |  |  | $ | — |  |  | $ | — |  |  | $ | 573 |  |  | $ | — |  |

[0001032975-25-000008:notes:55]
[same as prior period, unchanged from 0001032975-24-000075:notes:52]

[0001032975-25-000008:notes:56]
The marketable securities for the Company's deferred compensation plan were recorded at a fair value of $31.0 million and $29.2 million, as of December 31, 2024 and March 31, 2024, respectively, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized gains (losses) related to marketable securities for the three and nine months ended December 31, 2024 and 2023 were not material and were included in other income (expense), net, and corresponding changes in the deferred compensation liability were included in operating expenses and cost of goods sold, in the Company's condensed consolidated statements of operations.

[0001032975-25-000008:notes:57]
[same as prior period, unchanged from 0001032975-24-000075:notes:54]

[0001032975-25-000008:notes:58]
The Company has certain non-marketable investments included in other assets that are accounted for as equity method investments, with a carrying value of $18.7 million and $18.0 million as of December 31, 2024 and March 31, 2024, respectively. Gains (losses) related to equity method investments for the three and nine months ended December 31, 2024 and 2023 were not material and are included in other income (expense), net, in the Company's condensed consolidated statements of operations. There was no impairment of equity method investments during the three and nine months ended December 31, 2024 and 2023.

[0001032975-25-000008:notes:59]
[same as prior period, unchanged from 0001032975-24-000075:notes:56]

[0001032975-25-000008:notes:60]
[same as prior period, unchanged from 0001032975-24-000075:notes:57]

[0001032975-25-000008:notes:61]
The Company has certain equity investments without readily determinable fair values due to the absence of quoted market prices, the inherent lack of liquidity, and the fact that inputs used to measure fair value are unobservable and require management's judgment. When certain events or circumstances indicate that impairment may exist, the Company revalues the investments using various assumptions, including the financial metrics and ratios of comparable public companies. The carrying value is also adjusted for observable price changes with the same or similar security from the same issuer. The amount of these equity investments without readily determinable fair value included in other assets was $8.8 million and $10.1 million as of December 31, 2024 and March 31, 2024, respectively. The impairment charges related to these equity investments were not material during the three and nine months ended December 31, 2024 and 2023.

[0001032975-25-000008:notes:62]
During the nine months ended December 31, 2023, the Company recorded an impairment loss, before tax, of $9.6 million as a result of the write-off of a note receivable which has been deemed no longer recoverable. This note receivable was previously obtained in conjunction with an exchange transaction related to the Company's investment in a privately held company. The impairment loss is included in other income (expense), net, in the Company's condensed consolidated statement of operations for the nine months ended December 31, 2023.

[0001032975-25-000008:notes:63]
Non-Financial Assets
Goodwill, intangible assets, and property, plant and equipment, are not required to be measured at fair value on a recurring basis. However, if the Company is required to evaluate these non-financial assets for impairment, whether due to certain triggering events or because of the required annual impairment test, and a resulting impairment is recorded to reduce the carrying value to the fair value, the non-financial assets are measured at fair value during such period. There was no impairment of non-financial assets during the three and nine months ended December 31, 2024 and 2023.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-25-000008:notes:64]
[same as prior period, unchanged from 0001032975-24-000075:notes:62]

[0001032975-25-000008:notes:65]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis in other current assets and accrued and other current liabilities, respectively, on the condensed consolidated balance sheets as of December 31, 2024 and March 31, 2024. See Note 6 for the fair values of the Company’s derivative instruments as of December 31, 2024 and March 31, 2024.

[0001032975-25-000008:notes:66]
[same as prior period, unchanged from 0001032975-24-000075:notes:64]

[0001032975-25-000008:notes:67]
[same as prior period, unchanged from 0001032975-24-000075:notes:65]

[0001032975-25-000008:notes:68]
The notional amounts of foreign currency exchange forward contracts outstanding related to forecasted inventory purchases were $124.3 million and $90.5 million as of December 31, 2024 and March 31, 2024, respectively. The Company had $2.5 million of net gain related to its cash flow hedges included in accumulated other comprehensive loss as of December 31, 2024, which will be reclassified into earnings within the next twelve months.

[0001032975-25-000008:notes:69]
The following table presents the amounts of gain (loss) on the Company’s derivative instruments designated as hedging instruments for the three and nine months ended December 31, 2024 and 2023 and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income (in thousands):

[0001032975-25-000008:notes:70]
|  |  | Three months ended December 31, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  |  |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  |  |
| Cash flow hedges |  | $ | 3,577 |  |  | $ | (2,539) |  |  | $ | 790 |  |  | $ | (863) |  |  |  |  |  |
|  |  | Nine months ended December 31, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of Loss (Gain)Reclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |  |  |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |  |  |  |
| Cash flow hedges |  | $ | 2,228 |  |  | $ | (1,165) |  |  | $ | (849) |  |  | $ | 3,493 |  |  |  |  |  |

[0001032975-25-000008:notes:71]
[same as prior period, unchanged from 0001032975-24-000075:notes:69]

[0001032975-25-000008:notes:72]
[same as prior period, unchanged from 0001032975-24-000075:notes:70]

[0001032975-25-000008:notes:73]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within approximately one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are not material and included in other income (expense), net, in the condensed consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of December 31, 2024 and March 31, 2024 were $113.3 million and $79.4 million, respectively.

[0001032975-25-000008:notes:74]
[same as prior period, unchanged from 0001032975-24-000075:notes:72]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-25-000008:notes:75]
Goodwill and Other Intangible Assets
The Company conducts its impairment analysis of goodwill annually at December 31 or more frequently if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting unit may be less than its carrying amount. The Company conducted its annual impairment analysis of goodwill as of December 31, 2024 by performing a qualitative assessment and concluded that it was more likely than not that the fair value of its reporting unit exceeds its carrying amount.

[0001032975-25-000008:notes:76]
[same as prior period, unchanged from 0001032975-24-000075:notes:74]

[0001032975-25-000008:notes:77]
| As of March 31, 2024 |  | $ | 461,978 |  |
| Effects of foreign currency translation |  | (795) |  |
| As of December 31, 2024 |  | $ | 461,183 |  |

[0001032975-25-000008:notes:78]
[same as prior period, unchanged from 0001032975-24-000075:notes:76]

[0001032975-25-000008:notes:79]
|  |  | December 31, 2024 |  | March 31, 2024 |
|  |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademarks and trade names |  | $ | 32,390 |  |  | $ | (27,941) |  |  | $ | 4,449 |  |  | $ | 32,390 |  |  | $ | (25,739) |  |  | $ | 6,651 |  |
| Developed technology |  | 107,421 |  |  | (94,224) |  |  | 13,197 |  |  | 107,421 |  |  | (86,855) |  |  | 20,566 |  |
| Customer contracts/relationships |  | 69,087 |  |  | (56,750) |  |  | 12,337 |  |  | 69,087 |  |  | (51,061) |  |  | 18,026 |  |
| Effects of foreign currency translation |  | (1,411) |  |  | 589 |  |  | (822) |  |  | (1,019) |  |  | 379 |  |  | (640) |  |
| Total |  | $ | 207,487 |  |  | $ | (178,326) |  |  | $ | 29,161 |  |  | $ | 207,879 |  |  | $ | (163,276) |  |  | $ | 44,603 |  |


## us-gaap:DebtDisclosureTextBlock

[0001032975-25-000008:notes:80]
Financing Arrangements

[0001032975-25-000008:notes:81]
The Company had several uncommitted, unsecured bank lines of credit and letters of credit aggregating $171.3 million and $172.5 million as of December 31, 2024 and March 31, 2024, respectively. There are no financial covenants under the lines of credit with which the Company must comply. There was no borrowing outstanding under the lines of credit as of December 31, 2024 or March 31, 2024. As of December 31, 2024 and March 31, 2024, the Company had outstanding bank guarantees of $27.7 million and $14.3 million, respectively.

[0001032975-25-000008:notes:82]
On January 27, 2025, the Company entered into an unsecured revolving credit facility with a syndicate of banks (the "Credit Agreement"). The Credit Agreement provides a revolving line of credit of up to $750 million to the Company including the issuance of letters of credit of up to $100 million. The Credit Agreement terminates on January 27, 2030 unless extended in accordance with its terms. The Credit Agreement contains (1) an increase option allowing the Company to secure up to $250 million of additional commitments and (2) an extension option to extend the term by one-year which may be exercised no more than two times, subject to certain requirements. Loans under the Credit Agreement are available in U.S. Dollars, Euro, Sterling, Yen, Swiss Francs, Canadian Dollars, Australian Dollars and any other currency agreed to by each lender. Proceeds of loans made under the Credit Agreement may be used for general corporate purposes.

[0001032975-25-000008:notes:83]
The Credit Agreement contains a maximum net debt to adjusted EBITDA ratio, compliance with which is a condition to the Company's ability to borrow. Borrowings under the Credit Agreement will bear interest at a rate determined by reference to benchmark rates plus an applicable spread (ranging from 0% to 1.5%) based on the Company's net leverage ratio or credit rating at the time of the borrowing. Undrawn balances available under the Credit Agreement are subject to commitment fees at the applicable rate determined by reference to the Company's net leverage ratio or credit rating. There has been no borrowing outstanding under the Credit Agreement as of January 29, 2025.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-25-000008:notes:84]
Commitments and Contingencies

[0001032975-25-000008:notes:85]
Product Warranties

[0001032975-25-000008:notes:86]
Changes in the Company’s warranty liabilities for the three and nine months ended December 31, 2024 and 2023 were as follows (in thousands):

[0001032975-25-000008:notes:87]
|  | Three months ended December 31, |  | Nine months ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Beginning of the period | $ | 46,833 |  |  | $ | 40,265 |  |  | $ | 44,654 |  |  | $ | 40,886 |  |
| Provision | 12,060 |  |  | 11,249 |  |  | 34,022 |  |  | 30,734 |  |
| Settlements | (9,111) |  |  | (10,158) |  |  | (29,124) |  |  | (29,914) |  |
| Effects of foreign currency translation | (721) |  |  | 421 |  |  | (491) |  |  | 71 |  |
| End of the period | $ | 49,061 |  |  | $ | 41,777 |  |  | $ | 49,061 |  |  | $ | 41,777 |  |

[0001032975-25-000008:notes:88]
Indemnifications

[0001032975-25-000008:notes:89]
The Company indemnifies certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2024, no material amounts have been accrued for indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-25-000008:notes:90]
The Company also indemnifies its current and former directors and certain current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not capped, the obligations are conditional in nature, and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-25-000008:notes:91]
Legal Proceedings

[0001032975-25-000008:notes:92]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and legal proceedings. The Company intends to vigorously defend against them. Management periodically assesses the Company’s liabilities and contingencies in connection with these matters based upon the latest information available. The Company follows ASC ("Accounting Standards Codification") 450, Contingencies, in determining the accounting and disclosure for these contingencies. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows, and results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity, and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-25-000008:notes:93]
Shareholders’ Equity
Share Capital

[0001032975-25-000008:notes:94]
As of December 31, 2024, the Company's nominal share capital is CHF 42.2 million, consisting of 168,994,142 issued shares with a par value of CHF 0.25 each, of which 19,555,027 were held in treasury shares.

[0001032975-25-000008:notes:95]
The capital band under Swiss law allows a company's board of directors to adjust the company's share capital within a predefined range based on a general authority granted by the company's shareholders. At the 2023 Annual General Meeting ("AGM"), the Company's shareholders approved an amendment to the Company’s Articles of Incorporation to introduce a capital band provision authorizing the Board of Directors to adjust the Company's share capital, without additional shareholder approval, within a range of 155,795,958 registered shares to 190,417,282 registered shares for the five-year period ending on September 13, 2028. In addition, the Company has reserved conditional capital (1) up to 25,000,000 shares for potential issuance for the exercise of rights granted under the Company's employee equity incentive plans, and (2) up to 25,000,000 shares for issuance to cover any conversion rights under any potential future convertible bond issuance.

[0001032975-25-000008:notes:96]
In September 2024, the Company's Board of Directors approved the cancellation of 4.1 million treasury shares, which were repurchased in fiscal year 2024 for an aggregate cost of $332.1 million under the 2023 share repurchase program. The cancellation became effective in the quarter ended December 31, 2024, and as a result both the number of registered shares issued and the number of treasury shares outstanding decreased by 4.1 million shares. Upon cancellation of these shares, the Company deducted the par value from registered shares and reflected the excess of share repurchase cost over par value as a reduction to retained earnings.

[0001032975-25-000008:notes:97]
Share Repurchases

[0001032975-25-000008:notes:98]
In June 2023, the Company's Board of Directors approved a three-year share repurchase program, which allows the Company to use up to $1.0 billion to repurchase its shares. The 2023 share repurchase program enables

[0001032975-25-000008:notes:99]
the Company to repurchase shares for cancellation, as well as to support equity incentive plans or potential acquisitions. The Swiss Takeover Board approved the 2023 share repurchase program in July 2023 and the program became effective on July 28, 2023. During the nine months ended December 31, 2024, the Company repurchased 5.3 million shares for an aggregate cost of $461.4 million under the 2023 share repurchase program for cancellation, of which $17.6 million of the aggregate cost was not paid yet as of December 31, 2024. As of December 31, 2024, $174.8 million was available for repurchase under the 2023 share repurchase program.

[0001032975-25-000008:notes:100]
During the nine months ended December 31, 2023, the Company repurchased 3.0 million shares for an aggregate cost of $232.5 million under the 2023 share repurchase program for cancellation, of which $14.8 million of the aggregate cost was not paid yet as of December 31, 2023. In addition, the Company repurchased 2.6 million shares for an aggregate cost of $159.1 million under the previous share repurchase program during the nine months ended December 31, 2023. This previous share repurchase program was initially approved by the Company's Board of Directors in May 2020, to purchase Logitech shares to support equity incentive plans or potential acquisitions, and expired on July 27, 2023.

[0001032975-25-000008:notes:101]
Swiss law limits a company’s ability to hold or repurchase its own shares. The aggregate par value of all shares held in treasury by the Company and its subsidiaries may not exceed 10% of the issued share capital of the Company, which for the Company corresponds to approximately 16.9 million registered shares as of December 31, 2024. This limitation does not apply to shares repurchased for cancellation, due to the Board of Directors’ authority under the Company’s capital band set forth in the Company’s Articles of Incorporation. As of December 31, 2024, the Company had a total of 19.6 million shares held in treasury stock, which includes 5.3 million shares that have been repurchased for cancellation and 14.3 million shares that have been purchased to support equity incentive plans or potential acquisitions.

[0001032975-25-000008:notes:102]
[same as prior period, unchanged from 0001032975-24-000075:notes:94]

[0001032975-25-000008:notes:103]
[same as prior period, unchanged from 0001032975-24-000075:notes:97]

[0001032975-25-000008:notes:104]
During the nine months ended December 31, 2024, the Company declared cash dividends of CHF 1.16 (USD equivalent of $1.37 based on the exchange rate on the date of declaration) per share and paid a total of $207.9 million on the Company's outstanding shares. During the nine months ended December 31, 2023, the Company declared cash dividends of CHF 1.06 (USD equivalent of $1.19 based on the exchange rate on the date of declaration) per share and paid a total of $182.3 million on the Company's outstanding shares.

[0001032975-25-000008:notes:105]
[same as prior period, unchanged from 0001032975-24-000075:notes:99]

[0001032975-25-000008:notes:106]
[same as prior period, unchanged from 0001032975-24-000075:notes:100]

[0001032975-25-000008:notes:107]
[same as prior period, unchanged from 0001032975-24-000075:notes:101]

[0001032975-25-000008:notes:108]
|  |  | Currency Translation Adjustment |  | Defined Benefit Plans |  | Deferred Hedging Gains |  | Total |
| March 31, 2024 |  | $ | (103,947) |  |  | $ | (8,395) |  |  | $ | 1,140 |  |  | $ | (111,202) |  |
| Other comprehensive income (loss) |  | (23,998) |  |  | (501) |  |  | 1,379 |  |  | (23,120) |  |
| December 31, 2024 |  | $ | (127,945) |  |  | $ | (8,896) |  |  | $ | 2,519 |  |  | $ | (134,322) |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-25-000008:notes:109]
[same as prior period, unchanged from 0001032975-24-000075:notes:103]

[0001032975-25-000008:notes:110]
[same as prior period, unchanged from 0001032975-24-000075:notes:104]

[0001032975-25-000008:notes:111]
Sales by product category for the three and nine months ended December 31, 2024 and 2023 were as follows (in thousands):

[0001032975-25-000008:notes:112]
|  |  | Three months ended December 31, |  | Nine months ended December 31, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Gaming (1) |  | $ | 466,715 |  |  | $ | 409,043 |  |  | $ | 1,076,660 |  |  | $ | 957,576 |  |
| Keyboards & Combos |  | 236,748 |  |  | 229,432 |  |  | 662,017 |  |  | 605,201 |  |
| Pointing Devices |  | 217,045 |  |  | 206,180 |  |  | 602,927 |  |  | 572,310 |  |
| Video Collaboration |  | 176,053 |  |  | 169,522 |  |  | 482,755 |  |  | 461,257 |  |
| Webcams |  | 84,419 |  |  | 85,851 |  |  | 237,572 |  |  | 249,273 |  |
| Tablet Accessories |  | 77,433 |  |  | 64,239 |  |  | 241,586 |  |  | 198,252 |  |
| Headsets |  | 45,886 |  |  | 41,762 |  |  | 137,038 |  |  | 123,023 |  |
| Other (2) |  | 35,995 |  |  | 49,444 |  |  | 103,990 |  |  | 120,088 |  |
| Total Sales |  | $ | 1,340,294 |  |  | $ | 1,255,473 |  |  | $ | 3,544,545 |  |  | $ | 3,286,980 |  |

[0001032975-25-000008:notes:113]
[same as prior period, unchanged from 0001032975-24-000075:notes:107]

[0001032975-25-000008:notes:114]
[same as prior period, unchanged from 0001032975-24-000075:notes:108]

[0001032975-25-000008:notes:115]
Sales by geographic region (based on the customers’ locations) for the three and nine months ended December 31, 2024 and 2023 were as follows (in thousands):

[0001032975-25-000008:notes:116]
|  |  | Three months ended December 31, |  | Nine months ended December 31, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Americas |  | $ | 553,563 |  |  | $ | 538,530 |  |  | $ | 1,518,933 |  |  | $ | 1,446,104 |  |
| EMEA |  | 454,665 |  |  | 416,618 |  |  | 1,116,368 |  |  | 987,301 |  |
| Asia Pacific |  | 332,066 |  |  | 300,325 |  |  | 909,244 |  |  | 853,575 |  |
| Total Sales |  | $ | 1,340,294 |  |  | $ | 1,255,473 |  |  | $ | 3,544,545 |  |  | $ | 3,286,980 |  |

[0001032975-25-000008:notes:117]
[same as prior period, unchanged from 0001032975-24-000075:notes:111]

[0001032975-25-000008:notes:118]
Switzerland, the Company’s country of domicile, represented 3% of the Company's total consolidated sales for each of the three months ended December 31, 2024 and 2023, and 3% and 2% of the Company's total consolidated sales for the nine months ended December 31, 2024 and 2023, respectively.

[0001032975-25-000008:notes:119]
Three customers of the Company each represented 10% or more of the total consolidated gross sales for each of the three and nine months ended December 31, 2024 and 2023.

[0001032975-25-000008:notes:120]
[same as prior period, unchanged from 0001032975-24-000075:notes:114]

[0001032975-25-000008:notes:121]
|  |  | December 31, 2024 |  | March 31, 2024 |
| Americas |  | $ | 62,920 |  |  | $ | 67,762 |  |
| EMEA |  | 47,144 |  |  | 30,819 |  |
| Asia Pacific |  | 57,281 |  |  | 58,901 |  |
| Total |  | $ | 167,345 |  |  | $ | 157,482 |  |

[0001032975-25-000008:notes:122]
Property, plant and equipment, net (excluding software) and right-of-use assets in the United States, China and Ireland, were $61.3 million, $39.9 million, and $14.4 million, respectively, as of December 31, 2024. Property, plant and equipment, net (excluding software) and right-of-use assets in the United States, China, and Ireland were $66.5 million, $41.2 million, and $16.2 million, respectively, as of March 31, 2024. 
Property, plant and equipment, net (excluding software) and right-of-use assets in Switzerland, the Company’s country of domicile, were $23.5 million and $9.0 million as of December 31, 2024 and March 31, 2024, respectively. No other countries represented more than 10% of the Company’s total property, plant and equipment, net (excluding software) and right-of-use assets as of December 31, 2024 or March 31, 2024.
