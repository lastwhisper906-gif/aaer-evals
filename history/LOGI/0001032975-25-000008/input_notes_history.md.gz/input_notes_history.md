# LOGI note change history — 0001032975-24-000075 → 0001032975-25-000008


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-01-29):
[0001032975-25-000008:note_history:1]
Changes in the Company’s warranty liabilities for the three and nine months ended December 31, 2024 and 2023 were as follows (in thousands):
  (was, 2024-10-24, similarity 0.9621):
[0001032975-24-000075:note_history:1]
Changes in the Company’s warranty liabilities for the three and six months ended September 30, 2024 and 2023 were as follows (in thousands):

- changed (2025-01-29):
[0001032975-25-000008:note_history:2]
|  | Three months ended December 31, |  | Nine months ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Beginning of the period | $ | 46,833 |  |  | $ | 40,265 |  |  | $ | 44,654 |  |  | $ | 40,886 |  |
| Provision | 12,060 |  |  | 11,249 |  |  | 34,022 |  |  | 30,734 |  |
| Settlements | (9,111) |  |  | (10,158) |  |  | (29,124) |  |  | (29,914) |  |
| Effects of foreign currency translation | (721) |  |  | 421 |  |  | (491) |  |  | 71 |  |
| End of the period | $ | 49,061 |  |  | $ | 41,777 |  |  | $ | 49,061 |  |  | $ | 41,777 |  |
  (was, 2024-10-24, similarity 0.9042):
[0001032975-24-000075:note_history:2]
|  | Three months ended September 30, |  | Six months ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Beginning of the period | $ | 44,502 |  |  | $ | 39,885 |  |  | $ | 44,654 |  |  | $ | 40,886 |  |
| Provision | 11,776 |  |  | 10,393 |  |  | 21,962 |  |  | 19,485 |  |
| Settlements | (9,975) |  |  | (9,838) |  |  | (20,013) |  |  | (19,756) |  |
| Effects of foreign currency translation | 530 |  |  | (175) |  |  | 230 |  |  | (350) |  |
| End of the period | $ | 46,833 |  |  | $ | 40,265 |  |  | $ | 46,833 |  |  | $ | 40,265 |  |

- changed (2025-01-29):
[0001032975-25-000008:note_history:3]
The Company indemnifies certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2024, no material amounts have been accrued for indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2024-10-24, similarity 0.9945):
[0001032975-24-000075:note_history:3]
The Company indemnifies certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2024, no material amounts have been accrued for indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

- added (2025-01-29):
[0001032975-25-000008:note_history:4]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and legal proceedings. The Company intends to vigorously defend against them. Management periodically assesses the Company’s liabilities and contingencies in connection with these matters based upon the latest information available. The Company follows ASC ("Accounting Standards Codification") 450, Contingencies, in determining the accounting and disclosure for these contingencies. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows, and results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity, and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.

- removed (2025-01-29):
[0001032975-24-000075:note_history:5]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and legal proceedings. The Company intends to vigorously defend against them. Management periodically assesses the Company’s liabilities and contingencies in connection with these matters based upon the latest information available. The Company follows ASC

- removed (2025-01-29):
[0001032975-24-000075:note_history:6]
("Accounting Standards Codification") 450, Contingencies, in determining the accounting and disclosure for these contingencies. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows and results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company's defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company's business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against the Company can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company's business.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-01-29):
[0001032975-25-000008:note_history:7]
Logitech International S.A., together with its consolidated subsidiaries ("Logitech" or the "Company"), designs software-enabled hardware solutions that help businesses thrive and bring people together when working, creating, gaming and streaming. As a point of connection between people and the digital world, the Company's mission is to extend human potential in work and play, in a way that is good for people and the planet.
  (was, 2024-10-24, similarity 0.881):
[0001032975-24-000075:note_history:7]
Logitech International S.A, together with its consolidated subsidiaries ("Logitech" or the "Company"), designs software-enabled hardware solutions that help businesses thrive and bring people together when working, creating, gaming and streaming. As a point of connection between people and the digital world, the Company's mission is to

- changed (2025-01-29):
[0001032975-25-000008:note_history:8]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and nine months ended December 31, 2024 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2025, or any future periods.
  (was, 2024-10-24, similarity 0.9623):
[0001032975-24-000075:note_history:8]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and six months ended September 30, 2024 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2025, or any future periods.

- changed (2025-01-29):
[0001032975-25-000008:note_history:9]
There have been no material changes in the Company’s significant accounting policies during the three and nine months ended December 31, 2024 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2024.
  (was, 2024-10-24, similarity 0.9208):
[0001032975-24-000075:note_history:9]
There have been no material changes in the Company’s significant accounting policies during the three and six months ended September 30, 2024 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2024.

- changed (2025-01-29):
[0001032975-25-000008:note_history:10]
The Company's business has continued to be impacted by macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, changes in fiscal policies, geopolitical conflicts, low economic growth in certain regions, and uncertainty in consumer and enterprise demand. In addition, the Company's business may be adversely impacted by the potential expansion of tariffs on goods imported into the U.S., as well as responsive or related policies enacted in other countries.
  (was, 2024-10-24, similarity 0.762):
[0001032975-24-000075:note_history:10]
The Company's business has continued to be impacted by macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, changes in fiscal policies, geopolitical conflicts, low economic growth in certain regions, and uncertainty in consumer and enterprise demand.

- changed (2025-01-29):
[0001032975-25-000008:note_history:11]
In November 2023, the Financial Accounting Standard Board ("FASB") issued Accounting Standards Update ("ASU") 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures. ASU 2023-07 improves reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses that are regularly provided to the chief operating decision maker. In addition, ASU 2023-07 requires that all existing annual disclosures about segment profit or loss must be provided on an interim basis and clarifies that single reportable segment entities are subject to the disclosure requirement under Topic 280 in its entirety. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 and interim periods within those fiscal years beginning after December 15, 2024. A public entity should apply ASU 2023-07 retrospectively to all prior periods presented in the financial statements. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2023-07 on its consolidated financial statements and related disclosures.
  (was, 2024-10-24, similarity 0.6688):
[0001032975-24-000075:note_history:11]
In November 2023, the Financial Accounting Standard Board ("FASB") issued Accounting Standards Update ("ASU") 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures. ASU 2023-07 improves reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses that are regularly provided to the chief operating decision maker. In addition, ASU 2023-07 requires that all existing annual disclosures about segment profit or loss must be provided on an interim basis and clarifies that single reportable segment entities are subject to the disclosure requirement under Topic 280 in its entirety. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 and interim periods within those fiscal years beginning after December 15, 2024. A public entity should apply ASU 2023-07 retrospectively to all prior periods presented in the financial statements. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2023-07 on its consolidated financial statements and related disclosures. 
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. ASU 2023-09 requires additional disclosures related to rate reconciliation, income taxes paid, and other disclosures. Under ASU 2023-09, for each annual period presented, public entities are required to (1) disclose specific categories in the tabular rate reconciliation and (2) provide additional information for reconciling items that meet a quantitative threshold. In addition, ASU 2023-09 requires all reporting entities to disclose on an annual basis the amount of income taxes paid disaggregated by federal, state, and foreign taxes as well as the amount of income taxes paid by individual jurisdiction. ASU 2023-09 is effective for public business entities for annual periods beginning after December 15, 2024 and can be applied on a prospective basis with an option to apply the standard retrospectively. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2023-09 on its consolidated financial statements and related disclosures.

- added (2025-01-29):
[0001032975-25-000008:note_history:12]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. ASU 2023-09 requires additional disclosures related to rate reconciliation, income taxes paid, and other disclosures. Under ASU 2023-09, for each annual period presented, public entities are required to (1) disclose specific categories in the tabular rate reconciliation and (2) provide additional information for reconciling items that meet a quantitative threshold. In addition, ASU 2023-09 requires all reporting entities to disclose on an annual basis the amount of income taxes paid disaggregated by federal, state, and foreign taxes as well as the amount of income taxes paid by individual jurisdiction. ASU 2023-09 is effective for public business entities for annual periods beginning after December 15, 2024 and can be applied on a prospective basis with an option to apply the standard retrospectively. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2023-09 on its consolidated financial statements and related disclosures.

- added (2025-01-29):
[0001032975-25-000008:note_history:13]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses. ASU 2024-03 requires all public entities to disclose in the notes to the financial statements the amounts of purchases of inventory, employee compensation, depreciation, and intangible asset amortization included in each expense caption of the income statement. ASU 2024-03 is effective for fiscal years beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027. ASU 2024-03 can be applied either prospectively or retrospectively. Early adoption is permitted. The Company is currently evaluating the impact of ASU 2024-03 on its consolidated financial statements and related disclosures.

- removed (2025-01-29):
[0001032975-24-000075:note_history:14]
extend human potential in work and play, in a way that is good for people and the planet.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-01-29):
[0001032975-25-000008:note_history:15]
The Company had several uncommitted, unsecured bank lines of credit and letters of credit aggregating $171.3 million and $172.5 million as of December 31, 2024 and March 31, 2024, respectively. There are no financial covenants under the lines of credit with which the Company must comply. There was no borrowing outstanding under the lines of credit as of December 31, 2024 or March 31, 2024. As of December 31, 2024 and March 31, 2024, the Company had outstanding bank guarantees of $27.7 million and $14.3 million, respectively.
  (was, 2024-10-24, similarity 0.9185):
[0001032975-24-000075:note_history:15]
The Company had several uncommitted, unsecured bank lines of credit and letters of credit aggregating $178.7 million and $172.5 million as of September 30, 2024 and March 31, 2024, respectively. There are no financial covenants under the lines of credit with which the Company must comply. There was no borrowing outstanding under the lines of credit as of September 30, 2024 or March 31, 2024. As of September 30, 2024 and March 31, 2024, the Company had outstanding bank guarantees of $29.5 million and $14.3 million, respectively.

- added (2025-01-29):
[0001032975-25-000008:note_history:16]
On January 27, 2025, the Company entered into an unsecured revolving credit facility with a syndicate of banks (the "Credit Agreement"). The Credit Agreement provides a revolving line of credit of up to $750 million to the Company including the issuance of letters of credit of up to $100 million. The Credit Agreement terminates on January 27, 2030 unless extended in accordance with its terms. The Credit Agreement contains (1) an increase option allowing the Company to secure up to $250 million of additional commitments and (2) an extension option to extend the term by one-year which may be exercised no more than two times, subject to certain requirements. Loans under the Credit Agreement are available in U.S. Dollars, Euro, Sterling, Yen, Swiss Francs, Canadian Dollars, Australian Dollars and any other currency agreed to by each lender. Proceeds of loans made under the Credit Agreement may be used for general corporate purposes.

- added (2025-01-29):
[0001032975-25-000008:note_history:17]
The Credit Agreement contains a maximum net debt to adjusted EBITDA ratio, compliance with which is a condition to the Company's ability to borrow. Borrowings under the Credit Agreement will bear interest at a rate determined by reference to benchmark rates plus an applicable spread (ranging from 0% to 1.5%) based on the Company's net leverage ratio or credit rating at the time of the borrowing. Undrawn balances available under the Credit Agreement are subject to commitment fees at the applicable rate determined by reference to the Company's net leverage ratio or credit rating. There has been no borrowing outstanding under the Credit Agreement as of January 29, 2025.
