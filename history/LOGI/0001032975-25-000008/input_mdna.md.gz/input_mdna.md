# LOGI MD&A — 0001032975-25-000008


## mdna

[0001032975-25-000008:mdna:1]
[same as prior period, unchanged from 0001032975-24-000075:mdna:1]

[0001032975-25-000008:mdna:2]
[same as prior period, unchanged from 0001032975-24-000075:mdna:2]

[0001032975-25-000008:mdna:3]
[same as prior period, unchanged from 0001032975-24-000075:mdna:3]

[0001032975-25-000008:mdna:4]
[same as prior period, unchanged from 0001032975-24-000075:mdna:4]

[0001032975-25-000008:mdna:5]
[same as prior period, unchanged from 0001032975-24-000075:mdna:5]

[0001032975-25-000008:mdna:6]
[same as prior period, unchanged from 0001032975-24-000075:mdna:6]

[0001032975-25-000008:mdna:7]
[same as prior period, unchanged from 0001032975-24-000075:mdna:7]

[0001032975-25-000008:mdna:8]
[same as prior period, unchanged from 0001032975-24-000075:mdna:8]

[0001032975-25-000008:mdna:9]
[same as prior period, unchanged from 0001032975-24-000075:mdna:9]

[0001032975-25-000008:mdna:10]
•Our expectations regarding our potential indemnification obligations, and the outcome of pending or future legal proceedings and tax audits;

[0001032975-25-000008:mdna:11]
[same as prior period, unchanged from 0001032975-24-000075:mdna:11]

[0001032975-25-000008:mdna:12]
[same as prior period, unchanged from 0001032975-24-000075:mdna:12]

[0001032975-25-000008:mdna:13]
[same as prior period, unchanged from 0001032975-24-000075:mdna:13]

[0001032975-25-000008:mdna:14]
[same as prior period, unchanged from 0001032975-24-000075:mdna:14]

[0001032975-25-000008:mdna:15]
•The sufficiency of our cash and cash equivalents, cash generated from operations, and available borrowings under our Credit Agreement and bank lines of credit to fund capital expenditures and working capital needs, and our ability to comply with our obligations under such debt agreements; and

[0001032975-25-000008:mdna:16]
[same as prior period, unchanged from 0001032975-24-000075:mdna:16]

[0001032975-25-000008:mdna:17]
[same as prior period, unchanged from 0001032975-24-000075:mdna:17]

[0001032975-25-000008:mdna:18]
[same as prior period, unchanged from 0001032975-24-000075:mdna:18]

[0001032975-25-000008:mdna:19]
[same as prior period, unchanged from 0001032975-24-000075:mdna:19]

[0001032975-25-000008:mdna:20]
[same as prior period, unchanged from 0001032975-24-000075:mdna:20]

[0001032975-25-000008:mdna:21]
[same as prior period, unchanged from 0001032975-24-000075:mdna:21]

[0001032975-25-000008:mdna:22]
[same as prior period, unchanged from 0001032975-24-000075:mdna:22]

[0001032975-25-000008:mdna:23]
[same as prior period, unchanged from 0001032975-24-000075:mdna:23]

[0001032975-25-000008:mdna:24]
Our business has continued to be impacted by macroeconomic and geopolitical conditions. These conditions include inflation, interest rate and foreign currency fluctuations, changes in fiscal policies, geopolitical conflicts, low economic growth in certain regions, and uncertainty in consumer and enterprise demand. In addition, our business may be adversely impacted by the potential expansion of tariffs on goods imported into the U.S., as well as responsive or related policies enacted in other countries.

[0001032975-25-000008:mdna:25]
[same as prior period, unchanged from 0001032975-24-000075:mdna:25]

[0001032975-25-000008:mdna:26]
[same as prior period, unchanged from 0001032975-24-000075:mdna:26]

[0001032975-25-000008:mdna:27]
[same as prior period, unchanged from 0001032975-24-000075:mdna:27]

[0001032975-25-000008:mdna:28]
[same as prior period, unchanged from 0001032975-24-000075:mdna:28]

[0001032975-25-000008:mdna:29]
[same as prior period, unchanged from 0001032975-24-000075:mdna:29]

[0001032975-25-000008:mdna:30]
[same as prior period, unchanged from 0001032975-24-000075:mdna:30]

[0001032975-25-000008:mdna:31]
[same as prior period, unchanged from 0001032975-24-000075:mdna:31]

[0001032975-25-000008:mdna:32]
[same as prior period, unchanged from 0001032975-24-000075:mdna:32]

[0001032975-25-000008:mdna:33]
[same as prior period, unchanged from 0001032975-24-000075:mdna:33]

[0001032975-25-000008:mdna:34]
While we believe we will further benefit from these secular trends, we have experienced and will continue to experience challenges that impact our business and financial results. These challenges include (i) the current macroeconomic environment, including interest rate fluctuations, inflation, foreign exchange movements, changes in fiscal policies and low economic growth in certain regions, (ii) the uncertainty with overall consumer and enterprise demand, (iii) the uncertainty with enterprise strategy for office space utilization and related timing of enterprise

[0001032975-25-000008:mdna:35]
investments in infrastructure and technology, and (iv) the timing of further development of our B2B go-to-market capabilities.

[0001032975-25-000008:mdna:36]
[same as prior period, unchanged from 0001032975-24-000075:mdna:36]

[0001032975-25-000008:mdna:37]
[same as prior period, unchanged from 0001032975-24-000075:mdna:37]

[0001032975-25-000008:mdna:38]
[same as prior period, unchanged from 0001032975-24-000075:mdna:38]

[0001032975-25-000008:mdna:39]
[same as prior period, unchanged from 0001032975-24-000075:mdna:39]

[0001032975-25-000008:mdna:40]
[same as prior period, unchanged from 0001032975-24-000075:mdna:40]

[0001032975-25-000008:mdna:41]
Our sales for the three months ended December 31, 2024 increased 7%, compared to the three months ended December 31, 2023, primarily due to an increase in sales in Gaming and Tablet Accessories. Our sales for the nine months ended December 31, 2024 increased 8%, compared to the nine months ended December 31, 2023, primarily due to an increase in sales in Gaming, Keyboards & Combos, and Tablet Accessories. The sales in the three- and nine- month periods benefited from improved demand.

[0001032975-25-000008:mdna:42]
Sales for the three months ended December 31, 2024 increased 11%, 9%, and 3% in the Asia Pacific, EMEA, and Americas regions, respectively, compared to the three months ended December 31, 2023. Sales for the nine months ended December 31, 2024 increased 13%, 7%, and 5% in the EMEA, Asia Pacific, and Americas regions, respectively, compared to the nine months ended December 31, 2023.

[0001032975-25-000008:mdna:43]
Gross margin was 42.9% and 43.1% for the three and nine months ended December 31, 2024, respectively, and increased by 90 and 230 basis points, respectively, compared to the three and nine months ended December 31, 2023, primarily driven by lower product costs, partially offset by higher promotional spending.

[0001032975-25-000008:mdna:44]
Operating expenses for the three months ended December 31, 2024 were $339.9 million, or 25.4% of sales, compared to $304.7 million, or 24.3% of sales, for the three months ended December 31, 2023. Operating expenses for the nine months ended December 31, 2024 were $977.8 million, or 27.6% of sales, compared to $883.9 million, or 26.9% of sales, for the nine months ended December 31, 2023. The increase in operating expense was primarily driven by an increase in marketing and advertising spend.

[0001032975-25-000008:mdna:45]
We had an income tax provision of $45.1 million and an income tax benefit of $9.6 million for the three months ended December 31, 2024 and December 31, 2023, respectively. We had an income tax provision of $101.2 million and $33.3 million for the nine months ended December 31, 2024 and December 31, 2023, respectively. The change in the income tax provision for the three and nine months ended December 31, 2024, compared to the three and nine months ended December 31, 2023, respectively, was primarily due to the mix of income and losses in the various tax jurisdictions in which we operate and unrecognized tax benefits due to uncertain tax positions compared with the discrete tax benefits recognized in the prior period to remeasure the tax basis of goodwill under the Swiss Federal Act on Tax Reform and AHV Financing ("TRAF"), remeasurement of our Swiss deferred tax assets due to a change in tax rate, and Foreign Derived Intangible Income ("FDII") incentive provided by the Tax Cuts and Jobs Act.

[0001032975-25-000008:mdna:46]
Net income for the three and nine months ended December 31, 2024 was $200.1 million and $487.5 million, respectively, compared to $244.7 million and $444.5 million, for the three and nine months ended December 31, 2023, respectively.

[0001032975-25-000008:mdna:47]
[same as prior period, unchanged from 0001032975-24-000075:mdna:47]

[0001032975-25-000008:mdna:48]
The preparation of financial statements and related disclosures in conformity with U.S. GAAP requires us to make assumptions, judgments, and estimates that affect reported amounts of assets, liabilities, sales and expenses, and the disclosure of contingent assets and liabilities.

[0001032975-25-000008:mdna:49]
[same as prior period, unchanged from 0001032975-24-000075:mdna:49]

[0001032975-25-000008:mdna:50]
We base our assumptions, judgments, and estimates on historical experience and various other factors that we believe to be reasonable under the circumstances. Actual results could differ materially from these estimates under different assumptions or conditions. On a regular basis, we evaluate our assumptions, judgments and estimates. We also discuss our critical accounting policies and estimates with the Audit Committee of the Board of Directors.

[0001032975-25-000008:mdna:51]
[same as prior period, unchanged from 0001032975-24-000075:mdna:51]

[0001032975-25-000008:mdna:52]
There have been no material changes in our critical accounting estimates during the nine months ended December 31, 2024 compared with the critical accounting estimates disclosed in Management's Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended March 31, 2024.

[0001032975-25-000008:mdna:53]
[same as prior period, unchanged from 0001032975-24-000075:mdna:53]

[0001032975-25-000008:mdna:54]
[same as prior period, unchanged from 0001032975-24-000075:mdna:54]

[0001032975-25-000008:mdna:55]
[same as prior period, unchanged from 0001032975-24-000075:mdna:55]

[0001032975-25-000008:mdna:56]
[same as prior period, unchanged from 0001032975-24-000075:mdna:56]

[0001032975-25-000008:mdna:57]
[same as prior period, unchanged from 0001032975-24-000075:mdna:57]

[0001032975-25-000008:mdna:58]
[same as prior period, unchanged from 0001032975-24-000075:mdna:58]

[0001032975-25-000008:mdna:59]
[same as prior period, unchanged from 0001032975-24-000075:mdna:59]

[0001032975-25-000008:mdna:60]
[same as prior period, unchanged from 0001032975-24-000075:mdna:60]

[0001032975-25-000008:mdna:61]
[same as prior period, unchanged from 0001032975-24-000075:mdna:61]

[0001032975-25-000008:mdna:62]
Our sales for the three months ended December 31, 2024 increased 7%, compared to the three months ended December 31, 2023, primarily due to an increase in sales in Gaming and Tablet Accessories. Our sales for the nine months ended December 31, 2024 increased 8%, compared to the nine months ended December 31, 2023, primarily due to an increase in sales in Gaming, Keyboards & Combos, and Tablet Accessories. The sales in the three- and nine-month periods benefited from improved demand. If currency exchange rates had been constant in the three and nine months ended December 31, 2024 and 2023, our sales growth rates in constant currency would have been 6% and 8%, respectively.

[0001032975-25-000008:mdna:63]
[same as prior period, unchanged from 0001032975-24-000075:mdna:63]

[0001032975-25-000008:mdna:64]
Although our financial results are reported in U.S. Dollars, a portion of our sales was generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Australian Dollar, Canadian Dollar, Japanese Yen, Pound Sterling and New Taiwan Dollar. During the three months ended December 31, 2024, approximately 52% of our sales were denominated in currencies other than the U.S. Dollar.

[0001032975-25-000008:mdna:65]
[same as prior period, unchanged from 0001032975-24-000075:mdna:65]

[0001032975-25-000008:mdna:66]
The following table presents the change in sales by region for the three and nine months ended December 31, 2024, compared with the three and nine months ended December 31, 2023:

[0001032975-25-000008:mdna:67]
|  |  | Sales Growth Rate |  | Constant DollarSales Growth Rate |
|  |  | Three Months Ended December 31, 2024 |  | Nine Months Ended December 31, 2024 |  | Three Months Ended December 31, 2024 |  | Nine Months Ended December 31, 2024 |
| Americas |  | 3 | % |  | 5 | % |  | 4 | % |  | 6 | % |
| EMEA |  | 9 | % |  | 13 | % |  | 6 | % |  | 12 | % |
| Asia Pacific |  | 11 | % |  | 7 | % |  | 9 | % |  | 7 | % |

[0001032975-25-000008:mdna:68]
[same as prior period, unchanged from 0001032975-24-000075:mdna:68]

[0001032975-25-000008:mdna:69]
The increase in sales in the Americas region for the three-month period presented above was primarily driven by an increase in sales for Gaming and Video Collaboration, partially offset by a decrease in sales for Keyboards & Combos. The increase in sales in the Americas region for the nine-month period presented above was primarily driven by an increase in sales for Gaming, Tablet Accessories, and Keyboards & Combos.

[0001032975-25-000008:mdna:70]
[same as prior period, unchanged from 0001032975-24-000075:mdna:70]

[0001032975-25-000008:mdna:71]
The increase in sales in the EMEA region for the three-month period presented above was primarily driven by an increase in sales for Gaming and Keyboards & Combos. The increase in sales in the EMEA region for the nine-month period presented above was primarily driven by an increase in sales for Gaming, Keyboards & Combos, and Pointing Devices.

[0001032975-25-000008:mdna:72]
[same as prior period, unchanged from 0001032975-24-000075:mdna:72]

[0001032975-25-000008:mdna:73]
The increase in sales in the Asia Pacific region for the three- and nine-month periods presented above was primarily driven by an increase in sales for Gaming and Tablet Accessories.

[0001032975-25-000008:mdna:74]
[same as prior period, unchanged from 0001032975-24-000075:mdna:74]

[0001032975-25-000008:mdna:75]
Sales by product category for the three and nine months ended December 31, 2024 and 2023 were as follows (dollars in thousands):

[0001032975-25-000008:mdna:76]
|  |  | Three months ended December 31, |  | Nine months ended December 31, |
|  |  | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
| Gaming (1) |  | $ | 466,715 |  |  | $ | 409,043 |  |  | 14% |  | $ | 1,076,660 |  |  | $ | 957,576 |  |  | 12% |
| Keyboards & Combos |  | 236,748 |  |  | 229,432 |  |  | 3 |  | 662,017 |  |  | 605,201 |  |  | 9 |
| Pointing Devices |  | 217,045 |  |  | 206,180 |  |  | 5 |  | 602,927 |  |  | 572,310 |  |  | 5 |
| Video Collaboration |  | 176,053 |  |  | 169,522 |  |  | 4 |  | 482,755 |  |  | 461,257 |  |  | 5 |
| Webcams |  | 84,419 |  |  | 85,851 |  |  | (2) |  | 237,572 |  |  | 249,273 |  |  | (5) |
| Tablet Accessories |  | 77,433 |  |  | 64,239 |  |  | 21 |  | 241,586 |  |  | 198,252 |  |  | 22 |
| Headsets |  | 45,886 |  |  | 41,762 |  |  | 10 |  | 137,038 |  |  | 123,023 |  |  | 11 |
| Other (2) |  | 35,995 |  |  | 49,444 |  |  | (27) |  | 103,990 |  |  | 120,088 |  |  | (13) |
| Total Sales |  | $ | 1,340,294 |  |  | $ | 1,255,473 |  |  | 7% |  | $ | 3,544,545 |  |  | $ | 3,286,980 |  |  | 8% |

[0001032975-25-000008:mdna:77]
[same as prior period, unchanged from 0001032975-24-000075:mdna:77]

[0001032975-25-000008:mdna:78]
[same as prior period, unchanged from 0001032975-24-000075:mdna:78]

[0001032975-25-000008:mdna:79]
[same as prior period, unchanged from 0001032975-24-000075:mdna:79]

[0001032975-25-000008:mdna:80]
[same as prior period, unchanged from 0001032975-24-000075:mdna:80]

[0001032975-25-000008:mdna:81]
Sales of Gaming increased 14% and 12% for the three and nine months ended December 31, 2024, respectively, compared to the three and nine months ended December 31, 2023, primarily driven by an increase in sales of gaming mice and gaming steering wheels.

[0001032975-25-000008:mdna:82]
[same as prior period, unchanged from 0001032975-24-000075:mdna:82]

[0001032975-25-000008:mdna:83]
[same as prior period, unchanged from 0001032975-24-000075:mdna:83]

[0001032975-25-000008:mdna:84]
Sales of Keyboards & Combos increased 3% and 9% for the three and nine months ended December 31, 2024, respectively, compared to the three and nine months ended December 31, 2023, primarily driven by an increase in sales of cordless combo products.

[0001032975-25-000008:mdna:85]
[same as prior period, unchanged from 0001032975-24-000075:mdna:85]

[0001032975-25-000008:mdna:86]
[same as prior period, unchanged from 0001032975-24-000075:mdna:86]

[0001032975-25-000008:mdna:87]
Sales of Pointing Devices increased 5% for each of the three and nine months ended December 31, 2024, compared to the three and nine months ended December 31, 2023, primarily driven by an increase in sales of cordless mice.

[0001032975-25-000008:mdna:88]
[same as prior period, unchanged from 0001032975-24-000075:mdna:88]

[0001032975-25-000008:mdna:89]
[same as prior period, unchanged from 0001032975-24-000075:mdna:89]

[0001032975-25-000008:mdna:90]
Sales of Video Collaboration increased 4% and 5% for the three and nine months ended December 31, 2024, respectively, compared to the three and nine months ended December 31, 2023, primarily due to an increase in sales of conference room cameras as well as an increase in services revenue.

[0001032975-25-000008:mdna:91]
[same as prior period, unchanged from 0001032975-24-000075:mdna:91]

[0001032975-25-000008:mdna:92]
[same as prior period, unchanged from 0001032975-24-000075:mdna:92]

[0001032975-25-000008:mdna:93]
Sales of Webcams decreased 2% and 5% for the three and nine months ended December 31, 2024, respectively, compared to the three and nine months ended December 31, 2023, primarily driven by a decrease in sales of our VC webcams, partially offset by an increase of sales of our PC-based webcams.

[0001032975-25-000008:mdna:94]
[same as prior period, unchanged from 0001032975-24-000075:mdna:94]

[0001032975-25-000008:mdna:95]
[same as prior period, unchanged from 0001032975-24-000075:mdna:95]

[0001032975-25-000008:mdna:96]
Sales of Tablet Accessories increased 21% and 22% for the three and nine months ended December 31, 2024, respectively, compared to the three and nine months ended December 31, 2023, primarily driven by an increase in sales of Rugged Combo 4 and Rugged Combo 4 Touch as well as sales from our Combo Touch products for the new releases of iPad Air and iPad Pro that were launched in fiscal year 2025. Sales of Tablet Accessories for the three and nine months ended December 31, 2024, compared to the three and nine months ended December 31, 2023, benefited from strong demand from the education sector.

[0001032975-25-000008:mdna:97]
[same as prior period, unchanged from 0001032975-24-000075:mdna:97]

[0001032975-25-000008:mdna:98]
[same as prior period, unchanged from 0001032975-24-000075:mdna:98]

[0001032975-25-000008:mdna:99]
Sales of Headsets increased 10% and 11% for the three and nine months ended December 31, 2024, respectively, compared to the three and nine months ended December 31, 2023, primarily driven by an increase in sales of PC headsets and VC headsets.

[0001032975-25-000008:mdna:100]
[same as prior period, unchanged from 0001032975-24-000075:mdna:100]

[0001032975-25-000008:mdna:101]
[same as prior period, unchanged from 0001032975-24-000075:mdna:101]

[0001032975-25-000008:mdna:102]
Sales in Other category decreased 27% and 13% for the three and nine months ended December 31, 2024, respectively, compared to the three and nine months ended December 31, 2023, primarily driven by a decline in sales of mobile speakers.

[0001032975-25-000008:mdna:103]
[same as prior period, unchanged from 0001032975-24-000075:mdna:103]

[0001032975-25-000008:mdna:104]
Gross profit for the three and nine months ended December 31, 2024 and 2023 was as follows (dollars in thousands):

[0001032975-25-000008:mdna:105]
|  |  | Three months ended December 31, |  | Nine months ended December 31, |
|  |  | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
| Net sales |  | $ | 1,340,294 |  | $ | 1,255,473 |  | 7 | % |  | $ | 3,544,545 |  | $ | 3,286,980 |  | 8 | % |
| Gross profit |  | $ | 574,441 |  | $ | 526,780 |  | 9 | % |  | $ | 1,526,790 |  | $ | 1,341,044 |  | 14 | % |
| Gross margin |  | 42.9 | % |  | 42.0 | % |  |  |  | 43.1 | % |  | 40.8 | % |  |  |

[0001032975-25-000008:mdna:106]
[same as prior period, unchanged from 0001032975-24-000075:mdna:106]

[0001032975-25-000008:mdna:107]
Gross margin was 42.9% and 43.1% for the three and nine months ended December 31, 2024, respectively, and increased by 90 and 230 basis points, respectively, compared to the three and nine months ended December 31, 2023, primarily driven by lower product costs, partially offset by higher promotional spending.

[0001032975-25-000008:mdna:108]
[same as prior period, unchanged from 0001032975-24-000075:mdna:108]

[0001032975-25-000008:mdna:109]
Operating expenses for the three and nine months ended December 31, 2024 and 2023 were as follows (dollars in thousands):

[0001032975-25-000008:mdna:110]
|  |  | Three months ended December 31, |  | Nine months ended December 31, |  |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  |
| Marketing and selling |  | $ | 217,048 |  |  | $ | 189,175 |  |  | $ | 615,816 |  |  | $ | 544,716 |  |  |
| % of sales |  | 16.2 | % |  | 15.1 | % |  | 17.4 | % |  | 16.6 | % |  |
| Research and development |  | 77,973 |  |  | 72,704 |  |  | 229,485 |  |  | 211,822 |  |  |
| % of sales |  | 5.8 | % |  | 5.8 | % |  | 6.5 | % |  | 6.4 | % |  |
| General and administrative |  | 42,117 |  |  | 39,711 |  |  | 123,748 |  |  | 116,546 |  |  |
| % of sales |  | 3.2 | % |  | 3.2 | % |  | 3.5 | % |  | 3.5 | % |  |
| Amortization of intangible assets and acquisition-related costs |  | 2,637 |  |  | 2,276 |  |  | 8,065 |  |  | 8,279 |  |  |
| % of sales |  | 0.2 | % |  | 0.2 | % |  | 0.2 | % |  | 0.3 | % |  |
| Restructuring charges, net |  | 110 |  |  | 839 |  |  | 725 |  |  | 2,562 |  |  |
| % of sales |  | — | % |  | 0.1 | % |  | — | % |  | 0.1 | % |  |
| Total operating expenses |  | $ | 339,885 |  |  | $ | 304,705 |  |  | $ | 977,839 |  |  | $ | 883,925 |  |  |
| % of sales |  | 25.4 | % |  | 24.3 | % |  | 27.6 | % |  | 26.9 | % |  |

[0001032975-25-000008:mdna:111]
The increase in total operating expenses during the three and nine months ended December 31, 2024, compared to the three and nine months ended December 31, 2023, was primarily driven by an increase in marketing and selling expenses.

[0001032975-25-000008:mdna:112]
[same as prior period, unchanged from 0001032975-24-000075:mdna:112]

[0001032975-25-000008:mdna:113]
[same as prior period, unchanged from 0001032975-24-000075:mdna:113]

[0001032975-25-000008:mdna:114]
During the three and nine months ended December 31, 2024, marketing and selling expenses increased $27.9 million and $71.1 million, respectively, compared to the three and nine months ended December 31, 2023, primarily driven by increased investment in marketing and advertising and a provision for credit loss on accounts receivable recorded in the third quarter of fiscal year 2025.

[0001032975-25-000008:mdna:115]
[same as prior period, unchanged from 0001032975-24-000075:mdna:115]

[0001032975-25-000008:mdna:116]
[same as prior period, unchanged from 0001032975-24-000075:mdna:116]

[0001032975-25-000008:mdna:117]
During the three and nine months ended December 31, 2024, research and development expenses increased $5.3 million and $17.7 million, respectively, compared to the three and nine months ended December 31, 2023, primarily driven by higher personnel-related costs and third party costs to support our increased investment in product innovation.

[0001032975-25-000008:mdna:118]
[same as prior period, unchanged from 0001032975-24-000075:mdna:118]

[0001032975-25-000008:mdna:119]
[same as prior period, unchanged from 0001032975-24-000075:mdna:119]

[0001032975-25-000008:mdna:120]
During the three and nine months ended December 31, 2024, general and administrative expenses increased $2.4 million and $7.2 million, respectively, compared to the three and nine months ended December 31, 2023, primarily driven by higher personnel-related costs to support business growth.

[0001032975-25-000008:mdna:121]
[same as prior period, unchanged from 0001032975-24-000075:mdna:121]

[0001032975-25-000008:mdna:122]
[same as prior period, unchanged from 0001032975-24-000075:mdna:122]

[0001032975-25-000008:mdna:123]
During the three and nine months ended December 31, 2024, amortization of intangible assets and acquisition-related costs remained flat, compared to the three and nine months ended December 31, 2023.

[0001032975-25-000008:mdna:124]
Restructuring Charges, Net

[0001032975-25-000008:mdna:125]
The restructuring charges, net for the three and nine months ended December 31, 2024 and 2023, were related to costs incurred as a result of our restructuring plan initiated during fiscal year 2023. These restructuring activities were substantially completed during fiscal year 2024.

[0001032975-25-000008:mdna:126]
[same as prior period, unchanged from 0001032975-24-000075:mdna:126]

[0001032975-25-000008:mdna:127]
Interest income for the three and nine months ended December 31, 2024 and 2023 was as follows (in thousands):

[0001032975-25-000008:mdna:128]
|  |  | Three months ended December 31, |  | Nine months ended December 31, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Interest Income |  | $ | 12,176 |  |  | $ | 12,826 |  |  | $ | 42,603 |  |  | $ | 34,508 |  |

[0001032975-25-000008:mdna:129]
We invest in highly liquid instruments with an original maturity of three months or less at the date of purchase, which are classified as cash equivalents. During the three months ended December 31, 2024, interest income decreased $0.7 million, compared to the three months ended December 31, 2023, primarily driven by a decrease in interest rates, partially offset by an increase in the cash equivalents balance. During the nine months ended December 31, 2024, interest income increased $8.1 million, compared to the nine months ended December 31, 2023, primarily driven by an increase in the cash equivalents balance and an increase in average interest rates.

[0001032975-25-000008:mdna:130]
[same as prior period, unchanged from 0001032975-24-000075:mdna:130]

[0001032975-25-000008:mdna:131]
Other income (expense), net for the three and nine months ended December 31, 2024 and 2023 was as follows (in thousands):

[0001032975-25-000008:mdna:132]
|  |  | Three months ended December 31, |  | Nine months ended December 31, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Investment gain related to the deferred compensation plan |  | $ | 571 |  |  | $ | 2,061 |  |  | $ | 2,631 |  |  | $ | 2,761 |  |
| Currency exchange loss, net |  | (3,282) |  |  | (1,850) |  |  | (7,073) |  |  | (6,648) |  |
| Loss on investments, net |  | (119) |  |  | (604) |  |  | (1,718) |  |  | (12,213) |  |
| Non-service cost net pension income and other |  | 1,306 |  |  | 582 |  |  | 3,271 |  |  | 2,273 |  |
| Total |  | $ | (1,524) |  |  | $ | 189 |  |  | $ | (2,889) |  |  | $ | (13,827) |  |

[0001032975-25-000008:mdna:133]
Investment gain related to the deferred compensation plan represents earnings, gains, and losses on marketable securities related to a deferred compensation plan offered by one of our subsidiaries. The decrease in investment gain for three and nine months ended December 31, 2024, compared to the three and nine months ended December 31, 2023, primarily relates to the change in market performance of the underlying securities.

[0001032975-25-000008:mdna:134]
Currency exchange loss, net, relates to balances denominated in currencies other than the functional currency in our subsidiaries, as well as to the sale of currencies, and gains or losses recognized on currency exchange forward contracts. We do not speculate in currency positions, but we are alert to opportunities to maximize currency exchange gains and minimize currency exchange losses. The loss for the three months ended December 31, 2024 was primarily due to fluctuations in currency exchange rates of the Australian Dollar, Japanese Yen, and Brazilian Real against the U.S. Dollar. The loss for the three months ended December 31, 2023 was primarily due to fluctuations in the currency exchange rates of the Chinese Renminbi and Swedish Krona against the U.S. Dollar.

[0001032975-25-000008:mdna:135]
The loss for the nine months ended December 31, 2024 was primarily due to fluctuations in currency exchange rates of the Chinese Renminbi, Mexican Peso, and Brazilian Real against the U.S. Dollar. The loss for the nine months ended December 31, 2023 was primarily due to fluctuations in the currency exchange rates of the Chinese Renminbi, Brazilian Real, and Australian Dollar against the U.S. Dollar.

[0001032975-25-000008:mdna:136]
Loss on investments, net, includes unrealized gain (loss) from the change in fair value of investments, gain (loss) on equity-method investments and impairment of investments during the periods presented, as applicable. The loss on investments, net, for the three and nine months ended December 31, 2024 and the three months ended December 31, 2023 were not material. The loss on investments, net, for the nine months ended December 31, 2023 was primarily due to an impairment loss, as a result of the write-off of a note receivable which has been deemed no longer recoverable. This note receivable was previously obtained in conjunction with an exchange transaction related to our investment in a privately held company. See Note 6 to our condensed consolidated financial statements for more information.

[0001032975-25-000008:mdna:137]
[same as prior period, unchanged from 0001032975-24-000075:mdna:137]

[0001032975-25-000008:mdna:138]
The provision for income taxes and effective income tax rates for the three and nine months ended December 31, 2024 and 2023 were as follows (dollars in thousands):

[0001032975-25-000008:mdna:139]
|  |  | Three months ended December 31, |  | Nine months ended December 31, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Provision for (benefit from) income taxes |  | $ | 45,061 |  |  | $ | (9,594) |  |  | $ | 101,202 |  |  | $ | 33,272 |  |
| Effective income tax rate |  | 18.4 | % |  | (4.1) | % |  | 17.2 | % |  | 7.0 | % |

[0001032975-25-000008:mdna:140]
The change in the effective income tax rate for the three and nine months ended December 31, 2024, compared with the three and nine months ended December 31, 2023, was primarily due to the change in the mix of income and losses in the various tax jurisdictions in which we operate and unrecognized tax benefits due to uncertain tax positions compared with the discrete tax benefits recognized in the prior period for remeasurement of the tax basis of goodwill under TRAF, remeasurement of our Swiss deferred tax assets due to a change in tax rate, and FDII incentive provided by the Tax Cuts and Jobs Act.

[0001032975-25-000008:mdna:141]
The canton of Vaud completed the legislative process to enact TRAF, a reform to better align the Swiss tax system to international tax standards, on March 10, 2020 to take effect as of January 1, 2020. In March 2020, we increased the tax basis of goodwill, as a transition measure under TRAF, to be amortized over ten years beginning on January 1, 2020. During the three months ended December 31, 2023, we reached an agreement to remeasure the tax basis of goodwill under TRAF, which resulted in an income tax benefit of $25.1 million, net of assessment of uncertain tax positions. The remeasurement of the step-up will be amortized over the remaining ten-year amortization period.

[0001032975-25-000008:mdna:142]
On December 29, 2023, a change to the cantonal tax legislation was published. According to the law approved by the Vaud parliament, a progressive scale will be applicable for cantonal tax purposes resulting in an increase from the then current tax rate of 13.61% to 14.28% effective fiscal year 2025. The increase in tax rate resulted in a tax benefit of $5.1 million due to a remeasurement of our Swiss deferred tax assets in the fiscal quarter ended December 31, 2023.

[0001032975-25-000008:mdna:143]
The Tax Cuts and Jobs Act enacted Section 250, which provides for a deduction with respect to Global Intangible Low-Taxed Income ("GILTI") and FDII in the U.S. The application of this tax incentive is inherently complex. During the three months ended December 31, 2023, we analyzed the applicability of FDII and determined that this tax incentive applies to fiscal years 2021, 2022 and 2023. As a result, we realized a tax benefit of $17.9 million related to FDII. We have also concluded that any GILTI tax since the enactment of Tax Cuts and Jobs Act is immaterial.

[0001032975-25-000008:mdna:144]
The BEPS Project undertaken by the OECD recommended changes to numerous long-standing tax principles, including a proposal to reallocate profits among tax jurisdictions in which companies do business (“Pillar One”) and establishing a minimum tax on global income (“Pillar Two”). Some jurisdictions, including Switzerland, where we operate are implementing Pillar Two laws to effectuate a 15% minimum tax. The minimum tax effective beginning in fiscal year 2025 for the Company, is treated as a current cost and does not have a material impact on the

[0001032975-25-000008:mdna:145]
Company's effective tax rate. The OECD and participating countries continue to issue underlying rules and administrative guidance related to Pillar Two, and we continue to monitor the relevant developments.

[0001032975-25-000008:mdna:146]
We file Swiss and foreign tax returns. We received final tax assessments in Switzerland through fiscal year 2023. For other material foreign jurisdictions such as the United States, we are generally not subject to tax examinations for years prior to fiscal year 2020 and calendar year 2020. In the United States, the federal and state tax agencies have the authority to examine periods prior to fiscal year 2020, to the extent allowed by law, where tax attributes were generated, carried forward, and being utilized in subsequent years. We are under examination in foreign tax jurisdictions. If the examinations are resolved unfavorably, there is a possibility that they may have a material negative impact on our results of operations.

[0001032975-25-000008:mdna:147]
[same as prior period, unchanged from 0001032975-24-000075:mdna:143]

[0001032975-25-000008:mdna:148]
[same as prior period, unchanged from 0001032975-24-000075:mdna:144]

[0001032975-25-000008:mdna:149]
As of December 31, 2024, we had cash and cash equivalents of $1,502.8 million, compared with $1,520.8 million as of March 31, 2024. Our cash and cash equivalents consist of bank demand deposits, short-term time deposits, and U.S. Treasury securities, of which 72% is held in Switzerland and 11% is held in China (including Hong Kong). We do not expect to incur any material adverse tax impact except for what has already been recognized, or to be significantly inhibited by any country in which we do business, from the repatriation of funds to Switzerland, our country of domicile.

[0001032975-25-000008:mdna:150]
As of December 31, 2024, our working capital was $1,479.9 million, compared to $1,545.5 million as of March 31, 2024. The decrease was primarily driven by an increase in accounts payable and accrued and other current liabilities, and a decrease in cash and cash equivalents, partially offset by an increase in accounts receivable and inventories.

[0001032975-25-000008:mdna:151]
We had several uncommitted, unsecured bank lines of credit and letters of credit aggregating $171.3 million as of December 31, 2024. There are no financial covenants under these lines of credit with which we must comply. There was no borrowing outstanding under the lines of credit as of December 31, 2024. As of December 31, 2024, we had outstanding bank guarantees of $27.7 million.

[0001032975-25-000008:mdna:152]
On January 27, 2025, we entered into an unsecured revolving credit facility with a syndicate of banks ("the Credit Agreement"). The Credit Agreement provides a revolving line of credit of up to $750 million including the issuance of letters of credit of up to $100 million. The Credit Agreement terminates on January 27, 2030 unless extended in accordance with its terms. The Credit Agreement contains (1) an increase option allowing us to secure up to $250 million of additional commitments and (2) an extension option to extend the term by one-year which may be exercised no more than two times, subject to certain requirements. Loans under the Credit Agreement are available in U.S. Dollars, Euro, Sterling, Yen, Swiss Francs, Canadian Dollars, Australian Dollars and any other currency agreed to by each lender. Proceeds of loans made under the Credit Agreement may be used for general corporate purposes.

[0001032975-25-000008:mdna:153]
The Credit Agreement contains a maximum net debt to adjusted EBITDA ratio, compliance with which is a condition to our ability to borrow. Borrowings under the Credit Agreement will bear interest at a rate determined by reference to benchmark rates plus an applicable spread (ranging from 0% to 1.5%) based on our net leverage ratio or credit rating at the time of the borrowing. Undrawn balances available under the Credit Agreement are subject to commitment fees at the applicable rate determined by reference to our net leverage ratio or credit rating. There has been no borrowing outstanding under the Credit Agreement as of January 29, 2025.

[0001032975-25-000008:mdna:154]
The following tables present selected financial information and statistics as of and for the three months ended December 31, 2024 and 2023 (dollars in thousands):

[0001032975-25-000008:mdna:155]
|  |  | As of December 31, |  |
|  |  | 2024 |  | 2023 |  |
| Accounts receivable, net |  | $ | 648,230 |  |  | $ | 685,777 |  |  |
| Accounts payable |  | $ | 578,951 |  |  | $ | 527,988 |  |  |
| Inventories |  | $ | 483,569 |  |  | $ | 447,262 |  |  |

[0001032975-25-000008:mdna:156]
|  |  | Three months ended December 31, |  |
|  |  | 2024 |  | 2023 |  |
| Days sales in accounts receivable (“DSO”) (Days)(1) |  | 44 |  |  | 49 |  |  |
| Days accounts payable outstanding (“DPO”) (Days)(2) |  | 68 |  |  | 65 |  |  |
| Inventory turnover (“ITO”) (x)(3) |  | 6.3 |  |  | 6.5 |  |  |

[0001032975-25-000008:mdna:157]
[same as prior period, unchanged from 0001032975-24-000075:mdna:151]

[0001032975-25-000008:mdna:158]
[same as prior period, unchanged from 0001032975-24-000075:mdna:152]

[0001032975-25-000008:mdna:159]
[same as prior period, unchanged from 0001032975-24-000075:mdna:153]

[0001032975-25-000008:mdna:160]
DSO for the three months ended December 31, 2024 decreased by 5 days to 44 days, compared to 49 days for the three months ended December 31, 2023, primarily due to higher sales from improved demand as well as timing of sales within the quarter.

[0001032975-25-000008:mdna:161]
DPO for the three months ended December 31, 2024 increased by 3 days to 68 days, compared to 65 days for the three months ended December 31, 2023, primarily due to higher inventory purchases during the third quarter of fiscal year 2025 to align with demand.

[0001032975-25-000008:mdna:162]
ITO for the three months ended December 31, 2024 decreased by 0.2 to 6.3, compared to 6.5 for the three months ended December 31, 2023, primarily due to higher inventory balances as of December 31, 2024.

[0001032975-25-000008:mdna:163]
[same as prior period, unchanged from 0001032975-24-000075:mdna:157]

[0001032975-25-000008:mdna:164]
[same as prior period, unchanged from 0001032975-24-000075:mdna:158]

[0001032975-25-000008:mdna:165]
|  |  | Nine months ended December 31, |
|  |  | 2024 |  | 2023 |
| Net cash provided by operating activities |  | $ | 712,901 |  |  | $ | 906,011 |  |
| Net cash used in investing activities |  | (45,357) |  |  | (59,829) |  |
| Net cash used in financing activities |  | (676,099) |  |  | (578,475) |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (9,455) |  |  | (4,080) |  |
| Net increase (decrease) in cash and cash equivalents |  | $ | (18,010) |  |  | $ | 263,627 |  |

[0001032975-25-000008:mdna:166]
For the nine months ended December 31, 2024, net cash provided by operating activities was $712.9 million resulting from net income of $487.5 million, a favorable impact from adding back non-cash expenses totaling $156.0 million, and a favorable net change in operating assets and liabilities of $69.4 million. Non-cash adjustments were primarily related to share-based compensation expenses, depreciation and amortization, and deferred income taxes. The increase in accounts receivable, net, was primarily driven by higher sales as well as timing of sales within the quarter. The increases in inventories and accounts payable were due to higher inventory purchases to align with demand. The increase in accrued and other liabilities was primarily driven by higher income tax payable and higher performance-based compensation accrual due to strong business performance as well as higher deferred revenue due to an increase in services bookings.

[0001032975-25-000008:mdna:167]
For the nine months ended December 31, 2024, net cash used in investing activities was $45.4 million, primarily resulting from $43.3 million of purchases of property, plant, and equipment.

[0001032975-25-000008:mdna:168]
For the nine months ended December 31, 2024, net cash used in financing activities was $676.1 million, primarily resulting from payment for repurchases of our registered shares of $463.3 million and payment of cash dividends of $207.9 million.

[0001032975-25-000008:mdna:169]
For the nine months ended December 31, 2024, the effect of exchange rate changes on cash and cash equivalents was not material.

[0001032975-25-000008:mdna:170]
[same as prior period, unchanged from 0001032975-24-000075:mdna:164]

[0001032975-25-000008:mdna:171]
[same as prior period, unchanged from 0001032975-24-000075:mdna:165]

[0001032975-25-000008:mdna:172]
[same as prior period, unchanged from 0001032975-24-000075:mdna:166]

[0001032975-25-000008:mdna:173]
In June 2023, our Board of Directors approved a three-year share repurchase program, which allows us to use up to $1.0 billion to repurchase our shares. The 2023 share repurchase program enables us to repurchase shares for cancellation, as well as to support equity incentive plans or potential acquisitions. The Swiss Takeover Board approved the 2023 share repurchase program in July 2023 and the program became effective on July 28, 2023. During the nine months ended December 31, 2024, we repurchased 5.3 million shares for an aggregate cost of $461.4 million, under the 2023 share repurchase program for cancellation, of which $17.6 million of the aggregate cost was not paid yet as of December 31, 2024. As of December 31, 2024, $174.8 million was available for repurchase under the 2023 share repurchase program.

[0001032975-25-000008:mdna:174]
Swiss law limits a company’s ability to hold or repurchase its own shares. The aggregate par value of all shares held in treasury by us and our subsidiaries may not exceed 10% of our issued share capital, which corresponds to approximately 16.9 million registered shares as of December 31, 2024. This limitation does not apply to shares repurchased for cancellation, due to the Board of Directors' authority under the capital band set forth in the Company's Articles of Incorporation. As of December 31, 2024, we had a total of 19.6 million shares held in treasury stock, which includes 5.3 million shares that have been repurchased for cancellation and 14.3 million shares that have been purchased to support equity incentive plans or potential acquisitions.

[0001032975-25-000008:mdna:175]
Although we enter into trading plans for systematic repurchases (e.g., 10b5-1 trading plans) from time to time, our 2023 share repurchase program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years through July 27, 2026. To the extent that the shares are repurchased to support equity incentive plans or potential acquisitions, the shares are repurchased on the ordinary trading line of Swiss Exchange ("SIX") and/or the Nasdaq Global Select Market ("Nasdaq"). Shares repurchased for cancellation purposes are repurchased via a second trading line on SIX.

[0001032975-25-000008:mdna:176]
Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.

[0001032975-25-000008:mdna:177]
[same as prior period, unchanged from 0001032975-24-000075:mdna:170]

[0001032975-25-000008:mdna:178]
[same as prior period, unchanged from 0001032975-24-000075:mdna:171]

[0001032975-25-000008:mdna:179]
[same as prior period, unchanged from 0001032975-24-000075:mdna:172]

[0001032975-25-000008:mdna:180]
[same as prior period, unchanged from 0001032975-24-000075:mdna:173]

[0001032975-25-000008:mdna:181]
As of December 31, 2024, we had non-cancelable purchase commitments of $424.8 million for inventory purchases made in the normal course of business from original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. We recorded a liability for firm, non-cancelable, and unhedged inventory purchase commitments in excess of anticipated demand or net realizable value consistent with our valuation of excess and obsolete inventory. As of December 31, 2024, the liability for these purchase commitments was $18.8 million and is recorded in accrued and other current liabilities in the condensed consolidated balance sheet.

[0001032975-25-000008:mdna:182]
As of December 31, 2024, we have firm purchase commitments of $22.9 million for capital expenditures primarily related to commitments for tooling and equipment for new and existing products. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-25-000008:mdna:183]
[same as prior period, unchanged from 0001032975-24-000075:mdna:176]

[0001032975-25-000008:mdna:184]
[same as prior period, unchanged from 0001032975-24-000075:mdna:177]

[0001032975-25-000008:mdna:185]
[same as prior period, unchanged from 0001032975-24-000075:mdna:178]

[0001032975-25-000008:mdna:186]
We indemnify certain suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2024, no material amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-25-000008:mdna:187]
[same as prior period, unchanged from 0001032975-24-000075:mdna:180]

[0001032975-25-000008:mdna:188]
Legal Proceedings

[0001032975-25-000008:mdna:189]
From time to time, we are involved in claims and legal proceedings that arise in the ordinary course of our business. For more information about Legal Proceedings, see Part II Item 1 Legal Proceedings of this quarterly report on Form 10-Q for the period ended December 31, 2024.
