# LOGI note change history — 0001032975-17-000037 → 0001032975-17-000053


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2017-11-01):
[0001032975-17-000053:note_history:1]
All of the Company’s peripherals products sold are covered by warranty to be free from defects in material and workmanship. The warranty period varies by product and by region.

- changed (2017-11-01):
[0001032975-17-000053:note_history:2]
Changes in the Company’s warranty liability for the three and six months ended September 30, 2017 and 2016 were as follows (in thousands):
  (was, 2017-07-27, similarity 0.9231):
[0001032975-17-000037:note_history:2]
Changes in the Company’s warranty liability for the three months ended June 30, 2017 and 2016 were as follows (in thousands):

- changed (2017-11-01):
[0001032975-17-000053:note_history:3]
|  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Beginning of the period | $ | 22,056 |  |  | $ | 21,752 |  |  | $ | 21,911 |  |  | $ | 20,380 |  |
| Assumed from business acquisition | 1,230 |  |  | 150 |  |  | 1,230 |  |  | 1,963 |  |
| Provision | 5,414 |  |  | 3,163 |  |  | 9,715 |  |  | 6,340 |  |
| Settlements | (4,611 | ) |  | (3,452 | ) |  | (9,179 | ) |  | (6,880 | ) |
| Currency translation | 260 |  |  | (1 | ) |  | 672 |  |  | (191 | ) |
| End of the period | $ | 24,349 |  |  | $ | 21,612 |  |  | $ | 24,349 |  |  | $ | 21,612 |  |
  (was, 2017-07-27, similarity 0.6624):
[0001032975-17-000037:note_history:3]
|  |  | Three Months EndedJune 30, |
|  |  | 2017 |  | 2016 |
| Beginning of the period |  | $ | 21,911 |  |  | $ | 20,380 |  |
| Assumed from business acquisition |  | — |  |  | 1,813 |  |
| Provision |  | 5,124 |  |  | 3,177 |  |
| Settlements |  | (4,567 | ) |  | (3,428 | ) |
| Currency translation |  | (412 | ) |  | (190 | ) |
| End of the period |  | $ | 22,056 |  |  | $ | 21,752 |  |

- added (2017-11-01):
[0001032975-17-000053:note_history:4]
Logitech Europe S.A., one of our wholly-owned subsidiaries, guaranteed payments of certain third-party contract manufacturers’ purchase obligations. As of September 30, 2017, the maximum amount of this guarantee was $3.8 million, of which $1.4 million of guaranteed purchase obligations were outstanding.

- changed (2017-11-01):
[0001032975-17-000053:note_history:5]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2017, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2017-07-27, similarity 0.9899):
[0001032975-17-000037:note_history:5]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of June 30, 2017, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

- removed (2017-11-01):
[0001032975-17-000037:note_history:6]
All of the Company’s peripherals products sold are covered by warranty to be free from defects in material and workmanship. For products launched prior to April 1, 2014, the standard warranty period was up to five years. Starting from April 1, 2014, the standard warranty for all new products launched was changed to two years from the date of purchase for European Countries and generally one year from date of purchase for all other countries.

- removed (2017-11-01):
[0001032975-17-000037:note_history:7]
Logitech Europe S.A., one of our wholly-owned subsidiaries, guaranteed payments of certain third-party contract manufacturers’ purchase obligations. As of June 30, 2017, the maximum amount of this guarantee was $3.8 million, of which $0.9 million of guaranteed purchase obligations were outstanding.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2017-11-01):
[0001032975-17-000053:note_history:8]
Business Acquisition

- added (2017-11-01):
[0001032975-17-000053:note_history:9]
In August 2017, the Company acquired the ASTRO Gaming business. See "Note 2 - Business Acquisition" for more information.

- changed (2017-11-01):
[0001032975-17-000053:note_history:10]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and six months ended September 30, 2017 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2018, or any future periods.
  (was, 2017-07-27, similarity 0.7702):
[0001032975-17-000037:note_history:10]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three months ended June 30, 2017 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2018, or any future periods.

- changed (2017-11-01):
[0001032975-17-000053:note_history:11]
Certain amounts from the comparative period in the accompanying unaudited condensed consolidated financial statements have been reclassified to conform to the condensed consolidated financial statement presentation as of and for the three and six months ended September 30, 2017.
  (was, 2017-07-27, similarity 0.9118):
[0001032975-17-000037:note_history:11]
Certain amounts from the comparative period in the accompanying unaudited condensed consolidated financial statements have been reclassified to conform to the condensed consolidated financial statement presentation as of and for the three months ended June 30, 2017.

- changed (2017-11-01):
[0001032975-17-000053:note_history:12]
Other than the recent accounting pronouncements adopted, discussed below, there have been no substantial changes in the Company’s significant accounting policies during the six months ended September 30, 2017 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2017.
  (was, 2017-07-27, similarity 0.9259):
[0001032975-17-000037:note_history:12]
Other than the recent accounting pronouncements adopted, discussed below, there have been no substantial changes in the Company’s significant accounting policies during the three months ended June 30, 2017 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2017.

- changed (2017-11-01):
[0001032975-17-000053:note_history:13]
In July 2015, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2015-11, "Simplifying the Measurement of Inventory (Topic 330)" ("ASU 2015-11"). Topic 330, Inventory, previously required an entity to measure inventory at the lower of cost or market, with market value represented by replacement cost, net realizable value or net realizable value less a normal profit margin. ASU 2015-11 requires an entity to measure inventory at the lower of cost or net realizable value and is effective for fiscal years beginning after December 15, 2016. The Company adopted this standard effective April 1, 2017, which has not had a material impact on its consolidated financial statements.
  (was, 2017-07-27, similarity 0.7871):
[0001032975-17-000037:note_history:13]
In July 2015, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2015-11, "Simplifying the Measurement of Inventory (Topic 330)" ("ASU 2015-11"). Topic 330, Inventory, previously required an entity to measure inventory at the lower of cost or market, with market value represented by replacement cost, net realizable value or net realizable value less a normal profit margin. ASU 2015-11 requires an entity to measure inventory at the lower of cost or net realizable value and is effective for fiscal years beginning after December 15, 2016, with early adoption permitted. The Company has adopted this standard effective April 1, 2017 which did not have a material impact on its condensed consolidated financial statements.

- changed (2017-11-01):
[0001032975-17-000053:note_history:14]
In March 2016, the FASB issued ASU 2016-09, "Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting" ("ASU 2016-09"). ASU 2016-09 simplifies several aspects of the accounting for share-based payments, including immediate recognition of all excess tax benefits and deficiencies in the income statement, changing the threshold to qualify for equity classification up to the employees' maximum statutory tax rates, allowing an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures as they occur, and clarifying the classification on the statement of cash flows for the excess tax benefits and employee taxes paid when an employer withholds shares for tax withholding purposes. ASU 2016-09 is effective for fiscal years beginning after December 15, 2016. The Company adopted this standard effective April 1, 2017. Changes to the statements of cash flows related to the classification of excess tax benefits were implemented on a retroactive basis and accordingly, to conform to the current year presentation, the Company reclassified $4.1 million of excess tax benefits previously reported under financing activities to operating activities for the six months ended September 30, 2016 on its condensed consolidated statements of cash flows. Under the new standard, the Company accounts for forfeitures as they occur. The change in accounting for forfeitures resulted in a cumulative-effect adjustment to decrease retained earnings as of March 31, 2017 by $3.3 million. The Company further recognized a cumulative-effect adjustment to increase retained earnings as of March 31, 2017 by $57.2 million upon adoption of the new guidance to account for gross excess tax benefits of $75.2 million that were previously not recognized because the related tax deduction had not reduced current income taxes, offset by a valuation allowance of $18.0 million to reduce the deferred tax assets to amounts that are more likely than not to be realized.
  (was, 2017-07-27, similarity 0.6098):
[0001032975-17-000037:note_history:14]
In March 2016, the FASB issued ASU 2016-09, "Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting" ("ASU 2016-09"). ASU 2016-09 simplifies several aspects of the accounting for share-based payments, including immediate recognition of all excess tax benefits and deficiencies in the income statement, changing the threshold to qualify for equity classification up to the employees' maximum statutory tax rates, allowing an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures as they occur, and clarifying the classification on the statement of cash flows for the excess tax benefits and employee taxes paid when an employer withholds shares for tax withholding purposes. ASU 2016-09 is effective for fiscal years beginning after December 15, 2016, with early adoption permitted. The Company has adopted this standard effective April 1, 2017. Changes to the statements of cash flows related to the classification of excess tax benefits were implemented on a retroactive basis and accordingly, to conform to the current year presentation, the Company reclassified $3.3 million of excess tax benefits previously reported under financing activities to operating activities for the three months ended June 30, 2016 on its condensed consolidated statements of cash flows. Under the new standard, the Company accounts for forfeitures as they occur. The change in accounting for forfeitures resulted in a cumulative-effect adjustment to decrease retained earnings as of March 31, 2017 by $3.3 million. The Company further recognized a cumulative-effect adjustment to increase retained earnings as of March 31, 2017 by $57.2 million upon adoption of the new guidance to account for gross excess tax benefits of $75.2 million that were previously not recognized because the related tax deduction had not reduced current income taxes, offset by a valuation allowance of $18.0 million to reduce the deferred tax assets to amounts that are more likely than not to be realized.

- changed (2017-11-01):
[0001032975-17-000053:note_history:15]
350)" ("ASU 2017-04"), which removes Step 2 from the goodwill impairment test. ASU 2017-04 is effective for annual or any interim goodwill impairments in annual periods beginning December 15, 2019, with early adoption permitted. The Company adopted this standard effective April 1, 2017, which has not had a material impact on its consolidated financial statements.
  (was, 2017-07-27, similarity 0.8762):
[0001032975-17-000037:note_history:15]
350)" ("ASU 2017-04"), which removes Step 2 from the goodwill impairment test. ASU 2017-04 is effective for annual or any interim goodwill impairments in annual periods beginning December 15, 2019, with early adoption permitted. The Company has adopted this standard effective April 1, 2017 which did not have a material impact on its condensed consolidated financial statements.

- changed (2017-11-01):
[0001032975-17-000053:note_history:16]
effective for annual periods beginning after December 15, 2017, with early adoption permitted, including adoption in any interim period for which financial statements have not yet been issued. The Company adopted this standard effective April 1, 2017, which has not had a material impact on its consolidated financial statements.
  (was, 2017-07-27, similarity 0.8664):
[0001032975-17-000037:note_history:16]
effective for annual periods beginning after December 15, 2017, with early adoption permitted, including adoption in any interim period for which financial statements have not yet been issued. The Company has adopted this standard effective April 1, 2017 which did not have a material impact on its condensed consolidated financial statements.

- changed (2017-11-01):
[0001032975-17-000053:note_history:17]
In May 2014, the FASB issued ASU No. 2014-09, "Revenue from Contracts with Customers (Topic 606)" ("ASU 2014-09") which supersedes the revenue recognition requirements under ASC 605, Revenue Recognition. ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. Under the new model, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The new standard requires reporting companies to disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The new standard will become effective for the Company on April 1, 2018. The standard allows for either a "full retrospective" adoption, meaning the standard is applied to all of the periods presented subject to practical expedients, or a "modified retrospective" adoption, meaning the standard is applied only in the initial year, or interim period in year of initial application with a cumulative adjustment to opening retained earnings for existing contracts. The Company currently expects to utilize the modified retrospective transition method. The Company continues to evaluate the impact this new standard could have on the current contracts with customers and the accruals of various sales and marketing programs the Company offers and on the related breakage estimates. The Company has not completed its analysis of the impact to its consolidated financial statements and this information will not be available until the Company completes its full assessment. It is possible that during the fiscal year 2018, the Company may identify certain areas which may result in material impact on the Company’s consolidated financial statements, or the Company may revise its adoption method.
  (was, 2017-07-27, similarity 0.995):
[0001032975-17-000037:note_history:17]
In May 2014, the FASB issued ASU No. 2014-09, "Revenue from Contracts with Customers (Topic 606)" ("ASU 2014-09") which supersedes the revenue recognition requirements under ASC 605, Revenue Recognition. ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. Under the new model, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The new standard requires reporting companies to disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The new standard will become effective for the Company on April 1, 2018. The standard allows for either a "full retrospective" adoption, meaning the standard is applied to all of the periods presented subject to practical expedients, or a "modified retrospective" adoption, meaning the standard is applied only in the initial year, or interim period in year of initial application with a cumulative adjustment to opening retained earnings for existing contracts. The Company currently expects to utilize the modified retrospective transition method. The Company continues to evaluate the impact this new standard could have on the current contracts with customers and the accruals of various sales and marketing programs the Company offers and on the related breakage estimates. The Company has not completed its analysis of the impact to its condensed consolidated financial statements and this information will not be available until the Company completes its full assessment. It is possible that during the fiscal year 2018, the Company may identify certain areas which may result in material impact on the Company’s condensed consolidated financial statements, or the Company may revise its adoption method.

- changed (2017-11-01):
[0001032975-17-000053:note_history:18]
In January 2016, the FASB issued ASU 2016-01, "Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10)" ("ASU 2016-01"). ASU 2016-01 is effective for annual periods beginning after December 15, 2017, including interim periods within those annual periods, with early adoption permitted. The Company does not believe that the adoption of ASU 2016-01 will have a material impact on its consolidated financial statements and will adopt this standard effective April 1, 2018.
  (was, 2017-07-27, similarity 0.9859):
[0001032975-17-000037:note_history:18]
In January 2016, the FASB issued ASU 2016-01, “Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10)” ("ASU 2016-01"). ASU 2016-01 is effective for annual periods beginning after December 15, 2017, including interim periods within those annual periods, with early adoption permitted. The Company does not believe that the adoption of ASU 2016-01 will have a material impact on its condensed consolidated financial statements and will adopt this standard effective April 1, 2018.

- changed (2017-11-01):
[0001032975-17-000053:note_history:19]
In February 2016, the FASB issued ASU 2016-02, "Leases (Topic 842)" ("ASU 2016-02"), which requires the recognition of lease assets and lease liabilities arising from operating leases in the statement of financial position. ASU 2016-02 is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years, with early adoption permitted. The Company is evaluating the full effect that ASU 2016-02 will have on its consolidated financial statements and will adopt this standard effective April 1, 2019.
  (was, 2017-07-27, similarity 0.9904):
[0001032975-17-000037:note_history:19]
In February 2016, the FASB issued ASU 2016-02, "Leases (Topic 842)" ("ASU 2016-02"), which requires the recognition of lease assets and lease liabilities arising from operating leases in the statement of financial position. ASU 2016-02 is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years, with early adoption permitted. The Company is evaluating the full effect that ASU 2016-02 will have on its condensed consolidated financial statements and will adopt this standard effective April 1, 2019.

- added (2017-11-01):
[0001032975-17-000053:note_history:20]
In October 2016, the FASB issued ASU 2016-16, "Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory"  ("ASU 2016-16"), which eliminates the deferral of income tax effects of intra-entity asset transfers until the transferred asset is sold to an unrelated party or recovered through use. However, this standard does not apply to intra-entity transfer of inventory.  ASU 2016-16 is effective for annual periods beginning after December 15, 2017, including interim periods within those annual periods, with early adoption permitted but only in the first interim period of an annual period.  The cumulative effect of change on equity upon adoption is to be quantified under the modified retrospective approach and recorded as of the beginning of the period of adoption.  The Company is evaluating the full effect that ASU 2016-16 will have on its consolidated financial statements and will adopt this standard effective April 1, 2018.

- changed (2017-11-01):
[0001032975-17-000053:note_history:21]
In December 2016, the FASB issued ASU 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash" ("ASU 2016-18"), which requires that a statement of cash flows explains the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents.  ASU 2016-18 is effective for annual periods beginning after December 15, 2017, including interim periods within those annual periods, with early adoption permitted. The adoption of this standard should be applied using a retrospective transition method to each period presented. The Company does not expect the adoption of ASU 2016-18 will have a material impact on its consolidated financial statements and will adopt this standard effective April 1, 2018.
  (was, 2017-07-27, similarity 0.9934):
[0001032975-17-000037:note_history:21]
In December 2016, the FASB issued ASU 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash" ("ASU 2016-18"), which requires that a statement of cash flows explains the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents.  ASU 2016-18 is effective for annual periods beginning after December 15, 2017, including interim periods within those annual periods, with early adoption permitted. The adoption of this standard should be applied using a retrospective transition method to each period presented. The Company does not expect the adoption of ASU 2016-18 will have a material impact on its condensed consolidated financial statements and will adopt this standard effective April 1, 2018.

- added (2017-11-01):
[0001032975-17-000053:note_history:22]
In January 2017, the FASB issued ASU 2017-01, "Business Combination  (ASC Topic 805): Clarifying the Definition of a Business" ("ASU 2017-01"), which changes the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. ASU 2017-01 is effective for annual or any interim goodwill impairments in annual periods beginning after December 15, 2017, with early adoption permitted. The Company does not expect the adoption of ASU 2017-01 will have a material impact on its condensed consolidated financial statements and will adopt this standard effective April 1, 2018.

- changed (2017-11-01):
[0001032975-17-000053:note_history:23]
In March 2017, the FASB issued ASU 2017-07, "Compensation-Retirement Benefit (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost" ("ASU 2017-07"), which requires that the Company disaggregate the service cost component from the other components of net benefit cost, and also provides guidance on how to present the service cost component and the other components of net benefit cost in the income statement and allow only the service cost component of net benefit cost to be eligible for capitalization. ASU 2017-07 is effective for annual periods beginning after December 15, 2017, including interim periods within those annual periods, with early adoption permitted. The Company does not expect the adoption of ASU 2017-07 will have a material impact on its consolidated financial statements and will adopt this standard effective April 1, 2018.
  (was, 2017-07-27, similarity 0.9943):
[0001032975-17-000037:note_history:23]
In March 2017, the FASB issued ASU 2017-07, "Compensation-Retirement Benefit (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost" ("ASU 2017-07"), which requires that the Company disaggregate the service cost component from the other components of net benefit cost, and also provides guidance on how to present the service cost component and the other components of net benefit cost in the income statement and allow only the service cost component of net benefit cost to be eligible for capitalization. ASU 2017-07 is effective for annual periods beginning after December 15, 2017, including interim periods within those annual periods, with early adoption permitted. The Company does not expect the adoption of ASU 2017-07 will have a material impact on its condensed consolidated financial statements and will adopt this standard effective April 1, 2018.

- added (2017-11-01):
[0001032975-17-000053:note_history:24]
In August 2017, the FASB issued ASU 2017-12, "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" ("ASU 2017-12"), which improves the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements and simplifies the application of the hedge accounting guidance. ASU 2017-12 is effective for annual periods beginning after December 15, 2018, including interim periods within those annual periods, with early adoption permitted. The Company does not expect the adoption of ASU 2017-12 will have a material impact on its consolidated financial statements and is currently assessing the timing of adoption.

- removed (2017-11-01):
[0001032975-17-000037:note_history:25]
In October 2016, the FASB issued ASU 2016-16, "Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory"  ("ASU 2016-16"), which eliminates the deferral of income tax effects of intra-entity asset transfers until the transferred asset is sold to an unrelated party or recovered through use however, this standard does not apply to intra-entity transfer of inventory.  ASU 2016-16 is effective for annual periods beginning after December 15, 2017, including interim periods within those annual periods, with early adoption permitted but only in the first interim period of an annual period.  The cumulative effect of change on equity upon adoption is to be quantified under the modified retrospective approach and recorded as of the beginning of the period of adoption.  The Company is evaluating the full effect that ASU 2016-16 will have on its condensed consolidated financial statements and will adopt this standard effective April 1, 2018.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-11-01):
[0001032975-17-000053:note_history:26]
The Company had several uncommitted, unsecured bank lines of credit aggregating $68.2 million as of September 30, 2017. There are no financial covenants under these lines of credit with which the Company must comply. As of September 30, 2017, the Company had outstanding bank guarantees of $39.8 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of September 30, 2017 or March 31, 2017.

- removed (2017-11-01):
[0001032975-17-000037:note_history:27]
The Company had several uncommitted, unsecured bank lines of credit aggregating $38.9 million as of June 30, 2017. There are no financial covenants under these lines of credit with which the Company must comply. As of June 30, 2017, the Company had outstanding bank guarantees of $23.3 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of June 30, 2017 or March 31, 2017.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2017-11-01):
[0001032975-17-000037:note_history:28]
Subsequent Event

- removed (2017-11-01):
[0001032975-17-000037:note_history:29]
On July 10, 2017, the Company signed an agreement to acquire certain assets and liabilities constituting the Astro Gaming business from AG Acquisition Corporation for $85 million in cash.  Astro Gaming is a leading console gaming brand and has a history of producing award-winning headsets for professional gamers and enthusiasts. The transaction is expected to close in early August, 2017 and is subject to receipt of regulatory approvals in various jurisdictions and other closing conditions.
