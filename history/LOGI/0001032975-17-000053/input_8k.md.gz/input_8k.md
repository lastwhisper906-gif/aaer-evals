# LOGI 8-K — 0001032975-17-000043 filed 2017-10-24

## item codes, every 8-K on or before 2017-11-01

- 2017-10-24 0001032975-17-000043 — 2.02, 9.01
- 2017-09-18 0001032975-17-000040 — 5.07, 8.01
- 2017-07-25 0001032975-17-000028 — 2.02, 9.01
- 2017-07-12 0001032975-17-000022 — 1.01
- 2017-04-26 0001032975-17-000012 — 2.02, 9.01
- 2017-01-25 0001032975-17-000002 — 2.02, 9.01
- 2016-10-26 0001032975-16-000103 — 2.02, 9.01
- 2016-09-13 0001032975-16-000101 — 5.07, 8.01
- 2016-07-28 0001032975-16-000092 — 2.02, 9.01
- 2016-06-30 0001032975-16-000087 — 5.02
- 2016-04-28 0001032975-16-000077 — 2.02, 9.01
- 2016-04-14 0001032975-16-000073 — 1.01, 7.01, 9.01
- 2016-01-21 0001032975-16-000064 — 2.02, 9.01
- 2016-01-04 0001032975-16-000061 — 1.01, 2.01, 9.01
- 2015-12-23 0001032975-15-000059 — 5.02
- 2015-10-22 0001032975-15-000047 — 2.02, 9.01
- 2015-09-11 0001032975-15-000044 — 5.07, 8.01
- 2015-07-24 0001032975-15-000034 — 2.05 — amendment of 0001032975-15-000030
- 2015-07-23 0001032975-15-000030 — 2.02, 9.01
- 2015-06-25 0001032975-15-000025 — 5.02
- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2017-11-01

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-17-000043:8k_2_02:1]
EX-99.1
2
exhibit991q2fy18.htm
EXHIBIT 99.1

[0001032975-17-000043:8k_2_02:2]
Exhibit

[0001032975-17-000043:8k_2_02:3]
Exhibit 99.1

[0001032975-17-000043:8k_2_02:4]
Editorial Contacts:

[0001032975-17-000043:8k_2_02:5]
Ben Lu, Vice President, Investor Relations - USA (510) 713-5568

[0001032975-17-000043:8k_2_02:6]
Krista Todd, Vice President, Communications - USA (510) 713-5834

[0001032975-17-000043:8k_2_02:7]
Ben Starkie, Corporate Communications - Europe +41 (0) 79-292-3499

[0001032975-17-000043:8k_2_02:8]
Logitech Delivers Strong Q2 Sales and Profit Growth

[0001032975-17-000043:8k_2_02:9]
NEWARK, Calif. - October 23, 2017 and LAUSANNE, Switzerland, October 24, 2017 - Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced financial results for the second quarter of Fiscal Year 2018.

[0001032975-17-000043:8k_2_02:10]
| • | Q2 sales were $634 million, up 12 percent in US dollars and 11 percent in constant currency, compared to Q2 of the prior year. |

[0001032975-17-000043:8k_2_02:11]
| • | Q2 GAAP operating income grew 12 percent to $60 million, compared to $53 million in the same quarter a year ago. Q2 GAAP earnings per share (EPS) grew 21 percent to $0.34, compared to $0.28 in the same quarter a year ago. |

[0001032975-17-000043:8k_2_02:12]
| • | Q2 non-GAAP operating income grew 12 percent to $72 million, compared to $65 million in the same quarter a year ago. Q2 non-GAAP EPS grew 14 percent to $0.40, compared to $0.35 in the same quarter a year ago. |

[0001032975-17-000043:8k_2_02:13]
“We delivered another strong quarter of growth,” said Bracken Darrell, Logitech president and chief executive officer. “Gaming and Video Collaboration categories showed particular strength and momentum. And we have a diverse and strong portfolio overall. We’re entering the second half of the year with a wide range of exciting products ahead of the holiday season.”

[0001032975-17-000043:8k_2_02:14]
Outlook

[0001032975-17-000043:8k_2_02:15]
Logitech’s outlook for Fiscal Year 2018 is 10 to 12 percent sales growth in constant currency and $260 to $270 million in non-GAAP operating income.

[0001032975-17-000043:8k_2_02:16]
Prepared Remarks Available Online

[0001032975-17-000043:8k_2_02:17]
Logitech has made its prepared written remarks for the financial results teleconference available online on the Logitech corporate website at http://ir.logitech.com.

[0001032975-17-000043:8k_2_02:18]
Financial Results Teleconference and Webcast

[0001032975-17-000043:8k_2_02:19]
Logitech will hold a financial results teleconference to discuss the results for Q2 FY 2018 on

[0001032975-17-000043:8k_2_02:20]
Tuesday, October 24, 2017 at 8:30 a.m. Eastern Daylight Time and 2:30 p.m. Central European Summer Time. A live webcast of the call will be available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-17-000043:8k_2_02:21]
Use of Non-GAAP Financial Information and Constant Currency

[0001032975-17-000043:8k_2_02:22]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of intangible assets, purchase accounting effect on inventory, acquisition-related costs, change in fair value of contingent consideration for business acquisition, restructuring charges (credits), gain (loss) on investments in privately held companies, investigation and related expenses, non-GAAP income tax adjustment, and other items detailed under “Supplemental Financial Information” after the tables below. Logitech also presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information, used together with the GAAP financial information, will help investors to evaluate its current period performance and trends in its business. With respect to the Company’s outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to the GAAP amounts has been provided for Fiscal Year 2018.

[0001032975-17-000043:8k_2_02:23]
About Logitech

[0001032975-17-000043:8k_2_02:24]
Logitech designs products that have an everyday place in people's lives, connecting them to the digital experiences they care about. More than 35 years ago, Logitech started connecting people through

[0001032975-17-000043:8k_2_02:25]
computers, and now it’s a multi-brand company designing products that bring people together through music, gaming, video and computing. Brands of Logitech include Logitech, Ultimate Ears, Jaybird, Logitech G and ASTRO Gaming. Founded in 1981, and headquartered in Lausanne, Switzerland, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI). Find Logitech at www.logitech.com, the company blog or @Logitech.

[0001032975-17-000043:8k_2_02:26]
# # #

[0001032975-17-000043:8k_2_02:27]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-17-000043:8k_2_02:28]
2017 Logitech, Logicool, Logi and other Logitech marks are owned by Logitech and may be registered. All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s website at www.logitech.com.

[0001032975-17-000043:8k_2_02:29]
(LOGIIR)

[0001032975-17-000043:8k_2_02:30]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |
| (In thousands, except per share amounts) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | September 30, |  | September 30, |
| GAAP CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS (A) |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net sales |  | $ | 634,212 |  |  | $ | 564,304 |  |  | $ | 1,164,158 |  |  | $ | 1,044,168 |  |
| Cost of goods sold |  | 403,469 |  |  | 356,268 |  |  | 738,243 |  |  | 665,893 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 2,011 |  |  | 1,163 |  |  | 3,515 |  |  | 2,776 |  |
| Gross profit |  | 228,732 |  |  | 206,873 |  |  | 422,400 |  |  | 375,499 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 107,386 |  |  | 93,792 |  |  | 209,764 |  |  | 177,664 |  |
| Research and development |  | 36,647 |  |  | 32,632 |  |  | 71,746 |  |  | 64,583 |  |
| General and administrative |  | 25,205 |  |  | 25,290 |  |  | 50,559 |  |  | 50,945 |  |
| Amortization of intangible assets and acquisition-related costs |  | 2,491 |  |  | 1,748 |  |  | 3,881 |  |  | 3,041 |  |
| Change in fair value of contingent consideration for business acquisition |  | (2,930 | ) |  | — |  |  | (4,908 | ) |  | — |  |
| Total operating expenses |  | 168,799 |  |  | 153,462 |  |  | 331,042 |  |  | 296,233 |  |
| Operating income |  | 59,933 |  |  | 53,411 |  |  | 91,358 |  |  | 79,266 |  |
| Interest income (expense), net |  | 1,048 |  |  | (90 | ) |  | 2,223 |  |  | 61 |  |
| Other income (expense), net |  | 459 |  |  | (683 | ) |  | (570 | ) |  | (1,691 | ) |
| Income before income taxes |  | 61,440 |  |  | 52,638 |  |  | 93,011 |  |  | 77,636 |  |
| Provision for (benefit from) income taxes |  | 4,087 |  |  | 5,593 |  |  | (1,349 | ) |  | 8,650 |  |
| Net income |  | $ | 57,353 |  |  | $ | 47,045 |  |  | $ | 94,360 |  |  | $ | 68,986 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.35 |  |  | $ | 0.29 |  |  | $ | 0.58 |  |  | $ | 0.43 |  |
| Diluted |  | $ | 0.34 |  |  | $ | 0.28 |  |  | $ | 0.56 |  |  | $ | 0.42 |  |
| Weighted average shares used to compute net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 164,120 |  |  | 162,222 |  |  | 163,765 |  |  | 162,176 |  |
| Diluted |  | 169,078 |  |  | 165,549 |  |  | 168,710 |  |  | 164,926 |  |
| Cash dividend per share |  | $ | 0.63 |  |  | $ | 0.57 |  |  | $ | 0.63 |  |  | $ | 0.57 |  |

[0001032975-17-000043:8k_2_02:31]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS * |
| (In thousands) - unaudited |  |  |  |  |
|  |  | September 30, |  | March 31, |
| CONDENSED CONSOLIDATED BALANCE SHEETS (A) |  | 2017 |  | 2017 |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 398,848 |  |  | $ | 547,533 |  |
| Short-term investments |  | 6,789 |  |  | — |  |
| Accounts receivable, net |  | 279,581 |  |  | 185,179 |  |
| Inventories |  | 329,675 |  |  | 253,401 |  |
| Other current assets |  | 47,721 |  |  | 41,732 |  |
| Total current assets |  | 1,062,614 |  |  | 1,027,845 |  |
| Non-current assets: |  |  |  |  |  |  |
| Property, plant and equipment, net |  | 87,355 |  |  | 85,408 |  |
| Goodwill |  | 271,154 |  |  | 249,741 |  |
| Other intangible assets, net |  | 93,846 |  |  | 47,564 |  |
| Other assets |  | 138,144 |  |  | 88,119 |  |
| Total assets |  | $ | 1,653,113 |  |  | $ | 1,498,677 |  |
| Current liabilities: |  |  |  |  |  |  |
| Accounts payable |  | $ | 386,963 |  |  | $ | 274,805 |  |
| Accrued and other current liabilities |  | 229,176 |  |  | 232,273 |  |
| Total current liabilities |  | 616,139 |  |  | 507,078 |  |
| Non-current liabilities: |  |  |  |  |  |  |
| Income taxes payable |  | 33,241 |  |  | 51,797 |  |
| Other non-current liabilities |  | 80,903 |  |  | 83,691 |  |
| Total liabilities |  | 730,283 |  |  | 642,566 |  |
| Shareholders’ equity: |  |  |  |  |
| Registered shares, CHF 0.25 par value: |  | 30,148 |  |  | 30,148 |  |
| Issued and authorized shares —173,106 at September 30 and March 31, 2017 |  |  |  |  |
| Conditionally authorized shares — 50,000 at September 30 and March 31, 2017 |  |  |  |  |
| Additional paid-in capital |  | 29,940 |  |  | 26,596 |  |
| Shares in treasury, at cost — 8,745 at September 30, 2017 and 10,727 at March 31, 2017 |  | (156,589 | ) |  | (174,037 | ) |
| Retained earnings |  | 1,118,134 |  |  | 1,074,110 |  |
| Accumulated other comprehensive loss |  | (98,803 | ) |  | (100,706 | ) |
| Total shareholders’ equity |  | 922,830 |  |  | 856,111 |  |
| Total liabilities and shareholders’ equity |  | $ | 1,653,113 |  |  | $ | 1,498,677 |  |

[0001032975-17-000043:8k_2_02:32]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | September 30, |  | September 30, |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (A) |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 57,353 |  |  | $ | 47,045 |  |  | $ | 94,360 |  |  | $ | 68,986 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  | 10,220 |  |  | 10,511 |  |  | 19,368 |  |  | 23,616 |  |
| Amortization of intangible assets |  | 3,645 |  |  | 2,159 |  |  | 6,238 |  |  | 3,867 |  |
| Gain on investments in privately held companies |  | (695 | ) |  | (171 | ) |  | (436 | ) |  | (172 | ) |
| Loss on disposal of property, plant and equipment |  | 15 |  |  | — |  |  | 12 |  |  | — |  |
| Share-based compensation expense |  | 10,978 |  |  | 8,450 |  |  | 21,683 |  |  | 16,967 |  |
| Deferred income taxes |  | (2,054 | ) |  | 663 |  |  | (11,933 | ) |  | (385 | ) |
| Change in fair value of contingent consideration for business acquisition |  | (2,930 | ) |  | — |  |  | (4,908 | ) |  | — |  |
| Changes in assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | (57,762 | ) |  | (48,340 | ) |  | (93,464 | ) |  | (97,001 | ) |
| Inventories |  | (36,938 | ) |  | (18,310 | ) |  | (57,327 | ) |  | (28,317 | ) |
| Other assets |  | (5,402 | ) |  | (3,567 | ) |  | (8,490 | ) |  | (4,738 | ) |
| Accounts payable |  | 71,489 |  |  | 40,907 |  |  | 110,136 |  |  | 83,676 |  |
| Accrued and other liabilities |  | 20,464 |  |  | 35,522 |  |  | (7,739 | ) |  | 25,387 |  |
| Net cash provided by operating activities |  | 68,383 |  |  | 74,869 |  |  | 67,500 |  |  | 91,886 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (7,153 | ) |  | (6,623 | ) |  | (17,188 | ) |  | (14,758 | ) |
| Investment in privately held companies |  | (160 | ) |  | (160 | ) |  | (520 | ) |  | (480 | ) |
| Acquisitions, net of cash acquired |  | (85,000 | ) |  | (13,000 | ) |  | (85,000 | ) |  | (66,987 | ) |
| Proceeds from return of investment in privately held companies |  | 237 |  |  | — |  |  | 237 |  |  | — |  |
| Changes in restricted cash |  | — |  |  | — |  |  | — |  |  | 715 |  |
| Purchases of short-term investments |  | (6,789 | ) |  | — |  |  | (6,789 | ) |  | — |  |
| Purchases of trading investments |  | (390 | ) |  | (1,042 | ) |  | (999 | ) |  | (5,271 | ) |
| Proceeds from sales of trading investments |  | 410 |  |  | 1,065 |  |  | 1,057 |  |  | 5,296 |  |
| Net cash used in investing activities |  | (98,845 | ) |  | (19,760 | ) |  | (109,202 | ) |  | (81,485 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | (104,248 | ) |  | (93,093 | ) |  | (104,248 | ) |  | (93,093 | ) |
| Purchases of registered shares |  | (10,058 | ) |  | (18,472 | ) |  | (10,682 | ) |  | (42,894 | ) |
| Proceeds from exercises of stock options and purchase rights |  | 17,431 |  |  | 13,885 |  |  | 30,000 |  |  | 14,484 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (2,023 | ) |  | (1,862 | ) |  | (23,706 | ) |  | (11,047 | ) |
| Net cash used in financing activities |  | (98,898 | ) |  | (99,542 | ) |  | (108,636 | ) |  | (132,550 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | 551 |  |  | (477 | ) |  | 1,653 |  |  | (1,845 | ) |
| Net decrease in cash and cash equivalents |  | (128,809 | ) |  | (44,910 | ) |  | (148,685 | ) |  | (123,994 | ) |
| Cash and cash equivalents, beginning of the period |  | 527,657 |  |  | 440,111 |  |  | 547,533 |  |  | 519,195 |  |
| Cash and cash equivalents, end of the period |  | $ | 398,848 |  |  | $ | 395,201 |  |  | $ | 398,848 |  |  | $ | 395,201 |  |

[0001032975-17-000043:8k_2_02:33]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |  |  |  |  |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |  |  |
| NET SALES |  | Three Months Ended |  | Six Months Ended |
|  |  | September 30, |  | September 30, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Net sales by product category: |  |  |  |  |  |  |  |  |  |  |  |  |
| Pointing Devices |  | $ | 124,235 |  |  | $ | 123,300 |  |  | 1 | % |  | $ | 246,309 |  |  | $ | 240,083 |  |  | 3 | % |
| Keyboards & Combos |  | 119,431 |  |  | 116,516 |  |  | 3 |  |  | 235,544 |  |  | 234,535 |  |  | — |  |
| PC Webcams |  | 27,510 |  |  | 24,307 |  |  | 13 |  |  | 53,135 |  |  | 49,569 |  |  | 7 |  |
| Tablet & Other Accessories |  | 30,817 |  |  | 20,614 |  |  | 49 |  |  | 54,035 |  |  | 34,499 |  |  | 57 |  |
| Video Collaboration |  | 46,131 |  |  | 28,581 |  |  | 61 |  |  | 81,748 |  |  | 52,491 |  |  | 56 |  |
| Mobile Speakers |  | 90,550 |  |  | 97,172 |  |  | (7 | ) |  | 153,468 |  |  | 154,468 |  |  | (1 | ) |
| Audio-PC & Wearables |  | 63,215 |  |  | 62,254 |  |  | 2 |  |  | 113,417 |  |  | 118,833 |  |  | (5 | ) |
| Gaming |  | 113,754 |  |  | 79,193 |  |  | 44 |  |  | 191,462 |  |  | 135,693 |  |  | 41 |  |
| Smart Home |  | 18,370 |  |  | 11,807 |  |  | 56 |  |  | 34,836 |  |  | 22,974 |  |  | 52 |  |
| Other (1) |  | 199 |  |  | 560 |  |  | (64 | ) |  | 204 |  |  | 1,023 |  |  | (80 | ) |
| Total net sales |  | $ | 634,212 |  |  | $ | 564,304 |  |  | 12 |  |  | $ | 1,164,158 |  |  | $ | 1,044,168 |  |  | 11 |  |

[0001032975-17-000043:8k_2_02:34]
(1) Other category includes products that we currently intend to transition out of, or have already transitioned out of, because they are no longer strategic to our business.

[0001032975-17-000043:8k_2_02:35]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |  |  |  |  |
| GAAP TO NON-GAAP RECONCILIATION (A)(B) |  | Three Months Ended |  | Six Months Ended |
|  |  | September 30, |  | September 30, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Gross profit - GAAP |  | $ | 228,732 |  |  | $ | 206,873 |  |  | $ | 422,400 |  |  | $ | 375,499 |  |
| Share-based compensation expense |  | 1,091 |  |  | 638 |  |  | 1,802 |  |  | 1,313 |  |
| Amortization of intangible assets and purchase accounting effect on inventory |  | 2,011 |  |  | 1,163 |  |  | 3,515 |  |  | 2,776 |  |
| Gross profit - Non-GAAP |  | $ | 231,834 |  |  | $ | 208,674 |  |  | $ | 427,717 |  |  | $ | 379,588 |  |
| Gross margin - GAAP |  | 36.1 | % |  | 36.7 | % |  | 36.3 | % |  | 36.0 | % |
| Gross margin - Non-GAAP |  | 36.6 | % |  | 37.0 | % |  | 36.7 | % |  | 36.4 | % |
| Operating expenses - GAAP |  | $ | 168,799 |  |  | $ | 153,462 |  |  | $ | 331,042 |  |  | $ | 296,233 |  |
| Less: Share-based compensation expense |  | 9,887 |  |  | 7,812 |  |  | 19,881 |  |  | 15,654 |  |
| Less: Amortization of intangible assets and acquisition-related costs |  | 2,491 |  |  | 1,748 |  |  | 3,881 |  |  | 3,041 |  |
| Less: Change in fair value of contingent consideration for business acquisition |  | (2,930 | ) |  | — |  |  | (4,908 | ) |  | — |  |
| Less: Restructuring credits, net |  | (61 | ) |  | 74 |  |  | (116 | ) |  | (11 | ) |
| Less: Investigation and related expenses |  | — |  |  | — |  |  | — |  |  | 612 |  |
| Operating expenses - Non-GAAP |  | $ | 159,412 |  |  | $ | 143,828 |  |  | $ | 312,304 |  |  | $ | 276,937 |  |
| % of net sales - GAAP |  | 26.6 | % |  | 27.2 | % |  | 28.4 | % |  | 28.4 | % |
| % of net sales - Non - GAAP |  | 25.1 | % |  | 25.5 | % |  | 26.8 | % |  | 26.5 | % |
| Operating income - GAAP |  | $ | 59,933 |  |  | $ | 53,411 |  |  | $ | 91,358 |  |  | $ | 79,266 |  |
| Share-based compensation expense |  | 10,978 |  |  | 8,450 |  |  | 21,683 |  |  | 16,967 |  |
| Amortization of intangible assets |  | 3,645 |  |  | 2,159 |  |  | 6,238 |  |  | 3,867 |  |
| Purchase accounting effect on inventory |  | 114 |  |  | — |  |  | 114 |  |  | 703 |  |
| Acquisition-related costs |  | 741 |  |  | 752 |  |  | 1,042 |  |  | 1,247 |  |
| Change in fair value of contingent consideration for business acquisition |  | (2,930 | ) |  | — |  |  | (4,908 | ) |  | — |  |
| Restructuring credits, net |  | (61 | ) |  | 74 |  |  | (116 | ) |  | (11 | ) |
| Investigation and related expenses |  | — |  |  | — |  |  | — |  |  | 612 |  |
| Operating income - Non - GAAP |  | $ | 72,420 |  |  | $ | 64,846 |  |  | $ | 115,411 |  |  | $ | 102,651 |  |
| % of net sales - GAAP |  | 9.4 | % |  | 9.5 | % |  | 7.8 | % |  | 7.6 | % |
| % of net sales - Non - GAAP |  | 11.4 | % |  | 11.5 | % |  | 9.9 | % |  | 9.8 | % |
| Net income - GAAP |  | $ | 57,353 |  |  | $ | 47,045 |  |  | $ | 94,360 |  |  | $ | 68,986 |  |
| Share-based compensation expense |  | 10,978 |  |  | 8,450 |  |  | 21,683 |  |  | 16,967 |  |
| Amortization of intangible assets |  | 3,645 |  |  | 2,159 |  |  | 6,238 |  |  | 3,867 |  |
| Purchase accounting effect on inventory |  | 114 |  |  | — |  |  | 114 |  |  | 703 |  |
| Acquisition-related costs |  | 741 |  |  | 752 |  |  | 1,042 |  |  | 1,247 |  |
| Change in fair value of contingent consideration for business acquisition |  | (2,930 | ) |  | — |  |  | (4,908 | ) |  | — |  |
| Restructuring credits, net |  | (61 | ) |  | 74 |  |  | (116 | ) |  | (11 | ) |
| Investigation and related expenses |  | — |  |  | — |  |  | — |  |  | 612 |  |
| Gain on investments in privately held companies |  | (695 | ) |  | (171 | ) |  | (436 | ) |  | (172 | ) |
| Non-GAAP income tax adjustment |  | (1,890 | ) |  | (379 | ) |  | (10,982 | ) |  | (1,054 | ) |
| Net income - Non - GAAP |  | $ | 67,255 |  |  | $ | 57,930 |  |  | $ | 106,995 |  |  | $ | 91,145 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.34 |  |  | $ | 0.28 |  |  | $ | 0.56 |  |  | $ | 0.42 |  |
| Diluted - Non - GAAP |  | $ | 0.40 |  |  | $ | 0.35 |  |  | $ | 0.63 |  |  | $ | 0.55 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non - GAAP |  | 169,078 |  |  | 165,549 |  |  | 168,710 |  |  | 164,926 |  |

[0001032975-17-000043:8k_2_02:36]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS * |
| (In thousands) - unaudited |  |  |  |  |  |  |  |  |
| SHARE-BASED COMPENSATION EXPENSE |  | Three Months Ended |  | Six Months Ended |
|  |  | September 30, |  | September 30, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 1,091 |  |  | $ | 638 |  |  | $ | 1,802 |  |  | $ | 1,313 |  |
| Marketing and selling |  | 4,343 |  |  | 3,244 |  |  | 8,724 |  |  | 6,681 |  |
| Research and development |  | 1,633 |  |  | 917 |  |  | 3,176 |  |  | 1,831 |  |
| General and administrative |  | 3,911 |  |  | 3,651 |  |  | 7,981 |  |  | 7,142 |  |
| Total share-based compensation expense |  | 10,978 |  |  | 8,450 |  |  | 21,683 |  |  | 16,967 |  |
| Income tax benefit |  | (3,677 | ) |  | (1,886 | ) |  | (14,959 | ) |  | (3,701 | ) |
| Total share-based compensation expense, net of income tax |  | $ | 7,301 |  |  | $ | 6,564 |  |  | $ | 6,724 |  |  | $ | 13,266 |  |

[0001032975-17-000043:8k_2_02:37]
*  Note: These preliminary results for the three and six months ended September 30, 2017 are subject to adjustments, including potential adjustments, which we currently estimate not to be material, as we continue to verify information provided by a new third-party North American logistics service provider and distribution center added during the latter half of the second quarter of Fiscal Year 2018 and subsequent events (as required pursuant to applicable accounting rules) that may occur through the date of filing our Quarterly Report on Form 10-Q for the quarter ended September 30, 2017 with the SEC (the “10-Q”).  Upon completion of our additional work to verify such information, the completed financial information for the three and six months ended September 30, 2017 will need to be reviewed by our independent registered public accounting firm prior to filing the 10-Q with the SEC and our semi-annual report with the SIX Swiss Exchange.  We are working to complete and file all periodic reports within the applicable filing deadlines of the SEC and the SIX Swiss Exchange.

[0001032975-17-000043:8k_2_02:38]
(A) Preliminary valuation from the business acquisition

[0001032975-17-000043:8k_2_02:39]
The preliminary fair value of assets acquired and liabilities assumed from the business acquisition during the current period is included in the tables. The fair value of identifiable intangible assets acquired was based on estimates and assumptions made by us at the time of the acquisition. As additional information becomes available, such as finalization of purchase price adjustment and the finalization of the estimated fair value of the assets acquired and liabilities assumed, we may revise our preliminary or interim estimated fair value of the assets acquired and liabilities assumed during the remainder of the measurement periods (which will not exceed 12 months from the acquisition dates). Any such revisions or changes may be material, and may have a material impact over our financial condition and results of operations.

[0001032975-17-000043:8k_2_02:40]
(B) Non-GAAP Financial Measures

[0001032975-17-000043:8k_2_02:41]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-17-000043:8k_2_02:42]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter ended September 30, 2017, we excluded items in the following general categories, each of which are described below:

[0001032975-17-000043:8k_2_02:43]
Share-based compensation expenses. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis

[0001032975-17-000043:8k_2_02:44]
consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-17-000043:8k_2_02:45]
Amortization of intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our gross profit,  operating expenses, and financial results from period to period.

[0001032975-17-000043:8k_2_02:46]
Purchase accounting effect on inventory. Business combination accounting principles require us to measure acquired inventory at fair value. The fair value of inventory reflects the acquired company’s cost of manufacturing plus a portion of the expected profit margin. The non-GAAP adjustment excludes the expected profit margin component that is recorded under business combination accounting principles associated with our business acquisitions. We believe the adjustment is useful to investors because such charges are not reflective of our ongoing operations.

[0001032975-17-000043:8k_2_02:47]
Acquisition-related costs and change in fair value of contingent consideration for business acquisition.  We incurred expenses and credits in connection with our acquisitions which we generally would not have otherwise incurred in the periods presented as a part of our continuing operations. Acquisition related costs include all incremental expenses incurred to effect a business combination. Fair value of contingent consideration is associated with our estimates of the value of earn-outs in connection with certain acquisitions. We believe that providing the non-GAAP measures excluding these costs and credits, as well as the GAAP measures, assists our investors because such costs are not reflective of our ongoing operating results.

[0001032975-17-000043:8k_2_02:48]
Restructuring charges (credits). These expenses are associated with re-aligning our business strategies based on current economic conditions. We have undertaken several restructuring plans in recent years. In connection with our restructuring initiatives, we incurred restructuring charges related to employee terminations, facility closures and early cancellation of certain contracts. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges (credits) are not reflective of our ongoing operating results in the current period.

[0001032975-17-000043:8k_2_02:49]
Gain (loss) on investments in privately held companies. We recognized gain (loss) related our investments in various privately-held companies, which varies depending on the operational and financial performance of the privately-held companies in which we invested. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-17-000043:8k_2_02:50]
Investigation and related expenses.  These expenses are forensic accounting, audit, consulting and legal fees related to the Audit Committee’s investigation and the formal investigation by and settlement with the Securities and Exchange Commission (SEC), together with accruals based on settlement with the SEC. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-17-000043:8k_2_02:51]
Non-GAAP income tax adjustment.  Non-GAAP income tax adjustment primarily measures the income tax effect of non-GAAP adjustments excluded above and other events; the determination of which is based upon the nature of the underlying items, the mix of income and losses in jurisdictions and the relevant tax rates in which we operate.

[0001032975-17-000043:8k_2_02:52]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.

[0001032975-17-000043:8k_2_02:53]
Additional Supplemental Financial Information - Constant Currency

[0001032975-17-000043:8k_2_02:54]
In addition, Logitech presents percentage sales growth in constant currency to show performance unaffected by fluctuations in currency exchange rates.  Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales.
