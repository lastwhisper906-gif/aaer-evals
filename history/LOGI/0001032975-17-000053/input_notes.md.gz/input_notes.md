# LOGI notes — 0001032975-17-000053


## logi:ScheduleOfBalanceSheetComponentsAssetsTableTextBlock

[0001032975-17-000053:notes:1]
The following table presents the components of certain balance sheet asset amounts as of September 30 and March 31, 2017 (in thousands):

[0001032975-17-000053:notes:2]
|  |  | September 30,2017 |  | March 31,2017 |
| Accounts receivable, net: |  |  |  |  |  |  |
| Accounts receivable |  | $ | 529,842 |  |  | $ | 395,754 |  |
| Allowance for doubtful accounts |  | (229 | ) |  | (607 | ) |
| Allowance for sales returns |  | (21,712 | ) |  | (18,800 | ) |
| Allowance for cooperative marketing arrangements |  | (28,758 | ) |  | (28,022 | ) |
| Allowance for customer incentive programs |  | (70,413 | ) |  | (60,857 | ) |
| Allowance for pricing programs |  | (130,891 | ) |  | (102,289 | ) |
|  |  | $ | 277,839 |  |  | $ | 185,179 |  |
| Inventories: |  |  |  |  |  |  |
| Raw materials |  | $ | 46,405 |  |  | $ | 30,582 |  |
| Finished goods |  | 284,017 |  |  | 222,819 |  |
|  |  | $ | 330,422 |  |  | $ | 253,401 |  |
| Other current assets: |  |  |  |  |  |  |
| Value-added tax receivables |  | $ | 23,693 |  |  | $ | 23,132 |  |
| Prepaid expenses and other assets |  | 24,028 |  |  | 18,600 |  |
|  |  | $ | 47,721 |  |  | $ | 41,732 |  |
| Property, plant and equipment, net: |  |  |  |  |  |  |
| Property, plant and equipment at cost |  | $ | 359,333 |  |  | $ | 348,760 |  |
| Less: accumulated depreciation and amortization |  | (271,978 | ) |  | (263,352 | ) |
|  |  | $ | 87,355 |  |  | $ | 85,408 |  |
| Other assets: |  |  |  |  |  |  |
| Deferred tax assets |  | $ | 103,071 |  |  | $ | 57,303 |  |
| Trading investments for deferred compensation plan |  | 17,583 |  |  | 15,043 |  |
| Investments in privately held companies |  | 11,495 |  |  | 10,776 |  |
| Other assets |  | 5,995 |  |  | 4,997 |  |
|  |  | $ | 138,144 |  |  | $ | 88,119 |  |


## logi:ScheduleOfBalanceSheetComponentsLiabilityTableTextBlock

[0001032975-17-000053:notes:3]
The following table presents the components of certain balance sheet liability amounts as of September 30 and March 31, 2017 (in thousands):

[0001032975-17-000053:notes:4]
|  |  | September 30,2017 |  | March 31,2017 |
| Accrued and other current liabilities: |  |  |  |  |  |  |
| Accrued personnel expenses |  | $ | 68,645 |  |  | $ | 88,346 |  |
| Indirect customer incentive programs |  | 41,710 |  |  | 36,409 |  |
| Warranty accrual |  | 14,567 |  |  | 13,424 |  |
| Employee benefit plan obligation |  | 1,841 |  |  | 1,266 |  |
| Income taxes payable |  | 6,950 |  |  | 6,232 |  |
| Contingent consideration for business acquisition - current portion |  | 5,000 |  |  | 2,889 |  |
| Other current liabilities |  | 90,463 |  |  | 83,707 |  |
|  |  | $ | 229,176 |  |  | $ | 232,273 |  |
| Other non-current liabilities: |  |  |  |  |  |  |
| Warranty accrual |  | $ | 9,782 |  |  | $ | 8,487 |  |
| Obligation for deferred compensation plan |  | 17,583 |  |  | 15,043 |  |
| Employee benefit plan obligation |  | 43,057 |  |  | 41,998 |  |
| Deferred tax liability |  | 1,789 |  |  | 1,789 |  |
| Contingent consideration for business acquisition - non-current portion |  | — |  |  | 7,019 |  |
| Other non-current liabilities |  | 8,692 |  |  | 9,355 |  |
|  |  | $ | 80,903 |  |  | $ | 83,691 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001032975-17-000053:notes:5]
[same as prior period, unchanged from 0001032975-17-000037:notes:5]

[0001032975-17-000053:notes:6]
[same as prior period, unchanged from 0001032975-17-000037:notes:6]

[0001032975-17-000053:notes:7]
[same as prior period, unchanged from 0001032975-17-000037:notes:7]

[0001032975-17-000053:notes:8]
[same as prior period, unchanged from 0001032975-17-000037:notes:8]

[0001032975-17-000053:notes:9]
[same as prior period, unchanged from 0001032975-17-000037:notes:9]

[0001032975-17-000053:notes:10]
Business Acquisition

[0001032975-17-000053:notes:11]
In August 2017, the Company acquired the ASTRO Gaming business. See "Note 2 - Business Acquisition" for more information.

[0001032975-17-000053:notes:12]
[same as prior period, unchanged from 0001032975-17-000037:notes:10]

[0001032975-17-000053:notes:13]
[same as prior period, unchanged from 0001032975-17-000037:notes:11]

[0001032975-17-000053:notes:14]
In the opinion of management, these condensed consolidated financial statements include all adjustments, consisting of only normal and recurring adjustments, necessary and in all material aspects, for a fair statement of the results of operations, comprehensive income, financial position, cash flows and changes in shareholders' equity for the periods presented. Operating results for the three and six months ended September 30, 2017 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2018, or any future periods.

[0001032975-17-000053:notes:15]
[same as prior period, unchanged from 0001032975-17-000037:notes:13]

[0001032975-17-000053:notes:16]
Certain amounts from the comparative period in the accompanying unaudited condensed consolidated financial statements have been reclassified to conform to the condensed consolidated financial statement presentation as of and for the three and six months ended September 30, 2017.

[0001032975-17-000053:notes:17]
[same as prior period, unchanged from 0001032975-17-000037:notes:15]

[0001032975-17-000053:notes:18]
Other than the recent accounting pronouncements adopted, discussed below, there have been no substantial changes in the Company’s significant accounting policies during the six months ended September 30, 2017 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2017.

[0001032975-17-000053:notes:19]
[same as prior period, unchanged from 0001032975-17-000037:notes:17]

[0001032975-17-000053:notes:20]
[same as prior period, unchanged from 0001032975-17-000037:notes:18]

[0001032975-17-000053:notes:21]
[same as prior period, unchanged from 0001032975-17-000037:notes:19]

[0001032975-17-000053:notes:22]
In July 2015, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2015-11, "Simplifying the Measurement of Inventory (Topic 330)" ("ASU 2015-11"). Topic 330, Inventory, previously required an entity to measure inventory at the lower of cost or market, with market value represented by replacement cost, net realizable value or net realizable value less a normal profit margin. ASU 2015-11 requires an entity to measure inventory at the lower of cost or net realizable value and is effective for fiscal years beginning after December 15, 2016. The Company adopted this standard effective April 1, 2017, which has not had a material impact on its consolidated financial statements.

[0001032975-17-000053:notes:23]
In March 2016, the FASB issued ASU 2016-09, "Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting" ("ASU 2016-09"). ASU 2016-09 simplifies several aspects of the accounting for share-based payments, including immediate recognition of all excess tax benefits and deficiencies in the income statement, changing the threshold to qualify for equity classification up to the employees' maximum statutory tax rates, allowing an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures as they occur, and clarifying the classification on the statement of cash flows for the excess tax benefits and employee taxes paid when an employer withholds shares for tax withholding purposes. ASU 2016-09 is effective for fiscal years beginning after December 15, 2016. The Company adopted this standard effective April 1, 2017. Changes to the statements of cash flows related to the classification of excess tax benefits were implemented on a retroactive basis and accordingly, to conform to the current year presentation, the Company reclassified $4.1 million of excess tax benefits previously reported under financing activities to operating activities for the six months ended September 30, 2016 on its condensed consolidated statements of cash flows. Under the new standard, the Company accounts for forfeitures as they occur. The change in accounting for forfeitures resulted in a cumulative-effect adjustment to decrease retained earnings as of March 31, 2017 by $3.3 million. The Company further recognized a cumulative-effect adjustment to increase retained earnings as of March 31, 2017 by $57.2 million upon adoption of the new guidance to account for gross excess tax benefits of $75.2 million that were previously not recognized because the related tax deduction had not reduced current income taxes, offset by a valuation allowance of $18.0 million to reduce the deferred tax assets to amounts that are more likely than not to be realized.

[0001032975-17-000053:notes:24]
In January 2017, the FASB issued ASU 2017-04, "Simplifying the Test for Goodwill Impairment (Topic

[0001032975-17-000053:notes:25]
350)" ("ASU 2017-04"), which removes Step 2 from the goodwill impairment test. ASU 2017-04 is effective for annual or any interim goodwill impairments in annual periods beginning December 15, 2019, with early adoption permitted. The Company adopted this standard effective April 1, 2017, which has not had a material impact on its consolidated financial statements.

[0001032975-17-000053:notes:26]
In May 2017, the FASB issued ASU 2017-09, "Compensation-Stock Compensation (Topic 718): Scope of

[0001032975-17-000053:notes:27]
Modification Accounting" ("ASU 2017-09"), which provides guidance about which changes to the terms or conditions

[0001032975-17-000053:notes:28]
of a share-based payment award require an entity to apply modification accounting in Topic 718. ASU 2017-09 is

[0001032975-17-000053:notes:29]
effective for annual periods beginning after December 15, 2017, with early adoption permitted, including adoption in any interim period for which financial statements have not yet been issued. The Company adopted this standard effective April 1, 2017, which has not had a material impact on its consolidated financial statements.

[0001032975-17-000053:notes:30]
Recent Accounting Pronouncements to be Adopted

[0001032975-17-000053:notes:31]
In May 2014, the FASB issued ASU No. 2014-09, "Revenue from Contracts with Customers (Topic 606)" ("ASU 2014-09") which supersedes the revenue recognition requirements under ASC 605, Revenue Recognition. ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. Under the new model, recognition of revenue occurs when a customer obtains control of promised goods or services in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The new standard requires reporting companies to disclose the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The new standard will become effective for the Company on April 1, 2018. The standard allows for either a "full retrospective" adoption, meaning the standard is applied to all of the periods presented subject to practical expedients, or a "modified retrospective" adoption, meaning the standard is applied only in the initial year, or interim period in year of initial application with a cumulative adjustment to opening retained earnings for existing contracts. The Company currently expects to utilize the modified retrospective transition method. The Company continues to evaluate the impact this new standard could have on the current contracts with customers and the accruals of various sales and marketing programs the Company offers and on the related breakage estimates. The Company has not completed its analysis of the impact to its consolidated financial statements and this information will not be available until the Company completes its full assessment. It is possible that during the fiscal year 2018, the Company may identify certain areas which may result in material impact on the Company’s consolidated financial statements, or the Company may revise its adoption method.

[0001032975-17-000053:notes:32]
In January 2016, the FASB issued ASU 2016-01, "Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10)" ("ASU 2016-01"). ASU 2016-01 is effective for annual periods beginning after December 15, 2017, including interim periods within those annual periods, with early adoption permitted. The Company does not believe that the adoption of ASU 2016-01 will have a material impact on its consolidated financial statements and will adopt this standard effective April 1, 2018.

[0001032975-17-000053:notes:33]
In February 2016, the FASB issued ASU 2016-02, "Leases (Topic 842)" ("ASU 2016-02"), which requires the recognition of lease assets and lease liabilities arising from operating leases in the statement of financial position. ASU 2016-02 is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years, with early adoption permitted. The Company is evaluating the full effect that ASU 2016-02 will have on its consolidated financial statements and will adopt this standard effective April 1, 2019.

[0001032975-17-000053:notes:34]
In October 2016, the FASB issued ASU 2016-16, "Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory"  ("ASU 2016-16"), which eliminates the deferral of income tax effects of intra-entity asset transfers until the transferred asset is sold to an unrelated party or recovered through use. However, this standard does not apply to intra-entity transfer of inventory.  ASU 2016-16 is effective for annual periods beginning after December 15, 2017, including interim periods within those annual periods, with early adoption permitted but only in the first interim period of an annual period.  The cumulative effect of change on equity upon adoption is to be quantified under the modified retrospective approach and recorded as of the beginning of the period of adoption.  The Company is evaluating the full effect that ASU 2016-16 will have on its consolidated financial statements and will adopt this standard effective April 1, 2018.

[0001032975-17-000053:notes:35]
In December 2016, the FASB issued ASU 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash" ("ASU 2016-18"), which requires that a statement of cash flows explains the change during the period in the total of cash, cash equivalents, and amounts generally described as restricted cash or restricted cash equivalents.  ASU 2016-18 is effective for annual periods beginning after December 15, 2017, including interim periods within those annual periods, with early adoption permitted. The adoption of this standard should be applied using a retrospective transition method to each period presented. The Company does not expect the adoption of ASU 2016-18 will have a material impact on its consolidated financial statements and will adopt this standard effective April 1, 2018.

[0001032975-17-000053:notes:36]
In January 2017, the FASB issued ASU 2017-01, "Business Combination  (ASC Topic 805): Clarifying the Definition of a Business" ("ASU 2017-01"), which changes the definition of a business to assist with evaluating when a set of transferred assets and activities is a business. ASU 2017-01 is effective for annual or any interim goodwill impairments in annual periods beginning after December 15, 2017, with early adoption permitted. The Company does not expect the adoption of ASU 2017-01 will have a material impact on its condensed consolidated financial statements and will adopt this standard effective April 1, 2018.

[0001032975-17-000053:notes:37]
In March 2017, the FASB issued ASU 2017-07, "Compensation-Retirement Benefit (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost" ("ASU 2017-07"), which requires that the Company disaggregate the service cost component from the other components of net benefit cost, and also provides guidance on how to present the service cost component and the other components of net benefit cost in the income statement and allow only the service cost component of net benefit cost to be eligible for capitalization. ASU 2017-07 is effective for annual periods beginning after December 15, 2017, including interim periods within those annual periods, with early adoption permitted. The Company does not expect the adoption of ASU 2017-07 will have a material impact on its consolidated financial statements and will adopt this standard effective April 1, 2018.

[0001032975-17-000053:notes:38]
In August 2017, the FASB issued ASU 2017-12, "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities" ("ASU 2017-12"), which improves the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements and simplifies the application of the hedge accounting guidance. ASU 2017-12 is effective for annual periods beginning after December 15, 2018, including interim periods within those annual periods, with early adoption permitted. The Company does not expect the adoption of ASU 2017-12 will have a material impact on its consolidated financial statements and is currently assessing the timing of adoption.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001032975-17-000053:notes:39]
ASTRO Acquisition

[0001032975-17-000053:notes:40]
On August 11, 2017 (the "Acquisition Date"), the Company acquired certain assets and liabilities constituting the ASTRO Gaming business ("ASTRO") from AG Acquisition Corporation for a preliminary purchase price of $85.0 million in cash (the "ASTRO Acquisition"). ASTRO is a leading console gaming brand with a history of producing award-winning headsets for professional gamers and enthusiasts. ASTRO provides a strong growth platform in the console gaming accessories market.

[0001032975-17-000053:notes:41]
ASTRO meets the definition of a business, and its acquisition is accounted for using the acquisition method. The following table summarizes the preliminary estimated fair values of the assets acquired and liabilities assumed at the Acquisition Date (in thousands):

[0001032975-17-000053:notes:42]
|  |  | Estimated Fair Value |
| Inventories |  | $ | 10,331 |  |
| Property, plant, and equipment |  | 2,760 |  |
| Intangible assets |  | 52,520 |  |
| Other assets |  | 605 |  |
| Total identifiable assets acquired |  | $ | 66,216 |  |
| Accrued liabilities |  | (2,602 | ) |
| Net identifiable assets acquired |  | $ | 63,614 |  |
| Goodwill |  | 21,386 |  |
| Net assets acquired |  | $ | 85,000 |  |

[0001032975-17-000053:notes:43]
Goodwill related to the transaction is primarily attributable to opportunities and economies of scale from combining the operations and technologies of Logitech and ASTRO. Goodwill is expected to be deductible for tax purposes.

[0001032975-17-000053:notes:44]
The fair value of the inventory acquired is estimated at its net realizable value, which uses the estimated selling prices, less the cost of disposal and a reasonable profit allowance for the selling efforts. The difference between the fair value of the inventories and the amount recognized by the acquiree immediately before the acquisition date is $0.8 million, which will be recognized in "amortization of intangibles assets and purchase accounting effect on inventory" in the condensed consolidated statements of operations upon the sale of the acquired inventory.

[0001032975-17-000053:notes:45]
The Company included ASTRO's estimated fair value of assets acquired and liabilities assumed in its condensed consolidated balance sheets beginning the Acquisition Date. The results of operations for ASTRO for this partial quarter have been included in, but are not material to, the Company's condensed consolidated statements of operations from the Acquisition Date. Pro forma results of operations for the ASTRO Acquisition have not been presented because they are not material to the condensed consolidated statements of operations.

[0001032975-17-000053:notes:46]
The following table sets forth the components of identifiable intangible assets acquired at their estimated fair values and their estimated useful lives as of the Acquisition Date (Dollars in thousands):

[0001032975-17-000053:notes:47]
|  | Preliminary Fair Value |  | Estimated Useful Life (years) |
| Developed technology | $ | 12,540 |  |  | 4.0 |
| Customer relationships | 33,100 |  |  | 8.0 |
| Trade name | 6,880 |  |  | 6.0 |
| Total intangible assets acquired | $ | 52,520 |  |  | 6.8 |

[0001032975-17-000053:notes:48]
Intangible assets acquired as a result of the ASTRO Acquisition are being amortized over their estimated useful lives using the straight-line method of amortization. Amortization of acquired developed technology of $0.4 million during the three months ended September 30, 2017 is included in "amortization of intangible assets and purchase accounting effect of inventory" in the gross profit of the condensed consolidated statements of operations. Amortization of the acquired customer relationships and trade name of $0.7 million during the three months ended September 30, 2017 is included in "amortization of intangible assets and acquisition-related costs" in the operating expense of the condensed consolidated statements of operations.

[0001032975-17-000053:notes:49]
Developed technology relates to existing ASTRO gaming headset products. The economic useful life was determined based on the technology cycle related to developed technology of existing products, as well as the cash flows anticipated over the forecasted periods.

[0001032975-17-000053:notes:50]
Customer relationships represent the fair value of future projected revenue that will be derived from sales of products to existing customers of ASTRO. The economic useful life was determined based on historical customer turnover rates and industry benchmarks.

[0001032975-17-000053:notes:51]
Trade name relates to the “ASTRO” trade name. The economic useful life was determined based on the expected life of the trade name and the cash flows anticipated over the forecasted periods.

[0001032975-17-000053:notes:52]
The fair value of developed technology and trade name were estimated using the relief-from-royalty method, an income approach (Level 3), which estimates the cost savings that accrue to the owner of the intangible assets that would otherwise be payable as royalties or license fees on revenues earned through the use of the asset. A royalty rate is applied to the projected revenues associated with the intangible assets to determine the amount of savings, which is then discounted to determine the fair value. The developed technology and trade name were valued using royalty rates of 10% and 2%, respectively, and both were discounted at a rate of 13%.

[0001032975-17-000053:notes:53]
The fair value of customer relationships was estimated using the excess earnings method, an income approach (Level 3), which converts projected revenues and costs into cash flows. To reflect the fact that certain other assets contributed to the cash flows generated, the returns for these contributory assets were removed to arrive at estimated cash flows solely attributable to the customer relationships, which were discounted at a rate of 13%.

[0001032975-17-000053:notes:54]
The Company believes the preliminary value of purchased intangible assets recorded above represent the fair values of, and approximate the amounts a market participant would pay for, these intangible assets as of the Acquisition Date.

[0001032975-17-000053:notes:55]
The Company incurred acquisition-related costs for the ASTRO Acquisition of approximately $0.7 million and $1.0 million for the three and six months ended September 30, 2017, respectively. The acquisition-related costs are included in "amortization of intangible assets and acquisition-related costs" in the operating expenses of the condensed consolidated statements of operations.

[0001032975-17-000053:notes:56]
The fair value of identifiable intangible assets acquired was based on estimates and assumptions made by management at the time of the acquisition. As additional information becomes available, such as finalization of the estimated fair value of the assets acquired and liabilities assumed, and any dispute that may affect the total consideration transferred, the Company may revise its preliminary estimates of fair values during the remainder of the measurement periods (which will not exceed 12 months from the Acquisition Date). Any such revisions or changes may be material as we finalize the fair values of the tangible and intangible assets acquired and liabilities assumed.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001032975-17-000053:notes:57]
Commitments and Contingencies

[0001032975-17-000053:notes:58]
Product Warranties

[0001032975-17-000053:notes:59]
All of the Company’s peripherals products sold are covered by warranty to be free from defects in material and workmanship. The warranty period varies by product and by region.

[0001032975-17-000053:notes:60]
Changes in the Company’s warranty liability for the three and six months ended September 30, 2017 and 2016 were as follows (in thousands):

[0001032975-17-000053:notes:61]
|  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Beginning of the period | $ | 22,056 |  |  | $ | 21,752 |  |  | $ | 21,911 |  |  | $ | 20,380 |  |
| Assumed from business acquisition | 1,230 |  |  | 150 |  |  | 1,230 |  |  | 1,963 |  |
| Provision | 5,414 |  |  | 3,163 |  |  | 9,715 |  |  | 6,340 |  |
| Settlements | (4,611 | ) |  | (3,452 | ) |  | (9,179 | ) |  | (6,880 | ) |
| Currency translation | 260 |  |  | (1 | ) |  | 672 |  |  | (191 | ) |
| End of the period | $ | 24,349 |  |  | $ | 21,612 |  |  | $ | 24,349 |  |  | $ | 21,612 |  |

[0001032975-17-000053:notes:62]
Guarantees

[0001032975-17-000053:notes:63]
Logitech Europe S.A., one of our wholly-owned subsidiaries, guaranteed payments of certain third-party contract manufacturers’ purchase obligations. As of September 30, 2017, the maximum amount of this guarantee was $3.8 million, of which $1.4 million of guaranteed purchase obligations were outstanding.

[0001032975-17-000053:notes:64]
Indemnifications

[0001032975-17-000053:notes:65]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2017, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.

[0001032975-17-000053:notes:66]
The Company also indemnifies its current and former directors and certain of its current and former officers. Certain costs incurred for providing such indemnification may be recoverable under various insurance policies. The Company is unable to reasonably estimate the maximum amount that could be payable under these arrangements because these exposures are not limited, the obligations are conditional in nature and the facts and circumstances involved in any situation that might arise are variable.

[0001032975-17-000053:notes:67]
The stock purchase agreement entered on December 28, 2015 in connection with the investment by three venture capital firms in Lifesize contains representations, warranties and covenants of Logitech and Lifesize, Inc. to the Investors. Logitech has agreed, subject to certain limitations, to indemnify the Investors and certain persons related to the Investors for certain losses resulting from breaches of or inaccuracies in such representations, warranties and covenants as well as certain other obligations, including third-party expenses, restructuring costs and pre-closing tax obligations of Lifesize.

[0001032975-17-000053:notes:68]
Legal Proceedings

[0001032975-17-000053:notes:69]
From time to time the Company is involved in claims and legal proceedings that arise in the ordinary course of its business. The Company is currently subject to several such claims and a small number of legal proceedings. The Company believes that these matters lack merit and intends to vigorously defend against them. Based on currently available information, the Company does not believe that resolution of pending matters will have a material adverse effect on its financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that the Company’s defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on the Company’s business, financial condition, cash flows or results of operations in a particular period. Any claims or proceedings against the Company, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain a necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect the Company’s business.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001032975-17-000053:notes:70]
[same as prior period, unchanged from 0001032975-17-000037:notes:48]

[0001032975-17-000053:notes:71]
[same as prior period, unchanged from 0001032975-17-000037:notes:49]

[0001032975-17-000053:notes:72]
As of September 30, 2017, the Company offers the 2006 ESPP (2006 Employee Share Purchase Plan (Non-U.S.)), the 1996 ESPP (1996 Employee Share Purchase Plan (U.S.)), the 2006 Plan (2006 Stock Incentive Plan) and the 2012 Plan (2012 Stock Inducement Equity Plan).

[0001032975-17-000053:notes:73]
The following table summarizes the share-based compensation expense and total income tax benefit recognized for share-based awards for the three and six months ended September 30, 2017 and 2016 (in thousands):

[0001032975-17-000053:notes:74]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Cost of goods sold |  | $ | 1,091 |  |  | $ | 638 |  |  | $ | 1,802 |  |  | $ | 1,313 |  |
| Marketing and selling |  | 4,343 |  |  | 3,244 |  |  | 8,724 |  |  | 6,681 |  |
| Research and development |  | 1,633 |  |  | 917 |  |  | 3,176 |  |  | 1,831 |  |
| General and administrative |  | 3,911 |  |  | 3,651 |  |  | 7,981 |  |  | 7,142 |  |
| Total share-based compensation expense |  | 10,978 |  |  | 8,450 |  |  | 21,683 |  |  | 16,967 |  |
| Income tax benefit |  | (3,677 | ) |  | (1,886 | ) |  | (14,959 | ) |  | (3,701 | ) |
| Total share-based compensation expense, net of income tax |  | $ | 7,301 |  |  | $ | 6,564 |  |  | $ | 6,724 |  |  | $ | 13,266 |  |

[0001032975-17-000053:notes:75]
[same as prior period, unchanged from 0001032975-17-000037:notes:53]

[0001032975-17-000053:notes:76]
As of September 30, 2017 and 2016, the Company capitalized $0.8 million and $0.4 million of stock-based compensation expense to inventory, respectively.

[0001032975-17-000053:notes:77]
[same as prior period, unchanged from 0001032975-17-000037:notes:55]

[0001032975-17-000053:notes:78]
Certain of the Company’s subsidiaries sponsor defined benefit pension plans or non-retirement post-employment benefits covering substantially all of their employees. Benefits are provided based on employees’ years of service and earnings, or in accordance with applicable employee benefit regulations. The Company’s practice is to fund amounts sufficient to meet the requirements set forth in the applicable employee benefit and tax regulations. The cost recorded of $2.3 million and $2.8 million for the three months ended September 30, 2017 and 2016, respectively, and $4.6 million and $5.6 million for the six months ended September 30, 2017 and 2016, respectively, was primarily related to service costs.


## us-gaap:DebtDisclosureTextBlock

[0001032975-17-000053:notes:79]
Financing Arrangements

[0001032975-17-000053:notes:80]
The Company had several uncommitted, unsecured bank lines of credit aggregating $68.2 million as of September 30, 2017. There are no financial covenants under these lines of credit with which the Company must comply. As of September 30, 2017, the Company had outstanding bank guarantees of $39.8 million under these lines of credit. There was no borrowing outstanding under these lines of credit as of September 30, 2017 or March 31, 2017.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001032975-17-000053:notes:81]
[same as prior period, unchanged from 0001032975-17-000037:notes:59]

[0001032975-17-000053:notes:82]
Under certain agreements with the respective counterparties to the Company’s derivative contracts, subject to applicable requirements, the Company is allowed to net settle transactions of the same type with a single net amount payable by one party to the other. However, the Company presents its derivative assets and derivative liabilities on a gross basis on the condensed consolidated balance sheets as of September 30, 2017 and March 31, 2017.

[0001032975-17-000053:notes:83]
The fair values of the Company’s derivative instruments not designated as hedging instruments were not material as of September 30, 2017 or March 31, 2017. The following table presents the fair values of the Company’s derivative instruments designated as hedging instruments on a gross basis in other current assets or accrued and other current liabilities on its condensed consolidated balance sheets as of September 30, 2017 and March 31, 2017 (in thousands):

[0001032975-17-000053:notes:84]
|  |  | Derivatives |
|  |  | Asset |  | Liability |
|  |  | September 30,2017 |  | March 31,2017 |  | September 30,2017 |  | March 31,2017 |
| Cash flow hedges |  | $ | 165 |  |  | $ | 48 |  |  | $ | 38 |  |  | $ | 402 |  |

[0001032975-17-000053:notes:85]
The amount of gain (loss) recognized on derivatives not designated as hedging instruments were not material in all periods presented herein. The following table presents the amounts of gains (losses) on the Company’s derivative instruments designated as hedging instruments and their locations on its condensed consolidated statements of operations and condensed consolidated statements of comprehensive income for the three and six months ended September 30, 2017 and 2016 (in thousands):

[0001032975-17-000053:notes:86]
|  |  | Three Months EndedSeptember 30, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of LossReclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Cash flow hedges |  | $ | (2,140 | ) |  | $ | 564 |  |  | $ | 2,596 |  |  | $ | 155 |  |

[0001032975-17-000053:notes:87]
|  |  | Six Months Ended September 30, |
|  |  | Amount of Gain (Loss)Deferred as a Component of AccumulatedOther Comprehensive Loss |  | Amount of LossReclassified from Accumulated Other Comprehensive Loss to Costs of Goods Sold |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Cash flow hedges |  | $ | (5,349 | ) |  | $ | 1,529 |  |  | $ | 3,129 |  |  | $ | 895 |  |

[0001032975-17-000053:notes:88]
[same as prior period, unchanged from 0001032975-17-000037:notes:65]

[0001032975-17-000053:notes:89]
The Company enters into cash flow hedge contracts to protect against exchange rate exposure of forecasted inventory purchases. These hedging contracts mature within four months. Gains and losses in the fair value of the effective portion of the hedges are deferred as a component of accumulated other comprehensive loss until the hedged inventory purchases are sold, at which time the gains or losses are reclassified to cost of goods sold. Cash flows from such hedges are classified as operating activities in the condensed consolidated statements of cash flows. The notional amounts of foreign currency exchange forward contracts outstanding related to forecasted inventory purchases were $149.1 million and $59.4 million as of September 30, 2017 and March 31, 2017, respectively. The Company estimates that $2.7 million of net losses related to its cash flow hedges included in accumulated other comprehensive loss as of September 30, 2017 will be reclassified into earnings within the next 12 months.

[0001032975-17-000053:notes:90]
[same as prior period, unchanged from 0001032975-17-000037:notes:67]

[0001032975-17-000053:notes:91]
The Company also enters into foreign currency exchange forward and swap contracts to reduce the short-term effects of currency exchange rate fluctuations on certain receivables or payables denominated in currencies other than the functional currencies of its subsidiaries. These contracts generally mature within one month. The primary risk managed by using forward and swap contracts is the currency exchange rate risk. The gains or losses on these contracts are recognized in other income (expense), net in the condensed consolidated statements of operations based on the changes in fair value. The notional amounts of these contracts outstanding as of September 30, 2017 and March 31, 2017 were $95.6 million and $56.7 million, respectively. Open forward and swap contracts outstanding as of September 30, 2017 and March 31, 2017 consisted of contracts in Mexican Pesos, Japanese Yen, British Pounds, Taiwanese Dollars, Canadian Dollars, Australian Dollars and Chinese Renminbi to be settled at future dates at pre-determined exchange rates.

[0001032975-17-000053:notes:92]
[same as prior period, unchanged from 0001032975-17-000037:notes:69]


## us-gaap:EarningsPerShareTextBlock

[0001032975-17-000053:notes:93]
[same as prior period, unchanged from 0001032975-17-000037:notes:70]

[0001032975-17-000053:notes:94]
[same as prior period, unchanged from 0001032975-17-000037:notes:71]

[0001032975-17-000053:notes:95]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net Income |  | $ | 56,358 |  |  | $ | 47,045 |  |  | $ | 93,365 |  |  | $ | 68,986 |  |
| Shares used in net income per share computation: |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding - basic |  | 164,120 |  |  | 162,222 |  |  | 163,765 |  |  | 162,176 |  |
| Effect of potentially dilutive equivalent shares |  | 4,958 |  |  | 3,327 |  |  | 4,945 |  |  | 2,750 |  |
| Weighted average shares outstanding - diluted |  | 169,078 |  |  | 165,549 |  |  | 168,710 |  |  | 164,926 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.34 |  |  | $ | 0.29 |  |  | $ | 0.57 |  |  | $ | 0.43 |  |
| Diluted |  | $ | 0.33 |  |  | $ | 0.28 |  |  | $ | 0.55 |  |  | $ | 0.42 |  |

[0001032975-17-000053:notes:96]
Share equivalents attributable to outstanding stock options and restricted stock units of 0.6 million and 2.9 million for the three months ended September 30, 2017 and 2016, respectively, and 1.2 million and 3.1 million for the six months ended September 30, 2017 and 2016, respectively, were anti-dilutive and excluded from the calculation of diluted net income per share.


## us-gaap:FairValueLiabilitiesMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001032975-17-000053:notes:97]
The following table summarizes the changes in fair value of the Company’s contingent consideration balance measured with Level 3 inputs during the three and six months ended September 30, 2017 and 2016 (in thousands):

[0001032975-17-000053:notes:98]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Beginning of the period |  | $ | 7,475 |  |  | $ | 18,000 |  |  | $ | 9,908 |  |  | $ | — |  |
| Fair value of contingent consideration upon acquisition |  | — |  |  | — |  |  | — |  |  | 18,000 |  |
| Change in fair value of contingent consideration |  | (2,930 | ) |  | — |  |  | (4,908 | ) |  | — |  |
| Expected payment |  | (4,545 | ) |  | — |  |  | (5,000 | ) |  | — |  |
| End of the period |  | $ | — |  |  | $ | 18,000 |  |  | $ | — |  |  | $ | 18,000 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001032975-17-000053:notes:99]
[same as prior period, unchanged from 0001032975-17-000037:notes:77]

[0001032975-17-000053:notes:100]
[same as prior period, unchanged from 0001032975-17-000037:notes:78]

[0001032975-17-000053:notes:101]
[same as prior period, unchanged from 0001032975-17-000037:notes:79]

[0001032975-17-000053:notes:102]
[same as prior period, unchanged from 0001032975-17-000037:notes:80]

[0001032975-17-000053:notes:103]
[same as prior period, unchanged from 0001032975-17-000037:notes:81]

[0001032975-17-000053:notes:104]
[same as prior period, unchanged from 0001032975-17-000037:notes:82]

[0001032975-17-000053:notes:105]
|  |  | September 30, 2017 |  | March 31, 2017 |
|  |  | Level 1 |  | Level 2 |  | Level 3 |  | Level 1 |  | Level 2 |  | Level 3 |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 286,074 |  |  | $ | — |  |  | $ | — |  |  | $ | 448,742 |  |  | $ | — |  |  | $ | — |  |
| Time deposits included in short-term investments |  | $ | — |  |  | $ | 6,789 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Trading investments for deferred compensation plan included in other assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 3,110 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,813 |  |  | $ | — |  |  | $ | — |  |
| Mutual funds |  | 14,473 |  |  | — |  |  | — |  |  | 12,230 |  |  | — |  |  | — |  |
| Total of trading investments for deferred compensation plan |  | $ | 17,583 |  |  | $ | — |  |  | $ | — |  |  | $ | 15,043 |  |  | $ | — |  |  | $ | — |  |
| Currency exchange derivative assetsincluded in other current assets |  | $ | — |  |  | $ | 165 |  |  | $ | — |  |  | $ | — |  |  | $ | 48 |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related contingentconsideration included in accrued andother current liabilities and other non-current liabilities |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 9,908 |  |
| Currency exchange derivative liabilitiesincluded in accrued and other current liabilities |  | $ | — |  |  | $ | 107 |  |  | $ | — |  |  | $ | — |  |  | $ | 443 |  |  | $ | — |  |

[0001032975-17-000053:notes:106]
[same as prior period, unchanged from 0001032975-17-000037:notes:86]

[0001032975-17-000053:notes:107]
On April 20, 2016 (the "Jaybird Acquisition Date"), the Company acquired all of the equity interest of Jaybird, LLC (“Jaybird”). The acquisition-related contingent consideration liability arising from the Jaybird acquisition represents the future potential earn-out payments of up to $45.0 million based on the achievement of certain net revenue targets over approximately a two year period. If the net revenue targets are met, the Company will pay a maximum of $25.0 million and $20.0 million in fiscal years 2018 and 2019, respectively. The fair value of the earn-out as of the Jaybird Acquisition Date was $18.0 million, which was determined by using a Monte Carlo Simulation that includes significant unobservable inputs such as a risk-adjusted discount rate of 16% and projected net sales of Jaybird over the earn-out period. The fair value is remeasured at each reporting period at the estimated fair value based on the inputs on the date of remeasurement, with the change in fair value recognized as "change in fair value of contingent consideration for business acquisition" in the operating expense section in the condensed consolidated statements of operations. Projected net sales are based on the Company's internal projections, including analysis of the target markets. In October 2017, the Company and the sellers of Jaybird entered into an agreement fully, irrevocably and unconditionally releasing the Company from the earn-out rights and payments in exchange for $5.0 million in cash, which approximates the fair value of the contingent consideration as of September 30, 2017 and the expected cash payment is included in the accrued and other current liabilities.

[0001032975-17-000053:notes:108]
[same as prior period, unchanged from 0001032975-17-000037:notes:84]

[0001032975-17-000053:notes:109]
The marketable securities for the Company's deferred compensation plan are recorded at a fair value of $17.6 million and $15.0 million, respectively, as of September 30, 2017 and March 31, 2017, based on quoted market prices. Quoted market prices are observable inputs that are classified as Level 1 within the fair value hierarchy. Unrealized trading gains / (losses) related to trading securities for the three and six months ended September 30, 2017 and 2016 were not material and are included in other income (expense), net in the Company's condensed consolidated statements of operations.

[0001032975-17-000053:notes:110]
[same as prior period, unchanged from 0001032975-17-000037:notes:89]

[0001032975-17-000053:notes:111]
The Company’s non-marketable cost method investments, and non-financial assets, such as goodwill, intangible assets and property, plant and equipment, are recorded at fair value only upon initial recognition or if an impairment is recognized. There were no material impairments of long-lived assets during the three and six months ended September 30, 2017 or 2016.

[0001032975-17-000053:notes:112]
[same as prior period, unchanged from 0001032975-17-000037:notes:91]

[0001032975-17-000053:notes:113]
[same as prior period, unchanged from 0001032975-17-000037:notes:92]

[0001032975-17-000053:notes:114]
The aggregate recorded amount of cost method investments included in other assets as of September 30, 2017 and March 31, 2017 was $7.1 million and $7.4 million, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001032975-17-000053:notes:115]
[same as prior period, unchanged from 0001032975-17-000037:notes:94]

[0001032975-17-000053:notes:116]
The Company conducts its impairment analysis of the goodwill annually at December 31 and as necessary if changes in facts and circumstances indicate that it is more likely than not that the fair value of the Company’s reporting units may be less than its carrying amount. There have been no events or circumstances during the six months ended September 30, 2017 that have required the Company to perform an interim assessment of goodwill.

[0001032975-17-000053:notes:117]
The following table summarizes the activities in the Company’s goodwill balance during the six months ended September 30, 2017 (in thousands):

[0001032975-17-000053:notes:118]
| As of March 31, 2017 |  | $ | 249,741 |  |
| Business acquisitions (See Note 2) |  | 21,386 |  |
| Currency impact |  | 27 |  |
| As of September 30, 2017 |  | $ | 271,154 |  |

[0001032975-17-000053:notes:119]
[same as prior period, unchanged from 0001032975-17-000037:notes:98]

[0001032975-17-000053:notes:120]
|  |  | September 30, 2017 |  | March 31, 2017 |
|  |  | Gross Carrying Amount(Note 2) |  | AccumulatedAmortization |  | Net Carrying Amount |  | Gross Carrying Amount |  | AccumulatedAmortization |  | Net Carrying Amount |
| Trademark and trade names |  | $ | 23,380 |  |  | $ | (8,012 | ) |  | $ | 15,368 |  |  | $ | 16,500 |  |  | $ | (6,933 | ) |  | $ | 9,567 |  |
| Developed Technology |  | 75,825 |  |  | (46,225 | ) |  | 29,600 |  |  | 63,285 |  |  | (42,831 | ) |  | 20,454 |  |
| Customer contracts/relationships |  | 58,280 |  |  | (9,402 | ) |  | 48,878 |  |  | 25,180 |  |  | (7,637 | ) |  | 17,543 |  |
| Total |  | $ | 157,485 |  |  | $ | (63,639 | ) |  | $ | 93,846 |  |  | $ | 104,965 |  |  | $ | (57,401 | ) |  | $ | 47,564 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001032975-17-000053:notes:121]
[same as prior period, unchanged from 0001032975-17-000037:notes:100]

[0001032975-17-000053:notes:122]
[same as prior period, unchanged from 0001032975-17-000037:notes:101]

[0001032975-17-000053:notes:123]
The income tax provision for the three months ended September 30, 2017 was $4.1 million based on an effective income tax rate of 6.8% of pre-tax income, compared to an income tax provision of $5.6 million based on an effective income tax rate of 10.6% of pre-tax income for the three months ended September 30, 2016. The income tax benefit for the six months ended September 30, 2017 was $1.3 million based on an effective income tax rate of (1.5)% of pre-tax income, compared to an income tax provision of $8.7 million based on an effective income tax rate of 11.1% for the six months ended September 30, 2016.

[0001032975-17-000053:notes:124]
The change in the effective income tax rate is primarily due to the recognition of excess tax benefits of $1.1 million and $11.0 million, respectively, in the three and six months ended September 30, 2017 after adoption of ASU 2016-09, compared to the same periods ended September 30, 2016. In the three and six months ended September 30, 2017, there was a discrete tax benefit of $0.7 million and $1.9 million, respectively, from the reversal of uncertain tax positions from the expiration of statutes of limitations. In the same periods ended September 30, 2016, the tax benefit from the reversal of uncertain tax positions from the expiration of statutes of limitations was $0.7 million and $1.8 million, respectively.

[0001032975-17-000053:notes:125]
As of September 30 and March 31, 2017, the total amount of unrecognized tax benefits due to uncertain tax positions was $68.7 million and $63.7 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-17-000053:notes:126]
The Company had $33.2 million in non-current income taxes payable and $1.9 million in current income taxes payable, including interest and penalties, related to its income tax liability for uncertain tax positions as of September 30, 2017, compared to $51.8 million in non-current income taxes payable and $1.5 million in current income taxes payable as of March 31, 2017. The Company anticipates a settlement of $1.9 million with the tax authorities in a foreign jurisdiction in the third quarter of fiscal year 2018.

[0001032975-17-000053:notes:127]
The Company recognizes interest and penalties related to unrecognized tax positions in income tax expense. As of September 30 and March 31, 2017, the Company had $3.2 million and $3.0 million, respectively, of accrued interest and penalties related to uncertain tax positions.

[0001032975-17-000053:notes:128]
Although the Company has adequately provided for uncertain tax positions, the provisions on these positions may change as revised estimates are made or the underlying matters are settled or otherwise resolved. During fiscal year 2018, the Company will continue to review its tax positions and provide for or reverse unrecognized tax benefits as issues arise. During the next twelve months, it is reasonably possible that the amount of unrecognized tax benefits could increase or decrease significantly due to changes in tax law in various jurisdictions, new tax audits and changes in the U.S. dollar as compared to other currencies. Excluding these factors, uncertain tax positions may decrease by as much as $7.8 million from the lapse of the statutes of limitations in various jurisdictions during the next twelve months.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001032975-17-000053:notes:129]
Tangible long-lived assets by geographic region were as follows (in thousands):

[0001032975-17-000053:notes:130]
|  |  | September 30,2017 |  | March 31,2017 |
| Americas |  | $ | 37,725 |  |  | $ | 37,242 |  |
| EMEA |  | 4,110 |  |  | 4,006 |  |
| Asia Pacific |  | 45,520 |  |  | 44,160 |  |
| Total tangible long-lived assets |  | $ | 87,355 |  |  | $ | 85,408 |  |


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001032975-17-000053:notes:131]
Net sales by geographic region (based on the customers’ locations) for the three and six months ended September 30, 2017 and 2016 were as follows (in thousands):

[0001032975-17-000053:notes:132]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Americas |  | $ | 261,993 |  |  | $ | 239,830 |  |  | $ | 507,393 |  |  | $ | 462,455 |  |
| EMEA |  | 218,323 |  |  | 200,636 |  |  | 368,914 |  |  | 343,558 |  |
| Asia Pacific |  | 152,154 |  |  | 123,838 |  |  | 286,109 |  |  | 238,155 |  |
| Total net sales |  | $ | 632,470 |  |  | $ | 564,304 |  |  | $ | 1,162,416 |  |  | $ | 1,044,168 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001032975-17-000053:notes:133]
The components of accumulated other comprehensive income (loss) were as follows (in thousands):

[0001032975-17-000053:notes:134]
|  |  | Accumulated Other Comprehensive Income (Loss) |
|  |  | CumulativeTranslationAdjustment (1) |  | DefinedBenefitPlan (1) |  | DeferredHedgingLosses |  | Total |
| March 31, 2017 |  | $ | (89,708 | ) |  | $ | (10,480 | ) |  | $ | (518 | ) |  | $ | (100,706 | ) |
| Other comprehensive income (loss) |  | 3,641 |  |  | 482 |  |  | (2,220 | ) |  | 1,903 |  |
| September 30, 2017 |  | $ | (86,067 | ) |  | $ | (9,998 | ) |  | $ | (2,738 | ) |  | $ | (98,803 | ) |

[0001032975-17-000053:notes:135]
(1)        Tax effect was not significant as of September 30 or March 31, 2017.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001032975-17-000053:notes:136]
Net sales by product categories, excluding intercompany transactions, for the three and six months ended September 30, 2017 and 2016 were as follows (in thousands):

[0001032975-17-000053:notes:137]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Pointing Devices |  | $ | 123,643 |  |  | $ | 123,300 |  |  | $ | 245,717 |  |  | $ | 240,083 |  |
| Keyboards & Combos |  | 119,200 |  |  | 116,516 |  |  | 235,313 |  |  | 234,535 |  |
| PC Webcams |  | 27,466 |  |  | 24,307 |  |  | 53,091 |  |  | 49,569 |  |
| Tablet & Other Accessories |  | 30,784 |  |  | 20,614 |  |  | 54,002 |  |  | 34,499 |  |
| Video Collaboration |  | 46,139 |  |  | 28,581 |  |  | 81,756 |  |  | 52,491 |  |
| Mobile Speakers |  | 90,548 |  |  | 97,172 |  |  | 153,466 |  |  | 154,468 |  |
| Audio-PC & Wearables |  | 62,445 |  |  | 62,254 |  |  | 112,647 |  |  | 118,833 |  |
| Gaming |  | 113,722 |  |  | 79,193 |  |  | 191,430 |  |  | 135,693 |  |
| Smart Home |  | 18,323 |  |  | 11,807 |  |  | 34,789 |  |  | 22,974 |  |
| Other (1) |  | 200 |  |  | 560 |  |  | 205 |  |  | 1,023 |  |
| Total net sales |  | $ | 632,470 |  |  | $ | 564,304 |  |  | $ | 1,162,416 |  |  | $ | 1,044,168 |  |

[0001032975-17-000053:notes:138]
[same as prior period, unchanged from 0001032975-17-000037:notes:117]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001032975-17-000053:notes:139]
[same as prior period, unchanged from 0001032975-17-000037:notes:118]

[0001032975-17-000053:notes:140]
[same as prior period, unchanged from 0001032975-17-000037:notes:119]

[0001032975-17-000053:notes:141]
[same as prior period, unchanged from 0001032975-17-000037:notes:120]

[0001032975-17-000053:notes:142]
The United States and Germany each represented more than 10% of the total consolidated net sales for the periods presented herein. No other countries represented more than 10% of the Company’s total consolidated net sales for the periods presented herein.

[0001032975-17-000053:notes:143]
Switzerland, the Company’s home domicile, represented 2% of the Company’s total consolidated net sales for the three and six months ended September 30, 2017, and 3% and 2% for the three and six months ended September 30, 2016, respectively.

[0001032975-17-000053:notes:144]
Two customer groups of the Company each represented more than 10% of the total consolidated net sales for the periods presented herein.

[0001032975-17-000053:notes:145]
Tangible long-lived assets in the United States and China were $37.6 million and $38.1 million, respectively, as of September 30, 2017, and $37.1 million and $37.2 million, respectively, as of March 31, 2017. No other countries represented more than 10% of the Company’s total consolidated tangible long-lived assets as of September 30, 2017 or March 31, 2017. Tangible long-lived assets in Switzerland, the Company’s home domicile, were $2.0 million and $2.1 million as of September 30, 2017 and March 31, 2017, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001032975-17-000053:notes:146]
[same as prior period, unchanged from 0001032975-17-000037:notes:125]

[0001032975-17-000053:notes:147]
[same as prior period, unchanged from 0001032975-17-000037:notes:126]

[0001032975-17-000053:notes:148]
[same as prior period, unchanged from 0001032975-17-000037:notes:127]

[0001032975-17-000053:notes:149]
In March 2017, the Company's Board of Directors approved the 2017 share buyback program, which authorizes the Company to use up to $250.0 million to purchase up to 17.3 million shares of its own shares following the expiration date of the 2014 buyback program. The Company's share buyback program is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Purchases may be started or stopped at any time without prior notice depending on market conditions and other factors.

[0001032975-17-000053:notes:150]
During the six months ended September 30, 2017 and 2016, 0.3 million and 2.4 million shares, respectively, were repurchased for $10.7 million and $42.9 million, respectively.

[0001032975-17-000053:notes:151]
Cash Dividend on Shares of Common

[0001032975-17-000053:notes:152]
During the three and six months ended September 30, 2017, the Company declared and paid cash dividends of CHF 0.61 (USD equivalent of $0.63) per common share, totaling $104.2 million on the Company's outstanding common stock. During the three and six months ended September 30, 2016, the Company declared and paid cash dividends of CHF 0.56 (USD equivalent of $0.57) per common share, totaling $93.1 million on the Company's outstanding common stock.

[0001032975-17-000053:notes:153]
Any future dividends will be subject to the approval of the Company's shareholders.

[0001032975-17-000053:notes:154]
[same as prior period, unchanged from 0001032975-17-000037:notes:130]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001032975-17-000053:notes:155]
[same as prior period, unchanged from 0001032975-17-000037:notes:133]
