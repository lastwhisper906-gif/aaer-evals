# LOGI MD&A — 0001032975-17-000053


## mdna

[0001032975-17-000053:mdna:1]
[same as prior period, unchanged from 0001032975-17-000037:mdna:1]

[0001032975-17-000053:mdna:2]
[same as prior period, unchanged from 0001032975-17-000037:mdna:2]

[0001032975-17-000053:mdna:3]
[same as prior period, unchanged from 0001032975-17-000037:mdna:3]

[0001032975-17-000053:mdna:4]
Logitech is a world leader in designing, manufacturing and marketing products that have an everyday place in people's lives, connecting them to the digital experiences they care about. More than 35 years ago Logitech created products to improve experiences around the PC platform, and now it is designing products that enable better experiences consuming, sharing and creating any digital content (e.g. music, gaming, video), whether it is on a computer, mobile device or in the cloud. Logitech's brands include Logitech, Jaybird, ASTRO, Logitech G and Ultimate Ears.

[0001032975-17-000053:mdna:5]
[same as prior period, unchanged from 0001032975-17-000037:mdna:5]

[0001032975-17-000053:mdna:6]
[same as prior period, unchanged from 0001032975-17-000037:mdna:6]

[0001032975-17-000053:mdna:7]
On August 11, 2017 (the "Acquisition Date"), we acquired certain assets and liabilities constituting the ASTRO Gaming business ("ASTRO") from AG Acquisition Corporation for a preliminary purchase price of $85.0 million in cash (the "ASTRO Acquisition"). ASTRO is a leading console gaming brand with a history of producing award-winning headsets for professional gamers and enthusiasts.

[0001032975-17-000053:mdna:8]
[same as prior period, unchanged from 0001032975-17-000037:mdna:8]

[0001032975-17-000053:mdna:9]
Our net sales for the three and six months ended September 30, 2017 increased 12% and 11%, respectively, compared to the three and six months ended September 30, 2016, due to stronger net sales across all regions. The results of operations for ASTRO have been included in our condensed consolidated statements of operations from the Acquisition Date. For the three and six months ended September 30, 2017, Saitek, which was acquired on September 15, 2016, and ASTRO contributed a combined total of $7.0 million and $9.7 million to net sales, respectively, representing approximately 1% of the net sales for both periods.

[0001032975-17-000053:mdna:10]
Our net sales for the three months ended September 30, 2017 increased 9%, 9% and 23% in the Americas, EMEA and Asia Pacific, respectively, compared to the same period of the prior fiscal year. Our net sales for the six months ended September 30, 2017 increased 10%, 7% and 20% in the Americas, EMEA and Asia Pacific, respectively, compared to the same period of the prior fiscal year.

[0001032975-17-000053:mdna:11]
Given our global sales presence and the reporting of our financial results in U.S. Dollars, our financial results could be affected by shifts in currency exchange rates. See “Results of Operations” for information on the effect of currency exchange results on our net sales. If the U.S. Dollar becomes stronger or weaker in comparison to other currencies, it will also affect our results of operations in future periods.

[0001032975-17-000053:mdna:12]
We added a new third party logistics provider and distribution center in the United States in the second half of the second quarter of fiscal year 2018 to support our growth.  We experienced significant challenges in the transition, operating procedures and in ramping fulfillment in the second quarter and early third quarter of fiscal year 2018. Those challenges have added additional cost in these periods.

[0001032975-17-000053:mdna:13]
Our gross margin for the three months ended September 30, 2017 decreased to 36.0% from 36.7% for the three months ended September 30, 2016. The decrease in gross margin was primarily driven by an increase in promotions related to product transition, product mix, and additional costs from transition of the distribution center in the United States, partially offset by product cost reductions.

[0001032975-17-000053:mdna:14]
Our gross margin for the six months ended September 30, 2017 increased to 36.3% from 36.0% for the six months ended September 30, 2016. The increase in gross margin was primarily driven by product cost reductions, partially offset by an increase in promotions related to product transition, product mix, and additional costs from transition of the distribution center in the United States.

[0001032975-17-000053:mdna:15]
Operating expenses for the three months ended September 30, 2017 were $168.8 million, or 26.7% of net sales, compared to $153.5 million, or 27.2% of net sales, in the same period of the prior fiscal year. Operating expenses for the six months ended September 30, 2017 were $331.0 million, or 28.5% of net sales, compared to $296.2 million, or 28.4% of net sales, in the same period of the prior fiscal year. The increases were primarily driven by higher personnel-related costs due to increased headcount and higher external expenses to support the advertising, marketing, and research and development efforts for our new products, partially offset by a credit from change in fair value of contingent consideration from the Jaybird Acquisition.

[0001032975-17-000053:mdna:16]
Net income for the three and six months ended September 30, 2017 was $56.4 million and $93.4 million, compared to $47.0 million and $69.0 million for the three and six months ended September 30, 2016.

[0001032975-17-000053:mdna:17]
[same as prior period, unchanged from 0001032975-17-000037:mdna:14]

[0001032975-17-000053:mdna:18]
[same as prior period, unchanged from 0001032975-17-000037:mdna:15]

[0001032975-17-000053:mdna:19]
[same as prior period, unchanged from 0001032975-17-000037:mdna:16]

[0001032975-17-000053:mdna:20]
[same as prior period, unchanged from 0001032975-17-000037:mdna:17]

[0001032975-17-000053:mdna:21]
Music:  The music market grew during the first half of fiscal year 2018, driven by growing consumption of music through mobile devices such as smartphones and tablets. According to the Recording Industry Association of America (RIAA), revenues from streaming music platforms grew significantly in the first half of 2017. This market growth, together with our investments in the Ultimate Ears and Jaybird brands, new channel expansion, integration of personal voice assistants, such as Google Home and Amazon Alexa, and our new product introductions, has driven our growth in this market. The integration of personal voice assistants has become increasingly competitive in the speaker categories.

[0001032975-17-000053:mdna:22]
Gaming:  The PC gaming and console gaming platforms continue to show strong growth as online gaming, multi-platform experiences, and eSports gain greater popularity and gaming content becomes increasingly more demanding. We believe Logitech is well positioned to benefit from the PC gaming market growth. With the ASTRO Acquisition, we are also strengthening our portfolio in adjacent categories, such as the console gaming market.

[0001032975-17-000053:mdna:23]
Video Collaboration: The near and long-term structural growth opportunities in the video collaboration market is still significant. We are continuing our efforts to create and sell innovative products to accommodate the increasing demand from medium-sized meeting rooms to small-sized rooms such as huddle rooms. We will continue to invest in select business-specific products, targeted product marketing and sales channel development.

[0001032975-17-000053:mdna:24]
Smart Home:  This market increased in fiscal year 2017 and has continued to grow in the first half of fiscal year 2018. In October 2016, we integrated Amazon Alexa and Google Assistant voice capabilities into our Logitech Harmony Hub that enables voice control of the living room entertainment experience when used with an Amazon Echo or Echo Dot or a Google Home device. Through Harmony, Alexa can turn on/off and control a TV and AV system. We have also seen success with the professional installer channel through the recent introduction of the Harmony Pro. We will continue to explore other innovative experiences for the Smart Home.

[0001032975-17-000053:mdna:25]
Creativity & Productivity: Although new PC shipments continue to decline, the installed base of PC users remains large. We believe that innovative PC peripherals, such as our mice and keyboards, can renew the PC usage experience, providing growth opportunities. Smaller mobile computing devices, such as tablets, have created new markets and usage models for peripherals and accessories. We offer a number of products to enhance the use of mobile devices, including keyboard folios for the iPad Pro and iPad Mini, and keyboard covers and folios for the iPad Air.

[0001032975-17-000053:mdna:26]
[same as prior period, unchanged from 0001032975-17-000037:mdna:24]

[0001032975-17-000053:mdna:27]
[same as prior period, unchanged from 0001032975-17-000037:mdna:25]

[0001032975-17-000053:mdna:28]
[same as prior period, unchanged from 0001032975-17-000037:mdna:26]

[0001032975-17-000053:mdna:29]
The preparation of financial statements and related disclosures in conformity with GAAP requires us to make judgments, estimates and assumptions that affect reported amounts of assets, liabilities, goodwill and intangible assets from business acquisitions, contingent consideration from business acquisitions, and net sales and expenses.

[0001032975-17-000053:mdna:30]
[same as prior period, unchanged from 0001032975-17-000037:mdna:28]

[0001032975-17-000053:mdna:31]
[same as prior period, unchanged from 0001032975-17-000037:mdna:29]

[0001032975-17-000053:mdna:32]
Other than the recent accounting pronouncement adoptions discussed below, there have been no substantial changes in the Company’s significant accounting policies during the six months ended September 30, 2017, compared with the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended March 31, 2017.

[0001032975-17-000053:mdna:33]
[same as prior period, unchanged from 0001032975-17-000037:mdna:31]

[0001032975-17-000053:mdna:34]
In July 2015, the FASB issued ASU No. 2015-11, "Simplifying the Measurement of Inventory (Topic 330)" ("ASU 2015-11"). Topic 330, Inventory, previously required an entity to measure inventory at the lower of cost or market, with market value represented by replacement cost, net realizable value or net realizable value less a normal profit margin. ASU 2015-11 requires an entity to measure inventory at the lower of cost or net realizable value and effective for fiscal years beginning after December 15, 2016. We adopted this standard effective April 1, 2017, which has not had a material impact on our condensed consolidated financial statements.

[0001032975-17-000053:mdna:35]
In March 2016, the FASB issued ASU 2016-09, "Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting" ("ASU 2016-09"). ASU 2016-09 simplifies several aspects of the accounting for share-based payments, including immediate recognition of all excess tax benefits and deficiencies in the income statement, changing the threshold to qualify for equity classification up to the employees' maximum statutory tax rates, allowing an entity-wide accounting policy election to either estimate the number of awards that are expected to vest or account for forfeitures as they occur, and clarifying the classification on the statement of cash flows for the excess tax benefits and employee taxes paid when an employer withholds shares for tax withholding purposes. ASU 2016-09 is effective for fiscal years beginning after December 15, 2016. We adopted this standard effective April 1, 2017. Changes to the statements of cash flows related to the classification of excess tax benefits were implemented on a retroactive basis and accordingly, to conform to the current year presentation, we reclassified $4.1 million of excess tax benefits previously reported under financing activities to operating activities for the six months ended September 30, 2016 on our condensed consolidated statements of cash flows. Under the new standard, we account for forfeitures as they occur. The change in accounting for forfeitures resulted in a cumulative-effect adjustment to decrease retained earnings as of March 31, 2017 by $3.3 million. We further recognized a cumulative-effect adjustment to increase retained earnings as of March 31, 2017 by $57.2 million upon adoption of the new guidance to account for gross excess tax benefits of $75.2 million that were previously not recognized because the related tax deduction had not reduced current income taxes, offset by a valuation allowance of $18.0 million to reduce the deferred tax assets to amounts that are more likely than not to be realized.

[0001032975-17-000053:mdna:36]
In January 2017, the FASB issued ASU 2017-04, "Simplifying the Test for Goodwill Impairment (Topic 350)" ("ASU 2017-04"), which removes Step 2 from the goodwill impairment test. ASU 2017-04 is effective for for annual or any interim goodwill impairments in annual periods beginning December 15, 2019, with early adoption permitted. We adopted this standard effective April 1, 2017, which has not had a material impact on our condensed consolidated financial statements.

[0001032975-17-000053:mdna:37]
In May 2017, the FASB issued ASU 2017-09, "Compensation-Stock Compensation (Topic 718): Scope of Modification Accounting" ("ASU 2017-09"), which provides guidance about which changes to the terms or conditions

[0001032975-17-000053:mdna:38]
of a share-based payment award require an entity to apply modification accounting in Topic 718. ASU 2017-09 is effective for annual periods beginning after December 15, 2017, with early adoption permitted, including adoption in any interim period for which financial statements have not yet been issued. We adopted this standard effective April 1, 2017, which has not had a material impact on our condensed consolidated financial statements.

[0001032975-17-000053:mdna:39]
[same as prior period, unchanged from 0001032975-17-000037:mdna:36]

[0001032975-17-000053:mdna:40]
[same as prior period, unchanged from 0001032975-17-000037:mdna:37]

[0001032975-17-000053:mdna:41]
[same as prior period, unchanged from 0001032975-17-000037:mdna:38]

[0001032975-17-000053:mdna:42]
[same as prior period, unchanged from 0001032975-17-000037:mdna:39]

[0001032975-17-000053:mdna:43]
[same as prior period, unchanged from 0001032975-17-000037:mdna:45]

[0001032975-17-000053:mdna:44]
Although our financial results are reported in U.S. Dollars, a portion of our sales were generated in currencies other than the U.S. Dollar, such as the Euro, Chinese Renminbi, Japanese Yen, Canadian Dollar, Taiwan New Dollar, British Pound and Australian Dollar. During the three months ended September 30, 2017, 51% of our net sales were denominated in currencies other than the U.S. Dollar.

[0001032975-17-000053:mdna:45]
[same as prior period, unchanged from 0001032975-17-000037:mdna:40]

[0001032975-17-000053:mdna:46]
[same as prior period, unchanged from 0001032975-17-000037:mdna:41]

[0001032975-17-000053:mdna:47]
Net sales for the three and six months ended September 30, 2017 and 2016 were as follows (Dollars in thousands):

[0001032975-17-000053:mdna:48]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Net Sales |  | $ | 632,470 |  |  | $ | 564,304 |  |  | 12 | % |  | $ | 1,162,416 |  |  | $ | 1,044,168 |  |  | 11 | % |

[0001032975-17-000053:mdna:49]
Our net sales in the three and six months ended September 30, 2017 increased 12% and 11%, respectively, compared to the same periods of the prior fiscal year. Sales increased across all three regions during the three and six months ended September 30, 2017. If currency exchange rates had been constant in the three and six months ended September 30, 2017 and 2016, our constant dollar sales growth rates would have been 11% and 12%, respectively. We grew across most of our product categories, out of which Gaming, Video Collaboration, Tablet and Other Accessories, and Smart Home grew double digits for both periods presented above.  For the three months ended September 30, 2017, growth in these product categories was partially offset by the decline in the sales of our Mobile Speakers.

[0001032975-17-000053:mdna:50]
[same as prior period, unchanged from 0001032975-17-000037:mdna:47]

[0001032975-17-000053:mdna:51]
The following table presents the change in net sales by region for the three and six months ended September 30, 2017, compared with the three and six months ended September 30, 2016:

[0001032975-17-000053:mdna:52]
|  | Three Months EndedSeptember 30, 2017 Change in Sales |  | Six Months EndedSeptember 30, 2017Change in Sales |
| Americas | 9 | % |  | 10 | % |
| EMEA | 9 |  |  | 7 |  |
| Asia Pacific | 23 |  |  | 20 |  |

[0001032975-17-000053:mdna:53]
[same as prior period, unchanged from 0001032975-17-000037:mdna:50]

[0001032975-17-000053:mdna:54]
Net sales in the Americas increased 9% and 10% during the three and six months ended September 30, 2017, respectively, compared to the same periods of the prior fiscal year. If currency exchange rates had been constant in the three and six months ended September 30, 2017 and 2016, our constant dollar sales growth rate would have been 9% and 10% in the Americas, respectively. The increases in both periods were driven by growth in Tablet and Other Accessories, Video Collaboration, Gaming, Smart Home and Pointing Devices, partially offset by declines in sales for Mobile Speakers and Audio PC & Wearables.

[0001032975-17-000053:mdna:55]
[same as prior period, unchanged from 0001032975-17-000037:mdna:52]

[0001032975-17-000053:mdna:56]
Net sales in EMEA increased 9% and 7% during the three and six months ended September 30, 2017,  respectively, compared to the same periods of the prior fiscal year. If currency exchange rates had been constant in the three and six months ended September 30, 2017 and 2016, our constant dollar sales growth rates would have been 5% and 7%, respectively. The growth in both periods was driven by growth in Video Collaboration, Gaming and Smart Home, partially offset by declines in sales for Pointing Devices and Mobile Speakers.

[0001032975-17-000053:mdna:57]
[same as prior period, unchanged from 0001032975-17-000037:mdna:54]

[0001032975-17-000053:mdna:58]
Net sales in Asia Pacific increased 23% and 20% during the three and six months ended September 30, 2017, respectively, compared to the same periods of the prior fiscal year. If currency exchange rates had been constant in the three and six months ended September 30, 2017 and 2016, our constant dollar sales growth rates would have been 23% and 21%, respectively. The growth in both periods was driven by Gaming, Video Collaboration, Mobile Speakers, Pointing Devices, Tablet and Other Accessories and Audio PC & Wearables.

[0001032975-17-000053:mdna:59]
[same as prior period, unchanged from 0001032975-17-000037:mdna:56]

[0001032975-17-000053:mdna:60]
Net sales by product category for the three and six months ended September 30, 2017 and 2016 were as follows (Dollars in thousands):

[0001032975-17-000053:mdna:61]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Pointing Devices |  | $ | 123,643 |  |  | $ | 123,300 |  |  | — | % |  | $ | 245,717 |  |  | $ | 240,083 |  |  | 2 | % |
| Keyboards & Combos |  | 119,200 |  |  | 116,516 |  |  | 2 |  |  | 235,313 |  |  | 234,535 |  |  | — |  |
| PC Webcams |  | 27,466 |  |  | 24,307 |  |  | 13 |  |  | 53,091 |  |  | 49,569 |  |  | 7 |  |
| Tablet & Other Accessories |  | 30,784 |  |  | 20,614 |  |  | 49 |  |  | 54,002 |  |  | 34,499 |  |  | 57 |  |
| Video Collaboration |  | 46,139 |  |  | 28,581 |  |  | 61 |  |  | 81,756 |  |  | 52,491 |  |  | 56 |  |
| Mobile Speakers |  | 90,548 |  |  | 97,172 |  |  | (7 | ) |  | 153,466 |  |  | 154,468 |  |  | (1 | ) |
| Audio-PC & Wearables |  | 62,445 |  |  | 62,254 |  |  | — |  |  | 112,647 |  |  | 118,833 |  |  | (5 | ) |
| Gaming |  | 113,722 |  |  | 79,193 |  |  | 44 |  |  | 191,430 |  |  | 135,693 |  |  | 41 |  |
| Smart Home |  | 18,323 |  |  | 11,807 |  |  | 55 |  |  | 34,789 |  |  | 22,974 |  |  | 51 |  |
| Other (1) |  | 200 |  |  | 560 |  |  | (64 | ) |  | 205 |  |  | 1,023 |  |  | (80 | ) |
| Total net sales |  | $ | 632,470 |  |  | $ | 564,304 |  |  | 12 |  |  | $ | 1,162,416 |  |  | $ | 1,044,168 |  |  | 11 |  |

[0001032975-17-000053:mdna:62]
[same as prior period, unchanged from 0001032975-17-000037:mdna:59]

[0001032975-17-000053:mdna:63]
[same as prior period, unchanged from 0001032975-17-000037:mdna:60]

[0001032975-17-000053:mdna:64]
[same as prior period, unchanged from 0001032975-17-000037:mdna:80]

[0001032975-17-000053:mdna:65]
[same as prior period, unchanged from 0001032975-17-000037:mdna:81]

[0001032975-17-000053:mdna:66]
[same as prior period, unchanged from 0001032975-17-000037:mdna:82]

[0001032975-17-000053:mdna:67]
Net sales of Pointing Devices remained flat and increased 2% for the three and six months ended September 30, 2017, respectively, compared to the same periods of the prior fiscal year. The growth for the six-month period was driven by an increase in sales for our presentation tools and trackball mice.

[0001032975-17-000053:mdna:68]
[same as prior period, unchanged from 0001032975-17-000037:mdna:84]

[0001032975-17-000053:mdna:69]
[same as prior period, unchanged from 0001032975-17-000037:mdna:85]

[0001032975-17-000053:mdna:70]
Net sales of Keyboards & Combos increased 2% and remained flat in the three and six months ended September 30, 2017, respectively, compared to the same periods of the prior fiscal year. The increase for the three-month period was primarily driven by increases in sales for cordless keyboards, corded combos and corded keyboards.

[0001032975-17-000053:mdna:71]
[same as prior period, unchanged from 0001032975-17-000037:mdna:90]

[0001032975-17-000053:mdna:72]
[same as prior period, unchanged from 0001032975-17-000037:mdna:91]

[0001032975-17-000053:mdna:73]
PC Webcams net sales increased 13% and 7% in the three and six months ended September 30, 2017, respectively, compared to the same periods of the prior fiscal year. The increases were primarily driven by the continued success of our C922 Pro Stream webcam.

[0001032975-17-000053:mdna:74]
[same as prior period, unchanged from 0001032975-17-000037:mdna:87]

[0001032975-17-000053:mdna:75]
[same as prior period, unchanged from 0001032975-17-000037:mdna:88]

[0001032975-17-000053:mdna:76]
Net sales of Tablet & Other Accessories products increased 49% and 57% in the three and six months ended September 30, 2017, respectively, compared to the same periods of the prior fiscal year. The significant growth was primarily driven by the introduction of the Rugged Combo case for iPad Pro and the Slim Folio case for iPad, which were introduced in the fourth quarter of fiscal year 2017 and first quarter of fiscal year 2018, respectively.

[0001032975-17-000053:mdna:77]
[same as prior period, unchanged from 0001032975-17-000037:mdna:72]

[0001032975-17-000053:mdna:78]
[same as prior period, unchanged from 0001032975-17-000037:mdna:73]

[0001032975-17-000053:mdna:79]
[same as prior period, unchanged from 0001032975-17-000037:mdna:74]

[0001032975-17-000053:mdna:80]
Net sales of Video Collaboration products increased 61% and 56% in the three and six months ended September 30, 2017, respectively, compared to the same periods of the prior fiscal year. The increases were primarily due to the continued success of our Logitech Group conference camera, as well as the introductions of the Brio 4K Pro Webcam, PTZ Pro group camera, and Meetup video conference camera in the first half of fiscal year 2018.

[0001032975-17-000053:mdna:81]
[same as prior period, unchanged from 0001032975-17-000037:mdna:61]

[0001032975-17-000053:mdna:82]
[same as prior period, unchanged from 0001032975-17-000037:mdna:62]

[0001032975-17-000053:mdna:83]
[same as prior period, unchanged from 0001032975-17-000037:mdna:63]

[0001032975-17-000053:mdna:84]
Net sales of Mobile Speakers decreased 7% and 1% for the three and six months ended September 30, 2017, respectively, compared to the same period of the prior fiscal year. The decrease for the three-month period was primarily due to lower sales of UE Boom 2, UE Roll 2 and UE Mega Boom, in advance of the introduction of MEGABLAST and BLAST in the third quarter of fiscal year 2018, which were partially offset by the increase in sales for the UE WonderBoom, which was introduced in the first quarter of fiscal year 2018.

[0001032975-17-000053:mdna:85]
[same as prior period, unchanged from 0001032975-17-000037:mdna:65]

[0001032975-17-000053:mdna:86]
[same as prior period, unchanged from 0001032975-17-000037:mdna:66]

[0001032975-17-000053:mdna:87]
Audio-PC & Wearables net sales remained flat and decreased 5% for the three and six months ended September 30, 2017, respectively, compared to the same periods of the prior fiscal year. The decrease for the six months ended was primarily driven by a decline in sales for PC speakers and cordless headsets.

[0001032975-17-000053:mdna:88]
[same as prior period, unchanged from 0001032975-17-000037:mdna:68]

[0001032975-17-000053:mdna:89]
[same as prior period, unchanged from 0001032975-17-000037:mdna:69]

[0001032975-17-000053:mdna:90]
Our Gaming category comprises gaming mice, keyboards, headsets, gamepads, steering wheels, Saitek simulation controllers and ASTRO console gaming headsets.

[0001032975-17-000053:mdna:91]
Gaming net sales increased 44% and 41% for the three and six months ended September 30, 2017,  respectively, compared to the same periods of the prior fiscal year. The significant increases were primarily driven by the continuing success of our gaming mice, keyboards, headsets, simulation sticks and steering wheels, as well as the introduction of console gaming headsets resulting from the acquisition of ASTRO.

[0001032975-17-000053:mdna:92]
[same as prior period, unchanged from 0001032975-17-000037:mdna:76]

[0001032975-17-000053:mdna:93]
[same as prior period, unchanged from 0001032975-17-000037:mdna:77]

[0001032975-17-000053:mdna:94]
Our Smart Home category includes our Harmony line of advanced home entertainment controllers, home security cameras and new products, incorporating voice assistants, dedicated to controlling emerging categories of connected smart home devices such as lighting, thermostats and door locks.

[0001032975-17-000053:mdna:95]
Smart Home net sales increased 55% and 51% during the three and six months ended September 30, 2017, respectively, compared to the same periods of the prior fiscal year. The increases were primarily due to continued success of our Harmony Elite remote, as well as the introduction of Circle 2 Wired and Circle 2 Wireless security cameras in the second quarter of fiscal year 2018.

[0001032975-17-000053:mdna:96]
[same as prior period, unchanged from 0001032975-17-000037:mdna:93]

[0001032975-17-000053:mdna:97]
Gross profit for the three and six months ended September 30, 2017 and 2016 was as follows (Dollars in thousands):

[0001032975-17-000053:mdna:98]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Net sales |  | $ | 632,470 |  |  | $ | 564,304 |  |  | 12 | % |  | $ | 1,162,416 |  |  | $ | 1,044,168 |  |  | 11 | % |
| Gross profit |  | $ | 227,737 |  |  | $ | 206,873 |  |  | 10 |  |  | $ | 421,405 |  |  | $ | 375,499 |  |  | 12 |  |
| Gross margin |  | 36.0 | % |  | 36.7 | % |  |  |  | 36.3 | % |  | 36.0 | % |  |  |  |

[0001032975-17-000053:mdna:99]
Gross profit consists of net sales, less cost of goods sold (which includes materials, direct labor and related overhead costs, costs of manufacturing facilities, royalties, costs of purchasing components from outside suppliers, distribution costs, warranty costs, customer support, shipping and handling costs, outside processing costs and write-down of inventories), amortization of intangible assets and purchase accounting effect on inventory.

[0001032975-17-000053:mdna:100]
Our gross margin for the three months ended September 30, 2017 decreased by 70 basis points compared to the three months ended September 30, 2016. The decrease in gross margin was primarily driven by an increase in promotions related to product transition, product mix, and additional costs from transition of the distribution center in the United States, partially offset by product cost reductions.

[0001032975-17-000053:mdna:101]
Our gross margin for the six months ended September 30, 2017 increased by 30 basis points compared to the six months ended September 30, 2016. The increase in gross margin was primarily driven by product cost reductions, partially offset by an increase in promotions related to product transition, product mix, and additional costs from transition of the distribution center in the United States.

[0001032975-17-000053:mdna:102]
[same as prior period, unchanged from 0001032975-17-000037:mdna:98]

[0001032975-17-000053:mdna:103]
Operating expenses for the three and six months ended September 30, 2017 and 2016 were as follows (Dollars in thousands):

[0001032975-17-000053:mdna:104]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Marketing and selling |  | $ | 107,386 |  |  | $ | 93,792 |  |  | $ | 209,764 |  |  | $ | 177,664 |  |
| % of net sales |  | 17.0 | % |  | 16.6 | % |  | 18.0 | % |  | 17.0 | % |
| Research and development |  | 36,647 |  |  | 32,632 |  |  | 71,746 |  |  | 64,583 |  |
| % of net sales |  | 5.8 | % |  | 5.8 | % |  | 6.2 | % |  | 6.2 | % |
| General and administrative |  | 25,205 |  |  | 25,290 |  |  | 50,559 |  |  | 50,945 |  |
| % of net sales |  | 4.0 | % |  | 4.5 | % |  | 4.3 | % |  | 4.9 | % |
| Amortization of intangible assets and acquisition-related costs |  | 2,491 |  |  | 1,748 |  |  | 3,881 |  |  | 3,041 |  |
| % of net sales |  | 0.4 | % |  | 0.3 | % |  | 0.3 | % |  | 0.3 | % |
| Change in fair value of contingent consideration for business acquisition |  | (2,930 | ) |  | — |  |  | (4,908 | ) |  | — |  |
| % of net sales |  | (0.5 | )% |  | — | % |  | (0.4 | )% |  | — | % |
| Total operating expenses |  | $ | 168,799 |  |  | $ | 153,462 |  |  | $ | 331,042 |  |  | $ | 296,233 |  |
| % of net sales |  | 26.7 | % |  | 27.2 | % |  | 28.5 | % |  | 28.4 | % |

[0001032975-17-000053:mdna:105]
The increases in total operating expenses for the three and six months ended September 30, 2017, compared to the same period of the prior fiscal year, were mainly due to increases in marketing and selling expenses and research and development expenses from higher personnel-related costs due to increased headcount and higher external expenses to support the advertising and marketing efforts for our new products, partially offset by a credit from the change in fair value of contingent consideration for business acquisition.

[0001032975-17-000053:mdna:106]
[same as prior period, unchanged from 0001032975-17-000037:mdna:102]

[0001032975-17-000053:mdna:107]
[same as prior period, unchanged from 0001032975-17-000037:mdna:103]

[0001032975-17-000053:mdna:108]
During the three months ended September 30, 2017, marketing and selling expenses increased $13.6 million, compared to the same period of the prior fiscal year.  The increase was primarily driven by $7.1 million higher personnel-related costs due to increased headcount in addition to $5.7 million higher external expenses to support the advertising and marketing efforts for our new products. During the six months ended September 30, 2017, marketing and selling expenses increased $32.1 million compared to the same period of the prior fiscal year. The increase was primarily driven by $13.2 million higher personnel-related costs due to increased headcount in

[0001032975-17-000053:mdna:109]
addition to $18.5 million higher external expenses to support the advertising and marketing efforts for our new products.

[0001032975-17-000053:mdna:110]
[same as prior period, unchanged from 0001032975-17-000037:mdna:105]

[0001032975-17-000053:mdna:111]
[same as prior period, unchanged from 0001032975-17-000037:mdna:106]

[0001032975-17-000053:mdna:112]
During the three months ended September 30, 2017, research and development expenses increased $4.0 million compared to the same period in the prior fiscal year. The increase was primarily driven by $4.3 million higher personnel-related costs due to increased headcount to support the development and launch of new products and capabilities. During the six months ended September 30, 2017, research and development expenses increased $7.2 million compared to the same period in the prior fiscal year. The increase was primarily driven by $8.4 million higher personnel-related costs due to increased headcount to support the development and launch of new products and capabilities.

[0001032975-17-000053:mdna:113]
[same as prior period, unchanged from 0001032975-17-000037:mdna:108]

[0001032975-17-000053:mdna:114]
[same as prior period, unchanged from 0001032975-17-000037:mdna:109]

[0001032975-17-000053:mdna:115]
During the three and six months ended September 30, 2017, general and administrative expenses remained relatively flat, compared to the same periods in the prior fiscal year.

[0001032975-17-000053:mdna:116]
[same as prior period, unchanged from 0001032975-17-000037:mdna:111]

[0001032975-17-000053:mdna:117]
Amortization of intangibles and acquisition-related costs during the three and six months ended September 30, 2017 and 2016 were as follows (in thousands):

[0001032975-17-000053:mdna:118]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Amortization of intangible assets |  | $ | 1,750 |  |  | $ | 996 |  |  | $ | 2,839 |  |  | $ | 1,794 |  |
| Acquisition-related costs |  | 741 |  |  | 752 |  |  | 1,042 |  |  | 1,247 |  |
| Total |  | $ | 2,491 |  |  | $ | 1,748 |  |  | $ | 3,881 |  |  | $ | 3,041 |  |

[0001032975-17-000053:mdna:119]
Amortization of intangible assets consists of amortization of acquired intangible assets, including customer relationships and trade names. Acquisition-related costs include legal expense, due diligence costs, and other professional costs incurred for business acquisitions.

[0001032975-17-000053:mdna:120]
[same as prior period, unchanged from 0001032975-17-000037:mdna:115]

[0001032975-17-000053:mdna:121]
During the three months ended September 30, 2017, the fair value of the contingent consideration decreased  $2.9 million. The decrease in fair value of contingent consideration is primarily due to the agreement we reached with the sellers of Jaybird. In October 2017, we entered into an agreement with the sellers of Jaybird fully, irrevocably and unconditionally releasing the Company from the earn-out rights and payments in the Jaybird Acquisition agreement in exchange for $5.0 million in cash, which approximates the fair value of the contingent consideration as of September 30, 2017. During the six months ended September 30, 2017, the fair value of the contingent consideration decreased $4.9 million. See Note 7 to the Condensed Consolidated Financial Statements.

[0001032975-17-000053:mdna:122]
[same as prior period, unchanged from 0001032975-17-000037:mdna:122]

[0001032975-17-000053:mdna:123]
The provision for (benefit from) income taxes and effective tax rates for the three and six months ended September 30, 2017 and 2016 were as follows (Dollars in thousands):

[0001032975-17-000053:mdna:124]
|  |  | Three Months EndedSeptember 30, |  | Six Months Ended September 30, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Provision for (benefit from) income taxes |  | $ | 4,087 |  |  | $ | 5,593 |  |  | $ | (1,349 | ) |  | $ | 8,650 |  |
| Effective income tax rate |  | 6.8 | % |  | 10.6 | % |  | (1.5 | )% |  | 11.1 | % |

[0001032975-17-000053:mdna:125]
The change in the effective income tax rate is primarily due to the recognition of excess tax benefits of $1.1 million and $11.0 million, respectively, in the three and six months ended September 30, 2017 after adoption of ASU 2016-09, compared to the same periods ended September 30, 2016. In the three and six months ended September 30, 2017, there was a discrete tax benefit of $0.7 million and $1.9 million, respectively, from the reversal of uncertain tax positions from the expiration of statutes of limitations. In the same periods ended September 30, 2016, the tax benefit from the reversal of uncertain tax positions from the expiration of statutes of limitations was $0.7 million and $1.8 million, respectively.

[0001032975-17-000053:mdna:126]
As of September 30 and March 31, 2017, the total amount of unrecognized tax benefits due to uncertain tax positions was $68.7 million and $63.7 million, respectively, all of which would affect the effective income tax rate if recognized.

[0001032975-17-000053:mdna:127]
[same as prior period, unchanged from 0001032975-17-000037:mdna:127]

[0001032975-17-000053:mdna:128]
[same as prior period, unchanged from 0001032975-17-000037:mdna:128]

[0001032975-17-000053:mdna:129]
As of September 30, 2017, we had cash, cash equivalents and short-term investments of $405.6 million, compared to $547.5 million as of March 31, 2017, of which 42% is held in Switzerland, 24% is held in Germany, and 15% is held in Hong Kong and China as of September 30, 2017. We do not expect to incur any material adverse tax impact except for what has been recognized, or be significantly inhibited by any country in which we do business from the repatriation of funds to Switzerland, our home domicile.

[0001032975-17-000053:mdna:130]
The decrease in cash and cash equivalents was primarily due to the payment of cash dividends, the purchase of ASTRO, purchases of property, plant and equipment, tax withholdings related to settlements of restricted stock units and the purchases of our shares, partially offset by net income and proceeds from exercises of stock options and purchase rights.

[0001032975-17-000053:mdna:131]
As of September 30, 2017, our working capital was $445.5 million, compared to $520.8 million as of March 31, 2017. The decrease was primarily due to higher accounts payable and lower cash and cash equivalents, partially offset by higher accounts receivable, net and higher inventories. Our working capital increased compared to $396.7 million as of September 30, 2016, which was primarily driven by higher inventories, higher cash and cash equivalents and higher accounts receivable, net, partially offset by higher accounts payable and higher accruals and other liabilities.

[0001032975-17-000053:mdna:132]
We had several uncommitted, unsecured bank lines of credit aggregating $68.2 million as of September 30, 2017. There are no financial covenants under these lines of credit with which we must comply. As of September 30, 2017, we had outstanding bank guarantees of $39.8 million under these lines of credit.

[0001032975-17-000053:mdna:133]
[same as prior period, unchanged from 0001032975-17-000037:mdna:132]

[0001032975-17-000053:mdna:134]
|  |  | Six Months Ended September 30, |
|  |  | 2017 |  | 2016 |
| Net cash provided by operating activities |  | $ | 67,500 |  |  | $ | 91,886 |  |
| Net cash used in investing activities |  | (109,202 | ) |  | (81,485 | ) |
| Net cash used in financing activities |  | (108,636 | ) |  | (132,550 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | 1,653 |  |  | (1,845 | ) |
| Net decrease in cash and cash equivalents |  | $ | (148,685 | ) |  | $ | (123,994 | ) |

[0001032975-17-000053:mdna:135]
The following table presents selected financial information and statistics as of September 30, 2017 and 2016 (Dollars in thousands):

[0001032975-17-000053:mdna:136]
|  |  | Three Months EndedSeptember 30, |
|  |  | 2017 |  | 2016 |
| Accounts receivable, net |  | $ | 277,839 |  |  | $ | 240,606 |  |
| Accounts payable |  | $ | 386,963 |  |  | $ | 333,543 |  |
| Inventories |  | $ | 330,422 |  |  | $ | 268,110 |  |
| Days sales in accounts receivable (“DSO”) (Days) (1) |  | 40 |  |  | 38 |  |
| Days accounts payable outstanding (“DPO”) (Days) (2) |  | 86 |  |  | 84 |  |
| Inventory turnover (“ITO”) (x)(3) |  | 4.9 |  |  | 5.3 |  |

[0001032975-17-000053:mdna:137]
[same as prior period, unchanged from 0001032975-17-000037:mdna:136]

[0001032975-17-000053:mdna:138]
[same as prior period, unchanged from 0001032975-17-000037:mdna:137]

[0001032975-17-000053:mdna:139]
[same as prior period, unchanged from 0001032975-17-000037:mdna:138]

[0001032975-17-000053:mdna:140]
DSO for the three months ended September 30, 2017 increased two days, compared to September 30, 2016, primarily due to timing of net sales.

[0001032975-17-000053:mdna:141]
DPO for the three months ended September 30, 2017 increased two days, compared to September 30, 2016, due to higher inventory purchase for planned new product launches in the third quarter of fiscal year 2018.

[0001032975-17-000053:mdna:142]
ITO for the three months ended September 30, 2017 was lower, compared to the same period of the prior fiscal year. The increase in inventories compared with September 30, 2016 was primarily driven by higher purchase of inventories for planned new product launches in the third quarter of fiscal year 2018 and inventory acquired as part of ASTRO acquisition.

[0001032975-17-000053:mdna:143]
If we are not successful in launching and phasing in our new products, or market competition increases during the current fiscal year, or we are not able to sell the new products at the prices planned, it could have a material impact on our net sales, gross profit margin, operating results including operating cash flow, and inventory turnover in the future.

[0001032975-17-000053:mdna:144]
During the six months ended September 30, 2017, we generated $67.5 million cash in operating activities. Our main sources of operating cash flows were from net income after adding back non-cash expenses of depreciation, amortization, and share-based compensation expense, and from the increases in accounts payable, offset by the increases in accounts receivable, net and inventories. The increases in accounts receivable, net and accounts payable were primarily driven by higher business volumes and timing of payments.

[0001032975-17-000053:mdna:145]
Net cash used in investing activities was $109.2 million, primarily due to $85.0 million of purchase price for the acquisition of ASTRO business (refer to "Note 2- Business Acquisition" to the condensed consolidated financial statements), $17.2 million of purchases of property, plant, and equipment and $6.8 million purchases of short-term investments.

[0001032975-17-000053:mdna:146]
Net cash used in financing activities was $108.6 million, primarily for the $104.2 million cash dividends paid, $10.7 million repurchases of our registered shares and $23.7 million tax withholdings related to net share settlements of restricted stock units, partially offset by $30.0 million in proceeds received from the exercises of stock options.

[0001032975-17-000053:mdna:147]
Our expenditures for property, plant and equipment during the six months ended September 30, 2017 increased, compared to the same period of the prior fiscal year, mainly due to the higher amount of tooling purchases.

[0001032975-17-000053:mdna:148]
During the six months ended September 30, 2017, there was a $1.7 million gain of currency translation exchange rate effect on cash and cash equivalents, compared to a loss of $1.8 million during the same period of the prior fiscal year. The gain from currency translation exchange effect during the six months ended September 30, 2017 was primarily due to the strengthening of the Euro against the U.S. Dollar by 10% during the period. The loss from currency translation exchange effect during the six months ended September 30, 2016 was primarily due to weakening of the Euro against the U.S. Dollar by 2% during the period, which had an adverse impact on our cash and cash equivalents balances in subsidiaries with Euro as their functional currency.

[0001032975-17-000053:mdna:149]
[same as prior period, unchanged from 0001032975-17-000037:mdna:149]

[0001032975-17-000053:mdna:150]
[same as prior period, unchanged from 0001032975-17-000037:mdna:150]

[0001032975-17-000053:mdna:151]
During the three and six months ended September 30, 2017, we declared and paid cash dividends of approximately CHF 0.61 (USD equivalent of $0.63) per common share, totaling $104.2 million on our outstanding common stock. During the three and six months ended September 30, 2016, we declared and paid cash dividends of approximately CHF 0.56 (USD equivalent of $0.57) per common share, totaling $93.1 million on our outstanding common stock. Any future dividends will be subject to the approval of our shareholders.

[0001032975-17-000053:mdna:152]
In March 2017, our Board of Directors approved another share buyback program, which authorizes us to invest up to $250.0 million to purchase our own shares, following the expiration date of the 2014 buyback program. The new program was approved by the Swiss Takeover Board in May 2017. Although we enter into trading plans for systematic repurchases (e.g., 10b5-1 trading plans) from time to time, our share buyback program provides us with the opportunity to make opportunistic repurchases during periods of favorable market conditions and is expected to remain in effect for a period of three years. Shares may be repurchased from time to time on the open market, through block trades or otherwise. Opportunistic purchases may be started or stopped at any time without prior notice depending on market conditions and other factors. As of September 30, 2017, $239.9 million is still available for repurchase under the March 2017 program.

[0001032975-17-000053:mdna:153]
As noted in "Note 7 - Fair Value Measurements" to our condensed consolidated financial statements, we acquired all of the equity interest of Jaybird with an additional earn-out of up to $45.0 million in cash based on the achievement of certain net revenue growth targets over two years starting July 2016. If the net revenue growth targets are met, the Company will pay a maximum of $25.0 million and $20.0 million in fiscal years 2018 and 2019, respectively.  In October 2017, we entered into an agreement with the sellers of Jaybird fully, irrevocably and unconditionally releasing the Company from the earn-out rights and payments in the Jaybird purchase agreement in exchange for $5 million cash. The payment is expected to be made in the third quarter of fiscal year 2018.

[0001032975-17-000053:mdna:154]
[same as prior period, unchanged from 0001032975-17-000037:mdna:154]

[0001032975-17-000053:mdna:155]
If we do not generate sufficient operating cash flows to support our operations and future planned cash requirements, our operations could be harmed and our access to credit could be restricted or eliminated. However, we believe that the trend of our historical cash flow generation, our projections of future operations and our available cash balances will provide sufficient liquidity to fund our operations for at least the next 12 months.

[0001032975-17-000053:mdna:156]
[same as prior period, unchanged from 0001032975-17-000037:mdna:157]

[0001032975-17-000053:mdna:157]
[same as prior period, unchanged from 0001032975-17-000037:mdna:158]

[0001032975-17-000053:mdna:158]
[same as prior period, unchanged from 0001032975-17-000037:mdna:159]

[0001032975-17-000053:mdna:159]
As of September 30, 2017, we had non-cancelable purchase commitments for inventory purchases made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers, the majority of which are expected to be fulfilled within the next 12 months. Non-cancelable purchase commitments for capital expenditures primarily relate to commitments for tooling for new and existing products, computer hardware, leasehold and improvements. We expect to continue making capital expenditures in the future to support product development activities and ongoing and expanded operations. Although open purchase commitments are considered enforceable and legally binding, the terms generally allow us to reschedule or adjust our requirements based on business needs prior to delivery of goods or performance of services.

[0001032975-17-000053:mdna:160]
[same as prior period, unchanged from 0001032975-17-000037:mdna:161]

[0001032975-17-000053:mdna:161]
[same as prior period, unchanged from 0001032975-17-000037:mdna:162]

[0001032975-17-000053:mdna:162]
[same as prior period, unchanged from 0001032975-17-000037:mdna:163]

[0001032975-17-000053:mdna:163]
[same as prior period, unchanged from 0001032975-17-000037:mdna:164]

[0001032975-17-000053:mdna:164]
[same as prior period, unchanged from 0001032975-17-000037:mdna:165]

[0001032975-17-000053:mdna:165]
Logitech Europe S.A., one of our wholly-owned subsidiaries, guaranteed payments of two third-party contract manufacturers' purchase obligations. As of September 30, 2017, the maximum amount of this guarantee was $3.8 million, of which $1.4 million of guaranteed purchase obligations were outstanding.

[0001032975-17-000053:mdna:166]
[same as prior period, unchanged from 0001032975-17-000037:mdna:167]

[0001032975-17-000053:mdna:167]
We indemnify certain of our suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2017, no amounts have been accrued for indemnification provisions. We do not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under our indemnification arrangements.

[0001032975-17-000053:mdna:168]
[same as prior period, unchanged from 0001032975-17-000037:mdna:169]

[0001032975-17-000053:mdna:169]
The stock purchase agreement that we entered into in connection with the investment by three venture capital firms in Lifesize contains representations, warranties and covenants of Logitech and Lifesize to the Investors. Subject to certain limitations, we have agreed to indemnify the Investors and certain persons related to the Investors for certain losses resulting from breaches of or inaccuracies in such representations, warranties and covenants as well as certain other obligations, including third party expenses, restructuring costs and pre-closing tax obligations of Lifesize.

[0001032975-17-000053:mdna:170]
38

[0001032975-17-000053:mdna:171]
Legal Proceedings

[0001032975-17-000053:mdna:172]
From time to time we are involved in claims and legal proceedings that arise in the ordinary course of our business. We are currently subject to several such claims and a small number of legal proceedings. We believe that these matters lack merit and we intend to vigorously defend against them. Based on currently available information, we do not believe that resolution of pending matters will have a material adverse effect on our financial condition, cash flows or results of operations. However, litigation is subject to inherent uncertainties, and there can be no assurances that our defenses will be successful or that any such lawsuit or claim would not have a material adverse impact on our business, financial condition, cash flows and results of operations in a particular period. Any claims or proceedings against us, whether meritorious or not, can have an adverse impact because of defense costs, diversion of management and operational resources, negative publicity and other factors. Any failure to obtain necessary license or other rights, or litigation arising out of intellectual property claims, could adversely affect our business.

[0001032975-17-000053:mdna:173]
39
