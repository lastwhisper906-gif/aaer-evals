# LOGI note change history — 0001104659-14-083669 → 0001628280-15-000267


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-01-27):
[0001628280-15-000267:note_history:1]
Commitments and Contingencies
  (was, 2014-11-26, similarity 0.8657):
[0001104659-14-083669:note_history:1]
Note 11 — Commitments and Contingencies

- changed (2015-01-27):
[0001628280-15-000267:note_history:2]
Changes in the Company’s warranty liability for the three and nine months ended December 31, 2014 and 2013 were as follows (in thousands):
  (was, 2014-11-26, similarity 0.9615):
[0001104659-14-083669:note_history:2]
Changes in the Company’s warranty liability for the three and six months ended September 30, 2014 and 2013 were as follows (in thousands):

- changed (2015-01-27):
[0001628280-15-000267:note_history:3]
|  |  | Three Months Ended December 31, |  | Nine Months Ended December 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Beginning of the period |  | $ | 22,204 |  |  | $ | 23,021 |  |  | $ | 24,380 |  |  | $ | 21,442 |  |
| Provision |  | 2,381 |  |  | 4,343 |  |  | 6,607 |  |  | 11,532 |  |
| Settlements |  | (2,493 | ) |  | (3,842 | ) |  | (8,895 | ) |  | (11,779 | ) |
| Adjustment (1) |  | — |  |  | — |  |  | — |  |  | 2,327 |  |
| End of the period |  | $ | 22,092 |  |  | $ | 23,522 |  |  | $ | 22,092 |  |  | $ | 23,522 |  |
  (was, 2014-11-26, similarity 0.6625):
[0001104659-14-083669:note_history:3]
|  |  | Three Months Ended |  | Six Months Ended |  |
|  |  | September 30, |  | September 30, |  |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |  |
| Beginning of the period |  | $ | 23,420 |  | $ | 23,550 |  | $ | 24,380 |  | $ | 21,442 |  |
| Provision |  | 2,020 |  | 3,664 |  | 4,226 |  | 7,190 |  |
| Settlements |  | (3,236 | ) | (4,193 | ) | (6,402 | ) | (7,938 | ) |
| Adjustment (1) |  | — |  | — |  | — |  | 2,327 |  |
| End of the period |  | $ | 22,204 |  | $ | 23,021 |  | $ | 22,204 |  | $ | 23,021 |  |

- changed (2015-01-27):
[0001628280-15-000267:note_history:4]
(1)   During the nine month period December 31, 2013, the warranty liability allocated to the Company’s - Remotes product category was reclassified from liabilities held for sale.
  (was, 2014-11-26, similarity 0.9432):
[0001104659-14-083669:note_history:4]
|  | (1) |  | During the six month period September 30, 2013, the warranty liability allocated to the Company’s - Remotes product category was reclassified from liabilities held for sale. |

- changed (2015-01-27):
[0001628280-15-000267:note_history:5]
Commitments for inventory purchases are made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers and are expected to be fulfilled by December 31, 2014. Fixed purchase commitments for capital expenditures primarily related to commitments for computer hardware and leasehold improvements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the Company the option to reschedule and adjust its requirements based on the business needs prior to delivery of goods or performance of services.
  (was, 2014-11-26, similarity 0.7336):
[0001104659-14-083669:note_history:5]
Commitments for inventory purchases are made in the normal course of business to original design manufacturers, contract manufacturers and other suppliers and are expected to be fulfilled by September 30, 2014. Operating expense commitments are for consulting services, marketing arrangements, advertising, outsourced customer services, information technology maintenance and support services, and other services. Fixed purchase commitments for capital expenditures primarily related to commitments for computer hardware and leasehold improvements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the Company the option to reschedule and adjust its requirements based on the business needs prior to delivery of goods or performance of services. As of September 30, 2014, the Company’s outstanding purchase commitments had not materially changed since March 31, 2014.

- changed (2015-01-27):
[0001628280-15-000267:note_history:6]
Logitech Europe S.A.  guaranteed payments of a third-party contract manufacturer’s purchase obligations. As of December 31, 2014, the maximum amount of this guarantee was $3.5 million, of which $1.4 million of guaranteed purchase obligations were outstanding.
  (was, 2014-11-26, similarity 0.9859):
[0001104659-14-083669:note_history:6]
Logitech Europe S.A.  guaranteed payments of a third-party contract manufacturer’s purchase obligations. As of September 30, 2014, the maximum amount of this guarantee was $3.5 million, of which $2.7 million of guaranteed purchase obligations were outstanding.

- changed (2015-01-27):
[0001628280-15-000267:note_history:7]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of December 31, 2014, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.
  (was, 2014-11-26, similarity 0.9946):
[0001104659-14-083669:note_history:7]
The Company indemnifies certain of its suppliers and customers for losses arising from matters such as intellectual property disputes and product safety defects, subject to certain restrictions. The scope of these indemnities varies, but in some instances, includes indemnification for damages and expenses, including reasonable attorneys’ fees. As of September 30, 2014, no amounts have been accrued for these indemnification provisions. The Company does not believe, based on historical experience and information currently available, that it is probable that any material amounts will be required to be paid under its indemnification arrangements.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-01-27):
[0001628280-15-000267:note_history:8]
Summary of Significant Accounting Policies
  (was, 2014-11-26, similarity 0.9032):
[0001104659-14-083669:note_history:8]
Note 3 — Summary of Significant Accounting Policies

- changed (2015-01-27):
[0001628280-15-000267:note_history:9]
The consolidated interim financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (“GAAP”) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. They should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2014, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (“SEC”) on November 13, 2014.  In the opinion of management, these consolidated financial statements include all adjustments, consisting of normal recurring adjustments, necessary for a fair statement of the results for the periods presented. Operating results for the three and nine months ended December 31, 2014 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2015, or any future periods.
  (was, 2014-11-26, similarity 0.981):
[0001104659-14-083669:note_history:9]
The consolidated interim financial statements include the accounts of Logitech and its subsidiaries. All intercompany balances and transactions have been eliminated. The consolidated financial statements are presented in accordance with accounting principles generally accepted in the United States of America (“GAAP”) for interim financial information and therefore do not include all the information required by GAAP for complete financial statements. They should be read in conjunction with the Company’s audited consolidated financial statements for the fiscal year ended March 31, 2014, included in its Annual Report on Form 10-K filed with the Securities and Exchange Commission (“SEC”) on November 13, 2014.  In the opinion of management, these consolidated financial statements include all adjustments, consisting of normal recurring adjustments, necessary for a fair statement of the results for the periods presented. Operating results for the three and six months ended September 30, 2014 are not necessarily indicative of the results that may be expected for the fiscal year ending March 31, 2015, or any future periods.

- added (2015-01-27):
[0001628280-15-000267:note_history:10]
The Company’s fiscal year ends on March 31. Interim quarters are thirteen week periods, each ending on last Friday of the quarters.  For purposes of presentation, the Company has indicated its quarterly periods as ending on the quarter end.

- changed (2015-01-27):
[0001628280-15-000267:note_history:11]
There have been no substantial changes in the Company’s significant accounting policies during the nine months ended December 31, 2014 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2014.
  (was, 2014-11-26, similarity 0.9186):
[0001104659-14-083669:note_history:11]
There have been no substantial changes in the Company’s significant accounting policies during the six months ended September 30, 2014 compared with the significant accounting policies described in its Annual Report on Form 10-K for the fiscal year ended March 31, 2014.

- added (2015-01-27):
[0001628280-15-000267:note_history:12]
In November 2014, the FASB issued Accounting Standards Update No. 2014-17, "Business Combinations (Topic 805): Pushdown Accounting (a consensus of the FASB Emerging Issues Task Force)" ("ASU 2014-17"). ASU 2014-17 provides an acquired entity with an option to apply pushdown accounting in its separate financial statements upon occurrence of an event in which an acquirer obtains control of the acquired entity. An acquired entity may elect the option to apply pushdown accounting in the reporting period in which the change-in-control event occurs. The new standard is effective on November 18, 2014.  Early application is prohibited.  After the effective date, an acquired entity can make an election to apply the guidance to

- added (2015-01-27):
[0001628280-15-000267:note_history:13]
future change-in-control events or to its most recent change-in-control event. However, if the financial statements for the period in which the most recent change-in-control event occurred already have been issued or made available to be issued, the application of this guidance would be a change in accounting principle. The Company has adopted this new guidance and there's no impact on its consolidated financial statements.

- removed (2015-01-27):
[0001104659-14-083669:note_history:14]
The Company’s fiscal year ends on March 31. Interim quarters are thirteen-week periods, each ending on a Friday.  For purposes of presentation, the Company has indicated its quarterly periods as ending on the month end.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-01-27):
[0001628280-15-000267:note_history:15]
Financing Arrangements
  (was, 2014-11-26, similarity 0.8462):
[0001104659-14-083669:note_history:15]
Note 10— Financing Arrangements

- changed (2015-01-27):
[0001628280-15-000267:note_history:16]
The Company had several uncommitted, unsecured bank lines of credit aggregating $38.7 million as of December 31, 2014. There are no financial covenants under these lines of credit with which the Company must comply. As of December 31, 2014, the Company had outstanding bank guarantees of $7.5 million under these lines of credit.
  (was, 2014-11-26, similarity 0.7427):
[0001104659-14-083669:note_history:16]
The Company had several uncommitted, unsecured bank lines of credit aggregating $39.1 million as of September 30, 2014. There are no financial covenants under these lines of credit with which the Company must comply. As of September 30, 2014, the Company had outstanding bank guarantees of $7.0 million under these lines of credit. The Company also had credit lines related to corporate credit cards totaling $6.8 million as of September 30, 2014 and $6.9 million as of March 31, 2014. There are no financial covenants under these credit lines.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2015-01-27):
[0001104659-14-083669:note_history:17]
Note 14 — Subsequent Event

- removed (2015-01-27):
[0001104659-14-083669:note_history:18]
On November 12, 2014, the Board approved, subject to approval by the Company’s shareholders and other Swiss statutory requirements, a dividend of CHF 0.2625 per share. Based on the shares outstanding as of September 30, 2014, net of treasury shares, the aggregate amount of the dividend would be approximately CHF 42.9 million.
