# LOGI 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 6 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001032975-15-000023:item_9a:1]
ITEM 9A.    CONTROLS AND PROCEDURES

[0001032975-15-000023:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001032975-15-000023:item_9a:3]
As of the end of the period covered by this Annual Report on Form 10-K, Logitech carried out an evaluation, under the supervision and with the participation of our management, including our Chief Executive Officer and our Chief Financial Officer, of the effectiveness of our disclosure controls and procedures, as defined in Rule 13a-15(e) under the Securities and Exchange Act of 1934, as amended, ("the Exchange Act"). Disclosure controls and procedures are controls and other procedures designed to reasonably assure that information required to be disclosed in our reports filed or submitted under the Exchange Act, such as this Annual Report on Form 10-K, is recorded, processed, summarized and reported within the time periods specified in the Securities and Exchange Commission's rules and forms. Disclosure controls and procedures are also designed to reasonably assure that this information is accumulated and communicated to our management, including the Chief Executive Officer and the Chief Financial Officer, to allow timely decisions regarding required disclosure.

[0001032975-15-000023:item_9a:4]
Based on that evaluation, Logitech's Chief Executive Officer and Chief Financial Officer have concluded that, as of March 31, 2015, our disclosure controls and procedures were operating effectively, as described in Management's Report on Internal Control over Financial Reporting below.

[0001032975-15-000023:item_9a:5]
Management's Report on Internal Control over Financial Reporting

[0001032975-15-000023:item_9a:6]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting as such term is defined in Rule 13a-15(f) of the Exchange Act. Our management assessed, with the oversight of the Board of Directors, the effectiveness of our internal control over financial reporting as of March 31, 2015. In making this assessment, management used the criteria established in Internal Control-Integrated Framework (1992) issued by the Committee of Sponsoring Organizations of the Treadway Commission ("COSO"). Based on this assessment, management has concluded that the Company's internal control over financial reporting was effective as of March 31, 2015.

[0001032975-15-000023:item_9a:7]
Changes in Internal Controls over Financial Reporting:

[0001032975-15-000023:item_9a:8]
We implemented and enhanced the following internal control procedures which addressed previously identified material weaknesses. These internal control changes included the following:

[0001032975-15-000023:item_9a:9]
Changes to establish effective oversight of information, documentation and communication:

[0001032975-15-000023:item_9a:10]
| • | Finance and Accounting leadership team, including a new Chief Financial Officer (who was appointed Principal Financial and Accounting Officer), a new Vice President (VP) of Internal Audit, and a new VP, |

[0001032975-15-000023:item_9a:11]
67

[0001032975-15-000023:item_9a:12]
Corporate Controller, to strengthen oversight of the team and improve the design, implementation, execution and supervision of internal controls within the organization.

[0001032975-15-000023:item_9a:13]
| • | Enhanced lines of communications and other new policies and procedures that allow frequent open communication with key internal stakeholders, including Senior VPs and Directors, Legal Counsel, our advisors, and our independent registered public accounting firm, on key business and operational matters impacting financial reporting. |

[0001032975-15-000023:item_9a:14]
| • | Enhanced the Company's internal representation policies and procedures by requiring over 50 senior level employees to complete detailed questionnaires each quarter and ensured the feedback received is reviewed by the Controllership Group and appropriate actions are initiated and resolved. |

[0001032975-15-000023:item_9a:15]
| • | Enhanced the SOX Steering Committee, Disclosure Committee review process and the Audit Committee Communication process to include greater analyses of key financial statement information and metrics with a focus on areas involving greater management estimate and judgment to ensure greater transparency and effective monitoring and oversight. |

[0001032975-15-000023:item_9a:16]
| • | Implemented policy requiring formal documentation of the conclusions and basis for conclusions for all significant accounting positions and financial reporting issues, by finance and accounting personnel with sufficient technical competence, including review and approval by the appropriate level of management. |

[0001032975-15-000023:item_9a:17]
Changes to ensure that there is sufficient complement of personnel with appropriate accounting knowledge, experience and competence:

[0001032975-15-000023:item_9a:18]
| • | Hired experienced resources in the area of controllership functions, including SEC Reporting, Financial Planning and Analysis, Operations Finance, Regional Controllership Group, Revenue Recognition Accounting, and Corporate Consolidation and Reporting Group. |

[0001032975-15-000023:item_9a:19]
| • | Enhanced training for key individuals that provide critical information used in financial accounting and reporting to reinforce pre-established and new policies and procedures to improve our ability to prevent and detect potential material misstatements in our internally prepared reports, analyses and financial records. |

[0001032975-15-000023:item_9a:20]
| • | Identified skills gaps within the global finance and accounting organization and recruited resources with appropriate experience and technical expertise. |

[0001032975-15-000023:item_9a:21]
Changes to ensure that we have an appropriate methodology to accrue the costs of product warranties given to end customers (including an on-going review of the assumptions within the methodology to determine the completeness and accuracy of the warranty accrual):

[0001032975-15-000023:item_9a:22]
| • | Implemented new policies and procedures for identifying and accruing costs relating to product warranty, including documenting and evaluating the key assumptions used and ensuring the appropriate supervision and review each quarter. |

[0001032975-15-000023:item_9a:23]
Changes to ensure we consider all relevant information and document the underlying assumptions in our assessment of the valuation of finished goods, work in process and components inventory, including non-cancelable orders for such inventory:

[0001032975-15-000023:item_9a:24]
| • | Implemented new policies and procedures for analyzing our inventory reserves, including increased standardization and documentation over our evaluation of key inputs and assumptions such as aging, historical sales data, product life cycles and market acceptance. |

[0001032975-15-000023:item_9a:25]
Changes to ensure we review supporting information to determine the completeness and accuracy of the consolidated statement of cash flows, the consolidated statement of comprehensive income (loss) and disclosures in the notes to the consolidated financial statements:

[0001032975-15-000023:item_9a:26]
| • | Implemented a process to enhance the nature and extent of review of reports on Forms 10-Q and 10-K by a team led by the new Corporate Controller, a more robust process for disclosure committee |

[0001032975-15-000023:item_9a:27]
68

[0001032975-15-000023:item_9a:28]
meetings, and a final review of these filings with the Principal Financial and Accounting Officer. The Principal Financial and Accounting Officer and the Corporate Controller in turn report the results of this process to the Disclosure and Audit Committees in formal quarterly meetings.

[0001032975-15-000023:item_9a:29]
| • | Implemented processes and procedures to ensure the completeness and accuracy of the cash flow statement, the consolidated statement of comprehensive income (loss) and disclosures to the notes to the consolidated financial statements, including appropriate review and supervision over the individual components that support the sufficiency and appropriateness of these items each quarter. |

[0001032975-15-000023:item_9a:30]
After completing our testing of the design and operating effectiveness of these new enhanced procedures, we concluded that we have remediated the previously identified material weakness as of March 31, 2015.

[0001032975-15-000023:item_9a:31]
Except for the items noted above, we have made no changes to our internal control over financial reporting during the fiscal year ended March 31, 2015 that have materially affected, or that are reasonably likely to materially affect, our internal control over financial reporting.

[0001032975-15-000023:item_9a:32]
The effectiveness of the Company's internal control over financial reporting as of March 31, 2015 has been audited by KPMG LLP, an independent registered public accounting firm, as stated in its report, which appears in Item 15.

[0001032975-15-000023:item_9a:33]
Limitations on the Effectiveness of Controls

[0001032975-15-000023:item_9a:34]
The Company's management, including the Chief Executive Officer and Chief Financial Officer, does not expect that the Company's disclosure controls and procedures or internal control over financial reporting will prevent all errors and all fraud. Internal control over financial reporting, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the objectives will be met. Because of the inherent limitations in internal control over financial reporting, no evaluation of controls can provide absolute assurance that all control issues and instances of fraud, if any, within the Company have been detected. These inherent limitations include the realities that judgments in decision making can be faulty and that breakdowns can occur because of simple error or mistake. Controls can also be circumvented by the individual acts of some persons, by collusion of two or more people, or by management override of the controls. The design of any system of controls is based in part on certain assumptions about the likelihood of future events, and there can be no assurance that any design will succeed in achieving its stated goals under all potential future conditions. Over time, controls may become inadequate because of changes in conditions or deterioration in the degree of compliance with policies or procedures. Because of the inherent limitations in a cost-effective control system, misstatements due to error or fraud may occur and not be detected.
