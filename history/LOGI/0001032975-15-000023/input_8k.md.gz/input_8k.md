# LOGI 8-K — 0001032975-15-000008 filed 2015-04-23

## item codes, every 8-K on or before 2015-06-05

- 2015-05-14 0001032975-15-000011 — 8.01, 9.01
- 2015-04-23 0001032975-15-000008 — 2.02, 2.05
- 2015-01-22 0001628280-15-000191 — 2.02, 8.01
- 2014-12-23 0001193125-14-450908 — 5.02, 5.07, 8.01
- 2014-11-25 0001193125-14-425233 — 3.01
- 2014-11-13 0001193125-14-411303 — 4.01, 9.01
- 2014-10-23 0001104659-14-073164 — 2.02, 9.01
- 2014-09-04 0001193125-14-331214 — 4.02, 9.01
- 2014-08-18 0001193125-14-313346 — 3.01, 9.01
- 2014-07-24 0001104659-14-053065 — 2.02, 9.01
- 2014-06-05 0001193125-14-226177 — 3.01, 9.01
- 2014-05-22 0001193125-14-208777 — 8.01, 9.01
- 2014-04-24 0001104659-14-029650 — 2.02, 9.01
- 2014-01-23 0001104659-14-003619 — 2.02, 9.01
- 2013-10-24 0001104659-13-077404 — 2.02, 9.01
- 2013-09-09 0001193125-13-361441 — 5.02, 5.07, 8.01, 9.01
- 2013-09-06 0001193125-13-359930 — 5.02, 9.01
- 2013-08-02 0001193125-13-317343 — 5.02
- 2013-07-25 0001104659-13-056372 — 2.02, 9.01
- 2013-06-28 0001193125-13-277394 — 5.02, 9.01
- 2013-06-20 0001193125-13-265914 — 8.01, 9.01
- 2013-04-25 0001104659-13-032570 — 2.02, 9.01
- 2013-04-17 0001193125-13-158923 — 5.02, 9.01
- 2013-03-01 0001193125-13-085804 — 2.05
- 2013-01-24 0001104659-13-004214 — 2.02, 9.01
- 2013-01-02 0001193125-13-000058 — 5.02
- 2012-10-25 0001104659-12-070966 — 2.02, 9.01
- 2012-09-11 0001193125-12-388070 — 5.02, 5.07, 8.01, 9.01
- 2012-08-22 0001193125-12-364167 — 5.02, 8.01, 9.01
- 2012-07-26 0001104659-12-051084 — 2.02, 9.01
- 2012-06-08 0001193125-12-264132 — 2.05, 9.01 — amendment, the index does not say of what
- 2012-04-26 0001193125-12-183657 — 5.02, 9.01
- 2012-04-26 0001104659-12-028470 — 2.02, 2.05, 9.01
- 2012-03-15 0001193125-12-115954 — 5.02, 9.01
- 2012-01-26 0001104659-12-004014 — 2.02, 9.01
- 2012-01-04 0001193125-12-002212 — 1.01, 2.03, 9.01
- 2011-10-27 0001104659-11-058150 — 2.02, 9.01
- 2011-09-12 0001193125-11-245931 — 5.07
- 2011-07-28 0001193125-11-200929 — 5.02, 9.01
- 2011-07-28 0001193125-11-199704 — 2.02, 9.01
- 2011-04-28 0001193125-11-112669 — 2.02, 9.01
- 2011-03-24 0001193125-11-076483 — 5.02, 9.01
- 2011-01-27 0001032975-11-000003 — 9.01
- 2010-10-28 0001032975-10-000032 — 9.01
- 2010-09-13 0001032975-10-000022 — 5.07
- 2010-07-29 0001032975-10-000010 — 2.02, 9.01
- 2010-06-10 0001193125-10-136877 — 5.02, 9.01
- 2010-05-03 0001193125-10-104337 — 5.02
- 2010-04-29 0001032975-10-000008 — 2.02, 9.01
- 2010-02-19 0001032975-10-000006 — 9.01 — amendment of 0001193125-09-252416
- 2010-01-21 0001032975-10-000002 — 2.02, 9.01
- 2009-12-14 0001193125-09-252416 — 2.01, 9.01
- 2009-11-17 0001032975-09-000023 — 1.01
- 2009-10-22 0001032975-09-000018 — 9.01
- 2009-09-22 0001193125-09-195545 — 5.02, 9.01
- 2009-09-03 0001032975-09-000013 — 8.01
- 2009-07-23 0001140361-09-016802 — 2.02, 9.01
- 2009-06-01 0001193125-09-122550 — 5.02
- 2009-04-23 0001193125-09-085054 — 2.02, 9.01
- 2009-04-02 0001193125-09-071272 — 5.02, 9.01
- 2009-01-20 0001193125-09-008454 — 2.05 — amendment of 0001193125-09-002609
- 2009-01-20 0001193125-09-007902 — 2.02, 9.01
- 2009-01-07 0001193125-09-002609 — 2.05, 9.01
- 2009-01-07 0001193125-09-002370 — 5.02, 9.01
- 2008-12-09 0001193125-08-250543 — 5.02, 9.01
- 2008-10-21 0001193125-08-213212 — 2.02, 9.01
- 2008-07-22 0001193125-08-154721 — 2.02, 9.01
- 2008-06-24 0001193125-08-139163 — 5.03, 9.01
- 2008-05-13 0001193125-08-113263 — 5.02, 9.01
- 2008-04-22 0001193125-08-086176 — 2.02, 9.01

## late-filing notifications on or before 2015-06-05

- 2015-06-02 0001032975-15-000020 — NT 10-K, for the period ended 2015-03-31
- 2014-11-06 0001193125-14-401306 — NT 10-Q, for the period ended 2014-09-30
- 2014-07-24 0001193125-14-277575 — NT 10-Q, for the period ended 2014-06-30
- 2014-05-22 0001193125-14-208712 — NT 10-K, for the period ended 2014-03-31
- 2009-08-06 0001032975-09-000006 — NT 10-Q, for the period ended 2009-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001032975-15-000008:8k_2_02:1]
EX-99.1
2
exhibit991q4fy15.htm
EXHIBIT 99.1

[0001032975-15-000008:8k_2_02:2]
Exhibit 99.1 Q4FY15

[0001032975-15-000008:8k_2_02:3]
Exhibit 99.1

[0001032975-15-000008:8k_2_02:4]
For Immediate Release

[0001032975-15-000008:8k_2_02:5]
Editorial Contacts:

[0001032975-15-000008:8k_2_02:6]
Joe Greenhalgh, Vice President, Investor Relations - USA (510) 713-4430

[0001032975-15-000008:8k_2_02:7]
Krista Todd, Sr. Director, Communications - USA (510) 713-5834

[0001032975-15-000008:8k_2_02:8]
Ben Starkie, Corporate Communications - Europe +41-(0) 79-292-3499

[0001032975-15-000008:8k_2_02:9]
Logitech Exceeds Fiscal Year 2015 Expectations; Best Earnings in Seven Years

[0001032975-15-000008:8k_2_02:10]
Q4 Growth Category up 45 Percent in Constant Currency;

[0001032975-15-000008:8k_2_02:11]
Company Announces Acceleration of Growth Transformation

[0001032975-15-000008:8k_2_02:12]
NEWARK, Calif. - April 22, 2015 and LAUSANNE, Switzerland, April 23, 2015 - Logitech International (SIX: LOGN) (Nasdaq: LOGI) today announced preliminary financial results for the fourth quarter and full year of Fiscal Year 2015. Q4 closed a strong fiscal year with better-than-expected sales of $467 million - up 1 percent in constant currency - and GAAP operating income of $12 million, with non-GAAP operating income of $14 million.

[0001032975-15-000008:8k_2_02:13]
For the full Fiscal Year 2015, ended March 31, 2015:

[0001032975-15-000008:8k_2_02:14]
| • | Sales were $2.11 billion, down 1 percent compared to the previous fiscal year, and up 2 percent in constant currency. Importantly, Retail Strategic - sales in the Company’s Profit Maximization and Growth categories - grew by 6 percent in constant currency. |

[0001032975-15-000008:8k_2_02:15]
| • | GAAP operating income was $141 million, with GAAP earnings per share (EPS) of $0.81, compared to $0.46 a year ago. This was the Company’s best EPS since FY 2008. |

[0001032975-15-000008:8k_2_02:16]
| • | Non-GAAP operating income was $191 million, with non-GAAP EPS of $1.04, up from $0.75 a year ago (also the Company’s best since FY 2008). |

[0001032975-15-000008:8k_2_02:17]
| • | Cash flow from operations was $179 million. |

[0001032975-15-000008:8k_2_02:18]
“We closed Fiscal Year 2015 with a better-than-expected performance and good momentum in spite of currency headwinds,” said Bracken Darrell, Logitech president and chief executive officer. “Our Growth category - Gaming, Tablet and Other Accessories, Mobile Speakers and Video Collaboration - sales grew by 28 percent in constant currency over the full year, accelerating in the fourth quarter to 45 percent growth, the best performance of the fiscal year.

[0001032975-15-000008:8k_2_02:19]
“Looking at Fiscal Year 2016, we’re playing offense. We will accelerate our transformation of Logitech into a simpler, faster, growing company. We will focus on our growing Retail Strategic business. Consequently, we plan to exit our OEM business and reorganize Lifesize to sharpen its focus on its cloud-based offering. We will also streamline our overall cost structure through product, overhead and infrastructure cost reductions, including a targeted resource realignment. As a result, over the coming year we expect restructuring charges of approximately $15 million to $20 million. The savings from all these actions will be used to offset currency headwinds and invest in future growth.”

[0001032975-15-000008:8k_2_02:20]
Outlook

[0001032975-15-000008:8k_2_02:21]
Logitech confirmed its FY 2016 outlook of $150 million in non-GAAP operating income, despite the stronger currency headwinds, and 7% growth for Retail Strategic sales in constant currency.

[0001032975-15-000008:8k_2_02:22]
Preliminary Statement

[0001032975-15-000008:8k_2_02:23]
These preliminary Q4 and full year FY15 results are subject to material adjustments, including completion of our evaluation of Lifesize goodwill, Lifesize asset impairment and other subsequent events that may occur through the date of filing our Annual Report on Form 10-K.

[0001032975-15-000008:8k_2_02:24]
Prepared Remarks Available Online

[0001032975-15-000008:8k_2_02:25]
Logitech has made its prepared written remarks for the financial results teleconference available online on the Logitech corporate Web site at http://ir.logitech.com, in the Calendar section.

[0001032975-15-000008:8k_2_02:26]
Financial Results Teleconference and Webcast

[0001032975-15-000008:8k_2_02:27]
Logitech will hold a financial results teleconference to discuss the results for Q4 and full-year FY 2015 on Thurs., April 23, 2015 at 8:30 a.m. Eastern Standard Time and 14:30 Central European Time. A live webcast of the call will be available on the Logitech corporate website at http://ir.logitech.com.

[0001032975-15-000008:8k_2_02:28]
Use of Non-GAAP Financial Information

[0001032975-15-000008:8k_2_02:29]
To facilitate comparisons to Logitech’s historical results, Logitech has included non-GAAP adjusted measures, which exclude share-based compensation expense, amortization of other intangible assets, restructuring charges (credits), other restructuring-related charges, investment impairment (recovery), benefit from (provision for) income taxes, one-time special charges and other items detailed under “Supplemental Financial Information” after the tables below. Logitech also presents percentage sales growth in constant currency, a non-GAAP measure, to show performance unaffected by fluctuations in currency exchange rates. Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Logitech believes this information will help investors to evaluate its current period performance and trends in its business. With respect to our outlook for non-GAAP operating income, most of these excluded amounts pertain to events that have not yet occurred and are not currently possible to estimate with a reasonable degree of accuracy. Therefore, no reconciliation to a GAAP amount has been provided for FY 2016.

[0001032975-15-000008:8k_2_02:30]
About Logitech

[0001032975-15-000008:8k_2_02:31]
Logitech is a world leader in products that connect people to the digital experiences they care about. Spanning multiple computing, communication and entertainment platforms, Logitech’s combined hardware and software enable or enhance digital navigation, music and video entertainment, gaming, social networking, audio and video communication over the Internet, video security and home-entertainment control. Founded in 1981, Logitech International is a Swiss public company listed on the SIX Swiss Exchange (LOGN) and on the Nasdaq Global Select Market (LOGI).

[0001032975-15-000008:8k_2_02:32]
#   #   #

[0001032975-15-000008:8k_2_02:33]
reaction to them, on our sales, gross margins and profitability; if our products and marketing strategies fail to separate our products from competitors’ products; if we do not fully realize our goals to lower our costs and improve our operating leverage; if there is a deterioration of business and economic conditions in one or more of our sales regions or operating segments, or significant fluctuations in exchange rates; the effect of changes to our effective income tax rates. A detailed discussion of these and other risks and uncertainties that could cause actual results and events to differ materially from such forward-looking statements is included in Logitech’s periodic filings with the Securities and Exchange Commission, including our Quarterly Report on Form 10-Q for the fiscal quarter ended December 31, 2014 and our Annual Report on Form 10-K for the fiscal year ended March 31, 2014, available at www.sec.gov, under the caption Risk Factors and elsewhere. Logitech does not undertake any obligation to update any forward-looking statements to reflect new information or events or circumstances occurring after the date of this press release.

[0001032975-15-000008:8k_2_02:34]
Note that unless noted otherwise, comparisons are year over year.

[0001032975-15-000008:8k_2_02:35]
Logitech, the Logitech logo, and other Logitech marks are registered in Switzerland and other countries. All other trademarks are the property of their respective owners. For more information about Logitech and its products, visit the company’s Web site at www.logitech.com.

[0001032975-15-000008:8k_2_02:36]
(LOGIIR)

[0001032975-15-000008:8k_2_02:37]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS - The following financial statements and supplemental information may be subject to material adjustment. Please see note below the tables. |
| (In thousands, except per share amounts) -Unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| GAAP CONSOLIDATED STATEMENTS OF OPERATIONS |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Net sales |  | $ | 467,229 |  |  | $ | 490,321 |  |  | $ | 2,113,947 |  |  | $ | 2,128,713 |  |
| Cost of goods sold |  | 310,845 |  |  | 328,977 |  |  | 1,339,750 |  |  | 1,400,844 |  |
| Gross profit |  | 156,384 |  |  | 161,344 |  |  | 774,197 |  |  | 727,869 |  |
| % of net sales |  | 33.5 | % |  | 32.9 | % |  | 36.6 | % |  | 34.2 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Marketing and selling |  | 88,378 |  |  | 90,930 |  |  | 378,593 |  |  | 379,747 |  |
| Research and development |  | 33,755 |  |  | 30,796 |  |  | 131,012 |  |  | 139,385 |  |
| General and administrative |  | 27,239 |  |  | 28,693 |  |  | 128,196 |  |  | 118,940 |  |
| Restructuring charges (credit), net |  | (4,742 | ) |  | 5,190 |  |  | (4,888 | ) |  | 13,811 |  |
| Total operating expenses |  | 144,630 |  |  | 155,609 |  |  | 632,913 |  |  | 651,883 |  |
| Operating income |  | 11,754 |  |  | 5,735 |  |  | 141,284 |  |  | 75,986 |  |
| Interest income (expense), net |  | 388 |  |  | 465 |  |  | 1,225 |  |  | (397 | ) |
| Other income (expense), net |  | 1,347 |  |  | 632 |  |  | (2,752 | ) |  | 1,993 |  |
| Income before income taxes |  | 13,489 |  |  | 6,832 |  |  | 139,757 |  |  | 77,582 |  |
| Provision for (benefit from) income taxes |  | (3,228 | ) |  | (3,786 | ) |  | 4,490 |  |  | 3,278 |  |
| Net income |  | $ | 16,717 |  |  | $ | 10,618 |  |  | $ | 135,267 |  |  | $ | 74,304 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.10 |  |  | $ | 0.07 |  |  | $ | 0.83 |  |  | $ | 0.46 |  |
| Diluted |  | $ | 0.10 |  |  | $ | 0.06 |  |  | $ | 0.81 |  |  | $ | 0.46 |  |
| Shares used to compute net income per share : |  |  |  |  |  |  |  |  |
| Basic |  | 164,319 |  |  | 162,255 |  |  | 163,536 |  |  | 160,619 |  |
| Diluted |  | 166,424 |  |  | 165,766 |  |  | 166,174 |  |  | 162,526 |  |

[0001032975-15-000008:8k_2_02:38]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |
| PRELIMINARY RESULTS - The following financial statements and supplemental information may be subject to material adjustment. Please see note below the tables. |
| (In thousands) - Unaudited |  |  |  |  |
|  |  | March 31 |  | March 31, |
| CONSOLIDATED BALANCE SHEETS |  | 2015 |  | 2014 |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 537,038 |  |  | $ | 469,412 |  |
| Accounts receivable, net |  | 179,823 |  |  | 182,029 |  |
| Inventories |  | 270,231 |  |  | 222,402 |  |
| Other current assets |  | 64,996 |  |  | 59,157 |  |
| Total current assets |  | 1,052,088 |  |  | 933,000 |  |
| Non-current assets: |  |  |  |  |
| Property, plant and equipment, net |  | 91,593 |  |  | 88,391 |  |
| Goodwill |  | 340,782 |  |  | 345,010 |  |
| Other intangible assets |  | 1,866 |  |  | 10,529 |  |
| Other assets |  | 62,679 |  |  | 74,460 |  |
| Total assets |  | $ | 1,549,008 |  |  | $ | 1,451,390 |  |
| Current liabilities: |  |  |  |  |
| Accounts payable |  | $ | 299,995 |  |  | $ | 242,815 |  |
| Accrued and other current liabilities |  | 191,163 |  |  | 211,972 |  |
| Total current liabilities |  | 491,158 |  |  | 454,787 |  |
| Non-current liabilities: |  | 173,639 |  |  | 192,475 |  |
| Total liabilities |  | 664,797 |  |  | 647,262 |  |
| Total shareholders' equity |  | 884,211 |  |  | 804,128 |  |
| Total liabilities and shareholders' equity |  | $ | 1,549,008 |  |  | $ | 1,451,390 |  |

[0001032975-15-000008:8k_2_02:39]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS - The following financial statements and supplemental information may be subject to material adjustment. Please see note below the tables. |
| (In thousands) - Unaudited |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| CONSOLIDATED STATEMENTS OF CASH FLOWS |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 16,717 |  |  | $ | 10,618 |  |  | $ | 135,267 |  |  | $ | 74,304 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  | 11,745 |  |  | 16,212 |  |  | 41,304 |  |  | 48,967 |  |
| Amortization of other intangible assets |  | 737 |  |  | 2,781 |  |  | 8,361 |  |  | 17,771 |  |
| Share-based compensation expense |  | 5,779 |  |  | 8,134 |  |  | 25,825 |  |  | 25,546 |  |
| Impairment of investments |  | 39 |  |  | 56 |  |  | 2,298 |  |  | 624 |  |
| Loss (gain) on disposal of property, plant and equipment |  | — |  |  | 533 |  |  | (44 | ) |  | 4,411 |  |
| Excess tax benefits from share-based compensation |  | (298 | ) |  | (1,674 | ) |  | (2,831 | ) |  | (2,246 | ) |
| Deferred income taxes and other |  | 5,133 |  |  | (1,267 | ) |  | 1,982 |  |  | (4,828 | ) |
| Changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | 123,008 |  |  | 130,652 |  |  | (8,018 | ) |  | (219 | ) |
| Inventories |  | (29,840 | ) |  | 35,975 |  |  | (60,011 | ) |  | 49,471 |  |
| Other assets |  | 2,308 |  |  | 1,580 |  |  | (4,284 | ) |  | (1,388 | ) |
| Accounts payable |  | (50,897 | ) |  | (82,745 | ) |  | 60,413 |  |  | (21,322 | ) |
| Accrued and other liabilities |  | (42,857 | ) |  | (26,133 | ) |  | (21,630 | ) |  | 14,330 |  |
| Net cash provided by operating activities |  | 41,574 |  |  | 94,722 |  |  | 178,632 |  |  | 205,421 |  |
| Investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  | (10,476 | ) |  | (11,748 | ) |  | (45,253 | ) |  | (46,658 | ) |
| Investments in privately held companies |  | — |  |  | (300 | ) |  | (2,550 | ) |  | (300 | ) |
| Acquisitions, net of cash acquired |  | (926 | ) |  | — |  |  | (926 | ) |  | (650 | ) |
| Proceeds from return of investment from strategic investments |  | — |  |  | — |  |  | — |  |  | 261 |  |
| Purchases of trading investments |  | (1,571 | ) |  | (619 | ) |  | (5,034 | ) |  | (8,450 | ) |
| Proceeds from sales of trading investments |  | 1,618 |  |  | 683 |  |  | 5,474 |  |  | 8,994 |  |
| Net cash used in investing activities |  | (11,355 | ) |  | (11,984 | ) |  | (48,289 | ) |  | (46,803 | ) |
| Financing activities: |  |  |  |  |  |  |  |  |
| Payment of cash dividends |  | — |  |  | — |  |  | (43,767 | ) |  | (36,123 | ) |
| Purchase of treasury shares |  | (1,663 | ) |  | — |  |  | (1,663 | ) |  | — |  |
| Contingent consideration related to prior acquisition |  | — |  |  | — |  |  | (100 | ) |  | — |  |
| Repurchase of ESPP awards |  | — |  |  | — |  |  | (1,078 | ) |  | — |  |
| Proceeds from sales of shares upon exercise of options and purchase rights |  | 1,672 |  |  | 8,449 |  |  | 4,138 |  |  | 16,914 |  |
| Tax withholdings related to net share settlements of restricted stock units |  | (1,759 | ) |  | (2,781 | ) |  | (9,215 | ) |  | (5,718 | ) |
| Excess tax benefits from share-based compensation |  | 298 |  |  | 1,674 |  |  | 2,831 |  |  | 2,246 |  |
| Net cash provided by (used in) financing activities |  | (1,452 | ) |  | 7,342 |  |  | (48,854 | ) |  | (22,681 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (8,342 | ) |  | (533 | ) |  | (13,863 | ) |  | (349 | ) |
| Net increase in cash and cash equivalents |  | 20,425 |  |  | 89,547 |  |  | 67,626 |  |  | 135,588 |  |
| Cash and cash equivalents, beginning of the period |  | 516,613 |  |  | 379,865 |  |  | 469,412 |  |  | 333,824 |  |
| Cash and cash equivalents, end of the period |  | $ | 537,038 |  |  | $ | 469,412 |  |  | $ | 537,038 |  |  | $ | 469,412 |  |

[0001032975-15-000008:8k_2_02:40]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS - The following financial statements and supplemental information may be subject to material adjustment. Please see note below the tables. |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |  |  |  |  |  |  |
| NET SALES |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2015 |  | 2014 |  | Change |  | 2015 |  | 2014 |  | Change |
| Net sales by channel: |  |  |  |  |  |  |  |  |  |  |  |  |
| Retail |  | $ | 416,144 |  |  | $ | 424,193 |  |  | (1.9 | )% |  | $ | 1,887,446 |  |  | $ | 1,866,279 |  |  | 1.1 | % |
| OEM |  | 26,139 |  |  | 35,168 |  |  | (25.7 | ) |  | 117,462 |  |  | 141,749 |  |  | (17.1 | ) |
| Video conferencing |  | 24,946 |  |  | 30,960 |  |  | (19.4 | ) |  | 109,039 |  |  | 120,685 |  |  | (9.6 | ) |
| Total net sales |  | $ | 467,229 |  |  | $ | 490,321 |  |  | (4.7 | ) |  | $ | 2,113,947 |  |  | $ | 2,128,713 |  |  | (0.7 | ) |
| Net retail sales by product family(*): |  |  |  |  |  |  |  |  |  |  |  |  |
| Gaming |  | $ | 47,341 |  |  | $ | 45,281 |  |  | 4.5 |  |  | $ | 211,911 |  |  | $ | 186,926 |  |  | 13.4 |  |
| Tablet & Other Accessories |  | 26,021 |  |  | 22,221 |  |  | 17.1 |  |  | 140,994 |  |  | 172,484 |  |  | (18.3 | ) |
| Mobile Speakers |  | 38,406 |  |  | 19,382 |  |  | 98.2 |  |  | 178,038 |  |  | 87,414 |  |  | 103.7 |  |
| Video collaboration |  | 16,248 |  |  | 6,761 |  |  | 140.3 |  |  | 62,215 |  |  | 29,058 |  |  | 114.1 |  |
| Growth |  | 128,016 |  |  | 93,645 |  |  | 36.7 |  |  | 593,158 |  |  | 475,882 |  |  | 24.6 |  |
| Pointing Devices |  | 104,686 |  |  | 119,820 |  |  | (12.6 | ) |  | 487,210 |  |  | 506,884 |  |  | (3.9 | ) |
| Keyboards & Combos |  | 100,900 |  |  | 103,528 |  |  | (2.5 | ) |  | 426,117 |  |  | 415,314 |  |  | 2.6 |  |
| Audio-PC & Wearables |  | 51,015 |  |  | 59,435 |  |  | (14.2 | ) |  | 213,496 |  |  | 250,037 |  |  | (14.6 | ) |
| PC Webcams |  | 19,225 |  |  | 25,699 |  |  | (25.2 | ) |  | 96,680 |  |  | 113,791 |  |  | (15.0 | ) |
| Home Control |  | 11,836 |  |  | 13,421 |  |  | (11.8 | ) |  | 68,060 |  |  | 67,371 |  |  | 1.0 |  |
| Profit Maximization |  | 287,662 |  |  | 321,903 |  |  | (10.6 | ) |  | 1,291,563 |  |  | 1,353,397 |  |  | (4.6 | ) |
| Retail Strategic Sales |  | 415,678 |  |  | 415,548 |  |  | — |  |  | 1,884,721 |  |  | 1,829,279 |  |  | 3.0 |  |
| Other Non-Strategic |  | 466 |  |  | 8,645 |  |  | (94.6 | ) |  | 2,725 |  |  | 37,000 |  |  | (92.6 | ) |
| Total net retail sales |  | $ | 416,144 |  |  | $ | 424,193 |  |  | (1.9 | ) |  | $ | 1,887,446 |  |  | $ | 1,866,279 |  |  | 1.1 |  |
| __________________ |  |  |  |  |  |  |  |  |  |  |  |  |

[0001032975-15-000008:8k_2_02:41]
* Certain products within the retail product families as presented in prior years have been reclassified to conform to the current year presentation, with no impact on previously reported total net retail sales.

[0001032975-15-000008:8k_2_02:42]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS - The following financial statements and supplemental information may be subject to material adjustment. Please see note below the tables. |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |  |  |  |  |
| GAAP TO NON GAAP RECONCILIATION (A) |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Gross profit - GAAP |  | $ | 156,384 |  |  | $ | 161,344 |  |  | $ | 774,197 |  |  | $ | 727,869 |  |
| Share-based compensation expense |  | 749 |  |  | 675 |  |  | 2,473 |  |  | 2,518 |  |
| Amortization of other intangible assets |  | 515 |  |  | 549 |  |  | 2,141 |  |  | 7,910 |  |
| Restructuring-related charges |  | — |  |  | — |  |  | — |  |  | 5,194 |  |
| Gross profit - Non-GAAP |  | $ | 157,648 |  |  | $ | 162,568 |  |  | $ | 778,811 |  |  | $ | 743,491 |  |
| Gross margin - GAAP |  | 33.5 | % |  | 32.9 | % |  | 36.6 | % |  | 34.2 | % |
| Gross margin - Non-GAAP |  | 33.7 | % |  | 33.2 | % |  | 36.8 | % |  | 34.9 | % |
| Operating expenses - GAAP |  | $ | 144,630 |  |  | $ | 155,609 |  |  | $ | 632,913 |  |  | $ | 651,883 |  |
| Less: Share-based compensation expense |  | 5,030 |  |  | 7,459 |  |  | 23,352 |  |  | 23,028 |  |
| Less: Amortization of other intangible assets |  | 222 |  |  | 2,232 |  |  | 6,220 |  |  | 9,861 |  |
| Less: Restructuring charges (credits), net |  | (4,742 | ) |  | 5,190 |  |  | (4,888 | ) |  | 13,811 |  |
| Less: One time special charge |  | 963 |  |  | — |  |  | 20,487 |  |  | — |  |
| Operating expenses - Non-GAAP |  | $ | 143,157 |  |  | $ | 140,728 |  |  | $ | 587,742 |  |  | $ | 605,183 |  |
| % of net sales - GAAP |  | 31.0 | % |  | 31.7 | % |  | 29.9 | % |  | 30.6 | % |
| % of net sales - Non - GAAP |  | 30.6 | % |  | 28.7 | % |  | 27.8 | % |  | 28.4 | % |
| Operating income - GAAP |  | $ | 11,754 |  |  | $ | 5,735 |  |  | $ | 141,284 |  |  | $ | 75,986 |  |
| Share-based compensation expense |  | 5,779 |  |  | 8,134 |  |  | 25,825 |  |  | 25,546 |  |
| Amortization of other intangible assets |  | 737 |  |  | 2,781 |  |  | 8,361 |  |  | 17,771 |  |
| Restructuring charges (credits), net |  | (4,742 | ) |  | 5,190 |  |  | (4,888 | ) |  | 13,811 |  |
| Restructuring related charges |  | — |  |  | — |  |  | — |  |  | 5,194 |  |
| One time special charge |  | 963 |  |  | — |  |  | 20,487 |  |  | — |  |
| Operating income - Non - GAAP |  | $ | 14,491 |  |  | $ | 21,840 |  |  | $ | 191,069 |  |  | $ | 138,308 |  |
| % of net sales - GAAP |  | 2.5 | % |  | 1.2 | % |  | 6.7 | % |  | 3.6 | % |
| % of net sales - Non - GAAP |  | 3.1 | % |  | 4.5 | % |  | 9.0 | % |  | 6.5 | % |
| Net income - GAAP |  | $ | 16,717 |  |  | $ | 10,618 |  |  | $ | 135,267 |  |  | $ | 74,304 |  |
| Share-based compensation expense |  | 5,779 |  |  | 8,134 |  |  | 25,825 |  |  | 25,546 |  |
| Amortization of other intangible assets |  | 737 |  |  | 2,781 |  |  | 8,361 |  |  | 17,771 |  |
| Restructuring related charges |  | — |  |  | — |  |  | — |  |  | 5,194 |  |
| Restructuring charges (credits), net |  | (4,742 | ) |  | 5,190 |  |  | (4,888 | ) |  | 13,811 |  |
| One time special charge |  | 963 |  |  | — |  |  | 20,487 |  |  | — |  |
| Investment impairment, net |  | 39 |  |  | 56 |  |  | 2,298 |  |  | 203 |  |
| Provision for income taxes |  | (2,434 | ) |  | (5,443 | ) |  | (14,682 | ) |  | (15,590 | ) |
| Net income - Non - GAAP |  | $ | 17,059 |  |  | $ | 21,336 |  |  | $ | 172,668 |  |  | $ | 121,239 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP |  | $ | 0.10 |  |  | $ | 0.06 |  |  | $ | 0.81 |  |  | $ | 0.46 |  |
| Diluted - Non - GAAP |  | $ | 0.10 |  |  | $ | 0.13 |  |  | $ | 1.04 |  |  | $ | 0.75 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |  |
| Diluted - GAAP and Non GAAP |  | 166,424 |  |  | 165,766 |  |  | 166,174 |  |  | 162,526 |  |

[0001032975-15-000008:8k_2_02:43]
| LOGITECH INTERNATIONAL S.A. |  |  |  |  |  |  |  |  |
| PRELIMINARY RESULTS - The following financial statements and supplemental information may be subject to material adjustment. Please see note below the tables. |
| (In thousands, except per share amounts) - Unaudited |  |  |  |  |  |  |  |  |
| SHARED BASED COMPENSATION EXPENSE |  | Three Months Ended |  | Fiscal Years Ended |
|  |  | March 31, |  | March 31, |
| SUPPLEMENTAL FINANCIAL INFORMATION |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Share-based Compensation Expense |  |  |  |  |  |  |  |  |
| Cost of goods sold |  | $ | 749 |  |  | $ | 675 |  |  | $ | 2,473 |  |  | $ | 2,518 |  |
| Marketing and selling |  | 2,099 |  |  | 2,318 |  |  | 9,094 |  |  | 8,298 |  |
| Research and Development |  | 762 |  |  | 706 |  |  | 3,224 |  |  | 4,546 |  |
| General and administrative |  | 2,169 |  |  | 4,435 |  |  | 11,034 |  |  | 10,184 |  |
| Income tax benefit |  | (838 | ) |  | (2,559 | ) |  | (5,558 | ) |  | (4,902 | ) |
| Total share-based compensation expense after income taxes |  | $ | 4,941 |  |  | $ | 5,575 |  |  | $ | 20,267 |  |  | $ | 20,644 |  |
| __________________ |  |  |  |  |  |  |  |  |

[0001032975-15-000008:8k_2_02:44]
NOTE:  The preliminary results for the three months and full year ended March 31 of Fiscal Year 2015 contained in this release are subject to material adjustments based on the completion of our evaluation of Lifesize goodwill, Lifesize asset impairment and other subsequent events that may occur through the date of filing our Annual Report on Form 10-K with the U.S. Securities and Exchange Commission.

[0001032975-15-000008:8k_2_02:45]
(A) Non-GAAP Financial Measures

[0001032975-15-000008:8k_2_02:46]
To supplement our condensed consolidated financial results prepared in accordance with GAAP, we use a number of financial measures, both GAAP and non-GAAP, in analyzing and assessing our overall business performance, for making operating decisions and for forecasting and planning future periods. We consider the use of non-GAAP financial measures helpful in assessing our current financial performance, ongoing operations and prospects for the future as well as understanding financial and business trends relating to our financial condition and results of operations.

[0001032975-15-000008:8k_2_02:47]
While we use non-GAAP financial measures as a tool to enhance our understanding of certain aspects of our financial performance and to provide incremental insight into the underlying factors and trends affecting both our performance and our cash-generating potential, we do not consider these measures to be a substitute for, or superior to, the information provided by GAAP financial measures. Consistent with this approach, we believe that disclosing non-GAAP financial measures to the readers of our financial statements provides useful supplemental data that, while not a substitute for GAAP financial measures, can offer insight in the review of our financial and operational performance and enables investors to more fully understand trends in our current and future performance. In assessing our business during the quarter and year ended March 31, 2015, we excluded items in the following general categories, each of which are described below:

[0001032975-15-000008:8k_2_02:48]
Share-based compensation expenses. We believe that providing non-GAAP measures excluding share-based compensation expense, in addition to the GAAP measures, allows for a more transparent comparison of our financial results from period to period. We prepare and maintain our budgets and forecasts for future periods on a basis consistent with this non-GAAP financial measure. Further, companies use a variety of types of equity awards as well as a variety of methodologies, assumptions and estimates to determine share-based compensation expense. We believe that excluding share-based compensation expense enhances our ability and the ability of investors to understand the impact of non-cash share-based compensation on our operating results and to compare our results against the results of other companies.

[0001032975-15-000008:8k_2_02:49]
Amortization of other intangible assets. We incur intangible asset amortization expense, primarily in connection with our acquisitions of various businesses and technologies. The amortization of purchased intangibles varies depending on the level of acquisition activity. We exclude these various charges in budgeting, planning and forecasting future periods and we believe that providing the non-GAAP measures excluding these various non-cash charges, as well as the GAAP measures, provides additional insight when comparing our operating expenses and financial results from period to period.

[0001032975-15-000008:8k_2_02:50]
Restructuring and restructuring-related charges. These expenses are associated with re-aligning our business strategies based on current economic conditions. We have undertaken several restructurings in recent years. In connection with our restructuring initiatives, we incurred restructuring charges related to employee terminations, facility closures and early cancellation of certain contracts. Our restructuring initiatives also resulted in other costs related to restructurings not qualifying for inclusion in

[0001032975-15-000008:8k_2_02:51]
restructuring charges. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operating results in the current period.

[0001032975-15-000008:8k_2_02:52]
Investment impairment, net. We incur investment impairment, primarily related to our investments in various privately-held companies. The investment impairment varies depending on the operational and financial performance of the privately-held companies we invested in. We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are not reflective of our ongoing operations.

[0001032975-15-000008:8k_2_02:53]
One-time special charges:  costs related to investigations.  These expenses are forensic accounting, audit,

[0001032975-15-000008:8k_2_02:54]
consulting and legal fees related to the Audit Committee’s investigation and the ongoing formal investigation by the Securities and Exchange Commission.  We believe that providing the non-GAAP measures excluding these charges, as well as the GAAP measures, assists our investors because such charges are one-time in nature and not reflective of our ongoing operations.

[0001032975-15-000008:8k_2_02:55]
Other charges. We provided non-GAAP measures excluding the effect of certain charges and income that are not reflective of our ongoing operations.

[0001032975-15-000008:8k_2_02:56]
In addition, Logitech presents percentage sales growth in constant currency, a non-GAAP measure, to show performance unaffected by fluctuations in currency exchange rates.  Percentage sales growth in constant currency is calculated by translating prior period sales in each local currency at the current period’s average exchange rate for that currency and comparing that to current period sales. Sales for the three months ended March 31, 2015 compared to sales for the three months ended March 31, 2014 grew by 1 percent in constant currency and declined by 5 percent in U.S. dollars. Retail Strategic sales for the full fiscal year ended March 31, 2015 compared to the Retail Strategic sales for the full fiscal year ended March 31, 2014 grew by 6 percent in constant currency and 3 percent in U.S. dollars.

[0001032975-15-000008:8k_2_02:57]
Each of the non-GAAP financial measures described above, and used in this press release, should not be considered in isolation from, or as a substitute for, a measure of financial performance prepared in accordance with GAAP. Further, investors are cautioned that there are inherent limitations associated with the use of each of these non-GAAP financial measures as an analytical tool. In particular, these non-GAAP financial measures are not based on a comprehensive set of accounting rules or principles and many of the adjustments to the GAAP financial measures reflect the exclusion of items that are recurring and may be reflected in the Company’s financial results for the foreseeable future. We compensate for these limitations by providing specific information in the reconciliation included in this press release regarding the GAAP amounts excluded from the non-GAAP financial measures. In addition, as noted above, we evaluate the non-GAAP financial measures together with the most directly comparable GAAP financial information.
